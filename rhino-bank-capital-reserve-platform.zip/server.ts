import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { 
  PortfolioAsset, 
  CapitalMetrics, 
  LiquidityProfile, 
  BondAnalyticsResult, 
  ScenarioDefinition, 
  StressProjectionResult, 
  AuditLogEntry 
} from "./src/types";

// Helper for crypto hash (to sign audit logs)
import crypto from "crypto";

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Database representing Rhino Bank's Portfolio and Systems (Simulating Rust Treasury Engine)
let portfolio: PortfolioAsset[] = [
  { id: "1", name: "UK Gilt 2030", category: "Government Bonds", value: 12000, expectedReturn: 3.2, volatility: 4.5, duration: 7.2, convexity: 65.0, riskWeight: 0, creditRating: "AA" },
  { id: "2", name: "US Treasury 10Y", category: "Government Bonds", value: 9500, expectedReturn: 3.8, volatility: 4.8, duration: 8.1, convexity: 78.0, riskWeight: 0, creditRating: "AAA" },
  { id: "3", name: "HSBC Corporate Bond 2035", category: "Corporate Bonds", value: 8500, expectedReturn: 4.8, volatility: 6.2, duration: 5.4, convexity: 38.0, riskWeight: 50, creditRating: "A-" },
  { id: "4", name: "M6 Motorway Project Bond", category: "Infrastructure Debt", value: 4200, expectedReturn: 6.0, volatility: 8.0, duration: 9.1, convexity: 92.0, riskWeight: 75, creditRating: "BBB" },
  { id: "5", name: "Yorkshire SME Private Credit Fund", category: "Private Credit", value: 3500, expectedReturn: 7.5, volatility: 9.5, duration: 4.2, convexity: 22.0, riskWeight: 100, creditRating: "BB+" },
  { id: "6", name: "Global Equity Index", category: "Equities", value: 6000, expectedReturn: 9.0, volatility: 16.0, duration: 0, convexity: 0, riskWeight: 100, creditRating: "N/A" },
  { id: "7", name: "London Prime Commercial Real Estate", category: "Property", value: 3000, expectedReturn: 6.5, volatility: 12.0, duration: 0, convexity: 0, riskWeight: 100, creditRating: "N/A" },
  { id: "8", name: "Sherburn Wind Farm Debt Pool", category: "Renewable Energy", value: 2500, expectedReturn: 7.0, volatility: 10.0, duration: 8.5, convexity: 80.0, riskWeight: 50, creditRating: "BBB+" },
  { id: "9", name: "Northern Powerhouse VC II", category: "Venture Capital", value: 1200, expectedReturn: 14.0, volatility: 25.0, duration: 0, convexity: 0, riskWeight: 150, creditRating: "N/A" },
  { id: "10", name: "Sterling Liquid Cash Reserves", category: "Cash", value: 1500, expectedReturn: 2.0, volatility: 0.5, duration: 0.1, convexity: 0.1, riskWeight: 0, creditRating: "AA+" },
  { id: "11", name: "Carbon Offsetting Credits", category: "Alternatives", value: 1800, expectedReturn: 8.5, volatility: 15.0, duration: 0, convexity: 0, riskWeight: 150, creditRating: "N/A" }
];

// Configuration assumptions (Can be adjusted in the UI)
let regulatoryCapitalBuffers = {
  cet1BufferRatio: 4.5,
  capitalConservationBuffer: 2.5,
  countercyclicalBuffer: 1.0,
  internalTargetRatio: 12.0
};

// Security Role Sessions simulated (RBAC)
let currentUserRole = {
  email: "tom@ahyx.org",
  role: "Treasury Officer" as const,
  mfaEnabled: true,
  token: "RHINO-SESSION-MOCK-9921-X"
};

// Audit trail - Immutable Event Log (simulating digital signatures)
let auditLogs: AuditLogEntry[] = [
  {
    id: "a-101",
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
    userEmail: "system@rhino.bank",
    userRole: "Treasury Officer",
    action: "System Initialization",
    details: "Capital Reserve Engine and Treasury ledger initialized successfully.",
    ipAddress: "127.0.0.1",
    digitalSignature: "RSA-SIG-SYSTEM-0x8892EF",
    hash: "0a1b2c3d4e5f6g7h"
  }
];

// Helper to push to audit log with digital signature
function logAction(action: string, details: string, email = currentUserRole.email, role = currentUserRole.role) {
  const timestamp = new Date().toISOString();
  const id = "a-" + Math.floor(Math.random() * 1000000);
  const ipAddress = "192.168.1.144";
  
  // Sign the action details using a mock crypto hash
  const prevHash = auditLogs[auditLogs.length - 1]?.hash || "root";
  const contentToHash = `${id}-${timestamp}-${email}-${action}-${details}-${prevHash}`;
  const hash = crypto.createHash("sha256").update(contentToHash).digest("hex").substring(0, 16);
  const digitalSignature = `RSA-SIG-SHA256-${crypto.createHash("md5").update(contentToHash).digest("hex").substring(0, 8).toUpperCase()}`;

  const entry: AuditLogEntry = {
    id,
    timestamp,
    userEmail: email,
    userRole: role,
    action,
    details,
    ipAddress,
    digitalSignature,
    hash
  };
  auditLogs.unshift(entry); // Prepend so newest is first
}

// Lazy initialization of Gemini API SDK (To avoid startup crashes if key is missing)
let geminiClient: any = null;
function getGeminiClient() {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!geminiClient) {
    try {
      geminiClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
    } catch (e) {
      console.error("Failed to initialize Gemini Client:", e);
      return null;
    }
  }
  return geminiClient;
}

// -----------------------------------------------------------------------------
// Core Mathematical & Quantitative Engines (Simulating R Quantitative Packages)
// -----------------------------------------------------------------------------

// 1. Calculate Capital Adequacy
function calculateCapitalMetrics(portfolioList: PortfolioAsset[]): CapitalMetrics {
  const totalAssets = portfolioList.reduce((sum, a) => sum + a.value, 0);
  
  // RWA calculation
  const riskWeightedAssets = portfolioList.reduce((sum, a) => {
    return sum + (a.value * (a.riskWeight / 100));
  }, 0);

  // Available regulatory capital
  const commonEquityTier1 = 3800; // CET1
  const tier1Capital = 4500;      // Tier 1
  const tier2Capital = 1200;      // Tier 2
  const totalRegulatoryCapital = tier1Capital + tier2Capital;

  const cet1Ratio = (commonEquityTier1 / riskWeightedAssets) * 100;
  const tier1Ratio = (tier1Capital / riskWeightedAssets) * 100;
  const totalCapitalRatio = (totalRegulatoryCapital / riskWeightedAssets) * 100;
  const leverageRatio = (tier1Capital / totalAssets) * 100;

  const capitalBufferRequirement = regulatoryCapitalBuffers.cet1BufferRatio + 
                                  regulatoryCapitalBuffers.capitalConservationBuffer + 
                                  regulatoryCapitalBuffers.countercyclicalBuffer;

  const internalCapitalTarget = regulatoryCapitalBuffers.internalTargetRatio;
  
  // Available Financial Resources (AFR)
  const availableFinancialResources = tier1Capital;

  // Headroom is capital above the internal target
  const targetRequiredCapital = riskWeightedAssets * (internalCapitalTarget / 100);
  const capitalHeadroom = tier1Capital - targetRequiredCapital;

  return {
    commonEquityTier1,
    tier1Capital,
    tier2Capital,
    totalRegulatoryCapital,
    riskWeightedAssets,
    cet1Ratio,
    tier1Ratio,
    totalCapitalRatio,
    leverageRatio,
    capitalBufferRequirement,
    capitalHeadroom,
    internalCapitalTarget,
    availableFinancialResources,
    totalAssets
  };
}

// 2. Generate Liquidity Profile
function calculateLiquidityProfile(portfolioList: PortfolioAsset[]): LiquidityProfile {
  // Extract liquid assets
  const cashAsset = portfolioList.find(a => a.category === "Cash")?.value || 1500;
  const govBonds = portfolioList.find(a => a.category === "Government Bonds")?.value || 12000;
  const corpBonds = portfolioList.find(a => a.category === "Corporate Bonds")?.value || 8500;

  // Cash reserves: cash + 50% of Gov Bonds (intraday availability)
  const cashReserves = cashAsset + govBonds * 0.15;
  
  // HQLA: 100% Cash + 95% Gov Bonds + 70% Corporate Bonds
  const hqla = cashAsset + govBonds * 0.95 + corpBonds * 0.70;
  
  // Collateral Pools: Gov bonds available for repo
  const collateralPools = govBonds * 0.85;

  const committedFacilities = 2500; // USDm
  const fundingConcentrationRatio = 14.5; // Top 5 depositors / sources %
  const wholesaleFundingPercentage = 38.0;

  // Maturity Buckets (Inflows vs Outflows USDm)
  const maturityBuckets = [
    { bucket: "1 Day" as const, inflow: 1200, outflow: 800, net: 400, cumulativeGap: 400 },
    { bucket: "1 Week" as const, inflow: 2500, outflow: 3000, net: -500, cumulativeGap: -100 },
    { bucket: "1 Month" as const, inflow: 4100, outflow: 3900, net: 200, cumulativeGap: 100 },
    { bucket: "3 Months" as const, inflow: 5600, outflow: 6200, net: -600, cumulativeGap: -500 },
    { bucket: "1 Year" as const, inflow: 14000, outflow: 12500, net: 1500, cumulativeGap: 1000 },
    { bucket: "5 Years" as const, inflow: 12000, outflow: 11000, net: 1000, cumulativeGap: 2000 },
    { bucket: "10 Years" as const, inflow: 8000, outflow: 5000, net: 3000, cumulativeGap: 5000 }
  ];

  return {
    cashReserves,
    hqla,
    collateralPools,
    fundingConcentrationRatio,
    wholesaleFundingPercentage,
    committedFacilities,
    maturityBuckets
  };
}

// 3. Nelson-Siegel and Nelson-Siegel-Svensson Bootstrapping Models (Simulating R fixed-income packages)
function runBondAnalytics(beta0 = 4.2, beta1 = -1.5, beta2 = -2.0, beta3 = 1.0, tau1 = 1.8, tau2 = 5.0): BondAnalyticsResult {
  const maturities = [0.25, 0.5, 1, 2, 3, 5, 7, 10, 15, 20, 30];
  
  const nelsonSiegelSpot: number[] = [];
  const nelsonSiegelSvenssonSpot: number[] = [];
  const forwardCurve: number[] = [];
  const pcaYieldCurve: number[] = [];

  maturities.forEach(t => {
    // 1. Nelson-Siegel Spot Yield Model
    // R(t) = b0 + b1 * ((1 - e^{-t/tau}) / (t/tau)) + b2 * (((1 - e^{-t/tau}) / (t/tau)) - e^{-t/tau})
    const ns_term1 = (1 - Math.exp(-t / tau1)) / (t / tau1);
    const ns_term2 = ns_term1 - Math.exp(-t / tau1);
    const ns_yield = beta0 + beta1 * ns_term1 + beta2 * ns_term2;
    nelsonSiegelSpot.push(parseFloat(ns_yield.toFixed(4)));

    // 2. Nelson-Siegel-Svensson Spot Yield Model (Adds beta3 and tau2 for second hump/flexibility)
    const nss_term1 = (1 - Math.exp(-t / tau1)) / (t / tau1);
    const nss_term2 = nss_term1 - Math.exp(-t / tau1);
    const nss_term3 = ((1 - Math.exp(-t / tau2)) / (t / tau2)) - Math.exp(-t / tau2);
    const nss_yield = beta0 + beta1 * nss_term1 + beta2 * nss_term2 + beta3 * nss_term3;
    nelsonSiegelSvenssonSpot.push(parseFloat(nss_yield.toFixed(4)));

    // 3. Bootstrapping Instantaneous Forward Curve from NSS spot yield
    // Approx forward curve: f(t) = Spot(t) + t * dSpot/dt
    // For simplicity of visual modeling, we compute it with a slight upward term spread shift
    const forward_rate = nss_yield + (t * 0.05 * Math.exp(-t/10));
    forwardCurve.push(parseFloat(forward_rate.toFixed(4)));

    // 4. Principal Component Analysis (PCA) First Component (Shift) Yield Curve Simulation
    // PCA 1 captures parallel yield curve shifts. We simulate it with a 25bps parallel shock.
    pcaYieldCurve.push(parseFloat((nss_yield + 0.25).toFixed(4)));
  });

  // Calculate portfolio fixed-income risk stats
  const modifiedDuration = 6.45;
  const convexity = 54.2;
  const spreadDuration = 4.8;
  const immunizationStatus = "Optimally Immunized (Duration Match: 104.2%)";
  
  const keyRateDurations = [
    { rate: "2Y Key Rate", duration: 0.8 },
    { rate: "5Y Key Rate", duration: 2.1 },
    { rate: "10Y Key Rate", duration: 3.2 },
    { rate: "30Y Key Rate", duration: 0.35 }
  ];

  return {
    maturities,
    nelsonSiegelSpot,
    nelsonSiegelSvenssonSpot,
    forwardCurve,
    pcaYieldCurve,
    stats: {
      modifiedDuration,
      convexity,
      spreadDuration,
      immunizationStatus,
      keyRateDurations
    }
  };
}

// 4. Monte Carlo Simulator (Value-at-Risk & Expected Shortfall simulation)
function runMonteCarloRisk(portfolioList: PortfolioAsset[], simulationsCount = 500) {
  // Calculate weighted return & volatility of the bond/asset portfolio
  const totalVal = portfolioList.reduce((sum, a) => sum + a.value, 0);
  let portfolioReturn = 0;
  let portfolioVarSum = 0;

  portfolioList.forEach(a => {
    const weight = a.value / totalVal;
    portfolioReturn += a.expectedReturn * weight;
    portfolioVarSum += Math.pow(a.volatility * weight, 2);
  });
  
  // Account for diversification benefit (covariance) - reduce overall volatility
  const portfolioVolatility = Math.sqrt(portfolioVarSum) * 0.75; 

  const simulatedReturns: number[] = [];

  // Generate simulated portfolio returns using Box-Muller transform
  for (let i = 0; i < simulationsCount; i++) {
    const u1 = Math.random() || 0.0001;
    const u2 = Math.random() || 0.0001;
    const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    
    // Simulate return
    const simReturn = portfolioReturn + z * portfolioVolatility;
    simulatedReturns.push(simReturn);
  }

  // Sort returns in ascending order to compute tail risk parameters (Value-at-Risk, Expected Shortfall)
  simulatedReturns.sort((a, b) => a - b);

  // 99% Value-at-Risk corresponds to the 1st percentile of losses
  const varIndex = Math.floor(simulationsCount * 0.01);
  const percentReturn1 = simulatedReturns[varIndex];
  
  // VaR Loss in USD millions = Portfolio Value * loss %
  // Expressed as negative return loss
  const portfolioVaRPercent = Math.max(0, -percentReturn1);
  const portfolioValueAtRisk = totalVal * (portfolioVaRPercent / 100);

  // Expected Shortfall (Average of returns below the VaR threshold)
  const tailReturns = simulatedReturns.slice(0, varIndex);
  const avgTailReturn = tailReturns.reduce((sum, val) => sum + val, 0) / (tailReturns.length || 1);
  const portfolioESPercent = Math.max(0, -avgTailReturn);
  const portfolioExpectedShortfall = totalVal * (portfolioESPercent / 100);

  // Individual risk allocations simulated
  const creditRiskLoss = totalVal * 0.015;
  const marketRiskLoss = portfolioValueAtRisk;
  const interestRateRiskLoss = totalVal * 0.009;
  const liquidityRiskLoss = totalVal * 0.004;
  const operationalRiskLoss = totalVal * 0.003;
  const counterpartyRiskLoss = totalVal * 0.005;

  return {
    valueAtRisk: portfolioValueAtRisk,
    expectedShortfall: portfolioExpectedShortfall,
    marketRisk: marketRiskLoss,
    creditRisk: creditRiskLoss,
    interestRateRisk: interestRateRiskLoss,
    liquidityRisk: liquidityRiskLoss,
    operationalRisk: operationalRiskLoss,
    counterpartyRisk: counterpartyRiskLoss,
    portfolioVolatility,
    portfolioReturn,
    diversificationBenefit: 24.5 // % risk reduction due to uncorrelated assets
  };
}

// -----------------------------------------------------------------------------
// REST API Endpoints
// -----------------------------------------------------------------------------

// RBAC Profile
app.get("/api/auth/profile", (req, res) => {
  res.json(currentUserRole);
});

app.post("/api/auth/switch-role", (req, res) => {
  const { role } = req.body;
  if (role === "Treasury Officer" || role === "Risk Committee Chair" || role === "Regulatory Auditor" || role === "Quantitative Developer") {
    currentUserRole.role = role;
    logAction("Role Swapped", `Swapped session credentials to [${role}]`);
    res.json({ success: true, user: currentUserRole });
  } else {
    res.status(400).json({ error: "Invalid role specified" });
  }
});

// Portfolio management (Simulates internal transactional database)
app.get("/api/portfolio", (req, res) => {
  res.json(portfolio);
});

app.post("/api/portfolio", (req, res) => {
  const newAsset: PortfolioAsset = req.body;
  if (!newAsset.name || !newAsset.category || !newAsset.value) {
    return res.status(400).json({ error: "Missing required asset details." });
  }
  newAsset.id = "asset-" + Math.floor(Math.random() * 10000);
  portfolio.push(newAsset);
  logAction("Asset Created", `Added new institutional asset: ${newAsset.name} ($${newAsset.value}m)`);
  res.json(portfolio);
});

app.put("/api/portfolio/:id", (req, res) => {
  const { id } = req.params;
  const updatedAsset: Partial<PortfolioAsset> = req.body;
  const index = portfolio.findIndex(a => a.id === id);
  if (index !== -1) {
    portfolio[index] = { ...portfolio[index], ...updatedAsset } as PortfolioAsset;
    logAction("Asset Modified", `Updated transaction parameters for ${portfolio[index].name}`);
    res.json(portfolio);
  } else {
    res.status(404).json({ error: "Asset not found." });
  }
});

app.delete("/api/portfolio/:id", (req, res) => {
  const { id } = req.params;
  const index = portfolio.findIndex(a => a.id === id);
  if (index !== -1) {
    const assetName = portfolio[index].name;
    portfolio.splice(index, 1);
    logAction("Asset Divestment", `Liquidated asset exposure: ${assetName}`);
    res.json(portfolio);
  } else {
    res.status(404).json({ error: "Asset not found." });
  }
});

// Capital Reserve Engine Endpoints
app.get("/api/capital/adequacy", (req, res) => {
  const metrics = calculateCapitalMetrics(portfolio);
  res.json({
    metrics,
    assumptions: regulatoryCapitalBuffers
  });
});

app.post("/api/capital/adjust-assumptions", (req, res) => {
  const { cet1BufferRatio, capitalConservationBuffer, countercyclicalBuffer, internalTargetRatio } = req.body;
  if (cet1BufferRatio !== undefined) regulatoryCapitalBuffers.cet1BufferRatio = cet1BufferRatio;
  if (capitalConservationBuffer !== undefined) regulatoryCapitalBuffers.capitalConservationBuffer = capitalConservationBuffer;
  if (countercyclicalBuffer !== undefined) regulatoryCapitalBuffers.countercyclicalBuffer = countercyclicalBuffer;
  if (internalTargetRatio !== undefined) regulatoryCapitalBuffers.internalTargetRatio = internalTargetRatio;

  logAction("Capital Policy Updated", `Adjusted regulatory targets. Internal Target set to ${regulatoryCapitalBuffers.internalTargetRatio}%`);
  res.json({ success: true, assumptions: regulatoryCapitalBuffers });
});

// Liquidity Management Endpoints
app.get("/api/treasury/liquidity", (req, res) => {
  const profile = calculateLiquidityProfile(portfolio);
  res.json(profile);
});

// Bond Analytics Yield Curves Endpoints
app.get("/api/analytics/bond-curve", (req, res) => {
  const { beta0, beta1, beta2, beta3, tau1, tau2 } = req.query;
  const curve = runBondAnalytics(
    beta0 ? parseFloat(beta0 as string) : undefined,
    beta1 ? parseFloat(beta1 as string) : undefined,
    beta2 ? parseFloat(beta2 as string) : undefined,
    beta3 ? parseFloat(beta3 as string) : undefined,
    tau1 ? parseFloat(tau1 as string) : undefined,
    tau2 ? parseFloat(tau2 as string) : undefined
  );
  res.json(curve);
});

// Value at Risk / Stress Testing Endpoints
app.get("/api/analytics/risk-monte-carlo", (req, res) => {
  const riskStats = runMonteCarloRisk(portfolio);
  res.json(riskStats);
});

// Scenarios Definitions & stress projections over 10 Years
const scenarios: ScenarioDefinition[] = [
  { id: "s1", name: "Economic Expansion", category: "Expansion", description: "Vigorous macroeconomic growth driven by tech innovation. Higher returns, lower credit defaults.", gdpImpact: 3.5, rateShock: 100, creditSpreadImpact: -50, assetHaircut: 0, inflationImpact: 1.2 },
  { id: "s2", name: "Infrastructure Investment Boom", category: "Expansion", description: "Massive UK/Yorkshire project finance deployment. Infrastructure yields expand safely.", gdpImpact: 2.8, rateShock: 50, creditSpreadImpact: -30, assetHaircut: -5, inflationImpact: 0.8 },
  { id: "s3", name: "Property Downturn", category: "Contraction", description: "Real estate collapse with mortgage/commercial loan defaults. Collateral pools value decreases.", gdpImpact: -2.1, rateShock: -75, creditSpreadImpact: 120, assetHaircut: 20, inflationImpact: -1.0 },
  { id: "s4", name: "Credit Market Shock", category: "Shock", description: "Sudden downgrade cascade across corporate lending portfolio. RWA increases dramatically.", gdpImpact: -3.0, rateShock: 150, creditSpreadImpact: 350, assetHaircut: 15, inflationImpact: 1.5 },
  { id: "s5", name: "Energy Crisis", category: "Crisis", description: "Global supply interruption leading to hyperinflation and severe stagflation.", gdpImpact: -4.5, rateShock: 250, creditSpreadImpact: 400, assetHaircut: 25, inflationImpact: 5.5 },
  { id: "s6", name: "Global Recession", category: "Contraction", description: "Coordinated contraction of global trade. High credit write-offs, zero interest rates.", gdpImpact: -5.0, rateShock: -150, creditSpreadImpact: 300, assetHaircut: 30, inflationImpact: -2.0 }
];

app.get("/api/scenarios", (req, res) => {
  res.json(scenarios);
});

app.post("/api/scenarios/run-stress", (req, res) => {
  const { scenarioId } = req.body;
  const selectedScenario = scenarios.find(s => s.id === scenarioId) || scenarios[0];
  
  // Calculate stress over timeline 1, 3, 5, 10 Years
  const timelineYears = [1, 3, 5, 10];
  const initialMetrics = calculateCapitalMetrics(portfolio);
  
  const timeline = timelineYears.map(year => {
    // Math model representing macroeconomic compounding degradation / recovery
    let gdpFactor = Math.pow(1 + (selectedScenario.gdpImpact / 100), year);
    let rwaModifier = 1.0;
    let cet1Modifier = 0.0;
    let profitBase = 450; // default annual net income USDm

    if (selectedScenario.category === "Shock" || selectedScenario.category === "Crisis" || selectedScenario.category === "Contraction") {
      // Degrades heavily in Year 1-3, begins slow structured recovery by Year 5 and 10
      if (year === 1) {
        rwaModifier = 1.0 + (selectedScenario.creditSpreadImpact / 1000); // RWA expansion
        cet1Modifier = - (selectedScenario.assetHaircut / 15); // Capital hit
        profitBase = profitBase * (1 + (selectedScenario.gdpImpact / 10)); // Profit collapse
      } else if (year === 3) {
        rwaModifier = 1.0 + (selectedScenario.creditSpreadImpact / 800);
        cet1Modifier = - (selectedScenario.assetHaircut / 20);
        profitBase = profitBase * (1 + (selectedScenario.gdpImpact / 15));
      } else if (year === 5) {
        rwaModifier = 1.05; // Starting to normalize
        cet1Modifier = -0.5;
        profitBase = profitBase * 0.9;
      } else {
        rwaModifier = 1.02; // Normalized
        cet1Modifier = 0.0;
        profitBase = profitBase * 1.1; // Back to expansion
      }
    } else {
      // Expansion
      rwaModifier = Math.max(0.9, 1.0 - (year * 0.01));
      cet1Modifier = year * 0.2;
      profitBase = profitBase * Math.pow(1.05, year);
    }

    const projectedRwa = initialMetrics.riskWeightedAssets * rwaModifier;
    let projectedCet1 = initialMetrics.commonEquityTier1 + cet1Modifier * 100;
    
    // Accrue or subtract profitability from capital reserves
    projectedCet1 += (profitBase - 250) * year * 0.4; // assume dividend payout, rest goes to CET1
    
    const projectedCet1Ratio = (projectedCet1 / projectedRwa) * 100;
    
    // Liquidity Coverage Ratio (LCR) projection
    let initialLcr = 142; // %
    let projectedLcr = initialLcr;
    if (year === 1) {
      projectedLcr = initialLcr - (selectedScenario.assetHaircut * 1.5) + (selectedScenario.rateShock / 100);
    } else if (year === 3) {
      projectedLcr = initialLcr - (selectedScenario.assetHaircut * 0.8);
    } else {
      projectedLcr = initialLcr + (year * 1.5);
    }

    return {
      year,
      cet1Ratio: parseFloat(Math.max(5.0, projectedCet1Ratio).toFixed(2)),
      rwa: parseFloat(projectedRwa.toFixed(1)),
      liquidityCoverageRatio: parseFloat(Math.max(80, projectedLcr).toFixed(1)),
      profitability: parseFloat((profitBase / 2).toFixed(1)), // millions USD
      portfolioValue: parseFloat((initialMetrics.totalAssets * gdpFactor).toFixed(1))
    };
  });

  logAction("Stress Test Evaluated", `Evaluated scenario [${selectedScenario.name}] across 10-year prudential planning horizon.`);

  res.json({
    scenario: selectedScenario,
    timeline
  });
});

// Audit log GET endpoint
app.get("/api/audit-logs", (req, res) => {
  res.json(auditLogs);
});

// AI Treasury Assistant - Real-time Intelligent Prudential Advisory
app.post("/api/ai/assistant", async (req, res) => {
  const { prompt, chatHistory } = req.body;
  const ai = getGeminiClient();

  // Create prompt system instructions incorporating quantitative data
  const currentAdequacy = calculateCapitalMetrics(portfolio);
  const currentLiquidity = calculateLiquidityProfile(portfolio);
  const riskAnalysis = runMonteCarloRisk(portfolio);

  const contextInstruction = `
    You are the elite AI Chief Treasury Officer and prudential risk copilot at Rhino Bank, an institutional investment bank.
    Our visual theme is Yorkshire Engineering (steel, grey, deep navy, limestone). Speak with professional composure, institutional precision, and occasional references to robust, solid Yorkshire workmanship.

    Institutional Context:
    - Common Equity Tier 1 (CET1) Capital: $${currentAdequacy.commonEquityTier1}m
    - Tier 1 Capital: $${currentAdequacy.tier1Capital}m
    - Risk-Weighted Assets (RWA): $${currentAdequacy.riskWeightedAssets}m
    - CET1 Ratio: ${currentAdequacy.cet1Ratio.toFixed(2)}% (Target: ${regulatoryCapitalBuffers.internalTargetRatio}%)
    - Leverage Ratio: ${currentAdequacy.leverageRatio.toFixed(2)}%
    - High-Quality Liquid Assets (HQLA): $${currentLiquidity.hqla}m
    - Monte Carlo 99% Value-at-Risk (VaR): $${riskAnalysis.valueAtRisk.toFixed(2)}m
    - Expected Shortfall (ES): $${riskAnalysis.expectedShortfall.toFixed(2)}m
    - Portfolio assets under management: ${portfolio.length} core asset pools

    User prompt: "${prompt}"

    Please answer the user's query directly and authoritatively. If asked to:
    1. Forecast capital requirements: Give detailed, math-oriented forecasting.
    2. Detect unusual balance-sheet changes: Call out if asset valuations or RWA are drifting.
    3. Identify emerging liquidity pressures: Look at our maturity gap or wholesale funding dependency.
    4. Recommend portfolio rebalancing: Propose reducing high risk-weight alternatives (Venture Capital, Alternative Debt) in favor of HQLA Government Bonds.
    5. Summarise stress-test outcomes: Focus on how a Credit Shock or Property Downturn compromises CET1.
    6. Draft executive committee reports: Provide a structured, beautiful, professional memo ready for the Board.
  `;

  if (!ai) {
    // If API Key is missing, generate an extremely high-fidelity Yorkshire-accented treasury simulation
    // to keep the app 100% interactive and functional out-of-the-box!
    const simulatedAnswers = [
      `### Rhino Bank Executive Treasury Advisory\n\n**Prudential Assessment & Stress Summary**\n\nBased on our current ledger, our Common Equity Tier 1 (CET1) Ratio sits at **${currentAdequacy.cet1Ratio.toFixed(2)}%**, representing comfortable headroom of **$${currentAdequacy.capitalHeadroom.toFixed(0)}m** above our internal target of **${regulatoryCapitalBuffers.internalTargetRatio}%**.\n\nOur Monte Carlo models estimate a 99% 10-day Value-at-Risk (VaR) of **$${riskAnalysis.valueAtRisk.toFixed(2)}m** and Expected Shortfall of **$${riskAnalysis.expectedShortfall.toFixed(2)}m**.\n\n**Strategic Recommendation:**\n1. *Yorkshire Grit Portfolio Rebalancing*: Consider reallocating $500m from Venture Capital (risk-weight 150%) into highly liquid UK Gilts (0% risk-weight). This will release **$750m** of RWA, increasing our capital ratio immediately by **+0.45%**.\n2. *Liquidity Defense*: HQLA pools of **$${currentLiquidity.hqla.toFixed(0)}m** are robust, but wholesale concentration represents a long-term risk under extreme Credit Market Shocks. Keep solid reserves!\n\n*(Note: Real-time Gemini API integration is available by configuring your key in the Secrets Panel. Currently running on the high-fidelity offline analytics simulation).*`
    ];
    
    // Short delay to mimic API call
    await new Promise(resolve => setTimeout(resolve, 800));
    return res.json({ text: simulatedAnswers[0], mock: true });
  }

  try {
    const chatInput = [
      { role: "user", parts: [{ text: contextInstruction }] }
    ];

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: contextInstruction,
      config: {
        temperature: 0.7
      }
    });

    const responseText = response.text;
    res.json({ text: responseText, mock: false });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: "Failed to query Gemini assistant", details: error.message });
  }
});

// Vite/Production serving setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Rhino Capital Platform active on port ${PORT}`);
  });
}

startServer();
