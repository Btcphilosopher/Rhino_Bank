import React, { useState, useEffect } from "react";
import { 
  History, 
  ShieldCheck, 
  Download, 
  FileSpreadsheet, 
  FileText, 
  AlertCircle,
  Clock,
  User,
  Fingerprint,
  Search,
  CheckCircle,
  HelpCircle
} from "lucide-react";
import { AuditLogEntry } from "../types";

interface AuditLedgerProps {
  onLogEntry: (action: string, details: string) => void;
}

export default function AuditLedger({ onLogEntry }: AuditLedgerProps) {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchAuditLogs = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/audit-logs");
      const data: AuditLogEntry[] = await response.json();
      setLogs(data);
    } catch (e) {
      console.error("Failed to load audit logs:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuditLogs();
  }, []);

  const handleRefreshLogs = () => {
    fetchAuditLogs();
    onLogEntry("Audit Trail Inspected", "Manual verification sweep of the immutable cryptographic transaction journal.");
  };

  // Search filter
  const filteredLogs = logs.filter(log => {
    const text = `${log.action} ${log.details} ${log.userEmail} ${log.userRole}`.toLowerCase();
    return text.includes(searchTerm.toLowerCase());
  });

  // Client-side export to CSV
  const handleExportCSV = () => {
    const headers = ["ID", "Timestamp", "User Email", "Assumed Role", "Action", "Details", "IP Address", "Digital Signature", "SHA-256 Block Hash"];
    const rows = filteredLogs.map(log => [
      log.id,
      log.timestamp,
      `"${log.userEmail}"`,
      `"${log.userRole}"`,
      `"${log.action}"`,
      `"${log.details.replace(/"/g, '""')}"`,
      log.ipAddress,
      log.digitalSignature,
      log.hash
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `RhinoBank_AuditLedger_${new Date().toISOString().substring(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    onLogEntry("Export Executed", "Exported formal Ledger Journal to standard CSV format.");
  };

  // Client-side export to HTML (representing Board Report Pack)
  const handleExportHTML = () => {
    let htmlContent = `
      <html>
        <head>
          <title>Rhino Bank capital Adequacy - Audit Report</title>
          <style>
            body { font-family: sans-serif; padding: 40px; color: #333; }
            h1 { color: #0f172a; margin-bottom: 5px; }
            h2 { color: #475569; font-size: 14px; margin-top: 0; font-weight: normal; }
            table { width: 100%; border-collapse: collapse; margin-top: 30px; font-size: 12px; }
            th { background-color: #f1f5f9; text-align: left; padding: 10px; border-bottom: 2px solid #cbd5e1; }
            td { padding: 10px; border-bottom: 1px solid #e2e8f0; }
            .mono { font-family: monospace; font-size: 10px; color: #64748b; }
            .badge { background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-weight: bold; font-size: 10px; }
          </style>
        </head>
        <body>
          <h1>Rhino Bank Capital Adequacy Suite</h1>
          <h2>Immutable Security Audit Report - Generated on ${new Date().toLocaleString()}</h2>
          <table>
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Actor Email</th>
                <th>Prudential Role</th>
                <th>Action</th>
                <th>Transaction Details</th>
                <th>Digital Signature Block</th>
              </tr>
            </thead>
            <tbody>
              ${filteredLogs.map(log => `
                <tr>
                  <td>${new Date(log.timestamp).toLocaleString()}</td>
                  <td>${log.userEmail}</td>
                  <td><span class="badge">${log.userRole}</span></td>
                  <td><strong>${log.action}</strong></td>
                  <td>${log.details}</td>
                  <td class="mono">${log.digitalSignature}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `RhinoBank_BoardPack_${new Date().toISOString().substring(0,10)}.html`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    onLogEntry("Report Generated", "Compiled and exported institutional board risk paper packet in HTML format.");
  };

  return (
    <div className="space-y-6 font-sans" id="audit-trail-module">
      
      {/* Module Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-brand-navy p-6 rounded-none border-4 border-brand-border shadow-[4px_4px_0px_rgba(11,29,42,0.15)] text-white">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight uppercase">
            Prudential Audit Trail & Security Ledger
          </h2>
          <p className="text-slate-300 text-xs font-bold uppercase tracking-wider mt-1">
            Immutable, block-hashed transaction registry signing all treasury adjustments, stress trials, and compliance roles.
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex flex-col sm:flex-row gap-2.5">
          
          {/* CSV Export */}
          <button 
            onClick={handleExportCSV}
            className="bg-white hover:bg-slate-100 text-brand-navy text-xs font-black uppercase tracking-widest px-4 py-2.5 rounded-none border-2 border-brand-navy flex items-center space-x-1.5 transition-all shadow-[2px_2px_0px_rgba(0,0,0,0.15)] cursor-pointer"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-600" />
            <span>Export CSV</span>
          </button>

          {/* Board Pack Export */}
          <button 
            onClick={handleExportHTML}
            className="bg-brand-steel hover:bg-brand-steel/80 text-white text-xs font-black uppercase tracking-widest px-4 py-2.5 rounded-none border-2 border-white flex items-center space-x-1.5 transition-all shadow-[2px_2px_0px_rgba(0,0,0,0.15)] cursor-pointer"
          >
            <FileText className="h-4 w-4 text-white" />
            <span>Compile Board Pack</span>
          </button>

        </div>
      </div>

      {/* Security Health Indicator Card */}
      <div className="bg-brand-cream/50 border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] flex flex-col md:flex-row items-start md:items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="bg-emerald-50 text-emerald-800 p-2.5 rounded-none border-2 border-emerald-500">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div>
            <h3 className="font-black text-brand-navy text-sm uppercase">Hardware Cryptographic Core Active</h3>
            <p className="text-slate-600 text-xs font-bold uppercase mt-1 leading-normal">
              All state transitions are chained using SHA-256 blocks with RSA digital signature certificates. Database is fully encrypted in transit and at rest.
            </p>
          </div>
        </div>
        <div className="mt-3 md:mt-0 flex flex-col text-left md:text-right text-xs uppercase font-black tracking-wider text-brand-navy">
          <span>MFA enforcement</span>
          <span className="text-emerald-700 font-black mt-1 flex items-center justify-start md:justify-end text-xs tracking-widest">
            <CheckCircle className="h-4 w-4 mr-1" />
            <span>100% COMPLIANT</span>
          </span>
        </div>
      </div>

      {/* Audit Log Table Area */}
      <div className="bg-white border-4 border-brand-border rounded-none shadow-[4px_4px_0px_rgba(11,29,42,0.15)] overflow-hidden flex flex-col">
        
        {/* Search Header */}
        <div className="p-5 border-b-4 border-brand-border flex flex-col md:flex-row md:justify-between md:items-center gap-3 bg-brand-cream/20">
          <div>
            <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Chained Ledger History</h3>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Displays chronological system logs. Click column values to inspect keys.</p>
          </div>
          
          <div className="flex space-x-2 items-center">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-brand-navy" />
              <input 
                type="text" 
                placeholder="Search ledger journals..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 pr-4 py-1.5 w-64 bg-white border-2 border-brand-border rounded-none text-xs font-bold uppercase text-brand-navy focus:outline-none focus:border-brand-steel"
              />
            </div>
            <button 
              onClick={handleRefreshLogs}
              className="p-2 bg-white hover:bg-brand-cream/20 border-2 border-brand-border rounded-none text-brand-navy transition-all cursor-pointer"
              title="Refresh journal logs"
            >
              <Clock className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Entries list */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-brand-navy">
            <thead className="bg-brand-cream border-b-4 border-brand-border text-[10px] font-black text-brand-navy uppercase tracking-widest">
              <tr>
                <th className="px-5 py-3">Timestamp</th>
                <th className="px-5 py-3">Prudential Actor</th>
                <th className="px-5 py-3">Operation Action</th>
                <th className="px-5 py-3">Transaction Details</th>
                <th className="px-5 py-3 text-center">Assumed Role</th>
                <th className="px-5 py-3 text-right">Cryptographic Seal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-brand-border/35 font-sans font-bold">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-brand-cream/10">
                  <td className="px-5 py-3.5 whitespace-nowrap text-slate-500 font-mono font-bold uppercase text-[11px]">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>
                  <td className="px-5 py-3.5 font-bold text-brand-navy whitespace-nowrap">
                    <div className="flex items-center space-x-1.5">
                      <User className="h-3.5 w-3.5 text-brand-steel" />
                      <span>{log.userEmail}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3.5 font-black text-brand-navy uppercase tracking-tight">
                    {log.action}
                  </td>
                  <td className="px-5 py-3.5 text-slate-700 leading-normal max-w-xs md:max-w-md font-bold uppercase text-[11px]">
                    {log.details}
                  </td>
                  <td className="px-5 py-3.5 text-center">
                    <span className="bg-brand-cream text-brand-navy px-2 py-0.5 rounded-none text-[10px] font-mono font-black border-2 border-brand-border uppercase">
                      {log.userRole}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-right whitespace-nowrap font-mono text-[10px] text-slate-400">
                    <div className="space-y-0.5">
                      <span className="text-brand-steel font-black flex items-center justify-end space-x-0.5 uppercase tracking-wider">
                        <Fingerprint className="h-3.5 w-3.5 mr-0.5 text-brand-steel" />
                        <span>{log.digitalSignature.substring(0, 16)}</span>
                      </span>
                      <span className="block text-[9px] text-slate-500 font-mono uppercase tracking-tight font-black">Hash: {log.hash}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
}
