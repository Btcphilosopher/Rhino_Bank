import React, { useState } from "react";
import { 
  TrendingUp, 
  ShieldCheck, 
  HelpCircle, 
  AlertTriangle, 
  Plus, 
  Trash2, 
  Edit,
  DollarSign,
  Briefcase,
  ChevronRight,
  RefreshCw
} from "lucide-react";
import { PortfolioAsset, CapitalMetrics } from "../types";

interface CapitalAdequacyProps {
  portfolio: PortfolioAsset[];
  metrics: CapitalMetrics;
  assumptions: {
    cet1BufferRatio: number;
    capitalConservationBuffer: number;
    countercyclicalBuffer: number;
    internalTargetRatio: number;
  };
  onAssetUpdate: (updatedList: PortfolioAsset[]) => void;
  onAssumptionsUpdate: (updated: any) => void;
  onLogEntry: (action: string, details: string) => void;
}

export default function CapitalAdequacy({ 
  portfolio, 
  metrics, 
  assumptions, 
  onAssetUpdate, 
  onAssumptionsUpdate,
  onLogEntry
}: CapitalAdequacyProps) {
  
  // Local state for adding a new asset
  const [showAddForm, setShowAddForm] = useState(false);
  const [newAsset, setNewAsset] = useState<Partial<PortfolioAsset>>({
    name: "",
    category: "Government Bonds",
    value: 1000,
    expectedReturn: 4.5,
    volatility: 6.0,
    duration: 5.0,
    convexity: 45.0,
    riskWeight: 50,
    creditRating: "A"
  });

  // State to custom override asset risk weight in UI (simulating internal policy changes)
  const [isEditingWeights, setIsEditingWeights] = useState<string | null>(null);
  const [tempWeight, setTempWeight] = useState<number>(0);

  const handleAddAssetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAsset.name || !newAsset.value) return;

    const id = "asset-" + Math.floor(Math.random() * 10000);
    const assetToAdd: PortfolioAsset = {
      id,
      name: newAsset.name,
      category: newAsset.category as any,
      value: Number(newAsset.value),
      expectedReturn: Number(newAsset.expectedReturn),
      volatility: Number(newAsset.volatility),
      duration: Number(newAsset.duration),
      convexity: Number(newAsset.convexity),
      riskWeight: Number(newAsset.riskWeight),
      creditRating: newAsset.creditRating || "N/A"
    };

    const newList = [...portfolio, assetToAdd];
    onAssetUpdate(newList);
    onLogEntry("Asset Placement", `Allocated $${assetToAdd.value}m capital into [${assetToAdd.name}]`);
    setShowAddForm(false);
    setNewAsset({
      name: "",
      category: "Government Bonds",
      value: 1000,
      expectedReturn: 4.5,
      volatility: 6.0,
      duration: 5.0,
      convexity: 45.0,
      riskWeight: 50,
      creditRating: "A"
    });
  };

  const handleRemoveAsset = (id: string, name: string) => {
    const newList = portfolio.filter(a => a.id !== id);
    onAssetUpdate(newList);
    onLogEntry("Asset Divestment", `Liquidated asset exposure [${name}]`);
  };

  const handleSaveRiskWeight = (id: string, originalName: string) => {
    const newList = portfolio.map(a => {
      if (a.id === id) {
        return { ...a, riskWeight: tempWeight };
      }
      return a;
    });
    onAssetUpdate(newList);
    onLogEntry("Risk Weight Adjusted", `Overrode Basel risk-weight for [${originalName}] to ${tempWeight}%`);
    setIsEditingWeights(null);
  };

  const handleTargetChange = (val: number) => {
    onAssumptionsUpdate({ ...assumptions, internalTargetRatio: val });
  };

  // Helper colors based on Yorkshire theme
  const formatCurrency = (val: number) => {
    return `$${val.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}m`;
  };

  return (
    <div className="space-y-6 font-sans" id="capital-adequacy-module">
      
      {/* Module Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-brand-navy p-6 rounded-none border-4 border-brand-border shadow-[4px_4px_0px_rgba(11,29,42,0.15)] text-white">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight uppercase">
            Capital Adequacy & Reserve Engine
          </h2>
          <p className="text-slate-300 text-xs font-bold uppercase tracking-wider mt-1">
            Prudential leverage monitoring, available financial resources, and customizable Basel risk weights.
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button 
            onClick={() => {
              // Trigger a system recapitalisation log
              const updated = portfolio.map(a => {
                if (a.category === "Cash") {
                  return { ...a, value: a.value + 500 };
                }
                return a;
              });
              onAssetUpdate(updated);
              onLogEntry("Capital Injection", "Executed emergency equity replenishment: +$500m Common Reserves.");
            }}
            className="bg-brand-steel hover:bg-brand-steel/80 text-white text-xs font-black uppercase tracking-widest px-4 py-2.5 rounded-none border-2 border-white flex items-center space-x-1.5 transition-all shadow-[2px_2px_0px_rgba(0,0,0,0.15)] cursor-pointer"
          >
            <ShieldCheck className="h-4 w-4 text-white" />
            <span>Inject Equity (CET1)</span>
          </button>
        </div>
      </div>

      {/* KPI Ribbons */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        
        {/* Metric 1 */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Common Equity Tier 1 (CET1)</span>
            <span className="text-3xl font-black text-brand-navy block mt-1">{formatCurrency(metrics.commonEquityTier1)}</span>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs font-black">
            <span className="text-brand-graphite font-mono">Ratio: {metrics.cet1Ratio.toFixed(2)}%</span>
            <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-none border-2 border-emerald-500 text-[10px]">PASS</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Tier 1 Capital Ratio</span>
            <span className="text-3xl font-black text-brand-navy block mt-1">{metrics.tier1Ratio.toFixed(2)}%</span>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs font-black">
            <span className="text-brand-graphite font-mono">Regulatory Min: 8.5%</span>
            <span className="text-brand-steel uppercase">Headroom: {formatCurrency(metrics.capitalHeadroom)}</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Leverage Ratio</span>
            <span className="text-3xl font-black text-brand-navy block mt-1">{metrics.leverageRatio.toFixed(2)}%</span>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs font-black">
            <span className="text-brand-graphite font-mono">Regulatory Min: 3.0%</span>
            <span className="text-emerald-700 uppercase">Stable</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Total Risk-Weighted Assets</span>
            <span className="text-3xl font-black text-brand-navy block mt-1">{formatCurrency(metrics.riskWeightedAssets)}</span>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs font-black">
            <span className="text-brand-graphite font-mono">Total exposure: {formatCurrency(metrics.totalAssets)}</span>
            <span className="text-brand-steel font-mono font-bold">{(metrics.riskWeightedAssets / metrics.totalAssets * 100).toFixed(1)}% RW</span>
          </div>
        </div>

      </div>

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Portfolio Assets & Risk Weights Table */}
        <div className="lg:col-span-2 bg-white border-4 border-brand-border rounded-none shadow-[4px_4px_0px_rgba(11,29,42,0.15)] overflow-hidden flex flex-col">
          <div className="p-5 border-b-4 border-brand-border bg-brand-cream/40 flex justify-between items-center">
            <div>
              <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Capital Ledger & Exposure Weights</h3>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Configure individual asset books and risk weights.</p>
            </div>
            <button 
              onClick={() => setShowAddForm(!showAddForm)}
              className="bg-brand-navy hover:bg-brand-navy/90 text-white text-xs font-black uppercase tracking-widest px-3 py-1.5 rounded-none border-2 border-brand-border flex items-center space-x-1 transition-all cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Allocate Capital</span>
            </button>
          </div>

          {/* Capital Allocation Form (Conditional) */}
          {showAddForm && (
            <form onSubmit={handleAddAssetSubmit} className="bg-brand-cream/30 p-5 border-b-4 border-brand-border space-y-4 animate-fade-in">
              <h4 className="text-xs font-black uppercase tracking-widest text-brand-steel">New Capital Commitment Details</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-600 block mb-1">Exposure Name</label>
                  <input 
                    type="text" 
                    required
                    value={newAsset.name}
                    onChange={(e) => setNewAsset({ ...newAsset, name: e.target.value })}
                    className="w-full text-xs bg-white border-2 border-brand-border rounded-none px-2 py-1.5 text-slate-800 focus:outline-none focus:border-brand-steel font-bold"
                    placeholder="e.g. Leeds City Dev Bond"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-600 block mb-1">Asset Category</label>
                  <select 
                    value={newAsset.category}
                    onChange={(e) => setNewAsset({ ...newAsset, category: e.target.value as any })}
                    className="w-full text-xs bg-white border-2 border-brand-border rounded-none px-2 py-1.5 text-slate-800 focus:outline-none font-bold"
                  >
                    <option value="Government Bonds">Government Bonds</option>
                    <option value="Corporate Bonds">Corporate Bonds</option>
                    <option value="Infrastructure Debt">Infrastructure Debt</option>
                    <option value="Private Credit">Private Credit</option>
                    <option value="Equities">Equities</option>
                    <option value="Property">Property</option>
                    <option value="Renewable Energy">Renewable Energy</option>
                    <option value="Venture Capital">Venture Capital</option>
                    <option value="Alternatives">Alternatives</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-600 block mb-1">Value (USD millions)</label>
                  <input 
                    type="number" 
                    required
                    min="1"
                    value={newAsset.value}
                    onChange={(e) => setNewAsset({ ...newAsset, value: parseInt(e.target.value) })}
                    className="w-full text-xs bg-white border-2 border-brand-border rounded-none px-2 py-1.5 text-slate-800 focus:outline-none font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-1">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-600 block mb-1">Expected Return (%)</label>
                  <input 
                    type="number" 
                    step="0.1"
                    value={newAsset.expectedReturn}
                    onChange={(e) => setNewAsset({ ...newAsset, expectedReturn: parseFloat(e.target.value) })}
                    className="w-full text-xs bg-white border-2 border-brand-border rounded-none px-2 py-1.5 text-slate-800 focus:outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-600 block mb-1">Volatility (%)</label>
                  <input 
                    type="number" 
                    step="0.1"
                    value={newAsset.volatility}
                    onChange={(e) => setNewAsset({ ...newAsset, volatility: parseFloat(e.target.value) })}
                    className="w-full text-xs bg-white border-2 border-brand-border rounded-none px-2 py-1.5 text-slate-800 focus:outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-600 block mb-1">Risk Weight (%)</label>
                  <input 
                    type="number" 
                    step="5"
                    min="0"
                    max="150"
                    value={newAsset.riskWeight}
                    onChange={(e) => setNewAsset({ ...newAsset, riskWeight: parseInt(e.target.value) })}
                    className="w-full text-xs bg-white border-2 border-brand-border rounded-none px-2 py-1.5 text-slate-800 focus:outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-600 block mb-1">Credit Rating</label>
                  <input 
                    type="text" 
                    value={newAsset.creditRating}
                    onChange={(e) => setNewAsset({ ...newAsset, creditRating: e.target.value })}
                    className="w-full text-xs bg-white border-2 border-brand-border rounded-none px-2 py-1.5 text-slate-800 focus:outline-none font-bold"
                    placeholder="e.g. AA-"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button 
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="bg-white border-2 border-brand-border text-slate-700 text-xs font-bold px-3 py-1.5 rounded-none cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="bg-brand-navy hover:bg-brand-navy/90 text-white text-xs font-black uppercase tracking-widest px-4 py-1.5 rounded-none border-2 border-brand-border cursor-pointer"
                >
                  Confirm Asset Placement
                </button>
              </div>
            </form>
          )}

          {/* Assets Grid */}
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs text-brand-navy">
              <thead className="bg-brand-cream/60 text-[10px] font-black text-brand-steel uppercase tracking-widest border-b-4 border-brand-border select-none">
                <tr>
                  <th className="px-5 py-3">Book Name</th>
                  <th className="px-5 py-3">Asset Category</th>
                  <th className="px-5 py-3">Value</th>
                  <th className="px-5 py-3 text-center">Base RW</th>
                  <th className="px-5 py-3">RWA Portion</th>
                  <th className="px-5 py-3 text-center">Rating</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y-2 divide-brand-border font-bold">
                {portfolio.map((asset) => {
                  const rwaAmount = asset.value * (asset.riskWeight / 100);
                  return (
                    <tr key={asset.id} className="hover:bg-brand-cream/30">
                      <td className="px-5 py-3 font-black">{asset.name}</td>
                      <td className="px-5 py-3">
                        <span className="bg-brand-cream text-brand-navy px-2 py-0.5 rounded-none text-[10px] font-black border-2 border-brand-border uppercase">
                          {asset.category}
                        </span>
                      </td>
                      <td className="px-5 py-3 font-black font-mono">{formatCurrency(asset.value)}</td>
                      <td className="px-5 py-3 text-center font-mono font-black">
                        {isEditingWeights === asset.id ? (
                          <div className="flex items-center justify-center space-x-1.5">
                            <input 
                              type="number" 
                              value={tempWeight}
                              onChange={(e) => setTempWeight(parseInt(e.target.value) || 0)}
                              className="w-12 bg-white border-2 border-brand-border rounded-none px-1 py-0.5 font-black text-center text-slate-800"
                              min="0"
                              max="150"
                            />
                            <button 
                              onClick={() => handleSaveRiskWeight(asset.id, asset.name)}
                              className="text-white bg-brand-steel hover:bg-brand-steel/80 px-2 py-0.5 rounded-none font-bold border border-brand-border cursor-pointer"
                            >
                              ✓
                            </button>
                          </div>
                        ) : (
                          <span 
                            onClick={() => {
                              setIsEditingWeights(asset.id);
                              setTempWeight(asset.riskWeight);
                            }}
                            className="hover:bg-brand-cream/60 px-1.5 py-0.5 rounded-none border border-brand-border cursor-pointer text-brand-navy font-black font-mono underline decoration-brand-steel decoration-2"
                          >
                            {asset.riskWeight}%
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3 text-brand-steel font-mono font-black">{formatCurrency(rwaAmount)}</td>
                      <td className="px-5 py-3 text-center">
                        <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-none font-mono border-2 ${
                          asset.creditRating.startsWith("A") ? "bg-emerald-50 text-emerald-700 border-emerald-400" :
                          asset.creditRating.startsWith("B") ? "bg-amber-50 text-amber-700 border-amber-400" : "bg-slate-50 text-slate-600 border-slate-300"
                        }`}>
                          {asset.creditRating}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-right">
                        <button 
                          onClick={() => handleRemoveAsset(asset.id, asset.name)}
                          className="text-brand-navy hover:text-red-600 p-1.5 rounded-none transition-colors cursor-pointer"
                          title="Liquidate Asset"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Prudential Assumptions & Controls Card */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] space-y-6">
          <div>
            <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Capital Buffer & Policy Panel</h3>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Calibrate risk metrics and internal prudential buffers.</p>
          </div>

          {/* Buffer Requirements Detail */}
          <div className="bg-brand-cream/40 p-4 rounded-none border-2 border-brand-border space-y-3 text-xs font-bold text-brand-navy">
            <h4 className="font-black text-brand-steel border-b-2 border-brand-border pb-1.5 uppercase tracking-widest text-[10px]">
              Basel Pillar 1 + 2 Buffers
            </h4>
            <div className="flex justify-between">
              <span className="text-slate-600 uppercase">Basel Minimum CET1</span>
              <span className="font-mono font-black text-brand-navy">{assumptions.cet1BufferRatio.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600 uppercase">Capital Conservation (CCB)</span>
              <span className="font-mono font-black text-brand-navy">{assumptions.capitalConservationBuffer.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600 uppercase">Countercyclical Buffer (CCyB)</span>
              <span className="font-mono font-black text-brand-navy">{assumptions.countercyclicalBuffer.toFixed(1)}%</span>
            </div>
            <div className="border-t-2 border-brand-border pt-2 flex justify-between font-black text-brand-navy uppercase">
              <span>Combined Buffer Requirement</span>
              <span className="font-mono text-brand-steel">{(assumptions.cet1BufferRatio + assumptions.capitalConservationBuffer + assumptions.countercyclicalBuffer).toFixed(1)}%</span>
            </div>
          </div>

          {/* Internal Target Controller */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="font-black text-brand-navy uppercase">Internal Capital Target</span>
              <span className="font-mono font-black text-brand-steel text-sm bg-brand-cream px-2 py-0.5 border border-brand-border">{assumptions.internalTargetRatio.toFixed(1)}%</span>
            </div>
            <input 
              type="range" 
              min="8.0" 
              max="16.0" 
              step="0.5"
              value={assumptions.internalTargetRatio}
              onChange={(e) => handleTargetChange(parseFloat(e.target.value))}
              className="w-full accent-brand-steel cursor-pointer h-2 bg-brand-cream border border-brand-border"
            />
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wide leading-normal">
              Increasing our target expands the reserve capital requirement but hardens the balance sheet against credit shocks.
            </p>
          </div>

          {/* Available Financial Resources (AFR) Breakdown */}
          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-black uppercase text-brand-navy tracking-tight">Prudential Available Resources</h4>
            <div className="space-y-2">
              
              {/* CET1 block */}
              <div className="bg-brand-cream/30 p-2.5 rounded-none border-l-4 border-emerald-500 border-y border-r border-brand-border text-xs flex justify-between items-center font-bold text-brand-navy">
                <div>
                  <span className="font-black uppercase text-brand-navy block">CET1 Common Equity</span>
                  <span className="text-[9px] text-slate-500 uppercase tracking-wide">Tier 1 Highest Loss-Absorbency</span>
                </div>
                <span className="font-mono font-black text-emerald-700">{formatCurrency(metrics.commonEquityTier1)}</span>
              </div>

              {/* Tier 1 block */}
              <div className="bg-brand-cream/30 p-2.5 rounded-none border-l-4 border-brand-steel border-y border-r border-brand-border text-xs flex justify-between items-center font-bold text-brand-navy">
                <div>
                  <span className="font-black uppercase text-brand-navy block">Additional Tier 1 (AT1)</span>
                  <span className="text-[9px] text-slate-500 uppercase tracking-wide">Hybrid capital convertible on triggers</span>
                </div>
                <span className="font-mono font-black text-brand-steel">{formatCurrency(metrics.tier1Capital - metrics.commonEquityTier1)}</span>
              </div>

              {/* Tier 2 block */}
              <div className="bg-brand-cream/30 p-2.5 rounded-none border-l-4 border-brand-graphite border-y border-r border-brand-border text-xs flex justify-between items-center font-bold text-brand-navy">
                <div>
                  <span className="font-black uppercase text-brand-navy block">Tier 2 Capital</span>
                  <span className="text-[9px] text-slate-500 uppercase tracking-wide">Subordinated debt instruments</span>
                </div>
                <span className="font-mono font-black text-brand-graphite">{formatCurrency(metrics.tier2Capital)}</span>
              </div>

            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
