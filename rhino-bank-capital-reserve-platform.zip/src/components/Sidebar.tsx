import React from "react";
import { 
  Building2, 
  Layers, 
  TrendingUp, 
  Activity, 
  TrendingDown, 
  History, 
  MessageSquare, 
  ShieldAlert, 
  Users, 
  FileSpreadsheet
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: {
    email: string;
    role: "Treasury Officer" | "Risk Committee Chair" | "Regulatory Auditor" | "Quantitative Developer";
    mfaEnabled: boolean;
  };
  onRoleChange: (role: "Treasury Officer" | "Risk Committee Chair" | "Regulatory Auditor" | "Quantitative Developer") => void;
}

export default function Sidebar({ activeTab, setActiveTab, user, onRoleChange }: SidebarProps) {
  const menuItems = [
    { id: "capital", name: "Capital Adequacy", icon: Layers, roles: ["Treasury Officer", "Risk Committee Chair", "Regulatory Auditor"] },
    { id: "liquidity", name: "Treasury & Liquidity", icon: Activity, roles: ["Treasury Officer", "Risk Committee Chair"] },
    { id: "bond", name: "Bond & Yield Curves", icon: TrendingUp, roles: ["Treasury Officer", "Quantitative Developer", "Regulatory Auditor"] },
    { id: "risk", name: "Risk Engine & VaR", icon: ShieldAlert, roles: ["Risk Committee Chair", "Quantitative Developer"] },
    { id: "planner", name: "Prudential Planner", icon: TrendingDown, roles: ["Treasury Officer", "Risk Committee Chair"] },
    { id: "audit", name: "Audit Trail", icon: History, roles: ["Treasury Officer", "Risk Committee Chair", "Regulatory Auditor", "Quantitative Developer"] },
    { id: "ai", name: "AI Treasury Assistant", icon: MessageSquare, roles: ["Treasury Officer", "Risk Committee Chair", "Regulatory Auditor", "Quantitative Developer"] }
  ];

  return (
    <aside className="w-80 bg-brand-graphite border-r-4 border-brand-border text-white flex flex-col justify-between h-full font-sans" id="rhino-sidebar">
      {/* Brand Header */}
      <div className="p-6 border-b-4 border-brand-border bg-brand-navy/30">
        <div className="flex items-center space-x-3">
          <div className="bg-brand-steel p-2.5 rounded-none text-white font-black text-2xl tracking-tighter shadow-[2px_2px_0px_#BCC6CC]">
            R
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-white uppercase">
              RHINO BANK
            </h1>
            <span className="text-[10px] font-extrabold text-brand-steel tracking-widest uppercase block">
              PRUDENTIAL SUITE
            </span>
          </div>
        </div>
        <div className="mt-4 bg-brand-navy/60 px-3 py-1.5 rounded-none border border-brand-border text-[10px] font-mono text-slate-300 flex justify-between items-center">
          <span>MODEL STATUS (R-QUANT)</span>
          <span className="flex items-center space-x-1">
            <span className="h-2 w-2 rounded-none bg-emerald-500 animate-pulse"></span>
            <span className="text-emerald-400 font-bold">READY</span>
          </span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-6 space-y-1.5 overflow-y-auto">
        <p className="px-3 text-[10px] font-black uppercase tracking-widest text-brand-steel mb-3">
          Treasury Modules
        </p>
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const hasAccess = item.roles.includes(user.role);
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-3 text-xs font-extrabold uppercase tracking-wide transition-all rounded-none ${
                isActive
                  ? "bg-brand-navy text-white border-l-4 border-brand-steel font-black shadow-md"
                  : "text-slate-300 hover:text-white hover:bg-brand-steel/60"
              }`}
              id={`sidebar-tab-${item.id}`}
            >
              <div className="flex items-center space-x-3">
                <IconComponent className={`h-4.5 w-4.5 ${isActive ? "text-brand-steel" : "text-slate-400"}`} />
                <span>{item.name}</span>
              </div>
              {!hasAccess && (
                <span className="text-[9px] bg-brand-navy/80 text-amber-500 px-1.5 py-0.5 rounded-none border border-brand-steel/40 font-mono scale-90">
                  Audit Only
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User Session & Role Based Access Control */}
      <div className="p-6 border-t-4 border-brand-border bg-brand-navy/40 space-y-4">
        <div className="space-y-1.5">
          <p className="text-[10px] font-black tracking-widest text-brand-steel uppercase">
            Active Session Credentials
          </p>
          <div className="bg-brand-navy p-3 rounded-none border border-brand-border space-y-1.5">
            <p className="text-[11px] font-mono text-slate-200 truncate" title={user.email}>
              {user.email}
            </p>
            <div className="flex items-center justify-between">
              <span className="text-[9px] bg-brand-graphite text-brand-cream px-1.5 py-0.5 rounded-none border border-brand-border font-mono font-bold uppercase">
                {user.role}
              </span>
              {user.mfaEnabled && (
                <span className="text-[9px] bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded-none border border-emerald-500/30 font-mono flex items-center space-x-1 font-black">
                  <span>MFA ON</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Dynamic RBAC Switch */}
        <div className="space-y-1.5">
          <label className="text-[10px] font-black tracking-widest text-brand-steel uppercase flex items-center space-x-1">
            <Users className="h-3.5 w-3.5 text-brand-steel" />
            <span>Assumed Prudential Role</span>
          </label>
          <select
            value={user.role}
            onChange={(e) => onRoleChange(e.target.value as any)}
            className="w-full text-[11px] font-bold bg-brand-navy border border-brand-border text-slate-100 rounded-none px-2.5 py-2 focus:border-brand-steel focus:outline-none"
            id="rbac-role-selector"
          >
            <option value="Treasury Officer">Treasury Officer (A-I-L)</option>
            <option value="Risk Committee Chair">Risk Committee Chair (M-V-S)</option>
            <option value="Regulatory Auditor">Regulatory Auditor (A-L-V)</option>
            <option value="Quantitative Developer">Quantitative Developer (Q-B-S)</option>
          </select>
          <p className="text-[9px] text-slate-400 italic mt-1 leading-relaxed">
            Changes are dynamically logged with SHA-256 digital seals.
          </p>
        </div>
      </div>
    </aside>
  );
}
