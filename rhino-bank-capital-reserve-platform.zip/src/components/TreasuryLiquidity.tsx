import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  ReferenceLine,
  LineChart,
  Line
} from "recharts";
import { 
  Droplet, 
  Activity, 
  ShieldAlert, 
  Layers, 
  FileCheck, 
  TrendingUp, 
  HelpCircle,
  TrendingDown
} from "lucide-react";
import { LiquidityProfile } from "../types";

interface TreasuryLiquidityProps {
  liquidity: LiquidityProfile;
  onLogEntry: (action: string, details: string) => void;
}

export default function TreasuryLiquidity({ liquidity, onLogEntry }: TreasuryLiquidityProps) {
  
  const formatCurrency = (val: number) => {
    return `$${val.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}m`;
  };

  // Convert maturity buckets to chart format
  const chartData = liquidity.maturityBuckets.map(b => ({
    bucket: b.bucket,
    Inflows: b.inflow,
    Outflows: -b.outflow, // displayed as negative
    "Net Gap": b.net,
    "Cumulative Gap": b.cumulativeGap
  }));

  // Safe checks for warning thresholds
  const lcrRatio = (liquidity.hqla / 3200) * 100; // Simulating 3200 as stressed 30-day net cash outflow

  return (
    <div className="space-y-6 font-sans" id="treasury-liquidity-module">
      
      {/* Module Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-brand-navy p-6 rounded-none border-4 border-brand-border shadow-[4px_4px_0px_rgba(11,29,42,0.15)] text-white">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight uppercase">
            Treasury Liquidity & Funding Desk
          </h2>
          <p className="text-slate-300 text-xs font-bold uppercase tracking-wider mt-1">
            Real-time Liquidity Coverage Ratio (LCR), cash reserves, collateral pool availability, and contractual cash flow maturity gaps.
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-2">
          <button 
            onClick={() => {
              onLogEntry("Intraday Repo Sweep", "Executed collateral-optimized reverse repo sweep to lock in $450m short-term cash.");
            }}
            className="bg-brand-steel hover:bg-brand-steel/80 text-white text-xs font-black uppercase tracking-widest px-4 py-2.5 rounded-none border-2 border-white flex items-center space-x-1.5 transition-all shadow-[2px_2px_0px_rgba(0,0,0,0.15)] cursor-pointer"
          >
            <Layers className="h-4 w-4 text-white" />
            <span>Optimize Collateral Repo</span>
          </button>
        </div>
      </div>

      {/* KPI Ribbons */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        
        {/* KPI 1 */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">High-Quality Liquid Assets (HQLA)</span>
            <span className="text-3xl font-black text-brand-navy block mt-1 font-mono">{formatCurrency(liquidity.hqla)}</span>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs font-black">
            <span className="text-slate-500 font-mono">Stressed Outflow Net: $3,200m</span>
            <span className="text-brand-steel bg-brand-cream/80 px-2 py-0.5 rounded-none border-2 border-brand-steel text-[10px] font-black">LCR: {lcrRatio.toFixed(1)}%</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Cash & Intraday Reserves</span>
            <span className="text-3xl font-black text-brand-navy block mt-1 font-mono">{formatCurrency(liquidity.cashReserves)}</span>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs font-black">
            <span className="text-slate-500 font-mono">Minimum Buffer: $1,200m</span>
            <span className="text-emerald-700 font-black flex items-center space-x-1 uppercase text-[10px]">
              <span>● SURPLUS</span>
            </span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Collateral Pool (Gov Securities)</span>
            <span className="text-3xl font-black text-brand-navy block mt-1 font-mono">{formatCurrency(liquidity.collateralPools)}</span>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs font-black">
            <span className="text-slate-500 uppercase">Unencumbered Gov Bonds</span>
            <span className="text-brand-steel font-mono">85.0% Haircut</span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Wholesale Funding Ratio</span>
            <span className="text-3xl font-black text-brand-navy block mt-1 font-mono">{liquidity.wholesaleFundingPercentage.toFixed(1)}%</span>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs font-black">
            <span className="text-slate-500 uppercase">Concentration: {liquidity.fundingConcentrationRatio}%</span>
            <span className="text-amber-600 font-black uppercase text-[10px]">Watchlist</span>
          </div>
        </div>

      </div>

      {/* Main Panel Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Maturity Gap Visualizer */}
        <div className="lg:col-span-2 bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] flex flex-col">
          <div className="mb-4">
            <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Contractual Inflow/Outflow Maturity Gap</h3>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Analyses asset inflows against contractual liability outflows across term buckets.</p>
          </div>
          
          <div className="h-80 flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 20, right: 30, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="bucket" tick={{ fontSize: 10, fontWeight: "bold" }} stroke="#0B1D2A" />
                <YAxis tickFormatter={(val) => `$${val}m`} tick={{ fontSize: 10, fontWeight: "bold" }} stroke="#0B1D2A" />
                <Tooltip 
                  formatter={(value: any) => [`$${Math.abs(Number(value))}m`, undefined]}
                  contentStyle={{ backgroundColor: "#0B1D2A", color: "#F5F5F0", borderRadius: "0px", border: "2px solid #BCC6CC", fontSize: "11px", fontWeight: "bold" }}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px", fontWeight: "bold", textTransform: "uppercase" }} />
                <ReferenceLine y={0} stroke="#0B1D2A" strokeWidth={2} />
                <Bar dataKey="Inflows" fill="#4682B4" barSize={16} radius={0} />
                <Bar dataKey="Outflows" fill="#EF4444" barSize={16} radius={0} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cumulative Liquidity Gap Profile */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] flex flex-col justify-between">
          <div>
            <div className="mb-4">
              <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Cumulative Gap Analysis</h3>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Calculates cumulative funding sufficiency over a 10-year term.</p>
            </div>
            
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                  <XAxis dataKey="bucket" tick={{ fontSize: 9, fontWeight: "bold" }} stroke="#0B1D2A" />
                  <YAxis tickFormatter={(val) => `${val}m`} tick={{ fontSize: 9, fontWeight: "bold" }} stroke="#0B1D2A" />
                  <Tooltip contentStyle={{ backgroundColor: "#0B1D2A", color: "#F5F5F0", borderRadius: "0px", border: "2px solid #BCC6CC", fontSize: "11px", fontWeight: "bold" }} />
                  <ReferenceLine y={0} stroke="#94A3B8" strokeDasharray="3 3" />
                  <Line type="monotone" dataKey="Cumulative Gap" stroke="#10B981" strokeWidth={3} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-3 pt-4 border-t-2 border-brand-border text-xs font-bold">
            <h4 className="font-black text-brand-steel uppercase tracking-widest text-[10px]">Liquidity Health Assessment</h4>
            <div className="p-3 bg-amber-50 rounded-none border-2 border-amber-500 text-amber-900 space-y-1.5">
              <div className="flex items-center space-x-1.5 font-black uppercase text-xs">
                <ShieldAlert className="h-4 w-4 text-amber-600 shrink-0" />
                <span>Maturity Concentration Alert</span>
              </div>
              <p className="text-[11px] leading-relaxed font-bold">
                The <strong>1 Week</strong> and <strong>3 Months</strong> buckets exhibit minor structural deficit gaps totaling <strong>-$600m</strong>. While the total HQLA cushion provides perfect protection, treasury recommends extending funding tenors.
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* Real-time Collateral Optimization Table */}
      <div className="bg-white border-4 border-brand-border rounded-none shadow-[4px_4px_0px_rgba(11,29,42,0.15)] overflow-hidden">
        <div className="p-5 border-b-4 border-brand-border bg-brand-cream/40">
          <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Unencumbered Collateral Pools</h3>
          <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">High-quality liquid assets available as collateral for repo and central bank facilities.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-brand-navy">
            <thead className="bg-brand-cream/60 text-[10px] font-black text-brand-steel uppercase tracking-widest border-b-4 border-brand-border select-none">
              <tr>
                <th className="px-5 py-3">Collateral Asset Name</th>
                <th className="px-5 py-3">ISIN ID</th>
                <th className="px-5 py-3">Asset Classification</th>
                <th className="px-5 py-3">Total Value</th>
                <th className="px-5 py-3 text-center">Haircut %</th>
                <th className="px-5 py-3">Eligible Funding Value</th>
                <th className="px-5 py-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-brand-border font-bold">
              <tr className="hover:bg-brand-cream/30">
                <td className="px-5 py-3 font-black">UK Gilt 2030 Pool</td>
                <td className="px-5 py-3 font-mono text-[11px] text-slate-500">GB00B16XYZ88</td>
                <td className="px-5 py-3">Level 1 HQLA</td>
                <td className="px-5 py-3 font-black font-mono">$12,000m</td>
                <td className="px-5 py-3 text-center font-black">2.0%</td>
                <td className="px-5 py-3 font-mono font-black text-brand-steel">$11,760m</td>
                <td className="px-5 py-3 text-right">
                  <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-none border-2 border-emerald-500 font-black text-[9px] uppercase tracking-wide">UNENCUMBERED</span>
                </td>
              </tr>
              <tr className="hover:bg-brand-cream/30">
                <td className="px-5 py-3 font-black">US Treasury 10Y Pool</td>
                <td className="px-5 py-3 font-mono text-[11px] text-slate-500">US912828TY22</td>
                <td className="px-5 py-3">Level 1 HQLA</td>
                <td className="px-5 py-3 font-black font-mono">$9,500m</td>
                <td className="px-5 py-3 text-center font-black">1.5%</td>
                <td className="px-5 py-3 font-mono font-black text-brand-steel">$9,357m</td>
                <td className="px-5 py-3 text-right">
                  <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-none border-2 border-emerald-500 font-black text-[9px] uppercase tracking-wide">UNENCUMBERED</span>
                </td>
              </tr>
              <tr className="hover:bg-brand-cream/30">
                <td className="px-5 py-3 font-black">HSBC Corp Bond Pool</td>
                <td className="px-5 py-3 font-mono text-[11px] text-slate-500">XS1442119932</td>
                <td className="px-5 py-3">Level 2A HQLA</td>
                <td className="px-5 py-3 font-black font-mono">$8,500m</td>
                <td className="px-5 py-3 text-center font-black">15.0%</td>
                <td className="px-5 py-3 font-mono font-black text-brand-steel">$7,225m</td>
                <td className="px-5 py-3 text-right">
                  <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded-none border-2 border-blue-400 font-black text-[9px] uppercase tracking-wide">REPOSSESSABLE</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
