import React, { useState, useEffect } from "react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ReferenceLine
} from "recharts";
import { 
  TrendingUp, 
  AlertOctagon, 
  Sparkles, 
  Info,
  Calendar,
  Layers,
  ArrowRight
} from "lucide-react";
import { ScenarioDefinition, StressProjectionResult } from "../types";

interface CapitalPlannerProps {
  onLogEntry: (action: string, details: string) => void;
}

export default function CapitalPlanner({ onLogEntry }: CapitalPlannerProps) {
  const [scenarios, setScenarios] = useState<ScenarioDefinition[]>([]);
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>("s4"); // Default to Credit Market Shock
  const [loading, setLoading] = useState<boolean>(false);
  const [projection, setProjection] = useState<StressProjectionResult | null>(null);

  // Load scenarios from our Express backend
  const fetchScenarios = async () => {
    try {
      const response = await fetch("/api/scenarios");
      const data: ScenarioDefinition[] = await response.json();
      setScenarios(data);
    } catch (e) {
      console.error("Failed to fetch stress scenarios:", e);
    }
  };

  // Run the multi-year macro stress test on our backend (simulating R statistical forecasting models)
  const runStressTest = async (scenarioId: string) => {
    setLoading(true);
    try {
      const response = await fetch("/api/scenarios/run-stress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scenarioId })
      });
      const data: StressProjectionResult = await response.json();
      setProjection(data);
    } catch (e) {
      console.error("Failed to evaluate stress scenario:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchScenarios();
  }, []);

  useEffect(() => {
    if (selectedScenarioId) {
      runStressTest(selectedScenarioId);
    }
  }, [selectedScenarioId]);

  const activeScenario = scenarios.find(s => s.id === selectedScenarioId);

  // Convert projection data to recharts structure
  const chartData = projection?.timeline.map(t => ({
    year: `Y${t.year}`,
    "CET1 Ratio (%)": t.cet1Ratio,
    "Liquidity Ratio (LCR %)": t.liquidityCoverageRatio,
    "Profitability (USDm)": t.profitability,
    "Portfolio Value ($100m)": parseFloat((t.portfolioValue / 100).toFixed(1))
  })) || [];

  return (
    <div className="space-y-6 font-sans" id="prudential-planning-module">
      
      {/* Module Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-brand-navy p-6 rounded-none border-4 border-brand-border shadow-[4px_4px_0px_rgba(11,29,42,0.15)] text-white">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight uppercase">
            Capital Planning & Macro Scenario Engine
          </h2>
          <p className="text-slate-300 text-xs font-bold uppercase tracking-wider mt-1">
            Simulate 1-year, 3-year, 5-year, and 10-year prudential projections under customizable macroeconomic shock scenarios.
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-1 items-center bg-brand-cream/10 border-2 border-white rounded-none px-3 py-1.5 text-xs font-black uppercase text-white">
          <Calendar className="h-4 w-4 text-white mr-1.5" />
          <span>Horizon: 10 Years</span>
        </div>
      </div>

      {/* Scenario Selection Grid */}
      <div className="space-y-2">
        <label className="text-xs font-black text-brand-navy uppercase tracking-widest block mb-2">
          Select Active Stressed Macro Scenario
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
          {scenarios.map((sc) => {
            const isSelected = sc.id === selectedScenarioId;
            return (
              <button
                key={sc.id}
                onClick={() => {
                  setSelectedScenarioId(sc.id);
                  onLogEntry("Macro Stress Scenario Selected", `Initiated stress projection under [${sc.name}]`);
                }}
                className={`p-4 rounded-none border-4 text-left flex flex-col justify-between h-36 transition-all cursor-pointer ${
                  isSelected
                    ? "bg-brand-navy border-brand-steel text-white shadow-[4px_4px_0px_rgba(11,29,42,0.15)]"
                    : "bg-white border-brand-border text-brand-navy hover:border-brand-steel hover:bg-brand-cream/20 shadow-[4px_4px_0px_rgba(11,29,42,0.15)]"
                }`}
                id={`scenario-button-${sc.id}`}
              >
                <div className="space-y-1">
                  <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded-none border-2 ${
                    sc.category === "Expansion" ? "bg-emerald-50 border-emerald-500 text-emerald-700" :
                    sc.category === "Shock" ? "bg-orange-50 border-orange-500 text-orange-700" :
                    sc.category === "Crisis" ? "bg-red-50 border-red-500 text-red-700" : "bg-blue-50 border-blue-500 text-blue-700"
                  }`}>
                    {sc.category}
                  </span>
                  <h4 className="text-xs font-black uppercase truncate w-full mt-2 tracking-tight">{sc.name}</h4>
                </div>
                <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed font-bold uppercase tracking-wide mt-1">{sc.description}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Primary Projections Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Core Charts Area */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Chart 1: Capital & Liquidity Ratios */}
          <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] flex flex-col justify-between">
            <div className="mb-4">
              <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">CET1 Capital Adequacy Projection</h3>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Stressed capital ratio pathway. Basel Pillar 1 requirement represented at 4.5%.</p>
            </div>

            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                  <XAxis dataKey="year" stroke="#0B1D2A" tick={{ fontSize: 10, fontWeight: "bold" }} />
                  <YAxis tickFormatter={(val) => `${val}%`} stroke="#0B1D2A" tick={{ fontSize: 10, fontWeight: "bold" }} domain={[0, 25]} />
                  <Tooltip contentStyle={{ backgroundColor: "#0B1D2A", color: "#F5F5F0", borderRadius: "0px", border: "2px solid #BCC6CC", fontSize: "11px", fontWeight: "bold" }} />
                  <Legend wrapperStyle={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase" }} />
                  
                  {/* Baselines */}
                  <ReferenceLine y={4.5} stroke="#EF4444" strokeWidth={2} strokeDasharray="5 5" label={{ value: "REGULATORY CET1 LIMIT (4.5%)", fill: "#EF4444", fontSize: 9, fontWeight: "bold", position: "top" }} />
                  <ReferenceLine y={12.0} stroke="#4682B4" strokeWidth={2} strokeDasharray="3 3" label={{ value: "INTERNAL BANK TARGET (12%)", fill: "#4682B4", fontSize: 9, fontWeight: "bold", position: "top" }} />

                  <Line type="monotone" dataKey="CET1 Ratio (%)" stroke="#10B981" strokeWidth={3} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2: Liquidity Coverage Ratio */}
          <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] flex flex-col justify-between">
            <div className="mb-4">
              <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Liquidity Coverage Ratio Pathway</h3>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Contractual 30-day survival horizon under stressed outflow events (Minimum 100%).</p>
            </div>

            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                  <XAxis dataKey="year" stroke="#0B1D2A" tick={{ fontSize: 10, fontWeight: "bold" }} />
                  <YAxis tickFormatter={(val) => `${val}%`} stroke="#0B1D2A" tick={{ fontSize: 10, fontWeight: "bold" }} domain={[50, 200]} />
                  <Tooltip contentStyle={{ backgroundColor: "#0B1D2A", color: "#F5F5F0", borderRadius: "0px", border: "2px solid #BCC6CC", fontSize: "11px", fontWeight: "bold" }} />
                  <Legend wrapperStyle={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase" }} />
                  
                  {/* Minimum LCR */}
                  <ReferenceLine y={100} stroke="#EF4444" strokeWidth={2} strokeDasharray="5 5" label={{ value: "REGULATORY MINIMUM (100%)", fill: "#EF4444", fontSize: 9, fontWeight: "bold", position: "top" }} />

                  <Line type="monotone" dataKey="Liquidity Ratio (LCR %)" stroke="#4682B4" strokeWidth={3} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

        {/* Shock Parameters Sidebar */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] space-y-6">
          <div>
            <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight flex items-center space-x-1.5">
              <AlertOctagon className="h-4.5 w-4.5 text-brand-steel" />
              <span>Scenario Macro Indicators</span>
            </h3>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Parameters applied to R macroeconomic projection systems.</p>
          </div>

          {activeScenario && (
            <div className="space-y-4 text-xs font-bold text-brand-navy">
              
              <div className="p-3.5 bg-brand-cream/50 border-2 border-brand-border rounded-none">
                <span className="font-black uppercase text-brand-navy text-xs block">{activeScenario.name}</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-wide italic mt-1 block leading-normal">{activeScenario.description}</span>
              </div>

              {/* Stress Coefficients list */}
              <div className="space-y-2 uppercase tracking-wide">
                <div className="flex justify-between border-b-2 border-brand-border pb-1.5">
                  <span className="text-slate-600">GDP Compounding Change</span>
                  <span className={`font-mono font-black ${activeScenario.gdpImpact >= 0 ? "text-emerald-700" : "text-red-600"}`}>
                    {activeScenario.gdpImpact >= 0 ? "+" : ""}{activeScenario.gdpImpact}%
                  </span>
                </div>
                <div className="flex justify-between border-b-2 border-brand-border pb-1.5">
                  <span className="text-slate-600">Central Bank Rate Shock</span>
                  <span className="font-mono font-black text-brand-steel">
                    {activeScenario.rateShock >= 0 ? "+" : ""}{activeScenario.rateShock} bps
                  </span>
                </div>
                <div className="flex justify-between border-b-2 border-brand-border pb-1.5">
                  <span className="text-slate-600">Corporate Credit Spread</span>
                  <span className="font-mono font-black text-brand-navy">
                    +{activeScenario.creditSpreadImpact} bps
                  </span>
                </div>
                <div className="flex justify-between border-b-2 border-brand-border pb-1.5">
                  <span className="text-slate-600">Liquid Asset Haircuts</span>
                  <span className="font-mono font-black text-red-600">
                    {activeScenario.assetHaircut}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Inflation Shifting Coefficient</span>
                  <span className="font-mono font-black text-brand-navy">
                    {activeScenario.inflationImpact >= 0 ? "+" : ""}{activeScenario.inflationImpact}% points
                  </span>
                </div>
              </div>

              {/* Projections Key Performance Indicators */}
              <div className="bg-brand-navy text-white p-4 rounded-none border-2 border-brand-border space-y-3 pt-3">
                <h4 className="font-black text-[10px] text-brand-steel uppercase tracking-widest">
                  Timeline Projections (10Y)
                </h4>
                {projection?.timeline.map((t, idx) => (
                  <div key={idx} className="flex justify-between items-center text-[11px] border-b border-brand-cream/25 pb-2 last:border-0 last:pb-0 font-bold uppercase tracking-wide">
                    <span className="font-black text-slate-300">Year {t.year}</span>
                    <div className="text-right">
                      <span className={`font-mono font-black block ${t.cet1Ratio < 12 ? "text-red-400" : "text-emerald-400"}`}>
                        CET1: {t.cet1Ratio}%
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono block font-black">
                        Net Profit: ${t.profitability}m
                      </span>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
}
