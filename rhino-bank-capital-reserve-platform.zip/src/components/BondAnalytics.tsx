import React, { useState, useEffect } from "react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  BarChart,
  Bar
} from "recharts";
import { 
  Sliders, 
  TrendingUp, 
  Settings2, 
  HelpCircle, 
  Info,
  Zap,
  Activity
} from "lucide-react";
import { BondAnalyticsResult } from "../types";

interface BondAnalyticsProps {
  onLogEntry: (action: string, details: string) => void;
}

export default function BondAnalytics({ onLogEntry }: BondAnalyticsProps) {
  
  // Nelson-Siegel-Svensson Model Parameters State
  const [beta0, setBeta0] = useState<number>(4.2);  // long-term level (shift)
  const [beta1, setBeta1] = useState<number>(-1.5); // short-term component (slope)
  const [beta2, setBeta2] = useState<number>(-2.0); // medium-term component (curvature)
  const [beta3, setBeta3] = useState<number>(1.0);  // second curvature component
  const [tau1, setTau1] = useState<number>(1.8);    // first scale factor
  const [tau2, setTau2] = useState<number>(5.0);    // second scale factor

  const [loading, setLoading] = useState<boolean>(false);
  const [curveData, setCurveData] = useState<BondAnalyticsResult | null>(null);

  // Fetch the bootstrapped bond analytics from our Express server (simulating R packages)
  const fetchCurveData = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `/api/analytics/bond-curve?beta0=${beta0}&beta1=${beta1}&beta2=${beta2}&beta3=${beta3}&tau1=${tau1}&tau2=${tau2}`
      );
      const data: BondAnalyticsResult = await response.json();
      setCurveData(data);
    } catch (e) {
      console.error("Failed to fetch bootstrapped yield curve:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCurveData();
  }, [beta0, beta1, beta2, beta3, tau1, tau2]);

  const handleResetParameters = () => {
    setBeta0(4.2);
    setBeta1(-1.5);
    setBeta2(-2.0);
    setBeta3(1.0);
    setTau1(1.8);
    setTau2(5.0);
    onLogEntry("Yield Curve Calibrated", "Reset Nelson-Siegel-Svensson model parameters to bank benchmark standards.");
  };

  // Convert maturities & yields to recharts layout
  const formattedChartData = curveData?.maturities.map((m, idx) => ({
    maturity: `${m}Y`,
    "Nelson-Siegel": curveData.nelsonSiegelSpot[idx],
    "Nelson-Siegel-Svensson": curveData.nelsonSiegelSvenssonSpot[idx],
    "Forward Curve": curveData.forwardCurve[idx],
    "PCA Yield Curve": curveData.pcaYieldCurve[idx]
  })) || [];

  return (
    <div className="space-y-6 font-sans" id="bond-analytics-module">
      
      {/* Module Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-brand-navy p-6 rounded-none border-4 border-brand-border shadow-[4px_4px_0px_rgba(11,29,42,0.15)] text-white">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight uppercase">
            Fixed Income & Yield Curve Analytics
          </h2>
          <p className="text-slate-300 text-xs font-bold uppercase tracking-wider mt-1">
            Nelson-Siegel-Svensson (NSS) spot curve bootstrapping, principal component analysis (PCA), and key rate duration matching.
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button 
            onClick={handleResetParameters}
            className="bg-brand-steel hover:bg-brand-steel/80 text-white text-xs font-black uppercase tracking-widest px-4 py-2.5 rounded-none border-2 border-white flex items-center space-x-1.5 transition-all shadow-[2px_2px_0px_rgba(0,0,0,0.15)] cursor-pointer"
          >
            <Settings2 className="h-4 w-4 text-white" />
            <span>Reset Model Defaults</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Curve visualizer + parameters controller */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Sliders Controllers Panel */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] space-y-6">
          <div>
            <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">NSS Model Calibration</h3>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Adjust spline parameters to simulate parallel shifts, steepening, and humps.</p>
          </div>

          <div className="space-y-4">
            
            {/* Beta 0 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black uppercase tracking-wide text-brand-navy">
                <span className="flex items-center space-x-1">
                  <span>Beta 0 (Long-Term / Level)</span>
                  <Info className="h-3 w-3 text-brand-steel" title="Determines the general interest rate level or parallel shift." />
                </span>
                <span className="font-mono text-brand-steel font-black">{beta0.toFixed(2)}%</span>
              </div>
              <input 
                type="range" min="1.0" max="8.0" step="0.1" value={beta0}
                onChange={(e) => {
                  setBeta0(parseFloat(e.target.value));
                  onLogEntry("NSS Parameter Change", `Adjusted Beta 0 (Level) to ${e.target.value}%`);
                }}
                className="w-full accent-brand-steel cursor-pointer h-2 bg-brand-cream border border-brand-border"
              />
            </div>

            {/* Beta 1 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black uppercase tracking-wide text-brand-navy">
                <span className="flex items-center space-x-1">
                  <span>Beta 1 (Short-Term / Slope)</span>
                  <Info className="h-3 w-3 text-brand-steel" title="Determines the slope of the yield curve (spread between short and long)." />
                </span>
                <span className="font-mono text-brand-steel font-black">{beta1.toFixed(2)}%</span>
              </div>
              <input 
                type="range" min="-4.0" max="4.0" step="0.1" value={beta1}
                onChange={(e) => {
                  setBeta1(parseFloat(e.target.value));
                  onLogEntry("NSS Parameter Change", `Adjusted Beta 1 (Slope) to ${e.target.value}%`);
                }}
                className="w-full accent-brand-steel cursor-pointer h-2 bg-brand-cream border border-brand-border"
              />
            </div>

            {/* Beta 2 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black uppercase tracking-wide text-brand-navy">
                <span className="flex items-center space-x-1">
                  <span>Beta 2 (Curvature Hump 1)</span>
                  <Info className="h-3 w-3 text-brand-steel" title="Determines the shape and height of the first curvature hump." />
                </span>
                <span className="font-mono text-brand-steel font-black">{beta2.toFixed(2)}%</span>
              </div>
              <input 
                type="range" min="-5.0" max="5.0" step="0.1" value={beta2}
                onChange={(e) => {
                  setBeta2(parseFloat(e.target.value));
                  onLogEntry("NSS Parameter Change", `Adjusted Beta 2 (Hump 1) to ${e.target.value}%`);
                }}
                className="w-full accent-brand-steel cursor-pointer h-2 bg-brand-cream border border-brand-border"
              />
            </div>

            {/* Beta 3 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black uppercase tracking-wide text-brand-navy">
                <span className="flex items-center space-x-1">
                  <span>Beta 3 (Curvature Hump 2)</span>
                  <Info className="h-3 w-3 text-brand-steel" title="Determines the shape of the second curvature hump (exclusive to Svensson model)." />
                </span>
                <span className="font-mono text-brand-steel font-black">{beta3.toFixed(2)}%</span>
              </div>
              <input 
                type="range" min="-5.0" max="5.0" step="0.1" value={beta3}
                onChange={(e) => {
                  setBeta3(parseFloat(e.target.value));
                  onLogEntry("NSS Parameter Change", `Adjusted Beta 3 (Hump 2) to ${e.target.value}%`);
                }}
                className="w-full accent-brand-steel cursor-pointer h-2 bg-brand-cream border border-brand-border"
              />
            </div>

            {/* Tau 1 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black uppercase tracking-wide text-brand-navy">
                <span className="flex items-center space-x-1">
                  <span>Tau 1 (Scale Factor 1)</span>
                  <Info className="h-3 w-3 text-brand-steel" title="Determines the location/maturity where Curvature 1 peaks." />
                </span>
                <span className="font-mono text-brand-steel font-black">{tau1.toFixed(1)}Y</span>
              </div>
              <input 
                type="range" min="0.5" max="10.0" step="0.1" value={tau1}
                onChange={(e) => {
                  setTau1(parseFloat(e.target.value));
                }}
                className="w-full accent-brand-steel cursor-pointer h-2 bg-brand-cream border border-brand-border"
              />
            </div>

            {/* Tau 2 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black uppercase tracking-wide text-brand-navy">
                <span className="flex items-center space-x-1">
                  <span>Tau 2 (Scale Factor 2)</span>
                  <Info className="h-3 w-3 text-brand-steel" title="Determines the location/maturity where Curvature 2 peaks." />
                </span>
                <span className="font-mono text-brand-steel font-black">{tau2.toFixed(1)}Y</span>
              </div>
              <input 
                type="range" min="1.0" max="15.0" step="0.1" value={tau2}
                onChange={(e) => {
                  setTau2(parseFloat(e.target.value));
                }}
                className="w-full accent-brand-steel cursor-pointer h-2 bg-brand-cream border border-brand-border"
              />
            </div>

          </div>
        </div>

        {/* Curves Multi-Chart Visualizer */}
        <div className="lg:col-span-2 bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] flex flex-col justify-between">
          <div>
            <div className="mb-4 flex justify-between items-center">
              <div>
                <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Bootstrapped Term Structure Yield Curves</h3>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Plots spot, forward, and PCA shifts modeled in our R quantitative analytics server.</p>
              </div>
              {loading && <span className="text-xs bg-brand-cream text-brand-steel border-2 border-brand-steel px-2 py-0.5 rounded-none font-mono font-black animate-pulse uppercase tracking-widest">BOOTSTRAPPING...</span>}
            </div>

            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={formattedChartData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                  <XAxis dataKey="maturity" tick={{ fontSize: 10, fontWeight: "bold" }} stroke="#0B1D2A" />
                  <YAxis tickFormatter={(val) => `${val}%`} tick={{ fontSize: 10, fontWeight: "bold" }} stroke="#0B1D2A" domain={["auto", "auto"]} />
                  <Tooltip contentStyle={{ backgroundColor: "#0B1D2A", color: "#F5F5F0", borderRadius: "0px", border: "2px solid #BCC6CC", fontSize: "11px", fontWeight: "bold" }} />
                  <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px", fontWeight: "bold", textTransform: "uppercase" }} />
                  
                  {/* Svensson (NSS) spot */}
                  <Line type="monotone" dataKey="Nelson-Siegel-Svensson" stroke="#4682B4" strokeWidth={3} dot={{ r: 3 }} />
                  
                  {/* Nelson Siegel spot */}
                  <Line type="monotone" dataKey="Nelson-Siegel" stroke="#303437" strokeWidth={1.5} strokeDasharray="5 5" dot={false} />
                  
                  {/* Forward curve */}
                  <Line type="monotone" dataKey="Forward Curve" stroke="#F59E0B" strokeWidth={2} dot={false} />
                  
                  {/* PCA 1st Principal Component Curve */}
                  <Line type="monotone" dataKey="PCA Yield Curve" stroke="#10B981" strokeWidth={2} strokeDasharray="3 3" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-4 border-t-2 border-brand-border flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-500">
            <span>Model: Nelson-Siegel-Svensson Splines</span>
            <span>R optimization: Ordinary Least Squares (OLS) Bootstrap</span>
          </div>
        </div>

      </div>

      {/* Immunization & Key Rate Durations */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Core Bond Stats */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] space-y-4">
          <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight flex items-center space-x-1.5">
            <Activity className="h-4.5 w-4.5 text-brand-steel" />
            <span>Sensitivity & Volatility Stats</span>
          </h3>
          <div className="space-y-2.5 text-xs font-bold text-brand-navy">
            <div className="flex justify-between border-b-2 border-brand-border pb-1.5">
              <span className="text-slate-600 uppercase">Modified Duration</span>
              <span className="font-mono font-black text-brand-navy">{curveData?.stats.modifiedDuration || "6.45"} years</span>
            </div>
            <div className="flex justify-between border-b-2 border-brand-border pb-1.5">
              <span className="text-slate-600 uppercase">Convexity</span>
              <span className="font-mono font-black text-brand-navy">+{curveData?.stats.convexity || "54.2"}%</span>
            </div>
            <div className="flex justify-between border-b-2 border-brand-border pb-1.5">
              <span className="text-slate-600 uppercase">Spread Duration</span>
              <span className="font-mono font-black text-brand-navy">{curveData?.stats.spreadDuration || "4.8"} years</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600 uppercase">Immunization Status</span>
              <span className="text-emerald-700 bg-emerald-50 border border-emerald-400 px-2 py-0.5 font-black uppercase text-[10px]">{curveData?.stats.immunizationStatus || "OPTIMIZED"}</span>
            </div>
          </div>
        </div>

        {/* Key Rate Durations chart */}
        <div className="md:col-span-2 bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] flex flex-col justify-between">
          <div className="mb-2">
            <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Key Rate Duration Profile</h3>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Measures portfolio value sensitivity to rate changes at specific points along the curve.</p>
          </div>
          
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={curveData?.stats.keyRateDurations || []} layout="vertical" margin={{ left: 20, right: 20, top: 5, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#F1F5F9" />
                <XAxis type="number" stroke="#0B1D2A" tick={{ fontSize: 9, fontWeight: "bold" }} />
                <YAxis dataKey="rate" type="category" stroke="#0B1D2A" tick={{ fontSize: 9, fontWeight: "bold" }} />
                <Tooltip contentStyle={{ backgroundColor: "#0B1D2A", color: "#F5F5F0", borderRadius: "0px", border: "2px solid #BCC6CC", fontSize: "11px", fontWeight: "bold" }} />
                <Bar dataKey="duration" fill="#4682B4" barSize={12} radius={0} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
}
