import React, { useState, useEffect } from "react";
import { 
  ShieldAlert, 
  TrendingUp, 
  HelpCircle, 
  Percent, 
  Info,
  RefreshCw,
  Zap,
  CheckCircle,
  AlertOctagon
} from "lucide-react";

interface RiskStats {
  valueAtRisk: number;
  expectedShortfall: number;
  marketRisk: number;
  creditRisk: number;
  interestRateRisk: number;
  liquidityRisk: number;
  operationalRisk: number;
  counterpartyRisk: number;
  portfolioVolatility: number;
  portfolioReturn: number;
  diversificationBenefit: number;
}

interface RiskEngineProps {
  onLogEntry: (action: string, details: string) => void;
}

export default function RiskEngine({ onLogEntry }: RiskEngineProps) {
  const [loading, setLoading] = useState<boolean>(false);
  const [riskData, setRiskData] = useState<RiskStats | null>(null);

  const fetchRiskStats = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/analytics/risk-monte-carlo");
      const data: RiskStats = await response.json();
      setRiskData(data);
    } catch (e) {
      console.error("Failed to load Monte Carlo risk statistics:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRiskStats();
  }, []);

  const formatCurrency = (val: number) => {
    return `$${val.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}m`;
  };

  // Statically designed risk matrix heat map matching Yorkshire engineering standard
  const heatMapGrid = [
    { name: "Sovereign Default Risk", impact: "High", likelihood: "Low", rating: "Moderate", color: "bg-amber-50 text-amber-950 border-amber-500" },
    { name: "Commercial Property Collapse", impact: "Very High", likelihood: "Medium", rating: "Substantial", color: "bg-orange-50 text-orange-950 border-orange-500" },
    { name: "SME Credit Spread Spikes", impact: "High", likelihood: "High", rating: "Critical", color: "bg-red-50 text-red-950 border-red-500" },
    { name: "Clearing House Intraday Freeze", impact: "Critical", likelihood: "Low", rating: "Substantial", color: "bg-orange-50 text-orange-950 border-orange-500" },
    { name: "Operational System Failure", impact: "Medium", likelihood: "Low", rating: "Minor", color: "bg-emerald-50 text-emerald-950 border-emerald-500" },
    { name: "Interest Rate Sudden Parallel Shift", impact: "Medium", likelihood: "High", rating: "Moderate", color: "bg-amber-50 text-amber-950 border-amber-500" }
  ];

  return (
    <div className="space-y-6 font-sans" id="risk-engine-module">
      
      {/* Module Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-brand-navy p-6 rounded-none border-4 border-brand-border shadow-[4px_4px_0px_rgba(11,29,42,0.15)] text-white">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight uppercase">
            Risk Management & Quantitative Engine
          </h2>
          <p className="text-slate-300 text-xs font-bold uppercase tracking-wider mt-1">
            Monte Carlo simulated Value-at-Risk (99% VaR), Expected Shortfall (ES), and key risk-weight concentration benchmarks.
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button 
            onClick={() => {
              fetchRiskStats();
              onLogEntry("Monte Carlo Simulation Run", "Triggered live R-Simulation thread: 500 stochastic trials generated.");
            }}
            disabled={loading}
            className="bg-brand-steel hover:bg-brand-steel/80 text-white text-xs font-black uppercase tracking-widest px-4 py-2.5 rounded-none border-2 border-white flex items-center space-x-1.5 transition-all shadow-[2px_2px_0px_rgba(0,0,0,0.15)] cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            <span>{loading ? "Simulating..." : "Execute stochastic trial (R)"}</span>
          </button>
        </div>
      </div>

      {/* Main KPI panel */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        
        {/* KPI 1: Value at Risk */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">99% Value-at-Risk (VaR)</span>
            <span className="text-3xl font-black text-brand-navy block mt-1 font-mono">
              {riskData ? formatCurrency(riskData.valueAtRisk) : "$1,124.5m"}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 font-bold mt-4 leading-normal">
            Stochastic estimation of maximum portfolio loss over a 10-day holding period at 99% confidence.
          </p>
        </div>

        {/* KPI 2: Expected Shortfall */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Expected Shortfall (ES)</span>
            <span className="text-3xl font-black text-brand-navy block mt-1 font-mono">
              {riskData ? formatCurrency(riskData.expectedShortfall) : "$1,642.0m"}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 font-bold mt-4 leading-normal">
            Measures the average loss in the worst 1% tail of outcomes (Beyond the 99% VaR threshold).
          </p>
        </div>

        {/* KPI 3: Volatility */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Stochastic Volatility</span>
            <span className="text-3xl font-black text-brand-navy block mt-1 font-mono">
              {riskData ? `${(riskData.portfolioVolatility * 10).toFixed(2)}%` : "6.85%"}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 font-bold mt-4 leading-normal">
            Annualized standard deviation of simulated multi-asset returns.
          </p>
        </div>

        {/* KPI 4: Diversification Benefit */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-brand-steel"></div>
          <div>
            <span className="text-[10px] font-black text-brand-steel uppercase tracking-widest block">Diversification Index</span>
            <span className="text-3xl font-black text-emerald-700 block mt-1 font-mono">
              {riskData ? `${riskData.diversificationBenefit.toFixed(1)}%` : "24.5%"}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 font-bold mt-4 leading-normal">
            Uncorrelated asset coefficient reduction benefit achieved.
          </p>
        </div>

      </div>

      {/* Risk Segments and Matrix Heat Map */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Risk Allocations Breakdown */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] space-y-4">
          <div>
            <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Quant Risk Segment Allocation</h3>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Stochastic and empirical capital loss allocations per asset risk class.</p>
          </div>

          <div className="space-y-3 font-bold text-brand-navy">
            
            {/* Market Risk */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black">
                <span className="uppercase">Market Price Risk (VaR-derived)</span>
                <span className="font-mono text-brand-steel font-black">{riskData ? formatCurrency(riskData.marketRisk) : "$1,124.5m"}</span>
              </div>
              <div className="w-full bg-brand-cream h-3 rounded-none border-2 border-brand-border overflow-hidden">
                <div className="bg-brand-navy h-full" style={{ width: "75%" }}></div>
              </div>
            </div>

            {/* Credit Risk */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black">
                <span className="uppercase">Credit Spread & Rating Default Risk</span>
                <span className="font-mono text-brand-steel font-black">{riskData ? formatCurrency(riskData.creditRisk) : "$663.0m"}</span>
              </div>
              <div className="w-full bg-brand-cream h-3 rounded-none border-2 border-brand-border overflow-hidden">
                <div className="bg-brand-steel h-full" style={{ width: "45%" }}></div>
              </div>
            </div>

            {/* Interest Rate Risk */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black">
                <span className="uppercase">Interest Rate Yield Sensitivity (DV01)</span>
                <span className="font-mono text-brand-steel font-black">{riskData ? formatCurrency(riskData.interestRateRisk) : "$397.8m"}</span>
              </div>
              <div className="w-full bg-brand-cream h-3 rounded-none border-2 border-brand-border overflow-hidden">
                <div className="bg-[#BCC6CC] h-full" style={{ width: "30%" }}></div>
              </div>
            </div>

            {/* Liquidity Risk */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black">
                <span className="uppercase">Liquidity Asset Haircut Risk</span>
                <span className="font-mono text-brand-steel font-black">{riskData ? formatCurrency(riskData.liquidityRisk) : "$176.8m"}</span>
              </div>
              <div className="w-full bg-brand-cream h-3 rounded-none border-2 border-brand-border overflow-hidden">
                <div className="bg-[#4682B4] h-full" style={{ width: "15%" }}></div>
              </div>
            </div>

            {/* Operational Risk */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-black">
                <span className="uppercase">Operational & Security Failure Risk</span>
                <span className="font-mono text-brand-steel font-black">{riskData ? formatCurrency(riskData.operationalRisk) : "$132.6m"}</span>
              </div>
              <div className="w-full bg-brand-cream h-3 rounded-none border-2 border-brand-border overflow-hidden">
                <div className="bg-[#303437] h-full" style={{ width: "10%" }}></div>
              </div>
            </div>

          </div>
        </div>

        {/* Risk Heat Map Board */}
        <div className="bg-white border-4 border-brand-border rounded-none p-5 shadow-[4px_4px_0px_rgba(11,29,42,0.15)] space-y-4">
          <div>
            <h3 className="font-black text-brand-navy uppercase text-sm tracking-tight">Executive Risk Committee Dashboard</h3>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Prudential risk heatmap evaluating impact severity and trigger likelihoods.</p>
          </div>

          <div className="grid grid-cols-1 gap-2.5">
            {heatMapGrid.map((row, idx) => (
              <div key={idx} className={`p-3 rounded-none border-2 flex justify-between items-center font-bold ${row.color}`}>
                <div className="space-y-0.5">
                  <span className="text-xs font-black uppercase tracking-wide block">{row.name}</span>
                  <div className="flex space-x-2 text-[10px] font-bold uppercase tracking-wider opacity-85">
                    <span>Impact: {row.impact}</span>
                    <span>•</span>
                    <span>Likelihood: {row.likelihood}</span>
                  </div>
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-none border-2 bg-white">
                  {row.rating}
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
