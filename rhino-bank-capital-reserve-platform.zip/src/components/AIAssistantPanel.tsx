import React, { useState, useRef, useEffect } from "react";
import { 
  Send, 
  Bot, 
  User, 
  HelpCircle, 
  Sparkles, 
  FileText, 
  ShieldAlert, 
  ArrowRight,
  RefreshCw,
  BookOpen
} from "lucide-react";
import { ChatMessage } from "../types";

interface AIAssistantPanelProps {
  onLogEntry: (action: string, details: string) => void;
}

export default function AIAssistantPanel({ onLogEntry }: AIAssistantPanelProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "model",
      parts: [
        {
          text: `### Rhino Bank Treasury AI Copilot
          
How can I assist your committee today? I have full access to our Capital adequacy metrics, liquidity gaps, Nelson-Siegel curves, and multi-asset stress testing algorithms.
          
**I can support your workflow with these quantitative tools:**
*   **Forecast capital requirements**: Analyze the impacts of compounding macroeconomic projections.
*   **Recommend portfolio rebalancing**: Draft options to optimize RWA and expand CET1 ratios.
*   **Draft executive committee reports**: Generate formal Board-ready prudential papers.`
        }
      ]
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Pre-configured quantitative prompt indicators
  const promptChips = [
    { label: "Draft Executive Committee Report", text: "Draft an Executive Committee Report summarizing our 10-year capital stress-test outcomes under a severe Credit Market Shock scenario." },
    { label: "Formulate Portfolio Rebalancing Plan", text: "Recommend a portfolio rebalancing plan of $800m away from high-risk venture capital and alternatives towards HQLA Government Bonds to boost our CET1 ratio and headroom." },
    { label: "Analyze Emerging Liquidity Pressures", text: "Identify any emerging liquidity pressures based on our contractual inflows and outflows. Detail our 1-Week and 3-Month maturity gap deficits." },
    { label: "Explain Nelson-Siegel Yield curves", text: "Explain how our Nelson-Siegel-Svensson spline coefficients (Beta 0, Beta 1, Beta 2) translate to interest-rate parallel shifts, slopes, and curvature humps." }
  ];

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      role: "user",
      parts: [{ text: textToSend }]
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const response = await fetch("/api/ai/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: textToSend,
          chatHistory: messages
        })
      });

      const data = await response.json();
      const modelMsg: ChatMessage = {
        role: "model",
        parts: [{ text: data.text }]
      };

      setMessages(prev => [...prev, modelMsg]);
      onLogEntry("AI Advisor Queried", `Submitted query to Gemini copilot: [${textToSend.substring(0, 35)}...]`);
    } catch (e) {
      console.error("AI assistant query failed:", e);
      setMessages(prev => [
        ...prev,
        {
          role: "model",
          parts: [{ text: "### Connection Interrupt\n\nFailed to establish connection with our secure server-side AI model. Please verify that your system is online or check with your systems administrator." }]
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(input);
  };

  // Scroll messages to bottom on new additions
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="space-y-6 h-[calc(100vh-140px)] flex flex-col font-sans" id="ai-assistant-module">
      
      {/* Module Title */}
      <div className="bg-brand-navy p-6 rounded-none border-4 border-brand-border shadow-[4px_4px_0px_rgba(11,29,42,0.15)] text-white shrink-0">
        <h2 className="text-2xl font-black text-white tracking-tight uppercase flex items-center space-x-2">
          <Sparkles className="h-6 w-6 text-white animate-pulse" />
          <span>Institutional AI Treasury Advisor</span>
        </h2>
        <p className="text-slate-300 text-xs font-bold uppercase tracking-wider mt-1">
          Server-side Gemini powered prudential risk copilot. Analyzes capital ratios, audits balance-sheet anomalies, and drafts formal risk reports.
        </p>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 min-h-0 bg-white border-4 border-brand-border rounded-none shadow-[4px_4px_0px_rgba(11,29,42,0.15)] flex flex-col overflow-hidden">
        
        {/* Messages list */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 bg-brand-cream/10">
          {messages.map((msg, idx) => {
            const isBot = msg.role === "model";
            return (
              <div 
                key={idx} 
                className={`flex space-x-3.5 max-w-4xl ${isBot ? "" : "ml-auto flex-row-reverse space-x-reverse"}`}
              >
                {/* Avatar Icon */}
                <div className={`p-2.5 rounded-none shrink-0 h-10 w-10 flex items-center justify-center border-2 shadow-[2px_2px_0px_rgba(11,29,42,0.15)] ${
                  isBot 
                    ? "bg-brand-navy text-white border-brand-border" 
                    : "bg-brand-cream text-brand-navy border-brand-border"
                }`}>
                  {isBot ? <Bot className="h-5 w-5" /> : <User className="h-5 w-5" />}
                </div>

                {/* Message Box */}
                <div className={`p-5 rounded-none border-2 text-xs leading-relaxed space-y-3 shadow-[2px_2px_0px_rgba(11,29,42,0.15)] ${
                  isBot 
                    ? "bg-white text-brand-navy border-brand-border" 
                    : "bg-brand-navy text-white border-brand-border"
                }`}>
                  <div className={`prose prose-sm max-w-none font-bold uppercase ${isBot ? "text-brand-navy" : "text-white"}`}>
                    {/* Render basic custom Markdown styling cleanly */}
                    {msg.parts[0].text.split("\n").map((line, lineIdx) => {
                      if (line.trim().startsWith("###")) {
                        return <h3 key={lineIdx} className={`text-xs font-black uppercase tracking-wider mt-3 mb-1 ${isBot ? "text-brand-navy" : "text-white"}`}>{line.replace("###", "").trim()}</h3>;
                      }
                      if (line.trim().startsWith("**")) {
                        return <h4 key={lineIdx} className={`text-[11px] font-black uppercase mt-2 ${isBot ? "text-brand-steel" : "text-brand-cream"}`}>{line.replace(/\*\*/g, "").trim()}</h4>;
                      }
                      if (line.trim().startsWith("*")) {
                        return (
                          <div key={lineIdx} className="flex items-start space-x-1.5 ml-2 mt-1">
                            <span className={`font-black mt-0.5 ${isBot ? "text-brand-steel" : "text-brand-cream"}`}>•</span>
                            <span>{line.substring(1).trim()}</span>
                          </div>
                        );
                      }
                      return <p key={lineIdx} className="mt-1">{line}</p>;
                    })}
                  </div>
                </div>
              </div>
            );
          })}
          {loading && (
            <div className="flex space-x-3.5 max-w-4xl">
              <div className="p-2.5 bg-brand-navy text-white border-2 border-brand-border rounded-none h-10 w-10 flex items-center justify-center shrink-0">
                <Bot className="h-5 w-5" />
              </div>
              <div className="bg-white border-2 border-brand-border px-5 py-4 rounded-none shadow-[2px_2px_0px_rgba(11,29,42,0.15)] text-xs text-slate-500 flex items-center space-x-2">
                <RefreshCw className="h-3.5 w-3.5 animate-spin text-brand-steel" />
                <span className="font-bold text-brand-navy uppercase">Gemini performing quantitative assessment...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Action Prompt Chips */}
        <div className="p-4 border-t-2 border-brand-border bg-brand-cream/20 shrink-0">
          <p className="text-[10px] font-black text-brand-steel uppercase tracking-widest mb-2 flex items-center space-x-1">
            <BookOpen className="h-3.5 w-3.5 text-brand-steel" />
            <span>Select Analytical Intent</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {promptChips.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(chip.text)}
                disabled={loading}
                className="bg-white hover:bg-brand-cream/10 text-brand-navy text-[10px] font-black uppercase px-3 py-1.5 rounded-none border-2 border-brand-border transition-all flex items-center space-x-1 cursor-pointer disabled:opacity-50 shadow-[2px_2px_0px_rgba(11,29,42,0.15)]"
              >
                <span>{chip.label}</span>
                <ArrowRight className="h-3 w-3 text-brand-steel" />
              </button>
            ))}
          </div>
        </div>

        {/* Input Text Form */}
        <div className="p-4 border-t-4 border-brand-border bg-white shrink-0">
          <form onSubmit={handleFormSubmit} className="flex space-x-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask AI Treasury Copilot (e.g., 'Forecast capital under recession')..."
              className="flex-1 text-xs bg-brand-cream/10 border-2 border-brand-border rounded-none px-4 py-3 focus:outline-none focus:border-brand-steel text-brand-navy font-bold uppercase"
              disabled={loading}
              id="ai-prompt-input"
            />
            <button
              type="submit"
              disabled={!input.trim() || loading}
              className="bg-brand-steel hover:bg-brand-steel/80 text-white rounded-none px-5 flex items-center justify-center border-2 border-brand-border transition-all disabled:opacity-50 shadow-[2px_2px_0px_rgba(11,29,42,0.15)] cursor-pointer"
              id="ai-prompt-submit"
            >
              <Send className="h-4.5 w-4.5" />
            </button>
          </form>
        </div>

      </div>

    </div>
  );
}
