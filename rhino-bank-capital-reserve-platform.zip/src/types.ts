export interface PortfolioAsset {
  id: string;
  name: string;
  category: "Government Bonds" | "Corporate Bonds" | "Infrastructure Debt" | "Private Credit" | "Equities" | "Property" | "Renewable Energy" | "Venture Capital" | "Cash" | "Alternatives";
  value: number; // in USD millions
  expectedReturn: number; // annual %
  volatility: number; // annual %
  duration: number; // in years
  convexity: number;
  riskWeight: number; // % regulatory weight
  creditRating: string;
}

export interface CapitalMetrics {
  commonEquityTier1: number; // CET1
  tier1Capital: number;
  tier2Capital: number;
  totalRegulatoryCapital: number;
  riskWeightedAssets: number;
  cet1Ratio: number; // %
  tier1Ratio: number; // %
  totalCapitalRatio: number; // %
  leverageRatio: number; // %
  capitalBufferRequirement: number; // %
  capitalHeadroom: number; // in USD millions
  internalCapitalTarget: number; // %
  availableFinancialResources: number; // USD millions
  totalAssets: number;
}

export interface LiquidityProfile {
  cashReserves: number;
  hqla: number; // High-Quality Liquid Assets
  collateralPools: number;
  fundingConcentrationRatio: number; // %
  wholesaleFundingPercentage: number; // %
  committedFacilities: number;
  maturityBuckets: {
    bucket: "1 Day" | "1 Week" | "1 Month" | "3 Months" | "1 Year" | "5 Years" | "10 Years";
    inflow: number;
    outflow: number;
    net: number;
    cumulativeGap: number;
  }[];
}

export interface BondAnalyticsResult {
  maturities: number[];
  nelsonSiegelSpot: number[];
  nelsonSiegelSvenssonSpot: number[];
  forwardCurve: number[];
  pcaYieldCurve: number[];
  stats: {
    modifiedDuration: number;
    convexity: number;
    spreadDuration: number;
    immunizationStatus: string;
    keyRateDurations: { rate: string; duration: number }[];
  };
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  category: "Expansion" | "Contraction" | "Shock" | "Crisis";
  description: string;
  gdpImpact: number; // % change
  rateShock: number; // bps change
  creditSpreadImpact: number; // bps change
  assetHaircut: number; // % haircut on alternatives
  inflationImpact: number; // % point change
}

export interface StressProjectionResult {
  scenarioId: string;
  timeline: {
    year: number;
    cet1Ratio: number;
    rwa: number;
    liquidityCoverageRatio: number;
    profitability: number; // millions
    portfolioValue: number;
  }[];
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userEmail: string;
  userRole: "Treasury Officer" | "Risk Committee Chair" | "Regulatory Auditor" | "Quantitative Developer";
  action: string;
  details: string;
  ipAddress: string;
  digitalSignature: string;
  hash: string;
}

export interface ChatMessage {
  role: "user" | "model";
  parts: { text: string }[];
}

export interface SecuritySession {
  currentUser: {
    email: string;
    role: "Treasury Officer" | "Risk Committee Chair" | "Regulatory Auditor" | "Quantitative Developer";
    mfaEnabled: boolean;
    token: string;
  };
}
