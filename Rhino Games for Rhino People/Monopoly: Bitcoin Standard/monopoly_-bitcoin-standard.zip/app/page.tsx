'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Header } from '@/components/Header';
import { Board } from '@/components/Board';
import { PlayerDossier } from '@/components/PlayerDossier';
import { QuantTerminal } from '@/components/QuantTerminal';
import { Footer } from '@/components/Footer';

import { CreditDeskModal } from '@/components/CreditDeskModal';
import { MarketModal } from '@/components/MarketModal';
import { MiningModal } from '@/components/MiningModal';
import { QuantLabModal } from '@/components/QuantLabModal';
import { BlockchainVisualizerModal } from '@/components/BlockchainVisualizerModal';
import { AcademyModal } from '@/components/AcademyModal';
import { MonetaryLabModal } from '@/components/MonetaryLabModal';
import { TimeMachineModal } from '@/components/TimeMachineModal';
import { EndReportModal } from '@/components/EndReportModal';

import {
  Player,
  Property,
  Business,
  Loan,
  EconomicState,
  Block,
  Transaction,
  GameEvent,
  GameTimelineEntry,
  MiningFacility,
  Satoshi,
  MonetaryRegime,
} from '@/types/game';

import { INITIAL_PROPERTIES, INITIAL_BUSINESSES } from '@/lib/engine/boardData';
import { SCENARIOS } from '@/lib/engine/scenarios';
import { executeEconomicTurn } from '@/lib/engine/economy';
import { createTransaction } from '@/lib/engine/sats';

export default function GamePage() {
  // Scenario 1: Bitcoin Standard 2040 default
  const scenario = SCENARIOS[0];

  // Game Engine State
  const [economicState, setEconomicState] = useState<EconomicState>(scenario.initialEconomicState);

  const [players, setPlayers] = useState<Player[]>([
    {
      id: 'HUMAN',
      name: 'Rhino Investor',
      strategyType: 'HUMAN',
      walletBalanceSats: 25_000_000, // 0.25 BTC
      debtSats: 0,
      netWorthSats: 25_000_000,
      position: 0,
      color: '#F59E0B', // Amber
      avatar: '🦏',
      timePreference: 0.2,
      timePreferenceScore: 20, // Low time preference
      ltvRatioPercent: 0,
      incomeSats: 150_000,
      expensesSats: 20_000,
      isBankrupt: false,
      stats: {
        totalRentPaidSats: 0,
        totalRentEarnedSats: 0,
        totalInterestPaidSats: 0,
        totalInterestEarnedSats: 0,
        propertiesOwnedCount: 0,
        businessesOwnedCount: 0,
        miningHashRateTHs: 0,
        maxNetWorthSats: 25_000_000,
      },
    },
    {
      id: 'AI_SAVER',
      name: 'Hard Money Saver',
      strategyType: 'SAVER',
      walletBalanceSats: 25_000_000,
      debtSats: 0,
      netWorthSats: 25_000_000,
      position: 7,
      color: '#22C55E', // Emerald
      avatar: '🔒',
      timePreference: 0.1,
      timePreferenceScore: 10,
      ltvRatioPercent: 0,
      incomeSats: 100_000,
      expensesSats: 10_000,
      isBankrupt: false,
      stats: {
        totalRentPaidSats: 0,
        totalRentEarnedSats: 0,
        totalInterestPaidSats: 0,
        totalInterestEarnedSats: 0,
        propertiesOwnedCount: 0,
        businessesOwnedCount: 0,
        miningHashRateTHs: 0,
        maxNetWorthSats: 25_000_000,
      },
    },
    {
      id: 'AI_SPECULATOR',
      name: 'Leveraged Speculator',
      strategyType: 'SPECULATOR',
      walletBalanceSats: 25_000_000,
      debtSats: 15_000_000,
      netWorthSats: 25_000_000,
      position: 14,
      color: '#EF4444', // Red
      avatar: '🎰',
      timePreference: 0.9,
      timePreferenceScore: 90,
      ltvRatioPercent: 60,
      incomeSats: 200_000,
      expensesSats: 180_000,
      isBankrupt: false,
      stats: {
        totalRentPaidSats: 0,
        totalRentEarnedSats: 0,
        totalInterestPaidSats: 0,
        totalInterestEarnedSats: 0,
        propertiesOwnedCount: 0,
        businessesOwnedCount: 0,
        miningHashRateTHs: 0,
        maxNetWorthSats: 25_000_000,
      },
    },
    {
      id: 'AI_KING',
      name: 'Property King',
      strategyType: 'PROPERTY_KING',
      walletBalanceSats: 25_000_000,
      debtSats: 0,
      netWorthSats: 25_000_000,
      position: 21,
      color: '#38BDF8', // Sky
      avatar: '🏰',
      timePreference: 0.35,
      timePreferenceScore: 35,
      ltvRatioPercent: 0,
      incomeSats: 250_000,
      expensesSats: 50_000,
      isBankrupt: false,
      stats: {
        totalRentPaidSats: 0,
        totalRentEarnedSats: 0,
        totalInterestPaidSats: 0,
        totalInterestEarnedSats: 0,
        propertiesOwnedCount: 0,
        businessesOwnedCount: 0,
        miningHashRateTHs: 0,
        maxNetWorthSats: 25_000_000,
      },
    },
  ]);

  const [properties, setProperties] = useState<Property[]>(INITIAL_PROPERTIES);
  const [businesses, setBusinesses] = useState<Business[]>(INITIAL_BUSINESSES);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [miningFacility, setMiningFacility] = useState<MiningFacility>({
    id: 'MINING_HUMAN',
    ownerId: 'HUMAN',
    asicCount: 10,
    hashRateTHs: 1200,
    powerMW: 0.35,
    energyCostPerkWhSats: 450,
    efficiencyJoulePerTH: 21.5,
  });

  const [blockchain, setBlockchain] = useState<Block[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [timeline, setTimeline] = useState<GameTimelineEntry[]>([]);
  const [netWorthHistory, setNetWorthHistory] = useState<number[]>([25_000_000]);
  const [activeEvent, setActiveEvent] = useState<GameEvent | null>(null);

  // Auto play simulation state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const playIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Modals state
  const [selectedTileIndex, setSelectedTileIndex] = useState<number | null>(null);
  const [isCreditDeskOpen, setIsCreditDeskOpen] = useState<boolean>(false);
  const [isMarketOpen, setIsMarketOpen] = useState<boolean>(false);
  const [isMiningHubOpen, setIsMiningHubOpen] = useState<boolean>(false);
  const [isQuantLabOpen, setIsQuantLabOpen] = useState<boolean>(false);
  const [isBlockchainVisualizerOpen, setIsBlockchainVisualizerOpen] = useState<boolean>(false);
  const [isAcademyOpen, setIsAcademyOpen] = useState<boolean>(false);
  const [isMonetaryLabOpen, setIsMonetaryLabOpen] = useState<boolean>(false);
  const [isTimeMachineOpen, setIsTimeMachineOpen] = useState<boolean>(false);
  const [isEndReportOpen, setIsEndReportOpen] = useState<boolean>(false);

  const humanPlayer = players.find((p) => p.id === 'HUMAN')!;

  // Execute 1 Turn Engine
  const runTurn = () => {
    const output = executeEconomicTurn(
      economicState,
      players,
      properties,
      businesses,
      loans,
      [miningFacility],
      blockchain
    );

    setEconomicState(output.nextState);
    setPlayers(output.updatedPlayers);
    setProperties(output.updatedProperties);
    setBusinesses(output.updatedBusinesses);
    setLoans(output.updatedLoans);
    setTransactions((prev) => [...output.newTransactions, ...prev].slice(0, 50));
    setBlockchain((prev) => [...prev, output.newBlock]);
    setTimeline((prev) => [...prev, output.timelineEntry]);
    setActiveEvent(output.newEvent);

    const updatedHuman = output.updatedPlayers.find((p) => p.id === 'HUMAN')!;
    setNetWorthHistory((prev) => [...prev, updatedHuman.netWorthSats]);
  };

  // Auto-play timer
  useEffect(() => {
    if (isPlaying) {
      playIntervalRef.current = setInterval(() => {
        runTurn();
      }, 1500);
    } else if (playIntervalRef.current) {
      clearInterval(playIntervalRef.current);
    }
    return () => {
      if (playIntervalRef.current) clearInterval(playIntervalRef.current);
    };
  }, [isPlaying, economicState, players, properties, businesses, loans]);

  // Turn Actions
  const handleEndTurn = () => {
    runTurn();
  };

  const handleStepYear = () => {
    for (let i = 0; i < 12; i++) {
      runTurn();
    }
  };

  // Property & Business Purchases
  const handleBuyProperty = (propertyId: string) => {
    const prop = properties.find((p) => p.id === propertyId);
    if (!prop || humanPlayer.walletBalanceSats < prop.purchasePriceSats) return;

    setPlayers((prev) =>
      prev.map((p) =>
        p.id === 'HUMAN'
          ? {
              ...p,
              walletBalanceSats: p.walletBalanceSats - prop.purchasePriceSats,
              stats: { ...p.stats, propertiesOwnedCount: p.stats.propertiesOwnedCount + 1 },
            }
          : p
      )
    );

    setProperties((prev) =>
      prev.map((p) => (p.id === propertyId ? { ...p, ownerId: 'HUMAN' } : p))
    );

    const tx = createTransaction(
      economicState.turn,
      'HUMAN',
      'SYSTEM',
      prop.purchasePriceSats,
      `Acquired Property ${prop.name}`,
      'PROPERTY'
    );
    setTransactions((prev) => [tx, ...prev]);
  };

  const handleBuyBusiness = (businessId: string) => {
    const biz = businesses.find((b) => b.id === businessId);
    if (!biz || humanPlayer.walletBalanceSats < biz.purchasePriceSats) return;

    setPlayers((prev) =>
      prev.map((p) =>
        p.id === 'HUMAN'
          ? {
              ...p,
              walletBalanceSats: p.walletBalanceSats - biz.purchasePriceSats,
              stats: { ...p.stats, businessesOwnedCount: p.stats.businessesOwnedCount + 1 },
            }
          : p
      )
    );

    setBusinesses((prev) =>
      prev.map((b) => (b.id === businessId ? { ...b, ownerId: 'HUMAN' } : b))
    );

    const tx = createTransaction(
      economicState.turn,
      'HUMAN',
      'SYSTEM',
      biz.purchasePriceSats,
      `Acquired Business ${biz.name}`,
      'BUSINESS'
    );
    setTransactions((prev) => [tx, ...prev]);
  };

  const handleDevelopProperty = (propertyId: string) => {
    const prop = properties.find((p) => p.id === propertyId);
    if (!prop || humanPlayer.walletBalanceSats < prop.developmentCostSats) return;

    setPlayers((prev) =>
      prev.map((p) =>
        p.id === 'HUMAN'
          ? { ...p, walletBalanceSats: p.walletBalanceSats - prop.developmentCostSats }
          : p
      )
    );

    setProperties((prev) =>
      prev.map((p) =>
        p.id === propertyId
          ? {
              ...p,
              productivityBonus: p.productivityBonus + 0.3,
              developmentCostSats: Math.floor(p.developmentCostSats * 1.5),
            }
          : p
      )
    );
  };

  // Credit Desk Actions
  const handleTakeLoan = (amountSats: Satoshi, collateralPropId: string) => {
    const newLoan: Loan = {
      id: `LN_${Date.now().toString(36)}`,
      borrowerId: 'HUMAN',
      lenderId: 'SYSTEM',
      principalSats: amountSats,
      remainingPrincipalSats: amountSats,
      interestRateAnnual: economicState.interestRateAnnual,
      interestRateMonthly: parseFloat((economicState.interestRateAnnual / 12).toFixed(2)),
      collateralPropertyIds: [collateralPropId],
      termMonths: 36,
      monthsRemaining: 36,
      status: 'ACTIVE',
      createdTurn: economicState.turn,
    };

    setLoans((prev) => [...prev, newLoan]);

    setPlayers((prev) =>
      prev.map((p) =>
        p.id === 'HUMAN'
          ? {
              ...p,
              walletBalanceSats: p.walletBalanceSats + amountSats,
              debtSats: p.debtSats + amountSats,
            }
          : p
      )
    );

    setProperties((prev) =>
      prev.map((p) => (p.id === collateralPropId ? { ...p, isMortgaged: true } : p))
    );
  };

  const handleRepayLoan = (loanId: string, amountSats: Satoshi) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan || humanPlayer.walletBalanceSats < amountSats) return;

    setPlayers((prev) =>
      prev.map((p) =>
        p.id === 'HUMAN'
          ? {
              ...p,
              walletBalanceSats: p.walletBalanceSats - amountSats,
              debtSats: Math.max(0, p.debtSats - amountSats),
            }
          : p
      )
    );

    setLoans((prev) =>
      prev.map((l) =>
        l.id === loanId
          ? {
              ...l,
              remainingPrincipalSats: Math.max(0, l.remainingPrincipalSats - amountSats),
              status: l.remainingPrincipalSats - amountSats <= 0 ? 'PAID' : 'ACTIVE',
            }
          : l
      )
    );
  };

  // Mining Actions
  const handleBuyAsics = (count: number, costSats: Satoshi) => {
    if (humanPlayer.walletBalanceSats < costSats) return;

    setPlayers((prev) =>
      prev.map((p) =>
        p.id === 'HUMAN' ? { ...p, walletBalanceSats: p.walletBalanceSats - costSats } : p
      )
    );

    setMiningFacility((prev) => ({
      ...prev,
      asicCount: prev.asicCount + count,
      hashRateTHs: prev.hashRateTHs + count * 120,
      powerMW: prev.powerMW + count * 0.035,
    }));
  };

  // Monetary Regime Switcher
  const handleChangeRegime = (newRegime: MonetaryRegime) => {
    setEconomicState((prev) => ({ ...prev, monetaryRegime: newRegime }));
    setIsMonetaryLabOpen(false);
  };

  // Rewind Timeline
  const handleRewindToTurn = (targetTurn: number) => {
    const targetEntry = timeline.find((t) => t.turn === targetTurn);
    if (targetEntry) {
      setEconomicState(targetEntry.economicStateSnapshot);
      setTimeline((prev) => prev.filter((t) => t.turn <= targetTurn));
      setIsTimeMachineOpen(false);
    }
  };

  // Reset Game
  const handleResetGame = () => {
    setEconomicState(scenario.initialEconomicState);
    setProperties(INITIAL_PROPERTIES);
    setBusinesses(INITIAL_BUSINESSES);
    setLoans([]);
    setBlockchain([]);
    setTransactions([]);
    setTimeline([]);
    setNetWorthHistory([25_000_000]);
    setIsPlaying(false);
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0F1115] text-[#F5F2ED] overflow-hidden select-none font-sans">
      {/* TOP HEADER */}
      <Header
        economicState={economicState}
        isPlaying={isPlaying}
        onTogglePlay={() => setIsPlaying(!isPlaying)}
        onStepTurn={handleEndTurn}
        onStepYear={handleStepYear}
        onResetGame={handleResetGame}
        onOpenAcademy={() => setIsAcademyOpen(true)}
        onOpenQuantLab={() => setIsQuantLabOpen(true)}
        onOpenRegimeLab={() => setIsMonetaryLabOpen(true)}
        onOpenTimeMachine={() => setIsTimeMachineOpen(true)}
      />

      {/* MAIN CONTENT WORKSPACE */}
      <div className="flex-1 flex overflow-hidden">
        {/* LEFT COLUMN: PLAYER DOSSIER & FINANCIAL STATEMENTS */}
        <PlayerDossier
          humanPlayer={humanPlayer}
          properties={properties}
          businesses={businesses}
          activeLoans={loans}
          economicState={economicState}
        />

        {/* CENTER COLUMN: 28-TILE LIVING BOARD MAP */}
        <Board
          properties={properties}
          businesses={businesses}
          players={players}
          economicState={economicState}
          selectedTileIndex={selectedTileIndex}
          onSelectTile={(tileIdx) => {
            setSelectedTileIndex(tileIdx);
            setIsMarketOpen(true);
          }}
        />

        {/* RIGHT COLUMN: QUANT TERMINAL & AI AGENTS STATUS */}
        <QuantTerminal
          economicState={economicState}
          players={players}
          activeEvent={activeEvent}
          onOpenQuantLab={() => setIsQuantLabOpen(true)}
        />
      </div>

      {/* FOOTER ACTION BAR */}
      <Footer
        lastTransaction={transactions[0] || null}
        onEndTurn={handleEndTurn}
        onOpenMarket={() => setIsMarketOpen(true)}
        onOpenCreditDesk={() => setIsCreditDeskOpen(true)}
        onOpenMiningHub={() => setIsMiningHubOpen(true)}
        onOpenBlockchainVisualizer={() => setIsBlockchainVisualizerOpen(true)}
        isPlaying={isPlaying}
      />

      {/* INTERACTIVE FEATURE MODALS */}
      <CreditDeskModal
        isOpen={isCreditDeskOpen}
        onClose={() => setIsCreditDeskOpen(false)}
        humanPlayer={humanPlayer}
        properties={properties}
        activeLoans={loans}
        economicState={economicState}
        onTakeLoan={handleTakeLoan}
        onRepayLoan={handleRepayLoan}
      />

      <MarketModal
        isOpen={isMarketOpen}
        onClose={() => setIsMarketOpen(false)}
        humanPlayer={humanPlayer}
        properties={properties}
        businesses={businesses}
        economicState={economicState}
        onBuyProperty={handleBuyProperty}
        onBuyBusiness={handleBuyBusiness}
        onDevelopProperty={handleDevelopProperty}
      />

      <MiningModal
        isOpen={isMiningHubOpen}
        onClose={() => setIsMiningHubOpen(false)}
        humanPlayer={humanPlayer}
        miningFacility={miningFacility}
        economicState={economicState}
        onBuyAsics={handleBuyAsics}
      />

      <QuantLabModal
        isOpen={isQuantLabOpen}
        onClose={() => setIsQuantLabOpen(false)}
        humanPlayer={humanPlayer}
        economicState={economicState}
        netWorthHistory={netWorthHistory}
      />

      <BlockchainVisualizerModal
        isOpen={isBlockchainVisualizerOpen}
        onClose={() => setIsBlockchainVisualizerOpen(false)}
        blockchain={blockchain}
        latestTransactions={transactions}
      />

      <AcademyModal
        isOpen={isAcademyOpen}
        onClose={() => setIsAcademyOpen(false)}
      />

      <MonetaryLabModal
        isOpen={isMonetaryLabOpen}
        onClose={() => setIsMonetaryLabOpen(false)}
        currentRegime={economicState.monetaryRegime}
        onChangeRegime={handleChangeRegime}
      />

      <TimeMachineModal
        isOpen={isTimeMachineOpen}
        onClose={() => setIsTimeMachineOpen(false)}
        timeline={timeline}
        onRewindToTurn={handleRewindToTurn}
      />

      <EndReportModal
        isOpen={isEndReportOpen}
        onClose={() => setIsEndReportOpen(false)}
        humanPlayer={humanPlayer}
        economicState={economicState}
      />
    </div>
  );
}
