import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Monopoly: Bitcoin Standard',
  description: 'A quantitative economic strategy game of property, money, time preference, credit & economic survival under a Bitcoin standard.',
  openGraph: {
    title: 'Monopoly: Bitcoin Standard',
    description: 'A quantitative economic strategy game of property, money, time preference, credit & economic survival under a Bitcoin standard.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Monopoly: Bitcoin Standard',
    description: 'A quantitative economic strategy game of property, money, time preference, credit & economic survival under a Bitcoin standard.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
