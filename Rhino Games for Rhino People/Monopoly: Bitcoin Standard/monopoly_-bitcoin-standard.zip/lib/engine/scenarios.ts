import { GameConfig, EconomicState } from '@/types/game';

export interface ScenarioDefinition {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  config: GameConfig;
  initialEconomicState: EconomicState;
}

export const SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'scen_btc_standard',
    name: 'Bitcoin Standard 2040',
    subtitle: 'Fixed Hard Money Base Economy',
    description: 'RhinoCity operates under a strict 21,000,000 BTC hard money regime. Productivity growth drives structural price deflation in BTC terms.',
    config: {
      startingBtcPerPlayerSats: 25_000_000, // 0.25 BTC
      totalBtcSupplySats: 2_100_000_000_000_000,
      victoryPhilosophy: 'ACCUMULATOR',
      targetHorizonYears: 10,
      monetaryRegime: 'BITCOIN_STANDARD',
      seed: 'RHINO_BTC_2040',
      difficulty: 'INTERMEDIATE',
    },
    initialEconomicState: {
      turn: 1,
      month: 1,
      year: 1,
      gdpSats: 14_280_000_000, // ~142.8 BTC monthly GDP
      btcSupplySats: 2_100_000_000_000_000,
      btcVelocity: 1.2,
      btcPriceFiatGBP: 100_000,
      priceIndexCPI: 100.0,
      wagesSats: 450_000,
      employmentRate: 95.2,
      interestRateAnnual: 4.2,
      creditSupplySats: 500_000_000,
      creditDemandSats: 420_000_000,
      defaultRatePercent: 1.1,
      propertyIndex: 100.0,
      energyPriceSatsPerkWh: 450,
      industrialOutputIndex: 100.0,
      fiatInflationRateAnnual: 2.5,
      monetaryRegime: 'BITCOIN_STANDARD',
    },
  },
  {
    id: 'scen_fiat_comparison',
    name: 'Fiat Standard Comparison',
    subtitle: 'Elastic Central Bank Expansion',
    description: 'Compare how the exact same RhinoCity economy performs under elastic money printing and fiat debasement.',
    config: {
      startingBtcPerPlayerSats: 25_000_000,
      totalBtcSupplySats: 2_100_000_000_000_000,
      victoryPhilosophy: 'CAPITALIST',
      targetHorizonYears: 10,
      monetaryRegime: 'FIAT_STANDARD',
      seed: 'RHINO_FIAT_2040',
      difficulty: 'INTERMEDIATE',
    },
    initialEconomicState: {
      turn: 1,
      month: 1,
      year: 1,
      gdpSats: 14_280_000_000,
      btcSupplySats: 2_100_000_000_000_000,
      btcVelocity: 2.1,
      btcPriceFiatGBP: 100_000,
      priceIndexCPI: 100.0,
      wagesSats: 450_000,
      employmentRate: 92.0,
      interestRateAnnual: 7.5,
      creditSupplySats: 1_200_000_000,
      creditDemandSats: 1_500_000_000,
      defaultRatePercent: 3.8,
      propertyIndex: 100.0,
      energyPriceSatsPerkWh: 620,
      industrialOutputIndex: 98.0,
      fiatInflationRateAnnual: 8.5,
      monetaryRegime: 'FIAT_STANDARD',
    },
  },
  {
    id: 'scen_energy_crisis',
    name: 'Energy Shock & Industrial Crisis',
    subtitle: 'High Power Cost Survival',
    description: 'Electricity costs spike 3x. Industrial factories and Bitcoin miners face severe margin compression.',
    config: {
      startingBtcPerPlayerSats: 35_000_000,
      totalBtcSupplySats: 2_100_000_000_000_000,
      victoryPhilosophy: 'SURVIVOR',
      targetHorizonYears: 5,
      monetaryRegime: 'BITCOIN_STANDARD',
      seed: 'RHINO_ENERGY_CRISIS',
      difficulty: 'ADVANCED',
    },
    initialEconomicState: {
      turn: 1,
      month: 1,
      year: 1,
      gdpSats: 12_000_000_000,
      btcSupplySats: 2_100_000_000_000_000,
      btcVelocity: 1.0,
      btcPriceFiatGBP: 110_000,
      priceIndexCPI: 115.0,
      wagesSats: 400_000,
      employmentRate: 88.5,
      interestRateAnnual: 6.8,
      creditSupplySats: 300_000_000,
      creditDemandSats: 600_000_000,
      defaultRatePercent: 4.5,
      propertyIndex: 88.0,
      energyPriceSatsPerkWh: 1_350, // High power cost
      industrialOutputIndex: 82.0,
      fiatInflationRateAnnual: 4.2,
      monetaryRegime: 'BITCOIN_STANDARD',
    },
  },
];
