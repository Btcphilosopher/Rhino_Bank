import { Player, Property, Business, Loan, EconomicState, Satoshi } from '@/types/game';

export interface AIDecisionResult {
  actionType: 'BUY_PROPERTY' | 'BUY_BUSINESS' | 'DEVELOP_PROPERTY' | 'REPAY_DEBT' | 'TAKE_LOAN' | 'MORTGAGE_PROPERTY' | 'HOLD';
  targetPropertyId?: string;
  targetBusinessId?: string;
  loanAmountSats?: Satoshi;
  reason: string;
}

/**
 * Evaluate AI Player decision at turn start/end
 */
export function evaluateAIDecision(
  aiPlayer: Player,
  availableProperties: Property[],
  availableBusinesses: Business[],
  activeLoans: Loan[],
  economicState: EconomicState
): AIDecisionResult {
  if (aiPlayer.isBankrupt) {
    return { actionType: 'HOLD', reason: 'Player is insolvent' };
  }

  const wallet = aiPlayer.walletBalanceSats;
  const debt = aiPlayer.debtSats;
  const strategy = aiPlayer.strategyType;

  // 1. Debt Service Emergency Check: If debt service LTV > 75%, prioritize debt repayment or holding
  if (aiPlayer.ltvRatioPercent > 75 && debt > 0 && wallet > 500_000) {
    const repayAmt = Math.min(wallet * 0.5, debt);
    return {
      actionType: 'REPAY_DEBT',
      loanAmountSats: Math.floor(repayAmt),
      reason: `High LTV risk (${aiPlayer.ltvRatioPercent.toFixed(1)}%). Paying down debt to avoid liquidation.`,
    };
  }

  // 2. Strategy Specific Evaluations
  switch (strategy) {
    case 'SAVER': {
      // Saver requires high liquidity reserve (keeps at least 60% of wallet)
      const liquidCapital = wallet * 0.4;
      const goodProperty = availableProperties.find(
        (p) => p.purchasePriceSats <= liquidCapital && p.yieldPercent >= 6.8
      );
      if (goodProperty) {
        return {
          actionType: 'BUY_PROPERTY',
          targetPropertyId: goodProperty.id,
          reason: `High yield (${goodProperty.yieldPercent}%) property matching conservative criteria.`,
        };
      }
      return { actionType: 'HOLD', reason: 'Accumulating BTC savings reserve.' };
    }

    case 'SPECULATOR': {
      // Speculator aggressively uses leverage if LTV < 60%
      const cheapProperty = availableProperties.find((p) => p.purchasePriceSats <= wallet * 1.2);
      if (cheapProperty && cheapProperty.purchasePriceSats > wallet && aiPlayer.ltvRatioPercent < 60) {
        const neededLoan = cheapProperty.purchasePriceSats - wallet + 500_000;
        return {
          actionType: 'TAKE_LOAN',
          loanAmountSats: Math.floor(neededLoan),
          reason: `Speculative expansion: leveraging credit market for ${cheapProperty.name}.`,
        };
      }
      if (cheapProperty && cheapProperty.purchasePriceSats <= wallet) {
        return {
          actionType: 'BUY_PROPERTY',
          targetPropertyId: cheapProperty.id,
          reason: `Speculative acquisition of ${cheapProperty.name}.`,
        };
      }
      return { actionType: 'HOLD', reason: 'Scanning for market arbitrage opportunities.' };
    }

    case 'PROPERTY_KING': {
      // Property King looks for unowned properties or property upgrades
      const buyableProperty = availableProperties.find((p) => p.purchasePriceSats <= wallet * 0.8);
      if (buyableProperty) {
        return {
          actionType: 'BUY_PROPERTY',
          targetPropertyId: buyableProperty.id,
          reason: `Expanding land portfolio with ${buyableProperty.name}.`,
        };
      }
      return { actionType: 'HOLD', reason: 'Consolidating land holdings.' };
    }

    case 'INDUSTRIALIST': {
      // Industrialist prioritizes productive businesses & energy
      const buyableBiz = availableBusinesses.find((b) => b.purchasePriceSats <= wallet * 0.75);
      if (buyableBiz) {
        return {
          actionType: 'BUY_BUSINESS',
          targetBusinessId: buyableBiz.id,
          reason: `Acquiring productive business ${buyableBiz.name} to boost capital output.`,
        };
      }
      const industrialProperty = availableProperties.find(
        (p) => (p.district === 'INDUSTRIAL' || p.district === 'UTILITIES') && p.purchasePriceSats <= wallet * 0.8
      );
      if (industrialProperty) {
        return {
          actionType: 'BUY_PROPERTY',
          targetPropertyId: industrialProperty.id,
          reason: `Securing industrial infrastructure at ${industrialProperty.name}.`,
        };
      }
      return { actionType: 'HOLD', reason: 'Reinvesting cash flows into capital goods.' };
    }

    case 'HODLER': {
      // HODLER holds maximum BTC, buys only distressed properties below market value
      const undervalued = availableProperties.find(
        (p) => p.purchasePriceSats <= wallet * 0.25 && p.yieldPercent >= 7.5
      );
      if (undervalued) {
        return {
          actionType: 'BUY_PROPERTY',
          targetPropertyId: undervalued.id,
          reason: `Opportunistic purchase of undervalued asset ${undervalued.name}.`,
        };
      }
      return { actionType: 'HOLD', reason: 'HODLing BTC base money.' };
    }

    case 'BANKER': {
      // Banker accumulates BTC and provides liquidity
      if (wallet > 10_000_000 && debt > 0) {
        return {
          actionType: 'REPAY_DEBT',
          loanAmountSats: Math.floor(debt * 0.5),
          reason: 'Maintaining bank capital balance sheet strength.',
        };
      }
      const highYieldProp = availableProperties.find((p) => p.purchasePriceSats <= wallet * 0.5);
      if (highYieldProp) {
        return {
          actionType: 'BUY_PROPERTY',
          targetPropertyId: highYieldProp.id,
          reason: `Acquiring mortgage collateral backing asset ${highYieldProp.name}.`,
        };
      }
      return { actionType: 'HOLD', reason: 'Underwriting credit desk liquidity.' };
    }

    default:
      return { actionType: 'HOLD', reason: 'Evaluating macroeconomic conditions.' };
  }
}
