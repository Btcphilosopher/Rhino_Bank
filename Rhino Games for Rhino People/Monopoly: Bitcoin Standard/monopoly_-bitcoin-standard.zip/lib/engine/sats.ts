import { Satoshi, Transaction, AssetType } from '@/types/game';

export const SATS_PER_BTC = 100_000_000;

/**
 * Format satoshis to BTC string with 8 decimal places
 * e.g. 25000000 -> "0.25000000"
 */
export function satsToBtcString(sats: Satoshi, showUnit = true): string {
  const safeSats = Math.max(0, Math.floor(sats));
  const btcValue = (safeSats / SATS_PER_BTC).toFixed(8);
  return showUnit ? `${btcValue} BTC` : btcValue;
}

/**
 * Format satoshis with commas
 * e.g. 25000000 -> "25,000,000 sats"
 */
export function formatSats(sats: Satoshi, showUnit = true): string {
  const safeSats = Math.floor(sats);
  const formatted = new Intl.NumberFormat('en-US').format(safeSats);
  return showUnit ? `${formatted} sats` : formatted;
}

/**
 * Convert satoshis to fiat value GBP
 * e.g. 25,000,000 sats @ £100,000/BTC = 0.25 * 100000 = £25,000
 */
export function satsToFiatString(sats: Satoshi, btcPriceFiatGBP: number): string {
  const btcAmount = sats / SATS_PER_BTC;
  const fiatVal = btcAmount * btcPriceFiatGBP;
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    maximumFractionDigits: 0,
  }).format(fiatVal);
}

/**
 * Calculate Property Yield %
 * Yield = (Annual Rent / Market Value) * 100
 */
export function calculatePropertyYield(annualRentSats: Satoshi, marketValueSats: Satoshi): number {
  if (marketValueSats <= 0) return 0;
  return parseFloat(((annualRentSats / marketValueSats) * 100).toFixed(2));
}

/**
 * Create a validated Ledger Transaction object
 */
export function createTransaction(
  turn: number,
  senderId: string,
  receiverId: string,
  amountSats: Satoshi,
  reason: string,
  assetType: AssetType,
  feeSats: Satoshi = 0
): Transaction {
  const cleanAmount = Math.floor(Math.max(0, amountSats));
  const cleanFee = Math.floor(Math.max(0, feeSats));
  const hash = Math.random().toString(36).substring(2, 10).toUpperCase();

  return {
    transaction_id: `TX_${turn}_${hash}`,
    timestamp: new Date().toISOString(),
    turn,
    senderId,
    receiverId,
    amount_sats: cleanAmount,
    fee_sats: cleanFee,
    reason,
    asset_type: assetType,
  };
}

/**
 * Verify Monetary Conservation Invariant
 * Total Player Wallets + System Reserve == Total Money Supply
 */
export function verifyMonetaryInvariant(
  playerBalances: Satoshi[],
  systemReserveSats: Satoshi,
  totalMoneySupplySats: Satoshi
): { isConserved: boolean; deltaSats: number } {
  const sumBalances = playerBalances.reduce((acc, curr) => acc + Math.floor(curr), 0);
  const totalInCirculation = sumBalances + Math.floor(systemReserveSats);
  const delta = totalInCirculation - Math.floor(totalMoneySupplySats);

  return {
    isConserved: delta === 0,
    deltaSats: delta,
  };
}
