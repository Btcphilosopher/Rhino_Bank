import {
  Player,
  Property,
  Business,
  Loan,
  EconomicState,
  Transaction,
  Block,
  GameEvent,
  GameTimelineEntry,
  MiningFacility,
  Satoshi,
  MonetaryRegime,
} from '@/types/game';
import { createTransaction, verifyMonetaryInvariant, SATS_PER_BTC } from './sats';
import { evaluateAIDecision } from './ai';
import { RHINOCITY_TILES } from './boardData';

export interface TurnExecutionOutput {
  nextState: EconomicState;
  updatedPlayers: Player[];
  updatedProperties: Property[];
  updatedBusinesses: Business[];
  updatedLoans: Loan[];
  newTransactions: Transaction[];
  newBlock: Block;
  newEvent: GameEvent | null;
  timelineEntry: GameTimelineEntry;
  invariantStatus: { isConserved: boolean; deltaSats: number };
}

/**
 * Executes a full 1-month turn of the RhinoCity economy
 */
export function executeEconomicTurn(
  currentState: EconomicState,
  players: Player[],
  properties: Property[],
  businesses: Business[],
  loans: Loan[],
  miningFacilities: MiningFacility[],
  blockchain: Block[],
  seed = '2040-RHINO'
): TurnExecutionOutput {
  const nextTurn = currentState.turn + 1;
  const nextMonth = ((nextTurn - 1) % 12) + 1;
  const nextYear = Math.floor((nextTurn - 1) / 12) + 1;

  const newTransactions: Transaction[] = [];
  const updatedPlayers = players.map((p) => ({ ...p }));
  const updatedProperties = properties.map((p) => ({ ...p }));
  const updatedBusinesses = businesses.map((b) => ({ ...b }));
  let updatedLoans = loans.map((l) => ({ ...l }));

  // Helper map for quick player mutation
  const playerMap = new Map<string, Player>(updatedPlayers.map((p) => [p.id, p]));

  // 1. MACROECONOMIC ENGINE CALCULATIONS
  const regime = currentState.monetaryRegime;
  let productivityMultiplier = 1.002; // +0.2% monthly productivity baseline
  let populationGrowth = 1.001; // +0.1% monthly population

  // Regime specific monetary dynamics
  let newBtcSupply = currentState.btcSupplySats;
  let newBtcPriceFiat = currentState.btcPriceFiatGBP;
  let newCpiIndex = currentState.priceIndexCPI;
  let newFiatInflation = currentState.fiatInflationRateAnnual;

  if (regime === 'BITCOIN_STANDARD') {
    // Fixed supply hard money: Productivity growth increases goods supply, pushing BTC prices down (structural deflation)
    newBtcPriceFiat = Math.round(currentState.btcPriceFiatGBP * 1.006); // Fiat depreciates vs BTC
    newCpiIndex = parseFloat((currentState.priceIndexCPI * 0.998).toFixed(2)); // Prices fall in BTC terms
    newFiatInflation = 2.4;
  } else if (regime === 'FIAT_STANDARD') {
    // Elastic fiat money: currency expansion inflates CPI
    newCpiIndex = parseFloat((currentState.priceIndexCPI * 1.005).toFixed(2));
    newBtcPriceFiat = Math.round(currentState.btcPriceFiatGBP * 1.002);
    newFiatInflation = 6.0;
  }

  // Halving check every 48 months (4 years)
  if (nextTurn % 48 === 0) {
    newBtcPriceFiat = Math.round(newBtcPriceFiat * 1.25); // Supply shock repricing
  }

  const newGdp = Math.floor(currentState.gdpSats * productivityMultiplier * populationGrowth);
  const newInterestRate = parseFloat(
    (currentState.interestRateAnnual + (Math.random() * 0.2 - 0.1)).toFixed(2)
  );

  // 2. PROCESS PROPERTIES & RENTS
  updatedProperties.forEach((prop) => {
    // Dynamic Market Value Adjustment based on district GDP & interest rates
    const districtDemand = prop.district === 'COMMERCIAL' || prop.district === 'INDUSTRIAL' ? 1.003 : 1.001;
    prop.marketValueSats = Math.floor(prop.marketValueSats * districtDemand);

    // Calculate rent collected if owned
    if (prop.ownerId && !prop.isMortgaged) {
      const owner = playerMap.get(prop.ownerId);
      if (owner) {
        const grossRent = Math.floor(prop.baseRentSats * (prop.occupancyRate / 100) * prop.productivityBonus);
        const maintenance = Math.floor(prop.maintenanceCostSats);
        const netRent = grossRent - maintenance;

        if (netRent > 0) {
          owner.walletBalanceSats += netRent;
          owner.stats.totalRentEarnedSats += netRent;
          owner.incomeSats += netRent;

          const tx = createTransaction(
            nextTurn,
            'SYSTEM',
            owner.id,
            netRent,
            `Rental income from ${prop.name}`,
            'RENT'
          );
          newTransactions.push(tx);
        }
      }
    }

    // Update yield
    prop.yieldPercent = parseFloat(
      (((prop.baseRentSats * 12) / Math.max(1, prop.marketValueSats)) * 100).toFixed(2)
    );
  });

  // 3. PROCESS BUSINESSES
  updatedBusinesses.forEach((biz) => {
    if (biz.ownerId) {
      const owner = playerMap.get(biz.ownerId);
      if (owner) {
        const grossRevenue = Math.floor(biz.monthlyRevenueSats * biz.productivityFactor);
        const operatingExpenses = Math.floor(biz.operatingCostSats);
        const netProfit = grossRevenue - operatingExpenses;

        if (netProfit > 0) {
          owner.walletBalanceSats += netProfit;
          owner.incomeSats += netProfit;

          const tx = createTransaction(
            nextTurn,
            'SYSTEM',
            owner.id,
            netProfit,
            `Business profit from ${biz.name}`,
            'BUSINESS'
          );
          newTransactions.push(tx);
        } else if (netProfit < 0) {
          const loss = Math.abs(netProfit);
          const payment = Math.min(owner.walletBalanceSats, loss);
          owner.walletBalanceSats -= payment;
          owner.expensesSats += payment;
        }
      }
    }
  });

  // 4. PROCESS CREDIT MARKET & LOANS
  updatedLoans.forEach((loan) => {
    if (loan.status === 'ACTIVE') {
      const borrower = playerMap.get(loan.borrowerId);
      const lender = playerMap.get(loan.lenderId);

      const monthlyInterest = Math.floor(loan.remainingPrincipalSats * (loan.interestRateMonthly / 100));
      const monthlyPrincipalRepayment = Math.floor(loan.principalSats / loan.termMonths);
      const totalMonthlyPayment = monthlyInterest + monthlyPrincipalRepayment;

      if (borrower && borrower.walletBalanceSats >= totalMonthlyPayment) {
        borrower.walletBalanceSats -= totalMonthlyPayment;
        borrower.debtSats = Math.max(0, borrower.debtSats - monthlyPrincipalRepayment);
        borrower.stats.totalInterestPaidSats += monthlyInterest;
        borrower.expensesSats += totalMonthlyPayment;

        loan.remainingPrincipalSats = Math.max(0, loan.remainingPrincipalSats - monthlyPrincipalRepayment);
        loan.monthsRemaining -= 1;

        if (lender && lender.id !== 'SYSTEM') {
          lender.walletBalanceSats += totalMonthlyPayment;
          lender.stats.totalInterestEarnedSats += monthlyInterest;
          lender.incomeSats += totalMonthlyPayment;
        }

        const tx = createTransaction(
          nextTurn,
          borrower.id,
          lender ? lender.id : 'SYSTEM',
          totalMonthlyPayment,
          `Debt service payment on Loan #${loan.id.substring(0, 6)}`,
          'REPAYMENT'
        );
        newTransactions.push(tx);

        if (loan.remainingPrincipalSats <= 0 || loan.monthsRemaining <= 0) {
          loan.status = 'PAID';
        }
      } else if (borrower) {
        // Default or Liquidation warning!
        loan.status = 'DEFAULTED';
        borrower.ltvRatioPercent = Math.min(100, borrower.ltvRatioPercent + 15);

        // Collateral liquidation if borrower insolvent
        if (loan.collateralPropertyIds.length > 0) {
          const collateralProp = updatedProperties.find((p) => p.id === loan.collateralPropertyIds[0]);
          if (collateralProp) {
            collateralProp.ownerId = lender ? lender.id : null;
            collateralProp.isMortgaged = false;
            loan.status = 'LIQUIDATED';

            const tx = createTransaction(
              nextTurn,
              borrower.id,
              lender ? lender.id : 'SYSTEM',
              collateralProp.marketValueSats,
              `Collateral liquidation of ${collateralProp.name}`,
              'PROPERTY'
            );
            newTransactions.push(tx);
          }
        }
      }
    }
  });

  // Filter out paid/liquidated loans for active tracking
  updatedLoans = updatedLoans.filter((l) => l.status === 'ACTIVE');

  // 5. RUN AI PLAYER ACTIONS
  const unownedProperties = updatedProperties.filter((p) => p.ownerId === null);
  const unownedBusinesses = updatedBusinesses.filter((b) => b.ownerId === null);

  updatedPlayers.forEach((p) => {
    if (p.strategyType !== 'HUMAN' && !p.isBankrupt) {
      const decision = evaluateAIDecision(
        p,
        unownedProperties,
        unownedBusinesses,
        updatedLoans,
        currentState
      );

      if (decision.actionType === 'BUY_PROPERTY' && decision.targetPropertyId) {
        const prop = updatedProperties.find((pItem) => pItem.id === decision.targetPropertyId);
        if (prop && prop.ownerId === null && p.walletBalanceSats >= prop.purchasePriceSats) {
          p.walletBalanceSats -= prop.purchasePriceSats;
          prop.ownerId = p.id;
          p.stats.propertiesOwnedCount += 1;

          const tx = createTransaction(
            nextTurn,
            p.id,
            'SYSTEM',
            prop.purchasePriceSats,
            `Acquired property ${prop.name}`,
            'PROPERTY'
          );
          newTransactions.push(tx);
        }
      } else if (decision.actionType === 'BUY_BUSINESS' && decision.targetBusinessId) {
        const biz = updatedBusinesses.find((bItem) => bItem.id === decision.targetBusinessId);
        if (biz && biz.ownerId === null && p.walletBalanceSats >= biz.purchasePriceSats) {
          p.walletBalanceSats -= biz.purchasePriceSats;
          biz.ownerId = p.id;
          p.stats.businessesOwnedCount += 1;

          const tx = createTransaction(
            nextTurn,
            p.id,
            'SYSTEM',
            biz.purchasePriceSats,
            `Acquired business ${biz.name}`,
            'BUSINESS'
          );
          newTransactions.push(tx);
        }
      } else if (decision.actionType === 'REPAY_DEBT' && decision.loanAmountSats) {
        const repayAmt = Math.min(p.walletBalanceSats, decision.loanAmountSats);
        p.walletBalanceSats -= repayAmt;
        p.debtSats = Math.max(0, p.debtSats - repayAmt);

        const tx = createTransaction(
          nextTurn,
          p.id,
          'SYSTEM',
          repayAmt,
          `Voluntary debt paydown`,
          'REPAYMENT'
        );
        newTransactions.push(tx);
      }
    }
  });

  // 6. UPDATE PLAYER METRICS & NET WORTH
  updatedPlayers.forEach((p) => {
    const ownedPropsValue = updatedProperties
      .filter((prop) => prop.ownerId === p.id)
      .reduce((sum, prop) => sum + prop.marketValueSats, 0);

    const ownedBizValue = updatedBusinesses
      .filter((biz) => biz.ownerId === p.id)
      .reduce((sum, biz) => sum + biz.purchasePriceSats, 0);

    p.netWorthSats = p.walletBalanceSats + ownedPropsValue + ownedBizValue - p.debtSats;

    if (ownedPropsValue + ownedBizValue > 0) {
      p.ltvRatioPercent = parseFloat(
        ((p.debtSats / (ownedPropsValue + ownedBizValue)) * 100).toFixed(1)
      );
    } else {
      p.ltvRatioPercent = p.debtSats > 0 ? 100 : 0;
    }

    if (p.netWorthSats < -1_000_000) {
      p.isBankrupt = true;
    }
  });

  // 7. RANDOM ECONOMIC EVENT GENERATOR
  let newEvent: GameEvent | null = null;
  const eventRoll = Math.random();

  if (eventRoll < 0.15) {
    // 15% chance of event per month
    const events: GameEvent[] = [
      {
        id: `EV_${nextTurn}_BOOM`,
        turn: nextTurn,
        title: 'Industrial Productivity Surge',
        description: 'New manufacturing automation increases factory yields across RhinoCity by +15%.',
        category: 'BOOM',
        severity: 2,
        durationMonths: 3,
        economicEffect: 'Industrial output +15%, GDP +4%',
      },
      {
        id: `EV_${nextTurn}_ENERGY`,
        turn: nextTurn,
        title: 'Energy Supply Bottleneck',
        description: 'Grid maintenance spikes electricity rates, temporarily increasing factory operating costs.',
        category: 'ENERGY_SHOCK',
        severity: 3,
        durationMonths: 2,
        economicEffect: 'Power costs +25%, Business margins -10%',
      },
      {
        id: `EV_${nextTurn}_HOUSING`,
        turn: nextTurn,
        title: 'RhinoCity Demographic Inflow',
        description: 'Tech worker migration drives housing scarcity and increases rental occupancy to 98%.',
        category: 'HOUSING_SHORTAGE',
        severity: 2,
        durationMonths: 4,
        economicEffect: 'Residential rents +12%, Property values +8%',
      },
    ];
    newEvent = events[Math.floor(Math.random() * events.length)];
  }

  // 8. BLOCKCHAIN BLOCK GENERATION
  const newBlock: Block = {
    blockHeight: 842_910 + nextTurn,
    hash: `00000000000000${Math.random().toString(16).substring(2, 14)}`,
    timestamp: new Date().toISOString(),
    transactions: newTransactions,
    totalFeesSats: newTransactions.reduce((sum, tx) => sum + tx.fee_sats, 0),
    minerId: 'Satoshi Hash Power Co',
    sizeBytes: Math.floor(100_000 + newTransactions.length * 500),
  };

  // 9. NEXT ECONOMIC STATE
  const nextState: EconomicState = {
    ...currentState,
    turn: nextTurn,
    month: nextMonth,
    year: nextYear,
    gdpSats: newGdp,
    btcSupplySats: newBtcSupply,
    btcPriceFiatGBP: newBtcPriceFiat,
    priceIndexCPI: newCpiIndex,
    interestRateAnnual: newInterestRate,
    fiatInflationRateAnnual: newFiatInflation,
  };

  // 10. RECONCILE INVARIANT CHECK
  const playerBalances = updatedPlayers.map((p) => p.walletBalanceSats);
  const invariantStatus = verifyMonetaryInvariant(
    playerBalances,
    100_000_000_000, // System Reserve pool
    currentState.btcSupplySats
  );

  // 11. TIMELINE ENTRY
  const netWorths: Record<string, number> = {};
  const playerBalancesSummary: Record<string, { btcSats: Satoshi; netWorthSats: Satoshi; debtSats: Satoshi }> = {};

  updatedPlayers.forEach((p) => {
    netWorths[p.id] = p.netWorthSats;
    playerBalancesSummary[p.id] = {
      btcSats: p.walletBalanceSats,
      netWorthSats: p.netWorthSats,
      debtSats: p.debtSats,
    };
  });

  const timelineEntry: GameTimelineEntry = {
    turn: nextTurn,
    month: nextMonth,
    year: nextYear,
    actionDescription: `Turn ${nextTurn} completed (Month ${nextMonth}, Year ${nextYear})`,
    economicStateSnapshot: nextState,
    playerBalances: playerBalancesSummary,
    eventsTriggered: newEvent ? [newEvent.title] : [],
  };

  return {
    nextState,
    updatedPlayers,
    updatedProperties,
    updatedBusinesses,
    updatedLoans,
    newTransactions,
    newBlock,
    newEvent,
    timelineEntry,
    invariantStatus,
  };
}
