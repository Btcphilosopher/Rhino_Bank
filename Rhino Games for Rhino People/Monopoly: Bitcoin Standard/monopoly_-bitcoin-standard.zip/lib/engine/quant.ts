import { Satoshi, MonteCarloScenario, EconomicState, Player } from '@/types/game';

/**
 * Calculate Annualized Return (CAGR)
 */
export function calculateCAGR(initialSats: Satoshi, currentSats: Satoshi, monthsElapsed: number): number {
  if (initialSats <= 0 || monthsElapsed <= 0) return 0;
  const years = monthsElapsed / 12;
  const ratio = currentSats / initialSats;
  const cagr = (Math.pow(ratio, 1 / years) - 1) * 100;
  return isFinite(cagr) ? parseFloat(cagr.toFixed(2)) : 0;
}

/**
 * Calculate Maximum Drawdown from monthly net worth series
 */
export function calculateMaxDrawdown(netWorthSeries: number[]): number {
  if (netWorthSeries.length < 2) return 0;
  let peak = netWorthSeries[0];
  let maxDrawdown = 0;

  for (const val of netWorthSeries) {
    if (val > peak) peak = val;
    const drawdown = (peak - val) / peak;
    if (drawdown > maxDrawdown) maxDrawdown = drawdown;
  }

  return parseFloat((maxDrawdown * 100).toFixed(2));
}

/**
 * Calculate Sharpe Ratio
 */
export function calculateSharpeRatio(returnsSeries: number[], riskFreeRateAnnual = 0.02): number {
  if (returnsSeries.length < 3) return 0;
  const meanMonthlyReturn = returnsSeries.reduce((a, b) => a + b, 0) / returnsSeries.length;
  const riskFreeMonthly = riskFreeRateAnnual / 12;
  const excessReturn = meanMonthlyReturn - riskFreeMonthly;

  const variance = returnsSeries.reduce((acc, r) => acc + Math.pow(r - meanMonthlyReturn, 2), 0) / returnsSeries.length;
  const stdDev = Math.sqrt(variance);

  if (stdDev === 0) return 0;
  const annualizedSharpe = (excessReturn / stdDev) * Math.sqrt(12);
  return isFinite(annualizedSharpe) ? parseFloat(annualizedSharpe.toFixed(2)) : 0;
}

/**
 * Run Monte Carlo Scenario Generator
 * Simulates statistical wealth distribution over horizon months
 */
export function runMonteCarloSimulation(
  startingNetWorthSats: Satoshi,
  horizonMonths: number,
  expectedMonthlyGrowth = 0.008,
  monthlyVolatility = 0.035,
  simulationsCount = 500
): MonteCarloScenario {
  const allPaths: number[][] = [];

  for (let s = 0; s < simulationsCount; s++) {
    const path: number[] = [startingNetWorthSats];
    let current = startingNetWorthSats;

    for (let m = 1; m <= horizonMonths; m++) {
      // Box-Muller normal distribution random draw
      const u1 = Math.random();
      const u2 = Math.random();
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      
      const monthlyReturn = expectedMonthlyGrowth + z * monthlyVolatility;
      current = Math.max(100, current * (1 + monthlyReturn));
      path.push(Math.floor(current));
    }
    allPaths.push(path);
  }

  // Extract percentiles for each month
  const percentile5: number[] = [];
  const percentile25: number[] = [];
  const median: number[] = [];
  const percentile75: number[] = [];
  const percentile95: number[] = [];

  for (let m = 0; m <= horizonMonths; m++) {
    const valuesAtMonth = allPaths.map((p) => p[m]).sort((a, b) => a - b);
    percentile5.push(valuesAtMonth[Math.floor(simulationsCount * 0.05)]);
    percentile25.push(valuesAtMonth[Math.floor(simulationsCount * 0.25)]);
    median.push(valuesAtMonth[Math.floor(simulationsCount * 0.50)]);
    percentile75.push(valuesAtMonth[Math.floor(simulationsCount * 0.75)]);
    percentile95.push(valuesAtMonth[Math.floor(simulationsCount * 0.95)]);
  }

  return {
    seed: `MC_${Date.now()}`,
    simulationsCount,
    horizonMonths,
    percentile5,
    percentile25,
    median,
    percentile75,
    percentile95,
  };
}

/**
 * Calculate RhinoQuant Score
 * Composite economic metric combining Net Worth, Liquidity, Return, Low Leverage & Resilience
 */
export function calculateRhinoQuantScore(
  player: Player,
  startingSats: Satoshi,
  monthsElapsed: number
): {
  totalScore: number;
  wealthScore: number;
  liquidityScore: number;
  leverageScore: number;
  returnScore: number;
  resilienceScore: number;
} {
  const cagr = calculateCAGR(startingSats, player.netWorthSats, monthsElapsed);
  
  // Wealth score (0..30)
  const wealthGrowthRatio = player.netWorthSats / Math.max(1, startingSats);
  const wealthScore = Math.min(30, Math.floor(wealthGrowthRatio * 10));

  // Liquidity score (0..20)
  const liquidityRatio = player.walletBalanceSats / Math.max(1, player.netWorthSats);
  const liquidityScore = Math.min(20, Math.floor(liquidityRatio * 40));

  // Leverage score (0..20) - lower LTV is better
  const leveragePenalty = player.ltvRatioPercent;
  const leverageScore = Math.max(0, Math.floor(20 - leveragePenalty * 0.25));

  // Return score (0..15)
  const returnScore = Math.min(15, Math.max(0, Math.floor(cagr * 1.5)));

  // Resilience score (0..15)
  const resilienceScore = player.isBankrupt ? 0 : (player.happiness ?? 100) > 50 ? 15 : 8;

  const totalScore = wealthScore + liquidityScore + leverageScore + returnScore + resilienceScore;

  return {
    totalScore,
    wealthScore,
    liquidityScore,
    leverageScore,
    returnScore,
    resilienceScore,
  };
}
