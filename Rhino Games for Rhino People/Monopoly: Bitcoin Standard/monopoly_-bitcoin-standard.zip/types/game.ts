export type Satoshi = number; // Integer satoshis: 1 BTC = 100,000,000 sats

export type MonetaryRegime = 'BITCOIN_STANDARD' | 'FIAT_STANDARD' | 'GOLD_STANDARD' | 'FREE_BANKING';

export type AIStrategyType = 
  | 'HUMAN'
  | 'SAVER'
  | 'SPECULATOR'
  | 'PROPERTY_KING'
  | 'INDUSTRIALIST'
  | 'HODLER'
  | 'BANKER';

export type DistrictType = 
  | 'RESIDENTIAL'
  | 'COMMERCIAL'
  | 'INDUSTRIAL'
  | 'TRANSPORT'
  | 'UTILITIES'
  | 'SPECIAL';

export type DevelopmentLevel = 
  | 'EMPTY'
  | 'HOUSE'
  | 'APARTMENT'
  | 'OFFICE'
  | 'FACTORY'
  | 'WAREHOUSE'
  | 'HOTEL'
  | 'DATA_CENTER'
  | 'ENERGY_FACILITY'
  | 'RETAIL';

export interface Player {
  id: string;
  name: string;
  avatar: string;
  color: string;
  strategyType: AIStrategyType;
  walletBalanceSats: Satoshi;
  debtSats: Satoshi;
  timePreference: number; // 0.0 (very low / long term) to 1.0 (very high / instant)
  timePreferenceScore?: number;
  savingsRate?: number; // 0.0 to 1.0
  consumptionRate?: number; // 0.0 to 1.0
  happiness?: number; // 0 to 100
  isBankrupt: boolean;
  position: number; // 0 to 27 tile on board
  incomeSats: Satoshi;
  expensesSats: Satoshi;
  netWorthSats: Satoshi;
  ltvRatioPercent: number;
  stats: {
    totalRentPaidSats: Satoshi;
    totalRentEarnedSats: Satoshi;
    totalInterestPaidSats: Satoshi;
    totalInterestEarnedSats: Satoshi;
    propertiesOwnedCount: number;
    businessesOwnedCount: number;
    miningHashRateTHs?: number;
    maxNetWorthSats?: Satoshi;
  };
}

export interface Property {
  id: string;
  name: string;
  district: DistrictType;
  tileIndex: number; // 0..27 on rectangular board
  purchasePriceSats: Satoshi;
  marketValueSats: Satoshi;
  baseRentSats: Satoshi;
  occupancyRate: number; // e.g. 95%
  maintenanceCostSats: Satoshi;
  yieldPercent: number; // Annual yield = (Annual Rent / Market Value) * 100
  locationScore: number; // 1 to 10
  scarcityScore: number; // 1 to 10
  productivityBonus: number; // multiplier for adjacent businesses
  developmentLevel: DevelopmentLevel;
  developmentCostSats: Satoshi;
  ownerId: string | null; // null = unowned / municipality
  isMortgaged: boolean;
}

export interface Business {
  id: string;
  name: string;
  category: 'Bakery' | 'Coffee Shop' | 'Steelworks' | 'Logistics' | 'Energy Co' | 'Software Co' | 'Data Centre' | 'Mining Co' | 'Railway';
  tileIndex: number;
  purchasePriceSats: Satoshi;
  monthlyRevenueSats: Satoshi;
  operatingCostSats: Satoshi;
  employees: number;
  productivityFactor: number;
  ownerId: string | null;
  inventorySats: Satoshi;
}

export interface Loan {
  id: string;
  borrowerId: string;
  lenderId: string;
  principalSats: Satoshi;
  remainingPrincipalSats: Satoshi;
  interestRateAnnual?: number;
  interestRateMonthly: number; // e.g. 0.5% monthly = ~6% annual
  termMonths: number;
  monthsRemaining: number;
  collateralPropertyIds: string[];
  ltvPercent?: number;
  status: 'ACTIVE' | 'PAID' | 'DEFAULTED' | 'LIQUIDATED';
  createdTurn?: number;
}

export type AssetType = 'BTC' | 'PROPERTY' | 'BUSINESS' | 'LOAN' | 'TAX' | 'RENT' | 'DEVELOPMENT' | 'MINING' | 'REPAYMENT';

export interface Transaction {
  transaction_id: string;
  timestamp: string;
  turn: number;
  senderId: string; // 'SYSTEM' | player.id
  receiverId: string; // 'SYSTEM' | player.id
  amount_sats: Satoshi;
  fee_sats: Satoshi;
  reason: string;
  asset_type: AssetType;
}

export interface Block {
  blockHeight: number;
  hash: string;
  timestamp: string;
  transactions: Transaction[];
  totalFeesSats: Satoshi;
  minerId: string;
  sizeBytes: number;
}

export interface MiningFacility {
  id?: string;
  ownerId: string;
  asicCount: number;
  hashRateTHs: number;
  powerMW: number;
  energyCostPerkWhSats: Satoshi;
  efficiencyJoulePerTH?: number;
  monthlyCostSats?: Satoshi;
  monthlyMinedSats?: Satoshi;
}

export interface EconomicState {
  turn: number; // Turn count (1 turn = 1 month)
  month: number; // 1..12
  year: number; // 1..50
  gdpSats: Satoshi;
  btcSupplySats: Satoshi; // default 21,000,000 * 100,000,000 = 2,100,000,000,000,000
  btcVelocity: number; // e.g. 1.25x
  btcPriceFiatGBP: number; // Reference fiat price e.g. £100,000 per BTC
  priceIndexCPI: number; // Consumer Basket (100 base index)
  wagesSats: Satoshi;
  employmentRate: number; // % e.g. 94.5%
  interestRateAnnual: number; // % e.g. 4.5%
  creditSupplySats: Satoshi;
  creditDemandSats: Satoshi;
  defaultRatePercent: number; // % e.g. 1.2%
  propertyIndex: number; // base 100
  energyPriceSatsPerkWh: Satoshi;
  industrialOutputIndex: number; // base 100
  fiatInflationRateAnnual: number; // e.g. 2.5% vs -1.5% BTC deflation
  monetaryRegime: MonetaryRegime;
}

export interface GameEvent {
  id: string;
  turn: number;
  title: string;
  description: string;
  category: 'BOOM' | 'RECESSION' | 'ENERGY_SHOCK' | 'TECH_BREAKTHROUGH' | 'HOUSING_SHORTAGE' | 'BANKING_CRISIS' | 'DEMOGRAPHIC_BOOM' | 'HALVING';
  severity: number; // 1 to 5
  durationMonths: number;
  economicEffect: string;
}

export interface GameTimelineEntry {
  turn: number;
  month: number;
  year: number;
  actionDescription: string;
  economicStateSnapshot: EconomicState;
  playerBalances: Record<string, { btcSats: Satoshi; netWorthSats: Satoshi; debtSats: Satoshi }>;
  eventsTriggered: string[];
}

export interface MonteCarloScenario {
  seed: string;
  simulationsCount: number;
  horizonMonths: number;
  percentile5: number[];
  percentile25: number[];
  median: number[];
  percentile75: number[];
  percentile95: number[];
}

export type VictoryPhilosophy = 
  | 'ACCUMULATOR'
  | 'CAPITALIST'
  | 'LANDOWNER'
  | 'INDUSTRIALIST'
  | 'FINANCIER'
  | 'SURVIVOR';

export interface GameConfig {
  startingBtcPerPlayerSats: Satoshi; // e.g. 0.25 BTC = 25,000,000 sats
  totalBtcSupplySats: Satoshi; // 21,000,000 BTC
  victoryPhilosophy: VictoryPhilosophy;
  targetHorizonYears: number; // 10, 25, or 50 years
  monetaryRegime: MonetaryRegime;
  seed: string;
  difficulty: 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED' | 'QUANT';
}
