'use client';

import React, { useState } from 'react';
import { Player, Property, Business, Loan, EconomicState } from '@/types/game';
import { satsToBtcString, formatSats, satsToFiatString } from '@/lib/engine/sats';
import { Wallet, PieChart, ShieldAlert, ArrowUpRight, ArrowDownRight, FileText, Landmark, Building, Coins } from 'lucide-react';

interface PlayerDossierProps {
  humanPlayer: Player;
  properties: Property[];
  businesses: Business[];
  activeLoans: Loan[];
  economicState: EconomicState;
}

export const PlayerDossier: React.FC<PlayerDossierProps> = ({
  humanPlayer,
  properties,
  businesses,
  activeLoans,
  economicState,
}) => {
  const [activeTab, setActiveTab] = useState<'PORTFOLIO' | 'BALANCE_SHEET' | 'INCOME_STATEMENT' | 'CASH_FLOW'>('PORTFOLIO');

  const ownedProperties = properties.filter((p) => p.ownerId === humanPlayer.id);
  const ownedBusinesses = businesses.filter((b) => b.ownerId === humanPlayer.id);
  const playerLoans = activeLoans.filter((l) => l.borrowerId === humanPlayer.id);

  const totalPropValue = ownedProperties.reduce((sum, p) => sum + p.marketValueSats, 0);
  const totalBizValue = ownedBusinesses.reduce((sum, b) => sum + b.purchasePriceSats, 0);
  const totalAssets = humanPlayer.walletBalanceSats + totalPropValue + totalBizValue;

  // LTV status indicator
  const ltv = humanPlayer.ltvRatioPercent;
  let ltvColor = 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
  let ltvLabel = 'SAFE';

  if (ltv >= 85) {
    ltvColor = 'text-red-400 border-red-500/40 bg-red-500/10 animate-pulse';
    ltvLabel = 'LIQUIDATION RISK';
  } else if (ltv >= 70) {
    ltvColor = 'text-amber-400 border-amber-500/40 bg-amber-500/10';
    ltvLabel = 'HIGH RISK';
  } else if (ltv >= 50) {
    ltvColor = 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10';
    ltvLabel = 'WATCH';
  }

  return (
    <aside className="w-full lg:w-80 border-r border-[#2C2F36] bg-[#12151A] flex flex-col h-full shrink-0 select-none overflow-hidden text-[#F5F2ED]">
      {/* HEADER WALLET SUMMARY */}
      <div className="p-5 border-b border-[#2C2F36] bg-[#16191E]">
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-amber-500/90 font-mono mb-1 flex items-center">
              <Wallet className="w-3 h-3 mr-1 text-amber-500" />
              Primary Bitcoin Wallet
            </p>
            <p className="text-xl font-mono leading-none tracking-tight font-bold text-white">
              {satsToBtcString(humanPlayer.walletBalanceSats)}
            </p>
            <div className="flex items-center space-x-2 mt-1">
              <p className="text-[11px] font-mono text-[#8E9299]">
                {formatSats(humanPlayer.walletBalanceSats)}
              </p>
              <span className="text-[10px] font-mono text-amber-500/80">
                ({satsToFiatString(humanPlayer.walletBalanceSats, economicState.btcPriceFiatGBP)})
              </span>
            </div>
          </div>
          <div className="h-10 w-10 border border-[#2C2F36] rounded-full flex items-center justify-center bg-gradient-to-tr from-[#1A1D23] to-[#2C2F36] shadow-inner">
            <span className="text-xs font-bold text-amber-500">R</span>
          </div>
        </div>

        {/* NET WORTH & LEVERAGE METRICS */}
        <div className="space-y-2.5 pt-2 border-t border-[#2C2F36]">
          <div className="flex justify-between text-xs">
            <span className="text-[#8E9299]">Net Worth (BTC)</span>
            <span className="font-mono font-bold text-white">
              {satsToBtcString(humanPlayer.netWorthSats)}
            </span>
          </div>

          <div className="flex justify-between text-xs">
            <span className="text-[#8E9299]">Active Debt</span>
            <span className="font-mono font-semibold text-red-400">
              {humanPlayer.debtSats > 0 ? `(${satsToBtcString(humanPlayer.debtSats)})` : '0.00000000 BTC'}
            </span>
          </div>

          {/* LTV GAUGE BAR */}
          <div>
            <div className="flex justify-between items-center text-[10px] mb-1">
              <span className="uppercase tracking-wider text-[#8E9299]">LTV Ratio</span>
              <span className={`px-1.5 py-0.5 rounded border text-[9px] font-mono font-bold ${ltvColor}`}>
                {ltv.toFixed(1)}% {ltvLabel}
              </span>
            </div>
            <div className="w-full bg-[#1A1D23] h-1.5 rounded-full overflow-hidden border border-[#2C2F36]">
              <div
                className={`h-full transition-all duration-300 ${
                  ltv >= 85 ? 'bg-red-500' : ltv >= 70 ? 'bg-amber-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${Math.min(100, ltv)}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* DOSSIER TABS NAVIGATION */}
      <div className="flex border-b border-[#2C2F36] bg-[#0F1115] text-[10px] uppercase font-bold tracking-wider">
        <button
          onClick={() => setActiveTab('PORTFOLIO')}
          className={`flex-1 py-2.5 text-center border-b-2 transition cursor-pointer ${
            activeTab === 'PORTFOLIO'
              ? 'border-amber-500 text-amber-500 bg-[#16191E]'
              : 'border-transparent text-[#8E9299] hover:text-white'
          }`}
        >
          Assets
        </button>
        <button
          onClick={() => setActiveTab('BALANCE_SHEET')}
          className={`flex-1 py-2.5 text-center border-b-2 transition cursor-pointer ${
            activeTab === 'BALANCE_SHEET'
              ? 'border-amber-500 text-amber-500 bg-[#16191E]'
              : 'border-transparent text-[#8E9299] hover:text-white'
          }`}
        >
          Balance Sheet
        </button>
        <button
          onClick={() => setActiveTab('INCOME_STATEMENT')}
          className={`flex-1 py-2.5 text-center border-b-2 transition cursor-pointer ${
            activeTab === 'INCOME_STATEMENT'
              ? 'border-amber-500 text-amber-500 bg-[#16191E]'
              : 'border-transparent text-[#8E9299] hover:text-white'
          }`}
        >
          Income
        </button>
      </div>

      {/* TAB CONTENTS */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3">
        {/* PORTFOLIO TAB */}
        {activeTab === 'PORTFOLIO' && (
          <div>
            <h3 className="text-[10px] uppercase tracking-widest text-[#8E9299] mb-3 font-semibold">
              Property & Business Portfolio
            </h3>

            {ownedProperties.length === 0 && ownedBusinesses.length === 0 ? (
              <div className="p-4 bg-[#1A1D23] border border-[#2C2F36] rounded text-center text-xs text-[#8E9299]">
                No real estate or businesses acquired yet. Use turn funds to acquire capital assets on the board.
              </div>
            ) : (
              <div className="space-y-2.5">
                {ownedProperties.map((prop) => (
                  <div key={prop.id} className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded hover:border-amber-500/50 transition">
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-xs font-bold text-white flex items-center">
                        <Building className="w-3.5 h-3.5 mr-1 text-amber-500" />
                        {prop.name}
                      </span>
                      <span className="text-[10px] font-mono text-emerald-400 font-semibold">
                        +{prop.yieldPercent}% YLD
                      </span>
                    </div>
                    <p className="text-[10px] text-[#8E9299] font-mono">
                      Val: {satsToBtcString(prop.marketValueSats)} · Rent: {formatSats(prop.baseRentSats)}/m
                    </p>
                  </div>
                ))}

                {ownedBusinesses.map((biz) => (
                  <div key={biz.id} className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded hover:border-sky-500/50 transition">
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-xs font-bold text-white flex items-center">
                        <Coins className="w-3.5 h-3.5 mr-1 text-sky-400" />
                        {biz.name}
                      </span>
                      <span className="text-[10px] font-mono text-sky-400">
                        {biz.category}
                      </span>
                    </div>
                    <p className="text-[10px] text-[#8E9299] font-mono">
                      Rev: {formatSats(biz.monthlyRevenueSats)}/m · Employees: {biz.employees}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* BALANCE SHEET TAB */}
        {activeTab === 'BALANCE_SHEET' && (
          <div className="space-y-3 text-xs font-mono">
            <div className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <h4 className="text-[10px] uppercase text-emerald-400 tracking-wider mb-2 font-bold">ASSETS</h4>
              <div className="space-y-1.5 text-[11px]">
                <div className="flex justify-between text-[#8E9299]">
                  <span>Bitcoin Liquid Balance:</span>
                  <span className="text-white">{satsToBtcString(humanPlayer.walletBalanceSats, false)}</span>
                </div>
                <div className="flex justify-between text-[#8E9299]">
                  <span>Real Estate Assets:</span>
                  <span className="text-white">{satsToBtcString(totalPropValue, false)}</span>
                </div>
                <div className="flex justify-between text-[#8E9299]">
                  <span>Productive Businesses:</span>
                  <span className="text-white">{satsToBtcString(totalBizValue, false)}</span>
                </div>
                <div className="border-t border-[#2C2F36] pt-1 flex justify-between font-bold text-white">
                  <span>TOTAL ASSETS:</span>
                  <span className="text-emerald-400">{satsToBtcString(totalAssets)}</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <h4 className="text-[10px] uppercase text-red-400 tracking-wider mb-2 font-bold">LIABILITIES & EQUITY</h4>
              <div className="space-y-1.5 text-[11px]">
                <div className="flex justify-between text-[#8E9299]">
                  <span>Credit Market Mortgages:</span>
                  <span className="text-red-400">{satsToBtcString(humanPlayer.debtSats, false)}</span>
                </div>
                <div className="border-t border-[#2C2F36] pt-1 flex justify-between font-bold text-white">
                  <span>NET WORTH EQUITY:</span>
                  <span className="text-amber-500">{satsToBtcString(humanPlayer.netWorthSats)}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* INCOME STATEMENT TAB */}
        {activeTab === 'INCOME_STATEMENT' && (
          <div className="space-y-3 text-xs font-mono">
            <div className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <h4 className="text-[10px] uppercase text-emerald-400 tracking-wider mb-2 font-bold">MONTHLY REVENUE</h4>
              <div className="space-y-1.5 text-[11px]">
                <div className="flex justify-between text-[#8E9299]">
                  <span>Property Rental Income:</span>
                  <span className="text-emerald-400">
                    +{formatSats(ownedProperties.reduce((s, p) => s + p.baseRentSats, 0))}
                  </span>
                </div>
                <div className="flex justify-between text-[#8E9299]">
                  <span>Business Net Profits:</span>
                  <span className="text-emerald-400">
                    +{formatSats(ownedBusinesses.reduce((s, b) => s + (b.monthlyRevenueSats - b.operatingCostSats), 0))}
                  </span>
                </div>
                <div className="border-t border-[#2C2F36] pt-1 flex justify-between font-bold text-white">
                  <span>GROSS MONTHLY INCOME:</span>
                  <span className="text-emerald-400">+{formatSats(humanPlayer.incomeSats)}</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <h4 className="text-[10px] uppercase text-red-400 tracking-wider mb-2 font-bold">MONTHLY EXPENSES</h4>
              <div className="space-y-1.5 text-[11px]">
                <div className="flex justify-between text-[#8E9299]">
                  <span>Property Maintenance:</span>
                  <span className="text-red-400">
                    -{formatSats(ownedProperties.reduce((s, p) => s + p.maintenanceCostSats, 0))}
                  </span>
                </div>
                <div className="flex justify-between text-[#8E9299]">
                  <span>Debt Interest Service:</span>
                  <span className="text-red-400">
                    -{formatSats(playerLoans.reduce((s, l) => s + Math.floor(l.remainingPrincipalSats * (l.interestRateMonthly / 100)), 0))}
                  </span>
                </div>
                <div className="border-t border-[#2C2F36] pt-1 flex justify-between font-bold text-white">
                  <span>TOTAL MONTHLY EXPENSES:</span>
                  <span className="text-red-400">-{formatSats(humanPlayer.expensesSats)}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
