'use client';

import React from 'react';
import { EconomicState } from '@/types/game';
import { Play, Pause, FastForward, RotateCcw, LineChart, BookOpen, Layers, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  economicState: EconomicState;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStepTurn: () => void;
  onStepYear: () => void;
  onResetGame: () => void;
  onOpenAcademy: () => void;
  onOpenQuantLab: () => void;
  onOpenRegimeLab: () => void;
  onOpenTimeMachine: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  economicState,
  isPlaying,
  onTogglePlay,
  onStepTurn,
  onStepYear,
  onResetGame,
  onOpenAcademy,
  onOpenQuantLab,
  onOpenRegimeLab,
  onOpenTimeMachine,
}) => {
  const blockHeight = 842_910 + economicState.turn;

  return (
    <header className="h-16 border-b border-[#2C2F36] flex items-center justify-between px-6 bg-[#16191E] shrink-0 text-[#F5F2ED]">
      {/* BRAND & REGIME BADGE */}
      <div className="flex items-center space-x-4">
        <div>
          <h1 className="text-lg font-bold tracking-tighter uppercase text-white leading-none">
            RhinoCity <span className="text-amber-500 font-light italic text-base">Bitcoin Standard</span>
          </h1>
          <p className="text-[10px] text-[#8E9299] font-mono tracking-wider mt-0.5">
            Quantitative Economic Simulation Engine
          </p>
        </div>
        <button
          onClick={onOpenRegimeLab}
          className="text-[10px] bg-amber-500/10 text-amber-500 px-2.5 py-1 border border-amber-500/20 rounded uppercase tracking-widest hover:bg-amber-500/20 transition cursor-pointer flex items-center space-x-1"
        >
          <ShieldCheck className="w-3 h-3 mr-1" />
          <span>{economicState.monetaryRegime.replace('_', ' ')}</span>
        </button>
      </div>

      {/* SIMULATION STATE METRICS */}
      <div className="hidden lg:flex items-center space-x-8">
        <div className="text-right">
          <p className="text-[9px] uppercase tracking-widest text-[#8E9299]">Block Height</p>
          <p className="font-mono text-xs font-semibold text-amber-500">#{blockHeight.toLocaleString()}</p>
        </div>
        <div className="text-right">
          <p className="text-[9px] uppercase tracking-widest text-[#8E9299]">BTC Base Supply</p>
          <p className="font-mono text-xs font-semibold">21,000,000.00</p>
        </div>
        <div className="text-right">
          <p className="text-[9px] uppercase tracking-widest text-[#8E9299]">Simulation Turn</p>
          <p className="font-mono text-xs font-semibold text-white">
            M{economicState.month} / Y{economicState.year} <span className="text-[#8E9299] text-[10px]">(Turn {economicState.turn})</span>
          </p>
        </div>
      </div>

      {/* CONTROLS & NAVIGATION BUTTONS */}
      <div className="flex items-center space-x-2">
        {/* Simulation Execution Controls */}
        <div className="flex items-center bg-[#12151A] p-1 border border-[#2C2F36] rounded-md space-x-1 mr-2">
          <button
            onClick={onTogglePlay}
            className={`px-3 py-1.5 rounded text-xs font-semibold uppercase tracking-wider flex items-center space-x-1 transition cursor-pointer ${
              isPlaying
                ? 'bg-amber-500 text-black hover:bg-amber-400'
                : 'bg-[#1A1D23] text-amber-500 hover:bg-[#2C2F36]'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5 mr-1" /> : <Play className="w-3.5 h-3.5 mr-1" />}
            <span>{isPlaying ? 'Pause' : 'Auto Play'}</span>
          </button>

          <button
            onClick={onStepTurn}
            disabled={isPlaying}
            className="px-2.5 py-1.5 bg-[#1A1D23] hover:bg-[#2C2F36] text-xs font-medium rounded text-[#F5F2ED] transition disabled:opacity-50 cursor-pointer flex items-center"
            title="Advance 1 Month"
          >
            +1 Month
          </button>

          <button
            onClick={onStepYear}
            disabled={isPlaying}
            className="px-2.5 py-1.5 bg-[#1A1D23] hover:bg-[#2C2F36] text-xs font-medium rounded text-amber-500 transition disabled:opacity-50 cursor-pointer flex items-center"
            title="Advance 1 Year (12 Months)"
          >
            <FastForward className="w-3 h-3 mr-1" />
            +1 Year
          </button>
        </div>

        {/* Feature Navigation Tools */}
        <button
          onClick={onOpenQuantLab}
          className="p-2 bg-[#1A1D23] hover:bg-[#2C2F36] border border-[#2C2F36] rounded text-xs text-[#F5F2ED] flex items-center transition cursor-pointer"
          title="Quant Analytics Terminal"
        >
          <LineChart className="w-4 h-4 text-amber-500 sm:mr-1.5" />
          <span className="hidden sm:inline text-[11px] uppercase tracking-wider">Quant Lab</span>
        </button>

        <button
          onClick={onOpenTimeMachine}
          className="p-2 bg-[#1A1D23] hover:bg-[#2C2F36] border border-[#2C2F36] rounded text-xs text-[#F5F2ED] flex items-center transition cursor-pointer"
          title="Time Machine & What-If Engine"
        >
          <Layers className="w-4 h-4 text-sky-400 sm:mr-1.5" />
          <span className="hidden sm:inline text-[11px] uppercase tracking-wider">What-If</span>
        </button>

        <button
          onClick={onOpenAcademy}
          className="p-2 bg-[#1A1D23] hover:bg-[#2C2F36] border border-[#2C2F36] rounded text-xs text-[#F5F2ED] flex items-center transition cursor-pointer"
          title="RhinoQuant Academy"
        >
          <BookOpen className="w-4 h-4 text-emerald-400 sm:mr-1.5" />
          <span className="hidden sm:inline text-[11px] uppercase tracking-wider">Academy</span>
        </button>

        <button
          onClick={onResetGame}
          className="p-2 bg-[#1A1D23] hover:bg-red-950/40 border border-[#2C2F36] hover:border-red-500/50 rounded text-xs text-[#8E9299] hover:text-red-400 transition cursor-pointer"
          title="Reset Simulation Scenario"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
