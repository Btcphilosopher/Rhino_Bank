'use client';

import React, { useState } from 'react';
import { Player, EconomicState, MonteCarloScenario } from '@/types/game';
import { runMonteCarloSimulation, calculateCAGR, calculateMaxDrawdown, calculateSharpeRatio } from '@/lib/engine/quant';
import { satsToBtcString } from '@/lib/engine/sats';
import { X, LineChart, Activity, TrendingUp, BarChart, ShieldAlert, Cpu } from 'lucide-react';

interface QuantLabModalProps {
  isOpen: boolean;
  onClose: () => void;
  humanPlayer: Player;
  economicState: EconomicState;
  netWorthHistory: number[];
}

export const QuantLabModal: React.FC<QuantLabModalProps> = ({
  isOpen,
  onClose,
  humanPlayer,
  economicState,
  netWorthHistory,
}) => {
  const [simHorizonMonths, setSimHorizonMonths] = useState<number>(60);
  const [mcScenario, setMcScenario] = useState<MonteCarloScenario>(() =>
    runMonteCarloSimulation(humanPlayer ? humanPlayer.netWorthSats : 25_000_000, 60)
  );

  if (!isOpen) return null;

  const cagr = calculateCAGR(25_000_000, humanPlayer.netWorthSats, economicState.turn);
  const maxDrawdown = calculateMaxDrawdown(netWorthHistory);
  const sharpe = calculateSharpeRatio(
    netWorthHistory.map((val, idx) => (idx === 0 ? 0 : (val - netWorthHistory[idx - 1]) / netWorthHistory[idx - 1]))
  );

  const handleRunMC = () => {
    const res = runMonteCarloSimulation(humanPlayer.netWorthSats, simHorizonMonths);
    setMcScenario(res);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-4xl text-[#F5F2ED] overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* HEADER */}
        <div className="p-5 border-b border-[#2C2F36] bg-[#16191E] flex justify-between items-center shrink-0">
          <div className="flex items-center space-x-2">
            <LineChart className="w-5 h-5 text-amber-500" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-tight text-white">
                RhinoQuant Research & Monte Carlo Terminal
              </h2>
              <p className="text-[10px] text-[#8E9299] font-mono">
                Statistical Portfolio Modeling, Fan Charts & Risk Surfaces
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#2C2F36] text-[#8E9299] hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* CONTENT */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* STATISTICAL METRICS ROW */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-[#1A1D23] border border-[#2C2F36] rounded text-xs">
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Annualized CAGR</span>
              <p className="font-mono font-bold text-base text-emerald-400 mt-0.5">{cagr}%</p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Max Drawdown</span>
              <p className="font-mono font-bold text-base text-red-400 mt-0.5">{maxDrawdown}%</p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Sharpe Ratio</span>
              <p className="font-mono font-bold text-base text-amber-500 mt-0.5">{sharpe}</p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Active Net Worth</span>
              <p className="font-mono font-bold text-base text-white mt-0.5">
                {satsToBtcString(humanPlayer.netWorthSats)}
              </p>
            </div>
          </div>

          {/* MONTE CARLO FAN CHART CONTAINER */}
          <div className="p-4 border border-[#2C2F36] bg-[#16191E] rounded space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xs uppercase font-bold text-amber-500 tracking-wider">
                  Monte Carlo Fan Chart ({mcScenario.simulationsCount} Statistical Paths)
                </h3>
                <p className="text-[10px] text-[#8E9299] font-mono mt-0.5">
                  5th, 25th, Median (50th), 75th & 95th Percentile Wealth Cones
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <select
                  value={simHorizonMonths}
                  onChange={(e) => setSimHorizonMonths(parseInt(e.target.value))}
                  className="bg-[#12151A] border border-[#2C2F36] rounded px-2.5 py-1 text-xs font-mono text-white outline-none"
                >
                  <option value={24}>2 Years (24 Months)</option>
                  <option value={60}>5 Years (60 Months)</option>
                  <option value={120}>10 Years (120 Months)</option>
                </select>

                <button
                  onClick={handleRunMC}
                  className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs uppercase tracking-wider rounded transition cursor-pointer"
                >
                  Run Simulation
                </button>
              </div>
            </div>

            {/* SVG FAN CHART */}
            <div className="h-64 w-full bg-[#12151A] border border-[#2C2F36] rounded relative p-3 flex flex-col justify-between">
              <svg className="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
                {/* Gridlines */}
                <line x1="0" y1="50" x2="500" y2="50" stroke="#2C2F36" strokeDasharray="3,3" />
                <line x1="0" y1="100" x2="500" y2="100" stroke="#2C2F36" strokeDasharray="3,3" />
                <line x1="0" y1="150" x2="500" y2="150" stroke="#2C2F36" strokeDasharray="3,3" />

                {/* 5th to 95th Percentile Fan Area */}
                <polygon
                  points={
                    mcScenario.percentile95
                      .map((v, i) => `${(i / simHorizonMonths) * 500},${200 - Math.min(190, (v / (humanPlayer.netWorthSats * 3)) * 180)}`)
                      .join(' ') +
                    ' ' +
                    mcScenario.percentile5
                      .slice()
                      .reverse()
                      .map((v, i) => `${((simHorizonMonths - i) / simHorizonMonths) * 500},${200 - Math.min(190, (v / (humanPlayer.netWorthSats * 3)) * 180)}`)
                      .join(' ')
                  }
                  fill="#F59E0B"
                  fillOpacity="0.08"
                />

                {/* Median Path (50th Percentile) */}
                <polyline
                  points={mcScenario.median
                    .map((v, i) => `${(i / simHorizonMonths) * 500},${200 - Math.min(190, (v / (humanPlayer.netWorthSats * 3)) * 180)}`)
                    .join(' ')}
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="2"
                />

                {/* 75th Percentile Line */}
                <polyline
                  points={mcScenario.percentile75
                    .map((v, i) => `${(i / simHorizonMonths) * 500},${200 - Math.min(190, (v / (humanPlayer.netWorthSats * 3)) * 180)}`)
                    .join(' ')}
                  fill="none"
                  stroke="#22C55E"
                  strokeWidth="1.2"
                  strokeDasharray="4,2"
                />
              </svg>

              <div className="flex justify-between text-[10px] font-mono text-[#8E9299] mt-2">
                <span>Month 0</span>
                <span>Median Projected: {satsToBtcString(mcScenario.median[mcScenario.median.length - 1])}</span>
                <span>Month {simHorizonMonths}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
