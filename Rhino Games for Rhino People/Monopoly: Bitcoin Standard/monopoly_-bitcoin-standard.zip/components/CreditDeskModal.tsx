'use client';

import React, { useState } from 'react';
import { Player, Property, Loan, EconomicState, Satoshi } from '@/types/game';
import { satsToBtcString, formatSats } from '@/lib/engine/sats';
import { X, Landmark, AlertCircle, ArrowUpRight, ArrowDownRight, ShieldAlert, Check } from 'lucide-react';

interface CreditDeskModalProps {
  isOpen: boolean;
  onClose: () => void;
  humanPlayer: Player;
  properties: Property[];
  activeLoans: Loan[];
  economicState: EconomicState;
  onTakeLoan: (amountSats: Satoshi, collateralPropId: string) => void;
  onRepayLoan: (loanId: string, amountSats: Satoshi) => void;
}

export const CreditDeskModal: React.FC<CreditDeskModalProps> = ({
  isOpen,
  onClose,
  humanPlayer,
  properties,
  activeLoans,
  economicState,
  onTakeLoan,
  onRepayLoan,
}) => {
  const [loanAmountBtc, setLoanAmountBtc] = useState<string>('0.05');
  const [selectedCollateralId, setSelectedCollateralId] = useState<string>(
    properties.filter((p) => p.ownerId === humanPlayer.id && !p.isMortgaged)[0]?.id || ''
  );

  if (!isOpen) return null;

  const ownedProperties = properties.filter((p) => p.ownerId === humanPlayer.id && !p.isMortgaged);
  const myLoans = activeLoans.filter((l) => l.borrowerId === humanPlayer.id);

  const handleBorrowSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const btcVal = parseFloat(loanAmountBtc);
    if (isNaN(btcVal) || btcVal <= 0) return;

    const satsAmount = Math.floor(btcVal * 100_000_000);
    if (!selectedCollateralId) return;

    onTakeLoan(satsAmount, selectedCollateralId);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-2xl text-[#F5F2ED] overflow-hidden shadow-2xl">
        {/* HEADER */}
        <div className="p-5 border-b border-[#2C2F36] bg-[#16191E] flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Landmark className="w-5 h-5 text-amber-500" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-tight text-white">
                Rhino Credit Desk & Debt Market
              </h2>
              <p className="text-[10px] text-[#8E9299] font-mono">
                Collateralized Bitcoin Borrowing & Risk Monitor
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#2C2F36] text-[#8E9299] hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* LTV WARNING & CREDIT STATUS */}
          <div className="grid grid-cols-3 gap-3 p-3 bg-[#1A1D23] border border-[#2C2F36] rounded text-xs">
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Current LTV Ratio</span>
              <p className={`font-mono font-bold text-sm mt-0.5 ${humanPlayer.ltvRatioPercent > 70 ? 'text-red-400' : 'text-emerald-400'}`}>
                {humanPlayer.ltvRatioPercent.toFixed(1)}%
              </p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Annual Interest Rate</span>
              <p className="font-mono font-bold text-sm text-white mt-0.5">
                {economicState.interestRateAnnual.toFixed(1)}% p.a.
              </p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Total Active Debt</span>
              <p className="font-mono font-bold text-sm text-amber-500 mt-0.5">
                {satsToBtcString(humanPlayer.debtSats)}
              </p>
            </div>
          </div>

          {/* BORROW BTC FORM */}
          <div className="p-4 border border-[#2C2F36] bg-[#16191E] rounded space-y-4">
            <h3 className="text-xs uppercase font-bold text-amber-500 tracking-wider">
              Issue Collateralized Debt
            </h3>

            {ownedProperties.length === 0 ? (
              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded text-xs text-amber-400 flex items-center">
                <AlertCircle className="w-4 h-4 mr-2 shrink-0" />
                <span>You need unmortgaged real estate to pledge as loan collateral.</span>
              </div>
            ) : (
              <form onSubmit={handleBorrowSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] uppercase text-[#8E9299] font-mono mb-1">
                      Loan Principal (BTC)
                    </label>
                    <input
                      type="number"
                      step="0.005"
                      min="0.001"
                      max="1.0"
                      value={loanAmountBtc}
                      onChange={(e) => setLoanAmountBtc(e.target.value)}
                      className="w-full bg-[#12151A] border border-[#2C2F36] rounded px-3 py-2 text-xs font-mono text-white focus:border-amber-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase text-[#8E9299] font-mono mb-1">
                      Pledge Property Collateral
                    </label>
                    <select
                      value={selectedCollateralId}
                      onChange={(e) => setSelectedCollateralId(e.target.value)}
                      className="w-full bg-[#12151A] border border-[#2C2F36] rounded px-3 py-2 text-xs font-mono text-white focus:border-amber-500 outline-none"
                    >
                      {ownedProperties.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({satsToBtcString(p.marketValueSats)})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-extrabold uppercase tracking-wider text-xs rounded transition cursor-pointer"
                >
                  Confirm Loan Underwriting
                </button>
              </form>
            )}
          </div>

          {/* ACTIVE LOANS LIST */}
          <div>
            <h3 className="text-xs uppercase font-bold text-white tracking-wider mb-3">
              Active Loans & Debt Obligations
            </h3>

            {myLoans.length === 0 ? (
              <p className="text-xs text-[#8E9299] italic">No active debt obligations.</p>
            ) : (
              <div className="space-y-2">
                {myLoans.map((loan) => (
                  <div key={loan.id} className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded flex justify-between items-center text-xs">
                    <div>
                      <p className="font-bold text-white font-mono">
                        Loan #{loan.id.substring(0, 8)}
                      </p>
                      <p className="text-[10px] text-[#8E9299] font-mono mt-0.5">
                        Remaining Principal: {satsToBtcString(loan.remainingPrincipalSats)} · Rate: {loan.interestRateMonthly}%/m
                      </p>
                    </div>

                    <button
                      onClick={() => onRepayLoan(loan.id, Math.min(humanPlayer.walletBalanceSats, loan.remainingPrincipalSats))}
                      className="px-3 py-1.5 bg-[#12151A] hover:bg-emerald-950/40 border border-emerald-500/40 text-emerald-400 text-xs font-mono font-bold rounded transition cursor-pointer"
                    >
                      Repay Debt
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
