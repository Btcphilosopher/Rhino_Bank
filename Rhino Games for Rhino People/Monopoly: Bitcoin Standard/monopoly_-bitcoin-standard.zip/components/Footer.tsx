'use client';

import React from 'react';
import { Transaction } from '@/types/game';
import { satsToBtcString } from '@/lib/engine/sats';
import { Building, Landmark, Pickaxe, ArrowRight, Activity, Cpu } from 'lucide-react';

interface FooterProps {
  lastTransaction: Transaction | null;
  onEndTurn: () => void;
  onOpenMarket: () => void;
  onOpenCreditDesk: () => void;
  onOpenMiningHub: () => void;
  onOpenBlockchainVisualizer: () => void;
  isPlaying: boolean;
}

export const Footer: React.FC<FooterProps> = ({
  lastTransaction,
  onEndTurn,
  onOpenMarket,
  onOpenCreditDesk,
  onOpenMiningHub,
  onOpenBlockchainVisualizer,
  isPlaying,
}) => {
  return (
    <footer className="h-20 border-t border-[#2C2F36] bg-[#16191E] flex items-center px-6 shrink-0 justify-between text-[#F5F2ED] select-none">
      {/* PRIMARY ACTION BUTTONS */}
      <div className="flex items-center space-x-3">
        <button
          onClick={onEndTurn}
          disabled={isPlaying}
          className="h-11 px-7 bg-amber-500 hover:bg-amber-400 text-black font-extrabold uppercase tracking-widest text-xs rounded transition flex items-center shadow-[0_0_15px_rgba(245,158,11,0.3)] disabled:opacity-50 cursor-pointer"
        >
          <span>End Month</span>
          <ArrowRight className="w-4 h-4 ml-2" />
        </button>

        <button
          onClick={onOpenMarket}
          className="h-11 px-5 border border-[#2C2F36] bg-[#12151A] hover:bg-[#1A1D23] hover:border-amber-500/50 text-[#F5F2ED] font-bold uppercase tracking-wider text-xs rounded transition flex items-center cursor-pointer"
        >
          <Building className="w-4 h-4 mr-2 text-amber-500" />
          <span>Buy Assets</span>
        </button>

        <button
          onClick={onOpenCreditDesk}
          className="h-11 px-5 border border-[#2C2F36] bg-[#12151A] hover:bg-[#1A1D23] hover:border-amber-500/50 text-[#F5F2ED] font-bold uppercase tracking-wider text-xs rounded transition flex items-center cursor-pointer"
        >
          <Landmark className="w-4 h-4 mr-2 text-sky-400" />
          <span>Credit Desk</span>
        </button>

        <button
          onClick={onOpenMiningHub}
          className="h-11 px-5 border border-[#2C2F36] bg-[#12151A] hover:bg-[#1A1D23] hover:border-amber-500/50 text-[#F5F2ED] font-bold uppercase tracking-wider text-xs rounded transition flex items-center cursor-pointer"
        >
          <Pickaxe className="w-4 h-4 mr-2 text-emerald-400" />
          <span>ASIC Mining</span>
        </button>
      </div>

      {/* LAST TRANSACTION TICKER */}
      <div
        onClick={onOpenBlockchainVisualizer}
        className="hidden md:flex w-80 flex-col justify-center border-l border-[#2C2F36] pl-6 py-1 cursor-pointer hover:bg-[#12151A] transition rounded-r"
        title="Click to view Blockchain Ledger"
      >
        <div className="flex justify-between items-center mb-0.5">
          <p className="text-[10px] uppercase tracking-widest text-[#8E9299] font-mono flex items-center">
            <Activity className="w-3 h-3 mr-1 text-amber-500" />
            Last Blockchain Tx
          </p>
          <span className="text-[9px] text-amber-500 font-mono hover:underline">View Block</span>
        </div>

        {lastTransaction ? (
          <div className="flex justify-between items-baseline font-mono text-xs">
            <span className="text-white font-semibold truncate max-w-[140px]" title={lastTransaction.reason}>
              {lastTransaction.reason}
            </span>
            <span className={`font-bold ${lastTransaction.senderId === 'HUMAN' ? 'text-red-400' : 'text-emerald-400'}`}>
              {lastTransaction.senderId === 'HUMAN' ? '-' : '+'}{satsToBtcString(lastTransaction.amount_sats)}
            </span>
          </div>
        ) : (
          <p className="text-xs font-mono text-[#8E9299]">No transactions recorded yet</p>
        )}
      </div>
    </footer>
  );
};
