'use client';

import React from 'react';
import { EconomicState, Player, GameEvent } from '@/types/game';
import { satsToBtcString } from '@/lib/engine/sats';
import { AlertTriangle, TrendingUp, Cpu, Activity, Users, ShieldAlert, BarChart3 } from 'lucide-react';

interface QuantTerminalProps {
  economicState: EconomicState;
  players: Player[];
  activeEvent: GameEvent | null;
  onOpenQuantLab: () => void;
}

export const QuantTerminal: React.FC<QuantTerminalProps> = ({
  economicState,
  players,
  activeEvent,
  onOpenQuantLab,
}) => {
  const aiPlayers = players.filter((p) => p.strategyType !== 'HUMAN');

  // Synthetic price sparkline points
  const sparklinePath = 'M0 32 L12 28 L24 30 L36 22 L48 25 L60 14 L72 18 L84 8 L96 11 L108 4 L120 7';

  return (
    <aside className="w-full lg:w-80 border-l border-[#2C2F36] bg-[#12151A] p-5 flex flex-col h-full shrink-0 select-none overflow-y-auto text-[#F5F2ED]">
      {/* MARKET PRICE ACTION SECTION */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-[10px] uppercase tracking-widest text-[#8E9299] font-bold">
            Market Price Action
          </h3>
          <button
            onClick={onOpenQuantLab}
            className="text-[10px] text-amber-500 hover:underline flex items-center cursor-pointer"
          >
            <BarChart3 className="w-3 h-3 mr-1" />
            Expand Chart
          </button>
        </div>

        <div className="h-28 w-full bg-[#1A1D23] border border-[#2C2F36] rounded relative overflow-hidden flex flex-col justify-between p-2">
          {/* MINI SPARKLINE SVG */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 120 40" preserveAspectRatio="none">
            <path
              d={sparklinePath}
              fill="none"
              stroke="#F59E0B"
              strokeWidth="1.5"
            />
            <path
              d={`${sparklinePath} L120 40 L0 40 Z`}
              fill="url(#amber-grad)"
              opacity="0.15"
            />
            <defs>
              <linearGradient id="amber-grad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#F59E0B" stopOpacity="1" />
                <stop offset="100%" stopColor="#F59E0B" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>

          <div className="relative z-10 flex justify-between text-[10px] font-mono">
            <span className="text-[#8E9299]">BTC / GBP Rate:</span>
            <span className="text-amber-500 font-bold">£{economicState.btcPriceFiatGBP.toLocaleString()}</span>
          </div>

          <div className="relative z-10 flex justify-between items-end text-[10px] font-mono mt-auto pt-4">
            <span className="text-[#8E9299]">Real Estate Index</span>
            <span className="text-emerald-400 font-semibold flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" />
              +{((economicState.propertyIndex - 100) / 10).toFixed(1)}% / YTD
            </span>
          </div>
        </div>
      </div>

      {/* YIELD CURVE SECTION */}
      <div className="mb-6">
        <h4 className="text-[10px] uppercase tracking-widest text-[#8E9299] mb-3 font-bold">
          Rhino Credit Yield Curve
        </h4>
        <div className="space-y-2 text-xs font-mono">
          <div className="flex items-center space-x-2">
            <div className="w-10 text-[10px] text-[#8E9299]">1Y</div>
            <div className="flex-1 bg-[#1A1D23] h-2 rounded-full overflow-hidden border border-[#2C2F36]">
              <div className="bg-amber-500/60 w-1/2 h-full"></div>
            </div>
            <div className="text-[10px] text-white">
              {economicState.interestRateAnnual.toFixed(1)}%
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <div className="w-10 text-[10px] text-[#8E9299]">5Y</div>
            <div className="flex-1 bg-[#1A1D23] h-2 rounded-full overflow-hidden border border-[#2C2F36]">
              <div className="bg-amber-500/80 w-3/4 h-full"></div>
            </div>
            <div className="text-[10px] text-white">
              {(economicState.interestRateAnnual + 1.2).toFixed(1)}%
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <div className="w-10 text-[10px] text-[#8E9299]">10Y</div>
            <div className="flex-1 bg-[#1A1D23] h-2 rounded-full overflow-hidden border border-[#2C2F36]">
              <div className="bg-amber-500 w-full h-full"></div>
            </div>
            <div className="text-[10px] text-white">
              {(economicState.interestRateAnnual + 2.1).toFixed(1)}%
            </div>
          </div>
        </div>
      </div>

      {/* MACRO WARNINGS & EVENTS */}
      <div className="mb-6">
        <h4 className="text-[10px] uppercase tracking-widest text-[#8E9299] mb-3 font-bold flex items-center">
          <ShieldAlert className="w-3.5 h-3.5 mr-1 text-amber-500" />
          Macro Economic Signals
        </h4>

        {activeEvent ? (
          <div className="p-3 border border-amber-500/30 bg-amber-500/10 rounded mb-2">
            <p className="text-[11px] text-amber-500 font-bold uppercase tracking-tight flex items-center">
              <AlertTriangle className="w-3.5 h-3.5 mr-1" />
              {activeEvent.title}
            </p>
            <p className="text-[10px] text-[#F5F2ED]/90 mt-1 leading-relaxed">
              {activeEvent.description}
            </p>
            <p className="text-[9px] font-mono text-amber-400 mt-1 font-semibold">
              Effect: {activeEvent.economicEffect}
            </p>
          </div>
        ) : (
          <div className="p-3 border border-[#2C2F36] bg-[#1A1D23] rounded">
            <p className="text-[10px] text-amber-500/90 font-medium uppercase tracking-tight">
              Monetary Stability Normal
            </p>
            <p className="text-[9px] text-[#8E9299] mt-1 leading-relaxed">
              Bitcoin monetary base strictly conserved. Yields across Industrial District remain stable.
            </p>
          </div>
        )}
      </div>

      {/* COMPETING AI AGENTS DOSSIER */}
      <div className="flex-1">
        <h4 className="text-[10px] uppercase tracking-widest text-[#8E9299] mb-3 font-bold flex items-center">
          <Users className="w-3.5 h-3.5 mr-1 text-sky-400" />
          Competing AI Economic Agents
        </h4>

        <div className="space-y-2">
          {aiPlayers.map((ai) => (
            <div key={ai.id} className="p-2.5 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-bold text-white flex items-center space-x-1">
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: ai.color }}
                  ></span>
                  <span>{ai.name}</span>
                </span>
                <span className="text-[9px] font-mono text-amber-500 uppercase px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
                  {ai.strategyType}
                </span>
              </div>
              <div className="flex justify-between text-[10px] font-mono text-[#8E9299]">
                <span>Net Worth:</span>
                <span className="text-white font-semibold">{satsToBtcString(ai.netWorthSats)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
};
