'use client';

import React from 'react';
import { Block, Transaction } from '@/types/game';
import { satsToBtcString, formatSats } from '@/lib/engine/sats';
import { X, Layers, Activity, CheckCircle, ShieldCheck } from 'lucide-react';

interface BlockchainVisualizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  blockchain: Block[];
  latestTransactions: Transaction[];
}

export const BlockchainVisualizerModal: React.FC<BlockchainVisualizerModalProps> = ({
  isOpen,
  onClose,
  blockchain,
  latestTransactions,
}) => {
  if (!isOpen) return null;

  const latestBlock = blockchain[blockchain.length - 1];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-3xl text-[#F5F2ED] overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* HEADER */}
        <div className="p-5 border-b border-[#2C2F36] bg-[#16191E] flex justify-between items-center shrink-0">
          <div className="flex items-center space-x-2">
            <Layers className="w-5 h-5 text-amber-500" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-tight text-white">
                Bitcoin Blockchain Explorer & Ledger
              </h2>
              <p className="text-[10px] text-[#8E9299] font-mono">
                Immutable PoW Blocks & Satoshi Transaction History
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#2C2F36] text-[#8E9299] hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* LATEST BLOCK CARD */}
        {latestBlock && (
          <div className="p-4 bg-[#16191E] border-b border-[#2C2F36] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono shrink-0">
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Block Height</span>
              <p className="font-bold text-amber-500">#{latestBlock.blockHeight}</p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Block Size</span>
              <p className="font-bold text-white">{(latestBlock.sizeBytes / 1024).toFixed(1)} KB</p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Tx Count</span>
              <p className="font-bold text-emerald-400">{latestBlock.transactions.length} Txs</p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Miner</span>
              <p className="font-bold text-white truncate">{latestBlock.minerId}</p>
            </div>
          </div>
        )}

        {/* RECENT TRANSACTIONS TABLE */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          <h3 className="text-xs uppercase font-bold text-white tracking-wider mb-2">
            Confirmed Ledger Transactions
          </h3>

          {latestTransactions.length === 0 ? (
            <p className="text-xs text-[#8E9299] text-center py-6">No recent transactions.</p>
          ) : (
            latestTransactions.map((tx) => (
              <div key={tx.transaction_id} className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded font-mono text-xs flex justify-between items-center">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-amber-500 font-bold">{tx.transaction_id}</span>
                    <span className="text-[9px] uppercase px-1.5 py-0.5 rounded border border-[#2C2F36] text-[#8E9299]">
                      {tx.asset_type}
                    </span>
                  </div>
                  <p className="text-[10px] text-[#8E9299] mt-0.5">{tx.reason}</p>
                </div>

                <div className="text-right">
                  <p className="font-bold text-emerald-400">+{satsToBtcString(tx.amount_sats)}</p>
                  <p className="text-[9px] text-[#8E9299]">{formatSats(tx.amount_sats)}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
