'use client';

import React from 'react';
import { GameTimelineEntry } from '@/types/game';
import { satsToBtcString } from '@/lib/engine/sats';
import { X, Layers, RotateCcw, ArrowLeft } from 'lucide-react';

interface TimeMachineModalProps {
  isOpen: boolean;
  onClose: () => void;
  timeline: GameTimelineEntry[];
  onRewindToTurn: (turn: number) => void;
}

export const TimeMachineModal: React.FC<TimeMachineModalProps> = ({
  isOpen,
  onClose,
  timeline,
  onRewindToTurn,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-2xl text-[#F5F2ED] overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* HEADER */}
        <div className="p-5 border-b border-[#2C2F36] bg-[#16191E] flex justify-between items-center shrink-0">
          <div className="flex items-center space-x-2">
            <Layers className="w-5 h-5 text-sky-400" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-tight text-white">
                Time Machine & Counterfactual Simulator
              </h2>
              <p className="text-[10px] text-[#8E9299] font-mono">
                Rewind Timeline &amp; Test &quot;What If I Didn&apos;t Borrow?&quot; Scenarios
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#2C2F36] text-[#8E9299] hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TIMELINE LIST */}
        <div className="p-6 overflow-y-auto flex-1 space-y-2">
          {timeline.length === 0 ? (
            <p className="text-xs text-[#8E9299] text-center py-6">Timeline history is empty.</p>
          ) : (
            timeline.slice().reverse().map((entry) => (
              <div
                key={entry.turn}
                className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded flex justify-between items-center text-xs font-mono"
              >
                <div>
                  <p className="font-bold text-white">
                    Month {entry.month}, Year {entry.year} <span className="text-amber-500 text-[10px]">(Turn {entry.turn})</span>
                  </p>
                  <p className="text-[10px] text-[#8E9299] mt-0.5">{entry.actionDescription}</p>
                </div>

                <button
                  onClick={() => onRewindToTurn(entry.turn)}
                  className="px-3 py-1.5 bg-[#12151A] hover:bg-sky-950/40 border border-sky-500/40 text-sky-400 font-bold rounded transition cursor-pointer flex items-center"
                >
                  <RotateCcw className="w-3.5 h-3.5 mr-1" />
                  Rewind
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
