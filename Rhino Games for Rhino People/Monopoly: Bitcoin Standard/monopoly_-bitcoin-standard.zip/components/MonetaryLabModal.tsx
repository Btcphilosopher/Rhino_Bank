'use client';

import React from 'react';
import { MonetaryRegime, EconomicState } from '@/types/game';
import { X, ShieldCheck, RefreshCw, AlertTriangle } from 'lucide-react';

interface MonetaryLabModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRegime: MonetaryRegime;
  onChangeRegime: (regime: MonetaryRegime) => void;
}

export const MonetaryLabModal: React.FC<MonetaryLabModalProps> = ({
  isOpen,
  onClose,
  currentRegime,
  onChangeRegime,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-2xl text-[#F5F2ED] overflow-hidden shadow-2xl flex flex-col">
        {/* HEADER */}
        <div className="p-5 border-b border-[#2C2F36] bg-[#16191E] flex justify-between items-center shrink-0">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-amber-500" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-tight text-white">
                Comparative Monetary Regimes Laboratory
              </h2>
              <p className="text-[10px] text-[#8E9299] font-mono">
                Experiment with Hard Money vs Elastic Money Policy Regimes
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#2C2F36] text-[#8E9299] hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* CONTENT */}
        <div className="p-6 space-y-4">
          <div
            onClick={() => onChangeRegime('BITCOIN_STANDARD')}
            className={`p-4 border rounded cursor-pointer transition ${
              currentRegime === 'BITCOIN_STANDARD'
                ? 'border-amber-500 bg-amber-500/10'
                : 'border-[#2C2F36] bg-[#1A1D23] hover:border-amber-500/50'
            }`}
          >
            <h3 className="font-bold text-amber-500 text-xs uppercase tracking-wider">
              1. Bitcoin Standard Regime (Fixed 21,000,000 BTC)
            </h3>
            <p className="text-[11px] text-[#8E9299] mt-1 leading-relaxed font-mono">
              Absolute monetary scarcity. Productivity increases result in organic purchasing power appreciation and structural price deflation in BTC.
            </p>
          </div>

          <div
            onClick={() => onChangeRegime('FIAT_STANDARD')}
            className={`p-4 border rounded cursor-pointer transition ${
              currentRegime === 'FIAT_STANDARD'
                ? 'border-amber-500 bg-amber-500/10'
                : 'border-[#2C2F36] bg-[#1A1D23] hover:border-amber-500/50'
            }`}
          >
            <h3 className="font-bold text-sky-400 text-xs uppercase tracking-wider">
              2. Fiat Standard Comparison Regime (Elastic Supply)
            </h3>
            <p className="text-[11px] text-[#8E9299] mt-1 leading-relaxed font-mono">
              Elastic money printing. Central bank credit expansion introduces monetary inflation, asset price bubbles, and purchasing power debasement.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
