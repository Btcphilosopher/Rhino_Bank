'use client';

import React from 'react';
import { Property, Business, Player, EconomicState, DistrictType } from '@/types/game';
import { RHINOCITY_TILES, TileInfo } from '@/lib/engine/boardData';
import { satsToBtcString, formatSats } from '@/lib/engine/sats';
import { Building2, Factory, Home, Landmark, Zap, Train, ShieldAlert, Cpu, Sparkles, TrendingUp } from 'lucide-react';

interface BoardProps {
  properties: Property[];
  businesses: Business[];
  players: Player[];
  economicState: EconomicState;
  selectedTileIndex: number | null;
  onSelectTile: (tileIndex: number) => void;
}

export const Board: React.FC<BoardProps> = ({
  properties,
  businesses,
  players,
  economicState,
  selectedTileIndex,
  onSelectTile,
}) => {
  const propertyMap = new Map<number, Property>(properties.map((p) => [p.tileIndex, p]));
  const businessMap = new Map<number, Business>(businesses.map((b) => [b.tileIndex, b]));

  const getDistrictBadgeColor = (district?: DistrictType) => {
    switch (district) {
      case 'RESIDENTIAL':
        return 'border-amber-500/40 text-amber-500 bg-amber-500/10';
      case 'COMMERCIAL':
        return 'border-sky-500/40 text-sky-400 bg-sky-500/10';
      case 'INDUSTRIAL':
        return 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10';
      case 'TRANSPORT':
        return 'border-purple-500/40 text-purple-400 bg-purple-500/10';
      case 'UTILITIES':
        return 'border-indigo-500/40 text-indigo-400 bg-indigo-500/10';
      default:
        return 'border-[#2C2F36] text-[#8E9299] bg-[#1A1D23]';
    }
  };

  const getPropertyIcon = (district?: DistrictType) => {
    switch (district) {
      case 'RESIDENTIAL':
        return <Home className="w-3.5 h-3.5 text-amber-500" />;
      case 'COMMERCIAL':
        return <Building2 className="w-3.5 h-3.5 text-sky-400" />;
      case 'INDUSTRIAL':
        return <Factory className="w-3.5 h-3.5 text-emerald-400" />;
      case 'TRANSPORT':
        return <Train className="w-3.5 h-3.5 text-purple-400" />;
      case 'UTILITIES':
        return <Zap className="w-3.5 h-3.5 text-indigo-400" />;
      default:
        return <Landmark className="w-3.5 h-3.5 text-amber-500" />;
    }
  };

  return (
    <div className="flex-1 bg-[#0B0D11] p-4 lg:p-6 flex flex-col h-full overflow-hidden select-none">
      {/* MAP VIEW HEADER */}
      <div className="flex justify-between items-center mb-3 text-xs">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
          <span className="text-[#8E9299] uppercase tracking-wider font-semibold text-[11px]">
            RhinoCity Economic Cadastre & Property Grid
          </span>
        </div>
        <div className="flex space-x-4 text-[11px] font-mono">
          <span className="text-[#8E9299]">
            GDP: <strong className="text-white">{satsToBtcString(economicState.gdpSats)}</strong>
          </span>
          <span className="text-[#8E9299]">
            CPI Index: <strong className="text-amber-500">{economicState.priceIndexCPI.toFixed(1)}</strong>
          </span>
        </div>
      </div>

      {/* 28-TILE BOARD MAP GRID */}
      <div className="flex-1 border border-[#2C2F36] bg-[#0F1115] rounded-sm p-3 relative overflow-y-auto overflow-x-hidden bg-board-pattern">
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
          {RHINOCITY_TILES.map((tile) => {
            const property = propertyMap.get(tile.tileIndex);
            const business = businessMap.get(tile.tileIndex);
            const isSelected = selectedTileIndex === tile.tileIndex;
            const tileOwner = property?.ownerId
              ? players.find((p) => p.id === property.ownerId)
              : null;

            // Find players standing on this tile
            const playersOnTile = players.filter((p) => p.position === tile.tileIndex);

            return (
              <div
                key={tile.tileIndex}
                onClick={() => onSelectTile(tile.tileIndex)}
                className={`min-h-[110px] p-2.5 border rounded flex flex-col justify-between relative cursor-pointer transition-all duration-150 ${
                  isSelected
                    ? 'border-amber-500 bg-amber-500/10 shadow-[0_0_12px_rgba(245,158,11,0.25)] ring-1 ring-amber-500'
                    : tile.type === 'SPECIAL'
                    ? 'border-[#2C2F36] bg-[#12151A] hover:border-amber-500/50'
                    : 'border-[#2C2F36] bg-[#16191E] hover:border-amber-500/60'
                }`}
              >
                {/* TILE INDEX & DISTRICT TAG */}
                <div className="flex justify-between items-center text-[9px] font-mono mb-1">
                  <span className="text-[#8E9299]">
                    #{tile.tileIndex < 10 ? `0${tile.tileIndex}` : tile.tileIndex}
                  </span>
                  {tile.district ? (
                    <span
                      className={`px-1.5 py-0.5 rounded border uppercase text-[8px] tracking-tight font-semibold ${getDistrictBadgeColor(
                        tile.district
                      )}`}
                    >
                      {tile.district.substring(0, 4)}
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.5 rounded border border-amber-500/30 text-amber-500 bg-amber-500/10 uppercase text-[8px] tracking-tight">
                      SPECIAL
                    </span>
                  )}
                </div>

                {/* TILE NAME & ICON */}
                <div>
                  <div className="flex items-center space-x-1 mb-0.5">
                    {getPropertyIcon(tile.district)}
                    <h3 className="text-xs font-bold text-white truncate tracking-tight">{tile.name}</h3>
                  </div>

                  {property && (
                    <div className="text-[10px] font-mono space-y-0.5 mt-1">
                      <div className="flex justify-between text-[#8E9299]">
                        <span>Val:</span>
                        <span className="text-white">{satsToBtcString(property.marketValueSats, false)}</span>
                      </div>
                      <div className="flex justify-between text-[#8E9299]">
                        <span>Yield:</span>
                        <span className="text-emerald-400 font-semibold">{property.yieldPercent}%</span>
                      </div>
                    </div>
                  )}

                  {tile.type === 'SPECIAL' && (
                    <p className="text-[9px] text-[#8E9299] leading-tight line-clamp-2 mt-1">
                      {tile.description}
                    </p>
                  )}
                </div>

                {/* OWNER / DEVELOPMENT INDICATOR */}
                <div className="mt-2 pt-1 border-t border-[#2C2F36]/60 flex justify-between items-center text-[9px]">
                  {tileOwner ? (
                    <span className="flex items-center space-x-1 font-semibold text-white">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: tileOwner.color }}
                      ></span>
                      <span className="truncate max-w-[65px]">{tileOwner.name}</span>
                    </span>
                  ) : property ? (
                    <span className="text-amber-500/80 font-mono text-[8px] uppercase">
                      Unclaimed
                    </span>
                  ) : (
                    <span className="text-[#8E9299] text-[8px] uppercase font-mono">
                      Hub
                    </span>
                  )}

                  {business && (
                    <span className="text-sky-400 text-[8px] font-mono" title={`Business: ${business.name}`}>
                      +BIZ
                    </span>
                  )}
                </div>

                {/* PLAYER TOKENS ON TILE */}
                {playersOnTile.length > 0 && (
                  <div className="absolute -top-1.5 -right-1.5 flex -space-x-1">
                    {playersOnTile.map((p) => (
                      <div
                        key={p.id}
                        className="w-5 h-5 rounded-full border border-black flex items-center justify-center font-bold text-[9px] text-black shadow-md transform hover:scale-125 transition"
                        style={{ backgroundColor: p.color }}
                        title={`${p.name} is here`}
                      >
                        {p.name.substring(0, 1)}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* FOOTER METRIC BANNER */}
      <div className="mt-3 h-10 border-t border-[#2C2F36] pt-2 flex items-center justify-between text-xs px-1">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[#8E9299] text-[11px]">Real Estate Capital Index:</span>
            <span className="font-mono font-bold text-white">
              {economicState.propertyIndex.toFixed(1)} pts
            </span>
          </div>
          <div className="hidden md:flex items-center space-x-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span className="text-[#8E9299] text-[11px]">Grid Power Tariff:</span>
            <span className="font-mono text-white">
              {formatSats(economicState.energyPriceSatsPerkWh)} / kWh
            </span>
          </div>
        </div>

        <div className="text-right font-mono text-[11px]">
          <span className="text-[#8E9299]">Fiat Reference Rate: </span>
          <span className="text-amber-500 font-bold">
            £{economicState.btcPriceFiatGBP.toLocaleString()} / BTC
          </span>
        </div>
      </div>
    </div>
  );
};
