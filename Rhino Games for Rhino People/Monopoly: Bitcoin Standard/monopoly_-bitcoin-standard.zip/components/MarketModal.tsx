'use client';

import React, { useState } from 'react';
import { Player, Property, Business, EconomicState, Satoshi, DevelopmentLevel } from '@/types/game';
import { satsToBtcString, formatSats } from '@/lib/engine/sats';
import { X, Building2, Coins, Hammer, ShoppingBag, ArrowUpRight, TrendingUp } from 'lucide-react';

interface MarketModalProps {
  isOpen: boolean;
  onClose: () => void;
  humanPlayer: Player;
  properties: Property[];
  businesses: Business[];
  economicState: EconomicState;
  onBuyProperty: (propertyId: string) => void;
  onBuyBusiness: (businessId: string) => void;
  onDevelopProperty: (propertyId: string) => void;
}

export const MarketModal: React.FC<MarketModalProps> = ({
  isOpen,
  onClose,
  humanPlayer,
  properties,
  businesses,
  economicState,
  onBuyProperty,
  onBuyBusiness,
  onDevelopProperty,
}) => {
  const [activeTab, setActiveTab] = useState<'PROPERTIES' | 'BUSINESSES' | 'DEVELOPMENT'>('PROPERTIES');

  if (!isOpen) return null;

  const unownedProperties = properties.filter((p) => p.ownerId === null);
  const unownedBusinesses = businesses.filter((b) => b.ownerId === null);
  const myProperties = properties.filter((p) => p.ownerId === humanPlayer.id);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-3xl text-[#F5F2ED] overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* HEADER */}
        <div className="p-5 border-b border-[#2C2F36] bg-[#16191E] flex justify-between items-center shrink-0">
          <div className="flex items-center space-x-2">
            <ShoppingBag className="w-5 h-5 text-amber-500" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-tight text-white">
                RhinoCity Capital Assets Exchange
              </h2>
              <p className="text-[10px] text-[#8E9299] font-mono">
                Acquire Real Estate, Productive Businesses & Development Upgrades
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#2C2F36] text-[#8E9299] hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TABS */}
        <div className="flex border-b border-[#2C2F36] bg-[#0F1115] text-xs font-bold uppercase tracking-wider shrink-0">
          <button
            onClick={() => setActiveTab('PROPERTIES')}
            className={`flex-1 py-3 text-center border-b-2 transition cursor-pointer ${
              activeTab === 'PROPERTIES'
                ? 'border-amber-500 text-amber-500 bg-[#16191E]'
                : 'border-transparent text-[#8E9299] hover:text-white'
            }`}
          >
            Real Estate ({unownedProperties.length})
          </button>
          <button
            onClick={() => setActiveTab('BUSINESSES')}
            className={`flex-1 py-3 text-center border-b-2 transition cursor-pointer ${
              activeTab === 'BUSINESSES'
                ? 'border-amber-500 text-amber-500 bg-[#16191E]'
                : 'border-transparent text-[#8E9299] hover:text-white'
            }`}
          >
            Businesses ({unownedBusinesses.length})
          </button>
          <button
            onClick={() => setActiveTab('DEVELOPMENT')}
            className={`flex-1 py-3 text-center border-b-2 transition cursor-pointer ${
              activeTab === 'DEVELOPMENT'
                ? 'border-amber-500 text-amber-500 bg-[#16191E]'
                : 'border-transparent text-[#8E9299] hover:text-white'
            }`}
          >
            Improve Land ({myProperties.length})
          </button>
        </div>

        {/* CONTENT */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'PROPERTIES' && (
            <div className="space-y-3">
              {unownedProperties.length === 0 ? (
                <p className="text-xs text-[#8E9299] text-center py-6">
                  All properties in RhinoCity are currently owned by economic agents.
                </p>
              ) : (
                unownedProperties.map((prop) => {
                  const canAfford = humanPlayer.walletBalanceSats >= prop.purchasePriceSats;
                  return (
                    <div
                      key={prop.id}
                      className="p-4 bg-[#1A1D23] border border-[#2C2F36] rounded flex justify-between items-center hover:border-amber-500/50 transition"
                    >
                      <div>
                        <div className="flex items-center space-x-2">
                          <Building2 className="w-4 h-4 text-amber-500" />
                          <h3 className="font-bold text-white text-xs">{prop.name}</h3>
                          <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded border border-amber-500/30 text-amber-500 bg-amber-500/10">
                            {prop.district}
                          </span>
                        </div>
                        <p className="text-[11px] font-mono text-[#8E9299] mt-1">
                          Base Rent: {formatSats(prop.baseRentSats)}/m · Yield:{' '}
                          <span className="text-emerald-400 font-bold">{prop.yieldPercent}%</span>
                        </p>
                      </div>

                      <div className="text-right">
                        <p className="text-xs font-mono font-bold text-white mb-1">
                          {satsToBtcString(prop.purchasePriceSats)}
                        </p>
                        <button
                          onClick={() => onBuyProperty(prop.id)}
                          disabled={!canAfford}
                          className={`px-4 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition cursor-pointer ${
                            canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-black'
                              : 'bg-[#2C2F36] text-[#8E9299] cursor-not-allowed'
                          }`}
                        >
                          Acquire Land
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {activeTab === 'BUSINESSES' && (
            <div className="space-y-3">
              {unownedBusinesses.length === 0 ? (
                <p className="text-xs text-[#8E9299] text-center py-6">
                  All productive businesses are currently owned.
                </p>
              ) : (
                unownedBusinesses.map((biz) => {
                  const canAfford = humanPlayer.walletBalanceSats >= biz.purchasePriceSats;
                  return (
                    <div
                      key={biz.id}
                      className="p-4 bg-[#1A1D23] border border-[#2C2F36] rounded flex justify-between items-center hover:border-sky-500/50 transition"
                    >
                      <div>
                        <div className="flex items-center space-x-2">
                          <Coins className="w-4 h-4 text-sky-400" />
                          <h3 className="font-bold text-white text-xs">{biz.name}</h3>
                          <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded border border-sky-500/30 text-sky-400 bg-sky-500/10">
                            {biz.category}
                          </span>
                        </div>
                        <p className="text-[11px] font-mono text-[#8E9299] mt-1">
                          Monthly Profit: +{formatSats(biz.monthlyRevenueSats - biz.operatingCostSats)}/m · Employees: {biz.employees}
                        </p>
                      </div>

                      <div className="text-right">
                        <p className="text-xs font-mono font-bold text-white mb-1">
                          {satsToBtcString(biz.purchasePriceSats)}
                        </p>
                        <button
                          onClick={() => onBuyBusiness(biz.id)}
                          disabled={!canAfford}
                          className={`px-4 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition cursor-pointer ${
                            canAfford
                              ? 'bg-sky-500 hover:bg-sky-400 text-black'
                              : 'bg-[#2C2F36] text-[#8E9299] cursor-not-allowed'
                          }`}
                        >
                          Acquire Business
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {activeTab === 'DEVELOPMENT' && (
            <div className="space-y-3">
              {myProperties.length === 0 ? (
                <p className="text-xs text-[#8E9299] text-center py-6">
                  You do not own any properties yet. Acquire land first to improve it with development capital.
                </p>
              ) : (
                myProperties.map((prop) => {
                  const canAfford = humanPlayer.walletBalanceSats >= prop.developmentCostSats;
                  return (
                    <div
                      key={prop.id}
                      className="p-4 bg-[#1A1D23] border border-[#2C2F36] rounded flex justify-between items-center"
                    >
                      <div>
                        <h3 className="font-bold text-white text-xs flex items-center">
                          <Hammer className="w-4 h-4 mr-1 text-amber-500" />
                          {prop.name}
                        </h3>
                        <p className="text-[11px] font-mono text-[#8E9299] mt-1">
                          Current Tier: <strong className="text-amber-500">{prop.developmentLevel}</strong> · Productivity Bonus:{' '}
                          <strong className="text-emerald-400">+{((prop.productivityBonus - 1) * 100).toFixed(0)}%</strong>
                        </p>
                      </div>

                      <div className="text-right">
                        <p className="text-xs font-mono font-bold text-white mb-1">
                          Cost: {satsToBtcString(prop.developmentCostSats)}
                        </p>
                        <button
                          onClick={() => onDevelopProperty(prop.id)}
                          disabled={!canAfford}
                          className={`px-4 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition cursor-pointer ${
                            canAfford
                              ? 'bg-emerald-500 hover:bg-emerald-400 text-black'
                              : 'bg-[#2C2F36] text-[#8E9299] cursor-not-allowed'
                          }`}
                        >
                          Upgrade Capital Tier
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
