'use client';

import React from 'react';
import { Player, EconomicState } from '@/types/game';
import { calculateRhinoQuantScore, calculateCAGR } from '@/lib/engine/quant';
import { satsToBtcString, formatSats } from '@/lib/engine/sats';
import { X, Award, Trophy, TrendingUp, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface EndReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  humanPlayer: Player;
  economicState: EconomicState;
}

export const EndReportModal: React.FC<EndReportModalProps> = ({
  isOpen,
  onClose,
  humanPlayer,
  economicState,
}) => {
  if (!isOpen) return null;

  const startingSats = 25_000_000;
  const score = calculateRhinoQuantScore(humanPlayer, startingSats, economicState.turn);
  const cagr = calculateCAGR(startingSats, humanPlayer.netWorthSats, economicState.turn);

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-2xl text-[#F5F2ED] overflow-hidden shadow-2xl flex flex-col">
        {/* HEADER */}
        <div className="p-6 border-b border-[#2C2F36] bg-[#16191E] text-center">
          <Trophy className="w-10 h-10 text-amber-500 mx-auto mb-2" />
          <h2 className="text-xl font-extrabold uppercase tracking-tight text-white">
            RhinoQuant Economic Terminal Report
          </h2>
          <p className="text-xs text-[#8E9299] font-mono mt-1">
            Performance Analysis at Turn {economicState.turn} (Year {economicState.year})
          </p>
        </div>

        {/* COMPOSITE SCORE DISPLAY */}
        <div className="p-6 space-y-6">
          <div className="p-4 bg-[#1A1D23] border border-amber-500/40 rounded text-center">
            <span className="text-[10px] uppercase font-mono tracking-widest text-[#8E9299]">
              Overall RhinoQuant Composite Score
            </span>
            <p className="text-4xl font-mono font-extrabold text-amber-500 my-1">
              {score.totalScore} <span className="text-sm font-normal text-[#8E9299]">/ 100</span>
            </p>
            <p className="text-xs font-mono text-emerald-400">
              CAGR: +{cagr}% Annualized Real Net Worth Growth
            </p>
          </div>

          {/* METRIC BREAKDOWN GRID */}
          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <span className="text-[10px] text-[#8E9299] uppercase">Starting BTC Capital</span>
              <p className="font-bold text-white mt-0.5">{satsToBtcString(startingSats)}</p>
            </div>

            <div className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <span className="text-[10px] text-[#8E9299] uppercase">Ending Net Worth</span>
              <p className="font-bold text-emerald-400 mt-0.5">{satsToBtcString(humanPlayer.netWorthSats)}</p>
            </div>

            <div className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <span className="text-[10px] text-[#8E9299] uppercase">Properties Owned</span>
              <p className="font-bold text-amber-500 mt-0.5">{humanPlayer.stats.propertiesOwnedCount} Properties</p>
            </div>

            <div className="p-3 bg-[#1A1D23] border border-[#2C2F36] rounded">
              <span className="text-[10px] text-[#8E9299] uppercase">Businesses Owned</span>
              <p className="font-bold text-sky-400 mt-0.5">{humanPlayer.stats.businessesOwnedCount} Businesses</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-black font-extrabold uppercase tracking-widest text-xs rounded transition cursor-pointer"
          >
            Close Report & Resume Play
          </button>
        </div>
      </div>
    </div>
  );
};
