'use client';

import React, { useState } from 'react';
import { X, BookOpen, CheckCircle, HelpCircle, Shield, Lightbulb } from 'lucide-react';

interface AcademyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AcademyModal: React.FC<AcademyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-3xl text-[#F5F2ED] overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* HEADER */}
        <div className="p-5 border-b border-[#2C2F36] bg-[#16191E] flex justify-between items-center shrink-0">
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-tight text-white">
                RhinoQuant Academy
              </h2>
              <p className="text-[10px] text-[#8E9299] font-mono">
                Economic Mechanics, Time Preference & Monetary Principles
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#2C2F36] text-[#8E9299] hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* CONTENT */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs leading-relaxed">
          <div className="p-4 bg-[#1A1D23] border border-[#2C2F36] rounded space-y-2">
            <h3 className="font-bold text-amber-500 uppercase tracking-wider text-xs flex items-center">
              <Lightbulb className="w-4 h-4 mr-1.5" />
              1. Money → Saving → Capital → Production → Wealth → Time
            </h3>
            <p className="text-[#8E9299]">
              In a Bitcoin-standard economy, money cannot be printed at zero cost. Savings represent deferred consumption.
              When economic agents save real hard money (BTC), interest rates naturally decline, enabling long-term capital investment
              in factories, infrastructure, and real estate.
            </p>
          </div>

          <div className="p-4 bg-[#1A1D23] border border-[#2C2F36] rounded space-y-2">
            <h3 className="font-bold text-sky-400 uppercase tracking-wider text-xs flex items-center">
              <Shield className="w-4 h-4 mr-1.5" />
              2. Structural Deflation & Productivity
            </h3>
            <p className="text-[#8E9299]">
              Because Bitcoin supply is capped at 21,000,000 BTC, as technology and productivity improve, the output of goods and services expands.
              This causes prices to fall in BTC terms over time. Savers are rewarded with increasing purchasing power without taking unnecessary risk.
            </p>
          </div>

          <div className="p-4 bg-[#1A1D23] border border-[#2C2F36] rounded space-y-2">
            <h3 className="font-bold text-emerald-400 uppercase tracking-wider text-xs flex items-center">
              <HelpCircle className="w-4 h-4 mr-1.5" />
              3. Time Preference & Leverage Risk
            </h3>
            <p className="text-[#8E9299]">
              High time preference leads to over-leveraging and instant gratification. In contrast, low time preference prioritizes capital accumulation,
              sustainable debt levels (LTV &lt; 50%), and resilience against unexpected economic shocks.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
