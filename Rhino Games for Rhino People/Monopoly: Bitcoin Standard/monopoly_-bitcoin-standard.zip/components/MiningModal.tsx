'use client';

import React, { useState } from 'react';
import { Player, MiningFacility, EconomicState, Satoshi } from '@/types/game';
import { satsToBtcString, formatSats } from '@/lib/engine/sats';
import { X, Pickaxe, Cpu, Zap, Activity, Check } from 'lucide-react';

interface MiningModalProps {
  isOpen: boolean;
  onClose: () => void;
  humanPlayer: Player;
  miningFacility: MiningFacility;
  economicState: EconomicState;
  onBuyAsics: (count: number, costSats: Satoshi) => void;
}

export const MiningModal: React.FC<MiningModalProps> = ({
  isOpen,
  onClose,
  humanPlayer,
  miningFacility,
  economicState,
  onBuyAsics,
}) => {
  const [asicQuantity, setAsicQuantity] = useState<number>(5);

  if (!isOpen) return null;
  const costPerAsicSats = 1_500_000; // 0.015 BTC per ASIC
  const totalPurchaseCostSats = asicQuantity * costPerAsicSats;

  const canAfford = humanPlayer.walletBalanceSats >= totalPurchaseCostSats;

  const handleBuy = () => {
    if (canAfford) {
      onBuyAsics(asicQuantity, totalPurchaseCostSats);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#12151A] border border-[#2C2F36] rounded-lg w-full max-w-xl text-[#F5F2ED] overflow-hidden shadow-2xl">
        {/* HEADER */}
        <div className="p-5 border-b border-[#2C2F36] bg-[#16191E] flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Pickaxe className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-tight text-white">
                Satoshi ASIC Mining Datacenter
              </h2>
              <p className="text-[10px] text-[#8E9299] font-mono">
                PoW Hash Rate Economics & Grid Power Optimization
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#2C2F36] text-[#8E9299] hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* FACILITY STATS GRID */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3 bg-[#1A1D23] border border-[#2C2F36] rounded text-xs">
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Active ASICs</span>
              <p className="font-mono font-bold text-sm text-white mt-0.5">
                {miningFacility.asicCount} Units
              </p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Total Hash Rate</span>
              <p className="font-mono font-bold text-sm text-emerald-400 mt-0.5">
                {miningFacility.hashRateTHs} TH/s
              </p>
            </div>
            <div>
              <span className="text-[10px] text-[#8E9299] uppercase">Power Draw</span>
              <p className="font-mono font-bold text-sm text-amber-500 mt-0.5">
                {miningFacility.powerMW.toFixed(2)} MW
              </p>
            </div>
          </div>

          {/* PURCHASE NEW ASICS */}
          <div className="p-4 border border-[#2C2F36] bg-[#16191E] rounded space-y-4">
            <h3 className="text-xs uppercase font-bold text-emerald-400 tracking-wider">
              Expand Datacenter Hash Power
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] uppercase text-[#8E9299] font-mono mb-1">
                  ASIC Miners Quantity ({asicQuantity} Units)
                </label>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={asicQuantity}
                  onChange={(e) => setAsicQuantity(parseInt(e.target.value))}
                  className="w-full accent-emerald-500 bg-[#12151A] rounded h-2 cursor-pointer"
                />
              </div>

              <div className="p-3 bg-[#12151A] border border-[#2C2F36] rounded text-xs font-mono space-y-1">
                <div className="flex justify-between text-[#8E9299]">
                  <span>Capital Expenditure Cost:</span>
                  <span className="text-white font-bold">{satsToBtcString(totalPurchaseCostSats)}</span>
                </div>
                <div className="flex justify-between text-[#8E9299]">
                  <span>Added Hash Power:</span>
                  <span className="text-emerald-400">+{asicQuantity * 120} TH/s</span>
                </div>
              </div>

              <button
                onClick={handleBuy}
                disabled={!canAfford}
                className={`w-full py-2.5 rounded font-extrabold uppercase tracking-wider text-xs transition cursor-pointer ${
                  canAfford
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-black'
                    : 'bg-[#2C2F36] text-[#8E9299] cursor-not-allowed'
                }`}
              >
                Deploy ASIC Rig Fleet
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
