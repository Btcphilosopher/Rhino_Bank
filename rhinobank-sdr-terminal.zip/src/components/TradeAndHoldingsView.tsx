import React, { useState } from 'react';
import { OperatorRole, PlatformStateSnapshot } from '../shared/types';
import { fmtNum, fmtSdr, fmtTs, fmtUsd, shortHash } from './Formatters';

interface TradeAndHoldingsViewProps {
  mode: 'Trade' | 'Holdings';
  state: PlatformStateSnapshot;
  actorRole: OperatorRole;
  busy: boolean;
  onCreateRfq: (payload: { seriesId: string; requesterInvestorId: string; side: 'BUY' | 'SELL'; units: number }) => void;
  onSettleRfq: (payload: { rfqId: string; counterpartyInvestorId: string; bankPaymentRef: string }) => void;
  onExecuteTransfer: (payload: { seriesId: string; fromInvestorId: string; toInvestorId: string; units: number }) => void;
}

export const TradeAndHoldingsView: React.FC<TradeAndHoldingsViewProps> = ({
  mode,
  state,
  busy,
  onCreateRfq,
  onSettleRfq,
  onExecuteTransfer,
}) => {
  const [rfqInvestor, setRfqInvestor] = useState('INV-ZURICH-PEN');
  const [rfqSide, setRfqSide] = useState<'BUY' | 'SELL'>('SELL');
  const [rfqUnits, setRfqUnits] = useState(1000);
  const [counterpartyId, setCounterpartyId] = useState('INV-NORDIC-INS');

  const [txFrom, setTxFrom] = useState('INV-ZURICH-PEN');
  const [txTo, setTxTo] = useState('INV-UK-ASSET');
  const [txUnits, setTxUnits] = useState(500);

  if (mode === 'Trade') {
    return (
      <div className="space-y-8">
        <div className="border-b border-slate-200/10 pb-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
              RhinoBank SDR Markets Terminal
            </h1>
            <p className="text-xs text-[#B6B1A4] mt-1">
              Informational listings are distinct from primary issuance and execution permission. Secondary bank-rail USD cash legs are non-atomic and reconciled explicitly.
            </p>
          </div>
        </div>

        {/* Market Listings */}
        <div className="border border-slate-200/15 bg-[#0D1320]">
          <div className="px-6 py-4 border-b border-slate-200/10">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
              Admitted OTC Listings &amp; Indicative Model vs Dealer Spread
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200/10 text-xs text-[#7E8799]">
                  <th className="py-2.5 px-6 font-medium">Listing / Series</th>
                  <th className="py-2.5 px-4 font-medium">Venue &amp; Admission</th>
                  <th className="py-2.5 px-4 font-medium text-right">Indicative Bid / Ask (% Par)</th>
                  <th className="py-2.5 px-4 font-medium text-right">Model SDR Value</th>
                  <th className="py-2.5 px-6 font-medium text-right">Model USD Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/10 text-xs">
                {state.listings.map((l) => (
                  <tr key={l.listingId} className="hover:bg-[#121A2B]">
                    <td className="py-3 px-6">
                      <div className="font-mono text-[#F4F1EA]">{l.seriesId}</div>
                      <div className="text-[11px] text-[#7E8799]">{l.listingId}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-[#F4F1EA]">{l.venueName}</div>
                      <div className="text-[11px] font-mono text-[#22D3EE]">{l.admissionStatus} · {l.executionPermissionRequired}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#C8A24A] tabular-nums">
                      {l.indicativeBidPctPar.toFixed(2)} / {l.indicativeAskPctPar.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">
                      {fmtSdr(l.indicativeModelSdrValue, 0)}
                    </td>
                    <td className="py-3 px-6 font-mono text-right text-[#F4F1EA] tabular-nums">
                      {fmtUsd(l.indicativeModelUsdValue)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {state.listings[0] && (
            <div className="px-6 py-3 border-t border-slate-200/10 text-xs text-[#7E8799]">
              {state.listings[0].disclaimer}
            </div>
          )}
        </div>

        {/* Dealer RFQ Creation & Dual-Leg Settlement */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
              Request Dealer Firm Quote (RFQ)
            </h2>
            <div className="space-y-3 text-xs">
              <label className="space-y-1 block">
                <span className="text-[#7E8799] block">Requester Investor</span>
                <select
                  value={rfqInvestor}
                  onChange={(e) => setRfqInvestor(e.target.value)}
                  className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 text-[#F4F1EA]"
                >
                  {state.investors.map((i) => (
                    <option key={i.investorId} value={i.investorId}>
                      {i.investorId} ({i.kycStatus})
                    </option>
                  ))}
                </select>
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="space-y-1 block">
                  <span className="text-[#7E8799] block">Side</span>
                  <select
                    value={rfqSide}
                    onChange={(e) => setRfqSide(e.target.value as 'BUY' | 'SELL')}
                    className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
                  >
                    <option value="SELL">SELL</option>
                    <option value="BUY">BUY</option>
                  </select>
                </label>
                <label className="space-y-1 block">
                  <span className="text-[#7E8799] block">Units</span>
                  <input
                    type="number"
                    value={rfqUnits}
                    onChange={(e) => setRfqUnits(Number(e.target.value))}
                    className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
                  />
                </label>
              </div>
              <label className="space-y-1 block">
                <span className="text-[#7E8799] block">Settlement Counterparty</span>
                <select
                  value={counterpartyId}
                  onChange={(e) => setCounterpartyId(e.target.value)}
                  className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 text-[#F4F1EA]"
                >
                  {state.investors.map((i) => (
                    <option key={i.investorId} value={i.investorId}>
                      {i.investorId} ({i.jurisdiction})
                    </option>
                  ))}
                </select>
              </label>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  onCreateRfq({
                    seriesId: 'RB-SDR-2027-A',
                    requesterInvestorId: rfqInvestor,
                    side: rfqSide,
                    units: rfqUnits,
                  })
                }
                className="w-full py-2 text-xs font-medium bg-[#22D3EE] text-[#070B14] hover:bg-[#38BDF8] disabled:opacity-45 cursor-pointer"
              >
                Request Firm Dealer Quote
              </button>
            </div>
          </div>

          <div className="xl:col-span-2 border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
              Dealer Quotes &amp; Secondary Trade Settlement Log
            </h2>
            <div className="space-y-3">
              {state.rfqs.length === 0 && (
                <div className="text-xs text-[#7E8799] py-4">
                  No active RFQs yet. Submit a Dealer RFQ on the left to compare indicative model value vs firm dealer quotation.
                </div>
              )}
              {state.rfqs.map((rfq) => (
                <div key={rfq.rfqId} className="border border-slate-200/10 bg-[#070B14] p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                  <div className="space-y-1">
                    <div className="font-mono text-[#F4F1EA]">
                      {rfq.rfqId} · {rfq.side} {fmtNum(rfq.units)} units · {rfq.requesterInvestorId}
                    </div>
                    <div className="font-mono text-[#B6B1A4]">
                      Model Value: {fmtUsd(rfq.indicativeModelUsd)} · Firm Quote ({rfq.firmQuotePctPar}%): <span className="text-[#C8A24A]">{fmtUsd(rfq.firmQuoteTotalUsd ?? 0)}</span>
                    </div>
                  </div>
                  <div>
                    {rfq.status === 'QUOTED' ? (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() =>
                          onSettleRfq({
                            rfqId: rfq.rfqId,
                            counterpartyInvestorId: counterpartyId,
                            bankPaymentRef: `FED-SEPA-${Date.now().toString().slice(-6)}`,
                          })
                        }
                        className="px-3 py-1.5 border border-[#10B981]/60 text-[#10B981] hover:bg-[#10B981]/10 cursor-pointer"
                      >
                        Confirm Trade &amp; Dual-Leg Settle
                      </button>
                    ) : (
                      <span className="font-mono text-[#10B981]">{rfq.status}</span>
                    )}
                  </div>
                </div>
              ))}

              {state.trades.map((trd) => (
                <div key={trd.tradeId} className="border border-slate-200/10 bg-[#121A2B] p-4 text-xs space-y-1">
                  <div className="flex justify-between font-mono text-[#F4F1EA]">
                    <span>{trd.tradeId} · {trd.sellerInvestorId} → {trd.buyerInvestorId} ({fmtNum(trd.units)} units)</span>
                    <span className="text-[#C8A24A]">{fmtUsd(trd.agreedUsdAmount)}</span>
                  </div>
                  <div className="font-mono text-[#B6B1A4]">
                    Note Leg: {trd.noteTransferStatus} ({shortHash(trd.noteTransferTxHash)}) · Cash Leg: {trd.cashSettlementLegStatus} ({trd.cashPaymentRef})
                  </div>
                  <div className="text-[11px] text-[#7E8799]">{trd.settlementModelNote}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==================== HOLDINGS MODE ====================
  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200/10 pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
            Investor Holdings, Encumbrances &amp; Restricted Transfer Controls
          </h1>
          <p className="text-xs text-[#B6B1A4] mt-1">
            Ownership projections rebuilt from finalised PoS chain events. Private keys or recovery phrases are never collected by the application.
          </p>
        </div>
      </div>

      {/* Holdings Grid */}
      <div className="border border-slate-200/15 bg-[#0D1320]">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200/10 text-xs text-[#7E8799]">
                <th className="py-2.5 px-6 font-medium">Investor &amp; Wallet</th>
                <th className="py-2.5 px-4 font-medium">Series</th>
                <th className="py-2.5 px-4 font-medium text-right">Units</th>
                <th className="py-2.5 px-4 font-medium text-right">SDR Face Value</th>
                <th className="py-2.5 px-4 font-medium text-right">Indicative USD</th>
                <th className="py-2.5 px-4 font-medium">Transfer Status</th>
                <th className="py-2.5 px-6 font-medium text-right">Maturity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/10 text-xs">
              {state.holdings.map((h) => (
                <tr key={h.holdingId} className="hover:bg-[#121A2B]">
                  <td className="py-3 px-6">
                    <div className="text-[#F4F1EA] font-medium">{h.investorName}</div>
                    <div className="font-mono text-[#7E8799]">{h.investorId} · {shortHash(h.walletAddress)}</div>
                  </td>
                  <td className="py-3 px-4 font-mono text-[#22D3EE]">{h.seriesId}</td>
                  <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">{fmtNum(h.units)}</td>
                  <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">{fmtSdr(h.sdrFaceValue, 0)}</td>
                  <td className="py-3 px-4 font-mono text-right text-[#C8A24A] tabular-nums">{fmtUsd(h.indicativeUsdValue)}</td>
                  <td className="py-3 px-4 font-mono text-[#10B981]">
                    {h.transferAvailability} · Enc: {h.encumbrancesUnits}
                  </td>
                  <td className="py-3 px-6 font-mono text-right text-[#B6B1A4]">{h.maturityDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Restricted Transfer Gate & Key Loss Policy */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            Contractual Transfer Execution &amp; Whitelist Gate
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <label className="space-y-1">
              <span className="text-[#7E8799] block">From Investor</span>
              <select
                value={txFrom}
                onChange={(e) => setTxFrom(e.target.value)}
                className="w-full bg-[#070B14] border border-slate-200/20 px-2.5 py-2 text-[#F4F1EA]"
              >
                {state.holdings.map((h) => (
                  <option key={h.holdingId} value={h.investorId}>
                    {h.investorId} ({fmtNum(h.units)})
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">To Recipient (Test Ineligible)</span>
              <select
                value={txTo}
                onChange={(e) => setTxTo(e.target.value)}
                className="w-full bg-[#070B14] border border-slate-200/20 px-2.5 py-2 text-[#F4F1EA]"
              >
                {state.investors.map((inv) => (
                  <option key={inv.investorId} value={inv.investorId}>
                    {inv.investorId} · {inv.kycStatus}
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Units</span>
              <input
                type="number"
                value={txUnits}
                onChange={(e) => setTxUnits(Number(e.target.value))}
                className="w-full bg-[#070B14] border border-slate-200/20 px-2.5 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
          </div>
          <button
            type="button"
            disabled={busy}
            onClick={() =>
              onExecuteTransfer({
                seriesId: 'RB-SDR-2027-A',
                fromInvestorId: txFrom,
                toInvestorId: txTo,
                units: txUnits,
              })
            }
            className="px-4 py-2 text-xs font-medium bg-[#22D3EE] text-[#070B14] hover:bg-[#38BDF8] disabled:opacity-45 cursor-pointer"
          >
            Execute On-Chain Restricted Transfer
          </button>
        </div>

        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3 text-xs">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            Legal Ownership, Custody &amp; Key-Loss Policy
          </h2>
          <p className="text-[#B6B1A4] leading-relaxed">
            Registered institutional notes are NOT anonymous bearer instruments. Transfers require active whitelist compliance (KYC + Jurisdiction). RhinoBank never requests or stores investor private keys or seed phrases.
          </p>
          <p className="text-[#7E8799] leading-relaxed">
            Key-loss recovery follows documented multi-party legal verification: court order or dual-signatory institutional identity attestation, formal freeze of the lost wallet address, and re-issuance to a newly attested whitelisted custody address.
          </p>
        </div>
      </div>

      {/* Acquisition History */}
      <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
        <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
          Latest Acquisition Provenance Records
        </h2>
        <div className="space-y-2 text-xs font-mono">
          {state.holdings.flatMap((h) =>
            h.acquisitionRecords.map((acq) => (
              <div key={acq.acquisitionId} className="flex flex-wrap justify-between gap-2 py-1.5 border-b border-slate-200/10 text-[#B6B1A4]">
                <span>{h.investorId} · {acq.type} · {fmtNum(acq.units)} units</span>
                <span>{fmtUsd(acq.usdEquivalentAtTrade)} · Tx {shortHash(acq.txHash)} · {fmtTs(acq.timestamp)}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
