import React from 'react';
import { PlatformStateSnapshot } from '../shared/types';
import { fmtNum, fmtRate, fmtSdr, fmtTs, fmtUsd, shortHash } from './Formatters';

interface OverviewViewProps {
  state: PlatformStateSnapshot;
  busy: boolean;
  onRunRemainingDemo: () => void;
  onResetDemo: () => void;
  onNavigate: (tab: string) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  state,
  busy,
  onRunRemainingDemo,
  onResetDemo,
  onNavigate,
}) => {
  const primarySeries = state.series[0];
  const latestObs = state.observations.find(
    (o) => o.status === 'PUBLISHED' || o.status === 'CORRECTED' || o.status === 'FALLBACK_USED'
  ) ?? state.observations[0];

  const completedCount = state.demoSteps.filter((s) => s.completed).length;

  return (
    <div className="space-y-8">
      {/* Executive Mandate & Series Snapshot */}
      <div className="border border-slate-200/15 bg-[#0D1320] p-6">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6 pb-6 border-b border-slate-200/10">
          <div className="space-y-2 max-w-3xl">
            <div className="text-xs font-mono text-[#C8A24A] tracking-wide">
              INSTITUTIONAL ISSUANCE &amp; SETTLEMENT TERMINAL · {state.environmentLabel}
            </div>
            <h1 className="text-2xl font-display font-semibold text-[#F4F1EA] tracking-tight">
              {primarySeries?.terms.seriesName ?? 'RhinoBank SDR-Linked Note — Series 2027-A'}
            </h1>
            <p className="text-sm text-[#B6B1A4] leading-relaxed">
              {state.mandatoryDisclaimer} Validates authorised note supply, ownership transitions, and dated oracle commitments on {state.networkName}.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              disabled={busy || completedCount === state.demoSteps.length}
              onClick={onRunRemainingDemo}
              className="px-4 py-2 text-xs font-medium bg-[#22D3EE] text-[#070B14] hover:bg-[#38BDF8] disabled:opacity-45 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {completedCount === state.demoSteps.length
                ? 'All 12 Demo Steps Completed'
                : `Execute Steps ${completedCount + 1}–12 Demonstration`}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={onResetDemo}
              className="px-4 py-2 text-xs font-medium border border-slate-200/20 text-[#F4F1EA] hover:border-slate-200/40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Reset Testnet State
            </button>
          </div>
        </div>

        {/* 4-Column Financial & Finality Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 pt-6">
          <div>
            <div className="text-xs text-[#7E8799]">Outstanding Note Supply</div>
            <div className="mt-1 text-xl font-mono font-semibold text-[#F4F1EA] tabular-nums">
              {fmtNum(primarySeries?.quantities.outstandingUnits ?? 0)} Units
            </div>
            <div className="mt-1 text-xs font-mono text-[#B6B1A4] tabular-nums">
              {fmtSdr((primarySeries?.quantities.outstandingUnits ?? 0) * 1000, 0)} · Cap {fmtNum(primarySeries?.terms.supplyCapUnits ?? 0)}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#7E8799]">Reconstructed SDR Reference</div>
            <div className="mt-1 text-xl font-mono font-semibold text-[#22D3EE] tabular-nums">
              {fmtRate(latestObs?.reconstructedSdrUsd ?? 0)} USD/SDR
            </div>
            <div className="mt-1 text-xs font-mono text-[#B6B1A4]">
              {latestObs?.basketVersionId} · {latestObs?.status}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#7E8799]">PoS Finalised Block Height</div>
            <div className="mt-1 text-xl font-mono font-semibold text-[#F4F1EA] tabular-nums">
              #{fmtNum(state.indexer.finalisedChainBlock)}
            </div>
            <div className="mt-1 text-xs font-mono text-[#B6B1A4] tabular-nums">
              Head #{fmtNum(state.indexer.chainHeadBlock)} · Indexer Lag {state.indexer.lagBlocks} blocks
            </div>
          </div>
          <div>
            <div className="text-xs text-[#7E8799]">Series Lifecycle &amp; Valuation</div>
            <div className="mt-1 text-xl font-mono font-semibold text-[#C8A24A] tabular-nums">
              {fmtUsd(state.treasury.liabilities.totalOutstandingNotesUsd)}
            </div>
            <div className="mt-1 text-xs font-mono text-[#B6B1A4]">
              Stage: {primarySeries?.lifecycleStage} · Coupon {((primarySeries?.terms.couponFormula.annualRateBps ?? 0) / 100).toFixed(2)}%
            </div>
          </div>
        </div>
      </div>

      {/* Separation of Three Responsibilities */}
      <div className="space-y-3">
        <div className="flex items-baseline justify-between">
          <h2 className="text-base font-display font-semibold text-[#F4F1EA]">
            Separation of Institutional Responsibilities
          </h2>
          <span className="text-xs font-mono text-[#7E8799]">
            Consensus validation does not verify off-chain legal enforceability or asset backing
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="border border-slate-200/15 bg-[#0D1320] p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200/10 pb-2">
              <span className="text-sm font-display font-semibold text-[#F4F1EA]">01. Issuer Service</span>
              <span className="text-xs font-mono text-[#C8A24A]">Off-Chain Authority</span>
            </div>
            <p className="text-xs text-[#B6B1A4] leading-relaxed">
              Creates proposed note series, obtains Risk dual-approval signatures, collects bank-rail subscription proceeds, verifies KYC eligibility, and authorises issuance.
            </p>
            <div className="text-xs font-mono text-[#7E8799] pt-1">
              Active Subscriptions: {state.subscriptions.length} · Approved Investors: {state.investors.filter((i) => i.kycStatus === 'APPROVED').length}
            </div>
            <button
              type="button"
              onClick={() => onNavigate('Issue')}
              className="text-xs font-medium text-[#22D3EE] hover:underline cursor-pointer"
            >
              Open Issuance Workflow →
            </button>
          </div>

          <div className="border border-slate-200/15 bg-[#0D1320] p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200/10 pb-2">
              <span className="text-sm font-display font-semibold text-[#F4F1EA]">02. Note Contract</span>
              <span className="text-xs font-mono text-[#22D3EE]">On-Chain State Machine</span>
            </div>
            <p className="text-xs text-[#B6B1A4] leading-relaxed">
              Enforces issuance permissions, supply caps ({fmtNum(primarySeries?.terms.supplyCapUnits ?? 50000)} max), whitelisted ownership balances, transfer lockups, and retirement sequencing.
            </p>
            <div className="text-xs font-mono text-[#7E8799] pt-1">
              Contract: {shortHash(primarySeries?.contractAddress)} · {primarySeries?.contractVersion}
            </div>
            <button
              type="button"
              onClick={() => onNavigate('Notes')}
              className="text-xs font-medium text-[#22D3EE] hover:underline cursor-pointer"
            >
              Inspect Permanent Terms →
            </button>
          </div>

          <div className="border border-slate-200/15 bg-[#0D1320] p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200/10 pb-2">
              <span className="text-sm font-display font-semibold text-[#F4F1EA]">03. Proof-of-Stake Validators</span>
              <span className="text-xs font-mono text-[#F59E0B]">Casper FFG Finality</span>
            </div>
            <p className="text-xs text-[#B6B1A4] leading-relaxed">
              Agree on slot ordering and 2-epoch finality (2/3 stake quorum). RhinoBank runs 1 of 6 nodes (14.23% stake) and cannot unilaterally control consensus.
            </p>
            <div className="text-xs font-mono text-[#7E8799] pt-1">
              Online Stake: {state.validators.filter((v) => v.status === 'ACTIVE_ONLINE').reduce((a, b) => a + b.stakeSharePct, 0).toFixed(2)}% · Quorum 66.67%
            </div>
            <button
              type="button"
              onClick={() => onNavigate('Validators')}
              className="text-xs font-medium text-[#22D3EE] hover:underline cursor-pointer"
            >
              Open Validator Operations →
            </button>
          </div>
        </div>
      </div>

      {/* 12-Step End-to-End Demonstration Ledger */}
      <div className="border border-slate-200/15 bg-[#0D1320]">
        <div className="px-6 py-4 border-b border-slate-200/10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-display font-semibold text-[#F4F1EA]">
              End-to-End Demonstration Ledger (Series 2027-A)
            </h2>
            <p className="text-xs text-[#B6B1A4] mt-0.5">
              12-stage institutional lifecycle from SDR definition through secondary trade, coupon approval, and post-payment unit retirement.
            </p>
          </div>
          <div className="text-xs font-mono text-[#22D3EE] tabular-nums">
            {completedCount} / {state.demoSteps.length} Stages Verified
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200/10 text-xs text-[#7E8799]">
                <th className="py-2.5 px-6 font-medium">Step</th>
                <th className="py-2.5 px-4 font-medium">Lifecycle Milestone</th>
                <th className="py-2.5 px-4 font-medium">Authority Layer</th>
                <th className="py-2.5 px-4 font-medium">Status</th>
                <th className="py-2.5 px-6 font-medium text-right">Cryptographic / Operational Evidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/10 text-xs">
              {state.demoSteps.map((step) => (
                <tr key={step.stepNumber} className="hover:bg-[#121A2B] transition-colors">
                  <td className="py-2.5 px-6 font-mono text-[#7E8799] tabular-nums">
                    {String(step.stepNumber).padStart(2, '0')}
                  </td>
                  <td className="py-2.5 px-4 text-[#F4F1EA] font-medium">{step.title}</td>
                  <td className="py-2.5 px-4 text-[#B6B1A4]">{step.responsibility}</td>
                  <td className="py-2.5 px-4 font-mono">
                    {step.completed ? (
                      <span className="text-[#10B981]">VERIFIED</span>
                    ) : (
                      <span className="text-[#F59E0B]">PENDING EXECUTION</span>
                    )}
                  </td>
                  <td className="py-2.5 px-6 font-mono text-right text-[#B6B1A4]">
                    {step.evidenceRef ?? 'Awaiting execution'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Latest Timestamp Verification Strip */}
      <div className="flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-[#7E8799] border-t border-slate-200/10 pt-4">
        <span>Last Valuation Observation: {fmtTs(state.lastValuationTimestamp)}</span>
        <span>Last Finalised PoS Block: {fmtTs(state.lastChainTimestamp)}</span>
      </div>
    </div>
  );
};
