import React from 'react';
import { PlatformStateSnapshot } from '../shared/types';
import { fmtNum, fmtSdr, fmtTs, fmtUsd, shortHash } from './Formatters';

interface ValidatorsAndTreasuryViewProps {
  mode: 'Validators' | 'Treasury';
  state: PlatformStateSnapshot;
  busy: boolean;
  onToggleValidator: (validatorIndex: number, online: boolean) => void;
  onSlashValidator: (validatorIndex: number, reason: 'DOUBLE_PROPOSAL' | 'SURROUND_VOTE') => void;
  onFinaliseChain: () => void;
  onSimulateReorg: () => void;
  onRebuildIndexer: () => void;
}

export const ValidatorsAndTreasuryView: React.FC<ValidatorsAndTreasuryViewProps> = ({
  mode,
  state,
  busy,
  onToggleValidator,
  onSlashValidator,
  onFinaliseChain,
  onSimulateReorg,
  onRebuildIndexer,
}) => {
  if (mode === 'Validators') {
    const activeStakePct = state.validators
      .filter((v) => v.status === 'ACTIVE_ONLINE')
      .reduce((acc, v) => acc + v.stakeSharePct, 0);
    const hasQuorum = activeStakePct >= 66.67;

    return (
      <div className="space-y-8">
        <div className="border-b border-slate-200/10 pb-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
              Proof-of-Stake Validator Layer &amp; Chain Indexer
            </h1>
            <p className="text-xs text-[#B6B1A4] mt-1">
              {state.networkName} · 32-slot epochs · Casper FFG 2/3 supermajority justification &amp; 2-epoch finality. RhinoBank operates 1 node (14.23% stake) and cannot unilaterally control consensus.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={onFinaliseChain}
              className="px-3 py-1.5 text-xs font-medium bg-[#22D3EE] text-[#070B14] hover:bg-[#38BDF8] cursor-pointer"
            >
              Advance 2 Epochs (Finalise)
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={onSimulateReorg}
              className="px-3 py-1.5 text-xs border border-[#F59E0B]/60 text-[#F59E0B] hover:bg-[#F59E0B]/10 cursor-pointer"
            >
              Simulate Pre-Finality Reorg
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={onRebuildIndexer}
              className="px-3 py-1.5 text-xs border border-slate-200/20 text-[#F4F1EA] hover:border-slate-200/40 cursor-pointer"
            >
              Rebuild Indexer Projections
            </button>
          </div>
        </div>

        {/* Consensus & Indexer Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
          <div className="border border-slate-200/15 bg-[#0D1320] p-5">
            <div className="text-xs text-[#7E8799]">Online Attesting Stake</div>
            <div className={`mt-1 text-xl font-mono font-semibold tabular-nums ${hasQuorum ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
              {activeStakePct.toFixed(2)}%
            </div>
            <div className="mt-1 text-xs font-mono text-[#7E8799]">
              {hasQuorum ? 'Quorum Met (>= 66.67%)' : 'Quorum Lost — Inactivity Leak Risk'}
            </div>
          </div>
          <div className="border border-slate-200/15 bg-[#0D1320] p-5">
            <div className="text-xs text-[#7E8799]">Finalised / Head Block</div>
            <div className="mt-1 text-xl font-mono font-semibold text-[#F4F1EA] tabular-nums">
              #{fmtNum(state.indexer.finalisedChainBlock)} / #{fmtNum(state.indexer.chainHeadBlock)}
            </div>
            <div className="mt-1 text-xs font-mono text-[#7E8799]">
              Indexer Lag: {state.indexer.lagBlocks} blocks · Reorgs: {state.indexer.reorgCount}
            </div>
          </div>
          <div className="border border-slate-200/15 bg-[#0D1320] p-5">
            <div className="text-xs text-[#7E8799]">Indexer Finalised Projection</div>
            <div className="mt-1 text-xl font-mono font-semibold text-[#22D3EE] tabular-nums">
              {fmtNum(state.indexer.projectedTotalOutstandingUnits)} Units
            </div>
            <div className="mt-1 text-xs font-mono text-[#7E8799]">
              Issued {fmtNum(state.indexer.projectedTotalIssuedUnits)} · Retired {fmtNum(state.indexer.projectedTotalRedeemedUnits)}
            </div>
          </div>
          <div className="border border-slate-200/15 bg-[#0D1320] p-5">
            <div className="text-xs text-[#7E8799]">Staking vs Note Collateral Rule</div>
            <div className="mt-1 text-sm font-medium text-[#C8A24A]">
              Strictly Segregated
            </div>
            <div className="mt-1 text-xs text-[#7E8799]">
              Validator ETH bond does NOT insure issuer default.
            </div>
          </div>
        </div>

        {/* Validator Roster Table */}
        <div className="border border-slate-200/15 bg-[#0D1320]">
          <div className="px-6 py-4 border-b border-slate-200/10 flex items-center justify-between">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
              Active Validator Set (Gasper Slashing &amp; Liveness Telemetry)
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200/10 text-xs text-[#7E8799]">
                  <th className="py-2.5 px-6 font-medium">Index / Operator</th>
                  <th className="py-2.5 px-4 font-medium text-right">Bonded ETH</th>
                  <th className="py-2.5 px-4 font-medium text-right">Stake Share</th>
                  <th className="py-2.5 px-4 font-medium text-right">Participation</th>
                  <th className="py-2.5 px-4 font-medium text-right">Rewards / Penalties</th>
                  <th className="py-2.5 px-4 font-medium">Status</th>
                  <th className="py-2.5 px-6 font-medium text-right">Protocol Fault Simulation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/10 text-xs">
                {state.validators.map((v) => (
                  <tr key={v.validatorIndex} className="hover:bg-[#121A2B]">
                    <td className="py-3 px-6">
                      <div className="text-[#F4F1EA] font-medium">
                        #{v.validatorIndex} · {v.operatorName}
                      </div>
                      <div className="font-mono text-[#7E8799]">{v.pubkey} · {v.clientDiversity}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">{fmtNum(v.stakedEth, 2)} ETH</td>
                    <td className="py-3 px-4 font-mono text-right text-[#22D3EE] tabular-nums">{v.stakeSharePct.toFixed(2)}%</td>
                    <td className="py-3 px-4 font-mono text-right text-[#B6B1A4] tabular-nums">
                      {v.participationRatePct.toFixed(1)}% (Missed {v.missedAttestations32Slots})
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#B6B1A4] tabular-nums">
                      +{v.accumulatedRewardsEth.toFixed(4)} / -{v.accumulatedPenaltiesEth.toFixed(4)}
                    </td>
                    <td className="py-3 px-4 font-mono">
                      <span
                        className={
                          v.status === 'ACTIVE_ONLINE'
                            ? 'text-[#10B981]'
                            : v.status === 'INACTIVE_OFFLINE'
                            ? 'text-[#F59E0B]'
                            : 'text-[#EF4444]'
                        }
                      >
                        {v.status}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-right">
                      <div className="inline-flex gap-2">
                        {v.status !== 'SLASHED_EXITING' && (
                          <>
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => onToggleValidator(v.validatorIndex, v.status !== 'ACTIVE_ONLINE')}
                              className="px-2 py-1 border border-slate-200/20 text-[#B6B1A4] hover:text-[#F4F1EA] cursor-pointer"
                            >
                              {v.status === 'ACTIVE_ONLINE' ? 'Take Offline' : 'Bring Online'}
                            </button>
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => onSlashValidator(v.validatorIndex, 'DOUBLE_PROPOSAL')}
                              className="px-2 py-1 border border-[#EF4444]/60 text-[#EF4444] hover:bg-[#EF4444]/10 cursor-pointer"
                            >
                              Slash Double-Sign
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Consensus Blocks & Chain Transactions */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
              Recent Consensus Blocks &amp; Checkpoints
            </h2>
            <div className="space-y-2 max-h-64 overflow-y-auto text-xs font-mono">
              {state.blocks.slice(0, 12).map((b) => (
                <div key={b.blockHash} className="flex items-center justify-between py-1.5 border-b border-slate-200/10">
                  <div>
                    <span className="text-[#F4F1EA]">Block #{b.blockNumber}</span>
                    <span className="text-[#7E8799] ml-2">Epoch {b.epoch} · {b.txHashes.length} txs</span>
                  </div>
                  <span
                    className={
                      b.checkpointStatus === 'FINALISED'
                        ? 'text-[#10B981]'
                        : b.checkpointStatus === 'REORGED'
                        ? 'text-[#EF4444]'
                        : 'text-[#F59E0B]'
                    }
                  >
                    {b.checkpointStatus}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
              On-Chain Transaction Ledger
            </h2>
            <div className="space-y-2 max-h-64 overflow-y-auto text-xs">
              {state.transactions.slice(0, 12).map((tx) => (
                <div key={tx.txHash} className="py-1.5 border-b border-slate-200/10 space-y-0.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-[#22D3EE]">{tx.txType}</span>
                    <span className={tx.status === 'FINALISED' ? 'text-[#10B981]' : 'text-[#F59E0B]'}>
                      {tx.status}
                    </span>
                  </div>
                  <div className="text-[#B6B1A4]">{tx.payloadSummary}</div>
                  <div className="font-mono text-[11px] text-[#7E8799]">
                    {shortHash(tx.txHash)} · Block #{tx.blockNumber ?? '—'} · Signer {tx.signerKeyId}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==================== TREASURY & BACKING MODE ====================
  const t = state.treasury;
  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200/10 pb-4">
        <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
          Treasury, Segregated Accounts &amp; Asset-Liability Backing View
        </h1>
        <p className="text-xs text-[#B6B1A4] mt-1">
          {t.backingClassification} Valuation Date: <span className="font-mono text-[#22D3EE]">{fmtTs(t.valuationDate)}</span>
        </p>
      </div>

      {/* Liability Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
        <div className="border border-slate-200/15 bg-[#0D1320] p-5">
          <div className="text-xs text-[#7E8799]">Outstanding Note Liability (SDR)</div>
          <div className="mt-1 text-xl font-mono font-semibold text-[#F4F1EA] tabular-nums">
            {fmtSdr(t.liabilities.totalOutstandingNotesSdr, 0)}
          </div>
          <div className="mt-1 text-xs font-mono text-[#7E8799]">Private Issuer Liability</div>
        </div>
        <div className="border border-slate-200/15 bg-[#0D1320] p-5">
          <div className="text-xs text-[#7E8799]">Outstanding Liability (USD Eq.)</div>
          <div className="mt-1 text-xl font-mono font-semibold text-[#C8A24A] tabular-nums">
            {fmtUsd(t.liabilities.totalOutstandingNotesUsd)}
          </div>
          <div className="mt-1 text-xs font-mono text-[#7E8799]">Accrued Coupons: {fmtUsd(t.liabilities.accruedCouponsUsd)}</div>
        </div>
        <div className="border border-slate-200/15 bg-[#0D1320] p-5">
          <div className="text-xs text-[#7E8799]">Operationally Earmarked Liquidity</div>
          <div className="mt-1 text-xl font-mono font-semibold text-[#22D3EE] tabular-nums">
            {fmtUsd(t.accounts.find((a) => a.category === 'OPERATIONALLY_EARMARKED_LIQUIDITY')?.balanceUsd ?? 0)}
          </div>
          <div className="mt-1 text-xs text-[#7E8799]">FX Replicating Portfolio (Not Official SDRs)</div>
        </div>
        <div className="border border-slate-200/15 bg-[#0D1320] p-5">
          <div className="text-xs text-[#7E8799]">Verification &amp; Audit Scope</div>
          <div className="mt-1 text-xs text-[#F59E0B] leading-relaxed">
            {t.verificationScope}
          </div>
        </div>
      </div>

      {/* Account Segregation Table */}
      <div className="border border-slate-200/15 bg-[#0D1320]">
        <div className="px-6 py-4 border-b border-slate-200/10">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
            Account Segregation (Subscription Proceeds, Collateral, Issuer Capital &amp; Separate Validator Stake)
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200/10 text-xs text-[#7E8799]">
                <th className="py-2.5 px-6 font-medium">Account / Category</th>
                <th className="py-2.5 px-4 font-medium">Legal &amp; Operational Ringfence</th>
                <th className="py-2.5 px-4 font-medium text-right">Balance (USD)</th>
                <th className="py-2.5 px-6 font-medium text-right">Encumbered (USD)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/10 text-xs">
              {t.accounts.map((acc) => (
                <tr key={acc.accountId} className="hover:bg-[#121A2B]">
                  <td className="py-3 px-6">
                    <div className="font-mono text-[#F4F1EA]">{acc.accountId} · {acc.category}</div>
                    <div className="text-[#7E8799] mt-0.5">{acc.description}</div>
                  </td>
                  <td className="py-3 px-4 text-[#B6B1A4]">{acc.legalRingfence}</td>
                  <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">{fmtUsd(acc.balanceUsd)}</td>
                  <td className="py-3 px-6 font-mono text-right text-[#F59E0B] tabular-nums">{fmtUsd(acc.encumberedUsd)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Replicating FX Portfolio, Hedges & Maturity Mismatch */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            SDR-Replicating Currency Holdings (Private Liquidity — Not IMF SDRs)
          </h2>
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200/10 text-[#7E8799]">
                <th className="py-2 font-medium">Currency</th>
                <th className="py-2 font-medium text-right">Native Units</th>
                <th className="py-2 font-medium text-right">USD Equivalent</th>
                <th className="py-2 font-medium text-right">Weight</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/10 font-mono">
              {t.currencyHoldings.map((ch) => (
                <tr key={ch.currency}>
                  <td className="py-2 text-[#F4F1EA]">{ch.currency}</td>
                  <td className="py-2 text-right text-[#B6B1A4] tabular-nums">{fmtNum(ch.amount, 2)}</td>
                  <td className="py-2 text-right text-[#F4F1EA] tabular-nums">{fmtUsd(ch.usdEquivalent)}</td>
                  <td className="py-2 text-right text-[#22D3EE] tabular-nums">{ch.sdrReplicatingWeightPct.toFixed(2)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            Hedging Counterparty Exposure &amp; Maturity Gap
          </h2>
          <div className="space-y-2 text-xs">
            {t.hedgingPositions.map((h) => (
              <div key={h.hedgeId} className="flex justify-between py-1.5 border-b border-slate-200/10">
                <div>
                  <div className="text-[#F4F1EA]">{h.instrument}</div>
                  <div className="font-mono text-[#7E8799]">{h.counterparty} · Mat {h.maturityDate}</div>
                </div>
                <div className="text-right font-mono">
                  <div className="text-[#F4F1EA]">{fmtUsd(h.notionalUsd)}</div>
                  <div className={h.mtmUsd >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                    MTM {fmtUsd(h.mtmUsd)}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="pt-2">
            <div className="text-xs font-medium text-[#7E8799] mb-2">Maturity Mismatch Profile</div>
            {t.maturityProfile.map((m) => (
              <div key={m.bucket} className="flex justify-between text-xs font-mono py-1 border-b border-slate-200/10">
                <span className="text-[#B6B1A4]">{m.bucket}</span>
                <span className={m.netGapUsd >= 0 ? 'text-[#10B981]' : 'text-[#F59E0B]'}>
                  Gap {fmtUsd(m.netGapUsd)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
