import React, { useState } from 'react';
import { OperatorRole, PlatformStateSnapshot } from '../shared/types';
import { fmtRate, fmtTs, fmtUsd, shortHash } from './Formatters';

interface SdrReferenceViewProps {
  state: PlatformStateSnapshot;
  actorRole: OperatorRole;
  busy: boolean;
  onPublishObservation: (payload: {
    quotes: { USD: number; EUR: number; CNY: number; JPY: number; GBP: number };
    effectiveTime: string;
    secondaryBenchmarkSdrUsd?: number;
    supersedesObservationId?: string;
    forceFallback?: boolean;
  }) => void;
}

export const SdrReferenceView: React.FC<SdrReferenceViewProps> = ({
  state,
  actorRole,
  busy,
  onPublishObservation,
}) => {
  const basket = state.basketDefinition;
  const latestObs = state.observations.find(
    (o) => o.status === 'PUBLISHED' || o.status === 'CORRECTED' || o.status === 'FALLBACK_USED'
  ) ?? state.observations[0];
  const primarySeries = state.series[0];

  const [eurRate, setEurRate] = useState(1.0872);
  const [cnyRate, setCnyRate] = useState(7.168);
  const [jpyRate, setJpyRate] = useState(152.65);
  const [gbpRate, setGbpRate] = useState(1.2745);
  const [simulateStale, setSimulateStale] = useState(false);
  const [simulateDisagreement, setSimulateDisagreement] = useState(false);
  const [applyFallbackOnStale, setApplyFallbackOnStale] = useState(false);

  const livePreviewSdrUsd =
    0.57813 * 1.0 +
    0.37379 * eurRate +
    1.0993 / cnyRate +
    13.452 / jpyRate +
    0.08087 * gbpRate;

  const handlePublish = () => {
    const effectiveTime = simulateStale
      ? new Date(Date.now() - 48 * 3600 * 1000).toISOString() // >24h old -> stale
      : new Date(Date.now() - 60 * 1000).toISOString();

    const secondaryBenchmarkSdrUsd = simulateDisagreement
      ? Number((livePreviewSdrUsd * 1.0045).toFixed(6)) // 45 bps disagreement > 15 bps cap
      : undefined;

    onPublishObservation({
      quotes: { USD: 1.0, EUR: eurRate, CNY: cnyRate, JPY: jpyRate, GBP: gbpRate },
      effectiveTime,
      secondaryBenchmarkSdrUsd,
      forceFallback: simulateStale && applyFallbackOnStale,
    });
  };

  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200/10 pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
            SDR Reference Methodology &amp; Authenticated Oracle Service
          </h1>
          <p className="text-xs text-[#B6B1A4] mt-1">
            {basket.methodologyName} ({basket.imfRuleReference}). Proof-of-stake consensus verifies oracle transaction authorisation, not external FX accuracy.
          </p>
        </div>
        <div className="text-xs font-mono text-[#7E8799]">
          Basket Version: <span className="text-[#22D3EE]">{basket.basketVersionId}</span>
        </div>
      </div>

      {/* 4-Way Valuation Distinction */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
        <div className="border border-slate-200/15 bg-[#0D1320] p-5">
          <div className="text-xs text-[#7E8799]">01. Official Published SDR Value</div>
          <div className="mt-1 text-xl font-mono font-semibold text-[#F4F1EA] tabular-nums">
            {fmtRate(latestObs?.officialPublishedSdrUsd ?? 0)} USD
          </div>
          <div className="mt-1 text-xs font-mono text-[#7E8799]">IMF Rule O-1 Daily Fixing</div>
        </div>
        <div className="border border-slate-200/15 bg-[#0D1320] p-5">
          <div className="text-xs text-[#7E8799]">02. Independently Reconstructed</div>
          <div className="mt-1 text-xl font-mono font-semibold text-[#22D3EE] tabular-nums">
            {fmtRate(latestObs?.reconstructedSdrUsd ?? 0)} USD
          </div>
          <div className="mt-1 text-xs font-mono text-[#7E8799]">V_USD = sum(a_i * r_i) · 6 decimals</div>
        </div>
        <div className="border border-slate-200/15 bg-[#0D1320] p-5">
          <div className="text-xs text-[#7E8799]">03. Intraday Indicative Estimate</div>
          <div className="mt-1 text-xl font-mono font-semibold text-[#F59E0B] tabular-nums">
            {fmtRate(latestObs?.intradayIndicativeSdrUsd ?? 0)} USD
          </div>
          <div className="mt-1 text-xs font-mono text-[#7E8799]">Non-binding spot interpolation</div>
        </div>
        <div className="border border-slate-200/15 bg-[#0D1320] p-5">
          <div className="text-xs text-[#7E8799]">04. Private Note Market Value (1 Unit)</div>
          <div className="mt-1 text-xl font-mono font-semibold text-[#C8A24A] tabular-nums">
            {fmtUsd(1000 * (latestObs?.reconstructedSdrUsd ?? 0) * ((primarySeries?.privateNoteMarketPricePctPar ?? 99.85) / 100))}
          </div>
          <div className="mt-1 text-xs font-mono text-[#7E8799]">
            {primarySeries?.privateNoteMarketPricePctPar ?? 99.85}% of 1,000 SDR Par
          </div>
        </div>
      </div>

      {/* IMF Rule O-1 Basket Formula Reconstruction Table */}
      <div className="border border-slate-200/15 bg-[#0D1320]">
        <div className="px-6 py-4 border-b border-slate-200/10 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
            Basket Decomposition ({latestObs?.observationId})
          </h2>
          <span className="text-xs font-mono text-[#B6B1A4]">
            Effective {fmtTs(latestObs?.effectiveTime)} · Retrieved {fmtTs(latestObs?.retrievalTime)}
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200/10 text-xs text-[#7E8799]">
                <th className="py-2.5 px-6 font-medium">Currency</th>
                <th className="py-2.5 px-4 font-medium text-right">Fixed Amount (a_i)</th>
                <th className="py-2.5 px-4 font-medium">Quote Convention</th>
                <th className="py-2.5 px-4 font-medium text-right">Market Quote</th>
                <th className="py-2.5 px-4 font-medium text-right">Oriented Rate (r_i USD)</th>
                <th className="py-2.5 px-4 font-medium text-right">USD Contribution</th>
                <th className="py-2.5 px-6 font-medium text-right">Effective Weight</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/10 text-xs">
              {basket.currencies.map((ccy) => {
                const comp = latestObs?.components.find((c) => c.currency === ccy.currency);
                return (
                  <tr key={ccy.currency} className="hover:bg-[#121A2B]">
                    <td className="py-3 px-6">
                      <span className="font-mono font-semibold text-[#F4F1EA]">{ccy.currency}</span>
                      <span className="text-[#7E8799] ml-2">{ccy.name}</span>
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">
                      {ccy.fixedAmount}
                    </td>
                    <td className="py-3 px-4 font-mono text-[#B6B1A4]">
                      {ccy.quoteConvention === 'DIRECT_USD_PER_CCY' ? 'Direct (USD/CCY)' : 'Inverted (1 / CCY per USD)'}
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">
                      {comp?.quotedRate.toFixed(4)}
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#22D3EE] tabular-nums">
                      {comp?.usdPerUnit.toFixed(6)}
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">
                      ${comp?.usdContribution.toFixed(6)}
                    </td>
                    <td className="py-3 px-6 font-mono text-right text-[#B6B1A4] tabular-nums">
                      {comp?.effectiveWeightPct.toFixed(2)}% (Target {ccy.targetWeightPct}%)
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Oracle Adapter Publisher & Fault Controls */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200/10 pb-2">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
              Authenticated Oracle Adapter Publication (Requires ORACLE_OPERATOR)
            </h2>
            <span className="text-xs font-mono text-[#22D3EE]">Role: {actorRole}</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <label className="space-y-1">
              <span className="text-[#7E8799] block">EUR (USD/EUR)</span>
              <input
                type="number"
                step="0.0001"
                value={eurRate}
                onChange={(e) => setEurRate(Number(e.target.value))}
                className="w-full bg-[#070B14] border border-slate-200/20 px-2.5 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">CNY (CNY/USD)</span>
              <input
                type="number"
                step="0.001"
                value={cnyRate}
                onChange={(e) => setCnyRate(Number(e.target.value))}
                className="w-full bg-[#070B14] border border-slate-200/20 px-2.5 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">JPY (JPY/USD)</span>
              <input
                type="number"
                step="0.05"
                value={jpyRate}
                onChange={(e) => setJpyRate(Number(e.target.value))}
                className="w-full bg-[#070B14] border border-slate-200/20 px-2.5 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">GBP (USD/GBP)</span>
              <input
                type="number"
                step="0.0001"
                value={gbpRate}
                onChange={(e) => setGbpRate(Number(e.target.value))}
                className="w-full bg-[#070B14] border border-slate-200/20 px-2.5 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
          </div>

          <div className="flex flex-wrap gap-4 text-xs text-[#B6B1A4] pt-1">
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={simulateStale} onChange={(e) => setSimulateStale(e.target.checked)} />
              <span>Simulate Stale Feed (&gt;24h old)</span>
            </label>
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={applyFallbackOnStale} onChange={(e) => setApplyFallbackOnStale(e.target.checked)} />
              <span>Apply Contractual Fallback §4.3</span>
            </label>
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={simulateDisagreement} onChange={(e) => setSimulateDisagreement(e.target.checked)} />
              <span>Simulate Source Disagreement (&gt;15 bps)</span>
            </label>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-200/10">
            <div className="text-xs font-mono text-[#B6B1A4]">
              Preview V_USD: <span className="text-[#22D3EE]">{livePreviewSdrUsd.toFixed(6)}</span>
            </div>
            <button
              type="button"
              disabled={busy}
              onClick={handlePublish}
              className="px-4 py-2 text-xs font-medium bg-[#22D3EE] text-[#070B14] hover:bg-[#38BDF8] disabled:opacity-45 cursor-pointer"
            >
              Sign &amp; Publish SDR Observation
            </button>
          </div>
        </div>

        {/* Historical Observations Log */}
        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            Dated Oracle Observation Registry
          </h2>
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {state.observations.map((obs) => (
              <div key={obs.observationId} className="border border-slate-200/10 bg-[#070B14] p-3 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[#F4F1EA] font-medium">{obs.observationId}</span>
                  <span
                    className={`font-mono ${
                      obs.status === 'REJECTED_STALE'
                        ? 'text-[#EF4444]'
                        : obs.status === 'DISAGREEMENT_FLAGGED' || obs.status === 'FALLBACK_USED'
                        ? 'text-[#F59E0B]'
                        : 'text-[#10B981]'
                    }`}
                  >
                    {obs.status}
                  </span>
                </div>
                <div className="flex items-center justify-between font-mono text-[#B6B1A4]">
                  <span>Reconstructed: {fmtRate(obs.reconstructedSdrUsd)} USD/SDR</span>
                  <span>Spread: {obs.spreadBpsVsSecondary} bps</span>
                </div>
                <div className="text-[11px] font-mono text-[#7E8799]">
                  Signer {obs.oracleSignerKeyId} · Hash {shortHash(obs.payloadHash)} · Chain {obs.chainFinalised ? 'Finalised' : 'Not On-Chain'}
                </div>
                {obs.fallbackMethod && (
                  <div className="text-[11px] text-[#F59E0B]">{obs.fallbackMethod}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
