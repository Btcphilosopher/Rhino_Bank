import React, { useState } from 'react';
import { OperatorRole, PlatformStateSnapshot } from '../shared/types';
import { fmtNum, fmtRate, fmtSdr, fmtTs, fmtUsd, shortHash } from './Formatters';

interface NotesAndIssueViewProps {
  mode: 'Notes' | 'Issue';
  state: PlatformStateSnapshot;
  actorRole: OperatorRole;
  busy: boolean;
  onCreateSeries: (payload: {
    seriesId: string;
    seriesName: string;
    supplyCapUnits: number;
    annualRateBps: number;
    maturityDate: string;
    obligationNature: 'PRIVATE_UNSECURED_SENIOR_NOTE' | 'PRIVATE_COLLATERALISED_NOTE';
  }) => void;
  onAdvanceStage: (seriesId: string, targetStage: string) => void;
  onSubmitSubscription: (payload: {
    idempotencyKey: string;
    seriesId: string;
    investorId: string;
    requestedUnits: number;
  }) => void;
  onFundSubscription: (payload: {
    subscriptionId: string;
    fundedCashAmountUsd: number;
    settlementEvidenceRef: string;
    simulateFailure: boolean;
  }) => void;
  onIssueSubscription: (subscriptionId: string, idempotencyKey: string) => void;
}

export const NotesAndIssueView: React.FC<NotesAndIssueViewProps> = ({
  mode,
  state,
  actorRole,
  busy,
  onCreateSeries,
  onAdvanceStage,
  onSubmitSubscription,
  onFundSubscription,
  onIssueSubscription,
}) => {
  const [selectedSeriesId, setSelectedSeriesId] = useState(state.series[0]?.seriesId ?? 'RB-SDR-2027-A');
  const activeSeries = state.series.find((s) => s.seriesId === selectedSeriesId) ?? state.series[0];
  const latestObs = state.observations.find((o) => o.observationId === activeSeries?.latestObservationId) ?? state.observations[0];

  // Draft Series Form State
  const [newSeriesId, setNewSeriesId] = useState('RB-SDR-2027-B');
  const [newSeriesName, setNewSeriesName] = useState('RhinoBank SDR-Linked Note — Series 2027-B');
  const [supplyCap, setSupplyCap] = useState(25000);
  const [rateBps, setRateBps] = useState(450);
  const [maturityDate, setMaturityDate] = useState('2027-12-31');
  const [obligationNature, setObligationNature] = useState<'PRIVATE_UNSECURED_SENIOR_NOTE' | 'PRIVATE_COLLATERALISED_NOTE'>('PRIVATE_UNSECURED_SENIOR_NOTE');

  // Subscription Form State
  const [subInvestorId, setSubInvestorId] = useState('INV-NORDIC-INS');
  const [subUnits, setSubUnits] = useState(1500);
  const [subIdemKey, setSubIdemKey] = useState(`IDEM-SUB-${Date.now().toString().slice(-5)}`);

  if (mode === 'Notes' && activeSeries) {
    const q = activeSeries.quantities;
    return (
      <div className="space-y-8">
        {/* Series Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200/10 pb-4">
          <div>
            <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
              Versioned Note Schema &amp; Contractual Terms
            </h1>
            <p className="text-xs text-[#B6B1A4] mt-1">
              Permanent contractual rights are cryptographically committed and separated from dated SDR observations.
            </p>
          </div>
          <div className="flex items-center gap-2">
            {state.series.map((s) => (
              <button
                key={s.seriesId}
                type="button"
                onClick={() => setSelectedSeriesId(s.seriesId)}
                className={`px-3 py-1.5 text-xs font-mono border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  s.seriesId === activeSeries.seriesId
                    ? 'border-[#22D3EE] text-[#22D3EE] bg-[#121A2B]'
                    : 'border-slate-200/15 text-[#B6B1A4] hover:text-[#F4F1EA]'
                }`}
              >
                {s.seriesId}
              </button>
            ))}
          </div>
        </div>

        {/* Separated Supply Accounting */}
        <div className="border border-slate-200/15 bg-[#0D1320] p-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200/10">
            <span className="text-sm font-display font-semibold text-[#F4F1EA]">
              Quantity &amp; Supply Separation (1 Unit = {fmtSdr(activeSeries.terms.unitParSdr, 0)} Face Value)
            </span>
            <span className="text-xs font-mono text-[#C8A24A]">
              Lifecycle Stage: {activeSeries.lifecycleStage}
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6 pt-5">
            {[
              ['Authorised', q.authorisedUnits],
              ['Subscribed', q.subscribedUnits],
              ['Funded', q.fundedUnits],
              ['Issued (Minted)', q.issuedUnits],
              ['Outstanding', q.outstandingUnits],
              ['Redeemed / Retired', q.redeemedUnits],
            ].map(([label, val]) => (
              <div key={String(label)}>
                <div className="text-xs text-[#7E8799]">{label}</div>
                <div className="mt-1 text-lg font-mono font-semibold text-[#F4F1EA] tabular-nums">
                  {fmtNum(Number(val))}
                </div>
                <div className="text-xs font-mono text-[#7E8799] tabular-nums">
                  {fmtSdr(Number(val) * activeSeries.terms.unitParSdr, 0)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Permanent Terms vs Dated Observation Split */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2 border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200/10 pb-3">
              <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
                Permanent Contractual Terms (Schema {activeSeries.terms.schemaVersion})
              </h2>
              <span className="text-xs font-mono text-[#7E8799]">
                Contract {activeSeries.contractVersion}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Series &amp; Instrument ID</span>
                <span className="font-mono text-[#F4F1EA]">{activeSeries.terms.seriesId} / {activeSeries.terms.instrumentId}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Simulated ISIN</span>
                <span className="font-mono text-[#F4F1EA]">{activeSeries.terms.isinSimulated}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Issuer Legal Entity</span>
                <span className="text-[#F4F1EA] text-right">{activeSeries.terms.issuerIdentity.legalName}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Issuer LEI &amp; Jurisdiction</span>
                <span className="font-mono text-[#F4F1EA]">{activeSeries.terms.issuerIdentity.lei}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Issue / Maturity Dates</span>
                <span className="font-mono text-[#F4F1EA]">{activeSeries.terms.issueDate} → {activeSeries.terms.maturityDate}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Principal Denomination</span>
                <span className="font-mono text-[#F4F1EA]">{fmtSdr(activeSeries.terms.principalDenominationSdr, 0)} per unit</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Coupon Formula</span>
                <span className="font-mono text-[#F4F1EA]">
                  {(activeSeries.terms.couponFormula.annualRateBps / 100).toFixed(2)}% p.a. ({activeSeries.terms.couponFormula.dayCountConvention} · {activeSeries.terms.couponFormula.observationSchedule})
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Sub / Settlement Currency</span>
                <span className="font-mono text-[#F4F1EA]">
                  {activeSeries.terms.subscriptionCurrency} / {activeSeries.terms.settlementCurrency}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">SDR Basket Definition</span>
                <span className="font-mono text-[#22D3EE]">{activeSeries.terms.basketVersionId}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-200/10">
                <span className="text-[#7E8799]">Redemption Method</span>
                <span className="font-mono text-[#F4F1EA]">Cash USD Eq. at Final Observation</span>
              </div>
            </div>

            <div className="space-y-2 pt-2 text-xs">
              <div>
                <span className="text-[#7E8799]">FX &amp; Valuation Policy: </span>
                <span className="text-[#B6B1A4]">{activeSeries.terms.fxConversionAndRoundingRules} · {activeSeries.terms.valuationSourcePolicy}</span>
              </div>
              <div>
                <span className="text-[#7E8799]">Transfer Restrictions &amp; Eligibility: </span>
                <span className="text-[#B6B1A4]">{activeSeries.terms.investorEligibilityPolicy} · Whitelist [{activeSeries.terms.transferRestrictions.jurisdictionWhitelist.join(', ')}]</span>
              </div>
              <div>
                <span className="text-[#7E8799]">Ranking &amp; Collateral Terms: </span>
                <span className="text-[#F4F1EA]">{activeSeries.terms.rankingAndCollateralTerms}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Commitments, Signatures, & Dated Observation Link */}
          <div className="space-y-6">
            <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
              <h3 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
                Cryptographic Commitments &amp; Approvals
              </h3>
              <div className="text-xs space-y-2">
                <div>
                  <div className="text-[#7E8799]">Approved Term-Sheet Hash (On-Chain)</div>
                  <div className="font-mono text-[#22D3EE] break-all mt-0.5">{activeSeries.terms.termSheetCommitmentHash}</div>
                </div>
                <div>
                  <div className="text-[#7E8799]">Issuer Primary Signer</div>
                  <div className="font-mono text-[#F4F1EA]">{activeSeries.issuanceApprovalRefs.issuerSignerKeyId}</div>
                </div>
                <div>
                  <div className="text-[#7E8799]">Dual Approval (Risk / Compliance)</div>
                  <div className="font-mono text-[#F4F1EA]">
                    {activeSeries.issuanceApprovalRefs.dualApproverKeyId ?? 'Pending Risk Countersignature'}
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-200/10 text-[#7E8799]">
                  Governing documents (off-chain access-controlled): hash proves byte correspondence upon verification; off-chain availability requires object-storage SLA.
                </div>
                {activeSeries.terms.governingDocumentRefs.map((doc) => (
                  <div key={doc.title} className="pt-1">
                    <div className="text-[#F4F1EA]">{doc.title}</div>
                    <div className="font-mono text-[#7E8799]">{doc.uri} · {shortHash(doc.sha256)}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
              <h3 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
                Latest Linked Dated Observation
              </h3>
              {latestObs && (
                <div className="text-xs space-y-2">
                  <div className="flex justify-between">
                    <span className="text-[#7E8799]">Observation ID</span>
                    <span className="font-mono text-[#22D3EE]">{latestObs.observationId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#7E8799]">Effective Time</span>
                    <span className="font-mono text-[#F4F1EA]">{fmtTs(latestObs.effectiveTime)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#7E8799]">Reconstructed Value</span>
                    <span className="font-mono text-[#F4F1EA] tabular-nums">{fmtRate(latestObs.reconstructedSdrUsd)} USD/SDR</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#7E8799]">Unit Par Equivalent</span>
                    <span className="font-mono text-[#C8A24A] tabular-nums">{fmtUsd(1000 * latestObs.reconstructedSdrUsd)}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==================== ISSUE WORKFLOW MODE ====================
  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200/10 pb-4">
        <div>
          <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
            Issuance Workflow &amp; Idempotent Subscription Processing
          </h1>
          <p className="text-xs text-[#B6B1A4] mt-1">
            Draft → Reviewed → Approved → Subscription Open → Allocated → Funded → Authorised for Issuance → Issued. Active role: <span className="font-mono text-[#22D3EE]">{actorRole}</span>
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Panel 1: Create New Proposed Note Series */}
        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            01. Propose New Note Series (Requires ISSUER_OFFICER)
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Series Identifier</span>
              <input
                value={newSeriesId}
                onChange={(e) => setNewSeriesId(e.target.value)}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Supply Cap (Units · 1,000 SDR/unit)</span>
              <input
                type="number"
                value={supplyCap}
                onChange={(e) => setSupplyCap(Number(e.target.value))}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1 sm:col-span-2">
              <span className="text-[#7E8799] block">Series Name</span>
              <input
                value={newSeriesName}
                onChange={(e) => setNewSeriesName(e.target.value)}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Coupon Rate (bps)</span>
              <input
                type="number"
                value={rateBps}
                onChange={(e) => setRateBps(Number(e.target.value))}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Maturity Date</span>
              <input
                type="date"
                value={maturityDate}
                onChange={(e) => setMaturityDate(e.target.value)}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1 sm:col-span-2">
              <span className="text-[#7E8799] block">Obligation Ranking</span>
              <select
                value={obligationNature}
                onChange={(e) => setObligationNature(e.target.value as 'PRIVATE_UNSECURED_SENIOR_NOTE' | 'PRIVATE_COLLATERALISED_NOTE')}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 text-[#F4F1EA]"
              >
                <option value="PRIVATE_UNSECURED_SENIOR_NOTE">Private Unsecured Senior Note</option>
                <option value="PRIVATE_COLLATERALISED_NOTE">Private Collateralised Note</option>
              </select>
            </label>
          </div>
          <button
            type="button"
            disabled={busy}
            onClick={() =>
              onCreateSeries({
                seriesId: newSeriesId,
                seriesName: newSeriesName,
                supplyCapUnits: supplyCap,
                annualRateBps: rateBps,
                maturityDate,
                obligationNature,
              })
            }
            className="px-4 py-2 text-xs font-medium bg-[#22D3EE] text-[#070B14] hover:bg-[#38BDF8] disabled:opacity-45 cursor-pointer"
          >
            Create Draft Note Series
          </button>

          {/* Series Stage Transition Controls */}
          <div className="pt-4 border-t border-slate-200/10 space-y-3">
            <div className="text-xs font-medium text-[#F4F1EA]">Series Approval Gateways</div>
            {state.series.map((s) => (
              <div key={s.seriesId} className="flex flex-wrap items-center justify-between gap-2 py-2 border-b border-slate-200/10 text-xs">
                <div>
                  <span className="font-mono text-[#F4F1EA]">{s.seriesId}</span>
                  <span className="text-[#7E8799] mx-2">·</span>
                  <span className="font-mono text-[#F59E0B]">{s.lifecycleStage}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {s.lifecycleStage === 'Draft' && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => onAdvanceStage(s.seriesId, 'Reviewed')}
                      className="px-2.5 py-1 border border-[#F59E0B]/50 text-[#F59E0B] hover:bg-[#F59E0B]/10 cursor-pointer"
                    >
                      Mark Reviewed (Risk)
                    </button>
                  )}
                  {s.lifecycleStage === 'Reviewed' && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => onAdvanceStage(s.seriesId, 'Approved')}
                      className="px-2.5 py-1 border border-[#22D3EE]/60 text-[#22D3EE] hover:bg-[#22D3EE]/10 cursor-pointer"
                    >
                      Dual-Approve &amp; Commit
                    </button>
                  )}
                  {s.lifecycleStage === 'Approved' && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => onAdvanceStage(s.seriesId, 'Subscription Open')}
                      className="px-2.5 py-1 border border-[#10B981]/60 text-[#10B981] hover:bg-[#10B981]/10 cursor-pointer"
                    >
                      Open Subscription
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Panel 2: Submit Subscription Order */}
        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            02. Receive &amp; Allocate Subscription Order (Idempotent)
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Target Note Series</span>
              <select
                value={selectedSeriesId}
                onChange={(e) => setSelectedSeriesId(e.target.value)}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
              >
                {state.series.map((s) => (
                  <option key={s.seriesId} value={s.seriesId}>
                    {s.seriesId} ({s.lifecycleStage})
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Investor Account (Includes Ineligible Test)</span>
              <select
                value={subInvestorId}
                onChange={(e) => setSubInvestorId(e.target.value)}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 text-[#F4F1EA]"
              >
                {state.investors.map((inv) => (
                  <option key={inv.investorId} value={inv.investorId}>
                    {inv.investorId} · {inv.kycStatus} ({inv.jurisdiction})
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Requested Units</span>
              <input
                type="number"
                value={subUnits}
                onChange={(e) => setSubUnits(Number(e.target.value))}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[#7E8799] block">Idempotency Key</span>
              <input
                value={subIdemKey}
                onChange={(e) => setSubIdemKey(e.target.value)}
                className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
              />
            </label>
          </div>
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                onSubmitSubscription({
                  idempotencyKey: subIdemKey,
                  seriesId: selectedSeriesId,
                  investorId: subInvestorId,
                  requestedUnits: subUnits,
                })
              }
              className="px-4 py-2 text-xs font-medium bg-[#C8A24A] text-[#070B14] hover:bg-[#D9B45D] disabled:opacity-45 cursor-pointer"
            >
              Submit &amp; Allocate Subscription
            </button>
            <button
              type="button"
              onClick={() => setSubIdemKey(`IDEM-SUB-${Date.now().toString().slice(-5)}`)}
              className="px-3 py-2 text-xs border border-slate-200/20 text-[#B6B1A4] hover:text-[#F4F1EA] cursor-pointer"
            >
              New Idempotency Key
            </button>
          </div>
        </div>
      </div>

      {/* Subscriptions & Issuance Execution Table */}
      <div className="border border-slate-200/15 bg-[#0D1320]">
        <div className="px-6 py-4 border-b border-slate-200/10 flex items-center justify-between">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
            Subscription Orders, Settlement Evidence &amp; On-Chain Issuance
          </h2>
          <span className="text-xs font-mono text-[#7E8799]">
            Repeated issuance requests with same idempotency key return existing mint without duplicating supply
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200/10 text-xs text-[#7E8799]">
                <th className="py-2.5 px-6 font-medium">Order ID</th>
                <th className="py-2.5 px-4 font-medium">Series / Investor</th>
                <th className="py-2.5 px-4 font-medium text-right">Units</th>
                <th className="py-2.5 px-4 font-medium text-right">Expected USD</th>
                <th className="py-2.5 px-4 font-medium">Status</th>
                <th className="py-2.5 px-4 font-medium">Tx / Settlement Ref</th>
                <th className="py-2.5 px-6 font-medium text-right">Workflow Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/10 text-xs">
              {state.subscriptions.map((sub) => (
                <tr key={sub.subscriptionId} className="hover:bg-[#121A2B]">
                  <td className="py-3 px-6 font-mono text-[#F4F1EA]">
                    <div>{sub.subscriptionId}</div>
                    <div className="text-[11px] text-[#7E8799]">{sub.idempotencyKey}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="text-[#F4F1EA]">{sub.investorName}</div>
                    <div className="font-mono text-[#7E8799]">{sub.seriesId} · {sub.sdrObservationIdUsed}</div>
                  </td>
                  <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">
                    {fmtNum(sub.allocatedUnits)}
                  </td>
                  <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">
                    {fmtUsd(sub.expectedCashAmountUsd)}
                  </td>
                  <td className="py-3 px-4 font-mono">
                    <span
                      className={
                        sub.status === 'ISSUED'
                          ? 'text-[#10B981]'
                          : sub.status === 'FAILED_SETTLEMENT'
                          ? 'text-[#EF4444]'
                          : 'text-[#F59E0B]'
                      }
                    >
                      {sub.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[#B6B1A4]">
                    {sub.issuanceTxHash ? shortHash(sub.issuanceTxHash) : sub.settlementEvidenceRef ?? 'Awaiting wire'}
                  </td>
                  <td className="py-3 px-6 text-right">
                    <div className="inline-flex items-center gap-2">
                      {sub.status === 'ALLOCATED' && (
                        <>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() =>
                              onFundSubscription({
                                subscriptionId: sub.subscriptionId,
                                fundedCashAmountUsd: sub.expectedCashAmountUsd,
                                settlementEvidenceRef: `FEDWIRE-SIM-${Date.now().toString().slice(-6)}`,
                                simulateFailure: false,
                              })
                            }
                            className="px-2.5 py-1 border border-[#10B981]/60 text-[#10B981] hover:bg-[#10B981]/10 cursor-pointer"
                          >
                            Confirm Wire
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() =>
                              onFundSubscription({
                                subscriptionId: sub.subscriptionId,
                                fundedCashAmountUsd: 0,
                                settlementEvidenceRef: 'FAILED_SETTLEMENT_TEST',
                                simulateFailure: true,
                              })
                            }
                            className="px-2.5 py-1 border border-[#EF4444]/60 text-[#EF4444] hover:bg-[#EF4444]/10 cursor-pointer"
                          >
                            Fail Wire
                          </button>
                        </>
                      )}
                      {(sub.status === 'FUNDED' || sub.status === 'ISSUED') && (
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => onIssueSubscription(sub.subscriptionId, sub.idempotencyKey)}
                          className="px-2.5 py-1 border border-[#22D3EE]/60 text-[#22D3EE] hover:bg-[#22D3EE]/10 cursor-pointer"
                        >
                          {sub.status === 'ISSUED' ? 'Test Idempotent Replay' : 'Authorise & Issue'}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
