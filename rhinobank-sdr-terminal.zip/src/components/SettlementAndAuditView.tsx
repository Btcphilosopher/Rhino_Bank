import React, { useState } from 'react';
import { OperatorRole, PlatformStateSnapshot } from '../shared/types';
import { fmtNum, fmtSdr, fmtTs, fmtUsd, shortHash } from './Formatters';

interface SettlementAndAuditViewProps {
  mode: 'Settlement' | 'Audit';
  state: PlatformStateSnapshot;
  actorRole: OperatorRole;
  busy: boolean;
  onAdvanceCoupon: (couponId: string, targetStage: string, paymentEventId?: string) => void;
  onInitiateRedemption: (payload: { seriesId: string; investorId: string; unitsToRedeem: number; paymentEventId: string }) => void;
  onAdvanceRedemption: (redemptionId: string, action: 'INSTRUCT_PAYMENT' | 'CONFIRM_PAYMENT' | 'RETIRE_ON_CHAIN') => void;
  onToggleControl: (seriesId: string, control: 'PAUSE_ISSUANCE' | 'RESTRICT_TRANSFERS', value: boolean) => void;
  onProposeUpgrade: (seriesId: string, targetVersion: string) => void;
  onExecuteUpgrade: (seriesId: string) => void;
  onRotateKey: (roleName: string) => void;
}

export const SettlementAndAuditView: React.FC<SettlementAndAuditViewProps> = ({
  mode,
  state,
  actorRole,
  busy,
  onAdvanceCoupon,
  onInitiateRedemption,
  onAdvanceRedemption,
  onToggleControl,
  onProposeUpgrade,
  onExecuteUpgrade,
  onRotateKey,
}) => {
  const [redInvestorId, setRedInvestorId] = useState(state.holdings[0]?.investorId ?? 'INV-ZURICH-PEN');
  const [redUnits, setRedUnits] = useState(250);
  const [targetUpgradeVer, setTargetUpgradeVer] = useState('RhinoSDRNote-v1.1.0');

  if (mode === 'Settlement') {
    return (
      <div className="space-y-8">
        <div className="border-b border-slate-200/10 pb-4">
          <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
            Coupons, Redemption Sequencing &amp; Cash Settlement Reconciliation
          </h1>
          <p className="text-xs text-[#B6B1A4] mt-1">
            Scheduled → Calculated → Approved → Payment Instructed → Payment Confirmed → Reconciled. Burning a token alone is never labelled repayment; units retire on-chain only after confirmed cash payment.
          </p>
        </div>

        {/* Coupons Table */}
        <div className="border border-slate-200/15 bg-[#0D1320]">
          <div className="px-6 py-4 border-b border-slate-200/10 flex items-center justify-between">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
              Coupon Obligations
            </h2>
            <span className="text-xs font-mono text-[#7E8799]">Active Role: {actorRole}</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200/10 text-xs text-[#7E8799]">
                  <th className="py-2.5 px-6 font-medium">Coupon ID</th>
                  <th className="py-2.5 px-4 font-medium">Period &amp; Rate</th>
                  <th className="py-2.5 px-4 font-medium text-right">Gross SDR</th>
                  <th className="py-2.5 px-4 font-medium text-right">USD Amount</th>
                  <th className="py-2.5 px-4 font-medium">Status</th>
                  <th className="py-2.5 px-6 font-medium text-right">Workflow Step</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/10 text-xs">
                {state.coupons.map((c) => (
                  <tr key={c.couponId} className="hover:bg-[#121A2B]">
                    <td className="py-3 px-6 font-mono text-[#F4F1EA]">
                      <div>{c.couponId}</div>
                      <div className="text-[11px] text-[#7E8799]">{c.paymentEventId}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-[#F4F1EA]">{c.periodLabel}</div>
                      <div className="font-mono text-[#7E8799]">{c.annualRateBps} bps · {fmtNum(c.outstandingUnitsSnapshot)} units</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-right text-[#F4F1EA] tabular-nums">{fmtSdr(c.grossCouponSdr)}</td>
                    <td className="py-3 px-4 font-mono text-right text-[#C8A24A] tabular-nums">{fmtUsd(c.grossCouponUsd)}</td>
                    <td className="py-3 px-4 font-mono text-[#22D3EE]">{c.status}</td>
                    <td className="py-3 px-6 text-right">
                      <div className="inline-flex gap-2">
                        {c.status === 'Scheduled' && (
                          <button type="button" disabled={busy} onClick={() => onAdvanceCoupon(c.couponId, 'Calculated')} className="px-2.5 py-1 border border-[#22D3EE]/60 text-[#22D3EE] cursor-pointer">
                            Calculate
                          </button>
                        )}
                        {c.status === 'Calculated' && (
                          <button type="button" disabled={busy} onClick={() => onAdvanceCoupon(c.couponId, 'Approved')} className="px-2.5 py-1 border border-[#F59E0B]/60 text-[#F59E0B] cursor-pointer">
                            Approve
                          </button>
                        )}
                        {c.status === 'Approved' && (
                          <button type="button" disabled={busy} onClick={() => onAdvanceCoupon(c.couponId, 'Payment Instructed')} className="px-2.5 py-1 border border-[#22D3EE]/60 text-[#22D3EE] cursor-pointer">
                            Instruct Wire
                          </button>
                        )}
                        {c.status === 'Payment Instructed' && (
                          <button type="button" disabled={busy} onClick={() => onAdvanceCoupon(c.couponId, 'Payment Confirmed', c.paymentEventId)} className="px-2.5 py-1 border border-[#10B981]/60 text-[#10B981] cursor-pointer">
                            Confirm Payment
                          </button>
                        )}
                        {c.status === 'Payment Confirmed' && (
                          <button type="button" disabled={busy} onClick={() => onAdvanceCoupon(c.couponId, 'Reconciled')} className="px-2.5 py-1 border border-[#10B981]/60 text-[#10B981] cursor-pointer">
                            Reconcile
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Redemption Initiation & Sequenced Retirement */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
              Initiate Note Redemption
            </h2>
            <div className="space-y-3 text-xs">
              <label className="space-y-1 block">
                <span className="text-[#7E8799] block">Holder Account</span>
                <select
                  value={redInvestorId}
                  onChange={(e) => setRedInvestorId(e.target.value)}
                  className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 text-[#F4F1EA]"
                >
                  {state.holdings.map((h) => (
                    <option key={h.holdingId} value={h.investorId}>
                      {h.investorId} ({fmtNum(h.units)} units)
                    </option>
                  ))}
                </select>
              </label>
              <label className="space-y-1 block">
                <span className="text-[#7E8799] block">Units to Redeem</span>
                <input
                  type="number"
                  value={redUnits}
                  onChange={(e) => setRedUnits(Number(e.target.value))}
                  className="w-full bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
                />
              </label>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  onInitiateRedemption({
                    seriesId: 'RB-SDR-2027-A',
                    investorId: redInvestorId,
                    unitsToRedeem: redUnits,
                    paymentEventId: `PAY-EVT-RED-${Date.now().toString().slice(-6)}`,
                  })
                }
                className="w-full py-2 text-xs font-medium bg-[#C8A24A] text-[#070B14] hover:bg-[#D9B45D] cursor-pointer"
              >
                Create Redemption Instruction
              </button>
            </div>
          </div>

          <div className="xl:col-span-2 border border-slate-200/15 bg-[#0D1320] p-6 space-y-3">
            <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
              Redemption Sequencing Guard (Payment Confirmed Required Before On-Chain Retirement)
            </h2>
            {state.redemptions.length === 0 && (
              <div className="text-xs text-[#7E8799] py-4">
                No redemption instructions created yet. Create one on the left or run Steps 8–12 from Overview.
              </div>
            )}
            <div className="space-y-3">
              {state.redemptions.map((red) => (
                <div key={red.redemptionId} className="border border-slate-200/10 bg-[#070B14] p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                  <div className="space-y-1">
                    <div className="font-mono text-[#F4F1EA]">
                      {red.redemptionId} · {red.investorId} · {fmtNum(red.unitsToRedeem)} units ({fmtUsd(red.redemptionValueUsd)})
                    </div>
                    <div className="font-mono text-[#B6B1A4]">
                      Status: <span className="text-[#22D3EE]">{red.status}</span> · On-Chain Retired: {red.retiredOnChain ? 'YES' : 'NO'} {red.burnTxHash ? `(${shortHash(red.burnTxHash)})` : ''}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {red.status === 'Approved' && (
                      <button type="button" disabled={busy} onClick={() => onAdvanceRedemption(red.redemptionId, 'INSTRUCT_PAYMENT')} className="px-2.5 py-1 border border-[#22D3EE]/60 text-[#22D3EE] cursor-pointer">
                        Instruct Payment
                      </button>
                    )}
                    {red.status === 'Payment Instructed' && (
                      <button type="button" disabled={busy} onClick={() => onAdvanceRedemption(red.redemptionId, 'CONFIRM_PAYMENT')} className="px-2.5 py-1 border border-[#10B981]/60 text-[#10B981] cursor-pointer">
                        Confirm Payment
                      </button>
                    )}
                    {!red.retiredOnChain && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => onAdvanceRedemption(red.redemptionId, 'RETIRE_ON_CHAIN')}
                        className="px-2.5 py-1 border border-[#F59E0B]/60 text-[#F59E0B] cursor-pointer"
                      >
                        Retire Units On-Chain
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==================== AUDIT & SECURITY GOVERNANCE MODE ====================
  const primarySeries = state.series[0];
  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200/10 pb-4">
        <h1 className="text-xl font-display font-semibold text-[#F4F1EA]">
          Security Governance, Key Rotation, Timelocks &amp; Audit Trail
        </h1>
        <p className="text-xs text-[#B6B1A4] mt-1">
          Authorities to pause issuance, restrict transfers, rotate keys, and upgrade contracts are strictly separated. Secret material is redacted from all logs.
        </p>
      </div>

      {/* Emergency Pause & Timelock Upgrade Controls */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            Separated Circuit-Breaker Controls ({primarySeries?.seriesId})
          </h2>
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-2 border-b border-slate-200/10">
              <div>
                <div className="text-[#F4F1EA]">Pause Primary Issuance</div>
                <div className="text-[#7E8799]">Halts new minting; existing coupon &amp; redemption liabilities remain valid.</div>
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  onToggleControl(
                    primarySeries.seriesId,
                    'PAUSE_ISSUANCE',
                    !primarySeries.controls.issuancePaused
                  )
                }
                className={`px-3 py-1.5 font-mono border cursor-pointer ${
                  primarySeries?.controls.issuancePaused
                    ? 'border-[#EF4444] text-[#EF4444]'
                    : 'border-slate-200/25 text-[#F4F1EA]'
                }`}
              >
                {primarySeries?.controls.issuancePaused ? 'ISSUANCE PAUSED (RESUME)' : 'PAUSE ISSUANCE'}
              </button>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-slate-200/10">
              <div>
                <div className="text-[#F4F1EA]">Restrict Secondary Transfers</div>
                <div className="text-[#7E8799]">Requires RISK_APPROVER role; independent from oracle config.</div>
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  onToggleControl(
                    primarySeries.seriesId,
                    'RESTRICT_TRANSFERS',
                    !primarySeries.controls.transfersRestricted
                  )
                }
                className={`px-3 py-1.5 font-mono border cursor-pointer ${
                  primarySeries?.controls.transfersRestricted
                    ? 'border-[#F59E0B] text-[#F59E0B]'
                    : 'border-slate-200/25 text-[#F4F1EA]'
                }`}
              >
                {primarySeries?.controls.transfersRestricted ? 'TRANSFERS RESTRICTED (LIFT)' : 'RESTRICT TRANSFERS'}
              </button>
            </div>
          </div>
        </div>

        <div className="border border-slate-200/15 bg-[#0D1320] p-6 space-y-4">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA] border-b border-slate-200/10 pb-2">
            Restricted Contract Upgrade &amp; 48h Governance Timelock
          </h2>
          <div className="flex flex-wrap gap-3 text-xs">
            <input
              value={targetUpgradeVer}
              onChange={(e) => setTargetUpgradeVer(e.target.value)}
              className="flex-1 bg-[#070B14] border border-slate-200/20 px-3 py-2 font-mono text-[#F4F1EA]"
            />
            <button
              type="button"
              disabled={busy}
              onClick={() => onProposeUpgrade(primarySeries.seriesId, targetUpgradeVer)}
              className="px-3 py-2 bg-[#22D3EE] text-[#070B14] font-medium cursor-pointer"
            >
              Queue 48h Upgrade Proposal
            </button>
          </div>
          {primarySeries?.controls.pendingUpgrade && (
            <div className="border border-slate-200/10 bg-[#070B14] p-3 text-xs space-y-2">
              <div className="font-mono text-[#F59E0B]">
                Queued: {primarySeries.controls.pendingUpgrade.targetContractVersion} · Unlock {fmtTs(primarySeries.controls.pendingUpgrade.etaUnlockAt)}
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() => onExecuteUpgrade(primarySeries.seriesId)}
                className="px-3 py-1 border border-[#EF4444]/60 text-[#EF4444] cursor-pointer"
              >
                Attempt Immediate Execution (Tests Timelock Guard)
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Role-Separated Cryptographic Keys */}
      <div className="border border-slate-200/15 bg-[#0D1320]">
        <div className="px-6 py-4 border-b border-slate-200/10">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
            Role-Separated Ed25519 Signing Authorities (Private Keys Redacted Server-Side)
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200/10 text-[#7E8799]">
                <th className="py-2.5 px-6 font-medium">Key ID</th>
                <th className="py-2.5 px-4 font-medium">Role &amp; Scope</th>
                <th className="py-2.5 px-4 font-medium">Public Fingerprint</th>
                <th className="py-2.5 px-4 font-medium">Status</th>
                <th className="py-2.5 px-6 font-medium text-right">Rotation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/10">
              {state.keys.map((k) => (
                <tr key={k.keyId} className="hover:bg-[#121A2B]">
                  <td className="py-2.5 px-6 font-mono text-[#F4F1EA]">{k.keyId}</td>
                  <td className="py-2.5 px-4">
                    <div className="font-mono text-[#22D3EE]">{k.roleName}</div>
                    <div className="text-[#7E8799]">{k.authorityScope}</div>
                  </td>
                  <td className="py-2.5 px-4 font-mono text-[#B6B1A4]">{k.publicKeyFingerprint}</td>
                  <td className="py-2.5 px-4 font-mono">
                    <span className={k.status === 'ACTIVE' ? 'text-[#10B981]' : 'text-[#7E8799]'}>
                      {k.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-6 text-right">
                    {k.status === 'ACTIVE' && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => onRotateKey(k.roleName)}
                        className="px-2.5 py-1 border border-slate-200/20 text-[#F4F1EA] hover:border-[#22D3EE] cursor-pointer"
                      >
                        Rotate Key
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Immutable Audit History */}
      <div className="border border-slate-200/15 bg-[#0D1320]">
        <div className="px-6 py-4 border-b border-slate-200/10">
          <h2 className="text-sm font-display font-semibold text-[#F4F1EA]">
            Cryptographic Audit History
          </h2>
        </div>
        <div className="overflow-x-auto max-h-96 overflow-y-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200/10 text-[#7E8799]">
                <th className="py-2.5 px-6 font-medium">Log ID / Time</th>
                <th className="py-2.5 px-4 font-medium">Actor Role</th>
                <th className="py-2.5 px-4 font-medium">Action</th>
                <th className="py-2.5 px-4 font-medium">Outcome</th>
                <th className="py-2.5 px-6 font-medium">Detail &amp; Payload Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/10">
              {state.auditLogs.map((log) => (
                <tr key={log.logId} className="hover:bg-[#121A2B]">
                  <td className="py-2.5 px-6 font-mono text-[#7E8799]">
                    <div className="text-[#F4F1EA]">{log.logId}</div>
                    <div>{fmtTs(log.timestamp)}</div>
                  </td>
                  <td className="py-2.5 px-4 font-mono text-[#B6B1A4]">
                    <div>{log.actorRole}</div>
                    <div className="text-[11px] text-[#7E8799]">{log.actorKeyId}</div>
                  </td>
                  <td className="py-2.5 px-4 font-mono text-[#22D3EE]">{log.action}</td>
                  <td className="py-2.5 px-4 font-mono">
                    <span
                      className={
                        log.outcome === 'ALLOWED'
                          ? 'text-[#10B981]'
                          : log.outcome === 'DENIED'
                          ? 'text-[#F59E0B]'
                          : 'text-[#EF4444]'
                      }
                    >
                      {log.outcome}
                    </span>
                  </td>
                  <td className="py-2.5 px-6">
                    <div className="text-[#F4F1EA]">{log.detail}</div>
                    <div className="font-mono text-[11px] text-[#7E8799]">{shortHash(log.payloadHash)}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
