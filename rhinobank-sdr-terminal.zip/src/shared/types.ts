export type OperatorRole =
  | 'ISSUER_OFFICER'
  | 'RISK_APPROVER'
  | 'TREASURY_OPS'
  | 'ORACLE_OPERATOR'
  | 'EXTERNAL_AUDITOR'
  | 'INVESTOR';

export type IssuanceStage =
  | 'Draft'
  | 'Reviewed'
  | 'Approved'
  | 'Subscription Open'
  | 'Allocated'
  | 'Funded'
  | 'Authorised for Issuance'
  | 'Issued'
  | 'Rejected'
  | 'Cancelled'
  | 'Failed Settlement';

export type PaymentLifecycleStage =
  | 'Scheduled'
  | 'Calculated'
  | 'Approved'
  | 'Payment Instructed'
  | 'Payment Confirmed'
  | 'Reconciled'
  | 'Disputed'
  | 'Payment Failed'
  | 'Fallback Applied';

export type ObservationStatus =
  | 'PUBLISHED'
  | 'REJECTED_STALE'
  | 'DISAGREEMENT_FLAGGED'
  | 'CORRECTED'
  | 'FALLBACK_USED';

export type ChainTxStatus = 'PENDING' | 'SAFE_JUSTIFIED' | 'FINALISED' | 'REORGED_REVERTED';

export interface SdrBasketCurrency {
  currency: 'USD' | 'EUR' | 'CNY' | 'JPY' | 'GBP';
  name: string;
  fixedAmount: number;
  targetWeightPct: number;
  quoteConvention: 'DIRECT_USD_PER_CCY' | 'INDIRECT_CCY_PER_USD';
  sourceFixing: string;
}

export interface SdrBasketDefinition {
  basketVersionId: string;
  effectiveFrom: string;
  effectiveUntil: string;
  methodologyName: string;
  imfRuleReference: string;
  roundingDecimals: number;
  stalenessMaxAgeSeconds: number;
  disagreementThresholdBps: number;
  currencies: SdrBasketCurrency[];
}

export interface FxRateComponent {
  currency: 'USD' | 'EUR' | 'CNY' | 'JPY' | 'GBP';
  quotedRate: number;
  usdPerUnit: number;
  usdContribution: number;
  effectiveWeightPct: number;
  source: string;
}

export interface SdrObservation {
  observationId: string;
  basketVersionId: string;
  source: string;
  secondarySource?: string;
  effectiveTime: string;
  retrievalTime: string;
  publishedAt: string;
  status: ObservationStatus;
  officialPublishedSdrUsd: number;
  reconstructedSdrUsd: number;
  intradayIndicativeSdrUsd: number;
  spreadBpsVsSecondary: number;
  fallbackMethod?: string;
  supersedesObservationId?: string;
  components: FxRateComponent[];
  oracleSignerKeyId: string;
  oracleSignature: string;
  payloadHash: string;
  chainTxHash?: string;
  chainFinalised: boolean;
}

export interface PermanentContractTerms {
  schemaVersion: string;
  seriesId: string;
  instrumentId: string;
  isinSimulated: string;
  seriesName: string;
  issuerIdentity: {
    legalName: string;
    lei: string;
    jurisdiction: string;
    obligationNature: 'PRIVATE_UNSECURED_SENIOR_NOTE' | 'PRIVATE_COLLATERALISED_NOTE';
  };
  issueDate: string;
  maturityDate: string;
  principalDenominationSdr: number;
  unitParSdr: number;
  supplyCapUnits: number;
  couponFormula: {
    type: 'FIXED_ON_SDR_NOTIONAL' | 'SDRI_LINKED_FLOATING';
    annualRateBps: number;
    dayCountConvention: 'ACT/360' | 'ACT/365F' | '30/360';
    observationSchedule: 'QUARTERLY' | 'SEMI_ANNUAL';
    paymentLagBusinessDays: number;
  };
  subscriptionCurrency: 'USD' | 'EUR';
  settlementCurrency: 'USD' | 'EUR';
  redemptionMethod: 'CASH_USD_EQUIVALENT_AT_FINAL_OBSERVATION';
  sdrReferenceMethodology: string;
  basketVersionId: string;
  valuationSourcePolicy: string;
  fxConversionAndRoundingRules: string;
  transferRestrictions: {
    regime: 'WHITELISTED_ELIGIBLE_INSTITUTIONAL_ONLY';
    lockupUntil: string;
    jurisdictionWhitelist: string[];
    requireOffchainTransferApproval: boolean;
  };
  investorEligibilityPolicy: string;
  rankingAndCollateralTerms: string;
  termSheetDocumentRef: string;
  termSheetCommitmentHash: string;
  governingDocumentRefs: { title: string; uri: string; sha256: string }[];
}

export interface NoteSeriesRecord {
  seriesId: string;
  contractVersion: string;
  contractAddress: string;
  terms: PermanentContractTerms;
  lifecycleStage: IssuanceStage;
  issuanceApprovalRefs: {
    issuerSignerKeyId: string;
    issuerSignature?: string;
    dualApproverKeyId?: string;
    dualApprovalSignature?: string;
    approvedAt?: string;
  };
  quantities: {
    authorisedUnits: number;
    subscribedUnits: number;
    fundedUnits: number;
    issuedUnits: number;
    outstandingUnits: number;
    redeemedUnits: number;
  };
  controls: {
    issuancePaused: boolean;
    transfersRestricted: boolean;
    lastOracleConfigChangeAt: string;
    pendingUpgrade?: {
      proposalId: string;
      targetContractVersion: string;
      proposedBy: string;
      etaUnlockAt: string;
      timelockHours: number;
      status: 'TIMELOCKED' | 'EXECUTED' | 'CANCELLED';
    };
  };
  latestObservationId: string;
  privateNoteMarketPricePctPar: number;
}

export interface SubscriptionOrder {
  subscriptionId: string;
  idempotencyKey: string;
  seriesId: string;
  investorId: string;
  investorName: string;
  requestedUnits: number;
  allocatedUnits: number;
  settlementCurrency: 'USD' | 'EUR';
  sdrObservationIdUsed: string;
  expectedCashAmountUsd: number;
  fundedCashAmountUsd: number;
  settlementEvidenceRef?: string;
  status: 'SUBMITTED' | 'ALLOCATED' | 'FUNDED' | 'ISSUED' | 'REJECTED' | 'CANCELLED' | 'FAILED_SETTLEMENT';
  createdAt: string;
  updatedAt: string;
  issuanceTxHash?: string;
}

export interface InvestorAccount {
  investorId: string;
  legalName: string;
  lei: string;
  jurisdiction: string;
  walletAddress: string;
  kycStatus: 'APPROVED' | 'REVIEW_REQUIRED' | 'RESTRICTED';
  eligibilityTier: 'QUALIFIED_INSTITUTIONAL_BUYER' | 'NON_ELIGIBLE';
  recoveryPolicy: 'MULTI_PARTY_LEGAL_COURT_REISSUE_ONLY';
}

export interface HoldingPosition {
  holdingId: string;
  investorId: string;
  investorName: string;
  walletAddress: string;
  seriesId: string;
  units: number;
  sdrFaceValue: number;
  acquisitionRecords: {
    acquisitionId: string;
    type: 'PRIMARY_ISSUANCE' | 'SECONDARY_TRADE';
    units: number;
    sdrCostPerUnit: number;
    usdEquivalentAtTrade: number;
    timestamp: string;
    txHash: string;
  }[];
  accruedEntitlementSdr: number;
  indicativeUsdValue: number;
  transferAvailability: 'AVAILABLE_ELIGIBLE' | 'LOCKED_UP' | 'PAUSED' | 'ENCUMBERED';
  encumbrancesUnits: number;
  maturityDate: string;
}

export interface ValidatorNode {
  validatorIndex: number;
  pubkey: string;
  operatorName: string;
  isRhinoBankOperated: boolean;
  stakedEth: number;
  stakeSharePct: number;
  status: 'ACTIVE_ONLINE' | 'SLASHED_EXITING' | 'INACTIVE_OFFLINE';
  participationRatePct: number;
  missedAttestations32Slots: number;
  accumulatedRewardsEth: number;
  accumulatedPenaltiesEth: number;
  clientDiversity: string;
}

export interface ConsensusBlock {
  blockNumber: number;
  slot: number;
  epoch: number;
  blockHash: string;
  parentHash: string;
  proposerIndex: number;
  proposerName: string;
  attestationWeightPct: number;
  checkpointStatus: 'PENDING' | 'JUSTIFIED' | 'FINALISED' | 'REORGED';
  timestamp: string;
  txHashes: string[];
  stateRoot: string;
}

export interface ChainTransaction {
  txHash: string;
  blockNumber: number | null;
  slot: number | null;
  epoch: number | null;
  txType:
    | 'DEPLOY_SERIES'
    | 'ISSUE_NOTE'
    | 'TRANSFER_NOTE'
    | 'PUBLISH_OBSERVATION'
    | 'RETIRE_REDEEMED_NOTE'
    | 'PAUSE_CONTROL'
    | 'GOVERNANCE_TIMELOCK';
  seriesId: string;
  callerAddress: string;
  signerKeyId: string;
  signature: string;
  payloadSummary: string;
  payloadHash: string;
  status: ChainTxStatus;
  submittedAt: string;
  finalisedAt?: string;
}

export interface ChainEvent {
  eventId: string;
  txHash: string;
  blockNumber: number;
  eventName: string;
  seriesId: string;
  args: Record<string, string | number | boolean>;
  finalised: boolean;
  reorged: boolean;
  timestamp: string;
}

export interface IndexerStatus {
  chainHeadBlock: number;
  finalisedChainBlock: number;
  indexedBlock: number;
  lagBlocks: number;
  lastRebuiltAt: string;
  projectedTotalIssuedUnits: number;
  projectedTotalOutstandingUnits: number;
  projectedTotalRedeemedUnits: number;
  reorgCount: number;
}

export interface MarketListing {
  listingId: string;
  seriesId: string;
  venueName: string;
  admissionStatus: 'INFORMATIONAL_LISTING_ONLY' | 'ADMITTED_FOR_RFQ';
  executionPermissionRequired: string;
  indicativeBidPctPar: number;
  indicativeAskPctPar: number;
  indicativeModelSdrValue: number;
  indicativeModelUsdValue: number;
  disclaimer: string;
}

export interface DealerRfq {
  rfqId: string;
  seriesId: string;
  requesterInvestorId: string;
  requesterName: string;
  side: 'BUY' | 'SELL';
  units: number;
  indicativeModelUsd: number;
  firmQuotePctPar?: number;
  firmQuoteTotalUsd?: number;
  dealerName?: string;
  quoteExpiresAt?: string;
  status: 'REQUESTED' | 'QUOTED' | 'CONFIRMED' | 'TRANSFER_PREPARED' | 'SETTLED' | 'EXPIRED';
  createdAt: string;
}

export interface SecondaryTrade {
  tradeId: string;
  rfqId: string;
  seriesId: string;
  buyerInvestorId: string;
  sellerInvestorId: string;
  units: number;
  agreedPricePctPar: number;
  agreedUsdAmount: number;
  agreementTimestamp: string;
  noteTransferStatus: 'NOT_SUBMITTED' | 'PENDING_CHAIN' | 'FINALISED_ON_CHAIN';
  noteTransferTxHash?: string;
  cashSettlementLegStatus: 'AWAITING_WIRE' | 'WIRE_CONFIRMED_BANK_RAIL' | 'RECONCILED';
  cashPaymentRef?: string;
  settlementModelNote: string;
}

export interface CouponObligation {
  couponId: string;
  paymentEventId: string;
  seriesId: string;
  periodLabel: string;
  observationDate: string;
  observationId?: string;
  outstandingUnitsSnapshot: number;
  accruedDays: number;
  annualRateBps: number;
  grossCouponSdr: number;
  fxUsdPerSdrUsed: number;
  grossCouponUsd: number;
  status: PaymentLifecycleStage;
  paymentInstructionRef?: string;
  bankConfirmationRef?: string;
  notes?: string;
}

export interface RedemptionInstruction {
  redemptionId: string;
  paymentEventId: string;
  seriesId: string;
  investorId: string;
  investorName: string;
  unitsToRedeem: number;
  observationId: string;
  redemptionValueSdr: number;
  redemptionValueUsd: number;
  status: PaymentLifecycleStage;
  paymentInstructionRef?: string;
  bankConfirmationRef?: string;
  burnTxHash?: string;
  retiredOnChain: boolean;
  createdAt: string;
}

export interface TreasurySnapshot {
  valuationDate: string;
  verificationScope: string;
  backingClassification: string;
  accounts: {
    accountId: string;
    category:
      | 'INVESTOR_SUBSCRIPTION_PROCEEDS'
      | 'ISSUER_GENERAL_CAPITAL'
      | 'OPERATIONALLY_EARMARKED_LIQUIDITY'
      | 'COLLATERAL_RESERVE'
      | 'VALIDATOR_STAKING_WALLET_SEPARATE';
    description: string;
    balanceUsd: number;
    encumberedUsd: number;
    legalRingfence: string;
  }[];
  currencyHoldings: {
    currency: 'USD' | 'EUR' | 'CNY' | 'JPY' | 'GBP';
    amount: number;
    usdEquivalent: number;
    sdrReplicatingWeightPct: number;
  }[];
  hedgingPositions: {
    hedgeId: string;
    instrument: string;
    notionalUsd: number;
    counterparty: string;
    mtmUsd: number;
    maturityDate: string;
  }[];
  liabilities: {
    totalIssuedNotesSdr: number;
    totalOutstandingNotesSdr: number;
    totalOutstandingNotesUsd: number;
    accruedCouponsUsd: number;
  };
  maturityProfile: {
    bucket: string;
    assetsUsd: number;
    liabilitiesUsd: number;
    netGapUsd: number;
  }[];
}

export interface RoleKeyRecord {
  keyId: string;
  roleName: string;
  authorityScope: string;
  publicKeyFingerprint: string;
  status: 'ACTIVE' | 'ROTATED_REVOKED';
  createdAt: string;
}

export interface AuditLogEntry {
  logId: string;
  timestamp: string;
  actorRole: OperatorRole;
  actorKeyId: string;
  action: string;
  resourceId: string;
  outcome: 'ALLOWED' | 'DENIED' | 'FAILED';
  detail: string;
  payloadHash: string;
}

export interface DemoStepState {
  stepNumber: number;
  title: string;
  responsibility: 'Issuer Service' | 'Note Contract' | 'PoS Validators' | 'Oracle Adapter' | 'SDR Markets' | 'Treasury & Settlement';
  completed: boolean;
  evidenceRef?: string;
}

export interface PlatformStateSnapshot {
  environmentLabel: 'TESTNET / SIMULATION';
  mandatoryDisclaimer: string;
  networkName: string;
  chainId: string;
  lastValuationTimestamp: string;
  lastChainTimestamp: string;
  basketDefinition: SdrBasketDefinition;
  observations: SdrObservation[];
  series: NoteSeriesRecord[];
  subscriptions: SubscriptionOrder[];
  investors: InvestorAccount[];
  holdings: HoldingPosition[];
  validators: ValidatorNode[];
  blocks: ConsensusBlock[];
  transactions: ChainTransaction[];
  chainEvents: ChainEvent[];
  indexer: IndexerStatus;
  listings: MarketListing[];
  rfqs: DealerRfq[];
  trades: SecondaryTrade[];
  coupons: CouponObligation[];
  redemptions: RedemptionInstruction[];
  treasury: TreasurySnapshot;
  keys: RoleKeyRecord[];
  auditLogs: AuditLogEntry[];
  demoSteps: DemoStepState[];
}
