import {
  ChainEvent,
  ChainTransaction,
  ConsensusBlock,
  IndexerStatus,
  ValidatorNode,
} from '../shared/types.ts';
import { ManagedKeyPair, sha256Hex, signPayload } from './crypto.ts';

export class PosConsensusNetwork {
  public readonly networkName = 'Ethereum PoS Testnet Profile (Sepolia / Gasper Simulation)';
  public readonly chainId = '11155111-SIM';
  public readonly slotsPerEpoch = 32;
  public validators: ValidatorNode[];
  public blocks: ConsensusBlock[];
  public transactions: ChainTransaction[];
  public events: ChainEvent[];
  public indexer: IndexerStatus;
  private currentSlot: number;
  private currentEpoch: number;

  constructor() {
    this.validators = [
      {
        validatorIndex: 10412,
        pubkey: '0x8a91f4c2e10b73a5...e412',
        operatorName: 'Helvetia Institutional Staking AG',
        isRhinoBankOperated: false,
        stakedEth: 6400,
        stakeSharePct: 24.62,
        status: 'ACTIVE_ONLINE',
        participationRatePct: 99.8,
        missedAttestations32Slots: 0,
        accumulatedRewardsEth: 14.821,
        accumulatedPenaltiesEth: 0,
        clientDiversity: 'Lighthouse / Besu',
      },
      {
        validatorIndex: 10489,
        pubkey: '0x3b77d9a0c812fe19...90a1',
        operatorName: 'Nordic Sovereign Node Operator',
        isRhinoBankOperated: false,
        stakedEth: 5800,
        stakeSharePct: 22.31,
        status: 'ACTIVE_ONLINE',
        participationRatePct: 99.6,
        missedAttestations32Slots: 1,
        accumulatedRewardsEth: 13.204,
        accumulatedPenaltiesEth: 0.002,
        clientDiversity: 'Prysm / Geth',
      },
      {
        validatorIndex: 10531,
        pubkey: '0x71cc02be99f4a83d...118b',
        operatorName: 'Thames Clearing Validator Pool',
        isRhinoBankOperated: false,
        stakedEth: 4600,
        stakeSharePct: 17.69,
        status: 'ACTIVE_ONLINE',
        participationRatePct: 99.4,
        missedAttestations32Slots: 1,
        accumulatedRewardsEth: 10.119,
        accumulatedPenaltiesEth: 0.003,
        clientDiversity: 'Teku / Nethermind',
      },
      {
        validatorIndex: 10604,
        pubkey: '0x5e18a9d403f172bc...44d9',
        operatorName: 'RhinoBank Institutional Validator (1 of 6)',
        isRhinoBankOperated: true,
        stakedEth: 3700,
        stakeSharePct: 14.23,
        status: 'ACTIVE_ONLINE',
        participationRatePct: 99.9,
        missedAttestations32Slots: 0,
        accumulatedRewardsEth: 8.442,
        accumulatedPenaltiesEth: 0,
        clientDiversity: 'Teku / Besu',
      },
      {
        validatorIndex: 10688,
        pubkey: '0x94af2118cd6703ef...72c0',
        operatorName: 'Alpine Custody Consensus Node',
        isRhinoBankOperated: false,
        stakedEth: 3200,
        stakeSharePct: 12.31,
        status: 'ACTIVE_ONLINE',
        participationRatePct: 98.9,
        missedAttestations32Slots: 2,
        accumulatedRewardsEth: 6.912,
        accumulatedPenaltiesEth: 0.008,
        clientDiversity: 'Nimbus / Geth',
      },
      {
        validatorIndex: 10742,
        pubkey: '0x2d09e661ab3490fc...58e3',
        operatorName: 'Singapore Settlement Guild',
        isRhinoBankOperated: false,
        stakedEth: 2300,
        stakeSharePct: 8.85,
        status: 'ACTIVE_ONLINE',
        participationRatePct: 97.5,
        missedAttestations32Slots: 4,
        accumulatedRewardsEth: 4.883,
        accumulatedPenaltiesEth: 0.015,
        clientDiversity: 'Lodestar / Erigon',
      },
    ];

    this.currentEpoch = 412;
    this.currentSlot = 412 * this.slotsPerEpoch + 1;
    const genesisHash = sha256Hex({ genesis: 'rhinobank-sdr-testnet', epoch: 410 });
    const b100Hash = sha256Hex({ blockNumber: 13184, parentHash: genesisHash });
    const b101Hash = sha256Hex({ blockNumber: 13185, parentHash: b100Hash });

    this.blocks = [
      {
        blockNumber: 13184,
        slot: 410 * 32,
        epoch: 410,
        blockHash: b100Hash,
        parentHash: genesisHash,
        proposerIndex: 10412,
        proposerName: 'Helvetia Institutional Staking AG',
        attestationWeightPct: 99.4,
        checkpointStatus: 'FINALISED',
        timestamp: '2026-11-15T09:10:00Z',
        txHashes: [],
        stateRoot: sha256Hex({ block: 13184, root: 'initial' }),
      },
      {
        blockNumber: 13185,
        slot: 411 * 32,
        epoch: 411,
        blockHash: b101Hash,
        parentHash: b100Hash,
        proposerIndex: 10489,
        proposerName: 'Nordic Sovereign Node Operator',
        attestationWeightPct: 98.8,
        checkpointStatus: 'FINALISED',
        timestamp: '2026-11-15T09:16:24Z',
        txHashes: [],
        stateRoot: sha256Hex({ block: 13185, root: 'initial' }),
      },
    ];

    this.transactions = [];
    this.events = [];
    this.indexer = {
      chainHeadBlock: 13185,
      finalisedChainBlock: 13185,
      indexedBlock: 13185,
      lagBlocks: 0,
      lastRebuiltAt: '2026-11-15T09:16:25Z',
      projectedTotalIssuedUnits: 0,
      projectedTotalOutstandingUnits: 0,
      projectedTotalRedeemedUnits: 0,
      reorgCount: 0,
    };
  }

  public getActiveOnlineStakePct(): number {
    const total = this.validators.reduce((sum, v) => sum + v.stakedEth, 0);
    if (total === 0) return 0;
    const online = this.validators
      .filter((v) => v.status === 'ACTIVE_ONLINE')
      .reduce((sum, v) => sum + v.stakedEth, 0);
    return Math.round((online / total) * 10000) / 100;
  }

  public submitTransaction(params: {
    txType: ChainTransaction['txType'];
    seriesId: string;
    callerAddress: string;
    signerKey: ManagedKeyPair;
    payloadSummary: string;
    payload: Record<string, unknown>;
    eventsToEmit: { eventName: string; args: Record<string, string | number | boolean> }[];
    autoFinalise?: boolean;
  }): { tx: ChainTransaction; block: ConsensusBlock } {
    const timestamp = new Date().toISOString();
    const payloadHash = sha256Hex(params.payload);
    const signature = signPayload({ payloadHash, callerAddress: params.callerAddress }, params.signerKey.privateKeyPem);
    const txHash = sha256Hex({
      txType: params.txType,
      payloadHash,
      nonce: this.transactions.length + 1,
      timestamp,
    });

    const tx: ChainTransaction = {
      txHash,
      blockNumber: null,
      slot: null,
      epoch: null,
      txType: params.txType,
      seriesId: params.seriesId,
      callerAddress: params.callerAddress,
      signerKeyId: params.signerKey.keyId,
      signature,
      payloadSummary: params.payloadSummary,
      payloadHash,
      status: 'PENDING',
      submittedAt: timestamp,
    };

    this.transactions.unshift(tx);

    // Include into next proposed slot/block
    const block = this.proposeNextBlock([tx], params.eventsToEmit, timestamp);
    if (params.autoFinalise !== false) {
      this.advanceEpochsToFinalise(2);
    }
    return { tx, block };
  }

  public proposeNextBlock(
    txs: ChainTransaction[],
    eventsSpec: { eventName: string; args: Record<string, string | number | boolean> }[] = [],
    timestamp = new Date().toISOString()
  ): ConsensusBlock {
    const onlineValidators = this.validators.filter((v) => v.status === 'ACTIVE_ONLINE');
    if (onlineValidators.length === 0) {
      throw new Error('No online validators available to propose block');
    }
    const prevBlock = this.blocks[0];
    const nextBlockNum = prevBlock.blockNumber + 1;
    this.currentSlot += 1;
    this.currentEpoch = Math.floor(this.currentSlot / this.slotsPerEpoch);
    const proposer = onlineValidators[nextBlockNum % onlineValidators.length];
    const attestationWeightPct = this.getActiveOnlineStakePct();

    const blockHash = sha256Hex({
      blockNumber: nextBlockNum,
      slot: this.currentSlot,
      parentHash: prevBlock.blockHash,
      txHashes: txs.map((t) => t.txHash),
    });

    const stateRoot = sha256Hex({
      prevStateRoot: prevBlock.stateRoot,
      blockHash,
      eventsCount: eventsSpec.length,
    });

    const checkpointStatus: ConsensusBlock['checkpointStatus'] =
      attestationWeightPct >= 66.67 ? 'JUSTIFIED' : 'PENDING';

    const block: ConsensusBlock = {
      blockNumber: nextBlockNum,
      slot: this.currentSlot,
      epoch: this.currentEpoch,
      blockHash,
      parentHash: prevBlock.blockHash,
      proposerIndex: proposer.validatorIndex,
      proposerName: proposer.operatorName,
      attestationWeightPct,
      checkpointStatus,
      timestamp,
      txHashes: txs.map((t) => t.txHash),
      stateRoot,
    };

    // Accrue protocol-defined attestation rewards to online validators
    for (const v of this.validators) {
      if (v.status === 'ACTIVE_ONLINE') {
        v.accumulatedRewardsEth = Math.round((v.accumulatedRewardsEth + 0.0024) * 10000) / 10000;
      } else if (v.status === 'INACTIVE_OFFLINE') {
        v.missedAttestations32Slots += 1;
        v.accumulatedPenaltiesEth = Math.round((v.accumulatedPenaltiesEth + 0.0031) * 10000) / 10000;
      }
    }

    for (const tx of txs) {
      tx.blockNumber = nextBlockNum;
      tx.slot = this.currentSlot;
      tx.epoch = this.currentEpoch;
      tx.status = checkpointStatus === 'JUSTIFIED' ? 'SAFE_JUSTIFIED' : 'PENDING';
    }

    eventsSpec.forEach((ev, idx) => {
      const tx = txs[0];
      this.events.unshift({
        eventId: `EVT-${nextBlockNum}-${idx + 1}`,
        txHash: tx ? tx.txHash : blockHash,
        blockNumber: nextBlockNum,
        eventName: ev.eventName,
        seriesId: tx ? tx.seriesId : 'NETWORK',
        args: ev.args,
        finalised: false,
        reorged: false,
        timestamp,
      });
    });

    this.blocks.unshift(block);
    this.indexer.chainHeadBlock = nextBlockNum;
    this.indexer.lagBlocks = Math.max(0, this.indexer.chainHeadBlock - this.indexer.indexedBlock);
    return block;
  }

  public advanceEpochsToFinalise(epochs = 2): { finalisedBlock: number; activeStakePct: number } {
    const activeStakePct = this.getActiveOnlineStakePct();
    if (activeStakePct < 66.67) {
      // Casper FFG cannot finalise without >= 2/3 active attesting stake!
      // Apply inactivity leak if >4 epochs without finality
      if (epochs >= 4) {
        for (const v of this.validators) {
          if (v.status === 'INACTIVE_OFFLINE') {
            const leakEth = Math.round(v.stakedEth * 0.05 * 100) / 100;
            v.stakedEth = Math.max(0, Math.round((v.stakedEth - leakEth) * 100) / 100);
            v.accumulatedPenaltiesEth = Math.round((v.accumulatedPenaltiesEth + leakEth) * 10000) / 10000;
          }
        }
        this.recalculateStakeShares();
      }
      return { finalisedBlock: this.indexer.finalisedChainBlock, activeStakePct };
    }

    this.currentEpoch += epochs;
    this.currentSlot = this.currentEpoch * this.slotsPerEpoch;
    const now = new Date().toISOString();

    for (const block of this.blocks) {
      if (block.checkpointStatus !== 'REORGED') {
        block.checkpointStatus = 'FINALISED';
      }
    }
    for (const tx of this.transactions) {
      if (tx.status !== 'REORGED_REVERTED') {
        tx.status = 'FINALISED';
        tx.finalisedAt = tx.finalisedAt ?? now;
      }
    }
    for (const ev of this.events) {
      if (!ev.reorged) {
        ev.finalised = true;
      }
    }

    const topFinalised = this.blocks.find((b) => b.checkpointStatus === 'FINALISED');
    if (topFinalised) {
      this.indexer.finalisedChainBlock = topFinalised.blockNumber;
    }
    this.rebuildIndexerProjections();
    return { finalisedBlock: this.indexer.finalisedChainBlock, activeStakePct };
  }

  public simulatePreFinalityReorg(): { revertedTxHashes: string[]; newHeadBlock: number } {
    const unfinalisedBlocks = this.blocks.filter(
      (b) => b.checkpointStatus === 'PENDING' || b.checkpointStatus === 'JUSTIFIED'
    );
    const revertedTxHashes: string[] = [];

    for (const b of unfinalisedBlocks) {
      b.checkpointStatus = 'REORGED';
      for (const txHash of b.txHashes) {
        revertedTxHashes.push(txHash);
        const tx = this.transactions.find((t) => t.txHash === txHash);
        if (tx) tx.status = 'REORGED_REVERTED';
      }
      for (const ev of this.events) {
        if (ev.blockNumber === b.blockNumber) {
          ev.reorged = true;
          ev.finalised = false;
        }
      }
    }

    // Propose canonical replacement block on top of last finalised block
    const canonicalParent = this.blocks.find((b) => b.checkpointStatus === 'FINALISED') ?? this.blocks[this.blocks.length - 1];
    const nextBlockNum = (this.blocks[0]?.blockNumber ?? canonicalParent.blockNumber) + 1;
    this.currentSlot += 1;
    const online = this.validators.filter((v) => v.status === 'ACTIVE_ONLINE');
    const proposer = online[0] ?? this.validators[0];
    const replacementBlock: ConsensusBlock = {
      blockNumber: nextBlockNum,
      slot: this.currentSlot,
      epoch: Math.floor(this.currentSlot / this.slotsPerEpoch),
      blockHash: sha256Hex({ reorgReplacement: nextBlockNum, parent: canonicalParent.blockHash }),
      parentHash: canonicalParent.blockHash,
      proposerIndex: proposer.validatorIndex,
      proposerName: proposer.operatorName,
      attestationWeightPct: this.getActiveOnlineStakePct(),
      checkpointStatus: 'FINALISED',
      timestamp: new Date().toISOString(),
      txHashes: [],
      stateRoot: sha256Hex({ canonicalRoot: canonicalParent.stateRoot, nextBlockNum }),
    };

    this.blocks.unshift(replacementBlock);
    this.indexer.chainHeadBlock = replacementBlock.blockNumber;
    this.indexer.finalisedChainBlock = replacementBlock.blockNumber;
    this.indexer.reorgCount += 1;
    this.rebuildIndexerProjections();
    return { revertedTxHashes, newHeadBlock: replacementBlock.blockNumber };
  }

  public toggleValidatorOnline(validatorIndex: number, online: boolean): ValidatorNode {
    const val = this.validators.find((v) => v.validatorIndex === validatorIndex);
    if (!val) throw new Error(`Validator ${validatorIndex} not found`);
    if (val.status === 'SLASHED_EXITING') {
      throw new Error(`Validator ${validatorIndex} is slashed and exiting; cannot re-activate`);
    }
    val.status = online ? 'ACTIVE_ONLINE' : 'INACTIVE_OFFLINE';
    val.participationRatePct = online ? 99.5 : 0.0;
    return val;
  }

  public slashValidatorForEquivocation(validatorIndex: number, reason: 'DOUBLE_PROPOSAL' | 'SURROUND_VOTE'): ValidatorNode {
    const val = this.validators.find((v) => v.validatorIndex === validatorIndex);
    if (!val) throw new Error(`Validator ${validatorIndex} not found`);
    if (val.status === 'SLASHED_EXITING') return val;
    // Ethereum PoS real initial slashing penalty: min(1 ETH, effectiveBalance/32) + forced exit
    const initialSlashEth = Math.min(1, Math.round((val.stakedEth / 32) * 100) / 100);
    val.stakedEth = Math.max(0, Math.round((val.stakedEth - initialSlashEth) * 100) / 100);
    val.accumulatedPenaltiesEth = Math.round((val.accumulatedPenaltiesEth + initialSlashEth) * 10000) / 10000;
    val.status = 'SLASHED_EXITING';
    val.participationRatePct = 0;
    this.recalculateStakeShares();
    this.events.unshift({
      eventId: `SLASH-${Date.now()}`,
      txHash: sha256Hex({ validatorIndex, reason, ts: Date.now() }),
      blockNumber: this.indexer.chainHeadBlock,
      eventName: `VALIDATOR_SLASHED_${reason}`,
      seriesId: 'CONSENSUS',
      args: {
        validatorIndex,
        initialSlashEth,
        exitQueueDays: 36,
        note: 'Protocol slashing penalty on validator stake ONLY; note collateral & investor funds remain strictly segregated.',
      },
      finalised: true,
      reorged: false,
      timestamp: new Date().toISOString(),
    });
    return val;
  }

  private recalculateStakeShares(): void {
    const total = this.validators.reduce((sum, v) => sum + v.stakedEth, 0);
    for (const v of this.validators) {
      v.stakeSharePct = total > 0 ? Math.round((v.stakedEth / total) * 10000) / 100 : 0;
    }
  }

  public rebuildIndexerProjections(): IndexerStatus {
    let issued = 0;
    let redeemed = 0;
    const finalisedEvents = [...this.events].reverse().filter((e) => e.finalised && !e.reorged);
    for (const ev of finalisedEvents) {
      if (ev.eventName === 'NOTE_ISSUED') {
        issued += Number(ev.args.units ?? 0);
      } else if (ev.eventName === 'NOTE_REDEEMED_AND_RETIRED') {
        redeemed += Number(ev.args.units ?? 0);
      }
    }
    this.indexer.indexedBlock = this.indexer.finalisedChainBlock;
    this.indexer.lagBlocks = Math.max(0, this.indexer.chainHeadBlock - this.indexer.indexedBlock);
    this.indexer.lastRebuiltAt = new Date().toISOString();
    this.indexer.projectedTotalIssuedUnits = issued;
    this.indexer.projectedTotalRedeemedUnits = redeemed;
    this.indexer.projectedTotalOutstandingUnits = Math.max(0, issued - redeemed);
    return this.indexer;
  }
}
