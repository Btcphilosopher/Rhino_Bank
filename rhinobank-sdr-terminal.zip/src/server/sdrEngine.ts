import {
  FxRateComponent,
  ObservationStatus,
  SdrBasketDefinition,
  SdrObservation,
} from '../shared/types.ts';
import { ManagedKeyPair, sha256Hex, signPayload } from './crypto.ts';

export const IMF_2022_BASKET: SdrBasketDefinition = {
  basketVersionId: 'IMF-2022-R1',
  effectiveFrom: '2022-08-01T00:00:00Z',
  effectiveUntil: '2027-07-31T23:59:59Z',
  methodologyName: 'IMF Rule O-1 SDR Basket Valuation (2022 Quinquennial Review)',
  imfRuleReference: 'IMF Executive Board Decision No. 17237-(22/45) · Rule O-1 & Rule O-2',
  roundingDecimals: 6,
  stalenessMaxAgeSeconds: 86400, // 24h for daily fixing observations
  disagreementThresholdBps: 15, // 15 bps max divergence vs secondary benchmark feed
  currencies: [
    {
      currency: 'USD',
      name: 'U.S. Dollar',
      fixedAmount: 0.57813,
      targetWeightPct: 43.38,
      quoteConvention: 'DIRECT_USD_PER_CCY',
      sourceFixing: 'Numeraire (1.000000 USD)',
    },
    {
      currency: 'EUR',
      name: 'Euro',
      fixedAmount: 0.37379,
      targetWeightPct: 29.31,
      quoteConvention: 'DIRECT_USD_PER_CCY',
      sourceFixing: 'ECB / London Noon USD per EUR',
    },
    {
      currency: 'CNY',
      name: 'Chinese Renminbi',
      fixedAmount: 1.0993,
      targetWeightPct: 12.28,
      quoteConvention: 'INDIRECT_CCY_PER_USD',
      sourceFixing: 'CFETS / PBoC CNY per USD (inverted 1/q)',
    },
    {
      currency: 'JPY',
      name: 'Japanese Yen',
      fixedAmount: 13.452,
      targetWeightPct: 7.59,
      quoteConvention: 'INDIRECT_CCY_PER_USD',
      sourceFixing: 'BoJ / Tokyo Noon JPY per USD (inverted 1/q)',
    },
    {
      currency: 'GBP',
      name: 'Pound Sterling',
      fixedAmount: 0.08087,
      targetWeightPct: 7.44,
      quoteConvention: 'DIRECT_USD_PER_CCY',
      sourceFixing: 'BoE / London Noon USD per GBP',
    },
  ],
};

export interface FxQuotesPayload {
  USD: number; // Always 1.0
  EUR: number; // USD per EUR (e.g. 1.0845)
  CNY: number; // CNY per USD (e.g. 7.1850)
  JPY: number; // JPY per USD (e.g. 153.20)
  GBP: number; // USD per GBP (e.g. 1.2710)
}

export function roundTo(value: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.round((value + Number.EPSILON) * factor) / factor;
}

export function reconstructSdrValueUsd(
  quotes: FxQuotesPayload,
  basket: SdrBasketDefinition = IMF_2022_BASKET,
  sourceLabel = 'London Noon Benchmark / IMF Rule O-1'
): { reconstructedSdrUsd: number; components: FxRateComponent[] } {
  const rawComponents = basket.currencies.map((ccy) => {
    const quotedRate = quotes[ccy.currency];
    if (!Number.isFinite(quotedRate) || quotedRate <= 0) {
      throw new Error(`Invalid FX quote for ${ccy.currency}: ${quotedRate}`);
    }
    const usdPerUnit =
      ccy.quoteConvention === 'DIRECT_USD_PER_CCY' ? quotedRate : 1 / quotedRate;
    const usdContribution = ccy.fixedAmount * usdPerUnit;
    return {
      currency: ccy.currency,
      quotedRate,
      usdPerUnit: roundTo(usdPerUnit, 8),
      usdContribution: roundTo(usdContribution, 8),
      source: `${sourceLabel} (${ccy.sourceFixing})`,
    };
  });

  const unroundedTotal = rawComponents.reduce((acc, item) => acc + item.usdContribution, 0);
  const reconstructedSdrUsd = roundTo(unroundedTotal, basket.roundingDecimals);

  const components: FxRateComponent[] = rawComponents.map((item) => ({
    ...item,
    effectiveWeightPct: roundTo((item.usdContribution / unroundedTotal) * 100, 2),
  }));

  return { reconstructedSdrUsd, components };
}

export interface CreateObservationParams {
  observationId: string;
  quotes: FxQuotesPayload;
  officialPublishedSdrUsd?: number;
  secondaryBenchmarkSdrUsd?: number;
  intradayIndicativeSdrUsd?: number;
  source: string;
  secondarySource?: string;
  effectiveTime: string;
  retrievalTime: string;
  oracleKey: ManagedKeyPair;
  supersedesObservationId?: string;
  forceFallback?: boolean;
  lastValidObservation?: SdrObservation;
}

export function buildSignedSdrObservation(params: CreateObservationParams): SdrObservation {
  const basket = IMF_2022_BASKET;
  const effectiveMs = Date.parse(params.effectiveTime);
  const retrievalMs = Date.parse(params.retrievalTime);
  if (Number.isNaN(effectiveMs) || Number.isNaN(retrievalMs)) {
    throw new Error('Invalid observation timestamps');
  }

  const ageSeconds = Math.max(0, (retrievalMs - effectiveMs) / 1000);
  const { reconstructedSdrUsd, components } = reconstructSdrValueUsd(
    params.quotes,
    basket,
    params.source
  );

  const officialPublishedSdrUsd =
    params.officialPublishedSdrUsd !== undefined
      ? roundTo(params.officialPublishedSdrUsd, basket.roundingDecimals)
      : reconstructedSdrUsd;

  const secondaryBenchmark =
    params.secondaryBenchmarkSdrUsd !== undefined
      ? params.secondaryBenchmarkSdrUsd
      : reconstructedSdrUsd;

  const spreadBpsVsSecondary = roundTo(
    (Math.abs(reconstructedSdrUsd - secondaryBenchmark) / secondaryBenchmark) * 10000,
    2
  );

  const intradayIndicativeSdrUsd =
    params.intradayIndicativeSdrUsd !== undefined
      ? roundTo(params.intradayIndicativeSdrUsd, basket.roundingDecimals)
      : roundTo(reconstructedSdrUsd * 1.0003, basket.roundingDecimals);

  let status: ObservationStatus = 'PUBLISHED';
  let fallbackMethod: string | undefined;

  if (params.supersedesObservationId) {
    status = 'CORRECTED';
  } else if (ageSeconds > basket.stalenessMaxAgeSeconds) {
    if (params.forceFallback && params.lastValidObservation) {
      status = 'FALLBACK_USED';
      fallbackMethod = `Contractual Fallback §4.3: Last Official IMF Fixing (${params.lastValidObservation.observationId})`;
    } else {
      status = 'REJECTED_STALE';
    }
  } else if (spreadBpsVsSecondary > basket.disagreementThresholdBps) {
    status = 'DISAGREEMENT_FLAGGED';
  }

  const effectiveReconstructed =
    status === 'FALLBACK_USED' && params.lastValidObservation
      ? params.lastValidObservation.reconstructedSdrUsd
      : reconstructedSdrUsd;

  const corePayload = {
    observationId: params.observationId,
    basketVersionId: basket.basketVersionId,
    source: params.source,
    effectiveTime: params.effectiveTime,
    retrievalTime: params.retrievalTime,
    status,
    officialPublishedSdrUsd,
    reconstructedSdrUsd: effectiveReconstructed,
    spreadBpsVsSecondary,
    supersedesObservationId: params.supersedesObservationId ?? null,
  };

  const payloadHash = sha256Hex(corePayload);
  const oracleSignature = signPayload(corePayload, params.oracleKey.privateKeyPem);

  return {
    observationId: params.observationId,
    basketVersionId: basket.basketVersionId,
    source: params.source,
    secondarySource: params.secondarySource ?? 'WM/Refinitiv London 16:00 Benchmark (Simulated)',
    effectiveTime: params.effectiveTime,
    retrievalTime: params.retrievalTime,
    publishedAt: new Date().toISOString(),
    status,
    officialPublishedSdrUsd,
    reconstructedSdrUsd: effectiveReconstructed,
    intradayIndicativeSdrUsd,
    spreadBpsVsSecondary,
    fallbackMethod,
    supersedesObservationId: params.supersedesObservationId,
    components,
    oracleSignerKeyId: params.oracleKey.keyId,
    oracleSignature,
    payloadHash,
    chainFinalised: false,
  };
}
