import crypto from 'node:crypto';

export interface ManagedKeyPair {
  keyId: string;
  roleName: string;
  authorityScope: string;
  publicKeyPem: string;
  privateKeyPem: string;
  publicKeyFingerprint: string;
  status: 'ACTIVE' | 'ROTATED_REVOKED';
  createdAt: string;
}

export function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => canonicalJson(item)).join(',')}]`;
  }
  const obj = value as Record<string, unknown>;
  const keys = Object.keys(obj).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(obj[k])}`).join(',')}}`;
}

export function sha256Hex(input: string | object): string {
  const serialized = typeof input === 'string' ? input : canonicalJson(input);
  return '0x' + crypto.createHash('sha256').update(serialized).digest('hex');
}

export function generateEd25519Key(
  keyId: string,
  roleName: string,
  authorityScope: string
): ManagedKeyPair {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519', {
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });
  const fingerprint = crypto
    .createHash('sha256')
    .update(publicKey)
    .digest('hex')
    .slice(0, 24);

  return {
    keyId,
    roleName,
    authorityScope,
    publicKeyPem: publicKey,
    privateKeyPem: privateKey,
    publicKeyFingerprint: `ed25519:${fingerprint}`,
    status: 'ACTIVE',
    createdAt: new Date().toISOString(),
  };
}

export function signPayload(payload: unknown, privateKeyPem: string): string {
  const data = Buffer.from(typeof payload === 'string' ? payload : canonicalJson(payload), 'utf8');
  const signature = crypto.sign(null, data, privateKeyPem);
  return signature.toString('base64url');
}

export function verifyPayloadSignature(
  payload: unknown,
  signatureBase64Url: string,
  publicKeyPem: string
): boolean {
  try {
    const data = Buffer.from(typeof payload === 'string' ? payload : canonicalJson(payload), 'utf8');
    const sig = Buffer.from(signatureBase64Url, 'base64url');
    return crypto.verify(null, data, publicKeyPem, sig);
  } catch {
    return false;
  }
}

const SECRET_KEYS = /privatekey|secret|mnemonic|seed|password|apikey|token/i;

export function redactSensitiveFields<T>(input: T): T {
  if (input === null || typeof input !== 'object') {
    return input;
  }
  if (Array.isArray(input)) {
    return input.map((item) => redactSensitiveFields(item)) as unknown as T;
  }
  const output: Record<string, unknown> = {};
  for (const [key, val] of Object.entries(input as Record<string, unknown>)) {
    if (SECRET_KEYS.test(key)) {
      output[key] = '[REDACTED]';
    } else if (typeof val === 'string' && val.includes('BEGIN PRIVATE KEY')) {
      output[key] = '[REDACTED_PEM_KEY]';
    } else {
      output[key] = redactSensitiveFields(val);
    }
  }
  return output as T;
}
