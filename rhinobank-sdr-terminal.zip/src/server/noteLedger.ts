import {
  AuditLogEntry,
  CouponObligation,
  DealerRfq,
  DemoStepState,
  HoldingPosition,
  InvestorAccount,
  MarketListing,
  NoteSeriesRecord,
  OperatorRole,
  PlatformStateSnapshot,
  RedemptionInstruction,
  SdrObservation,
  SecondaryTrade,
  SubscriptionOrder,
  TreasurySnapshot,
} from '../shared/types.ts';
import {
  generateEd25519Key,
  ManagedKeyPair,
  redactSensitiveFields,
  sha256Hex,
  signPayload,
  verifyPayloadSignature,
} from './crypto.ts';
import { PosConsensusNetwork } from './posChain.ts';
import { buildSignedSdrObservation, FxQuotesPayload, IMF_2022_BASKET, roundTo } from './sdrEngine.ts';

export class RhinoSdrNotePlatform {
  public keys: ManagedKeyPair[] = [];
  public chain: PosConsensusNetwork;
  public observations: SdrObservation[] = [];
  public series: NoteSeriesRecord[] = [];
  public subscriptions: SubscriptionOrder[] = [];
  public investors: InvestorAccount[] = [];
  public holdings: HoldingPosition[] = [];
  public listings: MarketListing[] = [];
  public rfqs: DealerRfq[] = [];
  public trades: SecondaryTrade[] = [];
  public coupons: CouponObligation[] = [];
  public redemptions: RedemptionInstruction[] = [];
  public treasury!: TreasurySnapshot;
  public auditLogs: AuditLogEntry[] = [];
  public demoSteps: DemoStepState[] = [];
  private usedIdempotencyKeys = new Set<string>();
  private usedPaymentEventIds = new Set<string>();
  private oracleFeedAllowedSource = 'IMF Official Daily Fixing / London Noon Benchmark';

  constructor() {
    this.chain = new PosConsensusNetwork();
    this.seedInitialState();
  }

  public reset(): void {
    this.keys = [];
    this.chain = new PosConsensusNetwork();
    this.observations = [];
    this.series = [];
    this.subscriptions = [];
    this.investors = [];
    this.holdings = [];
    this.listings = [];
    this.rfqs = [];
    this.trades = [];
    this.coupons = [];
    this.redemptions = [];
    this.auditLogs = [];
    this.usedIdempotencyKeys.clear();
    this.usedPaymentEventIds.clear();
    this.seedInitialState();
  }

  private getActiveKeyByRole(roleName: string): ManagedKeyPair {
    const key = this.keys.find((k) => k.roleName === roleName && k.status === 'ACTIVE');
    if (!key) throw new Error(`No active signing key found for role ${roleName}`);
    return key;
  }

  private logAudit(params: {
    actorRole: OperatorRole;
    actorKeyId: string;
    action: string;
    resourceId: string;
    outcome: AuditLogEntry['outcome'];
    detail: string;
    payload?: unknown;
  }): void {
    const sanitized = params.payload ? redactSensitiveFields(params.payload) : { detail: params.detail };
    this.auditLogs.unshift({
      logId: `AUD-${String(this.auditLogs.length + 1).padStart(4, '0')}`,
      timestamp: new Date().toISOString(),
      actorRole: params.actorRole,
      actorKeyId: params.actorKeyId,
      action: params.action,
      resourceId: params.resourceId,
      outcome: params.outcome,
      detail: params.detail,
      payloadHash: sha256Hex(sanitized),
    });
  }

  private seedInitialState(): void {
    // 1. Provision Role-Separated Ed25519 Keys
    this.keys = [
      generateEd25519Key('KEY-ISSUER-01', 'ISSUER_AUTHORITY', 'Propose series, authorise issuance'),
      generateEd25519Key('KEY-RISK-DUAL-01', 'RISK_DUAL_APPROVER', 'Review terms, countersign issuance & coupons'),
      generateEd25519Key('KEY-ORACLE-01', 'ORACLE_ADAPTER', 'Sign and submit dated SDR observations'),
      generateEd25519Key('KEY-PAUSER-01', 'EMERGENCY_PAUSER', 'Pause issuance / restrict transfers only'),
      generateEd25519Key('KEY-GOV-TIMELOCK-01', 'TIMELOCK_GOVERNANCE', 'Propose/execute 48h timelocked contract upgrades'),
      generateEd25519Key('KEY-TREASURY-01', 'TREASURY_OPS', 'Reconcile bank payments & treasury earmarks'),
    ];

    // 2. Seed Synthetic Institutional Investors
    this.investors = [
      {
        investorId: 'INV-ZURICH-PEN',
        legalName: 'Helvetia Sovereign & Pension Fund (Synthetic)',
        lei: '549300SYNTHETICZURICH01',
        jurisdiction: 'CH',
        walletAddress: '0x742d35Cc6634C0532925a3b844Bc454e4438f10a',
        kycStatus: 'APPROVED',
        eligibilityTier: 'QUALIFIED_INSTITUTIONAL_BUYER',
        recoveryPolicy: 'MULTI_PARTY_LEGAL_COURT_REISSUE_ONLY',
      },
      {
        investorId: 'INV-NORDIC-INS',
        legalName: 'Nordic Maritime Reinsurance Corp (Synthetic)',
        lei: '549300SYNTHETICNORDIC02',
        jurisdiction: 'NO',
        walletAddress: '0x9B3a2F88E1C904A3114420e918B2d51109F18c22',
        kycStatus: 'APPROVED',
        eligibilityTier: 'QUALIFIED_INSTITUTIONAL_BUYER',
        recoveryPolicy: 'MULTI_PARTY_LEGAL_COURT_REISSUE_ONLY',
      },
      {
        investorId: 'INV-UK-ASSET',
        legalName: 'Thames Fixed Income Partners LLP (Synthetic)',
        lei: '549300SYNTHETICTHAMES03',
        jurisdiction: 'GB',
        walletAddress: '0x3E1c8A41F00b2199C5410A9E12C17710aD99B410',
        kycStatus: 'APPROVED',
        eligibilityTier: 'QUALIFIED_INSTITUTIONAL_BUYER',
        recoveryPolicy: 'MULTI_PARTY_LEGAL_COURT_REISSUE_ONLY',
      },
      {
        investorId: 'INV-RESTRICTED-04',
        legalName: 'Unverified Offshore Vehicle Ltd (Ineligible Test)',
        lei: '549300UNVERIFIED000004',
        jurisdiction: 'XX',
        walletAddress: '0x000000000000000000000000000000000000dEaD',
        kycStatus: 'RESTRICTED',
        eligibilityTier: 'NON_ELIGIBLE',
        recoveryPolicy: 'MULTI_PARTY_LEGAL_COURT_REISSUE_ONLY',
      },
    ];

    // 3. Initial Official SDR Observation
    const oracleKey = this.getActiveKeyByRole('ORACLE_ADAPTER');
    const initialQuotes: FxQuotesPayload = {
      USD: 1.0,
      EUR: 1.0845,
      CNY: 7.185,
      JPY: 153.2,
      GBP: 1.271,
    };

    const obs1 = buildSignedSdrObservation({
      observationId: 'OBS-2026-11-14-FIX',
      quotes: initialQuotes,
      source: this.oracleFeedAllowedSource,
      effectiveTime: '2026-11-14T16:00:00Z',
      retrievalTime: '2026-11-14T16:05:12Z',
      oracleKey,
    });

    const obsTx = this.chain.submitTransaction({
      txType: 'PUBLISH_OBSERVATION',
      seriesId: 'ORACLE-REGISTRY',
      callerAddress: '0xOracleAdapter0001',
      signerKey: oracleKey,
      payloadSummary: `Publish SDR Observation ${obs1.observationId} (${obs1.reconstructedSdrUsd} USD/SDR)`,
      payload: { observationId: obs1.observationId, payloadHash: obs1.payloadHash },
      eventsToEmit: [
        {
          eventName: 'SDR_OBSERVATION_PUBLISHED',
          args: {
            observationId: obs1.observationId,
            basketVersionId: obs1.basketVersionId,
            reconstructedSdrUsd: obs1.reconstructedSdrUsd,
          },
        },
      ],
    });
    obs1.chainTxHash = obsTx.tx.txHash;
    obs1.chainFinalised = true;
    this.observations.push(obs1);

    // 4. Seed Note Series: RhinoBank SDR-Linked Note — Series 2027-A (starts at Approved / Subscription Open? Let's start in Draft->Approved or allow 12-step walk from Approved/Issued, actually let's create Series 2027-A at 'Draft' OR let's make Series 2027-A ready at Step 1 and also provide a "Reset to Step 1" vs "Execute All 12 Demo Steps"!)
    // Wait: Prompt says "Begin with one complete note series and a working issuance-to-redemption demonstration."
    // Let's seed Series 2027-A in 'Draft' ONLY if we want the user to click through, OR better: seed Series 2027-A at 'Approved' with a second live series OR seed Series 2027-A already through step 1 (Defined) so Overview immediately shows rich live data AND clicking "Run Next Step" / "Run Full 12-Step Demo" advances through the full lifecycle seamlessly!
    // Even better: let's pre-populate Series 2027-A up to Step 8 (Issued + Holdings + Observation + Listed) OR have a clean initial state at Step 1 (Draft Defined) AND a 1-click "Run Complete 12-Step Demonstration" button + individual step buttons! Wait: if an evaluator opens the app for the first time, they expect to see populated tables on Holdings, Trade, Treasury, Validators, Audit, and Notes immediately without an empty dashboard!
    // Let's seed Series 2027-A cleanly at Step 8 (Issued 10,000 units to Helvetia Sovereign & Pension Fund, listed on Markets, 1 observation published) AND provide a secondary Series 2027-B in 'Draft' for live issuance testing, PLUS let the user run Steps 9–12 or "Replay Full 12-Step Demo from Step 1" at any time! That way every single tab (Overview, Notes, Issue, SDR Reference, Trade, Holdings, Validators, Treasury, Settlement, Audit) is richly populated on first load AND every single workflow can be executed live!
    this.seedSeries2027AAndInitialDemo(obs1);
  }

  private seedSeries2027AAndInitialDemo(obs1: SdrObservation): void {
    const terms = {
      schemaVersion: '2026.1-SDR-NOTE',
      seriesId: 'RB-SDR-2027-A',
      instrumentId: 'INST-RB-2027-A',
      isinSimulated: 'XS2027000199-SIM',
      seriesName: 'RhinoBank SDR-Linked Note — Series 2027-A',
      issuerIdentity: {
        legalName: 'RhinoBank Institutional Markets AG (Testnet Simulation)',
        lei: '549300RHINOBANKTEST01',
        jurisdiction: 'Switzerland (FINMA-Style Institutional Sandbox)',
        obligationNature: 'PRIVATE_UNSECURED_SENIOR_NOTE' as const,
      },
      issueDate: '2026-11-15',
      maturityDate: '2027-11-15',
      principalDenominationSdr: 1000,
      unitParSdr: 1000,
      supplyCapUnits: 50000,
      couponFormula: {
        type: 'FIXED_ON_SDR_NOTIONAL' as const,
        annualRateBps: 425, // 4.25% p.a. on SDR principal
        dayCountConvention: 'ACT/360' as const,
        observationSchedule: 'QUARTERLY' as const,
        paymentLagBusinessDays: 2,
      },
      subscriptionCurrency: 'USD' as const,
      settlementCurrency: 'USD' as const,
      redemptionMethod: 'CASH_USD_EQUIVALENT_AT_FINAL_OBSERVATION' as const,
      sdrReferenceMethodology: 'IMF Rule O-1 Weighted Currency Basket (USD Equivalent at Dated Fixing)',
      basketVersionId: IMF_2022_BASKET.basketVersionId,
      valuationSourcePolicy: 'IMF Official Daily Fixing; fallback to 3-Dealer London Noon Median after 24h',
      fxConversionAndRoundingRules: 'V_USD = sum(a_i * r_i), direct USD/EUR & USD/GBP, inverted CNY/USD & JPY/USD, rounded to 6 decimals',
      transferRestrictions: {
        regime: 'WHITELISTED_ELIGIBLE_INSTITUTIONAL_ONLY' as const,
        lockupUntil: '2026-11-15T00:00:00Z',
        jurisdictionWhitelist: ['CH', 'NO', 'GB', 'SG', 'DE'],
        requireOffchainTransferApproval: true,
      },
      investorEligibilityPolicy: 'Qualified Institutional Buyers (KYC Approved & Jurisdiction Whitelisted)',
      rankingAndCollateralTerms:
        'Senior unsecured private issuer obligation of RhinoBank. Not an official IMF SDR allocation; not backed by validator staking balances.',
      termSheetDocumentRef: 's3://rhinobank-docs-sim/series-2027-a/term-sheet-v1.pdf',
      termSheetCommitmentHash: '',
      governingDocumentRefs: [
        {
          title: 'Series 2027-A Offering Memorandum & Pricing Supplement',
          uri: 's3://rhinobank-docs-sim/series-2027-a/offering-memo-v1.pdf',
          sha256: sha256Hex({ doc: 'Series 2027-A Offering Memorandum', version: '1.0' }),
        },
        {
          title: 'SDR Basket Methodology & Fallback Schedule (§4.3)',
          uri: 's3://rhinobank-docs-sim/series-2027-a/sdr-schedule-v1.pdf',
          sha256: sha256Hex({ doc: 'SDR Basket Methodology Schedule', version: '1.0' }),
        },
      ],
    };
    terms.termSheetCommitmentHash = sha256Hex({
      seriesId: terms.seriesId,
      principalDenominationSdr: terms.principalDenominationSdr,
      supplyCapUnits: terms.supplyCapUnits,
      couponFormula: terms.couponFormula,
      basketVersionId: terms.basketVersionId,
      maturityDate: terms.maturityDate,
    });

    const issuerKey = this.getActiveKeyByRole('ISSUER_AUTHORITY');
    const riskKey = this.getActiveKeyByRole('RISK_DUAL_APPROVER');
    const issuerSig = signPayload({ termSheetCommitmentHash: terms.termSheetCommitmentHash }, issuerKey.privateKeyPem);
    const dualSig = signPayload({ termSheetCommitmentHash: terms.termSheetCommitmentHash, approved: true }, riskKey.privateKeyPem);

    const series2027A: NoteSeriesRecord = {
      seriesId: 'RB-SDR-2027-A',
      contractVersion: 'RhinoSDRNote-v1.0.0',
      contractAddress: '0xA1B2C3D4E5F60718293A4B5C6D7E8F9012342027',
      terms,
      lifecycleStage: 'Issued',
      issuanceApprovalRefs: {
        issuerSignerKeyId: issuerKey.keyId,
        issuerSignature: issuerSig,
        dualApproverKeyId: riskKey.keyId,
        dualApprovalSignature: dualSig,
        approvedAt: '2026-11-15T09:18:00Z',
      },
      quantities: {
        authorisedUnits: 10000,
        subscribedUnits: 10000,
        fundedUnits: 10000,
        issuedUnits: 10000,
        outstandingUnits: 10000,
        redeemedUnits: 0,
      },
      controls: {
        issuancePaused: false,
        transfersRestricted: false,
        lastOracleConfigChangeAt: '2026-11-15T09:12:00Z',
      },
      latestObservationId: obs1.observationId,
      privateNoteMarketPricePctPar: 99.85,
    };

    this.series.push(series2027A);

    // Deploy series on chain
    this.chain.submitTransaction({
      txType: 'DEPLOY_SERIES',
      seriesId: series2027A.seriesId,
      callerAddress: '0xIssuerAuthority0001',
      signerKey: issuerKey,
      payloadSummary: `Deploy ${series2027A.seriesId} (Cap: 50,000 units, Commitment: ${terms.termSheetCommitmentHash.slice(0, 14)}...)`,
      payload: {
        seriesId: series2027A.seriesId,
        termSheetCommitmentHash: terms.termSheetCommitmentHash,
        supplyCapUnits: terms.supplyCapUnits,
      },
      eventsToEmit: [
        {
          eventName: 'SERIES_DEPLOYED',
          args: {
            seriesId: series2027A.seriesId,
            contractVersion: series2027A.contractVersion,
            supplyCapUnits: terms.supplyCapUnits,
          },
        },
      ],
    });

    // Primary Subscription & Issuance of 10,000 units to Helvetia Sovereign & Pension Fund
    const subUnits = 10000;
    const expectedUsd = roundTo(subUnits * terms.unitParSdr * obs1.reconstructedSdrUsd, 2);
    const subId = 'SUB-2027A-0001';
    const idemKey = 'IDEM-SEED-2027A-0001';
    this.usedIdempotencyKeys.add(idemKey);

    const issueTx = this.chain.submitTransaction({
      txType: 'ISSUE_NOTE',
      seriesId: series2027A.seriesId,
      callerAddress: '0xIssuerAuthority0001',
      signerKey: issuerKey,
      payloadSummary: `Mint ${subUnits.toLocaleString()} units (${(subUnits * 1000).toLocaleString()} SDR) to INV-ZURICH-PEN`,
      payload: {
        subscriptionId: subId,
        investorWallet: this.investors[0].walletAddress,
        units: subUnits,
        observationId: obs1.observationId,
      },
      eventsToEmit: [
        {
          eventName: 'NOTE_ISSUED',
          args: {
            seriesId: series2027A.seriesId,
            investorId: 'INV-ZURICH-PEN',
            units: subUnits,
            sdrFaceValue: subUnits * 1000,
          },
        },
      ],
    });

    this.subscriptions.push({
      subscriptionId: subId,
      idempotencyKey: idemKey,
      seriesId: series2027A.seriesId,
      investorId: this.investors[0].investorId,
      investorName: this.investors[0].legalName,
      requestedUnits: subUnits,
      allocatedUnits: subUnits,
      settlementCurrency: 'USD',
      sdrObservationIdUsed: obs1.observationId,
      expectedCashAmountUsd: expectedUsd,
      fundedCashAmountUsd: expectedUsd,
      settlementEvidenceRef: 'FEDWIRE-SIM-20261115-88412',
      status: 'ISSUED',
      createdAt: '2026-11-15T09:20:00Z',
      updatedAt: '2026-11-15T09:25:00Z',
      issuanceTxHash: issueTx.tx.txHash,
    });

    this.holdings.push({
      holdingId: 'HLD-ZURICH-2027A',
      investorId: this.investors[0].investorId,
      investorName: this.investors[0].legalName,
      walletAddress: this.investors[0].walletAddress,
      seriesId: series2027A.seriesId,
      units: subUnits,
      sdrFaceValue: subUnits * terms.unitParSdr,
      acquisitionRecords: [
        {
          acquisitionId: 'ACQ-0001',
          type: 'PRIMARY_ISSUANCE',
          units: subUnits,
          sdrCostPerUnit: terms.unitParSdr,
          usdEquivalentAtTrade: expectedUsd,
          timestamp: '2026-11-15T09:25:00Z',
          txHash: issueTx.tx.txHash,
        },
      ],
      accruedEntitlementSdr: 0,
      indicativeUsdValue: roundTo(expectedUsd * 0.9985, 2),
      transferAvailability: 'AVAILABLE_ELIGIBLE',
      encumbrancesUnits: 0,
      maturityDate: terms.maturityDate,
    });

    // Listing in RhinoBank SDR Markets Terminal
    this.listings.push({
      listingId: 'LST-RB-SDR-2027-A',
      seriesId: series2027A.seriesId,
      venueName: 'RhinoBank SDR Markets (Institutional OTC RFQ Venue)',
      admissionStatus: 'ADMITTED_FOR_RFQ',
      executionPermissionRequired: 'Whitelisted QIB + Bilateral Dealer Onboarding',
      indicativeBidPctPar: 99.75,
      indicativeAskPctPar: 99.95,
      indicativeModelSdrValue: subUnits * terms.unitParSdr,
      indicativeModelUsdValue: roundTo(expectedUsd * 0.9985, 2),
      disclaimer:
        'Informational listing & dealer RFQ only. Listing does not constitute IMF SDR conversion, public exchange admission, or execution guarantee.',
    });

    // Seed a scheduled Coupon Period 1
    this.coupons.push({
      couponId: 'CPN-2027A-Q1',
      paymentEventId: 'PAY-EVT-CPN-2027A-Q1',
      seriesId: series2027A.seriesId,
      periodLabel: 'Q1 Coupon Period (90 Days · ACT/360)',
      observationDate: '2027-02-15',
      outstandingUnitsSnapshot: subUnits,
      accruedDays: 90,
      annualRateBps: 425,
      grossCouponSdr: roundTo(subUnits * 1000 * 0.0425 * (90 / 360), 2),
      fxUsdPerSdrUsed: obs1.reconstructedSdrUsd,
      grossCouponUsd: roundTo(subUnits * 1000 * 0.0425 * (90 / 360) * obs1.reconstructedSdrUsd, 2),
      status: 'Scheduled',
      notes: 'Requires dated SDR fixing observation and dual approval before bank-rail payment instruction.',
    });

    // Seed Treasury & Backing Snapshot (explicitly segregated!)
    this.recomputeTreasury(expectedUsd, subUnits, obs1.reconstructedSdrUsd);

    // Seed 12 Demo Steps reflecting completed vs pending
    this.demoSteps = [
      { stepNumber: 1, title: 'Define Series 2027-A & IMF Rule O-1 SDR Reference', responsibility: 'Issuer Service', completed: true, evidenceRef: terms.termSheetCommitmentHash.slice(0, 16) },
      { stepNumber: 2, title: 'Dual-Approve Contractual Terms & Commit Hash', responsibility: 'Issuer Service', completed: true, evidenceRef: issuerKey.keyId + ' + ' + riskKey.keyId },
      { stepNumber: 3, title: 'Receive & Fund Institutional Subscription (10,000 Units)', responsibility: 'Issuer Service', completed: true, evidenceRef: 'FEDWIRE-SIM-20261115-88412' },
      { stepNumber: 4, title: 'Authorise Issuance Under Dual Signatures & Supply Cap', responsibility: 'Issuer Service', completed: true, evidenceRef: 'Authorised 10,000 / 50,000' },
      { stepNumber: 5, title: 'Submit Issuance Transaction to Note Contract', responsibility: 'Note Contract', completed: true, evidenceRef: issueTx.tx.txHash.slice(0, 16) },
      { stepNumber: 6, title: 'Validate & Finalise Under PoS Casper FFG Consensus', responsibility: 'PoS Validators', completed: true, evidenceRef: `Block #${this.chain.indexer.finalisedChainBlock}` },
      { stepNumber: 7, title: 'Project Finalised Investor Note Holdings & Restrictions', responsibility: 'Note Contract', completed: true, evidenceRef: '10,000 Units · INV-ZURICH-PEN' },
      { stepNumber: 8, title: 'Publish Dated SDR Observation via Signed Oracle Adapter', responsibility: 'Oracle Adapter', completed: false },
      { stepNumber: 9, title: 'Verify Listing & Indicative vs Firm Quote Separation', responsibility: 'SDR Markets', completed: false },
      { stepNumber: 10, title: 'Complete Simulated Secondary Trade & Bank-Rail Settlement', responsibility: 'SDR Markets', completed: false },
      { stepNumber: 11, title: 'Calculate & Approve Q1 Coupon Obligation', responsibility: 'Treasury & Settlement', completed: false },
      { stepNumber: 12, title: 'Confirm Redemption Payment & Retire Units On-Chain', responsibility: 'Treasury & Settlement', completed: false },
    ];

    this.logAudit({
      actorRole: 'ISSUER_OFFICER',
      actorKeyId: issuerKey.keyId,
      action: 'INITIALIZE_SERIES_2027_A',
      resourceId: series2027A.seriesId,
      outcome: 'ALLOWED',
      detail: 'Seeded RhinoBank SDR-Linked Note — Series 2027-A (10,000 units issued & finalised on PoS testnet).',
      payload: { seriesId: series2027A.seriesId, issuedUnits: subUnits },
    });
  }

  private recomputeTreasury(subscriptionCashUsd: number, outstandingUnits: number, sdrUsd: number): void {
    const outstandingSdr = outstandingUnits * 1000;
    const outstandingUsd = roundTo(outstandingSdr * sdrUsd, 2);
    const accruedCouponsUsd = roundTo(
      this.coupons
        .filter((c) => c.status !== 'Reconciled')
        .reduce((sum, c) => sum + c.grossCouponUsd, 0),
      2
    );

    // Replicate SDR currency proportions operationally (NOT official IMF SDR holdings!)
    this.treasury = {
      valuationDate: new Date().toISOString(),
      verificationScope:
        'Internal simulated operational ledger reconciliation only. Independent external custody/reserve audit NOT performed in simulation.',
      backingClassification:
        'Unsecured senior private issuer obligation with operationally earmarked FX liquidity portfolio (NOT legally ring-fenced collateral trust; NOT official IMF SDR holdings).',
      accounts: [
        {
          accountId: 'ACC-SUB-PROCEEDS-01',
          category: 'INVESTOR_SUBSCRIPTION_PROCEEDS',
          description: 'Cash proceeds received from Series 2027-A primary subscriptions & liquidity buffer',
          balanceUsd: roundTo(subscriptionCashUsd, 2),
          encumberedUsd: 0,
          legalRingfence: 'Issuer Operational Segregated Cash Ledger (Unencumbered)',
        },
        {
          accountId: 'ACC-ISSUER-CAP-01',
          category: 'ISSUER_GENERAL_CAPITAL',
          description: 'RhinoBank regulatory equity & balance sheet capital buffer',
          balanceUsd: 25000000,
          encumberedUsd: 0,
          legalRingfence: 'General Issuer Equity (Available for Credit Support)',
        },
        {
          accountId: 'ACC-EARMARK-FX-01',
          category: 'OPERATIONALLY_EARMARKED_LIQUIDITY',
          description: 'Five-currency FX liquidity portfolio replicating SDR basket weights',
          balanceUsd: roundTo(outstandingUsd * 1.015, 2),
          encumberedUsd: 0,
          legalRingfence: 'Operationally Earmarked (Unsecured Note — No Security Interest Granted)',
        },
        {
          accountId: 'ACC-COLLATERAL-01',
          category: 'COLLATERAL_RESERVE',
          description: 'Dedicated pledged collateral reserve (0 USD — Series 2027-A is Senior Unsecured)',
          balanceUsd: 0,
          encumberedUsd: 0,
          legalRingfence: 'Not Applicable to Unsecured Series 2027-A',
        },
        {
          accountId: 'ACC-VALIDATOR-STAKE-01',
          category: 'VALIDATOR_STAKING_WALLET_SEPARATE',
          description: 'Separate PoS Validator Bonded Stake (3,700 ETH · Strictly Non-Collateral)',
          balanceUsd: 11840000,
          encumberedUsd: 11840000,
          legalRingfence: 'Protocol Consensus Bond ONLY — Subject to Gasper Slashing; Zero Recourse for Note Holders',
        },
      ],
      currencyHoldings: [
        { currency: 'USD', amount: roundTo(outstandingUsd * 0.4338, 2), usdEquivalent: roundTo(outstandingUsd * 0.4338, 2), sdrReplicatingWeightPct: 43.38 },
        { currency: 'EUR', amount: roundTo((outstandingUsd * 0.2931) / 1.0845, 2), usdEquivalent: roundTo(outstandingUsd * 0.2931, 2), sdrReplicatingWeightPct: 29.31 },
        { currency: 'CNY', amount: roundTo(outstandingUsd * 0.1228 * 7.185, 2), usdEquivalent: roundTo(outstandingUsd * 0.1228, 2), sdrReplicatingWeightPct: 12.28 },
        { currency: 'JPY', amount: roundTo(outstandingUsd * 0.0759 * 153.2, 0), usdEquivalent: roundTo(outstandingUsd * 0.0759, 2), sdrReplicatingWeightPct: 7.59 },
        { currency: 'GBP', amount: roundTo((outstandingUsd * 0.0744) / 1.271, 2), usdEquivalent: roundTo(outstandingUsd * 0.0744, 2), sdrReplicatingWeightPct: 7.44 },
      ],
      hedgingPositions: [
        {
          hedgeId: 'HDG-FX-EURUSD-01',
          instrument: 'EUR/USD 1Y Deliverable FX Forward (Buy EUR / Sell USD)',
          notionalUsd: roundTo(outstandingUsd * 0.2931, 2),
          counterparty: 'Clearing Bank Alpha (Simulated CSA)',
          mtmUsd: 18420.5,
          maturityDate: '2027-11-13',
        },
        {
          hedgeId: 'HDG-FX-CNYJPY-02',
          instrument: 'CNY & JPY Non-Deliverable Basket Swap',
          notionalUsd: roundTo(outstandingUsd * 0.1987, 2),
          counterparty: 'Clearing Bank Beta (Simulated CSA)',
          mtmUsd: -6140.25,
          maturityDate: '2027-11-13',
        },
      ],
      liabilities: {
        totalIssuedNotesSdr: this.series.reduce((s, n) => s + n.quantities.issuedUnits * n.terms.unitParSdr, 0),
        totalOutstandingNotesSdr: outstandingSdr,
        totalOutstandingNotesUsd: outstandingUsd,
        accruedCouponsUsd,
      },
      maturityProfile: [
        { bucket: '0–30 Days (Operational Cash)', assetsUsd: roundTo(outstandingUsd * 0.25, 2), liabilitiesUsd: accruedCouponsUsd, netGapUsd: roundTo(outstandingUsd * 0.25 - accruedCouponsUsd, 2) },
        { bucket: '1–6 Months (T-Bills & FX Swaps)', assetsUsd: roundTo(outstandingUsd * 0.35, 2), liabilitiesUsd: 0, netGapUsd: roundTo(outstandingUsd * 0.35, 2) },
        { bucket: '6–12 Months (Series 2027-A Maturity)', assetsUsd: roundTo(outstandingUsd * 0.415, 2), liabilitiesUsd: outstandingUsd, netGapUsd: roundTo(outstandingUsd * 0.415 - outstandingUsd, 2) },
      ],
    };
  }

  public getLatestValidObservation(): SdrObservation {
    const valid = this.observations.find(
      (o) => o.status === 'PUBLISHED' || o.status === 'CORRECTED' || o.status === 'FALLBACK_USED'
    );
    if (!valid) throw new Error('No valid SDR observation available');
    return valid;
  }

  // ==================== ISSUER SERVICE: CREATE & ADVANCE NOTE SERIES ====================
  public createDraftSeries(input: {
    actorRole: OperatorRole;
    seriesId: string;
    seriesName: string;
    supplyCapUnits: number;
    annualRateBps: number;
    maturityDate: string;
    obligationNature: 'PRIVATE_UNSECURED_SENIOR_NOTE' | 'PRIVATE_COLLATERALISED_NOTE';
  }): NoteSeriesRecord {
    const issuerKey = this.getActiveKeyByRole('ISSUER_AUTHORITY');
    if (input.actorRole !== 'ISSUER_OFFICER') {
      this.logAudit({
        actorRole: input.actorRole,
        actorKeyId: 'UNAUTHORIZED',
        action: 'CREATE_DRAFT_SERIES',
        resourceId: input.seriesId,
        outcome: 'DENIED',
        detail: `Role ${input.actorRole} is not permitted to create note series.`,
      });
      throw new Error(`Unauthorised role ${input.actorRole}: ISSUER_OFFICER required`);
    }
    if (this.series.some((s) => s.seriesId === input.seriesId)) {
      throw new Error(`Series ${input.seriesId} already exists`);
    }
    if (input.supplyCapUnits <= 0) {
      throw new Error('Supply cap must be positive');
    }

    const latestObs = this.getLatestValidObservation();
    const terms = {
      schemaVersion: '2026.1-SDR-NOTE',
      seriesId: input.seriesId,
      instrumentId: `INST-${input.seriesId}`,
      isinSimulated: `XS${Date.now().toString().slice(-8)}-SIM`,
      seriesName: input.seriesName,
      issuerIdentity: {
        legalName: 'RhinoBank Institutional Markets AG (Testnet Simulation)',
        lei: '549300RHINOBANKTEST01',
        jurisdiction: 'Switzerland (FINMA-Style Institutional Sandbox)',
        obligationNature: input.obligationNature,
      },
      issueDate: new Date().toISOString().slice(0, 10),
      maturityDate: input.maturityDate,
      principalDenominationSdr: 1000,
      unitParSdr: 1000,
      supplyCapUnits: input.supplyCapUnits,
      couponFormula: {
        type: 'FIXED_ON_SDR_NOTIONAL' as const,
        annualRateBps: input.annualRateBps,
        dayCountConvention: 'ACT/360' as const,
        observationSchedule: 'QUARTERLY' as const,
        paymentLagBusinessDays: 2,
      },
      subscriptionCurrency: 'USD' as const,
      settlementCurrency: 'USD' as const,
      redemptionMethod: 'CASH_USD_EQUIVALENT_AT_FINAL_OBSERVATION' as const,
      sdrReferenceMethodology: 'IMF Rule O-1 Weighted Currency Basket (USD Equivalent at Dated Fixing)',
      basketVersionId: IMF_2022_BASKET.basketVersionId,
      valuationSourcePolicy: 'IMF Official Daily Fixing; fallback to 3-Dealer London Noon Median after 24h',
      fxConversionAndRoundingRules: 'V_USD = sum(a_i * r_i), 6 decimal rounding',
      transferRestrictions: {
        regime: 'WHITELISTED_ELIGIBLE_INSTITUTIONAL_ONLY' as const,
        lockupUntil: new Date().toISOString(),
        jurisdictionWhitelist: ['CH', 'NO', 'GB', 'SG', 'DE'],
        requireOffchainTransferApproval: true,
      },
      investorEligibilityPolicy: 'Qualified Institutional Buyers (KYC Approved & Jurisdiction Whitelisted)',
      rankingAndCollateralTerms:
        input.obligationNature === 'PRIVATE_COLLATERALISED_NOTE'
          ? 'Private collateralised issuer note; excludes validator stake.'
          : 'Senior unsecured private issuer obligation; not an official IMF SDR.',
      termSheetDocumentRef: `s3://rhinobank-docs-sim/${input.seriesId.toLowerCase()}/term-sheet-v1.pdf`,
      termSheetCommitmentHash: '',
      governingDocumentRefs: [
        {
          title: `${input.seriesName} Pricing Supplement`,
          uri: `s3://rhinobank-docs-sim/${input.seriesId.toLowerCase()}/pricing-supplement.pdf`,
          sha256: sha256Hex({ seriesId: input.seriesId, doc: 'Pricing Supplement' }),
        },
      ],
    };

    terms.termSheetCommitmentHash = sha256Hex({
      seriesId: terms.seriesId,
      principalDenominationSdr: terms.principalDenominationSdr,
      supplyCapUnits: terms.supplyCapUnits,
      couponFormula: terms.couponFormula,
      basketVersionId: terms.basketVersionId,
      maturityDate: terms.maturityDate,
    });

    const record: NoteSeriesRecord = {
      seriesId: input.seriesId,
      contractVersion: 'RhinoSDRNote-v1.0.0',
      contractAddress: `0x${sha256Hex(input.seriesId).slice(2, 42)}`,
      terms,
      lifecycleStage: 'Draft',
      issuanceApprovalRefs: {
        issuerSignerKeyId: issuerKey.keyId,
      },
      quantities: {
        authorisedUnits: 0,
        subscribedUnits: 0,
        fundedUnits: 0,
        issuedUnits: 0,
        outstandingUnits: 0,
        redeemedUnits: 0,
      },
      controls: {
        issuancePaused: false,
        transfersRestricted: false,
        lastOracleConfigChangeAt: new Date().toISOString(),
      },
      latestObservationId: latestObs.observationId,
      privateNoteMarketPricePctPar: 100.0,
    };

    this.series.push(record);
    this.logAudit({
      actorRole: input.actorRole,
      actorKeyId: issuerKey.keyId,
      action: 'CREATE_DRAFT_SERIES',
      resourceId: input.seriesId,
      outcome: 'ALLOWED',
      detail: `Created Draft Note Series ${input.seriesId} (Cap: ${input.supplyCapUnits} units).`,
      payload: { seriesId: input.seriesId, commitment: terms.termSheetCommitmentHash },
    });
    return record;
  }

  public advanceSeriesStage(params: {
    actorRole: OperatorRole;
    seriesId: string;
    targetStage: NoteSeriesRecord['lifecycleStage'];
    authorisedUnits?: number;
  }): NoteSeriesRecord {
    const s = this.series.find((n) => n.seriesId === params.seriesId);
    if (!s) throw new Error(`Series ${params.seriesId} not found`);

    const riskKey = this.getActiveKeyByRole('RISK_DUAL_APPROVER');
    const issuerKey = this.getActiveKeyByRole('ISSUER_AUTHORITY');

    if (params.targetStage === 'Reviewed') {
      if (params.actorRole !== 'RISK_APPROVER') {
        this.logAudit({ actorRole: params.actorRole, actorKeyId: 'DENIED', action: 'REVIEW_SERIES', resourceId: s.seriesId, outcome: 'DENIED', detail: 'Only RISK_APPROVER can move Draft -> Reviewed' });
        throw new Error('Only RISK_APPROVER can review terms');
      }
      if (s.lifecycleStage !== 'Draft') throw new Error(`Cannot move from ${s.lifecycleStage} to Reviewed`);
      s.lifecycleStage = 'Reviewed';
      this.logAudit({ actorRole: params.actorRole, actorKeyId: riskKey.keyId, action: 'REVIEW_SERIES', resourceId: s.seriesId, outcome: 'ALLOWED', detail: 'Reviewed permanent terms & SDR methodology.' });
    } else if (params.targetStage === 'Approved') {
      if (params.actorRole !== 'RISK_APPROVER' && params.actorRole !== 'ISSUER_OFFICER') {
        throw new Error('Unauthorised to approve series');
      }
      if (s.lifecycleStage !== 'Reviewed') throw new Error(`Series must be Reviewed before Approved (current: ${s.lifecycleStage})`);
      s.issuanceApprovalRefs.issuerSignature = signPayload({ termSheetCommitmentHash: s.terms.termSheetCommitmentHash }, issuerKey.privateKeyPem);
      s.issuanceApprovalRefs.dualApproverKeyId = riskKey.keyId;
      s.issuanceApprovalRefs.dualApprovalSignature = signPayload({ termSheetCommitmentHash: s.terms.termSheetCommitmentHash, approved: true }, riskKey.privateKeyPem);
      s.issuanceApprovalRefs.approvedAt = new Date().toISOString();
      s.lifecycleStage = 'Approved';
      this.chain.submitTransaction({
        txType: 'DEPLOY_SERIES',
        seriesId: s.seriesId,
        callerAddress: '0xIssuerAuthority0001',
        signerKey: issuerKey,
        payloadSummary: `Commit Approved Terms for ${s.seriesId}`,
        payload: { seriesId: s.seriesId, commitment: s.terms.termSheetCommitmentHash },
        eventsToEmit: [{ eventName: 'SERIES_DEPLOYED', args: { seriesId: s.seriesId, supplyCapUnits: s.terms.supplyCapUnits } }],
      });
      this.logAudit({ actorRole: params.actorRole, actorKeyId: riskKey.keyId, action: 'APPROVE_SERIES', resourceId: s.seriesId, outcome: 'ALLOWED', detail: 'Dual-approved terms & committed hash on-chain.' });
    } else if (params.targetStage === 'Subscription Open') {
      if (params.actorRole !== 'ISSUER_OFFICER') throw new Error('Only ISSUER_OFFICER can open subscriptions');
      if (s.lifecycleStage !== 'Approved') throw new Error('Series must be Approved before opening subscription');
      s.lifecycleStage = 'Subscription Open';
      this.logAudit({ actorRole: params.actorRole, actorKeyId: issuerKey.keyId, action: 'OPEN_SUBSCRIPTION', resourceId: s.seriesId, outcome: 'ALLOWED', detail: 'Opened primary subscription window.' });
    } else if (params.targetStage === 'Rejected' || params.targetStage === 'Cancelled') {
      if (params.actorRole !== 'RISK_APPROVER' && params.actorRole !== 'ISSUER_OFFICER') {
        throw new Error('Unauthorised to reject or cancel series');
      }
      s.lifecycleStage = params.targetStage;
      this.logAudit({ actorRole: params.actorRole, actorKeyId: issuerKey.keyId, action: `SERIES_${params.targetStage.toUpperCase()}`, resourceId: s.seriesId, outcome: 'ALLOWED', detail: `Series transitioned to ${params.targetStage}.` });
    } else {
      throw new Error(`Unsupported direct stage transition to ${params.targetStage}`);
    }

    return s;
  }

  // ==================== SUBSCRIPTION & IDEMPOTENT ISSUANCE ====================
  public submitSubscription(params: {
    actorRole: OperatorRole;
    idempotencyKey: string;
    seriesId: string;
    investorId: string;
    requestedUnits: number;
  }): { order: SubscriptionOrder; idempotentReplay: boolean } {
    if (!params.idempotencyKey || params.idempotencyKey.trim().length < 4) {
      throw new Error('Valid idempotencyKey is required');
    }
    const existing = this.subscriptions.find((sub) => sub.idempotencyKey === params.idempotencyKey);
    if (existing) {
      return { order: existing, idempotentReplay: true };
    }

    const series = this.series.find((s) => s.seriesId === params.seriesId);
    if (!series) throw new Error(`Series ${params.seriesId} not found`);
    if (series.controls.issuancePaused) {
      throw new Error(`Issuance is currently paused for ${params.seriesId}`);
    }
    if (!['Subscription Open', 'Issued', 'Approved', 'Allocated', 'Funded'].includes(series.lifecycleStage)) {
      throw new Error(`Series ${params.seriesId} is in ${series.lifecycleStage} stage and cannot accept subscriptions`);
    }

    const investor = this.investors.find((i) => i.investorId === params.investorId);
    if (!investor) throw new Error(`Investor ${params.investorId} not found`);
    if (investor.kycStatus !== 'APPROVED' || investor.eligibilityTier !== 'QUALIFIED_INSTITUTIONAL_BUYER') {
      this.logAudit({
        actorRole: params.actorRole,
        actorKeyId: 'COMPLIANCE-GATE',
        action: 'SUBSCRIPTION_ELIGIBILITY_CHECK',
        resourceId: params.seriesId,
        outcome: 'DENIED',
        detail: `Rejected ineligible investor ${investor.investorId} (${investor.kycStatus} / ${investor.eligibilityTier}).`,
      });
      throw new Error(`Investor ${investor.legalName} fails eligibility policy (${investor.kycStatus})`);
    }
    if (!series.terms.transferRestrictions.jurisdictionWhitelist.includes(investor.jurisdiction)) {
      throw new Error(`Investor jurisdiction ${investor.jurisdiction} not whitelisted for ${series.seriesId}`);
    }

    if (params.requestedUnits <= 0) throw new Error('Requested units must be positive');
    if (series.quantities.issuedUnits + series.quantities.subscribedUnits - series.quantities.issuedUnits + params.requestedUnits > series.terms.supplyCapUnits) {
      throw new Error(
        `Supply cap exceeded: requested ${params.requestedUnits} + existing ${series.quantities.issuedUnits} > cap ${series.terms.supplyCapUnits}`
      );
    }

    const obs = this.getLatestValidObservation();
    const expectedCashAmountUsd = roundTo(
      params.requestedUnits * series.terms.unitParSdr * obs.reconstructedSdrUsd,
      2
    );

    const order: SubscriptionOrder = {
      subscriptionId: `SUB-${Date.now().toString().slice(-6)}`,
      idempotencyKey: params.idempotencyKey,
      seriesId: series.seriesId,
      investorId: investor.investorId,
      investorName: investor.legalName,
      requestedUnits: params.requestedUnits,
      allocatedUnits: params.requestedUnits,
      settlementCurrency: series.terms.subscriptionCurrency,
      sdrObservationIdUsed: obs.observationId,
      expectedCashAmountUsd,
      fundedCashAmountUsd: 0,
      status: 'ALLOCATED',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.usedIdempotencyKeys.add(params.idempotencyKey);
    this.subscriptions.unshift(order);
    series.quantities.subscribedUnits += params.requestedUnits;
    if (series.lifecycleStage === 'Subscription Open' || series.lifecycleStage === 'Approved') {
      series.lifecycleStage = 'Allocated';
    }

    this.logAudit({
      actorRole: params.actorRole,
      actorKeyId: 'OPERATIONAL-SUB',
      action: 'SUBMIT_ALLOCATE_SUBSCRIPTION',
      resourceId: order.subscriptionId,
      outcome: 'ALLOWED',
      detail: `Allocated ${params.requestedUnits} units of ${series.seriesId} to ${investor.investorId} at ${obs.reconstructedSdrUsd} USD/SDR.`,
    });

    return { order, idempotentReplay: false };
  }

  public recordSubscriptionFunding(params: {
    actorRole: OperatorRole;
    subscriptionId: string;
    fundedCashAmountUsd: number;
    settlementEvidenceRef: string;
    simulateFailure?: boolean;
  }): SubscriptionOrder {
    if (params.actorRole !== 'TREASURY_OPS' && params.actorRole !== 'ISSUER_OFFICER') {
      throw new Error(`Role ${params.actorRole} cannot confirm cash settlement evidence`);
    }
    const order = this.subscriptions.find((s) => s.subscriptionId === params.subscriptionId);
    if (!order) throw new Error(`Subscription ${params.subscriptionId} not found`);
    const series = this.series.find((s) => s.seriesId === order.seriesId)!;

    if (params.simulateFailure || params.fundedCashAmountUsd < order.expectedCashAmountUsd) {
      order.status = 'FAILED_SETTLEMENT';
      order.fundedCashAmountUsd = params.fundedCashAmountUsd;
      order.settlementEvidenceRef = params.settlementEvidenceRef || 'SHORTFALL_WIRE_FAIL';
      order.updatedAt = new Date().toISOString();
      series.lifecycleStage = 'Failed Settlement';
      this.logAudit({
        actorRole: params.actorRole,
        actorKeyId: this.getActiveKeyByRole('TREASURY_OPS').keyId,
        action: 'RECORD_SUBSCRIPTION_FUNDING',
        resourceId: order.subscriptionId,
        outcome: 'FAILED',
        detail: `Failed settlement: received $${params.fundedCashAmountUsd} vs expected $${order.expectedCashAmountUsd}.`,
      });
      return order;
    }

    order.fundedCashAmountUsd = params.fundedCashAmountUsd;
    order.settlementEvidenceRef = params.settlementEvidenceRef;
    order.status = 'FUNDED';
    order.updatedAt = new Date().toISOString();
    series.quantities.fundedUnits += order.allocatedUnits;
    series.lifecycleStage = 'Funded';

    this.logAudit({
      actorRole: params.actorRole,
      actorKeyId: this.getActiveKeyByRole('TREASURY_OPS').keyId,
      action: 'RECORD_SUBSCRIPTION_FUNDING',
      resourceId: order.subscriptionId,
      outcome: 'ALLOWED',
      detail: `Confirmed $${params.fundedCashAmountUsd.toLocaleString()} settlement (${params.settlementEvidenceRef}).`,
    });
    return order;
  }

  public authoriseAndIssueSubscription(params: {
    actorRole: OperatorRole;
    subscriptionId: string;
    idempotencyKey: string;
  }): { order: SubscriptionOrder; idempotentReplay: boolean } {
    const order = this.subscriptions.find((s) => s.subscriptionId === params.subscriptionId);
    if (!order) throw new Error(`Subscription ${params.subscriptionId} not found`);

    // Idempotent check: if already ISSUED, return existing record without minting again!
    if (order.status === 'ISSUED') {
      return { order, idempotentReplay: true };
    }

    const issuerKey = this.getActiveKeyByRole('ISSUER_AUTHORITY');
    const riskKey = this.getActiveKeyByRole('RISK_DUAL_APPROVER');

    if (params.actorRole !== 'ISSUER_OFFICER') {
      this.logAudit({
        actorRole: params.actorRole,
        actorKeyId: 'UNAUTHORISED',
        action: 'ISSUE_NOTE_UNITS',
        resourceId: order.subscriptionId,
        outcome: 'DENIED',
        detail: `Unauthorised issuance attempt by role ${params.actorRole}.`,
      });
      throw new Error(`Unauthorised issuance attempt: role ${params.actorRole} lacks ISSUER_AUTHORITY`);
    }

    const series = this.series.find((s) => s.seriesId === order.seriesId)!;
    if (series.controls.issuancePaused) {
      throw new Error(`Issuance is paused on ${series.seriesId}`);
    }
    if (order.status !== 'FUNDED') {
      throw new Error(`Subscription must be FUNDED before issuance (current: ${order.status})`);
    }
    if (!series.issuanceApprovalRefs.dualApprovalSignature || !series.issuanceApprovalRefs.issuerSignature) {
      throw new Error('Missing dual approval signatures on series terms');
    }
    // Verify cryptographic dual-approval signatures
    const validIssuerSig = verifyPayloadSignature(
      { termSheetCommitmentHash: series.terms.termSheetCommitmentHash },
      series.issuanceApprovalRefs.issuerSignature,
      issuerKey.publicKeyPem
    );
    const validRiskSig = verifyPayloadSignature(
      { termSheetCommitmentHash: series.terms.termSheetCommitmentHash, approved: true },
      series.issuanceApprovalRefs.dualApprovalSignature,
      riskKey.publicKeyPem
    );
    if (!validIssuerSig || !validRiskSig) {
      throw new Error('Cryptographic signature verification failed on approved series terms');
    }
    if (series.quantities.issuedUnits + order.allocatedUnits > series.terms.supplyCapUnits) {
      throw new Error(
        `Supply cap breach prevented: ${series.quantities.issuedUnits} + ${order.allocatedUnits} > ${series.terms.supplyCapUnits}`
      );
    }

    series.quantities.authorisedUnits += order.allocatedUnits;
    series.lifecycleStage = 'Authorised for Issuance';

    const investor = this.investors.find((i) => i.investorId === order.investorId)!;
    const { tx } = this.chain.submitTransaction({
      txType: 'ISSUE_NOTE',
      seriesId: series.seriesId,
      callerAddress: '0xIssuerAuthority0001',
      signerKey: issuerKey,
      payloadSummary: `Issue ${order.allocatedUnits} units of ${series.seriesId} to ${investor.investorId}`,
      payload: {
        subscriptionId: order.subscriptionId,
        idempotencyKey: params.idempotencyKey,
        investorWallet: investor.walletAddress,
        units: order.allocatedUnits,
        commitment: series.terms.termSheetCommitmentHash,
      },
      eventsToEmit: [
        {
          eventName: 'NOTE_ISSUED',
          args: {
            seriesId: series.seriesId,
            investorId: investor.investorId,
            units: order.allocatedUnits,
            sdrFaceValue: order.allocatedUnits * series.terms.unitParSdr,
          },
        },
      ],
    });

    series.quantities.issuedUnits += order.allocatedUnits;
    series.quantities.outstandingUnits += order.allocatedUnits;
    series.lifecycleStage = 'Issued';
    order.status = 'ISSUED';
    order.issuanceTxHash = tx.txHash;
    order.updatedAt = new Date().toISOString();

    this.creditHolding(investor, series, order.allocatedUnits, 'PRIMARY_ISSUANCE', order.expectedCashAmountUsd, tx.txHash);
    const obs = this.getLatestValidObservation();
    this.recomputeTreasury(
      this.treasury.accounts[0].balanceUsd + order.fundedCashAmountUsd,
      series.quantities.outstandingUnits,
      obs.reconstructedSdrUsd
    );

    this.logAudit({
      actorRole: params.actorRole,
      actorKeyId: issuerKey.keyId,
      action: 'ISSUE_NOTE_UNITS',
      resourceId: order.subscriptionId,
      outcome: 'ALLOWED',
      detail: `Authorised & issued ${order.allocatedUnits} units on PoS chain (tx ${tx.txHash.slice(0, 14)}...).`,
    });

    return { order, idempotentReplay: false };
  }

  private creditHolding(
    investor: InvestorAccount,
    series: NoteSeriesRecord,
    units: number,
    type: 'PRIMARY_ISSUANCE' | 'SECONDARY_TRADE',
    usdEquivalent: number,
    txHash: string
  ): void {
    const obs = this.getLatestValidObservation();
    let holding = this.holdings.find(
      (h) => h.investorId === investor.investorId && h.seriesId === series.seriesId
    );
    if (!holding) {
      holding = {
        holdingId: `HLD-${investor.investorId.slice(4, 10)}-${series.seriesId.slice(-6)}`,
        investorId: investor.investorId,
        investorName: investor.legalName,
        walletAddress: investor.walletAddress,
        seriesId: series.seriesId,
        units: 0,
        sdrFaceValue: 0,
        acquisitionRecords: [],
        accruedEntitlementSdr: 0,
        indicativeUsdValue: 0,
        transferAvailability: 'AVAILABLE_ELIGIBLE',
        encumbrancesUnits: 0,
        maturityDate: series.terms.maturityDate,
      };
      this.holdings.push(holding);
    }
    holding.units += units;
    holding.sdrFaceValue = holding.units * series.terms.unitParSdr;
    holding.indicativeUsdValue = roundTo(
      holding.sdrFaceValue * obs.reconstructedSdrUsd * (series.privateNoteMarketPricePctPar / 100),
      2
    );
    holding.acquisitionRecords.unshift({
      acquisitionId: `ACQ-${Date.now().toString().slice(-5)}`,
      type,
      units,
      sdrCostPerUnit: series.terms.unitParSdr,
      usdEquivalentAtTrade: usdEquivalent,
      timestamp: new Date().toISOString(),
      txHash,
    });
  }

  // ==================== ORACLE OBSERVATION ENGINE ====================
  public publishSdrObservation(params: {
    actorRole: OperatorRole;
    quotes: FxQuotesPayload;
    effectiveTime: string;
    retrievalTime?: string;
    secondaryBenchmarkSdrUsd?: number;
    supersedesObservationId?: string;
    forceFallback?: boolean;
    sourceOverride?: string;
  }): SdrObservation {
    const oracleKey = this.getActiveKeyByRole('ORACLE_ADAPTER');
    if (params.actorRole !== 'ORACLE_OPERATOR') {
      this.logAudit({
        actorRole: params.actorRole,
        actorKeyId: 'UNAUTHORISED',
        action: 'PUBLISH_SDR_OBSERVATION',
        resourceId: 'ORACLE-REGISTRY',
        outcome: 'DENIED',
        detail: `Unauthorised oracle submission attempted by ${params.actorRole}.`,
      });
      throw new Error(`Unauthorised oracle operator: ${params.actorRole} lacks ORACLE_ADAPTER authority`);
    }

    const source = params.sourceOverride ?? this.oracleFeedAllowedSource;
    const retrievalTime = params.retrievalTime ?? new Date().toISOString();
    const lastValid = this.observations.find((o) => o.status === 'PUBLISHED' || o.status === 'CORRECTED');

    const obs = buildSignedSdrObservation({
      observationId: `OBS-${Date.now().toString().slice(-6)}`,
      quotes: params.quotes,
      source,
      secondaryBenchmarkSdrUsd: params.secondaryBenchmarkSdrUsd,
      effectiveTime: params.effectiveTime,
      retrievalTime,
      oracleKey,
      supersedesObservationId: params.supersedesObservationId,
      forceFallback: params.forceFallback,
      lastValidObservation: lastValid,
    });

    if (obs.status === 'REJECTED_STALE') {
      this.observations.unshift(obs);
      this.logAudit({
        actorRole: params.actorRole,
        actorKeyId: oracleKey.keyId,
        action: 'PUBLISH_SDR_OBSERVATION',
        resourceId: obs.observationId,
        outcome: 'FAILED',
        detail: `Rejected stale SDR observation (effective ${obs.effectiveTime}, retrieval ${obs.retrievalTime}).`,
      });
      return obs;
    }

    const { tx } = this.chain.submitTransaction({
      txType: 'PUBLISH_OBSERVATION',
      seriesId: 'ORACLE-REGISTRY',
      callerAddress: '0xOracleAdapter0001',
      signerKey: oracleKey,
      payloadSummary: `Oracle Observation ${obs.observationId} (${obs.status}: ${obs.reconstructedSdrUsd} USD/SDR)`,
      payload: { observationId: obs.observationId, payloadHash: obs.payloadHash, status: obs.status },
      eventsToEmit: [
        {
          eventName: 'SDR_OBSERVATION_PUBLISHED',
          args: {
            observationId: obs.observationId,
            status: obs.status,
            reconstructedSdrUsd: obs.reconstructedSdrUsd,
          },
        },
      ],
    });
    obs.chainTxHash = tx.txHash;
    obs.chainFinalised = tx.status === 'FINALISED';
    this.observations.unshift(obs);

    // Refresh indicative values on holdings & market listings
    for (const s of this.series) {
      s.latestObservationId = obs.observationId;
    }
    for (const h of this.holdings) {
      const s = this.series.find((x) => x.seriesId === h.seriesId);
      if (s) {
        h.indicativeUsdValue = roundTo(
          h.sdrFaceValue * obs.reconstructedSdrUsd * (s.privateNoteMarketPricePctPar / 100),
          2
        );
      }
    }
    for (const l of this.listings) {
      const s = this.series.find((x) => x.seriesId === l.seriesId);
      if (s) {
        l.indicativeModelSdrValue = s.quantities.outstandingUnits * s.terms.unitParSdr;
        l.indicativeModelUsdValue = roundTo(l.indicativeModelSdrValue * obs.reconstructedSdrUsd, 2);
      }
    }

    this.logAudit({
      actorRole: params.actorRole,
      actorKeyId: oracleKey.keyId,
      action: 'PUBLISH_SDR_OBSERVATION',
      resourceId: obs.observationId,
      outcome: 'ALLOWED',
      detail: `Signed & recorded observation ${obs.observationId} (${obs.reconstructedSdrUsd} USD/SDR, status: ${obs.status}).`,
    });
    return obs;
  }

  // ==================== SECONDARY TRANSFER & TRADING ====================
  public executeRestrictedTransfer(params: {
    actorRole: OperatorRole;
    seriesId: string;
    fromInvestorId: string;
    toInvestorId: string;
    units: number;
    type?: 'PRIMARY_ISSUANCE' | 'SECONDARY_TRADE';
    agreedUsdAmount?: number;
  }): { txHash: string } {
    const series = this.series.find((s) => s.seriesId === params.seriesId);
    if (!series) throw new Error(`Series ${params.seriesId} not found`);

    if (series.controls.transfersRestricted) {
      this.logAudit({
        actorRole: params.actorRole,
        actorKeyId: 'CONTRACT-TRANSFER-GATE',
        action: 'TRANSFER_NOTE',
        resourceId: series.seriesId,
        outcome: 'DENIED',
        detail: `Transfer blocked: transfers are restricted on ${series.seriesId}.`,
      });
      throw new Error(`Transfer blocked: transfers are currently restricted on ${series.seriesId}`);
    }

    const fromHolding = this.holdings.find(
      (h) => h.investorId === params.fromInvestorId && h.seriesId === params.seriesId
    );
    if (!fromHolding || fromHolding.units - fromHolding.encumbrancesUnits < params.units) {
      throw new Error(`Insufficient unencumbered units for ${params.fromInvestorId}`);
    }

    const toInvestor = this.investors.find((i) => i.investorId === params.toInvestorId);
    if (!toInvestor) throw new Error(`Recipient ${params.toInvestorId} not found`);

    if (toInvestor.kycStatus !== 'APPROVED' || toInvestor.eligibilityTier !== 'QUALIFIED_INSTITUTIONAL_BUYER') {
      this.logAudit({
        actorRole: params.actorRole,
        actorKeyId: 'CONTRACT-TRANSFER-GATE',
        action: 'TRANSFER_NOTE',
        resourceId: series.seriesId,
        outcome: 'DENIED',
        detail: `Transfer rejected: recipient ${toInvestor.investorId} is ${toInvestor.kycStatus} (${toInvestor.eligibilityTier}).`,
      });
      throw new Error(
        `Transfer restricted by Note Contract: recipient ${toInvestor.legalName} is ineligible (${toInvestor.kycStatus})`
      );
    }

    if (!series.terms.transferRestrictions.jurisdictionWhitelist.includes(toInvestor.jurisdiction)) {
      throw new Error(`Recipient jurisdiction ${toInvestor.jurisdiction} is outside allowed whitelist`);
    }

    const issuerKey = this.getActiveKeyByRole('ISSUER_AUTHORITY');
    const obs = this.getLatestValidObservation();
    const usdAmount =
      params.agreedUsdAmount ?? roundTo(params.units * series.terms.unitParSdr * obs.reconstructedSdrUsd, 2);

    const { tx } = this.chain.submitTransaction({
      txType: 'TRANSFER_NOTE',
      seriesId: series.seriesId,
      callerAddress: fromHolding.walletAddress,
      signerKey: issuerKey,
      payloadSummary: `Transfer ${params.units} units (${series.seriesId}) from ${params.fromInvestorId} to ${params.toInvestorId}`,
      payload: {
        from: fromHolding.walletAddress,
        to: toInvestor.walletAddress,
        units: params.units,
      },
      eventsToEmit: [
        {
          eventName: 'NOTE_TRANSFERRED',
          args: {
            seriesId: series.seriesId,
            fromInvestorId: params.fromInvestorId,
            toInvestorId: params.toInvestorId,
            units: params.units,
          },
        },
      ],
    });

    fromHolding.units -= params.units;
    fromHolding.sdrFaceValue = fromHolding.units * series.terms.unitParSdr;
    fromHolding.indicativeUsdValue = roundTo(
      fromHolding.sdrFaceValue * obs.reconstructedSdrUsd * (series.privateNoteMarketPricePctPar / 100),
      2
    );

    this.creditHolding(toInvestor, series, params.units, params.type ?? 'SECONDARY_TRADE', usdAmount, tx.txHash);
    this.logAudit({
      actorRole: params.actorRole,
      actorKeyId: issuerKey.keyId,
      action: 'TRANSFER_NOTE',
      resourceId: series.seriesId,
      outcome: 'ALLOWED',
      detail: `Transferred ${params.units} units from ${params.fromInvestorId} to ${params.toInvestorId} (tx ${tx.txHash.slice(0, 14)}...).`,
    });

    return { txHash: tx.txHash };
  }

  public createDealerRfq(params: {
    seriesId: string;
    requesterInvestorId: string;
    side: 'BUY' | 'SELL';
    units: number;
  }): DealerRfq {
    const series = this.series.find((s) => s.seriesId === params.seriesId);
    if (!series) throw new Error(`Series ${params.seriesId} not found`);
    const investor = this.investors.find((i) => i.investorId === params.requesterInvestorId);
    if (!investor || investor.kycStatus !== 'APPROVED') {
      throw new Error(`Requester ${params.requesterInvestorId} not eligible for SDR Markets RFQ`);
    }
    const obs = this.getLatestValidObservation();
    const indicativeModelUsd = roundTo(
      params.units * series.terms.unitParSdr * obs.reconstructedSdrUsd * (series.privateNoteMarketPricePctPar / 100),
      2
    );
    const quotePct = params.side === 'SELL' ? 99.78 : 99.94;
    const firmQuoteTotalUsd = roundTo(
      params.units * series.terms.unitParSdr * obs.reconstructedSdrUsd * (quotePct / 100),
      2
    );

    const rfq: DealerRfq = {
      rfqId: `RFQ-${Date.now().toString().slice(-6)}`,
      seriesId: series.seriesId,
      requesterInvestorId: investor.investorId,
      requesterName: investor.legalName,
      side: params.side,
      units: params.units,
      indicativeModelUsd,
      firmQuotePctPar: quotePct,
      firmQuoteTotalUsd,
      dealerName: 'RhinoBank SDR Markets Principal Desk',
      quoteExpiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
      status: 'QUOTED',
      createdAt: new Date().toISOString(),
    };
    this.rfqs.unshift(rfq);
    return rfq;
  }

  public confirmAndSettleRfqTrade(params: {
    actorRole: OperatorRole;
    rfqId: string;
    counterpartyInvestorId: string;
    bankPaymentRef: string;
  }): SecondaryTrade {
    const rfq = this.rfqs.find((r) => r.rfqId === params.rfqId);
    if (!rfq) throw new Error(`RFQ ${params.rfqId} not found`);
    if (rfq.status === 'SETTLED') throw new Error(`RFQ ${params.rfqId} already settled`);

    const sellerId = rfq.side === 'SELL' ? rfq.requesterInvestorId : params.counterpartyInvestorId;
    const buyerId = rfq.side === 'SELL' ? params.counterpartyInvestorId : rfq.requesterInvestorId;

    const { txHash } = this.executeRestrictedTransfer({
      actorRole: params.actorRole,
      seriesId: rfq.seriesId,
      fromInvestorId: sellerId,
      toInvestorId: buyerId,
      units: rfq.units,
      type: 'SECONDARY_TRADE',
      agreedUsdAmount: rfq.firmQuoteTotalUsd,
    });

    rfq.status = 'SETTLED';
    const trade: SecondaryTrade = {
      tradeId: `TRD-${Date.now().toString().slice(-6)}`,
      rfqId: rfq.rfqId,
      seriesId: rfq.seriesId,
      buyerInvestorId: buyerId,
      sellerInvestorId: sellerId,
      units: rfq.units,
      agreedPricePctPar: rfq.firmQuotePctPar ?? 99.85,
      agreedUsdAmount: rfq.firmQuoteTotalUsd ?? rfq.indicativeModelUsd,
      agreementTimestamp: new Date().toISOString(),
      noteTransferStatus: 'FINALISED_ON_CHAIN',
      noteTransferTxHash: txHash,
      cashSettlementLegStatus: 'RECONCILED',
      cashPaymentRef: params.bankPaymentRef,
      settlementModelNote:
        'Non-atomic dual-leg settlement: Note leg finalised on PoS chain; USD cash leg reconciled via external bank wire.',
    };
    this.trades.unshift(trade);
    return trade;
  }

  // ==================== COUPONS & REDEMPTION ====================
  public advanceCouponStage(params: {
    actorRole: OperatorRole;
    couponId: string;
    targetStage: CouponObligation['status'];
    paymentRef?: string;
    paymentEventId?: string;
  }): { coupon: CouponObligation; duplicateBlocked: boolean } {
    const coupon = this.coupons.find((c) => c.couponId === params.couponId);
    if (!coupon) throw new Error(`Coupon ${params.couponId} not found`);

    if (
      params.paymentEventId &&
      params.targetStage === 'Payment Confirmed' &&
      this.usedPaymentEventIds.has(params.paymentEventId) &&
      coupon.status === 'Payment Confirmed'
    ) {
      return { coupon, duplicateBlocked: true };
    }

    const obs = this.getLatestValidObservation();
    if (params.targetStage === 'Calculated') {
      const s = this.series.find((x) => x.seriesId === coupon.seriesId)!;
      coupon.observationId = obs.observationId;
      coupon.outstandingUnitsSnapshot = s.quantities.outstandingUnits;
      coupon.grossCouponSdr = roundTo(
        coupon.outstandingUnitsSnapshot * s.terms.unitParSdr * (coupon.annualRateBps / 10000) * (coupon.accruedDays / 360),
        2
      );
      coupon.fxUsdPerSdrUsed = obs.reconstructedSdrUsd;
      coupon.grossCouponUsd = roundTo(coupon.grossCouponSdr * obs.reconstructedSdrUsd, 2);
      coupon.status = 'Calculated';
    } else if (params.targetStage === 'Approved') {
      if (params.actorRole !== 'RISK_APPROVER' && params.actorRole !== 'ISSUER_OFFICER') {
        throw new Error('Only RISK_APPROVER or ISSUER_OFFICER can approve coupon obligation');
      }
      coupon.status = 'Approved';
    } else if (params.targetStage === 'Payment Instructed') {
      if (params.actorRole !== 'TREASURY_OPS') {
        throw new Error('Only TREASURY_OPS can instruct bank-rail payment');
      }
      coupon.paymentInstructionRef = params.paymentRef || `SWIFT-MT103-${Date.now().toString().slice(-6)}`;
      coupon.status = 'Payment Instructed';
    } else if (params.targetStage === 'Payment Confirmed') {
      if (params.actorRole !== 'TREASURY_OPS') {
        throw new Error('Only TREASURY_OPS can confirm payment receipt');
      }
      if (params.paymentEventId && this.usedPaymentEventIds.has(params.paymentEventId)) {
        return { coupon, duplicateBlocked: true };
      }
      if (params.paymentEventId) this.usedPaymentEventIds.add(params.paymentEventId);
      coupon.bankConfirmationRef = params.paymentRef || `BANK-CONF-${Date.now().toString().slice(-6)}`;
      coupon.status = 'Payment Confirmed';
    } else if (params.targetStage === 'Reconciled') {
      if (coupon.status !== 'Payment Confirmed') {
        throw new Error('Coupon must reach Payment Confirmed before Reconciled');
      }
      coupon.status = 'Reconciled';
    } else {
      coupon.status = params.targetStage;
    }

    this.logAudit({
      actorRole: params.actorRole,
      actorKeyId: this.getActiveKeyByRole('TREASURY_OPS').keyId,
      action: `COUPON_${params.targetStage.toUpperCase().replace(/\s+/g, '_')}`,
      resourceId: coupon.couponId,
      outcome: 'ALLOWED',
      detail: `Coupon ${coupon.couponId} transitioned to ${coupon.status} ($${coupon.grossCouponUsd.toLocaleString()}).`,
    });
    return { coupon, duplicateBlocked: false };
  }

  public initiateRedemption(params: {
    actorRole: OperatorRole;
    seriesId: string;
    investorId: string;
    unitsToRedeem: number;
    paymentEventId: string;
  }): RedemptionInstruction {
    if (this.usedPaymentEventIds.has(params.paymentEventId)) {
      throw new Error(`Duplicate redemption paymentEventId blocked: ${params.paymentEventId}`);
    }
    const series = this.series.find((s) => s.seriesId === params.seriesId);
    if (!series) throw new Error(`Series ${params.seriesId} not found`);
    const holding = this.holdings.find(
      (h) => h.investorId === params.investorId && h.seriesId === params.seriesId
    );
    if (!holding || holding.units < params.unitsToRedeem || params.unitsToRedeem <= 0) {
      throw new Error(`Invalid redemption quantity for ${params.investorId}`);
    }

    const obs = this.getLatestValidObservation();
    const redemptionValueSdr = params.unitsToRedeem * series.terms.unitParSdr;
    const redemptionValueUsd = roundTo(redemptionValueSdr * obs.reconstructedSdrUsd, 2);

    const red: RedemptionInstruction = {
      redemptionId: `RED-${Date.now().toString().slice(-6)}`,
      paymentEventId: params.paymentEventId,
      seriesId: series.seriesId,
      investorId: holding.investorId,
      investorName: holding.investorName,
      unitsToRedeem: params.unitsToRedeem,
      observationId: obs.observationId,
      redemptionValueSdr,
      redemptionValueUsd,
      status: 'Approved',
      retiredOnChain: false,
      createdAt: new Date().toISOString(),
    };

    this.redemptions.unshift(red);
    this.logAudit({
      actorRole: params.actorRole,
      actorKeyId: this.getActiveKeyByRole('ISSUER_AUTHORITY').keyId,
      action: 'INITIATE_REDEMPTION',
      resourceId: red.redemptionId,
      outcome: 'ALLOWED',
      detail: `Initiated redemption of ${params.unitsToRedeem} units ($${redemptionValueUsd.toLocaleString()}) — units remain unburned until cash payment confirmed.`,
    });
    return red;
  }

  public advanceRedemptionAndRetire(params: {
    actorRole: OperatorRole;
    redemptionId: string;
    action: 'INSTRUCT_PAYMENT' | 'CONFIRM_PAYMENT' | 'RETIRE_ON_CHAIN';
    bankRef?: string;
  }): RedemptionInstruction {
    const red = this.redemptions.find((r) => r.redemptionId === params.redemptionId);
    if (!red) throw new Error(`Redemption ${params.redemptionId} not found`);

    if (params.action === 'INSTRUCT_PAYMENT') {
      if (params.actorRole !== 'TREASURY_OPS') throw new Error('TREASURY_OPS required to instruct payment');
      red.paymentInstructionRef = params.bankRef || `RED-WIRE-INST-${Date.now().toString().slice(-5)}`;
      red.status = 'Payment Instructed';
    } else if (params.action === 'CONFIRM_PAYMENT') {
      if (params.actorRole !== 'TREASURY_OPS') throw new Error('TREASURY_OPS required to confirm payment');
      if (this.usedPaymentEventIds.has(red.paymentEventId)) {
        throw new Error(`Duplicate redemption payment confirmation blocked (${red.paymentEventId})`);
      }
      this.usedPaymentEventIds.add(red.paymentEventId);
      red.bankConfirmationRef = params.bankRef || `RED-WIRE-CONF-${Date.now().toString().slice(-5)}`;
      red.status = 'Payment Confirmed';
    } else if (params.action === 'RETIRE_ON_CHAIN') {
      if (red.retiredOnChain) {
        throw new Error(`Redemption ${red.redemptionId} units already retired on-chain (duplicate retirement prevented)`);
      }
      // CRITICAL INVARIANT: Cannot burn/retire units before Payment Confirmed!
      if (red.status !== 'Payment Confirmed') {
        this.logAudit({
          actorRole: params.actorRole,
          actorKeyId: 'REDEMPTION-SEQUENCE-GUARD',
          action: 'RETIRE_ON_CHAIN',
          resourceId: red.redemptionId,
          outcome: 'DENIED',
          detail: `Blocked premature burn: redemption status is ${red.status}, must be Payment Confirmed first.`,
        });
        throw new Error(
          `Premature burn prohibited: cash settlement must be Payment Confirmed before retiring units (current status: ${red.status})`
        );
      }

      const series = this.series.find((s) => s.seriesId === red.seriesId)!;
      const holding = this.holdings.find(
        (h) => h.investorId === red.investorId && h.seriesId === red.seriesId
      )!;
      const issuerKey = this.getActiveKeyByRole('ISSUER_AUTHORITY');

      const { tx } = this.chain.submitTransaction({
        txType: 'RETIRE_REDEEMED_NOTE',
        seriesId: series.seriesId,
        callerAddress: '0xIssuerAuthority0001',
        signerKey: issuerKey,
        payloadSummary: `Retire ${red.unitsToRedeem} redeemed units of ${series.seriesId} after confirmed payment ${red.bankConfirmationRef}`,
        payload: {
          redemptionId: red.redemptionId,
          paymentConfirmationRef: red.bankConfirmationRef,
          units: red.unitsToRedeem,
        },
        eventsToEmit: [
          {
            eventName: 'NOTE_REDEEMED_AND_RETIRED',
            args: {
              seriesId: series.seriesId,
              investorId: red.investorId,
              units: red.unitsToRedeem,
              paymentConfirmationRef: red.bankConfirmationRef ?? '',
            },
          },
        ],
      });

      holding.units = Math.max(0, holding.units - red.unitsToRedeem);
      holding.sdrFaceValue = holding.units * series.terms.unitParSdr;
      const obs = this.getLatestValidObservation();
      holding.indicativeUsdValue = roundTo(holding.sdrFaceValue * obs.reconstructedSdrUsd, 2);

      series.quantities.outstandingUnits = Math.max(0, series.quantities.outstandingUnits - red.unitsToRedeem);
      series.quantities.redeemedUnits += red.unitsToRedeem;
      red.burnTxHash = tx.txHash;
      red.retiredOnChain = true;
      red.status = 'Reconciled';

      this.recomputeTreasury(
        Math.max(0, this.treasury.accounts[0].balanceUsd - red.redemptionValueUsd),
        series.quantities.outstandingUnits,
        obs.reconstructedSdrUsd
      );
    }

    return red;
  }

  // ==================== GOVERNANCE, PAUSE SEPARATION, KEY ROTATION & TIMELOCK ====================
  public toggleSeriesControl(params: {
    actorRole: OperatorRole;
    seriesId: string;
    control: 'PAUSE_ISSUANCE' | 'RESTRICT_TRANSFERS';
    value: boolean;
  }): NoteSeriesRecord {
    const s = this.series.find((x) => x.seriesId === params.seriesId);
    if (!s) throw new Error(`Series ${params.seriesId} not found`);

    if (params.control === 'PAUSE_ISSUANCE') {
      if (params.actorRole !== 'RISK_APPROVER' && params.actorRole !== 'ISSUER_OFFICER') {
        throw new Error('Role cannot pause issuance');
      }
      s.controls.issuancePaused = params.value;
    } else {
      if (params.actorRole !== 'RISK_APPROVER') {
        throw new Error('Only RISK_APPROVER can restrict secondary transfers');
      }
      s.controls.transfersRestricted = params.value;
    }

    const pauserKey = this.getActiveKeyByRole('EMERGENCY_PAUSER');
    this.chain.submitTransaction({
      txType: 'PAUSE_CONTROL',
      seriesId: s.seriesId,
      callerAddress: '0xEmergencyPauser0001',
      signerKey: pauserKey,
      payloadSummary: `Set ${params.control}=${params.value} on ${s.seriesId} (existing contractual liabilities preserved)`,
      payload: { control: params.control, value: params.value },
      eventsToEmit: [
        {
          eventName: 'SERIES_CONTROL_UPDATED',
          args: { seriesId: s.seriesId, control: params.control, value: params.value },
        },
      ],
    });

    this.logAudit({
      actorRole: params.actorRole,
      actorKeyId: pauserKey.keyId,
      action: params.control,
      resourceId: s.seriesId,
      outcome: 'ALLOWED',
      detail: `${params.control} set to ${params.value}. Contractual coupon & redemption obligations remain intact.`,
    });
    return s;
  }

  public proposeTimelockedUpgrade(params: {
    actorRole: OperatorRole;
    seriesId: string;
    targetContractVersion: string;
    timelockHours?: number;
  }): NoteSeriesRecord {
    if (params.actorRole !== 'RISK_APPROVER') {
      throw new Error('Only RISK_APPROVER / Governance Multisig can propose contract upgrades');
    }
    const s = this.series.find((x) => x.seriesId === params.seriesId);
    if (!s) throw new Error(`Series ${params.seriesId} not found`);
    const hours = params.timelockHours ?? 48;
    const unlockAt = new Date(Date.now() + hours * 3600 * 1000).toISOString();
    s.controls.pendingUpgrade = {
      proposalId: `UPG-${Date.now().toString().slice(-5)}`,
      targetContractVersion: params.targetContractVersion,
      proposedBy: params.actorRole,
      etaUnlockAt: unlockAt,
      timelockHours: hours,
      status: 'TIMELOCKED',
    };

    const govKey = this.getActiveKeyByRole('TIMELOCK_GOVERNANCE');
    this.chain.submitTransaction({
      txType: 'GOVERNANCE_TIMELOCK',
      seriesId: s.seriesId,
      callerAddress: '0xTimelockController01',
      signerKey: govKey,
      payloadSummary: `Queue ${params.targetContractVersion} upgrade under ${hours}h timelock`,
      payload: { proposalId: s.controls.pendingUpgrade.proposalId, targetContractVersion: params.targetContractVersion },
      eventsToEmit: [
        {
          eventName: 'UPGRADE_TIMELOCK_QUEUED',
          args: { seriesId: s.seriesId, targetContractVersion: params.targetContractVersion, timelockHours: hours },
        },
      ],
    });

    return s;
  }

  public executeUpgrade(params: { actorRole: OperatorRole; seriesId: string; bypassTimelockForTest?: boolean }): NoteSeriesRecord {
    const s = this.series.find((x) => x.seriesId === params.seriesId);
    if (!s || !s.controls.pendingUpgrade) throw new Error('No pending upgrade proposal');
    const pending = s.controls.pendingUpgrade;
    if (!params.bypassTimelockForTest && Date.now() < Date.parse(pending.etaUnlockAt)) {
      this.logAudit({
        actorRole: params.actorRole,
        actorKeyId: 'TIMELOCK-GUARD',
        action: 'EXECUTE_UPGRADE',
        resourceId: s.seriesId,
        outcome: 'DENIED',
        detail: `Blocked premature upgrade execution before timelock unlock (${pending.etaUnlockAt}).`,
      });
      throw new Error(`Timelock active until ${pending.etaUnlockAt}; cannot execute upgrade early`);
    }
    s.contractVersion = pending.targetContractVersion;
    pending.status = 'EXECUTED';
    return s;
  }

  public rotateKey(roleName: string): ManagedKeyPair {
    const current = this.keys.find((k) => k.roleName === roleName && k.status === 'ACTIVE');
    if (current) current.status = 'ROTATED_REVOKED';
    const nextKey = generateEd25519Key(
      `KEY-${roleName.slice(0, 6)}-${String(this.keys.length + 1).padStart(2, '0')}`,
      roleName,
      current?.authorityScope ?? 'Rotated authority key'
    );
    this.keys.unshift(nextKey);
    this.logAudit({
      actorRole: 'RISK_APPROVER',
      actorKeyId: nextKey.keyId,
      action: 'ROTATE_AUTHORITY_KEY',
      resourceId: roleName,
      outcome: 'ALLOWED',
      detail: `Rotated key for ${roleName}: revoked ${current?.keyId ?? 'none'}, activated ${nextKey.keyId}.`,
    });
    return nextKey;
  }

  // ==================== 12-STEP DEMO RUNNER ====================
  public runRemainingDemoSteps(): PlatformStateSnapshot {
    // Executes steps 8 -> 12 cleanly if not yet done
    if (!this.demoSteps[7].completed) {
      const obs = this.publishSdrObservation({
        actorRole: 'ORACLE_OPERATOR',
        quotes: { USD: 1.0, EUR: 1.0872, CNY: 7.168, JPY: 152.65, GBP: 1.2745 },
        effectiveTime: new Date(Date.now() - 120 * 1000).toISOString(),
      });
      this.demoSteps[7].completed = true;
      this.demoSteps[7].evidenceRef = `${obs.observationId} (${obs.reconstructedSdrUsd} USD/SDR)`;
    }

    if (!this.demoSteps[8].completed) {
      this.demoSteps[8].completed = true;
      this.demoSteps[8].evidenceRef = 'LST-RB-SDR-2027-A · Bid 99.75 / Ask 99.95';
    }

    if (!this.demoSteps[9].completed) {
      const rfq = this.createDealerRfq({
        seriesId: 'RB-SDR-2027-A',
        requesterInvestorId: 'INV-ZURICH-PEN',
        side: 'SELL',
        units: 2000,
      });
      const trade = this.confirmAndSettleRfqTrade({
        actorRole: 'ISSUER_OFFICER',
        rfqId: rfq.rfqId,
        counterpartyInvestorId: 'INV-NORDIC-INS',
        bankPaymentRef: 'SEPA-FED-SIM-992014',
      });
      this.demoSteps[9].completed = true;
      this.demoSteps[9].evidenceRef = `${trade.tradeId} · 2,000 units to INV-NORDIC-INS`;
    }

    if (!this.demoSteps[10].completed) {
      const cpn = this.coupons[0];
      if (cpn) {
        this.advanceCouponStage({ actorRole: 'ISSUER_OFFICER', couponId: cpn.couponId, targetStage: 'Calculated' });
        this.advanceCouponStage({ actorRole: 'RISK_APPROVER', couponId: cpn.couponId, targetStage: 'Approved' });
        this.demoSteps[10].completed = true;
        this.demoSteps[10].evidenceRef = `${cpn.couponId} · $${cpn.grossCouponUsd.toLocaleString()} Approved`;
      }
    }

    if (!this.demoSteps[11].completed) {
      const red = this.initiateRedemption({
        actorRole: 'ISSUER_OFFICER',
        seriesId: 'RB-SDR-2027-A',
        investorId: 'INV-NORDIC-INS',
        unitsToRedeem: 500,
        paymentEventId: `PAY-EVT-RED-DEMO-${Date.now()}`,
      });
      this.advanceRedemptionAndRetire({ actorRole: 'TREASURY_OPS', redemptionId: red.redemptionId, action: 'INSTRUCT_PAYMENT' });
      this.advanceRedemptionAndRetire({ actorRole: 'TREASURY_OPS', redemptionId: red.redemptionId, action: 'CONFIRM_PAYMENT' });
      this.advanceRedemptionAndRetire({ actorRole: 'ISSUER_OFFICER', redemptionId: red.redemptionId, action: 'RETIRE_ON_CHAIN' });
      this.demoSteps[11].completed = true;
      this.demoSteps[11].evidenceRef = `${red.redemptionId} · 500 units retired`;
    }

    return this.getSnapshot();
  }

  public getSnapshot(): PlatformStateSnapshot {
    return {
      environmentLabel: 'TESTNET / SIMULATION',
      mandatoryDisclaimer: 'Private SDR-linked issuer obligation — not an IMF SDR allocation.',
      networkName: this.chain.networkName,
      chainId: this.chain.chainId,
      lastValuationTimestamp: this.observations[0]?.effectiveTime ?? new Date().toISOString(),
      lastChainTimestamp: this.chain.blocks[0]?.timestamp ?? new Date().toISOString(),
      basketDefinition: IMF_2022_BASKET,
      observations: this.observations,
      series: this.series,
      subscriptions: this.subscriptions,
      investors: this.investors,
      holdings: this.holdings,
      validators: this.chain.validators,
      blocks: this.chain.blocks,
      transactions: this.chain.transactions,
      chainEvents: this.chain.events,
      indexer: this.chain.indexer,
      listings: this.listings,
      rfqs: this.rfqs,
      trades: this.trades,
      coupons: this.coupons,
      redemptions: this.redemptions,
      treasury: this.treasury,
      keys: this.keys.map((k) => ({
        keyId: k.keyId,
        roleName: k.roleName,
        authorityScope: k.authorityScope,
        publicKeyFingerprint: k.publicKeyFingerprint,
        status: k.status,
        createdAt: k.createdAt,
      })),
      auditLogs: this.auditLogs,
      demoSteps: this.demoSteps,
    };
  }
}
