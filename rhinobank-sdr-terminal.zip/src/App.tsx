import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  ArrowRightLeft,
  BookOpen,
  Building2,
  Coins,
  FileCheck2,
  Layers,
  Scale,
  ShieldAlert,
  Wallet,
} from 'lucide-react';
import { OperatorRole, PlatformStateSnapshot } from './shared/types';
import { fmtTs } from './components/Formatters';
import { OverviewView } from './components/OverviewView';
import { NotesAndIssueView } from './components/NotesAndIssueView';
import { SdrReferenceView } from './components/SdrReferenceView';
import { TradeAndHoldingsView } from './components/TradeAndHoldingsView';
import { ValidatorsAndTreasuryView } from './components/ValidatorsAndTreasuryView';
import { SettlementAndAuditView } from './components/SettlementAndAuditView';

type NavTab =
  | 'Overview'
  | 'Notes'
  | 'Issue'
  | 'SDR Reference'
  | 'Trade'
  | 'Holdings'
  | 'Validators'
  | 'Treasury'
  | 'Settlement'
  | 'Audit';

const NAV_ITEMS: { id: NavTab; icon: React.FC<{ className?: string }> }[] = [
  { id: 'Overview', icon: Layers },
  { id: 'Notes', icon: BookOpen },
  { id: 'Issue', icon: FileCheck2 },
  { id: 'SDR Reference', icon: Scale },
  { id: 'Trade', icon: ArrowRightLeft },
  { id: 'Holdings', icon: Wallet },
  { id: 'Validators', icon: Activity },
  { id: 'Treasury', icon: Building2 },
  { id: 'Settlement', icon: Coins },
  { id: 'Audit', icon: ShieldAlert },
];

const ROLES: OperatorRole[] = [
  'ISSUER_OFFICER',
  'RISK_APPROVER',
  'TREASURY_OPS',
  'ORACLE_OPERATOR',
  'EXTERNAL_AUDITOR',
  'INVESTOR',
];

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('Overview');
  const [actorRole, setActorRole] = useState<OperatorRole>('ISSUER_OFFICER');
  const [state, setState] = useState<PlatformStateSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [bannerMsg, setBannerMsg] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  const loadState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as PlatformStateSnapshot;
      setState(data);
    } catch (err) {
      setBannerMsg({ kind: 'error', text: `Failed to load platform state: ${(err as Error).message}` });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadState();
  }, [loadState]);

  const callApi = async (
    url: string,
    method: 'POST' | 'GET' = 'POST',
    body?: unknown,
    successLabel?: string
  ) => {
    setBusy(true);
    setBannerMsg(null);
    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'x-rhino-role': actorRole,
        },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || `Request failed (${res.status})`);
      }
      if (json.state) {
        setState(json.state as PlatformStateSnapshot);
      } else if (json.environmentLabel) {
        setState(json as PlatformStateSnapshot);
      } else {
        await loadState();
      }
      if (successLabel) {
        const replayTag = json.idempotentReplay ? ' (Idempotent replay — no duplicate mint)' : '';
        const dupTag = json.duplicateBlocked ? ' (Duplicate payment event blocked)' : '';
        setBannerMsg({ kind: 'ok', text: `${successLabel}${replayTag}${dupTag}` });
      }
    } catch (err) {
      setBannerMsg({ kind: 'error', text: (err as Error).message });
      await loadState();
    } finally {
      setBusy(false);
    }
  };

  if (loading || !state) {
    return (
      <div className="min-h-screen bg-[#070B14] text-[#F4F1EA] flex items-center justify-center">
        <div className="text-xs font-mono text-[#B6B1A4]">
          Initialising RHINOBANK — SDR Note terminal...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#070B14] text-[#F4F1EA] flex flex-col lg:flex-row">
      {/* Institutional Sidebar Navigation */}
      <aside className="w-full lg:w-60 shrink-0 bg-[#0D1320] border-b lg:border-b-0 lg:border-r border-slate-200/15 flex flex-col justify-between">
        <div>
          <div className="px-5 py-5 border-b border-slate-200/10">
            <div className="font-display font-bold text-base tracking-tight text-[#F4F1EA] whitespace-nowrap">
              RHINOBANK — SDR Note
            </div>
            <div className="mt-1 text-[11px] font-mono text-[#C8A24A]">
              {state.environmentLabel}
            </div>
          </div>

          <nav className="p-3 flex lg:flex-col gap-1 overflow-x-auto">
            {NAV_ITEMS.map(({ id, icon: Icon }) => {
              const active = activeTab === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setActiveTab(id)}
                  className={`flex items-center gap-2.5 px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer text-left ${
                    active
                      ? 'bg-[#121A2B] text-[#22D3EE] border border-[#22D3EE]/40'
                      : 'text-[#B6B1A4] hover:text-[#F4F1EA] border border-transparent'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span>{id}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="hidden lg:block p-5 border-t border-slate-200/10 space-y-2 text-[11px] text-[#7E8799]">
          <div className="font-mono text-[#F59E0B]">{state.environmentLabel}</div>
          <div className="leading-relaxed">{state.mandatoryDisclaimer}</div>
          <div className="font-mono pt-1">
            Chain: {state.chainId} · Head #{state.indexer.chainHeadBlock}
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Institutional Bar */}
        <header className="bg-[#0D1320] border-b border-slate-200/15 px-6 py-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="font-display font-semibold text-[#F4F1EA] whitespace-nowrap">
              {activeTab}
            </span>
            <span className="text-[#7E8799]" aria-hidden="true">/</span>
            <span className="font-mono text-[#F59E0B] whitespace-nowrap">
              {state.environmentLabel}
            </span>
            <span className="text-[#7E8799] hidden sm:inline" aria-hidden="true">·</span>
            <span className="text-[#B6B1A4] hidden sm:inline">
              {state.mandatoryDisclaimer}
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <label className="flex items-center gap-2 text-xs">
              <span className="text-[#7E8799] whitespace-nowrap">Operator Role</span>
              <select
                value={actorRole}
                onChange={(e) => setActorRole(e.target.value as OperatorRole)}
                className="bg-[#070B14] border border-slate-200/20 px-2.5 py-1.5 font-mono text-xs text-[#22D3EE]"
              >
                {ROLES.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </header>

        {/* Action Feedback Strip */}
        {bannerMsg && (
          <div
            className={`px-6 py-2.5 text-xs font-mono border-b flex items-center justify-between gap-4 ${
              bannerMsg.kind === 'ok'
                ? 'bg-[#10B981]/10 border-[#10B981]/30 text-[#10B981]'
                : 'bg-[#EF4444]/10 border-[#EF4444]/30 text-[#EF4444]'
            }`}
          >
            <span>{bannerMsg.text}</span>
            <button
              type="button"
              onClick={() => setBannerMsg(null)}
              className="text-xs underline cursor-pointer shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Viewport Canvas */}
        <main className="flex-1 p-6 lg:p-8 max-w-[1440px] w-full mx-auto">
          {activeTab === 'Overview' && (
            <OverviewView
              state={state}
              busy={busy}
              onRunRemainingDemo={() =>
                callApi('/api/demo/run-all', 'POST', {}, 'Executed Steps 8–12 end-to-end demonstration')
              }
              onResetDemo={() => callApi('/api/demo/reset', 'POST', {}, 'Reset simulation state to baseline')}
              onNavigate={(tab) => setActiveTab(tab as NavTab)}
            />
          )}

          {(activeTab === 'Notes' || activeTab === 'Issue') && (
            <NotesAndIssueView
              mode={activeTab}
              state={state}
              actorRole={actorRole}
              busy={busy}
              onCreateSeries={(payload) =>
                callApi('/api/series', 'POST', payload, `Created Draft Series ${payload.seriesId}`)
              }
              onAdvanceStage={(seriesId, targetStage) =>
                callApi(`/api/series/${seriesId}/stage`, 'POST', { targetStage }, `Series ${seriesId} moved to ${targetStage}`)
              }
              onSubmitSubscription={(payload) =>
                callApi('/api/subscriptions', 'POST', payload, `Submitted subscription for ${payload.requestedUnits} units`)
              }
              onFundSubscription={(payload) =>
                callApi(
                  `/api/subscriptions/${payload.subscriptionId}/fund`,
                  'POST',
                  payload,
                  payload.simulateFailure ? 'Recorded failed settlement event' : 'Confirmed bank-rail subscription funding'
                )
              }
              onIssueSubscription={(subscriptionId, idempotencyKey) =>
                callApi(
                  `/api/subscriptions/${subscriptionId}/issue`,
                  'POST',
                  { idempotencyKey },
                  `Issued & finalised note units for ${subscriptionId}`
                )
              }
            />
          )}

          {activeTab === 'SDR Reference' && (
            <SdrReferenceView
              state={state}
              actorRole={actorRole}
              busy={busy}
              onPublishObservation={(payload) =>
                callApi('/api/observations', 'POST', payload, 'Processed signed SDR observation via Oracle Adapter')
              }
            />
          )}

          {(activeTab === 'Trade' || activeTab === 'Holdings') && (
            <TradeAndHoldingsView
              mode={activeTab}
              state={state}
              actorRole={actorRole}
              busy={busy}
              onCreateRfq={(payload) =>
                callApi('/api/rfqs', 'POST', payload, `Dealer RFQ quoted for ${payload.units} units`)
              }
              onSettleRfq={(payload) =>
                callApi(`/api/rfqs/${payload.rfqId}/settle`, 'POST', payload, `Settled secondary trade for ${payload.rfqId}`)
              }
              onExecuteTransfer={(payload) =>
                callApi('/api/transfers', 'POST', payload, `Transferred ${payload.units} units on-chain`)
              }
            />
          )}

          {(activeTab === 'Validators' || activeTab === 'Treasury') && (
            <ValidatorsAndTreasuryView
              mode={activeTab}
              state={state}
              busy={busy}
              onToggleValidator={(idx, online) =>
                callApi(`/api/validators/${idx}/toggle`, 'POST', { online }, `Validator #${idx} set ${online ? 'ONLINE' : 'OFFLINE'}`)
              }
              onSlashValidator={(idx, reason) =>
                callApi(`/api/validators/${idx}/slash`, 'POST', { reason }, `Slashed validator #${idx} (${reason})`)
              }
              onFinaliseChain={() =>
                callApi('/api/chain/finalise', 'POST', { epochs: 2 }, 'Advanced 2 Casper FFG epochs to finalise pending checkpoints')
              }
              onSimulateReorg={() =>
                callApi('/api/chain/reorg', 'POST', {}, 'Simulated pre-finality reorg & rebuilt indexer projections')
              }
              onRebuildIndexer={() =>
                callApi('/api/indexer/rebuild', 'POST', {}, 'Rebuilt ownership & supply projections from finalised chain events')
              }
            />
          )}

          {(activeTab === 'Settlement' || activeTab === 'Audit') && (
            <SettlementAndAuditView
              mode={activeTab}
              state={state}
              actorRole={actorRole}
              busy={busy}
              onAdvanceCoupon={(couponId, targetStage, paymentEventId) =>
                callApi(`/api/coupons/${couponId}/advance`, 'POST', { targetStage, paymentEventId }, `Coupon ${couponId} -> ${targetStage}`)
              }
              onInitiateRedemption={(payload) =>
                callApi('/api/redemptions', 'POST', payload, `Initiated redemption instruction for ${payload.unitsToRedeem} units`)
              }
              onAdvanceRedemption={(redemptionId, action) =>
                callApi(`/api/redemptions/${redemptionId}/advance`, 'POST', { action }, `Redemption ${redemptionId}: ${action}`)
              }
              onToggleControl={(seriesId, control, value) =>
                callApi(`/api/series/${seriesId}/control`, 'POST', { control, value }, `Updated ${control} = ${value}`)
              }
              onProposeUpgrade={(seriesId, targetContractVersion) =>
                callApi(`/api/series/${seriesId}/upgrade/propose`, 'POST', { targetContractVersion, timelockHours: 48 }, `Queued 48h timelock upgrade to ${targetContractVersion}`)
              }
              onExecuteUpgrade={(seriesId) =>
                callApi(`/api/series/${seriesId}/upgrade/execute`, 'POST', {}, 'Executed upgrade')
              }
              onRotateKey={(roleName) =>
                callApi('/api/keys/rotate', 'POST', { roleName }, `Rotated Ed25519 key for ${roleName}`)
              }
            />
          )}
        </main>

        {/* Quiet Institutional Footer */}
        <footer className="border-t border-slate-200/10 px-6 py-3 flex flex-wrap items-center justify-between gap-4 text-[11px] font-mono text-[#7E8799]">
          <span>RHINOBANK — SDR Note · {state.environmentLabel} · {state.mandatoryDisclaimer}</span>
          <span>Valuation: {fmtTs(state.lastValuationTimestamp)} · Finalised Block #{state.indexer.finalisedChainBlock}</span>
        </footer>
      </div>
    </div>
  );
}
