import test from 'node:test';
import assert from 'node:assert/strict';
import { RhinoSdrNotePlatform } from '../src/server/noteLedger.ts';
import { redactSensitiveFields } from '../src/server/crypto.ts';
import { reconstructSdrValueUsd } from '../src/server/sdrEngine.ts';

test('01. Unauthorised issuance is blocked and audited', () => {
  const platform = new RhinoSdrNotePlatform();
  const sub = platform.submitSubscription({
    actorRole: 'ISSUER_OFFICER',
    idempotencyKey: 'TEST-UNAUTH-01',
    seriesId: 'RB-SDR-2027-A',
    investorId: 'INV-NORDIC-INS',
    requestedUnits: 500,
  });
  platform.recordSubscriptionFunding({
    actorRole: 'TREASURY_OPS',
    subscriptionId: sub.order.subscriptionId,
    fundedCashAmountUsd: sub.order.expectedCashAmountUsd,
    settlementEvidenceRef: 'WIRE-TEST-01',
  });

  assert.throws(() => {
    platform.authoriseAndIssueSubscription({
      actorRole: 'INVESTOR',
      subscriptionId: sub.order.subscriptionId,
      idempotencyKey: 'TEST-UNAUTH-01',
    });
  }, /Unauthorised issuance attempt/);
});

test('02. Supply cap enforcement prevents over-issuance', () => {
  const platform = new RhinoSdrNotePlatform();
  assert.throws(() => {
    platform.submitSubscription({
      actorRole: 'ISSUER_OFFICER',
      idempotencyKey: 'TEST-CAP-01',
      seriesId: 'RB-SDR-2027-A',
      investorId: 'INV-NORDIC-INS',
      requestedUnits: 45000, // 10,000 issued + 45,000 > 50,000 cap
    });
  }, /Supply cap exceeded/);
});

test('03. Duplicate subscription and issuance requests are strictly idempotent', () => {
  const platform = new RhinoSdrNotePlatform();
  const first = platform.submitSubscription({
    actorRole: 'ISSUER_OFFICER',
    idempotencyKey: 'IDEM-DUP-001',
    seriesId: 'RB-SDR-2027-A',
    investorId: 'INV-UK-ASSET',
    requestedUnits: 1000,
  });
  assert.equal(first.idempotentReplay, false);

  const replaySub = platform.submitSubscription({
    actorRole: 'ISSUER_OFFICER',
    idempotencyKey: 'IDEM-DUP-001',
    seriesId: 'RB-SDR-2027-A',
    investorId: 'INV-UK-ASSET',
    requestedUnits: 1000,
  });
  assert.equal(replaySub.idempotentReplay, true);
  assert.equal(replaySub.order.subscriptionId, first.order.subscriptionId);

  platform.recordSubscriptionFunding({
    actorRole: 'TREASURY_OPS',
    subscriptionId: first.order.subscriptionId,
    fundedCashAmountUsd: first.order.expectedCashAmountUsd,
    settlementEvidenceRef: 'WIRE-IDEM-001',
  });

  const issue1 = platform.authoriseAndIssueSubscription({
    actorRole: 'ISSUER_OFFICER',
    subscriptionId: first.order.subscriptionId,
    idempotencyKey: 'IDEM-DUP-001',
  });
  assert.equal(issue1.idempotentReplay, false);
  const outstandingAfterFirst = platform.series[0].quantities.outstandingUnits;

  const issue2 = platform.authoriseAndIssueSubscription({
    actorRole: 'ISSUER_OFFICER',
    subscriptionId: first.order.subscriptionId,
    idempotencyKey: 'IDEM-DUP-001',
  });
  assert.equal(issue2.idempotentReplay, true);
  assert.equal(platform.series[0].quantities.outstandingUnits, outstandingAfterFirst);
});

test('04. Transfer restrictions block ineligible recipients and restricted mode', () => {
  const platform = new RhinoSdrNotePlatform();
  assert.throws(() => {
    platform.executeRestrictedTransfer({
      actorRole: 'INVESTOR',
      seriesId: 'RB-SDR-2027-A',
      fromInvestorId: 'INV-ZURICH-PEN',
      toInvestorId: 'INV-RESTRICTED-04',
      units: 100,
    });
  }, /ineligible/);

  platform.toggleSeriesControl({
    actorRole: 'RISK_APPROVER',
    seriesId: 'RB-SDR-2027-A',
    control: 'RESTRICT_TRANSFERS',
    value: true,
  });

  assert.throws(() => {
    platform.executeRestrictedTransfer({
      actorRole: 'INVESTOR',
      seriesId: 'RB-SDR-2027-A',
      fromInvestorId: 'INV-ZURICH-PEN',
      toInvestorId: 'INV-NORDIC-INS',
      units: 100,
    });
  }, /transfers are currently restricted/);
});

test('05. Oracle authorisation rejects non-oracle callers and signs valid IMF Rule O-1 reconstruction', () => {
  const platform = new RhinoSdrNotePlatform();
  assert.throws(() => {
    platform.publishSdrObservation({
      actorRole: 'TREASURY_OPS',
      quotes: { USD: 1, EUR: 1.085, CNY: 7.18, JPY: 153.1, GBP: 1.272 },
      effectiveTime: new Date().toISOString(),
    });
  }, /Unauthorised oracle operator/);

  const calc = reconstructSdrValueUsd({ USD: 1, EUR: 1.0845, CNY: 7.185, JPY: 153.2, GBP: 1.271 });
  // 0.57813 + 0.37379*1.0845 + 1.0993/7.185 + 13.452/153.2 + 0.08087*1.271 = 1.327079
  assert.ok(calc.reconstructedSdrUsd > 1.32 && calc.reconstructedSdrUsd < 1.34);
});

test('06. Stale observations are rejected unless contractual fallback is explicitly invoked', () => {
  const platform = new RhinoSdrNotePlatform();
  const staleEffective = new Date(Date.now() - 48 * 3600 * 1000).toISOString();

  const rejected = platform.publishSdrObservation({
    actorRole: 'ORACLE_OPERATOR',
    quotes: { USD: 1, EUR: 1.0845, CNY: 7.185, JPY: 153.2, GBP: 1.271 },
    effectiveTime: staleEffective,
    forceFallback: false,
  });
  assert.equal(rejected.status, 'REJECTED_STALE');
  assert.equal(rejected.chainFinalised, false);

  const fallback = platform.publishSdrObservation({
    actorRole: 'ORACLE_OPERATOR',
    quotes: { USD: 1, EUR: 1.0845, CNY: 7.185, JPY: 153.2, GBP: 1.271 },
    effectiveTime: staleEffective,
    forceFallback: true,
  });
  assert.equal(fallback.status, 'FALLBACK_USED');
  assert.ok(fallback.fallbackMethod?.includes('Contractual Fallback'));
});

test('07. Contract-version preservation and pause does not erase contractual obligations', () => {
  const platform = new RhinoSdrNotePlatform();
  const originalVersion = platform.series[0].contractVersion;
  const originalCommitment = platform.series[0].terms.termSheetCommitmentHash;

  platform.toggleSeriesControl({
    actorRole: 'RISK_APPROVER',
    seriesId: 'RB-SDR-2027-A',
    control: 'PAUSE_ISSUANCE',
    value: true,
  });

  assert.equal(platform.series[0].contractVersion, originalVersion);
  assert.equal(platform.series[0].terms.termSheetCommitmentHash, originalCommitment);
  assert.equal(platform.series[0].quantities.outstandingUnits, 10000);
  assert.ok(platform.coupons.length >= 1);
});

test('08. PoS finality, pre-finality reorg recovery, and indexer projection rebuild', () => {
  const platform = new RhinoSdrNotePlatform();
  const issuerKey = platform.keys.find((k) => k.roleName === 'ISSUER_AUTHORITY' && k.status === 'ACTIVE')!;

  // Submit an unfinalised transaction (autoFinalise: false)
  const { tx } = platform.chain.submitTransaction({
    txType: 'TRANSFER_NOTE',
    seriesId: 'RB-SDR-2027-A',
    callerAddress: '0xTestCaller',
    signerKey: issuerKey,
    payloadSummary: 'Pending transfer before finality',
    payload: { test: true },
    eventsToEmit: [{ eventName: 'NOTE_TRANSFERRED', args: { units: 100 } }],
    autoFinalise: false,
  });
  assert.equal(tx.status, 'SAFE_JUSTIFIED');

  // Reorg reverts unfinalised blocks & rebuilds projections cleanly from finalised events
  const reorg = platform.chain.simulatePreFinalityReorg();
  assert.ok(reorg.revertedTxHashes.includes(tx.txHash));
  assert.equal(platform.chain.indexer.projectedTotalIssuedUnits, 10000);
  assert.equal(platform.chain.indexer.reorgCount, 1);
});

test('09. Separation of validator stake, collateral reserve, and issuer liquidity accounts', () => {
  const platform = new RhinoSdrNotePlatform();
  const stakeAcc = platform.treasury.accounts.find((a) => a.category === 'VALIDATOR_STAKING_WALLET_SEPARATE')!;
  const collateralAcc = platform.treasury.accounts.find((a) => a.category === 'COLLATERAL_RESERVE')!;
  assert.ok(stakeAcc);
  assert.ok(stakeAcc.legalRingfence.includes('Zero Recourse'));
  assert.equal(collateralAcc.balanceUsd, 0);
  assert.ok(platform.treasury.backingClassification.includes('NOT official IMF SDR'));
});

test('10. Coupon calculations, duplicate payment protection, and redemption sequencing', () => {
  const platform = new RhinoSdrNotePlatform();
  const couponId = platform.coupons[0].couponId;
  const paymentEventId = platform.coupons[0].paymentEventId;

  platform.advanceCouponStage({ actorRole: 'ISSUER_OFFICER', couponId, targetStage: 'Calculated' });
  assert.equal(platform.coupons[0].grossCouponSdr, 106250); // 10M SDR * 4.25% * (90/360)
  platform.advanceCouponStage({ actorRole: 'RISK_APPROVER', couponId, targetStage: 'Approved' });
  platform.advanceCouponStage({ actorRole: 'TREASURY_OPS', couponId, targetStage: 'Payment Instructed' });
  const conf1 = platform.advanceCouponStage({
    actorRole: 'TREASURY_OPS',
    couponId,
    targetStage: 'Payment Confirmed',
    paymentEventId,
  });
  assert.equal(conf1.duplicateBlocked, false);

  const confDup = platform.advanceCouponStage({
    actorRole: 'TREASURY_OPS',
    couponId,
    targetStage: 'Payment Confirmed',
    paymentEventId,
  });
  assert.equal(confDup.duplicateBlocked, true);

  // Redemption sequencing: cannot burn before Payment Confirmed
  const red = platform.initiateRedemption({
    actorRole: 'ISSUER_OFFICER',
    seriesId: 'RB-SDR-2027-A',
    investorId: 'INV-ZURICH-PEN',
    unitsToRedeem: 500,
    paymentEventId: 'PAY-RED-SEQ-01',
  });
  assert.throws(() => {
    platform.advanceRedemptionAndRetire({
      actorRole: 'ISSUER_OFFICER',
      redemptionId: red.redemptionId,
      action: 'RETIRE_ON_CHAIN',
    });
  }, /Premature burn prohibited/);

  platform.advanceRedemptionAndRetire({ actorRole: 'TREASURY_OPS', redemptionId: red.redemptionId, action: 'INSTRUCT_PAYMENT' });
  platform.advanceRedemptionAndRetire({ actorRole: 'TREASURY_OPS', redemptionId: red.redemptionId, action: 'CONFIRM_PAYMENT' });
  const retired = platform.advanceRedemptionAndRetire({ actorRole: 'ISSUER_OFFICER', redemptionId: red.redemptionId, action: 'RETIRE_ON_CHAIN' });
  assert.equal(retired.retiredOnChain, true);
  assert.equal(platform.series[0].quantities.redeemedUnits, 500);
  assert.equal(platform.series[0].quantities.outstandingUnits, 9500);
});

test('11. Key rotation, 48h upgrade timelock enforcement, secret redaction, and 12-step demo', () => {
  const platform = new RhinoSdrNotePlatform();
  const rotated = platform.rotateKey('ISSUER_AUTHORITY');
  assert.equal(rotated.status, 'ACTIVE');
  assert.equal(platform.keys.filter((k) => k.roleName === 'ISSUER_AUTHORITY' && k.status === 'ACTIVE').length, 1);

  platform.proposeTimelockedUpgrade({
    actorRole: 'RISK_APPROVER',
    seriesId: 'RB-SDR-2027-A',
    targetContractVersion: 'RhinoSDRNote-v2.0.0',
    timelockHours: 48,
  });
  assert.throws(() => {
    platform.executeUpgrade({ actorRole: 'RISK_APPROVER', seriesId: 'RB-SDR-2027-A' });
  }, /Timelock active/);

  const redacted = redactSensitiveFields({ privateKey: 'secret-pem', apiKey: '12345', safe: 'ok' });
  assert.equal(redacted.privateKey, '[REDACTED]');
  assert.equal(redacted.apiKey, '[REDACTED]');
  assert.equal(redacted.safe, 'ok');

  const finalState = platform.runRemainingDemoSteps();
  assert.equal(finalState.demoSteps.filter((s) => s.completed).length, 12);
});
