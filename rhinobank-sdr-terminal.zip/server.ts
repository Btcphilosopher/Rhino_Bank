import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { RhinoSdrNotePlatform } from './src/server/noteLedger.ts';
import { redactSensitiveFields } from './src/server/crypto.ts';
import { OperatorRole } from './src/shared/types.ts';

const PORT = 3000;
const platform = new RhinoSdrNotePlatform();

// Simple in-memory rate limiter for operational safety
const requestWindow = new Map<string, { count: number; resetAt: number }>();
function rateLimiter(req: Request, res: Response, next: NextFunction): void {
  const ip = req.ip || 'local';
  const now = Date.now();
  const entry = requestWindow.get(ip);
  if (!entry || now > entry.resetAt) {
    requestWindow.set(ip, { count: 1, resetAt: now + 60_000 });
    next();
    return;
  }
  entry.count += 1;
  if (entry.count > 240) {
    res.status(429).json({ error: 'Rate limit exceeded (max 240 requests/minute)' });
    return;
  }
  next();
}

function getActorRole(req: Request): OperatorRole {
  const headerRole = (req.headers['x-rhino-role'] as string | undefined) || req.body?.actorRole;
  const validRoles: OperatorRole[] = [
    'ISSUER_OFFICER',
    'RISK_APPROVER',
    'TREASURY_OPS',
    'ORACLE_OPERATOR',
    'EXTERNAL_AUDITOR',
    'INVESTOR',
  ];
  if (headerRole && validRoles.includes(headerRole as OperatorRole)) {
    return headerRole as OperatorRole;
  }
  return 'ISSUER_OFFICER';
}

export function createApp() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));
  app.use('/api', rateLimiter);

  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      environment: 'TESTNET / SIMULATION',
      chainId: platform.chain.chainId,
      finalisedBlock: platform.chain.indexer.finalisedChainBlock,
    });
  });

  app.get('/api/state', (_req, res) => {
    res.json(redactSensitiveFields(platform.getSnapshot()));
  });

  app.post('/api/demo/run-all', (_req, res) => {
    try {
      const snapshot = platform.runRemainingDemoSteps();
      res.json(redactSensitiveFields(snapshot));
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/demo/reset', (_req, res) => {
    platform.reset();
    res.json(redactSensitiveFields(platform.getSnapshot()));
  });

  // Series Management
  app.post('/api/series', (req, res) => {
    try {
      const created = platform.createDraftSeries({
        actorRole: getActorRole(req),
        seriesId: String(req.body.seriesId),
        seriesName: String(req.body.seriesName),
        supplyCapUnits: Number(req.body.supplyCapUnits),
        annualRateBps: Number(req.body.annualRateBps),
        maturityDate: String(req.body.maturityDate),
        obligationNature: req.body.obligationNature || 'PRIVATE_UNSECURED_SENIOR_NOTE',
      });
      res.status(201).json({ series: created, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/series/:seriesId/stage', (req, res) => {
    try {
      const updated = platform.advanceSeriesStage({
        actorRole: getActorRole(req),
        seriesId: req.params.seriesId,
        targetStage: req.body.targetStage,
      });
      res.json({ series: updated, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/series/:seriesId/control', (req, res) => {
    try {
      const updated = platform.toggleSeriesControl({
        actorRole: getActorRole(req),
        seriesId: req.params.seriesId,
        control: req.body.control,
        value: Boolean(req.body.value),
      });
      res.json({ series: updated, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/series/:seriesId/upgrade/propose', (req, res) => {
    try {
      const updated = platform.proposeTimelockedUpgrade({
        actorRole: getActorRole(req),
        seriesId: req.params.seriesId,
        targetContractVersion: String(req.body.targetContractVersion || 'RhinoSDRNote-v1.1.0'),
        timelockHours: Number(req.body.timelockHours ?? 48),
      });
      res.json({ series: updated, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/series/:seriesId/upgrade/execute', (req, res) => {
    try {
      const updated = platform.executeUpgrade({
        actorRole: getActorRole(req),
        seriesId: req.params.seriesId,
        bypassTimelockForTest: Boolean(req.body.bypassTimelockForTest),
      });
      res.json({ series: updated, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Subscriptions & Issuance
  app.post('/api/subscriptions', (req, res) => {
    try {
      const result = platform.submitSubscription({
        actorRole: getActorRole(req),
        idempotencyKey: String(req.body.idempotencyKey),
        seriesId: String(req.body.seriesId),
        investorId: String(req.body.investorId),
        requestedUnits: Number(req.body.requestedUnits),
      });
      res.status(result.idempotentReplay ? 200 : 201).json({
        ...result,
        state: redactSensitiveFields(platform.getSnapshot()),
      });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/subscriptions/:subscriptionId/fund', (req, res) => {
    try {
      const order = platform.recordSubscriptionFunding({
        actorRole: getActorRole(req),
        subscriptionId: req.params.subscriptionId,
        fundedCashAmountUsd: Number(req.body.fundedCashAmountUsd),
        settlementEvidenceRef: String(req.body.settlementEvidenceRef || 'FEDWIRE-SIM-MANUAL'),
        simulateFailure: Boolean(req.body.simulateFailure),
      });
      res.json({ order, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/subscriptions/:subscriptionId/issue', (req, res) => {
    try {
      const result = platform.authoriseAndIssueSubscription({
        actorRole: getActorRole(req),
        subscriptionId: req.params.subscriptionId,
        idempotencyKey: String(req.body.idempotencyKey || req.params.subscriptionId),
      });
      res.json({ ...result, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Oracle Observations
  app.post('/api/observations', (req, res) => {
    try {
      const obs = platform.publishSdrObservation({
        actorRole: getActorRole(req),
        quotes: {
          USD: 1.0,
          EUR: Number(req.body.quotes?.EUR ?? 1.0845),
          CNY: Number(req.body.quotes?.CNY ?? 7.185),
          JPY: Number(req.body.quotes?.JPY ?? 153.2),
          GBP: Number(req.body.quotes?.GBP ?? 1.271),
        },
        effectiveTime: String(req.body.effectiveTime || new Date().toISOString()),
        retrievalTime: req.body.retrievalTime ? String(req.body.retrievalTime) : undefined,
        secondaryBenchmarkSdrUsd:
          req.body.secondaryBenchmarkSdrUsd !== undefined
            ? Number(req.body.secondaryBenchmarkSdrUsd)
            : undefined,
        supersedesObservationId: req.body.supersedesObservationId,
        forceFallback: Boolean(req.body.forceFallback),
      });
      res.status(201).json({ observation: obs, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Holdings & Restricted Transfers
  app.post('/api/transfers', (req, res) => {
    try {
      const result = platform.executeRestrictedTransfer({
        actorRole: getActorRole(req),
        seriesId: String(req.body.seriesId),
        fromInvestorId: String(req.body.fromInvestorId),
        toInvestorId: String(req.body.toInvestorId),
        units: Number(req.body.units),
      });
      res.json({ ...result, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Trading & RFQ
  app.post('/api/rfqs', (req, res) => {
    try {
      const rfq = platform.createDealerRfq({
        seriesId: String(req.body.seriesId),
        requesterInvestorId: String(req.body.requesterInvestorId),
        side: req.body.side === 'BUY' ? 'BUY' : 'SELL',
        units: Number(req.body.units),
      });
      res.status(201).json({ rfq, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/rfqs/:rfqId/settle', (req, res) => {
    try {
      const trade = platform.confirmAndSettleRfqTrade({
        actorRole: getActorRole(req),
        rfqId: req.params.rfqId,
        counterpartyInvestorId: String(req.body.counterpartyInvestorId),
        bankPaymentRef: String(req.body.bankPaymentRef || `BANK-WIRE-${Date.now().toString().slice(-6)}`),
      });
      res.json({ trade, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Coupons & Redemptions
  app.post('/api/coupons/:couponId/advance', (req, res) => {
    try {
      const result = platform.advanceCouponStage({
        actorRole: getActorRole(req),
        couponId: req.params.couponId,
        targetStage: req.body.targetStage,
        paymentRef: req.body.paymentRef,
        paymentEventId: req.body.paymentEventId,
      });
      res.json({ ...result, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/redemptions', (req, res) => {
    try {
      const red = platform.initiateRedemption({
        actorRole: getActorRole(req),
        seriesId: String(req.body.seriesId),
        investorId: String(req.body.investorId),
        unitsToRedeem: Number(req.body.unitsToRedeem),
        paymentEventId: String(req.body.paymentEventId || `PAY-EVT-RED-${Date.now()}`),
      });
      res.status(201).json({ redemption: red, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/redemptions/:redemptionId/advance', (req, res) => {
    try {
      const red = platform.advanceRedemptionAndRetire({
        actorRole: getActorRole(req),
        redemptionId: req.params.redemptionId,
        action: req.body.action,
        bankRef: req.body.bankRef,
      });
      res.json({ redemption: red, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Validators, Consensus & Indexer
  app.post('/api/validators/:validatorIndex/toggle', (req, res) => {
    try {
      const val = platform.chain.toggleValidatorOnline(
        Number(req.params.validatorIndex),
        Boolean(req.body.online)
      );
      res.json({ validator: val, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/validators/:validatorIndex/slash', (req, res) => {
    try {
      const val = platform.chain.slashValidatorForEquivocation(
        Number(req.params.validatorIndex),
        req.body.reason === 'SURROUND_VOTE' ? 'SURROUND_VOTE' : 'DOUBLE_PROPOSAL'
      );
      res.json({ validator: val, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/chain/finalise', (req, res) => {
    try {
      const result = platform.chain.advanceEpochsToFinalise(Number(req.body.epochs ?? 2));
      res.json({ ...result, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/chain/reorg', (_req, res) => {
    try {
      const result = platform.chain.simulatePreFinalityReorg();
      res.json({ ...result, state: redactSensitiveFields(platform.getSnapshot()) });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  app.post('/api/indexer/rebuild', (_req, res) => {
    const indexer = platform.chain.rebuildIndexerProjections();
    res.json({ indexer, state: redactSensitiveFields(platform.getSnapshot()) });
  });

  app.post('/api/keys/rotate', (req, res) => {
    try {
      const key = platform.rotateKey(String(req.body.roleName));
      res.json({
        key: {
          keyId: key.keyId,
          roleName: key.roleName,
          publicKeyFingerprint: key.publicKeyFingerprint,
          status: key.status,
        },
        state: redactSensitiveFields(platform.getSnapshot()),
      });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  return app;
}

async function startServer() {
  const app = createApp();

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RHINOBANK — SDR Note terminal & API running on http://0.0.0.0:${PORT}`);
  });
}

// Only bind port when executed directly, allowing tests to import createApp() cleanly
const isMain = process.argv[1]?.endsWith('server.ts') || process.argv[1]?.endsWith('server.js');
if (isMain) {
  startServer();
}
