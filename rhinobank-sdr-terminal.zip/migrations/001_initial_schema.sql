-- RHINOBANK — SDR Note PostgreSQL Operational & Chain Projection Schema
-- Separates authoritative legal/contract terms, off-chain settlement evidence,
-- and chain-indexed ownership projections rebuilt from finalised blocks.

CREATE TABLE IF NOT EXISTS sdr_basket_definitions (
  basket_version_id VARCHAR(32) PRIMARY KEY,
  effective_from TIMESTAMPTZ NOT NULL,
  effective_until TIMESTAMPTZ NOT NULL,
  methodology_name TEXT NOT NULL,
  imf_rule_reference TEXT NOT NULL,
  rounding_decimals INT NOT NULL DEFAULT 6,
  currencies_json JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS sdr_observations (
  observation_id VARCHAR(64) PRIMARY KEY,
  basket_version_id VARCHAR(32) NOT NULL REFERENCES sdr_basket_definitions(basket_version_id),
  source TEXT NOT NULL,
  effective_time TIMESTAMPTZ NOT NULL,
  retrieval_time TIMESTAMPTZ NOT NULL,
  status VARCHAR(32) NOT NULL,
  official_published_sdr_usd NUMERIC(18, 6) NOT NULL,
  reconstructed_sdr_usd NUMERIC(18, 6) NOT NULL,
  intraday_indicative_sdr_usd NUMERIC(18, 6) NOT NULL,
  spread_bps_vs_secondary NUMERIC(10, 2) NOT NULL,
  components_json JSONB NOT NULL,
  oracle_signer_key_id VARCHAR(64) NOT NULL,
  oracle_signature TEXT NOT NULL,
  payload_hash VARCHAR(66) NOT NULL,
  chain_tx_hash VARCHAR(66),
  chain_finalised BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS note_series (
  series_id VARCHAR(64) PRIMARY KEY,
  contract_version VARCHAR(64) NOT NULL,
  contract_address VARCHAR(42) NOT NULL,
  lifecycle_stage VARCHAR(40) NOT NULL,
  terms_json JSONB NOT NULL,
  term_sheet_commitment_hash VARCHAR(66) NOT NULL,
  authorised_units BIGINT NOT NULL DEFAULT 0,
  subscribed_units BIGINT NOT NULL DEFAULT 0,
  funded_units BIGINT NOT NULL DEFAULT 0,
  issued_units BIGINT NOT NULL DEFAULT 0,
  outstanding_units BIGINT NOT NULL DEFAULT 0,
  redeemed_units BIGINT NOT NULL DEFAULT 0,
  issuance_paused BOOLEAN NOT NULL DEFAULT FALSE,
  transfers_restricted BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS investors (
  investor_id VARCHAR(64) PRIMARY KEY,
  legal_name TEXT NOT NULL,
  lei VARCHAR(32) NOT NULL,
  jurisdiction VARCHAR(8) NOT NULL,
  wallet_address VARCHAR(42) NOT NULL,
  kyc_status VARCHAR(32) NOT NULL,
  eligibility_tier VARCHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS subscription_orders (
  subscription_id VARCHAR(64) PRIMARY KEY,
  idempotency_key VARCHAR(128) UNIQUE NOT NULL,
  series_id VARCHAR(64) NOT NULL REFERENCES note_series(series_id),
  investor_id VARCHAR(64) NOT NULL REFERENCES investors(investor_id),
  requested_units BIGINT NOT NULL,
  allocated_units BIGINT NOT NULL,
  observation_id VARCHAR(64) NOT NULL REFERENCES sdr_observations(observation_id),
  expected_cash_usd NUMERIC(18, 2) NOT NULL,
  funded_cash_usd NUMERIC(18, 2) NOT NULL DEFAULT 0,
  settlement_evidence_ref TEXT,
  status VARCHAR(32) NOT NULL,
  issuance_tx_hash VARCHAR(66),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS chain_events (
  event_id VARCHAR(64) PRIMARY KEY,
  tx_hash VARCHAR(66) NOT NULL,
  block_number BIGINT NOT NULL,
  event_name VARCHAR(64) NOT NULL,
  series_id VARCHAR(64) NOT NULL,
  args_json JSONB NOT NULL,
  finalised BOOLEAN NOT NULL DEFAULT FALSE,
  reorged BOOLEAN NOT NULL DEFAULT FALSE,
  observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ownership_projections (
  holding_id VARCHAR(64) PRIMARY KEY,
  investor_id VARCHAR(64) NOT NULL REFERENCES investors(investor_id),
  series_id VARCHAR(64) NOT NULL REFERENCES note_series(series_id),
  units BIGINT NOT NULL,
  encumbrances_units BIGINT NOT NULL DEFAULT 0,
  last_finalised_block BIGINT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS settlement_payments (
  payment_event_id VARCHAR(128) PRIMARY KEY,
  payment_type VARCHAR(32) NOT NULL,
  series_id VARCHAR(64) NOT NULL REFERENCES note_series(series_id),
  gross_sdr NUMERIC(18, 2) NOT NULL,
  gross_usd NUMERIC(18, 2) NOT NULL,
  status VARCHAR(32) NOT NULL,
  bank_instruction_ref TEXT,
  bank_confirmation_ref TEXT,
  burn_tx_hash VARCHAR(66),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS treasury_segregated_accounts (
  account_id VARCHAR(64) PRIMARY KEY,
  category VARCHAR(64) NOT NULL,
  balance_usd NUMERIC(18, 2) NOT NULL,
  encumbered_usd NUMERIC(18, 2) NOT NULL DEFAULT 0,
  legal_ringfence TEXT NOT NULL,
  valuation_date TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
  log_id VARCHAR(64) PRIMARY KEY,
  actor_role VARCHAR(32) NOT NULL,
  actor_key_id VARCHAR(64) NOT NULL,
  action VARCHAR(64) NOT NULL,
  resource_id VARCHAR(64) NOT NULL,
  outcome VARCHAR(16) NOT NULL,
  detail TEXT NOT NULL,
  payload_hash VARCHAR(66) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
