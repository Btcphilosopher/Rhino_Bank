# RHINOBANK — SDR Note: Architecture, Security Assumptions & Delivery Report

> **Disclaimer**: *Private SDR-linked issuer obligation — not an IMF SDR allocation.*  
> **Environment**: `TESTNET / SIMULATION`

## 1. What Is Implemented, Simulated, and Tested

### Implemented & Running Live (Node.js + Express + React/TypeScript + Tailwind)
- **Three-Responsibility Separation**:
  - `Issuer Service` (`src/server/noteLedger.ts`): Proposes versioned note series, obtains Risk dual-approval, tracks KYC eligibility, verifies bank-rail settlement evidence, and issues idempotent mint instructions.
  - `Note Contract` (`contracts/RhinoSDRNote.sol` + deterministic on-chain ledger state machine): Enforces supply caps, whitelisted transfer restrictions, lockups, separated pause/upgrade controls, and post-payment retirement sequencing.
  - `Proof-of-Stake Consensus & Indexer` (`src/server/posChain.ts`): Models Ethereum PoS Gasper (LMD-GHOST + Casper FFG, 32-slot epochs, 2-epoch finality at >=2/3 online stake), protocol slashing, >4-epoch inactivity leak, pre-finality chain reorganisations, and finalised-event projection rebuilds.
- **IMF Rule O-1 SDR Valuation Engine** (`src/server/sdrEngine.ts` + `backend/app/sdr_engine.py`):
  - Exact `IMF-2022-R1` fixed basket currency units (`USD 0.57813`, `EUR 0.37379`, `CNY 1.0993`, `JPY 13.452`, `GBP 0.080870`) with orientation-correct rate conversion (`USD/EUR` & `USD/GBP` direct; `CNY/USD` & `JPY/USD` inverted) and 6-decimal rounding.
  - Separates Official Published SDR, Reconstructed Value, Intraday Indicative Estimate, and Private Note Market Value.
  - Enforces Ed25519 signature verification, stale-data rejection (>24h), secondary-benchmark disagreement flagging (>15 bps), observation corrections, and contractual fallback (`§4.3`).
- **Multi-Service Production Artifacts Delivered**:
  - Solidity smart contracts: `contracts/RhinoSDRNote.sol`, `contracts/RhinoSDROracleAdapter.sol`, `contracts/RhinoTimelockGovernance.sol`.
  - Python FastAPI operational API, indexer, and settlement worker: `backend/app/main.py`, `backend/app/sdr_engine.py`, `backend/app/indexer.py`, `backend/app/worker.py`.
  - PostgreSQL schema migration: `migrations/001_initial_schema.sql`.
  - Full container topology: `docker-compose.yml` & `config/testnet.json`.

### Simulated Components
- **Synthetic Institutional Investors & Test Funds**: Four synthetic institutional profiles (`INV-ZURICH-PEN`, `INV-NORDIC-INS`, `INV-UK-ASSET`, plus ineligible test entity `INV-RESTRICTED-04`).
- **Off-Chain Bank Payment Rails**: Fedwire / SEPA / SWIFT MT103 settlement references and confirmations are simulated operational triggers; secondary trades explicitly model non-atomic dual-leg settlement.
- **Ethereum PoS Testnet Profile**: Deterministic local Gasper consensus simulation (`11155111-SIM`) with 6 validators where RhinoBank operates 1 node (14.23% stake).

### Automated Tests (`tests/test_platform.ts`)
Verified via `npm test` (`tsx --test tests/test_platform.ts`):
1. Unauthorised issuance rejection & audit logging.
2. Supply-cap breach prevention.
3. Idempotent subscription & mint replay protection.
4. Contractual transfer restrictions (ineligible KYC + compliance pause).
5. Oracle operator authorisation & IMF Rule O-1 formula reconstruction.
6. Stale observation rejection & contractual fallback §4.3.
7. Contract-version preservation & persistence of liabilities across pauses.
8. PoS finality, pre-finality reorg reversion, and indexer projection rebuild.
9. Strict segregation of validator ETH stake vs collateral vs operational FX liquidity.
10. Coupon calculation (`ACT/360`), duplicate `paymentEventId` blocking, and redemption sequencing (blocking premature burn before `Payment Confirmed`).
11. Ed25519 key rotation, 48h governance timelock guard, secret redaction, and 12-step Series 2027-A demonstration.

---

## 2. Network Security Assumptions & Real-World External Arrangements

### Proof-of-Stake Security Assumptions (Ethereum Gasper)
- **Safety & Finality**: Requires `< 1/3` Byzantine stake. Finalised checkpoints cannot be reverted without slashing at least 1/3 of total staked ETH.
- **Liveness**: Requires `> 2/3` online stake; if >1/3 goes offline for >4 epochs, the quadratic inactivity leak drains inactive stake until honest validators regain 2/3 supermajority.
- **Non-Control Disclosure**: RhinoBank operates 1 of 6 validators (14.23% stake) and cannot unilaterally reorder, censor, or finalise blocks.
- **Scope Boundary**: PoS consensus validates transaction authorisation and ordering; it does **not** verify external FX accuracy, off-chain asset custody, or legal enforceability.

### Required External Arrangements Before Real-Value Deployment
1. **Legal Offering Documentation & Enforceability**: Prospectus/offering memorandum defining private note claims under governing Swiss/English/NY law.
2. **Independent Reserve / Custody Attestation**: Qualified custodian agreements, ISDA/CSA agreements for FX hedges, and third-party audit attestation.
3. **Licensed Payment & Settlement Rails**: Regulated banking/Fedwire/SEPA/RTGS settlement integration and KYC/AML screening providers.
4. **Independent Smart Contract & Infrastructure Audits**: Formal third-party Solidity audit, HSM/MPC key custody (`Issuance`, `Pauser`, `Timelock` multisig signers), and live Ethereum Mainnet/L2 RPC redundancy.

---

## 3. Startup & Verification Instructions

```bash
# 1. Install dependencies & run the live interactive terminal (port 3000)
npm install
npm run dev

# 2. Run the automated institutional test suite
npm test

# 3. Full multi-container production stack (PostgreSQL + MinIO + FastAPI + Indexer + Worker + Web)
docker compose up --build
```

## 4. Live Terminal API Reference (`/api/*`)
- `GET /api/state` — Full redacted snapshot of Series, SDR Observations, PoS Chain, Indexer, Holdings, Treasury, and Audit Logs.
- `POST /api/demo/run-all` — Executes remaining demonstration steps (8–12) on Series 2027-A.
- `POST /api/series` / `POST /api/series/:seriesId/stage` — Propose and advance Draft → Reviewed → Approved → Subscription Open.
- `POST /api/subscriptions` / `/fund` / `/issue` — Idempotent subscription allocation, wire confirmation/failure, and dual-signed minting.
- `POST /api/observations` — Sign and publish dated IMF Rule O-1 SDR observations (with stale/disagreement/fallback controls).
- `POST /api/transfers` — Execute KYC/jurisdiction-gated on-chain note transfers.
- `POST /api/rfqs` & `POST /api/rfqs/:rfqId/settle` — Dealer RFQ quoting and non-atomic dual-leg secondary trade settlement.
- `POST /api/coupons/:couponId/advance` & `POST /api/redemptions` / `/advance` — Sequenced coupon and post-payment unit retirement.
- `POST /api/chain/finalise` / `/reorg` & `POST /api/indexer/rebuild` — Consensus finality, reorg recovery, and indexer rebuild.
