// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

/**
 * @title RhinoTimelockGovernance
 * @notice Enforces mandatory 48-hour governance timelock before executing contract upgrades.
 */
contract RhinoTimelockGovernance {
    uint256 public constant MIN_DELAY = 48 hours;

    struct Proposal {
        address target;
        bytes data;
        uint256 eta;
        bool executed;
        bool cancelled;
    }

    address public multisigAdmin;
    mapping(bytes32 => Proposal) public proposals;

    event ProposalQueued(bytes32 indexed proposalId, address indexed target, uint256 eta);
    event ProposalExecuted(bytes32 indexed proposalId, address indexed target);
    event ProposalCancelled(bytes32 indexed proposalId);

    constructor(address _multisigAdmin) {
        multisigAdmin = _multisigAdmin;
    }

    function queue(address target, bytes calldata data, uint256 delaySeconds) external returns (bytes32) {
        require(msg.sender == multisigAdmin, "Only governance multisig");
        require(delaySeconds >= MIN_DELAY, "Delay below 48h minimum");
        uint256 eta = block.timestamp + delaySeconds;
        bytes32 id = keccak256(abi.encode(target, data, eta));
        proposals[id] = Proposal({target: target, data: data, eta: eta, executed: false, cancelled: false});
        emit ProposalQueued(id, target, eta);
        return id;
    }

    function execute(bytes32 proposalId) external {
        require(msg.sender == multisigAdmin, "Only governance multisig");
        Proposal storage p = proposals[proposalId];
        require(p.eta > 0 && !p.executed && !p.cancelled, "Invalid proposal state");
        require(block.timestamp >= p.eta, "Timelock delay active");
        p.executed = true;
        (bool ok, ) = p.target.call(p.data);
        require(ok, "Upgrade call failed");
        emit ProposalExecuted(proposalId, p.target);
    }
}
