// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

/**
 * @title RhinoSDROracleAdapter
 * @notice Authenticated registry of dated IMF Rule O-1 SDR basket valuations.
 * @dev    PoS consensus validates transaction authorisation and ordering; it does NOT
 *         independently verify off-chain FX market rates.
 */
contract RhinoSDROracleAdapter {
    enum ObservationStatus {
        PUBLISHED,
        DISAGREEMENT_FLAGGED,
        CORRECTED,
        FALLBACK_USED
    }

    struct Observation {
        bytes32 observationId;
        string basketVersionId;
        uint256 reconstructedSdrUsd1e6;
        uint256 officialSdrUsd1e6;
        uint256 effectiveTimestamp;
        uint256 retrievalTimestamp;
        ObservationStatus status;
        bytes32 supersedesId;
        address publisher;
    }

    address public oracleAdmin;
    mapping(address => bool) public authorizedPublishers;
    uint256 public maxStalenessSeconds = 86400;
    mapping(bytes32 => Observation) public observations;

    event ObservationPublished(
        bytes32 indexed observationId,
        string basketVersionId,
        uint256 reconstructedSdrUsd1e6,
        ObservationStatus status
    );

    constructor(address _admin, address _initialPublisher) {
        oracleAdmin = _admin;
        authorizedPublishers[_initialPublisher] = true;
    }

    function setPublisher(address publisher, bool allowed) external {
        require(msg.sender == oracleAdmin, "Only oracleAdmin");
        authorizedPublishers[publisher] = allowed;
    }

    function publishObservation(
        bytes32 observationId,
        string calldata basketVersionId,
        uint256 reconstructedSdrUsd1e6,
        uint256 officialSdrUsd1e6,
        uint256 effectiveTimestamp,
        uint256 retrievalTimestamp,
        ObservationStatus status,
        bytes32 supersedesId
    ) external {
        require(authorizedPublishers[msg.sender], "Unauthorised oracle publisher");
        require(observations[observationId].effectiveTimestamp == 0, "Observation ID exists");
        require(retrievalTimestamp >= effectiveTimestamp, "Invalid timestamps");

        if (status != ObservationStatus.FALLBACK_USED) {
            require(retrievalTimestamp - effectiveTimestamp <= maxStalenessSeconds, "Stale observation rejected");
        }

        observations[observationId] = Observation({
            observationId: observationId,
            basketVersionId: basketVersionId,
            reconstructedSdrUsd1e6: reconstructedSdrUsd1e6,
            officialSdrUsd1e6: officialSdrUsd1e6,
            effectiveTimestamp: effectiveTimestamp,
            retrievalTimestamp: retrievalTimestamp,
            status: status,
            supersedesId: supersedesId,
            publisher: msg.sender
        });

        emit ObservationPublished(observationId, basketVersionId, reconstructedSdrUsd1e6, status);
    }
}
