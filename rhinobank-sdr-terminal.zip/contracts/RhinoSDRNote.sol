// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

/**
 * @title RhinoSDRNote
 * @notice Private SDR-linked institutional note contract (ERC-20 fungible units within a series
 *         with ERC-3643-style transfer eligibility, supply caps, and separated governance roles).
 * @dev    Issued instruments are PRIVATE ISSUER OBLIGATIONS referencing the IMF SDR basket.
 *         They are NOT official IMF SDR allocations.
 */
contract RhinoSDRNote {
    bytes32 public constant ISSUER_ROLE = keccak256("ISSUER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");
    bytes32 public constant TRANSFER_AGENT_ROLE = keccak256("TRANSFER_AGENT_ROLE");
    bytes32 public constant ORACLE_ADMIN_ROLE = keccak256("ORACLE_ADMIN_ROLE");
    bytes32 public constant UPGRADER_TIMELOCK_ROLE = keccak256("UPGRADER_TIMELOCK_ROLE");

    string public seriesId;
    string public basketVersionId;
    bytes32 public approvedTermsCommitment;
    uint256 public immutable supplyCapUnits;
    uint256 public totalIssuedUnits;
    uint256 public totalOutstandingUnits;
    uint256 public totalRedeemedUnits;

    bool public issuancePaused;
    bool public transfersRestricted;
    uint256 public lockupUntil;

    address public oracleAdapter;
    address public timelockController;

    mapping(bytes32 => mapping(address => bool)) public roles;
    mapping(address => uint256) public balanceOf;
    mapping(address => bool) public whitelistedInvestor;
    mapping(bytes32 => bool) public processedIdempotencyKeys;
    mapping(bytes32 => bool) public confirmedPaymentEvents;

    event SeriesInitialized(string indexed seriesId, bytes32 approvedTermsCommitment, uint256 supplyCapUnits);
    event NoteIssued(bytes32 indexed idempotencyKey, address indexed investor, uint256 units, bytes32 observationId);
    event NoteTransferred(address indexed from, address indexed to, uint256 units);
    event PaymentConfirmationAnchored(bytes32 indexed paymentEventId, bytes32 bankReferenceHash);
    event NoteRedeemedAndRetired(bytes32 indexed paymentEventId, address indexed investor, uint256 units);
    event IssuancePauseChanged(bool paused);
    event TransfersRestrictionChanged(bool restricted);
    event WhitelistUpdated(address indexed investor, bool eligible);
    event OracleAdapterUpdated(address indexed newAdapter);

    modifier onlyRole(bytes32 role) {
        require(roles[role][msg.sender], "RhinoSDRNote: missing required role");
        _;
    }

    constructor(
        string memory _seriesId,
        string memory _basketVersionId,
        bytes32 _approvedTermsCommitment,
        uint256 _supplyCapUnits,
        uint256 _lockupUntil,
        address _issuer,
        address _pauser,
        address _transferAgent,
        address _oracleAdmin,
        address _timelockController
    ) {
        require(_supplyCapUnits > 0, "Supply cap must be positive");
        require(_approvedTermsCommitment != bytes32(0), "Terms commitment required");

        seriesId = _seriesId;
        basketVersionId = _basketVersionId;
        approvedTermsCommitment = _approvedTermsCommitment;
        supplyCapUnits = _supplyCapUnits;
        lockupUntil = _lockupUntil;
        timelockController = _timelockController;

        roles[ISSUER_ROLE][_issuer] = true;
        roles[PAUSER_ROLE][_pauser] = true;
        roles[TRANSFER_AGENT_ROLE][_transferAgent] = true;
        roles[ORACLE_ADMIN_ROLE][_oracleAdmin] = true;
        roles[UPGRADER_TIMELOCK_ROLE][_timelockController] = true;

        emit SeriesInitialized(_seriesId, _approvedTermsCommitment, _supplyCapUnits);
    }

    function setInvestorEligibility(address investor, bool eligible) external onlyRole(TRANSFER_AGENT_ROLE) {
        whitelistedInvestor[investor] = eligible;
        emit WhitelistUpdated(investor, eligible);
    }

    function setIssuancePaused(bool paused) external onlyRole(PAUSER_ROLE) {
        issuancePaused = paused;
        // Pausing issuance NEVER cancels or erases existing contractual coupon/redemption liabilities.
        emit IssuancePauseChanged(paused);
    }

    function setTransfersRestricted(bool restricted) external onlyRole(TRANSFER_AGENT_ROLE) {
        transfersRestricted = restricted;
        emit TransfersRestrictionChanged(restricted);
    }

    function setOracleAdapter(address newAdapter) external onlyRole(ORACLE_ADMIN_ROLE) {
        require(newAdapter != address(0), "Invalid oracle adapter");
        oracleAdapter = newAdapter;
        emit OracleAdapterUpdated(newAdapter);
    }

    function issueWithIdempotency(
        bytes32 idempotencyKey,
        address investor,
        uint256 units,
        bytes32 observationId
    ) external onlyRole(ISSUER_ROLE) {
        require(!issuancePaused, "Issuance paused");
        require(whitelistedInvestor[investor], "Recipient fails eligibility whitelist");
        require(units > 0, "Units must be positive");

        if (processedIdempotencyKeys[idempotencyKey]) {
            // Idempotent no-op: do not mint duplicate units
            return;
        }
        require(totalIssuedUnits + units <= supplyCapUnits, "Supply cap exceeded");

        processedIdempotencyKeys[idempotencyKey] = true;
        totalIssuedUnits += units;
        totalOutstandingUnits += units;
        balanceOf[investor] += units;

        emit NoteIssued(idempotencyKey, investor, units, observationId);
    }

    function transfer(address to, uint256 units) external returns (bool) {
        require(!transfersRestricted, "Transfers restricted by compliance");
        require(block.timestamp >= lockupUntil, "Series in lockup period");
        require(whitelistedInvestor[msg.sender] && whitelistedInvestor[to], "Both parties must be eligible");
        require(balanceOf[msg.sender] >= units, "Insufficient balance");

        balanceOf[msg.sender] -= units;
        balanceOf[to] += units;
        emit NoteTransferred(msg.sender, to, units);
        return true;
    }

    function anchorPaymentConfirmation(
        bytes32 paymentEventId,
        bytes32 bankReferenceHash
    ) external onlyRole(ISSUER_ROLE) {
        require(!confirmedPaymentEvents[paymentEventId], "Duplicate payment event");
        confirmedPaymentEvents[paymentEventId] = true;
        emit PaymentConfirmationAnchored(paymentEventId, bankReferenceHash);
    }

    function retireRedeemedUnits(
        bytes32 paymentEventId,
        address investor,
        uint256 units
    ) external onlyRole(ISSUER_ROLE) {
        require(confirmedPaymentEvents[paymentEventId], "Payment confirmation required before retirement");
        require(balanceOf[investor] >= units, "Insufficient holder balance");
        require(totalOutstandingUnits >= units, "Outstanding underflow");

        balanceOf[investor] -= units;
        totalOutstandingUnits -= units;
        totalRedeemedUnits += units;

        emit NoteRedeemedAndRetired(paymentEventId, investor, units);
    }
}
