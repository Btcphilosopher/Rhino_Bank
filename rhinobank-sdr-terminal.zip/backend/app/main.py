from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict
from .sdr_engine import is_observation_stale, reconstruct_sdr_usd

app = FastAPI(
    title="RHINOBANK — SDR Note Operational API",
    version="1.0.0",
    description="Private SDR-linked issuer obligation — not an IMF SDR allocation (Testnet Simulation).",
)


class ValuationRequest(BaseModel):
    quotes: Dict[str, float]
    effective_time: str
    retrieval_time: str


@app.get("/health")
def health():
    return {
        "status": "ok",
        "environment": "TESTNET / SIMULATION",
        "disclaimer": "Private SDR-linked issuer obligation — not an IMF SDR allocation.",
    }


@app.post("/sdr/reconstruct")
def reconstruct(req: ValuationRequest):
    if is_observation_stale(req.effective_time, req.retrieval_time):
        raise HTTPException(status_code=422, detail="Observation rejected: stale beyond 24h policy")
    val = reconstruct_sdr_usd(req.quotes)
    return {
        "basket_version_id": "IMF-2022-R1",
        "reconstructed_sdr_usd": float(val),
        "effective_time": req.effective_time,
        "retrieval_time": req.retrieval_time,
    }
