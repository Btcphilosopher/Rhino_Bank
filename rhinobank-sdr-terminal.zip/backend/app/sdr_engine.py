from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List


@dataclass(frozen=True)
class BasketCurrency:
    currency: str
    fixed_amount: Decimal
    quote_convention: str  # DIRECT_USD_PER_CCY or INDIRECT_CCY_PER_USD


IMF_2022_R1: List[BasketCurrency] = [
    BasketCurrency("USD", Decimal("0.57813"), "DIRECT_USD_PER_CCY"),
    BasketCurrency("EUR", Decimal("0.37379"), "DIRECT_USD_PER_CCY"),
    BasketCurrency("CNY", Decimal("1.0993"), "INDIRECT_CCY_PER_USD"),
    BasketCurrency("JPY", Decimal("13.452"), "INDIRECT_CCY_PER_USD"),
    BasketCurrency("GBP", Decimal("0.080870"), "DIRECT_USD_PER_CCY"),
]


def reconstruct_sdr_usd(quotes: Dict[str, float], rounding_decimals: int = 6) -> Decimal:
    """Compute V_USD = sum(a_i * r_i) with exact IMF Rule O-1 quote orientation."""
    total = Decimal("0")
    for item in IMF_2022_R1:
        q = Decimal(str(quotes[item.currency]))
        if q <= 0:
            raise ValueError(f"Non-positive FX quote for {item.currency}")
        r_i = q if item.quote_convention == "DIRECT_USD_PER_CCY" else (Decimal("1") / q)
        total += item.fixed_amount * r_i
    quant = Decimal("1").scaleb(-rounding_decimals)
    return total.quantize(quant, rounding=ROUND_HALF_UP)


def is_observation_stale(effective_iso: str, retrieval_iso: str, max_age_seconds: int = 86400) -> bool:
    eff = datetime.fromisoformat(effective_iso.replace("Z", "+00:00")).astimezone(timezone.utc)
    ret = datetime.fromisoformat(retrieval_iso.replace("Z", "+00:00")).astimezone(timezone.utc)
    return (ret - eff).total_seconds() > max_age_seconds
