"""Chain-specific Ethereum PoS indexer worker for rebuilding finalised ownership projections."""

import os
import time


def rebuild_projections_from_finalised_events(events: list[dict]) -> dict[str, int]:
    balances: dict[str, int] = {}
    for ev in sorted(events, key=lambda e: e["block_number"]):
        if not ev.get("finalised") or ev.get("reorged"):
            continue
        name = ev["event_name"]
        args = ev["args"]
        if name == "NOTE_ISSUED":
            inv = args["investor_id"]
            balances[inv] = balances.get(inv, 0) + int(args["units"])
        elif name == "NOTE_TRANSFERRED":
            frm, to, units = args["from_investor_id"], args["to_investor_id"], int(args["units"])
            balances[frm] = max(0, balances.get(frm, 0) - units)
            balances[to] = balances.get(to, 0) + units
        elif name == "NOTE_REDEEMED_AND_RETIRED":
            inv = args["investor_id"]
            balances[inv] = max(0, balances.get(inv, 0) - int(args["units"]))
    return balances


if __name__ == "__main__":
    db_url = os.getenv("DATABASE_URL", "postgresql://localhost/rhinobank_sdr")
    print(f"[chain-indexer] Watching Ethereum PoS finalised checkpoints -> {db_url}")
    while True:
        time.sleep(12)
