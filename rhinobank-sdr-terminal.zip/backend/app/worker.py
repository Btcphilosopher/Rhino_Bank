"""Background worker for scheduled coupon calculation and bank-rail settlement reconciliation."""

import os
import time

if __name__ == "__main__":
    db_url = os.getenv("DATABASE_URL", "postgresql://localhost/rhinobank_sdr")
    print(f"[settlement-worker] Monitoring coupon & redemption settlement queues -> {db_url}")
    while True:
        time.sleep(15)
