package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.math.BigDecimal
import java.math.RoundingMode

enum class RateCategory(val displayNameEn: String, val displayNameAr: String) {
    PUBLISHED_QIBOR_FIXING("Published QIBOR Fixing", "سعر تثبيت QIBOR المنشور"),
    AVERAGE_OVERNIGHT_INTERBANK("Average Overnight Interbank", "متوسط سعر ما بين البنوك لليلة واحدة"),
    QCB_POLICY_RATES("QCB Policy Rate", "سعر سياسة مصرف قطر المركزي"),
    INDIVIDUAL_BANK_QUOTES("Individual Bank Quote", "تسعير مصرف فردي"),
    EXECUTED_TRANSACTIONS("Executed Transaction Rate", "سعر العمليات المنفذة"),
    INTERNAL_FTP("Internal Funding-Transfer Price", "سعر تحويل التمويل الداخلي"),
    RHINOQUANT_ESTIMATE("RhinoQuant Model Estimate", "تقدير نموذج راينو كوانت")
}

enum class Tenor(val code: String, val labelEn: String, val labelAr: String, val approxDays: Int) {
    ON("O/N", "Overnight", "ليلة واحدة", 1),
    W1("1W", "1 Week", "أسبوع واحد", 7),
    M1("1M", "1 Month", "شهر واحد", 30),
    M3("3M", "3 Months", "3 أشهر", 90),
    M6("6M", "6 Months", "6 أشهر", 180),
    Y1("1Y", "1 Year", "سنة واحدة", 360)
}

enum class QualityStatus(val labelEn: String, val labelAr: String) {
    PUBLISHED_TODAY("Published Today", "نُشر اليوم"),
    EFFECTIVE_TODAY("Effective Today", "سارٍ اليوم"),
    LAST_AVAILABLE("Last Available", "آخر متاح"),
    STALE("Stale", "قديم"),
    ESTIMATED("Estimated", "مقدّر"),
    SIMULATED("Simulated", "محاكى توضيحي")
}

enum class EntitlementStatus(val labelEn: String) {
    LICENSED_INSTITUTIONAL("Licensed Institutional"),
    PUBLIC_POLICY("Public Policy"),
    INTERNAL_TREASURY("Internal Treasury Only"),
    RESTRICTED_REDISTRIBUTION("Restricted Redistribution")
}

enum class DayCountConvention(val code: String, val basisDays: Int, val labelEn: String, val labelAr: String) {
    ACT_360("ACT/360", 360, "ACT/360 (Money Market Standard)", "أساس ACT/360 (سوق النقد القياسي)"),
    ACT_365("ACT/365", 365, "ACT/365 (Bond Standard)", "أساس ACT/365 (السندات)"),
    THIRTY_360("30/360", 360, "30/360 (Fixed Convention)", "أساس 30/360 (التقليدي)")
}

enum class FundingType(val labelEn: String, val labelAr: String) {
    UNSECURED_INTERBANK("Unsecured Interbank", "اقتراض بين البنوك غير مضمون"),
    SECURED_REPO("Secured QCB/Repo", "تمويل ريبو مضمون"),
    QCB_DEPOSIT_FACILITY("QCB Deposit Facility", "تسهيل الإيداع لدى المركزي"),
    COMMERCIAL_DEPOSIT("Commercial Deposit", "وديعة تجارية")
}

@Entity(tableName = "rate_observations")
data class RateObservation(
    @PrimaryKey val seriesId: String,
    val category: RateCategory,
    val tenor: Tenor,
    val currency: String = "QAR",
    val ratePercent: Double,
    val changeBp: Int,
    val observationDate: String, // YYYY-MM-DD
    val publicationTimestampUtc: String,
    val publicationTimestampLocal: String,
    val effectiveDate: String,
    val source: String,
    val revisionId: String = "REV-01",
    val qualityStatus: QualityStatus,
    val entitlement: EntitlementStatus,
    val uncertaintyBp: Double = 0.0,
    val methodologyNote: String = ""
)

@Entity(tableName = "liquidity_ladder")
data class LiquidityLadderItem(
    @PrimaryKey val dateIso: String,
    val dateDisplayEn: String,
    val dateDisplayAr: String,
    val inflowsQarMillions: Double,
    val outflowsQarMillions: Double,
    val netFundingQarMillions: Double,
    val cumulativeNetQarMillions: Double = 0.0,
    val isWeekendOrHoliday: Boolean = false
)

@Entity(tableName = "treasury_alerts")
data class TreasuryAlert(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // "Policy scenarios", "Funding Gap", "Liquidity Outlook", "Data Quality"
    val titleEn: String,
    val titleAr: String,
    val messageEn: String,
    val messageAr: String,
    val timestampLocal: String,
    val severity: AlertSeverity,
    val isRead: Boolean = false
)

enum class AlertSeverity {
    INFO, WARNING, CRITICAL
}

data class HistoricalRatePoint(
    val dateDisplay: String,
    val qiborRate: Double,
    val observedRate: Double,
    val policyRate: Double,
    val modelScenarioLower: Double,
    val modelScenarioUpper: Double
)

data class FundingCalculationResult(
    val principal: BigDecimal,
    val annualRatePercent: Double,
    val days: Int,
    val convention: DayCountConvention,
    val interestAmount: BigDecimal,
    val maturityProceeds: BigDecimal,
    val formulaDisplay: String
)

data class CurveNode(
    val tenor: Tenor,
    val days: Int,
    val ratePercent: Double,
    val discountFactor: Double,
    val zeroRatePercent: Double,
    val forwardRatePercent: Double,
    val pv01Qar: Double
)

data class ScenarioStressResult(
    val scenarioName: String,
    val rateShiftBp: Int,
    val depositOutflowPercent: Double,
    val delayedReceiptDays: Int,
    val totalFundingCostQar: Double,
    val costChangeQar: Double,
    val liquidityGapQarMillions: Double,
    val bufferUtilisationPercent: Double,
    val isBufferBreached: Boolean
)

data class MonteCarloSummary(
    val iterations: Int = 1000,
    val meanFundingCostQar: Double,
    val standardErrorQar: Double,
    val p5thCostQar: Double,
    val p50thCostQar: Double,
    val p95thCostQar: Double,
    val probabilityOfDeficit: Double
)

@Entity(tableName = "audit_records")
data class AuditRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: String,
    val action: String,
    val performedBy: String,
    val role: String, // "Treasury Dealer", "Risk Manager", "Data Admin", "System"
    val status: String, // "APPROVED", "PENDING_CHECKER", "AUTO_RECORDED"
    val details: String
)
