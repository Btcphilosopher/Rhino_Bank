package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LiquidityLadderItem
import com.example.ui.components.LiquidityLadderTable
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MovementGreen
import com.example.ui.theme.MovementRed
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.util.Locale

@Composable
fun LiquidityScreen(
    items: List<LiquidityLadderItem>,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val openingCashMillions = 2450.0
    val internalBufferTargetMillions = 500.0
    val nextDayGapMillions = -125.0
    val netBufferAvailable = openingCashMillions + nextDayGapMillions - internalBufferTargetMillions

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidityMetricCard(
                title = "Opening Cash Balance",
                titleAr = "الرصيد النقدي الافتتاحي",
                value = "QAR ${String.format(Locale.US, "%,.1f", openingCashMillions)}m",
                subtitle = "Central Bank & Nostro clearing accounts",
                modifier = Modifier.weight(1f)
            )

            LiquidityMetricCard(
                title = "Internal Minimum Buffer",
                titleAr = "الحد الأدنى الاحتياطي",
                value = "QAR ${String.format(Locale.US, "%,.1f", internalBufferTargetMillions)}m",
                subtitle = "Board mandated prudential reserve",
                modifier = Modifier.weight(1f)
            )

            LiquidityMetricCard(
                title = "Next-Day Projected Gap",
                titleAr = "فجوة اليوم التالي المتوقعة",
                value = "-QAR ${String.format(Locale.US, "%,.1f", kotlin.math.abs(nextDayGapMillions))}m",
                subtitle = "Action required: Refinance via Interbank/Repo",
                valueColor = RhinoGoldBright,
                modifier = Modifier.weight(1f)
            )

            LiquidityMetricCard(
                title = "Net Headroom Above Buffer",
                titleAr = "فائض السيولة المتاح",
                value = "QAR ${String.format(Locale.US, "%,.1f", netBufferAvailable)}m",
                subtitle = "Available unencumbered buffer",
                valueColor = MovementGreen,
                modifier = Modifier.weight(1f)
            )
        }

        // Buffer Health Progress Indicator
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(1.dp, TerminalCardBorder, RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.WaterDrop, contentDescription = "Buffer", tint = RhinoGold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PRUDENTIAL LIQUIDITY BUFFER COVERAGE RATIO", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("365% (Compliant > 100%)", color = MovementGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { 0.73f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = RhinoGold,
                    trackColor = Color(0xFF1E2838),
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Contractual cash outflows are segregated from uncertain behavioural deposit flight forecasts. Qatar Banking weekend roll (Thu->Sun) strictly applied.",
                    color = IvoryDim,
                    fontSize = 10.sp
                )
            }
        }

        // Full Liquidity Ladder Table
        LiquidityLadderTable(
            items = items,
            modifier = Modifier.fillMaxWidth()
        )

        // Collateral Commitments & Central Bank Facility Limits
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(1.dp, TerminalCardBorder, RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Text("CONFIGURED REPO FACILITIES & COLLATERAL COMMITTED", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    FacilityStatusRow("QCB Repo Standing Facility", "Limit: QAR 2,000m", "Utilised: QAR 350m", "Collateral: QCB T-Bills (5% Haircut)")
                    FacilityStatusRow("Interbank Bilateral Credit Lines", "Limit: QAR 3,500m", "Utilised: QAR 1,200m", "Unsecured (Tier-1 Banks)")
                }
            }
        }
    }
}

@Composable
private fun LiquidityMetricCard(
    title: String,
    titleAr: String,
    value: String,
    subtitle: String,
    valueColor: Color = IvoryWhite,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCardBackground)
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(titleAr, color = IvoryDim, fontSize = 9.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, color = valueColor, fontSize = 18.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(4.dp))
            Text(subtitle, color = IvoryDim, fontSize = 9.sp)
        }
    }
}

@Composable
private fun FacilityStatusRow(facility: String, limit: String, utilised: String, note: String) {
    Column(modifier = Modifier.padding(horizontal = 6.dp)) {
        Text(facility, color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("$limit  •  $utilised", color = RhinoGoldBright, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text(note, color = IvoryDim, fontSize = 9.sp)
    }
}
