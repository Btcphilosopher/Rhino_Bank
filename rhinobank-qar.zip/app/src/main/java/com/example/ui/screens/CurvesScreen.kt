package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.QuantitativeEngine
import com.example.model.RateObservation
import com.example.model.Tenor
import com.example.ui.theme.ChartObservedGold
import com.example.ui.theme.ChartQiborPink
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TableRowAlt
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.util.Locale

@Composable
fun CurvesScreen(
    rateObservations: List<RateObservation>,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Map tenors to rates
    val tenorRateMap = remember(rateObservations) {
        val map = mutableMapOf<Tenor, Double>()
        listOf(Tenor.ON, Tenor.W1, Tenor.M1, Tenor.M3, Tenor.M6, Tenor.Y1).forEach { t ->
            val obs = rateObservations.find { it.tenor == t }
            map[t] = obs?.ratePercent ?: when(t) {
                Tenor.ON -> 4.25
                Tenor.W1 -> 4.29
                Tenor.M1 -> 4.35
                Tenor.M3 -> 4.48
                Tenor.M6 -> 4.60
                Tenor.Y1 -> 4.72
            }
        }
        map
    }

    val curveNodes = remember(tenorRateMap) {
        QuantitativeEngine.buildYieldCurve(tenorRateMap)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Curve Masthead
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF141A28))
                .border(1.dp, RhinoGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.TrendingUp, contentDescription = "Curve", tint = RhinoGold, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "QAR MONEY MARKET YIELD & DISCOUNT CURVE ANALYTICS",
                        color = IvoryWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "Bootstrapped discount factors, zero rates, and forward rates derived under ACT/360 money market convention.",
                        color = IvoryMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Visual Curve Chart: QIBOR Term Structure vs Forward Rates
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("QIBOR TERM STRUCTURE & FORWARD RATE CURVE", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.width(12.dp).height(3.dp).background(ChartQiborPink))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Spot QIBOR", color = IvoryMuted, fontSize = 9.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(modifier = Modifier.width(12.dp).height(3.dp).background(ChartObservedGold))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Forward Rate", color = IvoryMuted, fontSize = 9.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(modifier = Modifier.fillMaxWidth().height(150.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        val paddingLeft = 40.dp.toPx()
                        val paddingRight = 16.dp.toPx()
                        val paddingTop = 10.dp.toPx()
                        val paddingBottom = 20.dp.toPx()

                        val chartW = w - paddingLeft - paddingRight
                        val chartH = h - paddingTop - paddingBottom

                        val minRate = 4.10
                        val maxRate = 5.00

                        fun toY(r: Double): Float {
                            val norm = (r - minRate) / (maxRate - minRate)
                            return (paddingTop + chartH * (1f - norm)).toFloat()
                        }

                        val n = curveNodes.size
                        if (n > 1) {
                            val stepX = chartW / (n - 1)

                            // Spot Path (Pink)
                            val spotPath = Path()
                            for (i in 0 until n) {
                                val x = paddingLeft + i * stepX
                                val y = toY(curveNodes[i].ratePercent)
                                if (i == 0) spotPath.moveTo(x, y) else spotPath.lineTo(x, y)
                            }
                            drawPath(spotPath, ChartQiborPink, style = Stroke(width = 2.5f, cap = StrokeCap.Round))

                            // Forward Path (Gold)
                            val fwdPath = Path()
                            for (i in 0 until n) {
                                val x = paddingLeft + i * stepX
                                val y = toY(curveNodes[i].forwardRatePercent)
                                if (i == 0) fwdPath.moveTo(x, y) else fwdPath.lineTo(x, y)
                            }
                            drawPath(fwdPath, ChartObservedGold, style = Stroke(width = 2.5f, cap = StrokeCap.Round))

                            // Points
                            for (i in 0 until n) {
                                val x = paddingLeft + i * stepX
                                drawCircle(ChartQiborPink, radius = 3.5f, center = Offset(x, toY(curveNodes[i].ratePercent)))
                                drawCircle(ChartObservedGold, radius = 3.5f, center = Offset(x, toY(curveNodes[i].forwardRatePercent)))
                            }
                        }
                    }
                }

                // X-Axis Tenor Labels
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 40.dp, end = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    curveNodes.forEach { node ->
                        Text(node.tenor.code, color = IvoryMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Complete Bootstrapped Curve Analytics Table
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Text("BOOTSTRAPPED CURVE NODES & SENSITIVITY TABLE", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF182232))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text("Tenor", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                    Text("Days", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f))
                    Text("Par Rate", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                    Text("Discount Factor", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1.3f))
                    Text("Forward Rate", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1.1f))
                    Text("PV01 (QAR 10m)", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1.2f))
                }

                HorizontalDivider(color = Color(0xFF25344A), thickness = 1.dp)

                curveNodes.forEachIndexed { index, node ->
                    val isAlt = index % 2 == 1
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isAlt) TableRowAlt else Color.Transparent)
                            .padding(horizontal = 8.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(node.tenor.code, color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                        Text("${node.days}d", color = IvoryDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.7f))
                        Text("${String.format(Locale.US, "%.2f", node.ratePercent)}%", color = RhinoGoldBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                        Text(String.format(Locale.US, "%.6f", node.discountFactor), color = IvoryWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.weight(1.3f))
                        Text("${String.format(Locale.US, "%.2f", node.forwardRatePercent)}%", color = IvoryWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.weight(1.1f))
                        Text("QAR ${String.format(Locale.US, "%,.2f", node.pv01Qar)}", color = IvoryDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.weight(1.2f))
                    }
                    if (index < curveNodes.size - 1) {
                        HorizontalDivider(color = Color(0xFF1E2838), thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}
