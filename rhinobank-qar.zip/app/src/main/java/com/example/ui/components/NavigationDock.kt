package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TerminalWorkspace
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBorder

data class NavItemSpec(
    val workspace: TerminalWorkspace,
    val icon: ImageVector,
    val titleEn: String,
    val titleAr: String
)

val NavigationItems = listOf(
    NavItemSpec(TerminalWorkspace.OVERVIEW, Icons.Default.Home, "Overview", "نظرة عامة"),
    NavItemSpec(TerminalWorkspace.INTEREST_RATES, Icons.Default.Percent, "Interest Rates", "أسعار الفائدة"),
    NavItemSpec(TerminalWorkspace.LIQUIDITY, Icons.Default.Waves, "Liquidity", "السيولة"),
    NavItemSpec(TerminalWorkspace.FUNDING, Icons.Default.MonetizationOn, "Funding", "التمويل"),
    NavItemSpec(TerminalWorkspace.RISK, Icons.Default.Shield, "Risk", "المخاطر"),
    NavItemSpec(TerminalWorkspace.REPORTS, Icons.Default.Assessment, "Reports", "التقارير")
)

@Composable
fun VerticalNavigationDock(
    currentWorkspace: TerminalWorkspace,
    onSelectWorkspace: (TerminalWorkspace) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxHeight()
            .width(105.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF141924), Color(0xFF0F141F), Color(0xFF171D2B))
                )
            )
            .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
            .padding(vertical = 10.dp, horizontal = 6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NavigationItems.forEach { item ->
                val isSelected = item.workspace == currentWorkspace

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isSelected) {
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFF332917), Color(0xFF221A0E))
                                )
                            } else {
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Transparent)
                                )
                            }
                        )
                        .border(
                            1.dp,
                            if (isSelected) RhinoGold else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectWorkspace(item.workspace) }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.titleEn,
                            tint = if (isSelected) RhinoGoldBright else IvoryMuted,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = item.titleAr,
                            color = if (isSelected) IvoryWhite else IvoryDim,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = item.titleEn,
                            color = if (isSelected) RhinoGoldBright else IvoryDim,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HorizontalNavigationDock(
    currentWorkspace: TerminalWorkspace,
    onSelectWorkspace: (TerminalWorkspace) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF141924))
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(8.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        NavigationItems.forEach { item ->
            val isSelected = item.workspace == currentWorkspace
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) Color(0xFF2B2212) else Color.Transparent)
                    .border(1.dp, if (isSelected) RhinoGold else Color.Transparent, RoundedCornerShape(6.dp))
                    .clickable { onSelectWorkspace(item.workspace) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.titleEn,
                        tint = if (isSelected) RhinoGoldBright else IvoryDim,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = item.titleEn,
                        color = if (isSelected) IvoryWhite else IvoryDim,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}
