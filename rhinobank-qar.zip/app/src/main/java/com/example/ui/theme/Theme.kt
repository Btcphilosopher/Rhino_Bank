package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TerminalColorScheme = darkColorScheme(
    primary = RhinoGold,
    onPrimary = TerminalObsidian,
    primaryContainer = RhinoGoldContainer,
    onPrimaryContainer = RhinoGoldBright,
    secondary = IvoryWhite,
    onSecondary = TerminalObsidian,
    secondaryContainer = TerminalCardSurface,
    onSecondaryContainer = IvoryWhite,
    background = TerminalObsidian,
    onBackground = IvoryWhite,
    surface = TerminalCardBackground,
    onSurface = IvoryWhite,
    surfaceVariant = TerminalCardSurface,
    onSurfaceVariant = IvoryMuted,
    outline = TerminalCardBorder,
    error = MovementRed,
    onError = IvoryWhite,
    errorContainer = MovementRedBg,
    onErrorContainer = MovementRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Terminal uses dedicated brand colors
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
