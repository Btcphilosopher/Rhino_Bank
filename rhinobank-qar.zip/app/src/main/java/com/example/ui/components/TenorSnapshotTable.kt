package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RateObservation
import com.example.model.Tenor
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TableRowAlt
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder

@Composable
fun TenorSnapshotTable(
    rateObservations: List<RateObservation>,
    onSelectTenor: (Tenor, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    // Collect tenors from observations
    val rows = listOf(
        Triple(Tenor.ON, "ليلة واحدة", rateObservations.find { it.tenor == Tenor.ON }?.ratePercent ?: 4.25),
        Triple(Tenor.W1, "أسبوع واحد", rateObservations.find { it.tenor == Tenor.W1 }?.ratePercent ?: 4.29),
        Triple(Tenor.M1, "شهر واحد", rateObservations.find { it.tenor == Tenor.M1 }?.ratePercent ?: 4.35),
        Triple(Tenor.M3, "3 أشهر", rateObservations.find { it.tenor == Tenor.M3 }?.ratePercent ?: 4.48),
        Triple(Tenor.M6, "6 أشهر", rateObservations.find { it.tenor == Tenor.M6 }?.ratePercent ?: 4.60),
        Triple(Tenor.Y1, "سنة واحدة", rateObservations.find { it.tenor == Tenor.Y1 }?.ratePercent ?: 4.72)
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCardBackground)
            .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = "Tenors",
                    tint = RhinoGold,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "QAR TENOR SNAPSHOT",
                    color = IvoryWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = "  |  ",
                    color = IvoryDim,
                    fontSize = 13.sp
                )
                Text(
                    text = "لمحة عن آجال الريال القطري",
                    color = IvoryMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Table Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF182232))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tenor",
                    color = IvoryMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(0.8f)
                )
                Text(
                    text = "الأجل",
                    color = IvoryMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1.2f)
                )
                Text(
                    text = "Rate (QAR) (المعدل بالريال القطري)",
                    color = IvoryMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.End,
                    modifier = Modifier.weight(2f)
                )
            }

            HorizontalDivider(color = Color(0xFF25344A), thickness = 1.dp)

            // Table Body
            rows.forEachIndexed { index, (tenor, labelAr, rate) ->
                val isAlt = index % 2 == 1
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isAlt) TableRowAlt else Color.Transparent)
                        .clickable { onSelectTenor(tenor, rate) }
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tenor.code,
                        color = IvoryWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(0.8f)
                    )
                    Text(
                        text = labelAr,
                        color = IvoryMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1.2f)
                    )
                    Text(
                        text = "${String.format(java.util.Locale.US, "%.2f", rate)}%",
                        color = if (index == 0) RhinoGoldBright else IvoryWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(2f)
                    )
                }
                if (index < rows.size - 1) {
                    HorizontalDivider(color = Color(0xFF1B2433), thickness = 0.5.dp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Table Footnote
            Text(
                text = "ⓘ Illustrative inputs (market & policy-aligned)  مدخلات توضيحية (متسقة مع السوق والسياسة)",
                color = IvoryDim,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
