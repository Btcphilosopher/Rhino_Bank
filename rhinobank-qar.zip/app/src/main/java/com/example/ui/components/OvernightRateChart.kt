package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HistoricalRatePoint
import com.example.ui.theme.ChartObservedGold
import com.example.ui.theme.ChartPolicyWhite
import com.example.ui.theme.ChartQiborPink
import com.example.ui.theme.ChartScenarioBand
import com.example.ui.theme.ChartScenarioLine
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.util.Locale

@Composable
fun OvernightRateChart(
    historicalRates: List<HistoricalRatePoint>,
    selectedTimeframe: String,
    onSelectTimeframe: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var touchIndex by remember { mutableStateOf<Int?>(null) }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCardBackground)
            .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header: Title + Timeframe Selector + Model Scenario button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ShowChart,
                        contentDescription = "Chart",
                        tint = RhinoGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "OVERNIGHT RATE HISTORY",
                        color = IvoryWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "  |  ",
                        color = IvoryDim,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "تاريخ معدل ليلة واحدة",
                        color = IvoryMuted,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Timeframe selector buttons: 1M, 3M, 6M, 1Y
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF18202E))
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    listOf("1M", "3M", "6M", "1Y").forEach { tf ->
                        val isSelected = selectedTimeframe == tf
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isSelected) Color(0xFFD8A64E) else Color.Transparent)
                                .clickable { onSelectTimeframe(tf) }
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tf,
                                color = if (isSelected) Color(0xFF0C0F17) else IvoryMuted,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Chart Canvas with Touch Crosshair
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { offset ->
                                val count = historicalRates.size
                                if (count > 1) {
                                    val step = size.width / (count - 1)
                                    val idx = ((offset.x) / step).toInt().coerceIn(0, count - 1)
                                    touchIndex = idx
                                }
                            }
                        )
                    }
            ) {
                // Interactive Crosshair Tooltip
                touchIndex?.let { idx ->
                    if (idx in historicalRates.indices) {
                        val pt = historicalRates[idx]
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xE6141D2B))
                                .border(1.dp, RhinoGold.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${pt.dateDisplay}  •  QIBOR: ",
                                    color = IvoryWhite,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = String.format(Locale.US, "%.2f%%", pt.qiborRate),
                                    color = ChartQiborPink,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "  |  Interbank: ",
                                    color = IvoryWhite,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = String.format(Locale.US, "%.2f%%", pt.observedRate),
                                    color = ChartObservedGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "  |  Policy: ",
                                    color = IvoryWhite,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = String.format(Locale.US, "%.2f%%", pt.policyRate),
                                    color = ChartPolicyWhite,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // In-chart "Model scenario" badge at top right
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 2.dp, end = 10.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFF222B3B))
                        .border(1.dp, Color(0xFF3B485E), RoundedCornerShape(3.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Model scenario",
                        color = IvoryMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    val leftPadding = 52.dp.toPx()
                    val rightPadding = 12.dp.toPx()
                    val topPadding = 16.dp.toPx()
                    val bottomPadding = 24.dp.toPx()

                    val chartWidth = w - leftPadding - rightPadding
                    val chartHeight = h - topPadding - bottomPadding

                    val minRate = 3.90
                    val maxRate = 4.80

                    fun rateToY(rate: Double): Float {
                        val norm = (rate - minRate) / (maxRate - minRate)
                        return (topPadding + chartHeight * (1f - norm)).toFloat()
                    }

                    // Draw Horizontal Grid lines (3.90% to 4.80% in steps of 0.10%)
                    val gridSteps = listOf(3.90, 4.00, 4.10, 4.20, 4.30, 4.40, 4.50, 4.60, 4.70, 4.80)
                    for (step in gridSteps) {
                        val y = rateToY(step)
                        drawLine(
                            color = Color(0xFF1E2838),
                            start = Offset(leftPadding, y),
                            end = Offset(w - rightPadding, y),
                            strokeWidth = 1f
                        )
                    }

                    // Draw Points
                    val dataCount = historicalRates.size
                    if (dataCount > 1) {
                        val stepX = chartWidth / (dataCount - 1)

                        // 1. Shaded Model Scenario Confidence Band (from index dataCount - 3 to end)
                        val scenarioStartIndex = (dataCount - 3).coerceAtLeast(0)
                        val bandPath = Path()
                        val startX = leftPadding + scenarioStartIndex * stepX
                        bandPath.moveTo(startX, rateToY(historicalRates[scenarioStartIndex].modelScenarioUpper))

                        for (i in scenarioStartIndex until dataCount) {
                            val x = leftPadding + i * stepX
                            val y = rateToY(historicalRates[i].modelScenarioUpper)
                            bandPath.lineTo(x, y)
                        }
                        for (i in dataCount - 1 downTo scenarioStartIndex) {
                            val x = leftPadding + i * stepX
                            val y = rateToY(historicalRates[i].modelScenarioLower)
                            bandPath.lineTo(x, y)
                        }
                        bandPath.close()

                        drawPath(
                            path = bandPath,
                            color = ChartScenarioBand
                        )

                        // Vertical dashed divider line where scenario begins
                        drawLine(
                            color = Color(0xFF475569),
                            start = Offset(startX, topPadding),
                            end = Offset(startX, topPadding + chartHeight),
                            strokeWidth = 1.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
                        )

                        // 2. QCB Policy Rate Line (White)
                        val policyPath = Path()
                        for (i in 0 until dataCount) {
                            val x = leftPadding + i * stepX
                            val y = rateToY(historicalRates[i].policyRate)
                            if (i == 0) policyPath.moveTo(x, y) else policyPath.lineTo(x, y)
                        }
                        drawPath(
                            path = policyPath,
                            color = ChartPolicyWhite,
                            style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                        )

                        // 3. Observed Interbank Rate Line (Gold/Yellow)
                        val observedPath = Path()
                        for (i in 0 until dataCount) {
                            val x = leftPadding + i * stepX
                            val y = rateToY(historicalRates[i].observedRate)
                            if (i == 0) observedPath.moveTo(x, y) else observedPath.lineTo(x, y)
                        }
                        drawPath(
                            path = observedPath,
                            color = ChartObservedGold,
                            style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                        )

                        // 4. QIBOR Fixing Line (Pink/Rose)
                        val qiborPath = Path()
                        for (i in 0 until dataCount) {
                            val x = leftPadding + i * stepX
                            val y = rateToY(historicalRates[i].qiborRate)
                            if (i == 0) qiborPath.moveTo(x, y) else qiborPath.lineTo(x, y)
                        }
                        drawPath(
                            path = qiborPath,
                            color = ChartQiborPink,
                            style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                        )

                        // Touch index cursor indicator
                        touchIndex?.let { tIdx ->
                            val touchX = leftPadding + tIdx * stepX
                            drawLine(
                                color = RhinoGold,
                                start = Offset(touchX, topPadding),
                                end = Offset(touchX, topPadding + chartHeight),
                                strokeWidth = 1.5f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 3f), 0f)
                            )
                            drawCircle(
                                color = ChartQiborPink,
                                radius = 4f,
                                center = Offset(touchX, rateToY(historicalRates[tIdx].qiborRate))
                            )
                            drawCircle(
                                color = ChartObservedGold,
                                radius = 4f,
                                center = Offset(touchX, rateToY(historicalRates[tIdx].observedRate))
                            )
                        }
                    }
                }

                // Y-Axis Labels overlay
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 2.dp, top = 10.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("4.80%", "4.50%", "4.30%", "4.10%", "3.90%").forEach { lbl ->
                        Text(
                            text = lbl,
                            color = IvoryDim,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                    }
                }
            }

            // X-Axis Date markers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 54.dp, end = 12.dp, top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("15 Oct 2024", "12 Nov 2024", "10 Dec 2024", "07 Jan 2025", "15 Jan 2025", "22 Jan 2025").forEach { date ->
                    Text(
                        text = date,
                        color = IvoryDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Chart Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Pink Series
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(14.dp)
                            .height(3.dp)
                            .background(ChartQiborPink, RoundedCornerShape(1.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(text = "QIBOR (Offered Fixing)", color = IvoryWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(text = "سعر التثبيت المعروض", color = IvoryDim, fontSize = 8.sp)
                    }
                }

                // Yellow Series
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(14.dp)
                            .height(3.dp)
                            .background(ChartObservedGold, RoundedCornerShape(1.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(text = "Observed (Interbank)", color = IvoryWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(text = "المرصود (ما بين البنوك)", color = IvoryDim, fontSize = 8.sp)
                    }
                }

                // White Series
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(14.dp)
                            .height(3.dp)
                            .background(ChartPolicyWhite, RoundedCornerShape(1.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(text = "Policy (QCB Deposit)", color = IvoryWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(text = "سياسة المركزي (معدل الإيداع)", color = IvoryDim, fontSize = 8.sp)
                    }
                }

                // Model Scenario Band
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(ChartScenarioBand)
                            .border(1.dp, ChartScenarioLine, RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(text = "Model scenario (confidence range)", color = IvoryWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(text = "سيناريو النموذج (نطاق الثقة)", color = IvoryDim, fontSize = 8.sp)
                    }
                }
            }
        }
    }
}
