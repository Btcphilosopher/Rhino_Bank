package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AuditRecord
import com.example.ui.theme.DemoBadgeBg
import com.example.ui.theme.DemoBadgeBorder
import com.example.ui.theme.DemoBadgeText
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MovementGreen
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder

@Composable
fun ReportsAuditScreen(
    auditTrail: List<AuditRecord>,
    exportBannerMessage: String?,
    onExportReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val demoCujs = listOf(
        Pair("1. Importing Rate Observations", "Automated ingestion pipeline with checksum and provenance verification."),
        Pair("2. Identifying Stale Series", "Quality status flags (Published Today vs Effective vs Stale)."),
        Pair("3. Overnight vs Policy Rate Spreads", "Observed interbank (4.18%) vs QCB deposit floor (4.00%) = +18 bp spread."),
        Pair("4. Non-Business-Day Day Count", "Qatar weekend (Thu->Sun) 3 calendar days simple interest calculation ACT/360."),
        Pair("5. Next-Day Funding Gap Detection", "System net funding gap of -QAR 125.0m triggers treasury alert threshold."),
        Pair("6. Funding Options Comparison", "Unsecured Interbank (4.18%) vs Secured Repo (4.05%) vs QCB Standing (4.00%)."),
        Pair("7. Stress-Testing Shocks", "Deterministic parallel shifts (+25 bp, +50 bp) and 1,000-run Monte Carlo."),
        Pair("8. Exporting Entitled Treasury Report", "Signed institutional audit pack with cryptographic provenance.")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Export Action Header Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF141D2B))
                .border(1.dp, RhinoGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ENTITLED TREASURY REPORT PACK", color = IvoryWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(DemoBadgeBg)
                                .border(1.dp, DemoBadgeBorder, RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("DEMO DATA", color = DemoBadgeText, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("Daily QAR Money Market, Fixing Reconciliation, and Liquidity Risk Assessment", color = IvoryMuted, fontSize = 11.sp)
                }

                Button(
                    onClick = onExportReport,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RhinoGold,
                        contentColor = Color(0xFF0C0F17)
                    ),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = "Export", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export Report (CSV/PDF)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Confirmation toast banner if recently exported
        exportBannerMessage?.let { msg ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF132B1C))
                    .border(1.dp, MovementGreen, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = MovementGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(msg, color = IvoryWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Section: Demonstration Workflows (CUJ 1 to 8)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FactCheck, contentDescription = "CUJ", tint = RhinoGold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("INSTITUTIONAL DEMONSTRATION WORKFLOWS (13. SPECIFICATION)", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(10.dp))

                demoCujs.forEachIndexed { idx, (title, desc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Checked", tint = MovementGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(title, color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(desc, color = IvoryMuted, fontSize = 10.sp)
                        }
                    }
                    if (idx < demoCujs.size - 1) {
                        HorizontalDivider(color = Color(0xFF1E2838), thickness = 0.5.dp, modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }

        // Section: Immutable Audit Records
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = "Audit", tint = RhinoGold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("IMMUTABLE AUDIT TRAIL & MAKER-CHECKER LOG", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))

                auditTrail.forEachIndexed { idx, record ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(record.action, color = RhinoGoldBright, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(Color(0xFF1E2838))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("${record.role} • ${record.performedBy}", color = IvoryMuted, fontSize = 9.sp)
                                }
                            }
                            Text(record.timestamp, color = IvoryDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(record.details, color = IvoryMuted, fontSize = 10.sp)
                    }
                    if (idx < auditTrail.size - 1) {
                        HorizontalDivider(color = Color(0xFF1E2838), thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}
