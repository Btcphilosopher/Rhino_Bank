package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.QuantitativeEngine
import com.example.model.MonteCarloSummary
import com.example.model.ScenarioStressResult
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MovementGreen
import com.example.ui.theme.MovementRed
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.util.Locale

@Composable
fun RiskScenarioScreen(
    stressScenarios: List<ScenarioStressResult>,
    selectedScenarioIndex: Int,
    monteCarlo: MonteCarloSummary,
    onSelectScenario: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val activeScenario = stressScenarios.getOrElse(selectedScenarioIndex) { stressScenarios.first() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF141A28))
                .border(1.dp, RhinoGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shield, contentDescription = "Risk", tint = RhinoGold, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "TREASURY STRESS TESTING & RISK SIMULATION ENGINE",
                        color = IvoryWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "Deterministic parallel shifts, deposit shocks, and 1,000-run Monte Carlo stochastic funding paths.",
                        color = IvoryMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Section 1: Deterministic Scenarios Selector Cards
        Text("DETERMINISTIC MANAGEMENT SCENARIOS", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            stressScenarios.forEachIndexed { index, sc ->
                val isSelected = index == selectedScenarioIndex
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) Color(0xFF262014) else Color(0xFF141B26))
                        .border(
                            1.dp,
                            if (isSelected) RhinoGold else Color(0xFF222C3D),
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectScenario(index) }
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = sc.scenarioName,
                            color = if (isSelected) RhinoGoldBright else IvoryWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Shift: ${if (sc.rateShiftBp >= 0) "+${sc.rateShiftBp}" else "${sc.rateShiftBp}"} bp",
                            color = IvoryMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Outflow: ${sc.depositOutflowPercent}%",
                            color = IvoryDim,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        // Active Scenario Detailed Impact Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SCENARIO IMPACT RECONCILIATION: ${activeScenario.scenarioName.uppercase()}", color = RhinoGoldBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (activeScenario.isBufferBreached) "BUFFER BREACH WARNING" else "WITHIN PRUDENTIAL BUFFER",
                        color = if (activeScenario.isBufferBreached) MovementRed else MovementGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                HorizontalDivider(color = Color(0xFF263345), thickness = 1.dp, modifier = Modifier.padding(vertical = 10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    ImpactMetricItem("Daily Funding Cost", "QAR ${QuantitativeEngine.formatMoneyQar(activeScenario.totalFundingCostQar)}", "Cost Change: +QAR ${QuantitativeEngine.formatMoneyQar(activeScenario.costChangeQar)}")
                    ImpactMetricItem("Stressed Funding Gap", "QAR ${String.format(Locale.US, "%,.1f", activeScenario.liquidityGapQarMillions)}m", "Baseline: QAR 125.0m")
                    ImpactMetricItem("Buffer Utilisation", "${String.format(Locale.US, "%.1f", activeScenario.bufferUtilisationPercent)}%", "Internal Target: QAR 500m")
                }
            }
        }

        // Section 2: Monte Carlo Simulation Engine (1,000 iterations)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Casino, contentDescription = "Monte Carlo", tint = RhinoGold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("MONTE CARLO OVERNIGHT STOCHASTIC MODEL (1,000 RUNS)", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("SEED: 42 (REPRODUCIBLE)", color = IvoryDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }

                Text(
                    text = "Vasicek / Ornstein-Uhlenbeck mean-reverting process towards QCB policy rate (4.00%) with daily interbank volatility.",
                    color = IvoryDim,
                    fontSize = 10.sp
                )

                HorizontalDivider(color = Color(0xFF263345), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuantileBox("5th Percentile (Favorable)", "QAR ${QuantitativeEngine.formatMoneyQar(monteCarlo.p5thCostQar)}", MovementGreen)
                    QuantileBox("50th Percentile (Median)", "QAR ${QuantitativeEngine.formatMoneyQar(monteCarlo.p50thCostQar)}", RhinoGoldBright)
                    QuantileBox("95th Percentile (Tail Stress)", "QAR ${QuantitativeEngine.formatMoneyQar(monteCarlo.p95thCostQar)}", MovementRed)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Mean Funding Cost: QAR ${QuantitativeEngine.formatMoneyQar(monteCarlo.meanFundingCostQar)}", color = IvoryWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("Standard Error: ±QAR ${QuantitativeEngine.formatMoneyQar(monteCarlo.standardErrorQar)}", color = IvoryMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("Buffer Deficit Probability: ${String.format(Locale.US, "%.1f", monteCarlo.probabilityOfDeficit * 100)}%", color = if (monteCarlo.probabilityOfDeficit > 0.05) MovementRed else MovementGreen, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ImpactMetricItem(title: String, value: String, subtitle: String) {
    Column {
        Text(title, color = IvoryMuted, fontSize = 10.sp)
        Text(value, color = IvoryWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(subtitle, color = RhinoGold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun QuantileBox(label: String, value: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF161E2C))
            .border(1.dp, Color(0xFF28364A), RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(label, color = IvoryMuted, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
        }
    }
}
