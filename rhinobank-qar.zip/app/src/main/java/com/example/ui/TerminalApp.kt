package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.FundingComparisonDialog
import com.example.ui.components.HorizontalNavigationDock
import com.example.ui.components.RateProvenanceDialog
import com.example.ui.components.TerminalFooter
import com.example.ui.components.TerminalHeader
import com.example.ui.components.VerticalNavigationDock
import com.example.ui.screens.CurvesScreen
import com.example.ui.screens.FundingScreen
import com.example.ui.screens.LiquidityScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.RatesScreen
import com.example.ui.screens.ReportsAuditScreen
import com.example.ui.screens.RiskScenarioScreen
import com.example.ui.theme.TerminalDarkNavy
import com.example.ui.theme.TerminalObsidian

@Composable
fun TerminalApp(viewModel: TerminalViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val rates by viewModel.rates.collectAsStateWithLifecycle()
    val liquidityItems by viewModel.liquidityLadder.collectAsStateWithLifecycle()
    val alerts by viewModel.alerts.collectAsStateWithLifecycle()
    val auditTrail by viewModel.auditTrail.collectAsStateWithLifecycle()

    val layoutDirection = if (uiState.isArabicPrimary) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(TerminalObsidian)
        ) {
            val isWideScreen = maxWidth >= 760.dp

            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                containerColor = TerminalObsidian,
                topBar = {
                    TerminalHeader(
                        dohaTimeString = uiState.dohaTimeString,
                        dohaDateString = if (uiState.isArabicPrimary) uiState.dohaDateStringAr else uiState.dohaDateString,
                        isArabicPrimary = uiState.isArabicPrimary,
                        onToggleLanguage = { viewModel.toggleLanguage() }
                    )
                },
                bottomBar = {
                    Column {
                        if (!isWideScreen) {
                            HorizontalNavigationDock(
                                currentWorkspace = uiState.activeWorkspace,
                                onSelectWorkspace = { viewModel.selectWorkspace(it) },
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        TerminalFooter()
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isWideScreen) {
                        // Widescreen / Landscape layout: Main content on left, vertical navigation dock on right
                        Row(modifier = Modifier.fillMaxSize()) {
                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                ScreenContent(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    rates = rates,
                                    liquidityItems = liquidityItems,
                                    alerts = alerts,
                                    auditTrail = auditTrail
                                )
                            }
                            VerticalNavigationDock(
                                currentWorkspace = uiState.activeWorkspace,
                                onSelectWorkspace = { viewModel.selectWorkspace(it) },
                                modifier = Modifier.padding(top = 8.dp, end = 8.dp, bottom = 8.dp)
                            )
                        }
                    } else {
                        // Compact / Portrait layout
                        ScreenContent(
                            uiState = uiState,
                            viewModel = viewModel,
                            rates = rates,
                            liquidityItems = liquidityItems,
                            alerts = alerts,
                            auditTrail = auditTrail
                        )
                    }
                }
            }

            // Inspect Rate Provenance Dialog
            uiState.inspectedRate?.let { inspected ->
                RateProvenanceDialog(
                    rate = inspected,
                    onDismiss = { viewModel.inspectRate(null) },
                    onOverrideRate = { sId, newR, reason ->
                        viewModel.manualOverrideRate(sId, newR, reason)
                    }
                )
            }

            // Funding Options Comparison Dialog
            if (uiState.showFundingComparison) {
                FundingComparisonDialog(
                    principal = uiState.calcPrincipal,
                    days = uiState.calcDays,
                    convention = uiState.calcConvention,
                    onSelectFundingOption = { chosen ->
                        viewModel.selectFundingType(chosen)
                    },
                    onDismiss = { viewModel.openFundingComparison(false) }
                )
            }
        }
    }
}

@Composable
private fun ScreenContent(
    uiState: TerminalUiState,
    viewModel: TerminalViewModel,
    rates: List<com.example.model.RateObservation>,
    liquidityItems: List<com.example.model.LiquidityLadderItem>,
    alerts: List<com.example.model.TreasuryAlert>,
    auditTrail: List<com.example.model.AuditRecord>
) {
    when (uiState.activeWorkspace) {
        TerminalWorkspace.OVERVIEW -> {
            OverviewScreen(
                uiState = uiState,
                rateObservations = rates,
                liquidityItems = liquidityItems,
                alerts = alerts,
                onSelectTimeframe = { viewModel.selectTimeframe(it) },
                onInspectRate = { viewModel.inspectRate(it) },
                onSelectTenor = { _, rate -> viewModel.updateCalculator(ratePercent = rate) },
                onUpdatePrincipal = { viewModel.updateCalculator(principal = it) },
                onUpdateRate = { viewModel.updateCalculator(ratePercent = it) },
                onUpdateDays = { viewModel.updateCalculator(days = it) },
                onUpdateConvention = { viewModel.updateCalculator(convention = it) },
                onCompareFundingClick = { viewModel.openFundingComparison(true) },
                onSelectAlertFilter = { viewModel.setAlertFilter(it) }
            )
        }
        TerminalWorkspace.INTEREST_RATES -> {
            RatesScreen(
                rateObservations = rates,
                bankQuotes = viewModel.bankQuotes,
                onInspectRate = { viewModel.inspectRate(it) }
            )
        }
        TerminalWorkspace.LIQUIDITY -> {
            LiquidityScreen(
                items = liquidityItems
            )
        }
        TerminalWorkspace.FUNDING -> {
            FundingScreen(
                uiState = uiState,
                onUpdatePrincipal = { viewModel.updateCalculator(principal = it) },
                onUpdateRate = { viewModel.updateCalculator(ratePercent = it) },
                onUpdateDays = { viewModel.updateCalculator(days = it) },
                onUpdateConvention = { viewModel.updateCalculator(convention = it) },
                onToggleWeekendRoll = { viewModel.toggleWeekendDayRoll() },
                onCompareFundingClick = { viewModel.openFundingComparison(true) },
                onSelectFundingType = { viewModel.selectFundingType(it) }
            )
        }
        TerminalWorkspace.RISK -> {
            RiskScenarioScreen(
                stressScenarios = uiState.stressScenarios,
                selectedScenarioIndex = uiState.selectedStressScenarioIndex,
                monteCarlo = uiState.monteCarloSummary,
                onSelectScenario = { viewModel.selectStressScenario(it) }
            )
        }
        TerminalWorkspace.REPORTS -> {
            ReportsAuditScreen(
                auditTrail = auditTrail,
                exportBannerMessage = uiState.exportBannerMessage,
                onExportReport = { viewModel.exportEntitledReport() }
            )
        }
    }
}
