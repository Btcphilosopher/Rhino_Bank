package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LiquidityLadderItem
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MovementRed
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TableRowAlt
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.util.Locale

@Composable
fun LiquidityLadderTable(
    items: List<LiquidityLadderItem>,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCardBackground)
            .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = "Liquidity Ladder",
                    tint = RhinoGold,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "LIQUIDITY LADDER",
                    color = IvoryWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = "  |  ",
                    color = IvoryDim,
                    fontSize = 13.sp
                )
                Text(
                    text = "سلم السيولة",
                    color = IvoryMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Table Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF182232))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text(text = "Date", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(text = "التاريخ", color = IvoryDim, fontSize = 9.sp)
                }
                Column(modifier = Modifier.weight(1.1f), horizontalAlignment = Alignment.End) {
                    Text(text = "Inflows", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    Text(text = "التدفقات الداخلة", color = IvoryDim, fontSize = 9.sp, textAlign = TextAlign.End)
                }
                Column(modifier = Modifier.weight(1.1f), horizontalAlignment = Alignment.End) {
                    Text(text = "Outflows", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    Text(text = "التدفقات الخارجة", color = IvoryDim, fontSize = 9.sp, textAlign = TextAlign.End)
                }
                Column(modifier = Modifier.weight(1.2f), horizontalAlignment = Alignment.End) {
                    Text(text = "Net Funding", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    Text(text = "صافي التمويل", color = IvoryDim, fontSize = 9.sp, textAlign = TextAlign.End)
                }
            }

            HorizontalDivider(color = Color(0xFF25344A), thickness = 1.dp)

            // Table Data Rows
            items.forEachIndexed { index, item ->
                val isAlt = index % 2 == 1
                val isNegative = item.netFundingQarMillions < 0

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isAlt) TableRowAlt else Color.Transparent)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.dateDisplayEn,
                        color = IvoryWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1.3f)
                    )
                    Text(
                        text = "QAR ${String.format(Locale.US, "%,.1f", item.inflowsQarMillions)}m",
                        color = IvoryWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1.1f)
                    )
                    Text(
                        text = "QAR ${String.format(Locale.US, "%,.1f", item.outflowsQarMillions)}m",
                        color = IvoryWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1.1f)
                    )

                    val netFormatted = if (isNegative) {
                        "-QAR ${String.format(Locale.US, "%,.1f", kotlin.math.abs(item.netFundingQarMillions))}m"
                    } else {
                        "QAR ${String.format(Locale.US, "%,.1f", item.netFundingQarMillions)}m"
                    }

                    Text(
                        text = netFormatted,
                        color = if (isNegative) RhinoGoldBright else IvoryWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1.2f)
                    )
                }

                if (index < items.size - 1) {
                    HorizontalDivider(color = Color(0xFF1B2433), thickness = 0.5.dp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Footer note
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "ⓘ Amounts in QAR (millions) (المبالغ بالريال القطري (مليون ريال))",
                    color = IvoryDim,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Illustrative",
                    color = IvoryDim,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
