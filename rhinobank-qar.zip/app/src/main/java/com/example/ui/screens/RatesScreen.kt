package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RateCategory
import com.example.model.RateObservation
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MovementGreen
import com.example.ui.theme.MovementRed
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.util.Locale

@Composable
fun RatesScreen(
    rateObservations: List<RateObservation>,
    bankQuotes: List<Triple<String, Double, Double>>,
    onInspectRate: (RateObservation) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Benchmark Identity Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF131A26))
                .border(1.dp, RhinoGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Verified, contentDescription = "Verified", tint = RhinoGold, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "QAR BENCHMARK IDENTITY & PROVENANCE REGISTRY",
                        color = IvoryWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "Strict category separation enforced: Fixings • Policy • Interbank • Quotes • Model Estimates. Never substituted.",
                        color = IvoryMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Section 1: Published QIBOR Fixings (Official fixing panel)
        val qiborFixings = rateObservations.filter { it.category == RateCategory.PUBLISHED_QIBOR_FIXING }
        CategorySectionCard(
            titleEn = "PUBLISHED QIBOR FIXINGS",
            titleAr = "أسعار تثبيت QIBOR المنشورة",
            subtitle = "Official fixing panel publication at 10:00 QAT. Authorised provider metadata attached."
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF182232))
                    .padding(8.dp)
            ) {
                Text("Tenor", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("Rate (%)", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("Change (bp)", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("Status", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                Text("Action", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            }

            qiborFixings.forEachIndexed { idx, rate ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onInspectRate(rate) }
                        .padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(rate.tenor.code, color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${String.format(Locale.US, "%.2f", rate.ratePercent)}%", color = RhinoGoldBright, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(
                        text = if (rate.changeBp >= 0) "+${rate.changeBp} bp" else "${rate.changeBp} bp",
                        color = if (rate.changeBp >= 0) MovementGreen else MovementRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )
                    Text(rate.qualityStatus.labelEn, color = IvoryMuted, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                    Text("Inspect ⓘ", color = RhinoGold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                }
                if (idx < qiborFixings.size - 1) HorizontalDivider(color = Color(0xFF1E2838), thickness = 0.5.dp)
            }
        }

        // Section 2: QCB Policy Rates vs Interbank Average
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // QCB Policy Rates
            val policyRates = rateObservations.filter { it.category == RateCategory.QCB_POLICY_RATES }
            CategorySectionCard(
                titleEn = "QCB POLICY RATES",
                titleAr = "أسعار سياسة مصرف قطر المركزي",
                subtitle = "Monetary policy corridor (Deposit, Repo, Lending)",
                modifier = Modifier.weight(1f)
            ) {
                policyRates.forEachIndexed { idx, r ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onInspectRate(r) }
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(r.source, color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(r.seriesId, color = IvoryDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text("${String.format(Locale.US, "%.2f", r.ratePercent)}%", color = IvoryWhite, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    if (idx < policyRates.size - 1) HorizontalDivider(color = Color(0xFF1E2838), thickness = 0.5.dp)
                }
            }

            // RhinoQuant Model Estimate
            val estimate = rateObservations.find { it.category == RateCategory.RHINOQUANT_ESTIMATE }
            CategorySectionCard(
                titleEn = "RHINOQUANT MODEL ESTIMATE",
                titleAr = "تقدير نموذج راينو كوانت",
                subtitle = "Derived econometric estimate with explicit uncertainty",
                modifier = Modifier.weight(1f)
            ) {
                estimate?.let { est ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onInspectRate(est) }
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("RhinoQuant O/N Estimate", color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("${String.format(Locale.US, "%.2f", est.ratePercent)}%", color = RhinoGoldBright, fontSize = 18.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Uncertainty Band:", color = IvoryMuted, fontSize = 10.sp)
                            Text("±${est.uncertaintyBp} bp (${String.format(Locale.US, "%.2f", est.ratePercent - 0.04)}% - ${String.format(Locale.US, "%.2f", est.ratePercent + 0.04)}%)", color = RhinoGold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Method: ${est.methodologyNote}",
                            color = IvoryDim,
                            fontSize = 10.sp,
                            lineHeight = 13.sp
                        )
                    }
                }
            }
        }

        // Section 3: Individual Bank Quotes (Contributor quotes)
        CategorySectionCard(
            titleEn = "INDIVIDUAL CONTRIBUTING BANK QUOTES",
            titleAr = "تسعير البنوك المساهمة في السوق",
            subtitle = "Indicative contributor quotes submitted prior to daily fixing window"
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF182232))
                    .padding(8.dp)
            ) {
                Text("Bank Name", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                Text("Bid Quote (%)", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                Text("Offer Quote (%)", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                Text("Spread (bp)", color = IvoryMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
            }

            bankQuotes.forEachIndexed { idx, (name, bid, offer) ->
                val spreadBp = ((offer - bid) * 100).toInt()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(name, color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(2f))
                    Text("${String.format(Locale.US, "%.2f", bid)}%", color = IvoryWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                    Text("${String.format(Locale.US, "%.2f", offer)}%", color = RhinoGoldBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                    Text("$spreadBp bp", color = IvoryDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                }
                if (idx < bankQuotes.size - 1) HorizontalDivider(color = Color(0xFF1E2838), thickness = 0.5.dp)
            }
        }
    }
}

@Composable
private fun CategorySectionCard(
    titleEn: String,
    titleAr: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCardBackground)
            .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = titleEn, color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = titleAr, color = IvoryMuted, fontSize = 11.sp)
            }
            Text(text = subtitle, color = IvoryDim, fontSize = 9.sp)
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}
