package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.QuantitativeEngine
import com.example.model.DayCountConvention
import com.example.model.FundingCalculationResult
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.math.BigDecimal
import java.util.Locale

@Composable
fun FundingCalculatorPanel(
    principal: BigDecimal,
    annualRatePercent: Double,
    days: Int,
    convention: DayCountConvention,
    calcResult: FundingCalculationResult,
    onUpdatePrincipal: (BigDecimal) -> Unit,
    onUpdateRate: (Double) -> Unit,
    onUpdateDays: (Int) -> Unit,
    onUpdateConvention: (DayCountConvention) -> Unit,
    onCompareFundingClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCardBackground)
            .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Calculate,
                    contentDescription = "Funding Calculator",
                    tint = RhinoGold,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "FUNDING CALCULATOR",
                    color = IvoryWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = "  |  ",
                    color = IvoryDim,
                    fontSize = 13.sp
                )
                Text(
                    text = "حاسبة التمويل",
                    color = IvoryMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Body: Two columns (Inputs on left, Result & Compare on right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Left Column: Inputs
                Column(
                    modifier = Modifier.weight(1.2f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Principal
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Principal", color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "مبلغ التمويل", color = IvoryDim, fontSize = 9.sp)
                        }

                        // Principal Value Pill with Steppers
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF182232))
                                .border(1.dp, Color(0xFF28364C), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "QAR ${QuantitativeEngine.formatMoneyQar(principal).substringBefore(".")}",
                                color = IvoryWhite,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            // +/- Quick Adjust
                            Text(
                                text = "▲",
                                color = RhinoGold,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .clickable { onUpdatePrincipal(principal.add(BigDecimal("10000000"))) }
                                    .padding(horizontal = 2.dp)
                            )
                            Text(
                                text = "▼",
                                color = IvoryDim,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .clickable {
                                        if (principal > BigDecimal("10000000")) {
                                            onUpdatePrincipal(principal.subtract(BigDecimal("10000000")))
                                        }
                                    }
                                    .padding(horizontal = 2.dp)
                            )
                        }
                    }

                    // Annual Rate
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Annual Rate", color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "معدل سنوي", color = IvoryDim, fontSize = 9.sp)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF182232))
                                .border(1.dp, Color(0xFF28364C), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "${String.format(Locale.US, "%.2f", annualRatePercent)}%",
                                color = IvoryWhite,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "▲",
                                color = RhinoGold,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .clickable { onUpdateRate(annualRatePercent + 0.05) }
                                    .padding(horizontal = 2.dp)
                            )
                            Text(
                                text = "▼",
                                color = IvoryDim,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .clickable {
                                        if (annualRatePercent > 0.10) {
                                            onUpdateRate(annualRatePercent - 0.05)
                                        }
                                    }
                                    .padding(horizontal = 2.dp)
                            )
                        }
                    }

                    // Days
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Days", color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "عدد الأيام", color = IvoryDim, fontSize = 9.sp)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF182232))
                                .border(1.dp, Color(0xFF28364C), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "$days ${if (days == 3) "(Weekend)" else ""}",
                                color = if (days == 3) RhinoGoldBright else IvoryWhite,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "▲",
                                color = RhinoGold,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .clickable { onUpdateDays(days + 1) }
                                    .padding(horizontal = 2.dp)
                            )
                            Text(
                                text = "▼",
                                color = IvoryDim,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .clickable { if (days > 1) onUpdateDays(days - 1) }
                                    .padding(horizontal = 2.dp)
                            )
                        }
                    }

                    // Day Count Basis
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Day Count", color = IvoryWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "أساس احتساب الأيام", color = IvoryDim, fontSize = 9.sp)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF182232))
                                .border(1.dp, Color(0xFF28364C), RoundedCornerShape(4.dp))
                                .clickable {
                                    val nextConv = when (convention) {
                                        DayCountConvention.ACT_360 -> DayCountConvention.ACT_365
                                        DayCountConvention.ACT_365 -> DayCountConvention.THIRTY_360
                                        DayCountConvention.THIRTY_360 -> DayCountConvention.ACT_360
                                    }
                                    onUpdateConvention(nextConv)
                                }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "${convention.code} ⌄",
                                color = RhinoGoldBright,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Right Column: Result Box & Action Button
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Interest (Accrued) | الفائدة (المستحقة)",
                        color = IvoryMuted,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Prominent Highlight Result Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF161F2E))
                            .border(1.dp, RhinoGold.copy(alpha = 0.8f), RoundedCornerShape(6.dp))
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "QAR ${QuantitativeEngine.formatMoneyQar(calcResult.interestAmount)}",
                            color = RhinoGoldBright,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Transparent Formula string
                    Text(
                        text = calcResult.formulaDisplay,
                        color = IvoryDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Compare funding button
                    Button(
                        onClick = onCompareFundingClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RhinoGold,
                            contentColor = Color(0xFF0C0F17)
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "Compare",
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Compare funding",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "مقارنة خيارات التمويل",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
