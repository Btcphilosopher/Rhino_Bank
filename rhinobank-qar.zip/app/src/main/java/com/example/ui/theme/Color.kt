package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RhinoBank Institutional Terminal Color Palette
val TerminalObsidian = Color(0xFF0C0F17)
val TerminalDarkNavy = Color(0xFF0A0D14)
val TerminalCardBackground = Color(0xFF131926)
val TerminalCardSurface = Color(0xFF172030)
val TerminalCardBorder = Color(0xFF232E42)
val TerminalCardBorderGold = Color(0xFF5E4822)

// RhinoBank Gold
val RhinoGold = Color(0xFFD8A64E)
val RhinoGoldBright = Color(0xFFF3C268)
val RhinoGoldDim = Color(0xFF8C6D34)
val RhinoGoldContainer = Color(0xFF262015)

// Typography
val IvoryWhite = Color(0xFFF6F7F9)
val IvoryMuted = Color(0xFF94A3B8)
val IvoryDim = Color(0xFF64748B)

// Status / Movements
val MovementGreen = Color(0xFF22C55E)
val MovementGreenBg = Color(0xFF132F20)
val MovementRed = Color(0xFFEF4444)
val MovementRedBg = Color(0xFF381418)
val DemoBadgeBg = Color(0xFF2D1015)
val DemoBadgeBorder = Color(0xFF8F232B)
val DemoBadgeText = Color(0xFFF87171)

// Chart Series
val ChartQiborPink = Color(0xFFEC4899)
val ChartObservedGold = Color(0xFFFBBF24)
val ChartPolicyWhite = Color(0xFFFFFFFF)
val ChartScenarioBand = Color(0x33EC4899)
val ChartScenarioLine = Color(0xFFF472B6)

// Table / Dividers
val TableDivider = Color(0xFF1E2838)
val TableRowAlt = Color(0xFF101622)
