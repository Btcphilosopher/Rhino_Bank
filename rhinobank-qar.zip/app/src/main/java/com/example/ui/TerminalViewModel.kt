package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.InitialDemoData
import com.example.data.QatarBankingCalendar
import com.example.data.QuantitativeEngine
import com.example.data.TerminalDatabase
import com.example.data.TerminalRepository
import com.example.model.DayCountConvention
import com.example.model.FundingCalculationResult
import com.example.model.FundingType
import com.example.model.HistoricalRatePoint
import com.example.model.LiquidityLadderItem
import com.example.model.MonteCarloSummary
import com.example.model.RateObservation
import com.example.model.ScenarioStressResult
import com.example.model.Tenor
import com.example.model.TreasuryAlert
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class TerminalWorkspace(val titleEn: String, val titleAr: String) {
    OVERVIEW("Overview", "نظرة عامة"),
    INTEREST_RATES("Interest Rates", "أسعار الفائدة"),
    LIQUIDITY("Liquidity", "السيولة"),
    FUNDING("Funding", "التمويل"),
    RISK("Risk", "المخاطر"),
    REPORTS("Reports", "التقارير")
}

data class TerminalUiState(
    val activeWorkspace: TerminalWorkspace = TerminalWorkspace.OVERVIEW,
    val selectedTimeframe: String = "3M", // 1M, 3M, 6M, 1Y
    val dohaTimeString: String = "10:24:36",
    val dohaDateString: String = "Wed, 15 Jan 2025",
    val dohaDateStringAr: String = "الأربعاء، 15 يناير 2025",
    val isArabicPrimary: Boolean = false,
    
    // Calculator State
    val calcPrincipal: BigDecimal = BigDecimal("50000000"),
    val calcAnnualRatePercent: Double = 4.25,
    val calcDays: Int = 1,
    val calcConvention: DayCountConvention = DayCountConvention.ACT_360,
    val calcResult: FundingCalculationResult = QuantitativeEngine.calculateSimpleInterest(
        BigDecimal("50000000"), 4.25, 1, DayCountConvention.ACT_360
    ),
    
    // Comparison Funding Options
    val showFundingComparison: Boolean = false,
    val selectedFundingType: FundingType = FundingType.UNSECURED_INTERBANK,
    
    // Inspection Dialog State
    val inspectedRate: RateObservation? = null,
    
    // Alerts Filter
    val alertCategoryFilter: String = "Policy scenarios",
    
    // Stress Test Scenarios
    val selectedStressScenarioIndex: Int = 0,
    val stressScenarios: List<ScenarioStressResult> = listOf(
        QuantitativeEngine.evaluateScenario(50_000_000.0, 4.25, 0, 0.0, 0, "Baseline (Hold at 4.00%)"),
        QuantitativeEngine.evaluateScenario(50_000_000.0, 4.25, 25, 2.0, 1, "QCB +25 bp & Mild Outflow"),
        QuantitativeEngine.evaluateScenario(50_000_000.0, 4.25, 50, 5.0, 2, "QCB +50 bp & Liquidity Stress"),
        QuantitativeEngine.evaluateScenario(50_000_000.0, 4.25, -25, 0.0, 0, "QCB -25 bp Easing")
    ),
    val monteCarloSummary: MonteCarloSummary = QuantitativeEngine.runMonteCarloSimulation(
        currentRatePercent = 4.25,
        policyRatePercent = 4.00,
        principalQar = 50_000_000.0
    ),

    // Export confirmation banner
    val exportBannerMessage: String? = null
)

class TerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TerminalRepository(TerminalDatabase.getInstance(application))

    private val _uiState = MutableStateFlow(TerminalUiState())
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    val rates: StateFlow<List<RateObservation>> = repository.getRates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), InitialDemoData.rateObservations)

    val liquidityLadder: StateFlow<List<LiquidityLadderItem>> = repository.getLiquidityLadder()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), InitialDemoData.liquidityItems)

    val alerts: StateFlow<List<TreasuryAlert>> = repository.getAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), InitialDemoData.treasuryAlerts)

    val auditTrail = repository.getAuditTrail()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), InitialDemoData.auditRecords)

    val historicalRatePoints: List<HistoricalRatePoint> = InitialDemoData.historicalRates
    val bankQuotes = InitialDemoData.bankQuotes

    init {
        // Start Doha live clock ticker (Asia/Qatar time is UTC+3)
        viewModelScope.launch {
            val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.US)
            while (true) {
                // In demo mode we display the active trading day 15 Jan 2025 with live seconds ticking
                val now = LocalTime.now()
                _uiState.value = _uiState.value.copy(
                    dohaTimeString = now.format(timeFormatter)
                )
                delay(1000)
            }
        }
    }

    fun selectWorkspace(workspace: TerminalWorkspace) {
        _uiState.value = _uiState.value.copy(activeWorkspace = workspace)
    }

    fun selectTimeframe(tf: String) {
        _uiState.value = _uiState.value.copy(selectedTimeframe = tf)
    }

    fun toggleLanguage() {
        _uiState.value = _uiState.value.copy(isArabicPrimary = !_uiState.value.isArabicPrimary)
    }

    fun updateCalculator(
        principal: BigDecimal? = null,
        ratePercent: Double? = null,
        days: Int? = null,
        convention: DayCountConvention? = null
    ) {
        val p = principal ?: _uiState.value.calcPrincipal
        val r = ratePercent ?: _uiState.value.calcAnnualRatePercent
        val d = days ?: _uiState.value.calcDays
        val c = convention ?: _uiState.value.calcConvention

        val result = QuantitativeEngine.calculateSimpleInterest(p, r, d, c)
        _uiState.value = _uiState.value.copy(
            calcPrincipal = p,
            calcAnnualRatePercent = r,
            calcDays = d,
            calcConvention = c,
            calcResult = result
        )
    }

    fun toggleWeekendDayRoll() {
        // In Qatar banking, Thu-Sun rolls over Fri & Sat (3 calendar days)
        val newDays = if (_uiState.value.calcDays == 1) 3 else 1
        updateCalculator(days = newDays)
    }

    fun openFundingComparison(open: Boolean) {
        _uiState.value = _uiState.value.copy(showFundingComparison = open)
    }

    fun selectFundingType(type: FundingType) {
        val rate = when (type) {
            FundingType.UNSECURED_INTERBANK -> 4.18
            FundingType.SECURED_REPO -> 4.05
            FundingType.QCB_DEPOSIT_FACILITY -> 4.00
            FundingType.COMMERCIAL_DEPOSIT -> 4.30
        }
        _uiState.value = _uiState.value.copy(selectedFundingType = type)
        updateCalculator(ratePercent = rate)
    }

    fun inspectRate(rate: RateObservation?) {
        _uiState.value = _uiState.value.copy(inspectedRate = rate)
    }

    fun setAlertFilter(category: String) {
        _uiState.value = _uiState.value.copy(alertCategoryFilter = category)
    }

    fun selectStressScenario(index: Int) {
        _uiState.value = _uiState.value.copy(selectedStressScenarioIndex = index)
    }

    fun exportEntitledReport() {
        viewModelScope.launch {
            repository.addAuditRecord(
                action = "EXPORT_ENTITLED_REPORT",
                performedBy = "Desk Treasurer",
                role = "Treasury Dealer",
                details = "Generated signed QAR Money Market & Liquidity Daily Pack (PDF/CSV) with DEMO DATA stamp."
            )
            _uiState.value = _uiState.value.copy(
                exportBannerMessage = "Treasury Report Exported: RhinoBank_QAR_Daily_20250115.csv [Entitlement: Institutional]"
            )
            delay(4000)
            _uiState.value = _uiState.value.copy(exportBannerMessage = null)
        }
    }

    fun manualOverrideRate(seriesId: String, newRate: Double, reason: String) {
        viewModelScope.launch {
            val current = rates.value.find { it.seriesId == seriesId } ?: return@launch
            val updated = current.copy(
                ratePercent = newRate,
                qualityStatus = com.example.model.QualityStatus.ESTIMATED,
                revisionId = "REV-MANUAL"
            )
            repository.updateRateObservation(updated, "Risk Manager", reason)
            inspectRate(null)
        }
    }
}
