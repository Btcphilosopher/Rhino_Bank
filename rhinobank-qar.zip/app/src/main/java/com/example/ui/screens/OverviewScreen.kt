package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.LiquidityLadderItem
import com.example.model.RateObservation
import com.example.model.Tenor
import com.example.model.TreasuryAlert
import com.example.ui.TerminalUiState
import com.example.ui.components.FundingCalculatorPanel
import com.example.ui.components.LiquidityLadderTable
import com.example.ui.components.MetricCard
import com.example.ui.components.OvernightRateChart
import com.example.ui.components.PillType
import com.example.ui.components.TenorSnapshotTable
import com.example.ui.components.TreasuryAlertsPanel
import java.util.Locale

@Composable
fun OverviewScreen(
    uiState: TerminalUiState,
    rateObservations: List<RateObservation>,
    liquidityItems: List<LiquidityLadderItem>,
    alerts: List<TreasuryAlert>,
    onSelectTimeframe: (String) -> Unit,
    onInspectRate: (RateObservation) -> Unit,
    onSelectTenor: (Tenor, Double) -> Unit,
    onUpdatePrincipal: (java.math.BigDecimal) -> Unit,
    onUpdateRate: (Double) -> Unit,
    onUpdateDays: (Int) -> Unit,
    onUpdateConvention: (com.example.model.DayCountConvention) -> Unit,
    onCompareFundingClick: () -> Unit,
    onSelectAlertFilter: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val qiborOn = rateObservations.find { it.seriesId == "QAR-QIBOR-ON-FIXING" }
    val interbankOn = rateObservations.find { it.seriesId == "QAR-INTERBANK-ON-OBSERVED" }
    val qcbDeposit = rateObservations.find { it.seriesId == "QAR-QCB-DEPOSIT-POLICY" }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // TOP SECTION: 4 KEY METRIC CARDS (Exact match to screenshot)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Card 1: Overnight QIBOR
            MetricCard(
                icon = Icons.Default.MonetizationOn,
                titleEn = "Overnight QIBOR",
                titleAr = "معدل QIBOR لليلة واحدة",
                subtitleEn = "QIBOR Fixing (Offered Rate)",
                subtitleAr = "سعر التثبيت المعروض",
                value = "${String.format(Locale.US, "%.2f", qiborOn?.ratePercent ?: 4.25)}%",
                pillText = "▲ +${qiborOn?.changeBp ?: 2} bp",
                pillType = PillType.GREEN_BP,
                sourceText = "Source: QIBOR (Offered Fixing)  |  Illustrative",
                onClick = { qiborOn?.let { onInspectRate(it) } },
                modifier = Modifier.weight(1f)
            )

            // Card 2: Observed Interbank
            MetricCard(
                icon = Icons.Default.Handshake,
                titleEn = "Observed Interbank",
                titleAr = "معدل ما بين البنوك",
                subtitleEn = "Unsecured Interbank Rate",
                subtitleAr = "المعدل المرصود بين البنوك",
                value = "${String.format(Locale.US, "%.2f", interbankOn?.ratePercent ?: 4.18)}%",
                pillText = "▼ ${interbankOn?.changeBp ?: -1} bp",
                pillType = PillType.RED_BP,
                sourceText = "Source: Interbank (Observed)  |  Illustrative",
                onClick = { interbankOn?.let { onInspectRate(it) } },
                modifier = Modifier.weight(1f)
            )

            // Card 3: QCB Deposit
            MetricCard(
                icon = Icons.Default.AccountBalance,
                titleEn = "QCB Deposit",
                titleAr = "معدل الإيداع لدى",
                subtitleEn = "Qatar Central Bank Deposit Rate",
                subtitleAr = "المركزي القطري",
                value = "${String.format(Locale.US, "%.2f", qcbDeposit?.ratePercent ?: 4.00)}%",
                pillText = "Demo policy series",
                pillType = PillType.NEUTRAL_BADGE,
                sourceText = "Source: QCB (Policy Rate)  |  Illustrative",
                onClick = { qcbDeposit?.let { onInspectRate(it) } },
                modifier = Modifier.weight(1f)
            )

            // Card 4: Funding Gap
            MetricCard(
                icon = Icons.Default.TrendingUp,
                titleEn = "Funding Gap",
                titleAr = "فجوة التمويل",
                subtitleEn = "System Funding Gap (Net)",
                subtitleAr = "صافي فجوة التمويل",
                value = "QAR 125.0m",
                pillText = "Next business day",
                pillType = PillType.NEUTRAL_BADGE,
                sourceText = "Source: Treasury Model  |  Illustrative",
                onClick = { /* inspect funding gap model */ },
                modifier = Modifier.weight(1f)
            )
        }

        // MIDDLE SECTION: CHART (62%) + TENOR SNAPSHOT (38%)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OvernightRateChart(
                historicalRates = com.example.data.InitialDemoData.historicalRates,
                selectedTimeframe = uiState.selectedTimeframe,
                onSelectTimeframe = onSelectTimeframe,
                modifier = Modifier.weight(1.65f)
            )

            TenorSnapshotTable(
                rateObservations = rateObservations,
                onSelectTenor = onSelectTenor,
                modifier = Modifier.weight(1.05f)
            )
        }

        // BOTTOM SECTION: 3 PANELS
        // Liquidity Ladder (33%) + Funding Calculator (37%) + Treasury Alerts (30%)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LiquidityLadderTable(
                items = liquidityItems,
                modifier = Modifier.weight(1.05f)
            )

            FundingCalculatorPanel(
                principal = uiState.calcPrincipal,
                annualRatePercent = uiState.calcAnnualRatePercent,
                days = uiState.calcDays,
                convention = uiState.calcConvention,
                calcResult = uiState.calcResult,
                onUpdatePrincipal = onUpdatePrincipal,
                onUpdateRate = onUpdateRate,
                onUpdateDays = onUpdateDays,
                onUpdateConvention = onUpdateConvention,
                onCompareFundingClick = onCompareFundingClick,
                modifier = Modifier.weight(1.25f)
            )

            TreasuryAlertsPanel(
                alerts = alerts,
                activeFilter = uiState.alertCategoryFilter,
                onSelectFilter = onSelectAlertFilter,
                modifier = Modifier.weight(1.0f)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))
    }
}
