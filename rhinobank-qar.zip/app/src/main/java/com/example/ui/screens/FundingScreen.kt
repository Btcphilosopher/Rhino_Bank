package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.QatarBankingCalendar
import com.example.data.QuantitativeEngine
import com.example.model.DayCountConvention
import com.example.model.FundingType
import com.example.ui.TerminalUiState
import com.example.ui.components.FundingCalculatorPanel
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MovementGreen
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.math.BigDecimal
import java.time.LocalDate
import java.util.Locale

@Composable
fun FundingScreen(
    uiState: TerminalUiState,
    onUpdatePrincipal: (BigDecimal) -> Unit,
    onUpdateRate: (Double) -> Unit,
    onUpdateDays: (Int) -> Unit,
    onUpdateConvention: (DayCountConvention) -> Unit,
    onToggleWeekendRoll: () -> Unit,
    onCompareFundingClick: () -> Unit,
    onSelectFundingType: (FundingType) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var settlementDate by remember { mutableStateOf(LocalDate.of(2025, 1, 15)) }
    val maturityDate = settlementDate.plusDays(uiState.calcDays.toLong())

    var simulatedBrokerageFeeQar by remember { mutableStateOf(BigDecimal("150.00")) }
    val netMaturityProceeds = uiState.calcResult.maturityProceeds.subtract(simulatedBrokerageFeeQar)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Banner: Qatar Banking Calendar Roll Notice
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF141D2B))
                .border(1.dp, RhinoGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = "Calendar", tint = RhinoGold, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "QATAR BANKING CALENDAR INTEGRATION (WEEKEND: FRI & SAT)",
                            color = IvoryWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (uiState.calcDays == 1) "Standard 1-Day Midweek Overnight (Settlement: ${settlementDate} → Maturity: ${settlementDate.plusDays(1)})"
                            else "Weekend 3-Day Rollover Active (Settlement: Thu → Maturity: Sun, 3 Days ACT/360 Interest)",
                            color = IvoryMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Button(
                    onClick = onToggleWeekendRoll,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.calcDays == 3) RhinoGold else Color(0xFF222D3E),
                        contentColor = if (uiState.calcDays == 3) Color(0xFF0C0F17) else IvoryWhite
                    ),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = if (uiState.calcDays == 3) "Revert to 1-Day" else "Simulate Thu-Sun Roll (3d)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Main Funding Calculator Panel
        FundingCalculatorPanel(
            principal = uiState.calcPrincipal,
            annualRatePercent = uiState.calcAnnualRatePercent,
            days = uiState.calcDays,
            convention = uiState.calcConvention,
            calcResult = uiState.calcResult,
            onUpdatePrincipal = onUpdatePrincipal,
            onUpdateRate = onUpdateRate,
            onUpdateDays = onUpdateDays,
            onUpdateConvention = onUpdateConvention,
            onCompareFundingClick = onCompareFundingClick,
            modifier = Modifier.fillMaxWidth()
        )

        // Deal Ticket Breakdown & Transparency
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.dp, TerminalCardBorder), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Receipt, contentDescription = "Ticket", tint = RhinoGold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SIMULATED TREASURY DEAL TICKET", color = IvoryWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("STATUS: PRE-TRADE ANALYTIC", color = MovementGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                HorizontalDivider(color = Color(0xFF263345), thickness = 1.dp, modifier = Modifier.padding(vertical = 10.dp))

                TicketDetailRow("Instrument / Product", uiState.selectedFundingType.labelEn, uiState.selectedFundingType.labelAr)
                TicketDetailRow("Principal Amount", "QAR ${QuantitativeEngine.formatMoneyQar(uiState.calcPrincipal)}", "مبلغ رأس المال")
                TicketDetailRow("Agreed Annual Rate", "${String.format(Locale.US, "%.2f", uiState.calcAnnualRatePercent)}%", "معدل العائد السنوي")
                TicketDetailRow("Day-Count Convention", "${uiState.calcConvention.code} (${uiState.calcConvention.basisDays} days)", uiState.calcConvention.labelAr)
                TicketDetailRow("Settlement Date", "15 Jan 2025 (10:00 QAT)", "تاريخ التسوية")
                TicketDetailRow("Maturity Date", "${if (uiState.calcDays == 1) "16 Jan 2025" else "19 Jan 2025"} (10:00 QAT)", "تاريخ الاستحقاق")
                TicketDetailRow("Tenor Duration", "${uiState.calcDays} Calendar Day(s)", "مدة الأجل")
                TicketDetailRow("Gross Accrued Interest", "QAR ${QuantitativeEngine.formatMoneyQar(uiState.calcResult.interestAmount)}", "الفائدة الإجمالية")
                TicketDetailRow("Clearing / Brokerage Fees", "QAR ${QuantitativeEngine.formatMoneyQar(simulatedBrokerageFeeQar)}", "رسوم الوساطة والمقاصة")
                TicketDetailRow("Net Maturity Proceeds", "QAR ${QuantitativeEngine.formatMoneyQar(netMaturityProceeds)}", "صافي متحصلات الاستحقاق")

                Spacer(modifier = Modifier.height(12.dp))

                // Formula trace
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF161E2B))
                        .padding(10.dp)
                ) {
                    Column {
                        Text("TRANSPARENT CALCULATION AUDIT TRACE", color = RhinoGoldBright, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Interest = Principal × Rate% × (Days / Basis)\n" +
                                    "Interest = ${QuantitativeEngine.formatMoneyQar(uiState.calcPrincipal)} × ${uiState.calcAnnualRatePercent}% × (${uiState.calcDays} / ${uiState.calcConvention.basisDays}) = QAR ${QuantitativeEngine.formatMoneyQar(uiState.calcResult.interestAmount)}\n" +
                                    "Net Proceeds = Principal + Interest - Fees = QAR ${QuantitativeEngine.formatMoneyQar(netMaturityProceeds)}",
                            color = IvoryMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TicketDetailRow(label: String, value: String, labelAr: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(label, color = IvoryMuted, fontSize = 11.sp)
            Text(labelAr, color = IvoryDim, fontSize = 9.sp)
        }
        Text(
            value,
            color = IvoryWhite,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
