package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.QuantitativeEngine
import com.example.model.DayCountConvention
import com.example.model.FundingType
import com.example.model.RateObservation
import com.example.ui.theme.IvoryDim
import com.example.ui.theme.IvoryMuted
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MovementGreen
import com.example.ui.theme.RhinoGold
import com.example.ui.theme.RhinoGoldBright
import com.example.ui.theme.TerminalCardBackground
import com.example.ui.theme.TerminalCardBorder
import java.math.BigDecimal
import java.util.Locale

@Composable
fun RateProvenanceDialog(
    rate: RateObservation,
    onDismiss: () -> Unit,
    onOverrideRate: (seriesId: String, newRate: Double, reason: String) -> Unit
) {
    var isEditing by remember { mutableStateOf(false) }
    var editRateText by remember { mutableStateOf(rate.ratePercent.toString()) }
    var reasonText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(10.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.5.dp, RhinoGold.copy(alpha = 0.8f)), RoundedCornerShape(10.dp))
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Dialog Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Provenance",
                            tint = RhinoGold,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Column {
                            Text(
                                text = "RATE PROVENANCE & AUDIT",
                                color = IvoryWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "مصدر وسجل تدقيق سعر الفائدة",
                                color = IvoryMuted,
                                fontSize = 12.sp
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = IvoryMuted
                        )
                    }
                }

                HorizontalDivider(color = Color(0xFF263345), thickness = 1.dp, modifier = Modifier.padding(vertical = 10.dp))

                // Provenance metadata grid
                ProvenanceRow("Series Identifier", rate.seriesId)
                ProvenanceRow("Rate Category", "${rate.category.displayNameEn} (${rate.category.displayNameAr})")
                ProvenanceRow("Tenor & Currency", "${rate.tenor.code} • ${rate.currency}")
                ProvenanceRow("Current Value", "${String.format(Locale.US, "%.2f", rate.ratePercent)}% (${if (rate.changeBp >= 0) "+${rate.changeBp}" else "${rate.changeBp}"} bp)")
                ProvenanceRow("Observation Date", rate.observationDate)
                ProvenanceRow("Publication Timestamp", "${rate.publicationTimestampUtc} UTC  |  ${rate.publicationTimestampLocal}")
                ProvenanceRow("Effective Date", rate.effectiveDate)
                ProvenanceRow("Source", rate.source)
                ProvenanceRow("Revision ID", rate.revisionId)
                ProvenanceRow("Quality Status", "${rate.qualityStatus.labelEn} (${rate.qualityStatus.labelAr})")
                ProvenanceRow("Entitlement Status", rate.entitlement.labelEn)

                if (rate.uncertaintyBp > 0) {
                    ProvenanceRow("Uncertainty Band", "±${rate.uncertaintyBp} bp")
                }
                if (rate.methodologyNote.isNotEmpty()) {
                    ProvenanceRow("Methodology Note", rate.methodologyNote)
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Maker-Checker Manual Override Section
                if (!isEditing) {
                    Button(
                        onClick = { isEditing = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1E2838),
                            contentColor = RhinoGoldBright
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Propose Manual Rate Override (Maker-Checker)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF161E2C))
                            .padding(10.dp)
                    ) {
                        Text("Desk Override Proposal", color = RhinoGoldBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = editRateText,
                            onValueChange = { editRateText = it },
                            label = { Text("Proposed Rate (%)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = IvoryWhite,
                                unfocusedTextColor = IvoryWhite,
                                focusedBorderColor = RhinoGold
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = reasonText,
                            onValueChange = { reasonText = it },
                            label = { Text("Justification (Market move / Fix adjustment)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = IvoryWhite,
                                unfocusedTextColor = IvoryWhite,
                                focusedBorderColor = RhinoGold
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = { isEditing = false },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E394A)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Cancel", fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val newR = editRateText.toDoubleOrNull()
                                    if (newR != null && reasonText.isNotBlank()) {
                                        onOverrideRate(rate.seriesId, newR, reasonText)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RhinoGold, contentColor = Color(0xFF0C0F17)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Submit for Checker Approval", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProvenanceRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            color = IvoryMuted,
            fontSize = 11.sp,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            color = IvoryWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1.4f)
        )
    }
}

@Composable
fun FundingComparisonDialog(
    principal: BigDecimal,
    days: Int,
    convention: DayCountConvention,
    onSelectFundingOption: (FundingType) -> Unit,
    onDismiss: () -> Unit
) {
    val options = listOf(
        Triple(FundingType.UNSECURED_INTERBANK, 4.18, "Market reference interbank borrowing. No collateral required."),
        Triple(FundingType.SECURED_REPO, 4.05, "QCB Repo facility. Requires eligible Treasury Bills (5% haircut)."),
        Triple(FundingType.QCB_DEPOSIT_FACILITY, 4.00, "Central Bank deposit placement facility floor rate."),
        Triple(FundingType.COMMERCIAL_DEPOSIT, 4.30, "Institutional wholesale corporate deposit.")
    )

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(10.dp))
                .background(TerminalCardBackground)
                .border(BorderStroke(1.5.dp, RhinoGold.copy(alpha = 0.8f)), RoundedCornerShape(10.dp))
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "FUNDING OPTIONS COMPARISON",
                            color = IvoryWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "مقارنة خيارات وتكاليف التمويل",
                            color = IvoryMuted,
                            fontSize = 12.sp
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = IvoryMuted)
                    }
                }

                HorizontalDivider(color = Color(0xFF263345), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    text = "Principal: QAR ${QuantitativeEngine.formatMoneyQar(principal)}  •  Tenor: $days Day(s)  •  ${convention.code}",
                    color = RhinoGoldBright,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(10.dp))

                options.forEach { (type, rate, desc) ->
                    val result = QuantitativeEngine.calculateSimpleInterest(principal, rate, days, convention)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF161F2E))
                            .border(1.dp, Color(0xFF29374B), RoundedCornerShape(6.dp))
                            .clickable {
                                onSelectFundingOption(type)
                                onDismiss()
                            }
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = type.labelEn, color = IvoryWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(text = type.labelAr, color = IvoryDim, fontSize = 10.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${String.format(Locale.US, "%.2f", rate)}%",
                                        color = RhinoGoldBright,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Interest: QAR ${QuantitativeEngine.formatMoneyQar(result.interestAmount)}",
                                        color = IvoryWhite,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = desc, color = IvoryMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}
