package com.example.data

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object QatarBankingCalendar {

    private val dateFormatter = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy", Locale.ENGLISH)
    private val isoFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    /**
     * In Qatar, the standard banking weekend is Friday and Saturday.
     * Working days are Sunday through Thursday.
     */
    fun isWeekend(date: LocalDate): Boolean {
        return date.dayOfWeek == DayOfWeek.FRIDAY || date.dayOfWeek == DayOfWeek.SATURDAY
    }

    /**
     * Configured standard Qatar banking holidays (fixed and calculated).
     */
    fun isHoliday(date: LocalDate): Boolean {
        // Qatar National Day: Dec 18
        if (date.monthValue == 12 && date.dayOfMonth == 18) return true

        // Qatar National Sports Day: 2nd Tuesday of February
        if (date.monthValue == 2 && date.dayOfWeek == DayOfWeek.TUESDAY) {
            val day = date.dayOfMonth
            if (day in 8..14) return true
        }

        // Qatar Central Bank annual bank holiday (First Sunday in March)
        if (date.monthValue == 3 && date.dayOfWeek == DayOfWeek.SUNDAY && date.dayOfMonth <= 7) {
            return true
        }

        return false
    }

    fun isBusinessDay(date: LocalDate): Boolean {
        return !isWeekend(date) && !isHoliday(date)
    }

    /**
     * Finds the next valid business day.
     * If Thursday, rolls through Friday and Saturday to Sunday (3 calendar days).
     */
    fun nextBusinessDay(date: LocalDate): LocalDate {
        var next = date.plusDays(1)
        while (!isBusinessDay(next)) {
            next = next.plusDays(1)
        }
        return next
    }

    /**
     * Computes the actual calendar day count between settlement and maturity.
     */
    fun getOvernightDayCount(startDate: LocalDate): Int {
        val nextBiz = nextBusinessDay(startDate)
        return java.time.temporal.ChronoUnit.DAYS.between(startDate, nextBiz).toInt()
    }

    fun formatDisplayEn(date: LocalDate): String = date.format(dateFormatter)

    fun formatDisplayAr(date: LocalDate): String {
        val dayNameAr = when (date.dayOfWeek) {
            DayOfWeek.SUNDAY -> "الأحد"
            DayOfWeek.MONDAY -> "الاثنين"
            DayOfWeek.TUESDAY -> "الثلاثاء"
            DayOfWeek.WEDNESDAY -> "الأربعاء"
            DayOfWeek.THURSDAY -> "الخميس"
            DayOfWeek.FRIDAY -> "الجمعة"
            DayOfWeek.SATURDAY -> "السبت"
            else -> ""
        }
        val monthNameAr = when (date.monthValue) {
            1 -> "يناير"
            2 -> "فبراير"
            3 -> "مارس"
            4 -> "أبريل"
            5 -> "مايو"
            6 -> "يونيو"
            7 -> "يوليو"
            8 -> "أغسطس"
            9 -> "سبتمبر"
            10 -> "أكتوبر"
            11 -> "نوفمبر"
            12 -> "ديسمبر"
            else -> ""
        }
        return "$dayNameAr، ${date.dayOfMonth} $monthNameAr ${date.year}"
    }
}
