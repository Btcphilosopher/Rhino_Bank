package com.example.data

import com.example.model.AuditRecord
import com.example.model.LiquidityLadderItem
import com.example.model.RateObservation
import com.example.model.TreasuryAlert
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TerminalRepository(
    private val database: TerminalDatabase,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val rateDao = database.rateDao()
    private val liquidityDao = database.liquidityDao()
    private val alertDao = database.alertDao()
    private val auditDao = database.auditDao()

    init {
        scope.launch {
            seedDatabaseIfEmpty()
        }
    }

    private suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val existingRates = rateDao.getAllObservations().first()
        if (existingRates.isEmpty()) {
            rateDao.insertObservations(InitialDemoData.rateObservations)
        }

        val existingLiquidity = liquidityDao.getLiquidityItems().first()
        if (existingLiquidity.isEmpty()) {
            liquidityDao.insertItems(InitialDemoData.liquidityItems)
        }

        val existingAlerts = alertDao.getAlerts().first()
        if (existingAlerts.isEmpty()) {
            alertDao.insertAlerts(InitialDemoData.treasuryAlerts)
        }

        val existingAudits = auditDao.getAuditRecords().first()
        if (existingAudits.isEmpty()) {
            InitialDemoData.auditRecords.forEach { auditDao.insertRecord(it) }
        }
    }

    fun getRates(): Flow<List<RateObservation>> = rateDao.getAllObservations()

    fun getLiquidityLadder(): Flow<List<LiquidityLadderItem>> = liquidityDao.getLiquidityItems()

    fun getAlerts(): Flow<List<TreasuryAlert>> = alertDao.getAlerts()

    fun getAuditTrail(): Flow<List<AuditRecord>> = auditDao.getAuditRecords()

    suspend fun updateRateObservation(obs: RateObservation, userRole: String, reason: String) = withContext(Dispatchers.IO) {
        rateDao.updateObservation(obs)
        auditDao.insertRecord(
            AuditRecord(
                timestamp = "Just now (Doha QAT)",
                action = "MANUAL_RATE_OVERRIDE",
                performedBy = "Desk Trader",
                role = userRole,
                status = "APPROVED",
                details = "Updated ${obs.seriesId} to ${obs.ratePercent}%: $reason"
            )
        )
    }

    suspend fun addAuditRecord(action: String, performedBy: String, role: String, details: String) = withContext(Dispatchers.IO) {
        auditDao.insertRecord(
            AuditRecord(
                timestamp = "Just now (Doha QAT)",
                action = action,
                performedBy = performedBy,
                role = role,
                status = "APPROVED",
                details = details
            )
        )
    }

    suspend fun dismissAlert(id: Long) = withContext(Dispatchers.IO) {
        alertDao.markAsRead(id)
    }
}
