package com.example.data

import com.example.model.CurveNode
import com.example.model.DayCountConvention
import com.example.model.FundingCalculationResult
import com.example.model.MonteCarloSummary
import com.example.model.ScenarioStressResult
import com.example.model.Tenor
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.random.Random

object QuantitativeEngine {

    private val moneyFormatter = DecimalFormat("#,##0.00", DecimalFormatSymbols(Locale.US))
    private val percentFormatter = DecimalFormat("0.00%", DecimalFormatSymbols(Locale.US))

    /**
     * Calculates simple interest per money market standard:
     * Interest = Principal * Annual Rate * DayCountFraction
     * DayCountFraction = Days / BasisDays
     */
    fun calculateSimpleInterest(
        principal: BigDecimal,
        annualRatePercent: Double,
        days: Int,
        convention: DayCountConvention
    ): FundingCalculationResult {
        val rateDecimal = BigDecimal.valueOf(annualRatePercent)
            .divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP)

        val daysBd = BigDecimal.valueOf(days.toLong())
        val basisBd = BigDecimal.valueOf(convention.basisDays.toLong())

        val dayCountFraction = daysBd.divide(basisBd, 12, RoundingMode.HALF_UP)

        val interestExact = principal.multiply(rateDecimal).multiply(dayCountFraction)
        val interestRounded = interestExact.setScale(2, RoundingMode.HALF_UP)
        val maturityProceeds = principal.add(interestRounded).setScale(2, RoundingMode.HALF_UP)

        val principalFormatted = DecimalFormat("#,##0", DecimalFormatSymbols(Locale.US)).format(principal)
        val formula = "= $principalFormatted × $annualRatePercent% × $days / ${convention.basisDays}"

        return FundingCalculationResult(
            principal = principal,
            annualRatePercent = annualRatePercent,
            days = days,
            convention = convention,
            interestAmount = interestRounded,
            maturityProceeds = maturityProceeds,
            formulaDisplay = formula
        )
    }

    /**
     * Bootstraps discount curve and forward rates from QIBOR tenors.
     */
    fun buildYieldCurve(rates: Map<Tenor, Double>): List<CurveNode> {
        val orderedTenors = listOf(Tenor.ON, Tenor.W1, Tenor.M1, Tenor.M3, Tenor.M6, Tenor.Y1)
        val nodes = mutableListOf<CurveNode>()

        var prevDf = 1.0
        var prevDays = 0

        for (tenor in orderedTenors) {
            val rate = rates[tenor] ?: 4.25
            val days = tenor.approxDays

            // Simple money market discount factor: DF(t) = 1 / (1 + r * t / 360)
            val rateDecimal = rate / 100.0
            val df = 1.0 / (1.0 + rateDecimal * (days / 360.0))

            // Continuous/annualized Zero rate: (1/DF - 1) * (360 / days) * 100
            val zeroRate = ( (1.0 / df) - 1.0 ) * (360.0 / days) * 100.0

            // Forward rate between previous node and current node:
            val forwardRate = if (days > prevDays && prevDays > 0) {
                ((prevDf / df) - 1.0) * (360.0 / (days - prevDays)) * 100.0
            } else {
                rate
            }

            // PV01 for QAR 10m notional
            val notional = 10_000_000.0
            val pv01 = notional * (days / 360.0) * 0.0001

            nodes.add(
                CurveNode(
                    tenor = tenor,
                    days = days,
                    ratePercent = rate,
                    discountFactor = df,
                    zeroRatePercent = zeroRate,
                    forwardRatePercent = forwardRate,
                    pv01Qar = pv01
                )
            )

            prevDf = df
            prevDays = days
        }

        return nodes
    }

    /**
     * Volume-Weighted Average Rate (VWAP / VWMR) for internal interbank transaction trades.
     */
    fun calculateVwmr(trades: List<Pair<Double, Double>>): Double {
        if (trades.isEmpty()) return 0.0
        var totalVolume = 0.0
        var weightedSum = 0.0
        for ((rate, volume) in trades) {
            weightedSum += rate * volume
            totalVolume += volume
        }
        return if (totalVolume > 0) weightedSum / totalVolume else 0.0
    }

    /**
     * Deterministic Stress Scenarios for Treasury Desk.
     */
    fun evaluateScenario(
        basePrincipalQar: Double,
        baseRatePercent: Double,
        rateShiftBp: Int,
        depositOutflowPct: Double,
        delayedReceiptDays: Int,
        scenarioName: String,
        internalCashBufferQarMillions: Double = 500.0
    ): ScenarioStressResult {
        val stressedRatePercent = baseRatePercent + (rateShiftBp / 100.0)
        val stressedRateDecimal = stressedRatePercent / 100.0

        // 1-day funding cost under stressed rate
        val baseFundingCost = basePrincipalQar * (baseRatePercent / 100.0) * (1.0 / 360.0)
        val stressedFundingCost = basePrincipalQar * stressedRateDecimal * (1.0 / 360.0)
        val costChange = stressedFundingCost - baseFundingCost

        // Additional liquidity required from deposit outflows & delayed receipts
        val outflowImpactMillions = (basePrincipalQar / 1_000_000.0) * (depositOutflowPct / 100.0)
        val delayedImpactMillions = delayedReceiptDays * 45.0 // Assume QAR 45m daily receipt delay
        val totalLiquidityGapMillions = 125.0 + outflowImpactMillions + delayedImpactMillions

        val bufferUtilisation = (totalLiquidityGapMillions / internalCashBufferQarMillions) * 100.0
        val isBreached = totalLiquidityGapMillions > internalCashBufferQarMillions

        return ScenarioStressResult(
            scenarioName = scenarioName,
            rateShiftBp = rateShiftBp,
            depositOutflowPercent = depositOutflowPct,
            delayedReceiptDays = delayedReceiptDays,
            totalFundingCostQar = stressedFundingCost,
            costChangeQar = costChange,
            liquidityGapQarMillions = totalLiquidityGapMillions,
            bufferUtilisationPercent = bufferUtilisation,
            isBufferBreached = isBreached
        )
    }

    /**
     * Monte Carlo Overnight Simulation:
     * Generates 1,000 stochastic overnight funding paths with mean reversion to QCB policy rate.
     */
    fun runMonteCarloSimulation(
        currentRatePercent: Double,
        policyRatePercent: Double,
        principalQar: Double,
        daysHorizon: Int = 5,
        runs: Int = 1000,
        seed: Long = 42L
    ): MonteCarloSummary {
        val random = Random(seed)
        val costOutcomes = DoubleArray(runs)

        val kappa = 0.15 // Mean reversion speed
        val sigma = 0.08 // Daily basis point volatility
        val dt = 1.0 / 360.0

        for (i in 0 until runs) {
            var simRate = currentRatePercent
            var totalPeriodCost = 0.0

            for (day in 1..daysHorizon) {
                // Vasicek / Ornstein-Uhlenbeck drift towards policy rate + random shock
                val z = boxMullerGaussian(random)
                val drift = kappa * (policyRatePercent - simRate)
                val shock = sigma * z
                simRate += drift + shock
                if (simRate < 3.50) simRate = 3.50 // Interest rate corridor lower bound

                val dailyCost = principalQar * (simRate / 100.0) * (1.0 / 360.0)
                totalPeriodCost += dailyCost
            }
            costOutcomes[i] = totalPeriodCost
        }

        costOutcomes.sort()

        val mean = costOutcomes.average()
        val variance = costOutcomes.map { (it - mean).pow(2) }.average()
        val stdError = sqrt(variance / runs)

        val p5th = costOutcomes[(runs * 0.05).toInt()]
        val p50th = costOutcomes[(runs * 0.50).toInt()]
        val p95th = costOutcomes[(runs * 0.95).toInt()]

        // Probability of funding cost exceeding base expectation by > 10%
        val baseExpectation = principalQar * (currentRatePercent / 100.0) * (daysHorizon / 360.0)
        val deficitRuns = costOutcomes.count { it > baseExpectation * 1.05 }
        val probDeficit = deficitRuns.toDouble() / runs

        return MonteCarloSummary(
            iterations = runs,
            meanFundingCostQar = mean,
            standardErrorQar = stdError,
            p5thCostQar = p5th,
            p50thCostQar = p50th,
            p95thCostQar = p95th,
            probabilityOfDeficit = probDeficit
        )
    }

    private fun boxMullerGaussian(random: Random): Double {
        var u1 = random.nextDouble()
        while (u1 <= 1e-15) u1 = random.nextDouble()
        val u2 = random.nextDouble()
        return sqrt(-2.0 * kotlin.math.ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)
    }

    fun formatMoneyQar(amount: BigDecimal): String = moneyFormatter.format(amount)
    fun formatMoneyQar(amount: Double): String = moneyFormatter.format(amount)
}
