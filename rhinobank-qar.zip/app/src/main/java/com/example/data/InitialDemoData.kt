package com.example.data

import com.example.model.AlertSeverity
import com.example.model.AuditRecord
import com.example.model.EntitlementStatus
import com.example.model.HistoricalRatePoint
import com.example.model.LiquidityLadderItem
import com.example.model.QualityStatus
import com.example.model.RateCategory
import com.example.model.RateObservation
import com.example.model.Tenor
import com.example.model.TreasuryAlert

object InitialDemoData {

    val rateObservations = listOf(
        // Published QIBOR Fixing
        RateObservation(
            seriesId = "QAR-QIBOR-ON-FIXING",
            category = RateCategory.PUBLISHED_QIBOR_FIXING,
            tenor = Tenor.ON,
            ratePercent = 4.25,
            changeBp = 2,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-15T07:15:00Z",
            publicationTimestampLocal = "10:15 QAT",
            effectiveDate = "2025-01-15",
            source = "QIBOR (Offered Fixing)",
            qualityStatus = QualityStatus.PUBLISHED_TODAY,
            entitlement = EntitlementStatus.LICENSED_INSTITUTIONAL,
            methodologyNote = "Authorized fixing panel calculation at 10:00 Doha time."
        ),
        RateObservation(
            seriesId = "QAR-QIBOR-1W-FIXING",
            category = RateCategory.PUBLISHED_QIBOR_FIXING,
            tenor = Tenor.W1,
            ratePercent = 4.29,
            changeBp = 1,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-15T07:15:00Z",
            publicationTimestampLocal = "10:15 QAT",
            effectiveDate = "2025-01-15",
            source = "QIBOR (Offered Fixing)",
            qualityStatus = QualityStatus.PUBLISHED_TODAY,
            entitlement = EntitlementStatus.LICENSED_INSTITUTIONAL
        ),
        RateObservation(
            seriesId = "QAR-QIBOR-1M-FIXING",
            category = RateCategory.PUBLISHED_QIBOR_FIXING,
            tenor = Tenor.M1,
            ratePercent = 4.35,
            changeBp = 0,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-15T07:15:00Z",
            publicationTimestampLocal = "10:15 QAT",
            effectiveDate = "2025-01-15",
            source = "QIBOR (Offered Fixing)",
            qualityStatus = QualityStatus.PUBLISHED_TODAY,
            entitlement = EntitlementStatus.LICENSED_INSTITUTIONAL
        ),
        RateObservation(
            seriesId = "QAR-QIBOR-3M-FIXING",
            category = RateCategory.PUBLISHED_QIBOR_FIXING,
            tenor = Tenor.M3,
            ratePercent = 4.48,
            changeBp = 3,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-15T07:15:00Z",
            publicationTimestampLocal = "10:15 QAT",
            effectiveDate = "2025-01-15",
            source = "QIBOR (Offered Fixing)",
            qualityStatus = QualityStatus.PUBLISHED_TODAY,
            entitlement = EntitlementStatus.LICENSED_INSTITUTIONAL
        ),
        RateObservation(
            seriesId = "QAR-QIBOR-6M-FIXING",
            category = RateCategory.PUBLISHED_QIBOR_FIXING,
            tenor = Tenor.M6,
            ratePercent = 4.60,
            changeBp = 1,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-15T07:15:00Z",
            publicationTimestampLocal = "10:15 QAT",
            effectiveDate = "2025-01-15",
            source = "QIBOR (Offered Fixing)",
            qualityStatus = QualityStatus.PUBLISHED_TODAY,
            entitlement = EntitlementStatus.LICENSED_INSTITUTIONAL
        ),
        RateObservation(
            seriesId = "QAR-QIBOR-1Y-FIXING",
            category = RateCategory.PUBLISHED_QIBOR_FIXING,
            tenor = Tenor.Y1,
            ratePercent = 4.72,
            changeBp = 2,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-15T07:15:00Z",
            publicationTimestampLocal = "10:15 QAT",
            effectiveDate = "2025-01-15",
            source = "QIBOR (Offered Fixing)",
            qualityStatus = QualityStatus.PUBLISHED_TODAY,
            entitlement = EntitlementStatus.LICENSED_INSTITUTIONAL
        ),

        // Observed Interbank (Average Volume-Weighted)
        RateObservation(
            seriesId = "QAR-INTERBANK-ON-OBSERVED",
            category = RateCategory.AVERAGE_OVERNIGHT_INTERBANK,
            tenor = Tenor.ON,
            ratePercent = 4.18,
            changeBp = -1,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-15T07:10:00Z",
            publicationTimestampLocal = "10:10 QAT",
            effectiveDate = "2025-01-15",
            source = "Interbank (Observed)",
            qualityStatus = QualityStatus.EFFECTIVE_TODAY,
            entitlement = EntitlementStatus.INTERNAL_TREASURY,
            methodologyNote = "Volume-weighted interbank transactions reported up to 10:00 QAT."
        ),

        // QCB Policy Deposit Rate
        RateObservation(
            seriesId = "QAR-QCB-DEPOSIT-POLICY",
            category = RateCategory.QCB_POLICY_RATES,
            tenor = Tenor.ON,
            ratePercent = 4.00,
            changeBp = 0,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-01T00:00:00Z",
            publicationTimestampLocal = "03:00 QAT",
            effectiveDate = "2025-01-01",
            source = "QCB (Policy Rate)",
            qualityStatus = QualityStatus.LAST_AVAILABLE,
            entitlement = EntitlementStatus.PUBLIC_POLICY,
            methodologyNote = "Qatar Central Bank Standing Deposit Facility Rate (QCBDR)."
        ),

        // QCB Policy Repo Rate
        RateObservation(
            seriesId = "QAR-QCB-REPO-POLICY",
            category = RateCategory.QCB_POLICY_RATES,
            tenor = Tenor.ON,
            ratePercent = 4.25,
            changeBp = 0,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-01T00:00:00Z",
            publicationTimestampLocal = "03:00 QAT",
            effectiveDate = "2025-01-01",
            source = "QCB (Repo Rate)",
            qualityStatus = QualityStatus.LAST_AVAILABLE,
            entitlement = EntitlementStatus.PUBLIC_POLICY
        ),

        // QCB Policy Lending Rate
        RateObservation(
            seriesId = "QAR-QCB-LENDING-POLICY",
            category = RateCategory.QCB_POLICY_RATES,
            tenor = Tenor.ON,
            ratePercent = 4.50,
            changeBp = 0,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-01T00:00:00Z",
            publicationTimestampLocal = "03:00 QAT",
            effectiveDate = "2025-01-01",
            source = "QCB (Lending Rate)",
            qualityStatus = QualityStatus.LAST_AVAILABLE,
            entitlement = EntitlementStatus.PUBLIC_POLICY
        ),

        // RhinoQuant Model Estimate
        RateObservation(
            seriesId = "QAR-RHINOQUANT-ON-ESTIMATE",
            category = RateCategory.RHINOQUANT_ESTIMATE,
            tenor = Tenor.ON,
            ratePercent = 4.21,
            changeBp = 0,
            observationDate = "2025-01-15",
            publicationTimestampUtc = "2025-01-15T07:20:00Z",
            publicationTimestampLocal = "10:20 QAT",
            effectiveDate = "2025-01-15",
            source = "RhinoQuant Model",
            qualityStatus = QualityStatus.ESTIMATED,
            entitlement = EntitlementStatus.INTERNAL_TREASURY,
            uncertaintyBp = 4.0,
            methodologyNote = "Kalman-filtered interbank spread model conditioned on QCB deposit floor and dealer inventory."
        )
    )

    val liquidityItems = listOf(
        LiquidityLadderItem(
            dateIso = "2025-01-15",
            dateDisplayEn = "Wed, 15 Jan 2025",
            dateDisplayAr = "الأربعاء، 15 يناير 2025",
            inflowsQarMillions = 650.0,
            outflowsQarMillions = 775.0,
            netFundingQarMillions = -125.0,
            cumulativeNetQarMillions = -125.0
        ),
        LiquidityLadderItem(
            dateIso = "2025-01-16",
            dateDisplayEn = "Thu, 16 Jan 2025",
            dateDisplayAr = "الخميس، 16 يناير 2025",
            inflowsQarMillions = 1120.0,
            outflowsQarMillions = 1050.0,
            netFundingQarMillions = 70.0,
            cumulativeNetQarMillions = -55.0
        ),
        LiquidityLadderItem(
            dateIso = "2025-01-19",
            dateDisplayEn = "Sun, 19 Jan 2025",
            dateDisplayAr = "الأحد، 19 يناير 2025",
            inflowsQarMillions = 980.0,
            outflowsQarMillions = 1020.0,
            netFundingQarMillions = -40.0,
            cumulativeNetQarMillions = -95.0
        ),
        LiquidityLadderItem(
            dateIso = "2025-01-20",
            dateDisplayEn = "Mon, 20 Jan 2025",
            dateDisplayAr = "الاثنين، 20 يناير 2025",
            inflowsQarMillions = 1300.0,
            outflowsQarMillions = 1180.0,
            netFundingQarMillions = 120.0,
            cumulativeNetQarMillions = 25.0
        ),
        LiquidityLadderItem(
            dateIso = "2025-01-21",
            dateDisplayEn = "Tue, 21 Jan 2025",
            dateDisplayAr = "الثلاثاء، 21 يناير 2025",
            inflowsQarMillions = 1050.0,
            outflowsQarMillions = 1140.0,
            netFundingQarMillions = -90.0,
            cumulativeNetQarMillions = -65.0
        )
    )

    val treasuryAlerts = listOf(
        TreasuryAlert(
            category = "Policy scenarios",
            titleEn = "Policy Scenario Update",
            titleAr = "تحديث سيناريو السياسة",
            messageEn = "QCB path: hold at 4.00% (base), ±25 bp scenarios loaded.",
            messageAr = "مسار مصرف قطر المركزي: تثبيت عند 4.00%، تم تحميل سيناريوهات ±25 نقطة أساس.",
            timestampLocal = "10:12 QAT",
            severity = AlertSeverity.CRITICAL
        ),
        TreasuryAlert(
            category = "Funding Gap",
            titleEn = "Funding Gap Above Threshold",
            titleAr = "فجوة التمويل تجاوزت الحد",
            messageEn = "System funding gap at QAR 125.0m (threshold: QAR 100.0m).",
            messageAr = "صافي فجوة التمويل للنظام عند 125.0 مليون ر.ق (الحد الأقصى: 100.0 مليون ر.ق).",
            timestampLocal = "09:47 QAT",
            severity = AlertSeverity.WARNING
        ),
        TreasuryAlert(
            category = "Liquidity Outlook",
            titleEn = "Liquidity Outlook Stable",
            titleAr = "نظرة السيولة مستقرة",
            messageEn = "Next 5 business days: cumulative net funding +QAR 60.0m.",
            messageAr = "الأيام الخمسة القادمة: صافي تمويل تراكمي إيجابي +60.0 مليون ر.ق.",
            timestampLocal = "09:30 QAT",
            severity = AlertSeverity.INFO
        )
    )

    val historicalRates = listOf(
        HistoricalRatePoint("15 Oct 2024", 4.30, 4.22, 4.00, 4.25, 4.35),
        HistoricalRatePoint("22 Oct 2024", 4.28, 4.20, 4.00, 4.23, 4.33),
        HistoricalRatePoint("29 Oct 2024", 4.26, 4.19, 4.00, 4.21, 4.31),
        HistoricalRatePoint("05 Nov 2024", 4.27, 4.20, 4.00, 4.22, 4.32),
        HistoricalRatePoint("12 Nov 2024", 4.25, 4.18, 4.00, 4.20, 4.30),
        HistoricalRatePoint("19 Nov 2024", 4.26, 4.19, 4.00, 4.21, 4.31),
        HistoricalRatePoint("26 Nov 2024", 4.24, 4.17, 4.00, 4.19, 4.29),
        HistoricalRatePoint("03 Dec 2024", 4.27, 4.20, 4.00, 4.22, 4.32),
        HistoricalRatePoint("10 Dec 2024", 4.25, 4.18, 4.00, 4.20, 4.30),
        HistoricalRatePoint("17 Dec 2024", 4.23, 4.16, 4.00, 4.18, 4.28),
        HistoricalRatePoint("24 Dec 2024", 4.26, 4.19, 4.00, 4.21, 4.31),
        HistoricalRatePoint("31 Dec 2024", 4.28, 4.21, 4.00, 4.23, 4.33),
        HistoricalRatePoint("07 Jan 2025", 4.24, 4.17, 4.00, 4.19, 4.29),
        HistoricalRatePoint("15 Jan 2025", 4.25, 4.18, 4.00, 4.21, 4.32),
        HistoricalRatePoint("22 Jan 2025 (F)", 4.26, 4.19, 4.00, 4.18, 4.34)
    )

    val bankQuotes = listOf(
        Triple("Qatar National Bank (QNB)", 4.23, 4.25),
        Triple("The Commercial Bank (CBQ)", 4.24, 4.26),
        Triple("Doha Bank", 4.25, 4.27),
        Triple("Qatar International Islamic Bank (QIIB)", 4.23, 4.25),
        Triple("Masraf Al Rayan", 4.24, 4.26),
        Triple("Dukhan Bank", 4.25, 4.28)
    )

    val auditRecords = listOf(
        AuditRecord(
            timestamp = "15 Jan 2025 10:15:02 QAT",
            action = "IMPORT_FIXING",
            performedBy = "FeedHandler_QIBOR",
            role = "Data Admin",
            status = "APPROVED",
            details = "Ingested published fixing O/N 4.25%, 1W 4.29%, 1M 4.35%. Provenance checksum verified."
        ),
        AuditRecord(
            timestamp = "15 Jan 2025 09:47:11 QAT",
            action = "ALERT_TRIGGERED",
            performedBy = "System Engine",
            role = "System",
            status = "AUTO_RECORDED",
            details = "Net funding gap -QAR 125.0m breached threshold QAR 100.0m."
        ),
        AuditRecord(
            timestamp = "15 Jan 2025 09:12:44 QAT",
            action = "CALENDAR_ROLL_VALIDATION",
            performedBy = "Treasury Dealer",
            role = "Treasury Dealer",
            status = "APPROVED",
            details = "Confirmed Thu-Sun Qatar banking weekend roll (3 days ACT/360)."
        )
    )
}
