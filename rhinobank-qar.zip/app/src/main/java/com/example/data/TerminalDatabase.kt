package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.model.AlertSeverity
import com.example.model.AuditRecord
import com.example.model.EntitlementStatus
import com.example.model.LiquidityLadderItem
import com.example.model.QualityStatus
import com.example.model.RateCategory
import com.example.model.RateObservation
import com.example.model.Tenor
import com.example.model.TreasuryAlert

class Converters {
    @TypeConverter fun fromRateCategory(value: RateCategory?): String = value?.name ?: RateCategory.PUBLISHED_QIBOR_FIXING.name
    @TypeConverter fun toRateCategory(value: String): RateCategory = runCatching { RateCategory.valueOf(value) }.getOrDefault(RateCategory.PUBLISHED_QIBOR_FIXING)

    @TypeConverter fun fromTenor(value: Tenor?): String = value?.name ?: Tenor.ON.name
    @TypeConverter fun toTenor(value: String): Tenor = runCatching { Tenor.valueOf(value) }.getOrDefault(Tenor.ON)

    @TypeConverter fun fromQualityStatus(value: QualityStatus?): String = value?.name ?: QualityStatus.PUBLISHED_TODAY.name
    @TypeConverter fun toQualityStatus(value: String): QualityStatus = runCatching { QualityStatus.valueOf(value) }.getOrDefault(QualityStatus.PUBLISHED_TODAY)

    @TypeConverter fun fromEntitlement(value: EntitlementStatus?): String = value?.name ?: EntitlementStatus.LICENSED_INSTITUTIONAL.name
    @TypeConverter fun toEntitlement(value: String): EntitlementStatus = runCatching { EntitlementStatus.valueOf(value) }.getOrDefault(EntitlementStatus.LICENSED_INSTITUTIONAL)

    @TypeConverter fun fromAlertSeverity(value: AlertSeverity?): String = value?.name ?: AlertSeverity.INFO.name
    @TypeConverter fun toAlertSeverity(value: String): AlertSeverity = runCatching { AlertSeverity.valueOf(value) }.getOrDefault(AlertSeverity.INFO)
}

@Database(
    entities = [
        RateObservation::class,
        LiquidityLadderItem::class,
        TreasuryAlert::class,
        AuditRecord::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class TerminalDatabase : RoomDatabase() {
    abstract fun rateDao(): RateDao
    abstract fun liquidityDao(): LiquidityDao
    abstract fun alertDao(): AlertDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: TerminalDatabase? = null

        fun getInstance(context: Context): TerminalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TerminalDatabase::class.java,
                    "rhinobank_qar_terminal.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
