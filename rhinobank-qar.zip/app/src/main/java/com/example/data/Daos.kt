package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.AuditRecord
import com.example.model.LiquidityLadderItem
import com.example.model.RateObservation
import com.example.model.TreasuryAlert
import kotlinx.coroutines.flow.Flow

@Dao
interface RateDao {
    @Query("SELECT * FROM rate_observations ORDER BY seriesId ASC")
    fun getAllObservations(): Flow<List<RateObservation>>

    @Query("SELECT * FROM rate_observations WHERE seriesId = :seriesId")
    suspend fun getObservation(seriesId: String): RateObservation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertObservations(items: List<RateObservation>)

    @Update
    suspend fun updateObservation(item: RateObservation)
}

@Dao
interface LiquidityDao {
    @Query("SELECT * FROM liquidity_ladder ORDER BY dateIso ASC")
    fun getLiquidityItems(): Flow<List<LiquidityLadderItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<LiquidityLadderItem>)

    @Update
    suspend fun updateItem(item: LiquidityLadderItem)
}

@Dao
interface AlertDao {
    @Query("SELECT * FROM treasury_alerts ORDER BY id DESC")
    fun getAlerts(): Flow<List<TreasuryAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: TreasuryAlert)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<TreasuryAlert>)

    @Query("UPDATE treasury_alerts SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_records ORDER BY id DESC")
    fun getAuditRecords(): Flow<List<AuditRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: AuditRecord)
}
