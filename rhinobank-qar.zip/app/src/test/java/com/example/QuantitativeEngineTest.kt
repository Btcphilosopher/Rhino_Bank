package com.example

import com.example.data.QatarBankingCalendar
import com.example.data.QuantitativeEngine
import com.example.model.DayCountConvention
import com.example.model.Tenor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class QuantitativeEngineTest {

    @Test
    fun testSimpleInterestExactMatchesTerminalScreenshot() {
        val principal = BigDecimal("50000000")
        val ratePercent = 4.25
        val days = 1
        val convention = DayCountConvention.ACT_360

        val result = QuantitativeEngine.calculateSimpleInterest(principal, ratePercent, days, convention)

        // Interest = 50,000,000 * 0.0425 * (1 / 360) = 5,902.777... -> 5,902.78
        assertEquals(BigDecimal("5902.78"), result.interestAmount)
        assertEquals(BigDecimal("50005902.78"), result.maturityProceeds)
        assertEquals("= 50,000,000 × 4.25% × 1 / 360", result.formulaDisplay)
    }

    @Test
    fun testQatarWeekendRolloverThreeDaysInterest() {
        val principal = BigDecimal("50000000")
        val ratePercent = 4.25
        val days = 3 // Thu -> Sun across Fri & Sat
        val convention = DayCountConvention.ACT_360

        val result = QuantitativeEngine.calculateSimpleInterest(principal, ratePercent, days, convention)

        // 50,000,000 * 0.0425 * 3 / 360 = 17,708.333... -> 17,708.33
        assertEquals(BigDecimal("17708.33"), result.interestAmount)
        assertEquals(BigDecimal("50017708.33"), result.maturityProceeds)
    }

    @Test
    fun testQatarBankingCalendarWeekendAndBusinessDays() {
        // 2025-01-16 is Thursday
        val thursday = LocalDate.of(2025, 1, 16)
        assertTrue(QatarBankingCalendar.isBusinessDay(thursday))

        // 2025-01-17 is Friday (Qatar weekend)
        val friday = LocalDate.of(2025, 1, 17)
        assertTrue(QatarBankingCalendar.isWeekend(friday))
        assertFalse(QatarBankingCalendar.isBusinessDay(friday))

        // 2025-01-18 is Saturday (Qatar weekend)
        val saturday = LocalDate.of(2025, 1, 18)
        assertTrue(QatarBankingCalendar.isWeekend(saturday))
        assertFalse(QatarBankingCalendar.isBusinessDay(saturday))

        // 2025-01-19 is Sunday (Qatar business day)
        val sunday = LocalDate.of(2025, 1, 19)
        assertFalse(QatarBankingCalendar.isWeekend(sunday))
        assertTrue(QatarBankingCalendar.isBusinessDay(sunday))

        // Next business day from Thursday is Sunday
        val nextBiz = QatarBankingCalendar.nextBusinessDay(thursday)
        assertEquals(sunday, nextBiz)

        // Chrono day count between Thursday and Sunday is 3
        assertEquals(3, QatarBankingCalendar.getOvernightDayCount(thursday))
    }

    @Test
    fun testCurveBootstrappingAndDiscountFactors() {
        val rates = mapOf(
            Tenor.ON to 4.25,
            Tenor.W1 to 4.29,
            Tenor.M1 to 4.35,
            Tenor.M3 to 4.48,
            Tenor.M6 to 4.60,
            Tenor.Y1 to 4.72
        )

        val nodes = QuantitativeEngine.buildYieldCurve(rates)
        assertEquals(6, nodes.size)

        // DF should decrease with tenor
        for (i in 0 until nodes.size - 1) {
            assertTrue(nodes[i].discountFactor > nodes[i + 1].discountFactor)
        }
    }

    @Test
    fun testVolumeWeightedAverageRate() {
        val trades = listOf(
            Pair(4.18, 500_000_000.0),
            Pair(4.20, 300_000_000.0),
            Pair(4.16, 200_000_000.0)
        )
        val vwmr = QuantitativeEngine.calculateVwmr(trades)
        // (4.18*500 + 4.20*300 + 4.16*200) / 1000 = (2090 + 1260 + 832) / 1000 = 4182 / 1000 = 4.182
        assertEquals(4.182, vwmr, 0.001)
    }
}
