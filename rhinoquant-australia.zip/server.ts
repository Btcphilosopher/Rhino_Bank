import express from 'express';
import { createServer as createViteServer } from 'vite';
import { CURRENCY_METADATA, INITIAL_CURRENCY_PAIRS, STRESS_SCENARIOS } from './src/domain/marketData';
import {
  calculateCarrySignal,
  calculateForwardPricing,
  computeOptimalWeights,
  evaluatePortfolio,
  runHistoricalBacktest,
  runStressScenario,
  solveReverseStressTest,
} from './src/domain/quantEngine';
import { runQuantitativeValidationSuite } from './src/domain/quantTests';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // 1. GET /api/v1/carry/universe
  app.get('/api/v1/carry/universe', (_req, res) => {
    res.json({
      status: 'OK',
      mode: 'OFFLINE_SYNTHETIC_RESEARCH',
      timestamp: '2026-10-09T06:00:00Z',
      pairs: INITIAL_CURRENCY_PAIRS,
      currencies: CURRENCY_METADATA,
    });
  });

  // 2. GET /api/v1/carry/metrics
  app.get('/api/v1/carry/metrics', (req, res) => {
    const instrument = (req.query.instrument as any) || 'OIS_CURVE';
    const tenor = (req.query.tenor as any) || '3M';
    const metrics = INITIAL_CURRENCY_PAIRS.map((pair) =>
      calculateCarrySignal(pair, instrument, tenor)
    );
    res.json({
      status: 'OK',
      instrument,
      tenor,
      metrics,
    });
  });

  // 3. GET /api/v1/fx/spot
  app.get('/api/v1/fx/spot', (_req, res) => {
    res.json({
      status: 'OK',
      convention: 'S_{A/Q} = units of quote currency Q per 1 AUD',
      quotes: INITIAL_CURRENCY_PAIRS.map((p) => ({
        pairId: p.id,
        spot: p.spot,
        bid: p.spotBid,
        ask: p.spotAsk,
        spreadPips: Number(((p.spotAsk - p.spotBid) * p.pipMultiplier).toFixed(2)),
        timestamp: p.observationTimestamp,
        source: p.sourceProvider,
      })),
    });
  });

  // 4. GET /api/v1/fx/forwards
  app.get('/api/v1/fx/forwards', (req, res) => {
    const tenor = (req.query.tenor as any) || '3M';
    const instrument = (req.query.instrument as any) || 'OIS_CURVE';
    const compounding = (req.query.compounding as any) || 'CONTINUOUS';
    const forwards = INITIAL_CURRENCY_PAIRS.map((p) =>
      calculateForwardPricing(p, tenor, instrument, compounding)
    );
    res.json({
      status: 'OK',
      tenor,
      instrument,
      compounding,
      forwards,
    });
  });

  // 5. GET /api/v1/rates/curves
  app.get('/api/v1/rates/curves', (_req, res) => {
    res.json({
      status: 'OK',
      curves: CURRENCY_METADATA,
    });
  });

  // 6. POST /api/v1/portfolio/valuation
  app.post('/api/v1/portfolio/valuation', (req, res) => {
    const { positions = [], totalEquityAud = 10_000_000, baseCurrency = 'AUD' } = req.body || {};
    const summary = evaluatePortfolio(positions, INITIAL_CURRENCY_PAIRS, totalEquityAud, baseCurrency);
    res.json({
      status: 'OK',
      valuation: summary,
    });
  });

  // 7. POST /api/v1/portfolio/optimise
  app.post('/api/v1/portfolio/optimise', (req, res) => {
    const {
      positions = [],
      method = 'MEAN_VARIANCE_OPT',
      riskAversionLambda = 2.5,
      targetGrossNotionalAud = 10_000_000,
    } = req.body || {};
    const optimisedPositions = computeOptimalWeights(
      positions,
      INITIAL_CURRENCY_PAIRS,
      method,
      riskAversionLambda,
      targetGrossNotionalAud
    );
    res.json({
      status: 'OK',
      method,
      riskAversionLambda,
      positions: optimisedPositions,
    });
  });

  // 8. POST /api/v1/risk/stress
  app.post('/api/v1/risk/stress', (req, res) => {
    const { scenarioId = 'CORRELATED_UNWIND', positions = [], totalEquityAud = 10_000_000, baseCurrency = 'AUD' } =
      req.body || {};
    const scenario =
      STRESS_SCENARIOS.find((s) => s.id === scenarioId) || STRESS_SCENARIOS[0];
    const result = runStressScenario(
      scenario,
      positions,
      INITIAL_CURRENCY_PAIRS,
      totalEquityAud,
      baseCurrency
    );
    res.json({
      status: 'OK',
      result,
    });
  });

  // 9. POST /api/v1/risk/reverse-stress
  app.post('/api/v1/risk/reverse-stress', (req, res) => {
    const {
      targetLossPct = 10,
      positions = [],
      totalEquityAud = 10_000_000,
      baseCurrency = 'AUD',
      fundingShareRatio = 0.45,
    } = req.body || {};
    const result = solveReverseStressTest(
      targetLossPct,
      positions,
      INITIAL_CURRENCY_PAIRS,
      totalEquityAud,
      baseCurrency,
      fundingShareRatio
    );
    res.json({
      status: 'OK',
      result,
    });
  });

  // 10. POST /api/v1/backtests
  app.post('/api/v1/backtests', (req, res) => {
    const config = req.body || {
      strategyFamily: 'CARRY_TO_VOL_RANK',
      eligiblePairs: ['AUD/JPY', 'AUD/CHF', 'AUD/EUR', 'AUD/SGD', 'AUD/CAD'],
      rebalanceSchedule: 'MONTHLY',
      targetVolPct: 10,
      topNPairs: 3,
      includeTransactionCosts: true,
      txCostMultiplier: 1.0,
      outOfSampleSplitPct: 70,
      preventLookAheadLagDays: 1,
    };
    const report = runHistoricalBacktest(config, INITIAL_CURRENCY_PAIRS);
    res.json({
      status: 'OK',
      report,
    });
  });

  // 11. GET /api/v1/data/health
  app.get('/api/v1/data/health', (_req, res) => {
    const validationResults = runQuantitativeValidationSuite();
    res.json({
      status: 'OK',
      operatingMode: 'OFFLINE_SYNTHETIC_RESEARCH',
      liveExecutionEnabled: false,
      feeds: INITIAL_CURRENCY_PAIRS.map((p) => ({
        pairId: p.id,
        source: p.sourceProvider,
        observationTimestamp: p.observationTimestamp,
        freshness: p.freshnessStatus,
      })),
      validationSuite: validationResults,
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoQuant Australia Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
