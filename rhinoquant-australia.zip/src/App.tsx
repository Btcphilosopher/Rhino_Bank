/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Activity,
  BarChart3,
  BookOpen,
  Calculator,
  Download,
  Globe,
  Layers,
  Lock,
  ShieldAlert,
  TrendingUp,
} from 'lucide-react';
import { AudMacroView } from './components/AudMacroView';
import { CarryMonitorView } from './components/CarryMonitorView';
import { FxPricingView } from './components/FxPricingView';
import { PortfolioView } from './components/PortfolioView';
import { ResearchDataIntegrityView } from './components/ResearchDataIntegrityView';
import { RiskLabView } from './components/RiskLabView';
import { StrategyLabView } from './components/StrategyLabView';
import { INITIAL_CURRENCY_PAIRS } from './domain/marketData';
import { evaluatePortfolio } from './domain/quantEngine';
import {
  CurrencyCode,
  CurrencyPairSpec,
  PortfolioPosition,
  RateInstrumentType,
  Tenor,
} from './domain/types';

export type WorkspaceScreen =
  | 'CARRY_MONITOR'
  | 'AUD_MACRO'
  | 'FX_PRICING'
  | 'PORTFOLIO'
  | 'RISK_LAB'
  | 'STRATEGY_LAB'
  | 'RESEARCH'
  | 'DATA_INTEGRITY';

const INITIAL_POSITIONS: PortfolioPosition[] = [
  {
    id: 'pos-audjpy-1',
    pairId: 'AUD/JPY',
    direction: 'LONG_AUD',
    hedgedMode: 'UNHEDGED_CARRY',
    notionalAud: 4_500_000,
    entrySpot: 98.85,
    currentSpot: 100.42,
    entryTimestamp: '2026-07-10',
    holdingDays: 90,
    fundingInstrument: 'OIS_CURVE',
    tenor: '3M',
    marginReqPct: 3.33,
    stopLossThresholdPct: -8.0,
    positionLimitAud: 15_000_000,
    dataProvenance: 'RBA F11 / WM Refinitiv Snapshot',
  },
  {
    id: 'pos-audchf-2',
    pairId: 'AUD/CHF',
    direction: 'LONG_AUD',
    hedgedMode: 'UNHEDGED_CARRY',
    notionalAud: 3_500_000,
    entrySpot: 0.5715,
    currentSpot: 0.5784,
    entryTimestamp: '2026-07-10',
    holdingDays: 90,
    fundingInstrument: 'OIS_CURVE',
    tenor: '3M',
    marginReqPct: 4.0,
    stopLossThresholdPct: -8.0,
    positionLimitAud: 15_000_000,
    dataProvenance: 'SNB / RBA Cross Matrix',
  },
  {
    id: 'pos-audeur-3',
    pairId: 'AUD/EUR',
    direction: 'LONG_AUD',
    hedgedMode: 'UNHEDGED_CARRY',
    notionalAud: 2_500_000,
    entrySpot: 0.612,
    currentSpot: 0.6168,
    entryTimestamp: '2026-07-10',
    holdingDays: 90,
    fundingInstrument: 'OIS_CURVE',
    tenor: '3M',
    marginReqPct: 3.33,
    stopLossThresholdPct: -8.0,
    positionLimitAud: 15_000_000,
    dataProvenance: 'ECB EuroFX / RBA Reference',
  },
  {
    id: 'pos-audsgd-4',
    pairId: 'AUD/SGD',
    direction: 'LONG_AUD',
    hedgedMode: 'FX_FORWARD_HEDGED',
    notionalAud: 2_000_000,
    entrySpot: 0.878,
    currentSpot: 0.8812,
    entryTimestamp: '2026-07-10',
    holdingDays: 90,
    fundingInstrument: 'OIS_CURVE',
    tenor: '3M',
    marginReqPct: 3.5,
    stopLossThresholdPct: -6.0,
    positionLimitAud: 15_000_000,
    dataProvenance: 'MAS SORA / RBA Reference',
  },
];

export default function App() {
  const [activeScreen, setActiveScreen] = useState<WorkspaceScreen>('CARRY_MONITOR');
  const [pairs, setPairs] = useState<CurrencyPairSpec[]>(INITIAL_CURRENCY_PAIRS);
  const [selectedInstrument, setSelectedInstrument] =
    useState<RateInstrumentType>('OIS_CURVE');
  const [selectedTenor, setSelectedTenor] = useState<Tenor>('3M');
  const [pricingPairId, setPricingPairId] = useState<string>('AUD/JPY');

  const [positions, setPositions] = useState<PortfolioPosition[]>(INITIAL_POSITIONS);
  const [totalEquityAud, setTotalEquityAud] = useState<number>(10_000_000);
  const [baseCurrency, setBaseCurrency] = useState<CurrencyCode>('AUD');

  const handleAddPair = (newPair: CurrencyPairSpec) => {
    setPairs((prev) => [...prev, newPair]);
  };

  const handleInspectPairInPricing = (pairId: string) => {
    setPricingPairId(pairId);
    setActiveScreen('FX_PRICING');
  };

  const handleAddPositionFromPair = (pairId: string) => {
    const pair = pairs.find((p) => p.id === pairId) || pairs[0];
    const newPos: PortfolioPosition = {
      id: `pos-${Date.now()}`,
      pairId: pair.id,
      direction: 'LONG_AUD',
      hedgedMode: 'UNHEDGED_CARRY',
      notionalAud: 2_500_000,
      entrySpot: pair.spot,
      currentSpot: pair.spot,
      entryTimestamp: '2026-10-09',
      holdingDays: 30,
      fundingInstrument: selectedInstrument,
      tenor: selectedTenor,
      marginReqPct: pair.marginRequirementPct,
      stopLossThresholdPct: -8.0,
      positionLimitAud: 15_000_000,
      dataProvenance: pair.sourceProvider,
    };
    setPositions((prev) => [...prev, newPos]);
    setActiveScreen('PORTFOLIO');
  };

  const handleExportQuantitativeReport = () => {
    const summary = evaluatePortfolio(positions, pairs, totalEquityAud, baseCurrency);
    const payload = {
      platform: 'RhinoQuant Australia — Institutional FX Carry & Risk Platform',
      generatedAt: '2026-10-09T06:00:00Z',
      operatingMode: 'OFFLINE_SYNTHETIC_RESEARCH_SIMULATION',
      liveTradingEnabled: false,
      baseCurrency,
      totalEquityAud,
      portfolioSummary: summary,
      universeCount: pairs.length,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rhinoquant_australia_report_${baseCurrency.toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const sidebarItems: {
    id: WorkspaceScreen;
    label: string;
    group: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    {
      id: 'CARRY_MONITOR',
      label: 'Carry Monitor',
      group: 'Carry Research',
      icon: TrendingUp,
    },
    {
      id: 'AUD_MACRO',
      label: 'AUD Macro',
      group: 'Carry Research',
      icon: Globe,
    },
    {
      id: 'FX_PRICING',
      label: 'FX Pricing (CIP)',
      group: 'Carry Research',
      icon: Calculator,
    },
    {
      id: 'PORTFOLIO',
      label: 'Portfolio Construction',
      group: 'Portfolio & Risk',
      icon: Layers,
    },
    {
      id: 'RISK_LAB',
      label: 'Risk & Unwind Lab',
      group: 'Portfolio & Risk',
      icon: ShieldAlert,
    },
    {
      id: 'STRATEGY_LAB',
      label: 'Strategy Backtest Lab',
      group: 'Historical & Econometrics',
      icon: BarChart3,
    },
    {
      id: 'RESEARCH',
      label: 'Econometric Research',
      group: 'Historical & Econometrics',
      icon: BookOpen,
    },
    {
      id: 'DATA_INTEGRITY',
      label: 'Data Integrity & Tests',
      group: 'Historical & Econometrics',
      icon: Activity,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#0B0F17] text-[#E2E8F0]">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-[#111723] border-b border-[#1E293B]">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#carry-monitor"
          onClick={(e) => {
            e.preventDefault();
            setActiveScreen('CARRY_MONITOR');
          }}
          className="text-base font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0 font-display"
        >
          RhinoQuant Australia
        </a>

        {/* Zone 2: 4–5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
          <button
            onClick={() => setActiveScreen('CARRY_MONITOR')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeScreen === 'CARRY_MONITOR' ||
              activeScreen === 'AUD_MACRO' ||
              activeScreen === 'FX_PRICING'
                ? 'text-slate-100 underline underline-offset-4 decoration-[#38BDF8]'
                : ''
            }`}
          >
            Carry Research
          </button>
          <button
            onClick={() => setActiveScreen('PORTFOLIO')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeScreen === 'PORTFOLIO'
                ? 'text-slate-100 underline underline-offset-4 decoration-[#38BDF8]'
                : ''
            }`}
          >
            Portfolio Construction
          </button>
          <button
            onClick={() => setActiveScreen('STRATEGY_LAB')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeScreen === 'STRATEGY_LAB'
                ? 'text-slate-100 underline underline-offset-4 decoration-[#38BDF8]'
                : ''
            }`}
          >
            Historical Research
          </button>
          <button
            onClick={() => setActiveScreen('RISK_LAB')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeScreen === 'RISK_LAB'
                ? 'text-slate-100 underline underline-offset-4 decoration-[#38BDF8]'
                : ''
            }`}
          >
            Risk Laboratory
          </button>
          <button
            onClick={() => setActiveScreen('DATA_INTEGRITY')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeScreen === 'RESEARCH' || activeScreen === 'DATA_INTEGRITY'
                ? 'text-slate-100 underline underline-offset-4 decoration-[#38BDF8]'
                : ''
            }`}
          >
            Quantitative Validation
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleExportQuantitativeReport}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-[#0B0F17] bg-[#38BDF8] rounded-md hover:bg-[#38BDF8]/90 transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            Export Research Snapshot
          </button>
        </div>
      </header>

      {/* Main Institutional Workspace Canvas */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Left Navigation Sidebar (8 Screens) */}
        <aside className="w-full lg:w-60 bg-[#111723] border-b lg:border-b-0 lg:border-r border-[#1E293B] p-4 flex flex-col justify-between shrink-0">
          <div className="space-y-4">
            <div>
              <div className="text-[11px] font-medium text-slate-400 px-2.5 mb-2">
                Terminal Workspaces
              </div>
              <div className="space-y-1">
                {sidebarItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveScreen(item.id)}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                        isActive
                          ? 'bg-[#1E293B] text-[#38BDF8] font-semibold'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-[#1E293B]/40'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quick Mandate & Economic Summary */}
            <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded-md space-y-2 text-xs">
              <div className="font-semibold text-slate-200 flex items-center justify-between">
                <span>Operating Mandate</span>
                <Lock className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="text-[11px] text-slate-400 leading-relaxed">
                Offline Research & Simulation Mode · Live Execution Disabled · Base Currency:{' '}
                <strong className="text-slate-200 font-mono">{baseCurrency}</strong>
              </div>
              <div className="pt-2 border-t border-[#1E293B] font-mono text-[11px] text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>RBA Target:</span>
                  <span className="text-slate-200">4.35%</span>
                </div>
                <div className="flex justify-between">
                  <span>AUD/JPY 3M OIS:</span>
                  <span className="text-emerald-400">+408 bps</span>
                </div>
                <div className="flex justify-between">
                  <span>AUD/CHF 3M OIS:</span>
                  <span className="text-emerald-400">+349 bps</span>
                </div>
              </div>
            </div>
          </div>

          <div className="hidden lg:block pt-4 border-t border-[#1E293B] text-[11px] text-slate-500 space-y-1">
            <div>RhinoQuant Australia</div>
            <div>Institutional FX Carry & Risk</div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-5 lg:p-6 overflow-y-auto max-w-[1600px]">
          {/* Contextual Workspace Header */}
          <div className="mb-5 flex flex-wrap items-center justify-between gap-4 border-b border-[#1E293B] pb-4">
            <div>
              <div className="text-xs text-slate-400">
                RhinoQuant Australia · Institutional Australian Dollar Carry Intelligence ·{' '}
                <span>{activeScreen.replace(/_/g, ' ')}</span>
              </div>
              <h1 className="text-xl font-bold text-slate-100 mt-0.5 tracking-tight">
                {activeScreen === 'CARRY_MONITOR' &&
                  'Australian Dollar Carry Monitor & Financing Friction Matrix'}
                {activeScreen === 'AUD_MACRO' &&
                  'Reserve Bank of Australia & Global Macro Monetary Comparison'}
                {activeScreen === 'FX_PRICING' &&
                  'Covered Interest Parity (CIP) Forward Pricing & Basis Diagnostics'}
                {activeScreen === 'PORTFOLIO' &&
                  'Multi-Currency Portfolio Construction, Optimisation & Attribution'}
                {activeScreen === 'RISK_LAB' &&
                  'Carry Unwind Stress Laboratory & Numerical Reverse Stress Solver'}
                {activeScreen === 'STRATEGY_LAB' &&
                  'Event-Time Historical Backtesting & Walk-Forward Strategy Lab'}
                {activeScreen === 'RESEARCH' &&
                  'Econometric Regression Diagnostics & Multi-Language Stack'}
                {activeScreen === 'DATA_INTEGRITY' &&
                  'Market Data Provenance, Freshness Policy & Quantitative Validation'}
              </h1>
            </div>

            <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
              <span>Universe: {pairs.length} Pairs</span>
              <span>·</span>
              <span>Positions: {positions.length}</span>
              <span>·</span>
              <span>Base: {baseCurrency}</span>
            </div>
          </div>

          {activeScreen === 'CARRY_MONITOR' && (
            <CarryMonitorView
              pairs={pairs}
              onAddPair={handleAddPair}
              selectedInstrument={selectedInstrument}
              onSelectInstrument={setSelectedInstrument}
              selectedTenor={selectedTenor}
              onSelectTenor={setSelectedTenor}
              onInspectPairInPricing={handleInspectPairInPricing}
              onAddPositionFromPair={handleAddPositionFromPair}
            />
          )}

          {activeScreen === 'AUD_MACRO' && <AudMacroView />}

          {activeScreen === 'FX_PRICING' && (
            <FxPricingView
              pairs={pairs}
              selectedPairId={pricingPairId}
              onSelectPairId={setPricingPairId}
            />
          )}

          {activeScreen === 'PORTFOLIO' && (
            <PortfolioView
              positions={positions}
              onUpdatePositions={setPositions}
              pairs={pairs}
              totalEquityAud={totalEquityAud}
              onUpdateEquityAud={setTotalEquityAud}
              baseCurrency={baseCurrency}
              onUpdateBaseCurrency={setBaseCurrency}
            />
          )}

          {activeScreen === 'RISK_LAB' && (
            <RiskLabView
              positions={positions}
              pairs={pairs}
              totalEquityAud={totalEquityAud}
              baseCurrency={baseCurrency}
            />
          )}

          {activeScreen === 'STRATEGY_LAB' && <StrategyLabView pairs={pairs} />}

          {(activeScreen === 'RESEARCH' || activeScreen === 'DATA_INTEGRITY') && (
            <ResearchDataIntegrityView
              pairs={pairs}
              subTab={activeScreen}
              onChangeSubTab={(tab) => setActiveScreen(tab)}
            />
          )}
        </main>
      </div>
    </div>
  );
}
