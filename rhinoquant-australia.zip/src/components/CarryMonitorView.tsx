import React, { useMemo, useState } from 'react';
import { ArrowUpDown, Plus, Info, AlertTriangle } from 'lucide-react';
import { CURRENCY_METADATA } from '../domain/marketData';
import { calculateCarrySignal, calculateForwardPricing } from '../domain/quantEngine';
import {
  CurrencyCode,
  CurrencyPairSpec,
  RateInstrumentType,
  Tenor,
} from '../domain/types';

interface CarryMonitorViewProps {
  pairs: CurrencyPairSpec[];
  onAddPair: (pair: CurrencyPairSpec) => void;
  selectedInstrument: RateInstrumentType;
  onSelectInstrument: (inst: RateInstrumentType) => void;
  selectedTenor: Tenor;
  onSelectTenor: (tenor: Tenor) => void;
  onInspectPairInPricing: (pairId: string) => void;
  onAddPositionFromPair: (pairId: string) => void;
}

type SortField =
  | 'grossCarryPct'
  | 'netCarryPct'
  | 'carryToVolRatio'
  | 'realisedVol3M'
  | 'stressLossUnwind10Pct'
  | 'differentialPercentile';

export const CarryMonitorView: React.FC<CarryMonitorViewProps> = ({
  pairs,
  onAddPair,
  selectedInstrument,
  onSelectInstrument,
  selectedTenor,
  onSelectTenor,
  onInspectPairInPricing,
  onAddPositionFromPair,
}) => {
  const [sortField, setSortField] = useState<SortField>('netCarryPct');
  const [sortAsc, setSortAsc] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPairId, setSelectedPairId] = useState<string>('AUD/JPY');
  const [showAddRegistryModal, setShowAddRegistryModal] = useState<boolean>(false);
  const [newQuoteCurrency, setNewQuoteCurrency] = useState<CurrencyCode>('CNH');

  const rows = useMemo(() => {
    const computed = pairs.map((pair) => {
      const signal = calculateCarrySignal(pair, selectedInstrument, selectedTenor);
      const fwd = calculateForwardPricing(pair, selectedTenor, selectedInstrument, 'CONTINUOUS');
      return { pair, signal, fwd };
    });

    const filtered = computed.filter((r) =>
      r.pair.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      CURRENCY_METADATA[r.pair.quote].name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    filtered.sort((a, b) => {
      let valA = 0;
      let valB = 0;
      if (sortField === 'realisedVol3M') {
        valA = a.pair.realisedVol3M;
        valB = b.pair.realisedVol3M;
      } else {
        valA = a.signal[sortField];
        valB = b.signal[sortField];
      }
      return sortAsc ? valA - valB : valB - valA;
    });

    return filtered;
  }, [pairs, selectedInstrument, selectedTenor, sortField, sortAsc, searchQuery]);

  const activeDetail = useMemo(
    () => rows.find((r) => r.pair.id === selectedPairId) || rows[0],
    [rows, selectedPairId]
  );

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  const availableAdditionalCurrencies: CurrencyCode[] = (['CNH', 'SEK', 'NOK'] as CurrencyCode[]).filter(
    (code) => !pairs.some((p) => p.quote === code)
  );

  const handleRegisterNewPair = () => {
    if (!newQuoteCurrency) return;
    const presetMap: Record<string, Partial<CurrencyPairSpec>> = {
      CNH: {
        spot: 4.7820,
        spotBid: 4.7805,
        spotAsk: 4.7835,
        pipMultiplier: 10000,
        observedForwardPoints3M: -285.0,
        crossCurrencyBasisBps: -26,
        financingSpreadBps: 28,
        marginRequirementPct: 5.0,
        rolloverCostBps: 12,
        slippageAssumptionBps: 6,
        realisedVol3M: 7.95,
        impliedVol3M: 8.40,
        recentReturn1M: 0.65,
        maxDrawdown3Y: -9.80,
        historicalDifferentialPercentile: 79,
      },
      SEK: {
        spot: 6.9840,
        spotBid: 6.9810,
        spotAsk: 6.9870,
        pipMultiplier: 10000,
        observedForwardPoints3M: -268.0,
        crossCurrencyBasisBps: -15,
        financingSpreadBps: 22,
        marginRequirementPct: 4.0,
        rolloverCostBps: 9,
        slippageAssumptionBps: 5,
        realisedVol3M: 8.85,
        impliedVol3M: 9.30,
        recentReturn1M: 0.42,
        maxDrawdown3Y: -10.50,
        historicalDifferentialPercentile: 68,
      },
      NOK: {
        spot: 7.2410,
        spotBid: 7.2375,
        spotAsk: 7.2445,
        pipMultiplier: 10000,
        observedForwardPoints3M: +14.0,
        crossCurrencyBasisBps: +4,
        financingSpreadBps: 24,
        marginRequirementPct: 4.0,
        rolloverCostBps: 10,
        slippageAssumptionBps: 5,
        realisedVol3M: 9.40,
        impliedVol3M: 9.95,
        recentReturn1M: -0.25,
        maxDrawdown3Y: -11.40,
        historicalDifferentialPercentile: 44,
      },
    };

    const preset = presetMap[newQuoteCurrency] || presetMap.CNH;
    const newPair: CurrencyPairSpec = {
      id: `AUD/${newQuoteCurrency}`,
      base: 'AUD',
      quote: newQuoteCurrency,
      spot: preset.spot!,
      spotBid: preset.spotBid!,
      spotAsk: preset.spotAsk!,
      pipMultiplier: preset.pipMultiplier!,
      observedForwardPoints3M: preset.observedForwardPoints3M!,
      crossCurrencyBasisBps: preset.crossCurrencyBasisBps!,
      financingSpreadBps: preset.financingSpreadBps!,
      marginRequirementPct: preset.marginRequirementPct!,
      rolloverCostBps: preset.rolloverCostBps!,
      slippageAssumptionBps: preset.slippageAssumptionBps!,
      liquidityScore: 78,
      realisedVol3M: preset.realisedVol3M!,
      impliedVol3M: preset.impliedVol3M!,
      recentReturn1M: preset.recentReturn1M!,
      recentDrawdown3M: -3.2,
      maxDrawdown3Y: preset.maxDrawdown3Y!,
      historicalDifferentialPercentile: preset.historicalDifferentialPercentile!,
      ironOreBeta: 0.24,
      chinaPmiBeta: 0.35,
      globalRiskVixBeta: -0.45,
      sourceProvider: 'RhinoQuant Custom Registry (Synthetic Research Feed)',
      observationTimestamp: '2026-10-09T06:00:00Z',
      freshnessStatus: 'OFFLINE_SYNTHETIC',
      customAdded: true,
    };

    onAddPair(newPair);
    setSelectedPairId(newPair.id);
    setShowAddRegistryModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Control Strip */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#111723] border border-[#1E293B] p-4 rounded-lg">
        <div className="flex flex-wrap items-center gap-6">
          <div>
            <label className="block text-xs text-slate-400 mb-1">Rate Curve / Financing Basis</label>
            <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-[#1E293B] rounded-md">
              {(
                [
                  { id: 'OIS_CURVE', label: 'OIS Curve' },
                  { id: 'POLICY_RATE', label: 'Policy Rate' },
                  { id: 'MONEY_MARKET', label: 'Money Market' },
                  { id: 'GOVT_YIELD', label: 'Govt Yield' },
                  { id: 'FX_SWAP_IMPLIED', label: 'FX Swap Implied' },
                ] as { id: RateInstrumentType; label: string }[]
              ).map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSelectInstrument(item.id)}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                    selectedInstrument === item.id
                      ? 'bg-[#38BDF8] text-[#0B0F17] font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Valuation Tenor</label>
            <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-[#1E293B] rounded-md">
              {(['ON', '1W', '1M', '3M', '6M', '1Y', '2Y'] as Tenor[]).map((t) => (
                <button
                  key={t}
                  onClick={() => onSelectTenor(t)}
                  className={`px-2.5 py-1 text-xs font-mono font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                    selectedTenor === t
                      ? 'bg-slate-200 text-slate-950 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter pair or currency..."
            className="px-3 py-1.5 text-xs bg-[#0B0F17] border border-[#1E293B] rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-[#38BDF8]"
          />
          {availableAdditionalCurrencies.length > 0 && (
            <button
              onClick={() => {
                setNewQuoteCurrency(availableAdditionalCurrencies[0]);
                setShowAddRegistryModal(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#1E293B] hover:bg-[#334155] text-slate-100 rounded-md transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              Register Currency Pair
            </button>
          )}
        </div>
      </div>

      {/* Add Registry Modal */}
      {showAddRegistryModal && (
        <div className="bg-[#111723] border border-[#38BDF8]/40 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-sm font-semibold text-slate-100">
              Expand Configurable AUD Currency Universe
            </h3>
            <p className="text-xs text-slate-400">
              Add a new quote currency with verified ACT/360 curve nodes, cross-currency basis, and margin schedules.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <select
              value={newQuoteCurrency}
              onChange={(e) => setNewQuoteCurrency(e.target.value as CurrencyCode)}
              className="px-3 py-1.5 text-xs bg-[#0B0F17] border border-[#1E293B] rounded text-slate-200 font-mono"
            >
              {availableAdditionalCurrencies.map((c) => (
                <option key={c} value={c}>
                  AUD/{c} — {CURRENCY_METADATA[c].name} ({CURRENCY_METADATA[c].centralBankCode} {CURRENCY_METADATA[c].policyRate.toFixed(2)}%)
                </option>
              ))}
            </select>
            <button
              onClick={handleRegisterNewPair}
              className="px-3 py-1.5 text-xs font-medium bg-[#38BDF8] text-[#0B0F17] rounded hover:bg-[#38BDF8]/90 transition-colors whitespace-nowrap shrink-0"
            >
              Confirm Registration
            </button>
            <button
              onClick={() => setShowAddRegistryModal(false)}
              className="px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors whitespace-nowrap shrink-0"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Main Currency-Pair Research Matrix */}
      <div className="bg-[#111723] border border-[#1E293B] rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">
              01. Australian Dollar Currency-Pair Carry Matrix ({selectedTenor} · {selectedInstrument.replace(/_/g, ' ')})
            </h2>
            <p className="text-xs text-slate-400">
              Quote Convention: S(AUD/Q) = units of quote currency Q per 1.00 AUD · Theoretical rate differentials are not guaranteed returns.
            </p>
          </div>
          <div className="text-xs text-slate-400 font-mono">
            AUD {selectedTenor} Rate: {rows[0]?.signal.rAud.toFixed(2)}% (ACT/365) · Snapshot: 2026-10-09 06:00 UTC
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#1E293B] bg-[#0B0F17]/60 text-[11px] font-medium text-slate-400">
                <th className="py-2.5 px-3">Pair (Base/Quote)</th>
                <th className="py-2.5 px-3 text-right">Spot S(A/Q)</th>
                <th className="py-2.5 px-3 text-right">Quote Rate</th>
                <th className="py-2.5 px-3 text-right">
                  <button
                    onClick={() => handleSort('grossCarryPct')}
                    className="inline-flex items-center gap-1 hover:text-slate-200"
                  >
                    Gross Diff (c)
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-2.5 px-3 text-right">Fwd Pts / Outright</th>
                <th className="py-2.5 px-3 text-right">Friction Drag</th>
                <th className="py-2.5 px-3 text-right">
                  <button
                    onClick={() => handleSort('netCarryPct')}
                    className="inline-flex items-center gap-1 hover:text-slate-200 text-slate-200"
                  >
                    Net Carry
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-2.5 px-3 text-right">
                  <button
                    onClick={() => handleSort('realisedVol3M')}
                    className="inline-flex items-center gap-1 hover:text-slate-200"
                  >
                    3M Vol
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-2.5 px-3 text-right">
                  <button
                    onClick={() => handleSort('carryToVolRatio')}
                    className="inline-flex items-center gap-1 hover:text-slate-200"
                  >
                    Carry / Vol
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-2.5 px-3 text-right">
                  <button
                    onClick={() => handleSort('differentialPercentile')}
                    className="inline-flex items-center gap-1 hover:text-slate-200"
                  >
                    Hist %ile
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-2.5 px-3 text-right">3Y Max DD</th>
                <th className="py-2.5 px-3 text-right">
                  <button
                    onClick={() => handleSort('stressLossUnwind10Pct')}
                    className="inline-flex items-center gap-1 hover:text-slate-200"
                  >
                    10d Unwind Stress
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B] text-xs font-mono tabular-nums">
              {rows.map(({ pair, signal, fwd }) => {
                const isSelected = pair.id === activeDetail?.pair.id;
                const decimals = pair.quote === 'JPY' ? 2 : 4;
                return (
                  <tr
                    key={pair.id}
                    onClick={() => setSelectedPairId(pair.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? 'bg-[#1E293B]/70' : 'hover:bg-[#1E293B]/30'
                    }`}
                  >
                    <td className="py-2.5 px-3 font-sans">
                      <div className="font-semibold text-slate-100">{pair.id}</div>
                      <div className="text-[11px] text-slate-400">
                        {CURRENCY_METADATA[pair.quote].centralBankCode} · {CURRENCY_METADATA[pair.quote].dayCount}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      {pair.spot.toFixed(decimals)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {signal.rFunding.toFixed(2)}%
                    </td>
                    <td
                      className={`py-2.5 px-3 text-right font-medium ${
                        signal.grossCarryPct > 0
                          ? 'text-emerald-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {signal.grossCarryPct >= 0 ? '+' : ''}
                      {signal.grossCarryPct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      <div>
                        {fwd.marketForwardPointsPips >= 0 ? '+' : ''}
                        {fwd.marketForwardPointsPips.toFixed(1)}p
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {fwd.marketOutrightForward.toFixed(decimals)}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right text-amber-400">
                      -{signal.totalFrictionPct.toFixed(2)}%
                    </td>
                    <td
                      className={`py-2.5 px-3 text-right font-semibold ${
                        signal.netCarryPct > 0.5
                          ? 'text-emerald-400'
                          : signal.netCarryPct > 0
                          ? 'text-slate-200'
                          : 'text-rose-400'
                      }`}
                    >
                      {signal.netCarryPct >= 0 ? '+' : ''}
                      {signal.netCarryPct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {pair.realisedVol3M.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span
                        className={
                          signal.carryToVolRatio >= 0.25
                            ? 'text-emerald-400 font-semibold'
                            : signal.carryToVolRatio > 0
                            ? 'text-slate-300'
                            : 'text-rose-400'
                        }
                      >
                        {signal.carryToVolRatio.toFixed(2)}x
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {signal.differentialPercentile}th
                    </td>
                    <td className="py-2.5 px-3 text-right text-rose-400">
                      {pair.maxDrawdown3Y.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-rose-400 font-medium">
                      {signal.stressLossUnwind10Pct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right font-sans">
                      <div className="inline-flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onInspectPairInPricing(pair.id);
                          }}
                          className="text-[11px] text-[#38BDF8] hover:underline whitespace-nowrap shrink-0"
                        >
                          CIP Curve
                        </button>
                        <span className="text-slate-600">·</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onAddPositionFromPair(pair.id);
                          }}
                          className="text-[11px] text-slate-300 hover:text-white hover:underline whitespace-nowrap shrink-0"
                        >
                          Allocate
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Pair Economic Decomposition & Friction Waterfall */}
      {activeDetail && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-100">
                  02. Yield Advantage Erosion & Financing Friction Waterfall ({activeDetail.pair.id})
                </h3>
                <p className="text-xs text-slate-400">
                  Explicit separation of theoretical policy/OIS rate differential from financing costs and market-structure drag.
                </p>
              </div>
              <div className="text-xs font-mono text-slate-400">
                Model {activeDetail.signal.modelVersion}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-1 font-mono tabular-nums">
              <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
                <div className="text-[11px] font-sans text-slate-400">AUD {selectedTenor} Yield (r_AUD)</div>
                <div className="text-base font-semibold text-slate-100 mt-1">
                  +{activeDetail.signal.rAud.toFixed(2)}%
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  RBA / AUD {selectedInstrument}
                </div>
              </div>

              <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
                <div className="text-[11px] font-sans text-slate-400">
                  {activeDetail.pair.quote} Funding Cost (-r_Q)
                </div>
                <div className="text-base font-semibold text-amber-400 mt-1">
                  -{activeDetail.signal.rFunding.toFixed(2)}%
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {CURRENCY_METADATA[activeDetail.pair.quote].centralBankCode} Benchmark
                </div>
              </div>

              <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
                <div className="text-[11px] font-sans text-slate-400">
                  Theoretical Gross Carry (c)
                </div>
                <div
                  className={`text-base font-semibold mt-1 ${
                    activeDetail.signal.grossCarryPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {activeDetail.signal.grossCarryPct >= 0 ? '+' : ''}
                  {activeDetail.signal.grossCarryPct.toFixed(2)}%
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Before market frictions
                </div>
              </div>

              <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
                <div className="text-[11px] font-sans text-slate-400">Financing & Basis Spread</div>
                <div className="text-base font-semibold text-amber-400 mt-1">
                  -{(activeDetail.pair.financingSpreadBps + Math.max(0, -activeDetail.pair.crossCurrencyBasisBps * 0.5)).toFixed(0)} bps
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  CIP Basis: {activeDetail.pair.crossCurrencyBasisBps} bps
                </div>
              </div>

              <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
                <div className="text-[11px] font-sans text-slate-400">Rollover, Bid-Ask & Slippage</div>
                <div className="text-base font-semibold text-amber-400 mt-1">
                  -{(
                    activeDetail.pair.rolloverCostBps +
                    activeDetail.pair.slippageAssumptionBps +
                    ((activeDetail.pair.spotAsk - activeDetail.pair.spotBid) / activeDetail.pair.spot) * 10000
                  ).toFixed(1)} bps
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Margin Req: {activeDetail.pair.marginRequirementPct.toFixed(2)}%
                </div>
              </div>

              <div className="p-3 bg-[#0B0F17] border border-[#38BDF8]/40 rounded">
                <div className="text-[11px] font-sans text-[#38BDF8]">Estimated Net Carry</div>
                <div
                  className={`text-base font-bold mt-1 ${
                    activeDetail.signal.netCarryPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {activeDetail.signal.netCarryPct >= 0 ? '+' : ''}
                  {activeDetail.signal.netCarryPct.toFixed(2)}%
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Carry/Vol: {activeDetail.signal.carryToVolRatio.toFixed(2)}x
                </div>
              </div>
            </div>

            <div className="pt-2 space-y-2">
              <div className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                Signal Diagnostics & Risk Warnings
              </div>
              <div className="space-y-1.5 text-xs text-slate-400">
                {activeDetail.signal.warnings.map((w, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-amber-400">·</span>
                    <span>{w}</span>
                  </div>
                ))}
                <div className="flex items-start gap-2">
                  <span className="text-[#38BDF8]">·</span>
                  <span>
                    Breakeven AUD Spot Threshold (1Y): {activeDetail.pair.id} can depreciate at most{' '}
                    <strong className="text-slate-200 font-mono">
                      {Math.max(0, activeDetail.signal.netCarryPct).toFixed(2)}%
                    </strong>{' '}
                    (to{' '}
                    <strong className="text-slate-200 font-mono">
                      {(
                        activeDetail.pair.spot *
                        (1 - Math.max(0, activeDetail.signal.netCarryPct) / 100)
                      ).toFixed(activeDetail.pair.quote === 'JPY' ? 2 : 4)}
                    </strong>
                    ) before adverse FX translation wipes out 12 months of net carry accrual.
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
            <div className="border-b border-[#1E293B] pb-3">
              <h3 className="text-sm font-semibold text-slate-100">
                03. Macro & Global Risk Factor Sensitivities ({activeDetail.pair.id})
              </h3>
              <p className="text-xs text-slate-400">
                Empirical factor betas estimated from time-aligned historical observations.
              </p>
            </div>

            <div className="space-y-3 text-xs font-mono tabular-nums">
              <div className="flex items-center justify-between py-2 border-b border-[#1E293B]/60">
                <span className="font-sans text-slate-300">Seaborne Iron Ore Beta (per 10% move)</span>
                <span className="text-slate-100 font-semibold">
                  +{(activeDetail.pair.ironOreBeta * 10).toFixed(2)}% AUD
                </span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-[#1E293B]/60">
                <span className="font-sans text-slate-300">China Manufacturing PMI Beta (per +1 pt)</span>
                <span className="text-slate-100 font-semibold">
                  +{activeDetail.pair.chinaPmiBeta.toFixed(2)}% AUD
                </span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-[#1E293B]/60">
                <span className="font-sans text-slate-300">Global Risk-Off VIX Spike Beta (+10 VIX pts)</span>
                <span className="text-rose-400 font-semibold">
                  {(activeDetail.pair.globalRiskVixBeta * 5).toFixed(2)}% AUD
                </span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-[#1E293B]/60">
                <span className="font-sans text-slate-300">3M Realised vs Implied Volatility</span>
                <span className="text-slate-200">
                  {activeDetail.pair.realisedVol3M.toFixed(2)}% / {activeDetail.pair.impliedVol3M.toFixed(2)}%
                </span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="font-sans text-slate-300">Data Source Provenance</span>
                <span className="text-slate-400 font-sans text-right">
                  {activeDetail.pair.sourceProvider}
                </span>
              </div>
            </div>

            <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded text-xs text-slate-400 flex items-start gap-2">
              <Info className="w-4 h-4 text-[#38BDF8] shrink-0 mt-0.5" />
              <span>
                Note on Carry-to-Volatility: A high ratio ({activeDetail.signal.carryToVolRatio.toFixed(2)}x) reflects calm recent realised volatility and does not protect against skewed tail losses during crowded carry unwinds.
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
