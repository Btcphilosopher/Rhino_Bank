import React, { useMemo, useState } from 'react';
import { Plus, Trash2, CheckCircle2, Sliders } from 'lucide-react';
import { computeOptimalWeights, evaluatePortfolio } from '../domain/quantEngine';
import {
  AllocationMethod,
  CurrencyCode,
  CurrencyPairSpec,
  PortfolioPosition,
} from '../domain/types';

interface PortfolioViewProps {
  positions: PortfolioPosition[];
  onUpdatePositions: (positions: PortfolioPosition[]) => void;
  pairs: CurrencyPairSpec[];
  totalEquityAud: number;
  onUpdateEquityAud: (eq: number) => void;
  baseCurrency: CurrencyCode;
  onUpdateBaseCurrency: (ccy: CurrencyCode) => void;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({
  positions,
  onUpdatePositions,
  pairs,
  totalEquityAud,
  onUpdateEquityAud,
  baseCurrency,
  onUpdateBaseCurrency,
}) => {
  const [allocationMethod, setAllocationMethod] = useState<AllocationMethod>('MEAN_VARIANCE_OPT');
  const [riskAversionLambda, setRiskAversionLambda] = useState<number>(2.5);
  const [targetGrossAud, setTargetGrossAud] = useState<number>(12_000_000);
  const [newPairId, setNewPairId] = useState<string>('AUD/EUR');
  const [newHedgedMode, setNewHedgedMode] = useState<'UNHEDGED_CARRY' | 'FX_FORWARD_HEDGED'>(
    'UNHEDGED_CARRY'
  );

  const analytics = useMemo(
    () => evaluatePortfolio(positions, pairs, totalEquityAud, baseCurrency),
    [positions, pairs, totalEquityAud, baseCurrency]
  );

  const handleApplyOptimisation = () => {
    const updated = computeOptimalWeights(
      positions,
      pairs,
      allocationMethod,
      riskAversionLambda,
      targetGrossAud
    );
    onUpdatePositions(updated);
  };

  const handleAddPosition = () => {
    const pair = pairs.find((p) => p.id === newPairId) || pairs[0];
    const newPos: PortfolioPosition = {
      id: `pos-${Date.now()}`,
      pairId: pair.id,
      direction: 'LONG_AUD',
      hedgedMode: newHedgedMode,
      notionalAud: 2_500_000,
      entrySpot: Number((pair.spot * 0.992).toFixed(pair.quote === 'JPY' ? 2 : 4)),
      currentSpot: pair.spot,
      entryTimestamp: '2026-07-15',
      holdingDays: 90,
      fundingInstrument: 'OIS_CURVE',
      tenor: '3M',
      marginReqPct: pair.marginRequirementPct,
      stopLossThresholdPct: -8.0,
      positionLimitAud: 15_000_000,
      dataProvenance: pair.sourceProvider,
    };
    onUpdatePositions([...positions, newPos]);
  };

  const handleRemovePosition = (id: string) => {
    onUpdatePositions(positions.filter((p) => p.id !== id));
  };

  const handleToggleHedgedMode = (id: string) => {
    onUpdatePositions(
      positions.map((p) =>
        p.id === id
          ? {
              ...p,
              hedgedMode:
                p.hedgedMode === 'UNHEDGED_CARRY'
                  ? 'FX_FORWARD_HEDGED'
                  : 'UNHEDGED_CARRY',
            }
          : p
      )
    );
  };

  const handleChangeNotional = (id: string, val: number) => {
    onUpdatePositions(
      positions.map((p) =>
        p.id === id ? { ...p, notionalAud: Math.max(100_000, val) } : p
      )
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Portfolio Configuration & Optimiser Bar */}
      <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-6">
          <div>
            <label className="block text-xs text-slate-400 mb-1">Accounting Base Currency</label>
            <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-[#1E293B] rounded">
              {(['AUD', 'USD', 'JPY', 'EUR', 'CHF'] as CurrencyCode[]).map((ccy) => (
                <button
                  key={ccy}
                  onClick={() => onUpdateBaseCurrency(ccy)}
                  className={`px-2.5 py-1 text-xs font-mono font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                    baseCurrency === ccy
                      ? 'bg-[#38BDF8] text-[#0B0F17] font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {ccy}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Portfolio Equity (AUD)</label>
            <input
              type="number"
              step={1000000}
              value={totalEquityAud}
              onChange={(e) => onUpdateEquityAud(Math.max(1_000_000, Number(e.target.value)))}
              className="px-3 py-1.5 text-xs font-mono bg-[#0B0F17] border border-[#1E293B] rounded text-slate-100 w-36 text-right"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Allocation Optimiser: max_w (w^T μ - λ w^T Σ w)
            </label>
            <div className="flex items-center gap-2">
              <select
                value={allocationMethod}
                onChange={(e) => setAllocationMethod(e.target.value as AllocationMethod)}
                className="px-3 py-1.5 text-xs bg-[#0B0F17] border border-[#1E293B] rounded text-slate-100"
              >
                <option value="MEAN_VARIANCE_OPT">Covariance-Aware Mean-Variance (Ledoit-Wolf)</option>
                <option value="RISK_BUDGET">Carry-to-Volatility Risk Budget</option>
                <option value="EQUAL_RISK">Equal Risk Contribution (Inverse Vol)</option>
                <option value="VOLATILITY_TARGET">Volatility Targeting</option>
                <option value="EQUAL_WEIGHT">Equal Notional Weight</option>
              </select>

              <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
                <span>λ={riskAversionLambda.toFixed(1)}</span>
                <input
                  type="range"
                  min={0.5}
                  max={6.0}
                  step={0.5}
                  value={riskAversionLambda}
                  onChange={(e) => setRiskAversionLambda(Number(e.target.value))}
                  className="w-20 accent-[#38BDF8]"
                />
              </div>

              <button
                onClick={handleApplyOptimisation}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#38BDF8] text-[#0B0F17] rounded hover:bg-[#38BDF8]/90 transition-colors whitespace-nowrap shrink-0"
              >
                <Sliders className="w-3.5 h-3.5" />
                Run Allocation Solver
              </button>
            </div>
          </div>
        </div>

        {/* Add Position Quick Bar */}
        <div className="flex items-center gap-2">
          <select
            value={newPairId}
            onChange={(e) => setNewPairId(e.target.value)}
            className="px-2.5 py-1.5 text-xs font-mono bg-[#0B0F17] border border-[#1E293B] rounded text-slate-200"
          >
            {pairs.map((p) => (
              <option key={p.id} value={p.id}>
                {p.id}
              </option>
            ))}
          </select>
          <select
            value={newHedgedMode}
            onChange={(e) => setNewHedgedMode(e.target.value as any)}
            className="px-2.5 py-1.5 text-xs bg-[#0B0F17] border border-[#1E293B] rounded text-slate-200"
          >
            <option value="UNHEDGED_CARRY">Outright Unhedged Carry</option>
            <option value="FX_FORWARD_HEDGED">FX Forward Hedged Alternative</option>
          </select>
          <button
            onClick={handleAddPosition}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-[#1E293B] hover:bg-[#334155] text-slate-100 rounded transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Position
          </button>
        </div>
      </div>

      {/* KPI Summary Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 font-mono tabular-nums">
        <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4">
          <div className="text-xs font-sans text-slate-400">Gross Exposure ({baseCurrency})</div>
          <div className="text-lg font-semibold text-slate-100 mt-1">
            {Math.round(analytics.grossExposureBase).toLocaleString()} {baseCurrency}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Leverage: {analytics.effectiveLeverage.toFixed(2)}x Equity
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4">
          <div className="text-xs font-sans text-slate-400">Net AUD Exposure ({baseCurrency})</div>
          <div className="text-lg font-semibold text-[#38BDF8] mt-1">
            {Math.round(analytics.netAudExposureBase).toLocaleString()} {baseCurrency}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Excludes forward-hedged legs
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4">
          <div className="text-xs font-sans text-slate-400">Est. Annual Net Carry</div>
          <div className="text-lg font-semibold text-emerald-400 mt-1">
            +{Math.round(analytics.estimatedAnnualNetCarryBase).toLocaleString()} {baseCurrency}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Gross: +{Math.round(analytics.estimatedAnnualGrossCarryBase).toLocaleString()}
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4">
          <div className="text-xs font-sans text-slate-400">Portfolio Vol & Concentration</div>
          <div className="text-lg font-semibold text-slate-100 mt-1">
            {analytics.portfolioVolAnnualPct.toFixed(2)}% ann.
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            HHI Concentration: {analytics.herfindahlConcentration.toFixed(2)}
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4">
          <div className="text-xs font-sans text-slate-400">Margin Utilisation</div>
          <div
            className={`text-lg font-semibold mt-1 ${
              analytics.marginUtilisationPct > 50 ? 'text-amber-400' : 'text-slate-100'
            }`}
          >
            {analytics.marginUtilisationPct.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            {Math.round(analytics.marginUtilisedBase).toLocaleString()} {baseCurrency} posted
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4">
          <div className="text-xs font-sans text-slate-400">Daily VaR (99%) / ES (97.5%)</div>
          <div className="text-lg font-semibold text-rose-400 mt-1">
            -{Math.round(analytics.var99DailyBase).toLocaleString()} {baseCurrency}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            ES: -{Math.round(analytics.expectedShortfall975Base).toLocaleString()} {baseCurrency}
          </div>
        </div>
      </div>

      {/* Positions Table */}
      <div className="bg-[#111723] border border-[#1E293B] rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">
              01. Active Carry Positions & Hedged Alternative Comparison (Valued in {baseCurrency})
            </h2>
            <p className="text-xs text-slate-400">
              Toggle any position between Outright Unhedged Carry and FX Forward Hedged to verify how spot delta and CIP basis alter return attribution.
            </p>
          </div>
          <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Base-Currency P&L Reconciled (Error: {analytics.attribution.reconciliationErrorBps.toFixed(4)} bps)
          </div>
        </div>

        {positions.length === 0 ? (
          <div className="p-8 text-center space-y-3">
            <div className="text-sm text-slate-300">No active positions in portfolio.</div>
            <button
              onClick={handleAddPosition}
              className="px-4 py-2 text-xs font-medium bg-[#38BDF8] text-[#0B0F17] rounded hover:bg-[#38BDF8]/90"
            >
              Initialize Default AUD Carry Position
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#1E293B] bg-[#0B0F17]/60 text-[11px] text-slate-400">
                  <th className="py-2.5 px-3">Pair / Direction</th>
                  <th className="py-2.5 px-3">Exposure Structure</th>
                  <th className="py-2.5 px-3 text-right">Notional (AUD)</th>
                  <th className="py-2.5 px-3 text-right">Weight</th>
                  <th className="py-2.5 px-3 text-right">Entry / Current Spot</th>
                  <th className="py-2.5 px-3 text-right">Interest Carry ({baseCurrency})</th>
                  <th className="py-2.5 px-3 text-right">FX Spot P&L ({baseCurrency})</th>
                  <th className="py-2.5 px-3 text-right">Fwd / Rollover ({baseCurrency})</th>
                  <th className="py-2.5 px-3 text-right">Costs & Spread ({baseCurrency})</th>
                  <th className="py-2.5 px-3 text-right">Net P&L ({baseCurrency})</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B] text-xs font-mono tabular-nums">
                {analytics.positionValuations.map((pv) => {
                  const { position } = pv;
                  const isHedged = position.hedgedMode === 'FX_FORWARD_HEDGED';
                  const decimals = position.pairId.endsWith('JPY') ? 2 : 4;
                  return (
                    <tr key={position.id} className="hover:bg-[#1E293B]/30">
                      <td className="py-2.5 px-3 font-sans">
                        <div className="font-semibold text-slate-100">{position.pairId}</div>
                        <div className="text-[11px] text-slate-400">
                          {position.direction.replace('_', ' ')} · {position.holdingDays}d held
                        </div>
                      </td>
                      <td className="py-2.5 px-3 font-sans">
                        <button
                          onClick={() => handleToggleHedgedMode(position.id)}
                          className={`px-2 py-1 text-[11px] font-medium rounded border transition-colors whitespace-nowrap shrink-0 ${
                            isHedged
                              ? 'border-amber-500/40 bg-amber-500/10 text-amber-300'
                              : 'border-[#38BDF8]/40 bg-[#38BDF8]/10 text-[#38BDF8]'
                          }`}
                        >
                          {isHedged ? 'FX Forward Hedged' : 'Outright Unhedged Carry'}
                        </button>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <input
                          type="number"
                          step={500000}
                          value={position.notionalAud}
                          onChange={(e) =>
                            handleChangeNotional(position.id, Number(e.target.value))
                          }
                          className="w-28 px-2 py-1 text-right bg-[#0B0F17] border border-[#1E293B] rounded text-slate-100"
                        />
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-300">
                        {pv.weightPct.toFixed(1)}%
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-300">
                        {position.entrySpot.toFixed(decimals)} → {position.currentSpot.toFixed(decimals)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-emerald-400">
                        {pv.grossCarryBase >= 0 ? '+' : ''}
                        {Math.round(pv.grossCarryBase).toLocaleString()}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right ${
                          pv.spotPnlBase > 0
                            ? 'text-emerald-400'
                            : pv.spotPnlBase < 0
                            ? 'text-rose-400'
                            : 'text-slate-400'
                        }`}
                      >
                        {pv.spotPnlBase >= 0 ? '+' : ''}
                        {Math.round(pv.spotPnlBase).toLocaleString()}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right ${
                          pv.rolloverPnlBase >= 0 ? 'text-emerald-400' : 'text-amber-400'
                        }`}
                      >
                        {pv.rolloverPnlBase >= 0 ? '+' : ''}
                        {Math.round(pv.rolloverPnlBase).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-amber-400">
                        {Math.round(pv.fundingCostBase + pv.txCostBase).toLocaleString()}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-semibold ${
                          pv.netPnlBase >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {pv.netPnlBase >= 0 ? '+' : ''}
                        {Math.round(pv.netPnlBase).toLocaleString()} ({pv.returnPct.toFixed(2)}%)
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => handleRemovePosition(position.id)}
                          className="p-1 text-slate-400 hover:text-rose-400 transition-colors"
                          title="Remove position"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 6-Component Return Attribution Reconciliation Panel */}
      <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1E293B] pb-3 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">
              02. Portfolio Return Attribution Decomposition (% of Portfolio Equity)
            </h3>
            <p className="text-xs text-slate-400">
              Strict 6-component reconciliation without double-counting interest accruals and forward swap points.
            </p>
          </div>
          <div className="text-xs font-mono text-slate-400">
            Estimator: Ledoit-Wolf Shrinkage Covariance (α=0.30)
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 font-mono tabular-nums">
          <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
            <div className="text-[11px] font-sans text-slate-400">1. Interest / Carry</div>
            <div className="text-base font-semibold text-emerald-400 mt-1">
              +{analytics.attribution.interestCarryContributionPct.toFixed(2)}%
            </div>
          </div>
          <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
            <div className="text-[11px] font-sans text-slate-400">2. FX Spot Translation</div>
            <div
              className={`text-base font-semibold mt-1 ${
                analytics.attribution.fxSpotContributionPct >= 0
                  ? 'text-emerald-400'
                  : 'text-rose-400'
              }`}
            >
              {analytics.attribution.fxSpotContributionPct >= 0 ? '+' : ''}
              {analytics.attribution.fxSpotContributionPct.toFixed(2)}%
            </div>
          </div>
          <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
            <div className="text-[11px] font-sans text-slate-400">3. Fwd & Rollover</div>
            <div
              className={`text-base font-semibold mt-1 ${
                analytics.attribution.forwardRolloverContributionPct >= 0
                  ? 'text-emerald-400'
                  : 'text-amber-400'
              }`}
            >
              {analytics.attribution.forwardRolloverContributionPct >= 0 ? '+' : ''}
              {analytics.attribution.forwardRolloverContributionPct.toFixed(2)}%
            </div>
          </div>
          <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
            <div className="text-[11px] font-sans text-slate-400">4. Funding Adjustment</div>
            <div className="text-base font-semibold text-amber-400 mt-1">
              {analytics.attribution.fundingAdjustmentPct.toFixed(2)}%
            </div>
          </div>
          <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
            <div className="text-[11px] font-sans text-slate-400">5. Trading Costs</div>
            <div className="text-base font-semibold text-amber-400 mt-1">
              {analytics.attribution.tradingCostsPct.toFixed(2)}%
            </div>
          </div>
          <div className="p-3 bg-[#0B0F17] border border-[#38BDF8]/40 rounded">
            <div className="text-[11px] font-sans text-[#38BDF8]">6. Total Realised Return</div>
            <div
              className={`text-base font-bold mt-1 ${
                analytics.attribution.totalRealisedReturnPct >= 0
                  ? 'text-emerald-400'
                  : 'text-rose-400'
              }`}
            >
              {analytics.attribution.totalRealisedReturnPct >= 0 ? '+' : ''}
              {analytics.attribution.totalRealisedReturnPct.toFixed(2)}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
