import React, { useState } from 'react';
import { CURRENCY_METADATA } from '../domain/marketData';
import { calculateForwardPricing } from '../domain/quantEngine';
import {
  CompoundingMethod,
  CurrencyPairSpec,
  RateInstrumentType,
  Tenor,
} from '../domain/types';

interface FxPricingViewProps {
  pairs: CurrencyPairSpec[];
  selectedPairId: string;
  onSelectPairId: (id: string) => void;
}

export const FxPricingView: React.FC<FxPricingViewProps> = ({
  pairs,
  selectedPairId,
  onSelectPairId,
}) => {
  const [compounding, setCompounding] = useState<CompoundingMethod>('CONTINUOUS');
  const [instrument, setInstrument] = useState<RateInstrumentType>('OIS_CURVE');
  const [customNotionalAud, setCustomNotionalAud] = useState<number>(5_000_000);

  const activePair = pairs.find((p) => p.id === selectedPairId) || pairs[0];
  const decimals = activePair.quote === 'JPY' ? 2 : 4;
  const tenors: Tenor[] = ['ON', '1W', '1M', '3M', '6M', '1Y', '2Y'];

  const tenorCurve = tenors.map((t) =>
    calculateForwardPricing(activePair, t, instrument, compounding)
  );

  const selected3M = tenorCurve.find((c) => c.tenor === '3M') || tenorCurve[0];

  return (
    <div className="space-y-6">
      {/* Configuration Header */}
      <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-6">
          <div>
            <label className="block text-xs text-slate-400 mb-1">Currency Pair (S_A/Q)</label>
            <select
              value={activePair.id}
              onChange={(e) => onSelectPairId(e.target.value)}
              className="px-3 py-1.5 text-xs font-mono bg-[#0B0F17] border border-[#1E293B] rounded text-slate-100"
            >
              {pairs.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.id} — Spot {p.spot.toFixed(p.quote === 'JPY' ? 2 : 4)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Interest Rate Curve</label>
            <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-[#1E293B] rounded">
              {(
                [
                  { id: 'OIS_CURVE', label: 'OIS Curve' },
                  { id: 'MONEY_MARKET', label: 'Money Market' },
                  { id: 'GOVT_YIELD', label: 'Govt Yield' },
                  { id: 'POLICY_RATE', label: 'Policy Rate' },
                ] as { id: RateInstrumentType; label: string }[]
              ).map((inst) => (
                <button
                  key={inst.id}
                  onClick={() => setInstrument(inst.id)}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                    instrument === inst.id
                      ? 'bg-[#38BDF8] text-[#0B0F17] font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {inst.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Compounding Convention</label>
            <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-[#1E293B] rounded">
              {(['CONTINUOUS', 'SIMPLE', 'ANNUAL'] as CompoundingMethod[]).map((c) => (
                <button
                  key={c}
                  onClick={() => setCompounding(c)}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                    compounding === c
                      ? 'bg-slate-200 text-slate-950 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs text-slate-400 mb-1">Notional Sizing (AUD)</label>
          <input
            type="number"
            step={500000}
            min={100000}
            value={customNotionalAud}
            onChange={(e) => setCustomNotionalAud(Math.max(100000, Number(e.target.value)))}
            className="px-3 py-1.5 text-xs font-mono bg-[#0B0F17] border border-[#1E293B] rounded text-slate-100 w-36 text-right"
          />
        </div>
      </div>

      {/* Covered Interest Parity Reference Specification */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#1E293B] pb-3">
            <h2 className="text-sm font-semibold text-slate-100">
              01. Covered Interest Parity (CIP) Reference Engine
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Exact mathematical pricing distinguishing theoretical parity forwards from observed market swap points.
            </p>
          </div>

          <div className="p-3.5 bg-[#0B0F17] border border-[#1E293B] rounded font-mono text-xs space-y-2">
            <div className="text-slate-400">Continuous Reference Formulation:</div>
            <div className="text-sm text-[#38BDF8] font-semibold">
              F_(A/Q) = S_(A/Q) · exp[(r_Q - r_A) · T]
            </div>
            <div className="text-[11px] text-slate-400 pt-1 border-t border-[#1E293B]">
              Where S_({activePair.id}) = {activePair.spot.toFixed(decimals)} {activePair.quote} per 1 AUD · Day Count AUD = {CURRENCY_METADATA.AUD.dayCount} · Day Count {activePair.quote} = {CURRENCY_METADATA[activePair.quote].dayCount}
            </div>
          </div>

          <div className="space-y-2.5 text-xs font-mono tabular-nums">
            <div className="flex justify-between py-1.5 border-b border-[#1E293B]/60">
              <span className="font-sans text-slate-400">3M Theoretical Outright Forward</span>
              <span className="text-slate-100 font-semibold">
                {selected3M.theoreticalOutrightForward.toFixed(decimals)} ({selected3M.theoreticalForwardPointsPips.toFixed(1)} pips)
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-[#1E293B]/60">
              <span className="font-sans text-slate-400">3M Observed Market Outright Forward</span>
              <span className="text-[#38BDF8] font-semibold">
                {selected3M.marketOutrightForward.toFixed(decimals)} ({selected3M.marketForwardPointsPips.toFixed(1)} pips)
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-[#1E293B]/60">
              <span className="font-sans text-slate-400">Cross-Currency Basis Deviation</span>
              <span className="text-amber-400 font-semibold">
                {activePair.crossCurrencyBasisBps} bps
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-[#1E293B]/60">
              <span className="font-sans text-slate-400">3M Cash-Flow Swap Settlement ({customNotionalAud.toLocaleString()} AUD)</span>
              <span className="text-emerald-400 font-semibold">
                {Math.round(
                  customNotionalAud *
                    ((-selected3M.marketForwardPointsPips / activePair.pipMultiplier) /
                      activePair.spot)
                ).toLocaleString()}{' '}
                AUD
              </span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="font-sans text-slate-400">Bid / Ask Spread ({activePair.id})</span>
              <span className="text-slate-300">
                {activePair.spotBid.toFixed(decimals)} / {activePair.spotAsk.toFixed(decimals)} (
                {((activePair.spotAsk - activePair.spotBid) * activePair.pipMultiplier).toFixed(1)} pips)
              </span>
            </div>
          </div>
        </div>

        {/* Term Structure of Forward Points Table */}
        <div className="lg:col-span-7 bg-[#111723] border border-[#1E293B] rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-[#1E293B] flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-100">
                02. Term Structure of Forward Points & Implied Financing ({activePair.id})
              </h2>
              <p className="text-xs text-slate-400">
                Comparison of theoretical CIP forwards vs observed market swap points across maturities.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#1E293B] bg-[#0B0F17]/60 text-[11px] text-slate-400">
                  <th className="py-2.5 px-3">Tenor</th>
                  <th className="py-2.5 px-3 text-right">Year Frac (T)</th>
                  <th className="py-2.5 px-3 text-right">r_AUD</th>
                  <th className="py-2.5 px-3 text-right">r_{activePair.quote}</th>
                  <th className="py-2.5 px-3 text-right">Theoretical Fwd</th>
                  <th className="py-2.5 px-3 text-right">Theo Pts (pips)</th>
                  <th className="py-2.5 px-3 text-right">Market Outright</th>
                  <th className="py-2.5 px-3 text-right">Market Pts (pips)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B] text-xs font-mono tabular-nums">
                {tenorCurve.map((node) => (
                  <tr key={node.tenor} className="hover:bg-[#1E293B]/30">
                    <td className="py-2.5 px-3 font-semibold text-slate-100">{node.tenor}</td>
                    <td className="py-2.5 px-3 text-right text-slate-400">
                      {node.yearFraction.toFixed(4)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      {node.rAudPct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {node.rQuotePct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      {node.theoreticalOutrightForward.toFixed(decimals)}
                    </td>
                    <td
                      className={`py-2.5 px-3 text-right ${
                        node.theoreticalForwardPointsPips < 0 ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {node.theoreticalForwardPointsPips >= 0 ? '+' : ''}
                      {node.theoreticalForwardPointsPips.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#38BDF8] font-medium">
                      {node.marketOutrightForward.toFixed(decimals)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200 font-semibold">
                      {node.marketForwardPointsPips >= 0 ? '+' : ''}
                      {node.marketForwardPointsPips.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-3 bg-[#0B0F17]/50 border-t border-[#1E293B] text-xs text-slate-400">
            Note: Negative forward points in {activePair.id} indicate that AUD trades at a forward discount because r_AUD &gt; r_{activePair.quote}. Buying AUD forward (or rolling a short {activePair.quote} funding leg) locks in positive forward points accrual when spot remains unchanged.
          </div>
        </div>
      </div>
    </div>
  );
};
