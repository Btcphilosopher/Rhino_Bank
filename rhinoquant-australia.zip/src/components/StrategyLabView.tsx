import React, { useMemo, useState } from 'react';
import { Play, ShieldCheck } from 'lucide-react';
import { runHistoricalBacktest } from '../domain/quantEngine';
import { BacktestConfig, CurrencyPairSpec, StrategyFamily } from '../domain/types';

interface StrategyLabViewProps {
  pairs: CurrencyPairSpec[];
}

export const StrategyLabView: React.FC<StrategyLabViewProps> = ({ pairs }) => {
  const [config, setConfig] = useState<BacktestConfig>({
    strategyFamily: 'CARRY_TO_VOL_RANK',
    eligiblePairs: ['AUD/JPY', 'AUD/CHF', 'AUD/EUR', 'AUD/SGD', 'AUD/CAD'],
    rebalanceSchedule: 'MONTHLY',
    targetVolPct: 10.0,
    topNPairs: 3,
    includeTransactionCosts: true,
    txCostMultiplier: 1.0,
    outOfSampleSplitPct: 70,
    preventLookAheadLagDays: 1,
  });

  const report = useMemo(() => runHistoricalBacktest(config, pairs), [config, pairs]);

  const toggleEligiblePair = (pairId: string) => {
    const exists = config.eligiblePairs.includes(pairId);
    if (exists && config.eligiblePairs.length <= 1) return;
    setConfig({
      ...config,
      eligiblePairs: exists
        ? config.eligiblePairs.filter((id) => id !== pairId)
        : [...config.eligiblePairs, pairId],
    });
  };

  // SVG Chart helper
  const chartWidth = 840;
  const chartHeight = 250;
  const padX = 42;
  const padY = 24;

  const allVals = report.series.flatMap((pt) => [
    pt.cumulativeTotalPct,
    pt.cumulativeCarryPct,
    pt.cumulativeSpotPct,
    pt.benchmarkEqualWeightPct,
  ]);
  const minVal = Math.min(-10, ...allVals);
  const maxVal = Math.max(25, ...allVals);

  const toX = (idx: number) =>
    padX + (idx / Math.max(1, report.series.length - 1)) * (chartWidth - padX * 2);
  const toY = (val: number) =>
    chartHeight -
    padY -
    ((val - minVal) / Math.max(1, maxVal - minVal)) * (chartHeight - padY * 2);

  const buildPath = (getter: (pt: (typeof report.series)[0]) => number) =>
    report.series
      .map((pt, idx) => `${idx === 0 ? 'M' : 'L'} ${toX(idx).toFixed(1)} ${toY(getter(pt)).toFixed(1)}`)
      .join(' ');

  const oosIndex = report.series.findIndex((s) => s.isOutOfSample);
  const oosX = oosIndex >= 0 ? toX(oosIndex) : chartWidth;

  return (
    <div className="space-y-6">
      {/* Strategy Configuration Bar */}
      <div className="bg-[#111723] border border-[#1E293B] rounded-lg p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-6">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Strategy Family</label>
              <select
                value={config.strategyFamily}
                onChange={(e) =>
                  setConfig({ ...config, strategyFamily: e.target.value as StrategyFamily })
                }
                className="px-3 py-1.5 text-xs bg-[#0B0F17] border border-[#1E293B] rounded text-slate-100"
              >
                <option value="CARRY_TO_VOL_RANK">Carry-to-Volatility Ranked Carry</option>
                <option value="RATE_DIFF_RANK">Simple Rate-Differential Ranking</option>
                <option value="VOL_TARGETED_CARRY">Volatility-Targeted Carry (Dynamic Sizing)</option>
                <option value="REGIME_FILTERED_CARRY">Risk-Regime-Filtered Carry (Unwind Dampener)</option>
                <option value="MOMENTUM_FILTERED_CARRY">Trend / Momentum-Filtered Carry</option>
                <option value="DIVERSIFIED_PORTFOLIO_CARRY">Portfolio-Level Diversified Carry</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Rebalance Schedule</label>
              <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-[#1E293B] rounded">
                {(['WEEKLY', 'MONTHLY', 'QUARTERLY'] as const).map((sched) => (
                  <button
                    key={sched}
                    onClick={() => setConfig({ ...config, rebalanceSchedule: sched })}
                    className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                      config.rebalanceSchedule === sched
                        ? 'bg-[#38BDF8] text-[#0B0F17] font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {sched}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">
                Transaction Cost Stress ({config.txCostMultiplier.toFixed(1)}x)
              </label>
              <div className="flex items-center gap-2">
                {[0.0, 1.0, 1.5, 2.5].map((mult) => (
                  <button
                    key={mult}
                    onClick={() =>
                      setConfig({
                        ...config,
                        includeTransactionCosts: mult > 0,
                        txCostMultiplier: mult === 0 ? 1.0 : mult,
                      })
                    }
                    className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors whitespace-nowrap shrink-0 ${
                      (mult === 0 && !config.includeTransactionCosts) ||
                      (config.includeTransactionCosts && config.txCostMultiplier === mult)
                        ? 'border-[#38BDF8] bg-[#38BDF8]/15 text-[#38BDF8] font-semibold'
                        : 'border-[#1E293B] bg-[#0B0F17] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mult === 0 ? '0x (Gross)' : `${mult.toFixed(1)}x Friction`}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">
                In-Sample / Out-of-Sample Split ({config.outOfSampleSplitPct}% IS)
              </label>
              <input
                type="range"
                min={50}
                max={85}
                step={5}
                value={config.outOfSampleSplitPct}
                onChange={(e) =>
                  setConfig({ ...config, outOfSampleSplitPct: Number(e.target.value) })
                }
                className="w-32 accent-[#38BDF8]"
              />
            </div>
          </div>

          <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" />
            Event-Time Lag Enforced (t-{config.preventLookAheadLagDays}d · Zero Look-Ahead)
          </div>
        </div>

        {/* Eligible Pairs Selector */}
        <div className="pt-2 border-t border-[#1E293B] flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 mr-2">Eligible Universe:</span>
          {pairs.map((p) => {
            const active = config.eligiblePairs.includes(p.id);
            return (
              <button
                key={p.id}
                onClick={() => toggleEligiblePair(p.id)}
                className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'border-[#38BDF8]/50 bg-[#38BDF8]/15 text-slate-100 font-medium'
                    : 'border-[#1E293B] bg-[#0B0F17] text-slate-500 hover:text-slate-300'
                }`}
              >
                {p.id}
              </button>
            );
          })}
        </div>
      </div>

      {/* Backtest KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 font-mono tabular-nums">
        <div className="bg-[#111723] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] font-sans text-slate-400">Cumulative Return</div>
          <div
            className={`text-base font-bold mt-1 ${
              report.cumulativeReturnPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {report.cumulativeReturnPct >= 0 ? '+' : ''}
            {report.cumulativeReturnPct.toFixed(2)}%
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] font-sans text-slate-400">Annualised Return</div>
          <div className="text-base font-semibold text-slate-100 mt-1">
            {report.annualisedReturnPct >= 0 ? '+' : ''}
            {report.annualisedReturnPct.toFixed(2)}%
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] font-sans text-slate-400">Annualised Vol</div>
          <div className="text-base font-semibold text-slate-200 mt-1">
            {report.annualisedVolPct.toFixed(2)}%
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] font-sans text-slate-400">Sharpe / Sortino</div>
          <div className="text-base font-semibold text-[#38BDF8] mt-1">
            {report.sharpeRatio.toFixed(2)} / {report.sortinoRatio.toFixed(2)}
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] font-sans text-slate-400">Max Drawdown</div>
          <div className="text-base font-semibold text-rose-400 mt-1">
            {report.maxDrawdownPct.toFixed(2)}% ({report.maxDrawdownDurationDays}d)
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] font-sans text-slate-400">IS vs OOS Sharpe</div>
          <div className="text-base font-semibold text-slate-100 mt-1">
            {report.inSampleSharpe.toFixed(2)} vs {report.outOfSampleSharpe.toFixed(2)}
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] font-sans text-slate-400">Carry Contribution</div>
          <div className="text-base font-semibold text-emerald-400 mt-1">
            +{(
              report.attribution.interestCarryContributionPct +
              report.attribution.forwardRolloverContributionPct
            ).toFixed(2)}%
          </div>
        </div>

        <div className="bg-[#111723] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] font-sans text-slate-400">Tx & Funding Drag</div>
          <div className="text-base font-semibold text-amber-400 mt-1">
            {(
              report.attribution.tradingCostsPct + report.attribution.fundingAdjustmentPct
            ).toFixed(2)}%
          </div>
        </div>
      </div>

      {/* Cumulative Return Attribution Chart & Regime Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1E293B] pb-3">
            <div>
              <h2 className="text-sm font-semibold text-slate-100">
                01. Historical Cumulative Return Decomposition & Out-of-Sample Walk-Forward (36M)
              </h2>
              <p className="text-xs text-slate-400">
                Decomposes strategy cumulative return into Carry Accrual vs FX Spot Translation vs Equal-Weight Benchmark.
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="text-[#38BDF8] font-medium">— Net Total Return</span>
              <span className="text-emerald-400 font-medium">-- Cumulative Carry</span>
              <span className="text-amber-400 font-medium">· · FX Spot Component</span>
              <span className="text-slate-400">— Benchmark</span>
            </div>
          </div>

          <div className="w-full overflow-x-auto">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-64 bg-[#0B0F17] border border-[#1E293B] rounded"
            >
              {/* Out of sample shaded region */}
              <rect
                x={oosX}
                y={padY}
                width={Math.max(0, chartWidth - padX - oosX)}
                height={chartHeight - padY * 2}
                fill="#38BDF8"
                fillOpacity="0.06"
              />
              <line
                x1={oosX}
                y1={padY}
                x2={oosX}
                y2={chartHeight - padY}
                stroke="#38BDF8"
                strokeDasharray="4 4"
                strokeWidth="1"
              />
              <text
                x={oosX + 6}
                y={padY + 14}
                fill="#38BDF8"
                fontSize="10"
                fontFamily="JetBrains Mono, monospace"
              >
                OUT-OF-SAMPLE ({100 - config.outOfSampleSplitPct}%)
              </text>

              {/* Zero horizontal reference line */}
              <line
                x1={padX}
                y1={toY(0)}
                x2={chartWidth - padX}
                y2={toY(0)}
                stroke="#334155"
                strokeWidth="1"
              />

              {/* Benchmark path */}
              <path
                d={buildPath((p) => p.benchmarkEqualWeightPct)}
                fill="none"
                stroke="#64748B"
                strokeWidth="1.5"
              />

              {/* Cumulative Carry path */}
              <path
                d={buildPath((p) => p.cumulativeCarryPct)}
                fill="none"
                stroke="#10B981"
                strokeWidth="1.75"
                strokeDasharray="5 3"
              />

              {/* Cumulative Spot path */}
              <path
                d={buildPath((p) => p.cumulativeSpotPct)}
                fill="none"
                stroke="#F59E0B"
                strokeWidth="1.5"
                strokeDasharray="2 3"
              />

              {/* Net Total Return path */}
              <path
                d={buildPath((p) => p.cumulativeTotalPct)}
                fill="none"
                stroke="#38BDF8"
                strokeWidth="2.5"
              />

              {/* Y-Axis labels */}
              {[minVal, 0, Math.round(maxVal / 2), Math.round(maxVal)].map((v, i) => (
                <text
                  key={i}
                  x={6}
                  y={toY(v) + 3}
                  fill="#94A3B8"
                  fontSize="10"
                  fontFamily="JetBrains Mono, monospace"
                >
                  {v >= 0 ? `+${v.toFixed(0)}%` : `${v.toFixed(0)}%`}
                </text>
              ))}
            </svg>
          </div>
        </div>

        {/* Regime-Conditioned Performance & Robustness Diagnostics */}
        <div className="lg:col-span-4 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#1E293B] pb-3">
            <h3 className="text-sm font-semibold text-slate-100">
              02. Regime-Conditioned Performance
            </h3>
            <p className="text-xs text-slate-400">
              Separating calm carry accrual months from crowded FX unwind episodes.
            </p>
          </div>

          <div className="border border-[#1E293B] rounded overflow-hidden">
            <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
              <thead>
                <tr className="bg-[#0B0F17] border-b border-[#1E293B] text-[11px] text-slate-400">
                  <th className="py-2 px-2.5">Market Regime</th>
                  <th className="py-2 px-2.5 text-right">Months</th>
                  <th className="py-2 px-2.5 text-right">Ann. Ret</th>
                  <th className="py-2 px-2.5 text-right">Win %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]">
                {report.regimePerformance.map((rp, idx) => (
                  <tr key={idx}>
                    <td className="py-2 px-2.5 font-sans text-slate-200">{rp.regime}</td>
                    <td className="py-2 px-2.5 text-right text-slate-300">{rp.observations}</td>
                    <td
                      className={`py-2 px-2.5 text-right font-semibold ${
                        rp.annualisedReturnPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {rp.annualisedReturnPct >= 0 ? '+' : ''}
                      {rp.annualisedReturnPct.toFixed(1)}%
                    </td>
                    <td className="py-2 px-2.5 text-right text-slate-300">
                      {rp.winRatePct.toFixed(0)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-3.5 bg-[#0B0F17] border border-[#1E293B] rounded space-y-2 text-xs text-slate-400">
            <div className="font-semibold text-slate-200">
              Robustness & Survivorship Disclosure
            </div>
            <p>
              Annualisation convention: 12 monthly observations per year. Signals are lagged by {config.preventLookAheadLagDays} trading day after official publication timestamps to eliminate look-ahead bias.
            </p>
            <p className="text-amber-300/90">
              Historical Sharpe ({report.sharpeRatio.toFixed(2)}) is sensitive to the frequency of crowded carry unwind months and must not be extrapolated as a guaranteed return.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
