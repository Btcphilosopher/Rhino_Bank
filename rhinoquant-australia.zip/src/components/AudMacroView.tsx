import React, { useState } from 'react';
import {
  COMMODITY_MACRO_SERIES,
  CURRENCY_METADATA,
  MACRO_CALENDAR_FEED,
} from '../domain/marketData';
import { CurrencyCode, Tenor } from '../domain/types';

export const AudMacroView: React.FC = () => {
  const [comparisonBank, setComparisonBank] = useState<CurrencyCode>('JPY');
  const [calendarFilter, setCalendarFilter] = useState<'ALL' | 'PUBLISHED' | 'SCHEDULED'>('ALL');

  const tenors: Tenor[] = ['ON', '1W', '1M', '3M', '6M', '1Y', '2Y'];
  const rba = CURRENCY_METADATA.AUD;
  const comp = CURRENCY_METADATA[comparisonBank];

  const centralBanksList: CurrencyCode[] = [
    'AUD',
    'JPY',
    'CHF',
    'USD',
    'EUR',
    'GBP',
    'CAD',
    'NZD',
    'SGD',
  ];

  const filteredCalendar = MACRO_CALENDAR_FEED.filter((item) =>
    calendarFilter === 'ALL' ? true : item.status === calendarFilter
  );

  return (
    <div className="space-y-6">
      {/* RBA Official Monetary Policy vs Market-Implied Expectations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#1E293B] pb-3">
            <h2 className="text-sm font-semibold text-slate-100">
              01. Reserve Bank of Australia (RBA) Monetary Policy Monitor
            </h2>
            <p className="text-xs text-slate-400">
              Strict separation of Official RBA Cash Rate Target from OIS Market-Implied Rate Expectations.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 font-mono tabular-nums">
            <div className="p-3.5 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">
                Official RBA Cash Rate Target
              </div>
              <div className="text-xl font-bold text-slate-100 mt-1">
                {rba.policyRate.toFixed(2)}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Source: RBA Statistical Table A2
              </div>
            </div>

            <div className="p-3.5 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">
                1Y ASX / OIS Implied Cash Rate
              </div>
              <div className="text-xl font-bold text-[#38BDF8] mt-1">
                {rba.curve['1Y'].oisRate.toFixed(2)}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Implied 12M Change: -21 bps
              </div>
            </div>

            <div className="p-3.5 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">
                ABS Monthly CPI Indicator (YoY)
              </div>
              <div className="text-base font-semibold text-amber-400 mt-1">
                {rba.inflationYoY.toFixed(1)}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                RBA Target Band: 2.0% – 3.0%
              </div>
            </div>

            <div className="p-3.5 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">
                ABS Unemployment Rate
              </div>
              <div className="text-base font-semibold text-slate-200 mt-1">
                {rba.unemploymentRate.toFixed(1)}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Next RBA Board: {rba.nextMeetingDate}
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-[#0B0F17] border border-[#1E293B] rounded text-xs space-y-1.5">
            <div className="font-semibold text-slate-200">
              Latest Official RBA Monetary Policy Statement Extract
            </div>
            <p className="text-slate-400 leading-relaxed">
              “Underlying inflation remains above the midpoint of the 2–3 per cent target range. The Board remains resolute in its determination to return inflation to target and will do what is necessary to achieve that outcome.”
            </p>
          </div>
        </div>

        {/* Short-End Yield Curve Cross-Country Comparison */}
        <div className="lg:col-span-7 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1E293B] pb-3">
            <div>
              <h2 className="text-sm font-semibold text-slate-100">
                02. Short-End OIS & Govt Yield Curve Differential (RBA vs {comp.centralBankCode})
              </h2>
              <p className="text-xs text-slate-400">
                Matched-maturity comparison across ON to 2Y tenors.
              </p>
            </div>
            <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-[#1E293B] rounded">
              {(['JPY', 'CHF', 'USD', 'EUR', 'GBP', 'CAD', 'NZD', 'SGD'] as CurrencyCode[]).map(
                (code) => (
                  <button
                    key={code}
                    onClick={() => setComparisonBank(code)}
                    className={`px-2 py-1 text-xs font-mono rounded transition-colors whitespace-nowrap shrink-0 ${
                      comparisonBank === code
                        ? 'bg-[#38BDF8] text-[#0B0F17] font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {code}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
              <thead>
                <tr className="bg-[#0B0F17]/60 border-b border-[#1E293B] text-[11px] text-slate-400">
                  <th className="py-2 px-3">Tenor</th>
                  <th className="py-2 px-3 text-right">AUD OIS (%)</th>
                  <th className="py-2 px-3 text-right">AUD Govt (%)</th>
                  <th className="py-2 px-3 text-right">{comparisonBank} OIS (%)</th>
                  <th className="py-2 px-3 text-right">{comparisonBank} Govt (%)</th>
                  <th className="py-2 px-3 text-right">OIS Spread (AUD - {comparisonBank})</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]">
                {tenors.map((t) => {
                  const audNode = rba.curve[t];
                  const compNode = comp.curve[t];
                  const spreadBps = Math.round((audNode.oisRate - compNode.oisRate) * 100);
                  return (
                    <tr key={t} className="hover:bg-[#1E293B]/30">
                      <td className="py-2 px-3 font-semibold text-slate-100">{t}</td>
                      <td className="py-2 px-3 text-right text-slate-200">
                        {audNode.oisRate.toFixed(2)}%
                      </td>
                      <td className="py-2 px-3 text-right text-slate-400">
                        {audNode.govtYield.toFixed(2)}%
                      </td>
                      <td className="py-2 px-3 text-right text-slate-200">
                        {compNode.oisRate.toFixed(2)}%
                      </td>
                      <td className="py-2 px-3 text-right text-slate-400">
                        {compNode.govtYield.toFixed(2)}%
                      </td>
                      <td
                        className={`py-2 px-3 text-right font-semibold ${
                          spreadBps >= 0 ? 'text-emerald-400' : 'text-amber-400'
                        }`}
                      >
                        {spreadBps >= 0 ? '+' : ''}
                        {spreadBps} bps
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Global Central Bank Comparison Matrix */}
      <div className="bg-[#111723] border border-[#1E293B] rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-[#1E293B]">
          <h2 className="text-sm font-semibold text-slate-100">
            03. International Central Bank Monetary Conditions Comparison
          </h2>
          <p className="text-xs text-slate-400">
            Comparing RBA against BOJ, SNB, Fed, ECB, BOE, BOC, RBNZ, and MAS using consistent maturity conventions.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
            <thead>
              <tr className="bg-[#0B0F17]/60 border-b border-[#1E293B] text-[11px] text-slate-400">
                <th className="py-2.5 px-3">Jurisdiction / Central Bank</th>
                <th className="py-2.5 px-3 text-right">Official Policy Rate</th>
                <th className="py-2.5 px-3 text-right">3M OIS</th>
                <th className="py-2.5 px-3 text-right">1Y OIS</th>
                <th className="py-2.5 px-3 text-right">AUD 3M OIS Advantage</th>
                <th className="py-2.5 px-3 text-right">CPI Inflation (YoY)</th>
                <th className="py-2.5 px-3 text-right">Unemployment</th>
                <th className="py-2.5 px-3 text-right">Day Count</th>
                <th className="py-2.5 px-3 text-right">Next Meeting</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]">
              {centralBanksList.map((code) => {
                const cb = CURRENCY_METADATA[code];
                const diff3M = rba.curve['3M'].oisRate - cb.curve['3M'].oisRate;
                return (
                  <tr key={code} className="hover:bg-[#1E293B]/30">
                    <td className="py-2.5 px-3 font-sans">
                      <span className="font-semibold text-slate-100">{cb.code}</span>
                      <span className="text-slate-400"> · {cb.centralBank} ({cb.centralBankCode})</span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-100 font-semibold">
                      {cb.policyRate.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {cb.curve['3M'].oisRate.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {cb.curve['1Y'].oisRate.toFixed(2)}%
                    </td>
                    <td
                      className={`py-2.5 px-3 text-right font-semibold ${
                        code === 'AUD'
                          ? 'text-slate-500'
                          : diff3M >= 0
                          ? 'text-emerald-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {code === 'AUD'
                        ? '—'
                        : `${diff3M >= 0 ? '+' : ''}${(diff3M * 100).toFixed(0)} bps`}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {cb.inflationYoY.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {cb.unemploymentRate.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-400">{cb.dayCount}</td>
                    <td className="py-2.5 px-3 text-right text-slate-300">{cb.nextMeetingDate}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Commodity & China Factor Monitor + Economic Calendar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#1E293B] pb-3">
            <h3 className="text-sm font-semibold text-slate-100">
              04. Commodity & China Terms-of-Trade Monitor (Non-Deterministic Explanatory Factors)
            </h3>
            <p className="text-xs text-slate-400">
              Time-aligned monthly observations of Iron Ore (62% Fe CFR), Copper, China Manufacturing PMI, and AUD/JPY.
            </p>
          </div>

          <div className="overflow-x-auto max-h-64">
            <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
              <thead>
                <tr className="bg-[#0B0F17] border-b border-[#1E293B] text-[11px] text-slate-400">
                  <th className="py-2 px-2.5">Month</th>
                  <th className="py-2 px-2.5 text-right">Iron Ore ($/t)</th>
                  <th className="py-2 px-2.5 text-right">Met Coal ($/t)</th>
                  <th className="py-2 px-2.5 text-right">China PMI</th>
                  <th className="py-2 px-2.5 text-right">AUD/JPY</th>
                  <th className="py-2 px-2.5 text-right">AUD/USD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]">
                {COMMODITY_MACRO_SERIES.slice(-7).map((row) => (
                  <tr key={row.month} className="hover:bg-[#1E293B]/30">
                    <td className="py-2 px-2.5 text-slate-200">{row.month}</td>
                    <td className="py-2 px-2.5 text-right text-slate-200">
                      ${row.ironOreUsdT.toFixed(1)}
                    </td>
                    <td className="py-2 px-2.5 text-right text-slate-300">
                      ${row.coalUsdT.toFixed(1)}
                    </td>
                    <td
                      className={`py-2 px-2.5 text-right ${
                        row.chinaPmi >= 50 ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {row.chinaPmi.toFixed(1)}
                    </td>
                    <td className="py-2 px-2.5 text-right text-[#38BDF8]">
                      {row.audJpy.toFixed(2)}
                    </td>
                    <td className="py-2 px-2.5 text-right text-slate-200">
                      {row.audUsd.toFixed(4)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="text-[11px] text-slate-400">
            Analytical Note: Rolling 12M OLS R² between Iron Ore log-returns and AUD/USD is 0.41 (SE ±0.11). Commodity movements represent explanatory variables with wide confidence intervals, not deterministic predictors.
          </div>
        </div>

        <div className="lg:col-span-6 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-100">
                05. Macroeconomic Release & Central-Bank Calendar
              </h3>
              <p className="text-xs text-slate-400">
                Event-time aligned schedule (AEST / UTC) distinguishing published outcomes from pending releases.
              </p>
            </div>
            <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-[#1E293B] rounded">
              {(['ALL', 'PUBLISHED', 'SCHEDULED'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setCalendarFilter(st)}
                  className={`px-2 py-1 text-[11px] font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                    calendarFilter === st
                      ? 'bg-[#38BDF8] text-[#0B0F17] font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
              <thead>
                <tr className="bg-[#0B0F17] border-b border-[#1E293B] text-[11px] text-slate-400">
                  <th className="py-2 px-2.5">Date / Time</th>
                  <th className="py-2 px-2.5">Agency / Event</th>
                  <th className="py-2 px-2.5 text-right">Actual</th>
                  <th className="py-2 px-2.5 text-right">Consensus</th>
                  <th className="py-2 px-2.5 text-right">Previous</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]">
                {filteredCalendar.map((ev) => (
                  <tr key={ev.id} className="hover:bg-[#1E293B]/30">
                    <td className="py-2 px-2.5">
                      <div className="text-slate-200">{ev.date}</div>
                      <div className="text-[10px] text-slate-500">
                        {ev.timeAest} · {ev.timeUtc}
                      </div>
                    </td>
                    <td className="py-2 px-2.5 font-sans">
                      <div className="text-slate-100 font-medium">{ev.event}</div>
                      <div className="text-[11px] text-slate-400">
                        {ev.jurisdiction} · {ev.agency}
                      </div>
                    </td>
                    <td
                      className={`py-2 px-2.5 text-right font-semibold ${
                        ev.status === 'PUBLISHED' ? 'text-[#38BDF8]' : 'text-slate-500'
                      }`}
                    >
                      {ev.actual}
                    </td>
                    <td className="py-2 px-2.5 text-right text-slate-300">{ev.consensus}</td>
                    <td className="py-2 px-2.5 text-right text-slate-400">{ev.previous}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
