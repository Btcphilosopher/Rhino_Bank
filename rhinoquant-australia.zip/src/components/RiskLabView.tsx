import React, { useMemo, useState } from 'react';
import { AlertOctagon, Calculator, ShieldAlert } from 'lucide-react';
import { STRESS_SCENARIOS } from '../domain/marketData';
import { runStressScenario, solveReverseStressTest } from '../domain/quantEngine';
import {
  CurrencyCode,
  CurrencyPairSpec,
  PortfolioPosition,
} from '../domain/types';

interface RiskLabViewProps {
  positions: PortfolioPosition[];
  pairs: CurrencyPairSpec[];
  totalEquityAud: number;
  baseCurrency: CurrencyCode;
}

export const RiskLabView: React.FC<RiskLabViewProps> = ({
  positions,
  pairs,
  totalEquityAud,
  baseCurrency,
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('FUNDING_RALLY');
  const [reverseTargetLossPct, setReverseTargetLossPct] = useState<number>(10);
  const [reverseFundingShare, setReverseFundingShare] = useState<number>(0.45);

  const allStressResults = useMemo(
    () =>
      STRESS_SCENARIOS.map((scen) =>
        runStressScenario(scen, positions, pairs, totalEquityAud, baseCurrency)
      ),
    [positions, pairs, totalEquityAud, baseCurrency]
  );

  const activeStress = useMemo(
    () =>
      allStressResults.find((r) => r.scenario.id === selectedScenarioId) ||
      allStressResults[0],
    [allStressResults, selectedScenarioId]
  );

  const reverseSolution = useMemo(
    () =>
      solveReverseStressTest(
        reverseTargetLossPct,
        positions,
        pairs,
        totalEquityAud,
        baseCurrency,
        reverseFundingShare
      ),
    [reverseTargetLossPct, positions, pairs, totalEquityAud, baseCurrency, reverseFundingShare]
  );

  return (
    <div className="space-y-6">
      {/* Top 10 Scenarios Matrix */}
      <div className="bg-[#111723] border border-[#1E293B] rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">
              01. Carry Unwind & Stress Laboratory — 10 Institutional Scenarios (Valued in {baseCurrency})
            </h2>
            <p className="text-xs text-slate-400">
              Explicit separation of Historical Unwind Analogues from Hypothetical Parametric Stress Tests. Click any scenario to inspect pair-level dislocations.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#1E293B] bg-[#0B0F17]/60 text-[11px] text-slate-400">
                <th className="py-2.5 px-3">Scenario Name</th>
                <th className="py-2.5 px-3">Classification</th>
                <th className="py-2.5 px-3 text-right">Horizon</th>
                <th className="py-2.5 px-3 text-right">AUD Spot Shock</th>
                <th className="py-2.5 px-3 text-right">Spread Mult</th>
                <th className="py-2.5 px-3 text-right">Spot Loss ({baseCurrency})</th>
                <th className="py-2.5 px-3 text-right">Carry Accrual</th>
                <th className="py-2.5 px-3 text-right">Liquidity Drag</th>
                <th className="py-2.5 px-3 text-right">Est. Net P&L ({baseCurrency})</th>
                <th className="py-2.5 px-3 text-right">Equity Drawdown</th>
                <th className="py-2.5 px-3 text-right">Post-Shock Margin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B] text-xs font-mono tabular-nums">
              {allStressResults.map((res) => {
                const { scenario } = res;
                const isSelected = scenario.id === activeStress.scenario.id;
                return (
                  <tr
                    key={scenario.id}
                    onClick={() => setSelectedScenarioId(scenario.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? 'bg-[#1E293B]/70' : 'hover:bg-[#1E293B]/30'
                    }`}
                  >
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-100">
                      {scenario.name}
                    </td>
                    <td className="py-2.5 px-3 font-sans text-[11px] text-slate-400">
                      {scenario.isHistoricalEvent ? 'Historical Event Analogue' : 'Hypothetical Stress'} · {scenario.correlationRegime === 'CROWDED_UNWIND_090' ? 'ρ=0.90' : 'Normal ρ'}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {scenario.horizonDays}d
                    </td>
                    <td className="py-2.5 px-3 text-right text-rose-400">
                      {scenario.audSpotShockPct.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-amber-400">
                      {scenario.spreadWideningMultiplier.toFixed(1)}x
                    </td>
                    <td className="py-2.5 px-3 text-right text-rose-400">
                      {Math.round(res.spotShockLossBase).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-emerald-400">
                      +{Math.round(res.carryAccrualDuringHorizonBase).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-amber-400">
                      {Math.round(res.liquidityExecutionDragBase).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-semibold text-rose-400">
                      {Math.round(res.estimatedPnlBase).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-rose-400">
                      {res.estimatedReturnPct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span
                        className={
                          res.marginCallTriggered
                            ? 'text-rose-400 font-semibold'
                            : 'text-slate-300'
                        }
                      >
                        {res.postShockMarginUtilPct.toFixed(1)}%
                        {res.marginCallTriggered ? ' (BREACH)' : ''}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Scenario Detail & Reverse Stress Testing Solver */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Selected Scenario Deep Dive */}
        <div className="lg:col-span-6 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#1E293B] pb-3 flex items-start justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                02. Scenario Decomposition: {activeStress.scenario.name}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {activeStress.scenario.description}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 font-mono tabular-nums text-xs">
            <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">Post-Shock Equity</div>
              <div className="text-sm font-semibold text-slate-100 mt-1">
                {Math.round(activeStress.postShockEquityBase).toLocaleString()} {baseCurrency}
              </div>
            </div>
            <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">Post-Shock Leverage</div>
              <div className="text-sm font-semibold text-amber-400 mt-1">
                {activeStress.postShockLeverage.toFixed(2)}x
              </div>
            </div>
            <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">Rate Diff Shock</div>
              <div className="text-sm font-semibold text-rose-400 mt-1">
                {activeStress.scenario.rateDiffChangeBps} bps
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-medium text-slate-300">
              Position-Level Stress Valuation ({baseCurrency})
            </div>
            <div className="border border-[#1E293B] rounded overflow-hidden">
              <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
                <thead>
                  <tr className="bg-[#0B0F17] border-b border-[#1E293B] text-[11px] text-slate-400">
                    <th className="py-2 px-3">Pair</th>
                    <th className="py-2 px-3 text-right">Shocked Spot</th>
                    <th className="py-2 px-3 text-right">Position P&L ({baseCurrency})</th>
                    <th className="py-2 px-3 text-right">Return Impact</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E293B]">
                  {activeStress.pairImpacts.map((pi, idx) => (
                    <tr key={idx}>
                      <td className="py-2 px-3 font-semibold text-slate-200">{pi.pairId}</td>
                      <td className="py-2 px-3 text-right text-slate-300">
                        {pi.shockedSpot.toFixed(pi.pairId.endsWith('JPY') ? 2 : 4)}
                      </td>
                      <td className="py-2 px-3 text-right text-rose-400">
                        {Math.round(pi.pnlBase).toLocaleString()}
                      </td>
                      <td className="py-2 px-3 text-right text-rose-400">
                        {pi.pnlPct.toFixed(2)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded text-xs text-slate-400">
            <strong className="text-slate-200">Model & Data Limitation Disclosure:</strong>{' '}
            {activeStress.scenario.limitationsNote}
          </div>
        </div>

        {/* Reverse Stress Testing Numerical Solver */}
        <div className="lg:col-span-6 bg-[#111723] border border-[#1E293B] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#1E293B] pb-3">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-[#38BDF8]" />
              03. Reverse Stress Testing Numerical Solver
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Solves numerically for the exact combination of AUD depreciation, funding-currency appreciation, and bid-ask spread widening that produces a specified portfolio equity loss.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 bg-[#0B0F17] border border-[#1E293B] p-3.5 rounded">
            <div>
              <label className="block text-xs text-slate-400 mb-1">
                Target Portfolio Equity Loss Threshold
              </label>
              <div className="flex items-center gap-1.5">
                {[5, 10, 15, 20, 25].map((pct) => (
                  <button
                    key={pct}
                    onClick={() => setReverseTargetLossPct(pct)}
                    className={`px-3 py-1 text-xs font-mono font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                      reverseTargetLossPct === pct
                        ? 'bg-rose-500 text-white font-semibold'
                        : 'bg-[#111723] text-slate-300 hover:bg-[#1E293B]'
                    }`}
                  >
                    -{pct}% Equity
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">
                Funding Squeeze vs Broad AUD Share ({Math.round(reverseFundingShare * 100)}% Funding)
              </label>
              <input
                type="range"
                min={0.15}
                max={0.80}
                step={0.05}
                value={reverseFundingShare}
                onChange={(e) => setReverseFundingShare(Number(e.target.value))}
                className="w-40 accent-[#38BDF8]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono tabular-nums">
            <div className="p-3 bg-[#0B0F17] border border-rose-500/30 rounded">
              <div className="text-[11px] font-sans text-slate-400">Target Equity Loss</div>
              <div className="text-base font-bold text-rose-400 mt-1">
                {reverseSolution.targetLossPct.toFixed(1)}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {Math.round(reverseSolution.targetLossBase).toLocaleString()} {baseCurrency}
              </div>
            </div>

            <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">Solved AUD Drop</div>
              <div className="text-base font-semibold text-rose-400 mt-1">
                {reverseSolution.solvedAudDepreciationPct.toFixed(2)}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Broad AUD leg</div>
            </div>

            <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">Solved JPY/CHF Rally</div>
              <div className="text-base font-semibold text-amber-400 mt-1">
                +{reverseSolution.solvedFundingAppreciationPct.toFixed(2)}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Funding leg squeeze</div>
            </div>

            <div className="p-3 bg-[#0B0F17] border border-[#1E293B] rounded">
              <div className="text-[11px] font-sans text-slate-400">Solved Spread Mult</div>
              <div className="text-base font-semibold text-amber-400 mt-1">
                {reverseSolution.solvedSpreadWideningMult.toFixed(2)}x
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {reverseSolution.iterationsUsed} bisection steps
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-[#0B0F17] border border-[#1E293B] rounded space-y-1.5 text-xs text-slate-400">
            <div className="font-medium text-slate-200 flex items-center gap-1.5">
              <AlertOctagon className="w-3.5 h-3.5 text-[#38BDF8]" />
              Solver Assumptions & Numerical Convergence (Error: {reverseSolution.convergenceErrorBps} bps)
            </div>
            {reverseSolution.assumptionsDisclosed.map((a, idx) => (
              <div key={idx} className="flex items-start gap-2">
                <span className="text-[#38BDF8]">·</span>
                <span>{a}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
