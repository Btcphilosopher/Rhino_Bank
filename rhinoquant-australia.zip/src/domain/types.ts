export type CurrencyCode =
  | 'AUD'
  | 'JPY'
  | 'CHF'
  | 'USD'
  | 'EUR'
  | 'GBP'
  | 'CAD'
  | 'NZD'
  | 'SGD'
  | 'CNH'
  | 'SEK'
  | 'NOK';

export type RateInstrumentType =
  | 'POLICY_RATE'
  | 'OIS_CURVE'
  | 'MONEY_MARKET'
  | 'GOVT_YIELD'
  | 'DEPOSIT_BORROWING'
  | 'FX_SWAP_IMPLIED';

export type Tenor = 'ON' | '1W' | '1M' | '3M' | '6M' | '1Y' | '2Y';

export type DayCountBasis = 'ACT/360' | 'ACT/365' | '30/360';
export type CompoundingMethod = 'CONTINUOUS' | 'SIMPLE' | 'ANNUAL';

export interface YieldCurveNode {
  tenor: Tenor;
  yearFraction: number;
  policyRate: number; // % annualised
  oisRate: number; // % annualised
  moneyMarketRate: number; // % annualised
  govtYield: number; // % annualised
  borrowingSpreadBps: number; // financing friction above benchmark
}

export interface CurrencyMetadata {
  code: CurrencyCode;
  name: string;
  centralBank: string;
  centralBankCode: string;
  dayCount: DayCountBasis;
  policyRate: number;
  nextMeetingDate: string;
  marketImpliedChangeBps: number;
  inflationYoY: number;
  unemploymentRate: number;
  curve: Record<Tenor, YieldCurveNode>;
}

export interface CurrencyPairSpec {
  id: string; // e.g., "AUD/JPY"
  base: 'AUD';
  quote: CurrencyCode;
  spot: number; // units of quote per 1 AUD (S_{A/Q})
  spotBid: number;
  spotAsk: number;
  pipMultiplier: number; // 100 for JPY, 10000 for others
  observedForwardPoints3M: number; // in pips
  crossCurrencyBasisBps: number; // deviation from theoretical CIP
  financingSpreadBps: number;
  marginRequirementPct: number;
  rolloverCostBps: number;
  slippageAssumptionBps: number;
  liquidityScore: number; // 1 to 100
  realisedVol3M: number; // % annualised
  impliedVol3M: number; // % annualised
  recentReturn1M: number; // %
  recentDrawdown3M: number; // %
  maxDrawdown3Y: number; // %
  historicalDifferentialPercentile: number; // 0-100
  ironOreBeta: number; // sensitivity to iron ore changes
  chinaPmiBeta: number; // sensitivity to China PMI
  globalRiskVixBeta: number; // sensitivity to risk-off VIX spike
  sourceProvider: string;
  observationTimestamp: string;
  freshnessStatus: 'FRESH' | 'STALE_WARNING' | 'OFFLINE_SYNTHETIC';
  customAdded?: boolean;
}

export interface ForwardPricingOutput {
  pairId: string;
  spot: number;
  tenor: Tenor;
  yearFraction: number;
  rAudPct: number;
  rQuotePct: number;
  theoreticalOutrightForward: number;
  theoreticalForwardPointsPips: number;
  marketOutrightForward: number;
  marketForwardPointsPips: number;
  cipBasisImpliedBps: number;
  dayCountAud: DayCountBasis;
  dayCountQuote: DayCountBasis;
  compounding: CompoundingMethod;
}

export interface CarrySignalOutput {
  pairId: string;
  quote: CurrencyCode;
  spot: number;
  instrumentType: RateInstrumentType;
  tenor: Tenor;
  rAud: number;
  rFunding: number;
  grossCarryPct: number; // c ≈ r_AUD - r_funding
  swapImpliedCarryPct: number;
  totalFrictionPct: number; // bid-ask + financing spread + rollover + basis + slippage
  netCarryPct: number;
  carryToVolRatio: number; // netCarry / realisedVol
  differentialPercentile: number;
  recentSpotReturn1M: number;
  maxDrawdown: number;
  stressLossUnwind10Pct: number; // % loss under standard correlated unwind
  signalConfidence: 'HIGH' | 'MODERATE' | 'LOW_STALE';
  warnings: string[];
  modelVersion: string;
  calculatedAt: string;
}

export interface ReturnAttributionBreakdown {
  interestCarryContributionPct: number;
  fxSpotContributionPct: number;
  forwardRolloverContributionPct: number;
  fundingAdjustmentPct: number;
  tradingCostsPct: number;
  residualUnexplainedPct: number;
  totalRealisedReturnPct: number;
  reconciledWithinTolerance: boolean;
  reconciliationErrorBps: number;
}

export interface PortfolioPosition {
  id: string;
  pairId: string;
  direction: 'LONG_AUD' | 'SHORT_AUD';
  hedgedMode: 'UNHEDGED_CARRY' | 'FX_FORWARD_HEDGED';
  notionalAud: number;
  entrySpot: number;
  currentSpot: number;
  entryTimestamp: string;
  holdingDays: number;
  fundingInstrument: RateInstrumentType;
  tenor: Tenor;
  marginReqPct: number;
  stopLossThresholdPct: number;
  positionLimitAud: number;
  dataProvenance: string;
}

export type AllocationMethod =
  | 'EQUAL_WEIGHT'
  | 'EQUAL_RISK'
  | 'VOLATILITY_TARGET'
  | 'RISK_BUDGET'
  | 'MEAN_VARIANCE_OPT'
  | 'USER_DEFINED';

export interface PortfolioAnalyticsSummary {
  baseCurrency: CurrencyCode;
  totalEquityBase: number;
  grossExposureBase: number;
  netAudExposureBase: number;
  effectiveLeverage: number;
  marginUtilisedBase: number;
  marginUtilisationPct: number;
  estimatedAnnualGrossCarryBase: number;
  estimatedAnnualNetCarryBase: number;
  portfolioVolAnnualPct: number;
  var95DailyBase: number;
  var99DailyBase: number;
  expectedShortfall975Base: number;
  herfindahlConcentration: number;
  totalUnrealisedPnlBase: number;
  attribution: ReturnAttributionBreakdown;
  positionValuations: {
    position: PortfolioPosition;
    notionalBase: number;
    weightPct: number;
    grossCarryBase: number;
    fundingCostBase: number;
    spotPnlBase: number;
    rolloverPnlBase: number;
    txCostBase: number;
    netPnlBase: number;
    returnPct: number;
    attribution: ReturnAttributionBreakdown;
  }[];
}

export interface StressScenarioSpec {
  id: string;
  name: string;
  category:
    | 'AUD_SELLOFF'
    | 'FUNDING_RALLY'
    | 'RATE_CONVERGENCE'
    | 'VOLATILITY_SHOCK'
    | 'LIQUIDITY_DETERIORATION'
    | 'COMMODITY_SHOCK'
    | 'CHINA_GROWTH_SHOCK'
    | 'CORRELATED_UNWIND'
    | 'MARGIN_SHOCK'
    | 'COMPOUND_CRISIS';
  isHistoricalEvent: boolean;
  description: string;
  horizonDays: number;
  audSpotShockPct: number; // e.g., -8.5%
  fundingRallyExtraPct: Record<string, number>; // extra shock on JPY/CHF
  rateDiffChangeBps: number; // e.g., -125 bps narrowing
  volMultiplier: number; // e.g., 2.2x
  spreadWideningMultiplier: number; // e.g., 4.0x
  marginMultiplier: number; // e.g., 1.5x
  ironOreShockPct: number;
  chinaPmiShockPts: number;
  correlationRegime: 'NORMAL' | 'CROWDED_UNWIND_090';
  limitationsNote: string;
}

export interface StressTestResult {
  scenario: StressScenarioSpec;
  estimatedPnlBase: number;
  estimatedReturnPct: number;
  spotShockLossBase: number;
  carryAccrualDuringHorizonBase: number;
  liquidityExecutionDragBase: number;
  postShockEquityBase: number;
  postShockLeverage: number;
  postShockMarginUtilPct: number;
  marginCallTriggered: boolean;
  pairImpacts: {
    pairId: string;
    shockedSpot: number;
    pnlBase: number;
    pnlPct: number;
  }[];
}

export interface ReverseStressResult {
  targetLossPct: number;
  targetLossBase: number;
  solvedAudDepreciationPct: number;
  solvedFundingAppreciationPct: number;
  solvedSpreadWideningMult: number;
  iterationsUsed: number;
  convergenceErrorBps: number;
  assumptionsDisclosed: string[];
}

export type StrategyFamily =
  | 'RATE_DIFF_RANK'
  | 'CARRY_TO_VOL_RANK'
  | 'VOL_TARGETED_CARRY'
  | 'MOMENTUM_FILTERED_CARRY'
  | 'REGIME_FILTERED_CARRY'
  | 'DIVERSIFIED_PORTFOLIO_CARRY';

export interface BacktestConfig {
  strategyFamily: StrategyFamily;
  eligiblePairs: string[];
  rebalanceSchedule: 'WEEKLY' | 'MONTHLY' | 'QUARTERLY';
  targetVolPct: number;
  topNPairs: number;
  includeTransactionCosts: boolean;
  txCostMultiplier: number;
  outOfSampleSplitPct: number; // e.g. 70% in-sample, 30% OOS
  preventLookAheadLagDays: number;
}

export interface BacktestPoint {
  date: string;
  cumulativeTotalPct: number;
  cumulativeCarryPct: number;
  cumulativeSpotPct: number;
  cumulativeTxDragPct: number;
  benchmarkEqualWeightPct: number;
  drawdownPct: number;
  regime: 'CARRY_FAVOURABLE' | 'NEUTRAL' | 'CROWDED_UNWIND';
   isOutOfSample: boolean;
}

export interface BacktestReport {
  runId: string;
  config: BacktestConfig;
  timestamp: string;
  annualisationFactor: number;
  cumulativeReturnPct: number;
  annualisedReturnPct: number;
  annualisedVolPct: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdownPct: number;
  maxDrawdownDurationDays: number;
  expectedShortfall95Pct: number;
  annualTurnoverPct: number;
  inSampleSharpe: number;
  outOfSampleSharpe: number;
  attribution: ReturnAttributionBreakdown;
  regimePerformance: {
    regime: string;
    observations: number;
    annualisedReturnPct: number;
    winRatePct: number;
  }[];
  series: BacktestPoint[];
}
