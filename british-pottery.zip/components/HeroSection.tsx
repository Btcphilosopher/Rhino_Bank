'use client';

import React, { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import Image from 'next/image';

interface HeroSectionProps {
  onExploreProducts: () => void;
}

export default function HeroSection({ onExploreProducts }: HeroSectionProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const containerRef = React.useRef<HTMLDivElement>(null);
  
  // Track scroll position for parallax and morph transitions
  const { scrollY } = useScroll();
  const heroImageScale = useTransform(scrollY, [0, 800], [1.0, 1.08]);
  const heroTextY = useTransform(scrollY, [0, 800], [0, 60]);
  const heroLineLength = useTransform(scrollY, [100, 500], ['0%', '100%']);

  // Morph sequence state: 0 (Line drawing), 1 (Form), 2 (Material), 3 (Finished product)
  const [morphStep, setMorphStep] = useState<0 | 1 | 2 | 3>(0);
  const [sliderVal, setSliderVal] = useState(0); // 0 to 100

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  // Map slider value (0-100) to our four steps
  useEffect(() => {
    if (sliderVal < 25) {
      setMorphStep(0); // LINE DRAWING
    } else if (sliderVal < 55) {
      setMorphStep(1); // FORM / SILHOUETTE
    } else if (sliderVal < 85) {
      setMorphStep(2); // MATERIAL / TEXTURE
    } else {
      setMorphStep(3); // PHOTOGRAPH / PRODUCT
    }
  }, [sliderVal]);

  return (
    <div ref={containerRef} className="relative bg-[#FAF8F5] overflow-hidden">
      
      {/* 1. CINEMATIC HERO SECTION */}
      <section className="relative min-h-[92vh] flex flex-col justify-between px-4 sm:px-6 lg:px-8 py-12 max-w-7xl mx-auto border-b border-[#EBE6DF]">
        {/* Editorial Top Info */}
        <div className="flex justify-between items-start text-xs font-mono text-[#78716C] mt-4 z-10">
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col"
          >
            <span>BRITISH POTTERY / ARCHIVE 01</span>
            <span className="text-[10px] text-[#A8A29E] mt-0.5">LOCATION: STOKE-ON-TRENT, ENG</span>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-right"
          >
            <span>EST. Heritage 2026</span>
          </motion.div>
        </div>

        {/* Center Banner / Large Title */}
        <div className="my-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center z-10">
          <div className="lg:col-span-5 space-y-6 lg:pr-8">
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1.2, delay: 0.1 }}
              className="text-[10px] tracking-widest font-mono text-[#78716C] uppercase block"
            >
              FORMED IN CLAY. MADE TO LAST.
            </motion.span>
            <h1 className="text-4xl sm:text-6xl font-serif font-light text-[#1C1917] tracking-wider uppercase leading-[1.05] text-wrap: balance">
              CERAMICS, <br />
              <motion.span 
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.0, delay: 0.4 }}
                className="font-normal italic text-stone-800"
              >
                REFINED.
              </motion.span>
            </h1>
            <p className="text-sm text-[#57534E] leading-relaxed max-w-md">
              A physical dialogue between industrial precision and tactile, organic clay surfaces. Designed in Stoke-on-Trent for the hypermodern dining space.
            </p>
            <div className="pt-4 flex items-center gap-6">
              <button
                onClick={onExploreProducts}
                className="group relative px-6 py-3 bg-[#1C1917] hover:bg-[#292524] text-white text-xs tracking-widest font-medium uppercase transition-colors rounded-sm flex items-center gap-2 cursor-pointer"
              >
                <span>EXPLORE COLLECTIONS</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </button>
              <div className="h-px w-12 bg-[#D6CEBE]" />
              <span className="text-[10px] font-mono tracking-widest text-[#78716C] uppercase">COLLECTION / 04</span>
            </div>
          </div>

          {/* Large Hero Image (revealed through slow architectural crop) */}
          <div className="lg:col-span-7 relative flex justify-center">
            {/* Architectural Grid Line Overlays */}
            <div className="absolute inset-0 border border-dashed border-[#D6CEBE]/50 pointer-events-none z-20" />
            
            <motion.div
              initial={{ clipPath: 'inset(100% 0% 0% 0%)' }}
              animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
              transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }}
              className="relative w-full aspect-[4/3] bg-[#EBE6DF]/40 overflow-hidden border border-[#D6CEBE] rounded-sm group shadow-md"
            >
              <motion.div style={{ scale: heroImageScale, y: heroTextY }} className="w-full h-full relative">
                <Image
                  src="/images/hero_ceramic_vase.jpg"
                  alt="Premium British Ceramics Vase closeup"
                  fill
                  priority
                  sizes="(max-width: 1024px) 100vw, 55vw"
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              {/* Scope Measurement lines */}
              <div className="absolute top-4 left-6 pointer-events-none text-[9px] font-mono tracking-widest text-white/90 bg-black/40 px-2 py-0.5 rounded-xs uppercase">
                H 240MM · Ø 140MM
              </div>
              <div className="absolute bottom-4 right-6 pointer-events-none text-[9px] font-mono tracking-widest text-white/90 bg-[#1C1917]/70 px-2 py-0.5 rounded-xs">
                STONEWARE / VOLCANIC GLAZE
              </div>
            </motion.div>
          </div>
        </div>

        {/* Technical Progress indicator / Editorial Footer line */}
        <div className="w-full flex justify-between items-center text-xs font-mono text-[#78716C] border-t border-[#EBE6DF]/70 pt-6">
          <div className="flex gap-4 items-center">
            <span className="text-[#1C1917] font-semibold">01 / CONCEPT</span>
            <div className="h-[1px] w-12 bg-[#D6CEBE]" />
            <span>02 / MATERIAL</span>
            <div className="h-[1px] w-12 bg-[#D6CEBE]/40" />
            <span>03 / ARTEFACT</span>
          </div>
          <span className="hidden sm:inline">STOKE-ON-TRENT FACTORIES ACTIVE</span>
        </div>
      </section>

      {/* 2. THE SIGNATURE "DRAWING → OBJECT" DYNAMIC ANIMATION */}
      <section className="bg-white py-24 border-b border-[#EBE6DF]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Morph Left details */}
            <div className="lg:col-span-5 space-y-6">
              <span className="text-[10px] tracking-widest font-mono text-[#78716C] uppercase block">
                SIGNATURE INTERACTION MODULE
              </span>
              <h2 className="text-3xl sm:text-4xl font-serif text-[#1C1917] tracking-wide uppercase">
                FROM BLUEPRINT <br />
                TO PHYSICAL OBJECT.
              </h2>
              <p className="text-sm text-[#57534E] leading-relaxed max-w-md">
                Observe the lifecycle of high-precision British ceramics. Move the interactive slider to watch the blueprint wireframe solidify into glazed clay.
              </p>

              {/* Slider Controller */}
              <div className="pt-6 space-y-4">
                <div className="flex justify-between text-[11px] font-mono tracking-widest text-[#78716C]">
                  <span>DRAWING</span>
                  <span>MATERIAL</span>
                  <span>CERAMIC</span>
                </div>
                
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sliderVal}
                  onChange={(e) => setSliderVal(Number(e.target.value))}
                  className="w-full h-1 bg-[#EBE6DF] rounded-lg appearance-none cursor-ew-resize accent-[#1C1917] outline-none"
                  aria-label="Morph stage slider"
                />

                {/* Sub-label indicators based on current morph step */}
                <div className="border-t border-[#EBE6DF]/60 pt-4">
                  <span className="text-xs font-mono uppercase tracking-widest text-[#1C1917] block font-semibold">
                    STAGE {morphStep + 1}: {
                      morphStep === 0 ? 'LINE DRAWING / VECTOR BLUEPRINT' :
                      morphStep === 1 ? 'FORM & VOLUME DESIGN' :
                      morphStep === 2 ? 'RAW CLAY & REACTIVE SLIP' :
                      'VITRIFIED FINISHED CERAMIC'
                    }
                  </span>
                  <p className="text-xs text-[#78716C] mt-2 leading-relaxed">
                    {
                      morphStep === 0 ? 'Precision technical wireframe mapping precise millimeter calculations, draft dimensions, wall thickness, and center alignment.' :
                      morphStep === 1 ? 'Digital rendering of the hollow silhouette. Focussing on volumetric weight, balance, and standard liquid capacity.' :
                      morphStep === 2 ? 'Raw iron-rich British clay slurry is applied as a reactive slip. Clay elements prepare for extreme thermal transformation.' :
                      'Vitrified stoneware mug heated to 1280°C. Glaze pools around the shoulders, creating an unbreakable, beautiful heirloom.'
                    }
                  </p>
                </div>
              </div>
            </div>

            {/* Morph Right visualization box */}
            <div className="lg:col-span-7 relative h-[450px] bg-[#FAF8F5] border border-[#D6CEBE] rounded-sm flex items-center justify-center p-8 overflow-hidden group shadow-xs">
              
              {/* Grid Backgrounds to simulate design software / architecture blueprint */}
              <div className="absolute inset-0 bg-grid-lines opacity-10 pointer-events-none" />

              {/* Morph display sequence */}
              <div className="relative w-80 h-80 flex items-center justify-center">
                
                {/* STEP 0: Detailed Line Drawing SVG */}
                {morphStep === 0 && (
                  <motion.svg
                    key="step0"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-64 h-64 text-[#1C1917]/70 stroke-[0.7]"
                    viewBox="0 0 100 100"
                  >
                    {/* Measurement Line Overlay */}
                    <line x1="10" y1="5" x2="90" y2="5" stroke="#A8A29E" strokeDasharray="1,1" />
                    <text x="50" y="3" textAnchor="middle" fill="#A8A29E" fontSize="3" fontFamily="monospace">Ø 91MM</text>
                    
                    {/* Grid center axis */}
                    <line x1="50" y1="0" x2="50" y2="100" stroke="#EBE6DF" strokeDasharray="2,2" />

                    {/* Staffordshire Mug Blueprint Shape */}
                    <path d="M25,20 L75,20 L75,80 L25,80 Z" fill="none" stroke="currentColor" />
                    {/* Handle Outline */}
                    <path d="M75,30 C90,30 90,70 75,70" fill="none" stroke="currentColor" />
                    {/* Clay bottom divider */}
                    <line x1="25" y1="60" x2="75" y2="60" stroke="currentColor" strokeDasharray="2,2" />
                    
                    {/* Dimensions label */}
                    <line x1="15" y1="20" x2="15" y2="80" stroke="#A8A29E" />
                    <text x="12" y="50" textAnchor="middle" fill="#A8A29E" fontSize="3" fontFamily="monospace" transform="rotate(-90 12 50)">H 104MM</text>
                  </motion.svg>
                )}

                {/* STEP 1: Silhouette Form (Solid gray/clay contour) */}
                {morphStep === 1 && (
                  <motion.div
                    key="step1"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="w-56 h-64 bg-[#EBE6DF] relative border border-[#D6CEBE] rounded-t-lg shadow-sm flex items-center justify-center"
                  >
                    {/* Clay handle wire contour */}
                    <div className="absolute right-[-24px] top-10 w-8 h-28 border-[12px] border-[#EBE6DF] border-l-transparent rounded-r-full" />
                    <span className="text-[10px] font-mono tracking-widest text-[#57534E] uppercase">FORM SOLID</span>
                  </motion.div>
                )}

                {/* STEP 2: Raw Material Glaze Slip (Textured mockup) */}
                {morphStep === 2 && (
                  <motion.div
                    key="step2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="w-56 h-64 bg-[#78350F]/20 border border-[#9A3412] relative rounded-t-lg overflow-hidden flex flex-col justify-end"
                  >
                    {/* Clay handle */}
                    <div className="absolute right-[-24px] top-10 w-8 h-28 border-[12px] border-[#78350F]/20 border-l-transparent rounded-r-full" />
                    {/* Half dip slip color */}
                    <div className="h-2/3 bg-[#1E3A8A]/30 w-full border-t border-[#1E3A8A]" />
                    <div className="absolute top-1/2 left-0 right-0 text-center">
                      <span className="text-[9px] font-mono tracking-widest text-[#78350F] bg-[#FAF8F5] px-2 py-0.5 rounded-sm uppercase">DIP GLAZE SLIP</span>
                    </div>
                  </motion.div>
                )}

                {/* STEP 3: Complete High-Resolution Photographic Product */}
                {morphStep === 3 && (
                  <motion.div
                    key="step3"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="w-full h-full relative"
                  >
                    <Image
                      src="/images/product_staffordshire_mug.jpg"
                      alt="Finished Staffordshire Mug product"
                      fill
                      sizes="320px"
                      className="object-contain"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-4 left-0 right-0 text-center">
                      <span className="text-[9px] font-mono tracking-widest text-white bg-[#1C1917]/85 px-3 py-1 uppercase">
                        STAFFORDSHIRE MUG / £32
                      </span>
                    </div>
                  </motion.div>
                )}

              </div>

              {/* Scope measure corners */}
              <div className="absolute top-4 left-4 text-[9px] font-mono text-[#A8A29E]">STAGE_0{morphStep + 1}</div>
              <div className="absolute bottom-4 right-4 text-[9px] font-mono text-[#A8A29E] uppercase">BRITISH_PRODUCTION_2026</div>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
}
