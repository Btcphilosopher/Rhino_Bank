'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Product } from '@/lib/products';
import Image from 'next/image';
import { Heart, Plus, Minus, ArrowLeft, ShoppingBag, ShieldCheck, CornerDownRight } from 'lucide-react';

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
  onAddToBag: (product: Product, quantity: number) => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

export default function ProductDetail({
  product,
  onBack,
  onAddToBag,
  isFavorite,
  onToggleFavorite,
}: ProductDetailProps) {
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'provenance' | 'sustainability' | 'shipping'>('provenance');
  const [isAdded, setIsAdded] = useState(false);

  // Zoom position for sensory texture explore
  const [zoomPos, setZoomPos] = useState({ x: 50, y: 50 });
  const [isHoveringTexture, setIsHoveringTexture] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setZoomPos({ x, y });
  };

  const handleAddToBag = () => {
    onAddToBag(product, quantity);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 animate-fadeIn">
      {/* Back button & Breadcrumb */}
      <div className="mb-12 flex items-center justify-between">
        <button
          onClick={onBack}
          className="group flex items-center gap-2 text-xs font-mono tracking-widest text-[#57534E] hover:text-[#1C1917] transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4 group-hover:-translate-x-1 transition-transform" />
          <span>RETURN TO WORKS</span>
        </button>
        <span className="text-[10px] tracking-widest text-[#A8A29E] font-mono">
          ACCESSION: {product.id.toUpperCase()}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
        {/* LEFT COLUMN: Large Editorial Image Gallery (8/12 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="relative aspect-[4/3] w-full bg-[#EBE6DF]/20 border border-[#EBE6DF]/50 overflow-hidden rounded-sm group shadow-xs">
            <Image
              src={product.image}
              alt={product.name}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 60vw"
              className="object-cover transition-transform duration-1000 group-hover:scale-102"
              referrerPolicy="no-referrer"
            />
            
            {/* Visual crop framing corner brackets for architectural exhibition feel */}
            <div className="absolute top-4 left-4 h-3 w-3 border-t border-l border-[#1C1917]/30" />
            <div className="absolute top-4 right-4 h-3 w-3 border-t border-r border-[#1C1917]/30" />
            <div className="absolute bottom-4 left-4 h-3 w-3 border-b border-l border-[#1C1917]/30" />
            <div className="absolute bottom-4 right-4 h-3 w-3 border-b border-r border-[#1C1917]/30" />

            <div className="absolute bottom-4 left-6">
              <span className="text-[9px] font-mono tracking-widest text-white bg-[#1C1917]/70 backdrop-blur-xs px-2.5 py-1 uppercase">
                STUDIO PHOTOGRAPHY / STOKE-ON-TRENT
              </span>
            </div>
          </div>

          {/* Sub photos or technical sketches */}
          <div className="grid grid-cols-2 gap-4">
            <div className="relative aspect-square bg-[#EBE6DF]/15 border border-[#EBE6DF]/40 overflow-hidden rounded-sm">
              <Image
                src={product.image}
                alt={`${product.name} Alternate`}
                fill
                sizes="(max-width: 1024px) 50vw, 30vw"
                className="object-cover brightness-95 saturate-75 scale-x-[-1]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              <span className="absolute bottom-3 left-3 text-[9px] font-mono tracking-widest text-white uppercase">REVERSE PROFILE</span>
            </div>
            <div className="relative aspect-square bg-[#EBE6DF]/10 border border-[#EBE6DF]/30 flex flex-col items-center justify-center p-6 text-center rounded-sm">
              {/* Ceramic CAD Sketch Vector Drawing Mock */}
              <div className="w-24 h-24 relative opacity-40 border-l border-r border-dashed border-[#57534E]/60 rounded-t-full rounded-b-lg flex flex-col justify-between p-2">
                <div className="w-full border-t border-[#57534E]" />
                <span className="text-[8px] font-mono text-[#57534E]">FORM SPEC-01</span>
                <div className="w-full border-b border-[#57534E]" />
              </div>
              <span className="text-[9px] font-mono tracking-widest text-[#78716C] uppercase mt-4">ARCHITECTURAL SKETCH</span>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Stable Contiguous Purchase Module (5/12 cols) */}
        <div className="lg:col-span-5 lg:sticky lg:top-24 space-y-8">
          <div>
            <span className="text-xs tracking-widest text-[#78716C] font-mono uppercase block mb-1">
              {product.collection}
            </span>
            <h1 className="text-3xl sm:text-4xl font-serif font-medium text-[#1C1917] tracking-wider uppercase">
              {product.name}
            </h1>
            <div className="flex items-baseline gap-4 mt-2">
              <span className="text-xl font-mono text-[#1C1917] tabular-nums font-semibold">
                £{product.price.toFixed(2)}
              </span>
              <span className="text-xs text-[#15803D] font-mono uppercase flex items-center gap-1">
                <ShieldCheck className="h-4 w-4" /> IN STOCK / SHIPS IN 24H
              </span>
            </div>
          </div>

          {/* Description */}
          <div className="border-t border-[#EBE6DF] pt-6">
            <p className="text-sm text-[#57534E] leading-relaxed max-w-prose">
              {product.description}
            </p>
          </div>

          {/* Purchase Actions */}
          <div className="space-y-4 pt-4 border-t border-[#EBE6DF]">
            <div className="flex items-center justify-between">
              <span className="text-xs tracking-widest text-[#78716C] font-mono uppercase">QUANTITY</span>
              <div className="flex items-center border border-[#D6CEBE] bg-white rounded-sm">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-2 text-[#57534E] hover:text-[#1C1917] cursor-pointer"
                  aria-label="Decrease quantity"
                >
                  <Minus className="h-3 w-3" />
                </button>
                <span className="px-4 text-sm font-mono font-medium text-[#1C1917] tabular-nums">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-2 text-[#57534E] hover:text-[#1C1917] cursor-pointer"
                  aria-label="Increase quantity"
                >
                  <Plus className="h-3 w-3" />
                </button>
              </div>
            </div>

            <div className="flex gap-4 pt-2">
              <button
                onClick={handleAddToBag}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-4 text-xs font-semibold tracking-widest text-[#FAF8F5] bg-[#1C1917] hover:bg-[#292524] transition-all rounded-sm uppercase cursor-pointer"
              >
                <ShoppingBag className="h-4 w-4" />
                {isAdded ? 'OBJECT ADDED' : 'ADD TO BAG'}
              </button>
              <button
                onClick={onToggleFavorite}
                className="p-4 border border-[#D6CEBE] hover:border-[#1C1917] transition-colors rounded-sm text-[#78716C] hover:text-red-500 cursor-pointer"
                aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
              >
                <Heart className={`h-5 w-5 stroke-[1.5] ${isFavorite ? 'fill-red-500 stroke-red-500' : ''}`} />
              </button>
            </div>
          </div>

          {/* Architectural Technical Schedule */}
          <div className="border-t border-[#EBE6DF] pt-6">
            <h3 className="text-xs font-mono tracking-widest text-[#78716C] uppercase mb-4">SPECIFICATION</h3>
            <dl className="grid grid-cols-2 gap-x-6 gap-y-3 text-xs border-b border-[#EBE6DF]/50 pb-6 font-mono">
              <div className="border-b border-[#EBE6DF]/30 pb-2 flex flex-col">
                <dt className="text-[#A8A29E] uppercase text-[10px]">Material</dt>
                <dd className="text-[#1C1917] font-medium mt-0.5">{product.material}</dd>
              </div>
              <div className="border-b border-[#EBE6DF]/30 pb-2 flex flex-col">
                <dt className="text-[#A8A29E] uppercase text-[10px]">Finish</dt>
                <dd className="text-[#1C1917] font-medium mt-0.5">{product.glaze}</dd>
              </div>
              <div className="border-b border-[#EBE6DF]/30 pb-2 flex flex-col">
                <dt className="text-[#A8A29E] uppercase text-[10px]">Dimensions</dt>
                <dd className="text-[#1C1917] font-medium mt-0.5">{product.dimensions}</dd>
              </div>
              <div className="border-b border-[#EBE6DF]/30 pb-2 flex flex-col">
                <dt className="text-[#A8A29E] uppercase text-[10px]">Capacity / Vol</dt>
                <dd className="text-[#1C1917] font-medium mt-0.5">{product.capacity || 'N/A'}</dd>
              </div>
              <div className="border-b border-[#EBE6DF]/30 pb-2 flex flex-col">
                <dt className="text-[#A8A29E] uppercase text-[10px]">Weight</dt>
                <dd className="text-[#1C1917] font-medium mt-0.5">{product.weight}</dd>
              </div>
              <div className="border-b border-[#EBE6DF]/30 pb-2 flex flex-col">
                <dt className="text-[#A8A29E] uppercase text-[10px]">Production</dt>
                <dd className="text-[#1C1917] font-medium mt-0.5">{product.origin}</dd>
              </div>
            </dl>
          </div>
        </div>
      </div>

      {/* "THE OBJECT" SENSORY GLAZE SECTION */}
      <section className="mt-24 border-t border-[#EBE6DF] pt-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-4">
            <span className="text-[10px] tracking-widest text-[#78716C] font-mono uppercase block mb-1">SECTION 02 / ANALYSIS</span>
            <h2 className="text-3xl font-serif text-[#1C1917] uppercase tracking-wide">THE OBJECT</h2>
            <div className="w-12 h-[1px] bg-[#1C1917] my-4" />
            <p className="text-sm text-[#57534E] leading-relaxed mb-6">
              A physical dialogue between raw British clay and reactive silicate chemistry. 
              The surface displays exquisite volcanic ash speckling and subtle, kiln-carved flow marks.
            </p>
            <div className="space-y-3 font-mono text-[11px] text-[#78716C]">
              <div className="flex items-center gap-2">
                <CornerDownRight className="h-3.5 w-3.5 text-[#1C1917]" />
                <span>Hover over the texture to analyze the glaze</span>
              </div>
              <div className="flex items-center gap-2">
                <CornerDownRight className="h-3.5 w-3.5 text-[#1C1917]" />
                <span>Micro-pores: 0.1mm - 0.4mm spacing</span>
              </div>
              <div className="flex items-center gap-2">
                <CornerDownRight className="h-3.5 w-3.5 text-[#1C1917]" />
                <span>Iron reduction speckles: Volcanic source</span>
              </div>
            </div>
          </div>

          {/* Interactive tactile surface zoom (Turn the ceramic itself into the interface) */}
          <div className="lg:col-span-8">
            <div 
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setIsHoveringTexture(true)}
              onMouseLeave={() => setIsHoveringTexture(false)}
              className="relative h-96 w-full overflow-hidden border border-[#D6CEBE] bg-stone-100 rounded-sm cursor-crosshair group shadow-xs"
            >
              {/* Zoom image container */}
              <div 
                className="absolute inset-0 transition-transform duration-200"
                style={{
                  transform: isHoveringTexture ? 'scale(2.2)' : 'scale(1)',
                  transformOrigin: `${zoomPos.x}% ${zoomPos.y}%`
                }}
              >
                <Image
                  src={product.image}
                  alt={`${product.name} Glaze Texture`}
                  fill
                  sizes="100vw"
                  className="object-cover brightness-95"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Scope bracket outline UI when hovering */}
              {isHoveringTexture && (
                <div className="absolute inset-0 pointer-events-none border-[12px] border-[#FAF8F5]/80 flex items-center justify-center">
                  <div className="h-24 w-24 border border-white/60 relative flex flex-col justify-between p-1 font-mono text-[8px] text-white">
                    <span className="text-left font-semibold">MAG: 220%</span>
                    <span className="text-right">SENSORY REVEAL</span>
                  </div>
                </div>
              )}

              {/* Explanatory badge */}
              {!isHoveringTexture && (
                <div className="absolute inset-0 bg-[#1C1917]/20 backdrop-blur-[2px] flex flex-col items-center justify-center text-[#FAF8F5]">
                  <span className="text-xs font-mono tracking-widest uppercase">TACTILE SURVEY</span>
                  <span className="text-2xl font-serif tracking-widest mt-2 uppercase">EXPLORE GLAZE TEXTURE</span>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#D6CEBE] mt-1">[ HOVER TO EXAMINE ]</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* EDITORIAL NAVIGATION TABS */}
      <section className="mt-20 border-t border-[#EBE6DF] pt-12">
        <div className="flex border-b border-[#EBE6DF]/60">
          {(['provenance', 'sustainability', 'shipping'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-3 px-6 text-xs font-mono tracking-widest uppercase transition-all border-b-2 cursor-pointer ${
                activeTab === tab 
                  ? 'border-[#1C1917] text-[#1C1917] font-semibold' 
                  : 'border-transparent text-[#78716C] hover:text-[#1C1917]'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="py-8 min-h-[160px] max-w-3xl">
          <AnimatePresence mode="wait">
            {activeTab === 'provenance' && (
              <motion.div
                key="provenance"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="text-sm text-[#57534E] leading-relaxed space-y-4"
              >
                <p>
                  Each piece is designed and individually crafted in Stoke-on-Trent, Staffordshire—the historic industrial heart of British pottery. Throwing, trimming, slip-dipping, and firing are entirely performed by master artisans with over two decades of technical expertise.
                </p>
                <p className="italic font-serif">
                  Registered under Studio Mark: BP/2026. Stamped physically on the raw clay foot-ring.
                </p>
              </motion.div>
            )}

            {activeTab === 'sustainability' && (
              <motion.div
                key="sustainability"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="text-sm text-[#57534E] leading-relaxed space-y-4"
              >
                <p>
                  Our commitment is to permanent material objects. Clay is an incredibly durable, ancient material. Fired at 1280°C, our vitrified stoneware remains food safe, shock-resistant, and structural for centuries, negating the need for disposable tableware.
                </p>
                <p>
                  Our kilns use high-efficiency recapture ventilation systems, reducing heat waste by 35%. Clay scraps are 100% reconstituted into fresh slipbatches, achieving zero solid waste.
                </p>
              </motion.div>
            )}

            {activeTab === 'shipping' && (
              <motion.div
                key="shipping"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="text-sm text-[#57534E] leading-relaxed space-y-4"
              >
                <p>
                  Packaged with high-density, custom-molded biodegradable wood pulp structures. We utilize 100% plastic-free, recyclable cardboard casing with paper tape.
                </p>
                <p>
                  <strong>United Kingdom:</strong> Free standard shipping on orders over £150. Otherwise, flat £4.95 standard rate (2-3 business days) or £8.50 overnight priority delivery.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>
    </div>
  );
}
