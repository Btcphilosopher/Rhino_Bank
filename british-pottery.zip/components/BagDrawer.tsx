'use client';

import React from 'react';
import { X, Plus, Minus, Trash2, ArrowRight } from 'lucide-react';
import { Product } from '@/lib/products';
import Image from 'next/image';

export interface CartItem {
  product: Product;
  quantity: number;
}

interface BagDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onProceedToCheckout: () => void;
}

export default function BagDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
}: BagDrawerProps) {
  React.useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const delivery = subtotal > 150 || subtotal === 0 ? 0 : 4.95;
  const total = subtotal + delivery;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#1C1917]/20 backdrop-blur-xs transition-opacity duration-500 animate-fadeIn" 
        onClick={onClose} 
      />

      <div className="absolute inset-y-0 right-0 flex max-w-full pl-10">
        {/* Panel */}
        <div className="w-screen max-w-md transform bg-[#FAF8F5] shadow-2xl transition-all duration-500 ease-in-out border-l border-[#EBE6DF] flex flex-col h-full animate-slideLeft">
          
          {/* Header */}
          <div className="px-4 py-6 sm:px-6 border-b border-[#EBE6DF]">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-medium tracking-widest text-[#1C1917] uppercase font-sans">
                SHOPPING BAG ({cart.reduce((sum, i) => sum + i.quantity, 0)})
              </h2>
              <button
                onClick={onClose}
                className="p-1.5 text-[#57534E] hover:text-[#1C1917] transition-colors rounded-full hover:bg-[#EBE6DF]/40 cursor-pointer"
              >
                <X className="h-5 w-5 stroke-[1.5]" />
              </button>
            </div>
          </div>

          {/* Cart items */}
          <div className="flex-1 overflow-y-auto py-6 px-4 sm:px-6">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center py-12">
                <span className="text-xs font-serif italic text-[#78716C] mb-3">Your shopping bag is currently empty.</span>
                <span className="text-[11px] tracking-widest text-[#A8A29E] uppercase max-w-xs leading-relaxed">
                  Invest in beautiful British-made ceramics built to last a lifetime.
                </span>
                <button
                  onClick={onClose}
                  className="mt-8 px-6 py-2.5 text-xs tracking-widest text-white bg-[#1C1917] hover:bg-[#292524] transition-colors font-medium rounded-sm uppercase cursor-pointer"
                >
                  START BROWSING
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex gap-4 pb-6 border-b border-[#EBE6DF]/60 last:border-b-0">
                    {/* Image */}
                    <div className="h-24 w-20 relative bg-white border border-[#EBE6DF] overflow-hidden shrink-0">
                      <Image
                        src={item.product.image}
                        alt={item.product.name}
                        fill
                        sizes="80px"
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Product Details */}
                    <div className="flex-1 flex flex-col justify-between py-0.5">
                      <div>
                        <div className="flex justify-between items-start gap-2">
                          <h3 className="text-xs font-medium text-[#1C1917] font-sans">
                            {item.product.name}
                          </h3>
                          <span className="text-xs font-mono font-medium tabular-nums text-[#1C1917]">
                            £{(item.product.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                        <p className="text-[10px] tracking-widest text-[#78716C] uppercase mt-1">
                          {item.product.material} · {item.product.glaze.slice(0, 25)}...
                        </p>
                      </div>

                      {/* Quantity Selector & Trash */}
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center border border-[#D6CEBE] bg-white rounded-sm">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                            className="p-1 text-[#57534E] hover:text-[#1C1917] disabled:opacity-30 cursor-pointer"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="px-2.5 text-xs font-mono font-medium text-[#1C1917] tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            className="p-1 text-[#57534E] hover:text-[#1C1917] cursor-pointer"
                            aria-label="Increase quantity"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.product.id)}
                          className="p-1 text-[#A8A29E] hover:text-red-600 transition-colors cursor-pointer"
                          aria-label="Remove item"
                        >
                          <Trash2 className="h-4 w-4 stroke-[1.5]" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer summary */}
          {cart.length > 0 && (
            <div className="border-t border-[#EBE6DF] bg-white px-4 py-6 sm:px-6">
              <div className="space-y-2 font-mono text-xs text-[#57534E]">
                <div className="flex justify-between">
                  <span>SUBTOTAL</span>
                  <span className="font-medium text-[#1C1917] tabular-nums">£{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>DELIVERY</span>
                  {delivery === 0 ? (
                    <span className="text-[#15803D] font-medium tracking-wide">FREE OVER £150</span>
                  ) : (
                    <span className="font-medium text-[#1C1917] tabular-nums">£{delivery.toFixed(2)}</span>
                  )}
                </div>
                <div className="flex justify-between border-t border-[#EBE6DF]/80 pt-3 text-sm font-sans font-semibold text-[#1C1917]">
                  <span>TOTAL</span>
                  <span className="font-mono tabular-nums">£{total.toFixed(2)}</span>
                </div>
              </div>

              {subtotal < 150 && (
                <p className="text-[10px] text-[#78716C] italic mt-4 text-center">
                  Spend <span className="font-mono font-medium">£{(150 - subtotal).toFixed(2)}</span> more to qualify for Free UK Delivery.
                </p>
              )}

              <div className="mt-6">
                <button
                  onClick={onProceedToCheckout}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3.5 border border-transparent text-xs tracking-widest font-semibold text-[#FAF8F5] bg-[#1C1917] hover:bg-[#292524] shadow-sm transition-colors rounded-sm uppercase cursor-pointer"
                >
                  PROCEED TO CHECKOUT <ArrowRight className="h-4 w-4" />
                </button>
              </div>
              <div className="mt-4 flex justify-center text-center">
                <button
                  type="button"
                  className="text-xs font-serif italic text-[#78716C] hover:text-[#1C1917] hover:underline cursor-pointer"
                  onClick={onClose}
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
