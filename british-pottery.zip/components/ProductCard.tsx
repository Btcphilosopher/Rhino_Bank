'use client';

import React from 'react';
import { motion } from 'motion/react';
import { Product } from '@/lib/products';
import Image from 'next/image';
import { Heart, Maximize2 } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onClick: () => void;
  isFavorite: boolean;
  onToggleFavorite: (e: React.MouseEvent) => void;
  index: number;
}

export default function ProductCard({
  product,
  onClick,
  isFavorite,
  onToggleFavorite,
  index,
}: ProductCardProps) {
  // We can vary the layout slightly to create some asymmetry
  const isLarge = index % 5 === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ 
        duration: 0.8, 
        delay: Math.min(index * 0.08, 0.4), 
        ease: [0.16, 1, 0.3, 1] 
      }}
      className={`group flex flex-col justify-between ${
        isLarge ? 'md:col-span-2' : ''
      }`}
    >
      <div className="relative aspect-[4/3] bg-[#EBE6DF]/30 overflow-hidden border border-[#EBE6DF]/40 rounded-sm">
        {/* Interaction overlay */}
        <div 
          onClick={onClick}
          className="absolute inset-0 z-10 cursor-pointer"
        />

        {/* Favorite Button */}
        <button
          onClick={onToggleFavorite}
          className="absolute top-3 right-3 z-20 p-1.5 rounded-full bg-[#FAF8F5]/80 backdrop-blur-xs hover:bg-[#FAF8F5] text-[#78716C] hover:text-red-500 transition-all duration-300 shadow-sm cursor-pointer"
          aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
        >
          <Heart 
            className={`h-4 w-4 stroke-[1.5] transition-all duration-300 ${
              isFavorite ? 'fill-red-500 stroke-red-500 scale-110' : ''
            }`} 
          />
        </button>

        {/* Accession label hover indicator */}
        <div className="absolute bottom-3 left-3 z-20 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <span className="text-[9px] font-mono tracking-widest text-[#1C1917] bg-[#FAF8F5]/90 px-2 py-1 rounded-xs flex items-center gap-1">
            <Maximize2 className="h-2.5 w-2.5" /> DETAIL
          </span>
        </div>

        {/* Product Image */}
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes={isLarge ? "(max-width: 768px) 100vw, 50vw" : "(max-width: 768px) 50vw, 33vw"}
          className="object-cover group-hover:scale-104 transition-transform duration-1000 ease-[0.16, 1, 0.3, 1]"
          referrerPolicy="no-referrer"
        />

        {/* Availability Badge */}
        {product.availability !== 'In Stock' && (
          <div className="absolute top-3 left-3 z-20">
            <span className="text-[9px] font-mono uppercase tracking-widest bg-[#1C1917]/85 text-[#FAF8F5] px-2 py-0.5">
              {product.availability}
            </span>
          </div>
        )}
      </div>

      {/* Product Information (subtly shifted on hover) */}
      <div className="mt-3 group-hover:translate-y-[-2px] transition-transform duration-500 ease-out">
        {/* Category & Collection (Zero-Pill Discipline: unboxed, clean text with separators) */}
        <div className="flex items-center gap-1 text-[9px] tracking-widest text-[#78716C] font-mono uppercase">
          <span>{product.material}</span>
          <span>·</span>
          <span>{product.category}</span>
        </div>

        <div className="flex justify-between items-baseline mt-1.5 gap-2">
          <h3 
            onClick={onClick}
            className="text-xs font-semibold text-[#1C1917] hover:underline cursor-pointer tracking-wide transition-all font-sans"
          >
            {product.name}
          </h3>
          <span className="text-xs font-mono font-medium text-[#1C1917] tabular-nums shrink-0">
            £{product.price.toFixed(2)}
          </span>
        </div>
        
        {/* Fine description snippet for asymmetrical grid cards */}
        {isLarge && (
          <p className="text-[11px] text-[#78716C] line-clamp-2 mt-2 leading-relaxed max-w-prose">
            {product.description}
          </p>
        )}
      </div>
    </motion.div>
  );
}
