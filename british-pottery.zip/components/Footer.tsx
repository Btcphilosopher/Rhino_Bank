'use client';

import React from 'react';

interface FooterProps {
  setActiveView: (view: string) => void;
}

export default function Footer({ setActiveView }: FooterProps) {
  const sections = [
    {
      title: 'SHOP',
      links: [
        { label: 'All Tableware', view: 'shop' },
        { label: 'Tea & Coffee', view: 'shop' },
        { label: 'Vases & Vessels', view: 'shop' },
        { label: 'Limited Editions', view: 'shop' }
      ]
    },
    {
      title: 'ABOUT',
      links: [
        { label: 'Our Story', view: 'about' },
        { label: 'Stoke-on-Trent Craft', view: 'craft' },
        { label: 'Journal & Stories', view: 'journal' },
        { label: 'Archive Studio', view: 'shop' }
      ]
    },
    {
      title: 'INQUIRIES',
      links: [
        { label: 'Care & Restoration', view: 'about' },
        { label: 'Delivery & Returns', view: 'about' },
        { label: 'Bespoke Commissions', view: 'about' },
        { label: 'Contact Office', view: 'about' }
      ]
    }
  ];

  return (
    <footer className="bg-[#1C1917] text-[#EBE6DF] pt-20 pb-12 border-t border-[#292524]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-[#292524]">
          {/* Logo Brand column */}
          <div className="md:col-span-5 space-y-4">
            <h2 className="text-xl font-serif font-bold tracking-widest text-white">
              BRITISH POTTERY
            </h2>
            <p className="text-xs text-[#A8A29E] max-w-sm leading-relaxed">
              Crafting premium British tableware, vases, and custom studio ceramics. Fired in historic Stoke-on-Trent kilns, built to carry stories across generations.
            </p>
            <div className="pt-2 text-[10px] font-mono text-[#78716C]">
              <span>LONDON · STOKE-ON-TRENT · SCOTLAND</span>
            </div>
          </div>

          {/* Links Columns */}
          <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-8">
            {sections.map((section) => (
              <div key={section.title} className="space-y-4">
                <h4 className="text-[10px] font-mono tracking-widest text-[#78716C] uppercase font-semibold">
                  {section.title}
                </h4>
                <ul className="space-y-2 text-xs text-[#A8A29E]">
                  {section.links.map((link) => (
                    <li key={link.label}>
                      <button
                        onClick={() => setActiveView(link.view)}
                        className="hover:text-white transition-colors cursor-pointer text-left"
                      >
                        {link.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom micro lines */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-8 text-[10px] font-mono text-[#78716C] gap-4">
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            <span>© 2026 BRITISH POTTERY LTD.</span>
            <a href="#" className="hover:text-white transition-colors">PRIVACY CODE</a>
            <a href="#" className="hover:text-white transition-colors">TERMS OF USE</a>
            <a href="#" className="hover:text-white transition-colors">UK MANUFACTURING</a>
          </div>
          <div>
            <span>FORMED IN EARTH · DESIGNED FOR LIFE</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
