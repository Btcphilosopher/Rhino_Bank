'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CartItem } from '@/components/BagDrawer';
import { ShieldCheck, Truck, CreditCard, CheckCircle2, ShoppingBag, ArrowRight } from 'lucide-react';
import Image from 'next/image';

interface CheckoutViewProps {
  cart: CartItem[];
  onCompleteOrder: (orderId: string, deliveryDetails: any) => void;
  onBack: () => void;
}

export default function CheckoutView({ cart, onCompleteOrder, onBack }: CheckoutViewProps) {
  const [step, setStep] = useState<1 | 2>(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    country: 'United Kingdom',
    deliveryType: 'standard',
    cardName: 'Tom',
    cardNumber: '4111 2222 3333 4444',
    cardExpiry: '12/28',
    cardCvc: '123'
  });

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryCost = formData.deliveryType === 'express' ? 8.50 : (subtotal > 150 ? 0 : 4.95);
  const total = subtotal + deliveryCost;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmitDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.email || !formData.address || !formData.postalCode) {
      alert('Please fill out all required shipping details.');
      return;
    }
    setStep(2);
  };

  const handleSimulatePayment = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate payment loading
    const orderId = `BP-${Math.floor(100000 + Math.random() * 900000)}`;
    onCompleteOrder(orderId, formData);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 animate-fadeIn">
      <div className="mb-12">
        <button
          onClick={onBack}
          className="text-xs font-mono tracking-widest text-[#57534E] hover:text-[#1C1917] transition-colors cursor-pointer"
        >
          ← RETURN TO BAG
        </button>
        <h1 className="text-3xl font-serif tracking-wide uppercase mt-4 text-[#1C1917]">
          SECURE SECULAR CHECKOUT
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
        {/* LEFT COLUMN: Input form modules (7/12 cols) */}
        <div className="lg:col-span-7 space-y-8">
          {/* Progress Indicators */}
          <div className="flex border-b border-[#EBE6DF] pb-4">
            <span className={`text-xs font-mono tracking-widest uppercase mr-8 ${step === 1 ? 'text-[#1C1917] font-semibold' : 'text-[#A8A29E]'}`}>
              01 / SHIPPING & DELIVERY
            </span>
            <span className={`text-xs font-mono tracking-widest uppercase ${step === 2 ? 'text-[#1C1917] font-semibold' : 'text-[#A8A29E]'}`}>
              02 / SECURE SIMULATED PAYMENT
            </span>
          </div>

          {step === 1 ? (
            <form onSubmit={handleSubmitDetails} className="space-y-6">
              <h2 className="text-sm font-semibold text-[#1C1917] tracking-wider uppercase font-sans">
                DELIVERY DESTINATION
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">FIRST NAME *</label>
                  <input
                    type="text"
                    name="firstName"
                    required
                    value={formData.firstName}
                    onChange={handleChange}
                    className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-sans"
                    placeholder="Tom"
                  />
                </div>
                <div>
                  <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">LAST NAME *</label>
                  <input
                    type="text"
                    name="lastName"
                    required
                    value={formData.lastName}
                    onChange={handleChange}
                    className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-sans"
                    placeholder="Spooner"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">EMAIL ADDRESS *</label>
                  <input
                    type="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-sans"
                    placeholder="tom@ahyx.org"
                  />
                </div>
                <div>
                  <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">PHONE NUMBER *</label>
                  <input
                    type="tel"
                    name="phone"
                    required
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-sans"
                    placeholder="07123 456789"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">ADDRESS LINE *</label>
                <input
                  type="text"
                  name="address"
                  required
                  value={formData.address}
                  onChange={handleChange}
                  className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-sans"
                  placeholder="32 Britannia Way"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2">
                  <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">CITY *</label>
                  <input
                    type="text"
                    name="city"
                    required
                    value={formData.city}
                    onChange={handleChange}
                    className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-sans"
                    placeholder="Stoke-on-Trent"
                  />
                </div>
                <div>
                  <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">POSTAL CODE *</label>
                  <input
                    type="text"
                    name="postalCode"
                    required
                    value={formData.postalCode}
                    onChange={handleChange}
                    className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-mono"
                    placeholder="ST4 2DE"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-[#EBE6DF]">
                <h3 className="text-xs font-mono tracking-widest text-[#78716C] uppercase mb-4">DELIVERY METHOD</h3>
                <div className="space-y-3">
                  <label className="flex items-center justify-between p-4 border border-[#D6CEBE] rounded-sm bg-white cursor-pointer hover:border-[#1C1917] transition-all">
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="deliveryType"
                        value="standard"
                        checked={formData.deliveryType === 'standard'}
                        onChange={handleChange}
                        className="accent-[#1C1917]"
                      />
                      <div>
                        <span className="block text-xs font-semibold text-[#1C1917]">STANDARD ROYAL MAIL COURIER</span>
                        <span className="block text-[10px] text-[#78716C] mt-0.5">Delivery in 2–3 business days. Carbon neutral.</span>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-[#1C1917] tabular-nums font-semibold">
                      {subtotal > 150 ? 'FREE' : '£4.95'}
                    </span>
                  </label>

                  <label className="flex items-center justify-between p-4 border border-[#D6CEBE] rounded-sm bg-white cursor-pointer hover:border-[#1C1917] transition-all">
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="deliveryType"
                        value="express"
                        checked={formData.deliveryType === 'express'}
                        onChange={handleChange}
                        className="accent-[#1C1917]"
                      />
                      <div>
                        <span className="block text-xs font-semibold text-[#1C1917]">OVERNIGHT PRIORITY AIRWAY</span>
                        <span className="block text-[10px] text-[#78716C] mt-0.5">Delivery guaranteed next working day by 12:00.</span>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-[#1C1917] tabular-nums font-semibold">£8.50</span>
                  </label>
                </div>
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 px-6 py-4 border border-transparent text-xs tracking-widest font-semibold text-[#FAF8F5] bg-[#1C1917] hover:bg-[#292524] shadow-sm transition-colors rounded-sm uppercase cursor-pointer"
              >
                PROCEED TO SIMULATED PAYMENT <ArrowRight className="h-4 w-4" />
              </button>
            </form>
          ) : (
            <form onSubmit={handleSimulatePayment} className="space-y-6">
              <div className="p-4 bg-amber-50 border border-amber-200 text-[#78350F] rounded-sm text-xs leading-relaxed font-mono">
                <strong>[ NOTICE: INTEGRATED SIMULATION SYSTEM ]</strong>
                <p className="mt-1">
                  This checkout is fully operational using pre-populated test credentials. No actual money will be transacted. Fulfill with ease.
                </p>
              </div>

              <h2 className="text-sm font-semibold text-[#1C1917] tracking-wider uppercase font-sans flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-[#1C1917]" /> CREDIT CARD DETAILS
              </h2>

              <div>
                <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">NAME ON CARD</label>
                <input
                  type="text"
                  name="cardName"
                  required
                  value={formData.cardName}
                  onChange={handleChange}
                  className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-sans"
                />
              </div>

              <div>
                <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">CARD NUMBER (TEST)</label>
                <input
                  type="text"
                  name="cardNumber"
                  required
                  value={formData.cardNumber}
                  onChange={handleChange}
                  className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-mono tracking-widest"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">EXPIRY DATE</label>
                  <input
                    type="text"
                    name="cardExpiry"
                    required
                    placeholder="MM/YY"
                    value={formData.cardExpiry}
                    onChange={handleChange}
                    className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] tracking-wide text-[#78716C] uppercase mb-1.5 font-mono">SECURITY CODE (CVC)</label>
                  <input
                    type="password"
                    name="cardCvc"
                    required
                    maxLength={3}
                    value={formData.cardCvc}
                    onChange={handleChange}
                    className="w-full bg-white border border-[#D6CEBE] rounded-sm p-3 text-xs outline-none focus:border-[#1C1917] font-mono"
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4 border-t border-[#EBE6DF]">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-6 py-4 border border-[#D6CEBE] text-xs font-mono text-[#57534E] hover:text-[#1C1917] hover:border-[#1C1917] transition-all rounded-sm uppercase cursor-pointer"
                >
                  GO BACK
                </button>
                <button
                  type="submit"
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-4 text-xs font-semibold tracking-widest text-[#FAF8F5] bg-[#1C1917] hover:bg-[#292524] transition-colors rounded-sm uppercase cursor-pointer"
                >
                  CONFIRM & PAY £{total.toFixed(2)}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* RIGHT COLUMN: Order Summary (5/12 cols) */}
        <div className="lg:col-span-5 bg-white border border-[#EBE6DF] p-6 rounded-sm space-y-6 lg:sticky lg:top-24">
          <h2 className="text-xs font-mono tracking-widest text-[#78716C] uppercase border-b border-[#EBE6DF] pb-3">
            BAG SUMMARY
          </h2>

          <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
            {cart.map((item) => (
              <div key={item.product.id} className="flex gap-3 items-center">
                <div className="relative h-14 w-12 bg-stone-50 border border-[#EBE6DF] overflow-hidden shrink-0">
                  <Image
                    src={item.product.image}
                    alt={item.product.name}
                    fill
                    sizes="50px"
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <span className="block text-xs font-medium text-[#1C1917] truncate">{item.product.name}</span>
                  <span className="block text-[10px] text-[#78716C] font-mono">QTY: {item.quantity} · £{item.product.price.toFixed(2)}</span>
                </div>
                <span className="text-xs font-mono text-[#1C1917] font-medium tabular-nums">
                  £{(item.product.price * item.quantity).toFixed(2)}
                </span>
              </div>
            ))}
          </div>

          <div className="border-t border-[#EBE6DF] pt-4 space-y-2 text-xs font-mono text-[#57534E]">
            <div className="flex justify-between">
              <span>SUBTOTAL</span>
              <span className="text-[#1C1917] font-semibold tabular-nums">£{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>ESTIMATED DELIVERY</span>
              <span className="text-[#1C1917] font-semibold tabular-nums">
                {deliveryCost === 0 ? 'FREE' : `£${deliveryCost.toFixed(2)}`}
              </span>
            </div>
            <div className="flex justify-between border-t border-[#EBE6DF] pt-3 text-sm font-sans font-semibold text-[#1C1917]">
              <span>TOTAL TO CHARGE</span>
              <span className="font-mono tabular-nums">£{total.toFixed(2)}</span>
            </div>
          </div>

          <div className="pt-4 border-t border-[#EBE6DF]/60 space-y-3 text-[10px] text-[#78716C] leading-relaxed">
            <div className="flex gap-2 items-start">
              <ShieldCheck className="h-4 w-4 text-[#1C1917] shrink-0" />
              <span>Authentic hand-finished ceramic items are carefully padded with biodegradable wood pulp packaging. Fulfillments are 100% insured.</span>
            </div>
            <div className="flex gap-2 items-start">
              <Truck className="h-4 w-4 text-[#1C1917] shrink-0" />
              <span>Full shipment tracking details will be transmitted to you via secure automated notification upon kiln collection.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
