'use client';

import React from 'react';
import { Search, ShoppingBag, Heart, Menu, X } from 'lucide-react';

interface NavbarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  cartCount: number;
  openCart: () => void;
  openSearch: () => void;
  favoritesCount: number;
  openFavorites: () => void;
}

export default function Navbar({
  activeView,
  setActiveView,
  cartCount,
  openCart,
  openSearch,
  favoritesCount,
  openFavorites,
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { label: 'SHOP', view: 'shop' },
    { label: 'CRAFT', view: 'craft' },
    { label: 'JOURNAL', view: 'journal' },
    { label: 'ABOUT', view: 'about' }
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#EBE6DF] bg-[#FAF8F5]/90 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          
          {/* ZONE 1: Brand Wordmark (Single text element) */}
          <button 
            onClick={() => { setActiveView('home'); setMobileMenuOpen(false); }}
            className="text-lg font-serif font-bold tracking-widest text-[#1C1917] hover:opacity-80 transition-opacity cursor-pointer shrink-0"
          >
            BRITISH POTTERY
          </button>

          {/* ZONE 2: Navigation Links (4-6 links, single-line, hover underlines) */}
          <nav className="hidden md:flex items-center justify-center gap-8 text-xs font-medium tracking-widest text-[#57534E]">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => setActiveView(link.view)}
                className={`relative py-2 transition-colors hover:text-[#1C1917] cursor-pointer whitespace-nowrap ${
                  activeView === link.view 
                    ? 'text-[#1C1917] font-semibold after:absolute after:bottom-0 after:left-0 after:h-[1px] after:w-full after:bg-[#1C1917]' 
                    : ''
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* ZONE 3: Primary Actions (Search, Favorites, Bag) */}
          <div className="flex items-center justify-end gap-4 shrink-0">
            <button
              onClick={openSearch}
              aria-label="Search catalogue"
              className="p-1.5 text-[#57534E] hover:text-[#1C1917] transition-colors cursor-pointer"
            >
              <Search className="h-[18px] w-[18px] stroke-[1.5]" />
            </button>

            <button
              onClick={openFavorites}
              aria-label="View favorites"
              className="relative p-1.5 text-[#57534E] hover:text-[#1C1917] transition-colors cursor-pointer"
            >
              <Heart className={`h-[18px] w-[18px] stroke-[1.5] ${favoritesCount > 0 ? 'fill-red-500 stroke-red-500' : ''}`} />
              {favoritesCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-[#1C1917] text-[9px] font-mono tabular-nums text-[#FAF8F5]">
                  {favoritesCount}
                </span>
              )}
            </button>

            <button
              onClick={openCart}
              aria-label="Open shopping bag"
              className="relative p-1.5 text-[#57534E] hover:text-[#1C1917] transition-colors cursor-pointer"
            >
              <ShoppingBag className="h-[18px] w-[18px] stroke-[1.5]" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-[#1C1917] text-[9px] font-mono tabular-nums text-[#FAF8F5]">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-1.5 text-[#57534E] hover:text-[#1C1917] transition-colors cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5 stroke-[1.5]" /> : <Menu className="h-5 w-5 stroke-[1.5]" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 w-full bg-[#FAF8F5] border-b border-[#EBE6DF] py-6 px-4 z-50 shadow-lg animate-fadeIn">
          <div className="flex flex-col gap-4 text-center">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => {
                  setActiveView(link.view);
                  setMobileMenuOpen(false);
                }}
                className={`text-sm font-medium tracking-widest py-2.5 border-b border-[#FAF8F5] ${
                  activeView === link.view 
                    ? 'text-[#1C1917] font-semibold border-[#1C1917]' 
                    : 'text-[#57534E] hover:text-[#1C1917]'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
