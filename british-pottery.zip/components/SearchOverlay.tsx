'use client';

import React, { useState, useEffect, useRef } from 'react';
import { X, ArrowRight, Search } from 'lucide-react';
import { Product, products } from '@/lib/products';
import Image from 'next/image';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (productId: string) => void;
}

export default function SearchOverlay({ isOpen, onClose, onSelectProduct }: SearchOverlayProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      document.body.style.overflow = '';
      setQuery('');
      setResults([]);
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const term = query.toLowerCase();
    const filtered = products.filter(
      (p) =>
        p.name.toLowerCase().includes(term) ||
        p.category.toLowerCase().includes(term) ||
        p.material.toLowerCase().includes(term) ||
        p.glaze.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term)
    );
    setResults(filtered.slice(0, 6)); // limit to top 6
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#FAF8F5]/98 backdrop-blur-md flex flex-col p-6 sm:p-12 animate-fadeIn">
      {/* Header Bar */}
      <div className="flex items-center justify-between w-full max-w-7xl mx-auto">
        <span className="text-xs tracking-widest font-mono text-[#78716C]">SEARCH CATALOGUE</span>
        <button
          onClick={onClose}
          className="p-2 text-[#57534E] hover:text-[#1C1917] transition-colors rounded-full hover:bg-[#EBE6DF]/40 cursor-pointer"
          aria-label="Close search"
        >
          <X className="h-6 w-6 stroke-[1.2]" />
        </button>
      </div>

      {/* Main Search Container */}
      <div className="flex-1 flex flex-col justify-start w-full max-w-4xl mx-auto mt-16 sm:mt-24">
        <div className="relative border-b border-[#D6CEBE] pb-4 flex items-center">
          <Search className="h-8 w-8 text-[#A8A29E] mr-4 shrink-0 stroke-[1.2]" />
          <input
            ref={inputRef}
            type="text"
            placeholder="SEARCH CERAMICS..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-2xl sm:text-4xl font-serif tracking-widest text-[#1C1917] outline-none placeholder-[#A8A29E] uppercase font-light"
          />
        </div>

        {/* Suggestion tags (Zero-Pill Discipline: static metadata or unboxed text lists) */}
        {query.length === 0 && (
          <div className="mt-8">
            <h4 className="text-xs tracking-widest text-[#78716C] mb-4 uppercase">Suggested Queries</h4>
            <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-[#1C1917]">
              {['Cobalt', 'Stoneware', 'Tea Caddy', 'Mug', 'Limited', 'Porcelain'].map((term) => (
                <button
                  key={term}
                  onClick={() => setQuery(term)}
                  className="hover:underline transition-all cursor-pointer font-medium"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Results Grid */}
        {results.length > 0 && (
          <div className="mt-12 flex-1 overflow-y-auto max-h-[60vh] pr-2">
            <h4 className="text-xs tracking-widest text-[#78716C] mb-6 uppercase font-mono">
              Results found ({results.length})
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-12">
              {results.map((product) => (
                <div
                  key={product.id}
                  onClick={() => {
                    onSelectProduct(product.id);
                    onClose();
                  }}
                  className="group flex gap-4 p-3 border border-[#EBE6DF]/60 bg-white/50 hover:bg-white hover:border-[#D6CEBE] transition-all duration-300 cursor-pointer rounded-sm"
                >
                  <div className="relative h-20 w-20 bg-[#FAF8F5] shrink-0 overflow-hidden">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      sizes="80px"
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex flex-col justify-between py-1 flex-1 min-w-0">
                    <div>
                      <span className="block text-[10px] tracking-widest text-[#78716C] uppercase">
                        {product.category} · {product.material}
                      </span>
                      <h5 className="text-sm font-medium text-[#1C1917] truncate mt-0.5">
                        {product.name}
                      </h5>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs font-mono tabular-nums text-[#1C1917]">
                        £{product.price.toFixed(2)}
                      </span>
                      <span className="text-[10px] tracking-wide text-[#57534E] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        VIEW DETAIL <ArrowRight className="h-3 w-3" />
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty state */}
        {query.trim().length > 0 && results.length === 0 && (
          <div className="mt-12 py-12 text-center border border-dashed border-[#D6CEBE]/50 bg-white/20">
            <span className="block text-sm font-serif text-[#78716C] italic">
              No ceramic works found matching "{query}"
            </span>
            <span className="block text-xs text-[#A8A29E] mt-2">
              Try searching for materials like 'Stoneware' or categories like 'VASES'.
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
