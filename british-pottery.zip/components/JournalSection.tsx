'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { Sparkles, Calendar, BookOpen, Clock, ChevronRight, ChevronLeft } from 'lucide-react';

export default function JournalSection() {
  const [activeStage, setActiveStage] = useState(0);

  const articles = [
    {
      id: "inside-the-kiln",
      title: "Inside the British Kiln",
      subtitle: "A STUDY IN REACTION, FIRE, AND VITRIFICATION",
      date: "September 12, 2026",
      readTime: "6 min read",
      category: "CRAFT",
      image: "/images/craft_potter_wheel.jpg", // high fidelity photo
      text: "Firing is where control meets chaos. At 1280°C, the silica in clay melts into glass, fusion is completed, and reactive mineral slips run. The placement of the piece in the kiln, the exact speed of temperature ascension, and the gaseous cooling composition dictate the singular personality of each vessel. No two are ever alike."
    },
    {
      id: "why-stoneware-ages",
      title: "Why Stoneware Ages Beautifully",
      subtitle: "ANCIENT GEOLOGY DESIGNED FOR PERMANENT REVELATION",
      date: "August 24, 2026",
      readTime: "4 min read",
      category: "MATERIAL",
      image: "/images/product_stoneware_bowl.jpg",
      text: "Unlike lightweight industrial ceramics, British stoneware is formed with coarse, iron-bearing clay deposits that oxidize unevenly. As tea, oils, and physical hands touch the raw unglazed foot-ring over decades, it develops a deep, polished obsidian patina. An aesthetic relationship that ripens with use."
    },
    {
      id: "geometry-of-teacup",
      title: "The Geometry of a Teacup",
      subtitle: "THE MATH BEHIND PERFECT HEAT RETENTION & POUR CLARITY",
      date: "July 18, 2026",
      readTime: "8 min read",
      category: "DESIGN",
      image: "/images/product_staffordshire_mug.jpg",
      text: "An exceptional teacup balances thermodynamics with ergonomical physics. The draft angle of the body controls heat loss, the hand-bent handle offsets the center of gravity to avoid thumb tension, and a sharp rim lip breaks the capillary water tension to deliver a spill-free pour. Simple, perfect engineering."
    }
  ];

  // 10 Earth to Object stages
  const stages = [
    { title: "01 / RAW CLAY", label: "Harvesting", desc: "Sourcing rich iron-spotted clay deposits directly from the historic valleys surrounding Staffordshire.", spec: "Mineral content: 34% Kaolin, 48% Quartz" },
    { title: "02 / PREPARED CLAY", label: "Pugmill Normalization", desc: "The raw clay is wedged, filtered, and pressed through a vacuum pugmill to purge all air pocket micro-fractures.", spec: "Moisture target: 18.5% uniform density" },
    { title: "03 / THE WHEEL", label: "Artisanal Centering", desc: "Throwing the normalized clay on a spinning wheel, where the master artisan's thumbs center the mass via sheer physical memory.", spec: "Rotational velocity: 120 RPM" },
    { title: "04 / SHAPED VESSEL", label: "Forming Profile", desc: "Pulling the walls upward with precise thickness gradients, establishing the primary volumetric silhouette of the pottery.", spec: "Wall thickness margin: 3.5mm ± 0.2" },
    { title: "05 / DRYING", label: "Leather-Hard State", desc: "Leaving the wet vessel in a temperature-controlled draft room until excess moisture evaporates, leaving it strong enough to trim.", spec: "Ambient moisture reduction: 92%" },
    { title: "06 / GLAZING", label: "Slip Dipping", desc: "Submerging the biscuit-fired clay into a custom liquid mineral suspension formulated with cobalt, copper oxides, and wood ash.", spec: "Viscosity index: 1.25 Pascal-seconds" },
    { title: "07 / THE KILN", label: "Thermal Vitrification", desc: "Loading pieces into the high-efficiency gas kilns and firing slowly to peak vitrification temperature.", spec: "Peak firing threshold: 1280°C" },
    { title: "08 / FINISHED CERAMIC", label: "Quality Audit", desc: "Unloading the cooling kiln and auditing each ceramic piece for ring clarity, glaze melt variations, and base smoothness.", spec: "Acoustic resonance frequency: 440Hz clear ring" },
    { title: "09 / PACKAGING", label: "Pulp Protection", desc: "Molding custom wood-pulp casings to protect the delicate stoneware throughout courier transit without using single-use plastic.", spec: "100% biodegradable organic composition" },
    { title: "10 / DINING TABLE", label: "Everyday Communion", desc: "The finished ceramic object enters your home, prepared to support daily meals and carry tactile memories for centuries.", spec: "Expected lifecycle: 200+ years of active use" }
  ];

  const handleNextStage = () => {
    setActiveStage((prev) => (prev + 1) % stages.length);
  };

  const handlePrevStage = () => {
    setActiveStage((prev) => (prev - 1 + stages.length) % stages.length);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 animate-fadeIn">
      
      {/* Editorial Journal Feed */}
      <section className="mb-24">
        <span className="text-xs tracking-widest text-[#78716C] font-mono uppercase block mb-1">
          PUBLISHING HOUSE
        </span>
        <h1 className="text-3xl sm:text-5xl font-serif text-[#1C1917] tracking-wide uppercase mb-12">
          THE POTTERY JOURNAL
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {articles.map((article) => (
            <div 
              key={article.id} 
              className="group flex flex-col justify-between border-t border-[#EBE6DF] pt-6 hover:border-[#1C1917] transition-colors duration-500"
            >
              <div>
                <div className="flex items-center gap-3 text-[10px] text-[#78716C] font-mono uppercase mb-4">
                  <span>{article.category}</span>
                  <span>·</span>
                  <span>{article.readTime}</span>
                </div>

                <div className="relative aspect-[3/2] w-full bg-[#EBE6DF]/20 border border-[#EBE6DF]/30 overflow-hidden mb-6 rounded-sm">
                  <Image
                    src={article.image}
                    alt={article.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 33vw"
                    className="object-cover group-hover:scale-103 transition-transform duration-1000 ease-[0.16, 1, 0.3, 1]"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <h3 className="text-lg font-serif font-medium text-[#1C1917] tracking-wide uppercase group-hover:text-stone-800 transition-colors">
                  {article.title}
                </h3>
                <p className="text-[10px] tracking-widest text-[#A8A29E] font-mono uppercase mt-1">
                  {article.subtitle}
                </p>

                <p className="text-xs text-[#57534E] leading-relaxed mt-4">
                  {article.text}
                </p>
              </div>

              <div className="flex items-center justify-between mt-8 text-[11px] font-mono text-[#1C1917] border-t border-[#EBE6DF]/40 pt-4">
                <span>{article.date}</span>
                <span className="group-hover:translate-x-1.5 transition-transform duration-300 flex items-center gap-1">
                  READ STORY →
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FROM EARTH TO OBJECT: SIGNATURE SCROLL SEQUENCE */}
      <section className="bg-white border border-[#EBE6DF] p-6 sm:p-12 rounded-sm">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-[10px] tracking-widest font-mono text-[#78716C] uppercase block mb-1">
            CRAFT LIFECYCLE CHRONOLOGY
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif text-[#1C1917] tracking-wide uppercase">
            FROM EARTH TO OBJECT
          </h2>
          <p className="text-xs text-[#57534E] mt-3 leading-relaxed">
            Ten continuous physical transformations required to turn raw Staffordshire soil into a vitrified, architectural dining ceramic.
          </p>
        </div>

        {/* Horizontal Navigation Dots / Progress */}
        <div className="flex justify-between items-center overflow-x-auto border-b border-[#EBE6DF]/70 pb-4 mb-8 gap-4 scrollbar-thin">
          {stages.map((stage, idx) => (
            <button
              key={stage.title}
              onClick={() => setActiveStage(idx)}
              className={`text-left shrink-0 pb-2 border-b-2 transition-all cursor-pointer ${
                activeStage === idx
                  ? 'border-[#1C1917] text-[#1C1917] font-semibold'
                  : 'border-transparent text-[#A8A29E] hover:text-[#57534E]'
              }`}
            >
              <span className="block text-[10px] font-mono">{stage.title.split(' / ')[0]}</span>
              <span className="block text-xs tracking-wide uppercase font-medium">{stage.label}</span>
            </button>
          ))}
        </div>

        {/* Interactive Active Stage Showcase Card */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-[#FAF8F5] p-6 sm:p-10 rounded-sm min-h-[300px]">
          <div className="space-y-4">
            <span className="text-[10px] tracking-widest text-[#78716C] font-mono uppercase block">
              STAGE {stages[activeStage].title}
            </span>
            <h3 className="text-xl sm:text-2xl font-serif text-[#1C1917] uppercase tracking-wide">
              {stages[activeStage].label}
            </h3>
            <p className="text-sm text-[#57534E] leading-relaxed">
              {stages[activeStage].desc}
            </p>
            
            {/* Technical schedule box for stage */}
            <div className="border-t border-[#D6CEBE]/70 pt-4 mt-4">
              <span className="text-[9px] font-mono tracking-widest text-[#78716C] uppercase">TECHNICAL CONTROL METRIC:</span>
              <span className="block text-xs text-[#1C1917] font-mono mt-1 font-semibold">
                {stages[activeStage].spec}
              </span>
            </div>
          </div>

          <div className="relative h-64 bg-white border border-[#EBE6DF] flex flex-col items-center justify-center p-8 rounded-sm overflow-hidden">
            <div className="absolute inset-0 bg-grid-lines opacity-10" />
            
            {/* Elegant Vector CAD indicator graphics */}
            <div className="w-40 h-40 rounded-full border border-dashed border-[#1C1917]/20 flex items-center justify-center relative">
              <div className="w-24 h-24 rounded-full border border-[#1C1917]/10 flex items-center justify-center">
                <span className="text-[9px] font-mono text-[#57534E]/60">MONITOR ACTIVE</span>
              </div>
              <div className="absolute top-2 left-2 text-[8px] font-mono text-[#A8A29E]">CALIBRATE_0{activeStage + 1}</div>
              <div className="absolute bottom-2 right-2 text-[8px] font-mono text-[#A8A29E]">DEV_MARG: OK</div>
            </div>

            {/* Stepper controls */}
            <div className="absolute bottom-4 right-4 flex items-center gap-2">
              <button 
                onClick={handlePrevStage}
                className="p-1.5 border border-[#D6CEBE] hover:border-[#1C1917] hover:bg-stone-50 transition-colors text-[#1C1917] rounded-full cursor-pointer"
                aria-label="Previous step"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button 
                onClick={handleNextStage}
                className="p-1.5 border border-[#D6CEBE] hover:border-[#1C1917] hover:bg-stone-50 transition-colors text-[#1C1917] rounded-full cursor-pointer"
                aria-label="Next step"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
