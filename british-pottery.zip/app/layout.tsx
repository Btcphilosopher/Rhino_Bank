import type {Metadata} from 'next';
import { Cormorant_Garamond, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css'; // Global styles

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  variable: '--font-cormorant',
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  weight: ['300', '400', '500', '600', '700'],
});

export const metadata: Metadata = {
  title: 'BRITISH POTTERY — Ceramics, Refined.',
  description: 'An Anglo-Futurist hypermodern digital flagship for premium British ceramics and fine pottery, built for the next technological and cultural era.',
  openGraph: {
    title: 'BRITISH POTTERY — Ceramics, Refined.',
    description: 'An Anglo-Futurist hypermodern digital flagship for premium British ceramics and fine pottery, built for the next technological and cultural era.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BRITISH POTTERY — Ceramics, Refined.',
    description: 'An Anglo-Futurist hypermodern digital flagship for premium British ceramics and fine pottery, built for the next technological and cultural era.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${cormorant.variable} ${plusJakarta.variable}`}>
      <body className="font-sans antialiased text-[#1C1917] bg-[#FAF8F5]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
