'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import ProductCard from '@/components/ProductCard';
import ProductDetail from '@/components/ProductDetail';
import SearchOverlay from '@/components/SearchOverlay';
import BagDrawer, { CartItem } from '@/components/BagDrawer';
import CheckoutView from '@/components/CheckoutView';
import JournalSection from '@/components/JournalSection';
import Footer from '@/components/Footer';
import { Product, products } from '@/lib/products';
import Image from 'next/image';
import { Heart, Search, ShoppingBag, ShieldCheck, HelpCircle, CornerDownRight, ArrowRight, Award, MapPin, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Home() {
  // Navigation & View States
  const [activeView, setActiveView] = useState<string>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>('staffordshire-mug-cobalt');
  const [searchOpen, setSearchOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);

  // Cart & Favourites state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [orderConfirm, setOrderConfirm] = useState<{ orderId: string; details: any } | null>(null);

  // Shop View Filter States
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<string>('DEFAULT');
  const [filterAvailability, setFilterAvailability] = useState<string>('ALL');

  // Load sample initial favorite on first render for high-fidelity interactive feel
  useEffect(() => {
    setFavorites(['staffordshire-mug-cobalt', 'sculptural-stoneware-vase']);
  }, []);

  // Cart Handlers
  const handleAddToBag = (product: Product, qty: number) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.product.id === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + qty } : item
        );
      }
      return [...prevCart, { product, quantity: qty }];
    });
    setCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, newQty: number) => {
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity: newQty } : item))
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleToggleFavorite = (productId: string) => {
    setFavorites((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const handleCompleteOrder = (orderId: string, deliveryDetails: any) => {
    setOrderConfirm({ orderId, details: deliveryDetails });
    setCart([]); // Clear cart
    setActiveView('order-confirmation');
  };

  // Curate products to show on the Home page (Featured list)
  const featuredProducts = products.filter((p) =>
    ['staffordshire-mug-cobalt', 'cobalt-breakfast-plate', 'moorland-stoneware-bowl', 'sculptural-stoneware-vase', 'white-porcelain-teapot', 'kiln-blue-jug'].includes(p.id)
  );

  // Filtered and sorted products for the Shop grid
  const filteredProducts = products
    .filter((p) => {
      const matchesCategory = filterCategory === 'ALL' || p.category === filterCategory;
      const matchesAvailability = filterAvailability === 'ALL' || p.availability === filterAvailability;
      return matchesCategory && matchesAvailability;
    })
    .sort((a, b) => {
      if (sortBy === 'PRICE_LOW') return a.price - b.price;
      if (sortBy === 'PRICE_HIGH') return b.price - a.price;
      return 0; // Default sort order
    });

  return (
    <div className="min-h-screen flex flex-col justify-between font-sans selection:bg-[#1C1917] selection:text-[#FAF8F5]">
      
      {/* Search overlay & bag slide drawers */}
      <SearchOverlay
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectProduct={(id) => {
          setSelectedProductId(id);
          setActiveView('product-detail');
        }}
      />

      <BagDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onProceedToCheckout={() => {
          setCartOpen(false);
          setActiveView('checkout');
        }}
      />

      <Navbar
        activeView={activeView}
        setActiveView={(view) => {
          setActiveView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        openCart={() => setCartOpen(true)}
        openSearch={() => setSearchOpen(true)}
        favoritesCount={favorites.length}
        openFavorites={() => setActiveView('favorites')}
      />

      {/* Primary Dynamic Main Views with elegant state transitions */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          
          {/* VIEW 1: HOME */}
          {activeView === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
            >
              <HeroSection onExploreProducts={() => {
                setActiveView('shop');
                window.scrollTo({ top: 500, behavior: 'smooth' });
              }} />

              {/* SECTION: NEW CERAMICS (Featured Asymmetrical Gallery) */}
              <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col sm:flex-row justify-between items-baseline mb-16 border-b border-[#EBE6DF] pb-6 gap-4">
                  <div>
                    <span className="text-[10px] tracking-widest font-mono text-[#78716C] uppercase block mb-1">
                      CURATED COLLECTION / 04
                    </span>
                    <h2 className="text-3xl font-serif text-[#1C1917] tracking-wide uppercase">
                      NEW CERAMICS
                    </h2>
                  </div>
                  <button
                    onClick={() => { setActiveView('shop'); window.scrollTo({ top: 0 }); }}
                    className="text-xs font-mono tracking-widest text-[#1C1917] hover:underline flex items-center gap-1 cursor-pointer font-semibold"
                  >
                    VIEW THE WHOLE CATALOGUE <ArrowRight className="h-4 w-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
                  {featuredProducts.map((product, idx) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onClick={() => {
                        setSelectedProductId(product.id);
                        setActiveView('product-detail');
                        window.scrollTo({ top: 0 });
                      }}
                      isFavorite={favorites.includes(product.id)}
                      onToggleFavorite={(e) => {
                        e.stopPropagation();
                        handleToggleFavorite(product.id);
                      }}
                      index={idx}
                    />
                  ))}
                </div>
              </section>

              {/* SECTION: CLAY / FIRE / FORM MATERIAL STORY */}
              <section className="bg-white py-24 border-t border-b border-[#EBE6DF]">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="text-center max-w-xl mx-auto mb-16">
                    <span className="text-[10px] tracking-widest font-mono text-[#78716C] uppercase block">
                      OUR MATERIAL PHILOSOPHY
                    </span>
                    <h2 className="text-3xl font-serif text-[#1C1917] tracking-wider uppercase mt-2">
                      CLAY / FIRE / FORM
                    </h2>
                    <p className="text-xs text-[#57534E] leading-relaxed mt-3">
                      We reject temporal, fragile decoration. Our work honors the ancient, geological permanence of hand-shaped stone.
                    </p>
                  </div>

                  {/* 3 Large Architectural Gallery Cards */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Card 1: CLAY */}
                    <div className="relative aspect-[4/3] w-full overflow-hidden border border-[#D6CEBE] rounded-sm group bg-[#EBE6DF]/20">
                      <Image
                        src="/images/craft_potter_wheel.jpg"
                        alt="Raw Clay Preparation"
                        fill
                        className="object-cover group-hover:scale-103 transition-transform duration-1000 ease-out"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#1C1917]/75 via-[#1C1917]/25 to-transparent" />
                      <div className="absolute bottom-6 left-6 text-[#FAF8F5]">
                        <span className="block text-[9px] font-mono tracking-widest text-[#D6CEBE] uppercase">[ PART 01 / GEOLOGY ]</span>
                        <h3 className="text-xl font-serif tracking-widest uppercase mt-1">RAW CLAY</h3>
                        <p className="text-[10px] text-[#A8A29E] mt-2 max-w-xs leading-relaxed">
                          Coarse iron-speckled clay deposits are harvested, filtered and prepared to yield physical weight and textured grip.
                        </p>
                      </div>
                    </div>

                    {/* Card 2: FIRE */}
                    <div className="relative aspect-[4/3] w-full overflow-hidden border border-[#D6CEBE] rounded-sm group bg-[#EBE6DF]/20">
                      <Image
                        src="/images/hero_ceramic_vase.jpg"
                        alt="High temperature kiln interiors"
                        fill
                        className="object-cover group-hover:scale-103 transition-transform duration-1000 ease-out brightness-90 saturate-75"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#1C1917]/75 via-[#1C1917]/25 to-transparent" />
                      <div className="absolute bottom-6 left-6 text-[#FAF8F5]">
                        <span className="block text-[9px] font-mono tracking-widest text-[#D6CEBE] uppercase">[ PART 02 / INTENSITY ]</span>
                        <h3 className="text-xl font-serif tracking-widest uppercase mt-1">THERMAL FIRE</h3>
                        <p className="text-[10px] text-[#A8A29E] mt-2 max-w-xs leading-relaxed">
                          Heated to a monumental 1280°C in oxygen-reduced atmosphere. Silica vitrifies into high-tensile glass-ceramic structures.
                        </p>
                      </div>
                    </div>

                    {/* Card 3: FORM */}
                    <div className="relative aspect-[4/3] w-full overflow-hidden border border-[#D6CEBE] rounded-sm group bg-[#EBE6DF]/20">
                      <Image
                        src="/images/product_staffordshire_mug.jpg"
                        alt="Finished Ceramic Form"
                        fill
                        className="object-cover group-hover:scale-103 transition-transform duration-1000 ease-out"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#1C1917]/75 via-[#1C1917]/25 to-transparent" />
                      <div className="absolute bottom-6 left-6 text-[#FAF8F5]">
                        <span className="block text-[9px] font-mono tracking-widest text-[#D6CEBE] uppercase">[ PART 03 / VITRIFICATION ]</span>
                        <h3 className="text-xl font-serif tracking-widest uppercase mt-1">PERMANENT FORM</h3>
                        <p className="text-[10px] text-[#A8A29E] mt-2 max-w-xs leading-relaxed">
                          A beautiful, complete tactile object. Hand-finished with unique reactive cobalt glazes designed to last multiple lifecycles.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-12 text-center">
                    <span className="text-[10px] tracking-widest font-mono text-[#78716C] uppercase font-semibold">
                      MATERIAL / PROCESS / OBJECT · REGISTERED EST. 2026
                    </span>
                  </div>
                </div>
              </section>

              {/* SECTION: MADE IN BRITAIN (Production Heritage Column) */}
              <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  <div className="lg:col-span-5 space-y-6">
                    <span className="text-[10px] tracking-widest font-mono text-[#78716C] uppercase block mb-1">
                      INDUSTRIAL ORIGIN STUDY
                    </span>
                    <h2 className="text-3xl sm:text-4xl font-serif text-[#1C1917] tracking-wider uppercase leading-tight">
                      MADE IN BRITAIN. <br />
                      MADE TO LAST.
                    </h2>
                    <p className="text-sm text-[#57534E] leading-relaxed">
                      Our manufacturing roots are firmly bound to Stoke-on-Trent, historically referred to as "The Potteries"—the global epicenter of fine ceramics for over three centuries. 
                    </p>
                    <p className="text-xs text-[#78716C] leading-relaxed">
                      We inherit their legendary discipline of engineering quality while introducing modern, architectural geometries and reactive, ecological glaze recipes. Heritage is our foundational context, never static nostalgia.
                    </p>
                    
                    {/* Trust Indicators */}
                    <div className="grid grid-cols-2 gap-4 border-t border-[#EBE6DF] pt-6 font-mono text-xs">
                      <div className="flex gap-2 items-center">
                        <Award className="h-5 w-5 text-[#1C1917]" />
                        <div>
                          <span className="block font-semibold">100% British Clay</span>
                          <span className="block text-[10px] text-[#A8A29E]">Locally quarried</span>
                        </div>
                      </div>
                      <div className="flex gap-2 items-center">
                        <MapPin className="h-5 w-5 text-[#1C1917]" />
                        <div>
                          <span className="block font-semibold">Stoke Studios</span>
                          <span className="block text-[10px] text-[#A8A29E]">Artisan thrown</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Large visual illustration panel */}
                  <div className="lg:col-span-7">
                    <div className="relative aspect-[16/10] w-full bg-[#EBE6DF]/20 border border-[#D6CEBE] overflow-hidden rounded-sm">
                      <Image
                        src="/images/craft_potter_wheel.jpg"
                        alt="Pottery kiln and wheel workshop"
                        fill
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                      {/* Sub-label indicators mimicking technical layout overlay */}
                      <div className="absolute inset-0 bg-[#1C1917]/15 pointer-events-none" />
                      <div className="absolute top-4 left-4 border-l border-t border-white/60 h-12 w-12 p-2">
                        <span className="block text-[8px] font-mono text-white">GRID: ALIGNED</span>
                      </div>
                      <div className="absolute bottom-4 right-4 text-right bg-black/60 backdrop-blur-xs px-3 py-1.5 text-[9px] font-mono text-white rounded-xs">
                        <span>STOKE-ON-TRENT WORKSHOP PROFILE</span>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {/* VIEW 2: SHOP / CATALOGUE */}
          {activeView === 'shop' && (
            <motion.div
              key="shop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12"
            >
              {/* Shop Header */}
              <div className="border-b border-[#EBE6DF] pb-8 mb-12 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                <div>
                  <span className="text-xs tracking-widest text-[#78716C] font-mono uppercase block mb-1">
                    BRITISH CERAMICS / 2026
                  </span>
                  <h1 className="text-3xl sm:text-5xl font-serif text-[#1C1917] tracking-wider uppercase">
                    ALL WORKS ({filteredProducts.length})
                  </h1>
                </div>

                {/* Subdued search bar direct trigger */}
                <div className="flex items-center gap-2 border border-[#D6CEBE] bg-white px-3 py-2 rounded-sm w-full md:w-64">
                  <Search className="h-4 w-4 text-[#A8A29E]" />
                  <input
                    type="text"
                    placeholder="Search works..."
                    onClick={() => setSearchOpen(true)}
                    className="bg-transparent border-none outline-none text-xs text-[#1C1917] w-full cursor-pointer placeholder-[#A8A29E]"
                    readOnly
                  />
                </div>
              </div>

              {/* Sidebar Filters & Product Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-12 items-start">
                
                {/* SIDEBAR FILTERS (Interactive state selectors) */}
                <div className="space-y-8 lg:sticky lg:top-24">
                  
                  {/* Category filters */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-mono tracking-widest text-[#78716C] uppercase font-semibold">
                      CATEGORIES
                    </h4>
                    <div className="flex flex-col gap-2.5 items-start">
                      {['ALL', 'TABLEWARE', 'TEA & COFFEE', 'VASES', 'LIMITED'].map((cat) => (
                        <button
                          key={cat}
                          onClick={() => setFilterCategory(cat)}
                          className={`text-xs tracking-widest uppercase transition-colors cursor-pointer ${
                            filterCategory === cat 
                              ? 'text-[#1C1917] font-bold underline decoration-2 underline-offset-4' 
                              : 'text-[#78716C] hover:text-[#1C1917]'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Sort filters */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-mono tracking-widest text-[#78716C] uppercase font-semibold">
                      SORT BY PRICE
                    </h4>
                    <div className="flex flex-col gap-2.5 items-start">
                      {[
                        { label: 'DEFAULT CHRONOLOGY', val: 'DEFAULT' },
                        { label: 'PRICE: LOW TO HIGH', val: 'PRICE_LOW' },
                        { label: 'PRICE: HIGH TO LOW', val: 'PRICE_HIGH' }
                      ].map((option) => (
                        <button
                          key={option.val}
                          onClick={() => setSortBy(option.val)}
                          className={`text-xs tracking-widest uppercase transition-colors cursor-pointer ${
                            sortBy === option.val 
                              ? 'text-[#1C1917] font-bold underline decoration-2 underline-offset-4' 
                              : 'text-[#78716C] hover:text-[#1C1917]'
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Availability Filter */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-mono tracking-widest text-[#78716C] uppercase font-semibold">
                      AVAILABILITY
                    </h4>
                    <div className="flex flex-col gap-2.5 items-start">
                      {[
                        { label: 'ALL INVENTORY', val: 'ALL' },
                        { label: 'IN STOCK NOW', val: 'In Stock' },
                        { label: 'LIMITED EDITION', val: 'Limited Edition' }
                      ].map((option) => (
                        <button
                          key={option.val}
                          onClick={() => setFilterAvailability(option.val)}
                          className={`text-xs tracking-widest uppercase transition-colors cursor-pointer ${
                            filterAvailability === option.val 
                              ? 'text-[#1C1917] font-bold underline decoration-2 underline-offset-4' 
                              : 'text-[#78716C] hover:text-[#1C1917]'
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Specifications & assistance */}
                  <div className="border-t border-[#EBE6DF] pt-6 font-mono text-[10px] text-[#78716C] leading-relaxed">
                    <span>DESIGN SPECIFICATIONS ASSIST</span>
                    <p className="mt-2 text-[#A8A29E]">
                      All our products are crafted strictly using 100% food-safe lead-free compounds and fired to peak vitrification.
                    </p>
                  </div>
                </div>

                {/* PRODUCT GRID */}
                <div className="lg:col-span-3">
                  {filteredProducts.length === 0 ? (
                    <div className="py-24 text-center border border-dashed border-[#D6CEBE]/60 bg-white/40">
                      <p className="text-sm italic font-serif text-[#78716C]">
                        No premium ceramics found matching your selected filters.
                      </p>
                      <button
                        onClick={() => {
                          setFilterCategory('ALL');
                          setSortBy('DEFAULT');
                          setFilterAvailability('ALL');
                        }}
                        className="mt-6 text-xs font-mono uppercase tracking-widest font-semibold text-[#1C1917] hover:underline cursor-pointer"
                      >
                        Reset All Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-8 gap-y-16">
                      {filteredProducts.map((product, idx) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          onClick={() => {
                            setSelectedProductId(product.id);
                            setActiveView('product-detail');
                            window.scrollTo({ top: 0 });
                          }}
                          isFavorite={favorites.includes(product.id)}
                          onToggleFavorite={(e) => {
                            e.stopPropagation();
                            handleToggleFavorite(product.id);
                          }}
                          index={idx}
                        />
                      ))}
                    </div>
                  )}
                </div>

              </div>
            </motion.div>
          )}

          {/* VIEW 3: PRODUCT DETAIL */}
          {activeView === 'product-detail' && (
            <motion.div
              key="product-detail"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              {(() => {
                const selectedProd = products.find((p) => p.id === selectedProductId) || products[0];
                return (
                  <ProductDetail
                    product={selectedProd}
                    onBack={() => setActiveView('shop')}
                    onAddToBag={handleAddToBag}
                    isFavorite={favorites.includes(selectedProd.id)}
                    onToggleFavorite={() => handleToggleFavorite(selectedProd.id)}
                  />
                );
              })()}
            </motion.div>
          )}

          {/* VIEW 4: CRAFT / JOURNAL */}
          {(activeView === 'craft' || activeView === 'journal') && (
            <motion.div
              key="journal"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <JournalSection />
            </motion.div>
          )}

          {/* VIEW 5: ABOUT */}
          {activeView === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mx-auto max-w-3xl px-4 sm:px-6 py-16"
            >
              <span className="text-xs tracking-widest text-[#78716C] font-mono uppercase block mb-1">
                OUR CODES AND VALUES
              </span>
              <h1 className="text-3xl sm:text-5xl font-serif text-[#1C1917] tracking-wider uppercase mb-8">
                ABOUT THE STUDIO
              </h1>

              <div className="space-y-6 text-sm text-[#57534E] leading-relaxed">
                <p className="first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:float-left first-letter:mr-3 first-letter:mt-1 font-serif text-lg text-stone-800 leading-relaxed">
                  Founded in 2026, British Pottery was conceived as a radical critique against single-use, mass-manufactured, fragile tableware. We believe that everyday objects should offer rich sensory and visual communion.
                </p>
                <p>
                  We merge Stoke-on-Trent's iconic manufacturing heritage and rigorous engineering precision with contemporary architectural form and reactive silicate chemistries. Every cup, plate, and vase is individually cast or wheel-trimmed, hand-glazed with local reactive oxides, and vitrified at extreme temperatures to establish unbreakable, heirloom-grade durability.
                </p>
                
                <h3 className="text-xs font-mono tracking-widest text-[#1C1917] uppercase pt-6 font-semibold">
                  OUR STUDIO METRICS
                </h3>
                <dl className="grid grid-cols-2 sm:grid-cols-3 gap-6 font-mono text-xs border-t border-[#EBE6DF] pt-4">
                  <div>
                    <dt className="text-[#A8A29E] uppercase">Est. Foundation</dt>
                    <dd className="text-[#1C1917] font-semibold mt-1">Stoke-on-Trent, UK</dd>
                  </div>
                  <div>
                    <dt className="text-[#A8A29E] uppercase">Vitrification Peak</dt>
                    <dd className="text-[#1C1917] font-semibold mt-1">1280 Degrees Celsius</dd>
                  </div>
                  <div>
                    <dt className="text-[#A8A29E] uppercase">Lifecycle Target</dt>
                    <dd className="text-[#1C1917] font-semibold mt-1">200+ Years Active</dd>
                  </div>
                </dl>
              </div>
            </motion.div>
          )}

          {/* VIEW 6: SECURE SIMULATED CHECKOUT */}
          {activeView === 'checkout' && (
            <motion.div
              key="checkout"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <CheckoutView
                cart={cart}
                onCompleteOrder={handleCompleteOrder}
                onBack={() => setActiveView('shop')}
              />
            </motion.div>
          )}

          {/* VIEW 7: FAVORITES */}
          {activeView === 'favorites' && (
            <motion.div
              key="favorites"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12"
            >
              <h1 className="text-3xl font-serif tracking-wider uppercase text-[#1C1917] mb-8 border-b border-[#EBE6DF] pb-4">
                FAVORITES ({favorites.length})
              </h1>

              {favorites.length === 0 ? (
                <div className="py-24 text-center border border-dashed border-[#D6CEBE]/60 bg-white/40">
                  <p className="text-sm italic font-serif text-[#78716C]">
                    You haven't saved any ceramic pieces to your collection yet.
                  </p>
                  <button
                    onClick={() => setActiveView('shop')}
                    className="mt-6 px-6 py-2.5 text-xs font-mono uppercase tracking-widest font-semibold text-white bg-[#1C1917] hover:bg-[#292524] transition-colors rounded-sm cursor-pointer"
                  >
                    Explore Works
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
                  {products
                    .filter((p) => favorites.includes(p.id))
                    .map((product, idx) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        onClick={() => {
                          setSelectedProductId(product.id);
                          setActiveView('product-detail');
                          window.scrollTo({ top: 0 });
                        }}
                        isFavorite={true}
                        onToggleFavorite={(e) => {
                          e.stopPropagation();
                          handleToggleFavorite(product.id);
                        }}
                        index={idx}
                      />
                    ))}
                </div>
              )}
            </motion.div>
          )}

          {/* VIEW 8: ORDER CONFIRMATION / RECEIPT */}
          {activeView === 'order-confirmation' && orderConfirm && (
            <motion.div
              key="order-confirmation"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="mx-auto max-w-xl px-4 py-16 text-center"
            >
              <div className="bg-white border border-[#EBE6DF] p-8 sm:p-12 rounded-sm shadow-md space-y-6">
                <CheckCircle2 className="h-16 w-16 text-emerald-600 mx-auto stroke-[1.2]" />
                
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-emerald-700 bg-emerald-50 px-3 py-1 uppercase rounded-full">
                    simulated payment successful
                  </span>
                  <h1 className="text-3xl font-serif text-[#1C1917] uppercase tracking-wide mt-4">
                    ORDER CONFIRMED
                  </h1>
                  <span className="block text-xs font-mono text-[#78716C] mt-2">
                    REFERENCE ACCESSION: {orderConfirm.orderId}
                  </span>
                </div>

                <div className="border-t border-b border-[#EBE6DF]/70 py-6 text-left space-y-3 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="text-[#78716C]">RECIPIENT:</span>
                    <span className="text-[#1C1917] font-semibold">{orderConfirm.details.firstName} {orderConfirm.details.lastName}</span>
                  </div>
                  <div className="flex justify-between font-mono">
                    <span className="text-[#78716C]">DELIVERY ADDRESS:</span>
                    <span className="text-[#1C1917] font-semibold">{orderConfirm.details.address}, {orderConfirm.details.city}</span>
                  </div>
                  <div className="flex justify-between font-mono">
                    <span className="text-[#78716C]">POSTAL CODE:</span>
                    <span className="text-[#1C1917] font-semibold">{orderConfirm.details.postalCode}</span>
                  </div>
                  <div className="flex justify-between font-mono">
                    <span className="text-[#78716C]">METHOD:</span>
                    <span className="text-[#1C1917] font-semibold uppercase">{orderConfirm.details.deliveryType} Mail Courier</span>
                  </div>
                </div>

                <div className="text-sm text-[#57534E] leading-relaxed">
                  <p>
                    Thank you for your investment in premium British craft. Your physical order receipt has been simulated, and your items are being safely prepared for kiln-departure.
                  </p>
                </div>

                <div className="pt-4 flex flex-col sm:flex-row gap-4">
                  <button
                    onClick={() => {
                      setActiveView('shop');
                      setOrderConfirm(null);
                    }}
                    className="flex-1 px-6 py-3.5 bg-[#1C1917] hover:bg-[#292524] text-white text-xs font-semibold tracking-widest uppercase transition-colors rounded-sm cursor-pointer"
                  >
                    CONTINUE SHOPPING
                  </button>
                  <button
                    onClick={() => {
                      setActiveView('home');
                      setOrderConfirm(null);
                    }}
                    className="px-6 py-3.5 border border-[#D6CEBE] text-[#57534E] hover:text-[#1C1917] text-xs font-mono tracking-widest uppercase transition-colors rounded-sm cursor-pointer"
                  >
                    RETURN HOME
                  </button>
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      <Footer setActiveView={(view) => {
        setActiveView(view);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }} />

    </div>
  );
}
