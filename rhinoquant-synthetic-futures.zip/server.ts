import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import {
  buildForwardCurve,
  buildVolSurface,
  calculateMarginRequirement,
  calculateSyntheticFairValue,
  executeRResearchScript,
  runMonteCarloSimulation,
  runScenarioAnalysis,
} from './src/engine/quantEngine.js';
import { globalMarketSim } from './src/engine/marketSim.js';
import { INITIAL_POSITIONS, INITIAL_SYNTHETIC_CONFIGS } from './src/data/mockData.js';
import { AssetClass, Position, SyntheticFutureConfig } from './src/types/rhinoquant.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws/market' });

// Store in-memory state
let syntheticConfigs: SyntheticFutureConfig[] = [...INITIAL_SYNTHETIC_CONFIGS];
let currentPositions: Position[] = [...INITIAL_POSITIONS];

// WebSockets broadcaster
const clients = new Set<WebSocket>();

wss.on('connection', (ws) => {
  clients.add(ws);
  ws.send(JSON.stringify({ type: 'INIT', markets: globalMarketSim.getAllMarkets(), regime: globalMarketSim.getRegime() }));

  ws.on('close', () => {
    clients.delete(ws);
  });
});

// Periodic market tick simulation
setInterval(() => {
  globalMarketSim.tickSimulation();
  const markets = globalMarketSim.getAllMarkets();
  const payload = JSON.stringify({
    type: 'MARKET_TICK',
    timestamp: new Date().toISOString(),
    regime: globalMarketSim.getRegime(),
    markets
  });

  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  }
}, 1500);

// --- REST API ENDPOINTS ---

// GET /api/v1/instruments
app.get('/api/v1/instruments', (req, res) => {
  const markets = globalMarketSim.getAllMarkets();
  res.json({ status: 'SUCCESS', count: markets.length, data: markets });
});

// GET /api/v1/curves
app.get('/api/v1/curves', (req, res) => {
  const underlying = (req.query.underlying as string) || 'COPPER';
  const spot = Number(req.query.spot) || 10482;
  const assetClass = (req.query.assetClass as AssetClass) || 'METALS';
  const curve = buildForwardCurve(underlying, assetClass, spot);
  res.json({ status: 'SUCCESS', data: curve });
});

// GET /api/v1/volatility
app.get('/api/v1/volatility', (req, res) => {
  const underlying = (req.query.underlying as string) || 'COPPER';
  const volSurface = buildVolSurface(underlying);
  res.json({ status: 'SUCCESS', data: volSurface });
});

// GET /api/v1/synthetics
app.get('/api/v1/synthetics', (req, res) => {
  const results = syntheticConfigs.map(config => {
    const market = globalMarketSim.getMarket(config.observedFutureSymbol || '');
    const pricing = calculateSyntheticFairValue(config, market?.observedPrice);
    return {
      config,
      pricing
    };
  });
  res.json({ status: 'SUCCESS', count: results.length, data: results });
});

// POST /api/v1/synthetics
app.post('/api/v1/synthetics', (req, res) => {
  const body = req.body as SyntheticFutureConfig;
  const newConfig: SyntheticFutureConfig = {
    ...body,
    id: body.id || `RQ-SYN-${Date.now().toString().slice(-6)}`
  };
  syntheticConfigs.push(newConfig);

  const pricing = calculateSyntheticFairValue(newConfig);
  res.json({ status: 'SUCCESS', data: { config: newConfig, pricing } });
});

// GET /api/v1/pricing/:id
app.get('/api/v1/pricing/:id', (req, res) => {
  const config = syntheticConfigs.find(c => c.id === req.params.id) || syntheticConfigs[0];
  const market = globalMarketSim.getMarket(config.observedFutureSymbol || '');
  const pricing = calculateSyntheticFairValue(config, market?.observedPrice);
  res.json({ status: 'SUCCESS', data: pricing });
});

// GET /api/v1/portfolio
app.get('/api/v1/portfolio', (req, res) => {
  const totalNotional = currentPositions.reduce((acc, p) => acc + p.notional, 0);
  const grossExposure = currentPositions.reduce((acc, p) => acc + Math.abs(p.notional), 0);
  const netExposure = currentPositions.reduce((acc, p) => acc + (p.quantity > 0 ? p.notional : -p.notional), 0);
  const unrealizedPnL = currentPositions.reduce((acc, p) => acc + p.unrealizedPnL, 0);
  const realizedPnL = currentPositions.reduce((acc, p) => acc + p.realizedPnL, 0);

  const totalDelta = currentPositions.reduce((acc, p) => acc + p.greeks.delta, 0);
  const totalGamma = currentPositions.reduce((acc, p) => acc + p.greeks.gamma, 0);
  const totalVega = currentPositions.reduce((acc, p) => acc + p.greeks.vega, 0);
  const totalTheta = currentPositions.reduce((acc, p) => acc + p.greeks.theta, 0);
  const totalRho = currentPositions.reduce((acc, p) => acc + p.greeks.rho, 0);
  const totalDv01 = currentPositions.reduce((acc, p) => acc + p.greeks.dv01, 0);

  res.json({
    status: 'SUCCESS',
    data: {
      totalNotional,
      grossExposure,
      netExposure,
      marketValue: totalNotional + unrealizedPnL,
      unrealizedPnL,
      realizedPnL,
      totalPnL: unrealizedPnL + realizedPnL,
      portfolioGreeks: {
        delta: Number(totalDelta.toFixed(1)),
        gamma: Number(totalGamma.toFixed(4)),
        vega: Number(totalVega.toFixed(1)),
        theta: Number(totalTheta.toFixed(1)),
        rho: Number(totalRho.toFixed(1)),
        dv01: Number(totalDv01.toFixed(3)),
        cs01: Number((totalDv01 * 0.8).toFixed(3))
      },
      positions: currentPositions
    }
  });
});

// GET /api/v1/margin
app.get('/api/v1/margin', (req, res) => {
  const totalNotional = currentPositions.reduce((acc, p) => acc + p.notional, 0);
  const netExposure = currentPositions.reduce((acc, p) => acc + (p.quantity > 0 ? p.notional : -p.notional), 0);
  const mockGreeks = { delta: 120, gamma: 0.008, vega: 1250, theta: -110, rho: 360, dv01: 3.6, cs01: 2.88 };

  const margin = calculateMarginRequirement(totalNotional, netExposure, mockGreeks);
  res.json({ status: 'SUCCESS', data: margin });
});

// POST /api/v1/scenarios/run
app.post('/api/v1/scenarios/run', (req, res) => {
  const config = req.body;
  const results = runScenarioAnalysis(currentPositions, config);
  res.json({ status: 'SUCCESS', data: results });
});

// POST /api/v1/monte-carlo/run
app.post('/api/v1/monte-carlo/run', (req, res) => {
  const { simulations, horizonDays, volatility } = req.body;
  const result = runMonteCarloSimulation(13850000, volatility || 0.22, horizonDays || 10, simulations || 10000);
  res.json({ status: 'SUCCESS', data: result });
});

// POST /api/v1/r-research/run
app.post('/api/v1/r-research/run', (req, res) => {
  const result = executeRResearchScript(req.body);
  res.json({ status: 'SUCCESS', data: result });
});

// POST /api/v1/regime
app.post('/api/v1/regime', (req, res) => {
  const { regime } = req.body;
  if (regime) {
    globalMarketSim.setRegime(regime);
  }
  res.json({ status: 'SUCCESS', regime: globalMarketSim.getRegime() });
});

// Vite Middleware integration in Dev Mode
async function startServer() {
  const PORT = process.env.PORT || 3000;

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, () => {
    console.log(`[RHINOQUANT] Platform server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
