import { MarketMaker, MarketRegime, OrderBook, Position } from '../types/rhinoquant';

export interface MarketState {
  symbol: string;
  name: string;
  assetClass: string;
  observedPrice: number;
  syntheticPrice: number;
  basis: number;
  volatility: number;
  bid: number;
  ask: number;
  volume24h: number;
  change24h: number;
  orderBook: OrderBook;
}

export const INITIAL_MARKET_MAKERS: MarketMaker[] = [
  { id: 'MM-A', name: 'MARKET_MAKER_A (Barclays Capital)', type: 'MARKET_MAKER', spreadBps: 2.5, inventory: 450, riskLimit: 5000, quoteSize: 25, volatilitySensitivity: 1.2 },
  { id: 'MM-B', name: 'MARKET_MAKER_B (Macquarie Commodities)', type: 'MARKET_MAKER', spreadBps: 3.0, inventory: -220, riskLimit: 4000, quoteSize: 50, volatilitySensitivity: 1.5 },
  { id: 'HF-A', name: 'HEDGE_FUND_A (Brevan Howard Macro)', type: 'HEDGE_FUND', spreadBps: 5.0, inventory: 1200, riskLimit: 10000, quoteSize: 100, volatilitySensitivity: 2.1 },
  { id: 'CD-1', name: 'COMMODITY_DESK (Glencore Derivatives)', type: 'COMMODITY_DESK', spreadBps: 2.0, inventory: -850, riskLimit: 15000, quoteSize: 75, volatilitySensitivity: 0.9 },
  { id: 'ARB-1', name: 'ARBITRAGEUR (Rhino Quant Arbitrage)', type: 'ARBITRAGEUR', spreadBps: 1.5, inventory: 15, riskLimit: 2000, quoteSize: 10, volatilitySensitivity: 2.8 },
  { id: 'LP-1', name: 'LIQUIDITY_PROVIDER (Citadel Securities)', type: 'LIQUIDITY_PROVIDER', spreadBps: 1.8, inventory: 120, riskLimit: 8000, quoteSize: 150, volatilitySensitivity: 1.0 },
];

export class MarketSimulator {
  private markets: Map<string, MarketState> = new Map();
  private regime: MarketRegime = 'NORMAL';
  private replaySpeed: number = 1; // 1x, 10x, 100x
  private isReplaying: boolean = false;
  private listeners: Set<(markets: MarketState[]) => void> = new Set();

  constructor() {
    this.seedMarkets();
  }

  private seedMarkets() {
    const rawData = [
      { symbol: 'COPPER-202712', name: 'Copper Grade A Dec 2027', assetClass: 'METALS', price: 10482, synPrice: 10497, vol: 24.7 },
      { symbol: 'TIN-202712', name: 'Tin 99.85% LME Dec 2027', assetClass: 'METALS', price: 34252, synPrice: 34210, vol: 28.2 },
      { symbol: 'BRENT-202706', name: 'Brent Crude Ice Jun 2027', assetClass: 'ENERGY', price: 81.39, synPrice: 81.47, vol: 31.1 },
      { symbol: 'WHEAT-202709', name: 'Milling Wheat Paris Sep 2027', assetClass: 'AGRICULTURE', price: 232.5, synPrice: 233.8, vol: 19.5 },
      { symbol: 'DAIRY-202712', name: 'Rhino Butter/SMP Dec 2027', assetClass: 'DAIRY', price: 3830, synPrice: 3842, vol: 18.4 },
      { symbol: 'FREIGHT-202712', name: 'Capesize Route C5 Dec 2027', assetClass: 'FREIGHT', price: 1293, synPrice: 1284, vol: 22.7 },
      { symbol: 'POWER-UK-2027', name: 'UK Power Baseload 2027', assetClass: 'POWER', price: 84.5, synPrice: 85.2, vol: 35.8 },
      { symbol: 'SONIA-3M-2027', name: 'SONIA 3M Futures Dec 2027', assetClass: 'RATES', price: 95.82, synPrice: 95.85, vol: 8.4 },
      { symbol: 'GBPUSD-202712', name: 'GBP/USD Forward Dec 2027', assetClass: 'FX', price: 1.2845, synPrice: 1.2852, vol: 9.8 },
      { symbol: 'METALS-BASKET', name: 'Rhino 5-Metals Basket Future', assetClass: 'CUSTOM', price: 15420, synPrice: 15438, vol: 21.3 }
    ];

    for (const m of rawData) {
      const spread = m.price * 0.0006;
      const basis = m.synPrice - m.price;
      const state: MarketState = {
        symbol: m.symbol,
        name: m.name,
        assetClass: m.assetClass,
        observedPrice: m.price,
        syntheticPrice: m.synPrice,
        basis: Number(basis.toFixed(2)),
        volatility: m.vol,
        bid: Number((m.synPrice - spread / 2).toFixed(2)),
        ask: Number((m.synPrice + spread / 2).toFixed(2)),
        volume24h: Math.floor(Math.random() * 8000 + 1200),
        change24h: Number(((Math.random() - 0.48) * 1.8).toFixed(2)),
        orderBook: this.generateOrderBook(m.symbol, m.synPrice, spread)
      };
      this.markets.set(m.symbol, state);
    }
  }

  private generateOrderBook(symbol: string, mid: number, spread: number): OrderBook {
    const halfSpread = spread / 2;
    const bids = [];
    const asks = [];

    const isSmallNumber = mid < 100;
    const step = isSmallNumber ? 0.02 : mid < 1000 ? 0.5 : 5.0;

    for (let i = 0; i < 5; i++) {
      bids.push({
        price: Number((mid - halfSpread - i * step).toFixed(2)),
        quantity: Math.floor(Math.random() * 40 + 10) * 5,
        ordersCount: Math.floor(Math.random() * 4 + 1)
      });
      asks.push({
        price: Number((mid + halfSpread + i * step).toFixed(2)),
        quantity: Math.floor(Math.random() * 40 + 10) * 5,
        ordersCount: Math.floor(Math.random() * 4 + 1)
      });
    }

    return {
      symbol,
      bids,
      asks,
      lastTradePrice: Number((mid + (Math.random() - 0.5) * halfSpread).toFixed(2)),
      lastTradeSize: Math.floor(Math.random() * 20 + 5),
      lastTradeTime: new Date().toLocaleTimeString('en-GB', { hour12: false }),
      simulatedSpread: Number(spread.toFixed(2)),
      impliedSyntheticMid: Number(mid.toFixed(2))
    };
  }

  public setRegime(newRegime: MarketRegime) {
    this.regime = newRegime;
    this.tickSimulation();
  }

  public getRegime(): MarketRegime {
    return this.regime;
  }

  public tickSimulation() {
    let volMultiplier = 1.0;
    let basisBias = 0.0;

    if (this.regime === 'HIGH_VOLATILITY') volMultiplier = 2.5;
    if (this.regime === 'LIQUIDITY_CRISIS') volMultiplier = 4.0;
    if (this.regime === 'BASIS_SHOCK') basisBias = 18.5;
    if (this.regime === 'CONTANGO') basisBias = 25.0;
    if (this.regime === 'BACKWARDATION') basisBias = -30.0;

    for (const [symbol, state] of this.markets.entries()) {
      const vol = (state.volatility / 100) * volMultiplier;
      const noise = (Math.random() - 0.495) * 0.002 * vol;

      state.observedPrice = Number((state.observedPrice * (1 + noise)).toFixed(2));

      // Synthetic responds with model lag
      const syntheticNoise = noise * 0.98 + (Math.random() - 0.5) * 0.0005;
      state.syntheticPrice = Number((state.syntheticPrice * (1 + syntheticNoise) + basisBias * 0.02).toFixed(2));

      state.basis = Number((state.syntheticPrice - state.observedPrice).toFixed(2));

      const spread = state.syntheticPrice * 0.0006 * volMultiplier;
      state.bid = Number((state.syntheticPrice - spread / 2).toFixed(2));
      state.ask = Number((state.syntheticPrice + spread / 2).toFixed(2));

      state.orderBook = this.generateOrderBook(symbol, state.syntheticPrice, spread);
    }

    this.notifyListeners();
  }

  public subscribe(listener: (markets: MarketState[]) => void) {
    this.listeners.add(listener);
    listener(Array.from(this.markets.values()));
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    const data = Array.from(this.markets.values());
    for (const listener of this.listeners) {
      listener(data);
    }
  }

  public getAllMarkets(): MarketState[] {
    return Array.from(this.markets.values());
  }

  public getMarket(symbol: string): MarketState | undefined {
    return this.markets.get(symbol);
  }
}

export const globalMarketSim = new MarketSimulator();
