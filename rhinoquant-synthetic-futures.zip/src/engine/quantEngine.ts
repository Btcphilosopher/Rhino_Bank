import {
  AssetClass,
  ForwardCurve,
  Greeks,
  InterpolationMethod,
  MarginRequirement,
  MonteCarloResult,
  PnLAttribution,
  PortfolioSummary,
  Position,
  PricingResult,
  RQueryResult,
  RScriptRunRequest,
  ScenarioConfig,
  ScenarioResult,
  SyntheticFutureConfig,
  VolSurface,
} from '../types/rhinoquant';

// --- MATH UTILITIES ---
export function normCdf(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.sqrt(2.0);

  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);

  return 0.5 * (1.0 + sign * y);
}

export function normPdf(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

// Black-76 Option Pricing for Futures / Commodities
export function black76Price(
  isCall: boolean,
  F: number,
  K: number,
  T: number,
  r: number,
  sigma: number
): { price: number; greeks: Greeks } {
  if (T <= 0.0001) {
    const intrinsic = isCall ? Math.max(0, F - K) : Math.max(0, K - F);
    return {
      price: intrinsic,
      greeks: { delta: isCall ? (F > K ? 1 : 0) : (F < K ? -1 : 0), gamma: 0, vega: 0, theta: 0, rho: 0, dv01: 0, cs01: 0 }
    };
  }

  const sqrtT = Math.sqrt(T);
  const d1 = (Math.log(F / K) + (0.5 * sigma * sigma) * T) / (sigma * sqrtT);
  const d2 = d1 - sigma * sqrtT;
  const df = Math.exp(-r * T);

  let price = 0;
  let delta = 0;

  if (isCall) {
    price = df * (F * normCdf(d1) - K * normCdf(d2));
    delta = df * normCdf(d1);
  } else {
    price = df * (K * normCdf(-d2) - F * normCdf(-d1));
    delta = -df * normCdf(-d1);
  }

  const gamma = (df * normPdf(d1)) / (F * sigma * sqrtT);
  const vega = (F * df * normPdf(d1) * sqrtT) / 100; // per 1% vol
  const theta = (- (F * df * normPdf(d1) * sigma) / (2 * sqrtT) + (isCall ? r * df * (F * normCdf(d1) - K * normCdf(d2)) : r * df * (K * normCdf(-d2) - F * normCdf(-d1)))) / 365;
  const rho = (isCall ? -T * df * (F * normCdf(d1) - K * normCdf(d2)) : -T * df * (K * normCdf(-d2) - F * normCdf(-d1))) / 10000;
  const dv01 = Math.abs(rho);

  return {
    price: Math.max(0, price),
    greeks: { delta, gamma, vega, theta, rho, dv01, cs01: dv01 * 0.8 }
  };
}

// Implied Volatility Solver (Newton-Raphson)
export function solveImpliedVol(
  isCall: boolean,
  targetPrice: number,
  F: number,
  K: number,
  T: number,
  r: number
): number {
  let sigma = 0.25;
  for (let i = 0; i < 20; i++) {
    const res = black76Price(isCall, F, K, T, r, sigma);
    const diff = res.price - targetPrice;
    if (Math.abs(diff) < 1e-5) break;
    const vega = res.greeks.vega * 100;
    if (Math.abs(vega) < 1e-6) break;
    sigma = sigma - diff / vega;
    if (sigma <= 0.001) sigma = 0.001;
    if (sigma >= 3.0) sigma = 3.0;
  }
  return sigma;
}

// --- SYNTHETIC FAIR VALUE ENGINE ---
export function calculateSyntheticFairValue(
  config: SyntheticFutureConfig,
  observedFuturePrice?: number
): PricingResult {
  const T = 1.25; // default 1.25 years (e.g. Dec 2027)
  const r = config.financingRate / 100;

  let fairValue = 0;
  let modelEquations: string[] = [];
  let modelAssumptions: string[] = [];
  let modelInputs: Record<string, any> = {};

  if (config.syntheticType === 'SYNTHETIC_LONG_FUTURE' || config.syntheticType === 'SYNTHETIC_SHORT_FUTURE') {
    // Parity: Long Call + Short Put -> Synthetic Long
    const callLeg = config.legs.find(l => l.type === 'CALL');
    const putLeg = config.legs.find(l => l.type === 'PUT');
    const strike = callLeg?.strike || putLeg?.strike || 10000;
    const callPrice = callLeg?.price || 500;
    const putPrice = putLeg?.price || 480;

    const isLong = config.syntheticType === 'SYNTHETIC_LONG_FUTURE';
    // Parity equation: F = K + e^{rT} * (Call - Put)
    const netOptionDiff = isLong ? (callPrice - putPrice) : (putPrice - callPrice);
    const parityAdjust = Math.exp(r * T) * netOptionDiff;
    fairValue = strike + parityAdjust;

    modelEquations = [
      'Call-Put Parity: F_{synthetic} = Strike + e^{rT} \\times (C_{call} - P_{put})',
      'Transaction Cost Adjustment: F_{net} = F_{synthetic} \\pm \\text{Slippage}'
    ];
    modelAssumptions = [
      'European options with identical strike and expiry',
      'Continuous compounding at risk-free rate r',
      'Zero arbitrage condition holds across liquidity pools'
    ];
    modelInputs = {
      strike,
      callPrice,
      putPrice,
      financingRatePct: config.financingRate,
      timeToExpiryYears: T
    };
  } else if (config.syntheticType === 'SYNTHETIC_COMMODITY') {
    // Cost of Carry: F = Spot * exp((r + storage - convenience) * T)
    const spotLeg = config.legs.find(l => l.type === 'SPOT');
    const spot = spotLeg?.price || 10450;
    const s = config.storageCost / 100;
    const c = config.convenienceYield / 100;

    fairValue = spot * Math.exp((r + s - c) * T);

    modelEquations = [
      'Cost of Carry Model: F_{commodity} = S \\times e^{(r + s - c)T}',
      'where r = financing rate, s = storage cost %, c = convenience yield %'
    ];
    modelAssumptions = [
      'Constant storage cost over contract tenor',
      'Convenience yield estimated from inventory levels and physical tightness',
      'Continuous physical delivery'
    ];
    modelInputs = {
      spotPrice: spot,
      financingRatePct: config.financingRate,
      storageCostPct: config.storageCost,
      convenienceYieldPct: config.convenienceYield,
      timeToExpiryYears: T
    };
  } else if (config.syntheticType === 'SYNTHETIC_FX') {
    // Covered Interest Rate Parity: F = S * (1 + rd * T) / (1 + rf * T)
    const spotLeg = config.legs.find(l => l.type === 'SPOT');
    const spot = spotLeg?.price || 1.2850;
    const rd = (config.domesticRate || 4.25) / 100;
    const rf = (config.foreignRate || 3.75) / 100;

    fairValue = spot * ((1 + rd * T) / (1 + rf * T));

    modelEquations = [
      'Covered Interest Parity: F_{FX} = S \\times \\frac{1 + r_{domestic} T}{1 + r_{foreign} T}'
    ];
    modelAssumptions = [
      'No capital controls or swap line friction',
      'Matching interest rate tenor'
    ];
    modelInputs = { spot, domesticRatePct: rd * 100, foreignRatePct: rf * 100, T };
  } else if (config.syntheticType === 'SYNTHETIC_FREIGHT') {
    // Freight Route Index + Fuel Bunker Adjustment + Congestion Factor
    const indexLeg = config.legs.find(l => l.type === 'INDEX');
    const routeIndex = indexLeg?.price || config.routeIndex || 1280;
    const bunker = config.bunkerPrice || 620;
    const fuelAdj = (bunker - 600) * 0.15;
    fairValue = routeIndex + fuelAdj + 12.5; // congestion premium

    modelEquations = [
      'Synthetic Freight Parity: F_{freight} = \\text{RouteIndex} + 0.15 \\times (P_{bunker} - P_{base}) + \\text{CongestionPremium}'
    ];
    modelAssumptions = [
      'Capesize Baltic Route C5 benchmark',
      'Low sulphur fuel oil (LSFO) price sensitivity factor = 0.15'
    ];
    modelInputs = { routeIndex, bunkerPrice: bunker, congestionPremium: 12.5 };
  } else if (config.syntheticType === 'SYNTHETIC_POWER') {
    // Power Spark Spread Parity: Spark Spread = P_gas * HeatRate + P_carbon * CarbonIntensity + Margin
    const gas = config.gasPrice || 78.5; // p/therm
    const carbon = config.carbonPrice || 68.2; // EUR/tonne
    const heatRate = 1.95;
    const carbonIntensity = 0.38;

    fairValue = (gas * heatRate) + (carbon * carbonIntensity) + 8.5;

    modelEquations = [
      'Clean Spark Spread Model: F_{power} = P_{gas} \\times \\text{HeatRate} + P_{carbon} \\times \\text{CarbonIntensity} + \\text{CleanSparkMargin}'
    ];
    modelAssumptions = [
      '50% CCGT plant efficiency factor',
      'UK ETS carbon allowance inclusion'
    ];
    modelInputs = { gasPrice: gas, carbonPrice: carbon, heatRate, carbonIntensity };
  } else if (config.syntheticType === 'SYNTHETIC_DAIRY') {
    // Milk yield synthesis
    const milk = config.milkPrice || 42.5; // p/litre
    const processing = config.processingMargin || 12.0;
    fairValue = (milk * 88.5) + processing; // £/tonne equivalent

    modelEquations = [
      'Rhino Dairy Component Synthesis: F_{butter/smp} = P_{raw\\_milk} \\times \\text{ConversionYield} + \\text{ProcessingCost}'
    ];
    modelAssumptions = [
      'Fat content 4.2%, Protein content 3.4%',
      'Standard UK creamery yield table'
    ];
    modelInputs = { rawMilkPrice: milk, processingCost: processing };
  } else {
    // Default fallback
    const spot = config.legs[0]?.price || 1000;
    fairValue = spot * (1 + (r * T));
    modelEquations = ['Standard Carry Model: F = S \\times (1 + r T)'];
    modelAssumptions = ['Generic interest rate compounding'];
    modelInputs = { spot, r: config.financingRate, T };
  }

  // Adjust for transaction cost & slippage
  const tCost = config.transactionCost || 0.5;
  const slippage = config.slippage || 0.2;
  const bid = fairValue - tCost - slippage;
  const ask = fairValue + tCost + slippage;
  const mid = fairValue;

  const obs = observedFuturePrice ?? (fairValue - 15.4); // Observed benchmark
  const basis = fairValue - obs;
  const basisPercent = (basis / obs) * 100;
  const basisVol = 0.082; // 8.2% basis volatility
  const zScore = basis / (obs * basisVol * Math.sqrt(T));
  const forwardPremium = fairValue - (config.legs[0]?.price || fairValue * 0.95);

  const delta = config.syntheticType === 'SYNTHETIC_SHORT_FUTURE' ? -1.0 : 1.0;
  const gamma = 0.00012;
  const vega = 14.8;
  const theta = -1.25;
  const rho = 4.85;
  const dv01 = 0.0485;

  return {
    syntheticId: config.id,
    fairValue: Number(fairValue.toFixed(2)),
    bid: Number(bid.toFixed(2)),
    ask: Number(ask.toFixed(2)),
    mid: Number(mid.toFixed(2)),
    observedPrice: Number(obs.toFixed(2)),
    basis: Number(basis.toFixed(2)),
    basisPercent: Number(basisPercent.toFixed(3)),
    basisVol: Number((basisVol * 100).toFixed(2)),
    zScore: Number(zScore.toFixed(2)),
    forwardPremium: Number(forwardPremium.toFixed(2)),
    greeks: { delta, gamma, vega, theta, rho, dv01, cs01: dv01 * 0.8 },
    confidence: 98.5,
    modelId: 'RQ-SYN-FUT-001',
    modelVersion: '1.4.2',
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    status: 'RESEARCH',
    provenance: {
      modelId: 'RQ-SYN-FUT-001',
      modelVersion: '1.4.2',
      calibrationDate: '2026-09-26',
      equations: modelEquations,
      inputs: modelInputs,
      assumptions: modelAssumptions,
      limitations: [
        'Model assumes zero counterparty risk across execution venues',
        'Storage costs subject to physical warehouse capacity constraints',
        'Convenience yield fluctuates with spot inventory spikes'
      ]
    }
  };
}

// --- CURVE ENGINE ---
export function buildForwardCurve(
  underlying: string,
  assetClass: AssetClass,
  spotPrice: number,
  interpolation: InterpolationMethod = 'CUBIC_SPLINE'
): ForwardCurve {
  const tenors = [
    { label: 'SPOT', days: 0, multiplier: 1.0 },
    { label: '1M', days: 30, multiplier: 1.008 },
    { label: '2M', days: 60, multiplier: 1.015 },
    { label: '3M', days: 90, multiplier: 1.022 },
    { label: '6M', days: 180, multiplier: 1.038 },
    { label: '1Y', days: 365, multiplier: 1.062 },
    { label: '2Y', days: 730, multiplier: 1.098 },
    { label: '5Y', days: 1825, multiplier: 1.154 },
  ];

  // Adjust shape based on underlying
  let curveBias = 1.0;
  if (underlying === 'BRENT') curveBias = -0.04; // Backwardation
  if (underlying === 'COPPER') curveBias = 0.025; // Mild Contango
  if (underlying === 'NATURAL_GAS') curveBias = 0.08; // High contango / seasonality

  const points = tenors.map((t, idx) => {
    const rawPrice = spotPrice * (1 + (t.days / 365) * curveBias);
    const forwardRate = (rawPrice / spotPrice - 1) / Math.max(0.01, t.days / 365);
    const source = idx === 0 || idx === 3 || idx === 5 ? 'OBSERVED' : 'INTERPOLATED';
    return {
      tenor: t.label,
      daysToExpiry: t.days,
      price: Number(rawPrice.toFixed(2)),
      forwardRate: Number((forwardRate * 100).toFixed(2)),
      source: source as 'OBSERVED' | 'INTERPOLATED' | 'EXTRAPOLATED'
    };
  });

  const slope = points[points.length - 1].price - points[0].price;
  const contangoStatus = slope > 2 ? 'CONTANGO' : slope < -2 ? 'BACKWARDATION' : 'FLAT';
  const annualizedRollYield = Number(((points[0].price - points[3].price) / points[0].price * 4 * 100).toFixed(2));

  return {
    id: `CURVE-${underlying}`,
    underlying,
    assetClass,
    spot: spotPrice,
    points,
    interpolation,
    slope: Number(slope.toFixed(2)),
    curvature: 0.14,
    contangoStatus,
    annualizedRollYield
  };
}

// --- VOLATILITY SURFACE ENGINE ---
export function buildVolSurface(underlying: string, baseVol: number = 0.247): VolSurface {
  const expiries = ['1M', '3M', '6M', '1Y', '2Y'];
  const expiryDaysMap: Record<string, number> = { '1M': 30, '3M': 90, '6M': 180, '1Y': 365, '2Y': 730 };
  const strikes = [80, 90, 100, 110, 120]; // Pct of ATM

  const points = [];
  for (const exp of expiries) {
    const days = expiryDaysMap[exp];
    for (const Kpct of strikes) {
      // Skew formula: vol = baseVol + skew * (100 - Kpct)/100 + termStructure * sqrt(days/365)
      const skewAdj = 0.12 * ((100 - Kpct) / 100);
      const termAdj = -0.02 * Math.log(days / 30);
      const iv = Math.max(0.05, baseVol + skewAdj + termAdj);
      const delta = Kpct < 100 ? 0.25 : Kpct > 100 ? 0.75 : 0.50;
      points.push({
        strike: Kpct,
        expiryDays: days,
        expiryLabel: exp,
        impliedVol: Number((iv * 100).toFixed(1)),
        delta,
        isObserved: Kpct === 100 || Kpct === 90
      });
    }
  }

  return {
    id: `VOL-${underlying}`,
    underlying,
    atmVol: Number((baseVol * 100).toFixed(1)),
    vol25Call: Number(((baseVol - 0.025) * 100).toFixed(1)),
    vol25Put: Number(((baseVol + 0.038) * 100).toFixed(1)),
    skew: 6.3, // Put - Call skew
    points,
    expiries,
    strikes
  };
}

// --- RISK & SCENARIO ENGINE ---
export function runScenarioAnalysis(
  positions: Position[],
  config: ScenarioConfig
): ScenarioResult[] {
  const scenarios: ScenarioResult[] = [
    {
      scenarioName: 'Base Case (No Shock)',
      portfolioPnL: 0,
      portfolioPnLPct: 0,
      marginChange: 0,
      newVar: 142000,
      breachFlag: false,
      assetClassImpacts: { METALS: 0, ENERGY: 0, DAIRY: 0 }
    },
    {
      scenarioName: `Spot ${config.spotShockPct > 0 ? '+' : ''}${config.spotShockPct}% Shock`,
      portfolioPnL: 384000 * (config.spotShockPct / 10),
      portfolioPnLPct: 2.8 * (config.spotShockPct / 10),
      marginChange: 85000,
      newVar: 185000,
      breachFlag: false,
      assetClassImpacts: { METALS: 210000, ENERGY: 124000, DAIRY: 50000 }
    },
    {
      scenarioName: `Vol +${config.volShockPct}% Volatility Spike`,
      portfolioPnL: -192000 * (config.volShockPct / 15),
      portfolioPnLPct: -1.4 * (config.volShockPct / 15),
      marginChange: 240000,
      newVar: 290000,
      breachFlag: false,
      assetClassImpacts: { METALS: -110000, ENERGY: -62000, DAIRY: -20000 }
    },
    {
      scenarioName: 'Basis Dislocation & Liquidity Squeeze',
      portfolioPnL: -480000,
      portfolioPnLPct: -3.5,
      marginChange: 520000,
      newVar: 410000,
      breachFlag: true,
      assetClassImpacts: { METALS: -280000, ENERGY: -140000, DAIRY: -60000 }
    },
    {
      scenarioName: 'Stagflation Crisis (Commodity +15%, Rates +100bps, USD -5%)',
      portfolioPnL: 640000,
      portfolioPnLPct: 4.6,
      marginChange: 380000,
      newVar: 320000,
      breachFlag: false,
      assetClassImpacts: { METALS: 410000, ENERGY: 210000, DAIRY: 20000 }
    }
  ];

  return scenarios;
}

// --- MONTE CARLO SIMULATOR ---
export function runMonteCarloSimulation(
  portfolioValue: number = 13850000,
  volatility: number = 0.22,
  horizonDays: number = 10,
  simulations: number = 10000
): MonteCarloResult {
  const dt = horizonDays / 365;
  const sqrtDt = Math.sqrt(dt);
  const pnlList: number[] = [];

  for (let i = 0; i < simulations; i++) {
    // Box-Muller transform for Gaussian random numbers
    const u1 = Math.random();
    const u2 = Math.random();
    const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

    // Fat tail Student-t approximation
    const tMultiplier = 1 + 0.15 * (Math.random() - 0.5);
    const returnSim = (0.02 * dt) + volatility * sqrtDt * z * tMultiplier;
    const pnl = portfolioValue * returnSim;
    pnlList.push(pnl);
  }

  pnlList.sort((a, b) => a - b);

  const idx95 = Math.floor(simulations * 0.05);
  const idx99 = Math.floor(simulations * 0.01);

  const var95 = Math.abs(pnlList[idx95]);
  const var99 = Math.abs(pnlList[idx99]);

  // Expected Shortfall 95% (mean of worst 5% losses)
  const es95Sum = pnlList.slice(0, idx95).reduce((acc, v) => acc + v, 0);
  const expectedShortfall95 = Math.abs(es95Sum / idx95);

  // Histogram Bins
  const minPnl = pnlList[0];
  const maxPnl = pnlList[pnlList.length - 1];
  const numBins = 15;
  const binWidth = (maxPnl - minPnl) / numBins;

  const histogram: { bin: string; count: number }[] = [];
  for (let b = 0; b < numBins; b++) {
    const binStart = minPnl + b * binWidth;
    const binEnd = binStart + binWidth;
    const count = pnlList.filter(p => p >= binStart && p < binEnd).length;
    histogram.push({
      bin: `£${(binStart / 1000).toFixed(0)}k`,
      count
    });
  }

  return {
    simulations,
    paths: pnlList.slice(0, 50),
    var95: Number(var95.toFixed(2)),
    var99: Number(var99.toFixed(2)),
    expectedShortfall95: Number(expectedShortfall95.toFixed(2)),
    tailLoss: Number(Math.abs(minPnl).toFixed(2)),
    pnlHistogram: histogram,
    confidenceInterval: [
      Number((var95 * 0.95).toFixed(2)),
      Number((var95 * 1.05).toFixed(2))
    ]
  };
}

// --- RISK-BASED MARGIN ENGINE ---
export function calculateMarginRequirement(
  notional: number,
  netExposure: number,
  riskMetrics: Greeks
): MarginRequirement {
  // Scenario-based risk margin (Initial Margin)
  const priceShock = netExposure * 0.12; // 12% price shock
  const volShock = Math.abs(riskMetrics.vega * 100) * 0.15; // 15% vol shock
  const curveShock = Math.abs(riskMetrics.dv01 * 100) * 0.10;

  const initialMargin = Math.max(notional * 0.05, Math.abs(priceShock) + volShock + curveShock);
  const variationMargin = 45200; // current mark-to-market loss
  const maintenanceMargin = initialMargin * 0.80;

  const concentrationAddOn = netExposure > 5000000 ? (netExposure - 5000000) * 0.03 : 0;
  const liquidityAddOn = 35000;
  const stressMargin = initialMargin * 1.35;

  const totalRequiredMargin = initialMargin + variationMargin + concentrationAddOn + liquidityAddOn;
  const availableCollateral = 1850000;
  const surplusDeficit = availableCollateral - totalRequiredMargin;

  return {
    initialMargin: Number(initialMargin.toFixed(2)),
    variationMargin: Number(variationMargin.toFixed(2)),
    maintenanceMargin: Number(maintenanceMargin.toFixed(2)),
    stressMargin: Number(stressMargin.toFixed(2)),
    concentrationAddOn: Number(concentrationAddOn.toFixed(2)),
    liquidityAddOn: Number(liquidityAddOn.toFixed(2)),
    totalRequiredMargin: Number(totalRequiredMargin.toFixed(2)),
    availableCollateral: Number(availableCollateral.toFixed(2)),
    surplusDeficit: Number(surplusDeficit.toFixed(2)),
    isBreached: surplusDeficit < 0
  };
}

// --- R RESEARCH ENGINE SIMULATOR ---
export function executeRResearchScript(req: RScriptRunRequest): RQueryResult {
  const code = req.code;

  if (code.includes('rq_backtest_replication') || code.includes('backtest')) {
    const dates = ['2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09'];
    const tidyData = dates.map((d, i) => {
      const obs = 10400 + i * 40 + (Math.sin(i) * 35);
      const syn = obs + 12 + (Math.cos(i) * 5);
      const basis = syn - obs;
      return {
        date: d,
        observed_future: Number(obs.toFixed(1)),
        synthetic_future: Number(syn.toFixed(1)),
        basis: Number(basis.toFixed(1)),
        tracking_error: Number((Math.abs(basis) * 0.12).toFixed(2)),
        slippage_bps: 1.8
      };
    });

    return {
      stdout: `[R-STUDIO INTERPRETER] Executing rhinoquant v1.4.2 script...
Running rq_backtest_replication() across 9 monthly tenor windows...
Calculating tracking error, RMSE, and MAE...
Model Parity check: PASSED (p-value < 0.001)
Results generated successfully.`,
      stderr: '',
      tidyData,
      summary: {
        tracking_error_pct: 0.14,
        mean_basis: 14.2,
        basis_volatility: 4.8,
        rmse: 3.12,
        mae: 2.45,
        correlation: 0.9984
      },
      chartData: tidyData.flatMap(d => [
        { x: d.date, y: d.observed_future, group: 'Observed Future' },
        { x: d.date, y: d.synthetic_future, group: 'Synthetic Future' }
      ])
    };
  }

  // Default R execution output
  return {
    stdout: `[R-STUDIO INTERPRETER] Loaded package 'rhinoquant' (v1.4.2)
Executing quantitative script...
Object 'synthetic' initialized.
Fair Value: 10,497.20 GBP/tonne
Delta: 1.000 | Gamma: 0.00012 | Vega: 14.80 | Theta: -1.25`,
    stderr: '',
    tidyData: [
      { leg: 'LONG CALL 10500', strike: 10500, price: 542.0, delta: 0.52 },
      { leg: 'SHORT PUT 10500', strike: 10500, price: 526.6, delta: -0.48 },
      { leg: 'SYNTHETIC FUTURE', strike: 10500, fair_value: 10497.2, delta: 1.00 }
    ],
    summary: {
      fair_value: 10497.2,
      basis: 15.2,
      delta: 1.0,
      status: 'CONVERGED'
    }
  };
}
