import React, { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { SignatureOverview } from './components/SignatureOverview';
import { SyntheticBuilder } from './components/SyntheticBuilder';
import { CommodityLab } from './components/CommodityLab';
import { CurveTerminal } from './components/CurveTerminal';
import { VolSurfaceTerminal } from './components/VolSurfaceTerminal';
import { RiskScenarioLab } from './components/RiskScenarioLab';
import { MarginTerminal } from './components/MarginTerminal';
import { RResearchTerminal } from './components/RResearchTerminal';
import { MarketTerminal } from './components/MarketTerminal';
import { ReplayTerminal } from './components/ReplayTerminal';
import { DocsTerminal } from './components/DocsTerminal';
import { GovernanceProvenanceModal } from './components/GovernanceProvenanceModal';
import { globalMarketSim, MarketState } from './engine/marketSim';
import { INITIAL_POSITIONS, INITIAL_SYNTHETIC_CONFIGS } from './data/mockData';
import { MarketRegime, Position, SyntheticFutureConfig } from './types/rhinoquant';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('OVERVIEW');
  const [currentRegime, setCurrentRegime] = useState<MarketRegime>('NORMAL');
  const [markets, setMarkets] = useState<MarketState[]>(() => globalMarketSim.getAllMarkets());
  const [positions, setPositions] = useState<Position[]>(INITIAL_POSITIONS);
  const [isWsConnected, setIsWsConnected] = useState<boolean>(true);
  const [provenanceSymbol, setProvenanceSymbol] = useState<string | null>(null);

  // Subscribe to Market Simulator feed
  useEffect(() => {
    const unsubscribe = globalMarketSim.subscribe((updatedMarkets) => {
      setMarkets(updatedMarkets);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const handleRegimeChange = (newRegime: MarketRegime) => {
    setCurrentRegime(newRegime);
    globalMarketSim.setRegime(newRegime);
  };

  const handleOpenProvenance = (symbol: string) => {
    setProvenanceSymbol(symbol);
  };

  return (
    <div className="min-h-screen bg-[#111313] text-[#E9E7DF] font-sans flex flex-col selection:bg-[#294A59] selection:text-[#E9E7DF]">
      {/* NAVBAR */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentRegime={currentRegime}
        onRegimeChange={handleRegimeChange}
        isWsConnected={isWsConnected}
      />

      {/* MAIN VIEW SWITCHER */}
      <main className="flex-1 pb-12">
        {activeTab === 'OVERVIEW' && (
          <SignatureOverview
            markets={markets}
            onSelectSynthetic={(symbol) => {
              setActiveTab('BUILDER');
            }}
            onNavigateTab={setActiveTab}
            onOpenProvenance={handleOpenProvenance}
          />
        )}

        {activeTab === 'BUILDER' && (
          <SyntheticBuilder
            initialConfig={INITIAL_SYNTHETIC_CONFIGS[0]}
            onSaveSynthetic={(config) => {
              alert(`Synthetic Future ${config.name} saved to registry!`);
            }}
            onOpenProvenance={handleOpenProvenance}
          />
        )}

        {activeTab === 'COMMODITIES' && <CommodityLab />}

        {activeTab === 'CURVE' && <CurveTerminal />}

        {activeTab === 'VOL' && <VolSurfaceTerminal />}

        {activeTab === 'RISK' && <RiskScenarioLab positions={positions} />}

        {activeTab === 'MARGIN' && <MarginTerminal positions={positions} />}

        {activeTab === 'RESEARCH' && <RResearchTerminal />}

        {activeTab === 'MARKET' && <MarketTerminal markets={markets} />}

        {activeTab === 'REPLAY' && <ReplayTerminal />}

        {activeTab === 'DOCS' && <DocsTerminal />}
      </main>

      {/* PROVENANCE AUDIT MODAL */}
      <GovernanceProvenanceModal
        isOpen={!!provenanceSymbol}
        onClose={() => setProvenanceSymbol(null)}
        symbol={provenanceSymbol || 'COPPER-202712'}
      />

      {/* FOOTER CONTRACT */}
      <footer className="border-t border-[#202426] bg-[#111313] py-4 px-6 text-center font-mono text-xs text-[#727977]">
        <div className="max-w-[1600px] mx-auto flex flex-col md:flex-row items-center justify-between gap-2">
          <div>
            RHINOQUANT SYNTHETIC FUTURES · BRITISH DERIVATIVES ENGINEERING
          </div>
          <div className="text-[10px] text-[#727977]">
            FOR PROFESSIONAL INVESTORS & QUANTITATIVE DESKS ONLY · MODEL STATUS: RESEARCH (RQ-SYN-FUT-001)
          </div>
        </div>
      </footer>
    </div>
  );
}
