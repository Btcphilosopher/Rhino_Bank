import { Position, SyntheticFutureConfig } from '../types/rhinoquant';

export const INITIAL_SYNTHETIC_CONFIGS: SyntheticFutureConfig[] = [
  {
    id: 'RQ-SYN-COPPER-202712',
    name: 'Copper Grade A Dec 2027 Synthetic Long Future',
    underlying: 'COPPER',
    assetClass: 'METALS',
    syntheticType: 'SYNTHETIC_LONG_FUTURE',
    expiry: '2027-12',
    legs: [
      {
        instrumentId: 'COPPER-CALL-202712-10500',
        symbol: 'CALL-COPPER-2027-12-10500',
        type: 'CALL',
        side: 'LONG',
        quantity: 1,
        strike: 10500,
        expiry: '2027-12',
        price: 542.0
      },
      {
        instrumentId: 'COPPER-PUT-202712-10500',
        symbol: 'PUT-COPPER-2027-12-10500',
        type: 'PUT',
        side: 'SHORT',
        quantity: 1,
        strike: 10500,
        expiry: '2027-12',
        price: 526.6
      }
    ],
    financingRate: 4.25,
    storageCost: 1.20,
    convenienceYield: 0.85,
    transactionCost: 1.50,
    slippage: 0.50,
    observedFutureSymbol: 'COPPER-202712'
  },
  {
    id: 'RQ-SYN-TIN-202712',
    name: 'Tin 99.85% Dec 2027 Synthetic Cost-of-Carry Future',
    underlying: 'TIN',
    assetClass: 'METALS',
    syntheticType: 'SYNTHETIC_COMMODITY',
    expiry: '2027-12',
    legs: [
      {
        instrumentId: 'TIN-SPOT-LME',
        symbol: 'SPOT-TIN-LME',
        type: 'SPOT',
        side: 'LONG',
        quantity: 1,
        price: 33850
      }
    ],
    financingRate: 4.25,
    storageCost: 1.80,
    convenienceYield: 0.50,
    transactionCost: 5.0,
    slippage: 2.0,
    observedFutureSymbol: 'TIN-202712'
  },
  {
    id: 'RQ-SYN-BRENT-202706',
    name: 'Brent Crude Jun 2027 Call-Put Parity Synthetic',
    underlying: 'BRENT',
    assetClass: 'ENERGY',
    syntheticType: 'SYNTHETIC_LONG_FUTURE',
    expiry: '2027-06',
    legs: [
      {
        instrumentId: 'BRENT-CALL-80',
        symbol: 'CALL-BRENT-2027-06-80',
        type: 'CALL',
        side: 'LONG',
        quantity: 1,
        strike: 80.0,
        expiry: '2027-06',
        price: 8.42
      },
      {
        instrumentId: 'BRENT-PUT-80',
        symbol: 'PUT-BRENT-2027-06-80',
        type: 'PUT',
        side: 'SHORT',
        quantity: 1,
        strike: 80.0,
        expiry: '2027-06',
        price: 7.25
      }
    ],
    financingRate: 4.50,
    storageCost: 2.10,
    convenienceYield: 3.20, // Backwardation effect
    transactionCost: 0.08,
    slippage: 0.02,
    observedFutureSymbol: 'BRENT-202706'
  },
  {
    id: 'RQ-SYN-DAIRY-202712',
    name: 'Rhino Dairy Milk/Cream Synthesis Future',
    underlying: 'BUTTER_SMP',
    assetClass: 'DAIRY',
    syntheticType: 'SYNTHETIC_DAIRY',
    expiry: '2027-12',
    legs: [
      {
        instrumentId: 'MILK-RAW-UK',
        symbol: 'RAW-MILK-UK-P/L',
        type: 'MILK',
        side: 'LONG',
        quantity: 1,
        price: 42.5
      }
    ],
    financingRate: 4.25,
    storageCost: 1.5,
    convenienceYield: 0.0,
    milkPrice: 42.5,
    processingMargin: 12.0,
    transactionCost: 2.0,
    slippage: 1.0,
    observedFutureSymbol: 'DAIRY-202712'
  },
  {
    id: 'RQ-SYN-FREIGHT-202712',
    name: 'Capesize Route C5 Synthetic Freight Future',
    underlying: 'FREIGHT_C5',
    assetClass: 'FREIGHT',
    syntheticType: 'SYNTHETIC_FREIGHT',
    expiry: '2027-12',
    legs: [
      {
        instrumentId: 'FREIGHT-INDEX-BALTIC',
        symbol: 'BALTIC-CAPE-INDEX',
        type: 'INDEX',
        side: 'LONG',
        quantity: 1,
        price: 1280
      }
    ],
    financingRate: 4.25,
    storageCost: 0,
    convenienceYield: 0,
    routeIndex: 1280,
    bunkerPrice: 620,
    transactionCost: 1.0,
    slippage: 0.5,
    observedFutureSymbol: 'FREIGHT-202712'
  },
  {
    id: 'RQ-SYN-POWER-UK-2027',
    name: 'UK Power Baseload 2027 Spark Spread Synthetic',
    underlying: 'POWER_UK',
    assetClass: 'POWER',
    syntheticType: 'SYNTHETIC_POWER',
    expiry: '2027-12',
    legs: [
      {
        instrumentId: 'GAS-UK-NBP',
        symbol: 'UK-NBP-NATGAS-P/TH',
        type: 'FORWARD',
        side: 'LONG',
        quantity: 1,
        price: 78.5
      }
    ],
    financingRate: 4.25,
    storageCost: 0,
    convenienceYield: 0,
    gasPrice: 78.5,
    carbonPrice: 68.2,
    transactionCost: 0.20,
    slippage: 0.10,
    observedFutureSymbol: 'POWER-UK-2027'
  }
];

export const INITIAL_POSITIONS: Position[] = [
  {
    id: 'POS-001',
    instrumentId: 'RQ-SYN-COPPER-202712',
    symbol: 'COPPER-DEC27-SYNTHETIC-LONG',
    underlying: 'COPPER',
    assetClass: 'METALS',
    quantity: 50, // 50 contracts (250 tonnes)
    entryPrice: 10450,
    marketPrice: 10482,
    syntheticFairValue: 10497,
    isSyntheticLeg: true,
    syntheticGroupId: 'GRP-COPPER-01',
    unrealizedPnL: 118500,
    realizedPnL: 0,
    notional: 13121250,
    marginRequirement: 656000,
    greeks: { delta: 50.0, gamma: 0.006, vega: 740, theta: -62.5, rho: 242.5, dv01: 2.425, cs01: 1.94 }
  },
  {
    id: 'POS-002',
    instrumentId: 'BRENT-202706',
    symbol: 'BRENT-JUN27-OBSERVED-SHORT',
    underlying: 'BRENT',
    assetClass: 'ENERGY',
    quantity: -100,
    entryPrice: 82.10,
    marketPrice: 81.39,
    syntheticFairValue: 81.47,
    isSyntheticLeg: false,
    unrealizedPnL: 71000,
    realizedPnL: 12000,
    notional: 8139000,
    marginRequirement: 406000,
    greeks: { delta: -100.0, gamma: 0, vega: -850, theta: 45.0, rho: -120.0, dv01: 1.20, cs01: 0.96 }
  },
  {
    id: 'POS-003',
    instrumentId: 'RQ-SYN-DAIRY-202712',
    symbol: 'RHINO-DAIRY-SYNTHETIC-LONG',
    underlying: 'DAIRY',
    assetClass: 'DAIRY',
    quantity: 20,
    entryPrice: 3810,
    marketPrice: 3830,
    syntheticFairValue: 3842,
    isSyntheticLeg: true,
    unrealizedPnL: 32000,
    realizedPnL: 0,
    notional: 1532000,
    marginRequirement: 115000,
    greeks: { delta: 20.0, gamma: 0.002, vega: 180, theta: -15.0, rho: 45.0, dv01: 0.45, cs01: 0.36 }
  }
];
