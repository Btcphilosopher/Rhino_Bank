export type AssetClass =
  | 'EQUITY'
  | 'INDEX'
  | 'FX'
  | 'RATES'
  | 'BOND'
  | 'METALS'
  | 'ENERGY'
  | 'AGRICULTURE'
  | 'DAIRY'
  | 'FREIGHT'
  | 'POWER'
  | 'EMISSIONS'
  | 'CRYPTO'
  | 'CUSTOM';

export type SettlementType = 'CASH' | 'PHYSICAL';
export type PriceSource = 'OBSERVED' | 'DERIVED' | 'SYNTHETIC' | 'MODELLED' | 'ILLUSTRATIVE';

export interface ContractSpec {
  contractSize: number;
  currency: string;
  tickSize: number;
  tickValue: number;
  priceUnit: string;
  quantityUnit: string;
  settlementMethod: SettlementType;
  deliveryMethod: string;
}

export interface Instrument {
  id: string;
  symbol: string;
  name: string;
  assetClass: AssetClass;
  underlying: string;
  exchange: string;
  expiry: string; // YYYY-MM or YYYY-MM-DD
  strike?: number;
  optionType?: 'CALL' | 'PUT';
  priceSource: PriceSource;
  contractSpec: ContractSpec;
  lastPrice: number;
  bid: number;
  ask: number;
  impliedVol?: number;
}

export type SyntheticType =
  | 'SYNTHETIC_LONG_FUTURE'
  | 'SYNTHETIC_SHORT_FUTURE'
  | 'SYNTHETIC_COMMODITY'
  | 'SYNTHETIC_FX'
  | 'SYNTHETIC_BOND'
  | 'SYNTHETIC_EQUITY'
  | 'SYNTHETIC_FREIGHT'
  | 'SYNTHETIC_POWER'
  | 'SYNTHETIC_DAIRY'
  | 'BASKET';

export interface LegInput {
  instrumentId: string;
  symbol: string;
  type: 'CALL' | 'PUT' | 'SPOT' | 'FORWARD' | 'FUTURE' | 'SWAP' | 'INDEX' | 'BUNKER' | 'MILK' | 'CREAM';
  side: 'LONG' | 'SHORT';
  quantity: number;
  strike?: number;
  expiry?: string;
  price: number;
}

export interface SyntheticFutureConfig {
  id: string;
  name: string;
  underlying: string;
  assetClass: AssetClass;
  syntheticType: SyntheticType;
  expiry: string;
  legs: LegInput[];
  // Model Parameters
  financingRate: number; // annual %
  storageCost: number; // annual % or unit
  convenienceYield: number; // annual %
  foreignRate?: number; // for FX
  domesticRate?: number; // for FX
  repoRate?: number; // for Bonds
  conversionFactor?: number; // for Bonds
  routeIndex?: number; // for Freight
  bunkerPrice?: number; // for Freight
  gasPrice?: number; // for Power
  carbonPrice?: number; // for Power
  milkPrice?: number; // for Dairy
  processingMargin?: number; // for Dairy
  transactionCost: number;
  slippage: number;
  observedFutureSymbol?: string;
}

export interface Greeks {
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
  dv01: number;
  cs01: number;
}

export interface PricingResult {
  syntheticId: string;
  fairValue: number;
  bid: number;
  ask: number;
  mid: number;
  observedPrice?: number;
  basis: number; // Synthetic - Observed
  basisPercent: number;
  basisVol: number;
  zScore: number;
  forwardPremium: number;
  greeks: Greeks;
  confidence: number; // 0..100
  modelId: string;
  modelVersion: string;
  timestamp: string;
  status: 'RESEARCH' | 'VALIDATED' | 'EXPERIMENTAL' | 'DEPRECATED';
  provenance: CalculationProvenance;
}

export interface CalculationProvenance {
  modelId: string;
  modelVersion: string;
  calibrationDate: string;
  equations: string[];
  inputs: Record<string, number | string>;
  assumptions: string[];
  limitations: string[];
}

export type InterpolationMethod =
  | 'LINEAR'
  | 'LOG_LINEAR'
  | 'CUBIC_SPLINE'
  | 'MONOTONIC'
  | 'NELSON_SIEGEL'
  | 'NELSON_SIEGEL_SVENSSON';

export interface CurvePoint {
  tenor: string; // 'SPOT', '1M', '2M', '3M', '6M', '1Y', '2Y', '5Y'
  daysToExpiry: number;
  price: number;
  forwardRate: number;
  source: 'OBSERVED' | 'INTERPOLATED' | 'EXTRAPOLATED';
}

export interface ForwardCurve {
  id: string;
  underlying: string;
  assetClass: AssetClass;
  spot: number;
  points: CurvePoint[];
  interpolation: InterpolationMethod;
  slope: number;
  curvature: number;
  contangoStatus: 'CONTANGO' | 'BACKWARDATION' | 'FLAT';
  annualizedRollYield: number;
}

export interface VolPoint {
  strike: number;
  expiryDays: number;
  expiryLabel: string;
  impliedVol: number; // e.g. 0.247 for 24.7%
  delta: number;
  isObserved: boolean;
}

export interface VolSurface {
  id: string;
  underlying: string;
  atmVol: number;
  vol25Call: number;
  vol25Put: number;
  skew: number;
  points: VolPoint[];
  expiries: string[];
  strikes: number[];
}

export interface Position {
  id: string;
  instrumentId: string;
  symbol: string;
  underlying: string;
  assetClass: AssetClass;
  quantity: number; // + for Long, - for Short
  entryPrice: number;
  marketPrice: number;
  syntheticFairValue: number;
  isSyntheticLeg: boolean;
  syntheticGroupId?: string;
  unrealizedPnL: number;
  realizedPnL: number;
  notional: number;
  marginRequirement: number;
  greeks: Greeks;
}

export interface PortfolioSummary {
  totalNotional: number;
  grossExposure: number;
  netExposure: number;
  marketValue: number;
  unrealizedPnL: number;
  realizedPnL: number;
  totalPnL: number;
  totalMargin: number;
  var95: number;
  expectedShortfall95: number;
  portfolioGreeks: Greeks;
  positions: Position[];
}

export interface PnLAttribution {
  spotPnL: number;
  volPnL: number;
  timePnL: number;
  curvePnL: number;
  basisPnL: number;
  fxPnL: number;
  carryPnL: number;
  hedgePnL: number;
  totalPnL: number;
}

export interface ScenarioConfig {
  spotShockPct: number; // e.g. -10 to +10
  volShockPct: number; // e.g. -20 to +20
  rateShockBps: number; // e.g. -100 to +100
  fxShockPct: number;
  basisShockBps: number;
  liquidityShockPct: number;
}

export interface ScenarioResult {
  scenarioName: string;
  portfolioPnL: number;
  portfolioPnLPct: number;
  marginChange: number;
  newVar: number;
  breachFlag: boolean;
  assetClassImpacts: Record<string, number>;
}

export interface MonteCarloResult {
  simulations: number;
  paths: number[];
  var95: number;
  var99: number;
  expectedShortfall95: number;
  tailLoss: number;
  pnlHistogram: { bin: string; count: number }[];
  confidenceInterval: [number, number];
}

export interface MarginRequirement {
  initialMargin: number;
  variationMargin: number;
  maintenanceMargin: number;
  stressMargin: number;
  concentrationAddOn: number;
  liquidityAddOn: number;
  totalRequiredMargin: number;
  availableCollateral: number;
  surplusDeficit: number;
  isBreached: boolean;
}

export interface CollateralAccount {
  cashUSD: number;
  cashGBP: number;
  giltsValue: number;
  treasuriesValue: number;
  giltsHaircut: number; // e.g. 0.02 (2%)
  treasuriesHaircut: number;
  effectiveCollateralValue: number;
}

export interface MarginBacktestPoint {
  date: string;
  marginRequirement: number;
  actualNextDayPnL: number;
  breach: boolean;
  coveragePct: number;
}

export interface OrderBookLevel {
  price: number;
  quantity: number;
  ordersCount: number;
}

export interface OrderBook {
  symbol: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  lastTradePrice: number;
  lastTradeSize: number;
  lastTradeTime: string;
  simulatedSpread: number;
  impliedSyntheticMid: number;
}

export interface MarketMaker {
  id: string;
  name: string;
  type: 'MARKET_MAKER' | 'HEDGE_FUND' | 'ARBITRAGEUR' | 'COMMODITY_DESK' | 'LIQUIDITY_PROVIDER';
  spreadBps: number;
  inventory: number;
  riskLimit: number;
  quoteSize: number;
  volatilitySensitivity: number;
}

export type MarketRegime =
  | 'NORMAL'
  | 'HIGH_VOLATILITY'
  | 'LOW_VOLATILITY'
  | 'CONTANGO'
  | 'BACKWARDATION'
  | 'LIQUIDITY_CRISIS'
  | 'BASIS_SHOCK'
  | 'VOLATILITY_SHOCK'
  | 'RATE_SHOCK'
  | 'CORRELATION_BREAK';

export interface ModelGovernance {
  modelId: string;
  name: string;
  version: string;
  author: string;
  calibrationDate: string;
  dataset: string;
  assumptions: string[];
  limitations: string[];
  validationStatus: 'RESEARCH' | 'VALIDATED' | 'EXPERIMENTAL' | 'DEPRECATED';
  auditLog: { timestamp: string; action: string; user: string }[];
}

export interface RScriptRunRequest {
  code: string;
  syntheticId?: string;
}

export interface RQueryResult {
  stdout: string;
  stderr: string;
  tidyData: Record<string, any>[];
  summary: Record<string, any>;
  chartData?: { x: number | string; y: number; group?: string }[];
}
