import React, { useState } from 'react';
import { Play, Pause, FastForward, RotateCcw } from 'lucide-react';

export const ReplayTerminal: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1); // 1x, 10x, 100x

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      <div className="border-b border-[#202426] pb-4">
        <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
          <Play className="w-3.5 h-3.5 text-[#294A59]" />
          <span>HISTORICAL & SYNTHETIC MARKET TICK REPLAY ENGINE</span>
        </div>
        <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
          RHINOQUANT REPLAY TERMINAL
        </h1>
      </div>

      <div className="bg-[#182C35]/40 border border-[#294A59] p-6 space-y-6 font-mono text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="px-4 py-2 bg-[#294A59] hover:bg-[#294A59]/80 text-[#E9E7DF] font-bold border border-[#C7D2D1]/20 flex items-center gap-2 cursor-pointer"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              <span>{isPlaying ? 'PAUSE REPLAY' : 'PLAY REPLAY'}</span>
            </button>

            <button
              onClick={() => setSpeed(speed === 1 ? 10 : speed === 10 ? 100 : 1)}
              className="px-3 py-2 bg-[#202426] hover:bg-[#202426]/80 text-[#E9E7DF] border border-[#727977]/30 cursor-pointer"
            >
              SPEED: {speed}X
            </button>
          </div>

          <div className="text-[#727977]">
            REPLAY TIMESTAMP: <span className="text-[#E9E7DF] font-bold">2026-09-26 11:04:20</span>
          </div>
        </div>

        <div className="p-8 bg-[#111313] border border-[#202426] text-center space-y-3">
          <div className="text-[#3F7354] font-bold text-sm">
            {isPlaying ? 'REPLAY ACTIVE — SIMULATING BASIS DIVERGENCE & CONVERGENCE...' : 'REPLAY PAUSED'}
          </div>
          <div className="text-xs text-[#727977]">
            Observe how synthetic long futures and observed futures diverge during liquidity shocks and re-converge at expiry.
          </div>
        </div>
      </div>
    </div>
  );
};
