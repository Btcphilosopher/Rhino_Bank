import React, { useState } from 'react';
import { calculateMarginRequirement } from '../engine/quantEngine';
import { CollateralAccount, Position } from '../types/rhinoquant';
import { Database, Shield, AlertTriangle, CheckCircle, ArrowUpRight } from 'lucide-react';

interface MarginTerminalProps {
  positions: Position[];
}

export const MarginTerminal: React.FC<MarginTerminalProps> = ({ positions }) => {
  const [cashGBP, setCashGBP] = useState<number>(750000);
  const [giltsValue, setGiltsValue] = useState<number>(1100000);
  const giltsHaircut = 0.02; // 2% haircut for Gilts

  const totalNotional = positions.reduce((acc, p) => acc + p.notional, 0);
  const netExposure = positions.reduce((acc, p) => acc + (p.quantity > 0 ? p.notional : -p.notional), 0);
  const mockGreeks = { delta: 120, gamma: 0.008, vega: 1250, theta: -110, rho: 360, dv01: 3.6, cs01: 2.88 };

  const margin = calculateMarginRequirement(totalNotional, netExposure, mockGreeks);

  const effectiveGilts = giltsValue * (1 - giltsHaircut);
  const totalCollateral = cashGBP + effectiveGilts;
  const surplusDeficit = totalCollateral - margin.totalRequiredMargin;

  // Historical Margin Backtest
  const backtestHistory = [
    { date: '2026-09-22', req: 1120000, pnl: -14500, breach: false, coverage: 162.5 },
    { date: '2026-09-23', req: 1150000, pnl: -38200, breach: false, coverage: 158.2 },
    { date: '2026-09-24', req: 1140000, pnl: +21000, breach: false, coverage: 160.1 },
    { date: '2026-09-25', req: 1177000, pnl: -45200, breach: false, coverage: 157.1 }
  ];

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4">
        <div>
          <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <Database className="w-3.5 h-3.5 text-[#294A59]" />
            <span>RISK-BASED SYNTHETIC MARGIN & COLLATERAL SIMULATION ENGINE</span>
          </div>
          <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
            RHINOQUANT MARGIN TERMINAL
          </h1>
        </div>

        {/* SURPLUS BADGE */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="p-2 bg-[#202426] border border-[#727977]/30 flex items-center gap-2">
            <span className="text-[#727977]">COLLATERAL STATUS:</span>
            <span className={`font-bold flex items-center gap-1 ${
              surplusDeficit >= 0 ? 'text-[#3F7354]' : 'text-[#9B4038]'
            }`}>
              {surplusDeficit >= 0 ? <CheckCircle className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
              {surplusDeficit >= 0 ? 'SURPLUS' : 'MARGIN CALL BREACH'}
            </span>
          </div>

          <div className="p-2 bg-[#202426] border border-[#727977]/30">
            <span className="text-[#727977]">AVAILABLE SURPLUS: </span>
            <span className="font-bold text-[#C7D2D1] tabular-nums">
              £{surplusDeficit.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: COLLATERAL MANAGEMENT */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-4 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              POSTED COLLATERAL & HAIRCUTS
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[#727977] text-[11px] mb-1">UNENCUMBERED CASH (GBP)</label>
                <input
                  type="number"
                  step="25000"
                  value={cashGBP}
                  onChange={(e) => setCashGBP(parseFloat(e.target.value))}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-bold focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[#727977] text-[11px] mb-1">UK GILTS PAR VALUE (£)</label>
                <input
                  type="number"
                  step="50000"
                  value={giltsValue}
                  onChange={(e) => setGiltsValue(parseFloat(e.target.value))}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-bold focus:outline-none"
                />
                <div className="text-[10px] text-[#727977] mt-1">
                  Haircut Applied: 2.0% · Effective Value: £{effectiveGilts.toLocaleString()}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#727977]/20 space-y-2">
              <div className="flex justify-between font-bold">
                <span className="text-[#E9E7DF]">TOTAL EFFECTIVE COLLATERAL:</span>
                <span className="text-[#C7D2D1] tabular-nums">£{totalCollateral.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* MARGIN BREAKDOWN */}
          <div className="bg-[#182C35]/40 border border-[#294A59] p-5 space-y-3 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#294A59] pb-2 uppercase">
              RISK-BASED MARGIN COMPONENT BREAKDOWN
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-[#727977]">INITIAL MARGIN (Scenario Shock):</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">£{margin.initialMargin.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">VARIATION MARGIN (Mark-to-Market Loss):</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">£{margin.variationMargin.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">CONCENTRATION ADD-ON:</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">£{margin.concentrationAddOn.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">LIQUIDITY ADD-ON:</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">£{margin.liquidityAddOn.toLocaleString()}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#294A59]/40 font-bold">
                <span className="text-[#C7D2D1]">TOTAL REQUIRED MARGIN:</span>
                <span className="text-[#C7D2D1] tabular-nums">£{margin.totalRequiredMargin.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: BACKTEST & COVERAGE */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-4 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              MARGIN COVERAGE & BREACH BACKTESTING LOG
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="bg-[#111313] text-[#727977] border-b border-[#727977]/20 uppercase text-[11px]">
                    <th className="p-3">Trading Date</th>
                    <th className="p-3 text-right">Margin Requirement</th>
                    <th className="p-3 text-right">Subsequent 1D P&L</th>
                    <th className="p-3 text-right">Coverage Ratio</th>
                    <th className="p-3 text-center">Breach Flag</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#727977]/10">
                  {backtestHistory.map((row, idx) => (
                    <tr key={idx} className="hover:bg-[#202426]/60">
                      <td className="p-3 font-semibold text-[#E9E7DF]">{row.date}</td>
                      <td className="p-3 text-right text-[#E9E7DF] tabular-nums">
                        £{row.req.toLocaleString()}
                      </td>
                      <td className={`p-3 text-right font-bold tabular-nums ${row.pnl >= 0 ? 'text-[#3F7354]' : 'text-[#9B4038]'}`}>
                        {row.pnl >= 0 ? '+' : ''}£{row.pnl.toLocaleString()}
                      </td>
                        <td className="p-3 text-right text-[#C7D2D1] tabular-nums">{row.coverage}%</td>
                      <td className="p-3 text-center">
                        <span className="text-[10px] px-2 py-0.5 bg-[#3F7354]/20 text-[#3F7354] border border-[#3F7354]">
                          NO BREACH
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
