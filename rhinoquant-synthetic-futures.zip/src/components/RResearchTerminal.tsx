import React, { useState } from 'react';
import { executeRResearchScript } from '../engine/quantEngine';
import { RQueryResult } from '../types/rhinoquant';
import { Terminal, Play, CheckCircle, Code, BarChart, FileText } from 'lucide-react';

export const RResearchTerminal: React.FC = () => {
  const defaultRScript = `library(rhinoquant)

# 01 - Construct Synthetic Brent Future
synthetic <- rq_synthetic_future(
  call = "CALL-BRENT-2027-06",
  put  = "PUT-BRENT-2027-06",
  strike = 80
)

# 02 - Calculate Fair Value & Greeks
rq_price(synthetic)
rq_greeks(synthetic)

# 03 - Run Stress Matrix
rq_stress(
  synthetic,
  spot = c(-0.10, -0.05, 0, 0.05, 0.10)
)

# 04 - Backtest Synthetic Replication
rq_backtest_replication(
  synthetic_symbol = "SYNTHETIC-COPPER",
  observed_symbol  = "COPPER-202712"
)`;

  const [code, setCode] = useState<string>(defaultRScript);
  const [output, setOutput] = useState<RQueryResult>(() => executeRResearchScript({ code: defaultRScript }));
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const handleRunScript = () => {
    setIsRunning(true);
    setTimeout(() => {
      const res = executeRResearchScript({ code });
      setOutput(res);
      setIsRunning(false);
    }, 400);
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4">
        <div>
          <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-[#294A59]" />
            <span>R STATISTICAL COMPUTING & REPLICATION BACKTESTING ENVIRONMENT</span>
          </div>
          <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
            RHINOQUANT RESEARCH (R ENVIRONMENT)
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunScript}
            disabled={isRunning}
            className="px-5 py-2 bg-[#294A59] hover:bg-[#294A59]/80 disabled:opacity-50 text-[#E9E7DF] font-mono text-xs font-semibold border border-[#C7D2D1]/20 transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isRunning ? 'EXECUTING R SCRIPT...' : 'EXECUTE R SCRIPT'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: R CODE EDITOR */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-4 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-[#727977]/20 pb-2">
              <span className="font-bold text-[#E9E7DF] flex items-center gap-2">
                <Code className="w-3.5 h-3.5 text-[#294A59]" />
                <span>R SCRIPT EDITOR (rhinoquant package)</span>
              </span>
              <span className="text-[10px] text-[#727977]">R v4.3.2 · TIDYVERSE</span>
            </div>

            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              rows={16}
              className="w-full bg-[#111313] border border-[#727977]/30 p-3 font-mono text-xs text-[#E9E7DF] focus:outline-none focus:border-[#294A59] leading-relaxed select-all"
            />
          </div>

          {/* STDOUT CONSOLE */}
          <div className="bg-[#111313] border border-[#202426] p-4 space-y-2 font-mono text-xs">
            <div className="text-[10px] text-[#727977] uppercase border-b border-[#202426] pb-1">
              R CONSOLE STDOUT
            </div>
            <pre className="text-[#C7D2D1] whitespace-pre-wrap text-[11px] leading-relaxed">
              {output.stdout}
            </pre>
          </div>
        </div>

        {/* RIGHT COLUMN: TIDY DATA OUTPUT & BACKTEST SUMMARY */}
        <div className="lg:col-span-6 space-y-5">
          {/* SUMMARY METRICS */}
          {output.summary && (
            <div className="grid grid-cols-3 gap-3 font-mono text-xs">
              <div className="p-3 bg-[#182C35]/40 border border-[#294A59] space-y-1">
                <div className="text-[10px] text-[#727977]">TRACKING ERROR</div>
                <div className="text-lg font-bold text-[#E9E7DF] tabular-nums">
                  {output.summary.tracking_error_pct || 0.14}%
                </div>
              </div>

              <div className="p-3 bg-[#182C35]/40 border border-[#294A59] space-y-1">
                <div className="text-[10px] text-[#727977]">MEAN BASIS</div>
                <div className="text-lg font-bold text-[#3F7354] tabular-nums">
                  +£{output.summary.mean_basis || 14.2}
                </div>
              </div>

              <div className="p-3 bg-[#182C35]/40 border border-[#294A59] space-y-1">
                <div className="text-[10px] text-[#727977]">CORRELATION</div>
                <div className="text-lg font-bold text-[#C7D2D1] tabular-nums">
                  {output.summary.correlation || 0.9984}
                </div>
              </div>
            </div>
          )}

          {/* TIDY DATA FRAME TABLE */}
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-4 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-[#727977]/20 pb-2">
              <span className="font-bold text-[#E9E7DF] flex items-center gap-2">
                <FileText className="w-3.5 h-3.5 text-[#3F7354]" />
                <span>TIDY DATA FRAME OUTPUT (data.frame)</span>
              </span>
              <span className="text-[10px] text-[#3F7354]">9 TENOR WINDOWS</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="bg-[#111313] text-[#727977] border-b border-[#727977]/20 uppercase text-[11px]">
                    {output.tidyData.length > 0 &&
                      Object.keys(output.tidyData[0]).map((col) => (
                        <th key={col} className="p-2.5">
                          {col.replace('_', ' ')}
                        </th>
                      ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#727977]/10">
                  {output.tidyData.map((row, idx) => (
                    <tr key={idx} className="hover:bg-[#202426]/60">
                      {Object.values(row).map((val, cIdx) => (
                        <td key={cIdx} className="p-2.5 text-[#E9E7DF] tabular-nums">
                          {typeof val === 'number' ? val.toLocaleString() : String(val)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
