import React from 'react';
import { MarketState } from '../engine/marketSim';
import { ArrowUpRight, ArrowDownRight, Info, Zap, Shield, TrendingUp, Sliders, Layers } from 'lucide-react';

interface SignatureOverviewProps {
  markets: MarketState[];
  onSelectSynthetic: (symbol: string) => void;
  onNavigateTab: (tab: string) => void;
  onOpenProvenance: (symbol: string) => void;
}

export const SignatureOverview: React.FC<SignatureOverviewProps> = ({
  markets,
  onSelectSynthetic,
  onNavigateTab,
  onOpenProvenance
}) => {
  const copperMarket = markets.find(m => m.symbol === 'COPPER-202712') || markets[0];
  const tinMarket = markets.find(m => m.symbol === 'TIN-202712');
  const brentMarket = markets.find(m => m.symbol === 'BRENT-202706');
  const dairyMarket = markets.find(m => m.symbol === 'DAIRY-202712');
  const freightMarket = markets.find(m => m.symbol === 'FREIGHT-202712');

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* SECTION 01: SIGNATURE COPPER PANEL */}
      <div className="bg-[#182C35]/40 border border-[#294A59]/60 p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 font-mono text-[10px] text-[#727977] tracking-widest uppercase">
          MODEL: RQ-SYN-FUT-001 · STATUS: RESEARCH
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Headline Title */}
          <div className="lg:col-span-4 space-y-2">
            <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-[#294A59]"></span>
              <span>BENCHMARK SYNTHETIC DERIVATIVE</span>
            </div>
            <h1 className="text-3xl font-extrabold font-mono text-[#E9E7DF] tracking-tight">
              COPPER GRADE A
            </h1>
            <div className="flex items-center gap-2 font-mono text-xs text-[#727977]">
              <span>DECEMBER 2027 TENOR</span>
              <span>·</span>
              <span>LME BENCHMARK</span>
              <span>·</span>
              <span className="text-[#C7D2D1]">GBP / TONNE</span>
            </div>
          </div>

          {/* Pricing Triad */}
          <div className="lg:col-span-5 grid grid-cols-3 gap-3 bg-[#111313]/80 p-4 border border-[#202426]">
            <div className="space-y-1">
              <div className="text-[10px] font-mono text-[#727977] uppercase flex items-center gap-1">
                <span>OBSERVED FUTURE</span>
                <span className="text-[9px] px-1 bg-[#202426] text-[#727977]">EXCH</span>
              </div>
              <div className="text-xl font-bold font-mono text-[#E9E7DF] tabular-nums">
                £{copperMarket ? copperMarket.observedPrice.toLocaleString() : '10,482'}
              </div>
              <div className="text-[10px] font-mono text-[#727977]">Exchange Settlement</div>
            </div>

            <div className="space-y-1 border-x border-[#202426] px-3">
              <div className="text-[10px] font-mono text-[#294A59] font-semibold uppercase flex items-center gap-1">
                <span>SYNTHETIC FUTURE</span>
                <span className="text-[9px] px-1 bg-[#294A59]/30 text-[#C7D2D1]">MODEL</span>
              </div>
              <div className="text-xl font-bold font-mono text-[#C7D2D1] tabular-nums">
                £{copperMarket ? copperMarket.syntheticPrice.toLocaleString() : '10,497'}
              </div>
              <div className="text-[10px] font-mono text-[#3F7354]">Call/Put Parity Mid</div>
            </div>

            <div className="space-y-1 pl-2">
              <div className="text-[10px] font-mono text-[#727977] uppercase">BASIS</div>
              <div className={`text-xl font-bold font-mono tabular-nums ${
                (copperMarket?.basis || 15) >= 0 ? 'text-[#3F7354]' : 'text-[#9B4038]'
              }`}>
                {(copperMarket?.basis || 15) >= 0 ? '+' : ''}{copperMarket?.basis || 15}
              </div>
              <div className="text-[10px] font-mono text-[#727977]">+0.14% Premium</div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="lg:col-span-3 flex flex-col gap-2">
            <button
              onClick={() => onNavigateTab('BUILDER')}
              className="w-full py-2.5 px-4 bg-[#294A59] hover:bg-[#294A59]/80 text-[#E9E7DF] font-mono font-semibold text-xs transition-colors flex items-center justify-center gap-2 border border-[#C7D2D1]/20"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>OPEN SYNTHETIC BUILDER</span>
            </button>
            <button
              onClick={() => onOpenProvenance('COPPER-202712')}
              className="w-full py-2 px-4 bg-[#202426] hover:bg-[#202426]/80 text-[#727977] hover:text-[#E9E7DF] font-mono text-xs transition-colors flex items-center justify-center gap-2 border border-[#727977]/20"
            >
              <Info className="w-3.5 h-3.5" />
              <span>INSPECT PROVENANCE & EQUATIONS</span>
            </button>
          </div>
        </div>

        {/* MATHEMATICAL RELATIONSHIP FUSION DIAGRAM */}
        <div className="mt-6 pt-6 border-t border-[#202426] grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          <div className="p-3 bg-[#111313] border border-[#202426] space-y-1">
            <div className="flex justify-between text-[11px] font-mono">
              <span className="text-[#3F7354] font-semibold">LONG CALL 10,500</span>
              <span className="text-[#727977] tabular-nums">£542.00</span>
            </div>
            <div className="text-[10px] font-mono text-[#727977]">Dec 2027 Expiry · Delta: +0.52</div>
          </div>

          <div className="text-center font-mono text-xs text-[#727977] flex items-center justify-center gap-3">
            <span className="text-base text-[#E9E7DF] font-bold">+</span>
            <div className="p-3 bg-[#111313] border border-[#202426] space-y-1 flex-1 text-left">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-[#9B4038] font-semibold">SHORT PUT 10,500</span>
                <span className="text-[#727977] tabular-nums">£526.60</span>
              </div>
              <div className="text-[10px] font-mono text-[#727977]">Dec 2027 Expiry · Delta: -0.48</div>
            </div>
            <span className="text-base text-[#E9E7DF] font-bold">=</span>
          </div>

          <div className="p-3 bg-[#294A59]/20 border border-[#294A59] space-y-1">
            <div className="flex justify-between text-[11px] font-mono">
              <span className="text-[#C7D2D1] font-bold">SYNTHETIC LONG FUTURE</span>
              <span className="text-[#C7D2D1] font-bold tabular-nums">£10,497.20</span>
            </div>
            <div className="text-[10px] font-mono text-[#3F7354]">Synthetic Delta: 1.000 · Parity Converged</div>
          </div>
        </div>
      </div>

      {/* SECTION 02: QUICK NAV METRIC BAR */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 font-mono text-xs">
        <button
          onClick={() => onNavigateTab('CURVE')}
          className="p-3 bg-[#202426]/60 hover:bg-[#202426] border border-[#727977]/20 text-left transition-colors space-y-1 group"
        >
          <div className="text-[#727977] text-[10px] flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-[#294A59]" />
            <span>FORWARD CURVE</span>
          </div>
          <div className="text-[#E9E7DF] font-bold">CONTANGO (+£15)</div>
          <div className="text-[10px] text-[#727977] group-hover:text-[#C7D2D1]">Annualised Roll: 6.2%</div>
        </button>

        <button
          onClick={() => onNavigateTab('VOL')}
          className="p-3 bg-[#202426]/60 hover:bg-[#202426] border border-[#727977]/20 text-left transition-colors space-y-1 group"
        >
          <div className="text-[#727977] text-[10px] flex items-center gap-1">
            <Zap className="w-3 h-3 text-[#B38A42]" />
            <span>VOL SURFACE</span>
          </div>
          <div className="text-[#E9E7DF] font-bold">ATM VOL: 24.7%</div>
          <div className="text-[10px] text-[#727977] group-hover:text-[#C7D2D1]">25D Skew: +6.3% Put</div>
        </button>

        <button
          onClick={() => onNavigateTab('RISK')}
          className="p-3 bg-[#202426]/60 hover:bg-[#202426] border border-[#727977]/20 text-left transition-colors space-y-1 group"
        >
          <div className="text-[#727977] text-[10px] flex items-center gap-1">
            <Shield className="w-3 h-3 text-[#3F7354]" />
            <span>PORTFOLIO VaR</span>
          </div>
          <div className="text-[#E9E7DF] font-bold">£142,000 (95%)</div>
          <div className="text-[10px] text-[#727977] group-hover:text-[#C7D2D1]">ES 95%: £185,400</div>
        </button>

        <button
          onClick={() => onNavigateTab('MARGIN')}
          className="p-3 bg-[#202426]/60 hover:bg-[#202426] border border-[#727977]/20 text-left transition-colors space-y-1 group"
        >
          <div className="text-[#727977] text-[10px] flex items-center gap-1">
            <Layers className="w-3 h-3 text-[#294A59]" />
            <span>MARGIN REQ</span>
          </div>
          <div className="text-[#E9E7DF] font-bold">£1,177,000</div>
          <div className="text-[10px] text-[#3F7354] group-hover:text-[#C7D2D1]">Surplus: £673,000</div>
        </button>

        <button
          onClick={() => onNavigateTab('RESEARCH')}
          className="p-3 bg-[#202426]/60 hover:bg-[#202426] border border-[#727977]/20 text-left transition-colors space-y-1 group col-span-2 md:col-span-1"
        >
          <div className="text-[#727977] text-[10px] flex items-center gap-1">
            <Info className="w-3 h-3 text-[#C7D2D1]" />
            <span>R BACKTEST</span>
          </div>
          <div className="text-[#E9E7DF] font-bold">ERR: 0.14%</div>
          <div className="text-[10px] text-[#727977] group-hover:text-[#C7D2D1]">Correlation: 0.9984</div>
        </button>
      </div>

      {/* SECTION 03: INSTITUTIONAL SYNTHETIC FUTURES MATRIX */}
      <div className="bg-[#202426]/40 border border-[#727977]/20">
        <div className="p-4 border-b border-[#727977]/20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-[#294A59]"></span>
            <h2 className="font-mono text-sm font-bold text-[#E9E7DF]">
              INSTITUTIONAL SYNTHETIC FUTURES MATRIX
            </h2>
          </div>
          <div className="font-mono text-xs text-[#727977] flex items-center gap-3">
            <span>REAL-TIME MODEL ENGINE</span>
            <span>·</span>
            <span>10 ACTIVE MARKETS</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="bg-[#111313] text-[#727977] border-b border-[#727977]/20 text-[11px] uppercase tracking-wider">
                <th className="p-3">Asset</th>
                <th className="p-3">Underlying Market</th>
                <th className="p-3 text-right">Observed</th>
                <th className="p-3 text-right">Synthetic</th>
                <th className="p-3 text-right">Basis</th>
                <th className="p-3 text-right">Implied Vol</th>
                <th className="p-3 text-center">Bid / Ask</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#727977]/10">
              {markets.map((m) => {
                const basisPositive = m.basis >= 0;
                return (
                  <tr
                    key={m.symbol}
                    className="hover:bg-[#202426]/60 transition-colors"
                  >
                    <td className="p-3 font-semibold text-[#E9E7DF] flex items-center gap-2">
                      <span className="text-[#727977] text-[10px]">{m.assetClass}</span>
                      <span>{m.name}</span>
                    </td>
                    <td className="p-3 text-[#727977]">{m.symbol}</td>
                    <td className="p-3 text-right text-[#E9E7DF] tabular-nums font-semibold">
                      £{m.observedPrice.toLocaleString()}
                    </td>
                    <td className="p-3 text-right text-[#C7D2D1] tabular-nums font-semibold">
                      £{m.syntheticPrice.toLocaleString()}
                    </td>
                    <td className={`p-3 text-right tabular-nums font-bold ${basisPositive ? 'text-[#3F7354]' : 'text-[#9B4038]'}`}>
                      {basisPositive ? '+' : ''}{m.basis}
                    </td>
                    <td className="p-3 text-right text-[#E9E7DF] tabular-nums">
                      {m.volatility}%
                    </td>
                    <td className="p-3 text-center text-[#727977] tabular-nums text-[11px]">
                      {m.bid} / {m.ask}
                    </td>
                    <td className="p-3 text-center">
                      <span className="text-[10px] px-1.5 py-0.5 bg-[#294A59]/20 text-[#C7D2D1] border border-[#294A59]/40 font-mono">
                        RESEARCH
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={() => onSelectSynthetic(m.symbol)}
                        className="px-2 py-1 bg-[#202426] hover:bg-[#294A59] text-[#E9E7DF] text-[11px] border border-[#727977]/30 transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
