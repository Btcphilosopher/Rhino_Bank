import React, { useState } from 'react';
import { buildForwardCurve } from '../engine/quantEngine';
import { AssetClass, InterpolationMethod } from '../types/rhinoquant';
import { TrendingUp, Sliders, Info, CheckCircle, RefreshCw } from 'lucide-react';

export const CurveTerminal: React.FC = () => {
  const [underlying, setUnderlying] = useState<string>('COPPER');
  const [assetClass, setAssetClass] = useState<AssetClass>('METALS');
  const [spotPrice, setSpotPrice] = useState<number>(10482);
  const [interpolation, setInterpolation] = useState<InterpolationMethod>('CUBIC_SPLINE');

  const curve = buildForwardCurve(underlying, assetClass, spotPrice, interpolation);

  // SVG Chart Dimensions
  const chartWidth = 700;
  const chartHeight = 260;
  const padding = 40;

  const minPrice = Math.min(...curve.points.map(p => p.price)) * 0.98;
  const maxPrice = Math.max(...curve.points.map(p => p.price)) * 1.02;

  const getX = (idx: number) => {
    return padding + (idx / (curve.points.length - 1)) * (chartWidth - 2 * padding);
  };

  const getY = (price: number) => {
    return chartHeight - padding - ((price - minPrice) / (maxPrice - minPrice)) * (chartHeight - 2 * padding);
  };

  const svgPath = curve.points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(p.price)}`)
    .join(' ');

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4">
        <div>
          <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <TrendingUp className="w-3.5 h-3.5 text-[#294A59]" />
            <span>FORWARD & FUTURES CURVE CONSTRUCTION ENGINE</span>
          </div>
          <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
            RHINOQUANT CURVE TERMINAL
          </h1>
        </div>

        {/* CONTANGO / BACKWARDATION STATUS BADGE */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="p-2 bg-[#202426] border border-[#727977]/30 flex items-center gap-2">
            <span className="text-[#727977]">CURVE REGIME:</span>
            <span className={`font-bold ${
              curve.contangoStatus === 'CONTANGO'
                ? 'text-[#3F7354]'
                : curve.contangoStatus === 'BACKWARDATION'
                ? 'text-[#9B4038]'
                : 'text-[#E9E7DF]'
            }`}>
              {curve.contangoStatus}
            </span>
          </div>

          <div className="p-2 bg-[#202426] border border-[#727977]/30">
            <span className="text-[#727977]">ANNUALISED ROLL YIELD: </span>
            <span className="font-bold text-[#E9E7DF] tabular-nums">{curve.annualizedRollYield}%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: CONTROLS & INTERPOLATION */}
        <div className="lg:col-span-4 space-y-5">
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-4 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              CURVE CONSTRUCTION INPUTS
            </div>

            <div>
              <label className="block text-[#727977] text-[11px] mb-1">UNDERLYING MARKET</label>
              <select
                value={underlying}
                onChange={(e) => {
                  setUnderlying(e.target.value);
                  if (e.target.value === 'COPPER') setSpotPrice(10482);
                  if (e.target.value === 'BRENT') setSpotPrice(81.39);
                  if (e.target.value === 'NATURAL_GAS') setSpotPrice(78.5);
                }}
                className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-bold focus:outline-none"
              >
                <option value="COPPER">COPPER GRADE A (LME)</option>
                <option value="TIN">TIN 99.85% (LME)</option>
                <option value="BRENT">BRENT CRUDE (ICE)</option>
                <option value="NATURAL_GAS">UK NBP NATURAL GAS</option>
                <option value="WHEAT">MILLING WHEAT (PARIS)</option>
                <option value="BUTTER_SMP">BUTTER / SMP DAIRY</option>
              </select>
            </div>

            <div>
              <label className="block text-[#727977] text-[11px] mb-1">SPOT PRICE Benchmark (£)</label>
              <input
                type="number"
                value={spotPrice}
                onChange={(e) => setSpotPrice(parseFloat(e.target.value))}
                className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-bold focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[#727977] text-[11px] mb-1">INTERPOLATION ALGORITHM</label>
              <select
                value={interpolation}
                onChange={(e) => setInterpolation(e.target.value as InterpolationMethod)}
                className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#C7D2D1] font-bold focus:outline-none"
              >
                <option value="CUBIC_SPLINE">CUBIC SPLINE INTERPOLATION</option>
                <option value="LINEAR">PIECEWISE LINEAR</option>
                <option value="LOG_LINEAR">LOG-LINEAR INTERPOLATION</option>
                <option value="MONOTONIC">MONOTONIC HERMITE SPLINE</option>
                <option value="NELSON_SIEGEL">NELSON-SIEGEL PARSIMONIOUS</option>
                <option value="NELSON_SIEGEL_SVENSSON">NELSON-SIEGEL-SVENSSON (6-PARAM)</option>
              </select>
            </div>
          </div>

          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-3 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              CURVE SHAPE METRICS
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-[#727977]">CURVE SLOPE (Front vs 5Y):</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">£{curve.slope}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">CURVATURE PARAMETER:</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">{curve.curvature}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">3M / 6M CALENDAR SPREAD:</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">
                  £{(curve.points[4].price - curve.points[3].price).toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: CURVE VISUALIZATION & DATA TABLE */}
        <div className="lg:col-span-8 space-y-6">
          {/* CURVE CHART */}
          <div className="bg-[#182C35]/40 border border-[#294A59] p-5 space-y-3">
            <div className="flex items-center justify-between font-mono text-xs">
              <span className="font-bold text-[#E9E7DF] uppercase">FORWARD CURVE VISUALISER</span>
              <div className="flex items-center gap-4 text-[11px] text-[#727977]">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#294A59]"></span> OBSERVED
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#C7D2D1]"></span> INTERPOLATED
                </span>
              </div>
            </div>

            <div className="bg-[#111313] p-4 border border-[#202426] overflow-x-auto">
              <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto">
                {/* Grid Lines */}
                {[0, 1, 2, 3, 4].map((i) => {
                  const y = padding + (i / 4) * (chartHeight - 2 * padding);
                  return (
                    <line
                      key={i}
                      x1={padding}
                      y1={y}
                      x2={chartWidth - padding}
                      y2={y}
                      stroke="#202426"
                      strokeDasharray="3 3"
                    />
                  );
                })}

                {/* Curve Path */}
                <path
                  d={svgPath}
                  fill="none"
                  stroke="#294A59"
                  strokeWidth="2.5"
                />

                {/* Data Points */}
                {curve.points.map((p, idx) => {
                  const cx = getX(idx);
                  const cy = getY(p.price);
                  const isObserved = p.source === 'OBSERVED';
                  return (
                    <g key={idx}>
                      <circle
                        cx={cx}
                        cy={cy}
                        r={isObserved ? 5 : 3.5}
                        fill={isObserved ? '#294A59' : '#C7D2D1'}
                        stroke="#111313"
                        strokeWidth="1.5"
                      />
                      <text
                        x={cx}
                        y={cy - 10}
                        fill="#E9E7DF"
                        fontSize="10"
                        fontFamily="monospace"
                        textAnchor="middle"
                      >
                        £{p.price}
                      </text>
                      <text
                        x={cx}
                        y={chartHeight - 10}
                        fill="#727977"
                        fontSize="10"
                        fontFamily="monospace"
                        textAnchor="middle"
                      >
                        {p.tenor}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>

          {/* CURVE TENOR TABLE */}
          <div className="bg-[#202426]/40 border border-[#727977]/20 overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="bg-[#111313] text-[#727977] border-b border-[#727977]/20 uppercase text-[11px]">
                  <th className="p-3">Tenor</th>
                  <th className="p-3 text-right">Days</th>
                  <th className="p-3 text-right">Forward Price</th>
                  <th className="p-3 text-right">Implied Forward Rate</th>
                  <th className="p-3 text-center">Data Provenance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#727977]/10">
                {curve.points.map((pt, i) => (
                  <tr key={i} className="hover:bg-[#202426]/60">
                    <td className="p-3 font-bold text-[#E9E7DF]">{pt.tenor}</td>
                    <td className="p-3 text-right text-[#727977] tabular-nums">{pt.daysToExpiry}d</td>
                    <td className="p-3 text-right text-[#C7D2D1] font-bold tabular-nums">
                      £{pt.price.toLocaleString()}
                    </td>
                    <td className="p-3 text-right text-[#E9E7DF] tabular-nums">{pt.forwardRate}%</td>
                    <td className="p-3 text-center">
                      <span className={`text-[10px] px-2 py-0.5 border ${
                        pt.source === 'OBSERVED'
                          ? 'bg-[#294A59]/20 text-[#C7D2D1] border-[#294A59]'
                          : 'bg-[#202426] text-[#727977] border-[#727977]/30'
                      }`}>
                        {pt.source}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
