import React, { useState } from 'react';
import { BookOpen, Terminal, Database, Code, Cpu } from 'lucide-react';

export const DocsTerminal: React.FC = () => {
  const [activeDoc, setActiveDoc] = useState<'API' | 'R_PACKAGE' | 'RUST' | 'SQL'>('API');

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4 font-mono">
        <div>
          <div className="text-xs text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <BookOpen className="w-3.5 h-3.5 text-[#294A59]" />
            <span>INSTITUTIONAL ARCHITECTURE & API SPECIFICATION</span>
          </div>
          <h1 className="text-2xl font-bold text-[#E9E7DF] tracking-tight">
            RHINOQUANT DOCUMENTATION & API TERMINAL
          </h1>
        </div>

        {/* DOC TABS */}
        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setActiveDoc('API')}
            className={`px-3 py-1.5 border transition-colors ${
              activeDoc === 'API' ? 'bg-[#294A59] text-[#E9E7DF] border-[#C7D2D1]/40 font-bold' : 'bg-[#202426] text-[#727977] border-[#727977]/20'
            }`}
          >
            REST & WS API
          </button>
          <button
            onClick={() => setActiveDoc('R_PACKAGE')}
            className={`px-3 py-1.5 border transition-colors ${
              activeDoc === 'R_PACKAGE' ? 'bg-[#294A59] text-[#E9E7DF] border-[#C7D2D1]/40 font-bold' : 'bg-[#202426] text-[#727977] border-[#727977]/20'
            }`}
          >
            R PACKAGE
          </button>
          <button
            onClick={() => setActiveDoc('RUST')}
            className={`px-3 py-1.5 border transition-colors ${
              activeDoc === 'RUST' ? 'bg-[#294A59] text-[#E9E7DF] border-[#C7D2D1]/40 font-bold' : 'bg-[#202426] text-[#727977] border-[#727977]/20'
            }`}
          >
            RUST CRATE
          </button>
          <button
            onClick={() => setActiveDoc('SQL')}
            className={`px-3 py-1.5 border transition-colors ${
              activeDoc === 'SQL' ? 'bg-[#294A59] text-[#E9E7DF] border-[#C7D2D1]/40 font-bold' : 'bg-[#202426] text-[#727977] border-[#727977]/20'
            }`}
          >
            SQL SCHEMA
          </button>
        </div>
      </div>

      {/* API DOCS */}
      {activeDoc === 'API' && (
        <div className="bg-[#182C35]/40 border border-[#294A59] p-6 space-y-6 font-mono text-xs">
          <div className="text-sm font-bold text-[#E9E7DF] uppercase border-b border-[#294A59] pb-2">
            REST API v1 SPECIFICATION
          </div>

          <div className="space-y-4">
            <div className="p-3 bg-[#111313] border border-[#202426] space-y-1">
              <span className="text-[#3F7354] font-bold">GET</span>{' '}
              <span className="text-[#E9E7DF] font-bold">/api/v1/instruments</span>
              <p className="text-[#727977] text-[11px]">List all active market instruments and simulated prices.</p>
            </div>

            <div className="p-3 bg-[#111313] border border-[#202426] space-y-1">
              <span className="text-[#3F7354] font-bold">GET</span>{' '}
              <span className="text-[#E9E7DF] font-bold">/api/v1/curves?underlying=COPPER</span>
              <p className="text-[#727977] text-[11px]">Return forward curve points & contango classification.</p>
            </div>

            <div className="p-3 bg-[#111313] border border-[#202426] space-y-1">
              <span className="text-[#3F7354] font-bold">GET</span>{' '}
              <span className="text-[#E9E7DF] font-bold">/api/v1/synthetics</span>
              <p className="text-[#727977] text-[11px]">List all constructed synthetic futures with real-time fair value pricing.</p>
            </div>

            <div className="p-3 bg-[#111313] border border-[#202426] space-y-1">
              <span className="text-[#294A59] font-bold">POST</span>{' '}
              <span className="text-[#E9E7DF] font-bold">/api/v1/synthetics</span>
              <p className="text-[#727977] text-[11px]">Construct and register a new synthetic future instrument.</p>
            </div>

            <div className="p-3 bg-[#111313] border border-[#202426] space-y-1">
              <span className="text-[#294A59] font-bold">POST</span>{' '}
              <span className="text-[#E9E7DF] font-bold">/api/v1/r-research/run</span>
              <p className="text-[#727977] text-[11px]">Execute an R quantitative research script and return tidy data frames.</p>
            </div>
          </div>
        </div>
      )}

      {/* R PACKAGE DOCS */}
      {activeDoc === 'R_PACKAGE' && (
        <div className="bg-[#182C35]/40 border border-[#294A59] p-6 space-y-4 font-mono text-xs">
          <div className="text-sm font-bold text-[#E9E7DF] uppercase border-b border-[#294A59] pb-2">
            rhinoquant R PACKAGE SPECIFICATION
          </div>
          <pre className="p-4 bg-[#111313] text-[#C7D2D1] border border-[#202426] leading-relaxed">
{`library(rhinoquant)

# Construct Synthetic Future
synthetic <- rq_synthetic_future(
  call = "CALL-BRENT-2027-06",
  put  = "PUT-BRENT-2027-06",
  strike = 80
)

# Price Synthetic Future
pricing <- rq_price(synthetic)

# Compute Greeks
greeks <- rq_greeks(synthetic)

# Run Stress Test
stress <- rq_stress(synthetic, spot = c(-0.10, -0.05, 0, 0.05, 0.10))`}
          </pre>
        </div>
      )}

      {/* RUST CRATE STRUCTURE */}
      {activeDoc === 'RUST' && (
        <div className="bg-[#182C35]/40 border border-[#294A59] p-6 space-y-4 font-mono text-xs">
          <div className="text-sm font-bold text-[#E9E7DF] uppercase border-b border-[#294A59] pb-2">
            RUST HIGH-PERFORMANCE ENGINE CRATE ARCHITECTURE
          </div>
          <pre className="p-4 bg-[#111313] text-[#C7D2D1] border border-[#202426] leading-relaxed">
{`rhinoquant-synthetic-futures/
├── rust/
│   ├── rq-core/        # Math utilities & SIMD vectorised routines
│   ├── rq-instruments/ # Instrument registry & contract specifications
│   ├── rq-curves/      # Forward curves & Nelson-Siegel splines
│   ├── rq-options/     # Black-76, Black-Scholes & Bachelier solvers
│   ├── rq-synthetic/   # Synthetic future parity construction engine
│   ├── rq-pricing/     # Real-time pricing engine
│   ├── rq-greeks/      # High-performance analytical Greeks
│   ├── rq-market/      # L2 order book & market maker simulation
│   ├── rq-portfolio/   # Position tracking & P&L attribution
│   ├── rq-risk/        # 10,000 path Monte Carlo simulation
│   └── rq-margin/      # Risk-based scenario margin engine`}
          </pre>
        </div>
      )}

      {/* SQL SCHEMA */}
      {activeDoc === 'SQL' && (
        <div className="bg-[#182C35]/40 border border-[#294A59] p-6 space-y-4 font-mono text-xs">
          <div className="text-sm font-bold text-[#E9E7DF] uppercase border-b border-[#294A59] pb-2">
            POSTGRESQL PERSISTENCE SCHEMA
          </div>
          <pre className="p-4 bg-[#111313] text-[#C7D2D1] border border-[#202426] leading-relaxed">
{`CREATE TABLE instruments (
    instrument_id VARCHAR(64) PRIMARY KEY,
    symbol VARCHAR(32) UNIQUE NOT NULL,
    asset_class VARCHAR(32) NOT NULL,
    price_source VARCHAR(32) NOT NULL
);

CREATE TABLE synthetics (
    synthetic_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    synthetic_type VARCHAR(48) NOT NULL,
    financing_rate NUMERIC(8, 4) NOT NULL
);`}
          </pre>
        </div>
      )}
    </div>
  );
};
