import React, { useState } from 'react';
import { MarketState } from '../engine/marketSim';
import { INITIAL_MARKET_MAKERS } from '../engine/marketSim';
import { Activity, Sliders, CheckCircle } from 'lucide-react';

interface MarketTerminalProps {
  markets: MarketState[];
}

export const MarketTerminal: React.FC<MarketTerminalProps> = ({ markets }) => {
  const [selectedSymbol, setSelectedSymbol] = useState<string>('COPPER-202712');
  const market = markets.find(m => m.symbol === selectedSymbol) || markets[0];

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4">
        <div>
          <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <Activity className="w-3.5 h-3.5 text-[#294A59]" />
            <span>SIMULATED INSTITUTIONAL ORDER BOOK & MARKET MAKERS</span>
          </div>
          <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
            RHINOQUANT ORDER BOOK
          </h1>
        </div>

        <div className="font-mono text-xs px-3 py-1 bg-[#202426] border border-[#727977]/30 text-[#727977]">
          STATUS: <span className="text-[#3F7354] font-bold">SIMULATED EXCHANGE FEED</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono text-xs">
        {/* LEFT COLUMN: MARKET LIST & MARKET MAKERS */}
        <div className="lg:col-span-4 space-y-5">
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-4 space-y-3">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              SELECT SYNTHETIC MARKET
            </div>
            <div className="space-y-1">
              {markets.map((m) => (
                <button
                  key={m.symbol}
                  onClick={() => setSelectedSymbol(m.symbol)}
                  className={`w-full p-2.5 text-left border transition-colors flex items-center justify-between cursor-pointer ${
                    m.symbol === selectedSymbol
                      ? 'bg-[#294A59] text-[#E9E7DF] border-[#C7D2D1]/40 font-bold'
                      : 'bg-[#111313] text-[#727977] border-[#202426] hover:text-[#E9E7DF]'
                  }`}
                >
                  <span className="truncate">{m.name}</span>
                  <span className="tabular-nums">£{m.syntheticPrice}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-[#202426]/40 border border-[#727977]/20 p-4 space-y-3">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              ACTIVE LIQUIDITY PROVIDERS & MARKET MAKERS
            </div>
            <div className="space-y-2 text-[11px]">
              {INITIAL_MARKET_MAKERS.map((mm) => (
                <div key={mm.id} className="p-2 bg-[#111313] border border-[#202426] flex items-center justify-between">
                  <span className="text-[#E9E7DF] truncate">{mm.name}</span>
                  <span className="text-[#3F7354] font-bold">{mm.spreadBps} bps spread</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: L2 ORDER BOOK DEPTH */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-[#182C35]/40 border border-[#294A59] p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#294A59] pb-3">
              <span className="font-bold text-[#E9E7DF] text-sm uppercase">{market.name} L2 DEPTH</span>
              <span className="text-[#3F7354] font-bold">SPREAD: £{market.orderBook.simulatedSpread}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* BIDS */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold text-[#3F7354] uppercase border-b border-[#3F7354]/30 pb-1">
                  BIDS (BUY ORDERS)
                </div>
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="text-[#727977] text-[10px]">
                      <th>Price (£)</th>
                      <th className="text-right">Qty</th>
                      <th className="text-right">Count</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#202426]">
                    {market.orderBook.bids.map((b, i) => (
                      <tr key={i} className="hover:bg-[#3F7354]/10">
                        <td className="p-1.5 text-[#3F7354] font-bold tabular-nums">£{b.price}</td>
                        <td className="p-1.5 text-right text-[#E9E7DF] tabular-nums">{b.quantity}</td>
                        <td className="p-1.5 text-right text-[#727977]">{b.ordersCount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* ASKS */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold text-[#9B4038] uppercase border-b border-[#9B4038]/30 pb-1">
                  ASKS (SELL ORDERS)
                </div>
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="text-[#727977] text-[10px]">
                      <th>Price (£)</th>
                      <th className="text-right">Qty</th>
                      <th className="text-right">Count</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#202426]">
                    {market.orderBook.asks.map((a, i) => (
                      <tr key={i} className="hover:bg-[#9B4038]/10">
                        <td className="p-1.5 text-[#9B4038] font-bold tabular-nums">£{a.price}</td>
                        <td className="p-1.5 text-right text-[#E9E7DF] tabular-nums">{a.quantity}</td>
                        <td className="p-1.5 text-right text-[#727977]">{a.ordersCount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
