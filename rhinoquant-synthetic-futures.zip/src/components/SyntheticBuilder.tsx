import React, { useState } from 'react';
import { AssetClass, LegInput, SyntheticFutureConfig, SyntheticType } from '../types/rhinoquant';
import { calculateSyntheticFairValue } from '../engine/quantEngine';
import { Plus, Trash2, Sliders, Info, Shield, CheckCircle, ArrowRight } from 'lucide-react';

interface SyntheticBuilderProps {
  initialConfig?: SyntheticFutureConfig;
  onSaveSynthetic?: (config: SyntheticFutureConfig) => void;
  onOpenProvenance?: (id: string) => void;
}

export const SyntheticBuilder: React.FC<SyntheticBuilderProps> = ({
  initialConfig,
  onSaveSynthetic,
  onOpenProvenance
}) => {
  const [underlying, setUnderlying] = useState<string>(initialConfig?.underlying || 'COPPER');
  const [assetClass, setAssetClass] = useState<AssetClass>(initialConfig?.assetClass || 'METALS');
  const [syntheticType, setSyntheticType] = useState<SyntheticType>(initialConfig?.syntheticType || 'SYNTHETIC_LONG_FUTURE');
  const [expiry, setExpiry] = useState<string>(initialConfig?.expiry || '2027-12');

  // Model parameters
  const [financingRate, setFinancingRate] = useState<number>(initialConfig?.financingRate || 4.25);
  const [storageCost, setStorageCost] = useState<number>(initialConfig?.storageCost || 1.20);
  const [convenienceYield, setConvenienceYield] = useState<number>(initialConfig?.convenienceYield || 0.85);
  const [domesticRate, setDomesticRate] = useState<number>(initialConfig?.domesticRate || 4.25);
  const [foreignRate, setForeignRate] = useState<number>(initialConfig?.foreignRate || 3.75);
  const [routeIndex, setRouteIndex] = useState<number>(initialConfig?.routeIndex || 1280);
  const [bunkerPrice, setBunkerPrice] = useState<number>(initialConfig?.bunkerPrice || 620);
  const [gasPrice, setGasPrice] = useState<number>(initialConfig?.gasPrice || 78.5);
  const [carbonPrice, setCarbonPrice] = useState<number>(initialConfig?.carbonPrice || 68.2);
  const [milkPrice, setMilkPrice] = useState<number>(initialConfig?.milkPrice || 42.5);
  const [processingMargin, setProcessingMargin] = useState<number>(initialConfig?.processingMargin || 12.0);
  const [transactionCost, setTransactionCost] = useState<number>(initialConfig?.transactionCost || 1.50);
  const [slippage, setSlippage] = useState<number>(initialConfig?.slippage || 0.50);

  // Legs state
  const [legs, setLegs] = useState<LegInput[]>(
    initialConfig?.legs || [
      {
        instrumentId: 'COPPER-CALL-202712-10500',
        symbol: 'CALL-COPPER-2027-12-10500',
        type: 'CALL',
        side: 'LONG',
        quantity: 1,
        strike: 10500,
        price: 542.0
      },
      {
        instrumentId: 'COPPER-PUT-202712-10500',
        symbol: 'PUT-COPPER-2027-12-10500',
        type: 'PUT',
        side: 'SHORT',
        quantity: 1,
        strike: 10500,
        price: 526.6
      }
    ]
  );

  const currentConfig: SyntheticFutureConfig = {
    id: initialConfig?.id || `RQ-SYN-CUSTOM-${Date.now().toString().slice(-4)}`,
    name: `${underlying} ${expiry} ${syntheticType.replace('_', ' ')}`,
    underlying,
    assetClass,
    syntheticType,
    expiry,
    legs,
    financingRate,
    storageCost,
    convenienceYield,
    domesticRate,
    foreignRate,
    routeIndex,
    bunkerPrice,
    gasPrice,
    carbonPrice,
    milkPrice,
    processingMargin,
    transactionCost,
    slippage,
    observedFutureSymbol: `${underlying}-${expiry.replace('-', '')}`
  };

  const pricingResult = calculateSyntheticFairValue(currentConfig);

  const handleAddLeg = () => {
    const newLeg: LegInput = {
      instrumentId: `LEG-${legs.length + 1}`,
      symbol: `LEG-${underlying}-${legs.length + 1}`,
      type: 'CALL',
      side: 'LONG',
      quantity: 1,
      strike: 10000,
      price: 500.0
    };
    setLegs([...legs, newLeg]);
  };

  const handleRemoveLeg = (index: number) => {
    setLegs(legs.filter((_, i) => i !== index));
  };

  const handleUpdateLeg = (index: number, field: keyof LegInput, value: any) => {
    const updated = [...legs];
    updated[index] = { ...updated[index], [field]: value };
    setLegs(updated);
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4">
        <div>
          <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <Sliders className="w-3.5 h-3.5 text-[#294A59]" />
            <span>SYNTHETIC INSTRUMENT CONSTRUCTION LABORATORY</span>
          </div>
          <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
            SYNTHETIC FUTURE BUILDER
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onSaveSynthetic?.(currentConfig)}
            className="px-4 py-2 bg-[#294A59] hover:bg-[#294A59]/80 text-[#E9E7DF] font-mono text-xs font-semibold border border-[#C7D2D1]/20 transition-colors flex items-center gap-2"
          >
            <CheckCircle className="w-3.5 h-3.5" />
            <span>SAVE TO SYNTHETIC REGISTRY</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: INSTRUMENT CONFIGURATION & LEGS */}
        <div className="lg:col-span-7 space-y-6">
          {/* STEP 1: GENERAL INSTRUMENT CONFIGURATION */}
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-4">
            <div className="font-mono text-xs font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase tracking-wider flex items-center justify-between">
              <span>01. UNDERLYING & SYNTHETIC TYPE</span>
              <span className="text-[#727977] font-normal">CONFIG</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
              <div>
                <label className="block text-[#727977] text-[11px] mb-1">UNDERLYING ASSET</label>
                <input
                  type="text"
                  value={underlying}
                  onChange={(e) => setUnderlying(e.target.value.toUpperCase())}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-semibold focus:outline-none focus:border-[#294A59]"
                />
              </div>

              <div>
                <label className="block text-[#727977] text-[11px] mb-1">ASSET CLASS</label>
                <select
                  value={assetClass}
                  onChange={(e) => setAssetClass(e.target.value as AssetClass)}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-semibold focus:outline-none focus:border-[#294A59]"
                >
                  <option value="METALS">METALS</option>
                  <option value="ENERGY">ENERGY</option>
                  <option value="AGRICULTURE">AGRICULTURE</option>
                  <option value="DAIRY">DAIRY</option>
                  <option value="FREIGHT">FREIGHT</option>
                  <option value="POWER">POWER</option>
                  <option value="RATES">RATES</option>
                  <option value="FX">FX</option>
                  <option value="EQUITY">EQUITY</option>
                  <option value="CUSTOM">CUSTOM</option>
                </select>
              </div>

              <div>
                <label className="block text-[#727977] text-[11px] mb-1">EXPIRY TENOR</label>
                <input
                  type="text"
                  value={expiry}
                  onChange={(e) => setExpiry(e.target.value)}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-semibold focus:outline-none focus:border-[#294A59]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[#727977] text-[11px] mb-1">SYNTHETIC PARITY MODEL</label>
              <select
                value={syntheticType}
                onChange={(e) => setSyntheticType(e.target.value as SyntheticType)}
                className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#C7D2D1] font-bold focus:outline-none focus:border-[#294A59] font-mono"
              >
                <option value="SYNTHETIC_LONG_FUTURE">SYNTHETIC LONG FUTURE (Long Call + Short Put)</option>
                <option value="SYNTHETIC_SHORT_FUTURE">SYNTHETIC SHORT FUTURE (Short Call + Long Put)</option>
                <option value="SYNTHETIC_COMMODITY">SYNTHETIC COMMODITY (Spot + Cost of Carry)</option>
                <option value="SYNTHETIC_FX">SYNTHETIC FX (Covered Interest Rate Parity)</option>
                <option value="SYNTHETIC_FREIGHT">SYNTHETIC FREIGHT (Route Index + Fuel Bunker)</option>
                <option value="SYNTHETIC_POWER">SYNTHETIC POWER (Spark/Dark Spread Baseload)</option>
                <option value="SYNTHETIC_DAIRY">SYNTHETIC DAIRY (Milk/Cream Yield Synthesis)</option>
                <option value="BASKET">MULTI-ASSET CUSTOM BASKET</option>
              </select>
            </div>
          </div>

          {/* STEP 2: CONSTITUENT LEGS */}
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-4">
            <div className="font-mono text-xs font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase tracking-wider flex items-center justify-between">
              <span>02. CONSTITUENT LEGS</span>
              <button
                onClick={handleAddLeg}
                className="text-[11px] px-2 py-1 bg-[#294A59] hover:bg-[#294A59]/80 text-[#E9E7DF] transition-colors flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>ADD LEG</span>
              </button>
            </div>

            <div className="space-y-3">
              {legs.map((leg, index) => (
                <div
                  key={index}
                  className="bg-[#111313] border border-[#202426] p-3 space-y-3 font-mono text-xs"
                >
                  <div className="flex items-center justify-between border-b border-[#202426] pb-2">
                    <span className="font-semibold text-[#294A59]">LEG {index + 1}</span>
                    <button
                      onClick={() => handleRemoveLeg(index)}
                      className="text-[#9B4038] hover:text-red-400 text-xs transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    <div>
                      <label className="block text-[#727977] text-[10px]">TYPE</label>
                      <select
                        value={leg.type}
                        onChange={(e) => handleUpdateLeg(index, 'type', e.target.value)}
                        className="w-full bg-[#202426] border border-[#727977]/20 p-1 text-[#E9E7DF] focus:outline-none"
                      >
                        <option value="CALL">CALL</option>
                        <option value="PUT">PUT</option>
                        <option value="SPOT">SPOT</option>
                        <option value="FORWARD">FORWARD</option>
                        <option value="FUTURE">FUTURE</option>
                        <option value="SWAP">SWAP</option>
                        <option value="INDEX">INDEX</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[#727977] text-[10px]">SIDE</label>
                      <select
                        value={leg.side}
                        onChange={(e) => handleUpdateLeg(index, 'side', e.target.value)}
                        className="w-full bg-[#202426] border border-[#727977]/20 p-1 text-[#E9E7DF] focus:outline-none"
                      >
                        <option value="LONG">LONG (+)</option>
                        <option value="SHORT">SHORT (-)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[#727977] text-[10px]">STRIKE</label>
                      <input
                        type="number"
                        value={leg.strike || ''}
                        onChange={(e) => handleUpdateLeg(index, 'strike', parseFloat(e.target.value))}
                        className="w-full bg-[#202426] border border-[#727977]/20 p-1 text-[#E9E7DF] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[#727977] text-[10px]">PRICE</label>
                      <input
                        type="number"
                        step="0.1"
                        value={leg.price}
                        onChange={(e) => handleUpdateLeg(index, 'price', parseFloat(e.target.value))}
                        className="w-full bg-[#202426] border border-[#727977]/20 p-1 text-[#E9E7DF] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[#727977] text-[10px]">QTY</label>
                      <input
                        type="number"
                        value={leg.quantity}
                        onChange={(e) => handleUpdateLeg(index, 'quantity', parseFloat(e.target.value))}
                        className="w-full bg-[#202426] border border-[#727977]/20 p-1 text-[#E9E7DF] focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* STEP 3: CARRY, FINANCING & MODEL INPUTS */}
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-4">
            <div className="font-mono text-xs font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase tracking-wider">
              03. FINANCING, CARRY & TRANSACTION FRICTION
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
              <div>
                <label className="block text-[#727977] text-[10px]">FINANCING RATE (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={financingRate}
                  onChange={(e) => setFinancingRate(parseFloat(e.target.value))}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[#727977] text-[10px]">STORAGE COST (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={storageCost}
                  onChange={(e) => setStorageCost(parseFloat(e.target.value))}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[#727977] text-[10px]">CONVENIENCE YIELD (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={convenienceYield}
                  onChange={(e) => setConvenienceYield(parseFloat(e.target.value))}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[#727977] text-[10px]">TRANSACTION COST (£)</label>
                <input
                  type="number"
                  step="0.1"
                  value={transactionCost}
                  onChange={(e) => setTransactionCost(parseFloat(e.target.value))}
                  className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: REAL-TIME PRICING & PROVENANCE RESULTS */}
        <div className="lg:col-span-5 space-y-6">
          {/* PRICING RESULT CARD */}
          <div className="bg-[#182C35]/60 border border-[#294A59] p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#294A59] pb-3 font-mono">
              <span className="text-xs font-bold text-[#E9E7DF] uppercase">SYNTHETIC FAIR VALUE</span>
              <span className="text-[10px] px-2 py-0.5 bg-[#294A59] text-[#E9E7DF]">MODEL: {pricingResult.modelId}</span>
            </div>

            <div className="space-y-1">
              <div className="text-3xl font-extrabold font-mono text-[#C7D2D1] tabular-nums">
                £{pricingResult.fairValue.toLocaleString()}
              </div>
              <div className="text-xs font-mono text-[#727977]">
                SYNTHETIC MID FAIR VALUE
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 font-mono text-xs border-t border-[#294A59]/40">
              <div className="p-2 bg-[#111313]">
                <div className="text-[10px] text-[#727977]">SYNTHETIC BID / ASK</div>
                <div className="text-sm font-bold text-[#E9E7DF] tabular-nums">
                  £{pricingResult.bid} / £{pricingResult.ask}
                </div>
              </div>

              <div className="p-2 bg-[#111313]">
                <div className="text-[10px] text-[#727977]">BASIS VS OBSERVED</div>
                <div className={`text-sm font-bold tabular-nums ${pricingResult.basis >= 0 ? 'text-[#3F7354]' : 'text-[#9B4038]'}`}>
                  {pricingResult.basis >= 0 ? '+' : ''}{pricingResult.basis} ({pricingResult.basisPercent}%)
                </div>
              </div>
            </div>

            {/* SYNTHETIC GREEKS GRID */}
            <div className="pt-3 border-t border-[#294A59]/40 space-y-2">
              <div className="text-[11px] font-mono text-[#727977] uppercase">SYNTHETIC GREEKS</div>
              <div className="grid grid-cols-3 gap-2 font-mono text-xs">
                <div className="p-2 bg-[#111313] text-center">
                  <div className="text-[9px] text-[#727977]">DELTA</div>
                  <div className="font-bold text-[#E9E7DF]">{pricingResult.greeks.delta.toFixed(3)}</div>
                </div>
                <div className="p-2 bg-[#111313] text-center">
                  <div className="text-[9px] text-[#727977]">GAMMA</div>
                  <div className="font-bold text-[#E9E7DF]">{pricingResult.greeks.gamma.toFixed(5)}</div>
                </div>
                <div className="p-2 bg-[#111313] text-center">
                  <div className="text-[9px] text-[#727977]">VEGA</div>
                  <div className="font-bold text-[#E9E7DF]">{pricingResult.greeks.vega.toFixed(1)}</div>
                </div>
                <div className="p-2 bg-[#111313] text-center">
                  <div className="text-[9px] text-[#727977]">THETA</div>
                  <div className="font-bold text-[#E9E7DF]">{pricingResult.greeks.theta.toFixed(2)}</div>
                </div>
                <div className="p-2 bg-[#111313] text-center">
                  <div className="text-[9px] text-[#727977]">RHO</div>
                  <div className="font-bold text-[#E9E7DF]">{pricingResult.greeks.rho.toFixed(2)}</div>
                </div>
                <div className="p-2 bg-[#111313] text-center">
                  <div className="text-[9px] text-[#727977]">DV01</div>
                  <div className="font-bold text-[#E9E7DF]">{pricingResult.greeks.dv01.toFixed(3)}</div>
                </div>
              </div>
            </div>
          </div>

          {/* MODEL EQUATIONS & PROVENANCE BREAKDOWN */}
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-3 font-mono text-xs">
            <div className="text-xs font-bold text-[#E9E7DF] uppercase border-b border-[#727977]/20 pb-2 flex items-center justify-between">
              <span>MODEL EQUATIONS & PROVENANCE</span>
              <span className="text-[10px] text-[#3F7354]">CALIBRATED: 2026-09-26</span>
            </div>

            <div className="space-y-2 text-[11px]">
              <div className="text-[#727977] uppercase text-[10px]">GOVERNING EQUATIONS</div>
              {pricingResult.provenance.equations.map((eq, i) => (
                <div key={i} className="p-2 bg-[#111313] text-[#C7D2D1] border-l-2 border-[#294A59]">
                  {eq}
                </div>
              ))}
            </div>

            <div className="space-y-1 text-[11px] pt-2">
              <div className="text-[#727977] uppercase text-[10px]">KEY MODEL ASSUMPTIONS</div>
              <ul className="list-disc pl-4 text-[#727977] space-y-1">
                {pricingResult.provenance.assumptions.map((asm, i) => (
                  <li key={i}>{asm}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
