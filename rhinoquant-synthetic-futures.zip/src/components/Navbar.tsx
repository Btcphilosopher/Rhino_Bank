import React from 'react';
import { MarketRegime } from '../types/rhinoquant';
import { Activity, Database, Shield, Sliders, Terminal, TrendingUp, Layers, Play, BookOpen, Cpu } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentRegime: MarketRegime;
  onRegimeChange: (regime: MarketRegime) => void;
  isWsConnected: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentRegime,
  onRegimeChange,
  isWsConnected
}) => {
  const navItems = [
    { id: 'OVERVIEW', label: 'Overview', icon: Activity },
    { id: 'BUILDER', label: 'Synthetic Builder', icon: Sliders },
    { id: 'COMMODITIES', label: 'Commodity Lab', icon: Layers },
    { id: 'CURVE', label: 'Forward Curve', icon: TrendingUp },
    { id: 'VOL', label: 'Vol Surface', icon: Cpu },
    { id: 'RISK', label: 'Risk & Scenarios', icon: Shield },
    { id: 'MARGIN', label: 'Margin & Collateral', icon: Database },
    { id: 'RESEARCH', label: 'R Research', icon: Terminal },
    { id: 'MARKET', label: 'Order Book', icon: Activity },
    { id: 'REPLAY', label: 'Replay', icon: Play },
    { id: 'DOCS', label: 'Docs / API', icon: BookOpen }
  ];

  return (
    <header className="border-b border-[#202426] bg-[#111313] px-6 py-3 sticky top-0 z-50">
      <div className="flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className="flex items-center gap-3 text-left focus:outline-none group"
          >
            <div className="w-8 h-8 bg-[#294A59] border border-[#727977]/30 flex items-center justify-center font-mono font-bold text-lg text-[#E9E7DF] tracking-tighter shadow-inner">
              RQ
            </div>
            <div>
              <div className="text-base font-bold tracking-wider text-[#E9E7DF] font-mono group-hover:text-[#C7D2D1] transition-colors">
                RHINOQUANT
              </div>
              <div className="text-[10px] text-[#727977] font-mono tracking-widest uppercase">
                SYNTHETIC FUTURES PLATFORM
              </div>
            </div>
          </button>
        </div>

        {/* Zone 2: Product Family Nav Links */}
        <nav className="hidden xl:flex items-center gap-1 font-mono text-xs">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1.5 flex items-center gap-1.5 transition-all duration-150 whitespace-nowrap ${
                  isActive
                    ? 'bg-[#202426] text-[#E9E7DF] border-b-2 border-[#294A59] font-medium'
                    : 'text-[#727977] hover:text-[#E9E7DF] hover:bg-[#202426]/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#294A59]' : 'text-[#727977]'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Regime Selector & Telemetry */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="flex items-center gap-2 bg-[#202426] px-2.5 py-1 border border-[#727977]/20">
            <span className="text-[#727977] text-[10px] uppercase">REGIME:</span>
            <select
              value={currentRegime}
              onChange={(e) => onRegimeChange(e.target.value as MarketRegime)}
              className="bg-transparent text-[#E9E7DF] font-semibold text-xs focus:outline-none cursor-pointer"
            >
              <option value="NORMAL" className="bg-[#111313] text-[#E9E7DF]">NORMAL</option>
              <option value="HIGH_VOLATILITY" className="bg-[#111313] text-[#E9E7DF]">HIGH VOLATILITY</option>
              <option value="CONTANGO" className="bg-[#111313] text-[#E9E7DF]">CONTANGO</option>
              <option value="BACKWARDATION" className="bg-[#111313] text-[#E9E7DF]">BACKWARDATION</option>
              <option value="BASIS_SHOCK" className="bg-[#111313] text-[#E9E7DF]">BASIS SHOCK</option>
              <option value="LIQUIDITY_CRISIS" className="bg-[#111313] text-[#E9E7DF]">LIQUIDITY CRISIS</option>
            </select>
          </div>

          <div className="flex items-center gap-2 px-2 py-1 text-[11px] text-[#727977]">
            <span className={`w-2 h-2 rounded-full ${isWsConnected ? 'bg-[#3F7354] animate-pulse' : 'bg-[#9B4038]'}`}></span>
            <span className="hidden sm:inline">{isWsConnected ? 'FEED LIVE' : 'FEED DISCONNECTED'}</span>
          </div>
        </div>
      </div>

      {/* Sub-nav for smaller viewports */}
      <div className="flex xl:hidden overflow-x-auto gap-2 pt-2 text-xs font-mono border-t border-[#202426]/50 mt-2 scrollbar-none">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-2.5 py-1 transition-colors whitespace-nowrap text-[11px] ${
                isActive
                  ? 'bg-[#294A59] text-[#E9E7DF] font-medium'
                  : 'text-[#727977] hover:text-[#E9E7DF]'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
