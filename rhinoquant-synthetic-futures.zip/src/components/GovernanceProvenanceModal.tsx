import React from 'react';
import { X, CheckCircle, Info, Shield, FileText } from 'lucide-react';

interface GovernanceProvenanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbol: string;
}

export const GovernanceProvenanceModal: React.FC<GovernanceProvenanceModalProps> = ({
  isOpen,
  onClose,
  symbol
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 font-mono text-xs">
      <div className="bg-[#111313] border border-[#294A59] max-w-2xl w-full p-6 space-y-6 relative shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#727977] hover:text-[#E9E7DF] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-1 border-b border-[#202426] pb-3">
          <div className="text-[10px] text-[#294A59] font-bold uppercase">HOW WAS THIS CALCULATED?</div>
          <h2 className="text-xl font-bold text-[#E9E7DF]">
            MODEL GOVERNANCE & DATA PROVENANCE
          </h2>
          <div className="text-[#727977] text-[11px]">
            Target Instrument: {symbol}
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 p-3 bg-[#182C35]/40 border border-[#294A59]">
            <div>
              <span className="text-[#727977]">MODEL ID:</span>
              <span className="ml-2 text-[#E9E7DF] font-bold">RQ-SYN-FUT-001</span>
            </div>
            <div>
              <span className="text-[#727977]">VERSION:</span>
              <span className="ml-2 text-[#E9E7DF] font-bold">1.4.2</span>
            </div>
            <div>
              <span className="text-[#727977]">CALIBRATION DATE:</span>
              <span className="ml-2 text-[#E9E7DF]">2026-09-26</span>
            </div>
            <div>
              <span className="text-[#727977]">VALIDATION STATUS:</span>
              <span className="ml-2 text-[#3F7354] font-bold">RESEARCH</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-[#E9E7DF] font-bold uppercase border-b border-[#202426] pb-1">
              01. GOVERNING MATHEMATICAL EQUATION
            </div>
            <div className="p-3 bg-[#202426]/60 text-[#C7D2D1] border-l-2 border-[#294A59]">
              Call-Put Parity: F_synthetic = Strike + exp(r*T) * (Call_Price - Put_Price)
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-[#E9E7DF] font-bold uppercase border-b border-[#202426] pb-1">
              02. CALIBRATION ASSUMPTIONS & LIMITATIONS
            </div>
            <ul className="list-disc pl-5 text-[#727977] space-y-1">
              <li>Continuous risk-free interest compounding at 4.25% annualised rate</li>
              <li>Option legs are European vanilla contracts with identical strike and expiry</li>
              <li>Zero counterparty credit risk across clearing venues</li>
            </ul>
          </div>
        </div>

        <div className="pt-4 border-t border-[#202426] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#294A59] hover:bg-[#294A59]/80 text-[#E9E7DF] font-bold cursor-pointer"
          >
            CLOSE AUDIT PROVENANCE
          </button>
        </div>
      </div>
    </div>
  );
};
