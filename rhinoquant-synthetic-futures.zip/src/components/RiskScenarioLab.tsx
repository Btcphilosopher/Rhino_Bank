import React, { useState } from 'react';
import { Position, ScenarioConfig } from '../types/rhinoquant';
import { runMonteCarloSimulation, runScenarioAnalysis } from '../engine/quantEngine';
import { Shield, Activity, RefreshCw, BarChart2 } from 'lucide-react';

interface RiskScenarioLabProps {
  positions: Position[];
}

export const RiskScenarioLab: React.FC<RiskScenarioLabProps> = ({ positions }) => {
  const [spotShockPct, setSpotShockPct] = useState<number>(10);
  const [volShockPct, setVolShockPct] = useState<number>(15);
  const [rateShockBps, setRateShockBps] = useState<number>(50);

  const scenarioConfig: ScenarioConfig = {
    spotShockPct,
    volShockPct,
    rateShockBps,
    fxShockPct: 2,
    basisShockBps: 25,
    liquidityShockPct: 10
  };

  const scenarioResults = runScenarioAnalysis(positions, scenarioConfig);
  const mcResult = runMonteCarloSimulation(13850000, 0.22, 10, 10000);

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4">
        <div>
          <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-[#3F7354]" />
            <span>PORTFOLIO RISK DECOMPOSITION & MONTE CARLO SCENARIO ENGINE</span>
          </div>
          <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
            RHINOQUANT RISK LAB
          </h1>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="p-2 bg-[#202426] border border-[#727977]/30">
            <span className="text-[#727977]">VaR (95%, 10-DAY): </span>
            <span className="font-bold text-[#E9E7DF] tabular-nums">£{mcResult.var95.toLocaleString()}</span>
          </div>
          <div className="p-2 bg-[#202426] border border-[#727977]/30">
            <span className="text-[#727977]">EXPECTED SHORTFALL (95%): </span>
            <span className="font-bold text-[#9B4038] tabular-nums">£{mcResult.expectedShortfall95.toLocaleString()}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: SCENARIO CONTROLS */}
        <div className="lg:col-span-4 space-y-5">
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-4 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              INTERACTIVE SCENARIO CONTROLS
            </div>

            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-[#727977]">SPOT PRICE SHOCK</span>
                <span className="text-[#E9E7DF] font-bold">{spotShockPct > 0 ? '+' : ''}{spotShockPct}%</span>
              </div>
              <input
                type="range"
                min="-30"
                max="30"
                step="5"
                value={spotShockPct}
                onChange={(e) => setSpotShockPct(parseInt(e.target.value))}
                className="w-full accent-[#294A59] cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-[#727977]">VOLATILITY SHOCK</span>
                <span className="text-[#E9E7DF] font-bold">{volShockPct > 0 ? '+' : ''}{volShockPct}%</span>
              </div>
              <input
                type="range"
                min="-20"
                max="50"
                step="5"
                value={volShockPct}
                onChange={(e) => setVolShockPct(parseInt(e.target.value))}
                className="w-full accent-[#B38A42] cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-[#727977]">YIELD CURVE SHIFT</span>
                <span className="text-[#E9E7DF] font-bold">{rateShockBps > 0 ? '+' : ''}{rateShockBps} bps</span>
              </div>
              <input
                type="range"
                min="-150"
                max="150"
                step="25"
                value={rateShockBps}
                onChange={(e) => setRateShockBps(parseInt(e.target.value))}
                className="w-full accent-[#3F7354] cursor-pointer"
              />
            </div>
          </div>

          {/* MONTE CARLO SUMMARY */}
          <div className="bg-[#182C35]/40 border border-[#294A59] p-5 space-y-3 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#294A59] pb-2 uppercase">
              10,000 PATH MONTE CARLO ENGINE
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-[#727977]">VaR 99% (WORST 1%):</span>
                <span className="font-bold text-[#9B4038] tabular-nums">£{mcResult.var99.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">MAXIMUM TAIL LOSS:</span>
                <span className="font-bold text-[#9B4038] tabular-nums">£{mcResult.tailLoss.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">95% CONFIDENCE BOUNDS:</span>
                <span className="font-bold text-[#C7D2D1] tabular-nums">
                  [£{(mcResult.confidenceInterval[0]/1000).toFixed(0)}k, £{(mcResult.confidenceInterval[1]/1000).toFixed(0)}k]
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: SCENARIO MATRIX & HISTOGRAM */}
        <div className="lg:col-span-8 space-y-6">
          {/* SCENARIO RESULTS TABLE */}
          <div className="bg-[#202426]/40 border border-[#727977]/20">
            <div className="p-4 border-b border-[#727977]/20 font-mono text-xs font-bold text-[#E9E7DF] uppercase">
              STRESS SCENARIO IMPACT BREAKDOWN
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="bg-[#111313] text-[#727977] border-b border-[#727977]/20 uppercase text-[11px]">
                    <th className="p-3">Scenario Name</th>
                    <th className="p-3 text-right">Portfolio P&L</th>
                    <th className="p-3 text-right">P&L %</th>
                    <th className="p-3 text-right">Margin Change</th>
                    <th className="p-3 text-right">Post-Stress VaR</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#727977]/10">
                  {scenarioResults.map((s, idx) => {
                    const isPositive = s.portfolioPnL >= 0;
                    return (
                      <tr key={idx} className="hover:bg-[#202426]/60">
                        <td className="p-3 font-semibold text-[#E9E7DF]">{s.scenarioName}</td>
                        <td className={`p-3 text-right font-bold tabular-nums ${isPositive ? 'text-[#3F7354]' : 'text-[#9B4038]'}`}>
                          {isPositive ? '+' : ''}£{s.portfolioPnL.toLocaleString()}
                        </td>
                        <td className={`p-3 text-right tabular-nums ${isPositive ? 'text-[#3F7354]' : 'text-[#9B4038]'}`}>
                          {isPositive ? '+' : ''}{s.portfolioPnLPct}%
                        </td>
                        <td className="p-3 text-right text-[#E9E7DF] tabular-nums">
                          +£{s.marginChange.toLocaleString()}
                        </td>
                        <td className="p-3 text-right text-[#C7D2D1] tabular-nums">
                          £{s.newVar.toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* MONTE CARLO HISTOGRAM */}
          <div className="bg-[#182C35]/40 border border-[#294A59] p-5 space-y-3">
            <div className="font-mono text-xs font-bold text-[#E9E7DF] uppercase">
              P&L DISTRIBUTION HISTOGRAM (10,000 PATHS)
            </div>
            <div className="h-44 flex items-end gap-2 bg-[#111313] p-4 border border-[#202426]">
              {mcResult.pnlHistogram.map((bin, i) => {
                const maxCount = Math.max(...mcResult.pnlHistogram.map(b => b.count));
                const heightPct = (bin.count / maxCount) * 100;
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                    <div
                      className="w-full bg-[#294A59] hover:bg-[#C7D2D1] transition-colors"
                      style={{ height: `${heightPct}%` }}
                    ></div>
                    <span className="text-[9px] font-mono text-[#727977] truncate w-full text-center">
                      {bin.bin}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
