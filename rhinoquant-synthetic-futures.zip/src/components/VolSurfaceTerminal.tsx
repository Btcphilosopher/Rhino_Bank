import React, { useState } from 'react';
import { buildVolSurface } from '../engine/quantEngine';
import { Cpu, Zap, Sliders, CheckCircle } from 'lucide-react';

export const VolSurfaceTerminal: React.FC = () => {
  const [underlying, setUnderlying] = useState<string>('COPPER');
  const [baseVol, setBaseVol] = useState<number>(0.247);
  const [pricingModel, setPricingModel] = useState<'BLACK76' | 'BLACK_SCHOLES' | 'BACHELIER'>('BLACK76');

  const volSurface = buildVolSurface(underlying, baseVol);

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4">
        <div>
          <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5 text-[#B38A42]" />
            <span>INSTITUTIONAL VOLATILITY SURFACE & SKEW ENGINE</span>
          </div>
          <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
            RHINOQUANT VOL ENGINE
          </h1>
        </div>

        {/* METRICS SUMMARY */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="p-2 bg-[#202426] border border-[#727977]/30">
            <span className="text-[#727977]">ATM VOL: </span>
            <span className="font-bold text-[#E9E7DF] tabular-nums">{volSurface.atmVol}%</span>
          </div>

          <div className="p-2 bg-[#202426] border border-[#727977]/30">
            <span className="text-[#727977]">25D SKEW (Put-Call): </span>
            <span className="font-bold text-[#3F7354] tabular-nums">+{volSurface.skew}%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: CONTROLS & MODEL SELECTION */}
        <div className="lg:col-span-4 space-y-5">
          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-4 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              SURFACE CALIBRATION INPUTS
            </div>

            <div>
              <label className="block text-[#727977] text-[11px] mb-1">UNDERLYING ASSET</label>
              <select
                value={underlying}
                onChange={(e) => setUnderlying(e.target.value)}
                className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-bold focus:outline-none"
              >
                <option value="COPPER">COPPER GRADE A (LME)</option>
                <option value="TIN">TIN 99.85% (LME)</option>
                <option value="BRENT">BRENT CRUDE (ICE)</option>
                <option value="WHEAT">MILLING WHEAT</option>
                <option value="POWER_UK">UK POWER BASELOAD</option>
              </select>
            </div>

            <div>
              <label className="block text-[#727977] text-[11px] mb-1">ATM IMPLIED VOLATILITY</label>
              <input
                type="number"
                step="0.005"
                value={baseVol}
                onChange={(e) => setBaseVol(parseFloat(e.target.value))}
                className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#E9E7DF] font-bold focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[#727977] text-[11px] mb-1">PRICING MODEL</label>
              <select
                value={pricingModel}
                onChange={(e) => setPricingModel(e.target.value as any)}
                className="w-full bg-[#111313] border border-[#727977]/30 p-2 text-[#C7D2D1] font-bold focus:outline-none"
              >
                <option value="BLACK76">BLACK-76 (FUTURES / COMMODITIES)</option>
                <option value="BLACK_SCHOLES">BLACK-SCHOLES (SPOT)</option>
                <option value="BACHELIER">BACHELIER (NORMAL VOLATILITY)</option>
              </select>
            </div>
          </div>

          <div className="bg-[#202426]/40 border border-[#727977]/20 p-5 space-y-3 font-mono text-xs">
            <div className="font-bold text-[#E9E7DF] border-b border-[#727977]/20 pb-2 uppercase">
              SMILE & TERM STRUCTURE METRICS
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-[#727977]">25 DELTA CALL VOL:</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">{volSurface.vol25Call}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">25 DELTA PUT VOL:</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">{volSurface.vol25Put}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">ATM STRADDLE PRICE:</span>
                <span className="font-bold text-[#C7D2D1] tabular-nums">£1,068.60</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#727977]">CALENDAR VOL SPREAD (1M-1Y):</span>
                <span className="font-bold text-[#E9E7DF] tabular-nums">-2.4%</span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: VOLATILITY SURFACE HEATMAP GRID */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-[#182C35]/40 border border-[#294A59] p-5 space-y-4">
            <div className="flex items-center justify-between font-mono text-xs">
              <span className="font-bold text-[#E9E7DF] uppercase">IMPLIED VOLATILITY SURFACE MATRIX (%)</span>
              <span className="text-[10px] text-[#727977]">STRIKE (% OF ATM) × EXPIRY TENOR</span>
            </div>

            <div className="overflow-x-auto bg-[#111313] p-4 border border-[#202426]">
              <table className="w-full text-center font-mono text-xs">
                <thead>
                  <tr className="border-b border-[#202426] text-[#727977] text-[11px]">
                    <th className="p-3 text-left">Expiry / Strike</th>
                    {volSurface.strikes.map((s) => (
                      <th key={s} className="p-3">{s}% Strike</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#202426]">
                  {volSurface.expiries.map((exp) => (
                    <tr key={exp} className="hover:bg-[#202426]/40">
                      <td className="p-3 font-bold text-left text-[#E9E7DF]">{exp} Tenor</td>
                      {volSurface.strikes.map((s) => {
                        const point = volSurface.points.find(p => p.expiryLabel === exp && p.strike === s);
                        const iv = point?.impliedVol || 24.7;
                        // Color intensity based on vol level
                        const bgOpacity = Math.min(0.8, (iv / 40));
                        return (
                          <td
                            key={s}
                            className="p-3 tabular-nums font-semibold text-[#E9E7DF] border-l border-[#202426]"
                            style={{ backgroundColor: `rgba(41, 74, 89, ${bgOpacity})` }}
                          >
                            {iv}%
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
