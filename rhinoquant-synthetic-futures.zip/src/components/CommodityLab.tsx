import React, { useState } from 'react';
import { Layers, Sliders, ArrowRight, Info, CheckCircle } from 'lucide-react';

export const CommodityLab: React.FC = () => {
  const [selectedCommodity, setSelectedCommodity] = useState<string>('DAIRY');

  const commodities = [
    { id: 'DAIRY', name: 'Rhino Dairy Component Synthesis', assetClass: 'DAIRY', spot: 3830, syn: 3842, unit: '£/tonne' },
    { id: 'COPPER', name: 'Copper Grade A LME', assetClass: 'METALS', spot: 10482, syn: 10497, unit: '£/tonne' },
    { id: 'TIN', name: 'Tin 99.85% LME', assetClass: 'METALS', spot: 34252, syn: 34210, unit: '£/tonne' },
    { id: 'BRENT', name: 'Brent Crude ICE', assetClass: 'ENERGY', spot: 81.39, syn: 81.47, unit: '$/bbl' },
    { id: 'FREIGHT', name: 'Capesize Route C5 Freight Index', assetClass: 'FREIGHT', spot: 1293, syn: 1284, unit: 'Index' },
    { id: 'POWER', name: 'UK Power Baseload Spark Spread', assetClass: 'POWER', spot: 84.5, syn: 85.2, unit: '£/MWh' },
    { id: 'BASKET', name: 'Rhino 5-Metals Basket Future', assetClass: 'CUSTOM', spot: 15420, syn: 15438, unit: 'Basket' }
  ];

  const active = commodities.find(c => c.id === selectedCommodity) || commodities[0];

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#202426] pb-4">
        <div>
          <div className="text-xs font-mono text-[#727977] uppercase tracking-wider flex items-center gap-2">
            <Layers className="w-3.5 h-3.5 text-[#294A59]" />
            <span>SPECIALISED SYNTHETIC COMMODITIES RESEARCH LABORATORY</span>
          </div>
          <h1 className="text-2xl font-bold font-mono text-[#E9E7DF] tracking-tight">
            SYNTHETIC COMMODITY LAB
          </h1>
        </div>
      </div>

      {/* COMMODITY SELECTOR GRID */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 font-mono text-xs">
        {commodities.map((c) => {
          const isSelected = selectedCommodity === c.id;
          return (
            <button
              key={c.id}
              onClick={() => setSelectedCommodity(c.id)}
              className={`p-3 text-left border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#294A59] text-[#E9E7DF] border-[#C7D2D1]/40 shadow-inner font-bold'
                  : 'bg-[#202426]/40 text-[#727977] border-[#727977]/20 hover:text-[#E9E7DF] hover:bg-[#202426]'
              }`}
            >
              <div className="text-[10px] opacity-75">{c.assetClass}</div>
              <div className="text-sm truncate">{c.id}</div>
              <div className="text-[10px] text-[#C7D2D1] tabular-nums mt-1">£{c.syn}</div>
            </button>
          );
        })}
      </div>

      {/* DETAILED COMMODITY SYNTHESIS PANEL */}
      <div className="bg-[#182C35]/40 border border-[#294A59] p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#294A59]/40 pb-4 font-mono">
          <div>
            <div className="text-xs text-[#727977]">{active.assetClass} SYNTHETIC DERIVATIVE</div>
            <h2 className="text-2xl font-bold text-[#E9E7DF]">{active.name}</h2>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="p-2 bg-[#111313] border border-[#202426]">
              <span className="text-[#727977]">SPOT BENCHMARK: </span>
              <span className="font-bold text-[#E9E7DF] tabular-nums">{active.spot} {active.unit}</span>
            </div>
            <div className="p-2 bg-[#294A59] text-[#E9E7DF]">
              <span className="opacity-75">SYNTHETIC FUTURE: </span>
              <span className="font-bold tabular-nums">{active.syn} {active.unit}</span>
            </div>
          </div>
        </div>

        {/* SPECIALIZED DAIRY COMPONENT SYNTHESIS DIAGRAM */}
        {selectedCommodity === 'DAIRY' && (
          <div className="space-y-4 font-mono text-xs">
            <div className="text-xs font-bold text-[#C7D2D1] uppercase">
              RHINO DAIRY COMPONENT CONVERSION FLOW: RAW MILK → CREAM / BUTTER / SMP
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center text-center">
              <div className="p-4 bg-[#111313] border border-[#202426] space-y-1">
                <div className="text-[10px] text-[#727977]">INPUT 1</div>
                <div className="font-bold text-[#E9E7DF]">RAW MILK</div>
                <div className="text-[#3F7354] tabular-nums">42.5 p/litre</div>
              </div>

              <div className="text-[#727977] font-bold">→</div>

              <div className="p-4 bg-[#111313] border border-[#202426] space-y-1">
                <div className="text-[10px] text-[#727977]">PROCESSING</div>
                <div className="font-bold text-[#E9E7DF]">CREAMERY YIELD</div>
                <div className="text-[#727977]">4.2% Fat / 3.4% Prot</div>
              </div>

              <div className="text-[#727977] font-bold">→</div>

              <div className="p-4 bg-[#294A59]/40 border border-[#294A59] space-y-1">
                <div className="text-[10px] text-[#C7D2D1]">SYNTHETIC FUTURE</div>
                <div className="font-bold text-[#E9E7DF]">BUTTER & SMP</div>
                <div className="text-[#C7D2D1] font-bold tabular-nums">£3,842.00 / tonne</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
