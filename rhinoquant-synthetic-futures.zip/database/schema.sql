-- RHINOQUANT SYNTHETIC FUTURES PLATFORM DATABASE SCHEMA
-- PostgreSQL schema for instruments, curves, vol surfaces, synthetics, portfolios & risk audit

CREATE TABLE IF NOT EXISTS instruments (
    instrument_id VARCHAR(64) PRIMARY KEY,
    symbol VARCHAR(32) UNIQUE NOT NULL,
    name VARCHAR(128) NOT NULL,
    asset_class VARCHAR(32) NOT NULL,
    underlying VARCHAR(32) NOT NULL,
    exchange VARCHAR(32) NOT NULL,
    expiry VARCHAR(10) NOT NULL,
    strike NUMERIC(16, 4),
    option_type VARCHAR(8),
    price_source VARCHAR(32) NOT NULL,
    contract_size NUMERIC(16, 4) NOT NULL,
    currency VARCHAR(8) NOT NULL,
    tick_size NUMERIC(12, 6) NOT NULL,
    tick_value NUMERIC(12, 4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS synthetics (
    synthetic_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    underlying VARCHAR(32) NOT NULL,
    asset_class VARCHAR(32) NOT NULL,
    synthetic_type VARCHAR(48) NOT NULL,
    expiry VARCHAR(10) NOT NULL,
    financing_rate NUMERIC(8, 4) NOT NULL,
    storage_cost NUMERIC(8, 4) NOT NULL,
    convenience_yield NUMERIC(8, 4) NOT NULL,
    transaction_cost NUMERIC(8, 4) NOT NULL,
    slippage NUMERIC(8, 4) NOT NULL,
    observed_future_symbol VARCHAR(32),
    model_id VARCHAR(32) DEFAULT 'RQ-SYN-FUT-001',
    model_version VARCHAR(16) DEFAULT '1.4.2',
    status VARCHAR(16) DEFAULT 'RESEARCH',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS synthetic_legs (
    leg_id SERIAL PRIMARY KEY,
    synthetic_id VARCHAR(64) REFERENCES synthetics(synthetic_id) ON DELETE CASCADE,
    instrument_id VARCHAR(64) REFERENCES instruments(instrument_id),
    leg_type VARCHAR(16) NOT NULL,
    side VARCHAR(8) NOT NULL,
    quantity NUMERIC(12, 4) NOT NULL,
    strike NUMERIC(16, 4),
    entry_price NUMERIC(16, 4) NOT NULL
);

CREATE TABLE IF NOT EXISTS pricing_results (
    calculation_id SERIAL PRIMARY KEY,
    synthetic_id VARCHAR(64) REFERENCES synthetics(synthetic_id),
    fair_value NUMERIC(16, 4) NOT NULL,
    bid NUMERIC(16, 4) NOT NULL,
    ask NUMERIC(16, 4) NOT NULL,
    mid NUMERIC(16, 4) NOT NULL,
    observed_price NUMERIC(16, 4),
    basis NUMERIC(16, 4) NOT NULL,
    basis_vol NUMERIC(8, 4) NOT NULL,
    z_score NUMERIC(8, 4) NOT NULL,
    delta NUMERIC(8, 4) NOT NULL,
    gamma NUMERIC(12, 6) NOT NULL,
    vega NUMERIC(8, 4) NOT NULL,
    theta NUMERIC(8, 4) NOT NULL,
    rho NUMERIC(8, 4) NOT NULL,
    dv01 NUMERIC(8, 4) NOT NULL,
    model_id VARCHAR(32) NOT NULL,
    model_version VARCHAR(16) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS curves (
    curve_id VARCHAR(64) PRIMARY KEY,
    underlying VARCHAR(32) NOT NULL,
    asset_class VARCHAR(32) NOT NULL,
    spot NUMERIC(16, 4) NOT NULL,
    interpolation VARCHAR(32) NOT NULL,
    slope NUMERIC(16, 4) NOT NULL,
    contango_status VARCHAR(16) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS volatility_surfaces (
    surface_id VARCHAR(64) PRIMARY KEY,
    underlying VARCHAR(32) NOT NULL,
    atm_vol NUMERIC(8, 4) NOT NULL,
    vol_25_call NUMERIC(8, 4) NOT NULL,
    vol_25_put NUMERIC(8, 4) NOT NULL,
    skew NUMERIC(8, 4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS portfolios (
    portfolio_id VARCHAR(32) PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    currency VARCHAR(8) DEFAULT 'GBP',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS positions (
    position_id VARCHAR(64) PRIMARY KEY,
    portfolio_id VARCHAR(32) REFERENCES portfolios(portfolio_id),
    instrument_id VARCHAR(64) NOT NULL,
    quantity NUMERIC(16, 4) NOT NULL,
    entry_price NUMERIC(16, 4) NOT NULL,
    market_price NUMERIC(16, 4) NOT NULL,
    synthetic_fair_value NUMERIC(16, 4) NOT NULL,
    is_synthetic_leg BOOLEAN DEFAULT FALSE,
    unrealized_pnl NUMERIC(16, 2) NOT NULL,
    realized_pnl NUMERIC(16, 2) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS margin_results (
    margin_id SERIAL PRIMARY KEY,
    portfolio_id VARCHAR(32) REFERENCES portfolios(portfolio_id),
    initial_margin NUMERIC(16, 2) NOT NULL,
    variation_margin NUMERIC(16, 2) NOT NULL,
    maintenance_margin NUMERIC(16, 2) NOT NULL,
    stress_margin NUMERIC(16, 2) NOT NULL,
    concentration_add_on NUMERIC(16, 2) NOT NULL,
    liquidity_add_on NUMERIC(16, 2) NOT NULL,
    total_required NUMERIC(16, 2) NOT NULL,
    available_collateral NUMERIC(16, 2) NOT NULL,
    surplus_deficit NUMERIC(16, 2) NOT NULL,
    is_breached BOOLEAN DEFAULT FALSE,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_events (
    audit_id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    action VARCHAR(64) NOT NULL,
    entity_type VARCHAR(32) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    inputs JSONB,
    outputs JSONB,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
