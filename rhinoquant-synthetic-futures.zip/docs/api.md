# RHINOQUANT REST & WEBSOCKET API SPECIFICATION

## REST Endpoints

### Instruments
- `GET /api/v1/instruments` — List all market instruments and simulated prices.

### Forward Curves
- `GET /api/v1/curves?underlying=COPPER&spot=10482` — Return forward curve points & contango classification.

### Volatility Surfaces
- `GET /api/v1/volatility?underlying=COPPER` — Return strike x expiry implied volatility matrix and skew.

### Synthetic Futures Construction
- `GET /api/v1/synthetics` — List configured synthetic futures and pricing.
- `POST /api/v1/synthetics` — Create a new synthetic future.
- `GET /api/v1/pricing/{id}` — Get real-time fair value, bid/ask, basis, and Greeks for a synthetic.

### Portfolio & Risk
- `GET /api/v1/portfolio` — Return active positions, notional, P&L, and portfolio Greeks.
- `GET /api/v1/margin` — Return initial, variation, maintenance, and stress margin requirements.
- `POST /api/v1/scenarios/run` — Run stress scenarios (Spot, Vol, Rate, Basis shocks).
- `POST /api/v1/monte-carlo/run` — Run 10,000 path Monte Carlo simulation.

### Quantitative Research (R Interpreter)
- `POST /api/v1/r-research/run` — Execute R scripts and return tidy data frames.

## WebSockets

### Market Ticks
- `ws://<host>/ws/market`
- Emits real-time market ticks every 1.5 seconds:
```json
{
  "type": "MARKET_TICK",
  "timestamp": "2026-09-26 11:04:20",
  "regime": "NORMAL",
  "markets": [...]
}
```
