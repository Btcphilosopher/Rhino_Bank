import React, { useState } from "react";
import {
  FileText,
  Code2,
  GitBranch,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Database,
  Lock,
  Layers,
  ArrowRight,
  HelpCircle,
  Copy,
  Check,
  RefreshCw,
} from "lucide-react";
import { ContractIR, ContractClause, Obligation, ContractStateType } from "../../types/contract-ir";
import { ContractCompiler } from "../../services/compiler";

interface ContractWorkspaceViewProps {
  contract: ContractIR;
  onUpdateContract: (updated: ContractIR) => void;
  onOpenAiForClause: (clause: ContractClause) => void;
}

export const ContractWorkspaceView: React.FC<ContractWorkspaceViewProps> = ({
  contract,
  onUpdateContract,
  onOpenAiForClause,
}) => {
  const [selectedClauseId, setSelectedClauseId] = useState<string>(
    contract.clauses[6]?.id || contract.clauses[0]?.id || "CLAUSE-01"
  );
  const [rightPanelTab, setRightPanelTab] = useState<
    "OBLIGATIONS" | "CONTRACT_IR" | "SOLIDITY" | "STATE_MACHINE" | "PROVENANCE"
  >("SOLIDITY");
  const [copiedCode, setCopiedCode] = useState(false);
  const [analyzingClause, setAnalyzingClause] = useState(false);

  const selectedClause =
    contract.clauses.find((c) => c.id === selectedClauseId) || contract.clauses[0];

  const relatedObligations = contract.obligations.filter((o) =>
    selectedClause?.relatedObligationIds.includes(o.id)
  );

  const ambiguities = ContractCompiler.analyzeAmbiguities(contract);
  const parityStats = ContractCompiler.calculateParity(contract);

  const handleCopyCode = () => {
    if (contract.generated_solidity?.sourceCode) {
      navigator.clipboard.writeText(contract.generated_solidity.sourceCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleAnalyzeClauseAi = async () => {
    if (!selectedClause) return;
    setAnalyzingClause(true);
    try {
      const response = await fetch("/api/ai/analyze-clause", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clauseText: selectedClause.legalText,
          clauseTitle: selectedClause.title,
          contractContext: {
            contractId: contract.contract_id,
            title: contract.title,
            governingLaw: contract.governing_law,
            category: contract.financial_terms.category,
          },
        }),
      });

      if (response.ok) {
        const data = await response.json();
        // Update clause with AI breakdown
        const updatedClauses = contract.clauses.map((c) => {
          if (c.id === selectedClause.id) {
            return {
              ...c,
              formalSummary: data.analysis.formalSummary || c.formalSummary,
              ambiguities: data.analysis.ambiguities || c.ambiguities,
              codeMapping: data.analysis.codeMapping || c.codeMapping,
            };
          }
          return c;
        });
        onUpdateContract({ ...contract, clauses: updatedClauses });
      }
    } catch (e) {
      console.error("Failed to analyze clause", e);
    } finally {
      setAnalyzingClause(false);
    }
  };

  return (
    <div className="h-[calc(100vh-80px)] flex flex-col bg-[#0b0e14] text-slate-200">
      {/* Contract Context Header */}
      <div className="bg-[#10141f] border-b border-[#1e2638] px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="px-2 py-1 bg-indigo-950/70 border border-indigo-500/40 rounded font-mono text-xs text-indigo-300 font-semibold">
            {contract.contract_id}
          </div>
          <div>
            <h1 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
              {contract.title}
              <span className="text-xs font-mono font-normal text-slate-400">
                v{contract.version}
              </span>
            </h1>
            <div className="flex items-center gap-3 text-[11px] text-slate-400 font-sans">
              <span>
                <strong className="text-slate-300">Law:</strong> {contract.governing_law}
              </span>
              <span>•</span>
              <span>
                <strong className="text-slate-300">Forum:</strong> {contract.dispute_forum}
              </span>
              <span>•</span>
              <span>
                <strong className="text-slate-300">Category:</strong>{" "}
                {contract.financial_terms.category}
              </span>
            </div>
          </div>
        </div>

        {/* Parity & State Badges */}
        <div className="flex items-center gap-3">
          {/* Current State Indicator */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#161c2c] border border-[#263147] text-xs font-mono">
            <span className="text-slate-400 text-[10px]">STATE:</span>
            <span className="text-emerald-400 font-bold">{contract.currentState}</span>
          </div>

          {/* Parity Score */}
          <div className="flex items-center gap-2 px-3 py-1 bg-[#161c2c] border border-[#263147] rounded text-xs font-mono">
            <span className="text-slate-400">PARITY:</span>
            <span className="text-indigo-300 font-bold">
              {parityStats.parityPercentage}% MAPPED
            </span>
            <span className="text-[10px] text-slate-400">
              ({parityStats.verifiedCount}/{parityStats.legalObligationsCount} verified)
            </span>
          </div>

          {/* Legal Review Required Stamp */}
          {contract.legalReviewRequired && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-950/50 border border-amber-600/40 text-amber-300 rounded text-xs font-mono font-bold animate-pulse">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>LEGAL REVIEW REQUIRED</span>
            </div>
          )}
        </div>
      </div>

      {/* Main 3-Column Workspace */}
      <div className="flex-1 grid grid-cols-12 divide-x divide-[#1e2638] overflow-hidden">
        {/* ================= COLUMN 1: STRUCTURE (3 Cols) ================= */}
        <div className="col-span-3 bg-[#0d1018] flex flex-col h-full overflow-hidden">
          <div className="p-3 border-b border-[#1e2638] flex items-center justify-between bg-[#10141f]">
            <div className="flex items-center gap-1.5 text-xs font-mono font-semibold text-slate-300">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              <span>CONTRACT STRUCTURE</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">
              {contract.clauses.length} CLAUSES
            </span>
          </div>

          {/* Clauses List */}
          <div className="flex-1 overflow-y-auto divide-y divide-[#171d2c] text-xs font-sans">
            {contract.clauses.map((clause) => {
              const isSelected = clause.id === selectedClauseId;
              const hasAmbiguity = clause.ambiguities && clause.ambiguities.length > 0;
              const hasObligation = clause.relatedObligationIds.length > 0;

              return (
                <div
                  key={clause.id}
                  onClick={() => setSelectedClauseId(clause.id)}
                  className={`p-3 cursor-pointer transition-colors flex items-start gap-2.5 ${
                    isSelected
                      ? "bg-[#182030] border-l-2 border-indigo-400 text-white"
                      : "hover:bg-[#121622] text-slate-300"
                  }`}
                >
                  <span className="font-mono text-[11px] text-slate-400 mt-0.5">
                    {clause.sectionNumber}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h3 className="font-semibold truncate text-xs">{clause.title}</h3>
                      {clause.isOperative && (
                        <span className="text-[9px] px-1 py-0.2 rounded bg-indigo-950/80 border border-indigo-500/30 text-indigo-300 font-mono">
                          EXEC
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                      {clause.formalSummary || clause.legalText}
                    </p>

                    {/* Status & Ambiguity Tags */}
                    <div className="flex items-center gap-2 mt-1.5 font-mono text-[10px]">
                      <span
                        className={`flex items-center gap-0.5 ${
                          clause.status === "APPROVED"
                            ? "text-emerald-400"
                            : clause.status === "REQUIRES_REVIEW"
                            ? "text-amber-400"
                            : "text-slate-400"
                        }`}
                      >
                        <CheckCircle2 className="w-2.5 h-2.5" />
                        <span>{clause.status}</span>
                      </span>

                      {hasAmbiguity && (
                        <span className="text-amber-400 bg-amber-950/40 px-1 rounded border border-amber-600/30 flex items-center gap-0.5">
                          <AlertTriangle className="w-2.5 h-2.5" />
                          <span>{clause.ambiguities.length} AMB</span>
                        </span>
                      )}

                      {hasObligation && (
                        <span className="text-slate-400">
                          {clause.relatedObligationIds.length} Obligation
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom Summary Pill */}
          <div className="p-2.5 bg-[#0f131d] border-t border-[#1e2638] text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>Parties: {contract.parties.length}</span>
            <span>Defs: {contract.definitions.length}</span>
            <span>Invariants: {contract.invariants.length}</span>
          </div>
        </div>

        {/* ================= COLUMN 2: LEGAL TEXT & CLAUSE EDITOR (5 Cols) ================= */}
        <div className="col-span-5 bg-[#0c0f17] flex flex-col h-full overflow-hidden">
          {selectedClause ? (
            <>
              {/* Clause Header */}
              <div className="p-3 border-b border-[#1e2638] bg-[#101420] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-[#1a2133] text-indigo-300 font-bold">
                    Section {selectedClause.sectionNumber}
                  </span>
                  <h2 className="text-sm font-semibold text-white truncate max-w-xs">
                    {selectedClause.title}
                  </h2>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleAnalyzeClauseAi}
                    disabled={analyzingClause}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-indigo-900/60 hover:bg-indigo-800/80 border border-indigo-500/40 text-indigo-300 text-xs font-medium transition-colors"
                  >
                    {analyzingClause ? (
                      <RefreshCw className="w-3 h-3 animate-spin text-indigo-400" />
                    ) : (
                      <Sparkles className="w-3 h-3 text-indigo-400" />
                    )}
                    <span>{analyzingClause ? "Analyzing..." : "Analyze with AI"}</span>
                  </button>
                </div>
              </div>

              {/* Legal Text Body */}
              <div className="flex-1 p-5 overflow-y-auto space-y-4">
                {/* Authoritative Legal Language */}
                <div className="bg-[#121622] p-4 rounded border border-[#20293d] shadow-sm">
                  <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
                    <span>Authoritative Legal Text (Source of Truth)</span>
                    <span className="text-emerald-400 font-normal">English Law Construction</span>
                  </div>
                  <div className="font-serif text-sm leading-relaxed text-slate-200 border-l-2 border-indigo-500/50 pl-3.5 py-1 selection:bg-indigo-900 selection:text-white">
                    {selectedClause.legalText}
                  </div>
                </div>

                {/* Ambiguity & Legal Review Warnings */}
                {selectedClause.ambiguities && selectedClause.ambiguities.length > 0 && (
                  <div className="bg-amber-950/30 border border-amber-600/40 rounded p-3 text-xs space-y-2">
                    <div className="flex items-center gap-1.5 text-amber-300 font-mono font-semibold">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      <span>Potential Legal Ambiguity Detected</span>
                    </div>
                    {selectedClause.ambiguities.map((amb, i) => (
                      <div key={i} className="text-slate-300 pl-4 border-l border-amber-600/40 py-0.5">
                        <p>{amb}</p>
                        <div className="mt-1 flex items-center gap-2">
                          <button
                            onClick={() => onOpenAiForClause(selectedClause)}
                            className="text-indigo-300 hover:text-indigo-200 underline font-mono text-[11px]"
                          >
                            Resolve Ambiguity with Assistant →
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Structured Formal Logic Breakdown */}
                <div className="bg-[#10141f] rounded border border-[#1e2638] p-3 text-xs space-y-2">
                  <div className="flex items-center justify-between font-mono text-[11px] text-slate-300">
                    <span className="font-semibold flex items-center gap-1">
                      <FileText className="w-3 h-3 text-indigo-400" />
                      FORMAL CLAUSE IR MAPPING
                    </span>
                    <span className="text-[10px] text-slate-400">Clause Ref: {selectedClause.id}</span>
                  </div>

                  <div className="text-slate-300 text-xs font-sans leading-relaxed">
                    <strong className="text-slate-400">Formal Summary: </strong>
                    {selectedClause.formalSummary || "No formal summary mapped yet."}
                  </div>

                  {selectedClause.codeMapping && (
                    <div className="bg-[#0b0e14] p-2.5 rounded border border-[#1c2333] font-mono text-xs space-y-1">
                      <div className="text-[10px] text-indigo-400 font-bold">
                        EXECUTABLE SOLIDITY FUNCTION:
                      </div>
                      <div className="text-slate-200">{selectedClause.codeMapping.functionName}</div>
                      <div className="text-[11px] text-slate-400 font-sans">
                        {selectedClause.codeMapping.solidityLines}
                      </div>
                    </div>
                  )}
                </div>

                {/* Related Obligations linked to this clause */}
                <div className="space-y-2">
                  <div className="text-xs font-mono font-semibold text-slate-300 flex items-center gap-1.5">
                    <Layers className="w-3 h-3 text-indigo-400" />
                    <span>LINKED FIRST-CLASS OBLIGATIONS ({relatedObligations.length})</span>
                  </div>

                  {relatedObligations.length === 0 ? (
                    <div className="text-xs text-slate-400 font-sans italic bg-[#10141f] p-3 rounded border border-[#1e2638]">
                      This clause establishes legal framework definitions or general recitals with no direct state-modifying smart contract obligations.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {relatedObligations.map((obl) => (
                        <div
                          key={obl.id}
                          className="bg-[#121622] p-3 rounded border border-[#20293d] text-xs space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <span className="px-1.5 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300 font-mono text-[10px] font-bold">
                              {obl.type}: {obl.action}
                            </span>
                            <span className="font-mono text-[10px] text-emerald-400 flex items-center gap-1">
                              <CheckCircle2 className="w-2.5 h-2.5" />
                              {obl.verificationStatus}
                            </span>
                          </div>

                          <p className="text-slate-300 font-sans">{obl.objectDescription}</p>

                          <div className="bg-[#0a0d13] p-2 rounded border border-[#181f2f] font-mono text-[11px] text-indigo-300">
                            <span className="text-slate-400">Formal Invariant: </span>
                            {obl.formalLogic}
                          </div>

                          {obl.executionFunction && (
                            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1 border-t border-[#1c2333]">
                              <span>Function: {obl.executionFunction}</span>
                              <span>Auto-Executable: {obl.isAutomated ? "Yes" : "Human Gated"}</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-400 text-xs">
              Select a clause from the structure tree to inspect authoritative legal language.
            </div>
          )}
        </div>

        {/* ================= COLUMN 3: EXECUTABLE REPRESENTATION (4 Cols) ================= */}
        <div className="col-span-4 bg-[#0a0d14] flex flex-col h-full overflow-hidden">
          {/* Tabs Bar */}
          <div className="p-1.5 border-b border-[#1e2638] bg-[#0e121b] flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setRightPanelTab("SOLIDITY")}
                className={`px-2.5 py-1 rounded transition-colors ${
                  rightPanelTab === "SOLIDITY"
                    ? "bg-[#1b2336] text-white font-semibold shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Solidity (.sol)
              </button>
              <button
                onClick={() => setRightPanelTab("CONTRACT_IR")}
                className={`px-2.5 py-1 rounded transition-colors ${
                  rightPanelTab === "CONTRACT_IR"
                    ? "bg-[#1b2336] text-white font-semibold shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Contract IR
              </button>
              <button
                onClick={() => setRightPanelTab("STATE_MACHINE")}
                className={`px-2.5 py-1 rounded transition-colors ${
                  rightPanelTab === "STATE_MACHINE"
                    ? "bg-[#1b2336] text-white font-semibold shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                State Machine
              </button>
              <button
                onClick={() => setRightPanelTab("PROVENANCE")}
                className={`px-2.5 py-1 rounded transition-colors ${
                  rightPanelTab === "PROVENANCE"
                    ? "bg-[#1b2336] text-white font-semibold shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Trace
              </button>
            </div>

            {rightPanelTab === "SOLIDITY" && (
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1 text-[11px] text-indigo-300 hover:text-indigo-200 px-2 py-0.5 rounded bg-indigo-950/60 border border-indigo-500/30"
              >
                {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCode ? "Copied" : "Copy"}</span>
              </button>
            )}
          </div>

          {/* Right Panel Content */}
          <div className="flex-1 overflow-y-auto p-3">
            {/* TAB: SOLIDITY CODE */}
            {rightPanelTab === "SOLIDITY" && (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 bg-[#121622] px-3 py-1.5 rounded border border-[#20293d]">
                  <span>Target: EVM 0.8.28</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> Security Gate: PASSED
                  </span>
                </div>

                <div className="bg-[#06080d] p-3.5 rounded border border-[#1a2133] font-mono text-[11px] leading-relaxed text-slate-300 overflow-x-auto selection:bg-indigo-900">
                  <pre className="text-slate-300 whitespace-pre">
                    {contract.generated_solidity?.sourceCode || ContractCompiler.generateSolidity(contract)}
                  </pre>
                </div>
              </div>
            )}

            {/* TAB: CONTRACT IR (JSON AST) */}
            {rightPanelTab === "CONTRACT_IR" && (
              <div className="space-y-2">
                <div className="text-[11px] font-mono text-slate-400 bg-[#121622] px-3 py-1.5 rounded border border-[#20293d] flex items-center justify-between">
                  <span>LEXEXEC Formal Intermediate Representation (IR)</span>
                  <span className="text-indigo-400 font-bold">JSON AST</span>
                </div>
                <div className="bg-[#06080d] p-3 rounded border border-[#1a2133] font-mono text-[10.5px] leading-snug text-slate-300 overflow-x-auto">
                  <pre>{JSON.stringify(contract, null, 2)}</pre>
                </div>
              </div>
            )}

            {/* TAB: STATE MACHINE */}
            {rightPanelTab === "STATE_MACHINE" && (
              <div className="space-y-4 text-xs">
                <div className="text-[11px] font-mono text-slate-300 bg-[#121622] p-2.5 rounded border border-[#20293d]">
                  <span className="font-semibold text-white">Explicit Finite State Machine:</span>
                  <p className="text-[11px] text-slate-400 mt-1">
                    All legal transitions are mathematically deterministic with explicit trigger events and preconditions.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                    Permitted Transitions
                  </div>
                  {contract.state_machine.transitions.map((t) => (
                    <div
                      key={t.id}
                      className="bg-[#121622] p-3 rounded border border-[#20293d] space-y-1.5"
                    >
                      <div className="flex items-center gap-2 font-mono text-xs font-semibold">
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                          {t.fromState}
                        </span>
                        <ArrowRight className="w-3 h-3 text-indigo-400" />
                        <span className="px-1.5 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300 text-[10px]">
                          {t.toState}
                        </span>
                      </div>
                      <div className="text-slate-300 font-sans text-xs">
                        <strong>Trigger:</strong> {t.triggerEvent}
                      </div>
                      <div className="text-slate-400 font-sans text-[11px]">
                        <strong>Condition:</strong> {t.condition}
                      </div>
                      <div className="font-mono text-[10px] text-emerald-400 bg-[#0c0f16] p-1.5 rounded border border-[#192233]">
                        Consequence: {t.executableConsequence}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: PROVENANCE */}
            {rightPanelTab === "PROVENANCE" && (
              <div className="space-y-3 text-xs">
                <div className="bg-[#121622] p-2.5 rounded border border-[#20293d] text-[11px] font-mono text-slate-300">
                  <span className="font-bold text-white">Bidirectional Legal Provenance Matrix:</span>
                  <p className="text-slate-400 mt-0.5">
                    Every Solidity function links to a formal Obligation ID, which resolves to an authoritative Legal Clause.
                  </p>
                </div>

                <div className="space-y-2">
                  {contract.obligations.map((obl) => (
                    <div
                      key={obl.id}
                      className="bg-[#10141f] p-3 rounded border border-[#1e2638] font-mono text-xs space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-indigo-300 font-bold">
                        <span>{obl.id}</span>
                        <span className="text-[10px] text-slate-400">{obl.clauseRef}</span>
                      </div>
                      <div className="text-slate-300 font-sans text-xs">{obl.objectDescription}</div>
                      <div className="text-emerald-400 text-[11px]">
                        Solidity: {obl.executionFunction || "Gated via Agent"}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Formal Logic: {obl.formalLogic}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
