import React, { useState } from "react";
import {
  X,
  Sparkles,
  Terminal,
  Send,
  HelpCircle,
  FileText,
  Code2,
  AlertTriangle,
  RotateCw,
  CheckCircle2,
} from "lucide-react";
import { ContractIR, ContractClause } from "../../types/contract-ir";

interface AiAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  contract: ContractIR;
  targetClause?: ContractClause | null;
}

export const AiAssistantDrawer: React.FC<AiAssistantDrawerProps> = ({
  isOpen,
  onClose,
  contract,
  targetClause,
}) => {
  const [queryMode, setQueryMode] = useState<
    "WHAT_HAPPENS_IF" | "WHY_DOES_CODE_EXIST" | "REVERSE_TRANSLATE" | "AMBIGUITY_FIX"
  >("WHAT_HAPPENS_IF");
  const [promptInput, setPromptInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleRunAiQuery = async (overridePrompt?: string) => {
    const textToSend = overridePrompt || promptInput;
    if (!textToSend && queryMode === "WHAT_HAPPENS_IF") return;

    setIsLoading(true);
    setAiResponse(null);

    try {
      const res = await fetch("/api/ai/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          queryType: queryMode,
          userPrompt: textToSend,
          contractContext: {
            contractId: contract.contract_id,
            title: contract.title,
            governingLaw: contract.governing_law,
            clauseText: targetClause?.legalText,
            clauseTitle: targetClause?.title,
            notional: contract.financial_terms.notional,
            currency: contract.financial_terms.currency,
          },
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setAiResponse(data.answer);
      } else {
        setAiResponse("Legal Intelligence Engine response timed out. Please retry.");
      }
    } catch (e) {
      setAiResponse("Unable to communicate with the LEXEXEC AI Reasoning service.");
    } finally {
      setIsLoading(false);
    }
  };

  const presetQueries = [
    {
      title: "What happens if borrower fails to pay on 10 Dec 2026?",
      mode: "WHAT_HAPPENS_IF" as const,
      prompt: "What happens if the borrower fails to make the quarterly interest payment on 10 December 2026?",
    },
    {
      title: "Why does require(soniaRateBps <= 3000) exist?",
      mode: "WHY_DOES_CODE_EXIST" as const,
      prompt: "Why does the smart contract enforce require(soniaRateBps <= 3000)? Which legal clause or security invariant justifies this?",
    },
    {
      title: "How is the 3-day grace period legally constructed?",
      mode: "WHAT_HAPPENS_IF" as const,
      prompt: "How is the 3-day grace period in Clause 10 constructed? Does it count calendar days or London Business Days?",
    },
    {
      title: "Explain the acceleration remedy in plain English",
      mode: "REVERSE_TRANSLATE" as const,
      prompt: "Explain the legal acceleration remedy in Clause 11 and how the smart contract executes it.",
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-xl bg-[#0e121b] border-l border-[#20283d] h-full flex flex-col text-slate-200 shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-[#20283d] flex items-center justify-between bg-[#121624]">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-indigo-950/80 border border-indigo-500/40 rounded">
              <Sparkles className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h2 className="font-mono text-sm font-semibold text-white">
                LEXEXEC LEGAL INTELLIGENCE ASSISTANT
              </h2>
              <p className="text-[11px] text-slate-400">
                Grounded in {contract.title} ({contract.governing_law})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Query Mode Buttons */}
        <div className="p-3 bg-[#0a0d14] border-b border-[#1a2133] grid grid-cols-3 gap-2 text-xs font-mono">
          <button
            onClick={() => {
              setQueryMode("WHAT_HAPPENS_IF");
              setAiResponse(null);
            }}
            className={`py-1.5 px-2 rounded text-center transition-colors ${
              queryMode === "WHAT_HAPPENS_IF"
                ? "bg-indigo-600 text-white font-bold"
                : "bg-[#141a29] text-slate-400 hover:text-slate-200"
            }`}
          >
            What Happens If...?
          </button>
          <button
            onClick={() => {
              setQueryMode("WHY_DOES_CODE_EXIST");
              setAiResponse(null);
            }}
            className={`py-1.5 px-2 rounded text-center transition-colors ${
              queryMode === "WHY_DOES_CODE_EXIST"
                ? "bg-indigo-600 text-white font-bold"
                : "bg-[#141a29] text-slate-400 hover:text-slate-200"
            }`}
          >
            Why Does Code Exist?
          </button>
          <button
            onClick={() => {
              setQueryMode("REVERSE_TRANSLATE");
              setAiResponse(null);
            }}
            className={`py-1.5 px-2 rounded text-center transition-colors ${
              queryMode === "REVERSE_TRANSLATE"
                ? "bg-indigo-600 text-white font-bold"
                : "bg-[#141a29] text-slate-400 hover:text-slate-200"
            }`}
          >
            Legal Translation
          </button>
        </div>

        {/* Body / Chat Area */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs font-sans">
          {/* Target Clause Context Notice */}
          {targetClause && (
            <div className="bg-[#141926] p-3 rounded border border-[#232d45] space-y-1">
              <span className="font-mono text-[10px] text-indigo-400 font-bold">FOCUSED CLAUSE CONTEXT:</span>
              <div className="font-semibold text-white text-xs">{targetClause.title} ({targetClause.id})</div>
              <div className="font-serif text-[11px] text-slate-300 italic line-clamp-2">
                "{targetClause.legalText}"
              </div>
            </div>
          )}

          {/* Preset Questions */}
          <div className="space-y-2">
            <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">
              Recommended Legal & Execution Inquiries
            </div>
            <div className="grid grid-cols-1 gap-1.5 font-mono text-xs">
              {presetQueries.map((pq, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setQueryMode(pq.mode);
                    setPromptInput(pq.prompt);
                    handleRunAiQuery(pq.prompt);
                  }}
                  className="p-2.5 rounded bg-[#121622] hover:bg-[#182030] border border-[#20293d] text-left text-slate-300 hover:text-white transition-colors flex items-center justify-between"
                >
                  <span className="truncate">{pq.title}</span>
                  <span className="text-indigo-400 text-xs">→</span>
                </button>
              ))}
            </div>
          </div>

          {/* AI Response Box */}
          {isLoading && (
            <div className="bg-[#121724] p-4 rounded border border-[#222c42] flex items-center gap-3 text-indigo-300 font-mono text-xs">
              <RotateCw className="w-4 h-4 animate-spin text-indigo-400" />
              <span>Analyzing contract AST, state transitions, and legal construction...</span>
            </div>
          )}

          {aiResponse && (
            <div className="bg-[#111726] p-4 rounded border border-indigo-500/40 space-y-2">
              <div className="flex items-center gap-1.5 text-indigo-400 font-mono font-bold text-xs">
                <Sparkles className="w-3.5 h-3.5" />
                <span>LEXEXEC Formal Reasoning Output:</span>
              </div>
              <div className="text-slate-200 text-xs leading-relaxed whitespace-pre-wrap font-sans">
                {aiResponse}
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-3 bg-[#101420] border-t border-[#20283d] flex items-center gap-2">
          <input
            type="text"
            placeholder={
              queryMode === "WHAT_HAPPENS_IF"
                ? "Ask a scenario: e.g. What if interest rate spikes by 400bps?"
                : "Ask about code provenance or legal construction..."
            }
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleRunAiQuery()}
            className="flex-1 bg-[#090b10] border border-[#1f283d] rounded px-3 py-2 text-xs text-slate-200 outline-none placeholder:text-slate-500 font-sans"
          />
          <button
            onClick={() => handleRunAiQuery()}
            disabled={isLoading || !promptInput.trim()}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-950 text-white rounded font-mono text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Analyze</span>
          </button>
        </div>
      </div>
    </div>
  );
};
