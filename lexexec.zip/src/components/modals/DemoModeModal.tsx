import React, { useState } from "react";
import {
  X,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  FileText,
  Code2,
  Cpu,
  TrendingUp,
  ShieldCheck,
  Scale,
  PlayCircle,
} from "lucide-react";
import { AppView } from "../../types";

interface DemoModeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToView: (view: AppView) => void;
}

export const DemoModeModal: React.FC<DemoModeModalProps> = ({
  isOpen,
  onClose,
  onNavigateToView,
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const steps = [
    {
      title: "1. Legal Layer & Standard Contract Architecture",
      subtitle: "Authoritative English Legal Construction",
      icon: <FileText className="w-6 h-6 text-indigo-400" />,
      description: "LEXEXEC structures raw commercial agreements into 15 standard clauses (Parties, Definitions, Covenants, Conditions Precedent, Interest, Default, Remedies, Governing Law). Legal text remains the authoritative source of truth.",
      keyInsight: "Never assume CODE = CONTRACT. Legal review checkpoints are mandatory.",
      targetView: "WORKSPACE" as AppView,
    },
    {
      title: "2. Logical Layer & Formal Contract IR (AST)",
      subtitle: "Mathematical Intermediate Representation",
      icon: <Cpu className="w-6 h-6 text-purple-400" />,
      description: "Extracts defined terms, financial parameters, and first-class obligations into a machine-readable JSON AST Intermediate Representation, with explicit finite state machines.",
      keyInsight: "Every financial term and state transition is strictly typed and deterministic.",
      targetView: "WORKSPACE" as AppView,
    },
    {
      title: "3. Legal ↔ Code Parity & Human/Machine Matrix",
      subtitle: "Guaranteed Obligation Accounting",
      icon: <Scale className="w-6 h-6 text-emerald-400" />,
      description: "Displays complete parity between legal obligations and executable functions. Unmapped provisions (such as accounting audits) are explicitly flagged with governance justifications.",
      keyInsight: "41 mapped executable rules, 1 explicitly unmapped accounting covenant.",
      targetView: "RULES" as AppView,
    },
    {
      title: "4. SMT Solver & Formal Verification",
      subtitle: "Z3 Bounded Model Checking",
      icon: <ShieldCheck className="w-6 h-6 text-teal-400" />,
      description: "Proves mathematical invariants (non-negative principal, single settlement path, bounded oracle rates) before any smart contract compilation or deployment.",
      keyInsight: "5 out of 5 formal invariants verified inductive by Z3 SMT solver.",
      targetView: "VERIFICATION" as AppView,
    },
    {
      title: "5. Financial Contract Simulation Sandbox",
      subtitle: "Stress-Testing Market Rates & Default Cascades",
      icon: <PlayCircle className="w-6 h-6 text-amber-400" />,
      description: "Test the contract against live SONIA shocks, Gilt collateral drops, 3-day grace period timeouts, and acceleration remedies with transparent calculation receipts.",
      keyInsight: "Interactive timeline scrubber, margin deficit alerts, and cash flow schedules.",
      targetView: "SIMULATION" as AppView,
    },
    {
      title: "6. Multi-Sig On-Chain Deployment & Execution",
      subtitle: "Tamper-Evident Merkle Audit Trail",
      icon: <Code2 className="w-6 h-6 text-sky-400" />,
      description: "Compile verified Solidity 0.8.28 bytecode, gather multi-sig legal & compliance signatures, and log every lifecycle payment to an immutable cryptographic audit chain.",
      keyInsight: "Full institutional transparency with real-time settlement receipts.",
      targetView: "DEPLOYMENTS" as AppView,
    },
  ];

  const currentStepData = steps[currentStep];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  const handleGoToView = () => {
    onNavigateToView(currentStepData.targetView);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="w-full max-w-2xl bg-[#0e121b] border border-[#232c42] rounded-lg shadow-2xl overflow-hidden text-slate-200">
        {/* Header */}
        <div className="p-4 bg-[#121624] border-b border-[#20283d] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-amber-950/80 border border-amber-600/40 rounded">
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            </div>
            <div>
              <h2 className="font-mono text-sm font-semibold text-white">
                LEXEXEC PLATFORM ARCHITECTURE DEMONSTRATION
              </h2>
              <p className="text-[11px] text-slate-400">
                Stage {currentStep + 1} of {steps.length} — Institutional Legal-Tech Walkthrough
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Content */}
        <div className="p-6 space-y-5">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-[#151c2c] rounded-lg border border-[#232f4a] flex-shrink-0">
              {currentStepData.icon}
            </div>
            <div className="space-y-1">
              <span className="font-mono text-xs text-indigo-400 font-bold uppercase">
                {currentStepData.subtitle}
              </span>
              <h3 className="text-base font-bold text-white">{currentStepData.title}</h3>
              <p className="text-xs text-slate-300 font-sans leading-relaxed pt-1">
                {currentStepData.description}
              </p>
            </div>
          </div>

          <div className="bg-[#121724] p-3.5 rounded border border-indigo-500/40 font-mono text-xs space-y-1">
            <div className="text-[10px] text-indigo-400 font-bold uppercase">CORE ARCHITECTURAL PRINCIPLE:</div>
            <div className="text-slate-200">{currentStepData.keyInsight}</div>
          </div>

          {/* Stepper Dots */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-1.5">
              {steps.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentStep(i)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    i === currentStep
                      ? "bg-indigo-400 w-6"
                      : i < currentStep
                      ? "bg-emerald-400"
                      : "bg-slate-700"
                  }`}
                />
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleGoToView}
                className="px-3 py-1.5 bg-[#141a29] hover:bg-[#1a2236] border border-[#232d45] text-indigo-300 rounded font-mono text-xs transition-colors"
              >
                Inspect in {currentStepData.targetView}
              </button>

              <button
                onClick={handleNext}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-mono text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <span>{currentStep === steps.length - 1 ? "Complete Walkthrough" : "Next Stage"}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
