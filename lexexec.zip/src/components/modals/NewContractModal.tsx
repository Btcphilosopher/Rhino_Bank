import React, { useState } from "react";
import {
  X,
  Sparkles,
  ArrowRight,
  Building,
  Coins,
  Scale,
  Calendar,
  Layers,
  FileText,
  RotateCw,
} from "lucide-react";
import { FinancialContractCategory, ContractIR } from "../../types/contract-ir";
import { SEED_CONTRACTS } from "../../data/seedContracts";

interface NewContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateContract: (newContract: ContractIR) => void;
}

export const NewContractModal: React.FC<NewContractModalProps> = ({
  isOpen,
  onClose,
  onCreateContract,
}) => {
  const [naturalLanguagePrompt, setNaturalLanguagePrompt] = useState(
    "Draft a £15,000,000 renewable energy term loan facility under English law between Apex Meridian and Caledonian Institutional Capital, priced at SONIA + 2.00% with quarterly interest payments and bullet maturity in 2029."
  );
  const [category, setCategory] = useState<FinancialContractCategory>("LOAN");
  const [title, setTitle] = useState("£15,000,000 Clean Grid Term Loan Facility");
  const [notional, setNotional] = useState(15000000);
  const [currency, setCurrency] = useState("GBP");
  const [rateType, setRateType] = useState<"FLOATING" | "FIXED">("FLOATING");
  const [spreadBps, setSpreadBps] = useState(200);
  const [fixedRate, setFixedRate] = useState(6.5);
  const [governingLaw, setGoverningLaw] = useState("England and Wales");
  const [disputeForum, setDisputeForum] = useState("High Court of Justice (Commercial Court), London");
  const [dayCount, setDayCount] = useState<"ACT/365F" | "ACT/360" | "30/360">("ACT/365F");
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const handleGenerateContract = async () => {
    setIsGenerating(true);

    // Simulate synthesis & compilation into full Contract IR
    setTimeout(() => {
      const templateBaseline = SEED_CONTRACTS[0]; // Clone Loan archetype
      const newContractId = `LEX-2026-000${Math.floor(200 + Math.random() * 800)}`;

      const newContract: ContractIR = {
        ...templateBaseline,
        contract_id: newContractId,
        title: title || `${currency} ${notional.toLocaleString()} Facility Agreement`,
        version: "1.0.0",
        governing_law: governingLaw,
        dispute_forum: disputeForum,
        currentState: "DRAFT",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        financial_terms: {
          ...templateBaseline.financial_terms,
          category,
          notional,
          currency,
          spreadBps: rateType === "FLOATING" ? spreadBps : 0,
          fixedRatePercent: rateType === "FIXED" ? fixedRate : undefined,
          referenceRateName: rateType === "FLOATING" ? "SONIA" : undefined,
          dayCountConvention: dayCount,
        },
      };

      setIsGenerating(false);
      onCreateContract(newContract);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="w-full max-w-3xl bg-[#0e121b] border border-[#232c42] rounded-lg shadow-2xl overflow-hidden text-slate-200">
        {/* Header */}
        <div className="p-4 bg-[#121624] border-b border-[#20283d] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-indigo-950/80 border border-indigo-500/40 rounded">
              <Sparkles className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h2 className="font-mono text-sm font-semibold text-white">
                NATURAL LANGUAGE CONTRACT BUILDER & IR COMPILER
              </h2>
              <p className="text-[11px] text-slate-400">
                Synthesize structured legal clauses, defined terms, and executable rules from deal parameters
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {/* Natural Language Prompt Box */}
          <div className="space-y-1.5">
            <label className="font-mono text-xs font-semibold text-indigo-300 flex items-center justify-between">
              <span>Natural Language Commercial Intent (Prompt)</span>
              <span className="text-[10px] text-slate-400 font-normal">AI Legal Parsing</span>
            </label>
            <textarea
              rows={3}
              value={naturalLanguagePrompt}
              onChange={(e) => setNaturalLanguagePrompt(e.target.value)}
              className="w-full bg-[#090b10] border border-[#1f283d] rounded p-3 text-xs text-slate-200 outline-none focus:border-indigo-500 font-sans"
              placeholder="Describe parties, notional, pricing, covenants, and maturity..."
            />
          </div>

          {/* Structured Parameter Fields */}
          <div className="grid grid-cols-3 gap-4 text-xs font-mono">
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">CONTRACT CATEGORY</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as FinancialContractCategory)}
                className="w-full bg-[#090b10] border border-[#1f283d] rounded p-2 text-slate-200 outline-none"
              >
                <option value="LOAN">Commercial Term Loan</option>
                <option value="REPO">Repurchase Agreement (Repo)</option>
                <option value="BOND">Corporate Bond Indenture</option>
                <option value="INTEREST_RATE_SWAP">ISDA Interest Rate Swap</option>
                <option value="ESCROW">Commercial Escrow</option>
                <option value="TRADE_FINANCE">Letter of Credit (Trade)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">PRINCIPAL / NOTIONAL</label>
              <div className="flex">
                <input
                  type="number"
                  value={notional}
                  onChange={(e) => setNotional(parseFloat(e.target.value))}
                  className="w-full bg-[#090b10] border border-[#1f283d] rounded p-2 text-slate-200 outline-none"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">CURRENCY</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full bg-[#090b10] border border-[#1f283d] rounded p-2 text-slate-200 outline-none"
              >
                <option value="GBP">GBP (£)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="CHF">CHF</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">PRICING STRUCTURE</label>
              <div className="flex gap-2">
                <button
                  onClick={() => setRateType("FLOATING")}
                  className={`flex-1 py-1.5 rounded border text-center ${
                    rateType === "FLOATING"
                      ? "bg-indigo-600 text-white border-indigo-500 font-bold"
                      : "bg-[#090b10] text-slate-400 border-[#1f283d]"
                  }`}
                >
                  SONIA + Margin
                </button>
                <button
                  onClick={() => setRateType("FIXED")}
                  className={`flex-1 py-1.5 rounded border text-center ${
                    rateType === "FIXED"
                      ? "bg-indigo-600 text-white border-indigo-500 font-bold"
                      : "bg-[#090b10] text-slate-400 border-[#1f283d]"
                  }`}
                >
                  Fixed Rate
                </button>
              </div>
            </div>

            {rateType === "FLOATING" ? (
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">MARGIN SPREAD (BPS)</label>
                <input
                  type="number"
                  value={spreadBps}
                  onChange={(e) => setSpreadBps(parseInt(e.target.value))}
                  className="w-full bg-[#090b10] border border-[#1f283d] rounded p-2 text-slate-200 outline-none"
                  placeholder="200 (= 2.00%)"
                />
              </div>
            ) : (
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">FIXED COUPON (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={fixedRate}
                  onChange={(e) => setFixedRate(parseFloat(e.target.value))}
                  className="w-full bg-[#090b10] border border-[#1f283d] rounded p-2 text-slate-200 outline-none"
                />
              </div>
            )}

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">DAY COUNT CONVENTION</label>
              <select
                value={dayCount}
                onChange={(e) => setDayCount(e.target.value as any)}
                className="w-full bg-[#090b10] border border-[#1f283d] rounded p-2 text-slate-200 outline-none"
              >
                <option value="ACT/365F">ACT/365F (Sterling Standard)</option>
                <option value="ACT/360">ACT/360 (Money Market)</option>
                <option value="30/360">30/360 (Bond ICMA)</option>
              </select>
            </div>

            <div className="space-y-1 col-span-2">
              <label className="text-slate-400 text-[11px]">GOVERNING LAW & JURISDICTION</label>
              <input
                type="text"
                value={governingLaw}
                onChange={(e) => setGoverningLaw(e.target.value)}
                className="w-full bg-[#090b10] border border-[#1f283d] rounded p-2 text-slate-200 outline-none font-sans text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">CONTRACT TITLE</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-[#090b10] border border-[#1f283d] rounded p-2 text-slate-200 outline-none font-sans text-xs"
              />
            </div>
          </div>

          {/* Action Button */}
          <div className="pt-3 border-t border-[#20283d] flex items-center justify-between">
            <span className="font-mono text-[11px] text-slate-400">
              Output: Full 15-Clause Legal Draft + Contract IR AST + Solidity
            </span>

            <button
              onClick={handleGenerateContract}
              disabled={isGenerating}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-950 text-white rounded font-mono text-xs font-semibold flex items-center gap-2 transition-colors shadow-md"
            >
              {isGenerating ? (
                <RotateCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              <span>{isGenerating ? "Synthesizing Contract IR..." : "Compile to Contract IR & Workspace"}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
