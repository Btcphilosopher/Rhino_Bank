import React, { useState } from "react";
import { Rocket, ShieldCheck, CheckCircle2, Clock, Terminal, AlertTriangle, Layers, ExternalLink } from "lucide-react";
import { DeploymentReceipt } from "../../types";

export const DeploymentsView: React.FC = () => {
  const [deployments, setDeployments] = useState<DeploymentReceipt[]>([
    {
      id: "DEP-2026-0081",
      contractId: "LEX-2026-000184",
      contractTitle: "£25M Term Loan Facility Agreement",
      contractHash: "0x8f192837bcde8192a837482910fa728198f4e229a7cb81dc710928aee91b9487",
      codeHash: "0x98f4e229a7cb81dc710928aee91b9487c9102837bcde8192a837482910fa7281",
      network: "LOCAL_EVM",
      environment: "SANDBOX",
      blockNumber: 1948291,
      transactionHash: "0x12a837482910fa728198f4e229a7cb81dc710928aee91b9487c9102837bcde81",
      deployedAddress: "0x89205A3A3b2A69De6Dbf7f01ED13B2108B2c43e7",
      deployedAt: "2026-09-07T09:15:22Z",
      deployerRole: "CONTRACT_ENGINEER",
      deployerAddress: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC",
      signersApproved: ["Sarah Jenkins (Legal)", "Dr. Ryan Vance (Engineer)", "FCA Gate (Compliance)"],
      formalVerificationStatus: "VERIFIED",
      gasUsed: 1842900,
    },
    {
      id: "DEP-2026-0082",
      contractId: "LEX-2026-000186",
      contractTitle: "Global Master Repurchase Agreement (Repo)",
      contractHash: "0x3892bcde710928aee91b9487c9102837bcde8192a837482910fa728198f4e229",
      codeHash: "0x78ab1264c9102374bcde8192a837482910fa728198f4e229a7cb81dc710928ae",
      network: "LOCAL_EVM",
      environment: "SANDBOX",
      blockNumber: 1948330,
      transactionHash: "0x510928aee91b9487c9102837bcde8192a837482910fa728198f4e229a7cb81dc",
      deployedAddress: "0x1234567890123456789012345678901234567890",
      deployedAt: "2026-09-13T12:00:00Z",
      deployerRole: "CONTRACT_ENGINEER",
      deployerAddress: "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
      signersApproved: ["Clifford Chance (Legal)", "Chief Risk Officer"],
      formalVerificationStatus: "VERIFIED",
      gasUsed: 1420100,
    },
  ]);

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>DEPLOYMENT PIPELINE & ON-CHAIN REGISTRY</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-300">
              MULTI-SIG GATED
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Production contract deployment receipts, multi-sig legal & technical approvals, and immutable on-chain bytecode provenance.
          </p>
        </div>
      </div>

      {/* Deployment Flow Visualiser */}
      <div className="bg-[#10141f] p-4 rounded border border-[#1e2638] space-y-3 font-mono text-xs">
        <div className="text-white font-semibold flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span>INSTITUTIONAL DEPLOYMENT GATES (MANDATORY ORDER)</span>
        </div>

        <div className="grid grid-cols-5 gap-3 text-center">
          <div className="bg-[#141b2b] p-3 rounded border border-[#232f4a] space-y-1">
            <div className="text-emerald-400 font-bold">1. COMPILE</div>
            <div className="text-[10px] text-slate-400">IR to Solidity AST</div>
            <span className="text-[10px] text-emerald-400">✓ Complete</span>
          </div>
          <div className="bg-[#141b2b] p-3 rounded border border-[#232f4a] space-y-1">
            <div className="text-emerald-400 font-bold">2. SMT PROOF</div>
            <div className="text-[10px] text-slate-400">Z3 Inductive Proof</div>
            <span className="text-[10px] text-emerald-400">✓ Complete</span>
          </div>
          <div className="bg-[#141b2b] p-3 rounded border border-[#232f4a] space-y-1">
            <div className="text-emerald-400 font-bold">3. LEGAL GATE</div>
            <div className="text-[10px] text-slate-400">Counsel Multi-Sig</div>
            <span className="text-[10px] text-emerald-400">✓ Complete</span>
          </div>
          <div className="bg-[#141b2b] p-3 rounded border border-[#232f4a] space-y-1">
            <div className="text-emerald-400 font-bold">4. COMPLIANCE</div>
            <div className="text-[10px] text-slate-400">KYC/Sanctions Gate</div>
            <span className="text-[10px] text-emerald-400">✓ Complete</span>
          </div>
          <div className="bg-[#141b2b] p-3 rounded border border-[#232f4a] space-y-1">
            <div className="text-indigo-300 font-bold">5. ON-CHAIN</div>
            <div className="text-[10px] text-slate-400">Deterministic Bytecode</div>
            <span className="text-[10px] text-emerald-400">✓ Active</span>
          </div>
        </div>
      </div>

      {/* Receipts Table */}
      <div className="bg-[#10141f] rounded border border-[#1e2638] overflow-hidden">
        <div className="p-3.5 border-b border-[#1e2638] font-mono text-xs font-semibold text-white">
          VERIFIED ON-CHAIN DEPLOYMENT RECEIPTS ({deployments.length})
        </div>

        <div className="divide-y divide-[#171d2b]">
          {deployments.map((d) => (
            <div key={d.id} className="p-4 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-indigo-300">{d.id}</span>
                  <span className="text-white font-semibold font-sans">{d.contractTitle}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {d.network} / {d.environment}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400">{d.deployedAt.replace("T", " ").substring(0, 19)}</span>
              </div>

              <div className="grid grid-cols-2 gap-4 bg-[#0a0d14] p-3 rounded border border-[#182030] text-[11px] text-slate-300">
                <div>
                  <span className="text-slate-500">Contract Address: </span>
                  <span className="text-emerald-400 font-bold">{d.deployedAddress}</span>
                </div>
                <div>
                  <span className="text-slate-500">Tx Hash: </span>
                  <span className="text-slate-300 truncate">{d.transactionHash}</span>
                </div>
                <div>
                  <span className="text-slate-500">Block Number: </span>
                  <span>#{d.blockNumber} (Gas: {d.gasUsed.toLocaleString()})</span>
                </div>
                <div>
                  <span className="text-slate-500">Verification: </span>
                  <span className="text-emerald-400 font-bold">{d.formalVerificationStatus}</span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 flex items-center gap-2">
                <span className="text-slate-500">Multi-Sig Approved By:</span>
                {d.signersApproved.map((sig, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 text-[10px]">
                    {sig}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
