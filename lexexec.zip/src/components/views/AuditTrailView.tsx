import React from "react";
import { History, ShieldCheck, CheckCircle2, Search, Filter, Hash, User, Calendar } from "lucide-react";
import { AuditService } from "../../services/auditService";

export const AuditTrailView: React.FC = () => {
  const auditRecords = AuditService.getAuditTrail();

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>IMMUTABLE CRYPTOGRAPHIC AUDIT LOG</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-300">
              TAMPER-EVIDENT MERKLE CHAIN
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Every legal modification, compilation artifact, formal verification proof, and settlement event linked in a continuous SHA256 audit chain.
          </p>
        </div>
      </div>

      <div className="bg-[#10141f] rounded border border-[#1e2638] overflow-hidden">
        <div className="p-3.5 border-b border-[#1e2638] flex items-center justify-between font-mono text-xs font-semibold text-white">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-indigo-400" />
            <span>CHRONOLOGICAL AUDIT CHAIN ({auditRecords.length} EVENTS)</span>
          </div>
          <span className="text-emerald-400 text-[11px] flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> All Hashes Verified
          </span>
        </div>

        <div className="divide-y divide-[#171d2b]">
          {auditRecords.map((record) => (
            <div key={record.id} className="p-4 hover:bg-[#131926] transition-colors space-y-2">
              <div className="flex items-center justify-between font-mono text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-indigo-300">{record.id}</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-white font-semibold">{record.contractId}</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                    v{record.contractVersion}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/40 text-[10px] font-bold">
                    {record.eventType}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400">{record.timestamp.replace("T", " ").substring(0, 19)}</div>
              </div>

              <p className="text-xs text-slate-200 font-sans">{record.description}</p>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 bg-[#0a0d14] p-2 rounded border border-[#182030]">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Actor:</span>
                  <span className="text-slate-300">{record.actor} ({record.role})</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Hash:</span>
                  <span className="text-emerald-400 truncate max-w-[220px]">{record.eventHash}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
