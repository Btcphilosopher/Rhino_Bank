import React from "react";
import { ShieldCheck, CheckCircle2, AlertTriangle, FileText, Globe, Scale } from "lucide-react";

export const ComplianceView: React.FC = () => {
  const complianceChecks = [
    { id: "COMP-01", framework: "FCA / PRA Senior Managers & Certification Regime (SMCR)", status: "COMPLIANT", description: "Designated legal engineer and credit approver roles assigned to verified FCA approved persons." },
    { id: "COMP-02", framework: "EMIR Refit / CFTC Swaps Reporting", status: "COMPLIANT", description: "Automated generation of unique trade identifiers (UTI) and trade repository reporting payloads." },
    { id: "COMP-03", framework: "UK eIDAS & Electronic Communications Act 2000", status: "COMPLIANT", description: "Cryptographic counterpart signature verification meets statutory criteria for enforceable deed execution." },
    { id: "COMP-04", framework: "OFAC & HM Treasury Sanctions Screening", status: "COMPLIANT", description: "Continuous automated scanning of settlement IBANs and wallet addresses against SDN lists." },
  ];

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>REGULATORY COMPLIANCE & EMIR/MIFID CONTROLS</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-300">
              4/4 CONTROLS ACTIVE
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Automated compliance gates ensuring all machine-executable contracts satisfy statutory, regulatory, and trade reporting obligations.
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {complianceChecks.map((chk) => (
          <div key={chk.id} className="bg-[#10141f] p-4 rounded border border-[#1e2638] flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2 font-mono text-xs">
                <span className="text-indigo-400 font-bold">{chk.id}</span>
                <span className="text-white font-semibold">{chk.framework}</span>
              </div>
              <p className="text-xs text-slate-400 font-sans">{chk.description}</p>
            </div>
            <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-600/40 text-xs font-mono font-bold flex items-center gap-1.5 flex-shrink-0">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {chk.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const GovernanceView: React.FC = () => {
  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>MULTI-SIG GOVERNANCE & EMERGENCY DISPUTE DESK</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
              3-OF-4 CONSENSUS REQUIRED
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Human-in-the-loop intervention protocols: Contract pause overrides, legal dispute escalations, and restructuring waivers.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-5">
        <div className="bg-[#10141f] p-5 rounded border border-[#1e2638] space-y-3">
          <h2 className="text-sm font-semibold text-white font-mono">Emergency Pause Status</h2>
          <p className="text-xs text-slate-400">
            Enforces Clause 14 (Human Discretion & Waiver). When enabled, automated state machine payment triggers and liquidations are frozen while maintaining legal validity.
          </p>
          <div className="bg-[#0a0d14] p-3 rounded border border-[#182030] font-mono text-xs flex items-center justify-between">
            <span className="text-slate-400">AUTOMATION STATE:</span>
            <span className="text-emerald-400 font-bold">ACTIVE (UNPAUSED)</span>
          </div>
        </div>

        <div className="bg-[#10141f] p-5 rounded border border-[#1e2638] space-y-3">
          <h2 className="text-sm font-semibold text-white font-mono">Dispute Resolution Forum</h2>
          <p className="text-xs text-slate-400">
            Designated competent forum: High Court of Justice (Commercial Court), London under English Law.
          </p>
          <div className="bg-[#0a0d14] p-3 rounded border border-[#182030] font-mono text-xs flex items-center justify-between">
            <span className="text-slate-400">ARBITRATION DESK:</span>
            <span className="text-indigo-300 font-bold">LCIA ARBITRATION ACTIVE</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export const JurisdictionsView: React.FC = () => {
  const jurisdictions = [
    { name: "England and Wales", forum: "Commercial Court, London / LCIA", enforceability: "99.4%", standard: "LMA / ISDA Sterling standard" },
    { name: "New York", forum: "US District Court (SDNY) / AAA", enforceability: "99.1%", standard: "ISDA / LSTA US standard" },
    { name: "Switzerland", forum: "Commercial Court of Zurich", enforceability: "98.8%", standard: "Swiss DLT Act (ERC-3643)" },
    { name: "Singapore", forum: "Singapore International Arbitration Centre (SIAC)", enforceability: "99.0%", standard: "ICC UCP 600 Trade Rules" },
    { name: "Delaware", forum: "Delaware Court of Chancery", enforceability: "99.5%", standard: "DGCL Corporate Escrow" },
  ];

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>SUPPORTED JURISDICTIONS & GOVERNING LAWS</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
              5 MAJOR JURISDICTIONS
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Standardised legal constructions and judicial forum rules mapping statutory contract law to executable smart contracts.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-5">
        {jurisdictions.map((j, i) => (
          <div key={i} className="bg-[#10141f] p-4 rounded border border-[#1e2638] space-y-2 font-mono text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-sm">{j.name}</span>
              <span className="text-emerald-400 font-bold">{j.enforceability} Enforceability</span>
            </div>
            <div className="text-slate-400 font-sans text-xs">
              <strong>Dispute Forum: </strong>{j.forum}
            </div>
            <div className="text-slate-500 text-[11px]">
              <strong>Primary Market Standard: </strong>{j.standard}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
