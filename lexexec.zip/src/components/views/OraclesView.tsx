import React, { useState } from "react";
import { Radio, ShieldCheck, AlertTriangle, RefreshCw, Key, TrendingUp, CheckCircle2 } from "lucide-react";
import { OracleService } from "../../services/oracleService";
import { OracleFeed } from "../../types";

export const OraclesView: React.FC = () => {
  const [feeds, setFeeds] = useState<OracleFeed[]>(OracleService.getFeeds());
  const [selectedFeedId, setSelectedFeedId] = useState<string>("ORACLE-SONIA");

  const handleSimulateStale = (feedId: string) => {
    OracleService.updateFeedValue(feedId, 5.1845, true);
    setFeeds(OracleService.getFeeds());
  };

  const handleSimulateRecover = (feedId: string) => {
    OracleService.updateFeedValue(feedId, 5.1845, false);
    setFeeds(OracleService.getFeeds());
  };

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>ORACLE NETWORK & REFERENCE RATE BENCHMARKS</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
              5 BENCHMARKS MONITORED
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative reference rates (SONIA, SOFR, €STR), FX fixings, and Gilt asset valuations with cryptographic signature validation and fallback waterfalls.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-5">
        {feeds.map((feed) => (
          <div key={feed.id} className="bg-[#10141f] p-5 rounded border border-[#1e2638] space-y-3.5">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-sm font-semibold text-white">{feed.name}</h2>
                <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400 mt-0.5">
                  <span>Feed ID: {feed.id}</span>
                  <span>•</span>
                  <span>Currency: {feed.currency}</span>
                </div>
              </div>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold flex items-center gap-1 ${
                  feed.status === "ACTIVE"
                    ? "bg-emerald-950 text-emerald-300 border border-emerald-600/40"
                    : "bg-red-950 text-red-300 border border-red-600/40 animate-pulse"
                }`}
              >
                {feed.status === "ACTIVE" ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                {feed.status}
              </span>
            </div>

            <div className="bg-[#0a0d14] p-3 rounded border border-[#182030] flex items-center justify-between font-mono">
              <div>
                <div className="text-[10px] text-slate-500 uppercase">CURRENT BENCHMARK FIXING</div>
                <div className="text-xl font-bold text-white">
                  {feed.currentValue} <span className="text-xs text-indigo-300 font-normal">{feed.unit}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-slate-500">CONFIDENCE RATING</div>
                <div className="text-sm font-bold text-emerald-400">{feed.confidence}%</div>
              </div>
            </div>

            <div className="text-xs text-slate-400 space-y-1 font-mono text-[11px]">
              <div><strong className="text-slate-300">Administrator:</strong> {feed.source}</div>
              <div className="truncate"><strong className="text-slate-300">ECDSA Signature:</strong> {feed.signature}</div>
            </div>

            <div className="pt-2 border-t border-[#1e2638] flex items-center justify-between">
              <span className="text-[10px] font-mono text-slate-500">
                Fallback: Central Bank Base Rate + Spread Waterfall
              </span>

              {feed.status === "ACTIVE" ? (
                <button
                  onClick={() => handleSimulateStale(feed.id)}
                  className="px-2.5 py-1 rounded bg-amber-950/60 hover:bg-amber-900 border border-amber-600/40 text-amber-300 text-[11px] font-mono transition-colors"
                >
                  Simulate Staleness Failure
                </button>
              ) : (
                <button
                  onClick={() => handleSimulateRecover(feed.id)}
                  className="px-2.5 py-1 rounded bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-600/40 text-emerald-300 text-[11px] font-mono transition-colors"
                >
                  Restore Benchmark Feed
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
