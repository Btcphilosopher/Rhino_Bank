import React from "react";
import {
  FileText,
  Search,
  Filter,
  Plus,
  ArrowRight,
  ShieldAlert,
  CheckCircle2,
  Clock,
  Layers,
  Scale,
} from "lucide-react";
import { ContractIR } from "../../types/contract-ir";
import { ContractCompiler } from "../../services/compiler";

interface ContractsListViewProps {
  contracts: ContractIR[];
  selectedContractId: string;
  onSelectContract: (contractId: string) => void;
  onOpenNewContract: () => void;
  onOpenWorkspace: (contractId: string) => void;
}

export const ContractsListView: React.FC<ContractsListViewProps> = ({
  contracts,
  selectedContractId,
  onSelectContract,
  onOpenNewContract,
  onOpenWorkspace,
}) => {
  const [searchTerm, setSearchTerm] = React.useState("");
  const [categoryFilter, setCategoryFilter] = React.useState<string>("ALL");

  const filtered = contracts.filter((c) => {
    const matchesSearch =
      c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.contract_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.governing_law.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      categoryFilter === "ALL" || c.financial_terms.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      {/* Top Banner */}
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>INSTITUTIONAL CONTRACT REPOSITORY</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
              {contracts.length} CONTRACTS ACTIVE
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Machine-executable legal agreements with formal mathematical Intermediate Representation (IR), state machines, and verified Solidity artifacts.
          </p>
        </div>

        <button
          onClick={onOpenNewContract}
          className="px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs flex items-center gap-1.5 transition-colors shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Formal Contract</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 bg-[#10141f] border border-[#1e2638] rounded px-3 py-1.5 flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search by Contract ID, Title, Governing Law..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-transparent text-xs text-slate-200 outline-none w-full placeholder:text-slate-500"
          />
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="text-slate-500">CATEGORY:</span>
          {["ALL", "LOAN", "REPO", "BOND", "INTEREST_RATE_SWAP", "ESCROW", "TRADE_FINANCE", "FX_FORWARD"].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-2.5 py-1 rounded transition-colors ${
                categoryFilter === cat
                  ? "bg-indigo-600 text-white font-bold"
                  : "bg-[#10141f] text-slate-400 hover:text-slate-200 border border-[#1e2638]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Contracts Table */}
      <div className="bg-[#10141f] rounded border border-[#1e2638] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead className="bg-[#0d111a] text-slate-400 font-mono text-[11px] border-b border-[#1e2638]">
              <tr>
                <th className="p-3.5">CONTRACT ID & TITLE</th>
                <th className="p-3.5">CATEGORY</th>
                <th className="p-3.5">NOTIONAL VALUE</th>
                <th className="p-3.5">PARTIES</th>
                <th className="p-3.5">GOVERNING LAW</th>
                <th className="p-3.5">PARITY SCORE</th>
                <th className="p-3.5">STATE</th>
                <th className="p-3.5 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#171d2b]">
              {filtered.map((c) => {
                const parity = ContractCompiler.calculateParity(c);
                return (
                  <tr
                    key={c.contract_id}
                    className={`hover:bg-[#131926] transition-colors cursor-pointer ${
                      c.contract_id === selectedContractId ? "bg-[#141a29]" : ""
                    }`}
                    onClick={() => {
                      onSelectContract(c.contract_id);
                      onOpenWorkspace(c.contract_id);
                    }}
                  >
                    <td className="p-3.5 font-mono">
                      <div className="font-bold text-indigo-300 text-xs">{c.contract_id}</div>
                      <div className="font-sans font-medium text-white text-xs mt-0.5 line-clamp-1">
                        {c.title}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">v{c.version}</div>
                    </td>

                    <td className="p-3.5 font-mono">
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-bold">
                        {c.financial_terms.category}
                      </span>
                    </td>

                    <td className="p-3.5 font-mono text-xs font-semibold text-slate-200">
                      {c.financial_terms.currency}{" "}
                      {c.financial_terms.notional?.toLocaleString() || "N/A"}
                    </td>

                    <td className="p-3.5 text-slate-300 text-xs">
                      {c.parties.length > 0 ? (
                        <div className="space-y-0.5">
                          <div className="font-medium truncate max-w-xs">{c.parties[0]?.legalName}</div>
                          {c.parties[1] && (
                            <div className="text-slate-400 text-[11px] truncate max-w-xs">
                              vs {c.parties[1]?.legalName}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-500 italic">Unassigned</span>
                      )}
                    </td>

                    <td className="p-3.5 text-slate-300 text-xs font-sans">
                      <div>{c.governing_law}</div>
                      <div className="text-[10px] text-slate-500">{c.dispute_forum}</div>
                    </td>

                    <td className="p-3.5 font-mono">
                      <div className="flex items-center gap-1 text-indigo-300 font-bold">
                        <span>{parity.parityPercentage}%</span>
                        <span className="text-[10px] text-slate-500 font-normal">
                          ({parity.verifiedCount}/{parity.legalObligationsCount})
                        </span>
                      </div>
                    </td>

                    <td className="p-3.5 font-mono">
                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-600/40 text-[10px] font-bold">
                        {c.currentState}
                      </span>
                    </td>

                    <td className="p-3.5 text-right font-mono">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectContract(c.contract_id);
                          onOpenWorkspace(c.contract_id);
                        }}
                        className="px-2.5 py-1 bg-indigo-950 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-300 rounded text-xs font-medium inline-flex items-center gap-1 transition-colors"
                      >
                        <span>Workspace</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
