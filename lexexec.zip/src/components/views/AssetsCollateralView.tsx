import React from "react";
import { Coins, ShieldCheck, TrendingUp, DollarSign, Layers } from "lucide-react";

export const AssetsCollateralView: React.FC = () => {
  const collateralPools = [
    {
      id: "ASSET-GILT-10Y",
      name: "United Kingdom 10-Year Benchmark Gilt (4.250% 2036)",
      isin: "GB00B24FF097",
      assetClass: "SOVEREIGN_DEBT",
      currency: "GBP",
      marketValue: 12500000,
      haircutPct: 20,
      effectiveValue: 10000000,
      custodian: "Euroclear UK & International (CREST)",
      pledgedToContract: "LEX-2026-000186 (GMRA Repo)",
      eligibilityStatus: "ELIGIBLE_GRADE_A",
    },
    {
      id: "ASSET-UST-10Y",
      name: "United States Treasury Note 10Y (4.125% 2034)",
      isin: "US91282CJZ52",
      assetClass: "SOVEREIGN_DEBT",
      currency: "USD",
      marketValue: 25000000,
      haircutPct: 15,
      effectiveValue: 21250000,
      custodian: "BNY Mellon Tri-Party Custody",
      pledgedToContract: "LEX-2026-000187 (ISDA Margin)",
      eligibilityStatus: "ELIGIBLE_GRADE_A",
    },
    {
      id: "ASSET-CASH-GBP",
      name: "Sterling Cash Reserve Escrow (Bank of England Reserve Account)",
      isin: "CASH-GBP-RESERVE",
      assetClass: "CASH_EQUIVALENT",
      currency: "GBP",
      marketValue: 5000000,
      haircutPct: 0,
      effectiveValue: 5000000,
      custodian: "Thames Corporate Trustee & Paying Agent",
      pledgedToContract: "LEX-2026-000184 (Loan Escrow)",
      eligibilityStatus: "ELIGIBLE_GRADE_A",
    },
    {
      id: "ASSET-ERC3643-RE",
      name: "Tokenised Commercial Real Estate Note (ERC-3643)",
      isin: "CH1298401928",
      assetClass: "TOKENISED_SECURITY",
      currency: "CHF",
      marketValue: 12000000,
      haircutPct: 35,
      effectiveValue: 7800000,
      custodian: "Sygnum Bank Digital Custody",
      pledgedToContract: "LEX-2026-000189 (Real Estate DvP)",
      eligibilityStatus: "ELIGIBLE_GRADE_B",
    },
  ];

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>COLLATERAL ASSETS & HAIRCUT SCHEDULE</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
              4 PLEDGED ASSET POOLS
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Eligible collateral, custodian integrations, haircut schedules, and real-time mark-to-market valuations.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-5">
        {collateralPools.map((asset) => (
          <div key={asset.id} className="bg-[#10141f] p-5 rounded border border-[#1e2638] space-y-3.5">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-sm font-semibold text-white">{asset.name}</h2>
                <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400 mt-0.5">
                  <span>ISIN: {asset.isin}</span>
                  <span>•</span>
                  <span>Class: {asset.assetClass}</span>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-600/40 text-[10px] font-mono font-bold">
                {asset.eligibilityStatus}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3 bg-[#0a0d14] p-3 rounded border border-[#182030] font-mono text-xs">
              <div>
                <div className="text-[10px] text-slate-500">MARKET VALUE</div>
                <div className="font-bold text-white">£{asset.marketValue.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">HAIRCUT DEDUCTION</div>
                <div className="font-bold text-amber-400">{asset.haircutPct}%</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">EFFECTIVE COLLATERAL</div>
                <div className="font-bold text-emerald-400">£{asset.effectiveValue.toLocaleString()}</div>
              </div>
            </div>

            <div className="text-xs text-slate-400 space-y-1 font-mono text-[11px]">
              <div><strong className="text-slate-300">Custodian:</strong> {asset.custodian}</div>
              <div><strong className="text-slate-300">Pledged To:</strong> {asset.pledgedToContract}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
