import React, { useState } from "react";
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  DollarSign,
  FileCheck,
  Search,
  Filter,
} from "lucide-react";
import { ExecutionEventReceipt } from "../../types";

export const ExecutionMonitorView: React.FC = () => {
  const [receipts, setReceipts] = useState<ExecutionEventReceipt[]>([
    {
      id: "RCPT-2026-0922-001",
      contractId: "LEX-2026-000184",
      contractTitle: "£25M Term Loan Facility",
      eventType: "PRINCIPAL_DISBURSEMENT",
      amountFormatted: "£25,000,000.00",
      payerName: "Caledonian Institutional Capital Partners",
      beneficiaryName: "Apex Meridian Infrastructure Holdings",
      contractState: "PERFORMING",
      legalClauseRef: "Clause 05 (Utilisation & Disbursement)",
      executionRuleId: "OBL-03",
      codeVersion: "v1.4.2",
      timestamp: "2026-09-10T14:32:01Z",
      settlementTxHash: "0x892019abcdf8472910fa728198f4e229a7cb81dc710928aee91b9487c9102837",
      status: "CONFIRMED",
    },
    {
      id: "RCPT-2026-0922-002",
      contractId: "LEX-2026-000186",
      contractTitle: "Global Master Repurchase Agreement (Repo)",
      eventType: "PURCHASE_SETTLEMENT_DVP",
      amountFormatted: "£10,000,000.00",
      payerName: "Sterling Sovereign Liquidity Fund",
      beneficiaryName: "Apex Prime Brokerage",
      contractState: "PERFORMING",
      legalClauseRef: "Clause 01 (Purchase & Sale)",
      executionRuleId: "OBL-REPO-01",
      codeVersion: "v2.1.0",
      timestamp: "2026-09-15T09:12:44Z",
      settlementTxHash: "0x3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e",
      status: "CONFIRMED",
    },
    {
      id: "RCPT-2026-0922-003",
      contractId: "LEX-2026-000188",
      contractTitle: "Software IP Escrow Agreement",
      eventType: "MILESTONE_RELEASE_M1",
      amountFormatted: "£1,050,000.00",
      payerName: "Enterprise Cloud Systems Inc.",
      beneficiaryName: "Quantum AI Core Labs Ltd",
      contractState: "PERFORMING",
      legalClauseRef: "Clause 04 (Milestone Release)",
      executionRuleId: "OBL-ESC-01",
      codeVersion: "v1.1.0",
      timestamp: "2026-09-18T16:00:22Z",
      settlementTxHash: "0x7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a",
      status: "CONFIRMED",
    },
    {
      id: "RCPT-2026-0922-004",
      contractId: "LEX-2026-000187",
      contractTitle: "ISDA Master Interest Rate Swap (£100M)",
      eventType: "QUARTERLY_NET_RESET",
      amountFormatted: "£184,210.50 (Net)",
      payerName: "European Pension Asset Management",
      beneficiaryName: "Manhattan Global Derivatives",
      contractState: "PERFORMING",
      legalClauseRef: "Confirmation Section 2",
      executionRuleId: "OBL-SWAP-01",
      codeVersion: "v1.0.0",
      timestamp: "2026-09-20T11:00:00Z",
      settlementTxHash: "0x1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c9d0e",
      status: "CONFIRMED",
      oracleContext: "SONIA Fixed @ 5.1845% vs 4.50% Fixed Leg",
    },
  ]);

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      {/* Top Banner */}
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-950/80 border border-indigo-500/40 rounded">
            <Activity className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 font-mono text-sm font-semibold text-white">
              <span>INSTITUTIONAL EXECUTION & SETTLEMENT MONITOR</span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-300">
                LIVE SETTLEMENT DESK
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Authoritative transaction receipts, legal clause provenance, and payment verification trail across all smart contracts.
            </p>
          </div>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-[#10141f] p-3.5 rounded border border-[#1e2638] space-y-1">
          <div className="text-slate-400 text-[11px]">24H SETTLEMENT VOLUME</div>
          <div className="text-2xl font-bold text-white">£36,234,210.50</div>
          <div className="text-[10px] text-emerald-400">100% On-Time Settlement</div>
        </div>

        <div className="bg-[#10141f] p-3.5 rounded border border-[#1e2638] space-y-1">
          <div className="text-slate-400 text-[11px]">ACTIVE OBLIGATIONS DUE</div>
          <div className="text-2xl font-bold text-indigo-300">14 OBLIGATIONS</div>
          <div className="text-[10px] text-slate-500">Next due: 2026-12-10 (£433.4k)</div>
        </div>

        <div className="bg-[#10141f] p-3.5 rounded border border-[#1e2638] space-y-1">
          <div className="text-slate-400 text-[11px]">MARGIN CALLS OPEN</div>
          <div className="text-2xl font-bold text-emerald-400">0 DEFICITS</div>
          <div className="text-[10px] text-slate-500">Collateral coverage: 125%</div>
        </div>

        <div className="bg-[#10141f] p-3.5 rounded border border-[#1e2638] space-y-1">
          <div className="text-slate-400 text-[11px]">EVENTS OF DEFAULT</div>
          <div className="text-2xl font-bold text-emerald-400">0 ACTIVE</div>
          <div className="text-[10px] text-slate-500">All facilities performing</div>
        </div>
      </div>

      {/* Execution Receipts Table */}
      <div className="bg-[#10141f] rounded border border-[#1e2638] overflow-hidden">
        <div className="p-3.5 border-b border-[#1e2638] flex items-center justify-between font-mono text-xs font-semibold text-white">
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-indigo-400" />
            <span>IMMUTABLE EXECUTION RECEIPTS & LEGAL PROVENANCE</span>
          </div>
          <span className="text-slate-400 font-normal">{receipts.length} Confirmed Events</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead className="bg-[#0d111a] text-slate-400 font-mono text-[11px] border-b border-[#1e2638]">
              <tr>
                <th className="p-3.5">RECEIPT ID & DATE</th>
                <th className="p-3.5">CONTRACT & EVENT</th>
                <th className="p-3.5">AMOUNT</th>
                <th className="p-3.5">PAYER → BENEFICIARY</th>
                <th className="p-3.5">LEGAL PROVENANCE</th>
                <th className="p-3.5">SETTLEMENT TX HASH</th>
                <th className="p-3.5">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#171d2b]">
              {receipts.map((rcpt) => (
                <tr key={rcpt.id} className="hover:bg-[#131926] transition-colors">
                  <td className="p-3.5 font-mono">
                    <div className="font-bold text-indigo-300">{rcpt.id}</div>
                    <div className="text-[10px] text-slate-500">{rcpt.timestamp.replace("T", " ").substring(0, 19)}</div>
                  </td>

                  <td className="p-3.5">
                    <div className="font-medium text-white">{rcpt.contractTitle}</div>
                    <div className="font-mono text-[10px] text-indigo-400 font-bold mt-0.5">
                      {rcpt.eventType}
                    </div>
                  </td>

                  <td className="p-3.5 font-mono text-xs font-semibold text-emerald-400">
                    {rcpt.amountFormatted || "N/A"}
                  </td>

                  <td className="p-3.5 text-xs text-slate-300">
                    <div className="truncate max-w-xs">{rcpt.payerName}</div>
                    <div className="text-slate-500 text-[11px] truncate max-w-xs">→ {rcpt.beneficiaryName}</div>
                  </td>

                  <td className="p-3.5 text-xs">
                    <div className="text-slate-300 font-medium">{rcpt.legalClauseRef}</div>
                    <div className="font-mono text-[10px] text-slate-500">Rule: {rcpt.executionRuleId}</div>
                  </td>

                  <td className="p-3.5 font-mono text-[10px] text-slate-400 truncate max-w-[140px]">
                    {rcpt.settlementTxHash}
                  </td>

                  <td className="p-3.5 font-mono">
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-600/40 text-[10px] font-bold flex items-center gap-1 w-fit">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      {rcpt.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
