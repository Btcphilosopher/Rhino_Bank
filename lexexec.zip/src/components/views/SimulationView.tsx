import React, { useState, useMemo } from "react";
import {
  PlayCircle,
  RotateCcw,
  FastForward,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Calendar,
  Percent,
  Layers,
  ArrowRight,
  Sliders,
  Activity,
  Calculator,
  ShieldAlert,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";
import { ContractIR, ContractStateType } from "../../types/contract-ir";
import { FinancialCalculationEngine, CalculationTrace } from "../../services/financeEngine";
import { AuditService } from "../../services/auditService";

interface SimulationViewProps {
  contract: ContractIR;
  onUpdateContract: (contract: ContractIR) => void;
}

export const SimulationView: React.FC<SimulationViewProps> = ({ contract, onUpdateContract }) => {
  const [simulatedState, setSimulatedState] = useState<ContractStateType>(contract.currentState);
  const [simulatedDate, setSimulatedDate] = useState<string>("2026-09-05");
  const [soniaRate, setSoniaRate] = useState<number>(5.1845);
  const [collateralValuation, setCollateralValuation] = useState<number>(
    contract.financial_terms.collateralValuation || 12500000
  );
  const [haircutPct, setHaircutPct] = useState<number>(contract.financial_terms.haircutPercent || 20);
  const [lastCalculationTrace, setLastCalculationTrace] = useState<CalculationTrace | null>(null);
  const [executionLogs, setExecutionLogs] = useState<
    Array<{ timestamp: string; action: string; details: string; status: "OK" | "WARNING" | "DEFAULT" }>
  >([
    {
      timestamp: "2026-09-05 10:00:00",
      action: "INIT_SIMULATION",
      details: `Initialized environment for ${contract.contract_id}`,
      status: "OK",
    },
  ]);

  // Derived financial metrics
  const notional = contract.financial_terms.notional || 25000000;
  const spreadBps = contract.financial_terms.spreadBps || 175;
  const effectiveRate = soniaRate + spreadBps / 100;

  // Collateral margin metrics
  const collateralMetrics = useMemo(() => {
    return FinancialCalculationEngine.calculateCollateralMetrics(
      notional,
      collateralValuation,
      haircutPct,
      100
    );
  }, [notional, collateralValuation, haircutPct]);

  // Generate dynamic amortization schedule
  const schedule = useMemo(() => {
    return FinancialCalculationEngine.generateAmortizationSchedule(
      notional,
      contract.financial_terms.currency || "GBP",
      contract.financial_terms.startDate || "2026-09-05",
      contract.financial_terms.maturityDate || "2029-06-30",
      effectiveRate,
      contract.financial_terms.paymentFrequency || "Quarterly",
      contract.financial_terms.dayCountConvention || "ACT/365F"
    );
  }, [notional, contract.financial_terms, effectiveRate]);

  // Chart data
  const chartData = schedule.map((item) => ({
    date: item.paymentDate.substring(0, 7),
    Interest: item.interestAmount,
    Principal: item.principalRepayment,
    Total: item.totalCashflow,
  }));

  const logAction = (
    action: string,
    details: string,
    status: "OK" | "WARNING" | "DEFAULT" = "OK"
  ) => {
    setExecutionLogs((prev) => [
      {
        timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
        action,
        details,
        status,
      },
      ...prev,
    ]);
  };

  const handleDisbursePrincipal = () => {
    setSimulatedState("PERFORMING");
    setSimulatedDate("2026-09-10");
    logAction(
      "DISBURSE_PRINCIPAL",
      `Lender transferred £${notional.toLocaleString()} to Borrower settlement account`,
      "OK"
    );
    AuditService.appendRecord(
      contract.contract_id,
      contract.version,
      "Simulated Treasury Agent",
      "TREASURER",
      "PAYMENT_SETTLED",
      `Principal disbursed £${notional.toLocaleString()}`
    );
  };

  const handlePayScheduledInterest = () => {
    const { interest, trace } = FinancialCalculationEngine.calculateSimpleInterest(
      notional,
      effectiveRate,
      simulatedDate,
      "2026-12-10",
      contract.financial_terms.dayCountConvention
    );
    setLastCalculationTrace(trace);
    setSimulatedDate("2026-12-10");
    logAction(
      "PAY_INTEREST",
      `Borrower paid scheduled interest coupon of ${trace.resultFormatted} (Rate: ${effectiveRate.toFixed(4)}%)`,
      "OK"
    );
    AuditService.appendRecord(
      contract.contract_id,
      contract.version,
      "Apex Meridian Treasury",
      "TRADER",
      "PAYMENT_SETTLED",
      `Interest settled ${trace.resultFormatted}`
    );
  };

  const handleTriggerDefault = () => {
    setSimulatedState("EVENT_OF_DEFAULT");
    setSimulatedDate("2026-12-15");
    logAction(
      "EVENT_OF_DEFAULT",
      "Scheduled quarterly coupon missed past 3 Business Days grace period. Automatic covenant breach flagged.",
      "DEFAULT"
    );
    AuditService.appendRecord(
      contract.contract_id,
      contract.version,
      "Automated State Machine Engine",
      "AUDITOR",
      "DEFAULT_TRIGGERED",
      "Payment default past 3 days grace period"
    );
  };

  const handleAccelerateLoan = () => {
    setSimulatedState("ACCELERATION");
    logAction(
      "ACCELERATE_FACILITY",
      `Facility Agent served formal demand for immediate repayment of £${notional.toLocaleString()} plus accrued interest.`,
      "DEFAULT"
    );
  };

  const handleIssueMarginCall = () => {
    logAction(
      "MARGIN_CALL_ISSUED",
      `Variation margin notice issued: Deficit ${collateralMetrics.trace.resultFormatted}. Counterparty has 24h to post collateral.`,
      "WARNING"
    );
  };

  const handlePostCollateral = () => {
    const restored = collateralValuation + 2000000;
    setCollateralValuation(restored);
    logAction(
      "COLLATERAL_POSTED",
      `Counterparty delivered £2,000,000 additional UK Gilts. Effective collateral restored to £${((restored * (100 - haircutPct)) / 100).toLocaleString()}.`,
      "OK"
    );
  };

  const handleResetSimulation = () => {
    setSimulatedState("PERFORMING");
    setSimulatedDate("2026-09-05");
    setSoniaRate(5.1845);
    setCollateralValuation(contract.financial_terms.collateralValuation || 12500000);
    setLastCalculationTrace(null);
    logAction("RESET", "Simulation sandbox reset to baseline contractual terms.", "OK");
  };

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      {/* Top Banner: Simulation Context */}
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-950/80 border border-indigo-500/40 rounded">
            <PlayCircle className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 font-mono text-sm font-semibold text-white">
              <span>FINANCIAL CONTRACT SIMULATION & STRESS-TEST ENGINE</span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-300">
                ACTIVE SANDBOX
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Testing {contract.title} ({contract.contract_id}) across market rate shocks, payment default cascades, and margin calls.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={handleResetSimulation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#161c2c] hover:bg-[#1e263b] border border-[#263147] text-slate-300 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Baseline</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left (Controls & State), Right (Cash Flow & Live Receipts) */}
      <div className="grid grid-cols-12 gap-6">
        {/* Left Column: Parameter Shifters & Scenario Triggers (5 Cols) */}
        <div className="col-span-5 space-y-5">
          {/* Market Parameter Sliders */}
          <div className="bg-[#10141f] p-4 rounded border border-[#1e2638] space-y-4">
            <div className="flex items-center justify-between border-b border-[#1e2638] pb-2">
              <span className="font-mono text-xs font-semibold text-white flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                MARKET PARAMETER SHIFTERS
              </span>
              <span className="font-mono text-[10px] text-slate-400">Deterministic Inputs</span>
            </div>

            {/* SONIA Reference Rate Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">SONIA Benchmark Rate:</span>
                <span className="text-indigo-300 font-bold">{soniaRate.toFixed(4)}% p.a.</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="12.0"
                step="0.05"
                value={soniaRate}
                onChange={(e) => setSoniaRate(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                <span>0.5% (Low Rate)</span>
                <span>Margin: +{(spreadBps / 100).toFixed(2)}% | All-in: {effectiveRate.toFixed(4)}%</span>
                <span>12.0% (Crisis Shock)</span>
              </div>
            </div>

            {/* Collateral Valuation (for Repo / Secured Facilities) */}
            <div className="space-y-1.5 pt-2 border-t border-[#181f2f]">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Collateral Market Value (UK Gilts):</span>
                <span className={`font-bold ${collateralMetrics.marginSurplusOrDeficit < 0 ? "text-red-400" : "text-emerald-400"}`}>
                  £{collateralValuation.toLocaleString()}
                </span>
              </div>
              <input
                type="range"
                min="6000000"
                max="16000000"
                step="250000"
                value={collateralValuation}
                onChange={(e) => setCollateralValuation(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                <span>£6.0M (Liquidation)</span>
                <span>Haircut: {haircutPct}%</span>
                <span>£16.0M (Over-collateralised)</span>
              </div>
            </div>

            {/* Margin Status Indicator */}
            <div className="bg-[#0b0e14] p-2.5 rounded border border-[#1a2133] text-xs font-mono flex items-center justify-between">
              <div>
                <span className="text-slate-400 text-[10px]">MARGIN RATIO / DEFICIT:</span>
                <div className="font-bold text-slate-200">
                  Effective: £{collateralMetrics.effectiveCollateral.toLocaleString()}
                </div>
              </div>
              <div className={`px-2 py-1 rounded text-[11px] font-bold ${
                collateralMetrics.marginStatus === "SATISFIED"
                  ? "bg-emerald-950 text-emerald-300 border border-emerald-600/40"
                  : "bg-red-950 text-red-300 border border-red-600/40 animate-pulse"
              }`}>
                {collateralMetrics.marginStatus}
              </div>
            </div>
          </div>

          {/* Interactive Scenario Trigger Buttons */}
          <div className="bg-[#10141f] p-4 rounded border border-[#1e2638] space-y-3">
            <div className="font-mono text-xs font-semibold text-white flex items-center justify-between">
              <span>CONTRACT LIFECYCLE ACTION TRIGGERS</span>
              <span className="text-[10px] text-slate-400">State: {simulatedState}</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleDisbursePrincipal}
                className="px-3 py-2 bg-indigo-950/60 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-200 rounded text-xs font-mono font-medium transition-colors text-left"
              >
                <div className="font-bold">1. Disburse Principal</div>
                <div className="text-[10px] text-slate-400">Transfer £{notional.toLocaleString()}</div>
              </button>

              <button
                onClick={handlePayScheduledInterest}
                className="px-3 py-2 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-200 rounded text-xs font-mono font-medium transition-colors text-left"
              >
                <div className="font-bold">2. Settle Coupon</div>
                <div className="text-[10px] text-slate-400">Pay at {effectiveRate.toFixed(2)}%</div>
              </button>

              <button
                onClick={handleTriggerDefault}
                className="px-3 py-2 bg-red-950/60 hover:bg-red-900 border border-red-500/40 text-red-200 rounded text-xs font-mono font-medium transition-colors text-left"
              >
                <div className="font-bold">3. Miss Payment</div>
                <div className="text-[10px] text-slate-400">Trigger Default (3d grace)</div>
              </button>

              <button
                onClick={handleAccelerateLoan}
                className="px-3 py-2 bg-amber-950/60 hover:bg-amber-900 border border-amber-500/40 text-amber-200 rounded text-xs font-mono font-medium transition-colors text-left"
              >
                <div className="font-bold">4. Accelerate Remedy</div>
                <div className="text-[10px] text-slate-400">Demand Full £{notional.toLocaleString()}</div>
              </button>

              <button
                onClick={handleIssueMarginCall}
                className="px-3 py-2 bg-purple-950/60 hover:bg-purple-900 border border-purple-500/40 text-purple-200 rounded text-xs font-mono font-medium transition-colors text-left"
              >
                <div className="font-bold">5. Issue Margin Call</div>
                <div className="text-[10px] text-slate-400">Demand Deficit Transfer</div>
              </button>

              <button
                onClick={handlePostCollateral}
                className="px-3 py-2 bg-teal-950/60 hover:bg-teal-900 border border-teal-500/40 text-teal-200 rounded text-xs font-mono font-medium transition-colors text-left"
              >
                <div className="font-bold">6. Post Collateral</div>
                <div className="text-[10px] text-slate-400">+£2,000,000 Gilts</div>
              </button>
            </div>
          </div>

          {/* Transparent Calculation Trace Receipt */}
          {lastCalculationTrace && (
            <div className="bg-[#10141f] p-4 rounded border border-[#1e2638] space-y-2 font-mono text-xs">
              <div className="flex items-center justify-between text-indigo-300 font-bold border-b border-[#1e2638] pb-1.5">
                <span className="flex items-center gap-1.5">
                  <Calculator className="w-3.5 h-3.5" />
                  CALCULATION TRACE RECEIPT
                </span>
                <span className="text-[10px] text-slate-400">{lastCalculationTrace.rounding}</span>
              </div>
              <div className="text-[11px] text-slate-300">
                <strong className="text-slate-400">Formula: </strong>
                {lastCalculationTrace.formula}
              </div>
              <div className="bg-[#0b0e14] p-2 rounded border border-[#181f2f] text-[10.5px] text-slate-400 space-y-0.5">
                <div>Notional: £{lastCalculationTrace.inputs.notional?.toLocaleString()}</div>
                <div>Annual Rate: {lastCalculationTrace.inputs.annualRatePercent?.toFixed(4)}%</div>
                <div>Days Accrued: {lastCalculationTrace.inputs.daysAccrued} / {lastCalculationTrace.inputs.basis}</div>
              </div>
              <div className="flex items-center justify-between text-emerald-400 font-bold pt-1">
                <span>Computed Result:</span>
                <span>{lastCalculationTrace.resultFormatted}</span>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Dynamic Cash Flow Projection & Simulation Event Logs (7 Cols) */}
        <div className="col-span-7 space-y-5">
          {/* Recharts Cash Flow Graph */}
          <div className="bg-[#10141f] p-4 rounded border border-[#1e2638] space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-mono text-xs font-semibold text-white flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
                  DYNAMIC CASH FLOW PROJECTIONS ({contract.financial_terms.currency})
                </h3>
                <p className="text-[11px] text-slate-400">
                  Projected coupons and principal redemption based on {effectiveRate.toFixed(4)}% all-in rate.
                </p>
              </div>
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
                {contract.financial_terms.dayCountConvention}
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1f273b" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                  <YAxis
                    stroke="#64748b"
                    fontSize={11}
                    tickFormatter={(val) => `£${(val / 1000).toFixed(0)}k`}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#0e131f", borderColor: "#26324d", fontSize: "11px" }}
                    formatter={(value: any) => [`£${Number(value).toLocaleString()}`, ""]}
                  />
                  <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "6px" }} />
                  <Bar dataKey="Interest" fill="#6366f1" stackId="a" />
                  <Bar dataKey="Principal" fill="#10b981" stackId="a" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Simulation Execution Trail Logs */}
          <div className="bg-[#10141f] p-4 rounded border border-[#1e2638] space-y-3">
            <div className="flex items-center justify-between font-mono text-xs">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-indigo-400" />
                SIMULATION EXECUTION TRAIL
              </span>
              <span className="text-[10px] text-slate-400">Sim Date: {simulatedDate}</span>
            </div>

            <div className="max-h-48 overflow-y-auto divide-y divide-[#182030] font-mono text-xs">
              {executionLogs.map((log, idx) => (
                <div key={idx} className="py-2 flex items-start gap-2.5">
                  <span className="text-[10px] text-slate-500 whitespace-nowrap">{log.timestamp}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      log.status === "OK"
                        ? "bg-emerald-950 text-emerald-300 border border-emerald-600/40"
                        : log.status === "WARNING"
                        ? "bg-amber-950 text-amber-300 border border-amber-600/40"
                        : "bg-red-950 text-red-300 border border-red-600/40"
                    }`}
                  >
                    {log.action}
                  </span>
                  <span className="text-slate-300 text-[11px] font-sans flex-1">{log.details}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
