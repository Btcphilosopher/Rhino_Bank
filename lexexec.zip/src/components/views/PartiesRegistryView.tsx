import React from "react";
import { Users, CheckCircle2, ShieldCheck, Building, Key, ExternalLink, Globe } from "lucide-react";
import { ContractParty } from "../../types/contract-ir";

export const PartiesRegistryView: React.FC = () => {
  const parties: ContractParty[] = [
    {
      id: "PARTY-APEX-MERIDIAN",
      legalName: "Apex Meridian Infrastructure Holdings Ltd",
      jurisdiction: "England and Wales",
      registrationId: "UK-CO-09823412",
      lei: "213800XYZ98765432109",
      role: "BORROWER",
      address: "100 Bishopsgate, Level 24, London EC2N 4AG",
      authorizedSignatories: [
        { name: "Eleanor Vance", title: "Chief Financial Officer", email: "e.vance@apexmeridian.co.uk", hasSigned: true, signedAt: "2026-09-05T14:22:10Z" },
        { name: "Sir David Thornton", title: "Executive Chairman", email: "d.thornton@apexmeridian.co.uk", hasSigned: true, signedAt: "2026-09-05T14:30:00Z" },
      ],
      identityProvider: "UK Companies House / BankID Institutional",
      settlementAccount: "GB82BARC20000084729104",
      walletAddress: "0x89205A3A3b2A69De6Dbf7f01ED13B2108B2c43e7",
      kycStatus: "VERIFIED",
    },
    {
      id: "PARTY-CALEDONIAN-CAP",
      legalName: "Caledonian Institutional Capital Partners Plc",
      jurisdiction: "Scotland / UK",
      registrationId: "SC-482910",
      lei: "549300ABC12345678901",
      role: "LENDER",
      address: "50 Lothian Road, Edinburgh EH3 9WJ",
      authorizedSignatories: [
        { name: "Alistair Campbell, QC (Hon)", title: "Managing Director, Credit Facilities", email: "a.campbell@caledoniancap.com", hasSigned: true },
      ],
      identityProvider: "FCA Dual Authorised Registry / LEI GLEIF",
      settlementAccount: "GB12BOFS80000019284729",
      walletAddress: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC",
      kycStatus: "VERIFIED",
    },
    {
      id: "PARTY-THAMES-TRUSTEE",
      legalName: "Thames Corporate Trustee & Paying Agent Services Ltd",
      jurisdiction: "England and Wales",
      registrationId: "UK-CO-10294821",
      lei: "213800AGNT84729103820",
      role: "PAYING_AGENT",
      address: "25 Bank Street, Canary Wharf, London E14 5JP",
      authorizedSignatories: [
        { name: "Marcus Sterling", title: "Head of Agency & Trust Operations", email: "m.sterling@thamestrustee.com", hasSigned: true },
      ],
      identityProvider: "FCA Registered Agency Services",
      settlementAccount: "GB99THAM50000091827364",
      walletAddress: "0x90F79bf6EB2c4f870365E785982E1f101E93b906",
      kycStatus: "VERIFIED",
    },
    {
      id: "PARTY-STERLING-SOV",
      legalName: "Sterling Sovereign Liquidity Fund Ltd",
      jurisdiction: "England and Wales",
      registrationId: "UK-CO-11029481",
      lei: "213800REPOLIQUID9876",
      role: "BUYER",
      address: "1 Churchill Place, London E14 5HP",
      authorizedSignatories: [
        { name: "Charles Montgomery", title: "Head of Repo Trading", email: "c.montgomery@sterlingsl.com", hasSigned: true },
      ],
      identityProvider: "Bank of England CREST Settler",
      settlementAccount: "GB88STER90000012847192",
      walletAddress: "0x1234567890123456789012345678901234567890",
      kycStatus: "VERIFIED",
    },
  ];

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>INSTITUTIONAL PARTIES & IDENTITY REGISTRY</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
              {parties.length} IDENTITIES VERIFIED
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            KYC/AML verified legal entities, LEI identifiers, corporate signatories, and crypto-custodial settlement accounts.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-5">
        {parties.map((p) => (
          <div key={p.id} className="bg-[#10141f] p-5 rounded border border-[#1e2638] space-y-3.5">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-sm font-semibold text-white">{p.legalName}</h2>
                <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400 mt-0.5">
                  <span>LEI: {p.lei}</span>
                  <span>•</span>
                  <span>Reg: {p.registrationId}</span>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-600/40 text-[10px] font-mono font-bold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                {p.kycStatus}
              </span>
            </div>

            <div className="text-xs text-slate-400 space-y-1 bg-[#0a0d14] p-3 rounded border border-[#182030] font-mono text-[11px]">
              <div><strong className="text-slate-300">Jurisdiction:</strong> {p.jurisdiction}</div>
              <div><strong className="text-slate-300">Address:</strong> {p.address}</div>
              <div><strong className="text-slate-300">Settlement IBAN:</strong> {p.settlementAccount}</div>
              <div><strong className="text-slate-300">Smart Contract Wallet:</strong> {p.walletAddress}</div>
            </div>

            <div>
              <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-1.5">
                Authorised Signatories ({p.authorizedSignatories.length})
              </div>
              <div className="space-y-1.5">
                {p.authorizedSignatories.map((sig: any, i: number) => (
                  <div key={i} className="flex items-center justify-between bg-[#141a29] px-3 py-1.5 rounded border border-[#202b40] text-xs">
                    <div>
                      <div className="font-semibold text-slate-200">{sig.name}</div>
                      <div className="text-[10px] text-slate-400">{sig.title} ({sig.email})</div>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      eIDAS Signed
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
