import React, { useState } from "react";
import {
  Scale,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  ShieldCheck,
  Cpu,
  UserCheck,
  FileText,
  Layers,
  ArrowRight,
} from "lucide-react";
import { ContractIR } from "../../types/contract-ir";
import { HumanMachineMatrixItem } from "../../types";

interface ParityMatrixViewProps {
  contract: ContractIR;
}

export const ParityMatrixView: React.FC<ParityMatrixViewProps> = ({ contract }) => {
  const [governanceMatrix, setGovernanceMatrix] = useState<HumanMachineMatrixItem[]>([
    {
      id: "GOV-01",
      element: "Legal Intent & Agreement Drafting",
      humanRole: "Required",
      machineRole: "Assist",
      notes: "Commercial agreement must be authored or confirmed by qualified legal counsel.",
      isEditable: false,
    },
    {
      id: "GOV-02",
      element: "Ambiguity Resolution & Defined Terms",
      humanRole: "Required",
      machineRole: "Assist",
      notes: "Humans must choose between competing statutory interpretations or day count conventions.",
      isEditable: false,
    },
    {
      id: "GOV-03",
      element: "Mathematical Coupon & Accrual Calculation",
      humanRole: "Optional",
      machineRole: "Automated",
      notes: "Deterministic calculation engine calculates exact interest to 18 decimal places.",
      isEditable: false,
    },
    {
      id: "GOV-04",
      element: "Conditions Precedent & KYC Verification",
      humanRole: "Review",
      machineRole: "Automated",
      notes: "Identity registries and signed documentation verified before release flag enabled.",
      isEditable: false,
    },
    {
      id: "GOV-05",
      element: "Financial Covenant Audit Sign-Off",
      humanRole: "Required",
      machineRole: "No",
      notes: "Statutory management accounts audited by certified human accountants.",
      isEditable: false,
    },
    {
      id: "GOV-06",
      element: "Scheduled Payment Settlement & Receipts",
      humanRole: "Optional",
      machineRole: "Enforce",
      notes: "Smart contract executes balance transfers and logs cryptographic settlement hash.",
      isEditable: false,
    },
    {
      id: "GOV-07",
      element: "Default Grace Period Monitoring",
      humanRole: "Review",
      machineRole: "Automated",
      notes: "Automated clock monitors 3-day grace period; alerts human agent before acceleration.",
      isEditable: false,
    },
    {
      id: "GOV-08",
      element: "Emergency Pause & Legal Dispute Waiver",
      humanRole: "Required",
      machineRole: "Enforce",
      notes: "Authorized agent can halt automated smart contract execution during active litigation.",
      isEditable: false,
    },
  ]);

  const verifiedObligations = contract.obligations.filter((o) => o.verificationStatus === "VERIFIED");
  const unmappedObligations = contract.obligations.filter((o) => o.verificationStatus === "UNMAPPED");
  const reviewObligations = contract.obligations.filter((o) => o.verificationStatus === "REQUIRES_REVIEW");

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      {/* Top Banner */}
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-950/80 border border-indigo-500/40 rounded">
            <Scale className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 font-mono text-sm font-semibold text-white">
              <span>LEGAL ↔ EXECUTABLE CODE PARITY MATRIX</span>
              <span className="text-xs px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
                PROVABLE PARITY ENGINE
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Comprehensive mapping between authoritative legal obligations, formal IR statements, and executable smart contract functions.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Total Legal Obligations:</span>
          <span className="text-white font-bold">{contract.obligations.length}</span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-[#10141f] p-3.5 rounded border border-[#1e2638] space-y-1">
          <div className="text-slate-400 text-[11px]">PARITY SCORE</div>
          <div className="text-2xl font-bold text-indigo-300">
            {Math.round((verifiedObligations.length / Math.max(1, contract.obligations.length)) * 100)}%
          </div>
          <div className="text-[10px] text-slate-500">Machine executable & verified</div>
        </div>

        <div className="bg-[#10141f] p-3.5 rounded border border-[#1e2638] space-y-1">
          <div className="text-slate-400 text-[11px]">VERIFIED RULES</div>
          <div className="text-2xl font-bold text-emerald-400">{verifiedObligations.length}</div>
          <div className="text-[10px] text-slate-500">Full formal logic mapping</div>
        </div>

        <div className="bg-[#10141f] p-3.5 rounded border border-[#1e2638] space-y-1">
          <div className="text-slate-400 text-[11px]">UNMAPPED (HUMAN GATED)</div>
          <div className="text-2xl font-bold text-amber-400">{unmappedObligations.length}</div>
          <div className="text-[10px] text-slate-500">Intentionally reserved for human audit</div>
        </div>

        <div className="bg-[#10141f] p-3.5 rounded border border-[#1e2638] space-y-1">
          <div className="text-slate-400 text-[11px]">AMBIGUOUS CLAUSES</div>
          <div className="text-2xl font-bold text-slate-400">0</div>
          <div className="text-[10px] text-slate-500">All terms mathematically closed</div>
        </div>
      </div>

      {/* Deep-Dive: Unmapped Obligations Warning Box */}
      {unmappedObligations.length > 0 && (
        <div className="bg-amber-950/30 border border-amber-600/40 rounded p-4 space-y-2 text-xs">
          <div className="flex items-center gap-2 text-amber-300 font-mono font-bold">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>EXPLICITLY UNMAPPED LEGAL OBLIGATION — HUMAN REVIEW GOVERNANCE</span>
          </div>
          {unmappedObligations.map((u) => (
            <div key={u.id} className="bg-[#0e121b] p-3 rounded border border-[#1f283d] space-y-1.5 font-sans">
              <div className="flex items-center justify-between font-mono text-[11px]">
                <span className="font-bold text-white">{u.id}: {u.action} ({u.clauseRef})</span>
                <span className="text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-600/30">
                  HUMAN AUDIT REQUIRED
                </span>
              </div>
              <p className="text-slate-300 text-xs">
                <strong>Legal Object:</strong> {u.objectDescription}
              </p>
              <div className="text-slate-400 text-xs bg-[#090b10] p-2 rounded border border-[#181f2f]">
                <strong className="text-slate-300">Justification: </strong>
                {u.unmappedReason || "Requires certified statutory accounting audit."}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Complete Obligation Parity Table */}
      <div className="bg-[#10141f] rounded border border-[#1e2638] overflow-hidden">
        <div className="p-3.5 border-b border-[#1e2638] flex items-center justify-between font-mono text-xs font-semibold text-white">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-400" />
            <span>DETAILED OBLIGATION PARITY REGISTRY</span>
          </div>
          <span className="text-slate-400 font-normal">{contract.obligations.length} Total Elements</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead className="bg-[#0d111a] text-slate-400 font-mono text-[11px] border-b border-[#1e2638]">
              <tr>
                <th className="p-3">ID & REF</th>
                <th className="p-3">TYPE</th>
                <th className="p-3">ACTOR → COUNTERPARTY</th>
                <th className="p-3">LEGAL ACTION & OBJECT</th>
                <th className="p-3">EXECUTABLE FUNCTION</th>
                <th className="p-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#171d2b]">
              {contract.obligations.map((obl) => (
                <tr key={obl.id} className="hover:bg-[#131926] transition-colors">
                  <td className="p-3 font-mono">
                    <div className="font-bold text-indigo-300">{obl.id}</div>
                    <div className="text-[10px] text-slate-500">{obl.clauseRef}</div>
                  </td>
                  <td className="p-3 font-mono">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-bold">
                      {obl.type}
                    </span>
                  </td>
                  <td className="p-3 font-mono text-[11px] text-slate-300">
                    <div>{obl.actorPartyId}</div>
                    <div className="text-slate-500">→ {obl.counterpartyId}</div>
                  </td>
                  <td className="p-3 text-slate-200">
                    <div className="font-medium text-white">{obl.action}</div>
                    <div className="text-slate-400 text-[11px] line-clamp-1">{obl.objectDescription}</div>
                  </td>
                  <td className="p-3 font-mono text-[11px]">
                    {obl.executionFunction ? (
                      <span className="text-emerald-400">{obl.executionFunction}</span>
                    ) : (
                      <span className="text-amber-400 italic">Human Gated</span>
                    )}
                  </td>
                  <td className="p-3 font-mono text-[11px]">
                    <span
                      className={`px-2 py-0.5 rounded font-bold inline-flex items-center gap-1 ${
                        obl.verificationStatus === "VERIFIED"
                          ? "bg-emerald-950 text-emerald-300 border border-emerald-600/40"
                          : obl.verificationStatus === "UNMAPPED"
                          ? "bg-amber-950 text-amber-300 border border-amber-600/40"
                          : "bg-purple-950 text-purple-300 border border-purple-600/40"
                      }`}
                    >
                      {obl.verificationStatus === "VERIFIED" && <CheckCircle2 className="w-2.5 h-2.5" />}
                      {obl.verificationStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Human / Machine Matrix */}
      <div className="bg-[#10141f] rounded border border-[#1e2638] overflow-hidden space-y-0">
        <div className="p-3.5 border-b border-[#1e2638] flex items-center justify-between font-mono text-xs font-semibold text-white">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-indigo-400" />
            <span>HUMAN / MACHINE GOVERNANCE DIVISION MATRIX</span>
          </div>
          <span className="text-slate-400 text-[11px]">Strict Non-Delegable Legal Review Rules</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead className="bg-[#0d111a] text-slate-400 font-mono text-[11px] border-b border-[#1e2638]">
              <tr>
                <th className="p-3">CONTRACTUAL ELEMENT</th>
                <th className="p-3">HUMAN ROLE</th>
                <th className="p-3">MACHINE ROLE</th>
                <th className="p-3">GOVERNANCE RATIONALE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#171d2b]">
              {governanceMatrix.map((item) => (
                <tr key={item.id} className="hover:bg-[#131926]">
                  <td className="p-3 font-medium text-white font-mono text-xs">{item.element}</td>
                  <td className="p-3 font-mono">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.humanRole === "Required"
                          ? "bg-amber-950 text-amber-300 border border-amber-600/40"
                          : "bg-slate-800 text-slate-300"
                      }`}
                    >
                      {item.humanRole}
                    </span>
                  </td>
                  <td className="p-3 font-mono">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.machineRole === "Automated" || item.machineRole === "Enforce"
                          ? "bg-indigo-950 text-indigo-300 border border-indigo-500/40"
                          : "bg-slate-800 text-slate-300"
                      }`}
                    >
                      {item.machineRole}
                    </span>
                  </td>
                  <td className="p-3 text-slate-300 text-xs">{item.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
