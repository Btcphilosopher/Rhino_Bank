import React from "react";
import {
  Layers,
  ArrowRight,
  ShieldCheck,
  Scale,
  FileCode2,
  CheckCircle2,
  Coins,
  Building,
  Anchor,
  Sparkles,
} from "lucide-react";
import { FinancialContractCategory } from "../../types/contract-ir";

interface TemplatesViewProps {
  onSelectTemplate: (category: FinancialContractCategory) => void;
}

export const TemplatesView: React.FC<TemplatesViewProps> = ({ onSelectTemplate }) => {
  const templates: Array<{
    category: FinancialContractCategory;
    title: string;
    description: string;
    standardOrigin: string;
    defaultLaw: string;
    icon: React.ReactNode;
    features: string[];
  }> = [
    {
      category: "LOAN",
      title: "Syndicated Commercial Term Loan Facility",
      description: "Structured multi-tranche commercial credit agreement with SONIA floating interest, quarterly resets, financial covenants, and acceleration remedies.",
      standardOrigin: "LMA (Loan Market Association) Standard v2024",
      defaultLaw: "England and Wales",
      icon: <Building className="w-5 h-5 text-indigo-400" />,
      features: ["SONIA / SOFR Benchmark with 5d shift", "3-Day Business Grace Period", "Leverage & Interest Cover Ratios", "Acceleration Remedy on Default"],
    },
    {
      category: "REPO",
      title: "Global Master Repurchase Agreement (Bilateral Repo)",
      description: "Securities repurchase transaction with daily mark-to-market variation margin, haircuts, and delivery-versus-payment (DvP) settlement logic.",
      standardOrigin: "ICMA GMRA 2011 Standard",
      defaultLaw: "England and Wales",
      icon: <Coins className="w-5 h-5 text-amber-400" />,
      features: ["20% Initial Haircut", "Daily Variation Margin Deficit Trigger", "Equivalent Securities Return", "Close-out Netting Provisions"],
    },
    {
      category: "BOND",
      title: "Fixed-Rate Corporate Bond Indenture",
      description: "Senior institutional registered notes with annual fixed coupon distribution, trustee agency rights, negative pledge covenants, and maturity redemption.",
      standardOrigin: "ICMA Primary Market Debt Standard",
      defaultLaw: "England and Wales",
      icon: <Scale className="w-5 h-5 text-emerald-400" />,
      features: ["5.850% Fixed Annual Coupon", "ACT/ACT ICMA Day Count", "Trustee Acceleration Powers", "Registered Denominations (£100k)"],
    },
    {
      category: "INTEREST_RATE_SWAP",
      title: "ISDA Master Interest Rate Swap Confirmation",
      description: "Fixed vs Floating derivative contract with quarterly net cash flow settlements, zero principal exchange, and benchmark fallback waterfalls.",
      standardOrigin: "ISDA 2006 Definitions / 2021 Swaps Matrix",
      defaultLaw: "New York / England and Wales",
      icon: <FileCode2 className="w-5 h-5 text-purple-400" />,
      features: ["Net Settlement Engine", "SONIA / SOFR Floating Leg", "Fixed Leg Accrual", "Automatic Netting Logic"],
    },
    {
      category: "ESCROW",
      title: "Tri-Party Commercial & Software IP Escrow",
      description: "Milestone-conditioned deposit release architecture with independent verification agent, release milestones, and dispute holdback escrow.",
      standardOrigin: "Institutional Technology Escrow Model",
      defaultLaw: "Delaware",
      icon: <Layers className="w-5 h-5 text-teal-400" />,
      features: ["3-Tier Release Milestones", "Inspection & Acceptance Gates", "Arbitration Lockout", "Automated Token Transfer"],
    },
    {
      category: "TRADE_FINANCE",
      title: "Documentary Letter of Credit (UCP 600)",
      description: "Cross-border trade finance facility releasing payment upon electronic presentation of bills of lading and customs inspection certificates.",
      standardOrigin: "ICC UCP 600 (Uniform Customs and Practice)",
      defaultLaw: "Singapore",
      icon: <Anchor className="w-5 h-5 text-sky-400" />,
      features: ["Documentary Presentation Triggers", "Issuing & Advising Bank Rails", "Bill of Lading Oracle Feeds", "Strict Compliance Principle"],
    },
  ];

  return (
    <div className="p-6 bg-[#0b0e14] text-slate-200 min-h-[calc(100vh-80px)] space-y-6">
      <div className="bg-[#10141f] border border-[#1e2638] rounded p-4 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <span>INSTITUTIONAL CONTRACT ARCHETYPE LIBRARY</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300">
              6 VERIFIED ARCHETYPES
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Production-grade formal templates conforming to LMA, ISDA, ICMA, and ICC international standards.
          </p>
        </div>
      </div>

      {/* Grid of Templates */}
      <div className="grid grid-cols-2 gap-5">
        {templates.map((tpl) => (
          <div
            key={tpl.category}
            className="bg-[#10141f] p-5 rounded border border-[#1e2638] hover:border-indigo-500/50 transition-all flex flex-col justify-between space-y-4 shadow-sm"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-[#171e2e] rounded border border-[#232f47]">
                    {tpl.icon}
                  </div>
                  <div>
                    <h2 className="text-sm font-semibold text-white">{tpl.title}</h2>
                    <span className="font-mono text-[10px] text-indigo-400">{tpl.standardOrigin}</span>
                  </div>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {tpl.defaultLaw}
                </span>
              </div>

              <p className="text-xs text-slate-300 font-sans leading-relaxed">{tpl.description}</p>

              <div className="space-y-1.5 pt-1">
                <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                  Key Executable Capabilities
                </div>
                <div className="grid grid-cols-2 gap-1.5 font-mono text-[11px] text-slate-300">
                  {tpl.features.map((feat, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                      <span className="truncate">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#1e2638] flex items-center justify-between">
              <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                SMT Inductive Proof: Pre-Verified
              </span>

              <button
                onClick={() => onSelectTemplate(tpl.category)}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-mono font-medium flex items-center gap-1.5 transition-colors"
              >
                <span>Instantiate Contract</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
