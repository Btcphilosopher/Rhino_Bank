import React from "react";
import { ShieldAlert, Info } from "lucide-react";

export const DisclaimerBanner: React.FC = () => {
  return (
    <div className="bg-[#121624] border-b border-[#232a3b] px-4 py-1.5 flex items-center justify-between text-[11px] text-slate-300">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 text-amber-400 font-mono font-bold text-[10px] uppercase bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-600/40">
          <ShieldAlert className="w-3 h-3" />
          <span>Legal Review Checkpoint</span>
        </div>
        <p className="text-slate-400 font-sans">
          <strong className="text-slate-300">Notice:</strong> LEXEXEC generates structured contractual logic and executable smart contract implementations. It does not independently determine legal validity, regulatory status, or transactional suitability. Qualified legal and compliance review is mandatory prior to live execution.
        </p>
      </div>

      <div className="flex items-center gap-3 font-mono text-[10px] text-slate-400">
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse"></span>
          Z3 Formal Solver: Ready
        </span>
        <span className="text-slate-600">|</span>
        <span>Foundry Engine: v0.8.28</span>
        <span className="text-slate-600">|</span>
        <span>Oracle Consensus: 99.9%</span>
      </div>
    </div>
  );
};
