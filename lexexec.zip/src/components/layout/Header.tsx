import React from "react";
import {
  FileText,
  Layers,
  Users,
  Coins,
  Scale,
  PlayCircle,
  Activity,
  CheckCircle2,
  History,
  Rocket,
  Globe,
  Radio,
  ShieldCheck,
  Cpu,
  Sparkles,
  AlertTriangle,
  ChevronDown,
  Terminal,
} from "lucide-react";
import { AppView, AppEnvironment, NetworkTarget, UserRole } from "../../types";

interface HeaderProps {
  currentView: AppView;
  onSelectView: (view: AppView) => void;
  environment: AppEnvironment;
  onSelectEnvironment: (env: AppEnvironment) => void;
  network: NetworkTarget;
  onSelectNetwork: (net: NetworkTarget) => void;
  userRole: UserRole;
  onSelectRole: (role: UserRole) => void;
  reviewCount: number;
  onOpenAiAssistant: () => void;
  onOpenDemoMode: () => void;
  onOpenNewContract: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onSelectView,
  environment,
  onSelectEnvironment,
  network,
  onSelectNetwork,
  userRole,
  onSelectRole,
  reviewCount,
  onOpenAiAssistant,
  onOpenDemoMode,
  onOpenNewContract,
}) => {
  const primaryNavItems: Array<{ id: AppView; label: string; icon: React.ReactNode }> = [
    { id: "CONTRACTS", label: "CONTRACTS", icon: <FileText className="w-3.5 h-3.5" /> },
    { id: "TEMPLATES", label: "TEMPLATES", icon: <Layers className="w-3.5 h-3.5" /> },
    { id: "PARTIES", label: "PARTIES", icon: <Users className="w-3.5 h-3.5" /> },
    { id: "ASSETS", label: "ASSETS", icon: <Coins className="w-3.5 h-3.5" /> },
    { id: "RULES", label: "RULES (PARITY)", icon: <Scale className="w-3.5 h-3.5" /> },
    { id: "EXECUTION", label: "EXECUTION", icon: <Activity className="w-3.5 h-3.5" /> },
    { id: "SIMULATION", label: "SIMULATION", icon: <PlayCircle className="w-3.5 h-3.5" /> },
    { id: "VERIFICATION", label: "VERIFICATION", icon: <CheckCircle2 className="w-3.5 h-3.5" /> },
    { id: "AUDIT", label: "AUDIT", icon: <History className="w-3.5 h-3.5" /> },
    { id: "DEPLOYMENTS", label: "DEPLOYMENTS", icon: <Rocket className="w-3.5 h-3.5" /> },
  ];

  const secondaryNavItems: Array<{ id: AppView; label: string; icon: React.ReactNode }> = [
    { id: "JURISDICTIONS", label: "JURISDICTIONS", icon: <Globe className="w-3 h-3" /> },
    { id: "ORACLES", label: "ORACLES", icon: <Radio className="w-3 h-3" /> },
    { id: "COMPLIANCE", label: "COMPLIANCE", icon: <ShieldCheck className="w-3 h-3" /> },
    { id: "GOVERNANCE", label: "GOVERNANCE", icon: <Cpu className="w-3 h-3" /> },
  ];

  const roleLabels: Record<UserRole, string> = {
    LEGAL_ENGINEER: "LEGAL ENGINEER",
    LAWYER: "MANAGING LAWYER",
    CONTRACT_ENGINEER: "CONTRACT ENGINEER",
    TRADER: "INSTITUTIONAL TRADER",
    TREASURER: "CHIEF TREASURER",
    COMPLIANCE_OFFICER: "COMPLIANCE OFFICER",
    RISK_OFFICER: "CHIEF RISK OFFICER",
    APPROVER: "SIGNATORY APPROVER",
    ADMIN: "SYS ADMIN",
    AUDITOR: "INDEPENDENT AUDITOR",
  };

  return (
    <header className="bg-[#0f131c] border-b border-[#232a3b] select-none sticky top-0 z-40">
      {/* Top Bar: Brand, Environment, Network, Role & Demo Controls */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#1c2333] text-xs">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onSelectView("CONTRACTS")}>
            <div className="w-6 h-6 rounded bg-[#1e293b] border border-indigo-500/40 flex items-center justify-center font-mono font-bold text-indigo-400 text-xs shadow-inner">
              LEX
            </div>
            <div>
              <div className="flex items-center gap-1.5 font-mono font-semibold tracking-wider text-slate-100 text-sm">
                LEXEXEC
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-950/80 border border-indigo-500/30 text-indigo-300 font-sans font-medium">
                  v3.7 COMPILER
                </span>
              </div>
              <div className="text-[10px] text-slate-400 font-sans tracking-tight">
                LEGAL AGREEMENTS <span className="text-slate-600">→</span> FORMAL CONTRACTS <span className="text-slate-600">→</span> EXECUTABLE LOGIC
              </div>
            </div>
          </div>

          <div className="h-6 w-px bg-[#232a3b] mx-1" />

          {/* Quick Action: New Contract Builder */}
          <button
            onClick={onOpenNewContract}
            className="px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <span>+</span>
            <span>New Contract</span>
          </button>

          {/* Guided Demo Mode */}
          <button
            onClick={onOpenDemoMode}
            className="px-2.5 py-1 rounded bg-amber-950/60 hover:bg-amber-900/80 border border-amber-600/40 text-amber-300 font-medium text-xs flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3 h-3 text-amber-400 animate-pulse" />
            <span>Demonstration Walkthrough</span>
          </button>
        </div>

        {/* Right: Institutional Status Indicators */}
        <div className="flex items-center gap-3 font-mono text-[11px]">
          {/* Environment Switcher */}
          <div className="flex items-center gap-1.5 bg-[#141824] px-2 py-1 rounded border border-[#232a3b]">
            <span className="text-slate-400 text-[10px]">ENV</span>
            <select
              value={environment}
              onChange={(e) => onSelectEnvironment(e.target.value as AppEnvironment)}
              className={`bg-transparent font-semibold cursor-pointer outline-none ${
                environment === "PRODUCTION"
                  ? "text-red-400 font-bold"
                  : environment === "STAGING"
                  ? "text-amber-400"
                  : "text-emerald-400"
              }`}
            >
              <option value="LOCAL" className="bg-[#141824] text-slate-200">LOCAL</option>
              <option value="SANDBOX" className="bg-[#141824] text-emerald-400">SANDBOX</option>
              <option value="STAGING" className="bg-[#141824] text-amber-400">STAGING</option>
              <option value="PRODUCTION" className="bg-[#141824] text-red-400">PRODUCTION [LOCKED]</option>
            </select>
          </div>

          {/* Network Switcher */}
          <div className="flex items-center gap-1.5 bg-[#141824] px-2 py-1 rounded border border-[#232a3b]">
            <span className="text-slate-400 text-[10px]">NET</span>
            <select
              value={network}
              onChange={(e) => onSelectNetwork(e.target.value as NetworkTarget)}
              className="bg-transparent text-indigo-300 font-semibold cursor-pointer outline-none"
            >
              <option value="LOCAL_EVM" className="bg-[#141824] text-indigo-300">LOCAL EVM</option>
              <option value="SEPOLIA_TESTNET" className="bg-[#141824] text-indigo-300">SEPOLIA TESTNET</option>
              <option value="CANTON_SIM" className="bg-[#141824] text-indigo-300">CANTON DISTRIBUTED</option>
              <option value="PERMISSIONED_CONSORTIUM" className="bg-[#141824] text-indigo-300">CONSORTIUM LEDGER</option>
            </select>
          </div>

          {/* Review Status Pill */}
          <button
            onClick={() => onSelectView("RULES")}
            className="flex items-center gap-1.5 bg-amber-950/40 hover:bg-amber-900/50 text-amber-300 border border-amber-600/30 px-2 py-1 rounded transition-colors"
          >
            <AlertTriangle className="w-3 h-3 text-amber-400" />
            <span>REVIEW: {reviewCount} ITEMS</span>
          </button>

          {/* User Role Switcher */}
          <div className="flex items-center gap-1.5 bg-[#141824] px-2 py-1 rounded border border-[#232a3b]">
            <span className="text-slate-400 text-[10px]">USER</span>
            <select
              value={userRole}
              onChange={(e) => onSelectRole(e.target.value as UserRole)}
              className="bg-transparent text-slate-200 font-semibold cursor-pointer outline-none"
            >
              {Object.entries(roleLabels).map(([roleKey, label]) => (
                <option key={roleKey} value={roleKey} className="bg-[#141824] text-slate-200">
                  {label}
                </option>
              ))}
            </select>
          </div>

          {/* AI Assistant Quick Toggle */}
          <button
            onClick={onOpenAiAssistant}
            className="flex items-center gap-1 bg-indigo-950/70 hover:bg-indigo-900/80 border border-indigo-500/40 text-indigo-300 px-2 py-1 rounded transition-colors"
            title="Open AI Contract Assistant"
          >
            <Terminal className="w-3.5 h-3.5 text-indigo-400" />
            <span className="font-sans font-medium">AI Assistant</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="flex items-center justify-between px-4 overflow-x-auto scrollbar-none bg-[#0c0f17]">
        <div className="flex items-center gap-1 py-1">
          {primaryNavItems.map((item) => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? "bg-[#1c2438] text-white border-b-2 border-indigo-400 shadow-sm"
                    : "text-slate-400 hover:text-slate-200 hover:bg-[#151a26]"
                }`}
              >
                <span className={isActive ? "text-indigo-400" : "text-slate-500"}>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Secondary Navigation */}
        <div className="flex items-center gap-1 py-1 border-l border-[#1f273b] pl-3 ml-2">
          {secondaryNavItems.map((item) => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono transition-colors whitespace-nowrap ${
                  isActive
                    ? "bg-[#182030] text-indigo-300 font-semibold"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
