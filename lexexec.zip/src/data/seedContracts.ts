import { ContractIR } from "../types/contract-ir";

export const SEED_CONTRACTS: ContractIR[] = [
  // 1. COMMERCIAL LOAN FACILITY
  {
    contract_id: "LEX-2026-000184",
    title: "£25,000,000 Term Loan Facility Agreement",
    version: "1.4.2",
    governing_law: "England and Wales",
    dispute_forum: "High Court of Justice (Commercial Court), London",
    currentState: "PERFORMING",
    created_at: "2026-09-01T10:00:00Z",
    updated_at: "2026-09-22T08:30:00Z",
    legalReviewRequired: true,
    parties: [
      {
        id: "PARTY-BORROWER",
        legalName: "Apex Meridian Infrastructure Holdings Ltd",
        jurisdiction: "England and Wales",
        registrationId: "UK-CO-09823412",
        lei: "213800XYZ98765432109",
        role: "BORROWER",
        address: "100 Bishopsgate, Level 24, London EC2N 4AG",
        authorizedSignatories: [
          {
            name: "Eleanor Vance",
            title: "Chief Financial Officer",
            email: "e.vance@apexmeridian.co.uk",
            hasSigned: true,
            signedAt: "2026-09-05T14:22:10Z",
          },
        ],
        identityProvider: "UK Companies House / BankID Institutional",
        settlementAccount: "GB82BARC20000084729104",
        walletAddress: "0x89205A3A3b2A69De6Dbf7f01ED13B2108B2c43e7",
        kycStatus: "VERIFIED",
      },
      {
        id: "PARTY-LENDER",
        legalName: "Caledonian Institutional Capital Partners Plc",
        jurisdiction: "Scotland / UK",
        registrationId: "SC-482910",
        lei: "549300ABC12345678901",
        role: "LENDER",
        address: "50 Lothian Road, Edinburgh EH3 9WJ",
        authorizedSignatories: [
          {
            name: "Alistair Campbell, QC (Hon)",
            title: "Managing Director, Credit Facilities",
            email: "a.campbell@caledoniancap.com",
            hasSigned: true,
            signedAt: "2026-09-05T15:10:44Z",
          },
        ],
        identityProvider: "FCA Dual Authorised Registry / LEI GLEIF",
        settlementAccount: "GB12BOFS80000019284729",
        walletAddress: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC",
        kycStatus: "VERIFIED",
      },
      {
        id: "PARTY-AGENT",
        legalName: "Thames Corporate Trustee & Paying Agent Services Ltd",
        jurisdiction: "England and Wales",
        registrationId: "UK-CO-10294821",
        lei: "213800AGNT84729103820",
        role: "PAYING_AGENT",
        address: "25 Bank Street, Canary Wharf, London E14 5JP",
        authorizedSignatories: [
          {
            name: "Marcus Sterling",
            title: "Head of Agency & Trust Operations",
            email: "m.sterling@thamestrustee.com",
            hasSigned: true,
            signedAt: "2026-09-05T16:00:12Z",
          },
        ],
        identityProvider: "FCA Registered Agency Services",
        settlementAccount: "GB99THAM50000091827364",
        walletAddress: "0x90F79bf6EB2c4f870365E785982E1f101E93b906",
        kycStatus: "VERIFIED",
      },
    ],
    definitions: [
      {
        id: "DEF-01",
        term: "Business Day",
        definitionText: "A day (other than a Saturday or Sunday) on which commercial banks and foreign exchange markets are open for general business in London.",
        structuredType: "calendar_rule",
        jurisdiction: "London",
        source: "LMA Standard Definition v2024",
        parameters: { calendar: "TARGET2/London", holidayRule: "MODIFIED_FOLLOWING" },
      },
      {
        id: "DEF-02",
        term: "Reference Rate",
        definitionText: "SONIA (Sterling Overnight Index Average) as administered by the Bank of England and published on the relevant Bloomberg or Refinitiv page.",
        structuredType: "reference_rate",
        jurisdiction: "United Kingdom",
        source: "Bank of England Benchmark Administrator",
        parameters: { fallback: "BOE_BASE_RATE_PLUS_SPREAD", observationPeriodShift: 5 },
      },
      {
        id: "DEF-03",
        term: "Margin",
        definitionText: "1.75 per cent (175 basis points) per annum.",
        structuredType: "formula",
        jurisdiction: "England and Wales",
        source: "Contract Specific Schedule 2",
        parameters: { marginBps: 175, ratePercent: 1.75 },
      },
      {
        id: "DEF-04",
        term: "Day Count Fraction",
        definitionText: "Actual/365 (Fixed), meaning the actual number of days elapsed in the Interest Period divided by 365.",
        structuredType: "formula",
        jurisdiction: "United Kingdom",
        source: "LMA Standard Sterling Rules",
        parameters: { basis: 365, convention: "ACT/365F" },
      },
    ],
    clauses: [
      {
        id: "CLAUSE-01",
        sectionNumber: "01",
        title: "Parties and Recitals",
        legalText: "THIS AGREEMENT is dated 5 September 2026 and made between Apex Meridian Infrastructure Holdings Ltd as Borrower and Caledonian Institutional Capital Partners Plc as Original Lender, with Thames Corporate Trustee & Paying Agent Services Ltd acting as Facility Agent.",
        formalSummary: "Identifies borrower, lender and paying agent entities.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: false,
        relatedObligationIds: [],
      },
      {
        id: "CLAUSE-02",
        sectionNumber: "02",
        title: "Definitions and Interpretation",
        legalText: "Capitalised terms defined in Schedule 1 (Definitions) shall bear the meanings attributed therein. Any reference to statutory provisions includes amendments thereof.",
        formalSummary: "Binds contract interpretation to formal Definitions Engine.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: false,
        relatedObligationIds: [],
      },
      {
        id: "CLAUSE-03",
        sectionNumber: "03",
        title: "The Facility and Purpose",
        legalText: "Subject to the terms of this Agreement, the Lender makes available to the Borrower a Sterling term loan facility in an aggregate principal amount equal to £25,000,000 to fund qualifying renewable grid infrastructure development.",
        formalSummary: "Establishes principal notional £25,000,000.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-01"],
        codeMapping: {
          functionName: "getFacilityNotional()",
          solidityLines: "uint256 public constant PRINCIPAL_NOTIONAL = 25000000 * 10**18;",
        },
      },
      {
        id: "CLAUSE-04",
        sectionNumber: "04",
        title: "Conditions Precedent",
        legalText: "The Borrower may not deliver a Utilisation Request unless the Agent has received all documents and evidence specified in Schedule 2 (Conditions Precedent) in form and substance satisfactory to the Agent.",
        formalSummary: "Requires KYC, corporate resolutions and perfection before disbursement.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-02"],
      },
      {
        id: "CLAUSE-05",
        sectionNumber: "05",
        title: "Utilisation & Disbursement",
        legalText: "Upon satisfaction of the Conditions Precedent, the Lender shall disburse the full principal amount of £25,000,000 to the Borrower's designated settlement account within 2 Business Days of the Utilisation Date.",
        formalSummary: "Disbursement transfer obligation upon CP satisfaction.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-03"],
        codeMapping: {
          functionName: "disbursePrincipal()",
          solidityLines: "function disbursePrincipal() external onlyLender inState(State.APPROVED) { ... }",
        },
      },
      {
        id: "CLAUSE-06",
        sectionNumber: "06",
        title: "Repayment and Maturity",
        legalText: "The Borrower shall repay the aggregate outstanding principal of the Loan in full on the Final Maturity Date, being 30 June 2029 (or if such date is not a Business Day, the immediately following Business Day).",
        formalSummary: "Bullet principal repayment of £25,000,000 on 30 June 2029.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-04"],
        codeMapping: {
          functionName: "repayPrincipalAtMaturity()",
          solidityLines: "function repayPrincipalAtMaturity() external payable onlyBorrower inState(State.ACTIVE) { ... }",
        },
      },
      {
        id: "CLAUSE-07",
        sectionNumber: "07",
        title: "Interest Calculation and Payment",
        legalText: "The rate of interest on the Loan for each Interest Period is the percentage rate per annum which is the aggregate of the applicable Reference Rate (SONIA) plus the Margin of 1.75%. The Borrower shall pay accrued interest quarterly on each Interest Payment Date.",
        formalSummary: "Quarterly interest payment: Notional × (SONIA + 1.75%) × (Days / 365).",
        ambiguities: [
          "Confirm exact fixing observation shift (default 5 Business Days lagged recommended by Bank of England WG).",
        ],
        severity: "LOW",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-05"],
        codeMapping: {
          functionName: "payQuarterlyInterest()",
          solidityLines: "function payQuarterlyInterest(uint256 soniaRateBps) external payable onlyBorrower { ... }",
        },
      },
      {
        id: "CLAUSE-08",
        sectionNumber: "08",
        title: "Prepayment and Cancellation",
        legalText: "The Borrower may, if it gives the Agent not less than 10 Business Days' prior written notice, prepay the whole or any part of the Loan (but, if in part, being an amount that reduces the Loan by an integral multiple of £1,000,000), subject to break costs.",
        formalSummary: "Permitted voluntary prepayment with 10 days notice and minimum chunks of £1M.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-06"],
      },
      {
        id: "CLAUSE-09",
        sectionNumber: "09",
        title: "Financial Covenants and Ratio Tests",
        legalText: "The Borrower shall ensure that on each quarterly calculation date, the Leverage Ratio does not exceed 3.50:1 and the Interest Cover Ratio is not less than 4.00:1. Compliance certificates must be submitted within 30 days of period end.",
        formalSummary: "Covenant maintenance: Leverage <= 3.5x and Interest Cover >= 4.0x.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-07"],
      },
      {
        id: "CLAUSE-10",
        sectionNumber: "10",
        title: "Events of Default",
        legalText: "Each of the events set out in this Clause is an Event of Default: (a) Non-payment of principal or interest within 3 Business Days of due date; (b) Breach of financial covenant uncured after 15 Business Days; (c) Insolvency or administration proceedings.",
        formalSummary: "Triggers default state if payment missed past 3-day grace period.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-08"],
        codeMapping: {
          functionName: "triggerDefault()",
          solidityLines: "function triggerDefault() external onlyAgentOrLender { ... }",
        },
      },
      {
        id: "CLAUSE-11",
        sectionNumber: "11",
        title: "Remedies and Acceleration",
        legalText: "On and at any time after the occurrence of an Event of Default which is continuing, the Agent may, and shall if so directed by the Majority Lenders, by notice to the Borrower declare that the Loan and all accrued interest is immediately due and payable.",
        formalSummary: "Acceleration right to demand immediate £25M + accrued interest.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-09"],
        codeMapping: {
          functionName: "accelerateLoanRemedy()",
          solidityLines: "function accelerateLoanRemedy() external onlyAgent { ... }",
        },
      },
      {
        id: "CLAUSE-12",
        sectionNumber: "12",
        title: "Governing Law",
        legalText: "This Agreement and any non-contractual obligations arising out of or in connection with it are governed by English law.",
        formalSummary: "Governing law explicitly designated as England & Wales.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: false,
        relatedObligationIds: [],
      },
      {
        id: "CLAUSE-13",
        sectionNumber: "13",
        title: "Dispute Resolution & Jurisdiction",
        legalText: "The courts of England have exclusive jurisdiction to settle any dispute arising out of or in connection with this Agreement.",
        formalSummary: "Exclusive jurisdiction of London Commercial Court.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: false,
        relatedObligationIds: [],
      },
      {
        id: "CLAUSE-14",
        sectionNumber: "14",
        title: "Human Discretion & Force Majeure",
        legalText: "The Agent and Lenders retain full discretion to grant waivers, extend cure periods or approve restructuring proposals under human legal review without invalidating other provisions.",
        formalSummary: "Explicit human intervention and waiver capability.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-10"],
      },
      {
        id: "CLAUSE-15",
        sectionNumber: "15",
        title: "Execution and Counterparts",
        legalText: "This Agreement may be executed in any number of counterparts and by electronic signature verification conforming with UK eIDAS regulations.",
        formalSummary: "Authorizes digital signature and cryptographic verification.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-11"],
      },
    ],
    obligations: [
      {
        id: "OBL-01",
        clauseRef: "Clause 03",
        type: "PERMISSION",
        actorPartyId: "PARTY-LENDER",
        counterpartyId: "PARTY-BORROWER",
        action: "Establish Facility",
        objectDescription: "£25,000,000 Sterling Term Facility",
        amount: 25000000,
        currency: "GBP",
        isAutomated: true,
        executionFunction: "getFacilityNotional()",
        verificationStatus: "VERIFIED",
        formalLogic: "ASSERT total_facility_limit == 25000000 * 10^18",
      },
      {
        id: "OBL-02",
        clauseRef: "Clause 04",
        type: "CONDITION",
        actorPartyId: "PARTY-BORROWER",
        counterpartyId: "PARTY-AGENT",
        action: "Satisfy Conditions Precedent",
        objectDescription: "Delivery of KYC, constitutional documents, director certificates",
        isAutomated: true,
        executionFunction: "verifyConditionsPrecedent()",
        verificationStatus: "VERIFIED",
        formalLogic: "ASSERT conditions_precedent_satisfied == true BEFORE disbursement",
      },
      {
        id: "OBL-03",
        clauseRef: "Clause 05",
        type: "OBLIGATION",
        actorPartyId: "PARTY-LENDER",
        counterpartyId: "PARTY-BORROWER",
        action: "Disburse Principal",
        objectDescription: "Transfer of £25,000,000 upon CP satisfaction",
        amount: 25000000,
        currency: "GBP",
        deadline: "2026-09-10",
        isAutomated: true,
        executionFunction: "disbursePrincipal()",
        verificationStatus: "VERIFIED",
        formalLogic: "STATE_TRANSITION(APPROVED -> ACTIVE) && BAL(BORROWER) += 25M",
      },
      {
        id: "OBL-04",
        clauseRef: "Clause 06",
        type: "OBLIGATION",
        actorPartyId: "PARTY-BORROWER",
        counterpartyId: "PARTY-LENDER",
        action: "Repay Principal at Maturity",
        objectDescription: "Repay £25,000,000 principal balance",
        amount: 25000000,
        currency: "GBP",
        deadline: "2029-06-30",
        isAutomated: true,
        executionFunction: "repayPrincipalAtMaturity()",
        verificationStatus: "VERIFIED",
        formalLogic: "IF (now >= maturityDate) => MUST_PAY(BORROWER, LENDER, outstanding_principal)",
      },
      {
        id: "OBL-05",
        clauseRef: "Clause 07",
        type: "OBLIGATION",
        actorPartyId: "PARTY-BORROWER",
        counterpartyId: "PARTY-LENDER",
        action: "Pay Quarterly Accrued Interest",
        objectDescription: "Quarterly interest based on SONIA + 175bps",
        currency: "GBP",
        rateFormula: "SONIA + 1.75%",
        frequency: "QUARTERLY",
        isAutomated: true,
        executionFunction: "payQuarterlyInterest()",
        verificationStatus: "VERIFIED",
        formalLogic: "interest_payment == principal * (sonia_oracle + 0.0175) * (days / 365)",
      },
      {
        id: "OBL-06",
        clauseRef: "Clause 08",
        type: "RIGHT",
        actorPartyId: "PARTY-BORROWER",
        counterpartyId: "PARTY-LENDER",
        action: "Voluntary Prepayment",
        objectDescription: "Prepay principal in chunks of £1,000,000 with 10 days notice",
        isAutomated: true,
        executionFunction: "prepayLoan(uint256 amount)",
        verificationStatus: "VERIFIED",
        formalLogic: "amount % 1000000 == 0 && amount <= outstanding_principal",
      },
      {
        id: "OBL-07",
        clauseRef: "Clause 09",
        type: "OBLIGATION",
        actorPartyId: "PARTY-BORROWER",
        counterpartyId: "PARTY-AGENT",
        action: "Financial Covenant Compliance",
        objectDescription: "Maintain Leverage <= 3.5x and Interest Cover >= 4.0x",
        frequency: "QUARTERLY",
        isAutomated: false,
        unmappedReason: "Requires human accounting audit & certified statutory management accounts review.",
        verificationStatus: "UNMAPPED",
        formalLogic: "AUDIT_CERTIFICATE_UPLOADED && leverage_ratio <= 3.5",
      },
      {
        id: "OBL-08",
        clauseRef: "Clause 10",
        type: "EVENT",
        actorPartyId: "PARTY-BORROWER",
        counterpartyId: "PARTY-LENDER",
        action: "Payment Default Detection",
        objectDescription: "Trigger event of default if overdue payment exceeds 3 business days",
        isAutomated: true,
        executionFunction: "triggerDefault()",
        verificationStatus: "VERIFIED",
        formalLogic: "now > payment_due_date + 3_DAYS && payment_settled == false => STATE = EVENT_OF_DEFAULT",
      },
      {
        id: "OBL-09",
        clauseRef: "Clause 11",
        type: "REMEDY",
        actorPartyId: "PARTY-AGENT",
        counterpartyId: "PARTY-BORROWER",
        action: "Acceleration of Facility",
        objectDescription: "Demand immediate repayment of all outstanding principal and accrued interest",
        isAutomated: true,
        executionFunction: "accelerateLoanRemedy()",
        verificationStatus: "VERIFIED",
        formalLogic: "STATE == EVENT_OF_DEFAULT => accelerated_principal = outstanding_principal + interest",
      },
      {
        id: "OBL-10",
        clauseRef: "Clause 14",
        type: "RIGHT",
        actorPartyId: "PARTY-AGENT",
        counterpartyId: "PARTY-BORROWER",
        action: "Human Discretionary Waiver & Pause",
        objectDescription: "Authorized agent can pause automated execution for dispute negotiation",
        isAutomated: true,
        executionFunction: "emergencyPauseExecution()",
        verificationStatus: "VERIFIED",
        formalLogic: "onlyAgentOrAdmin => isExecutionPaused = true",
      },
    ],
    financial_terms: {
      category: "LOAN",
      notional: 25000000,
      currency: "GBP",
      startDate: "2026-09-05",
      maturityDate: "2029-06-30",
      dayCountConvention: "ACT/365F",
      paymentFrequency: "Quarterly",
      referenceRateName: "SONIA",
      spreadBps: 175,
      businessDayAdjustment: "Modified Following",
    },
    state_machine: {
      states: [
        "DRAFT",
        "LEGAL_REVIEW",
        "APPROVED",
        "SIGNED",
        "EFFECTIVE",
        "ACTIVE",
        "PERFORMING",
        "EVENT_OF_DEFAULT",
        "REMEDY_PERIOD",
        "ACCELERATION",
        "DISPUTE",
        "MATURED",
        "TERMINATED",
      ],
      transitions: [
        {
          id: "TRANS-01",
          fromState: "DRAFT",
          toState: "LEGAL_REVIEW",
          triggerEvent: "SUBMIT_FOR_REVIEW",
          condition: "All mandatory clauses populated",
          responsibleParty: "PARTY-BORROWER",
          executableConsequence: "Lock draft clauses from uncontrolled edits",
          isAutomated: true,
        },
        {
          id: "TRANS-02",
          fromState: "LEGAL_REVIEW",
          toState: "APPROVED",
          triggerEvent: "APPROVE_LEGAL_TERMS",
          condition: "Legal and compliance counsel sign-off",
          responsibleParty: "LEGAL_ENGINEER",
          executableConsequence: "Generate cryptographic Contract IR digest",
          isAutomated: false,
        },
        {
          id: "TRANS-03",
          fromState: "APPROVED",
          toState: "SIGNED",
          triggerEvent: "COLLECT_SIGNATURES",
          condition: "All authorized signatories signed via eIDAS / wallet",
          responsibleParty: "PARTY-AGENT",
          executableConsequence: "Emit SignedContractEvent with SHA256 hashes",
          isAutomated: true,
        },
        {
          id: "TRANS-04",
          fromState: "SIGNED",
          toState: "EFFECTIVE",
          triggerEvent: "CONDITIONS_PRECEDENT_SATISFIED",
          condition: "KYC and security documents perfected",
          responsibleParty: "PARTY-AGENT",
          executableConsequence: "Enable disbursement function on smart contract",
          isAutomated: true,
        },
        {
          id: "TRANS-05",
          fromState: "EFFECTIVE",
          toState: "PERFORMING",
          triggerEvent: "PRINCIPAL_DISBURSED",
          condition: "£25M transferred from Lender to Borrower",
          responsibleParty: "PARTY-LENDER",
          executableConsequence: "Activate quarterly interest accrual timer",
          isAutomated: true,
        },
        {
          id: "TRANS-06",
          fromState: "PERFORMING",
          toState: "EVENT_OF_DEFAULT",
          triggerEvent: "PAYMENT_MISSED_GRACE_EXPIRED",
          condition: "Unpaid interest after 3 Business Days",
          responsibleParty: "PARTY-BORROWER",
          executableConsequence: "Freeze voluntary drawdowns and alert Agent",
          isAutomated: true,
        },
        {
          id: "TRANS-07",
          fromState: "PERFORMING",
          toState: "MATURED",
          triggerEvent: "FINAL_PRINCIPAL_REPAID",
          condition: "Principal balance reduced to £0 on or before maturity date",
          responsibleParty: "PARTY-BORROWER",
          executableConsequence: "Release security charges and mark contract fulfilled",
          isAutomated: true,
        },
      ],
    },
    cash_flows: [
      {
        id: "CF-01",
        date: "2026-09-10",
        payerId: "PARTY-LENDER",
        payeeId: "PARTY-BORROWER",
        payerName: "Caledonian Capital",
        payeeName: "Apex Meridian",
        type: "PRINCIPAL_DISBURSEMENT",
        amount: 25000000,
        currency: "GBP",
        status: "SETTLED",
        obligationId: "OBL-03",
        clauseRef: "Clause 05",
      },
      {
        id: "CF-02",
        date: "2026-12-10",
        payerId: "PARTY-BORROWER",
        payeeId: "PARTY-LENDER",
        payerName: "Apex Meridian",
        payeeName: "Caledonian Capital",
        type: "INTEREST_COUPON",
        amount: 433400.68,
        calculatedRate: 6.9345, // SONIA (5.1845%) + 1.75%
        currency: "GBP",
        status: "PROJECTED",
        obligationId: "OBL-05",
        clauseRef: "Clause 07",
      },
      {
        id: "CF-03",
        date: "2027-03-10",
        payerId: "PARTY-BORROWER",
        payeeId: "PARTY-LENDER",
        payerName: "Apex Meridian",
        payeeName: "Caledonian Capital",
        type: "INTEREST_COUPON",
        amount: 428630.14,
        calculatedRate: 6.9345,
        currency: "GBP",
        status: "PROJECTED",
        obligationId: "OBL-05",
        clauseRef: "Clause 07",
      },
      {
        id: "CF-04",
        date: "2027-06-10",
        payerId: "PARTY-BORROWER",
        payeeId: "PARTY-LENDER",
        payerName: "Apex Meridian",
        payeeName: "Caledonian Capital",
        type: "INTEREST_COUPON",
        amount: 438171.23,
        calculatedRate: 6.9345,
        currency: "GBP",
        status: "PROJECTED",
        obligationId: "OBL-05",
        clauseRef: "Clause 07",
      },
      {
        id: "CF-05",
        date: "2029-06-30",
        payerId: "PARTY-BORROWER",
        payeeId: "PARTY-LENDER",
        payerName: "Apex Meridian",
        payeeName: "Caledonian Capital",
        type: "PRINCIPAL_REPAYMENT",
        amount: 25000000,
        currency: "GBP",
        status: "PROJECTED",
        obligationId: "OBL-04",
        clauseRef: "Clause 06",
      },
    ],
    invariants: [
      {
        id: "INV-01",
        name: "Non-Negative Principal",
        description: "Outstanding facility principal balance can never become negative under any repayment or prepayment scenario.",
        formalStatement: "ASSERT outstandingPrincipal >= 0",
        smtProofMethod: "Z3_SMT_SOLVER",
        status: "PASSED",
        executionTimeMs: 14.2,
      },
      {
        id: "INV-02",
        name: "No Double Settlement",
        description: "An interest period payment cannot be settled more than once per scheduled payment date.",
        formalStatement: "ASSERT settledPaymentCount(periodIndex) <= 1",
        smtProofMethod: "SYMBOLIC_EXECUTION",
        status: "PASSED",
        executionTimeMs: 22.8,
      },
      {
        id: "INV-03",
        name: "Role Authorization Guard",
        description: "Only the designated Borrower address can invoke payment functions; only the Agent can trigger acceleration remedies.",
        formalStatement: "ASSERT msg.sender == borrower || msg.sender == agent",
        smtProofMethod: "BOUNDED_MODEL_CHECKER",
        status: "PASSED",
        executionTimeMs: 18.5,
      },
      {
        id: "INV-04",
        name: "Maturity Terminal Condition",
        description: "The contract cannot transition to MATURED state unless outstanding principal is exactly zero.",
        formalStatement: "ASSERT state == State.MATURED IMPLIES outstandingPrincipal == 0",
        smtProofMethod: "Z3_SMT_SOLVER",
        status: "PASSED",
        executionTimeMs: 11.7,
      },
      {
        id: "INV-05",
        name: "Oracle Dependency Boundedness",
        description: "Reference rate input must be strictly bounded between 0% and 30% per annum to prevent oracle flash-loan manipulation.",
        formalStatement: "ASSERT soniaRateBps >= 0 && soniaRateBps <= 3000",
        smtProofMethod: "BOUNDED_MODEL_CHECKER",
        status: "PASSED",
        executionTimeMs: 9.4,
      },
    ],
    tests: [
      {
        id: "TEST-01",
        title: "Disbursement on Valid Conditions Precedent",
        category: "HAPPY_PATH",
        givenState: "Contract in APPROVED state with CP evidence signed",
        whenEvent: "Lender deposits £25,000,000 to facility escrow",
        thenExpected: "State shifts to PERFORMING, Borrower wallet receives £25M, accrual clock starts",
        status: "PASSED",
        gasEstimate: 84210,
        solidityCode: `function test_DisbursementHappyPath() public {
    vm.prank(agent);
    loan.verifyConditionsPrecedent();
    vm.deal(lender, 25000000 ether);
    vm.prank(lender);
    loan.disbursePrincipal{value: 25000000 ether}();
    assertEq(uint(loan.currentState()), uint(ExecutableLoan.State.PERFORMING));
}`,
      },
      {
        id: "TEST-02",
        title: "Quarterly Interest Payment Calculation",
        category: "HAPPY_PATH",
        givenState: "Loan in PERFORMING state for 91 days",
        whenEvent: "Borrower pays interest with SONIA fixed at 5.1845% + 1.75% margin",
        thenExpected: "Interest obligation marked SETTLED, receipt recorded, state remains PERFORMING",
        status: "PASSED",
        gasEstimate: 62190,
        solidityCode: `function test_PayQuarterlyInterest() public {
    // Warp 91 days
    vm.warp(block.timestamp + 91 days);
    uint256 expectedInterest = loan.calculateAccruedInterest(518); // 5.18%
    vm.deal(borrower, expectedInterest);
    vm.prank(borrower);
    loan.payQuarterlyInterest{value: expectedInterest}(518);
    assertEq(loan.lastSettledPeriod(), 1);
}`,
      },
      {
        id: "TEST-03",
        title: "Late Payment Default Trigger past 3 Days Grace",
        category: "DEFAULT",
        givenState: "Interest payment due at timestamp T",
        whenEvent: "Timestamp reaches T + 4 days with zero payment recorded",
        thenExpected: "Agent executes triggerDefault(); contract shifts to EVENT_OF_DEFAULT",
        status: "PASSED",
        gasEstimate: 48900,
        solidityCode: `function test_DefaultAfterGracePeriod() public {
    vm.warp(block.timestamp + 95 days); // 4 days overdue
    vm.prank(agent);
    loan.triggerDefault();
    assertEq(uint(loan.currentState()), uint(ExecutableLoan.State.EVENT_OF_DEFAULT));
}`,
      },
      {
        id: "TEST-04",
        title: "Unauthorised Prepayment Rejection",
        category: "INVALID_INPUT",
        givenState: "Loan in PERFORMING state",
        whenEvent: "Third party attempts prepayment with non-multiple chunk (£750k)",
        thenExpected: "Transaction reverts with InvalidPrepaymentMultiple error",
        status: "PASSED",
        gasEstimate: 21300,
        solidityCode: `function testRevert_InvalidPrepaymentChunk() public {
    vm.prank(stranger);
    vm.expectRevert("LEX: Only borrower");
    loan.prepayLoan(750000 ether);
}`,
      },
    ],
    generated_solidity: {
      contractName: "ExecutableCommercialLoan",
      compilerVersion: "0.8.28",
      bytecodeHash: "0x8f192837bcde8192a837482910fa728198f4e229a7cb81dc710928aee91b9487",
      securityGatePassed: true,
      securityFindings: [
        {
          id: "SEC-01",
          severity: "INFO",
          title: "Reentrancy Guard Implemented",
          description: "All external value transfers use OpenZeppelin ReentrancyGuard nonReentrant modifier.",
          mitigation: "Verified clean execution ordering checks-effects-interactions.",
        },
        {
          id: "SEC-02",
          severity: "LOW",
          title: "Oracle Ingestion Timestamp Verification",
          description: "Reference rate parameter accepts max 24hr freshness signature.",
          mitigation: "Stale data checks enforced in require block.",
        },
      ],
      sourceCode: `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC LEGAL COMPILER v3.7
// PROVENANCE: Derived from Agreement LEX-2026-000184 (Governing Law: England & Wales)
// WARNING: Legal review required before mainnet execution.
pragma solidity ^0.8.28;

/**
 * @title ExecutableCommercialLoan
 * @notice Formal machine-executable implementation of £25M Facility Agreement (LEX-2026-000184)
 * @dev Legal Layer Clause 07 & Clause 10 mapped directly to state transitions
 */
contract ExecutableCommercialLoan {

    enum State {
        DRAFT,
        LEGAL_REVIEW,
        APPROVED,
        SIGNED,
        EFFECTIVE,
        PERFORMING,
        EVENT_OF_DEFAULT,
        REMEDY_PERIOD,
        ACCELERATED,
        DISPUTE,
        MATURED,
        TERMINATED
    }

    // ================= CONTRACT PARTIES (Clause 01) =================
    address public immutable borrower;
    address public immutable lender;
    address public immutable facilityAgent;

    // ================= FINANCIAL TERMS (Clause 03, 06, 07) =================
    uint256 public constant PRINCIPAL_NOTIONAL = 25000000 * 10**18; // £25M
    uint256 public constant SPREAD_BPS = 175; // 1.75% Margin
    uint256 public constant GRACE_PERIOD_SECONDS = 3 days;
    uint256 public immutable maturityTimestamp;
    
    uint256 public outstandingPrincipal;
    uint256 public nextPaymentDueTimestamp;
    uint256 public currentPeriodIndex;
    State public currentState;
    bool public isEmergencyPaused;

    // ================= EVENTS (Provable Execution Trail) =================
    event StateChanged(State indexed previousState, State indexed newState, string reason);
    event PrincipalDisbursed(address indexed lender, address indexed borrower, uint256 amount);
    event InterestPaid(uint256 indexed period, uint256 amount, uint256 soniaRateBps);
    event DefaultDeclared(address indexed triggeredBy, string reason);
    event LoanAccelerated(uint256 totalAmountClaimed);

    modifier onlyBorrower() {
        require(msg.sender == borrower, "LEX: Only Borrower authorised");
        _;
    }

    modifier onlyLender() {
        require(msg.sender == lender, "LEX: Only Lender authorised");
        _;
    }

    modifier onlyAgent() {
        require(msg.sender == facilityAgent, "LEX: Only Facility Agent authorised");
        _;
    }

    modifier inState(State expected) {
        require(currentState == expected, "LEX: Invalid state transition");
        _;
    }

    modifier notPaused() {
        require(!isEmergencyPaused, "LEX: Automated execution paused for legal review");
        _;
    }

    constructor(
        address _borrower,
        address _lender,
        address _agent,
        uint256 _maturityTimestamp
    ) {
        require(_borrower != address(0) && _lender != address(0), "LEX: Invalid party address");
        borrower = _borrower;
        lender = _lender;
        facilityAgent = _agent;
        maturityTimestamp = _maturityTimestamp;
        currentState = State.APPROVED;
    }

    /**
     * @notice Enforces Clause 05 (Principal Disbursement)
     */
    function disbursePrincipal() external payable onlyLender inState(State.APPROVED) {
        require(msg.value == PRINCIPAL_NOTIONAL, "LEX: Incorrect notional amount");
        outstandingPrincipal = PRINCIPAL_NOTIONAL;
        currentState = State.PERFORMING;
        nextPaymentDueTimestamp = block.timestamp + 90 days;
        
        (bool sent, ) = payable(borrower).call{value: msg.value}("");
        require(sent, "LEX: Transfer to borrower failed");
        
        emit PrincipalDisbursed(lender, borrower, msg.value);
        emit StateChanged(State.APPROVED, State.PERFORMING, "Principal disbursed");
    }

    /**
     * @notice Enforces Clause 07 (Quarterly Interest Payment)
     * @param soniaRateBps Reference rate in basis points (e.g. 518 for 5.18%)
     */
    function payQuarterlyInterest(uint256 soniaRateBps) 
        external 
        payable 
        onlyBorrower 
        inState(State.PERFORMING) 
        notPaused 
    {
        require(soniaRateBps <= 3000, "LEX: Rate outside sanity bounds");
        uint256 totalRateBps = soniaRateBps + SPREAD_BPS;
        uint256 expectedInterest = (outstandingPrincipal * totalRateBps * 90) / (365 * 10000);
        
        require(msg.value >= expectedInterest, "LEX: Insufficient interest payment");
        
        (bool sent, ) = payable(lender).call{value: msg.value}("");
        require(sent, "LEX: Transfer to lender failed");

        currentPeriodIndex++;
        nextPaymentDueTimestamp = block.timestamp + 90 days;
        emit InterestPaid(currentPeriodIndex, msg.value, soniaRateBps);
    }

    /**
     * @notice Enforces Clause 10 (Events of Default)
     */
    function triggerDefault() external onlyAgent inState(State.PERFORMING) {
        require(block.timestamp > nextPaymentDueTimestamp + GRACE_PERIOD_SECONDS, "LEX: Grace period active");
        currentState = State.EVENT_OF_DEFAULT;
        emit DefaultDeclared(msg.sender, "Overdue payment past 3-day grace period");
        emit StateChanged(State.PERFORMING, State.EVENT_OF_DEFAULT, "Payment default");
    }

    /**
     * @notice Enforces Clause 11 (Remedies and Acceleration)
     */
    function accelerateLoanRemedy() external onlyAgent inState(State.EVENT_OF_DEFAULT) {
        currentState = State.ACCELERATED;
        emit LoanAccelerated(outstandingPrincipal);
        emit StateChanged(State.EVENT_OF_DEFAULT, State.ACCELERATED, "Acceleration notice served");
    }

    /**
     * @notice Enforces Clause 14 (Human Dispute & Pause Override)
     */
    function setEmergencyPause(bool paused) external onlyAgent {
        isEmergencyPaused = paused;
    }
}`,
    },
    governance: {
      requiredApprovals: [
        { role: "LAWYER", approved: true, approvedBy: "Sarah Jenkins, Partner (Linklaters Synthetic)", timestamp: "2026-09-06T11:00:00Z" },
        { role: "CONTRACT_ENGINEER", approved: true, approvedBy: "Dr. Ryan Vance, Lead Formal Methods", timestamp: "2026-09-06T14:30:00Z" },
        { role: "COMPLIANCE_OFFICER", approved: true, approvedBy: "FCA Institutional Compliance Gate", timestamp: "2026-09-06T16:00:00Z" },
        { role: "APPROVER", approved: true, approvedBy: "Credit Committee Resolution #8491", timestamp: "2026-09-07T09:00:00Z" },
      ],
      isDeployable: true,
    },
  },

  // 2. BILATERAL REPURCHASE AGREEMENT (REPO)
  {
    contract_id: "LEX-2026-000186",
    title: "Global Master Repurchase Agreement (Bilateral Repo)",
    version: "2.1.0",
    governing_law: "England and Wales",
    dispute_forum: "London Court of International Arbitration (LCIA)",
    currentState: "PERFORMING",
    created_at: "2026-09-12T09:00:00Z",
    updated_at: "2026-09-22T08:00:00Z",
    legalReviewRequired: true,
    parties: [
      {
        id: "PARTY-BUYER",
        legalName: "Sterling Sovereign Liquidity Fund Ltd",
        jurisdiction: "England and Wales",
        registrationId: "UK-CO-11029481",
        lei: "213800REPOLIQUID9876",
        role: "BUYER",
        address: "1 Churchill Place, London E14 5HP",
        authorizedSignatories: [{ name: "Charles Montgomery", title: "Head of Repo Trading", email: "c.montgomery@sterlingsl.com", hasSigned: true }],
        identityProvider: "Bank of England CREST Settler",
        settlementAccount: "GB88STER90000012847192",
        walletAddress: "0x1234567890123456789012345678901234567890",
        kycStatus: "VERIFIED",
      },
      {
        id: "PARTY-SELLER",
        legalName: "Apex Prime Brokerage & Securities Services Plc",
        jurisdiction: "England and Wales",
        registrationId: "UK-CO-08492019",
        lei: "213800APEXPRIME84729",
        role: "SELLER",
        address: "25 Ropemaker Street, London EC2Y 9LY",
        authorizedSignatories: [{ name: "Samantha Hughes", title: "Treasurer", email: "s.hughes@apexprime.com", hasSigned: true }],
        identityProvider: "Euroclear / Clearstream Custody",
        settlementAccount: "GB44APEX40000084729103",
        walletAddress: "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
        kycStatus: "VERIFIED",
      },
    ],
    definitions: [
      {
        id: "DEF-REPO-01",
        term: "Repurchase Price",
        definitionText: "Purchase Price plus Repurchase Rate accrued on actual/365 basis.",
        structuredType: "formula",
        jurisdiction: "London",
        source: "ICMA GMRA 2011",
        parameters: { purchasePrice: 10000000, repurchasePrice: 10043150.68 },
      },
      {
        id: "DEF-REPO-02",
        term: "Haircut",
        definitionText: "20.00% initial margin deduction applied to the market value of Eligible Collateral.",
        structuredType: "formula",
        jurisdiction: "United Kingdom",
        source: "Schedule Annex 1",
        parameters: { haircutPct: 20 },
      },
    ],
    clauses: [
      {
        id: "CLAUSE-REPO-01",
        sectionNumber: "01",
        title: "Purchase and Sale of Securities",
        legalText: "Seller agrees to sell to Buyer, and Buyer agrees to purchase from Seller, Eligible UK Gilt Securities against payment of the Purchase Price of £10,000,000 on the Purchase Date.",
        formalSummary: "Initial purchase: £10M cash for £12.5M UK Gilts (20% haircut).",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-REPO-01"],
      },
      {
        id: "CLAUSE-REPO-02",
        sectionNumber: "02",
        title: "Repurchase Obligation",
        legalText: "Seller agrees to repurchase from Buyer, and Buyer agrees to sell to Seller, Equivalent Securities on the Repurchase Date (30 October 2026) against payment of the Repurchase Price (£10,043,150.68).",
        formalSummary: "Repurchase on 30 Oct 2026 at agreed repo rate.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-REPO-02"],
      },
      {
        id: "CLAUSE-REPO-03",
        sectionNumber: "03",
        title: "Daily Margin Maintenance & Haircut",
        legalText: "If on any Business Day the Net Exposure of either party exceeds the Transaction Threshold, the party with the deficit shall transfer Margin Securities or Cash within 24 hours of notice.",
        formalSummary: "Daily MTM margin call if effective collateral drops below £10M.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-REPO-03"],
      },
    ],
    obligations: [
      {
        id: "OBL-REPO-01",
        clauseRef: "Clause 01",
        type: "OBLIGATION",
        actorPartyId: "PARTY-BUYER",
        counterpartyId: "PARTY-SELLER",
        action: "Transfer Purchase Price",
        objectDescription: "£10,000,000 cash for £12,500,000 UK Gilt 10Y Collateral",
        amount: 10000000,
        currency: "GBP",
        isAutomated: true,
        executionFunction: "executeInitialExchange()",
        verificationStatus: "VERIFIED",
        formalLogic: "COLLATERAL_POSTED(12.5M Gilt) && CASH_TRANSFERRED(10M GBP)",
      },
      {
        id: "OBL-REPO-02",
        clauseRef: "Clause 02",
        type: "OBLIGATION",
        actorPartyId: "PARTY-SELLER",
        counterpartyId: "PARTY-BUYER",
        action: "Repurchase Equivalent Securities",
        objectDescription: "Pay Repurchase Price £10,043,150.68 to receive Gilts back",
        amount: 10043150.68,
        currency: "GBP",
        deadline: "2026-10-30",
        isAutomated: true,
        executionFunction: "settleRepurchase()",
        verificationStatus: "VERIFIED",
        formalLogic: "CASH_RETURNED(10.043M) => COLLATERAL_RELEASED(Seller)",
      },
      {
        id: "OBL-REPO-03",
        clauseRef: "Clause 03",
        type: "OBLIGATION",
        actorPartyId: "PARTY-SELLER",
        counterpartyId: "PARTY-BUYER",
        action: "Post Variation Margin on Deficit",
        objectDescription: "Deliver additional cash or gilts if MTM drops below required margin",
        currency: "GBP",
        frequency: "ON_DEMAND",
        isAutomated: true,
        executionFunction: "postVariationMargin(uint256 amount)",
        verificationStatus: "VERIFIED",
        formalLogic: "IF (effectiveCollateral < notional) => MUST_POST_MARGIN(diff)",
      },
    ],
    financial_terms: {
      category: "REPO",
      notional: 10000000,
      currency: "GBP",
      startDate: "2026-09-15",
      maturityDate: "2026-10-30",
      dayCountConvention: "ACT/365F",
      paymentFrequency: "At Maturity",
      fixedRatePercent: 5.25,
      businessDayAdjustment: "Following",
      collateralAsset: "UK Gilt 10Y Benchmark (GB00B24FF097)",
      collateralQuantity: 12500000,
      collateralValuation: 12500000,
      haircutPercent: 20,
      repurchasePrice: 10043150.68,
    },
    state_machine: {
      states: ["DRAFT", "APPROVED", "SIGNED", "PERFORMING", "EVENT_OF_DEFAULT", "MATURED"],
      transitions: [
        {
          id: "T-REPO-1",
          fromState: "APPROVED",
          toState: "PERFORMING",
          triggerEvent: "COLLATERAL_AND_CASH_DELIVERED",
          condition: "DvP settlement confirmed",
          responsibleParty: "PARTY-BUYER",
          executableConsequence: "Lock collateral in escrow contract",
          isAutomated: true,
        },
      ],
    },
    cash_flows: [
      {
        id: "CF-R1",
        date: "2026-09-15",
        payerId: "PARTY-BUYER",
        payeeId: "PARTY-SELLER",
        payerName: "Sterling Liquidity",
        payeeName: "Apex Prime",
        type: "PRINCIPAL_DISBURSEMENT",
        amount: 10000000,
        currency: "GBP",
        status: "SETTLED",
        obligationId: "OBL-REPO-01",
        clauseRef: "Clause 01",
      },
      {
        id: "CF-R2",
        date: "2026-10-30",
        payerId: "PARTY-SELLER",
        payeeId: "PARTY-BUYER",
        payerName: "Apex Prime",
        payeeName: "Sterling Liquidity",
        type: "PRINCIPAL_REPAYMENT",
        amount: 10043150.68,
        currency: "GBP",
        status: "PROJECTED",
        obligationId: "OBL-REPO-02",
        clauseRef: "Clause 02",
      },
    ],
    invariants: [
      {
        id: "INV-R1",
        name: "Collateral Value Coverage",
        description: "Effective collateral after haircut must satisfy the £10M purchase price.",
        formalStatement: "ASSERT collateralMarketValue * 0.80 >= notional",
        smtProofMethod: "Z3_SMT_SOLVER",
        status: "PASSED",
        executionTimeMs: 12.1,
      },
    ],
    tests: [
      {
        id: "TEST-REPO-01",
        title: "Margin Deficit Call Simulation",
        category: "BOUNDARY",
        givenState: "Gilt market price drops by 8%",
        whenEvent: "Oracle updates Gilt valuation to £11.5M (Effective = £9.2M)",
        thenExpected: "System issues £800,000 Margin Call obligation to Seller",
        status: "PASSED",
        gasEstimate: 51200,
        solidityCode: `function test_MarginCallOnGiltDrop() public {
    repo.updateCollateralValuation(11500000 ether);
    assertEq(repo.isMarginDeficit(), true);
    assertEq(repo.getMarginDeficitAmount(), 800000 ether);
}`,
      },
    ],
    generated_solidity: {
      contractName: "ExecutableGMRA",
      compilerVersion: "0.8.28",
      bytecodeHash: "0x3892bcde710928aee91b9487c9102837bcde8192a837482910fa728198f4e229",
      securityGatePassed: true,
      securityFindings: [],
      sourceCode: `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC REPO COMPILER
pragma solidity ^0.8.28;

contract ExecutableGMRA {
    address public buyer;
    address public seller;
    uint256 public constant PURCHASE_PRICE = 10000000 * 10**18;
    uint256 public constant HAIRCUT_BPS = 2000; // 20%
    uint256 public collateralValuation = 12500000 * 10**18;

    function getEffectiveCollateral() public view returns (uint256) {
        return (collateralValuation * (10000 - HAIRCUT_BPS)) / 10000;
    }

    function isMarginDeficit() public view returns (bool) {
        return getEffectiveCollateral() < PURCHASE_PRICE;
    }
}`,
    },
    governance: {
      requiredApprovals: [
        { role: "LAWYER", approved: true, approvedBy: "Clifford Chance Synthetic", timestamp: "2026-09-13T10:00:00Z" },
        { role: "RISK_OFFICER", approved: true, approvedBy: "Chief Collateral Risk Officer", timestamp: "2026-09-13T11:30:00Z" },
      ],
      isDeployable: true,
    },
  },

  // 3. CORPORATE BOND INDENTURE
  {
    contract_id: "LEX-2026-000185",
    title: "£50,000,000 5.850% Senior Fixed Rate Bonds due 2031",
    version: "1.2.0",
    governing_law: "England and Wales",
    dispute_forum: "High Court of Justice, London",
    currentState: "PERFORMING",
    created_at: "2026-08-15T12:00:00Z",
    updated_at: "2026-09-20T10:00:00Z",
    legalReviewRequired: true,
    parties: [
      {
        id: "PARTY-ISSUER",
        legalName: "Britannia Energy Infrastructure Finance Plc",
        jurisdiction: "England and Wales",
        registrationId: "UK-CO-07891234",
        role: "ISSUER",
        address: "10 Paternoster Square, London EC4M 7LS",
        authorizedSignatories: [{ name: "Sir Richard Thorne", title: "Chief Executive Officer", email: "r.thorne@britanniaenergy.com", hasSigned: true }],
        identityProvider: "London Stock Exchange Regulated Issuer",
        settlementAccount: "GB91BRIT10000092837461",
        walletAddress: "0x5555555555555555555555555555555555555555",
        kycStatus: "VERIFIED",
      },
      {
        id: "PARTY-TRUSTEE",
        legalName: "Law Debenture Trust Corporation Plc",
        jurisdiction: "England and Wales",
        registrationId: "UK-CO-00123456",
        role: "TRUSTEE",
        address: "8th Floor, 100 Bishopsgate, London EC2N 4AG",
        authorizedSignatories: [{ name: "Gillian Ward", title: "Senior Trust Director", email: "g.ward@lawdeb.com", hasSigned: true }],
        identityProvider: "UK Corporate Trustee Association",
        settlementAccount: "GB33LAWD90000081726354",
        walletAddress: "0x6666666666666666666666666666666666666666",
        kycStatus: "VERIFIED",
      },
    ],
    definitions: [
      {
        id: "DEF-BOND-01",
        term: "Coupon Rate",
        definitionText: "5.850 per cent per annum payable annually in arrear on 15 December in each year.",
        structuredType: "formula",
        jurisdiction: "England and Wales",
        source: "Prospectus Terms",
        parameters: { fixedRate: 5.85 },
      },
    ],
    clauses: [
      {
        id: "CL-BOND-01",
        sectionNumber: "01",
        title: "Aggregate Nominal Amount and Form",
        legalText: "The initial aggregate nominal amount of the Bonds is £50,000,000 represented by registered bond certificates in denominations of £100,000 each.",
        formalSummary: "£50M total nominal in £100k denominations.",
        ambiguities: [],
        severity: "NONE",
        status: "APPROVED",
        isOperative: true,
        relatedObligationIds: ["OBL-BOND-01"],
      },
    ],
    obligations: [
      {
        id: "OBL-BOND-01",
        clauseRef: "Clause 01",
        type: "OBLIGATION",
        actorPartyId: "PARTY-ISSUER",
        counterpartyId: "PARTY-TRUSTEE",
        action: "Pay Annual Fixed Coupon",
        objectDescription: "£2,925,000 annual coupon (£50M × 5.850%)",
        amount: 2925000,
        currency: "GBP",
        frequency: "ANNUALLY",
        isAutomated: true,
        executionFunction: "distributeCoupon()",
        verificationStatus: "VERIFIED",
        formalLogic: "coupon == notional * 0.0585",
      },
    ],
    financial_terms: {
      category: "BOND",
      notional: 50000000,
      currency: "GBP",
      startDate: "2026-08-15",
      maturityDate: "2031-12-15",
      dayCountConvention: "ACT/ACT",
      paymentFrequency: "Annually",
      fixedRatePercent: 5.85,
      businessDayAdjustment: "Following",
    },
    state_machine: {
      states: ["DRAFT", "APPROVED", "PERFORMING", "MATURED"],
      transitions: [],
    },
    cash_flows: [],
    invariants: [],
    tests: [],
    generated_solidity: {
      contractName: "ExecutableBondIndenture",
      compilerVersion: "0.8.28",
      bytecodeHash: "0x1111111111111111111111111111111111111111111111111111111111111111",
      securityGatePassed: true,
      securityFindings: [],
      sourceCode: `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC BOND COMPILER\ncontract ExecutableBondIndenture {}`,
    },
    governance: { requiredApprovals: [], isDeployable: true },
  },

  // 4. ISDA INTEREST RATE SWAP
  {
    contract_id: "LEX-2026-000187",
    title: "ISDA Master Confirmation — £100M SONIA Floating/Fixed Interest Rate Swap",
    version: "1.0.0",
    governing_law: "New York",
    dispute_forum: "US District Court for the Southern District of New York (SDNY)",
    currentState: "PERFORMING",
    created_at: "2026-09-02T14:00:00Z",
    updated_at: "2026-09-22T08:00:00Z",
    legalReviewRequired: true,
    parties: [
      {
        id: "PARTY-SWAP-A",
        legalName: "Manhattan Global Derivatives LLC",
        jurisdiction: "Delaware / New York",
        registrationId: "DE-LLC-8921049",
        role: "BANK",
        address: "200 West Street, New York, NY 10282",
        authorizedSignatories: [{ name: "Jonathan Miller", title: "Head of Swaps Trading", email: "j.miller@manhattanglobal.com", hasSigned: true }],
        identityProvider: "CFTC Registered Swap Dealer",
        settlementAccount: "US99MANH10000091827364",
        walletAddress: "0x7777777777777777777777777777777777777777",
        kycStatus: "VERIFIED",
      },
      {
        id: "PARTY-SWAP-B",
        legalName: "European Pension Asset Management SA",
        jurisdiction: "Luxembourg",
        registrationId: "LU-B-192837",
        role: "FUND",
        address: "44 Avenue J.F. Kennedy, L-1855 Luxembourg",
        authorizedSignatories: [{ name: "Dr. Henri Dupont", title: "Chief Investment Officer", email: "h.dupont@euro-pension.lu", hasSigned: true }],
        identityProvider: "CSSF Regulated Supervised Entity",
        settlementAccount: "LU12EPAM80000019283746",
        walletAddress: "0x8888888888888888888888888888888888888888",
        kycStatus: "VERIFIED",
      },
    ],
    definitions: [],
    clauses: [],
    obligations: [
      {
        id: "OBL-SWAP-01",
        clauseRef: "Confirmation Section 2",
        type: "OBLIGATION",
        actorPartyId: "PARTY-SWAP-A",
        counterpartyId: "PARTY-SWAP-B",
        action: "Quarterly Net Settlement",
        objectDescription: "Net difference between Fixed 4.50% and SONIA Floating Rate on £100M",
        currency: "GBP",
        frequency: "QUARTERLY",
        isAutomated: true,
        executionFunction: "settleNetSwapCashflow()",
        verificationStatus: "VERIFIED",
        formalLogic: "net_payment = notional * (fixed_rate - floating_oracle) * (days / 365)",
      },
    ],
    financial_terms: {
      category: "INTEREST_RATE_SWAP",
      notional: 100000000,
      currency: "GBP",
      startDate: "2026-09-15",
      maturityDate: "2031-09-15",
      dayCountConvention: "ACT/365F",
      paymentFrequency: "Quarterly",
      fixedRatePercent: 4.5,
      referenceRateName: "SONIA",
      businessDayAdjustment: "Modified Following",
    },
    state_machine: { states: ["APPROVED", "PERFORMING"], transitions: [] },
    cash_flows: [],
    invariants: [],
    tests: [],
    generated_solidity: {
      contractName: "ExecutableISDASwap",
      compilerVersion: "0.8.28",
      bytecodeHash: "0x2222222222222222222222222222222222222222222222222222222222222222",
      securityGatePassed: true,
      securityFindings: [],
      sourceCode: `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC SWAP COMPILER\ncontract ExecutableISDASwap {}`,
    },
    governance: { requiredApprovals: [], isDeployable: true },
  },

  // 5. MILESTONE ESCROW AGREEMENT
  {
    contract_id: "LEX-2026-000188",
    title: "Tri-Party Software IP & Commercial Development Escrow Agreement",
    version: "1.1.0",
    governing_law: "Delaware",
    dispute_forum: "Delaware Court of Chancery",
    currentState: "PERFORMING",
    created_at: "2026-09-08T11:00:00Z",
    updated_at: "2026-09-22T08:00:00Z",
    legalReviewRequired: true,
    parties: [
      {
        id: "PARTY-ESCROW-DEP",
        legalName: "Enterprise Cloud Systems Inc.",
        jurisdiction: "Delaware",
        registrationId: "DE-CORP-4829104",
        role: "INVESTOR",
        address: "1209 North Orange Street, Wilmington, DE 19801",
        authorizedSignatories: [{ name: "Rachel Adams", title: "VP Engineering", email: "r.adams@enterprisecloud.io", hasSigned: true }],
        identityProvider: "Delaware Division of Corporations",
        settlementAccount: "US44ENTC80000019284729",
        walletAddress: "0x9999999999999999999999999999999999999999",
        kycStatus: "VERIFIED",
      },
      {
        id: "PARTY-ESCROW-BEN",
        legalName: "Quantum AI Core Labs Ltd",
        jurisdiction: "England and Wales",
        registrationId: "UK-CO-12948201",
        role: "ISSUER",
        address: "Silicon Roundabout, London EC1V 1AB",
        authorizedSignatories: [{ name: "Dr. Kenji Sato", title: "Chief Technology Officer", email: "k.sato@quantumai.io", hasSigned: true }],
        identityProvider: "UK Companies House",
        settlementAccount: "GB88QNTM90000018273645",
        walletAddress: "0xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
        kycStatus: "VERIFIED",
      },
    ],
    definitions: [],
    clauses: [],
    obligations: [
      {
        id: "OBL-ESC-01",
        clauseRef: "Clause 04",
        type: "OBLIGATION",
        actorPartyId: "PARTY-ESCROW-DEP",
        counterpartyId: "PARTY-ESCROW-BEN",
        action: "Release Milestone 1 Funds",
        objectDescription: "Release £1,000,000 (30%) upon Architecture Validation",
        amount: 1000000,
        currency: "GBP",
        isAutomated: true,
        executionFunction: "releaseMilestone(1)",
        verificationStatus: "VERIFIED",
        formalLogic: "milestone_approved(1) => transfer(ben, 1000000)",
      },
    ],
    financial_terms: {
      category: "ESCROW",
      notional: 3500000,
      currency: "GBP",
      startDate: "2026-09-08",
      maturityDate: "2027-03-31",
      dayCountConvention: "ACT/365F",
      paymentFrequency: "At Maturity",
      businessDayAdjustment: "Following",
      milestones: [
        { id: "M1", description: "Architecture Specification & Security Audit Sign-off", percentage: 30, amount: 1050000, approverPartyId: "PARTY-ESCROW-DEP", isReleased: true },
        { id: "M2", description: "Core Compiler Engine Integration & Test Harness", percentage: 40, amount: 1400000, approverPartyId: "PARTY-ESCROW-DEP", isReleased: false },
        { id: "M3", description: "Production Deployment & Acceptance Testing", percentage: 30, amount: 1050000, approverPartyId: "PARTY-ESCROW-DEP", isReleased: false },
      ],
    },
    state_machine: { states: ["APPROVED", "PERFORMING"], transitions: [] },
    cash_flows: [],
    invariants: [],
    tests: [],
    generated_solidity: {
      contractName: "ExecutableEscrow",
      compilerVersion: "0.8.28",
      bytecodeHash: "0x3333333333333333333333333333333333333333333333333333333333333333",
      securityGatePassed: true,
      securityFindings: [],
      sourceCode: `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC ESCROW COMPILER\ncontract ExecutableEscrow {}`,
    },
    governance: { requiredApprovals: [], isDeployable: true },
  },

  // 6. TOKENISED ASSET SALE & SETTLEMENT
  {
    contract_id: "LEX-2026-000189",
    title: "Tokenised Real Estate Security (ERC-3643) Transfer & DvP Agreement",
    version: "1.0.0",
    governing_law: "Switzerland",
    dispute_forum: "Commercial Court of Zurich (Handelsgericht Zürich)",
    currentState: "APPROVED",
    created_at: "2026-09-14T09:30:00Z",
    updated_at: "2026-09-22T08:00:00Z",
    legalReviewRequired: true,
    parties: [],
    definitions: [],
    clauses: [],
    obligations: [],
    financial_terms: {
      category: "TOKENISED_ASSET",
      notional: 12000000,
      currency: "CHF",
      startDate: "2026-09-20",
      maturityDate: "2026-10-20",
      dayCountConvention: "ACT/365F",
      paymentFrequency: "At Maturity",
      businessDayAdjustment: "Following",
    },
    state_machine: { states: ["DRAFT", "APPROVED"], transitions: [] },
    cash_flows: [],
    invariants: [],
    tests: [],
    generated_solidity: {
      contractName: "ExecutableTokenisedAssetSale",
      compilerVersion: "0.8.28",
      bytecodeHash: "0x4444444444444444444444444444444444444444444444444444444444444444",
      securityGatePassed: true,
      securityFindings: [],
      sourceCode: `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC TOKENISATION COMPILER\ncontract ExecutableTokenisedAssetSale {}`,
    },
    governance: { requiredApprovals: [], isDeployable: true },
  },

  // 7. CROSS-BORDER TRADE FINANCE LETTER OF CREDIT
  {
    contract_id: "LEX-2026-000190",
    title: "Documentary Letter of Credit & Shipping Release (UCP 600)",
    version: "1.0.0",
    governing_law: "Singapore",
    dispute_forum: "Singapore International Arbitration Centre (SIAC)",
    currentState: "PERFORMING",
    created_at: "2026-09-16T08:00:00Z",
    updated_at: "2026-09-22T08:00:00Z",
    legalReviewRequired: true,
    parties: [],
    definitions: [],
    clauses: [],
    obligations: [],
    financial_terms: {
      category: "TRADE_FINANCE",
      notional: 4800000,
      currency: "USD",
      startDate: "2026-09-16",
      maturityDate: "2026-11-30",
      dayCountConvention: "ACT/360",
      paymentFrequency: "At Maturity",
      businessDayAdjustment: "Following",
    },
    state_machine: { states: ["APPROVED", "PERFORMING"], transitions: [] },
    cash_flows: [],
    invariants: [],
    tests: [],
    generated_solidity: {
      contractName: "ExecutableTradeFinanceLC",
      compilerVersion: "0.8.28",
      bytecodeHash: "0x5555555555555555555555555555555555555555555555555555555555555555",
      securityGatePassed: true,
      securityFindings: [],
      sourceCode: `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC TRADE FINANCE\ncontract ExecutableTradeFinanceLC {}`,
    },
    governance: { requiredApprovals: [], isDeployable: true },
  },

  // 8. DELIVERABLE FX FORWARD
  {
    contract_id: "LEX-2026-000191",
    title: "Institutional Deliverable FX Forward Confirmation (GBP/USD)",
    version: "1.0.0",
    governing_law: "England and Wales",
    dispute_forum: "High Court of Justice, London",
    currentState: "PERFORMING",
    created_at: "2026-09-18T10:00:00Z",
    updated_at: "2026-09-22T08:00:00Z",
    legalReviewRequired: true,
    parties: [],
    definitions: [],
    clauses: [],
    obligations: [],
    financial_terms: {
      category: "FX_FORWARD",
      notional: 15000000,
      currency: "GBP",
      baseCurrency: "GBP",
      quoteCurrency: "USD",
      forwardRate: 1.3145,
      startDate: "2026-09-18",
      maturityDate: "2026-12-31",
      dayCountConvention: "ACT/365F",
      paymentFrequency: "At Maturity",
      businessDayAdjustment: "Following",
    },
    state_machine: { states: ["APPROVED", "PERFORMING"], transitions: [] },
    cash_flows: [],
    invariants: [],
    tests: [],
    generated_solidity: {
      contractName: "ExecutableFXForward",
      compilerVersion: "0.8.28",
      bytecodeHash: "0x6666666666666666666666666666666666666666666666666666666666666666",
      securityGatePassed: true,
      securityFindings: [],
      sourceCode: `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC FX FORWARD\ncontract ExecutableFXForward {}`,
    },
    governance: { requiredApprovals: [], isDeployable: true },
  },
];
