import React, { useState } from "react";
import { Header } from "./components/layout/Header";
import { DisclaimerBanner } from "./components/layout/DisclaimerBanner";
import { ContractWorkspaceView } from "./components/workspace/ContractWorkspaceView";
import { SimulationView } from "./components/views/SimulationView";
import { VerificationView } from "./components/views/VerificationView";
import { ParityMatrixView } from "./components/views/ParityMatrixView";
import { ContractsListView } from "./components/views/ContractsListView";
import { TemplatesView } from "./components/views/TemplatesView";
import { ExecutionMonitorView } from "./components/views/ExecutionMonitorView";
import { PartiesRegistryView } from "./components/views/PartiesRegistryView";
import { AssetsCollateralView } from "./components/views/AssetsCollateralView";
import { AuditTrailView } from "./components/views/AuditTrailView";
import { DeploymentsView } from "./components/views/DeploymentsView";
import { OraclesView } from "./components/views/OraclesView";
import {
  ComplianceView,
  GovernanceView,
  JurisdictionsView,
} from "./components/views/ComplianceView";
import { AiAssistantDrawer } from "./components/modals/AiAssistantDrawer";
import { DemoModeModal } from "./components/modals/DemoModeModal";
import { NewContractModal } from "./components/modals/NewContractModal";

import { SEED_CONTRACTS } from "./data/seedContracts";
import { ContractIR, ContractClause, FinancialContractCategory } from "./types/contract-ir";
import { AppView, UserRole } from "./types";
import { AuditService } from "./services/auditService";

export default function App() {
  const [contracts, setContracts] = useState<ContractIR[]>(SEED_CONTRACTS);
  const [selectedContractId, setSelectedContractId] = useState<string>("LEX-2026-000184");
  const [activeView, setActiveView] = useState<AppView>("WORKSPACE");
  const [activeRole, setActiveRole] = useState<UserRole>("LEGAL_ENGINEER");

  // Modals & Drawers state
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState<boolean>(false);
  const [isDemoModalOpen, setIsDemoModalOpen] = useState<boolean>(false);
  const [isNewContractModalOpen, setIsNewContractModalOpen] = useState<boolean>(false);
  const [focusedClause, setFocusedClause] = useState<ContractClause | null>(null);

  const selectedContract =
    contracts.find((c) => c.contract_id === selectedContractId) || contracts[0];

  const handleUpdateContract = (updated: ContractIR) => {
    setContracts((prev) =>
      prev.map((c) => (c.contract_id === updated.contract_id ? updated : c))
    );
    AuditService.logEvent({
      contractId: updated.contract_id,
      contractVersion: updated.version,
      eventType: "CLAUSE_CHANGED",
      actor: "Legal Engineering Desk",
      role: activeRole,
      description: `Contract updated: ${updated.title}`,
    });
  };

  const handleCreateContract = (newContract: ContractIR) => {
    setContracts((prev) => [newContract, ...prev]);
    setSelectedContractId(newContract.contract_id);
    setActiveView("WORKSPACE");
    AuditService.logEvent({
      contractId: newContract.contract_id,
      contractVersion: newContract.version,
      eventType: "CONTRACT_CREATED",
      actor: "Institutional Deal Origination",
      role: activeRole,
      description: `New formal contract created: ${newContract.title} (${newContract.financial_terms.category})`,
    });
  };

  const handleSelectTemplate = (category: FinancialContractCategory) => {
    const matchingSeed = contracts.find((c) => c.financial_terms.category === category);
    if (matchingSeed) {
      setSelectedContractId(matchingSeed.contract_id);
      setActiveView("WORKSPACE");
    } else {
      setIsNewContractModalOpen(true);
    }
  };

  const handleOpenAiWithClause = (clause: ContractClause) => {
    setFocusedClause(clause);
    setIsAiDrawerOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white antialiased">
      {/* Institutional Legal Disclaimer Banner */}
      <DisclaimerBanner />

      {/* Main High-Density Header */}
      <Header
        currentView={activeView}
        onSelectView={setActiveView}
        environment="SANDBOX"
        onSelectEnvironment={() => {}}
        network="LOCAL_EVM"
        onSelectNetwork={() => {}}
        userRole={activeRole}
        onSelectRole={setActiveRole}
        reviewCount={3}
        onOpenAiAssistant={() => {
          setFocusedClause(null);
          setIsAiDrawerOpen(true);
        }}
        onOpenDemoMode={() => setIsDemoModalOpen(true)}
        onOpenNewContract={() => setIsNewContractModalOpen(true)}
      />

      {/* Primary Main Content Area */}
      <main className="flex-1">
        {activeView === "WORKSPACE" && (
          <ContractWorkspaceView
            contract={selectedContract}
            onUpdateContract={handleUpdateContract}
            onOpenAiForClause={handleOpenAiWithClause}
          />
        )}

        {activeView === "SIMULATION" && (
          <SimulationView
            contract={selectedContract}
            onUpdateContract={handleUpdateContract}
          />
        )}

        {activeView === "VERIFICATION" && (
          <VerificationView contract={selectedContract} />
        )}

        {activeView === "RULES" && (
          <ParityMatrixView contract={selectedContract} />
        )}

        {activeView === "CONTRACTS" && (
          <ContractsListView
            contracts={contracts}
            selectedContractId={selectedContractId}
            onSelectContract={setSelectedContractId}
            onOpenNewContract={() => setIsNewContractModalOpen(true)}
            onOpenWorkspace={(cid) => {
              setSelectedContractId(cid);
              setActiveView("WORKSPACE");
            }}
          />
        )}

        {activeView === "TEMPLATES" && (
          <TemplatesView onSelectTemplate={handleSelectTemplate} />
        )}

        {activeView === "EXECUTION" && <ExecutionMonitorView />}

        {activeView === "PARTIES" && <PartiesRegistryView />}

        {activeView === "COLLATERAL" && <AssetsCollateralView />}

        {activeView === "AUDIT" && <AuditTrailView />}

        {activeView === "DEPLOYMENTS" && <DeploymentsView />}

        {activeView === "ORACLES" && <OraclesView />}

        {activeView === "COMPLIANCE" && <ComplianceView />}

        {activeView === "GOVERNANCE" && <GovernanceView />}

        {activeView === "JURISDICTIONS" && <JurisdictionsView />}
      </main>

      {/* Modals & AI Drawer */}
      <AiAssistantDrawer
        isOpen={isAiDrawerOpen}
        onClose={() => setIsAiDrawerOpen(false)}
        contract={selectedContract}
        targetClause={focusedClause}
      />

      <DemoModeModal
        isOpen={isDemoModalOpen}
        onClose={() => setIsDemoModalOpen(false)}
        onNavigateToView={setActiveView}
      />

      <NewContractModal
        isOpen={isNewContractModalOpen}
        onClose={() => setIsNewContractModalOpen(false)}
        onCreateContract={handleCreateContract}
      />
    </div>
  );
}
