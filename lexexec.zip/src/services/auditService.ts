import { AuditRecord, UserRole } from "../types";

export class AuditService {
  private static records: AuditRecord[] = [
    {
      id: "AUD-001",
      contractId: "LEX-2026-000184",
      contractVersion: "1.0.0",
      timestamp: "2026-09-01T10:00:00Z",
      actor: "Eleanor Vance (Borrower CFO)",
      role: "TRADER",
      eventType: "CONTRACT_CREATED",
      description: "Initial loan facility draft created based on LMA Sterling Term Loan template.",
      eventHash: "0x3a9f1b2c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a",
      previousHash: "0x0000000000000000000000000000000000000000000000000000000000000000",
    },
    {
      id: "AUD-002",
      contractId: "LEX-2026-000184",
      contractVersion: "1.2.0",
      timestamp: "2026-09-03T14:15:00Z",
      actor: "Sarah Jenkins, Partner",
      role: "LAWYER",
      eventType: "CLAUSE_CHANGED",
      description: "Clause 07 (Interest) updated to reference Bank of England SONIA with 5-day observation shift.",
      eventHash: "0x7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a",
      previousHash: "0x3a9f1b2c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a",
    },
    {
      id: "AUD-003",
      contractId: "LEX-2026-000184",
      contractVersion: "1.3.0",
      timestamp: "2026-09-04T09:30:00Z",
      actor: "Dr. Ryan Vance",
      role: "CONTRACT_ENGINEER",
      eventType: "CODE_GENERATED",
      description: "Contract IR compiled into ExecutableCommercialLoan.sol with bytecode hash 0x8f19...87.",
      eventHash: "0x9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c",
      previousHash: "0x7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a",
    },
    {
      id: "AUD-004",
      contractId: "LEX-2026-000184",
      contractVersion: "1.4.0",
      timestamp: "2026-09-05T11:00:00Z",
      actor: "Z3 Automated SMT Solver",
      role: "AUDITOR",
      eventType: "VERIFICATION_PASSED",
      description: "5 formal invariants passed: Non-negative principal, single settlement path, bounded oracle rates.",
      eventHash: "0x1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c9d0e",
      previousHash: "0x9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c",
    },
    {
      id: "AUD-005",
      contractId: "LEX-2026-000184",
      contractVersion: "1.4.2",
      timestamp: "2026-09-05T16:00:00Z",
      actor: "Multi-Sig Signatories (Vance, Campbell, Sterling)",
      role: "APPROVER",
      eventType: "SIGNATURE_RECORDED",
      description: "All 3 authorised signatories signed via eIDAS qualified electronic signature.",
      eventHash: "0x4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c9d0e1f2a3b",
      previousHash: "0x1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c9d0e",
    },
    {
      id: "AUD-006",
      contractId: "LEX-2026-000184",
      contractVersion: "1.4.2",
      timestamp: "2026-09-10T09:15:00Z",
      actor: "Caledonian Capital Treasury",
      role: "TREASURER",
      eventType: "PAYMENT_SETTLED",
      description: "£25,000,000 principal disbursed upon satisfaction of Conditions Precedent.",
      eventHash: "0x5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c9d0e1f2a3b4c",
      previousHash: "0x4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a3a9f1b2c8d4e5f6a7b8c9d0e1f2a3b",
    },
  ];

  static getAuditTrail(contractId?: string): AuditRecord[] {
    if (contractId) {
      return this.records.filter((r) => r.contractId === contractId);
    }
    return [...this.records];
  }

  static logEvent(params: {
    contractId: string;
    contractVersion: string;
    actor: string;
    role: UserRole;
    eventType: AuditRecord["eventType"];
    description: string;
    payloadMetadata?: Record<string, any>;
  }): AuditRecord {
    return this.appendRecord(
      params.contractId,
      params.contractVersion,
      params.actor,
      params.role,
      params.eventType,
      params.description,
      params.payloadMetadata
    );
  }

  static appendRecord(
    contractId: string,
    contractVersion: string,
    actor: string,
    role: UserRole,
    eventType: AuditRecord["eventType"],
    description: string,
    payloadMetadata?: Record<string, any>
  ): AuditRecord {
    const previous = this.records[this.records.length - 1];
    const previousHash = previous ? previous.eventHash : "0x0000000000000000000000000000000000000000000000000000000000000000";
    
    // Pseudo-hash generation
    const raw = `${Date.now()}-${contractId}-${eventType}-${description}-${previousHash}`;
    let hashNum = 0;
    for (let i = 0; i < raw.length; i++) {
      hashNum = (hashNum << 5) - hashNum + raw.charCodeAt(i);
      hashNum |= 0;
    }
    const eventHash = "0x" + Math.abs(hashNum).toString(16).padStart(16, "0") + Math.random().toString(16).substring(2, 18) + Math.random().toString(16).substring(2, 18) + Math.random().toString(16).substring(2, 18);

    const newRecord: AuditRecord = {
      id: `AUD-${(this.records.length + 1).toString().padStart(3, "0")}`,
      contractId,
      contractVersion,
      timestamp: new Date().toISOString(),
      actor,
      role,
      eventType,
      description,
      eventHash,
      previousHash,
      payloadMetadata,
    };

    this.records.unshift(newRecord);
    return newRecord;
  }
}
