import { DayCountConvention } from "../types/contract-ir";

export interface CalculationTrace {
  formula: string;
  inputs: Record<string, any>;
  source: string;
  timestamp: string;
  rounding: string;
  precision: number;
  result: number;
  resultFormatted: string;
}

export class FinancialCalculationEngine {
  /**
   * Computes the day-count accrual factor between two ISO date strings.
   */
  static getDayCountAccrualFactor(
    startDateStr: string,
    endDateStr: string,
    convention: DayCountConvention = "ACT/365F"
  ): { days: number; factor: number; basis: number } {
    const start = new Date(startDateStr);
    const end = new Date(endDateStr);
    const diffMs = end.getTime() - start.getTime();
    const actualDays = Math.max(0, Math.round(diffMs / (1000 * 60 * 60 * 24)));

    switch (convention) {
      case "ACT/360":
        return { days: actualDays, factor: actualDays / 360, basis: 360 };
      case "ACT/365F":
        return { days: actualDays, factor: actualDays / 365, basis: 365 };
      case "30/360": {
        const d1 = Math.min(30, start.getDate());
        const d2 = start.getDate() === 30 ? Math.min(30, end.getDate()) : end.getDate();
        const m1 = start.getMonth() + 1;
        const m2 = end.getMonth() + 1;
        const y1 = start.getFullYear();
        const y2 = end.getFullYear();
        const days360 = (y2 - y1) * 360 + (m2 - m1) * 30 + (d2 - d1);
        return { days: days360, factor: days360 / 360, basis: 360 };
      }
      case "ACT/ACT":
      default:
        return { days: actualDays, factor: actualDays / 365.25, basis: 365.25 };
    }
  }

  /**
   * Deterministic Simple Interest Calculation with Provenance Trace
   */
  static calculateSimpleInterest(
    notional: number,
    annualRatePct: number,
    startDateStr: string,
    endDateStr: string,
    convention: DayCountConvention = "ACT/365F"
  ): { interest: number; trace: CalculationTrace } {
    const { days, factor, basis } = this.getDayCountAccrualFactor(startDateStr, endDateStr, convention);
    const rateDecimal = annualRatePct / 100;
    const interest = notional * rateDecimal * factor;

    const trace: CalculationTrace = {
      formula: "Notional × (AnnualRate / 100) × (Days / Basis)",
      inputs: {
        notional,
        annualRatePercent: annualRatePct,
        rateDecimal,
        startDate: startDateStr,
        endDate: endDateStr,
        daysAccrued: days,
        dayCountConvention: convention,
        basis,
        accrualFactor: factor,
      },
      source: "LEXEXEC Financial Calculation Engine v3.7",
      timestamp: new Date().toISOString(),
      rounding: "Half-Up 2 Decimals",
      precision: 2,
      result: Number(interest.toFixed(2)),
      resultFormatted: `£${Number(interest.toFixed(2)).toLocaleString("en-GB", { minimumFractionDigits: 2 })}`,
    };

    return {
      interest: Number(interest.toFixed(2)),
      trace,
    };
  }

  /**
   * Compound Accrued Interest
   */
  static calculateCompoundInterest(
    notional: number,
    annualRatePct: number,
    periodsPerYear: number,
    totalYears: number
  ): { futureValue: number; totalInterest: number; trace: CalculationTrace } {
    const r = annualRatePct / 100;
    const n = periodsPerYear;
    const t = totalYears;
    const futureValue = notional * Math.pow(1 + r / n, n * t);
    const totalInterest = futureValue - notional;

    const trace: CalculationTrace = {
      formula: "Notional × (1 + r/n)^(n×t)",
      inputs: {
        notional,
        ratePercent: annualRatePct,
        periodsPerYear: n,
        totalYears: t,
      },
      source: "LEXEXEC Compound Calculation Module",
      timestamp: new Date().toISOString(),
      rounding: "Half-Up 2 Decimals",
      precision: 2,
      result: Number(totalInterest.toFixed(2)),
      resultFormatted: `£${Number(totalInterest.toFixed(2)).toLocaleString("en-GB", { minimumFractionDigits: 2 })}`,
    };

    return {
      futureValue: Number(futureValue.toFixed(2)),
      totalInterest: Number(totalInterest.toFixed(2)),
      trace,
    };
  }

  /**
   * Collateral & Margin Metrics
   */
  static calculateCollateralMetrics(
    notional: number,
    collateralMarketValue: number,
    haircutPct: number,
    requiredMarginPct: number = 100
  ): {
    haircutAmount: number;
    effectiveCollateral: number;
    requiredMarginAmount: number;
    marginSurplusOrDeficit: number;
    loanToValuePct: number;
    marginStatus: "SATISFIED" | "DEFICIT_WARNING" | "MARGIN_CALL_REQUIRED" | "LIQUIDATION_BREACH";
    trace: CalculationTrace;
  } {
    const haircutFactor = 1 - haircutPct / 100;
    const haircutAmount = collateralMarketValue * (haircutPct / 100);
    const effectiveCollateral = collateralMarketValue * haircutFactor;
    const requiredMarginAmount = notional * (requiredMarginPct / 100);
    const marginSurplusOrDeficit = effectiveCollateral - requiredMarginAmount;
    const ltv = (notional / Math.max(1, collateralMarketValue)) * 100;

    let marginStatus: "SATISFIED" | "DEFICIT_WARNING" | "MARGIN_CALL_REQUIRED" | "LIQUIDATION_BREACH" = "SATISFIED";
    if (effectiveCollateral < notional * 0.85) {
      marginStatus = "LIQUIDATION_BREACH";
    } else if (marginSurplusOrDeficit < 0) {
      marginStatus = "MARGIN_CALL_REQUIRED";
    } else if (marginSurplusOrDeficit < notional * 0.05) {
      marginStatus = "DEFICIT_WARNING";
    }

    const trace: CalculationTrace = {
      formula: "EffectiveCollateral = MarketValue × (1 - Haircut) ; MarginDiff = EffectiveCollateral - RequiredMargin",
      inputs: {
        notional,
        collateralMarketValue,
        haircutPct,
        effectiveCollateral,
        requiredMarginAmount,
      },
      source: "LEXEXEC Collateral & Haircut Module",
      timestamp: new Date().toISOString(),
      rounding: "Standard",
      precision: 2,
      result: Number(marginSurplusOrDeficit.toFixed(2)),
      resultFormatted: `${marginSurplusOrDeficit >= 0 ? "+" : "-"}£${Math.abs(marginSurplusOrDeficit).toLocaleString("en-GB", { minimumFractionDigits: 2 })}`,
    };

    return {
      haircutAmount: Number(haircutAmount.toFixed(2)),
      effectiveCollateral: Number(effectiveCollateral.toFixed(2)),
      requiredMarginAmount: Number(requiredMarginAmount.toFixed(2)),
      marginSurplusOrDeficit: Number(marginSurplusOrDeficit.toFixed(2)),
      loanToValuePct: Number(ltv.toFixed(2)),
      marginStatus,
      trace,
    };
  }

  /**
   * Deterministic Cash Flow Schedule Generator
   */
  static generateAmortizationSchedule(
    notional: number,
    currency: string,
    startDateStr: string,
    maturityDateStr: string,
    annualRatePct: number,
    frequency: "Monthly" | "Quarterly" | "Semi-Annually" | "Annually" | "At Maturity",
    convention: DayCountConvention = "ACT/365F"
  ) {
    const start = new Date(startDateStr);
    const end = new Date(maturityDateStr);
    const schedule = [];

    const monthStep =
      frequency === "Monthly"
        ? 1
        : frequency === "Quarterly"
        ? 3
        : frequency === "Semi-Annually"
        ? 6
        : frequency === "Annually"
        ? 12
        : 999;

    let currentPeriodStart = new Date(start);
    let periodIndex = 1;

    while (currentPeriodStart < end) {
      let currentPeriodEnd = new Date(currentPeriodStart);
      if (monthStep >= 999) {
        currentPeriodEnd = new Date(end);
      } else {
        currentPeriodEnd.setMonth(currentPeriodEnd.getMonth() + monthStep);
        if (currentPeriodEnd > end) {
          currentPeriodEnd = new Date(end);
        }
      }

      const pStartStr = currentPeriodStart.toISOString().split("T")[0];
      const pEndStr = currentPeriodEnd.toISOString().split("T")[0];
      const { interest, trace } = this.calculateSimpleInterest(
        notional,
        annualRatePct,
        pStartStr,
        pEndStr,
        convention
      );

      const isLast = currentPeriodEnd >= end;
      const principalRepayment = isLast ? notional : 0;
      const totalCashflow = interest + principalRepayment;

      schedule.push({
        period: periodIndex,
        startDate: pStartStr,
        paymentDate: pEndStr,
        interestAmount: interest,
        principalRepayment,
        totalCashflow: Number(totalCashflow.toFixed(2)),
        outstandingPrincipal: isLast ? 0 : notional,
        currency,
        trace,
      });

      if (isLast) break;
      currentPeriodStart = new Date(currentPeriodEnd);
      periodIndex++;
    }

    return schedule;
  }
}
