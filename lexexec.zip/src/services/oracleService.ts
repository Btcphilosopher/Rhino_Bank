import { OracleFeed } from "../types";

export class OracleService {
  private static feeds: OracleFeed[] = [
    {
      id: "ORACLE-SONIA",
      name: "SONIA (Sterling Overnight Index Average)",
      category: "REFERENCE_RATE",
      currency: "GBP",
      currentValue: 5.1845,
      unit: "% p.a.",
      lastUpdated: new Date().toISOString(),
      source: "Bank of England Benchmark Administrator (Refinitiv / Bloomberg Feed BBA)",
      confidence: 99.98,
      signature: "0x98f4e229a7cb81dc710928aee91b9487c9102837bcde8192a837482910fa7281",
      isStale: false,
      status: "ACTIVE",
      history: [
        { timestamp: "2026-09-18", value: 5.182 },
        { timestamp: "2026-09-19", value: 5.1835 },
        { timestamp: "2026-09-20", value: 5.184 },
        { timestamp: "2026-09-21", value: 5.1845 },
        { timestamp: "2026-09-22", value: 5.1845 },
      ],
    },
    {
      id: "ORACLE-SOFR",
      name: "SOFR (Secured Overnight Financing Rate)",
      category: "REFERENCE_RATE",
      currency: "USD",
      currentValue: 4.825,
      unit: "% p.a.",
      lastUpdated: new Date().toISOString(),
      source: "Federal Reserve Bank of New York",
      confidence: 99.95,
      signature: "0x78ab1264c9102374bcde8192a837482910fa728198f4e229a7cb81dc710928ae",
      isStale: false,
      status: "ACTIVE",
      history: [
        { timestamp: "2026-09-18", value: 4.83 },
        { timestamp: "2026-09-19", value: 4.828 },
        { timestamp: "2026-09-20", value: 4.826 },
        { timestamp: "2026-09-21", value: 4.825 },
        { timestamp: "2026-09-22", value: 4.825 },
      ],
    },
    {
      id: "ORACLE-ESTR",
      name: "€STR (Euro Short-Term Rate)",
      category: "REFERENCE_RATE",
      currency: "EUR",
      currentValue: 3.652,
      unit: "% p.a.",
      lastUpdated: new Date().toISOString(),
      source: "European Central Bank",
      confidence: 99.92,
      signature: "0x510928aee91b9487c9102837bcde8192a837482910fa728198f4e229a7cb81dc",
      isStale: false,
      status: "ACTIVE",
      history: [
        { timestamp: "2026-09-18", value: 3.655 },
        { timestamp: "2026-09-19", value: 3.654 },
        { timestamp: "2026-09-20", value: 3.653 },
        { timestamp: "2026-09-21", value: 3.652 },
        { timestamp: "2026-09-22", value: 3.652 },
      ],
    },
    {
      id: "ORACLE-GBPUSD",
      name: "GBP / USD Spot Rate",
      category: "FX_PAIR",
      currency: "USD",
      currentValue: 1.3145,
      unit: "USD per GBP",
      lastUpdated: new Date().toISOString(),
      source: "WM/Reuters 4pm Benchmark",
      confidence: 99.88,
      signature: "0x12a837482910fa728198f4e229a7cb81dc710928aee91b9487c9102837bcde81",
      isStale: false,
      status: "ACTIVE",
      history: [
        { timestamp: "2026-09-18", value: 1.309 },
        { timestamp: "2026-09-19", value: 1.3115 },
        { timestamp: "2026-09-20", value: 1.313 },
        { timestamp: "2026-09-21", value: 1.3142 },
        { timestamp: "2026-09-22", value: 1.3145 },
      ],
    },
    {
      id: "ORACLE-UKGILT-10Y",
      name: "UK Gilt 10-Year Benchmark (Price)",
      category: "SECURITY_PRICE",
      currency: "GBP",
      currentValue: 98.42,
      unit: "Clean Price",
      lastUpdated: new Date().toISOString(),
      source: "UK Debt Management Office / Tradeweb DMO",
      confidence: 99.9,
      signature: "0xbcde8192a837482910fa728198f4e229a7cb81dc710928aee91b9487c9102837",
      isStale: false,
      status: "ACTIVE",
      history: [
        { timestamp: "2026-09-18", value: 99.1 },
        { timestamp: "2026-09-19", value: 98.85 },
        { timestamp: "2026-09-20", value: 98.6 },
        { timestamp: "2026-09-21", value: 98.45 },
        { timestamp: "2026-09-22", value: 98.42 },
      ],
    },
  ];

  static getFeeds(): OracleFeed[] {
    return [...this.feeds];
  }

  static getFeedById(id: string): OracleFeed | undefined {
    return this.feeds.find((f) => f.id === id);
  }

  static updateFeedValue(id: string, newValue: number, isStale: boolean = false) {
    const feed = this.feeds.find((f) => f.id === id);
    if (feed) {
      feed.currentValue = newValue;
      feed.lastUpdated = new Date().toISOString();
      feed.isStale = isStale;
      feed.status = isStale ? "DEGRADED" : "ACTIVE";
      feed.history.push({
        timestamp: new Date().toISOString().split("T")[0],
        value: newValue,
      });
      if (feed.history.length > 8) feed.history.shift();
    }
  }
}
