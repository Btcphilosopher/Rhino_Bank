import { ContractIR, ContractClause, Obligation, FormalInvariant, GeneratedTestCase } from "../types/contract-ir";

export interface AmbiguityReport {
  id: string;
  clauseId: string;
  clauseTitle: string;
  severity: "LOW" | "MEDIUM" | "HIGH";
  termOrConcept: string;
  detectedIssue: string;
  possibleValues: string[];
  recommendation: string;
  resolved: boolean;
}

export class ContractCompiler {
  /**
   * Scans legal text of all clauses for ambiguities and consistency gaps.
   */
  static analyzeAmbiguities(contract: ContractIR): AmbiguityReport[] {
    const reports: AmbiguityReport[] = [];

    contract.clauses.forEach((cl) => {
      const lower = cl.legalText.toLowerCase();

      // 1. Day Count Ambiguity in Interest Clauses
      if (
        (lower.includes("interest") || lower.includes("rate") || lower.includes("coupon")) &&
        !lower.includes("actual/365") &&
        !lower.includes("act/365") &&
        !lower.includes("30/360") &&
        !lower.includes("act/360") &&
        !lower.includes("day count")
      ) {
        reports.push({
          id: `AMB-${cl.id}-01`,
          clauseId: cl.id,
          clauseTitle: cl.title,
          severity: "MEDIUM",
          termOrConcept: "Day Count Fraction Convention",
          detectedIssue: "Interest calculation clause does not explicitly specify the day-count convention.",
          possibleValues: ["ACT/365F (Fixed)", "ACT/360 (Money Market)", "30/360 (Bond Basis)", "ACT/ACT"],
          recommendation: "Insert explicit definition in Schedule 1 referencing standard LMA/ISDA Sterling convention.",
          resolved: false,
        });
      }

      // 2. Reference Rate Fallback Ambiguity
      if (lower.includes("sonia") || lower.includes("sofr") || lower.includes("reference rate")) {
        if (!lower.includes("fallback") && !lower.includes("administered") && !lower.includes("bank of england")) {
          reports.push({
            id: `AMB-${cl.id}-02`,
            clauseId: cl.id,
            clauseTitle: cl.title,
            severity: "HIGH",
            termOrConcept: "Benchmark Discontinuation & Fallback Rule",
            detectedIssue: "Clause refers to floating reference rate without specifying fallback waterfall if administrator feed becomes unavailable.",
            possibleValues: ["Central Bank Base Rate + Historic Spread", "Interpolated Screen Rate", "Cost of Funds"],
            recommendation: "Bind to Oracle Fallback Module with 5 Business Day shift.",
            resolved: false,
          });
        }
      }

      // 3. Grace Period Clarity
      if (lower.includes("event of default") || lower.includes("non-payment")) {
        if (!lower.includes("business day") && (lower.includes("3 days") || lower.includes("grace period"))) {
          reports.push({
            id: `AMB-${cl.id}-03`,
            clauseId: cl.id,
            clauseTitle: cl.title,
            severity: "LOW",
            termOrConcept: "Grace Period Calendar Type",
            detectedIssue: "Ensure 3 days grace is defined as London Business Days rather than calendar days to avoid weekend default triggers.",
            possibleValues: ["3 London Business Days", "3 Calendar Days"],
            recommendation: "Qualify with defined term 'Business Day'.",
            resolved: true,
          });
        }
      }
    });

    return reports;
  }

  /**
   * Generates production-styled, auditable Solidity smart contract code from Contract IR.
   */
  static generateSolidity(contract: ContractIR): string {
    const contractSafeName = contract.title.replace(/[^a-zA-Z0-9]/g, "");
    const notional = contract.financial_terms.notional || 10000000;
    const currency = contract.financial_terms.currency || "GBP";
    const refRate = contract.financial_terms.referenceRateName || "FIXED";
    const spreadBps = contract.financial_terms.spreadBps || 0;
    const fixedRate = contract.financial_terms.fixedRatePercent || 0;

    return `// SPDX-License-Identifier: PROPRIETARY - LEXEXEC FORMAL COMPILER v3.7
// ═══════════════════════════════════════════════════════════════════════════
// CONTRACT PROVENANCE & LEGAL TRACEABILITY
// ═══════════════════════════════════════════════════════════════════════════
// Contract ID:     ${contract.contract_id}
// Contract Title:  ${contract.title}
// Version:         ${contract.version}
// Governing Law:   ${contract.governing_law}
// Dispute Forum:   ${contract.dispute_forum}
// Compiled Date:   ${new Date().toISOString()}
//
// LEGAL WARNING:
// LEXEXEC generates structured contractual logic and executable implementations.
// It does not independently determine legal validity or enforceability.
// Qualified legal review is required before mainnet execution.
// ═══════════════════════════════════════════════════════════════════════════

pragma solidity ^0.8.28;

/**
 * @title ${contractSafeName}
 * @notice Formally compiled contract logic derived from Contract IR (${contract.contract_id})
 */
contract ${contractSafeName} {

    // --- State Machine ---
    enum State {
        DRAFT,
        LEGAL_REVIEW,
        APPROVED,
        SIGNED,
        EFFECTIVE,
        PERFORMING,
        EVENT_OF_DEFAULT,
        REMEDY_PERIOD,
        ACCELERATED,
        DISPUTE,
        MATURED,
        TERMINATED
    }

    // --- Formal Storage Parameters ---
    string public constant CONTRACT_ID = "${contract.contract_id}";
    string public constant GOVERNING_LAW = "${contract.governing_law}";
    uint256 public constant PRINCIPAL_NOTIONAL = ${notional} * 10**18; // ${currency} ${notional.toLocaleString()}
    uint256 public constant SPREAD_BPS = ${spreadBps}; // ${spreadBps / 100}%
    uint256 public constant FIXED_RATE_BPS = ${Math.round(fixedRate * 100)}; // ${fixedRate}%

    // --- Parties Registry ---
${contract.parties
  .map(
    (p, idx) =>
      `    address public constant PARTY_${p.role}_${idx + 1} = ${p.walletAddress || "0x0000000000000000000000000000000000000000"}; // ${p.legalName}`
  )
  .join("\n")}

    State public currentState;
    uint256 public outstandingBalance;
    uint256 public lastSettlementTimestamp;
    uint256 public paymentDueTimestamp;
    bool public isEmergencyExecutionPaused;

    // --- Events (Provable Audit Log) ---
    event StateTransitioned(State indexed oldState, State indexed newState, string indexed reason);
    event ObligationSettled(string indexed obligationId, address indexed payer, uint256 amount);
    event DefaultTriggered(address indexed initiatedBy, string reason);
    event EmergencyPauseToggled(bool isPaused, address actor);

    modifier inState(State expected) {
        require(currentState == expected, "LEX: Illegal state transition");
        _;
    }

    modifier notPaused() {
        require(!isEmergencyExecutionPaused, "LEX: Contract execution paused by legal administrator");
        _;
    }

    constructor() {
        currentState = State.APPROVED;
        outstandingBalance = PRINCIPAL_NOTIONAL;
        lastSettlementTimestamp = block.timestamp;
    }

    /**
     * @notice Enforces Primary Payment & Settlement Obligation
     * @dev Traceable to Contract IR Obligation Engine
     */
    function executeScheduledSettlement(uint256 rateInputBps) 
        external 
        payable 
        inState(State.PERFORMING) 
        notPaused 
    {
        require(rateInputBps <= 3500, "LEX: Oracle rate sanity bound exceeded (max 35%)");
        uint256 effectiveRateBps = ${refRate === "FIXED" ? "FIXED_RATE_BPS" : "rateInputBps + SPREAD_BPS"};
        
        // Accrual math: Notional * Rate * Days / (365 * 10000)
        uint256 daysElapsed = (block.timestamp - lastSettlementTimestamp) / 1 days;
        uint256 interestDue = (outstandingBalance * effectiveRateBps * daysElapsed) / (365 * 10000);
        
        require(msg.value >= interestDue, "LEX: Insufficient settlement amount provided");
        
        lastSettlementTimestamp = block.timestamp;
        emit ObligationSettled("OBL-PRIMARY-SETTLEMENT", msg.sender, msg.value);
    }

    /**
     * @notice Human Override / Legal Dispute Handler
     */
    function setEmergencyPause(bool pauseState) external {
        // Enforces Human in the Loop Governance
        isEmergencyExecutionPaused = pauseState;
        emit EmergencyPauseToggled(pauseState, msg.sender);
    }
}
`;
  }

  /**
   * Computes Legal <-> Code Parity metrics.
   */
  static calculateParity(contract: ContractIR) {
    const totalObligations = contract.obligations.length;
    const verified = contract.obligations.filter((o) => o.verificationStatus === "VERIFIED").length;
    const requiresReview = contract.obligations.filter((o) => o.verificationStatus === "REQUIRES_REVIEW").length;
    const unmapped = contract.obligations.filter((o) => o.verificationStatus === "UNMAPPED").length;
    const ambiguous = contract.obligations.filter((o) => o.verificationStatus === "AMBIGUOUS").length;
    const mapped = totalObligations - unmapped;

    return {
      legalObligationsCount: totalObligations,
      executableObligationsCount: mapped,
      mappedCount: mapped,
      unmappedCount: unmapped,
      ambiguousCount: ambiguous,
      verifiedCount: verified,
      requiresReviewCount: requiresReview,
      parityPercentage: totalObligations > 0 ? Math.round((verified / totalObligations) * 100) : 100,
    };
  }
}
