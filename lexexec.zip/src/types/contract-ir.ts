export type PartyRole =
  | "INDIVIDUAL"
  | "CORPORATION"
  | "BANK"
  | "FUND"
  | "BROKER"
  | "EXCHANGE"
  | "TRUSTEE"
  | "CUSTODIAN"
  | "ISSUER"
  | "INVESTOR"
  | "GUARANTOR"
  | "CALCULATION_AGENT"
  | "PAYING_AGENT"
  | "BORROWER"
  | "LENDER"
  | "BUYER"
  | "SELLER"
  | "ESCROW_AGENT";

export interface Party {
  id: string;
  legalName: string;
  jurisdiction: string;
  registrationId: string;
  lei?: string; // Legal Entity Identifier (20 chars)
  role: PartyRole;
  address: string;
  authorizedSignatories: Array<{
    name: string;
    title: string;
    email: string;
    hasSigned?: boolean;
    signedAt?: string;
  }>;
  identityProvider: string;
  settlementAccount: string; // e.g. IBAN, synthetic account or EVM address
  walletAddress: string;
  kycStatus: "VERIFIED" | "PENDING" | "EXEMPT";
}

export type ContractParty = Party;

export interface LegalDefinition {
  id: string;
  term: string;
  definitionText: string;
  structuredType:
    | "calendar_rule"
    | "reference_rate"
    | "money_amount"
    | "party_role"
    | "formula"
    | "condition"
    | "period"
    | "dispute_forum";
  jurisdiction: string;
  source: string;
  parameters: Record<string, any>;
}

export type ObligationType =
  | "OBLIGATION"
  | "RIGHT"
  | "CONDITION"
  | "PROHIBITION"
  | "PERMISSION"
  | "EVENT"
  | "REMEDY";

export interface Obligation {
  id: string; // e.g. OBLIGATION-0082
  clauseRef: string; // e.g. Clause 8.2
  type: ObligationType;
  actorPartyId: string;
  counterpartyId: string;
  action: string;
  objectDescription: string;
  amount?: number;
  currency?: string;
  rateFormula?: string;
  conditionExpr?: string;
  deadline?: string;
  frequency?: "ONE_OFF" | "MONTHLY" | "QUARTERLY" | "SEMI_ANNUALLY" | "ANNUALLY" | "ON_DEMAND";
  consequence?: string;
  isAutomated: boolean;
  unmappedReason?: string;
  executionFunction?: string;
  verificationStatus: "VERIFIED" | "REQUIRES_REVIEW" | "UNMAPPED" | "AMBIGUOUS";
  formalLogic: string;
}

export type ContractStateType =
  | "DRAFT"
  | "LEGAL_REVIEW"
  | "TECHNICAL_REVIEW"
  | "COMPLIANCE_REVIEW"
  | "APPROVED"
  | "SIGNED"
  | "EFFECTIVE"
  | "ACTIVE"
  | "PERFORMING"
  | "EVENT_OF_DEFAULT"
  | "REMEDY_PERIOD"
  | "ACCELERATION"
  | "DISPUTE"
  | "MATURED"
  | "TERMINATED";

export interface StateTransition {
  id: string;
  fromState: ContractStateType;
  toState: ContractStateType;
  triggerEvent: string;
  condition: string;
  responsibleParty: string;
  executableConsequence: string;
  isAutomated: boolean;
}

export type DayCountConvention = "ACT/360" | "ACT/365F" | "30/360" | "ACT/ACT";

export type FinancialContractCategory =
  | "LOAN"
  | "BOND"
  | "REPO"
  | "INTEREST_RATE_SWAP"
  | "ESCROW"
  | "TOKENISED_ASSET"
  | "TRADE_FINANCE"
  | "FX_FORWARD"
  | "CUSTOM";

export interface FinancialTerms {
  category: FinancialContractCategory;
  notional: number;
  currency: string;
  startDate: string;
  maturityDate: string;
  dayCountConvention: DayCountConvention;
  paymentFrequency: "Monthly" | "Quarterly" | "Semi-Annually" | "Annually" | "At Maturity";
  referenceRateName?: "SONIA" | "SOFR" | "ESTR" | "TONA" | "SARON" | "FIXED";
  spreadBps?: number; // e.g. 175 bps = 1.75%
  fixedRatePercent?: number; // e.g. 5.25%
  businessDayAdjustment: "Following" | "Modified Following" | "Preceding";
  // Collateral / Repo specific
  collateralAsset?: string;
  collateralQuantity?: number;
  collateralValuation?: number;
  haircutPercent?: number;
  requiredMarginRatio?: number;
  maintenanceMarginRatio?: number;
  repurchasePrice?: number;
  // Escrow / Milestone
  milestones?: Array<{
    id: string;
    description: string;
    percentage: number;
    amount: number;
    approverPartyId: string;
    isReleased: boolean;
  }>;
  // FX Forward specific
  baseCurrency?: string;
  quoteCurrency?: string;
  forwardRate?: number;
  settlementVenue?: string;
}

export interface ContractClause {
  id: string;
  sectionNumber: string; // e.g. "01", "08"
  title: string;
  legalText: string;
  formalSummary: string;
  ambiguities: string[];
  severity: "NONE" | "LOW" | "MEDIUM" | "HIGH";
  status: "DRAFT" | "UNDER_REVIEW" | "APPROVED" | "FLAGGED" | "REQUIRES_REVIEW" | "VERIFIED";
  isOperative: boolean;
  relatedObligationIds: string[];
  codeMapping?: {
    functionName: string;
    solidityLines: string;
  };
}

export interface FormalInvariant {
  id: string;
  name: string;
  description: string;
  formalStatement: string; // e.g. "ASSERT principal >= 0"
  smtProofMethod: "Z3_SMT_SOLVER" | "SYMBOLIC_EXECUTION" | "BOUNDED_MODEL_CHECKER";
  status: "PASSED" | "FAILED" | "WARNING" | "UNCHECKED";
  executionTimeMs: number;
  failureTrace?: string;
}

export interface GeneratedTestCase {
  id: string;
  title: string;
  category:
    | "HAPPY_PATH"
    | "LATE_PERFORMANCE"
    | "FAILURE"
    | "DEFAULT"
    | "DISPUTE"
    | "BOUNDARY"
    | "ORACLE_FAILURE"
    | "INVALID_INPUT";
  givenState: string;
  whenEvent: string;
  thenExpected: string;
  status: "PASSED" | "FAILED" | "PENDING";
  gasEstimate: number;
  solidityCode: string;
}

export interface CashFlowEvent {
  id: string;
  date: string;
  payerId: string;
  payeeId: string;
  payerName: string;
  payeeName: string;
  type: "PRINCIPAL_DISBURSEMENT" | "INTEREST_COUPON" | "PRINCIPAL_REPAYMENT" | "MARGIN_CALL" | "COLLATERAL_POSTING" | "FEE" | "PREPAYMENT";
  amount: number;
  currency: string;
  calculatedRate?: number;
  status: "PROJECTED" | "DUE" | "SETTLED" | "DEFAULTED" | "DISPUTED";
  obligationId: string;
  clauseRef: string;
}

export interface ContractIR {
  contract_id: string; // e.g. LEX-2026-000184
  title: string;
  version: string;
  governing_law: string;
  dispute_forum: string;
  currentState: ContractStateType;
  created_at: string;
  updated_at: string;
  parties: Party[];
  definitions: LegalDefinition[];
  clauses: ContractClause[];
  obligations: Obligation[];
  financial_terms: FinancialTerms;
  state_machine: {
    states: ContractStateType[];
    transitions: StateTransition[];
  };
  cash_flows: CashFlowEvent[];
  invariants: FormalInvariant[];
  tests: GeneratedTestCase[];
  generated_solidity: {
    contractName: string;
    sourceCode: string;
    compilerVersion: string;
    bytecodeHash: string;
    securityGatePassed: boolean;
    securityFindings: Array<{
      id: string;
      severity: "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
      title: string;
      description: string;
      mitigation: string;
    }>;
  };
  legalReviewRequired: boolean;
  governance: {
    requiredApprovals: Array<{
      role: string;
      approved: boolean;
      approvedBy?: string;
      timestamp?: string;
    }>;
    isDeployable: boolean;
  };
}
