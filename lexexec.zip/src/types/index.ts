import { ContractIR, ContractStateType, FinancialContractCategory } from "./contract-ir";

export * from "./contract-ir";

export type UserRole =
  | "LEGAL_ENGINEER"
  | "LAWYER"
  | "CONTRACT_ENGINEER"
  | "TRADER"
  | "TREASURER"
  | "COMPLIANCE_OFFICER"
  | "RISK_OFFICER"
  | "APPROVER"
  | "ADMIN"
  | "AUDITOR";

export type AppEnvironment = "LOCAL" | "SANDBOX" | "STAGING" | "PRODUCTION";
export type NetworkTarget = "LOCAL_EVM" | "SEPOLIA_TESTNET" | "CANTON_SIM" | "PERMISSIONED_CONSORTIUM";

export type AppView =
  | "CONTRACTS"
  | "WORKSPACE"
  | "TEMPLATES"
  | "PARTIES"
  | "ASSETS"
  | "COLLATERAL"
  | "RULES"
  | "EXECUTION"
  | "SIMULATION"
  | "VERIFICATION"
  | "AUDIT"
  | "DEPLOYMENTS"
  | "JURISDICTIONS"
  | "ORACLES"
  | "COMPLIANCE"
  | "GOVERNANCE";

export interface OracleFeed {
  id: string;
  name: string; // e.g. SONIA (Bank of England), SOFR (NY Fed), GBP/USD
  category: "REFERENCE_RATE" | "FX_PAIR" | "COMMODITY" | "SECURITY_PRICE" | "CORPORATE_EVENT";
  currency: string;
  currentValue: number;
  unit: string;
  lastUpdated: string;
  source: string;
  confidence: number;
  signature: string;
  isStale: boolean;
  status: "ACTIVE" | "DEGRADED" | "SIMULATED_FAILOVER";
  history: Array<{ timestamp: string; value: number }>;
}

export interface AuditRecord {
  id: string;
  contractId: string;
  contractVersion: string;
  timestamp: string;
  actor: string;
  role: UserRole;
  eventType:
    | "CONTRACT_CREATED"
    | "CLAUSE_CHANGED"
    | "AMBIGUITY_RESOLVED"
    | "PARTY_ADDED"
    | "LEGAL_REVIEW_COMPLETED"
    | "TECHNICAL_REVIEW_COMPLETED"
    | "CODE_GENERATED"
    | "VERIFICATION_PASSED"
    | "TESTS_RUN"
    | "SIGNATURE_RECORDED"
    | "CONTRACT_ACTIVATED"
    | "ORACLE_INGESTED"
    | "PAYMENT_TRIGGERED"
    | "PAYMENT_SETTLED"
    | "MARGIN_CALL_ISSUED"
    | "COLLATERAL_POSTED"
    | "DEFAULT_TRIGGERED"
    | "HUMAN_OVERRIDE_PAUSE"
    | "HUMAN_OVERRIDE_RESUME"
    | "CONTRACT_DEPLOYED"
    | "CONTRACT_TERMINATED";
  description: string;
  eventHash: string;
  previousHash: string;
  payloadMetadata?: Record<string, any>;
}

export interface DeploymentReceipt {
  id: string;
  contractId: string;
  contractTitle: string;
  contractHash: string;
  codeHash: string;
  network: NetworkTarget;
  environment: AppEnvironment;
  blockNumber: number;
  transactionHash: string;
  deployedAddress: string;
  deployedAt: string;
  deployerRole: UserRole;
  deployerAddress: string;
  signersApproved: string[];
  formalVerificationStatus: "VERIFIED" | "OVERRIDDEN";
  gasUsed: number;
}

export interface ExecutionEventReceipt {
  id: string;
  contractId: string;
  contractTitle: string;
  eventType: string;
  amountFormatted?: string;
  payerName: string;
  beneficiaryName: string;
  contractState: ContractStateType;
  legalClauseRef: string;
  executionRuleId: string;
  codeVersion: string;
  timestamp: string;
  settlementTxHash: string;
  status: "CONFIRMED" | "DISPUTED" | "PENDING";
  oracleContext?: string;
}

export interface HumanMachineMatrixItem {
  id: string;
  element: string;
  humanRole: "Required" | "Review" | "Approval" | "Optional" | "Escalation";
  machineRole: "No" | "Assist" | "Automated" | "Enforce";
  notes: string;
  isEditable: boolean;
}
