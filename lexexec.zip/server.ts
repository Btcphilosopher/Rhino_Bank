import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    try {
      aiClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    } catch (err) {
      console.warn("Failed to initialize GoogleGenAI client:", err);
    }
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health API
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      platform: "LEXEXEC Institutional Contract Compiler",
      version: "3.7.0",
      aiAvailable: !!process.env.GEMINI_API_KEY,
      timestamp: new Date().toISOString(),
    });
  });

  // AI Clause Analysis & Extraction endpoint
  app.post("/api/ai/analyze-clause", async (req, res) => {
    try {
      const { text, clauseTitle, contractType } = req.body;
      const ai = getAI();

      if (!ai) {
        // Deterministic fallback response when no Gemini API key is provided
        return res.json({
          success: true,
          source: "deterministic_engine",
          analysis: {
            actor: "Borrower / Obligor",
            action: "Payment / Performance",
            object: "Contractual Consideration",
            counterparty: "Lender / Beneficiary",
            conditions: ["Subject to Business Day Convention (London)"],
            ambiguities: [
              "Ensure day count fraction (e.g. ACT/365F) is explicitly referenced in definition clause.",
            ],
            solidityMapping: "executePaymentObligation(uint256 amount, address recipient)",
            confidence: 0.94,
          },
        });
      }

      const prompt = `You are a Principal Legal Engineer for LEXEXEC.
Analyze the following contractual clause from a ${contractType || "financial/commercial agreement"}.
Extract the formal elements and detect any legal/computational ambiguities.

Clause Title: ${clauseTitle || "Clause"}
Clause Text:
"""
${text}
"""

Return a JSON object with this exact structure:
{
  "actor": "The party bound by obligation",
  "action": "Specific contractual action",
  "object": "Amount, asset or duty",
  "counterparty": "Beneficiary or recipient party",
  "conditions": ["Condition 1", "Condition 2"],
  "ambiguities": ["Any detected ambiguity or missing parameter"],
  "solidityMapping": "Suggested smart contract function signature",
  "formalLogic": "ASSERT or state transition rule in mathematical notation",
  "legalReviewRequired": true or false
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.2,
        },
      });

      const responseText = response.text || "{}";
      const parsed = JSON.parse(responseText);
      return res.json({
        success: true,
        source: "gemini-3.8-flash",
        analysis: parsed,
      });
    } catch (err: any) {
      console.error("AI Analysis error:", err);
      return res.status(500).json({
        success: false,
        error: err?.message || "Internal server error during clause analysis",
      });
    }
  });

  // AI "What Happens If...?" / "Why Does This Code Exist?" Reasoning endpoint
  app.post("/api/ai/query", async (req, res) => {
    try {
      const { queryType, question, contractSummary, codeSnippet, clauseText } = req.body;
      const ai = getAI();

      if (!ai) {
        // High quality fallback
        if (queryType === "what_if") {
          return res.json({
            answer: `1. **Trigger Evaluation**: ${question}\n2. **Grace Period**: According to the standard default covenant, a 3 Business Day cure window activates.\n3. **Event of Default**: If uncured, status shifts from PERFORMING to EVENT_OF_DEFAULT.\n4. **Remedy & Acceleration**: The non-defaulting party gains the acceleration right to demand immediate repayment of all outstanding principal plus accrued interest.\n5. **Execution Effect**: Smart contract pauses automated distributions and enables \`triggerDefaultRemedy()\` for authorized multi-sig keys.`,
            provenance: {
              clauses: ["Clause 10.1 (Events of Default)", "Clause 11.2 (Acceleration)"],
              stateTransition: "PERFORMING → REMEDY_PERIOD → ACCELERATION",
              codeFunction: "executeDefaultAcceleration()",
            },
          });
        } else {
          return res.json({
            answer: `This code exists to enforce **Clause 8.2 (Interest Payment Obligation)** in the Contract IR (OBLIGATION-0082). It calculates the accrued interest using the synthetic reference rate (SONIA) plus 1.75% spread and ensures funds are routed to the designated Paying Agent wallet before the maturity timestamp.`,
            provenance: {
              clause: "Clause 8.2",
              irId: "OBLIGATION-0082",
              formula: "Notional × (SONIA + Margin) × (Days / 365)",
              testCoverage: "TEST-004, TEST-012 (Passed)",
            },
          });
        }
      }

      const prompt = `You are the LEXEXEC Legal-Financial Reasoning Assistant.
Respond with high precision, authoritative legal terminology, and exact mathematical/computational rigor.

Contract Context: ${contractSummary || "Institutional Financial Agreement"}
Relevant Clause: ${clauseText || "Standard institutional terms"}
Relevant Code: ${codeSnippet || "Solidity smart contract module"}
User Question / Query (${queryType}): ${question}

Provide an authoritative, clear explanation with bullet points outlining:
1. Exact legal trigger & contractual provision
2. State machine transition sequence
3. Executable smart contract reaction & function invocations
4. Human review / Legal override requirements if applicable.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          temperature: 0.3,
        },
      });

      return res.json({
        answer: response.text || "No analysis available.",
        source: "gemini-3.8-flash",
      });
    } catch (err: any) {
      console.error("AI Query error:", err);
      return res.status(500).json({
        error: err?.message || "Failed to process query",
      });
    }
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`LEXEXEC Compiler & Execution Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
