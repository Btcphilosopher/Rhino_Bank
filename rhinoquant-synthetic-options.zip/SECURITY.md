# Security & Access Control

## 1. Institutional Security Policy
- **Zero Hardcoded Credentials**: API keys, credentials, and secrets are never embedded in source code.
- **Least-Privilege Role-Based Access Control (RBAC)**: Segregates Trader, Risk Officer, Quantitative Researcher, and Compliance roles.
- **Data Integrity**: Cryptographic hashing of audit trails prevents retroactive tampering with trade records or limit override events.
