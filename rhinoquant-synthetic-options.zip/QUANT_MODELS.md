# Quantitative Models & Mathematical Foundations

## 1. Black-Scholes-Merton (1973) with Continuous Dividend Yield
For European equity and index options:
$$d_1 = \frac{\ln(S/K) + (r - q + \frac{1}{2}\sigma^2)T}{\sigma \sqrt{T}}$$
$$d_2 = d_1 - \sigma \sqrt{T}$$

### European Call:
$$C = S e^{-q T} N(d_1) - K e^{-r T} N(d_2)$$

### European Put:
$$P = K e^{-r T} N(-d_2) - S e^{-q T} N(-d_1)$$

Where:
- $S$: Spot underlying price
- $K$: Strike price
- $T$: Time to maturity in annualized years ($D / 365$)
- $r$: Continuously compounded risk-free rate
- $q$: Continuous dividend yield / cost-of-carry
- $\sigma$: Implied volatility
- $N(x)$: Standard Normal Cumulative Distribution Function (Abramowitz & Stegun 7.1.26 approximation, error $< 1.5 \times 10^{-7}$).

---

## 2. Black-76 Model (Options on Futures & Commodities)
For options on forwards, commodity futures (e.g. WTI Crude), and interest rates:
$$d_1 = \frac{\ln(F/K) + \frac{1}{2}\sigma^2 T}{\sigma \sqrt{T}}$$
$$d_2 = d_1 - \sigma \sqrt{T}$$
$$C = e^{-r T} \left[F N(d_1) - K N(d_2)\right]$$
$$P = e^{-r T} \left[K N(-d_2) - F N(-d_1)\right]$$

---

## 3. Binomial Lattice (Cox-Ross-Rubinstein)
For American options with early exercise boundary:
$$\Delta t = \frac{T}{N}, \quad u = e^{\sigma \sqrt{\Delta t}}, \quad d = \frac{1}{u}, \quad p = \frac{e^{(r - q)\Delta t} - d}{u - d}$$

At each backward step $t_k$:
$$V_{i,k} = \max\left(\text{Intrinsic}(S_{i,k}), e^{-r \Delta t} [p V_{i, k+1} + (1-p) V_{i+1, k+1}]\right)$$

**Early Exercise Premium**:
$$\text{Premium}_{early} = V_{American} - V_{European}$$

---

## 4. Stochastic Volatility Inspired (SVI) Parametric Surface
The raw SVI total implied variance formulation parameterizes total variance $w(k) = \sigma^2 T$ against log-moneyness $k = \ln(K / F)$:
$$w(k) = a + b \left[\rho(k - m) + \sqrt{(k - m)^2 + \sigma^2}\right]$$
- $a \ge 0$: Overall variance level
- $b \ge 0$: Asymptotic slope of the wings
- $\rho \in (-1, 1)$: Skew / correlation (negative for equity downside skew)
- $m$: Horizontal translation (vertex location)
- $\sigma > 0$: Vertex curvature smoothness

---

## 5. Model Limitations & Governance
- **Black-Scholes**: Assumes log-normal distribution with constant volatility; fails to capture fat tails and skew without surface interpolation.
- **CRR Lattice**: Converges as $O(1/N)$; oscillation around early exercise boundary is mitigated using 80+ steps.
- **Monte Carlo**: Subject to statistical sampling error $\epsilon = \sigma / \sqrt{N}$; mitigated using antithetic pairs ($Z$ and $-Z$).
