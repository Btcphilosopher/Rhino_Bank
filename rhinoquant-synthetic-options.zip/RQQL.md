# RQQL — RhinoQuant Quant Language

**RQQL** is an institutional domain-specific language designed for fast terminal interaction, algorithmic position creation, and immediate risk querying.

## 1. Syntax & Commands

### Strategy Construction:
```rqql
SYNTHETIC LONG FORWARD STRIKE 5800 EXPIRY 90
SYNTHETIC SHORT FORWARD STRIKE 5800 EXPIRY 90
LONG STRADDLE STRIKE 5800 EXPIRY 30
```

### Analytical Evaluation:
```rqql
PRICE
GREEKS
```

### Risk & Hedging:
```rqql
HEDGE DELTA
SCENARIO SPOT +10%
SCENARIO SPOT -5%
STRESS VOL +15
```

## 2. Execution Pipeline
1. **Lexical Tokenization**: Standardizes keywords and parameters.
2. **Grammar Parsing**: Identifies target strategy or quantitative query.
3. **Execution Kernel**: Calls `SyntheticInstrumentEngine` and `HedgingEngine`.
4. **Structured Output**: Emits structured key metrics, diagnostics, and positions.
