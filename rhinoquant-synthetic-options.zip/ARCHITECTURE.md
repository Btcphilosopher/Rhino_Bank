# RhinoQuant Architecture & System Design

## 1. System Philosophy

RhinoQuant Synthetic Options follows an institutional clean architecture separating domain mathematics, financial instruments, risk computation, market data abstraction, and user interaction.

```
RhinoQuant Architecture
│
├── Domain Models (/domain/model/)
│   ├── Strongly typed Instrument Hierarchy (Spot, Future, Option, Forward, Swap, Cash)
│   ├── PositionLeg & Portfolio
│   ├── AuditEvent & ModelGovernanceRecord
│   └── RiskStatus & DataProvenance
│
├── Numerical & Pricing Engines (/domain/pricing/)
│   ├── BlackScholes.kt (BSM analytical formulas + 1st/2nd/3rd order Greeks)
│   ├── Black76.kt (Forward/Commodities/Futures options)
│   ├── BinomialCRR.kt (Cox-Ross-Rubinstein American lattice + early exercise)
│   └── MonteCarloEngine.kt (Antithetic variates, Barrier & Asian structures)
│
├── Volatility Engine (/domain/volatility/)
│   ├── ImpliedVolSolver.kt (Newton-Raphson + Brent Bisection fallback)
│   └── VolatilitySurface.kt (SVI parametric calibration, Skew, Smile, Term Structure)
│
├── Synthetics Engine (/domain/synthetics/)
│   ├── SyntheticInstrumentEngine.kt (Decomposition, Put-Call parity, replication)
│   └── StrategyLibrary.kt (Institutional templates: Forward, Box, Collar, Straddle, Condor)
│
├── Risk & Scenarios (/domain/risk/)
│   ├── ScenarioEngine.kt (2D/3D Scenario Cube, Stress testing presets, P&L attribution, MC VaR)
│   └── HedgingEngine.kt (Delta/Vega neutral solver, SPAN portfolio margin, Liquidity score)
│
├── Arbitrage & Financing (/domain/arbitrage/)
│   └── ArbitrageEngine.kt (Put-Call parity dislocation, Box implied financing vs SOFR, Futures basis)
│
├── Quant Language (/domain/rqql/)
│   └── RqqlEngine.kt (DSL lexer, parser, execution pipeline)
│
├── Market Data Abstraction (/domain/marketdata/)
│   ├── MarketDataEngine.kt (Multi-asset snapshot provider, Option Chain generator)
│   └── DataQualityEngine.kt (Crossed quotes, stale quotes, latency, provenance)
│
└── Institutional Terminal UI (/ui/)
    ├── HeaderBar & WorkspaceTabs (Dense Bloomberg/Refinitiv style terminal layout)
    ├── Workspaces (Workbench, Chain, Surface, Pricing, Scenarios, Arbitrage, Hedging, RQQL, Audit)
    └── PayoffCanvas (Vectorized mathematical payoff curve renderer)
```

## 2. Institutional Quant Design Principles
- **No Mock or Fake Logic**: Calculations derive from standard normal distributions, numerical derivatives, and stochastic differential equations.
- **Explicit Provenance**: Every quote and dataset carries explicit `DEMO`, `SIMULATED`, `HISTORICAL`, or `LIVE` metadata with health scores.
- **Atomic Package Routing**: Multi-leg orders explicitly highlight the execution advantage of atomic package routing over sequential leg-in risk.
