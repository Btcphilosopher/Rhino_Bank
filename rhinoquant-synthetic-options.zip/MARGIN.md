# Portfolio Margin & SPAN Scanning Engine

## 1. Margin Methodology
RhinoQuant implements an institutional portfolio margin framework aligning with CME SPAN and CBOE TIMS principles:
- **Defined Risk Positions**: Spreads (Bull Call, Bear Put, Iron Condor, Box Spreads, Collars) have margin strictly capped at their **maximum contractual loss**.
- **Unhedged Options**: Require $\max(15\% \times S \times \text{Multiplier} - \text{OTM Amount}, 10\% \times S \times \text{Multiplier})$.
- **Cross-Product Offsets**: Synthetic forwards and futures legs offset underlying delta, unlocking substantial capital efficiency.

## 2. Margin Categories
- **Initial Margin (IM)**: Capital required to initiate synthetic structures.
- **Maintenance Margin (MM)**: Minimum equity threshold ($80\%$ of IM) before margin call.
- **Variation Margin (VM)**: Daily mark-to-market settlement cashflow.
- **Margin Utilization**: $\text{IM} / \text{Equity} \times 100\%$ with threshold alerts:
  - Green: $< 55\%$
  - Amber: $55\% - 75\%$
  - Red: $75\% - 90\%$
  - Breach: $\ge 90\%$
