# RhinoQuant Synthetic Options Platform

**RhinoQuant Synthetic Options** is a production-grade institutional quantitative derivatives research, pricing, structuring, execution-analysis, and risk-management platform engineered for investment banks, quantitative hedge funds, proprietary trading desks, commodity trading houses, and asset managers.

---

## 1. Executive Summary

In institutional quantitative finance, option strategies are never treated as mere static drawings or retail payoff diagrams. Instead, every synthetic exposure is treated as a **mathematically defined portfolio of constituent financial instruments**:
- **Synthetic Long Forward**: $\text{Long Call}(K, T) + \text{Short Put}(K, T)$
- **Synthetic Short Forward**: $\text{Short Call}(K, T) + \text{Long Put}(K, T)$
- **Synthetic Long Call (Protective Put)**: $\text{Long Underlying}(S) + \text{Long Put}(K, T)$
- **Synthetic Long Put**: $\text{Short Underlying}(S) + \text{Long Call}(K, T)$
- **Box Spread Financing**: $\text{Bull Call Spread}(K_1, K_2) + \text{Bear Put Spread}(K_1, K_2)$
- **Zero-Cost Collar**: $\text{Long Underlying}(S) + \text{Long OTM Put} + \text{Short OTM Call}$

Every position mathematically resolves into explicit underlying legs, exposures, risk factors, and Greeks sensitivities.

---

## 2. Core Capabilities

1. **Synthetic Instrument Engine**:
   - Automatic multi-leg decomposition.
   - Put-call parity consistency verification: $C - P = S e^{-q T} - K e^{-r T}$.
   - Continuous replication analysis.

2. **Multi-Model Quantitative Pricing Engine**:
   - **Black-Scholes-Merton**: European equity and index derivatives with continuous dividend yield $q$ and rate $r$.
   - **Black-76**: Futures, commodities (e.g. WTI Crude), and interest rate derivatives.
   - **Binomial Cox-Ross-Rubinstein (CRR)**: American-style options with early exercise boundary and early exercise premium calculation.
   - **Antithetic Monte Carlo Simulation**: 20,000+ path path-dependent simulation for European, Asian arithmetic average, and Barrier structures.

3. **Implied Volatility & Surface Modeling**:
   - High-precision Newton-Raphson solver with Brent bisection fallback.
   - Strict no-arbitrage boundary enforcement ($C \ge \max(0, S e^{-qT} - K e^{-rT})$).
   - Parametric **SVI (Stochastic Volatility Inspired)** surface calibration:
     $$w(k) = a + b \left[\rho(k - m) + \sqrt{(k - m)^2 + \sigma^2}\right]$$
   - 25-Delta Risk Reversal ($IV_{25\Delta C} - IV_{25\Delta P}$) and 25-Delta Butterfly metrics.

4. **Analytical Greeks Engine (1st, 2nd, 3rd Order)**:
   - 1st Order: Delta ($\Delta$), Vega ($\mathcal{V}$), Theta ($\Theta$), Rho ($\rho$).
   - 2nd Order: Gamma ($\Gamma$), Vanna ($\partial \mathcal{V}/\partial S$), Volga / Volgamma ($\partial \mathcal{V}/\partial \sigma$), Charm ($\partial \Delta/\partial t$).
   - 3rd Order: Color ($\partial \Gamma/\partial t$), Speed ($\partial \Gamma/\partial S$), Zomma ($\partial \Gamma/\partial \sigma$).

5. **Risk, Scenarios & Tail Analysis**:
   - Multidimensional Scenario Cube (Underlying $\pm 20\% \times$ Volatility $\pm 10$ vol points).
   - Institutional Stress Presets: Vol Shock, Vol Crush, Tail Risk, Skew Steepening, Skew Flattening.
   - 1-Day 99% Monte Carlo Value at Risk (VaR) and Expected Shortfall (CVaR).
   - Taylor series P&L Attribution (Delta P&L, Gamma P&L, Vega P&L, Theta carry, Rho, Residual).

6. **Arbitrage & Box Spread Financing**:
   - Detection of Conversion & Reversal arbitrage after transaction costs.
   - Box Spread implied borrowing rate calculation vs SOFR benchmark.
   - Synthetic forward vs observed futures basis dislocation.

7. **Hedging & Execution Analytics**:
   - Automated Delta-neutral, Vega-neutral, and Gamma-neutral hedge rebalancing solver.
   - SPAN / Portfolio Margin simulation with cross-leg offset benefits.
   - Liquidity score, market impact estimate, and atomic package execution vs sequential legging risk warnings.

8. **RQQL (RhinoQuant Quant Language)**:
   - Dedicated institutional DSL for rapid strategy synthesis and risk interrogation:
     `SYNTHETIC LONG FORWARD STRIKE 5800 EXPIRY 90`
     `HEDGE DELTA`
     `SCENARIO SPOT +10%`
     `STRESS VOL +15`

9. **Model Governance & Immutable Audit**:
   - Traceable model calibrations, numerical tolerances, and approvals.
   - Immutable audit logs of all overrides, strategy constructions, and pre-trade tickets.
   - Automated institutional research memorandum synthesis.
