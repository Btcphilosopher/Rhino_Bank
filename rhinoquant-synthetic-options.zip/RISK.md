# Risk Management, Scenarios & Value at Risk

## 1. Multidimensional Scenario Cube
The scenario engine revalues the full portfolio across multidimensional shock matrices:
- **Underlying Spot Shifts**: $-20\%, -10\%, -5\%, 0\%, +5\%, +10\%, +20\%$
- **Volatility Shifts**: $-10, -5, 0, +5, +10 \text{ vol points}$
- **Time Decay**: $0, 7, 14, 30 \text{ days}$
- **Rates Shifts**: $\pm 100 \text{ bps}$

## 2. Institutional Stress Presets
1. **VOL_SHOCK**: Spot $-10\%$, Vol $+15.0$ pts, $2$ days time decay.
2. **VOL_CRUSH**: Spot $+4\%$, Vol $-10.0$ pts.
3. **TAIL_RISK_LIQUIDATION**: Spot $-25\%$, Vol $+25.0$ pts.
4. **RATES_UP_INFLATION**: Spot $-5\%$, Vol $+5.0$ pts, Rates $+150$ bps.
5. **SKEW_STEEPENING**: OTM Put vol $+8.0$ pts, OTM Call vol $-2.0$ pts.

## 3. Taylor Series P&L Attribution
Decomposes daily P&L into exact Greek drivers:
$$\Delta\Pi \approx \Delta \cdot \Delta S + \frac{1}{2}\Gamma (\Delta S)^2 + \mathcal{V} \cdot \Delta\sigma + \Theta \cdot \Delta t + \rho \cdot \Delta r + \text{Carry} + \epsilon_{\text{residual}}$$

## 4. Value at Risk (VaR) & Expected Shortfall (CVaR)
- **1-Day 95% and 99% VaR**: Parametric and Monte Carlo historical quantile cutoff.
- **Expected Shortfall (CVaR)**: Expected loss beyond the VaR threshold:
  $$\text{ES}_\alpha = -\mathbb{E}\left[X \mid X \le -\text{VaR}_\alpha\right]$$
