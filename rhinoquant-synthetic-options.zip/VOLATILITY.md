# Volatility Engine & Surface Modeling

## 1. Implied Volatility Solver
RhinoQuant uses a dual-phase solver:
1. **Newton-Raphson Iteration**:
   $$\sigma_{n+1} = \sigma_n - \frac{V_{BS}(\sigma_n) - V_{mkt}}{\mathcal{V}(\sigma_n)}$$
   Uses analytical unscaled Vega step. Converges in $< 5$ iterations for near-the-money options.
2. **Brent-Bisection Fallback**:
   Triggered automatically when Vega $< 10^{-7}$ (deep in-the-money or out-of-the-money) or when Newton steps escape the $[0.1\%, 500\%]$ domain.
3. **No-Arbitrage Guards**:
   Rejects prices violating theoretical bounds:
   $$\max(0, S e^{-q T} - K e^{-r T}) \le C \le S e^{-q T}$$
   Flags `NO_ARBITRAGE_SOLUTION` rather than returning numerical garbage.

## 2. Volatility Surface Structure
Dimensions:
$$\text{Strike } (K) \times \text{Expiry } (T) \times \text{Implied Volatility } (\sigma) \times \text{Moneyness } (K/S) \times \text{Delta } (\Delta)$$

## 3. Surface Metrics
- **ATM Term Structure**: Forward volatility curve across tenors (30D, 60D, 90D, 180D, 365D).
- **25-Delta Risk Reversal**:
  $$\text{RR}_{25\Delta} = \sigma(25\Delta \text{ Call}) - \sigma(25\Delta \text{ Put})$$
  Measures institutional directional skew and fear premium.
- **25-Delta Butterfly**:
  $$\text{BF}_{25\Delta} = \frac{\sigma(25\Delta \text{ Call}) + \sigma(25\Delta \text{ Put})}{2} - \sigma_{ATM}$$
  Measures wing convexity and tail risk expectations.
