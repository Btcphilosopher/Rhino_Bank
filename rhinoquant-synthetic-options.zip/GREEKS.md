# Greeks Engine & Sensitivities Hierarchy

RhinoQuant implements exact analytical derivatives for first, second, and third-order sensitivities.

## 1. First-Order Greeks
- **Delta ($\Delta = \frac{\partial V}{\partial S}$)**:
  - Call: $\Delta_C = e^{-q T} N(d_1)$
  - Put: $\Delta_P = -e^{-q T} N(-d_1)$
- **Vega ($\mathcal{V} = \frac{\partial V}{\partial \sigma}$)**:
  $$\mathcal{V} = S e^{-q T} \sqrt{T} n(d_1) \times 0.01 \quad (\text{per 1\% vol})$$
- **Theta ($\Theta = \frac{\partial V}{\partial t}$)**:
  $$\Theta_C = -\frac{S e^{-q T} n(d_1) \sigma}{2 \sqrt{T}} - r K e^{-r T} N(d_2) + q S e^{-q T} N(d_1) \quad (\div 365 \text{ for daily carry})$$
- **Rho ($\rho = \frac{\partial V}{\partial r}$)**:
  $$\rho_C = K T e^{-r T} N(d_2) \times 0.01 \quad (\text{per 100 bps})$$

## 2. Second-Order Greeks
- **Gamma ($\Gamma = \frac{\partial^2 V}{\partial S^2}$)**:
  $$\Gamma = \frac{e^{-q T} n(d_1)}{S \sigma \sqrt{T}}$$
- **Vanna ($\frac{\partial \mathcal{V}}{\partial S} = \frac{\partial \Delta}{\partial \sigma}$)**:
  $$\text{Vanna} = -\frac{e^{-q T} n(d_1) d_2}{\sigma} \times 0.01$$
- **Volga / Volgamma ($\frac{\partial^2 V}{\partial \sigma^2}$)**:
  $$\text{Volga} = \mathcal{V} \frac{d_1 d_2}{\sigma} \times 0.01$$
- **Charm ($\frac{\partial \Delta}{\partial t}$)**:
  Time decay of Delta per calendar day.

## 3. Third-Order Greeks
- **Color ($\frac{\partial \Gamma}{\partial t}$)**: Rate of Gamma decay over time.
- **Speed ($\frac{\partial \Gamma}{\partial S}$)**: Rate of change of Gamma with respect to underlying spot price.
- **Zomma ($\frac{\partial \Gamma}{\partial \sigma}$)**: Rate of change of Gamma with respect to implied volatility.
