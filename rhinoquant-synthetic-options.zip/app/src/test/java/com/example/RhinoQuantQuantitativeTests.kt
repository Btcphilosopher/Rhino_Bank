package com.example

import com.example.domain.arbitrage.ArbitrageEngine
import com.example.domain.model.*
import com.example.domain.pricing.*
import com.example.domain.risk.HedgingEngine
import com.example.domain.risk.ScenarioEngine
import com.example.domain.rqql.RqqlEngine
import com.example.domain.synthetics.StrategyLibrary
import com.example.domain.synthetics.SyntheticInstrumentEngine
import com.example.domain.volatility.ImpliedVolSolver
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs
import kotlin.math.exp

class RhinoQuantQuantitativeTests {

    private val S = 5800.0
    private val K = 5800.0
    private val T = 90.0 / 365.0
    private val r = 0.045
    private val q = 0.015
    private val sigma = 0.18

    @Test
    fun testPutCallParityExactRelationship() {
        // C - P = S*e^(-qT) - K*e^(-rT)
        val callPrice = BlackScholes.price(S, K, T, r, q, sigma, OptionType.CALL)
        val putPrice = BlackScholes.price(S, K, T, r, q, sigma, OptionType.PUT)

        val actualDiff = callPrice - putPrice
        val theoreticalDiff = S * exp(-q * T) - K * exp(-r * T)

        assertEquals("Put-Call Parity must hold analytically", theoreticalDiff, actualDiff, 1e-4)
    }

    @Test
    fun testDeltaNumericalDerivativeConsistency() {
        // Analytical Delta vs Central Finite Difference: (V(S + dS) - V(S - dS)) / (2*dS)
        val dS = 0.01
        val callBase = BlackScholes.priceAndGreeks(S, K, T, r, q, sigma, OptionType.CALL)
        val callUp = BlackScholes.price(S + dS, K, T, r, q, sigma, OptionType.CALL)
        val callDown = BlackScholes.price(S - dS, K, T, r, q, sigma, OptionType.CALL)

        val finiteDiffDelta = (callUp - callDown) / (2.0 * dS)
        assertEquals("Delta must match central finite difference", finiteDiffDelta, callBase.delta, 1e-4)

        // Gamma numerical derivative: (V(S+dS) - 2*V(S) + V(S-dS)) / (dS^2)
        val finiteDiffGamma = (callUp - 2.0 * callBase.price + callDown) / (dS * dS)
        assertEquals("Gamma must match second derivative finite difference", finiteDiffGamma, callBase.gamma, 1e-4)
    }

    @Test
    fun testVegaNumericalDerivative() {
        val dVol = 0.001
        val callBase = BlackScholes.priceAndGreeks(S, K, T, r, q, sigma, OptionType.CALL)
        val callUp = BlackScholes.price(S, K, T, r, q, sigma + dVol, OptionType.CALL)
        val callDown = BlackScholes.price(S, K, T, r, q, sigma - dVol, OptionType.CALL)

        val numericalVegaPer1Pct = ((callUp - callDown) / (2.0 * dVol)) * 0.01
        assertEquals("Vega must match finite difference", numericalVegaPer1Pct, callBase.vega, 1e-4)
    }

    @Test
    fun testImpliedVolatilitySolverConvergence() {
        val targetVol = 0.235
        val callMarket = BlackScholes.price(S, K, T, r, q, targetVol, OptionType.CALL)

        val solved = ImpliedVolSolver.solve(callMarket, S, K, T, r, q, OptionType.CALL)
        assertEquals("Solver must converge to target vol", SolverStatus.CONVERGED, solved.status)
        assertEquals("Solved IV must equal original vol", targetVol, solved.impliedVol, 1e-4)
    }

    @Test
    fun testImpliedVolatilityNoArbitrageViolation() {
        // Price below intrinsic bound must reject
        val brokenPrice = 1.0 // Deep below minimum boundary
        val solved = ImpliedVolSolver.solve(brokenPrice, S, K, T, r, q, OptionType.CALL)
        assertEquals("Must flag NO_ARBITRAGE_SOLUTION", SolverStatus.NO_ARBITRAGE_SOLUTION, solved.status)
    }

    @Test
    fun testSyntheticLongForwardDecomposition() {
        val template = StrategyLibrary.templates.find { it.id == "SYNTH_LONG_FWD" }!!
        val legs = template.legGenerator(S, 90.0, sigma)

        val decomp = SyntheticInstrumentEngine.decomposePortfolio(legs, S, r, q)
        assertEquals("Must detect SYNTHETIC_LONG_FORWARD", "SYNTHETIC_LONG_FORWARD", decomp.detectedSyntheticType)
        // Delta of synthetic long forward should be close to 1.0 (due to 100 multiplier)
        assertTrue("Synthetic long forward must have strong positive delta", decomp.greeks.netDelta > 0.90)
    }

    @Test
    fun testBoxSpreadImpliedFinancing() {
        val k1 = S * 0.95
        val k2 = S * 1.05
        val c1 = BlackScholes.price(S, k1, T, r, q, sigma, OptionType.CALL)
        val c2 = BlackScholes.price(S, k2, T, r, q, sigma, OptionType.CALL)
        val p1 = BlackScholes.price(S, k1, T, r, q, sigma, OptionType.PUT)
        val p2 = BlackScholes.price(S, k2, T, r, q, sigma, OptionType.PUT)

        val box = ArbitrageEngine.analyzeBoxSpread(k1, k2, 90.0, c1, c2, p1, p2, 0.045)
        assertTrue("Box spread implied rate must be positive and close to risk-free rate", box.impliedBorrowRate in 0.03..0.06)
    }

    @Test
    fun testDeltaNeutralHedging() {
        val call = OptionInstrument("TEST_C", AssetClass.INDEX, "SPX", marketPrice = 150.0, bid = 149.0, ask = 151.0, optionType = OptionType.CALL, strike = S, expiryDays = 90.0, impliedVolatility = sigma)
        val leg = PositionLeg("leg-1", Side.BUY, 10.0, call)
        val spotInst = SpotInstrument("SPX_SPOT", AssetClass.INDEX, "SPX", marketPrice = S, bid = S - 0.25, ask = S + 0.25)

        val hedge = HedgingEngine.computeHedge(listOf(leg), S, r, q, spotInst, "DELTA")
        assertEquals("Hedge must recommend selling underlying for long calls", Side.SELL, hedge.recommendedSide)
        assertTrue("Residual post-hedge delta must be near zero", abs(hedge.postHedgeDelta) < 1e-4)
    }

    @Test
    fun testRqqlParsingAndExecution() {
        val legs = emptyList<PositionLeg>()
        val res = RqqlEngine.execute("SYNTHETIC LONG FORWARD STRIKE 5800 EXPIRY 90", legs, S, r, q, sigma)
        assertTrue("RQQL command must succeed", res.isSuccess)
        assertNotNull("Must generate position legs", res.generatedLegs)
        assertEquals("Must generate 2 legs", 2, res.generatedLegs!!.size)
    }
}
