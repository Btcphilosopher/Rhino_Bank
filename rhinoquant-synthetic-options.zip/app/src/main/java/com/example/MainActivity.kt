package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.RhinoQuantViewModel
import com.example.ui.TerminalWorkspace
import com.example.ui.components.HeaderBar
import com.example.ui.components.WorkspaceTabs
import com.example.ui.screens.*
import com.example.ui.theme.RhinoBgDark
import com.example.ui.theme.RhinoQuantTheme

class MainActivity : ComponentActivity() {

    private val viewModel: RhinoQuantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val uiState by viewModel.uiState.collectAsState()

            RhinoQuantTheme(darkTheme = uiState.isDarkTheme) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(RhinoBgDark)
                    ) {
                        HeaderBar(
                            selectedUnderlying = uiState.selectedUnderlying,
                            availableUnderlyings = com.example.domain.marketdata.MarketDataEngine.underlyings,
                            selectedExpiryDays = uiState.selectedExpiryDays,
                            onSelectUnderlying = { viewModel.selectUnderlying(it) },
                            onSelectExpiry = { viewModel.selectExpiry(it) },
                            onQuickRqql = { viewModel.executeRqqlCommand(it) },
                            isDarkTheme = uiState.isDarkTheme,
                            onToggleTheme = { viewModel.toggleTheme() }
                        )

                        WorkspaceTabs(
                            currentWorkspace = uiState.currentWorkspace,
                            onSelectWorkspace = { viewModel.setWorkspace(it) }
                        )

                        Box(modifier = Modifier.fillMaxSize()) {
                            when (uiState.currentWorkspace) {
                                TerminalWorkspace.WORKBENCH -> WorkbenchWorkspace(uiState, viewModel)
                                TerminalWorkspace.CHAIN -> OptionChainWorkspace(uiState, viewModel)
                                TerminalWorkspace.SURFACE -> VolSurfaceWorkspace(uiState)
                                TerminalWorkspace.PRICING -> PricingWorkspace(uiState, viewModel)
                                TerminalWorkspace.SCENARIO -> ScenarioWorkspace(uiState, viewModel)
                                TerminalWorkspace.ARBITRAGE -> ArbitrageWorkspace(uiState, viewModel)
                                TerminalWorkspace.HEDGING -> HedgingWorkspace(uiState, viewModel)
                                TerminalWorkspace.RQQL -> RqqlWorkspace(uiState, viewModel)
                                TerminalWorkspace.RESEARCH -> ResearchAndAuditWorkspace(uiState, viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
