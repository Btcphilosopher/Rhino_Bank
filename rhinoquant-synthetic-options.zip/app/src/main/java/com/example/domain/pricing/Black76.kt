package com.example.domain.pricing

import com.example.domain.model.OptionType
import kotlin.math.*

object Black76 {

    fun priceAndGreeks(
        F: Double,
        K: Double,
        T: Double,
        r: Double,
        sigma: Double,
        type: OptionType
    ): PricingResult {
        val safeF = max(1e-4, F)
        val safeK = max(1e-4, K)
        val safeT = max(1e-6, T)
        val safeVol = max(1e-4, sigma)

        val sqrtT = sqrt(safeT)
        val d1 = (ln(safeF / safeK) + 0.5 * safeVol * safeVol * safeT) / (safeVol * sqrtT)
        val d2 = d1 - safeVol * sqrtT

        val erT = exp(-r * safeT)
        val nd1 = BlackScholes.normCdf(d1)
        val nd2 = BlackScholes.normCdf(d2)
        val npd1 = BlackScholes.normPdf(d1)

        val price: Double
        val delta: Double
        val intrinsic: Double

        if (type == OptionType.CALL) {
            price = erT * (safeF * nd1 - safeK * nd2)
            delta = erT * nd1
            intrinsic = max(0.0, safeF - safeK)
        } else {
            val n_minus_d1 = BlackScholes.normCdf(-d1)
            val n_minus_d2 = BlackScholes.normCdf(-d2)
            price = erT * (safeK * n_minus_d2 - safeF * n_minus_d1)
            delta = -erT * n_minus_d1
            intrinsic = max(0.0, safeK - safeF)
        }

        val boundedPrice = max(0.0, price)
        val timeValue = max(0.0, boundedPrice - intrinsic)

        val gamma = (erT * npd1) / (safeF * safeVol * sqrtT)
        val vega = (safeF * erT * sqrtT * npd1) * 0.01

        val rawTheta = if (type == OptionType.CALL) {
            -(safeF * erT * npd1 * safeVol) / (2.0 * sqrtT) - r * boundedPrice
        } else {
            -(safeF * erT * npd1 * safeVol) / (2.0 * sqrtT) - r * boundedPrice
        }
        val thetaPerDay = rawTheta / 365.0
        val rho = -safeT * boundedPrice * 0.01

        val vanna = (-erT * npd1 * d2 / safeVol) * 0.01
        val volga = (vega * d1 * d2 / safeVol) * 0.01
        val charm = (-r * delta - erT * npd1 * d2 / (2.0 * safeT)) / 365.0
        val color = -gamma * (r + (1.0 - d1 * d2) / (2.0 * safeT)) / 365.0
        val speed = -gamma / safeF * (d1 / (safeVol * sqrtT) + 1.0)
        val zomma = gamma * (d1 * d2 - 1.0) / safeVol

        return PricingResult(
            price = boundedPrice,
            intrinsicValue = intrinsic,
            timeValue = timeValue,
            d1 = d1,
            d2 = d2,
            delta = delta,
            gamma = gamma,
            vega = vega,
            theta = thetaPerDay,
            rho = rho,
            vanna = vanna,
            volga = volga,
            charm = charm,
            color = color,
            speed = speed,
            zomma = zomma
        )
    }
}
