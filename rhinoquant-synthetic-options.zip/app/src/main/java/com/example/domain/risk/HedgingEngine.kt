package com.example.domain.risk

import com.example.domain.model.*
import com.example.domain.pricing.BlackScholes
import com.example.domain.synthetics.PortfolioGreeks
import com.example.domain.synthetics.SyntheticInstrumentEngine
import kotlin.math.*

data class HedgeRecommendation(
    val hedgeTarget: String,
    val recommendedInstrument: Instrument,
    val recommendedSide: Side,
    val recommendedQuantity: Double,
    val tradeNotional: Double,
    val postHedgeDelta: Double,
    val postHedgeGamma: Double,
    val postHedgeVega: Double,
    val postHedgeTheta: Double,
    val postHedgeMarginDelta: Double,
    val executionNotes: String
)

data class MarginRequirements(
    val initialMargin: Double,
    val maintenanceMargin: Double,
    val variationMargin: Double,
    val spanMaxScanningLoss: Double,
    val netOffsetBenefit: Double,
    val marginUtilizationPercent: Double,
    val marginStatus: RiskStatus
)

data class LiquidityMetrics(
    val strategyLiquidityScore: Int,      // 0 to 100
    val estimatedSlippage: Double,
    val estimatedMarketImpactBps: Double,
    val leggingRiskWarning: String,
    val packageExecutionAdvantage: String
)

object HedgingEngine {

    /**
     * Solves for the optimal hedge position to neutralize selected Greek exposures.
     */
    fun computeHedge(
        legs: List<PositionLeg>,
        spot: Double,
        rate: Double,
        divYield: Double,
        hedgeInstrument: Instrument,
        targetGreek: String = "DELTA"
    ): HedgeRecommendation {
        val currentGreeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(legs, spot, rate, divYield)

        var neededQty = 0.0
        var side = Side.SELL
        var note = ""

        when (targetGreek) {
            "DELTA" -> {
                // Hedge using underlying or future
                val instrumentDelta = when (hedgeInstrument) {
                    is SpotInstrument -> 1.0 * hedgeInstrument.priceMultiplier
                    is FutureInstrument -> exp((rate - divYield) * (hedgeInstrument.expiryDays / 365.0)) * hedgeInstrument.priceMultiplier
                    is OptionInstrument -> {
                        val pr = BlackScholes.priceAndGreeks(
                            spot, hedgeInstrument.strike, hedgeInstrument.expiryDays / 365.0,
                            rate, divYield, hedgeInstrument.impliedVolatility, hedgeInstrument.optionType
                        )
                        pr.delta * hedgeInstrument.priceMultiplier
                    }
                    else -> 1.0
                }

                val netDelta = currentGreeks.netDelta
                val contractsNeeded = -netDelta / instrumentDelta

                side = if (contractsNeeded >= 0) Side.BUY else Side.SELL
                neededQty = abs(contractsNeeded)
                note = "Delta Neutral: Neutralizes portfolio Delta ($netDelta) to 0.0 using ${hedgeInstrument.instrumentId}."
            }

            "VEGA" -> {
                val instVega = if (hedgeInstrument is OptionInstrument) {
                    val pr = BlackScholes.priceAndGreeks(
                        spot, hedgeInstrument.strike, hedgeInstrument.expiryDays / 365.0,
                        rate, divYield, hedgeInstrument.impliedVolatility, hedgeInstrument.optionType
                    )
                    pr.vega * hedgeInstrument.priceMultiplier
                } else 1.0

                val netVega = currentGreeks.netVega
                val contractsNeeded = -netVega / instVega
                side = if (contractsNeeded >= 0) Side.BUY else Side.SELL
                neededQty = abs(contractsNeeded)
                note = "Vega Neutral: Neutralizes portfolio Vega ($netVega) against volatility shocks."
            }

            "GAMMA" -> {
                val instGamma = if (hedgeInstrument is OptionInstrument) {
                    val pr = BlackScholes.priceAndGreeks(
                        spot, hedgeInstrument.strike, hedgeInstrument.expiryDays / 365.0,
                        rate, divYield, hedgeInstrument.impliedVolatility, hedgeInstrument.optionType
                    )
                    pr.gamma * hedgeInstrument.priceMultiplier
                } else 1.0

                val netGamma = currentGreeks.netGamma
                val contractsNeeded = -netGamma / instGamma
                side = if (contractsNeeded >= 0) Side.BUY else Side.SELL
                neededQty = abs(contractsNeeded)
                note = "Gamma Neutral: Eliminates non-linear convexity risk."
            }
        }

        // Calculate post-hedge Greeks
        val hedgeLeg = PositionLeg(
            id = "hedge-leg",
            side = side,
            quantity = neededQty,
            instrument = hedgeInstrument
        )
        val combinedLegs = legs + hedgeLeg
        val postGreeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(combinedLegs, spot, rate, divYield)

        val notional = neededQty * hedgeInstrument.marketPrice * hedgeInstrument.priceMultiplier

        return HedgeRecommendation(
            hedgeTarget = targetGreek,
            recommendedInstrument = hedgeInstrument,
            recommendedSide = side,
            recommendedQuantity = neededQty,
            tradeNotional = notional,
            postHedgeDelta = postGreeks.netDelta,
            postHedgeGamma = postGreeks.netGamma,
            postHedgeVega = postGreeks.netVega,
            postHedgeTheta = postGreeks.netTheta,
            postHedgeMarginDelta = notional * 0.15,
            executionNotes = note
        )
    }

    /**
     * Calculates institutional SPAN / portfolio margin with cross-leg offsets.
     */
    fun calculateMargin(
        legs: List<PositionLeg>,
        spot: Double,
        rate: Double,
        divYield: Double,
        accountEquity: Double = 500_000.0
    ): MarginRequirements {
        val greeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(legs, spot, rate, divYield)
        val payoff = SyntheticInstrumentEngine.evaluatePayoff(legs, spot)

        // Standard portfolio margin rules:
        // Capped risk structures (spreads/collars/box) have margin limited to maximum defined loss.
        // Naked positions require 15% underlying notional plus out-of-the-money amount.
        var grossUnhedgedMargin = 0.0

        for (leg in legs) {
            val notional = leg.quantity * leg.instrument.marketPrice * leg.instrument.priceMultiplier
            grossUnhedgedMargin += when (val inst = leg.instrument) {
                is SpotInstrument -> notional * 0.50 // Reg-T 50% equity margin
                is FutureInstrument -> notional * 0.08 // CME E-mini futures ~8% margin
                is OptionInstrument -> {
                    if (leg.side == Side.SELL) {
                        // Short option margin: max(20% underlying - OTM, 10% underlying)
                        val otmAmount = if (inst.optionType == OptionType.CALL) max(0.0, inst.strike - spot) else max(0.0, spot - inst.strike)
                        val undNotional = leg.quantity * spot * inst.priceMultiplier
                        max(undNotional * 0.15 - otmAmount * leg.quantity * inst.priceMultiplier, undNotional * 0.10)
                    } else {
                        // Long option: paid in full
                        leg.quantity * inst.marketPrice * inst.priceMultiplier
                    }
                }
                else -> notional * 0.20
            }
        }

        // Net portfolio margin offset benefit:
        val maxPotentialLoss = abs(payoff.maxLoss).coerceAtLeast(0.0)
        val netRequiredMargin = min(grossUnhedgedMargin, maxPotentialLoss + 5000.0)
        val maintenance = netRequiredMargin * 0.80
        val offsetBenefit = grossUnhedgedMargin - netRequiredMargin

        val utilization = (netRequiredMargin / accountEquity) * 100.0
        val status = when {
            utilization >= 90.0 -> RiskStatus.BREACH
            utilization >= 75.0 -> RiskStatus.RED
            utilization >= 55.0 -> RiskStatus.AMBER
            else -> RiskStatus.GREEN
        }

        return MarginRequirements(
            initialMargin = netRequiredMargin,
            maintenanceMargin = maintenance,
            variationMargin = greeks.netPrice * 0.02,
            spanMaxScanningLoss = maxPotentialLoss,
            netOffsetBenefit = offsetBenefit,
            marginUtilizationPercent = utilization,
            marginStatus = status
        )
    }

    /**
     * Institutional liquidity analysis:
     * Assesses market impact, slippage, and simultaneous package execution vs sequential legging risk.
     */
    fun evaluateLiquidity(
        legs: List<PositionLeg>,
        totalNotional: Double
    ): LiquidityMetrics {
        var weightedSpreadBps = 0.0
        var totalCost = 0.0

        for (leg in legs) {
            val mid = 0.5 * (leg.instrument.bid + leg.instrument.ask)
            val spread = leg.instrument.ask - leg.instrument.bid
            val spreadBps = if (mid > 0) (spread / mid) * 10_000.0 else 50.0
            val cost = leg.quantity * mid * leg.instrument.priceMultiplier
            weightedSpreadBps += spreadBps * cost
            totalCost += cost
        }

        val avgSpreadBps = if (totalCost > 0) weightedSpreadBps / totalCost else 25.0
        val slippageDollars = (avgSpreadBps / 10_000.0) * totalNotional * 0.5

        // Square-root market impact model: Impact = gamma * sigma * sqrt(Q / V)
        val impactBps = min(45.0, 3.5 * sqrt(legs.sumOf { it.quantity } / 50.0))

        val score = (100.0 - avgSpreadBps * 0.8 - impactBps * 0.5).toInt().coerceIn(15, 98)

        val leggingRisk = if (legs.size > 1) {
            "CRITICAL: Sequential execution exposes portfolio to ${legs.size}-leg market slippage. Execute as a single atomic RFQ / CME Package order to eliminate legging hazard."
        } else {
            "LOW: Single leg order has minimal execution divergence risk."
        }

        val packageAdvantage = "Package order guarantees atomic simultaneous execution across all ${legs.size} legs at fixed net credit/debit, saving est. $${String.format("%.2f", slippageDollars * 0.40)} in execution drag."

        return LiquidityMetrics(
            strategyLiquidityScore = score,
            estimatedSlippage = slippageDollars,
            estimatedMarketImpactBps = impactBps,
            leggingRiskWarning = leggingRisk,
            packageExecutionAdvantage = packageAdvantage
        )
    }
}
