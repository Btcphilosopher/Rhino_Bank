package com.example.domain.volatility

import com.example.domain.model.OptionType
import com.example.domain.model.SolverStatus
import com.example.domain.pricing.BlackScholes
import kotlin.math.*

data class ImpliedVolResult(
    val impliedVol: Double,
    val status: SolverStatus,
    val iterations: Int,
    val residualError: Double,
    val modelPrice: Double,
    val marketPrice: Double,
    val message: String
)

object ImpliedVolSolver {

    private const val MAX_ITERATIONS = 100
    private const val TOLERANCE = 1e-6
    private const val MIN_VOL = 0.001 // 0.1%
    private const val MAX_VOL = 5.0   // 500%

    /**
     * Solves for Black-Scholes implied volatility given market price.
     */
    fun solve(
        marketPrice: Double,
        S: Double,
        K: Double,
        T: Double,
        r: Double,
        q: Double,
        type: OptionType
    ): ImpliedVolResult {
        if (marketPrice <= 0.0 || marketPrice.isNaN()) {
            return ImpliedVolResult(
                impliedVol = 0.0,
                status = SolverStatus.STALE_MARKET,
                iterations = 0,
                residualError = marketPrice,
                modelPrice = 0.0,
                marketPrice = marketPrice,
                message = "STALE MARKET: Non-positive or invalid market quote"
            )
        }

        if (T <= 1e-6) {
            return ImpliedVolResult(
                impliedVol = 0.0,
                status = SolverStatus.MODEL_FAILED,
                iterations = 0,
                residualError = 0.0,
                modelPrice = marketPrice,
                marketPrice = marketPrice,
                message = "MODEL FAILED: Option at or past expiration"
            )
        }

        val eqT = exp(-q * T)
        val erT = exp(-r * T)

        // Strict No-Arbitrage Bounds
        val lowerBound = if (type == OptionType.CALL) {
            max(0.0, S * eqT - K * erT)
        } else {
            max(0.0, K * erT - S * eqT)
        }

        val upperBound = if (type == OptionType.CALL) {
            S * eqT
        } else {
            K * erT
        }

        if (marketPrice < lowerBound - 1e-4) {
            return ImpliedVolResult(
                impliedVol = Double.NaN,
                status = SolverStatus.NO_ARBITRAGE_SOLUTION,
                iterations = 0,
                residualError = lowerBound - marketPrice,
                modelPrice = lowerBound,
                marketPrice = marketPrice,
                message = "NO ARBITRAGE SOLUTION: Quote breaks lower theoretical bound ($lowerBound)"
            )
        }

        if (marketPrice > upperBound + 1e-4) {
            return ImpliedVolResult(
                impliedVol = Double.NaN,
                status = SolverStatus.NO_ARBITRAGE_SOLUTION,
                iterations = 0,
                residualError = marketPrice - upperBound,
                modelPrice = upperBound,
                marketPrice = marketPrice,
                message = "NO ARBITRAGE SOLUTION: Quote exceeds maximum asset bound ($upperBound)"
            )
        }

        // Initial Volatility Guess using Brenner-Subrahmanyam ATM approximation
        var sigma = sqrt(2.0 * Math.PI / T) * (marketPrice / S).coerceIn(0.05, 3.0)
        sigma = sigma.coerceIn(0.10, 0.80)

        // Phase 1: Newton-Raphson Iteration
        var iterations = 0
        var residual = 0.0

        for (i in 0 until 35) {
            iterations++
            val pricing = BlackScholes.priceAndGreeks(S, K, T, r, q, sigma, type)
            val modelPrice = pricing.price
            residual = modelPrice - marketPrice

            if (abs(residual) < TOLERANCE) {
                return ImpliedVolResult(
                    impliedVol = sigma,
                    status = SolverStatus.CONVERGED,
                    iterations = iterations,
                    residualError = abs(residual),
                    modelPrice = modelPrice,
                    marketPrice = marketPrice,
                    message = "CONVERGED via Newton-Raphson"
                )
            }

            // Raw unscaled vega (dPrice / dSigma)
            val rawVega = pricing.vega * 100.0

            if (rawVega < 1e-7 || rawVega.isNaN()) {
                // Vega is too flat (deep ITM / deep OTM) - break to Brent / Bisection
                break
            }

            val step = residual / rawVega
            val nextSigma = sigma - step

            if (nextSigma < MIN_VOL || nextSigma > MAX_VOL || step.isNaN()) {
                break
            }

            sigma = nextSigma
        }

        // Phase 2: Brent / Bisection fallback for difficult regions
        var a = MIN_VOL
        var b = MAX_VOL
        var fa = BlackScholes.price(S, K, T, r, q, a, type) - marketPrice
        var fb = BlackScholes.price(S, K, T, r, q, b, type) - marketPrice

        if (fa * fb > 0.0) {
            // Cannot bracket within [0.001, 5.0]
            val finalPrice = BlackScholes.price(S, K, T, r, q, sigma, type)
            return ImpliedVolResult(
                impliedVol = sigma,
                status = SolverStatus.OUTLIER,
                iterations = iterations,
                residualError = abs(finalPrice - marketPrice),
                modelPrice = finalPrice,
                marketPrice = marketPrice,
                message = "OUTLIER: Solution outside extreme bounds [0.1%, 500%]"
            )
        }

        for (j in 0 until 65) {
            iterations++
            val mid = 0.5 * (a + b)
            val fMid = BlackScholes.price(S, K, T, r, q, mid, type) - marketPrice

            if (abs(fMid) < TOLERANCE || (b - a) < 1e-5) {
                val finalPrice = BlackScholes.price(S, K, T, r, q, mid, type)
                return ImpliedVolResult(
                    impliedVol = mid,
                    status = SolverStatus.CONVERGED,
                    iterations = iterations,
                    residualError = abs(fMid),
                    modelPrice = finalPrice,
                    marketPrice = marketPrice,
                    message = "CONVERGED via Brent Bisection fallback"
                )
            }

            if (fa * fMid < 0.0) {
                b = mid
                fb = fMid
            } else {
                a = mid
                fa = fMid
            }
        }

        val finalMid = 0.5 * (a + b)
        val finalPrice = BlackScholes.price(S, K, T, r, q, finalMid, type)
        return ImpliedVolResult(
            impliedVol = finalMid,
            status = if (abs(finalPrice - marketPrice) < 0.01) SolverStatus.CONVERGED else SolverStatus.MODEL_FAILED,
            iterations = iterations,
            residualError = abs(finalPrice - marketPrice),
            modelPrice = finalPrice,
            marketPrice = marketPrice,
            message = "Terminated after max iterations"
        )
    }
}
