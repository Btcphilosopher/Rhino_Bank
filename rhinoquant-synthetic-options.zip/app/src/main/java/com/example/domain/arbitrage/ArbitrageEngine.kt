package com.example.domain.arbitrage

import com.example.domain.model.OptionInstrument
import com.example.domain.model.OptionType
import kotlin.math.*

data class PutCallParityCheck(
    val strike: Double,
    val expiryDays: Double,
    val callBid: Double,
    val callAsk: Double,
    val putBid: Double,
    val putAsk: Double,
    val spot: Double,
    val rate: Double,
    val divYield: Double,
    val theoreticalDiff: Double,   // S*e^(-qT) - K*e^(-rT)
    val marketMidDiff: Double,        // C_mid - P_mid
    val grossDislocation: Double,     // marketMidDiff - theoreticalDiff
    val conversionEdge: Double,       // Profit from buying synthetic forward & selling spot
    val reversalEdge: Double,         // Profit from buying spot & selling synthetic forward
    val transactionCost: Double,
    val isArbitrageViable: Boolean,
    val tradeRecommendation: String
)

data class BoxFinancingAnalysis(
    val lowerStrike: Double,
    val upperStrike: Double,
    val expiryDays: Double,
    val payoffAtExpiry: Double,
    val boxMarketCost: Double,
    val impliedBorrowRate: Double,
    val benchmarkSofrRate: Double,
    val spreadVsSofrBps: Double,
    val capitalRequired: Double,
    val annualSavingsVsBankBorrowing: Double,
    val arbitrageAssessment: String
)

data class SyntheticForwardAnalysis(
    val spot: Double,
    val strike: Double,
    val expiryDays: Double,
    val callMid: Double,
    val putMid: Double,
    val theoreticalForward: Double,
    val syntheticForward: Double,
    val observedFutures: Double,
    val basis: Double,
    val fundingAdjustedBasis: Double,
    val netDislocation: Double,
    val edgeAfterFees: Double
)

object ArbitrageEngine {

    /**
     * Scans and verifies Put-Call Parity consistency across strikes.
     */
    fun checkPutCallParity(
        call: OptionInstrument,
        put: OptionInstrument,
        spot: Double,
        rate: Double,
        divYield: Double,
        spotBid: Double = spot - 0.25,
        spotAsk: Double = spot + 0.25,
        feePerContract: Double = 0.65
    ): PutCallParityCheck {
        val T = max(1e-4, call.expiryDays / 365.0)
        val eqT = exp(-divYield * T)
        val erT = exp(-rate * T)

        val K = call.strike
        val theoreticalDiff = spot * eqT - K * erT

        val callMid = 0.5 * (call.bid + call.ask)
        val putMid = 0.5 * (put.bid + put.ask)
        val marketMidDiff = callMid - putMid

        val grossDislocation = marketMidDiff - theoreticalDiff

        // CONVERSION: Long Put (ask) + Short Call (bid) + Long Underlying (ask)
        // Reversal: Long Call (ask) + Short Put (bid) + Short Underlying (bid)
        val conversionCost = call.bid - put.ask - (spotAsk * eqT - K * erT)
        val reversalCost = (spotBid * eqT - K * erT) - (call.ask - put.bid)

        val roundTripFees = (feePerContract * 2.0 + 1.0) / 100.0 // normalized per share
        val transCost = 0.5 * ((call.ask - call.bid) + (put.ask - put.bid) + (spotAsk - spotBid)) + roundTripFees

        val isArb = (conversionCost > roundTripFees) || (reversalCost > roundTripFees)

        val rec = when {
            conversionCost > roundTripFees -> "CONVERSION ARBITRAGE DETECTED: Synthetic forward overpriced vs underlying. Edge: +$${String.format("%.2f", conversionCost)}/sh."
            reversalCost > roundTripFees -> "REVERSAL ARBITRAGE DETECTED: Synthetic forward underpriced vs underlying. Edge: +$${String.format("%.2f", reversalCost)}/sh."
            abs(grossDislocation) < transCost -> "CONSISTENT: Market pricing adheres strictly to Put-Call Parity bounds within transaction bid/ask friction."
            else -> "DISLOCATION WITHIN FRICTION: Gross dislocation ($${String.format("%.2f", grossDislocation)}) absorbed by execution spread and financing carry."
        }

        return PutCallParityCheck(
            strike = K,
            expiryDays = call.expiryDays,
            callBid = call.bid,
            callAsk = call.ask,
            putBid = put.bid,
            putAsk = put.ask,
            spot = spot,
            rate = rate,
            divYield = divYield,
            theoreticalDiff = theoreticalDiff,
            marketMidDiff = marketMidDiff,
            grossDislocation = grossDislocation,
            conversionEdge = max(0.0, conversionCost),
            reversalEdge = max(0.0, reversalCost),
            transactionCost = transCost,
            isArbitrageViable = isArb,
            tradeRecommendation = rec
        )
    }

    /**
     * Analyzes Box Spread synthetic financing and compares implied interest rates against SOFR.
     */
    fun analyzeBoxSpread(
        lowerStrike: Double,
        upperStrike: Double,
        expiryDays: Double,
        call1Price: Double,
        call2Price: Double,
        put1Price: Double,
        put2Price: Double,
        benchmarkSofr: Double = 0.0460 // 4.60%
    ): BoxFinancingAnalysis {
        val T = max(1e-4, expiryDays / 365.0)
        val payoffPerShare = upperStrike - lowerStrike
        val payoffTotal = payoffPerShare * 100.0 // 1 contract = 100 shares

        // Net debit to enter Bull Call + Bear Put:
        // Bull Call = Call1 - Call2
        // Bear Put = Put2 - Put1
        val netDebitPerShare = (call1Price - call2Price) + (put2Price - put1Price)
        val netDebitTotal = netDebitPerShare * 100.0

        // Implied continuously compounded rate: payoff = cost * e^(r*T) => r = ln(payoff/cost) / T
        val impliedRate = if (netDebitPerShare > 0 && payoffPerShare > netDebitPerShare) {
            ln(payoffPerShare / netDebitPerShare) / T
        } else {
            0.0
        }

        val spreadBps = (impliedRate - benchmarkSofr) * 10_000.0
        val bankRate = benchmarkSofr + 0.0150 // typical prime bank facility SOFR + 150 bps
        val savings = max(0.0, (bankRate - impliedRate) * netDebitTotal)

        val assessment = when {
            impliedRate <= 0.0 -> "INVALID PRICING: Inverted box spread pricing violates terminal payoff certainty."
            impliedRate < benchmarkSofr -> "ATTRACTIVE SYNTHETIC BORROWING: Box implied rate (${String.format("%.2f", impliedRate * 100)}%) is ${String.format("%.0f", -spreadBps)} bps BELOW SOFR. Institutional borrowing vehicle."
            impliedRate > bankRate -> "ATTRACTIVE SYNTHETIC LENDING: Box rate yields higher return than unsecured institutional bank credit."
            else -> "FAIR PRICING: Implied financing tracks sovereign/repo funding curve within expected market liquidity bounds."
        }

        return BoxFinancingAnalysis(
            lowerStrike = lowerStrike,
            upperStrike = upperStrike,
            expiryDays = expiryDays,
            payoffAtExpiry = payoffTotal,
            boxMarketCost = netDebitTotal,
            impliedBorrowRate = impliedRate,
            benchmarkSofrRate = benchmarkSofr,
            spreadVsSofrBps = spreadBps,
            capitalRequired = netDebitTotal,
            annualSavingsVsBankBorrowing = savings,
            arbitrageAssessment = assessment
        )
    }

    /**
     * Compares Synthetic Forward vs Observed Futures Basis.
     */
    fun analyzeSyntheticForward(
        spot: Double,
        strike: Double,
        expiryDays: Double,
        callMid: Double,
        putMid: Double,
        observedFutures: Double,
        rate: Double,
        divYield: Double,
        fundingSpreadBps: Double = 15.0
    ): SyntheticForwardAnalysis {
        val T = max(1e-4, expiryDays / 365.0)
        val theoreticalForward = spot * exp((rate - divYield) * T)
        val syntheticForward = strike + (callMid - putMid) * exp(rate * T)

        val basis = syntheticForward - spot
        val netDislocation = syntheticForward - observedFutures
        val fundingAdjustment = spot * (fundingSpreadBps / 10_000.0) * T
        val fundingAdjustedBasis = basis - fundingAdjustment
        val edge = abs(netDislocation) - 0.35 // after 35c execution friction

        return SyntheticForwardAnalysis(
            spot = spot,
            strike = strike,
            expiryDays = expiryDays,
            callMid = callMid,
            putMid = putMid,
            theoreticalForward = theoreticalForward,
            syntheticForward = syntheticForward,
            observedFutures = observedFutures,
            basis = basis,
            fundingAdjustedBasis = fundingAdjustedBasis,
            netDislocation = netDislocation,
            edgeAfterFees = max(0.0, edge)
        )
    }
}
