package com.example.domain.pricing

import com.example.domain.model.OptionType
import java.util.Random
import kotlin.math.*

enum class ExoticStructure {
    EUROPEAN_VANILLA,
    ASIAN_ARITHMETIC_AVG,
    BARRIER_UP_AND_OUT,
    BARRIER_DOWN_AND_OUT
}

data class MonteCarloResult(
    val price: Double,
    val standardError: Double,
    val ci95Lower: Double,
    val ci95Upper: Double,
    val numPaths: Int,
    val numSteps: Int,
    val structure: ExoticStructure,
    val executionTimeMs: Long,
    val percentiles: List<Pair<Double, Double>> // percentile to terminal spot
)

object MonteCarloEngine {

    fun simulate(
        S0: Double,
        K: Double,
        T: Double,
        r: Double,
        q: Double,
        sigma: Double,
        type: OptionType,
        structure: ExoticStructure = ExoticStructure.EUROPEAN_VANILLA,
        barrierLevel: Double? = null,
        numPaths: Int = 20_000,
        numSteps: Int = 50,
        seed: Long = 42L
    ): MonteCarloResult {
        val startTime = System.currentTimeMillis()
        val rng = Random(seed)

        val dt = T / numSteps
        val sqrtDt = sqrt(dt)
        val drift = (r - q - 0.5 * sigma * sigma) * dt
        val discount = exp(-r * T)

        var sumPayoff = 0.0
        var sumPayoffSq = 0.0
        val terminalSpots = ArrayList<Double>(numPaths)

        val halfPaths = numPaths / 2

        for (p in 0 until halfPaths) {
            // Antithetic pair 1 and 2
            var s1 = S0
            var s2 = S0
            var s1Avg = S0
            var s2Avg = S0
            var breached1 = false
            var breached2 = false

            for (step in 1..numSteps) {
                // Box-Muller standard normal
                val u1 = max(1e-12, rng.nextDouble())
                val u2 = rng.nextDouble()
                val z1 = sqrt(-2.0 * ln(u1)) * cos(2.0 * Math.PI * u2)
                val z2 = -z1 // Antithetic variate

                s1 *= exp(drift + sigma * sqrtDt * z1)
                s2 *= exp(drift + sigma * sqrtDt * z2)

                s1Avg += s1
                s2Avg += s2

                if (structure == ExoticStructure.BARRIER_UP_AND_OUT && barrierLevel != null) {
                    if (s1 >= barrierLevel) breached1 = true
                    if (s2 >= barrierLevel) breached2 = true
                } else if (structure == ExoticStructure.BARRIER_DOWN_AND_OUT && barrierLevel != null) {
                    if (s1 <= barrierLevel) breached1 = true
                    if (s2 <= barrierLevel) breached2 = true
                }
            }

            s1Avg /= (numSteps + 1)
            s2Avg /= (numSteps + 1)

            terminalSpots.add(s1)
            terminalSpots.add(s2)

            val payoff1 = calcPayoff(s1, s1Avg, K, type, structure, breached1)
            val payoff2 = calcPayoff(s2, s2Avg, K, type, structure, breached2)

            val pairAvg = 0.5 * (payoff1 + payoff2)
            sumPayoff += pairAvg * 2.0
            sumPayoffSq += (pairAvg * pairAvg) * 2.0
        }

        val n = halfPaths * 2
        val meanPayoff = sumPayoff / n
        val discountedPrice = meanPayoff * discount
        val variance = max(0.0, (sumPayoffSq / n - meanPayoff * meanPayoff))
        val standardError = (sqrt(variance / n)) * discount
        val z95 = 1.95996
        val ciLower = max(0.0, discountedPrice - z95 * standardError)
        val ciUpper = discountedPrice + z95 * standardError

        terminalSpots.sort()
        val percentiles = listOf(
            0.01 to terminalSpots[(n * 0.01).toInt().coerceIn(0, n - 1)],
            0.05 to terminalSpots[(n * 0.05).toInt().coerceIn(0, n - 1)],
            0.25 to terminalSpots[(n * 0.25).toInt().coerceIn(0, n - 1)],
            0.50 to terminalSpots[(n * 0.50).toInt().coerceIn(0, n - 1)],
            0.75 to terminalSpots[(n * 0.75).toInt().coerceIn(0, n - 1)],
            0.95 to terminalSpots[(n * 0.95).toInt().coerceIn(0, n - 1)],
            0.99 to terminalSpots[(n * 0.99).toInt().coerceIn(0, n - 1)]
        )

        val duration = System.currentTimeMillis() - startTime

        return MonteCarloResult(
            price = discountedPrice,
            standardError = standardError,
            ci95Lower = ciLower,
            ci95Upper = ciUpper,
            numPaths = n,
            numSteps = numSteps,
            structure = structure,
            executionTimeMs = duration,
            percentiles = percentiles
        )
    }

    private fun calcPayoff(
        sTerminal: Double,
        sAvg: Double,
        K: Double,
        type: OptionType,
        structure: ExoticStructure,
        breached: Boolean
    ): Double {
        if (breached) return 0.0
        val effectiveSpot = if (structure == ExoticStructure.ASIAN_ARITHMETIC_AVG) sAvg else sTerminal
        return if (type == OptionType.CALL) {
            max(0.0, effectiveSpot - K)
        } else {
            max(0.0, K - effectiveSpot)
        }
    }
}
