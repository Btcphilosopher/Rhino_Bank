package com.example.domain.volatility

import com.example.domain.model.OptionType
import com.example.domain.pricing.BlackScholes
import kotlin.math.*

data class VolSurfacePoint(
    val expiryDays: Double,
    val strike: Double,
    val moneyness: Double,  // K / S
    val logMoneyness: Double, // ln(K / F)
    val impliedVol: Double,
    val callDelta: Double,
    val putDelta: Double
)

data class SviParameters(
    val a: Double,     // Base variance level
    val b: Double,     // Slope of the wings
    val rho: Double,   // Asymmetry / skew (-1 to +1)
    val m: Double,     // Vertex shift (horizontal shift)
    val sigma: Double  // Vertex curvature (smoothness)
) {
    /**
     * Raw SVI total variance w(k) = a + b * (rho*(k - m) + sqrt((k - m)^2 + sigma^2))
     * where k = ln(K / F) is log-moneyness.
     */
    fun totalVariance(k: Double): Double {
        val diff = k - m
        val w = a + b * (rho * diff + sqrt(diff * diff + sigma * sigma))
        return max(1e-6, w)
    }

    fun impliedVol(k: Double, T: Double): Double {
        val w = totalVariance(k)
        return sqrt(w / max(1e-6, T))
    }
}

data class SurfaceSkewMetrics(
    val expiryDays: Double,
    val atmVol: Double,
    val call25DeltaVol: Double,
    val put25DeltaVol: Double,
    val riskReversal25D: Double, // 25D Call Vol - 25D Put Vol
    val butterfly25D: Double,    // 0.5 * (25D Call + 25D Put) - ATM Vol
    val slope90to110: Double     // (Vol(110%) - Vol(90%)) / 0.20
)

class VolatilitySurface(
    val spot: Double,
    val riskFreeRate: Double,
    val dividendYield: Double,
    val expiriesDays: List<Double>,
    val strikes: List<Double>,
    val sviCalibrations: Map<Double, SviParameters>
) {
    val points: List<VolSurfacePoint> = buildSurfacePoints()

    private fun buildSurfacePoints(): List<VolSurfacePoint> {
        val list = mutableListOf<VolSurfacePoint>()
        for (expiry in expiriesDays) {
            val T = expiry / 365.0
            val F = spot * exp((riskFreeRate - dividendYield) * T)
            val svi = sviCalibrations[expiry] ?: defaultSvi(expiry)

            for (K in strikes) {
                val k = ln(K / F)
                val iv = svi.impliedVol(k, T)
                val moneyness = K / spot
                val pricingCall = BlackScholes.priceAndGreeks(spot, K, T, riskFreeRate, dividendYield, iv, OptionType.CALL)
                val pricingPut = BlackScholes.priceAndGreeks(spot, K, T, riskFreeRate, dividendYield, iv, OptionType.PUT)

                list.add(
                    VolSurfacePoint(
                        expiryDays = expiry,
                        strike = K,
                        moneyness = moneyness,
                        logMoneyness = k,
                        impliedVol = iv,
                        callDelta = pricingCall.delta,
                        putDelta = pricingPut.delta
                    )
                )
            }
        }
        return list
    }

    fun getVolatility(strike: Double, expiryDays: Double): Double {
        val T = expiryDays / 365.0
        val F = spot * exp((riskFreeRate - dividendYield) * T)
        val k = ln(strike / F)

        // Find nearest expiry calibrations or interpolate
        val lowerExp = expiriesDays.filter { it <= expiryDays }.maxOrNull() ?: expiriesDays.first()
        val upperExp = expiriesDays.filter { it >= expiryDays }.minOrNull() ?: expiriesDays.last()

        val sviLow = sviCalibrations[lowerExp] ?: defaultSvi(lowerExp)
        val sviHigh = sviCalibrations[upperExp] ?: defaultSvi(upperExp)

        if (lowerExp == upperExp) {
            return sviLow.impliedVol(k, T)
        }

        val weight = (expiryDays - lowerExp) / (upperExp - lowerExp)
        val wLow = sviLow.totalVariance(k)
        val wHigh = sviHigh.totalVariance(k)
        val interpTotalVar = (1.0 - weight) * wLow + weight * wHigh
        return sqrt(interpTotalVar / max(1e-6, T))
    }

    fun computeSkewMetrics(): List<SurfaceSkewMetrics> {
        return expiriesDays.map { expiry ->
            val T = expiry / 365.0
            val F = spot * exp((riskFreeRate - dividendYield) * T)
            val svi = sviCalibrations[expiry] ?: defaultSvi(expiry)

            val atmVol = svi.impliedVol(0.0, T)
            // 25 Delta Call is approximately log-moneyness +0.15, Put is -0.15
            val kCall25 = 0.14
            val kPut25 = -0.18
            val callVol = svi.impliedVol(kCall25, T)
            val putVol = svi.impliedVol(kPut25, T)

            val rr25 = callVol - putVol
            val bf25 = 0.5 * (callVol + putVol) - atmVol

            val vol90 = getVolatility(spot * 0.90, expiry)
            val vol110 = getVolatility(spot * 1.10, expiry)
            val slope = (vol110 - vol90) / 0.20

            SurfaceSkewMetrics(
                expiryDays = expiry,
                atmVol = atmVol,
                call25DeltaVol = callVol,
                put25DeltaVol = putVol,
                riskReversal25D = rr25,
                butterfly25D = bf25,
                slope90to110 = slope
            )
        }
    }

    companion object {
        fun defaultSvi(expiryDays: Double): SviParameters {
            val T = expiryDays / 365.0
            // Realistic institutional equity index skew: negative rho (downside put skew)
            return SviParameters(
                a = 0.04 * T,
                b = 0.12 * sqrt(T),
                rho = -0.55, // Negative equity skew
                m = 0.02,
                sigma = 0.15
            )
        }

        fun createDemoSurface(spot: Double = 5800.0, r: Double = 0.045, q: Double = 0.015): VolatilitySurface {
            val expiries = listOf(30.0, 60.0, 90.0, 180.0, 365.0)
            val step = spot * 0.02
            val strikes = (-8..8).map { spot + it * step }

            val calibs = mutableMapOf<Double, SviParameters>()
            calibs[30.0] = SviParameters(a = 0.0035, b = 0.09, rho = -0.62, m = 0.01, sigma = 0.10)
            calibs[60.0] = SviParameters(a = 0.0070, b = 0.11, rho = -0.58, m = 0.015, sigma = 0.12)
            calibs[90.0] = SviParameters(a = 0.0110, b = 0.13, rho = -0.54, m = 0.02, sigma = 0.14)
            calibs[180.0] = SviParameters(a = 0.0220, b = 0.16, rho = -0.48, m = 0.025, sigma = 0.17)
            calibs[365.0] = SviParameters(a = 0.0440, b = 0.20, rho = -0.42, m = 0.03, sigma = 0.20)

            return VolatilitySurface(
                spot = spot,
                riskFreeRate = r,
                dividendYield = q,
                expiriesDays = expiries,
                strikes = strikes,
                sviCalibrations = calibs
            )
        }
    }
}
