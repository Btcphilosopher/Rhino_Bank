package com.example.domain.rqql

import com.example.domain.model.*
import com.example.domain.pricing.BlackScholes
import com.example.domain.risk.HedgingEngine
import com.example.domain.risk.ScenarioEngine
import com.example.domain.synthetics.SyntheticInstrumentEngine

data class RqqlResult(
    val command: String,
    val isSuccess: Boolean,
    val outputTitle: String,
    val outputText: String,
    val generatedLegs: List<PositionLeg>? = null,
    val keyMetrics: Map<String, String> = emptyMap()
)

object RqqlEngine {

    /**
     * Executes an RQQL script or line command.
     */
    fun execute(
        input: String,
        currentLegs: List<PositionLeg>,
        currentSpot: Double,
        rate: Double = 0.045,
        divYield: Double = 0.015,
        atmVol: Double = 0.18
    ): RqqlResult {
        val trimmed = input.trim()
        val upper = trimmed.uppercase()

        return try {
            when {
                upper.startsWith("SYNTHETIC LONG FORWARD") || upper.startsWith("SYNTH LONG FWD") -> {
                    val strike = parseParam(upper, "STRIKE") ?: currentSpot
                    val expiry = parseParam(upper, "EXPIRY") ?: 90.0

                    val c = OptionInstrument("SPX_C_$strike", AssetClass.INDEX, "SPX", marketPrice = currentSpot * 0.038, bid = currentSpot * 0.037, ask = currentSpot * 0.039, optionType = OptionType.CALL, strike = strike, expiryDays = expiry, impliedVolatility = atmVol)
                    val p = OptionInstrument("SPX_P_$strike", AssetClass.INDEX, "SPX", marketPrice = currentSpot * 0.036, bid = currentSpot * 0.035, ask = currentSpot * 0.037, optionType = OptionType.PUT, strike = strike, expiryDays = expiry, impliedVolatility = atmVol)

                    val newLegs = listOf(
                        PositionLeg("leg-1", Side.BUY, 1.0, c),
                        PositionLeg("leg-2", Side.SELL, 1.0, p)
                    )
                    val greeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(newLegs, currentSpot, rate, divYield)

                    RqqlResult(
                        command = trimmed,
                        isSuccess = true,
                        outputTitle = "SYNTHETIC LONG FORWARD CONSTRUCTED",
                        outputText = "Constructed BUY CALL(K=$strike) + SELL PUT(K=$strike). Delta ~ ${String.format("%.3f", greeks.netDelta)}. Perfectly replicates underlying forward delivery.",
                        generatedLegs = newLegs,
                        keyMetrics = mapOf(
                            "Delta" to String.format("%.3f", greeks.netDelta),
                            "Gamma" to String.format("%.5f", greeks.netGamma),
                            "Net Value" to "$${String.format("%.2f", greeks.netPrice)}"
                        )
                    )
                }

                upper.startsWith("LONG STRADDLE") -> {
                    val strike = parseParam(upper, "STRIKE") ?: currentSpot
                    val expiry = parseParam(upper, "EXPIRY") ?: 30.0

                    val c = OptionInstrument("SPX_C_$strike", AssetClass.INDEX, "SPX", marketPrice = currentSpot * 0.025, bid = currentSpot * 0.024, ask = currentSpot * 0.026, optionType = OptionType.CALL, strike = strike, expiryDays = expiry, impliedVolatility = atmVol)
                    val p = OptionInstrument("SPX_P_$strike", AssetClass.INDEX, "SPX", marketPrice = currentSpot * 0.024, bid = currentSpot * 0.023, ask = currentSpot * 0.025, optionType = OptionType.PUT, strike = strike, expiryDays = expiry, impliedVolatility = atmVol)

                    val newLegs = listOf(
                        PositionLeg("leg-1", Side.BUY, 1.0, c),
                        PositionLeg("leg-2", Side.BUY, 1.0, p)
                    )
                    val greeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(newLegs, currentSpot, rate, divYield)

                    RqqlResult(
                        command = trimmed,
                        isSuccess = true,
                        outputTitle = "LONG STRADDLE CONSTRUCTED",
                        outputText = "Constructed ATM Straddle: BUY CALL + BUY PUT at K=$strike. Vega: ${String.format("%.2f", greeks.netVega)}, Gamma: ${String.format("%.4f", greeks.netGamma)}.",
                        generatedLegs = newLegs,
                        keyMetrics = mapOf(
                            "Net Delta" to String.format("%.3f", greeks.netDelta),
                            "Net Vega" to String.format("%.2f", greeks.netVega),
                            "Net Theta/day" to String.format("%.2f", greeks.netTheta)
                        )
                    )
                }

                upper == "PRICE" -> {
                    val greeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(currentLegs, currentSpot, rate, divYield)
                    RqqlResult(
                        command = trimmed,
                        isSuccess = true,
                        outputTitle = "PORTFOLIO PRICING",
                        outputText = "Evaluated ${currentLegs.size} constituent legs against BSM & market quotes. Net Portfolio Mark: $${String.format("%.2f", greeks.netPrice)}, Total Notional: $${String.format("%.2f", greeks.totalNotional)}.",
                        keyMetrics = mapOf(
                            "Mark-to-Market" to "$${String.format("%.2f", greeks.netPrice)}",
                            "Notional" to "$${String.format("%.2f", greeks.totalNotional)}"
                        )
                    )
                }

                upper == "GREEKS" -> {
                    val g = SyntheticInstrumentEngine.calculatePortfolioGreeks(currentLegs, currentSpot, rate, divYield)
                    RqqlResult(
                        command = trimmed,
                        isSuccess = true,
                        outputTitle = "AGGREGATE PORTFOLIO GREEKS",
                        outputText = "Net Delta: ${String.format("%.3f", g.netDelta)} | Net Gamma: ${String.format("%.5f", g.netGamma)} | Net Vega: ${String.format("%.2f", g.netVega)} | Net Theta/day: ${String.format("%.2f", g.netTheta)} | Net Rho: ${String.format("%.2f", g.netRho)}.",
                        keyMetrics = mapOf(
                            "Delta" to String.format("%.3f", g.netDelta),
                            "Gamma" to String.format("%.5f", g.netGamma),
                            "Vega" to String.format("%.2f", g.netVega),
                            "Theta/day" to String.format("%.2f", g.netTheta),
                            "Vanna" to String.format("%.4f", g.netVanna),
                            "Volga" to String.format("%.4f", g.netVolga)
                        )
                    )
                }

                upper.startsWith("HEDGE DELTA") -> {
                    val spotInst = SpotInstrument("SPX_UNDERLYING", AssetClass.INDEX, "SPX", marketPrice = currentSpot, bid = currentSpot - 0.25, ask = currentSpot + 0.25)
                    val rec = HedgingEngine.computeHedge(currentLegs, currentSpot, rate, divYield, spotInst, "DELTA")
                    RqqlResult(
                        command = trimmed,
                        isSuccess = true,
                        outputTitle = "DELTA HEDGE RECOMMENDATION",
                        outputText = "${rec.recommendedSide} ${String.format("%.2f", rec.recommendedQuantity)} units of ${rec.recommendedInstrument.underlying} @ $${currentSpot}. Residual Delta: ${String.format("%.4f", rec.postHedgeDelta)}.",
                        keyMetrics = mapOf(
                            "Hedge Action" to "${rec.recommendedSide} ${String.format("%.2f", rec.recommendedQuantity)}",
                            "Trade Notional" to "$${String.format("%.2f", rec.tradeNotional)}",
                            "Post-Hedge Delta" to String.format("%.4f", rec.postHedgeDelta)
                        )
                    )
                }

                upper.startsWith("SCENARIO SPOT") -> {
                    val shiftMatch = Regex("([+-]?\\d+(\\.\\d+)?%)").find(upper)?.value ?: "+5%"
                    val shiftVal = (shiftMatch.replace("%", "").toDoubleOrNull() ?: 5.0) / 100.0
                    val shiftedSpot = currentSpot * (1.0 + shiftVal)
                    val baseVal = SyntheticInstrumentEngine.calculatePortfolioGreeks(currentLegs, currentSpot, rate, divYield).netPrice
                    val newVal = SyntheticInstrumentEngine.calculatePortfolioGreeks(currentLegs, shiftedSpot, rate, divYield).netPrice
                    val pnl = newVal - baseVal

                    RqqlResult(
                        command = trimmed,
                        isSuccess = true,
                        outputTitle = "SCENARIO EVALUATION: SPOT SHIFT $shiftMatch",
                        outputText = "Underlying shifted to $${String.format("%.2f", shiftedSpot)} ($shiftMatch). Expected Portfolio P&L: ${if (pnl >= 0) "+$" else "-$"}${String.format("%.2f", kotlin.math.abs(pnl))}.",
                        keyMetrics = mapOf(
                            "Base Value" to "$${String.format("%.2f", baseVal)}",
                            "Shifted Value" to "$${String.format("%.2f", newVal)}",
                            "P&L" to "${if (pnl >= 0) "+$" else "-$"}${String.format("%.2f", kotlin.math.abs(pnl))}"
                        )
                    )
                }

                upper.startsWith("STRESS VOL") -> {
                    val shiftPts = Regex("([+-]?\\d+(\\.\\d+)?)").find(upper.removePrefix("STRESS VOL"))?.value?.toDoubleOrNull() ?: 15.0
                    val shiftedLegs = currentLegs.map { leg ->
                        if (leg.instrument is OptionInstrument) {
                            val inst = leg.instrument as OptionInstrument
                            leg.copy(instrument = inst.copy(impliedVolatility = inst.impliedVolatility + shiftPts / 100.0))
                        } else leg
                    }
                    val baseVal = SyntheticInstrumentEngine.calculatePortfolioGreeks(currentLegs, currentSpot, rate, divYield).netPrice
                    val stressedVal = SyntheticInstrumentEngine.calculatePortfolioGreeks(shiftedLegs, currentSpot, rate, divYield).netPrice
                    val pnl = stressedVal - baseVal

                    RqqlResult(
                        command = trimmed,
                        isSuccess = true,
                        outputTitle = "VOLATILITY STRESS TEST: +${shiftPts} VOL POINTS",
                        outputText = "Implied volatility shifted across surface by +${shiftPts} pts. Expected portfolio P&L: ${if (pnl >= 0) "+$" else "-$"}${String.format("%.2f", kotlin.math.abs(pnl))}.",
                        keyMetrics = mapOf(
                            "Vol Shock" to "+${shiftPts} pts",
                            "Stressed P&L" to "${if (pnl >= 0) "+$" else "-$"}${String.format("%.2f", kotlin.math.abs(pnl))}"
                        )
                    )
                }

                else -> {
                    RqqlResult(
                        command = trimmed,
                        isSuccess = false,
                        outputTitle = "SYNTAX ERROR",
                        outputText = "Unrecognized RQQL command '$trimmed'. Supported syntax:\n" +
                                "• SYNTHETIC LONG FORWARD [STRIKE <k>] [EXPIRY <d>]\n" +
                                "• LONG STRADDLE [STRIKE <k>] [EXPIRY <d>]\n" +
                                "• PRICE\n" +
                                "• GREEKS\n" +
                                "• HEDGE DELTA\n" +
                                "• SCENARIO SPOT +10%\n" +
                                "• STRESS VOL +15"
                    )
                }
            }
        } catch (e: Exception) {
            RqqlResult(
                command = trimmed,
                isSuccess = false,
                outputTitle = "EXECUTION EXCEPTION",
                outputText = "Error evaluating RQQL: ${e.message}"
            )
        }
    }

    private fun parseParam(cmd: String, key: String): Double? {
        val regex = Regex("$key\\s+([0-9]+(?:\\.[0-9]+)?)")
        return regex.find(cmd)?.groupValues?.get(1)?.toDoubleOrNull()
    }
}
