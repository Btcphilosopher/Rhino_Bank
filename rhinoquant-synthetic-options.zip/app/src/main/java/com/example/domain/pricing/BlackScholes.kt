package com.example.domain.pricing

import com.example.domain.model.OptionType
import kotlin.math.*

data class PricingResult(
    val price: Double,
    val intrinsicValue: Double,
    val timeValue: Double,
    val d1: Double,
    val d2: Double,
    val delta: Double,
    val gamma: Double,
    val vega: Double,        // per 1% vol
    val theta: Double,       // per calendar day (1/365)
    val rho: Double,         // per 100 bps
    val vanna: Double,       // dVega/dS
    val volga: Double,       // dVega/dVol
    val charm: Double,       // dDelta/dt per day
    val color: Double,       // dGamma/dt per day
    val speed: Double,       // dGamma/dS
    val zomma: Double        // dGamma/dVol
)

object BlackScholes {

    private const val INV_SQRT_2PI = 0.3989422804014327

    fun normPdf(x: Double): Double {
        return INV_SQRT_2PI * exp(-0.5 * x * x)
    }

    /**
     * Abramowitz and Stegun 7.1.26 high-precision polynomial approximation.
     * Absolute error < 1.5e-7.
     */
    fun normCdf(x: Double): Double {
        if (x.isNaN()) return Double.NaN
        if (x > 8.0) return 1.0
        if (x < -8.0) return 0.0

        val z = abs(x)
        val t = 1.0 / (1.0 + 0.2316419 * z)
        val poly = t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))))
        val ans = 1.0 - normPdf(z) * poly
        return if (x >= 0.0) ans else 1.0 - ans
    }

    /**
     * Prices European Call or Put under Black-Scholes-Merton with continuous rate r and dividend yield q.
     * @param S Spot price of underlying
     * @param K Strike price
     * @param T Time to maturity in years
     * @param r Risk-free rate (e.g. 0.045 for 4.5%)
     * @param q Continuous dividend yield / carry (e.g. 0.015 for 1.5%)
     * @param sigma Implied volatility (e.g. 0.20 for 20%)
     * @param type CALL or PUT
     */
    fun priceAndGreeks(
        S: Double,
        K: Double,
        T: Double,
        r: Double,
        q: Double,
        sigma: Double,
        type: OptionType
    ): PricingResult {
        val safeS = max(1e-4, S)
        val safeK = max(1e-4, K)
        val safeT = max(1e-6, T)
        val safeVol = max(1e-4, sigma)

        val sqrtT = sqrt(safeT)
        val d1 = (ln(safeS / safeK) + (r - q + 0.5 * safeVol * safeVol) * safeT) / (safeVol * sqrtT)
        val d2 = d1 - safeVol * sqrtT

        val eqT = exp(-q * safeT)
        val erT = exp(-r * safeT)
        val nd1 = normCdf(d1)
        val nd2 = normCdf(d2)
        val npd1 = normPdf(d1)

        val price: Double
        val delta: Double
        val intrinsic: Double

        if (type == OptionType.CALL) {
            price = safeS * eqT * nd1 - safeK * erT * nd2
            delta = eqT * nd1
            intrinsic = max(0.0, safeS - safeK)
        } else {
            val n_minus_d1 = normCdf(-d1)
            val n_minus_d2 = normCdf(-d2)
            price = safeK * erT * n_minus_d2 - safeS * eqT * n_minus_d1
            delta = -eqT * n_minus_d1
            intrinsic = max(0.0, safeK - safeS)
        }

        val boundedPrice = max(0.0, price)
        val timeValue = max(0.0, boundedPrice - intrinsic)

        // 1st & 2nd Order Greeks
        val gamma = (eqT * npd1) / (safeS * safeVol * sqrtT)
        // Scaled vega for a 1.0 percentage point change in volatility (0.01)
        val vega = (safeS * eqT * sqrtT * npd1) * 0.01

        // Theta per calendar day (1 / 365)
        val rawTheta = if (type == OptionType.CALL) {
            -(safeS * eqT * npd1 * safeVol) / (2.0 * sqrtT) -
                    r * safeK * erT * nd2 +
                    q * safeS * eqT * nd1
        } else {
            -(safeS * eqT * npd1 * safeVol) / (2.0 * sqrtT) +
                    r * safeK * erT * normCdf(-d2) -
                    q * safeS * eqT * normCdf(-d1)
        }
        val thetaPerDay = rawTheta / 365.0

        // Rho per 100 bps (0.01 rate shift)
        val rho = if (type == OptionType.CALL) {
            (safeK * safeT * erT * nd2) * 0.01
        } else {
            (-safeK * safeT * erT * normCdf(-d2)) * 0.01
        }

        // Higher-Order Greeks
        // Vanna: dVega / dS or dDelta / dVol
        val vanna = (-eqT * npd1 * d2 / safeVol) * 0.01

        // Volga (Volgamma): dVega / dVol
        val volga = (vega * d1 * d2 / safeVol) * 0.01

        // Charm: -dDelta / dT (per day)
        val charmYear = if (type == OptionType.CALL) {
            q * eqT * nd1 - eqT * npd1 * (2.0 * (r - q) * safeT - d2 * safeVol * sqrtT) / (2.0 * safeT * safeVol * sqrtT)
        } else {
            -q * eqT * normCdf(-d1) - eqT * npd1 * (2.0 * (r - q) * safeT - d2 * safeVol * sqrtT) / (2.0 * safeT * safeVol * sqrtT)
        }
        val charmPerDay = charmYear / 365.0

        // Color: dGamma / dT (per day)
        val colorYear = -gamma * (q + (r - q) * d1 / (safeVol * sqrtT) + (1.0 - d1 * d2) / (2.0 * safeT))
        val colorPerDay = colorYear / 365.0

        // Speed: dGamma / dS
        val speed = -gamma / safeS * (d1 / (safeVol * sqrtT) + 1.0)

        // Zomma: dGamma / dVol
        val zomma = gamma * (d1 * d2 - 1.0) / safeVol

        return PricingResult(
            price = boundedPrice,
            intrinsicValue = intrinsic,
            timeValue = timeValue,
            d1 = d1,
            d2 = d2,
            delta = delta,
            gamma = gamma,
            vega = vega,
            theta = thetaPerDay,
            rho = rho,
            vanna = vanna,
            volga = volga,
            charm = charmPerDay,
            color = colorPerDay,
            speed = speed,
            zomma = zomma
        )
    }

    /**
     * Analytical pricing only (convenience method)
     */
    fun price(
        S: Double,
        K: Double,
        T: Double,
        r: Double,
        q: Double,
        sigma: Double,
        type: OptionType
    ): Double {
        return priceAndGreeks(S, K, T, r, q, sigma, type).price
    }
}
