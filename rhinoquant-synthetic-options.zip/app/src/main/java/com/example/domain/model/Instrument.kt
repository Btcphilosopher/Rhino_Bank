package com.example.domain.model

import java.time.LocalDate

enum class AssetClass(val code: String, val displayName: String) {
    EQUITY("EQ", "Equities"),
    INDEX("IDX", "Equity Index"),
    COMMODITY("COMM", "Commodities"),
    FX("FX", "Foreign Exchange"),
    RATE("RATE", "Interest Rates"),
    CRYPTO("CRYPTO", "Digital Assets")
}

enum class ExerciseStyle {
    EUROPEAN,
    AMERICAN,
    BERMUDAN
}

enum class OptionType {
    CALL,
    PUT;

    fun sign(): Int = if (this == CALL) 1 else -1
}

enum class SettlementType {
    PHYSICAL,
    CASH
}

enum class Side {
    BUY,
    SELL;

    fun multiplier(): Double = if (this == BUY) 1.0 else -1.0
}

enum class DataProvenance {
    LIVE,
    HISTORICAL,
    SIMULATED,
    DEMO,
    STALE
}

enum class SolverStatus {
    CONVERGED,
    MODEL_FAILED,
    NO_ARBITRAGE_SOLUTION,
    OUTLIER,
    STALE_MARKET,
    LOW_LIQUIDITY
}

enum class RiskStatus {
    GREEN,
    AMBER,
    RED,
    BREACH
}

sealed interface Instrument {
    val instrumentId: String
    val assetClass: AssetClass
    val underlying: String
    val currency: String
    val contractSize: Double
    val priceMultiplier: Double
    val marketPrice: Double
    val bid: Double
    val ask: Double
    val tickSize: Double
    val provenance: DataProvenance
    val timestampMs: Long
}

data class SpotInstrument(
    override val instrumentId: String,
    override val assetClass: AssetClass,
    override val underlying: String,
    override val currency: String = "USD",
    override val contractSize: Double = 1.0,
    override val priceMultiplier: Double = 1.0,
    override val marketPrice: Double,
    override val bid: Double,
    override val ask: Double,
    override val tickSize: Double = 0.01,
    override val provenance: DataProvenance = DataProvenance.DEMO,
    override val timestampMs: Long = System.currentTimeMillis(),
    val dividendYield: Double = 0.015,
    val borrowCostBps: Double = 25.0
) : Instrument

data class FutureInstrument(
    override val instrumentId: String,
    override val assetClass: AssetClass,
    override val underlying: String,
    override val currency: String = "USD",
    override val contractSize: Double = 50.0,
    override val priceMultiplier: Double = 50.0,
    override val marketPrice: Double,
    override val bid: Double,
    override val ask: Double,
    override val tickSize: Double = 0.25,
    override val provenance: DataProvenance = DataProvenance.DEMO,
    override val timestampMs: Long = System.currentTimeMillis(),
    val expiryDays: Double,
    val basis: Double = 0.0
) : Instrument

data class OptionInstrument(
    override val instrumentId: String,
    override val assetClass: AssetClass,
    override val underlying: String,
    override val currency: String = "USD",
    override val contractSize: Double = 100.0,
    override val priceMultiplier: Double = 100.0,
    override val marketPrice: Double,
    override val bid: Double,
    override val ask: Double,
    override val tickSize: Double = 0.05,
    override val provenance: DataProvenance = DataProvenance.DEMO,
    override val timestampMs: Long = System.currentTimeMillis(),
    val optionType: OptionType,
    val strike: Double,
    val expiryDays: Double,
    val exerciseStyle: ExerciseStyle = ExerciseStyle.EUROPEAN,
    val settlementType: SettlementType = SettlementType.CASH,
    val impliedVolatility: Double,
    val delta: Double = 0.0,
    val gamma: Double = 0.0,
    val theta: Double = 0.0,
    val vega: Double = 0.0,
    val rho: Double = 0.0,
    val volume: Long = 1420L,
    val openInterest: Long = 8500L,
    val moneyness: Double = 1.0
) : Instrument

data class PositionLeg(
    val id: String,
    val side: Side,
    val quantity: Double,
    val instrument: Instrument,
    val customPrice: Double? = null,
    val hedgeRatio: Double = 1.0
) {
    val effectivePrice: Double get() = customPrice ?: instrument.marketPrice
    val signedQuantity: Double get() = quantity * side.multiplier()
    val notional: Double get() = quantity * effectivePrice * instrument.priceMultiplier
}
