package com.example.domain.model

import com.example.domain.risk.MarginRequirements
import com.example.domain.synthetics.PortfolioGreeks
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ModelGovernanceRecord(
    val modelName: String,
    val modelVersion: String,
    val calibrationTimestamp: Long = System.currentTimeMillis(),
    val marketDataSnapshotId: String,
    val numericalTolerance: Double = 1e-6,
    val solverMethod: String = "Newton-Raphson with Brent Bisection Fallback",
    val authorizedQuant: String = "RHINO_QUANT_CORE_DESK",
    val status: String = "APPROVED_PRODUCTION"
)

data class AuditEvent(
    val eventId: String,
    val timestampMs: Long = System.currentTimeMillis(),
    val user: String,
    val desk: String = "DESK_SYNTHETICS_LON",
    val action: String,
    val details: String,
    val riskStatus: RiskStatus = RiskStatus.GREEN
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(timestampMs))
}

data class RiskLimitsConfig(
    val maxNetDelta: Double = 50.0,
    val maxNetVega: Double = 25_000.0,
    val maxNetGamma: Double = 0.50,
    val maxNotional: Double = 25_000_000.0,
    val maxMarginUtilization: Double = 80.0
)

data class LimitCheckEvaluation(
    val metricName: String,
    val currentValue: Double,
    val threshold: Double,
    val status: RiskStatus
)

data class TradeTicket(
    val ticketId: String,
    val strategyName: String,
    val underlying: String,
    val legsCount: Int,
    val netCreditDebit: Double,
    val totalNotional: Double,
    val initialMarginRequired: Double,
    val limitCheckStatus: RiskStatus,
    val executionRoute: String = "RFQ_PACKAGE_ATOMIC",
    val traderId: String = "TRADER_DESK_01",
    val bookId: String = "BOOK_VOL_SYNTH_04",
    val timestampMs: Long = System.currentTimeMillis()
)

object ResearchNoteGenerator {

    fun generateNote(
        strategyName: String,
        underlying: String,
        spot: Double,
        greeks: PortfolioGreeks,
        margin: MarginRequirements,
        governance: ModelGovernanceRecord,
        breakEvens: List<Double>,
        syntheticReplication: String
    ): String {
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).format(Date())
        return """
            ================================================================================
            RHINOQUANT QUANTITATIVE DERIVATIVES RESEARCH MEMORANDUM
            ================================================================================
            CLASSIFICATION: RESTRICTED INSTITUTIONAL / INTERNAL RISK MEMO
            ISSUED BY: Rhino Bank Quantitative Research & Risk Strategy
            TIMESTAMP: $dateStr
            
            1. STRATEGY SPECIFICATION
            --------------------------------------------------------------------------------
            Strategy: $strategyName
            Underlying: $underlying (Spot: $$spot)
            Replication Principle: $syntheticReplication
            Net Capital Outlay: ${if (greeks.netPrice >= 0) "Debit $" else "Credit $"}${String.format("%.2f", kotlin.math.abs(greeks.netPrice))}
            Aggregate Notional Exposure: $${String.format("%.2f", greeks.totalNotional)}
            Break-Even Spot Boundaries: ${if (breakEvens.isEmpty()) "None (Constant payoff)" else breakEvens.joinToString(", ") { "$${String.format("%.2f", it)}" }}
            
            2. PORTFOLIO GREEKS & SENSITIVITIES
            --------------------------------------------------------------------------------
            • Net Delta (Δ):       ${String.format("%+10.4f", greeks.netDelta)}  [1st order underlying exposure]
            • Net Gamma (Γ):       ${String.format("%+10.6f", greeks.netGamma)}  [Convexity acceleration]
            • Net Vega (V):        ${String.format("%+10.2f", greeks.netVega)}  [Sensitivity per 1.0% vol point]
            • Net Theta/day (Θ):   ${String.format("%+10.2f", greeks.netTheta)}  [Time decay carry per day]
            • Net Rho (ρ):         ${String.format("%+10.2f", greeks.netRho)}  [Rate shift per 100 bps]
            • Net Vanna:           ${String.format("%+10.4f", greeks.netVanna)}  [Cross dVega/dS]
            • Net Volga:           ${String.format("%+10.4f", greeks.netVolga)}  [Vol of vol convexity]
            • Net Charm:           ${String.format("%+10.4f", greeks.netCharm)}  [Delta decay per day]
            
            3. PRICING & MODEL GOVERNANCE
            --------------------------------------------------------------------------------
            Engine Model: ${governance.modelName} (Ver: ${governance.modelVersion})
            Calibration Snapshot: ${governance.marketDataSnapshotId}
            Numerical Precision: Tolerance = ${governance.numericalTolerance}
            Solver Methodology: ${governance.solverMethod}
            Model Governance Clearance: ${governance.status} by ${governance.authorizedQuant}
            
            4. MARGIN & EXECUTION ANALYSIS
            --------------------------------------------------------------------------------
            Initial SPAN Margin: $${String.format("%.2f", margin.initialMargin)}
            Maintenance Margin:  $${String.format("%.2f", margin.maintenanceMargin)}
            Cross-Leg Offset Benefit: $${String.format("%.2f", margin.netOffsetBenefit)}
            Margin Utilization:  ${String.format("%.1f", margin.marginUtilizationPercent)}% [${margin.marginStatus}]
            Execution Recommendation: Route as CME / CBOE Package Order via atomic RFQ.
            
            5. REGULATORY & AUDIT STATEMENT
            --------------------------------------------------------------------------------
            This memorandum is a quantitative structuring and risk measurement artifact.
            Data provenance: Verified synthetic analytical model.
            ================================================================================
        """.trimIndent()
    }
}
