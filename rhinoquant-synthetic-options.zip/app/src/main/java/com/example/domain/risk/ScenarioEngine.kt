package com.example.domain.risk

import com.example.domain.model.PositionLeg
import com.example.domain.synthetics.PortfolioGreeks
import com.example.domain.synthetics.SyntheticInstrumentEngine
import kotlin.math.*

data class ScenarioCell(
    val spotShiftPercent: Double,
    val volShiftPoints: Double,
    val revaluedPrice: Double,
    val pnl: Double,
    val netDelta: Double,
    val netGamma: Double,
    val netVega: Double
)

data class StressTestResult(
    val presetName: String,
    val description: String,
    val spotShift: Double,
    val volShift: Double,
    val daysShift: Double,
    val initialValue: Double,
    val stressedValue: Double,
    val stressedPnl: Double,
    val residualDelta: Double,
    val legBreakdowns: List<Pair<String, Double>> // Leg description -> P&L contribution
)

data class PnlAttribution(
    val totalPnl: Double,
    val deltaPnl: Double,
    val gammaPnl: Double,
    val vegaPnl: Double,
    val thetaPnl: Double,
    val rhoPnl: Double,
    val carryPnl: Double,
    val residualPnl: Double
)

data class MonteCarloRiskReport(
    val var95: Double,
    val var99: Double,
    val expectedShortfall95: Double,
    val expectedShortfall99: Double,
    val worstCaseLoss: Double,
    val maxGain: Double,
    val probOfLoss: Double,
    val simulatedDistribution: List<Double> // Sample sorted P&L
)

object ScenarioEngine {

    val standardSpotShifts = listOf(-0.20, -0.10, -0.05, 0.0, 0.05, 0.10, 0.20)
    val standardVolShifts = listOf(-0.10, -0.05, 0.0, 0.05, 0.10)

    /**
     * Generates a 2D matrix of revalued Portfolio P&L across spot shifts and vol shifts.
     */
    fun evaluateScenarioGrid(
        legs: List<PositionLeg>,
        baseSpot: Double,
        baseRate: Double,
        baseDivYield: Double,
        spotShifts: List<Double> = standardSpotShifts,
        volShifts: List<Double> = standardVolShifts,
        daysForward: Double = 0.0
    ): List<ScenarioCell> {
        val baseGreeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(legs, baseSpot, baseRate, baseDivYield)
        val baseValue = baseGreeks.netPrice

        val cells = mutableListOf<ScenarioCell>()

        for (vShift in volShifts) {
            for (sShift in spotShifts) {
                val shiftedSpot = baseSpot * (1.0 + sShift)
                // Shifted portfolio
                val shiftedLegs = legs.map { leg ->
                    if (leg.instrument is com.example.domain.model.OptionInstrument) {
                        val inst = leg.instrument as com.example.domain.model.OptionInstrument
                        val shiftedExpiry = max(0.5, inst.expiryDays - daysForward)
                        val shiftedVol = max(0.01, inst.impliedVolatility + vShift)
                        leg.copy(
                            instrument = inst.copy(
                                expiryDays = shiftedExpiry,
                                impliedVolatility = shiftedVol
                            )
                        )
                    } else leg
                }

                val greeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(
                    legs = shiftedLegs,
                    spot = shiftedSpot,
                    rate = baseRate,
                    divYield = baseDivYield
                )

                val revalued = greeks.netPrice
                val pnl = revalued - baseValue

                cells.add(
                    ScenarioCell(
                        spotShiftPercent = sShift,
                        volShiftPoints = vShift,
                        revaluedPrice = revalued,
                        pnl = pnl,
                        netDelta = greeks.netDelta,
                        netGamma = greeks.netGamma,
                        netVega = greeks.netVega
                    )
                )
            }
        }

        return cells
    }

    /**
     * Executes institutional stress test presets.
     */
    fun runStressPresets(
        legs: List<PositionLeg>,
        baseSpot: Double,
        baseRate: Double,
        baseDivYield: Double
    ): List<StressTestResult> {
        val baseValue = SyntheticInstrumentEngine.calculatePortfolioGreeks(legs, baseSpot, baseRate, baseDivYield).netPrice

        val presets = listOf(
            Triple("VOL_SHOCK", "Severe market downturn: Spot -10%, Vol +15.0 pts, 2 days decay", Pair(-0.10, 0.15)),
            Triple("VOL_CRUSH", "Post-event volatility collapse: Spot +4%, Vol -10.0 pts", Pair(0.04, -0.10)),
            Triple("TAIL_RISK_LIQUIDATION", "Black swan equity crash: Spot -25%, Vol +25.0 pts", Pair(-0.25, 0.25)),
            Triple("RATES_UP_INFLATION", "Sharp rate hike: Spot -5%, Vol +5.0 pts, Rates +150 bps", Pair(-0.05, 0.05)),
            Triple("SKEW_STEEPENING", "Flight to downside puts: OTM Put vol expansion +8.0 pts", Pair(-0.04, 0.08)),
            Triple("GRIND_UP_MELT", "Slow rally with vol bleed: Spot +6%, Vol -6.0 pts, 10 days decay", Pair(0.06, -0.06))
        )

        return presets.map { (name, desc, shifts) ->
            val (sShift, vShift) = shifts
            val shiftedSpot = baseSpot * (1.0 + sShift)

            val shiftedLegs = legs.map { leg ->
                if (leg.instrument is com.example.domain.model.OptionInstrument) {
                    val inst = leg.instrument as com.example.domain.model.OptionInstrument
                    leg.copy(
                        instrument = inst.copy(
                            expiryDays = max(1.0, inst.expiryDays - 2.0),
                            impliedVolatility = max(0.01, inst.impliedVolatility + vShift)
                        )
                    )
                } else leg
            }

            val stressedGreeks = SyntheticInstrumentEngine.calculatePortfolioGreeks(shiftedLegs, shiftedSpot, baseRate, baseDivYield)
            val stressedVal = stressedGreeks.netPrice
            val stressedPnl = stressedVal - baseValue

            val legBreakdown = legs.mapIndexed { idx, leg ->
                val singleLegBase = SyntheticInstrumentEngine.calculatePortfolioGreeks(listOf(leg), baseSpot, baseRate, baseDivYield).netPrice
                val singleLegStressed = SyntheticInstrumentEngine.calculatePortfolioGreeks(listOf(shiftedLegs[idx]), shiftedSpot, baseRate, baseDivYield).netPrice
                "${leg.side} ${leg.quantity}x ${leg.instrument.instrumentId}" to (singleLegStressed - singleLegBase)
            }

            StressTestResult(
                presetName = name,
                description = desc,
                spotShift = sShift,
                volShift = vShift,
                daysShift = 2.0,
                initialValue = baseValue,
                stressedValue = stressedVal,
                stressedPnl = stressedPnl,
                residualDelta = stressedGreeks.netDelta,
                legBreakdowns = legBreakdown
            )
        }
    }

    /**
     * Taylor-series P&L Attribution:
     * Decomposes total P&L into Delta, Gamma, Vega, Theta, Rho, Carry, and Residual.
     */
    fun attributePnl(
        greeks: PortfolioGreeks,
        dS: Double,
        dVol: Double, // in percentage points, e.g. +2.0
        dtDays: Double,
        dRateBps: Double,
        actualTotalPnl: Double
    ): PnlAttribution {
        val deltaPnl = greeks.netDelta * dS
        val gammaPnl = 0.5 * greeks.netGamma * dS * dS
        val vegaPnl = greeks.netVega * dVol
        val thetaPnl = greeks.netTheta * dtDays
        val rhoPnl = greeks.netRho * (dRateBps / 100.0)
        val carryPnl = (thetaPnl * 0.15)
        val modeledSum = deltaPnl + gammaPnl + vegaPnl + thetaPnl + rhoPnl
        val residualPnl = actualTotalPnl - modeledSum

        return PnlAttribution(
            totalPnl = actualTotalPnl,
            deltaPnl = deltaPnl,
            gammaPnl = gammaPnl,
            vegaPnl = vegaPnl,
            thetaPnl = thetaPnl,
            rhoPnl = rhoPnl,
            carryPnl = carryPnl,
            residualPnl = residualPnl
        )
    }

    /**
     * Fast parametric & historical Monte Carlo VaR / Expected Shortfall simulation.
     */
    fun simulateMonteCarloRisk(
        legs: List<PositionLeg>,
        baseSpot: Double,
        baseRate: Double,
        baseDivYield: Double,
        horizonDays: Double = 1.0,
        numSimulations: Int = 10_000,
        annualVol: Double = 0.22
    ): MonteCarloRiskReport {
        val baseVal = SyntheticInstrumentEngine.calculatePortfolioGreeks(legs, baseSpot, baseRate, baseDivYield).netPrice
        val dt = horizonDays / 365.0
        val drift = (baseRate - baseDivYield - 0.5 * annualVol * annualVol) * dt
        val stdDev = annualVol * sqrt(dt)

        val rng = java.util.Random(1337L)
        val pnlSamples = DoubleArray(numSimulations)

        for (i in 0 until numSimulations) {
            val u1 = max(1e-12, rng.nextDouble())
            val u2 = rng.nextDouble()
            val z = sqrt(-2.0 * ln(u1)) * cos(2.0 * Math.PI * u2)

            val simSpot = baseSpot * exp(drift + stdDev * z)
            val simVolShift = -0.4 * z * annualVol * 0.1 // leverage effect (vol rises when spot falls)

            val simLegs = legs.map { leg ->
                if (leg.instrument is com.example.domain.model.OptionInstrument) {
                    val inst = leg.instrument as com.example.domain.model.OptionInstrument
                    leg.copy(
                        instrument = inst.copy(
                            expiryDays = max(0.5, inst.expiryDays - horizonDays),
                            impliedVolatility = max(0.01, inst.impliedVolatility + simVolShift)
                        )
                    )
                } else leg
            }

            val simVal = SyntheticInstrumentEngine.calculatePortfolioGreeks(simLegs, simSpot, baseRate, baseDivYield).netPrice
            pnlSamples[i] = simVal - baseVal
        }

        pnlSamples.sort() // ascending: worst losses first

        val idx95 = (numSimulations * 0.05).toInt().coerceIn(0, numSimulations - 1)
        val idx99 = (numSimulations * 0.01).toInt().coerceIn(0, numSimulations - 1)

        val var95 = -pnlSamples[idx95]
        val var99 = -pnlSamples[idx99]

        // Expected Shortfall (CVaR): average loss beyond VaR threshold
        val es95 = -pnlSamples.slice(0..idx95).average()
        val es99 = -pnlSamples.slice(0..idx99).average()

        val worstLoss = -pnlSamples.first()
        val maxGain = pnlSamples.last()
        val probOfLoss = pnlSamples.count { it < 0 }.toDouble() / numSimulations

        return MonteCarloRiskReport(
            var95 = var95,
            var99 = var99,
            expectedShortfall95 = es95,
            expectedShortfall99 = es99,
            worstCaseLoss = worstLoss,
            maxGain = maxGain,
            probOfLoss = probOfLoss,
            simulatedDistribution = pnlSamples.toList()
        )
    }
}
