package com.example.domain.pricing

import com.example.domain.model.ExerciseStyle
import com.example.domain.model.OptionType
import kotlin.math.*

data class BinomialResult(
    val price: Double,
    val earlyExercisePremium: Double,
    val delta: Double,
    val gamma: Double,
    val theta: Double,
    val steps: Int,
    val earlyExerciseNodes: Int
)

object BinomialCRR {

    /**
     * Cox-Ross-Rubinstein (CRR) binomial lattice pricing.
     * Supports European and American style options.
     * Calculates early exercise premium and lattice Greeks.
     */
    fun price(
        S: Double,
        K: Double,
        T: Double,
        r: Double,
        q: Double,
        sigma: Double,
        type: OptionType,
        style: ExerciseStyle = ExerciseStyle.AMERICAN,
        steps: Int = 100
    ): BinomialResult {
        val n = max(10, steps)
        val dt = T / n
        val u = exp(sigma * sqrt(dt))
        val d = 1.0 / u
        val p = (exp((r - q) * dt) - d) / (u - d)
        val discount = exp(-r * dt)

        val prices = DoubleArray(n + 1)
        val values = DoubleArray(n + 1)

        // Terminal payoff at step n
        for (i in 0..n) {
            prices[i] = S * u.pow(n - i) * d.pow(i)
            values[i] = if (type == OptionType.CALL) {
                max(0.0, prices[i] - K)
            } else {
                max(0.0, K - prices[i])
            }
        }

        var earlyExerciseCount = 0
        var sUp = 0.0
        var sDown = 0.0
        var vUp = 0.0
        var vDown = 0.0
        var vMid = 0.0

        // Step backwards through the tree
        for (step in n - 1 downTo 0) {
            for (i in 0..step) {
                val spotAtNode = S * u.pow(step - i) * d.pow(i)
                val continuationValue = discount * (p * values[i] + (1.0 - p) * values[i + 1])
                val intrinsicValue = if (type == OptionType.CALL) {
                    max(0.0, spotAtNode - K)
                } else {
                    max(0.0, K - spotAtNode)
                }

                if (style == ExerciseStyle.AMERICAN && intrinsicValue > continuationValue) {
                    values[i] = intrinsicValue
                    earlyExerciseCount++
                } else {
                    values[i] = continuationValue
                }
            }

            // Record step 1 and step 2 for lattice Greeks
            if (step == 1) {
                sUp = S * u
                sDown = S * d
                vUp = values[0]
                vDown = values[1]
            } else if (step == 2) {
                vMid = values[1]
            }
        }

        val treePrice = values[0]
        val europeanBsPrice = BlackScholes.price(S, K, T, r, q, sigma, type)
        val earlyExercisePremium = if (style == ExerciseStyle.AMERICAN) {
            max(0.0, treePrice - europeanBsPrice)
        } else 0.0

        // Lattice Greeks
        val delta = if (sUp != sDown) (vUp - vDown) / (sUp - sDown) else 0.0
        val h = 0.5 * (sUp - sDown)
        val gamma = if (h > 0) ((vUp - treePrice) / (sUp - S) - (treePrice - vDown) / (S - sDown)) / h else 0.0
        val theta = ((vMid - treePrice) / (2.0 * dt)) / 365.0

        return BinomialResult(
            price = treePrice,
            earlyExercisePremium = earlyExercisePremium,
            delta = delta,
            gamma = gamma,
            theta = theta,
            steps = n,
            earlyExerciseNodes = earlyExerciseCount
        )
    }
}
