package com.example.domain.synthetics

import com.example.domain.model.*
import com.example.domain.pricing.BlackScholes
import com.example.domain.pricing.PricingResult
import kotlin.math.*

data class PortfolioGreeks(
    val netPrice: Double,
    val netDelta: Double,
    val netGamma: Double,
    val netVega: Double,
    val netTheta: Double,
    val netRho: Double,
    val netVanna: Double,
    val netVolga: Double,
    val netCharm: Double,
    val totalNotional: Double
)

data class PayoffPoint(
    val underlyingPrice: Double,
    val payoffAtExpiry: Double,
    val pnlAtExpiry: Double
)

data class PayoffAnalysis(
    val points: List<PayoffPoint>,
    val maxProfit: Double,
    val maxLoss: Double,
    val breakEvenPoints: List<Double>,
    val initialCost: Double,
    val probabilityOfProfit: Double
)

data class SyntheticDecomposition(
    val strategyName: String,
    val detectedSyntheticType: String,
    val resolvedLegs: List<PositionLeg>,
    val greeks: PortfolioGreeks,
    val payoff: PayoffAnalysis,
    val putCallParityDislocation: Double?,
    val impliedFinancingRate: Double?,
    val replicationDescription: String
)

object SyntheticInstrumentEngine {

    /**
     * Calculates combined portfolio Greeks across all constituent legs.
     */
    fun calculatePortfolioGreeks(
        legs: List<PositionLeg>,
        spot: Double,
        rate: Double,
        divYield: Double,
        volOverride: Double? = null
    ): PortfolioGreeks {
        var netPrice = 0.0
        var netDelta = 0.0
        var netGamma = 0.0
        var netVega = 0.0
        var netTheta = 0.0
        var netRho = 0.0
        var netVanna = 0.0
        var netVolga = 0.0
        var netCharm = 0.0
        var totalNotional = 0.0

        for (leg in legs) {
            val mult = leg.side.multiplier() * leg.quantity
            val contractMultiplier = leg.instrument.priceMultiplier

            when (val inst = leg.instrument) {
                is SpotInstrument -> {
                    val price = leg.effectivePrice
                    netPrice += price * mult * contractMultiplier
                    netDelta += 1.0 * mult * contractMultiplier
                    totalNotional += abs(price * mult * contractMultiplier)
                }
                is FutureInstrument -> {
                    val price = leg.effectivePrice
                    val T = inst.expiryDays / 365.0
                    val deltaFactor = exp((rate - divYield) * T)
                    netPrice += price * mult * contractMultiplier
                    netDelta += deltaFactor * mult * contractMultiplier
                    totalNotional += abs(price * mult * contractMultiplier)
                }
                is OptionInstrument -> {
                    val T = max(1e-5, inst.expiryDays / 365.0)
                    val vol = volOverride ?: inst.impliedVolatility
                    val pr = BlackScholes.priceAndGreeks(
                        S = spot,
                        K = inst.strike,
                        T = T,
                        r = rate,
                        q = divYield,
                        sigma = vol,
                        type = inst.optionType
                    )
                    netPrice += leg.effectivePrice * mult * contractMultiplier
                    netDelta += pr.delta * mult * contractMultiplier
                    netGamma += pr.gamma * mult * contractMultiplier
                    netVega += pr.vega * mult * contractMultiplier
                    netTheta += pr.theta * mult * contractMultiplier
                    netRho += pr.rho * mult * contractMultiplier
                    netVanna += pr.vanna * mult * contractMultiplier
                    netVolga += pr.volga * mult * contractMultiplier
                    netCharm += pr.charm * mult * contractMultiplier
                    totalNotional += abs(inst.strike * mult * contractMultiplier)
                }
            }
        }

        return PortfolioGreeks(
            netPrice = netPrice,
            netDelta = netDelta,
            netGamma = netGamma,
            netVega = netVega,
            netTheta = netTheta,
            netRho = netRho,
            netVanna = netVanna,
            netVolga = netVolga,
            netCharm = netCharm,
            totalNotional = totalNotional
        )
    }

    /**
     * Evaluates terminal payoff at expiry across spot price range.
     */
    fun evaluatePayoff(
        legs: List<PositionLeg>,
        currentSpot: Double,
        rangePercent: Double = 0.30,
        numPoints: Int = 100
    ): PayoffAnalysis {
        val minSpot = max(1.0, currentSpot * (1.0 - rangePercent))
        val maxSpot = currentSpot * (1.0 + rangePercent)
        val step = (maxSpot - minSpot) / (numPoints - 1)

        val points = mutableListOf<PayoffPoint>()
        var initialCost = 0.0

        for (leg in legs) {
            initialCost += leg.side.multiplier() * leg.quantity * leg.effectivePrice * leg.instrument.priceMultiplier
        }

        var maxProfit = Double.NEGATIVE_INFINITY
        var maxLoss = Double.POSITIVE_INFINITY
        var profitableCount = 0

        val breakEvens = mutableListOf<Double>()
        var lastPnl: Double? = null
        var lastSpot = minSpot

        for (i in 0 until numPoints) {
            val s = minSpot + i * step
            var totalPayoffAtExpiry = 0.0

            for (leg in legs) {
                val mult = leg.side.multiplier() * leg.quantity * leg.instrument.priceMultiplier
                when (val inst = leg.instrument) {
                    is SpotInstrument -> {
                        totalPayoffAtExpiry += (s - leg.effectivePrice) * mult
                    }
                    is FutureInstrument -> {
                        totalPayoffAtExpiry += (s - leg.effectivePrice) * mult
                    }
                    is OptionInstrument -> {
                        val intrinsic = if (inst.optionType == OptionType.CALL) {
                            max(0.0, s - inst.strike)
                        } else {
                            max(0.0, inst.strike - s)
                        }
                        totalPayoffAtExpiry += intrinsic * mult
                    }
                }
            }

            val pnl = totalPayoffAtExpiry - initialCost
            points.add(PayoffPoint(underlyingPrice = s, payoffAtExpiry = totalPayoffAtExpiry, pnlAtExpiry = pnl))

            if (pnl > maxProfit) maxProfit = pnl
            if (pnl < maxLoss) maxLoss = pnl
            if (pnl >= 0.0) profitableCount++

            if (lastPnl != null) {
                if ((lastPnl < 0 && pnl >= 0) || (lastPnl > 0 && pnl <= 0)) {
                    // Linear interpolation of break-even
                    val ratio = abs(lastPnl) / (abs(lastPnl) + abs(pnl))
                    val beSpot = lastSpot + ratio * (s - lastSpot)
                    breakEvens.add(beSpot)
                }
            }
            lastPnl = pnl
            lastSpot = s
        }

        val probOfProfit = profitableCount.toDouble() / numPoints

        return PayoffAnalysis(
            points = points,
            maxProfit = maxProfit,
            maxLoss = maxLoss,
            breakEvenPoints = breakEvens.distinct(),
            initialCost = initialCost,
            probabilityOfProfit = probOfProfit
        )
    }

    /**
     * Universal decomposition engine:
     * Inspects constituent legs and classifies the synthetic structure mathematically.
     */
    fun decomposePortfolio(
        legs: List<PositionLeg>,
        spot: Double,
        rate: Double,
        divYield: Double
    ): SyntheticDecomposition {
        val greeks = calculatePortfolioGreeks(legs, spot, rate, divYield)
        val payoff = evaluatePayoff(legs, spot)

        // Classify structure
        var detectedType = "CUSTOM_MULTI_LEG_COMBINATION"
        var desc = "Custom multi-leg portfolio with ${legs.size} legs."
        var parityDislocation: Double? = null
        var impliedFinancing: Double? = null

        val options = legs.mapNotNull { if (it.instrument is OptionInstrument) it else null }
        val spots = legs.mapNotNull { if (it.instrument is SpotInstrument) it else null }

        if (legs.size == 2 && options.size == 2) {
            val opt1 = options[0]
            val opt2 = options[1]
            val inst1 = opt1.instrument as OptionInstrument
            val inst2 = opt2.instrument as OptionInstrument

            if (inst1.strike == inst2.strike && abs(inst1.expiryDays - inst2.expiryDays) < 1e-3) {
                val call = if (inst1.optionType == OptionType.CALL) opt1 else opt2
                val put = if (inst1.optionType == OptionType.PUT) opt1 else opt2

                if (call.side == Side.BUY && put.side == Side.SELL && call.quantity == put.quantity) {
                    detectedType = "SYNTHETIC_LONG_FORWARD"
                    desc = "LONG CALL + SHORT PUT at strike ${inst1.strike}: Replicates long forward contract. Delta ~ +1.0."
                    val T = inst1.expiryDays / 365.0
                    val theoreticalForward = spot * exp((rate - divYield) * T)
                    val observedForward = inst1.strike + (call.effectivePrice - put.effectivePrice) * exp(rate * T)
                    parityDislocation = observedForward - theoreticalForward
                } else if (call.side == Side.SELL && put.side == Side.BUY && call.quantity == put.quantity) {
                    detectedType = "SYNTHETIC_SHORT_FORWARD"
                    desc = "SHORT CALL + LONG PUT at strike ${inst1.strike}: Replicates short forward contract. Delta ~ -1.0."
                } else if (call.side == Side.BUY && put.side == Side.BUY) {
                    detectedType = "LONG_STRADDLE"
                    desc = "LONG CALL + LONG PUT at strike ${inst1.strike}: Pure delta-neutral long volatility & gamma exposure."
                } else if (call.side == Side.SELL && put.side == Side.SELL) {
                    detectedType = "SHORT_STRADDLE"
                    desc = "SHORT CALL + SHORT PUT at strike ${inst1.strike}: Short volatility & positive theta carry."
                }
            } else if (inst1.optionType == inst2.optionType && opt1.side != opt2.side) {
                val optType = inst1.optionType
                val buyLeg = if (opt1.side == Side.BUY) opt1 else opt2
                val sellLeg = if (opt1.side == Side.SELL) opt1 else opt2
                val buyStrike = (buyLeg.instrument as OptionInstrument).strike
                val sellStrike = (sellLeg.instrument as OptionInstrument).strike

                if (optType == OptionType.CALL) {
                    detectedType = if (buyStrike < sellStrike) "BULL_CALL_SPREAD" else "BEAR_CALL_SPREAD"
                    desc = "$detectedType between K=$buyStrike and K=$sellStrike."
                } else {
                    detectedType = if (buyStrike > sellStrike) "BEAR_PUT_SPREAD" else "BULL_PUT_SPREAD"
                    desc = "$detectedType between K=$buyStrike and K=$sellStrike."
                }
            }
        } else if (legs.size == 2 && spots.size == 1 && options.size == 1) {
            val spotLeg = spots[0]
            val optLeg = options[0]
            val opt = optLeg.instrument as OptionInstrument

            if (spotLeg.side == Side.BUY && opt.optionType == OptionType.PUT && optLeg.side == Side.BUY) {
                detectedType = "SYNTHETIC_LONG_CALL (PROTECTIVE PUT)"
                desc = "LONG SPOT + LONG PUT: Mathematically replicates a synthetic Long Call via Put-Call parity."
            } else if (spotLeg.side == Side.SELL && opt.optionType == OptionType.CALL && optLeg.side == Side.BUY) {
                detectedType = "SYNTHETIC_LONG_PUT"
                desc = "SHORT SPOT + LONG CALL: Mathematically replicates a synthetic Long Put."
            } else if (spotLeg.side == Side.BUY && opt.optionType == OptionType.CALL && optLeg.side == Side.SELL) {
                detectedType = "COVERED_CALL"
                desc = "LONG SPOT + SHORT CALL: Yield enhancement with capped upside."
            }
        } else if (legs.size == 4 && options.size == 4) {
            // Box Spread check
            val strikes = options.map { (it.instrument as OptionInstrument).strike }.distinct().sorted()
            if (strikes.size == 2) {
                val k1 = strikes[0]
                val k2 = strikes[1]
                detectedType = "SYNTHETIC_BOX_SPREAD"
                val tDays = (options[0].instrument as OptionInstrument).expiryDays
                val T = max(1e-4, tDays / 365.0)
                val payoffTerm = (k2 - k1) * 100.0
                val netCost = abs(payoff.initialCost)
                impliedFinancing = if (netCost > 0) ln(payoffTerm / netCost) / T else null
                desc = "BOX SPREAD: Bull Call Spread (K1=$k1, K2=$k2) + Bear Put Spread (K1=$k1, K2=$k2). Riskless synthetic financing instrument."
            }
        }

        return SyntheticDecomposition(
            strategyName = detectedType.replace("_", " "),
            detectedSyntheticType = detectedType,
            resolvedLegs = legs,
            greeks = greeks,
            payoff = payoff,
            putCallParityDislocation = parityDislocation,
            impliedFinancingRate = impliedFinancing,
            replicationDescription = desc
        )
    }
}
