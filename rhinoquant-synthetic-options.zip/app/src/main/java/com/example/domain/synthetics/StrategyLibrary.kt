package com.example.domain.synthetics

import com.example.domain.model.*

data class StrategyTemplate(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val legGenerator: (spot: Double, expiryDays: Double, atmVol: Double) -> List<PositionLeg>
)

object StrategyLibrary {

    val templates: List<StrategyTemplate> = listOf(
        StrategyTemplate(
            id = "SYNTH_LONG_FWD",
            name = "Synthetic Long Forward",
            category = "Directional",
            description = "LONG CALL(K,T) + SHORT PUT(K,T). Replicates a forward contract with 1.0 delta and identical cashflow obligations.",
            legGenerator = { spot, expiry, vol ->
                listOf(
                    PositionLeg(
                        id = "leg-1",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_C_$spot",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.04,
                            bid = spot * 0.039,
                            ask = spot * 0.041,
                            optionType = OptionType.CALL,
                            strike = spot,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    ),
                    PositionLeg(
                        id = "leg-2",
                        side = Side.SELL,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_P_$spot",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.038,
                            bid = spot * 0.037,
                            ask = spot * 0.039,
                            optionType = OptionType.PUT,
                            strike = spot,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    )
                )
            }
        ),
        StrategyTemplate(
            id = "SYNTH_SHORT_FWD",
            name = "Synthetic Short Forward",
            category = "Directional",
            description = "SHORT CALL(K,T) + LONG PUT(K,T). Replicates a short forward contract with -1.0 delta.",
            legGenerator = { spot, expiry, vol ->
                listOf(
                    PositionLeg(
                        id = "leg-1",
                        side = Side.SELL,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_C_$spot",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.04,
                            bid = spot * 0.039,
                            ask = spot * 0.041,
                            optionType = OptionType.CALL,
                            strike = spot,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    ),
                    PositionLeg(
                        id = "leg-2",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_P_$spot",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.038,
                            bid = spot * 0.037,
                            ask = spot * 0.039,
                            optionType = OptionType.PUT,
                            strike = spot,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    )
                )
            }
        ),
        StrategyTemplate(
            id = "SYNTH_LONG_CALL",
            name = "Synthetic Long Call",
            category = "Directional",
            description = "LONG UNDERLYING + LONG PUT(K,T). Replicates a Call option profile with limited downside.",
            legGenerator = { spot, expiry, vol ->
                listOf(
                    PositionLeg(
                        id = "leg-1",
                        side = Side.BUY,
                        quantity = 100.0,
                        instrument = SpotInstrument(
                            instrumentId = "SPX_SPOT",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot,
                            bid = spot - 0.25,
                            ask = spot + 0.25
                        )
                    ),
                    PositionLeg(
                        id = "leg-2",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_P_$spot",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.038,
                            bid = spot * 0.037,
                            ask = spot * 0.039,
                            optionType = OptionType.PUT,
                            strike = spot,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    )
                )
            }
        ),
        StrategyTemplate(
            id = "BOX_SPREAD_FINANCING",
            name = "Box Spread Financing",
            category = "Financing",
            description = "BULL CALL(K1,K2) + BEAR PUT(K1,K2). Synthetic zero-coupon bond yielding an implied borrowing/lending rate against SOFR.",
            legGenerator = { spot, expiry, vol ->
                val k1 = spot * 0.95
                val k2 = spot * 1.05
                listOf(
                    PositionLeg(
                        id = "leg-1",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_C_$k1",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.07,
                            bid = spot * 0.069,
                            ask = spot * 0.071,
                            optionType = OptionType.CALL,
                            strike = k1,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    ),
                    PositionLeg(
                        id = "leg-2",
                        side = Side.SELL,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_C_$k2",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.02,
                            bid = spot * 0.019,
                            ask = spot * 0.021,
                            optionType = OptionType.CALL,
                            strike = k2,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    ),
                    PositionLeg(
                        id = "leg-3",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_P_$k2",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.065,
                            bid = spot * 0.064,
                            ask = spot * 0.066,
                            optionType = OptionType.PUT,
                            strike = k2,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    ),
                    PositionLeg(
                        id = "leg-4",
                        side = Side.SELL,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_P_$k1",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.018,
                            bid = spot * 0.017,
                            ask = spot * 0.019,
                            optionType = OptionType.PUT,
                            strike = k1,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    )
                )
            }
        ),
        StrategyTemplate(
            id = "ZERO_COST_COLLAR",
            name = "Zero-Cost Collar",
            category = "Risk Management",
            description = "LONG UNDERLYING + BUY OTM PUT + SELL OTM CALL. Hedged equity exposure funded by upside surrender.",
            legGenerator = { spot, expiry, vol ->
                val kPut = spot * 0.95
                val kCall = spot * 1.05
                listOf(
                    PositionLeg(
                        id = "leg-1",
                        side = Side.BUY,
                        quantity = 100.0,
                        instrument = SpotInstrument(
                            instrumentId = "SPX_SPOT",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot,
                            bid = spot - 0.25,
                            ask = spot + 0.25
                        )
                    ),
                    PositionLeg(
                        id = "leg-2",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_P_$kPut",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.022,
                            bid = spot * 0.021,
                            ask = spot * 0.023,
                            optionType = OptionType.PUT,
                            strike = kPut,
                            expiryDays = expiry,
                            impliedVolatility = vol * 1.08
                        )
                    ),
                    PositionLeg(
                        id = "leg-3",
                        side = Side.SELL,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_C_$kCall",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.022,
                            bid = spot * 0.021,
                            ask = spot * 0.023,
                            optionType = OptionType.CALL,
                            strike = kCall,
                            expiryDays = expiry,
                            impliedVolatility = vol * 0.94
                        )
                    )
                )
            }
        ),
        StrategyTemplate(
            id = "LONG_STRADDLE",
            name = "Long Straddle",
            category = "Volatility",
            description = "LONG ATM CALL + LONG ATM PUT. High positive vega & gamma, sensitive to volatility explosion.",
            legGenerator = { spot, expiry, vol ->
                listOf(
                    PositionLeg(
                        id = "leg-1",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_C_$spot",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.04,
                            bid = spot * 0.039,
                            ask = spot * 0.041,
                            optionType = OptionType.CALL,
                            strike = spot,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    ),
                    PositionLeg(
                        id = "leg-2",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument(
                            instrumentId = "SPX_P_$spot",
                            assetClass = AssetClass.INDEX,
                            underlying = "SPX",
                            marketPrice = spot * 0.038,
                            bid = spot * 0.037,
                            ask = spot * 0.039,
                            optionType = OptionType.PUT,
                            strike = spot,
                            expiryDays = expiry,
                            impliedVolatility = vol
                        )
                    )
                )
            }
        ),
        StrategyTemplate(
            id = "IRON_CONDOR",
            name = "Iron Condor",
            category = "Volatility",
            description = "BULL PUT SPREAD + BEAR CALL SPREAD. Range-bound theta harvesting with strictly defined risk boundaries.",
            legGenerator = { spot, expiry, vol ->
                val p1 = spot * 0.90
                val p2 = spot * 0.95
                val c1 = spot * 1.05
                val c2 = spot * 1.10
                listOf(
                    PositionLeg("leg-1", Side.BUY, 1.0, OptionInstrument("SPX_P_$p1", AssetClass.INDEX, "SPX", marketPrice = spot * 0.009, bid = spot * 0.008, ask = spot * 0.010, optionType = OptionType.PUT, strike = p1, expiryDays = expiry, impliedVolatility = vol * 1.15)),
                    PositionLeg("leg-2", Side.SELL, 1.0, OptionInstrument("SPX_P_$p2", AssetClass.INDEX, "SPX", marketPrice = spot * 0.021, bid = spot * 0.020, ask = spot * 0.022, optionType = OptionType.PUT, strike = p2, expiryDays = expiry, impliedVolatility = vol * 1.08)),
                    PositionLeg("leg-3", Side.SELL, 1.0, OptionInstrument("SPX_C_$c1", AssetClass.INDEX, "SPX", marketPrice = spot * 0.020, bid = spot * 0.019, ask = spot * 0.021, optionType = OptionType.CALL, strike = c1, expiryDays = expiry, impliedVolatility = vol * 0.95)),
                    PositionLeg("leg-4", Side.BUY, 1.0, OptionInstrument("SPX_C_$c2", AssetClass.INDEX, "SPX", marketPrice = spot * 0.008, bid = spot * 0.007, ask = spot * 0.009, optionType = OptionType.CALL, strike = c2, expiryDays = expiry, impliedVolatility = vol * 0.92))
                )
            }
        ),
        StrategyTemplate(
            id = "CALENDAR_SPREAD",
            name = "Calendar Spread",
            category = "Time Structure",
            description = "SHORT FRONT-MONTH CALL + LONG BACK-MONTH CALL. Positive Vega, exploits differential theta decay curvature.",
            legGenerator = { spot, _, vol ->
                listOf(
                    PositionLeg(
                        id = "leg-1",
                        side = Side.SELL,
                        quantity = 1.0,
                        instrument = OptionInstrument("SPX_C_30D", AssetClass.INDEX, "SPX", marketPrice = spot * 0.025, bid = spot * 0.024, ask = spot * 0.026, optionType = OptionType.CALL, strike = spot, expiryDays = 30.0, impliedVolatility = vol)
                    ),
                    PositionLeg(
                        id = "leg-2",
                        side = Side.BUY,
                        quantity = 1.0,
                        instrument = OptionInstrument("SPX_C_90D", AssetClass.INDEX, "SPX", marketPrice = spot * 0.045, bid = spot * 0.044, ask = spot * 0.046, optionType = OptionType.CALL, strike = spot, expiryDays = 90.0, impliedVolatility = vol)
                    )
                )
            }
        )
    )
}
