package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RhinoQuant Institutional Color System
val RhinoBgDark = Color(0xFF0B111A)        // Deep terminal background
val RhinoSurfaceDark = Color(0xFF111926)   // Primary workspace surface
val RhinoSurfaceVariant = Color(0xFF162132)// Secondary analytical pane
val RhinoCardBg = Color(0xFF192538)        // Dense card / panel background
val RhinoBorder = Color(0xFF23354C)        // Precision grid & divider line
val RhinoBorderSubtle = Color(0xFF1A293D)  // Secondary separator

// Typography tones
val RhinoTextPrimary = Color(0xFFF1F5F9)   // Bright off-white for data
val RhinoTextSecondary = Color(0xFF94A3B8) // Muted steel slate for labels
val RhinoTextTertiary = Color(0xFF64748B)  // Timestamp & provenance
val RhinoTextMuted = Color(0xFF475569)

// Quantitative Accents (Restrained institutional palette)
val RhinoCyan = Color(0xFF38BDF8)          // Primary quant active / call / selection
val RhinoBlue = Color(0xFF2563EB)          // Deep brand primary
val RhinoEmerald = Color(0xFF10B981)       // Positive P&L / BUY / Call / Compliant
val RhinoEmeraldMuted = Color(0xFF065F46)  // Background tint
val RhinoCrimson = Color(0xFFF43F5E)       // Negative P&L / SELL / Put / Breach
val RhinoCrimsonMuted = Color(0xFF881337)  // Background tint
val RhinoAmber = Color(0xFFF59E0B)         // Warning / Limit watch / Model alert
val RhinoAmberMuted = Color(0xFF78350F)    // Amber background tint
val RhinoPurple = Color(0xFFA855F7)        // Volatility / Greeks accent

// Greeks & Risk metric colors
val DeltaColor = Color(0xFF38BDF8)
val GammaColor = Color(0xFF818CF8)
val VegaColor = Color(0xFFA855F7)
val ThetaColor = Color(0xFFFB923C)
val RhoColor = Color(0xFF34D399)
