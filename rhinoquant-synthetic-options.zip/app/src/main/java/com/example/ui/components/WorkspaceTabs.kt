package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TerminalWorkspace
import com.example.ui.theme.*

@Composable
fun WorkspaceTabs(
    currentWorkspace: TerminalWorkspace,
    onSelectWorkspace: (TerminalWorkspace) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(RhinoBgDark)
            .border(width = 1.dp, color = RhinoBorderSubtle)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TerminalWorkspace.values().forEach { ws ->
            val isSelected = ws == currentWorkspace

            Box(
                modifier = Modifier
                    .padding(horizontal = 2.dp, vertical = 2.dp)
                    .background(
                        if (isSelected) RhinoSurfaceVariant else Color.Transparent
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSelected) RhinoCyan else Color.Transparent
                    )
                    .clickable { onSelectWorkspace(ws) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("tab_${ws.name.lowercase()}")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = ws.iconLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) RhinoCyan else RhinoTextTertiary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        modifier = Modifier
                            .background(RhinoCardBg)
                            .padding(horizontal = 3.dp, vertical = 1.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = ws.title.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) RhinoTextPrimary else RhinoTextSecondary,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}
