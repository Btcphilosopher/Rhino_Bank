package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.synthetics.PayoffAnalysis
import com.example.ui.theme.*
import kotlin.math.abs
import kotlin.math.max

@Composable
fun PayoffCanvas(
    analysis: PayoffAnalysis,
    currentSpot: Double,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(RhinoCardBg, RoundedCornerShape(4.dp))
            .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
            .padding(10.dp)
            .testTag("payoff_canvas_container")
    ) {
        // Summary metrics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TERMINAL PAYOFF & P&L PROFILE",
                style = MaterialTheme.typography.labelSmall,
                color = RhinoTextSecondary,
                fontWeight = FontWeight.Bold
            )
            Row {
                Text(
                    text = "POP: ${String.format("%.1f", analysis.probabilityOfProfit * 100)}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoCyan,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "MAX PROFIT: ${if (analysis.maxProfit > 1e7) "UNLIMITED" else "$" + String.format("%.2f", analysis.maxProfit)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoEmerald
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "MAX LOSS: ${if (analysis.maxLoss < -1e7) "UNLIMITED" else "$" + String.format("%.2f", analysis.maxLoss)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoCrimson
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Canvas Payoff Curve
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(RhinoBgDark)
                .border(1.dp, RhinoBorderSubtle)
        ) {
            val points = analysis.points
            if (points.isEmpty()) return@Canvas

            val w = size.width
            val h = size.height

            val minSpot = points.first().underlyingPrice
            val maxSpot = points.last().underlyingPrice
            val spotRange = max(1.0, maxSpot - minSpot)

            val pnls = points.map { it.pnlAtExpiry }
            val minPnl = pnls.minOrNull() ?: -100.0
            val maxPnl = pnls.maxOrNull() ?: 100.0
            val pnlRange = max(1.0, max(abs(minPnl), abs(maxPnl)) * 2.2)

            val zeroY = h * 0.5f // center zero axis

            // Zero P&L horizontal reference line
            drawLine(
                color = RhinoBorder,
                start = Offset(0f, zeroY),
                end = Offset(w, zeroY),
                strokeWidth = 1.dp.toPx()
            )

            // Current Spot vertical line
            val currentSpotX = ((currentSpot - minSpot) / spotRange).toFloat() * w
            if (currentSpotX in 0f..w) {
                drawLine(
                    color = RhinoCyan.copy(alpha = 0.5f),
                    start = Offset(currentSpotX, 0f),
                    end = Offset(currentSpotX, h),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Path for payoff curve
            val curvePath = Path()
            points.forEachIndexed { i, pt ->
                val x = ((pt.underlyingPrice - minSpot) / spotRange).toFloat() * w
                val y = zeroY - (pt.pnlAtExpiry / (pnlRange * 0.5)).toFloat() * (h * 0.45f)
                val clampedY = y.coerceIn(0f, h)
                if (i == 0) {
                    curvePath.moveTo(x, clampedY)
                } else {
                    curvePath.lineTo(x, clampedY)
                }
            }

            // Draw line
            drawPath(
                path = curvePath,
                color = RhinoCyan,
                style = Stroke(width = 2.dp.toPx())
            )

            // Highlight break-even points
            analysis.breakEvenPoints.forEach { be ->
                val beX = ((be - minSpot) / spotRange).toFloat() * w
                if (beX in 0f..w) {
                    drawCircle(
                        color = RhinoAmber,
                        radius = 4.dp.toPx(),
                        center = Offset(beX, zeroY)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "BREAK-EVEN: ${if (analysis.breakEvenPoints.isEmpty()) "N/A" else analysis.breakEvenPoints.joinToString { "$" + String.format("%.2f", it) }}",
                style = MaterialTheme.typography.labelSmall,
                color = RhinoAmber
            )
            Text(
                text = "INITIAL CAPITAL: ${if (analysis.initialCost >= 0) "Debit $" else "Credit $"}${String.format("%.2f", abs(analysis.initialCost))}",
                style = MaterialTheme.typography.labelSmall,
                color = RhinoTextSecondary
            )
        }
    }
}
