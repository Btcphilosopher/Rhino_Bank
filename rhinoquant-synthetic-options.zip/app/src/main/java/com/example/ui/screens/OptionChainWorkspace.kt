package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.OptionType
import com.example.domain.model.Side
import com.example.ui.RhinoQuantUiState
import com.example.ui.RhinoQuantViewModel
import com.example.ui.theme.*

@Composable
fun OptionChainWorkspace(
    uiState: RhinoQuantUiState,
    viewModel: RhinoQuantViewModel,
    modifier: Modifier = Modifier
) {
    val chain = uiState.optionChain
    val quality = uiState.dataQuality
    val spot = uiState.selectedUnderlying.spotPrice

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(8.dp)
            .testTag("option_chain_screen")
    ) {
        // Data Quality & Market Depth bar
        if (quality != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(if (quality.overallHealthScore >= 90) RhinoEmeraldMuted else RhinoAmberMuted, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "HEALTH: ${quality.overallHealthScore}/100",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (quality.overallHealthScore >= 90) RhinoEmerald else RhinoAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Crossed quotes: ${quality.crossedQuotesDetected} | Latency: ${quality.latencyMs}ms",
                        style = MaterialTheme.typography.bodySmall,
                        color = RhinoTextSecondary
                    )
                }
                Text(
                    text = "${quality.provenance.name} FEED",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoCyan
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(RhinoCardBg)
                .border(1.dp, RhinoBorder)
                .padding(horizontal = 4.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("CALL BID/ASK", style = MaterialTheme.typography.labelSmall, color = RhinoCyan, modifier = Modifier.weight(1.8f))
            Text("IV", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(0.9f))
            Text("Δ (C)", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(0.8f))
            Text("STRIKE", style = MaterialTheme.typography.labelSmall, color = RhinoAmber, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
            Text("Δ (P)", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(0.8f))
            Text("IV", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(0.9f))
            Text("PUT BID/ASK", style = MaterialTheme.typography.labelSmall, color = RhinoPurple, modifier = Modifier.weight(1.8f))
        }

        // Option Chain Rows
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, RhinoBorderSubtle),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            items(chain) { row ->
                val isAtm = row.isAtm
                val c = row.call
                val p = row.put

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isAtm) RhinoSurfaceVariant else RhinoBgDark)
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Call Bid / Ask
                    Row(
                        modifier = Modifier
                            .weight(1.8f)
                            .clickable { viewModel.addLeg(Side.BUY, OptionType.CALL, row.strike) }
                    ) {
                        Text("$${String.format("%.2f", c.bid)}", style = MaterialTheme.typography.labelSmall, color = RhinoEmerald)
                        Text(" / ", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary)
                        Text("$${String.format("%.2f", c.ask)}", style = MaterialTheme.typography.labelSmall, color = RhinoCrimson)
                    }

                    // Call IV
                    Text(
                        text = "${String.format("%.1f", c.impliedVolatility * 100)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        modifier = Modifier.weight(0.9f)
                    )

                    // Call Delta
                    Text(
                        text = String.format("%.2f", c.delta),
                        style = MaterialTheme.typography.labelSmall,
                        color = DeltaColor,
                        modifier = Modifier.weight(0.8f)
                    )

                    // Strike Center
                    Box(
                        modifier = Modifier
                            .weight(1.3f)
                            .background(if (isAtm) RhinoAmberMuted else RhinoCardBg, RoundedCornerShape(2.dp))
                            .padding(vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$${row.strike.toInt()}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isAtm) RhinoAmber else RhinoTextPrimary
                        )
                    }

                    // Put Delta
                    Text(
                        text = String.format("%.2f", p.delta),
                        style = MaterialTheme.typography.labelSmall,
                        color = DeltaColor,
                        modifier = Modifier.weight(0.8f)
                    )

                    // Put IV
                    Text(
                        text = "${String.format("%.1f", p.impliedVolatility * 100)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        modifier = Modifier.weight(0.9f)
                    )

                    // Put Bid / Ask
                    Row(
                        modifier = Modifier
                            .weight(1.8f)
                            .clickable { viewModel.addLeg(Side.BUY, OptionType.PUT, row.strike) }
                    ) {
                        Text("$${String.format("%.2f", p.bid)}", style = MaterialTheme.typography.labelSmall, color = RhinoEmerald)
                        Text(" / ", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary)
                        Text("$${String.format("%.2f", p.ask)}", style = MaterialTheme.typography.labelSmall, color = RhinoCrimson)
                    }
                }
            }
        }
    }
}
