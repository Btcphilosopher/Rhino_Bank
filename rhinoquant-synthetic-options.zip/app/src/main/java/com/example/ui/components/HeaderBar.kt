package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.marketdata.UnderlyingMarketSnapshot
import com.example.domain.model.DataProvenance
import com.example.ui.theme.*

@Composable
fun HeaderBar(
    selectedUnderlying: UnderlyingMarketSnapshot,
    availableUnderlyings: List<UnderlyingMarketSnapshot>,
    selectedExpiryDays: Double,
    onSelectUnderlying: (String) -> Unit,
    onSelectExpiry: (Double) -> Unit,
    onQuickRqql: (String) -> Unit,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    var quickCmd by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(RhinoSurfaceDark)
            .border(width = 1.dp, color = RhinoBorder)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Top row: Brand & Status indicators
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Logo & System status
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(RhinoCyan.copy(alpha = 0.2f))
                        .border(1.dp, RhinoCyan, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "RQ",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "RHINOQUANT",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = RhinoTextPrimary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SYNTHETIC OPTIONS",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoCyan,
                    modifier = Modifier
                        .background(RhinoSurfaceVariant, RoundedCornerShape(2.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            // Provenance & System Health
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(RhinoEmeraldMuted)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "DATA: DEMO | 4ms",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoEmerald,
                        fontSize = 9.sp
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onToggleTheme,
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("theme_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = "Toggle Theme",
                        tint = RhinoTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Second row: Underlying Selector & Live Quote Ticker
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "UNDERLYING:",
                style = MaterialTheme.typography.labelSmall,
                color = RhinoTextTertiary,
                modifier = Modifier.padding(end = 6.dp)
            )

            availableUnderlyings.forEach { und ->
                val isSelected = und.symbol == selectedUnderlying.symbol
                Box(
                    modifier = Modifier
                        .padding(end = 6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isSelected) RhinoBlue else RhinoCardBg)
                        .border(
                            1.dp,
                            if (isSelected) RhinoCyan else RhinoBorder,
                            RoundedCornerShape(3.dp)
                        )
                        .clickable { onSelectUnderlying(und.symbol) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("underlying_tab_${und.symbol}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = und.symbol,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else RhinoTextPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = String.format("%.2f", und.spotPrice),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) RhinoCyan else RhinoTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "TENOR:",
                style = MaterialTheme.typography.labelSmall,
                color = RhinoTextTertiary,
                modifier = Modifier.padding(end = 6.dp)
            )

            selectedUnderlying.availableExpiries.forEach { exp ->
                val isSelected = exp == selectedExpiryDays
                Box(
                    modifier = Modifier
                        .padding(end = 4.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isSelected) RhinoSurfaceVariant else RhinoBgDark)
                        .border(
                            1.dp,
                            if (isSelected) RhinoCyan else RhinoBorderSubtle,
                            RoundedCornerShape(3.dp)
                        )
                        .clickable { onSelectExpiry(exp) }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                        .testTag("expiry_tab_${exp.toInt()}D")
                ) {
                    Text(
                        text = "${exp.toInt()}D",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) RhinoCyan else RhinoTextSecondary
                    )
                }
            }
        }
    }
}
