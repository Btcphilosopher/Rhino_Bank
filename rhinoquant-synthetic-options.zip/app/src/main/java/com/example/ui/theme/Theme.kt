package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RhinoDarkColorScheme = darkColorScheme(
    primary = RhinoCyan,
    onPrimary = Color(0xFF031C34),
    primaryContainer = RhinoBlue,
    onPrimaryContainer = Color(0xFFE0F2FE),
    secondary = RhinoTextSecondary,
    onSecondary = Color(0xFF0F172A),
    secondaryContainer = RhinoSurfaceVariant,
    onSecondaryContainer = RhinoTextPrimary,
    tertiary = RhinoPurple,
    onTertiary = Color.White,
    background = RhinoBgDark,
    onBackground = RhinoTextPrimary,
    surface = RhinoSurfaceDark,
    onSurface = RhinoTextPrimary,
    surfaceVariant = RhinoCardBg,
    onSurfaceVariant = RhinoTextSecondary,
    outline = RhinoBorder,
    outlineVariant = RhinoBorderSubtle,
    error = RhinoCrimson,
    onError = Color.White
)

private val RhinoLightColorScheme = lightColorScheme(
    primary = Color(0xFF0284C7),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = Color(0xFF475569),
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF334155),
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFFE2E8F0),
    error = RhinoCrimson,
    onError = Color.White
)

@Composable
fun RhinoQuantTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) RhinoDarkColorScheme else RhinoLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
