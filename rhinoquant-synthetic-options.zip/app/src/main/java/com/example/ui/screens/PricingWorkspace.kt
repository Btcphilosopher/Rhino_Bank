package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.OptionType
import com.example.domain.pricing.*
import com.example.ui.RhinoQuantUiState
import com.example.ui.RhinoQuantViewModel
import com.example.ui.theme.*

@Composable
fun PricingWorkspace(
    uiState: RhinoQuantUiState,
    viewModel: RhinoQuantViewModel,
    modifier: Modifier = Modifier
) {
    val spot = uiState.selectedUnderlying.spotPrice
    val r = uiState.selectedUnderlying.riskFreeRate
    val q = uiState.selectedUnderlying.dividendYieldOrCarry
    val expiryDays = uiState.selectedExpiryDays
    val T = expiryDays / 365.0

    var strikeInput by remember { mutableStateOf(spot.toString()) }
    var volInput by remember { mutableStateOf("0.20") }
    var selectedOptionType by remember { mutableStateOf(OptionType.CALL) }

    val currentStrike = strikeInput.toDoubleOrNull() ?: spot
    val currentVol = volInput.toDoubleOrNull() ?: 0.20

    // Analytical pricing
    val bsResult = BlackScholes.priceAndGreeks(spot, currentStrike, T, r, q, currentVol, selectedOptionType)
    val b76Result = Black76.priceAndGreeks(spot, currentStrike, T, r, currentVol, selectedOptionType)
    val crrResult = uiState.binomialAmericanResult

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(10.dp)
            .testTag("pricing_models_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Model Configuration Inputs
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "QUANTITATIVE PRICING ENGINE INPUTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = strikeInput,
                        onValueChange = { strikeInput = it },
                        label = { Text("Strike ($)", color = RhinoTextTertiary) },
                        textStyle = MaterialTheme.typography.labelSmall.copy(color = RhinoTextPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("pricing_strike_input")
                    )
                    OutlinedTextField(
                        value = volInput,
                        onValueChange = { volInput = it },
                        label = { Text("Vol (e.g. 0.20)", color = RhinoTextTertiary) },
                        textStyle = MaterialTheme.typography.labelSmall.copy(color = RhinoTextPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("pricing_vol_input")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { selectedOptionType = OptionType.CALL },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedOptionType == OptionType.CALL) RhinoCyan else RhinoCardBg),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("CALL OPTION", color = if (selectedOptionType == OptionType.CALL) RhinoBgDark else RhinoTextPrimary, style = MaterialTheme.typography.labelSmall)
                    }

                    Button(
                        onClick = { selectedOptionType = OptionType.PUT },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedOptionType == OptionType.PUT) RhinoPurple else RhinoCardBg),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("PUT OPTION", color = if (selectedOptionType == OptionType.PUT) Color.White else RhinoTextPrimary, style = MaterialTheme.typography.labelSmall)
                    }

                    Button(
                        onClick = { viewModel.runMonteCarloSimulation() },
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoBlue),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Text("RUN MONTE CARLO", color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // 2. Cross-Model Valuation Comparison
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "CROSS-MODEL VALUATION MATRIX",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ModelCard("BLACK-SCHOLES (EUR)", "$${String.format("%.4f", bsResult.price)}", "Continuous q=${String.format("%.2f", q * 100)}%", RhinoCyan, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    ModelCard("BLACK-76 (FORWARD)", "$${String.format("%.4f", b76Result.price)}", "Futures F=$${String.format("%.2f", spot)}", RhinoBlue, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    val crrPrice = crrResult?.price ?: bsResult.price
                    val earlyPrem = crrResult?.earlyExercisePremium ?: 0.0
                    ModelCard("CRR BINOMIAL (AME)", "$${String.format("%.4f", crrPrice)}", "Early Prem: +$${String.format("%.3f", earlyPrem)}", RhinoAmber, Modifier.weight(1f))
                }

                if (uiState.monteCarloPricingResult != null) {
                    val mc = uiState.monteCarloPricingResult
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RhinoCardBg, RoundedCornerShape(3.dp))
                            .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(3.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("MONTE CARLO (20,000 PATHS ANTITHETIC)", style = MaterialTheme.typography.labelSmall, color = RhinoPurple, fontWeight = FontWeight.Bold)
                                Text("Mean Price: $${String.format("%.4f", mc.price)} | Std Error: ±$${String.format("%.4f", mc.standardError)}", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("95% CI: [$${String.format("%.3f", mc.ci95Lower)}, $${String.format("%.3f", mc.ci95Upper)}]", style = MaterialTheme.typography.labelSmall, color = RhinoCyan)
                                Text("Duration: ${mc.executionTimeMs}ms", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary)
                            }
                        }
                    }
                }
            }
        }

        // 3. Full Analytical Greeks Breakdown (1st, 2nd, 3rd Order)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "ANALYTICAL GREEKS HIERARCHY (EXACT DERIVATIVES)",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                GreekRow("DELTA (Δ = ∂V/∂S)", String.format("%+8.4f", bsResult.delta), "GAMMA (Γ = ∂²V/∂S²)", String.format("%+8.6f", bsResult.gamma))
                GreekRow("VEGA (V = ∂V/∂σ per 1%)", String.format("%+8.4f", bsResult.vega), "THETA (Θ = ∂V/∂t per day)", String.format("%+8.4f", bsResult.theta))
                GreekRow("RHO (ρ = ∂V/∂r per 100bps)", String.format("%+8.4f", bsResult.rho), "VANNA (∂²V/∂S∂σ)", String.format("%+8.5f", bsResult.vanna))
                GreekRow("VOLGA / VOLGAMMA (∂²V/∂σ²)", String.format("%+8.5f", bsResult.volga), "CHARM (∂Δ/∂t per day)", String.format("%+8.5f", bsResult.charm))
                GreekRow("COLOR (∂Γ/∂t per day)", String.format("%+8.6f", bsResult.color), "SPEED (∂³V/∂S³)", String.format("%+8.6f", bsResult.speed))
                GreekRow("ZOMMA (∂Γ/∂σ)", String.format("%+8.5f", bsResult.zomma), "d1 / d2 NORMAL ARGUMENTS", "${String.format("%.3f", bsResult.d1)} / ${String.format("%.3f", bsResult.d2)}")
            }
        }
    }
}

@Composable
private fun ModelCard(name: String, price: String, detail: String, accentColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(RhinoCardBg, RoundedCornerShape(3.dp))
            .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(3.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(name, style = MaterialTheme.typography.labelSmall, color = accentColor, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(price, style = MaterialTheme.typography.titleMedium, color = RhinoTextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(detail, style = MaterialTheme.typography.bodySmall, color = RhinoTextTertiary, fontSize = 9.sp)
        }
    }
}

@Composable
private fun GreekRow(name1: String, val1: String, name2: String, val2: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(name1, style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, fontSize = 9.sp)
            Text(val1, style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, fontWeight = FontWeight.Bold)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(name2, style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, fontSize = 9.sp)
            Text(val2, style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, fontWeight = FontWeight.Bold)
        }
    }
}
