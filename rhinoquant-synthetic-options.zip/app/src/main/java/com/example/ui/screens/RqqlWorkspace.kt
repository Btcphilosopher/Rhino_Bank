package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoQuantUiState
import com.example.ui.RhinoQuantViewModel
import com.example.ui.theme.*

@Composable
fun RqqlWorkspace(
    uiState: RhinoQuantUiState,
    viewModel: RhinoQuantViewModel,
    modifier: Modifier = Modifier
) {
    var cmdText by remember { mutableStateOf("") }
    val history = uiState.rqqlHistory

    val quickCommands = listOf(
        "SYNTHETIC LONG FORWARD STRIKE 5825 EXPIRY 90",
        "LONG STRADDLE STRIKE 5825 EXPIRY 30",
        "PRICE",
        "GREEKS",
        "HEDGE DELTA",
        "SCENARIO SPOT +10%",
        "STRESS VOL +15"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(10.dp)
            .testTag("rqql_console_screen")
    ) {
        // Quick Presets
        Text(
            text = "RQQL (RHINOQUANT QUANT LANGUAGE) COMMAND PALETTE",
            style = MaterialTheme.typography.labelSmall,
            color = RhinoTextSecondary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickCommands.forEach { qCmd ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(RhinoCardBg)
                        .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(3.dp))
                        .clickable {
                            cmdText = qCmd
                            viewModel.executeRqqlCommand(qCmd)
                        }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Text(qCmd, style = MaterialTheme.typography.labelSmall, color = RhinoCyan, fontSize = 9.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input Line
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = cmdText,
                onValueChange = { cmdText = it },
                placeholder = { Text("Enter RQQL command (e.g. 'HEDGE DELTA')...", color = RhinoTextTertiary, style = MaterialTheme.typography.labelSmall) },
                textStyle = MaterialTheme.typography.labelSmall.copy(color = RhinoTextPrimary),
                modifier = Modifier
                    .weight(1f)
                    .testTag("rqql_command_input")
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    viewModel.executeRqqlCommand(cmdText)
                    cmdText = ""
                },
                colors = ButtonDefaults.buttonColors(containerColor = RhinoCyan),
                shape = RoundedCornerShape(3.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("rqql_execute_btn")
            ) {
                Text("RUN", style = MaterialTheme.typography.labelSmall, color = RhinoBgDark, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Console Output History
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (history.isEmpty()) {
                item {
                    Text(
                        text = "RQQL Terminal Ready. Enter a command or click a preset above.",
                        style = MaterialTheme.typography.bodySmall,
                        color = RhinoTextTertiary
                    )
                }
            } else {
                items(history.reversed()) { (cmd, res) ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RhinoCardBg, RoundedCornerShape(3.dp))
                            .border(1.dp, if (res.isSuccess) RhinoBorderSubtle else RhinoCrimson.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("> $cmd", style = MaterialTheme.typography.labelSmall, color = RhinoCyan, fontWeight = FontWeight.Bold)
                                Text(if (res.isSuccess) "OK" else "ERR", style = MaterialTheme.typography.labelSmall, color = if (res.isSuccess) RhinoEmerald else RhinoCrimson, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(res.outputTitle, style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(res.outputText, style = MaterialTheme.typography.bodySmall, color = RhinoTextSecondary)

                            if (res.keyMetrics.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    res.keyMetrics.forEach { (k, v) ->
                                        Text("$k: $v", style = MaterialTheme.typography.labelSmall, color = RhinoAmber, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
