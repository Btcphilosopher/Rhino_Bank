package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.risk.ScenarioEngine
import com.example.ui.RhinoQuantUiState
import com.example.ui.RhinoQuantViewModel
import com.example.ui.theme.*

@Composable
fun ScenarioWorkspace(
    uiState: RhinoQuantUiState,
    viewModel: RhinoQuantViewModel,
    modifier: Modifier = Modifier
) {
    val grid = uiState.scenarioGrid
    val stress = uiState.stressResults
    val mcRisk = uiState.monteCarloRisk

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(10.dp)
            .testTag("scenario_cube_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Scenario Cube Heat Matrix (Spot Shift vs Vol Shift)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "MULTIDIMENSIONAL SCENARIO CUBE (UNDERLYING SHIFT x VOLATILITY SHIFT)",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Values display expected portfolio mark-to-market P&L in USD.",
                    style = MaterialTheme.typography.bodySmall,
                    color = RhinoTextTertiary
                )
                Spacer(modifier = Modifier.height(6.dp))

                val spotShifts = ScenarioEngine.standardSpotShifts
                val volShifts = ScenarioEngine.standardVolShifts

                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoCardBg)
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("VOL \\ SPOT", style = MaterialTheme.typography.labelSmall, color = RhinoAmber, modifier = Modifier.weight(1.2f))
                    spotShifts.forEach { sShift ->
                        Text(
                            text = "${if (sShift >= 0) "+" else ""}${(sShift * 100).toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = RhinoTextTertiary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                volShifts.forEach { vShift ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${if (vShift >= 0) "+" else ""}${(vShift * 100).toInt()}v",
                            style = MaterialTheme.typography.labelSmall,
                            color = RhinoCyan,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1.2f)
                        )

                        spotShifts.forEach { sShift ->
                            val cell = grid.find { it.spotShiftPercent == sShift && it.volShiftPoints == vShift }
                            val pnl = cell?.pnl ?: 0.0
                            val pnlColor = when {
                                pnl > 50.0 -> RhinoEmerald
                                pnl < -50.0 -> RhinoCrimson
                                else -> RhinoTextPrimary
                            }

                            Text(
                                text = "${if (pnl >= 0) "+" else ""}${pnl.toInt()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = pnlColor,
                                fontWeight = if (kotlin.math.abs(pnl) > 500) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // 2. Institutional Stress Testing Presets
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "INSTITUTIONAL STRESS TEST SCENARIOS",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                stress.forEach { s ->
                    val isProfit = s.stressedPnl >= 0
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = RhinoCardBg),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorderSubtle))
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(s.presetName, style = MaterialTheme.typography.labelMedium, color = RhinoTextPrimary, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${if (isProfit) "+$" else "-$"}${String.format("%.2f", kotlin.math.abs(s.stressedPnl))}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isProfit) RhinoEmerald else RhinoCrimson,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(s.description, style = MaterialTheme.typography.bodySmall, color = RhinoTextSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Residual Delta: ${String.format("%.3f", s.residualDelta)} | Stressed Mark: $${String.format("%.2f", s.stressedValue)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = RhinoTextTertiary,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }

        // 3. Monte Carlo VaR & Expected Shortfall
        if (mcRisk != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "MONTE CARLO VALUE AT RISK & TAIL RISK (1-DAY 99% HORIZON)",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        RiskBox("1D VaR 95%", "$${String.format("%.2f", mcRisk.var95)}", RhinoAmber, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        RiskBox("1D VaR 99%", "$${String.format("%.2f", mcRisk.var99)}", RhinoCrimson, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        RiskBox("EXP. SHORTFALL (99%)", "$${String.format("%.2f", mcRisk.expectedShortfall99)}", RhinoCrimson, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        RiskBox("WORST TAIL LOSS", "$${String.format("%.2f", mcRisk.worstCaseLoss)}", RhinoCrimson, Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun RiskBox(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(RhinoCardBg, RoundedCornerShape(3.dp))
            .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(3.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, fontSize = 9.sp)
            Text(value, style = MaterialTheme.typography.labelMedium, color = valueColor, fontWeight = FontWeight.Bold)
        }
    }
}
