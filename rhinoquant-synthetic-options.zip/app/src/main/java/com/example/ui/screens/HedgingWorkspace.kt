package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.RiskStatus
import com.example.ui.RhinoQuantUiState
import com.example.ui.RhinoQuantViewModel
import com.example.ui.theme.*

@Composable
fun HedgingWorkspace(
    uiState: RhinoQuantUiState,
    viewModel: RhinoQuantViewModel,
    modifier: Modifier = Modifier
) {
    val hedge = uiState.hedgeRecommendation
    val margin = uiState.marginRequirements
    val liq = uiState.liquidityMetrics

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(10.dp)
            .testTag("hedging_workspace_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Delta Neutral Hedge Solver
        if (hedge != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "AUTOMATED HEDGE SOLVER (DELTA NEUTRAL REBALANCING)",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HedgeCard("RECOMMENDED ACTION", "${hedge.recommendedSide} ${String.format("%.2f", hedge.recommendedQuantity)} units", RhinoCyan, Modifier.weight(1.3f))
                        Spacer(modifier = Modifier.width(6.dp))
                        HedgeCard("INSTRUMENT", hedge.recommendedInstrument.instrumentId, RhinoTextPrimary, Modifier.weight(1.3f))
                        Spacer(modifier = Modifier.width(6.dp))
                        HedgeCard("POST-HEDGE DELTA", String.format("%.4f", hedge.postHedgeDelta), RhinoEmerald, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        HedgeCard("POST-HEDGE VEGA", String.format("%.2f", hedge.postHedgeVega), VegaColor, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RhinoCardBg, RoundedCornerShape(3.dp))
                            .padding(6.dp)
                    ) {
                        Text(
                            text = hedge.executionNotes,
                            style = MaterialTheme.typography.bodySmall,
                            color = RhinoTextSecondary
                        )
                    }
                }
            }
        }

        // 2. SPAN & Portfolio Margin
        if (margin != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PORTFOLIO MARGIN REQUIREMENTS (SPAN SIMULATION)",
                            style = MaterialTheme.typography.labelSmall,
                            color = RhinoTextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .background(if (margin.marginStatus == RiskStatus.GREEN) RhinoEmeraldMuted else RhinoCrimsonMuted, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "UTILIZATION: ${String.format("%.1f", margin.marginUtilizationPercent)}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (margin.marginStatus == RiskStatus.GREEN) RhinoEmerald else RhinoCrimson,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HedgeCard("INITIAL MARGIN", "$${String.format("%.2f", margin.initialMargin)}", RhinoTextPrimary, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        HedgeCard("MAINTENANCE MARGIN", "$${String.format("%.2f", margin.maintenanceMargin)}", RhinoTextPrimary, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        HedgeCard("CROSS-LEG OFFSET BENEFIT", "$${String.format("%.2f", margin.netOffsetBenefit)}", RhinoEmerald, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        HedgeCard("MAX SCANNING LOSS", "$${String.format("%.2f", margin.spanMaxScanningLoss)}", RhinoAmber, Modifier.weight(1f))
                    }
                }
            }
        }

        // 3. Liquidity, Market Impact, and Legging Risk
        if (liq != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "LIQUIDITY PROFILE & PACKAGE EXECUTION ANALYTICS",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HedgeCard("LIQUIDITY SCORE", "${liq.strategyLiquidityScore} / 100", RhinoCyan, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        HedgeCard("EST. SLIPPAGE", "$${String.format("%.2f", liq.estimatedSlippage)}", RhinoAmber, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        HedgeCard("MARKET IMPACT", "${String.format("%.1f", liq.estimatedMarketImpactBps)} bps", RhinoTextSecondary, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RhinoCardBg, RoundedCornerShape(3.dp))
                            .padding(6.dp)
                    ) {
                        Column {
                            Text(liq.leggingRiskWarning, style = MaterialTheme.typography.bodySmall, color = RhinoCrimson)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(liq.packageExecutionAdvantage, style = MaterialTheme.typography.bodySmall, color = RhinoEmerald)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HedgeCard(title: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(RhinoCardBg, RoundedCornerShape(2.dp))
            .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(2.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(title, style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, fontSize = 8.5.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.labelSmall, color = valueColor, fontWeight = FontWeight.Bold)
        }
    }
}
