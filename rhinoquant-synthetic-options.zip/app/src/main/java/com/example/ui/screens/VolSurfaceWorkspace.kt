package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoQuantUiState
import com.example.ui.theme.*

@Composable
fun VolSurfaceWorkspace(
    uiState: RhinoQuantUiState,
    modifier: Modifier = Modifier
) {
    val surface = uiState.selectedUnderlying.surface
    val skewList = uiState.skewMetrics

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(10.dp)
            .testTag("vol_surface_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Skew & Smile Metrics (25-Delta Risk Reversal & Butterfly)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "VOLATILITY SKEW & TERM STRUCTURE METRICS",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoCardBg)
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TENOR", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(1.0f))
                    Text("ATM VOL", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(1.2f))
                    Text("25D CALL", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(1.2f))
                    Text("25D PUT", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(1.2f))
                    Text("25D RR", style = MaterialTheme.typography.labelSmall, color = RhinoCyan, modifier = Modifier.weight(1.2f))
                    Text("25D BF", style = MaterialTheme.typography.labelSmall, color = RhinoPurple, modifier = Modifier.weight(1.2f))
                }

                skewList.forEach { m ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${m.expiryDays.toInt()}D", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, modifier = Modifier.weight(1.0f))
                        Text("${String.format("%.1f", m.atmVol * 100)}%", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, modifier = Modifier.weight(1.2f))
                        Text("${String.format("%.1f", m.call25DeltaVol * 100)}%", style = MaterialTheme.typography.labelSmall, color = RhinoTextSecondary, modifier = Modifier.weight(1.2f))
                        Text("${String.format("%.1f", m.put25DeltaVol * 100)}%", style = MaterialTheme.typography.labelSmall, color = RhinoTextSecondary, modifier = Modifier.weight(1.2f))
                        Text("${String.format("%+.2f", m.riskReversal25D * 100)}%", style = MaterialTheme.typography.labelSmall, color = RhinoCyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                        Text("${String.format("%+.2f", m.butterfly25D * 100)}%", style = MaterialTheme.typography.labelSmall, color = RhinoPurple, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                    }
                }
            }
        }

        // 2. Authoritative Volatility Matrix (Strikes vs Tenors)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "IMPLIED VOLATILITY MATRIX (STRIKE x TENOR)",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                val spot = uiState.selectedUnderlying.spotPrice
                val step = spot * 0.03
                val strikes = listOf(spot * 0.88, spot * 0.94, spot * 1.00, spot * 1.06, spot * 1.12)
                val expiries = listOf(30.0, 60.0, 90.0, 180.0, 365.0)

                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoCardBg)
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("STRIKE", style = MaterialTheme.typography.labelSmall, color = RhinoAmber, modifier = Modifier.weight(1.2f))
                    expiries.forEach { exp ->
                        Text("${exp.toInt()}D", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(1f))
                    }
                }

                strikes.forEach { K ->
                    val isAtm = kotlin.math.abs(K - spot) < spot * 0.02
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${K.toInt()}${if (isAtm) " [ATM]" else ""}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isAtm) RhinoAmber else RhinoTextPrimary,
                            fontWeight = if (isAtm) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.weight(1.2f)
                        )

                        expiries.forEach { exp ->
                            val iv = surface.getVolatility(K, exp)
                            val volColor = when {
                                iv > 0.28 -> RhinoCrimson
                                iv > 0.22 -> RhinoAmber
                                else -> RhinoCyan
                            }
                            Text(
                                text = "${String.format("%.1f", iv * 100)}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = volColor,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // 3. SVI Model Calibration Parameters
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "SVI (STOCHASTIC VOLATILITY INSPIRED) CALIBRATION PARAMETERS",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Total Variance: w(k) = a + b * [ρ*(k - m) + √((k - m)² + σ²)]",
                    style = MaterialTheme.typography.bodySmall,
                    color = RhinoTextTertiary
                )
                Spacer(modifier = Modifier.height(6.dp))

                surface.sviCalibrations.forEach { (exp, svi) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${exp.toInt()}D:", style = MaterialTheme.typography.labelSmall, color = RhinoCyan, modifier = Modifier.weight(0.8f))
                        Text("a=${String.format("%.4f", svi.a)}", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, modifier = Modifier.weight(1f))
                        Text("b=${String.format("%.3f", svi.b)}", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, modifier = Modifier.weight(1f))
                        Text("ρ=${String.format("%.2f", svi.rho)}", style = MaterialTheme.typography.labelSmall, color = RhinoAmber, modifier = Modifier.weight(1f))
                        Text("m=${String.format("%.3f", svi.m)}", style = MaterialTheme.typography.labelSmall, color = RhinoTextSecondary, modifier = Modifier.weight(1f))
                        Text("σ=${String.format("%.3f", svi.sigma)}", style = MaterialTheme.typography.labelSmall, color = RhinoTextSecondary, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
