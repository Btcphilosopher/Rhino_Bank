package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoQuantUiState
import com.example.ui.RhinoQuantViewModel
import com.example.ui.theme.*

@Composable
fun ResearchAndAuditWorkspace(
    uiState: RhinoQuantUiState,
    viewModel: RhinoQuantViewModel,
    modifier: Modifier = Modifier
) {
    val memo = uiState.generatedMemo
    val audit = uiState.auditEvents
    val tickets = uiState.tradeTickets

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(10.dp)
            .testTag("research_and_audit_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Research Note Generator Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "QUANTITATIVE RESEARCH MEMORANDUM",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = { viewModel.generateResearchMemo() },
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoCyan),
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("REFRESH MEMO", style = MaterialTheme.typography.labelSmall, color = RhinoBgDark, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (memo.isBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Click 'REFRESH MEMO' to synthesize analytical research note for active strategy.", style = MaterialTheme.typography.bodySmall, color = RhinoTextTertiary)
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RhinoBgDark, RoundedCornerShape(3.dp))
                            .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(3.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = memo,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = JetBrainsMono,
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            ),
                            color = RhinoTextPrimary
                        )
                    }
                }
            }
        }

        // 2. Pre-Trade Tickets Log
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "PRE-TRADE TICKETS LOG (${tickets.size})",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                if (tickets.isEmpty()) {
                    Text("No trade tickets submitted in this session.", style = MaterialTheme.typography.bodySmall, color = RhinoTextTertiary)
                } else {
                    tickets.forEach { t ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(RhinoCardBg, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(t.ticketId, style = MaterialTheme.typography.labelSmall, color = RhinoCyan, fontWeight = FontWeight.Bold)
                            Text(t.strategyName, style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary)
                            Text("${t.legsCount} legs", style = MaterialTheme.typography.labelSmall, color = RhinoTextSecondary)
                            Text("Notional: $${String.format("%.0f", t.totalNotional)}", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary)
                            Text(t.limitCheckStatus.name, style = MaterialTheme.typography.labelSmall, color = RhinoEmerald, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 3. Immutable Audit Trail Table
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "IMMUTABLE AUDIT TRAIL LOG",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                audit.forEach { ev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(ev.formattedTime, style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(1f))
                        Text(ev.action, style = MaterialTheme.typography.labelSmall, color = RhinoCyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                        Text(ev.details, style = MaterialTheme.typography.bodySmall, color = RhinoTextSecondary, modifier = Modifier.weight(3f))
                    }
                }
            }
        }
    }
}
