package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.domain.synthetics.StrategyLibrary
import com.example.ui.RhinoQuantUiState
import com.example.ui.RhinoQuantViewModel
import com.example.ui.components.PayoffCanvas
import com.example.ui.theme.*

@Composable
fun WorkbenchWorkspace(
    uiState: RhinoQuantUiState,
    viewModel: RhinoQuantViewModel,
    modifier: Modifier = Modifier
) {
    val spot = uiState.selectedUnderlying.spotPrice
    val decomp = uiState.decomposition
    var showAddDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(10.dp)
            .testTag("workbench_workspace_scroll"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Institutional Strategy Templates Bar
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "INSTITUTIONAL STRATEGY TEMPLATES",
                    style = MaterialTheme.typography.labelSmall,
                    color = RhinoTextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StrategyLibrary.templates.forEach { tmpl ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(RhinoCardBg)
                                .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(3.dp))
                                .clickable { viewModel.loadTemplate(tmpl.id) }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                                .testTag("template_${tmpl.id}")
                        ) {
                            Text(
                                text = tmpl.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = RhinoCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // 2. Synthetic Decomposition & Mathematical Equivalence Card
        if (decomp != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("synthetic_decomposition_card"),
                    colors = CardDefaults.cardColors(containerColor = RhinoSurfaceDark),
                    shape = RoundedCornerShape(4.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(RhinoBorder))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(RhinoCyan)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SYNTHETIC DECOMPOSITION: ${decomp.strategyName}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = RhinoTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (decomp.impliedFinancingRate != null) {
                                Box(
                                    modifier = Modifier
                                        .background(RhinoAmberMuted, RoundedCornerShape(3.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "FINANCING: ${String.format("%.2f", decomp.impliedFinancingRate * 100)}% p.a.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RhinoAmber,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = decomp.replicationDescription,
                            style = MaterialTheme.typography.bodyMedium,
                            color = RhinoTextSecondary
                        )

                        if (decomp.putCallParityDislocation != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "PARITY DISLOCATION: $${String.format("%.4f", decomp.putCallParityDislocation)} against Spot $${String.format("%.2f", spot)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (kotlin.math.abs(decomp.putCallParityDislocation) < 0.25) RhinoEmerald else RhinoCrimson
                            )
                        }
                    }
                }
            }
        }

        // 3. Position Legs Table
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CONSTITUENT PORTFOLIO LEGS (${uiState.activeLegs.size})",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Row {
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = RhinoBlue),
                            shape = RoundedCornerShape(3.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier
                                .height(26.dp)
                                .testTag("add_leg_button")
                        ) {
                            Text("+ ADD LEG", style = MaterialTheme.typography.labelSmall, color = Color.White)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        OutlinedButton(
                            onClick = { viewModel.clearLegs() },
                            shape = RoundedCornerShape(3.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier
                                .height(26.dp)
                                .testTag("clear_legs_button")
                        ) {
                            Text("CLEAR", style = MaterialTheme.typography.labelSmall, color = RhinoCrimson)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (uiState.activeLegs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No active portfolio legs. Load a template or click '+ ADD LEG'.",
                            style = MaterialTheme.typography.bodySmall,
                            color = RhinoTextTertiary
                        )
                    }
                } else {
                    // Header row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RhinoCardBg)
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("SIDE", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(0.9f))
                        Text("QTY", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(0.7f))
                        Text("INSTRUMENT", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(2.0f))
                        Text("STRIKE", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(1.0f))
                        Text("PRICE", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(1.0f))
                        Text("DEL", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(0.8f))
                        Text("ACT", style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, modifier = Modifier.weight(0.7f))
                    }

                    uiState.activeLegs.forEach { leg ->
                        val inst = leg.instrument
                        val isOption = inst is OptionInstrument
                        val strikeStr = if (isOption) "$${(inst as OptionInstrument).strike.toInt()}" else "SPOT"
                        val deltaStr = if (isOption) String.format("%.2f", (inst as OptionInstrument).delta) else "1.00"

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Side toggle
                            Box(
                                modifier = Modifier
                                    .weight(0.9f)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (leg.side == Side.BUY) RhinoEmeraldMuted else RhinoCrimsonMuted)
                                    .clickable {
                                        val newSide = if (leg.side == Side.BUY) Side.SELL else Side.BUY
                                        viewModel.updateLegSide(leg.id, newSide)
                                    }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = leg.side.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (leg.side == Side.BUY) RhinoEmerald else RhinoCrimson,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text("${leg.quantity.toInt()}x", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, modifier = Modifier.weight(0.7f))
                            Text(inst.instrumentId, style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, modifier = Modifier.weight(2.0f))
                            Text(strikeStr, style = MaterialTheme.typography.labelSmall, color = RhinoCyan, modifier = Modifier.weight(1.0f))
                            Text("$${String.format("%.2f", leg.effectivePrice)}", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary, modifier = Modifier.weight(1.0f))
                            Text(deltaStr, style = MaterialTheme.typography.labelSmall, color = RhinoTextSecondary, modifier = Modifier.weight(0.8f))

                            // Delete button
                            IconButton(
                                onClick = { viewModel.removeLeg(leg.id) },
                                modifier = Modifier
                                    .size(20.dp)
                                    .weight(0.7f)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Remove Leg", tint = RhinoCrimson, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }

        // 4. Portfolio Greeks Grid
        if (decomp != null) {
            val g = decomp.greeks
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "AGGREGATE PORTFOLIO GREEKS & SENSITIVITIES",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GreekBox("NET DELTA (Δ)", String.format("%+8.3f", g.netDelta), DeltaColor, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        GreekBox("NET GAMMA (Γ)", String.format("%+8.5f", g.netGamma), GammaColor, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        GreekBox("NET VEGA (V)", String.format("%+8.2f", g.netVega), VegaColor, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        GreekBox("THETA / DAY", String.format("%+8.2f", g.netTheta), ThetaColor, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GreekBox("RHO (100bps)", String.format("%+8.2f", g.netRho), RhoColor, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        GreekBox("VANNA", String.format("%+8.4f", g.netVanna), RhinoCyan, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        GreekBox("VOLGA", String.format("%+8.4f", g.netVolga), RhinoPurple, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        GreekBox("CHARM / DAY", String.format("%+8.4f", g.netCharm), RhinoTextSecondary, Modifier.weight(1f))
                    }
                }
            }
        }

        // 5. Payoff Canvas
        if (decomp != null) {
            item {
                PayoffCanvas(
                    analysis = decomp.payoff,
                    currentSpot = spot
                )
            }
        }

        // 6. Action Execution Toolbar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.createTradeTicket() },
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoCyan),
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("create_ticket_action_btn")
                ) {
                    Text("TRADE TICKET", style = MaterialTheme.typography.labelSmall, color = RhinoBgDark, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        val spotInst = SpotInstrument("HEDGE_UNDERLYING", uiState.selectedUnderlying.assetClass, uiState.selectedUnderlying.symbol, marketPrice = spot, bid = spot - 0.25, ask = spot + 0.25)
                        val rec = com.example.domain.risk.HedgingEngine.computeHedge(uiState.activeLegs, spot, uiState.selectedUnderlying.riskFreeRate, uiState.selectedUnderlying.dividendYieldOrCarry, spotInst, "DELTA")
                        viewModel.addLeg(rec.recommendedSide, OptionType.CALL, spot, rec.recommendedQuantity)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoCardBg),
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, RhinoBorder, RoundedCornerShape(3.dp))
                        .testTag("delta_hedge_action_btn")
                ) {
                    Text("DELTA HEDGE", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary)
                }

                Button(
                    onClick = { viewModel.generateResearchMemo() },
                    colors = ButtonDefaults.buttonColors(containerColor = RhinoCardBg),
                    shape = RoundedCornerShape(3.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, RhinoBorder, RoundedCornerShape(3.dp))
                        .testTag("research_memo_action_btn")
                ) {
                    Text("GENERATE MEMO", style = MaterialTheme.typography.labelSmall, color = RhinoTextPrimary)
                }
            }
        }
    }

    // Add Leg Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Leg to Synthetic Strategy", color = RhinoTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Select instrument parameters for ${uiState.selectedUnderlying.symbol}:", style = MaterialTheme.typography.bodySmall, color = RhinoTextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { viewModel.addLeg(Side.BUY, OptionType.CALL, spot); showAddDialog = false }) {
                            Text("BUY CALL (ATM)")
                        }
                        Button(onClick = { viewModel.addLeg(Side.SELL, OptionType.PUT, spot); showAddDialog = false }) {
                            Text("SELL PUT (ATM)")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { viewModel.addLeg(Side.BUY, OptionType.PUT, spot * 0.95); showAddDialog = false }) {
                            Text("BUY OTM PUT")
                        }
                        Button(onClick = { viewModel.addLeg(Side.SELL, OptionType.CALL, spot * 1.05); showAddDialog = false }) {
                            Text("SELL OTM CALL")
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("CANCEL", color = RhinoTextSecondary)
                }
            },
            containerColor = RhinoSurfaceDark
        )
    }
}

@Composable
private fun GreekBox(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(RhinoCardBg, RoundedCornerShape(2.dp))
            .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(2.dp))
            .padding(vertical = 4.dp, horizontal = 6.dp)
    ) {
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, fontSize = 9.sp)
            Text(value, style = MaterialTheme.typography.labelMedium, color = valueColor, fontWeight = FontWeight.Bold)
        }
    }
}
