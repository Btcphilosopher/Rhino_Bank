package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoQuantUiState
import com.example.ui.RhinoQuantViewModel
import com.example.ui.theme.*

@Composable
fun ArbitrageWorkspace(
    uiState: RhinoQuantUiState,
    viewModel: RhinoQuantViewModel,
    modifier: Modifier = Modifier
) {
    val parity = uiState.parityCheck
    val box = uiState.boxAnalysis
    val fwd = uiState.forwardAnalysis

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RhinoBgDark)
            .padding(10.dp)
            .testTag("arbitrage_workspace_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Put-Call Parity Consistency Detector
        if (parity != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PUT-CALL PARITY CONSISTENCY: C - P = S*e^(-qT) - K*e^(-rT)",
                            style = MaterialTheme.typography.labelSmall,
                            color = RhinoTextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .background(if (parity.isArbitrageViable) RhinoEmeraldMuted else RhinoSurfaceVariant, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (parity.isArbitrageViable) "ARBITRAGE OPPORTUNITY" else "ARBITRAGE-FREE",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (parity.isArbitrageViable) RhinoEmerald else RhinoTextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricCell("THEORETICAL DIFF", "$${String.format("%.3f", parity.theoreticalDiff)}", RhinoTextPrimary, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("MARKET MID DIFF", "$${String.format("%.3f", parity.marketMidDiff)}", RhinoCyan, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("GROSS DISLOCATION", "$${String.format("%.3f", parity.grossDislocation)}", RhinoAmber, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("BID/ASK FRICTION", "$${String.format("%.3f", parity.transactionCost)}", RhinoTextTertiary, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RhinoCardBg, RoundedCornerShape(3.dp))
                            .padding(6.dp)
                    ) {
                        Text(
                            text = parity.tradeRecommendation,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (parity.isArbitrageViable) RhinoEmerald else RhinoTextSecondary
                        )
                    }
                }
            }
        }

        // 2. Box Spread Synthetic Financing Engine
        if (box != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "BOX SPREAD SYNTHETIC FINANCING & SOFR BENCHMARK",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricCell("TERMINAL PAYOFF", "$${String.format("%.2f", box.payoffAtExpiry)}", RhinoTextPrimary, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("MARKET DEBIT", "$${String.format("%.2f", box.boxMarketCost)}", RhinoTextPrimary, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("IMPLIED RATE", "${String.format("%.2f", box.impliedBorrowRate * 100)}%", RhinoCyan, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("SOFR BENCHMARK", "${String.format("%.2f", box.benchmarkSofrRate * 100)}%", RhinoTextTertiary, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricCell("SPREAD VS SOFR", "${String.format("%+.0f", box.spreadVsSofrBps)} bps", if (box.spreadVsSofrBps < 0) RhinoEmerald else RhinoAmber, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("EST. ANNUAL SAVINGS", "$${String.format("%.2f", box.annualSavingsVsBankBorrowing)}", RhinoEmerald, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RhinoCardBg, RoundedCornerShape(3.dp))
                            .padding(6.dp)
                    ) {
                        Text(
                            text = box.arbitrageAssessment,
                            style = MaterialTheme.typography.bodySmall,
                            color = RhinoTextSecondary
                        )
                    }
                }
            }
        }

        // 3. Synthetic Forward vs Futures Basis Analyzer
        if (fwd != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RhinoSurfaceDark, RoundedCornerShape(4.dp))
                        .border(1.dp, RhinoBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "SYNTHETIC FORWARD VS FUTURES BASIS DISLOCATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = RhinoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricCell("SYNTHETIC FWD", "$${String.format("%.2f", fwd.syntheticForward)}", RhinoCyan, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("OBSERVED FUTURES", "$${String.format("%.2f", fwd.observedFutures)}", RhinoTextPrimary, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("THEORETICAL FWD", "$${String.format("%.2f", fwd.theoreticalForward)}", RhinoTextTertiary, Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        MetricCell("NET BASIS DISLOC", "$${String.format("%.3f", fwd.netDislocation)}", RhinoAmber, Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCell(title: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(RhinoCardBg, RoundedCornerShape(2.dp))
            .border(1.dp, RhinoBorderSubtle, RoundedCornerShape(2.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(title, style = MaterialTheme.typography.labelSmall, color = RhinoTextTertiary, fontSize = 8.5.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.labelSmall, color = valueColor, fontWeight = FontWeight.Bold)
        }
    }
}
