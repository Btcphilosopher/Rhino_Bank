package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.arbitrage.*
import com.example.domain.marketdata.*
import com.example.domain.model.*
import com.example.domain.pricing.*
import com.example.domain.risk.*
import com.example.domain.rqql.*
import com.example.domain.synthetics.*
import com.example.domain.volatility.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class TerminalWorkspace(val title: String, val iconLabel: String) {
    WORKBENCH("Workbench", "SYNTH"),
    CHAIN("Option Chain", "CHAIN"),
    SURFACE("Vol Surface", "SURF"),
    PRICING("Pricing Models", "MATH"),
    SCENARIO("Scenario Cube", "SCEN"),
    ARBITRAGE("Arbitrage & Box", "ARB"),
    HEDGING("Hedging & Margin", "HEDGE"),
    RQQL("RQQL Console", "RQQL"),
    RESEARCH("Research & Audit", "MEMO")
}

data class RhinoQuantUiState(
    val currentWorkspace: TerminalWorkspace = TerminalWorkspace.WORKBENCH,
    val selectedUnderlying: UnderlyingMarketSnapshot = MarketDataEngine.underlyings.first(),
    val selectedExpiryDays: Double = 90.0,
    val activeLegs: List<PositionLeg> = emptyList(),
    val decomposition: SyntheticDecomposition? = null,
    val optionChain: List<OptionChainRow> = emptyList(),
    val dataQuality: DataQualityReport? = null,
    val skewMetrics: List<SurfaceSkewMetrics> = emptyList(),
    val scenarioGrid: List<ScenarioCell> = emptyList(),
    val stressResults: List<StressTestResult> = emptyList(),
    val monteCarloRisk: MonteCarloRiskReport? = null,
    val parityCheck: PutCallParityCheck? = null,
    val boxAnalysis: BoxFinancingAnalysis? = null,
    val forwardAnalysis: SyntheticForwardAnalysis? = null,
    val hedgeRecommendation: HedgeRecommendation? = null,
    val marginRequirements: MarginRequirements? = null,
    val liquidityMetrics: LiquidityMetrics? = null,
    val rqqlHistory: List<Pair<String, RqqlResult>> = emptyList(),
    val auditEvents: List<AuditEvent> = emptyList(),
    val tradeTickets: List<TradeTicket> = emptyList(),
    val generatedMemo: String = "",
    val pricingModelSelection: String = "BLACK_SCHOLES",
    val binomialAmericanResult: BinomialResult? = null,
    val monteCarloPricingResult: MonteCarloResult? = null,
    val isDarkTheme: Boolean = true,
    val isBusyCalculating: Boolean = false
)

class RhinoQuantViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(RhinoQuantUiState())
    val uiState: StateFlow<RhinoQuantUiState> = _uiState.asStateFlow()

    private val governanceRecord = ModelGovernanceRecord(
        modelName = "Black-Scholes-Merton & SVI Analytical Engine",
        modelVersion = "3.8.4-RELEASE",
        marketDataSnapshotId = "SNAP_20261011_INDEX_DERIV"
    )

    init {
        // Initialize with default template: Synthetic Long Forward on SPX
        val defaultSnapshot = MarketDataEngine.underlyings.first()
        val defaultTemplate = StrategyLibrary.templates.first()
        val initialLegs = defaultTemplate.legGenerator(defaultSnapshot.spotPrice, 90.0, 0.18)

        _uiState.update {
            it.copy(
                selectedUnderlying = defaultSnapshot,
                selectedExpiryDays = 90.0,
                activeLegs = initialLegs
            )
        }

        recalculateAll(initialLegs, defaultSnapshot, 90.0)
        logAuditEvent("SYSTEM_STARTUP", "RhinoQuant Synthetic Options engine initialized. Connected to SNAP_20261011.")
    }

    fun setWorkspace(workspace: TerminalWorkspace) {
        _uiState.update { it.copy(currentWorkspace = workspace) }
    }

    fun toggleTheme() {
        _uiState.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    fun selectUnderlying(symbol: String) {
        val snapshot = MarketDataEngine.underlyings.find { it.symbol == symbol } ?: return
        val currentExpiry = _uiState.value.selectedExpiryDays
        val currentLegs = _uiState.value.activeLegs

        // Re-anchor legs to new underlying spot if needed
        _uiState.update { it.copy(selectedUnderlying = snapshot) }
        recalculateAll(currentLegs, snapshot, currentExpiry)
        logAuditEvent("SELECT_UNDERLYING", "Switched active research book to ${snapshot.symbol} (${snapshot.name}).")
    }

    fun selectExpiry(expiryDays: Double) {
        _uiState.update { it.copy(selectedExpiryDays = expiryDays) }
        recalculateAll(_uiState.value.activeLegs, _uiState.value.selectedUnderlying, expiryDays)
        logAuditEvent("SELECT_EXPIRY", "Shifted curve tenor to ${expiryDays.toInt()} Days.")
    }

    fun loadTemplate(templateId: String) {
        val template = StrategyLibrary.templates.find { it.id == templateId } ?: return
        val snapshot = _uiState.value.selectedUnderlying
        val expiry = _uiState.value.selectedExpiryDays
        val atmVol = snapshot.surface.getVolatility(snapshot.spotPrice, expiry)

        val newLegs = template.legGenerator(snapshot.spotPrice, expiry, atmVol)
        _uiState.update { it.copy(activeLegs = newLegs) }
        recalculateAll(newLegs, snapshot, expiry)
        logAuditEvent("LOAD_TEMPLATE", "Loaded strategy template: ${template.name} (${newLegs.size} legs).")
    }

    fun addLeg(side: Side, type: OptionType, strike: Double, qty: Double = 1.0) {
        val snapshot = _uiState.value.selectedUnderlying
        val expiry = _uiState.value.selectedExpiryDays
        val iv = snapshot.surface.getVolatility(strike, expiry)
        val pr = BlackScholes.priceAndGreeks(snapshot.spotPrice, strike, expiry / 365.0, snapshot.riskFreeRate, snapshot.dividendYieldOrCarry, iv, type)

        val newLeg = PositionLeg(
            id = "leg-${UUID.randomUUID().toString().take(6)}",
            side = side,
            quantity = qty,
            instrument = OptionInstrument(
                instrumentId = "${snapshot.symbol}_${type.name.first()}_${strike.toInt()}_${expiry.toInt()}D",
                assetClass = snapshot.assetClass,
                underlying = snapshot.symbol,
                marketPrice = pr.price,
                bid = pr.price * 0.99,
                ask = pr.price * 1.01,
                optionType = type,
                strike = strike,
                expiryDays = expiry,
                impliedVolatility = iv,
                delta = pr.delta,
                gamma = pr.gamma,
                theta = pr.theta,
                vega = pr.vega
            )
        )

        val updatedLegs = _uiState.value.activeLegs + newLeg
        _uiState.update { it.copy(activeLegs = updatedLegs) }
        recalculateAll(updatedLegs, snapshot, expiry)
        logAuditEvent("ADD_LEG", "Added leg: $side $qty x $type K=$strike.")
    }

    fun removeLeg(legId: String) {
        val updated = _uiState.value.activeLegs.filterNot { it.id == legId }
        _uiState.update { it.copy(activeLegs = updated) }
        recalculateAll(updated, _uiState.value.selectedUnderlying, _uiState.value.selectedExpiryDays)
        logAuditEvent("REMOVE_LEG", "Removed leg $legId.")
    }

    fun clearLegs() {
        _uiState.update { it.copy(activeLegs = emptyList()) }
        recalculateAll(emptyList(), _uiState.value.selectedUnderlying, _uiState.value.selectedExpiryDays)
        logAuditEvent("CLEAR_PORTFOLIO", "Cleared all active portfolio positions.")
    }

    fun updateLegSide(legId: String, newSide: Side) {
        val updated = _uiState.value.activeLegs.map {
            if (it.id == legId) it.copy(side = newSide) else it
        }
        _uiState.update { it.copy(activeLegs = updated) }
        recalculateAll(updated, _uiState.value.selectedUnderlying, _uiState.value.selectedExpiryDays)
        logAuditEvent("UPDATE_LEG_SIDE", "Swapped leg $legId side to $newSide.")
    }

    fun executeRqqlCommand(cmdText: String) {
        if (cmdText.isBlank()) return
        val currentLegs = _uiState.value.activeLegs
        val snapshot = _uiState.value.selectedUnderlying
        val atmVol = snapshot.surface.getVolatility(snapshot.spotPrice, _uiState.value.selectedExpiryDays)

        val result = RqqlEngine.execute(
            input = cmdText,
            currentLegs = currentLegs,
            currentSpot = snapshot.spotPrice,
            rate = snapshot.riskFreeRate,
            divYield = snapshot.dividendYieldOrCarry,
            atmVol = atmVol
        )

        val newHistory = _uiState.value.rqqlHistory + (cmdText to result)
        _uiState.update { it.copy(rqqlHistory = newHistory) }

        if (result.isSuccess && result.generatedLegs != null) {
            _uiState.update { it.copy(activeLegs = result.generatedLegs) }
            recalculateAll(result.generatedLegs, snapshot, _uiState.value.selectedExpiryDays)
        }

        logAuditEvent("EXECUTE_RQQL", "Executed RQQL command: '$cmdText' -> ${result.outputTitle}.")
    }

    fun runMonteCarloSimulation() {
        val snapshot = _uiState.value.selectedUnderlying
        val legs = _uiState.value.activeLegs
        val spot = snapshot.spotPrice
        val rate = snapshot.riskFreeRate
        val carry = snapshot.dividendYieldOrCarry
        val expiry = _uiState.value.selectedExpiryDays

        val atmVol = snapshot.surface.getVolatility(spot, expiry)
        val mcPricing = MonteCarloEngine.simulate(
            S0 = spot,
            K = spot,
            T = expiry / 365.0,
            r = rate,
            q = carry,
            sigma = atmVol,
            type = OptionType.CALL,
            numPaths = 20_000
        )

        val mcRisk = ScenarioEngine.simulateMonteCarloRisk(
            legs = legs,
            baseSpot = spot,
            baseRate = rate,
            baseDivYield = carry
        )

        _uiState.update {
            it.copy(
                monteCarloPricingResult = mcPricing,
                monteCarloRisk = mcRisk
            )
        }
        logAuditEvent("MONTE_CARLO", "Executed 20,000 paths antithetic Monte Carlo simulation.")
    }

    fun generateResearchMemo() {
        val state = _uiState.value
        val decomp = state.decomposition ?: return
        val memo = ResearchNoteGenerator.generateNote(
            strategyName = decomp.strategyName,
            underlying = state.selectedUnderlying.symbol,
            spot = state.selectedUnderlying.spotPrice,
            greeks = decomp.greeks,
            margin = state.marginRequirements ?: MarginRequirements(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, RiskStatus.GREEN),
            governance = governanceRecord,
            breakEvens = decomp.payoff.breakEvenPoints,
            syntheticReplication = decomp.replicationDescription
        )
        _uiState.update { it.copy(generatedMemo = memo) }
        logAuditEvent("GENERATE_RESEARCH_NOTE", "Generated quantitative research memorandum.")
    }

    fun createTradeTicket(): TradeTicket {
        val state = _uiState.value
        val decomp = state.decomposition
        val margin = state.marginRequirements
        val notional = decomp?.greeks?.totalNotional ?: 0.0

        val ticket = TradeTicket(
            ticketId = "TKT-${UUID.randomUUID().toString().take(8).uppercase()}",
            strategyName = decomp?.strategyName ?: "CUSTOM_POSITION",
            underlying = state.selectedUnderlying.symbol,
            legsCount = state.activeLegs.size,
            netCreditDebit = decomp?.greeks?.netPrice ?: 0.0,
            totalNotional = notional,
            initialMarginRequired = margin?.initialMargin ?: 0.0,
            limitCheckStatus = if (notional > 25_000_000) RiskStatus.AMBER else RiskStatus.GREEN
        )

        _uiState.update { it.copy(tradeTickets = it.tradeTickets + ticket) }
        logAuditEvent("CREATE_TRADE_TICKET", "Created pre-trade ticket ${ticket.ticketId} with status ${ticket.limitCheckStatus}.")
        return ticket
    }

    private fun recalculateAll(
        legs: List<PositionLeg>,
        snapshot: UnderlyingMarketSnapshot,
        expiryDays: Double
    ) {
        val spot = snapshot.spotPrice
        val rate = snapshot.riskFreeRate
        val carry = snapshot.dividendYieldOrCarry

        // 1. Synthetic Decomposition & Payoff
        val decomp = SyntheticInstrumentEngine.decomposePortfolio(legs, spot, rate, carry)

        // 2. Option Chain & Data Quality
        val chain = MarketDataEngine.getOptionChain(snapshot, expiryDays)
        val quality = MarketDataEngine.auditDataQuality(chain)

        // 3. Vol Surface Skew Metrics
        val skew = snapshot.surface.computeSkewMetrics()

        // 4. Scenario Grid & Stress Presets
        val grid = ScenarioEngine.evaluateScenarioGrid(legs, spot, rate, carry)
        val stress = ScenarioEngine.runStressPresets(legs, spot, rate, carry)

        // 5. Margin & Liquidity
        val margin = HedgingEngine.calculateMargin(legs, spot, rate, carry)
        val liquidity = HedgingEngine.evaluateLiquidity(legs, decomp.greeks.totalNotional)

        // 6. Hedge Recommendation (Delta neutral using Spot)
        val spotInst = SpotInstrument("${snapshot.symbol}_UNDERLYING", snapshot.assetClass, snapshot.symbol, marketPrice = spot, bid = snapshot.bid, ask = snapshot.ask)
        val hedge = HedgingEngine.computeHedge(legs, spot, rate, carry, spotInst, "DELTA")

        // 7. Arbitrage checks on ATM strike
        val atmRow = chain.minByOrNull { kotlin.math.abs(it.strike - spot) }
        val parity = if (atmRow != null) {
            ArbitrageEngine.checkPutCallParity(atmRow.call, atmRow.put, spot, rate, carry)
        } else null

        // 8. Box spread financing analysis
        val k1 = spot * 0.95
        val k2 = spot * 1.05
        val iv1 = snapshot.surface.getVolatility(k1, expiryDays)
        val iv2 = snapshot.surface.getVolatility(k2, expiryDays)
        val c1 = BlackScholes.price(spot, k1, expiryDays / 365.0, rate, carry, iv1, OptionType.CALL)
        val c2 = BlackScholes.price(spot, k2, expiryDays / 365.0, rate, carry, iv2, OptionType.CALL)
        val p1 = BlackScholes.price(spot, k1, expiryDays / 365.0, rate, carry, iv1, OptionType.PUT)
        val p2 = BlackScholes.price(spot, k2, expiryDays / 365.0, rate, carry, iv2, OptionType.PUT)
        val box = ArbitrageEngine.analyzeBoxSpread(k1, k2, expiryDays, c1, c2, p1, p2)

        // 9. Synthetic forward analysis
        val forward = if (atmRow != null) {
            val fwdObserved = spot * kotlin.math.exp((rate - carry) * (expiryDays / 365.0)) + 0.25
            ArbitrageEngine.analyzeSyntheticForward(spot, atmRow.strike, expiryDays, atmRow.call.marketPrice, atmRow.put.marketPrice, fwdObserved, rate, carry)
        } else null

        // 10. Binomial American vs European comparison
        val crr = BinomialCRR.price(spot, spot, expiryDays / 365.0, rate, carry, iv1, OptionType.PUT, ExerciseStyle.AMERICAN, 80)

        _uiState.update {
            it.copy(
                decomposition = decomp,
                optionChain = chain,
                dataQuality = quality,
                skewMetrics = skew,
                scenarioGrid = grid,
                stressResults = stress,
                marginRequirements = margin,
                liquidityMetrics = liquidity,
                hedgeRecommendation = hedge,
                parityCheck = parity,
                boxAnalysis = box,
                forwardAnalysis = forward,
                binomialAmericanResult = crr
            )
        }
    }

    private fun logAuditEvent(action: String, details: String) {
        val event = AuditEvent(
            eventId = "EVT-${UUID.randomUUID().toString().take(6)}",
            user = "RHINO_QUANT_TRADER",
            action = action,
            details = details
        )
        _uiState.update { it.copy(auditEvents = listOf(event) + it.auditEvents.take(50)) }
    }
}
