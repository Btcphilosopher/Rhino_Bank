# RhinoQuant User Guide & Operational Workflows

## 1. Navigating Workspaces
Use the top terminal navigation bar to switch workspaces:
1. **WORKBENCH**: Multi-leg synthetic strategy builder, live decomposition, Greeks grid, and vector payoff curve.
2. **OPTION CHAIN**: Full institutional dual-sided strike matrix with Calls, Puts, IV, Greeks, and data quality diagnostics. Click any quote to add directly to your strategy.
3. **VOL SURFACE**: Term structure, volatility skew, 25-Delta Risk Reversal, 25-Delta Butterfly, and SVI parameters.
4. **PRICING MODELS**: Interactive Black-Scholes, Black-76, Binomial American CRR, and 20,000-path Monte Carlo pricing comparison.
5. **SCENARIO CUBE**: 2D heat matrix of spot vs volatility shocks, stress testing presets, and Value at Risk (VaR).
6. **ARBITRAGE & BOX**: Put-call parity scanner, box spread synthetic borrowing rates vs SOFR, and forward basis dislocations.
7. **HEDGING & MARGIN**: Automated delta-neutral hedge rebalancer, SPAN portfolio margin, and package execution analytics.
8. **RQQL CONSOLE**: Command-line interface for rapid quantitative scripting and strategy execution.
9. **RESEARCH & AUDIT**: Formatted institutional quantitative research memorandum generation and immutable audit trail logs.

## 2. Typical Trading Desk Workflow
1. Select **Underlying** (e.g. `SPX`, `AAPL`, `NVDA`, `CL`, `EURUSD`) and **Tenor** (e.g. `90D`) from the header.
2. Under **WORKBENCH**, select a template like `Synthetic Long Forward` or click `+ ADD LEG`.
3. Inspect the live mathematical decomposition, net Greeks ($\Delta, \Gamma, \mathcal{V}, \Theta$), and payoff curve.
4. Click `DELTA HEDGE` to neutralize directional exposure.
5. Navigate to `SCENARIOS` to test portfolio behavior under market shocks (e.g. `VOL_SHOCK`).
6. Click `GENERATE MEMO` in the research workspace to export an institutional memorandum.
7. Click `TRADE TICKET` to generate a compliant pre-trade ticket.
