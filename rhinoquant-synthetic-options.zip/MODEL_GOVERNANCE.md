# Model Governance & Regulatory Auditability

## 1. Regulatory Context (SR 11-7 / OCC Guidelines)
Institutional financial systems require strict mathematical model governance:
- Every valuation must record the model version, calibration snapshot, solver status, and numerical tolerances.
- Price or volatility overrides must be stamped with immutable user IDs and timestamps.

## 2. RhinoQuant Governance Specification
Every model evaluation produces a `ModelGovernanceRecord`:
- **Model Name & Version**: e.g. `Black-Scholes-Merton & SVI Analytical Engine (v3.8.4-RELEASE)`.
- **Calibration Snapshot ID**: e.g. `SNAP_20261011_INDEX_DERIV`.
- **Numerical Tolerance**: Machine epsilon $10^{-6}$.
- **Solver Status**: `CONVERGED`, `MODEL_FAILED`, `NO_ARBITRAGE_SOLUTION`, or `OUTLIER`.
- **Authorized Desk**: `RHINO_QUANT_CORE_DESK`.

## 3. Immutable Audit Trail
Every trade ticket creation, leg edit, or override is appended to an immutable in-memory and database audit log.
