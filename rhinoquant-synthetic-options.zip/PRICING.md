# Quantitative Pricing Engine

## 1. Engine Architecture
The RhinoQuant pricing framework provides plug-in compatible pricing engines:
- `BlackScholes`: European options with continuous dividend yields.
- `Black76`: Options on futures, commodities, and forward underlyings.
- `BinomialCRR`: Cox-Ross-Rubinstein American lattice model.
- `MonteCarloEngine`: Path simulation for European, Asian, and Barrier options.

## 2. Benchmark Equations & Formulations
### Black-Scholes-Merton:
$$C = S e^{-q T} N(d_1) - K e^{-r T} N(d_2)$$
$$P = K e^{-r T} N(-d_2) - S e^{-q T} N(-d_1)$$

### Black-76:
$$C = e^{-r T} [F N(d_1) - K N(d_2)]$$
$$P = e^{-r T} [K N(-d_2) - F N(-d_1)]$$

### Binomial American Early Exercise Boundary:
At each node $(i, j)$:
$$V_{i,j} = \max\left(\text{Intrinsic}(S_{i,j}), e^{-r \Delta t} [p V_{i+1, j+1} + (1-p) V_{i+1, j}]\right)$$

### Monte Carlo Simulation:
Antithetic pair generation under risk-neutral measure:
$$S_{t+\Delta t}^{(1)} = S_t \exp\left((r - q - \frac{1}{2}\sigma^2)\Delta t + \sigma \sqrt{\Delta t} Z\right)$$
$$S_{t+\Delta t}^{(2)} = S_t \exp\left((r - q - \frac{1}{2}\sigma^2)\Delta t - \sigma \sqrt{\Delta t} Z\right)$$
Variance reduction yields $50\%+$ lower standard error $\text{SE} = \sigma / \sqrt{N}$.
