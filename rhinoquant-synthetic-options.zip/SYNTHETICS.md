# Synthetic Options Engineering & Decomposition

## 1. Principles of Synthetic Equivalence

Synthetic instruments replicate target asset cashflows, payoffs, and Greek exposures using combinations of other financial contracts.

### Canonical Synthetic Equations:
1. **Synthetic Long Forward**:
   $$\text{Long Forward} \equiv \text{Long Call}(K, T) - \text{Short Put}(K, T)$$
   - Delta $\approx +1.0$
   - Gamma $\approx 0$ (at ATM)
   - Replicates linear spot exposure without underlying borrow constraints.

2. **Synthetic Short Forward**:
   $$\text{Short Forward} \equiv -\text{Long Call}(K, T) + \text{Long Put}(K, T)$$
   - Delta $\approx -1.0$

3. **Synthetic Long Call (Protective Put)**:
   $$\text{Synthetic Call} \equiv \text{Long Underlying}(S) + \text{Long Put}(K, T)$$
   - Replicates call payoff profile with bounded downside.

4. **Synthetic Long Put**:
   $$\text{Synthetic Put} \equiv -\text{Short Underlying}(S) + \text{Long Call}(K, T)$$

5. **Box Spread Financing**:
   $$\text{Box}(K_1, K_2) \equiv [\text{Long Call}(K_1) - \text{Short Call}(K_2)] + [\text{Long Put}(K_2) - \text{Short Put}(K_1)]$$
   - Terminal Payoff is deterministic: exactly $(K_2 - K_1) \times \text{Multiplier}$.
   - All Greeks ($\Delta, \Gamma, \mathcal{V}, \Theta$) sum to zero.
   - Functions as a pure synthetic zero-coupon bond.
   - Implied annualized financing rate:
     $$r_{implied} = \frac{1}{T} \ln\left(\frac{K_2 - K_1}{P_{box}}\right)$$

---

## 2. Institutional Put-Call Parity Verification

In frictionless, arbitrage-free markets:
$$C_{mid} - P_{mid} = S e^{-q T} - K e^{-r T}$$

RhinoQuant audits dislocations against bid/ask friction:
$$\text{Friction} = \frac{1}{2}\left[(\text{Ask}_C - \text{Bid}_C) + (\text{Ask}_P - \text{Bid}_P) + (\text{Ask}_S - \text{Bid}_S)\right] + \text{Exchange Fees}$$

If the dislocation exceeds friction, the engine flags either:
- **Conversion Arbitrage**: Overpriced synthetic forward vs underlying.
- **Reversal Arbitrage**: Underpriced synthetic forward vs underlying.
