# Execution Analytics & Liquidity Engine

## 1. Package Execution vs Legging Hazard
In complex multi-leg options structures (e.g. Box Spreads, Collars, Ratio Spreads):
- **Sequential Execution ("Legging In")**: Exposes the desk to adverse quote movements, execution delays, and asymmetric fills between legs.
- **Atomic Package RFQ**: Guarantees simultaneous atomic fill across all constituent legs at a net limit price, eliminating execution divergence.

## 2. Liquidity & Slippage Modeling
- **Spread Drag**: $\text{Cost}_{spread} = \frac{1}{2}\sum_i Q_i \cdot (\text{Ask}_i - \text{Bid}_i) \cdot M_i$.
- **Market Impact (Square-Root Model)**:
  $$\text{Impact} = \gamma \cdot \sigma \cdot \sqrt{\frac{Q}{V}}$$
  Where $Q$ is order quantity, $V$ is average volume, and $\sigma$ is underlying volatility.
- **Liquidity Score ($0 - 100$)**: Composite score reflecting weighted bid/ask tightness, market depth, and execution certainty.
