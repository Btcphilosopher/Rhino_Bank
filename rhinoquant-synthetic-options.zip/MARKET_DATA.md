# Market Data Architecture & Data Quality Engine

## 1. Multi-Asset Abstraction
RhinoQuant supports cross-asset derivatives models:
- **Equities / Index**: SPX, AAPL, NVDA (with continuous dividend yield $q$).
- **Commodities**: WTI Crude Oil (CL) (with storage cost and convenience yield dynamics).
- **Foreign Exchange**: EUR/USD (with interest rate parity $r_d - r_f$).
- **Rates**: SOFR term benchmarks.

## 2. Data Quality Audit Engine
Every analytical tick is validated through the `DataQualityEngine`:
- **Crossed Markets**: $\text{Bid} \ge \text{Ask}$ flagged as abnormal market dislocation.
- **Stale Quotes**: Quotes older than $60,000\text{ ms}$ marked `STALE`.
- **Zero Volume / Illiquid Wings**: Flagged for widened confidence intervals.
- **Data Provenance**: Explicitly declared on all UI screens as `DEMO`, `SIMULATED`, `HISTORICAL`, or `LIVE`.
