# Testing & Numerical Verification

## 1. Test Suite Architecture
The platform is protected by automated unit and numerical property tests in `app/src/test/java/com/example/RhinoQuantQuantitativeTests.kt`.

## 2. Tested Invariants
1. **Put-Call Parity Exact Relationship**:
   $$C - P = S e^{-q T} - K e^{-r T}$$
   Verified with tolerance $< 10^{-4}$.
2. **Delta Central Finite Difference**:
   $$\Delta \equiv \lim_{h \to 0} \frac{V(S+h) - V(S-h)}{2h}$$
   Analytical $\Delta$ matches numerical central finite difference within $10^{-4}$.
3. **Gamma Second Derivative**:
   $$\Gamma \equiv \lim_{h \to 0} \frac{V(S+h) - 2V(S) + V(S-h)}{h^2}$$
4. **Vega Derivative**:
   $$\mathcal{V} \equiv \frac{\partial V}{\partial \sigma}$$
5. **Implied Volatility Solver Convergence**:
   Newton-Raphson converges to ground-truth volatility within $< 10^{-5}$.
6. **No-Arbitrage Bound Violation Rejection**:
   Ensures deep-out-of-bounds quotes return `NO_ARBITRAGE_SOLUTION`.
7. **Synthetic Forward Decomposition**:
   Ensures Long Call + Short Put resolves to `SYNTHETIC_LONG_FORWARD`.
8. **Box Spread Financing Rate**:
   Ensures implied interest rate matches benchmark risk-free rate.
9. **Delta-Neutral Hedging**:
   Ensures post-hedge delta equals $0.0000$.
10. **RQQL DSL Parsing**:
    Validates tokenization and execution pipeline.
