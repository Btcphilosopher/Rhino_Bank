#' Simulator & Synthetic Exchange R6 Class
#'
#' Realistic event-driven synthetic exchange and execution simulator modeling
#' queue priority, partial fills, adverse selection, transaction costs, and latency components.
#'
#' @export
Simulator <- R6::R6Class(
  "Simulator",
  
  public = list(
    # Latency parameters in microseconds (us)
    market_data_us = 50,
    strategy_us = 20,
    risk_us = 10,
    network_us = 100,
    exchange_us = 150,
    cancel_us = 80,
    
    # Transaction cost parameters
    commission_per_share = 0.0005,
    maker_rebate = 0.0002,
    taker_fee = 0.0008,
    slippage_std = 0.005,
    market_impact_gamma = 0.1,
    
    # Internal exchange matching state
    exchange_book = NULL,
    exchange_orders = NULL,
    next_exchange_id = 5000,
    
    initialize = function(config = list()) {
      if (!is.null(config$market_data_us)) self$market_data_us <- config$market_data_us
      if (!is.null(config$strategy_us)) self$strategy_us <- config$strategy_us
      if (!is.null(config$risk_us)) self$risk_us <- config$risk_us
      if (!is.null(config$network_us)) self$network_us <- config$network_us
      if (!is.null(config$exchange_us)) self$exchange_us <- config$exchange_us
      
      self$exchange_orders <- list()
    },
    
    #' Calculate Total R Simulation End-to-End Latency
    get_total_latency_us = function() {
      return(self$market_data_us + self$strategy_us + self$risk_us + self$network_us + self$exchange_us)
    },
    
    #' Submit Order to Execution Simulator
    submit_order = function(order, order_book) {
      self$next_exchange_id <- self$next_exchange_id + 1
      ex_id <- sprintf("EX_%d", self$next_exchange_id)
      
      bb <- order_book$best_bid()
      ba <- order_book$best_ask()
      mid <- order_book$mid()
      
      fills <- list()
      
      # Market Order Execution
      if (order$order_type == "MARKET") {
        exec_price <- if (order$side == "BUY") ba["price"] else bb["price"]
        if (is.na(exec_price)) exec_price <- if (!is.na(mid)) mid else order$price
        
        # Apply Slippage & Impact
        slippage <- rnorm(1, mean = 0, sd = self$slippage_std)
        impact <- self$market_impact_gamma * sqrt(order$quantity) * 0.001
        
        if (order$side == "BUY") {
          exec_price <- exec_price + abs(slippage) + impact
        } else {
          exec_price <- exec_price - abs(slippage) - impact
        }
        
        fee <- order$quantity * self$taker_fee
        
        fills[[1]] <- list(
          exchange_order_id = ex_id,
          fill_qty = order$quantity,
          fill_price = exec_price,
          fee = fee,
          is_maker = FALSE,
          latency_us = self$get_total_latency_us()
        )
      } 
      # Limit Order Execution Logic
      else {
        # Check Immediate Crossing
        crosses <- FALSE
        if (order$side == "BUY" && !is.na(ba["price"]) && order$price >= ba["price"]) {
          crosses <- TRUE
        } else if (order$side == "SELL" && !is.na(bb["price"]) && order$price <= bb["price"]) {
          crosses <- TRUE
        }
        
        if (crosses) {
          exec_price <- order$price
          fee <- order$quantity * self$taker_fee
          fills[[1]] <- list(
            exchange_order_id = ex_id,
            fill_qty = order$quantity,
            fill_price = exec_price,
            fee = fee,
            is_maker = FALSE,
            latency_us = self$get_total_latency_us()
          )
        } else {
          # Limit order rests in book with fill probability
          # Queue survival / fill probability based on queue depth and touch closeness
          dist_from_touch <- if (order$side == "BUY") (ba["price"] - order$price) else (order$price - bb["price"])
          prob_fill <- max(0.05, 0.95 - (dist_from_touch * 10))
          
          if (runif(1) < prob_fill) {
            fee <- -order$quantity * self$maker_rebate # Maker rebate
            fills[[1]] <- list(
              exchange_order_id = ex_id,
              fill_qty = order$quantity,
              fill_price = order$price,
              fee = fee,
              is_maker = TRUE,
              latency_us = self$get_total_latency_us()
            )
          }
        }
      }
      
      return(list(
        exchange_order_id = ex_id,
        fills = fills,
        latency_us = self$get_total_latency_us()
      ))
    }
  )
)
