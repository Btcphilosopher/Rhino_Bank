#' Strategy Base R6 Class & Implementations
#'
#' Provides the institutional quantitative strategy interface and research strategies:
#' - MarketMakingStrategy (Avellaneda-Stoikov inventory & volatility model)
#' - StatArbStrategy (Pairs trading & z-score mean reversion)
#' - MomentumStrategy (Short-term order flow & price momentum)
#' - ExecutionStrategy (TWAP, VWAP, POV, Implementation Shortfall)
#'
#' @export
Strategy <- R6::R6Class(
  "Strategy",
  
  public = list(
    strategy_id = NULL,
    symbol = NULL,
    portfolio_id = NULL,
    active = TRUE,
    parameters = list(),
    
    initialize = function(strategy_id, symbol = "RHINO", parameters = list()) {
      self$strategy_id <- strategy_id
      self$symbol <- symbol
      self$parameters <- parameters
    },
    
    on_market_event = function(event) {},
    on_book_update = function(book) {},
    on_trade = function(trade) {},
    on_timer = function(timestamp) {},
    on_fill = function(fill) {},
    generate_orders = function(market_state, features, portfolio) {
      return(list())
    }
  )
)

#' MarketMakingStrategy R6 Class
#'
#' Implements inventory-aware, volatility-adjusted, microprice-based market making.
#' Uses Avellaneda-Stoikov framework: Reservation Price r = s - q * gamma * sigma^2 * (T - t)
#' Half-spread delta = (1 / gamma) * ln(1 + gamma / k)
#' @export
MarketMakingStrategy <- R6::R6Class(
  "MarketMakingStrategy",
  inherit = Strategy,
  
  public = list(
    gamma = 0.1,        # Risk aversion parameter
    kappa = 1.5,        # Order book liquidity density
    target_spread = 0.02, # Default half-spread target
    order_size = 10,    # Default quote size
    
    initialize = function(strategy_id = "MM_ALPHA", symbol = "RHINO", parameters = list()) {
      super$initialize(strategy_id, symbol, parameters)
      if (!is.null(parameters$gamma)) self$gamma <- parameters$gamma
      if (!is.null(parameters$kappa)) self$kappa <- parameters$kappa
      if (!is.null(parameters$target_spread)) self$target_spread <- parameters$target_spread
      if (!is.null(parameters$order_size)) self$order_size <- parameters$order_size
    },
    
    generate_orders = function(market_state, features, portfolio) {
      if (!self$active) return(list())
      
      mid_price <- market_state$mid
      if (is.null(mid_price) || is.na(mid_price)) return(list())
      
      inventory <- portfolio$get_position(self$symbol)
      volatility <- if (!is.null(features$realised_volatility)) max(features$realised_volatility, 0.01) else 0.02
      microprice <- if (!is.null(features$microprice) && !is.na(features$microprice)) features$microprice else mid_price
      
      # Reservation Price (Avellaneda-Stoikov)
      reservation_price <- microprice - (inventory * self$gamma * (volatility^2))
      
      # Optimal spread adjustment
      half_spread <- max(self$target_spread / 2, (1 / self$gamma) * log(1 + (self$gamma / self$kappa)))
      
      bid_price <- round(reservation_price - half_spread, 2)
      ask_price <- round(reservation_price + half_spread, 2)
      
      # Ensure non-crossed prices relative to current best bid/ask
      if (!is.null(market_state$best_ask) && !is.na(market_state$best_ask) && bid_price >= market_state$best_ask) {
        bid_price <- market_state$best_ask - 0.01
      }
      if (!is.null(market_state$best_bid) && !is.na(market_state$best_bid) && ask_price <= market_state$best_bid) {
        ask_price <- market_state$best_bid + 0.01
      }
      
      orders <- list(
        list(
          strategy_id = self$strategy_id,
          symbol = self$symbol,
          side = "BUY",
          order_type = "LIMIT",
          price = bid_price,
          quantity = self$order_size
        ),
        list(
          strategy_id = self$strategy_id,
          symbol = self$symbol,
          side = "SELL",
          order_type = "LIMIT",
          price = ask_price,
          quantity = self$order_size
        )
      )
      return(orders)
    }
  )
)

#' StatArbStrategy R6 Class
#'
#' Statistical Arbitrage & Z-Score Mean Reversion strategy.
#' @export
StatArbStrategy <- R6::R6Class(
  "StatArbStrategy",
  inherit = Strategy,
  
  public = list(
    entry_threshold = 2.0,
    exit_threshold = 0.5,
    stop_threshold = 3.5,
    order_size = 20,
    
    initialize = function(strategy_id = "STAT_ARB", symbol = "RHINO", parameters = list()) {
      super$initialize(strategy_id, symbol, parameters)
      if (!is.null(parameters$entry_threshold)) self$entry_threshold <- parameters$entry_threshold
      if (!is.null(parameters$exit_threshold)) self$exit_threshold <- parameters$exit_threshold
      if (!is.null(parameters$stop_threshold)) self$stop_threshold <- parameters$stop_threshold
      if (!is.null(parameters$order_size)) self$order_size <- parameters$order_size
    },
    
    generate_orders = function(market_state, features, portfolio) {
      if (!self$active) return(list())
      
      z_score <- features$z_score
      if (is.null(z_score) || is.na(z_score)) return(list())
      
      pos <- portfolio$get_position(self$symbol)
      mid_price <- market_state$mid
      if (is.null(mid_price) || is.na(mid_price)) return(list())
      
      orders <- list()
      
      if (pos == 0) {
        if (z_score > self$entry_threshold && z_score < self$stop_threshold) {
          # Short signal
          orders[[1]] <- list(
            strategy_id = self$strategy_id,
            symbol = self$symbol,
            side = "SELL",
            order_type = "LIMIT",
            price = market_state$best_bid,
            quantity = self$order_size
          )
        } else if (z_score < -self$entry_threshold && z_score > -self$stop_threshold) {
          # Long signal
          orders[[1]] <- list(
            strategy_id = self$strategy_id,
            symbol = self$symbol,
            side = "BUY",
            order_type = "LIMIT",
            price = market_state$best_ask,
            quantity = self$order_size
          )
        }
      } else if (pos > 0 && z_score >= -self$exit_threshold) {
        # Close long
        orders[[1]] <- list(
          strategy_id = self$strategy_id,
          symbol = self$symbol,
          side = "SELL",
          order_type = "LIMIT",
          price = market_state$best_bid,
          quantity = abs(pos)
        )
      } else if (pos < 0 && z_score <= self$exit_threshold) {
        # Close short
        orders[[1]] <- list(
          strategy_id = self$strategy_id,
          symbol = self$symbol,
          side = "BUY",
          order_type = "LIMIT",
          price = market_state$best_ask,
          quantity = abs(pos)
        )
      }
      return(orders)
    }
  )
)

#' MomentumStrategy R6 Class
#' @export
MomentumStrategy <- R6::R6Class(
  "MomentumStrategy",
  inherit = Strategy,
  
  public = list(
    momentum_threshold = 0.001,
    order_size = 15,
    
    initialize = function(strategy_id = "MOMENTUM", symbol = "RHINO", parameters = list()) {
      super$initialize(strategy_id, symbol, parameters)
      if (!is.null(parameters$momentum_threshold)) self$momentum_threshold <- parameters$momentum_threshold
      if (!is.null(parameters$order_size)) self$order_size <- parameters$order_size
    },
    
    generate_orders = function(market_state, features, portfolio) {
      if (!self$active) return(list())
      
      mom <- features$short_term_momentum
      if (is.null(mom) || is.na(mom)) return(list())
      
      orders <- list()
      if (mom > self$momentum_threshold) {
        orders[[1]] <- list(
          strategy_id = self$strategy_id,
          symbol = self$symbol,
          side = "BUY",
          order_type = "LIMIT",
          price = market_state$best_ask,
          quantity = self$order_size
        )
      } else if (mom < -self$momentum_threshold) {
        orders[[1]] <- list(
          strategy_id = self$strategy_id,
          symbol = self$symbol,
          side = "SELL",
          order_type = "LIMIT",
          price = market_state$best_bid,
          quantity = self$order_size
        )
      }
      return(orders)
    }
  )
)
