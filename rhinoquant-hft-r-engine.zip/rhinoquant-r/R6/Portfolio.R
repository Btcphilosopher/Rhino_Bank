#' Portfolio R6 Class
#'
#' Institutional portfolio engine tracking positions, cash, realized P&L,
#' unrealized P&L, total P&L, leverage, margin usage, and multi-venue exposure.
#'
#' @export
Portfolio <- R6::R6Class(
  "Portfolio",
  
  public = list(
    portfolio_id = "MAIN",
    initial_cash = 1000000,
    cash = 1000000,
    positions = list(), # symbol -> qty
    avg_cost = list(), # symbol -> average acquisition cost
    realised_pnl = 0,
    unrealised_pnl = 0,
    total_fees = 0,
    trade_history = NULL,
    pnl_history = NULL,
    
    initialize = function(portfolio_id = "MAIN", initial_cash = 1000000) {
      self$portfolio_id <- portfolio_id
      self$initial_cash <- initial_cash
      self$cash <- initial_cash
      self$positions <- list()
      self$avg_cost <- list()
      self$trade_history <- list()
      self$pnl_history <- list()
    },
    
    #' Get Position Quantity for a Symbol
    get_position = function(symbol) {
      if (is.null(self$positions[[symbol]])) return(0)
      return(self$positions[[symbol]])
    },
    
    #' Process Fill Event
    process_fill = function(symbol, side, quantity, price, fee = 0, timestamp = Sys.time()) {
      current_qty <- self$get_position(symbol)
      current_cost <- if (is.null(self$avg_cost[[symbol]])) 0 else self$avg_cost[[symbol]]
      
      trade_qty <- if (side == "BUY") quantity else -quantity
      new_qty <- current_qty + trade_qty
      
      # Calculate Realised P&L when reducing position
      if ((current_qty > 0 && trade_qty < 0) || (current_qty < 0 && trade_qty > 0)) {
        closed_qty <- min(abs(current_qty), abs(trade_qty))
        pnl <- if (current_qty > 0) closed_qty * (price - current_cost) else closed_qty * (current_cost - price)
        self$realised_pnl <- self$realised_pnl + pnl
      }
      
      # Update Average Cost
      if (new_qty == 0) {
        self$avg_cost[[symbol]] <- 0
      } else if ((current_qty >= 0 && trade_qty > 0) || (current_qty <= 0 && trade_qty < 0)) {
        total_val <- (abs(current_qty) * current_cost) + (quantity * price)
        self$avg_cost[[symbol]] <- total_val / abs(new_qty)
      }
      
      self$positions[[symbol]] <- new_qty
      self$cash <- self$cash - (trade_qty * price) - fee
      self$total_fees <- self$total_fees + fee
      
      # Record Trade
      self$trade_history[[length(self$trade_history) + 1]] <- list(
        timestamp = timestamp,
        symbol = symbol,
        side = side,
        quantity = quantity,
        price = price,
        fee = fee,
        position_after = new_qty,
        cash_after = self$cash,
        realised_pnl = self$realised_pnl
      )
    },
    
    #' Mark to Market
    mark_to_market = function(market_prices) {
      unreal <- 0
      gross_notional <- 0
      
      for (sym in names(self$positions)) {
        qty <- self$positions[[sym]]
        if (qty != 0) {
          px <- market_prices[[sym]]
          if (!is.null(px) && !is.na(px)) {
            cost <- self$avg_cost[[sym]]
            unreal <- unreal + (qty * (px - cost))
            gross_notional <- gross_notional + (abs(qty) * px)
          }
        }
      }
      
      self$unrealised_pnl <- unreal
      total_equity <- self$cash + gross_notional + self$unrealised_pnl
      leverage <- if (total_equity > 0) gross_notional / total_equity else 0
      
      summary <- list(
        timestamp = Sys.time(),
        cash = self$cash,
        realised_pnl = self$realised_pnl,
        unrealised_pnl = self$unrealised_pnl,
        total_fees = self$total_fees,
        gross_pnl = self$realised_pnl + self$unrealised_pnl,
        net_pnl = self$realised_pnl + self$unrealised_pnl - self$total_fees,
        total_equity = total_equity,
        gross_notional = gross_notional,
        leverage = leverage
      )
      
      self$pnl_history[[length(self$pnl_history) + 1]] <- summary
      return(summary)
    },
    
    #' Get Portfolio Summary
    get_summary = function() {
      gross_pnl <- self$realised_pnl + self$unrealised_pnl
      net_pnl <- gross_pnl - self$total_fees
      
      return(list(
        portfolio_id = self$portfolio_id,
        cash = self$cash,
        realised_pnl = self$realised_pnl,
        unrealised_pnl = self$unrealised_pnl,
        gross_pnl = gross_pnl,
        total_fees = self$total_fees,
        net_pnl = net_pnl,
        total_equity = self$cash + self$unrealised_pnl,
        trade_count = length(self$trade_history)
      ))
    }
  )
)
