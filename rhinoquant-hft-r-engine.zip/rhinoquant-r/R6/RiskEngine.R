#' RiskEngine R6 Class
#'
#' Institutional pre-trade risk engine enforcing strict position limits, fat-finger controls,
#' rate limits, price collars, stale data checks, and independent multi-level kill switches.
#'
#' @export
RiskEngine <- R6::R6Class(
  "RiskEngine",
  
  public = list(
    # Limits
    max_position = 1000,
    max_order_quantity = 100,
    max_notional = 100000,
    max_leverage = 5.0,
    max_daily_loss = 5000,
    max_strategy_loss = 2500,
    max_order_rate = 50, # Orders per second
    price_collar_pct = 0.02, # 2% collar around mid
    stale_market_ms = 5000, # 5s market data age limit
    
    # State tracking
    order_timestamps = NULL,
    kill_switches = list(
      global = FALSE,
      portfolio = FALSE,
      venue = list(),
      strategy = list(),
      connectivity = FALSE,
      stale_data = FALSE,
      loss_limit = FALSE,
      risk_breach = FALSE
    ),
    rejection_log = NULL,
    
    initialize = function(config = list()) {
      if (!is.null(config$max_position)) self$max_position <- config$max_position
      if (!is.null(config$max_order_quantity)) self$max_order_quantity <- config$max_order_quantity
      if (!is.null(config$max_notional)) self$max_notional <- config$max_notional
      if (!is.null(config$max_leverage)) self$max_leverage <- config$max_leverage
      if (!is.null(config$max_daily_loss)) self$max_daily_loss <- config$max_daily_loss
      if (!is.null(config$price_collar_pct)) self$price_collar_pct <- config$price_collar_pct
      if (!is.null(config$stale_market_ms)) self$stale_market_ms <- config$stale_market_ms
      
      self$order_timestamps <- numeric(0)
      self$rejection_log <- list()
    },
    
    #' Main Pre-Trade Validation Pipeline
    validate_order = function(order, market_state, portfolio) {
      current_time <- as.numeric(Sys.time())
      
      # 1. Kill Switches
      if (self$kill_switches$global) return(self$reject("RISK_REJECT_KILL_SWITCH_GLOBAL", "Global Kill Switch active"))
      if (self$kill_switches$portfolio) return(self$reject("RISK_REJECT_KILL_SWITCH_PORTFOLIO", "Portfolio Kill Switch active"))
      if (self$kill_switches$loss_limit) return(self$reject("RISK_REJECT_KILL_SWITCH_LOSS_LIMIT", "Loss Limit Kill Switch active"))
      if (isTRUE(self$kill_switches$strategy[[order$strategy_id]])) {
        return(self$reject("RISK_REJECT_KILL_SWITCH_STRATEGY", sprintf("Strategy %s Kill Switch active", order$strategy_id)))
      }
      
      # 2. Stale Market Check
      if (!is.null(market_state$timestamp)) {
        age_ms <- (current_time - market_state$timestamp) * 1000
        if (age_ms > self$stale_market_ms) {
          return(self$reject("RISK_REJECT_STALE_MARKET", sprintf("Market data stale by %.1f ms", age_ms)))
        }
      }
      
      # 3. Order Rate Limit
      self$order_timestamps <- self$order_timestamps[self$order_timestamps > (current_time - 1.0)]
      if (length(self$order_timestamps) >= self$max_order_rate) {
        return(self$reject("RISK_REJECT_RATE_LIMIT", sprintf("Order rate exceeded %d ops", self$max_order_rate)))
      }
      
      # 4. Max Single Order Quantity / Fat-Finger
      if (order$quantity > self$max_order_quantity) {
        return(self$reject("RISK_REJECT_FAT_FINGER", sprintf("Quantity %f exceeds max order quantity %f", order$quantity, self$max_order_quantity)))
      }
      
      # 5. Price Collar Check
      if (!is.null(market_state$mid) && !is.na(market_state$mid)) {
        mid <- market_state$mid
        dev <- abs(order$price - mid) / mid
        if (dev > self$price_collar_pct) {
          return(self$reject("RISK_REJECT_PRICE_COLLAR", sprintf("Price %.2f deviates %.2f%% from mid %.2f (max allowed %.2f%%)", order$price, dev * 100, mid, self$price_collar_pct * 100)))
        }
      }
      
      # 6. Position Limit Check
      current_pos <- portfolio$get_position(order$symbol)
      delta_pos <- if (order$side == "BUY") order$quantity else -order$quantity
      projected_pos <- current_pos + delta_pos
      
      if (abs(projected_pos) > self$max_position) {
        return(self$reject("RISK_REJECT_POSITION_LIMIT", sprintf("Projected position %.0f exceeds limit %.0f", projected_pos, self$max_position)))
      }
      
      # 7. Notional Value Check
      notional <- order$quantity * order$price
      if (notional > self$max_notional) {
        return(self$reject("RISK_REJECT_NOTIONAL_LIMIT", sprintf("Notional %.2f exceeds max allowed %.2f", notional, self$max_notional)))
      }
      
      # 8. Daily Loss Limit Check
      pnl_summary <- portfolio$get_summary()
      if (pnl_summary$total_pnl < -self$max_daily_loss) {
        self$activate_kill_switch("loss_limit")
        return(self$reject("RISK_REJECT_LOSS_LIMIT", sprintf("Daily loss %.2f breached max loss limit %.2f", pnl_summary$total_pnl, self$max_daily_loss)))
      }
      
      # Record successful validation timestamp for rate limiting
      self$order_timestamps <- c(self$order_timestamps, current_time)
      
      return(list(approved = TRUE, reason = "APPROVED", message = "Order passed all risk controls"))
    },
    
    #' Activate Kill Switch
    activate_kill_switch = function(type, target = NULL) {
      if (type == "global") self$kill_switches$global <- TRUE
      else if (type == "portfolio") self$kill_switches$portfolio <- TRUE
      else if (type == "loss_limit") self$kill_switches$loss_limit <- TRUE
      else if (type == "strategy" && !is.null(target)) self$kill_switches$strategy[[target]] <- TRUE
      else if (type == "venue" && !is.null(target)) self$kill_switches$venue[[target]] <- TRUE
    },
    
    #' Reset Kill Switch
    reset_kill_switch = function(type, target = NULL) {
      if (type == "global") self$kill_switches$global <- FALSE
      else if (type == "portfolio") self$kill_switches$portfolio <- FALSE
      else if (type == "loss_limit") self$kill_switches$loss_limit <- FALSE
      else if (type == "strategy" && !is.null(target)) self$kill_switches$strategy[[target]] <- FALSE
      else if (type == "venue" && !is.null(target)) self$kill_switches$venue[[target]] <- FALSE
    },
    
    #' Reject Order Helper
    reject = function(code, message) {
      res <- list(approved = FALSE, reason = code, message = message, timestamp = Sys.time())
      self$rejection_log[[length(self$rejection_log) + 1]] <- res
      return(res)
    }
  )
)
