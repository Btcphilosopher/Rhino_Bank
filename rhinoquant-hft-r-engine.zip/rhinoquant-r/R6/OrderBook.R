#' OrderBook R6 Class
#'
#' Reconstructs and models an L1/L2/L3 Limit Order Book with microprice,
#' queue dynamics, order flow imbalance, and anomaly detection.
#'
#' @export
OrderBook <- R6::R6Class(
  "OrderBook",
  
  public = list(
    symbol = NULL,
    venue = NULL,
    bids = NULL, # list or data.table of price -> qty
    asks = NULL, # list or data.table of price -> qty
    last_sequence = 0,
    last_timestamp = 0,
    trade_history = NULL,
    anomaly_log = NULL,
    
    #' Initialize Order Book
    initialize = function(symbol = "RHINO", venue = "SYNTHETIC") {
      self$symbol <- symbol
      self$venue <- venue
      self$bids <- data.frame(price = numeric(0), qty = numeric(0), orders = integer(0))
      self$asks <- data.frame(price = numeric(0), qty = numeric(0), orders = integer(0))
      self$trade_history <- list()
      self$anomaly_log <- list()
    },
    
    #' Update Bid Level
    update_bid = function(price, quantity, orders = 1, sequence = NULL, timestamp = NULL) {
      self$validate_update(price, quantity, sequence, timestamp)
      
      if (quantity <= 0) {
        self$bids <- self$bids[self$bids$price != price, ]
      } else {
        idx <- which(abs(self$bids$price - price) < 1e-6)
        if (length(idx) > 0) {
          self$bids$qty[idx] <- quantity
          self$bids$orders[idx] <- orders
        } else {
          self$bids <- rbind(self$bids, data.frame(price = price, qty = quantity, orders = orders))
        }
      }
      # Sort bids descending
      if (nrow(self$bids) > 0) {
        self$bids <- self$bids[order(-self$bids$price), , drop = FALSE]
      }
      self$check_crossed_locked()
    },
    
    #' Update Ask Level
    update_ask = function(price, quantity, orders = 1, sequence = NULL, timestamp = NULL) {
      self$validate_update(price, quantity, sequence, timestamp)
      
      if (quantity <= 0) {
        self$asks <- self$asks[self$asks$price != price, ]
      } else {
        idx <- which(abs(self$asks$price - price) < 1e-6)
        if (length(idx) > 0) {
          self$asks$qty[idx] <- quantity
          self$asks$orders[idx] <- orders
        } else {
          self$asks <- rbind(self$asks, data.frame(price = price, qty = quantity, orders = orders))
        }
      }
      # Sort asks ascending
      if (nrow(self$asks) > 0) {
        self$asks <- self$asks[order(self$asks$price), , drop = FALSE]
      }
      self$check_crossed_locked()
    },
    
    #' Best Bid Price & Size
    best_bid = function() {
      if (nrow(self$bids) == 0) return(c(price = NA, qty = 0))
      return(c(price = self$bids$price[1], qty = self$bids$qty[1]))
    },
    
    #' Best Ask Price & Size
    best_ask = function() {
      if (nrow(self$asks) == 0) return(c(price = NA, qty = 0))
      return(c(price = self$asks$price[1], qty = self$asks$qty[1]))
    },
    
    #' Mid Price
    mid = function() {
      bb <- self$best_bid()["price"]
      ba <- self$best_ask()["price"]
      if (is.na(bb) || is.na(ba)) return(NA_real_)
      return((bb + ba) / 2)
    },
    
    #' Spread
    spread = function() {
      bb <- self$best_bid()["price"]
      ba <- self$best_ask()["price"]
      if (is.na(bb) || is.na(ba)) return(NA_real_)
      return(ba - bb)
    },
    
    #' Microprice (Volume-Weighted Mid Price)
    microprice = function() {
      bb <- self$best_bid()
      ba <- self$best_ask()
      if (is.na(bb["price"]) || is.na(ba["price"])) return(NA_real_)
      total_qty <- bb["qty"] + ba["qty"]
      if (total_qty == 0) return(self$mid())
      # Microprice = (ba_price * bid_qty + bb_price * ask_qty) / total_qty
      return(as.numeric((ba["price"] * bb["qty"] + bb["price"] * ba["qty"]) / total_qty))
    },
    
    #' Order Book Depth
    depth = function(levels = 5) {
      n_bids <- min(levels, nrow(self$bids))
      n_asks <- min(levels, nrow(self$asks))
      
      bid_depth <- if (n_bids > 0) sum(self$bids$qty[1:n_bids]) else 0
      ask_depth <- if (n_asks > 0) sum(self$asks$qty[1:n_asks]) else 0
      
      return(list(
        levels = levels,
        bid_depth = bid_depth,
        ask_depth = ask_depth,
        bids = head(self$bids, levels),
        asks = head(self$asks, levels)
      ))
    },
    
    #' Depth Imbalance
    imbalance = function(levels = 1) {
      dep <- self$depth(levels)
      tot <- dep$bid_depth + dep$ask_depth
      if (tot == 0) return(0)
      return((dep$bid_depth - dep$ask_depth) / tot)
    },
    
    #' Estimate Queue Position for an order
    queue_position = function(side, price, order_qty) {
      if (side == "BUY" || side == "BID") {
        idx <- which(abs(self$bids$price - price) < 1e-6)
        if (length(idx) == 0) return(0)
        return(self$bids$qty[idx]) # Quantity ahead in queue
      } else {
        idx <- which(abs(self$asks$price - price) < 1e-6)
        if (length(idx) == 0) return(0)
        return(self$asks$qty[idx])
      }
    },
    
    #' Book Pressure
    book_pressure = function() {
      imb <- self$imbalance(3)
      mic <- self$microprice()
      m <- self$mid()
      m_diff <- if (!is.na(mic) && !is.na(m)) mic - m else 0
      return(list(imbalance = imb, microprice_offset = m_diff))
    },
    
    #' Validate update inputs & detect sequence gaps / timestamp reversals
    validate_update = function(price, quantity, sequence, timestamp) {
      if (!is.null(sequence)) {
        if (self$last_sequence > 0 && sequence > self$last_sequence + 1) {
          self$log_anomaly("SEQUENCE_GAP", sprintf("Expected %d, got %d", self$last_sequence + 1, sequence))
        }
        self$last_sequence <- sequence
      }
      if (!is.null(timestamp)) {
        if (self$last_timestamp > 0 && timestamp < self$last_timestamp) {
          self$log_anomaly("INVALID_TIMESTAMP", sprintf("Timestamp went backwards: %f < %f", timestamp, self$last_timestamp))
        }
        self$last_timestamp <- timestamp
      }
      if (price <= 0) {
        self$log_anomaly("INVALID_PRICE", sprintf("Non-positive price: %f", price))
      }
    },
    
    #' Check for Crossed or Locked Books
    check_crossed_locked = function() {
      if (nrow(self$bids) > 0 && nrow(self$asks) > 0) {
        bb <- self$bids$price[1]
        ba <- self$asks$price[1]
        if (bb > ba) {
          self$log_anomaly("CROSSED_BOOK", sprintf("Best Bid (%f) > Best Ask (%f)", bb, ba))
        } else if (abs(bb - ba) < 1e-6) {
          self$log_anomaly("LOCKED_BOOK", sprintf("Best Bid (%f) == Best Ask (%f)", bb, ba))
        }
      }
    },
    
    #' Log Anomaly
    log_anomaly = function(type, details) {
      self$anomaly_log[[length(self$anomaly_log) + 1]] <- list(
        time = Sys.time(),
        type = type,
        details = details
      )
    }
  )
)
