#' OrderManager (OMS) R6 Class
#'
#' Manages full order lifecycle state transitions:
#' NEW -> ACK -> PARTIAL_FILL -> FILL / CANCEL / REJECT / EXPIRE / REPLACE
#'
#' @export
OrderManager <- R6::R6Class(
  "OrderManager",
  
  public = list(
    orders = NULL, # List of order_id -> order state
    order_history = NULL, # Audit log of order state transitions
    next_id = 1000,
    
    initialize = function() {
      self$orders <- list()
      self$order_history <- list()
    },
    
    #' Generate Client Order ID
    generate_client_order_id = function() {
      self$next_id <- self$next_id + 1
      return(sprintf("RQ_ORD_%d", self$next_id))
    },
    
    #' Create and Register New Order
    create_order = function(strategy_id, symbol, side, price, quantity, order_type = "LIMIT", venue = "SYNTHETIC") {
      client_id <- self$generate_client_order_id()
      order <- list(
        client_order_id = client_id,
        exchange_order_id = NA_character_,
        strategy_id = strategy_id,
        portfolio_id = "MAIN",
        symbol = symbol,
        venue = venue,
        side = side,
        order_type = order_type,
        price = price,
        quantity = quantity,
        filled_quantity = 0,
        remaining_quantity = quantity,
        avg_fill_price = 0,
        status = "NEW",
        created_time = Sys.time(),
        updated_time = Sys.time(),
        events = list()
      )
      
      self$orders[[client_id]] <- order
      self$record_transition(client_id, "NEW", "Order created")
      return(order)
    },
    
    #' Update Order Status on Exchange Acknowledgment
    process_ack = function(client_order_id, exchange_order_id) {
      if (is.null(self$orders[[client_order_id]])) return(FALSE)
      self$orders[[client_order_id]]$exchange_order_id <- exchange_order_id
      self$orders[[client_order_id]]$status <- "ACK"
      self$orders[[client_order_id]]$updated_time <- Sys.time()
      self$record_transition(client_order_id, "ACK", sprintf("Assigned exchange ID %s", exchange_order_id))
      return(TRUE)
    },
    
    #' Process Fill or Partial Fill
    process_fill = function(client_order_id, fill_qty, fill_price, fill_time = Sys.time()) {
      if (is.null(self$orders[[client_order_id]])) return(NULL)
      
      ord <- self$orders[[client_order_id]]
      new_filled <- ord$filled_quantity + fill_qty
      new_remaining <- ord$quantity - new_filled
      
      # Compute new volume-weighted average fill price
      tot_val <- (ord$filled_quantity * ord$avg_fill_price) + (fill_qty * fill_price)
      ord$avg_fill_price <- tot_val / new_filled
      ord$filled_quantity <- new_filled
      ord$remaining_quantity <- max(0, new_remaining)
      
      new_status <- if (ord$remaining_quantity == 0) "FILL" else "PARTIAL_FILL"
      ord$status <- new_status
      ord$updated_time <- fill_time
      
      self$orders[[client_order_id]] <- ord
      self$record_transition(client_order_id, new_status, sprintf("Filled %f @ %f", fill_qty, fill_price))
      
      fill_event <- list(
        client_order_id = client_order_id,
        exchange_order_id = ord$exchange_order_id,
        strategy_id = ord$strategy_id,
        symbol = ord$symbol,
        venue = ord$venue,
        side = ord$side,
        fill_qty = fill_qty,
        fill_price = fill_price,
        fill_time = fill_time,
        status = new_status
      )
      return(fill_event)
    },
    
    #' Process Cancellation
    process_cancel = function(client_order_id, reason = "User requested") {
      if (is.null(self$orders[[client_order_id]])) return(FALSE)
      self$orders[[client_order_id]]$status <- "CANCEL"
      self$orders[[client_order_id]]$updated_time <- Sys.time()
      self$record_transition(client_order_id, "CANCEL", reason)
      return(TRUE)
    },
    
    #' Process Order Rejection
    process_reject = function(client_order_id, reason) {
      if (is.null(self$orders[[client_order_id]])) return(FALSE)
      self$orders[[client_order_id]]$status <- "REJECT"
      self$orders[[client_order_id]]$updated_time <- Sys.time()
      self$record_transition(client_order_id, "REJECT", reason)
      return(TRUE)
    },
    
    #' Audit log record
    record_transition = function(client_order_id, status, details) {
      trans <- list(
        time = Sys.time(),
        client_order_id = client_order_id,
        status = status,
        details = details
      )
      self$order_history[[length(self$order_history) + 1]] <- trans
    },
    
    #' Get Active (Open) Orders
    get_active_orders = function() {
      active <- Filter(function(o) o$status %in% c("NEW", "ACK", "PARTIAL_FILL"), self$orders)
      return(active)
    },
    
    #' Get Order Summary
    get_summary = function() {
      statuses <- sapply(self$orders, function(o) o$status)
      return(list(
        total_submitted = length(self$orders),
        active = sum(statuses %in% c("NEW", "ACK", "PARTIAL_FILL")),
        filled = sum(statuses == "FILL"),
        partially_filled = sum(statuses == "PARTIAL_FILL"),
        cancelled = sum(statuses == "CANCEL"),
        rejected = sum(statuses == "REJECT")
      ))
    }
  )
)
