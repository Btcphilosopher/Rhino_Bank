#' Synthetic Market Generator
#'
#' Generates realistic high-frequency market data streams, order book dynamics,
#' regime shifts, volatility clustering, and market shocks for testing.
#'
#' @export
SyntheticMarket <- R6::R6Class(
  "SyntheticMarket",
  
  public = list(
    symbol = "RHINO",
    venue = "SYNTHETIC",
    initial_price = 100.0,
    current_mid = 100.0,
    volatility = 0.02,
    mean_reversion_speed = 0.05,
    tick_size = 0.01,
    sequence = 0,
    regime = "NORMAL", # NORMAL, TRENDING, MEAN_REVERTING, HIGH_VOLATILITY, SHOCK
    
    initialize = function(symbol = "RHINO", venue = "SYNTHETIC", initial_price = 100.0) {
      self$symbol <- symbol
      self$venue <- venue
      self$initial_price <- initial_price
      self$current_mid <- initial_price
      self$sequence <- 0
    },
    
    #' Generate Next Market Event Batch (Quotes & Trades)
    next_tick = function() {
      self$sequence <- self$sequence + 1
      
      # Stochastic Mid Price Walk (Geometric Brownian Motion + Jump Diffusion + Mean Reversion)
      dt <- 1 / 3600 # 1 second in hours
      drift <- if (self$regime == "TRENDING") 0.05 else 0.0
      reversion <- self$mean_reversion_speed * (self$initial_price - self$current_mid)
      
      # Volatility regimes
      vol <- if (self$regime == "HIGH_VOLATILITY") self$volatility * 3 else self$volatility
      
      # Random Shock Check
      jump <- if (runif(1) < 0.01) rnorm(1, mean = 0, sd = 0.20) else 0
      
      dw <- rnorm(1, mean = 0, sd = sqrt(dt))
      d_price <- (drift + reversion) * dt + vol * self$current_mid * dw + jump
      
      self$current_mid <- max(1.0, round((self$current_mid + d_price) / self$tick_size) * self$tick_size)
      
      # Spread generation (0.01 to 0.04)
      half_spread <- max(self$tick_size, round((runif(1, 0.01, 0.03)) / self$tick_size) * self$tick_size)
      bid_price <- self$current_mid - half_spread
      ask_price <- self$current_mid + half_spread
      
      bid_qty <- round(runif(1, 10, 200))
      ask_qty <- round(runif(1, 10, 200))
      
      quote_event <- QuoteEvent(
        symbol = self$symbol,
        venue = self$venue,
        bid_price = bid_price,
        bid_qty = bid_qty,
        ask_price = ask_price,
        ask_qty = ask_qty,
        sequence_number = self$sequence
      )
      
      events <- list(quote_event)
      
      # 30% chance of a trade occurring at top of book
      if (runif(1) < 0.3) {
        self$sequence <- self$sequence + 1
        side <- if (runif(1) > 0.5) "BUY" else "SELL"
        px <- if (side == "BUY") ask_price else bid_price
        qty <- round(runif(1, 1, 50))
        
        trade_event <- TradeEvent(
          symbol = self$symbol,
          venue = self$venue,
          price = px,
          quantity = qty,
          side = side,
          sequence_number = self$sequence
        )
        events[[length(events) + 1]] <- trade_event
      }
      
      return(events)
    }
  )
)
