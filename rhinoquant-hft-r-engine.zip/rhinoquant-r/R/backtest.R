#' Event-Driven Backtesting Engine
#'
#' Event-driven event loop backtester strictly enforcing causal temporal order:
#' Event N -> Strategy sees N -> Strategy decision -> Risk Check -> OMS -> Execution Simulator -> Event N+1.
#' Strictly prevents look-ahead bias.
#'
#' @export
BacktestingEngine <- R6::R6Class(
  "BacktestingEngine",
  
  public = list(
    strategy = NULL,
    risk_engine = NULL,
    oms = NULL,
    portfolio = NULL,
    execution_simulator = NULL,
    order_book = NULL,
    feature_engine = NULL,
    latency_engine = NULL,
    logger = NULL,
    
    events_processed = 0,
    orders_generated = 0,
    orders_rejected = 0,
    fills_executed = 0,
    
    initialize = function(strategy, risk_config = list(), initial_cash = 1000000) {
      self$strategy <- strategy
      self$risk_engine <- RiskEngine$new(config = risk_config)
      self$oms <- OrderManager$new()
      self$portfolio <- Portfolio$new(initial_cash = initial_cash)
      self$execution_simulator <- Simulator$new()
      self$order_book <- OrderBook$new(symbol = strategy$symbol)
      self$feature_engine <- FeatureEngine$new()
      self$latency_engine <- LatencyEngine$new()
      self$logger <- StructuredLogger$new()
    },
    
    #' Run Backtest on Event Stream
    run = function(event_stream) {
      start_wall_time <- Sys.time()
      
      for (evt in event_stream) {
        self$events_processed <- self$events_processed + 1
        t1 <- Sys.time()
        
        # 1. Update Order Book state from Event N
        if (evt$event_type == "QUOTE") {
          self$order_book$update_bid(evt$payload$bid_price, evt$payload$bid_qty)
          self$order_book$update_ask(evt$payload$ask_price, evt$payload$ask_qty)
        } else if (evt$event_type == "BOOK_UPDATE") {
          if (evt$payload$side %in% c("BUY", "BID")) {
            self$order_book$update_bid(evt$payload$price, evt$payload$quantity)
          } else {
            self$order_book$update_ask(evt$payload$price, evt$payload$quantity)
          }
        }
        t2 <- Sys.time()
        
        # 2. Streaming Feature Calculation from Event N
        features <- self$feature_engine$update(evt, self$order_book)
        t3 <- Sys.time()
        
        # Market state snapshot
        market_state <- list(
          symbol = evt$symbol,
          timestamp = evt$exchange_timestamp,
          best_bid = self$order_book$best_bid()["price"],
          best_ask = self$order_book$best_ask()["price"],
          mid = self$order_book$mid(),
          spread = self$order_book$spread()
        )
        
        # 3. Strategy Decision on Event N state
        strategy_orders <- self$strategy$generate_orders(market_state, features, self$portfolio)
        t4 <- Sys.time()
        
        # 4. Process each generated order through Risk, OMS, and Execution Simulator
        for (ord_spec in strategy_orders) {
          self$orders_generated <- self$orders_generated + 1
          
          # Risk Check
          risk_res <- self$risk_engine$validate_order(ord_spec, market_state, self$portfolio)
          t5 <- Sys.time()
          
          if (!risk_res$approved) {
            self$orders_rejected <- self$orders_rejected + 1
            self$logger$log_event("risk_engine", "ORDER_REJECTED", list(
              reason = risk_res$reason,
              details = risk_res$message
            ), level = "WARNING")
            next
          }
          
          # OMS Order Creation
          oms_order <- self$oms$create_order(
            strategy_id = ord_spec$strategy_id,
            symbol = ord_spec$symbol,
            side = ord_spec$side,
            price = ord_spec$price,
            quantity = ord_spec$quantity,
            order_type = if (!is.null(ord_spec$order_type)) ord_spec$order_type else "LIMIT"
          )
          
          # Execution Simulation
          exec_res <- self$execution_simulator$submit_order(oms_order, self$order_book)
          self$oms$process_ack(oms_order$client_order_id, exec_res$exchange_order_id)
          
          # Process Fills
          for (fill in exec_res$fills) {
            self$fills_executed <- self$fills_executed + 1
            self$oms$process_fill(oms_order$client_order_id, fill$fill_qty, fill$fill_price)
            self$portfolio$process_fill(oms_order$symbol, oms_order$side, fill$fill_qty, fill$fill_price, fill$fee)
            self$logger$log_event("oms", "ORDER_FILLED", list(
              order_id = oms_order$client_order_id,
              qty = fill$fill_qty,
              price = fill$fill_price
            ))
          }
          t6 <- Sys.time()
          
          # Record Latency Instrumentation
          self$latency_engine$record(
            md_us = as.numeric(t2 - t1) * 1e6,
            feat_us = as.numeric(t3 - t2) * 1e6,
            strat_us = as.numeric(t4 - t3) * 1e6,
            risk_us = as.numeric(t5 - t4) * 1e6,
            exec_us = as.numeric(t6 - t5) * 1e6
          )
        }
        
        # Mark Portfolio to Market
        if (!is.na(market_state$mid)) {
          prices <- list()
          prices[[self$strategy$symbol]] <- market_state$mid
          self$portfolio$mark_to_market(prices)
        }
      }
      
      end_wall_time <- Sys.time()
      elapsed_s <- as.numeric(end_wall_time - start_wall_time, units = "secs")
      
      # Calculate Analytics & Metrics
      perf <- PerformanceEngine$calculate_metrics(self$portfolio, self$oms)
      latency_summary <- self$latency_engine$summary()
      
      return(list(
        events_processed = self$events_processed,
        orders_generated = self$orders_generated,
        orders_rejected = self$orders_rejected,
        fills_executed = self$fills_executed,
        elapsed_seconds = elapsed_s,
        throughput_eps = self$events_processed / max(0.001, elapsed_s),
        portfolio_summary = self$portfolio$get_summary(),
        performance = perf,
        latency = latency_summary,
        risk_rejections = self$risk_engine$rejection_log
      ))
    }
  )
)
