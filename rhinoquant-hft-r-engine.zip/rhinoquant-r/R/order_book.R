#' Order Book Helper Functions
#'
#' Functional helpers for order book operations and metrics.
#'
#' @export
create_order_book <- function(symbol = "RHINO", venue = "SYNTHETIC") {
  OrderBook$new(symbol = symbol, venue = venue)
}

#' Compute Microprice
#' @export
compute_microprice <- function(bid_px, bid_qty, ask_px, ask_qty) {
  tot <- bid_qty + ask_qty
  if (is.na(tot) || tot == 0) return((bid_px + ask_px) / 2)
  return((ask_px * bid_qty + bid_px * ask_qty) / tot)
}

#' Compute Order Flow Imbalance (OFI)
#' @export
compute_ofi <- function(prev_bid_px, prev_bid_qty, curr_bid_px, curr_bid_qty,
                        prev_ask_px, prev_ask_qty, curr_ask_px, curr_ask_qty) {
  # Bid delta
  delta_bid <- if (curr_bid_px > prev_bid_px) curr_bid_qty
  else if (curr_bid_px == prev_bid_px) curr_bid_qty - prev_bid_qty
  else -prev_bid_qty
  
  # Ask delta
  delta_ask <- if (curr_ask_px < prev_ask_px) curr_ask_qty
  else if (curr_ask_px == prev_ask_px) curr_ask_qty - prev_ask_qty
  else -prev_ask_qty
  
  return(delta_bid - delta_ask)
}
