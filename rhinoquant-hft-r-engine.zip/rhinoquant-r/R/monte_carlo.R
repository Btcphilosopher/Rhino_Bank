#' Monte Carlo Risk & Performance Engine
#'
#' Runs stochastic Monte Carlo simulations over return distributions,
#' slippage uncertainty, execution delays, and market regimes.
#'
#' @export
MonteCarloEngine <- list(
  
  simulate = function(pnl_returns, num_simulations = 500, horizon_steps = 100, seed = 12345) {
    if (!is.null(seed)) set.seed(seed)
    
    mean_ret <- if (length(pnl_returns) > 0) mean(pnl_returns) else 0.0001
    sd_ret <- if (length(pnl_returns) > 1) sd(pnl_returns) else 0.005
    
    sim_paths <- matrix(0, nrow = num_simulations, ncol = horizon_steps)
    
    for (i in 1:num_simulations) {
      shocks <- rnorm(horizon_steps, mean = mean_ret, sd = sd_ret)
      sim_paths[i, ] <- cumsum(shocks)
    }
    
    final_returns <- sim_paths[, horizon_steps]
    quantiles <- quantile(final_returns, probs = c(0.01, 0.05, 0.50, 0.95, 0.99))
    
    list(
      num_simulations = num_simulations,
      horizon_steps = horizon_steps,
      var_95 = as.numeric(-quantiles["5%"]),
      var_99 = as.numeric(-quantiles["1%"]),
      expected_return_p50 = as.numeric(quantiles["50%"]),
      quantiles = quantiles,
      paths_sample = sim_paths[1:min(10, num_simulations), ]
    )
  }
)
