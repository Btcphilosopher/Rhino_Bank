#' Execution Algorithms Module
#'
#' Institutional execution algorithms: TWAP, VWAP, POV, Implementation Shortfall.
#'
#' @export
ExecutionAlgo <- R6::R6Class(
  "ExecutionAlgo",
  
  public = list(
    algo_type = "TWAP", # TWAP, VWAP, POV, IMPLEMENTATION_SHORTFALL
    total_quantity = 1000,
    executed_quantity = 0,
    start_time = NULL,
    end_time = NULL,
    target_duration_s = 300,
    target_pov_rate = 0.1, # 10% of volume
    benchmark_arrival_price = NA_real_,
    
    initialize = function(algo_type = "TWAP", total_quantity = 1000, duration_s = 300, pov_rate = 0.1) {
      self$algo_type <- algo_type
      self$total_quantity <- total_quantity
      self$target_duration_s <- duration_s
      self$target_pov_rate <- pov_rate
      self$start_time <- Sys.time()
      self$end_time <- self$start_time + duration_s
    },
    
    #' Compute Next Slice Size
    get_next_slice = function(market_state, features) {
      remaining_qty <- self$total_quantity - self$executed_quantity
      if (remaining_qty <= 0) return(0)
      
      now <- Sys.time()
      if (is.na(self$benchmark_arrival_price) && !is.null(market_state$mid)) {
        self$benchmark_arrival_price <- market_state$mid
      }
      
      if (self$algo_type == "TWAP") {
        time_elapsed_s <- as.numeric(now - self$start_time, units = "secs")
        time_remaining_s <- max(1, self$target_duration_s - time_elapsed_s)
        n_slices_remaining <- max(1, ceiling(time_remaining_s / 5)) # slice every 5s
        slice <- min(remaining_qty, ceiling(remaining_qty / n_slices_remaining))
        return(slice)
      } else if (self$algo_type == "POV") {
        volume_intensity <- if (!is.null(features$trade_intensity)) features$trade_intensity * 10 else 50
        slice <- min(remaining_qty, max(5, round(volume_intensity * self$target_pov_rate)))
        return(slice)
      } else if (self$algo_type == "IMPLEMENTATION_SHORTFALL") {
        # Accelerate execution if price moves adversely relative to arrival price
        mid <- market_state$mid
        urgency_multiplier <- 1.0
        if (!is.na(self$benchmark_arrival_price) && !is.null(mid)) {
          price_slippage <- (mid - self$benchmark_arrival_price) / self$benchmark_arrival_price
          if (price_slippage > 0.001) urgency_multiplier <- 1.5
        }
        base_slice <- ceiling(remaining_qty / 20)
        return(min(remaining_qty, round(base_slice * urgency_multiplier)))
      }
      return(min(remaining_qty, 10))
    }
  )
)
