#' Strategy Optimisation Engine
#'
#' Provides grid search, random search, and numerical optimization (optim) for
#' strategy parameters across Sharpe ratio, return, and drawdown targets.
#'
#' @export
OptimisationEngine <- list(
  
  #' Grid Search Strategy Optimization
  grid_search = function(strategy_class, event_stream, param_grid, objective = "sharpe") {
    results <- list()
    best_score <- -Inf
    best_params <- NULL
    
    # Expand grid
    grid_df <- expand.grid(param_grid)
    
    for (i in 1:nrow(grid_df)) {
      params <- as.list(grid_df[i, , drop = FALSE])
      strat <- strategy_class$new(strategy_id = sprintf("OPT_%d", i), symbol = "RHINO", parameters = params)
      
      bt <- BacktestingEngine$new(strategy = strat)
      res <- bt$run(event_stream)
      
      score <- if (objective == "sharpe") res$performance$sharpe_ratio
      else if (objective == "net_pnl") res$performance$net_pnl
      else -res$performance$max_drawdown_pct
      
      results[[i]] <- list(
        params = params,
        score = score,
        performance = res$performance
      )
      
      if (score > best_score) {
        best_score <- score
        best_params <- params
      }
    }
    
    return(list(
      best_params = best_params,
      best_score = best_score,
      all_trials = results
    ))
  }
)
