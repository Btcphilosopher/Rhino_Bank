#' Strategy Utilities and Factory
#'
#' Factory functions for creating research strategies.
#'
#' @export
create_market_maker <- function(strategy_id = "MM_ALPHA", symbol = "RHINO", gamma = 0.1, kappa = 1.5, order_size = 10) {
  MarketMakingStrategy$new(
    strategy_id = strategy_id,
    symbol = symbol,
    parameters = list(gamma = gamma, kappa = kappa, order_size = order_size)
  )
}

#' Create Stat Arb Strategy
#' @export
create_stat_arb <- function(strategy_id = "STAT_ARB", symbol = "RHINO", entry_threshold = 2.0, exit_threshold = 0.5) {
  StatArbStrategy$new(
    strategy_id = strategy_id,
    symbol = symbol,
    parameters = list(entry_threshold = entry_threshold, exit_threshold = exit_threshold)
  )
}

#' Create Momentum Strategy
#' @export
create_momentum_strategy <- function(strategy_id = "MOMENTUM", symbol = "RHINO", threshold = 0.001) {
  MomentumStrategy$new(
    strategy_id = strategy_id,
    symbol = symbol,
    parameters = list(momentum_threshold = threshold)
  )
}
