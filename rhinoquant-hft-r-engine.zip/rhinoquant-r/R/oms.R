#' Order Manager OMS Functional Wrapper
#' @export
create_order_manager <- function() {
  OrderManager$new()
}
