#' Latency Simulation Instrumentation Engine
#'
#' Records and computes percentiles (p50, p90, p95, p99, p99.9, max) for simulated
#' pipeline stages. Explicitly labeled as "R SIMULATION LATENCY".
#'
#' @export
LatencyEngine <- R6::R6Class(
  "LatencyEngine",
  
  public = list(
    md_latencies = numeric(0),
    feat_latencies = numeric(0),
    strat_latencies = numeric(0),
    risk_latencies = numeric(0),
    exec_latencies = numeric(0),
    e2e_latencies = numeric(0),
    
    initialize = function() {
      self$reset()
    },
    
    reset = function() {
      self$md_latencies <- numeric(0)
      self$feat_latencies <- numeric(0)
      self$strat_latencies <- numeric(0)
      self$risk_latencies <- numeric(0)
      self$exec_latencies <- numeric(0)
      self$e2e_latencies <- numeric(0)
    },
    
    #' Record Latency Breakdown in Microseconds
    record = function(md_us, feat_us, strat_us, risk_us, exec_us) {
      e2e <- md_us + feat_us + strat_us + risk_us + exec_us
      self$md_latencies <- c(self$md_latencies, md_us)
      self$feat_latencies <- c(self$feat_latencies, feat_us)
      self$strat_latencies <- c(self$strat_latencies, strat_us)
      self$risk_latencies <- c(self$risk_latencies, risk_us)
      self$exec_latencies <- c(self$exec_latencies, exec_us)
      self$e2e_latencies <- c(self$e2e_latencies, e2e)
    },
    
    #' Compute Percentiles Helper
    get_percentiles = function(vec) {
      if (length(vec) == 0) {
        return(list(p50 = 0, p90 = 0, p95 = 0, p99 = 0, p99_9 = 0, max = 0))
      }
      qs <- quantile(vec, probs = c(0.50, 0.90, 0.95, 0.99, 0.999), names = FALSE)
      list(
        p50 = round(qs[1], 2),
        p90 = round(qs[2], 2),
        p95 = round(qs[3], 2),
        p99 = round(qs[4], 2),
        p99_9 = round(qs[5], 2),
        max = round(max(vec), 2)
      )
    },
    
    #' Return Full Summary
    summary = function() {
      list(
        label = "R SIMULATION LATENCY",
        unit = "microseconds (us)",
        disclaimer = "Simulated R execution latency. Does NOT represent live hardware exchange latency.",
        market_data_p50 = self$get_percentiles(self$md_latencies)$p50,
        feature_calc_p50 = self$get_percentiles(self$feat_latencies)$p50,
        strategy_p50 = self$get_percentiles(self$strat_latencies)$p50,
        risk_check_p50 = self$get_percentiles(self$risk_latencies)$p50,
        execution_p50 = self$get_percentiles(self$exec_latencies)$p50,
        e2e_breakdown = list(
          p50 = self$get_percentiles(self$e2e_latencies)$p50,
          p90 = self$get_percentiles(self$e2e_latencies)$p90,
          p95 = self$get_percentiles(self$e2e_latencies)$p95,
          p99 = self$get_percentiles(self$e2e_latencies)$p99,
          p99_9 = self$get_percentiles(self$e2e_latencies)$p99_9,
          max = self$get_percentiles(self$e2e_latencies)$max
        )
      )
    }
  )
)
