#' Structured JSON Logger
#'
#' Machine-readable structured logging format for institutional auditing.
#'
#' @export
StructuredLogger <- R6::R6Class(
  "StructuredLogger",
  
  public = list(
    log_file = NULL,
    logs = list(),
    
    initialize = function(log_file = NULL) {
      self$log_file <- log_file
      self$logs <- list()
    },
    
    log_event = function(component, event_type, payload = list(), level = "INFO") {
      log_entry <- list(
        timestamp = format(Sys.time(), "%Y-%m-%dT%H:%M:%OS3Z"),
        component = component,
        event_type = event_type,
        level = level,
        payload = payload
      )
      self$logs[[length(self$logs) + 1]] <- log_entry
      
      if (!is.null(self$log_file)) {
        json_line <- jsonlite::toJSON(log_entry, auto_unbox = TRUE)
        cat(json_line, "\n", file = self$log_file, append = TRUE)
      }
      return(log_entry)
    }
  )
)
