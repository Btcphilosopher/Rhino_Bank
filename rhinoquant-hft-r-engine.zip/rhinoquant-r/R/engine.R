#' RhinoQuant Engine API & Demo Entrypoint
#'
#' Institutional pure-R quantitative trading, research, backtesting & simulation engine.
#'
#' @export
RhinoQuant <- R6::R6Class(
  "RhinoQuant",
  
  public = list(
    state = "INITIALISING", # INITIALISING, READY, RUNNING, PAUSED, DEGRADED, STOPPING, STOPPED, FAILED
    config = NULL,
    market_data = NULL,
    order_book = NULL,
    feature_engine = NULL,
    alpha_engine = NULL,
    strategy = NULL,
    risk_engine = NULL,
    oms = NULL,
    portfolio = NULL,
    execution_simulator = NULL,
    synthetic_market = NULL,
    logger = NULL,
    
    initialize = function(config_path = NULL) {
      self$state <- "INITIALISING"
      self$logger <- StructuredLogger$new()
      
      self$config <- if (!is.null(config_path) && file.exists(config_path)) {
        ConfigLoader$load_yaml(config_path)
      } else {
        ConfigLoader$validate(list())
      }
      
      self$order_book <- OrderBook$new(symbol = self$config$market$symbol, venue = self$config$market$venue)
      self$feature_engine <- FeatureEngine$new()
      self$alpha_engine <- create_default_alpha_engine()
      self$strategy <- create_market_maker(symbol = self$config$market$symbol)
      self$risk_engine <- RiskEngine$new(config = self$config$risk)
      self$oms <- OrderManager$new()
      self$portfolio <- Portfolio$new()
      self$execution_simulator <- Simulator$new(config = self$config$latency)
      self$synthetic_market <- SyntheticMarket$new(symbol = self$config$market$symbol)
      
      self$state <- "READY"
      self$logger$log_event("engine", "STATE_CHANGED", list(state = "READY"))
    },
    
    #' Health Checks API
    health_check = function() {
      list(
        engine_status = self$state,
        market_data_status = "OK",
        storage_status = "OK",
        risk_status = if (isTRUE(self$risk_engine$kill_switches$global)) "KILL_SWITCH_ACTIVE" else "NORMAL",
        simulation_status = "OK",
        execution_status = "OK",
        timestamp = Sys.time()
      )
    },
    
    #' Run Engine Headless Simulation Loop
    run_simulation = function(ticks = 50, seed = 12345) {
      if (!is.null(seed)) set.seed(seed)
      self$state <- "RUNNING"
      
      event_stream <- list()
      for (i in 1:ticks) {
        batch <- self$synthetic_market$next_tick()
        event_stream <- c(event_stream, batch)
      }
      
      bt <- BacktestingEngine$new(strategy = self$strategy, risk_config = self$config$risk)
      results <- bt$run(event_stream)
      
      self$state <- "READY"
      return(results)
    }
  )
)

#' RhinoQuant Demo Script
#'
#' Runs complete end-to-end synthetic market, order book, features, alpha,
#' strategy, risk, OMS, execution, portfolio, P&L, latency, and analytics pipeline.
#'
#' @export
rhinoquant_demo <- function(ticks = 60, seed = 12345) {
  cat("\n=======================================================\n")
  cat("           RHINOQUANT HFT R ENGINE DEMO                \n")
  cat("=======================================================\n\n")
  
  rq <- RhinoQuant$new()
  cat(sprintf("Environment: %s\n", toupper(rq$config$environment)))
  cat(sprintf("Instrument:  %s\n", rq$config$market$symbol))
  cat(sprintf("Venue:       %s\n\n", rq$config$market$venue))
  
  cat("Running synthetic market simulation...\n")
  res <- rq$run_simulation(ticks = ticks, seed = seed)
  
  cat("\n-------------------- MARKET STATE ---------------------\n")
  bb <- rq$order_book$best_bid()
  ba <- rq$order_book$best_ask()
  m <- rq$order_book$mid()
  sp <- rq$order_book$spread()
  
  cat(sprintf("Best Bid:    %.2f (Qty: %.0f)\n", if (is.na(bb["price"])) 0 else bb["price"], bb["qty"]))
  cat(sprintf("Best Ask:    %.2f (Qty: %.0f)\n", if (is.na(ba["price"])) 0 else ba["price"], ba["qty"]))
  cat(sprintf("Mid Price:   %.2f\n", if (is.na(m)) 0 else m))
  cat(sprintf("Spread:      %.2f\n\n", if (is.na(sp)) 0 else sp))
  
  cat("-------------------- STRATEGY & OMS -------------------\n")
  cat(sprintf("Strategy:    %s (ACTIVE)\n", rq$strategy$strategy_id))
  cat(sprintf("Events:      %d processed\n", res$events_processed))
  cat(sprintf("Submitted:   %d orders\n", res$orders_generated))
  cat(sprintf("Rejected:    %d orders\n", res$orders_rejected))
  cat(sprintf("Filled:      %d fills\n\n", res$fills_executed))
  
  cat("-------------------- RISK ENGINE ----------------------\n")
  health <- rq$health_check()
  cat(sprintf("Risk Status: %s\n", health$risk_status))
  cat(sprintf("Rejections:  %d risk violations logged\n\n", length(res$risk_rejections)))
  
  cat("-------------------- PORTFOLIO & P&L ------------------\n")
  pnl <- res$performance
  cat(sprintf("Inventory:   %.0f shares\n", rq$portfolio$get_position(rq$config$market$symbol)))
  cat(sprintf("Gross P&L:   $%.2f\n", pnl$gross_pnl))
  cat(sprintf("Total Fees:  $%.2f\n", pnl$total_fees))
  cat(sprintf("Net P&L:     $%.2f\n", pnl$net_pnl))
  cat(sprintf("Sharpe:      %.2f\n", pnl$sharpe_ratio))
  cat(sprintf("Max DD:      %.2f%%\n\n", pnl$max_drawdown_pct))
  
  cat("------------------ R SIMULATION LATENCY ---------------\n")
  lat <- res$latency
  cat(sprintf("Market Data p50: %.2f us\n", lat$market_data_p50))
  cat(sprintf("Strategy p50:    %.2f us\n", lat$strategy_p50))
  cat(sprintf("Risk Check p50:  %.2f us\n", lat$risk_check_p50))
  cat(sprintf("End-to-End p99:  %.2f us\n", lat$e2e_breakdown$p99))
  cat("=======================================================\n\n")
  
  return(invisible(res))
}

#' Run testthat test suite
#' @export
run_tests <- function() {
  if (requireNamespace("testthat", quietly = TRUE)) {
    testthat::test_dir("rhinoquant-r/tests/testthat")
  } else {
    cat("testthat package not available.\n")
  }
}

#' Run benchmark suite
#' @export
run_benchmarks <- function() {
  cat("\nRunning RhinoQuant R Engine Benchmarks...\n")
  t1 <- Sys.time()
  rq <- RhinoQuant$new()
  res <- rq$run_simulation(ticks = 100, seed = 12345)
  t2 <- Sys.time()
  dur_s <- as.numeric(t2 - t1, units = "secs")
  cat(sprintf("Processed %d events in %.3f seconds (%.0f events/sec)\n", res$events_processed, dur_s, res$events_processed / dur_s))
  return(res)
}
