#' Configuration Loader Engine
#'
#' Loads and validates system YAML and JSON configuration files.
#'
#' @export
ConfigLoader <- list(
  
  load_yaml = function(file_path) {
    if (!file.exists(file_path)) {
      stop(sprintf("Configuration file not found: %s", file_path))
    }
    cfg <- yaml::read_yaml(file_path)
    return(ConfigLoader$validate(cfg))
  },
  
  validate = function(cfg) {
    if (is.null(cfg$environment)) cfg$environment <- "simulation"
    if (is.null(cfg$market)) cfg$market <- list(symbol = "RHINO", venue = "SYNTHETIC")
    if (is.null(cfg$risk)) {
      cfg$risk <- list(
        max_position = 1000,
        max_order_quantity = 100,
        max_notional = 100000,
        max_daily_loss = 5000
      )
    }
    if (is.null(cfg$latency)) {
      cfg$latency <- list(
        market_data_us = 50,
        strategy_us = 20,
        risk_us = 10,
        network_us = 100,
        exchange_us = 150
      )
    }
    return(cfg)
  }
)
