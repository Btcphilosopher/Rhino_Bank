#' Streaming Feature Engine
#'
#' Incremental streaming feature computation engine calculating microstructure,
#' statistical, and cross-asset features without full dataset recalculation.
#'
#' @export
FeatureEngine <- R6::R6Class(
  "FeatureEngine",
  
  public = list(
    window_size = 50,
    price_history = numeric(0),
    trade_prices = numeric(0),
    trade_volumes = numeric(0),
    prev_bid = c(price = NA, qty = 0),
    prev_ask = c(price = NA, qty = 0),
    
    # EWMA state
    ewma_alpha = 0.1,
    ewma_mean = NA_real_,
    ewma_var = NA_real_,
    
    initialize = function(window_size = 50, ewma_alpha = 0.1) {
      self$window_size <- window_size
      self$ewma_alpha <- ewma_alpha
      self$price_history <- numeric(0)
      self$trade_prices <- numeric(0)
      self$trade_volumes <- numeric(0)
    },
    
    #' Process event incrementally and return updated feature vector
    update = function(event, order_book) {
      bb <- order_book$best_bid()
      ba <- order_book$best_ask()
      mid <- order_book$mid()
      micro <- order_book$microprice()
      spread <- order_book$spread()
      imb <- order_book$imbalance(1)
      
      # Update price history
      if (!is.na(mid)) {
        self$price_history <- c(self$price_history, mid)
        if (length(self$price_history) > self$window_size) {
          self$price_history <- tail(self$price_history, self$window_size)
        }
      }
      
      # Process Trade Event
      if (event$event_type == "TRADE") {
        px <- event$payload$price
        vol <- event$payload$quantity
        self$trade_prices <- c(self$trade_prices, px)
        self$trade_volumes <- c(self$trade_volumes, vol)
        if (length(self$trade_prices) > self$window_size) {
          self$trade_prices <- tail(self$trade_prices, self$window_size)
          self$trade_volumes <- tail(self$trade_volumes, self$window_size)
        }
      }
      
      # Microstructure Features
      ofi <- 0
      if (!is.na(self$prev_bid["price"]) && !is.na(bb["price"])) {
        ofi <- compute_ofi(
          self$prev_bid["price"], self$prev_bid["qty"], bb["price"], bb["qty"],
          self$prev_ask["price"], self$prev_ask["qty"], ba["price"], ba["qty"]
        )
      }
      self$prev_bid <- bb
      self$prev_ask <- ba
      
      # Statistical Features
      roll_mean <- if (length(self$price_history) > 0) mean(self$price_history) else NA_real_
      roll_sd <- if (length(self$price_history) > 2) sd(self$price_history) else 0.01
      z_score <- if (!is.na(mid) && !is.na(roll_mean) && roll_sd > 0) (mid - roll_mean) / roll_sd else 0
      
      # Incremental EWMA
      if (!is.na(mid)) {
        if (is.na(self$ewma_mean)) {
          self$ewma_mean <- mid
          self$ewma_var <- 0
        } else {
          diff <- mid - self$ewma_mean
          self$ewma_mean <- self$ewma_mean + (self$ewma_alpha * diff)
          self$ewma_var <- (1 - self$ewma_alpha) * (self$ewma_var + self$ewma_alpha * (diff^2))
        }
      }
      
      # Realised Volatility
      returns <- if (length(self$price_history) > 1) diff(log(self$price_history)) else 0
      realised_vol <- if (length(returns) > 2) sd(returns) * sqrt(252 * 6.5 * 3600) else 0.01
      
      # Short-term momentum
      st_momentum <- if (length(self$price_history) >= 5) {
        (mid - self$price_history[length(self$price_history) - 4]) / self$price_history[length(self$price_history) - 4]
      } else 0
      
      # VWAP
      vwap <- if (length(self$trade_prices) > 0 && sum(self$trade_volumes) > 0) {
        sum(self$trade_prices * self$trade_volumes) / sum(self$trade_volumes)
      } else mid
      
      features <- list(
        timestamp = Sys.time(),
        mid = mid,
        microprice = micro,
        spread = spread,
        spread_ticks = if (!is.na(spread)) round(spread / 0.01) else NA_integer_,
        imbalance = imb,
        order_flow_imbalance = ofi,
        rolling_mean = roll_mean,
        rolling_sd = roll_sd,
        z_score = z_score,
        ewma_mean = self$ewma_mean,
        ewma_sd = sqrt(max(0, self$ewma_var)),
        realised_volatility = realised_vol,
        short_term_momentum = st_momentum,
        vwap = vwap,
        trade_intensity = length(self$trade_prices)
      )
      
      return(features)
    }
  )
)
