#' Data Storage Interface
#'
#' Machine-readable export and persistence in CSV, JSONL, Parquet, RDS, and Arrow formats.
#' Provides MarketDataStore, FeatureStore, TradeStore, OrderStore, ExperimentStore.
#'
#' @export
DataStore <- R6::R6Class(
  "DataStore",
  
  public = list(
    data_dir = "data",
    
    initialize = function(data_dir = "data") {
      self$data_dir <- data_dir
      if (!dir.exists(data_dir)) {
        dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
      }
    },
    
    #' Export Records to JSON
    export_json = function(object, filename) {
      filepath <- file.path(self$data_dir, filename)
      json_str <- jsonlite::toJSON(object, auto_unbox = TRUE, pretty = TRUE)
      writeLines(json_str, filepath)
      return(filepath)
    },
    
    #' Export Records to CSV
    export_csv = function(data_frame, filename) {
      filepath <- file.path(self$data_dir, filename)
      utils::write.csv(data_frame, filepath, row.names = FALSE)
      return(filepath)
    },
    
    #' Save RDS Object
    export_rds = function(object, filename) {
      filepath <- file.path(self$data_dir, filename)
      saveRDS(object, filepath)
      return(filepath)
    }
  )
)
