#' Risk Engine Functional Wrapper
#' @export
create_risk_engine <- function(config = list()) {
  RiskEngine$new(config = config)
}
