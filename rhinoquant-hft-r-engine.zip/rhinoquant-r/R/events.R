#' Canonical Market Event Model
#'
#' Defines structured canonical event types for high-frequency market data,
#' order book updates, trades, quotes, and instrument state transitions.
#'
#' @export
MarketEvent <- function(event_type = "QUOTE", symbol = "RHINO", venue = "SYNTHETIC",
                        sequence_number = 0, timestamp = Sys.time(), payload = list()) {
  structure(
    list(
      event_id = sprintf("EVT_%d_%09.0f", sequence_number, as.numeric(timestamp) * 1e9),
      event_type = event_type, # QUOTE, TRADE, BOOK_UPDATE, BOOK_SNAPSHOT, AUCTION, INSTRUMENT
      symbol = symbol,
      venue = venue,
      sequence_number = sequence_number,
      exchange_timestamp = as.numeric(timestamp),
      receive_timestamp = as.numeric(Sys.time()),
      payload = payload
    ),
    class = c("MarketEvent", "list")
  )
}

#' Create TradeEvent
#' @export
TradeEvent <- function(symbol = "RHINO", venue = "SYNTHETIC", price, quantity, side = "BUY", sequence_number = 0) {
  MarketEvent(
    event_type = "TRADE",
    symbol = symbol,
    venue = venue,
    sequence_number = sequence_number,
    payload = list(price = price, quantity = quantity, side = side)
  )
}

#' Create QuoteEvent
#' @export
QuoteEvent <- function(symbol = "RHINO", venue = "SYNTHETIC", bid_price, bid_qty, ask_price, ask_qty, sequence_number = 0) {
  MarketEvent(
    event_type = "QUOTE",
    symbol = symbol,
    venue = venue,
    sequence_number = sequence_number,
    payload = list(
      bid_price = bid_price,
      bid_qty = bid_qty,
      ask_price = ask_price,
      ask_qty = ask_qty
    )
  )
}

#' Create BookUpdate
#' @export
BookUpdate <- function(symbol = "RHINO", venue = "SYNTHETIC", side, price, quantity, sequence_number = 0) {
  MarketEvent(
    event_type = "BOOK_UPDATE",
    symbol = symbol,
    venue = venue,
    sequence_number = sequence_number,
    payload = list(side = side, price = price, quantity = quantity)
  )
}

#' Create BookSnapshot
#' @export
BookSnapshot <- function(symbol = "RHINO", venue = "SYNTHETIC", bids, asks, sequence_number = 0) {
  MarketEvent(
    event_type = "BOOK_SNAPSHOT",
    symbol = symbol,
    venue = venue,
    sequence_number = sequence_number,
    payload = list(bids = bids, asks = asks)
  )
}

#' Create InstrumentEvent
#' @export
InstrumentEvent <- function(symbol = "RHINO", venue = "SYNTHETIC", status = "TRADING", sequence_number = 0) {
  MarketEvent(
    event_type = "INSTRUMENT",
    symbol = symbol,
    venue = venue,
    sequence_number = sequence_number,
    payload = list(status = status)
  )
}
