#' Portfolio Functional Wrapper
#' @export
create_portfolio <- function(portfolio_id = "MAIN", initial_cash = 1000000) {
  Portfolio$new(portfolio_id = portfolio_id, initial_cash = initial_cash)
}
