#' Performance & Analytics Engine
#'
#' Institutional performance calculation engine computing Sharpe, Sortino, Max Drawdown,
#' Turnover, Profit Factor, Fill Ratio, Cancel Ratio, and HFT throughput analytics.
#'
#' @export
PerformanceEngine <- list(
  
  calculate_metrics = function(portfolio, oms) {
    history <- portfolio$pnl_history
    if (length(history) == 0) {
      return(list(
        total_return_pct = 0,
        gross_pnl = 0,
        net_pnl = 0,
        sharpe_ratio = 0,
        sortino_ratio = 0,
        max_drawdown = 0,
        volatility = 0,
        turnover = 0,
        hit_rate = 0,
        profit_factor = 0,
        fill_ratio = 0,
        cancel_ratio = 0
      ))
    }
    
    net_pnls <- sapply(history, function(h) h$net_pnl)
    total_equities <- sapply(history, function(h) h$total_equity)
    
    # Returns series
    returns <- diff(total_equities) / head(total_equities, -1)
    returns <- returns[!is.na(returns) & is.finite(returns)]
    
    mean_ret <- if (length(returns) > 0) mean(returns) else 0
    sd_ret <- if (length(returns) > 1) sd(returns) else 0.001
    
    # Sharpe Ratio (annualized assuming 252 days * 6.5h * 3600s)
    annual_factor <- sqrt(252 * 6.5 * 3600)
    sharpe <- if (sd_ret > 0) (mean_ret / sd_ret) * annual_factor else 0
    
    # Sortino Ratio (downside deviation)
    downside_returns <- returns[returns < 0]
    downside_sd <- if (length(downside_returns) > 1) sd(downside_returns) else sd_ret
    sortino <- if (downside_sd > 0) (mean_ret / downside_sd) * annual_factor else 0
    
    # Maximum Drawdown
    cum_max <- cummax(total_equities)
    drawdowns <- (total_equities - cum_max) / cum_max
    max_dd <- abs(min(drawdowns, 0))
    
    # Trade Level Analytics
    trades <- portfolio$trade_history
    trade_pnls <- numeric(0)
    if (length(trades) > 1) {
      # Calculate trade P&L
      for (i in seq_along(trades)) {
        if (i > 1 && !is.null(trades[[i]]$realised_pnl)) {
          diff_pnl <- trades[[i]]$realised_pnl - trades[[i-1]]$realised_pnl
          if (diff_pnl != 0) trade_pnls <- c(trade_pnls, diff_pnl)
        }
      }
    }
    
    wins <- trade_pnls[trade_pnls > 0]
    losses <- trade_pnls[trade_pnls < 0]
    hit_rate <- if (length(trade_pnls) > 0) length(wins) / length(trade_pnls) else 0
    profit_factor <- if (sum(abs(losses)) > 0) sum(wins) / sum(abs(losses)) else if (sum(wins) > 0) 99.0 else 0
    
    # OMS Ratios
    oms_sum <- oms$get_summary()
    fill_ratio <- if (oms_sum$total_submitted > 0) oms_sum$filled / oms_sum$total_submitted else 0
    cancel_ratio <- if (oms_sum$total_submitted > 0) oms_sum$cancelled / oms_sum$total_submitted else 0
    
    return(list(
      total_return_pct = ((tail(total_equities, 1) - portfolio$initial_cash) / portfolio$initial_cash) * 100,
      gross_pnl = portfolio$realised_pnl + portfolio$unrealised_pnl,
      total_fees = portfolio$total_fees,
      net_pnl = portfolio$realised_pnl + portfolio$unrealised_pnl - portfolio$total_fees,
      sharpe_ratio = round(sharpe, 2),
      sortino_ratio = round(sortino, 2),
      max_drawdown_pct = round(max_dd * 100, 2),
      volatility_pct = round(sd_ret * annual_factor * 100, 2),
      trade_count = length(trades),
      hit_rate = round(hit_rate * 100, 1),
      profit_factor = round(profit_factor, 2),
      fill_ratio = round(fill_ratio * 100, 1),
      cancel_ratio = round(cancel_ratio * 100, 1)
    ))
  }
)
