#' Market Data Pipeline Engine
#'
#' Ingestion, validation, normalisation, and streaming dispatch of market data events.
#'
#' @export
MarketDataPipeline <- R6::R6Class(
  "MarketDataPipeline",
  
  public = list(
    data_source = NULL,
    subscribers = list(),
    event_count = 0,
    invalid_event_count = 0,
    
    initialize = function() {
      self$subscribers <- list()
    },
    
    #' Register Event Handler Subscriber
    subscribe = function(handler) {
      self$subscribers[[length(self$subscribers) + 1]] <- handler
    },
    
    #' Process Raw Record
    process_raw = function(raw_record) {
      # 1. Parse
      parsed <- self$parse(raw_record)
      if (is.null(parsed)) {
        self$invalid_event_count <- self$invalid_event_count + 1
        return(NULL)
      }
      
      # 2. Validate
      if (!self$validate(parsed)) {
        self$invalid_event_count <- self$invalid_event_count + 1
        return(NULL)
      }
      
      # 3. Normalise to Canonical MarketEvent
      canonical_evt <- self$normalise(parsed)
      self$event_count <- self$event_count + 1
      
      # 4. Dispatch to subscribers
      for (sub in self$subscribers) {
        sub(canonical_evt)
      }
      return(canonical_evt)
    },
    
    parse = function(raw) {
      if (is.list(raw) && !is.null(raw$type)) return(raw)
      if (is.character(raw)) {
        tryCatch(jsonlite::fromJSON(raw), error = function(e) NULL)
      } else {
        return(raw)
      }
    },
    
    validate = function(parsed) {
      if (is.null(parsed$symbol)) return(FALSE)
      if (!is.null(parsed$price) && parsed$price <= 0) return(FALSE)
      if (!is.null(parsed$quantity) && parsed$quantity < 0) return(FALSE)
      return(TRUE)
    },
    
    normalise = function(parsed) {
      MarketEvent(
        event_type = if (!is.null(parsed$type)) parsed$type else "QUOTE",
        symbol = parsed$symbol,
        venue = if (!is.null(parsed$venue)) parsed$venue else "SYNTHETIC",
        sequence_number = if (!is.null(parsed$seq)) parsed$seq else self$event_count + 1,
        payload = parsed
      )
    }
  )
)
