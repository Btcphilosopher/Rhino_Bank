#' Schemas & Validation Rules
#'
#' Type-checking and structure validation for internal messages and data payloads.
#'
#' @export
EventSchema <- list(
  validate_event = function(event) {
    if (!inherits(event, "MarketEvent")) return(FALSE)
    if (is.null(event$event_type) || !event$event_type %in% c("QUOTE", "TRADE", "BOOK_UPDATE", "BOOK_SNAPSHOT", "AUCTION", "INSTRUMENT")) {
      return(FALSE)
    }
    return(TRUE)
  }
)

OrderSchema <- list(
  validate_order = function(order) {
    if (is.null(order$symbol) || is.null(order$side) || is.null(order$price) || is.null(order$quantity)) {
      return(FALSE)
    }
    if (!order$side %in% c("BUY", "SELL", "BID", "ASK")) return(FALSE)
    if (order$price <= 0 || order$quantity <= 0) return(FALSE)
    return(TRUE)
  }
)
