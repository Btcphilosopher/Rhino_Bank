#' Alpha Engine Framework
#'
#' Evaluates multiple alpha models (Order Flow, Momentum, Mean Reversion,
#' Cross Asset, Volatility, Liquidity), normalises signals, and combines them into expected return vectors.
#'
#' @export
AlphaSignal <- function(direction = 0, confidence = 0.5, expected_return = 0,
                        holding_period_s = 10, risk = 0.01) {
  list(
    direction = direction, # -1 (short), 0 (neutral), +1 (long)
    confidence = min(max(confidence, 0), 1), # 0 to 1
    expected_return = expected_return,
    holding_period_s = holding_period_s,
    risk = risk,
    timestamp = Sys.time()
  )
}

#' AlphaEngine R6 Class
#' @export
AlphaEngine <- R6::R6Class(
  "AlphaEngine",
  
  public = list(
    models = list(),
    weights = numeric(0),
    
    initialize = function() {
      self$models <- list()
      self$weights <- numeric(0)
    },
    
    #' Register Alpha Model
    add_model = function(name, model_fn, weight = 1.0) {
      self$models[[name]] <- model_fn
      self$weights[name] <- weight
    },
    
    #' Evaluate all alpha models & combine signals
    evaluate = function(market_state, features, portfolio) {
      signals <- list()
      weighted_returns <- 0
      tot_weight <- sum(self$weights)
      
      if (tot_weight == 0) tot_weight <- 1.0
      
      for (name in names(self$models)) {
        model_fn <- self$models[[name]]
        sig <- model_fn(market_state, features, portfolio)
        signals[[name]] <- sig
        w <- self$weights[name]
        weighted_returns <- weighted_returns + (sig$expected_return * sig$confidence * w)
      }
      
      combined_exp_return <- weighted_returns / tot_weight
      combined_direction <- if (combined_exp_return > 0.0001) 1 else if (combined_exp_return < -0.0001) -1 else 0
      
      return(list(
        individual_signals = signals,
        combined_signal = AlphaSignal(
          direction = combined_direction,
          confidence = min(1.0, abs(combined_exp_return) * 100),
          expected_return = combined_exp_return
        )
      ))
    }
  )
)

#' Standard Alpha Models Generator
#' @export
create_default_alpha_engine <- function() {
  engine <- AlphaEngine$new()
  
  # 1. Order Flow Alpha
  engine$add_model("OrderFlow", function(market_state, features, portfolio) {
    ofi <- if (!is.null(features$order_flow_imbalance)) features$order_flow_imbalance else 0
    dir <- if (ofi > 5) 1 else if (ofi < -5) -1 else 0
    AlphaSignal(direction = dir, confidence = min(1, abs(ofi) / 20), expected_return = ofi * 0.0001)
  }, weight = 1.2)
  
  # 2. Mean Reversion Alpha
  engine$add_model("MeanReversion", function(market_state, features, portfolio) {
    z <- if (!is.null(features$z_score)) features$z_score else 0
    dir <- if (z > 2.0) -1 else if (z < -2.0) 1 else 0
    AlphaSignal(direction = dir, confidence = min(1, abs(z) / 4.0), expected_return = -z * 0.0002)
  }, weight = 1.0)
  
  # 3. Momentum Alpha
  engine$add_model("Momentum", function(market_state, features, portfolio) {
    mom <- if (!is.null(features$short_term_momentum)) features$short_term_momentum else 0
    dir <- if (mom > 0.0005) 1 else if (mom < -0.0005) -1 else 0
    AlphaSignal(direction = dir, confidence = min(1, abs(mom) * 1000), expected_return = mom * 0.5)
  }, weight = 0.8)
  
  return(engine)
}
