#' Quantitative Statistical Utilities
#'
#' Pure R mathematical and financial statistical functions.
#'
#' @export
compute_returns <- function(prices) {
  if (length(prices) < 2) return(numeric(0))
  diff(prices) / head(prices, -1)
}

#' Compute Log Returns
#' @export
compute_log_returns <- function(prices) {
  if (length(prices) < 2) return(numeric(0))
  diff(log(prices))
}

#' Compute Rolling EWMA
#' @export
compute_ewma <- function(values, lambda = 0.94) {
  n <- length(values)
  if (n == 0) return(numeric(0))
  ewma <- numeric(n)
  ewma[1] <- values[1]
  for (i in 2:n) {
    ewma[i] <- lambda * ewma[i - 1] + (1 - lambda) * values[i]
  }
  return(ewma)
}

#' Compute Z-Score Vector
#' @export
compute_z_score <- function(values) {
  if (length(values) < 2) return(rep(0, length(values)))
  m <- mean(values, na.rm = TRUE)
  s <- sd(values, na.rm = TRUE)
  if (is.na(s) || s == 0) return(rep(0, length(values)))
  return((values - m) / s)
}
