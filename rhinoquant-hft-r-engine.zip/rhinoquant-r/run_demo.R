# Root runner script for RhinoQuant HFT R Engine

r_files <- c(
  "R6/OrderBook.R",
  "R6/Strategy.R",
  "R6/RiskEngine.R",
  "R6/OrderManager.R",
  "R6/Simulator.R",
  "R6/Portfolio.R",
  "R/events.R",
  "R/market_data.R",
  "R/order_book.R",
  "R/features.R",
  "R/alpha.R",
  "R/strategies.R",
  "R/portfolio.R",
  "R/risk.R",
  "R/oms.R",
  "R/execution.R",
  "R/simulator.R",
  "R/analytics.R",
  "R/latency.R",
  "R/optimisation.R",
  "R/monte_carlo.R",
  "R/storage.R",
  "R/logging.R",
  "R/configuration.R",
  "R/schemas.R",
  "R/utilities.R",
  "R/backtest.R",
  "R/engine.R"
)

base_dir <- "rhinoquant-r"

for (f in r_files) {
  p <- file.path(base_dir, f)
  if (file.exists(p)) {
    source(p)
  } else {
    warning(paste("File missing:", p))
  }
}

# Execute synthetic demo
res <- rhinoquant_demo(ticks = 50, seed = 12345)
