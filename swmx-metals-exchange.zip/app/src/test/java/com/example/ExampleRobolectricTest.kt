package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.swmx.data.SWMXDataRepository
import com.example.swmx.model.OrderSide
import com.example.swmx.model.OrderType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read app name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("SWMX Metals Exchange", appName)
  }

  @Test
  fun `repository initialization and order matching verification`() {
    val repo = SWMXDataRepository()
    assertTrue(repo.instruments.value.isNotEmpty())
    val tin = repo.instruments.value.find { it.symbol == "SWXSN" }
    assertNotNull(tin)

    val (order, trade) = repo.submitOrder(
      symbol = "SWXSN",
      side = OrderSide.BUY,
      orderType = OrderType.LIMIT,
      quantityDmt = 10.0,
      priceGbp = 24850.0,
      idempotencyKey = "TEST-IDEM-001"
    )
    assertNotNull(order)
    assertNotNull(trade)
    assertEquals(10.0, order.quantityDmt, 0.01)
    assertEquals(24850.0, order.priceGbp, 0.01)
  }

  @Test
  fun `contained metal engine test`() {
    val repo = SWMXDataRepository()
    val calc = repo.calculateContainedMetal(
      wetWeight = 250.0,
      moisturePct = 8.0,
      gradePct = 24.0,
      referencePriceGbp = 8000.0
    )
    assertEquals(230.0, calc.dryWeightTonnes, 0.01)
    assertEquals(55.2, calc.containedMetalTonnes, 0.01)
    assertTrue(calc.netSettlementValueGbp > 0)
  }
}
