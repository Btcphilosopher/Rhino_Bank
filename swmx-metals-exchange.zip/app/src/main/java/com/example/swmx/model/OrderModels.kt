package com.example.swmx.model

enum class OrderSide {
    BUY, SELL
}

enum class OrderType(val label: String, val description: String) {
    LIMIT("Limit", "Resting order executed at specified price or better"),
    MARKET("Market", "Execute immediately against best available liquidity"),
    ICEBERG("Iceberg", "Disclose only a fraction of total lot volume"),
    FILL_OR_KILL("FOK", "Fill entire lot quantity immediately or cancel"),
    IMMEDIATE_OR_CANCEL("IOC", "Fill immediately any available portion; cancel rest"),
    GOOD_TILL_CANCELLED("GTC", "Rest in order book until filled or cancelled"),
    GOOD_TILL_DATE("GTD", "Rest until specified delivery window cutoff"),
    ALL_OR_NONE("AON", "Fill complete lot without partial executions"),
    RFQ("RFQ", "Request bilateral customized quote for physical lot"),
    NEGOTIATED_PHYSICAL("Negotiated Physical", "Direct bilateral contract execution"),
    AUCTION("Auction", "Periodic physical lot call auction"),
    TENDER("Tender", "Formal procurement tender with sealed bids")
}

enum class OrderStatus {
    NEW,
    PARTIALLY_FILLED,
    FILLED,
    CANCELLED,
    REJECTED
}

data class Order(
    val orderId: String,
    val symbol: String,
    val side: OrderSide,
    val orderType: OrderType,
    val quantityDmt: Double,
    val displayQuantityDmt: Double? = null,
    val priceGbp: Double,
    val filledQuantityDmt: Double = 0.0,
    val status: OrderStatus = OrderStatus.NEW,
    val idempotencyKey: String,
    val participantId: String,
    val participantName: String,
    val incoterm: String = "FCA Warehouse Tamar",
    val deliveryLocation: String = "Tamar Valley Minerals Hub",
    val timestamp: String,
    val executionNotes: String = ""
)

data class OrderBookLevel(
    val priceGbp: Double,
    val quantityDmt: Double,
    val lotCount: Int,
    val cumulativeDmt: Double,
    val depthPct: Double // 0.0 to 1.0 for depth visual
)

data class OrderBook(
    val symbol: String,
    val bids: List<OrderBookLevel>,
    val offers: List<OrderBookLevel>,
    val bestBidGbp: Double,
    val bestOfferGbp: Double,
    val spreadGbp: Double,
    val spreadPct: Double,
    val midGbp: Double,
    val vwapGbp: Double,
    val dayHighGbp: Double,
    val dayLowGbp: Double,
    val openGbp: Double,
    val settlementPriceGbp: Double,
    val timestamp: String
)

data class Trade(
    val tradeId: String,
    val symbol: String,
    val priceGbp: Double,
    val quantityDmt: Double,
    val side: OrderSide,
    val buyer: String,
    val seller: String,
    val lotId: String?,
    val timestamp: String,
    val deliveryTerms: String = "FCA Tamar Valley Depository",
    val settlementStatus: String = "TRADE_EXECUTED"
)

data class QuoteResponse(
    val quoteId: String,
    val rfqId: String,
    val sellerName: String,
    val priceGbpPerDmt: Double,
    val offeredQuantityDmt: Double,
    val gradeSummary: String,
    val deliveryWindowDays: Int,
    val warehouseLocation: String,
    val incoterm: String,
    val paymentTerms: String = "CAD (Cash Against Documents) 5 Business Days",
    val validityMinutes: Int = 60,
    val accepted: Boolean = false,
    val timestamp: String
)

data class RFQ(
    val rfqId: String, // SWMX-RFQ-2026-00341
    val buyerName: String,
    val symbol: String,
    val commodity: String,
    val requestedQuantityDmt: Double,
    val gradeSpec: String, // "Cu >= 24.5%, As <= 0.15%, Moisture <= 8.5%"
    val deliveryLocation: String,
    val deliveryWindow: String, // "14-28 Days"
    val incoterm: String = "DAP Plymouth Industrial Dock",
    val quotes: List<QuoteResponse> = emptyList(),
    val status: String, // "OPEN", "QUOTED", "ACCEPTED", "CONTRACTED", "EXPIRED"
    val contractId: String? = null,
    val createdAt: String
)

data class PhysicalContract(
    val contractId: String, // SWMX-CTR-2026-00912
    val rfqOrOrderId: String,
    val symbol: String,
    val commodity: String,
    val buyer: String,
    val seller: String,
    val lotId: String,
    val quantityDmt: Double,
    val priceGbpPerDmt: Double,
    val totalValueGbp: Double,
    val incoterm: String,
    val warehouse: String,
    val executionDate: String,
    val deliveryDeadline: String,
    val assayClause: String = "Referee: Wardell Armstrong / Cornish Assay Office if delta > 0.25%",
    val currentStage: DeliveryStage,
    val settled: Boolean = false
)

enum class DeliveryStage(val stageNumber: Int, val title: String, val description: String) {
    TRADE_EXECUTED(1, "TRADE EXECUTED", "Electronic match recorded on SWMX ledger"),
    CONTRACT_CREATED(2, "CONTRACT CREATED", "Bilateral spot purchase & sale terms locked"),
    LOT_ALLOCATED(3, "LOT ALLOCATED", "Physical stock reserved in certified depository"),
    DELIVERY_BOOKED(4, "DELIVERY BOOKED", "Transport slot & haulier credentials approved"),
    MATERIAL_DISPATCHED(5, "DISPATCHED", "Vehicle loaded and departed from warehouse gate"),
    MATERIAL_RECEIVED(6, "RECEIVED", "Consignment arrived at buyer receiving terminal"),
    WEIGHT_VERIFIED(7, "WEIGHT VERIFIED", "Gross & Tare weighbridge certificate logged"),
    ASSAY_VERIFIED(8, "ASSAY VERIFIED", "Composite moisture & XRF/ICP grade confirmed"),
    INVOICE_CREATED(9, "INVOICE CREATED", "Contained metal & TC/RC commercial invoice issued"),
    PAYMENT_CONFIRMED(10, "PAYMENT CONFIRMED", "RTGS / Sterling funds escrow released"),
    SETTLED(11, "SETTLED", "Final title transfer complete, warehouse receipt updated")
}

data class DeliveryEvent(
    val eventId: String,
    val timestamp: String,
    val stage: DeliveryStage,
    val location: String,
    val actor: String,
    val signatureHash: String,
    val notes: String
)

data class DeliveryTracker(
    val deliveryId: String, // SWMX-DEL-2026-00192
    val contractId: String,
    val lotId: String,
    val carrier: String,
    val vehicleReg: String,
    val origin: String,
    val destination: String,
    val currentStage: DeliveryStage,
    val eta: String,
    val events: List<DeliveryEvent>
)
