package com.example.swmx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.swmx.model.*
import com.example.swmx.ui.components.*
import com.example.swmx.viewmodel.SWMXViewModel
import com.example.ui.theme.*

@Composable
fun SpotBoardScreen(
    viewModel: SWMXViewModel,
    modifier: Modifier = Modifier
) {
    val instruments by viewModel.instruments.collectAsState()
    val filteredInstruments by viewModel.filteredInstruments.collectAsState()
    val selectedInstrument by viewModel.selectedInstrument.collectAsState()
    val selectedSymbol by viewModel.selectedSymbol.collectAsState()
    val orderBook by viewModel.currentOrderBook.collectAsState()
    val trades by viewModel.currentTrades.collectAsState()
    val basis by viewModel.currentBasis.collectAsState()
    val curve by viewModel.currentCurve.collectAsState()
    val statusFilter by viewModel.selectedStatusFilter.collectAsState()

    var showOrderDialog by remember { mutableStateOf(false) }
    var showRfqDialog by remember { mutableStateOf(false) }
    var selectedOrderPrice by remember { mutableStateOf(8240.0) }

    if (showOrderDialog && selectedInstrument != null) {
        QuickOrderDialog(
            symbol = selectedSymbol,
            initialPrice = selectedOrderPrice,
            onDismiss = { showOrderDialog = false },
            onSubmit = { side, type, qty, price, displayQty ->
                viewModel.submitOrder(selectedSymbol, side, type, qty, price, displayQty)
            }
        )
    }

    if (showRfqDialog && selectedInstrument != null) {
        QuickRfqDialog(
            symbol = selectedSymbol,
            commodityName = selectedInstrument!!.commodity,
            onDismiss = { showRfqDialog = false },
            onSubmit = { buyer, sym, comm, qty, spec, loc, win, incoterm ->
                viewModel.submitRfq(buyer, sym, comm, qty, spec, loc, win, incoterm)
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            // Market Status Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = if (statusFilter == null) CornishAmber else TerminalSurfaceElevated,
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (statusFilter == null) CornishAmber else TerminalSurfaceBorder),
                    modifier = Modifier.clickable { viewModel.setStatusFilter(null) }
                ) {
                    Text(
                        text = "ALL MARKETS",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (statusFilter == null) Color.Black else TextSecondary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }

                listOf(
                    MarketStatus.ACTIVE,
                    MarketStatus.DEVELOPMENT,
                    MarketStatus.RECYCLING,
                    MarketStatus.EXPLORATION,
                    MarketStatus.HISTORICAL
                ).forEach { status ->
                    val isSelected = statusFilter == status
                    Surface(
                        color = if (isSelected) CornishAmber else TerminalSurfaceElevated,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) CornishAmber else TerminalSurfaceBorder),
                        modifier = Modifier.clickable { viewModel.setStatusFilter(status) }
                    ) {
                        Text(
                            text = status.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) Color.Black else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }

        // Ticker Carousel / Horizontal Ticker Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                instruments.forEach { inst ->
                    val isSelected = inst.symbol == selectedSymbol
                    Surface(
                        color = if (isSelected) TerminalSurfaceElevated else TerminalSurface,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) CornishAmber else TerminalSurfaceBorder
                        ),
                        modifier = Modifier
                            .width(160.dp)
                            .clickable { viewModel.selectInstrument(inst.symbol) }
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = inst.symbol,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) CornishAmberBright else TextPrimary
                                )
                                MarketStatusBadge(status = inst.marketStatus)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "£${String.format("%,.0f", inst.lastPriceGbp)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${if (inst.changePct24h >= 0) "+" else ""}${inst.changePct24h}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (inst.changePct24h >= 0) MarketGreenBright else MarketRedBright,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${inst.volume24hDmt.toInt()} ${inst.lotUnit.symbol}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Active Instrument Spotlight Card
        if (selectedInstrument != null) {
            val inst = selectedInstrument!!
            item {
                Surface(
                    color = TerminalSurface,
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = inst.symbol,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = CornishAmberBright
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    MarketStatusBadge(status = inst.marketStatus)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    CommodityGroupBadge(group = inst.commodityGroup)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = inst.commodity,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "${inst.region} • Form: ${inst.physicalForm.label}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "£${String.format("%,.0f", inst.lastPriceGbp)}",
                                    style = MaterialTheme.typography.displayMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${inst.priceUnit} (${if (inst.changePct24h >= 0) "+" else ""}${inst.changePct24h}%)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (inst.changePct24h >= 0) MarketGreenBright else MarketRedBright,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = TerminalSurfaceBorder, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Benchmark Reference & Inventory Readout
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("BENCHMARK REF", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text(inst.benchmarkReference, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("AVAILABLE INVENTORY", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("${inst.totalAvailableInventoryDmt.toInt()} DMT (${inst.activeLotsCount} Lots)", style = MaterialTheme.typography.labelSmall, color = TamarCyanBright, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Fast Action Buttons (Order / RFQ)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    selectedOrderPrice = inst.lastPriceGbp
                                    showOrderDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MarketGreen),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("open_order_dialog_button")
                            ) {
                                Icon(Icons.Default.AddShoppingCart, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("PLACE ORDER", color = Color.Black, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            }

                            Button(
                                onClick = { showRfqDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = CornishAmber),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("open_rfq_dialog_button")
                            ) {
                                Icon(Icons.Default.RequestQuote, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("LAUNCH RFQ", color = Color.Black, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Level-2 Order Book
        item {
            SectionHeader(
                title = "Order Book & Market Depth",
                badgeText = selectedSymbol
            )
            OrderBookLadderView(
                orderBook = orderBook,
                onPriceClick = { price ->
                    selectedOrderPrice = price
                    showOrderDialog = true
                }
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Regional Basis Decomposition Tree
        if (basis != null) {
            item {
                SectionHeader(
                    title = "South West Basis & Pricing Tree",
                    badgeText = "INDEPENDENTLY AUDITABLE"
                )
                Surface(
                    color = TerminalSurface,
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Global Reference (LME/European):", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("£${String.format("%,.0f", basis!!.globalReferencePriceGbp)}/t", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("+ South West Regional Premium (Basis):", style = MaterialTheme.typography.bodySmall, color = CornishAmber)
                            Text("+£${basis!!.southWestBasisPremiumGbp.toInt()}/t", style = MaterialTheme.typography.labelMedium, color = CornishAmberBright, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("+ Local Haulage & Freight (Tamar corridor):", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("+£${basis!!.freightAdjustmentGbp.toInt()}/t", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("± Grade & Moisture Adjustment:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("${if (basis!!.gradeAdjustmentGbp >= 0) "+" else ""}£${basis!!.gradeAdjustmentGbp.toInt()}/t", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("- Smelter TC/RC Treatment Deductions:", style = MaterialTheme.typography.bodySmall, color = MarketRedBright)
                            Text("${basis!!.tcRcAdjustmentGbp.toInt()} £/t", style = MaterialTheme.typography.labelMedium, color = MarketRedBright)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("+ Vault Storage & Insurance Escrow:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("+£${basis!!.warehouseInsuranceGbp.toInt()}/t", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Divider(color = TerminalSurfaceBorder, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Indicative SWMX Physical Price:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("£${String.format("%,.0f", basis!!.indicativeSwmxPhysicalPriceGbp)}/t DMT", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TamarCyanBright)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Forward Price Curve (Simulated)
        if (curve.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Spot & Forward Delivery Curve",
                    badgeText = "SIMULATED"
                )
                Surface(
                    color = TerminalSurface,
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TENOR", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.weight(1f))
                            Text("DAYS", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.weight(0.8f))
                            Text("PRICE (£/t)", style = MaterialTheme.typography.labelSmall, color = TextPrimary, modifier = Modifier.weight(1.2f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            Text("BASIS", style = MaterialTheme.typography.labelSmall, color = CornishAmber, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            Text("STATUS", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.weight(1.2f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        }
                        Divider(color = TerminalSurfaceBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                        curve.forEach { point ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(point.tenor, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextCode, modifier = Modifier.weight(1f))
                                Text("${point.daysToDelivery}d", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.weight(0.8f))
                                Text("£${point.priceGbp.toInt()}", style = MaterialTheme.typography.labelMedium, color = TextPrimary, modifier = Modifier.weight(1.2f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Text("${if (point.basisGbp >= 0) "+" else ""}£${point.basisGbp.toInt()}", style = MaterialTheme.typography.labelSmall, color = CornishAmberBright, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Surface(
                                    color = if (point.simulated) TerminalSurfaceElevated else MarketGreenBg,
                                    shape = RoundedCornerShape(3.dp),
                                    modifier = Modifier.weight(1.2f)
                                ) {
                                    Text(
                                        text = if (point.simulated) "SIMULATED" else "SPOT",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        color = if (point.simulated) TextMuted else MarketGreenBright,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Live Physical Trades Tape
        item {
            SectionHeader(
                title = "Physical Spot Transactions Tape",
                badgeText = "${trades.size} TRADES"
            )
        }

        items(trades) { trade ->
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(trade.tradeId, style = MaterialTheme.typography.labelSmall, color = TextCode)
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = if (trade.side == OrderSide.BUY) MarketGreenBg else MarketRedBg,
                                shape = RoundedCornerShape(3.dp)
                            ) {
                                Text(
                                    text = trade.side.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (trade.side == OrderSide.BUY) MarketGreenBright else MarketRedBright,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text("£${String.format("%,.0f", trade.priceGbp)}/t (${trade.quantityDmt} DMT)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${trade.buyer} ⇄ ${trade.seller}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 1)
                        Text(trade.timestamp.takeLast(8), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                    Text(trade.deliveryTerms, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
