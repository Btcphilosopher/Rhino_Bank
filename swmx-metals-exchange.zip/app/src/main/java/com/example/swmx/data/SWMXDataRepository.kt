package com.example.swmx.data

import com.example.swmx.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class SWMXDataRepository {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK)
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.UK).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    // --- State Holders ---
    private val _instruments = MutableStateFlow<List<Instrument>>(emptyList())
    val instruments: StateFlow<List<Instrument>> = _instruments.asStateFlow()

    private val _selectedInstrumentSymbol = MutableStateFlow("SWXSN")
    val selectedInstrumentSymbol: StateFlow<String> = _selectedInstrumentSymbol.asStateFlow()

    private val _orderBooks = MutableStateFlow<Map<String, OrderBook>>(emptyMap())
    val orderBooks: StateFlow<Map<String, OrderBook>> = _orderBooks.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _lots = MutableStateFlow<List<PhysicalLot>>(emptyList())
    val lots: StateFlow<List<PhysicalLot>> = _lots.asStateFlow()

    private val _warehouses = MutableStateFlow<List<Warehouse>>(emptyList())
    val warehouses: StateFlow<List<Warehouse>> = _warehouses.asStateFlow()

    private val _warehouseReceipts = MutableStateFlow<List<WarehouseReceipt>>(emptyList())
    val warehouseReceipts: StateFlow<List<WarehouseReceipt>> = _warehouseReceipts.asStateFlow()

    private val _inventoryLedger = MutableStateFlow<List<InventoryLedgerEntry>>(emptyList())
    val inventoryLedger: StateFlow<List<InventoryLedgerEntry>> = _inventoryLedger.asStateFlow()

    private val _rfqs = MutableStateFlow<List<RFQ>>(emptyList())
    val rfqs: StateFlow<List<RFQ>> = _rfqs.asStateFlow()

    private val _contracts = MutableStateFlow<List<PhysicalContract>>(emptyList())
    val contracts: StateFlow<List<PhysicalContract>> = _contracts.asStateFlow()

    private val _deliveries = MutableStateFlow<List<DeliveryTracker>>(emptyList())
    val deliveries: StateFlow<List<DeliveryTracker>> = _deliveries.asStateFlow()

    private val _regionalAssets = MutableStateFlow<List<RegionalAsset>>(emptyList())
    val regionalAssets: StateFlow<List<RegionalAsset>> = _regionalAssets.asStateFlow()

    private val _disputes = MutableStateFlow<List<AssayDispute>>(emptyList())
    val disputes: StateFlow<List<AssayDispute>> = _disputes.asStateFlow()

    private val _fixMessages = MutableStateFlow<List<FIXMessage>>(emptyList())
    val fixMessages: StateFlow<List<FIXMessage>> = _fixMessages.asStateFlow()

    private val _userOrders = MutableStateFlow<List<Order>>(emptyList())
    val userOrders: StateFlow<List<Order>> = _userOrders.asStateFlow()

    private val _apiKeys = MutableStateFlow<List<ApiKeyInfo>>(emptyList())
    val apiKeys: StateFlow<List<ApiKeyInfo>> = _apiKeys.asStateFlow()

    init {
        initializeSeedData()
    }

    private fun now(): String = dateFormat.format(Date())
    private fun nowIso(): String = isoFormat.format(Date())

    private fun initializeSeedData() {
        val initialInstruments = listOf(
            Instrument(
                instrumentId = "SWMX-SN-99.85-GB-CW-001",
                symbol = "SWXSN",
                commodity = "Cornish Tin (Refined 99.85% / Concentrate)",
                commodityGroup = CommodityGroup.BASE_METALS,
                marketStatus = MarketStatus.DEVELOPMENT,
                region = "Cornwall (Camborne-Pool-Redruth)",
                physicalForm = PhysicalForm.INGOT,
                minimumLot = 5.0,
                lotUnit = WeightUnit.DMT,
                priceUnit = "£/t DMT",
                currency = "GBP",
                deliverable = true,
                assayRequired = true,
                warehouseEligible = true,
                lastPriceGbp = 24850.0,
                changePct24h = +1.85,
                dayHighGbp = 25100.0,
                dayLowGbp = 24620.0,
                vwapGbp = 24810.0,
                volume24hDmt = 145.0,
                turnoverGbp = 3597450.0,
                activeLotsCount = 6,
                totalAvailableInventoryDmt = 340.0,
                benchmarkReference = "LME Tin Cash (GBP eq) + £320 SW Regional Premium",
                description = "High-purity South West tin ingots and cassiterite concentrate from Cornish lodes. Historic benchmark with active modern feasibility delivery tracks.",
                defaultAssayGrade = "Sn 99.85% | Fe 0.015% | As 0.008% | Bi 0.004%"
            ),
            Instrument(
                instrumentId = "SWMX-CU-24.8-GB-TAM-002",
                symbol = "SWXCU",
                commodity = "South West Copper Concentrate (Cu 24-26%)",
                commodityGroup = CommodityGroup.CONCENTRATES,
                marketStatus = MarketStatus.DEVELOPMENT,
                region = "Tamar Valley & West Devon",
                physicalForm = PhysicalForm.CONCENTRATE,
                minimumLot = 20.0,
                lotUnit = WeightUnit.DMT,
                priceUnit = "£/t DMT",
                currency = "GBP",
                deliverable = true,
                assayRequired = true,
                warehouseEligible = true,
                lastPriceGbp = 8240.0,
                changePct24h = -0.45,
                dayHighGbp = 8320.0,
                dayLowGbp = 8180.0,
                vwapGbp = 8235.0,
                volume24hDmt = 480.0,
                turnoverGbp = 3952800.0,
                activeLotsCount = 8,
                totalAvailableInventoryDmt = 1120.0,
                benchmarkReference = "LME Copper Grade A minus TC/RC plus Tamar Low-Carbon Premium",
                description = "Flotation chalcopyrite concentrate produced in the Tamar mineral belt. Low impurity penalty with silver and gold payable credits.",
                defaultAssayGrade = "Cu 24.8% | Ag 42 g/t | Au 1.7 g/t | As 0.12% | Moisture 8.4%"
            ),
            Instrument(
                instrumentId = "SWMX-WO3-62.2-GB-DEV-003",
                symbol = "SWXW",
                commodity = "Tungsten Wolframite Concentrate (WO3 62%)",
                commodityGroup = CommodityGroup.CRITICAL_MINERALS,
                marketStatus = MarketStatus.DEVELOPMENT,
                region = "West Devon / Hemerdon Basin",
                physicalForm = PhysicalForm.CONCENTRATE,
                minimumLot = 10.0,
                lotUnit = WeightUnit.DMT,
                priceUnit = "£/mtu WO3",
                currency = "GBP",
                deliverable = true,
                assayRequired = true,
                warehouseEligible = true,
                lastPriceGbp = 27850.0,
                changePct24h = +2.40,
                dayHighGbp = 28100.0,
                dayLowGbp = 27400.0,
                vwapGbp = 27790.0,
                volume24hDmt = 85.0,
                turnoverGbp = 2362150.0,
                activeLotsCount = 4,
                totalAvailableInventoryDmt = 210.0,
                benchmarkReference = "European APT Ref (GBP eq) + UK Strategic Reserve Basis",
                description = "Critical mineral tungsten concentrate from Hemerdon sheeted vein complex. High grade WO3 for hard-metal tooling and defense supply chains.",
                defaultAssayGrade = "WO3 62.4% | Sn 0.12% | As 0.03% | Mo 0.01% | Moisture 3.4%"
            ),
            Instrument(
                instrumentId = "SWMX-RCU-99.2-GB-PLY-004",
                symbol = "SWX-RCU",
                commodity = "Secondary Recycled Copper (No.1 Granules/Chops)",
                commodityGroup = CommodityGroup.SECONDARY_RECYCLED,
                marketStatus = MarketStatus.RECYCLING,
                region = "Plymouth & Falmouth Depots",
                physicalForm = PhysicalForm.GRANULES,
                minimumLot = 10.0,
                lotUnit = WeightUnit.DMT,
                priceUnit = "£/t DMT",
                currency = "GBP",
                deliverable = true,
                assayRequired = true,
                warehouseEligible = true,
                lastPriceGbp = 7690.0,
                changePct24h = +0.65,
                dayHighGbp = 7740.0,
                dayLowGbp = 7620.0,
                vwapGbp = 7680.0,
                volume24hDmt = 260.0,
                turnoverGbp = 1999400.0,
                activeLotsCount = 5,
                totalAvailableInventoryDmt = 450.0,
                benchmarkReference = "LME Copper - 7% Scrap Recycler Discount",
                description = "Circular economy secondary copper recovered from industrial infrastructure across the South West. Zero-scope-1 smelting feedstock.",
                defaultAssayGrade = "Cu 99.2% | Pb 0.04% | Fe 0.02% | Sn 0.03%"
            ),
            Instrument(
                instrumentId = "SWMX-PB-78.2-GB-DEV-005",
                symbol = "SWXPB",
                commodity = "South West Refined Lead & Galena Concentrate",
                commodityGroup = CommodityGroup.BASE_METALS,
                marketStatus = MarketStatus.HISTORICAL,
                region = "Tamar Valley & Bere Alston",
                physicalForm = PhysicalForm.CONCENTRATE,
                minimumLot = 25.0,
                lotUnit = WeightUnit.DMT,
                priceUnit = "£/t DMT",
                currency = "GBP",
                deliverable = false,
                assayRequired = true,
                warehouseEligible = false,
                lastPriceGbp = 1780.0,
                changePct24h = +0.20,
                dayHighGbp = 1795.0,
                dayLowGbp = 1770.0,
                vwapGbp = 1782.0,
                volume24hDmt = 45.0,
                turnoverGbp = 80190.0,
                activeLotsCount = 1,
                totalAvailableInventoryDmt = 30.0,
                benchmarkReference = "LME Lead Cash Historical Benchmark",
                description = "Historical reference series representing the high-silver lead ores of Bere Alston and Tamar mines with modern indicative pricing.",
                defaultAssayGrade = "Pb 78.2% | Ag 1,240 g/t | Sb 0.4% | Zn 1.1%"
            ),
            Instrument(
                instrumentId = "SWMX-AG-840-GB-CW-006",
                symbol = "SWXAG",
                commodity = "Cornish Native & By-product Silver Doré",
                commodityGroup = CommodityGroup.PRECIOUS_METALS,
                marketStatus = MarketStatus.HISTORICAL,
                region = "Herodsfoot / Gwinear / St Just",
                physicalForm = PhysicalForm.DORE,
                minimumLot = 0.5,
                lotUnit = WeightUnit.TOZ,
                priceUnit = "£/oz tr",
                currency = "GBP",
                deliverable = true,
                assayRequired = true,
                warehouseEligible = true,
                lastPriceGbp = 25.40,
                changePct24h = +1.15,
                dayHighGbp = 25.85,
                dayLowGbp = 25.10,
                vwapGbp = 25.35,
                volume24hDmt = 12.0,
                turnoverGbp = 304800.0,
                activeLotsCount = 2,
                totalAvailableInventoryDmt = 15.0,
                benchmarkReference = "LBMA Silver Benchmark + Cornish Provenance Stamp",
                description = "Precious silver doré recovered as by-product from South West polymetallic mineral veins with certified assay hallmarking.",
                defaultAssayGrade = "Ag 84.5% | Au 2.1% | Pb 8.2% | Cu 4.2%"
            ),
            Instrument(
                instrumentId = "SWMX-AS-98.5-GB-DEV-007",
                symbol = "SWXAS",
                commodity = "South West Refined White Arsenic (As2O3)",
                commodityGroup = CommodityGroup.INDUSTRIAL_MINERALS,
                marketStatus = MarketStatus.HISTORICAL,
                region = "Devon Great Consols / Tamar",
                physicalForm = PhysicalForm.OXIDE,
                minimumLot = 10.0,
                lotUnit = WeightUnit.DMT,
                priceUnit = "£/t DMT",
                currency = "GBP",
                deliverable = false,
                assayRequired = true,
                warehouseEligible = false,
                lastPriceGbp = 2150.0,
                changePct24h = 0.0,
                dayHighGbp = 2150.0,
                dayLowGbp = 2150.0,
                vwapGbp = 2150.0,
                volume24hDmt = 0.0,
                turnoverGbp = 0.0,
                activeLotsCount = 0,
                totalAvailableInventoryDmt = 0.0,
                benchmarkReference = "Industrial Chemical Benchmark (Historical Model)",
                description = "Historical benchmark series. Devon Great Consols produced over 50% of the world's arsenic in the late 19th century. Preserved for provenance analytics.",
                defaultAssayGrade = "As2O3 98.6% | Fe 0.15% | S 0.08%"
            ),
            Instrument(
                instrumentId = "SWMX-LI-1.4-GB-CW-008",
                symbol = "SWXLI",
                commodity = "Cornish Geothermal / Mica Lithium Concentrate",
                commodityGroup = CommodityGroup.CRITICAL_MINERALS,
                marketStatus = MarketStatus.EXPLORATION,
                region = "St Austell & United Downs",
                physicalForm = PhysicalForm.CONCENTRATE,
                minimumLot = 25.0,
                lotUnit = WeightUnit.DMT,
                priceUnit = "£/t DMT (6% Li2O eq)",
                currency = "GBP",
                deliverable = false,
                assayRequired = true,
                warehouseEligible = false,
                lastPriceGbp = 890.0,
                changePct24h = +3.10,
                dayHighGbp = 915.0,
                dayLowGbp = 870.0,
                vwapGbp = 888.0,
                volume24hDmt = 60.0,
                turnoverGbp = 53400.0,
                activeLotsCount = 1,
                totalAvailableInventoryDmt = 50.0,
                benchmarkReference = "Fastmarkets Spodumene 6% CIF Europe (GBP eq)",
                description = "Next-generation green transition mineral from Cornish granite mica and geothermal brines. Active exploration pilot track.",
                defaultAssayGrade = "Li2O 1.42% | Rb 0.35% | Cs 0.08% | F 1.8%"
            )
        )
        _instruments.value = initialInstruments

        // Warehouses
        val initialWarehouses = listOf(
            Warehouse(
                warehouseId = "SWMX-WH-TAM-01",
                name = "Tamar Valley Minerals Hub & Depository",
                operator = "Tamar Physical Logistics Ltd",
                district = "Tamar Valley / Gunnislake",
                county = "Devon",
                capacityTonnes = 5000.0,
                utilizedTonnes = 1840.0,
                availableTonnes = 3160.0,
                reservedTonnes = 420.0,
                commodityRestrictions = listOf("Copper Concentrate", "Tungsten Wolframite", "Tin Ingots", "Secondary Metal"),
                assayFacilities = true,
                loadingFacilities = "Overhead 25t gantry, container tipper, bulk bag pneumatic loaders",
                transportLinks = "A390 Tamar corridor, direct freight link to Plymouth Millbay railhead",
                storageFeeGbpPerDay = 0.45,
                receiptsIssuedCount = 38
            ),
            Warehouse(
                warehouseId = "SWMX-WH-RDR-02",
                name = "Redruth Central Mineral Depository",
                operator = "Cornish Mineral Depository Vaults",
                district = "Camborne-Pool-Redruth",
                county = "Cornwall",
                capacityTonnes = 3500.0,
                utilizedTonnes = 1120.0,
                availableTonnes = 2380.0,
                reservedTonnes = 180.0,
                commodityRestrictions = listOf("Tin Ingots", "Cassiterite Concentrate", "Precious Doré", "Pilot Concentrates"),
                assayFacilities = true,
                loadingFacilities = "Enclosed secure bay, automated ingot bundler, calibrated weighbridge",
                transportLinks = "A30 arterial trunk route, Falmouth freight corridor",
                storageFeeGbpPerDay = 0.55,
                receiptsIssuedCount = 24
            ),
            Warehouse(
                warehouseId = "SWMX-WH-PLY-03",
                name = "Plymouth Cattedown Marine & Recycling Depository",
                operator = "South West Marine Storage PLC",
                district = "Plymouth Sound / Cattedown",
                county = "Devon",
                capacityTonnes = 8000.0,
                utilizedTonnes = 3450.0,
                availableTonnes = 4550.0,
                reservedTonnes = 650.0,
                commodityRestrictions = listOf("Secondary Recycled Copper", "Secondary Tin", "Granules", "Scrap Bundles"),
                assayFacilities = true,
                loadingFacilities = "Deepwater coaster berth, mobile harbour cranes, shredder & granulator links",
                transportLinks = "A38 Devon Expressway, Plymouth Port Quay 4",
                storageFeeGbpPerDay = 0.38,
                receiptsIssuedCount = 52
            ),
            Warehouse(
                warehouseId = "SWMX-WH-FLM-04",
                name = "Falmouth Docks Bulk Mineral Terminal",
                operator = "Cornwall Maritime Terminal Ltd",
                district = "Falmouth & Carrick Roads",
                county = "Cornwall",
                capacityTonnes = 6500.0,
                utilizedTonnes = 2100.0,
                availableTonnes = 4400.0,
                reservedTonnes = 310.0,
                commodityRestrictions = listOf("Bulk Concentrates", "Kaolin", "Industrial Minerals"),
                assayFacilities = false,
                loadingFacilities = "10,000 DWT dry cargo jetty, telescopic ship loader",
                transportLinks = "Maritime coastal shipping to European smelters (Antwerp / Hamburg / Bilbao)",
                storageFeeGbpPerDay = 0.32,
                receiptsIssuedCount = 19
            )
        )
        _warehouses.value = initialWarehouses

        // Physical Lots
        val initialLots = listOf(
            PhysicalLot(
                lotId = "SWMX-LOT-CU-2026-004812",
                symbol = "SWXCU",
                commodity = "Copper Concentrate",
                producerName = "Tamar Valley Minerals (Synthetic Demo)",
                mineOrFacility = "Tamar Processing Concentrator Unit 3",
                batch = "TVM-2026-B09",
                quantityWmt = 250.0,
                moisturePct = 8.4,
                quantityDmt = 229.0,
                gradeSummary = "Cu 24.81% | Ag 42.0 g/t | Au 1.70 g/t | As 0.12%",
                assayProfile = AssayProfile(
                    elements = mapOf(
                        "Cu" to 24.81,
                        "Ag_gpt" to 42.0,
                        "Au_gpt" to 1.70,
                        "As" to 0.12,
                        "Pb" to 0.41,
                        "Zn" to 0.72,
                        "Fe" to 28.6,
                        "S" to 29.4,
                        "Moisture" to 8.4
                    ),
                    sampleId = "SMP-CU-004812-A",
                    assayDate = "2026-09-22",
                    certificateId = "SWMX-CERT-CU-8841",
                    confidencePct = 99.6
                ),
                packaging = "1.5t UV-Stabilized Big Bags on Heat-Treated Pallets",
                warehouseId = "SWMX-WH-TAM-01",
                warehouseName = "Tamar Valley Minerals Hub & Depository",
                location = "Bay 14, Gunnislake Hub",
                productionDate = "2026-09-18",
                availableDate = "2026-09-25",
                deliveryWindow = "Prompt (3-5 Business Days)",
                ownership = "Tamar Minerals Trading Ltd",
                status = "AVAILABLE",
                certificateId = "SWMX-CERT-CU-8841",
                traceabilityHash = "0x8f2a994c4e1b883017ca9214ef56d3c7a0044192",
                qrCodeContent = "SWMX:LOT:SWMX-LOT-CU-2026-004812:DMT:229.0:CU:24.81:WH:TAM01"
            ),
            PhysicalLot(
                lotId = "SWMX-LOT-SN-2026-001290",
                symbol = "SWXSN",
                commodity = "Cornish Tin Metal Ingots",
                producerName = "Cornish Metals Smelting (Synthetic Demo)",
                mineOrFacility = "South Crofty Pilot Refiner, Pool",
                batch = "SCP-SN-2026-04",
                quantityWmt = 50.0,
                moisturePct = 0.0,
                quantityDmt = 50.0,
                gradeSummary = "Sn 99.88% | Fe 0.015% | As 0.008% | Bi 0.003%",
                assayProfile = AssayProfile(
                    elements = mapOf(
                        "Sn" to 99.88,
                        "Fe" to 0.015,
                        "As" to 0.008,
                        "Bi" to 0.003,
                        "Pb" to 0.021,
                        "Cu" to 0.012,
                        "Moisture" to 0.0
                    ),
                    sampleId = "SMP-SN-001290-C",
                    assayDate = "2026-09-20",
                    certificateId = "SWMX-CERT-SN-4102",
                    confidencePct = 99.9
                ),
                packaging = "Strapped 1-Tonne Ingot Bundles (25kg cast bars)",
                warehouseId = "SWMX-WH-RDR-02",
                warehouseName = "Redruth Central Mineral Depository",
                location = "Vault 2, Redruth Yard",
                productionDate = "2026-09-15",
                availableDate = "2026-09-21",
                deliveryWindow = "Immediate (24hr FCA Release)",
                ownership = "Cornish Tin Holding Corp",
                status = "AVAILABLE",
                certificateId = "SWMX-CERT-SN-4102",
                traceabilityHash = "0x44a1e902bc34df00871239aa81f456c071d3e899",
                qrCodeContent = "SWMX:LOT:SWMX-LOT-SN-2026-001290:DMT:50.0:SN:99.88:WH:RDR02"
            ),
            PhysicalLot(
                lotId = "SWMX-LOT-W-2026-000844",
                symbol = "SWXW",
                commodity = "Tungsten Wolframite Concentrate",
                producerName = "Tungsten West Strategic Minerals (Demo)",
                mineOrFacility = "Hemerdon Concentrator Plant, Plympton",
                batch = "HMD-W-2026-22",
                quantityWmt = 124.2,
                moisturePct = 3.4,
                quantityDmt = 120.0,
                gradeSummary = "WO3 62.40% | Sn 0.12% | As 0.03% | Mo 0.01%",
                assayProfile = AssayProfile(
                    elements = mapOf(
                        "WO3" to 62.40,
                        "Sn" to 0.12,
                        "As" to 0.03,
                        "Mo" to 0.01,
                        "Fe" to 14.2,
                        "Mn" to 4.8,
                        "Moisture" to 3.4
                    ),
                    sampleId = "SMP-W-000844-H",
                    assayDate = "2026-09-23",
                    certificateId = "SWMX-CERT-W-9930",
                    confidencePct = 99.7
                ),
                packaging = "Heavy-Duty Lined Steel Drums (200L / 500kg)",
                warehouseId = "SWMX-WH-TAM-01",
                warehouseName = "Tamar Valley Minerals Hub & Depository",
                location = "Security Compound C, Gunnislake",
                productionDate = "2026-09-19",
                availableDate = "2026-09-24",
                deliveryWindow = "Prompt (5 Business Days)",
                ownership = "South West Critical Materials Consortium",
                status = "AVAILABLE",
                certificateId = "SWMX-CERT-W-9930",
                traceabilityHash = "0x77c21109aa804351ef9120de8420ac8872513994",
                qrCodeContent = "SWMX:LOT:SWMX-LOT-W-2026-000844:DMT:120.0:WO3:62.4:WH:TAM01"
            ),
            PhysicalLot(
                lotId = "SWMX-LOT-RCU-2026-005118",
                symbol = "SWX-RCU",
                commodity = "Secondary Recycled Copper Chops",
                producerName = "Plymouth Non-Ferrous Recyclers Ltd",
                mineOrFacility = "Cattedown Secondary Processing Yard",
                batch = "PLY-RCU-511",
                quantityWmt = 85.0,
                moisturePct = 0.0,
                quantityDmt = 85.0,
                gradeSummary = "Cu 99.20% | Pb 0.04% | Fe 0.02% | Sn 0.03%",
                assayProfile = AssayProfile(
                    elements = mapOf(
                        "Cu" to 99.20,
                        "Pb" to 0.04,
                        "Fe" to 0.02,
                        "Sn" to 0.03,
                        "Zn" to 0.02,
                        "Moisture" to 0.0
                    ),
                    sampleId = "SMP-RCU-005118-P",
                    assayDate = "2026-09-24",
                    certificateId = "SWMX-CERT-RCU-1287",
                    confidencePct = 99.4
                ),
                packaging = "1.0t Bulk Bags on Standard Euro Pallets",
                warehouseId = "SWMX-WH-PLY-03",
                warehouseName = "Plymouth Cattedown Marine & Recycling Depository",
                location = "Shed 4B, Cattedown Wharves",
                productionDate = "2026-09-22",
                availableDate = "2026-09-24",
                deliveryWindow = "Prompt (2 Business Days)",
                ownership = "Devon Circular Commodities Ltd",
                status = "RESERVED",
                certificateId = "SWMX-CERT-RCU-1287",
                traceabilityHash = "0x12bb9930fe41774098ca4190ea6541289110034a",
                qrCodeContent = "SWMX:LOT:SWMX-LOT-RCU-2026-005118:DMT:85.0:CU:99.2:WH:PLY03"
            )
        )
        _lots.value = initialLots

        // Warehouse Receipts
        val initialReceipts = listOf(
            WarehouseReceipt(
                receiptId = "SWMX-WHR-2026-00891",
                lotId = "SWMX-LOT-CU-2026-004812",
                commodity = "Copper Concentrate",
                quantityDmt = 229.0,
                grade = "Cu 24.81% | Ag 42g/t",
                owner = "Tamar Minerals Trading Ltd",
                warehouseName = "Tamar Valley Minerals Hub & Depository",
                issueDate = "2026-09-22",
                expiryReviewDate = "2027-09-22",
                status = "ACTIVE",
                qrHash = "WHR-HASH-0x994a2b1"
            ),
            WarehouseReceipt(
                receiptId = "SWMX-WHR-2026-00892",
                lotId = "SWMX-LOT-SN-2026-001290",
                commodity = "Cornish Tin Metal Ingots",
                quantityDmt = 50.0,
                grade = "Sn 99.88%",
                owner = "Cornish Tin Holding Corp",
                warehouseName = "Redruth Central Mineral Depository",
                issueDate = "2026-09-21",
                expiryReviewDate = "2027-09-21",
                status = "ACTIVE",
                qrHash = "WHR-HASH-0x881f3c4"
            ),
            WarehouseReceipt(
                receiptId = "SWMX-WHR-2026-00893",
                lotId = "SWMX-LOT-W-2026-000844",
                commodity = "Tungsten Wolframite Concentrate",
                quantityDmt = 120.0,
                grade = "WO3 62.40%",
                owner = "South West Critical Materials Consortium",
                warehouseName = "Tamar Valley Minerals Hub & Depository",
                issueDate = "2026-09-24",
                expiryReviewDate = "2027-09-24",
                status = "ACTIVE",
                qrHash = "WHR-HASH-0x77e900a"
            )
        )
        _warehouseReceipts.value = initialReceipts

        // Inventory Ledger Entries (Double entry style)
        val initialLedger = listOf(
            InventoryLedgerEntry(
                entryId = "LED-00194",
                timestamp = "2026-09-22 09:14:02",
                lotId = "SWMX-LOT-CU-2026-004812",
                warehouseId = "SWMX-WH-TAM-01",
                eventType = "LOT_CREATED",
                quantityDeltaDmt = +229.0,
                balanceAfterDmt = 229.0,
                referenceId = "WHR-2026-00891",
                operator = "Depository Intake Desk 1"
            ),
            InventoryLedgerEntry(
                entryId = "LED-00195",
                timestamp = "2026-09-23 11:30:15",
                lotId = "SWMX-LOT-RCU-2026-005118",
                warehouseId = "SWMX-WH-PLY-03",
                eventType = "LOT_CREATED",
                quantityDeltaDmt = +85.0,
                balanceAfterDmt = 85.0,
                referenceId = "WHR-2026-00894",
                operator = "Cattedown Receiving Desk"
            ),
            InventoryLedgerEntry(
                entryId = "LED-00196",
                timestamp = "2026-09-24 14:02:40",
                lotId = "SWMX-LOT-RCU-2026-005118",
                warehouseId = "SWMX-WH-PLY-03",
                eventType = "RESERVED",
                quantityDeltaDmt = -85.0,
                balanceAfterDmt = 0.0,
                referenceId = "CTR-2026-00912",
                operator = "Automated Matching Escrow"
            )
        )
        _inventoryLedger.value = initialLedger

        // Order Books
        val books = mutableMapOf<String, OrderBook>()

        // Tin Order Book (SWXSN)
        books["SWXSN"] = OrderBook(
            symbol = "SWXSN",
            bids = listOf(
                OrderBookLevel(24820.0, 15.0, 2, 15.0, 0.40),
                OrderBookLevel(24780.0, 25.0, 3, 40.0, 0.70),
                OrderBookLevel(24710.0, 50.0, 4, 90.0, 1.00)
            ),
            offers = listOf(
                OrderBookLevel(24890.0, 10.0, 1, 10.0, 0.30),
                OrderBookLevel(24950.0, 30.0, 2, 40.0, 0.65),
                OrderBookLevel(25020.0, 45.0, 3, 85.0, 1.00)
            ),
            bestBidGbp = 24820.0,
            bestOfferGbp = 24890.0,
            spreadGbp = 70.0,
            spreadPct = 0.28,
            midGbp = 24855.0,
            vwapGbp = 24810.0,
            dayHighGbp = 25100.0,
            dayLowGbp = 24620.0,
            openGbp = 24680.0,
            settlementPriceGbp = 24850.0,
            timestamp = now()
        )

        // Copper Order Book (SWXCU)
        books["SWXCU"] = OrderBook(
            symbol = "SWXCU",
            bids = listOf(
                OrderBookLevel(8220.0, 25.0, 2, 25.0, 0.25),
                OrderBookLevel(8185.0, 40.0, 3, 65.0, 0.60),
                OrderBookLevel(8140.0, 100.0, 5, 165.0, 1.00)
            ),
            offers = listOf(
                OrderBookLevel(8260.0, 20.0, 1, 20.0, 0.20),
                OrderBookLevel(8295.0, 50.0, 2, 70.0, 0.55),
                OrderBookLevel(8340.0, 100.0, 4, 170.0, 1.00)
            ),
            bestBidGbp = 8220.0,
            bestOfferGbp = 8260.0,
            spreadGbp = 40.0,
            spreadPct = 0.48,
            midGbp = 8240.0,
            vwapGbp = 8235.0,
            dayHighGbp = 8320.0,
            dayLowGbp = 8180.0,
            openGbp = 8280.0,
            settlementPriceGbp = 8240.0,
            timestamp = now()
        )

        // Tungsten Order Book (SWXW)
        books["SWXW"] = OrderBook(
            symbol = "SWXW",
            bids = listOf(
                OrderBookLevel(27800.0, 10.0, 1, 10.0, 0.35),
                OrderBookLevel(27650.0, 20.0, 2, 30.0, 0.70),
                OrderBookLevel(27500.0, 35.0, 3, 65.0, 1.00)
            ),
            offers = listOf(
                OrderBookLevel(27920.0, 15.0, 1, 15.0, 0.40),
                OrderBookLevel(28050.0, 25.0, 2, 40.0, 0.75),
                OrderBookLevel(28200.0, 30.0, 2, 70.0, 1.00)
            ),
            bestBidGbp = 27800.0,
            bestOfferGbp = 27920.0,
            spreadGbp = 120.0,
            spreadPct = 0.43,
            midGbp = 27860.0,
            vwapGbp = 27790.0,
            dayHighGbp = 28100.0,
            dayLowGbp = 27400.0,
            openGbp = 27500.0,
            settlementPriceGbp = 27850.0,
            timestamp = now()
        )

        _orderBooks.value = books

        // Trades Tape
        val initialTrades = listOf(
            Trade(
                tradeId = "TRD-2026-000421",
                symbol = "SWXCU",
                priceGbp = 8240.0,
                quantityDmt = 25.0,
                side = OrderSide.BUY,
                buyer = "Wessex Refiners & Smelting Ltd",
                seller = "Tamar Minerals Trading Ltd",
                lotId = "SWMX-LOT-CU-2026-004812",
                timestamp = "2026-09-25 13:42:10",
                deliveryTerms = "FCA Tamar Valley Minerals Hub",
                settlementStatus = "SETTLED"
            ),
            Trade(
                tradeId = "TRD-2026-000422",
                symbol = "SWXSN",
                priceGbp = 24850.0,
                quantityDmt = 10.0,
                side = OrderSide.BUY,
                buyer = "British Alloy Technologies PLC",
                seller = "Cornish Tin Holding Corp",
                lotId = "SWMX-LOT-SN-2026-001290",
                timestamp = "2026-09-25 13:48:55",
                deliveryTerms = "FCA Redruth Depository",
                settlementStatus = "MATERIAL_DISPATCHED"
            ),
            Trade(
                tradeId = "TRD-2026-000423",
                symbol = "SWXW",
                priceGbp = 27850.0,
                quantityDmt = 15.0,
                side = OrderSide.SELL,
                buyer = "Advanced Tooling European Gmbh",
                seller = "South West Critical Materials Consortium",
                lotId = "SWMX-LOT-W-2026-000844",
                timestamp = "2026-09-25 13:54:12",
                deliveryTerms = "DAP Plymouth Rail Freight Terminal",
                settlementStatus = "CONTRACT_CREATED"
            ),
            Trade(
                tradeId = "TRD-2026-000424",
                symbol = "SWX-RCU",
                priceGbp = 7690.0,
                quantityDmt = 85.0,
                side = OrderSide.BUY,
                buyer = "South Coast Cable & Wire Works",
                seller = "Devon Circular Commodities Ltd",
                lotId = "SWMX-LOT-RCU-2026-005118",
                timestamp = "2026-09-25 13:58:30",
                deliveryTerms = "FCA Plymouth Cattedown Depository",
                settlementStatus = "WEIGHED"
            )
        )
        _trades.value = initialTrades

        // RFQs
        val initialRfqs = listOf(
            RFQ(
                rfqId = "SWMX-RFQ-2026-00341",
                buyerName = "Avonmouth Copper Smelters Ltd",
                symbol = "SWXCU",
                commodity = "Copper Concentrate",
                requestedQuantityDmt = 250.0,
                gradeSpec = "Cu >= 24.5%, As <= 0.15%, Moisture <= 8.5%",
                deliveryLocation = "Tamar Valley Minerals Hub / South West Corridor",
                deliveryWindow = "14-28 Days",
                incoterm = "FCA Tamar Depository",
                status = "QUOTED",
                createdAt = "2026-09-25 11:20:00",
                quotes = listOf(
                    QuoteResponse(
                        quoteId = "QTE-2026-00109",
                        rfqId = "SWMX-RFQ-2026-00341",
                        sellerName = "Tamar Minerals Trading Ltd",
                        priceGbpPerDmt = 8230.0,
                        offeredQuantityDmt = 250.0,
                        gradeSummary = "Cu 24.81% | Ag 42g/t | As 0.12%",
                        deliveryWindowDays = 14,
                        warehouseLocation = "Tamar Valley Minerals Hub (Gunnislake)",
                        incoterm = "FCA Depository",
                        timestamp = "2026-09-25 11:45:00"
                    ),
                    QuoteResponse(
                        quoteId = "QTE-2026-00110",
                        rfqId = "SWMX-RFQ-2026-00341",
                        sellerName = "Cornish Polymetallic Merchants",
                        priceGbpPerDmt = 8255.0,
                        offeredQuantityDmt = 200.0,
                        gradeSummary = "Cu 24.60% | Ag 38g/t | As 0.14%",
                        deliveryWindowDays = 21,
                        warehouseLocation = "Redruth Central Depository",
                        incoterm = "DAP Avonmouth",
                        timestamp = "2026-09-25 12:05:00"
                    )
                )
            ),
            RFQ(
                rfqId = "SWMX-RFQ-2026-00342",
                buyerName = "European Hardmetal Alloys B.V.",
                symbol = "SWXW",
                commodity = "Tungsten Wolframite Concentrate",
                requestedQuantityDmt = 60.0,
                gradeSpec = "WO3 >= 62.0%, Sn <= 0.15%",
                deliveryLocation = "Plymouth Port Coaster Wharf",
                deliveryWindow = "Prompt (7-14 Days)",
                incoterm = "FOB Plymouth",
                status = "OPEN",
                createdAt = "2026-09-25 12:50:00"
            )
        )
        _rfqs.value = initialRfqs

        // Contracts
        val initialContracts = listOf(
            PhysicalContract(
                contractId = "SWMX-CTR-2026-00912",
                rfqOrOrderId = "TRD-2026-000424",
                symbol = "SWX-RCU",
                commodity = "Secondary Recycled Copper Chops",
                buyer = "South Coast Cable & Wire Works",
                seller = "Devon Circular Commodities Ltd",
                lotId = "SWMX-LOT-RCU-2026-005118",
                quantityDmt = 85.0,
                priceGbpPerDmt = 7690.0,
                totalValueGbp = 653650.0,
                incoterm = "FCA Plymouth Cattedown Depository",
                warehouse = "Plymouth Cattedown Marine & Recycling Depository",
                executionDate = "2026-09-25 13:58:30",
                deliveryDeadline = "2026-10-02",
                currentStage = DeliveryStage.WEIGHT_VERIFIED,
                settled = false
            )
        )
        _contracts.value = initialContracts

        // Deliveries
        val initialDeliveries = listOf(
            DeliveryTracker(
                deliveryId = "SWMX-DEL-2026-00192",
                contractId = "SWMX-CTR-2026-00912",
                lotId = "SWMX-LOT-RCU-2026-005118",
                carrier = "Tamar Haulage & Bulk Logistics Ltd",
                vehicleReg = "WK24 PLY (Scania 44t articulated)",
                origin = "Plymouth Cattedown Depository Shed 4B",
                destination = "South Coast Cable Works, Exeter Depot",
                currentStage = DeliveryStage.WEIGHT_VERIFIED,
                eta = "2026-09-25 17:30 BST",
                events = listOf(
                    DeliveryEvent("EVT-DEL-01", "2026-09-25 14:05:00", DeliveryStage.TRADE_EXECUTED, "SWMX Electronic Core", "Matching Engine", "0x39a11", "Trade matched at £7,690/t"),
                    DeliveryEvent("EVT-DEL-02", "2026-09-25 14:15:22", DeliveryStage.CONTRACT_CREATED, "Legal Clearing House", "SWMX Legal", "0x78ba2", "Master Physical Commodities Agreement executed"),
                    DeliveryEvent("EVT-DEL-03", "2026-09-25 14:30:10", DeliveryStage.LOT_ALLOCATED, "Plymouth Cattedown Depository", "Vault Custodian", "0x91cf4", "Stock reserved in Shed 4B"),
                    DeliveryEvent("EVT-DEL-04", "2026-09-25 15:00:00", DeliveryStage.DELIVERY_BOOKED, "Tamar Logistics Desk", "Transport Coordinator", "0x44d18", "Slot Ref: TMR-LOG-992"),
                    DeliveryEvent("EVT-DEL-05", "2026-09-25 15:45:00", DeliveryStage.MATERIAL_DISPATCHED, "Cattedown Gate 2", "Depository Weighmaster", "0x82ea9", "Tare: 14.8t, Gross: 99.8t"),
                    DeliveryEvent("EVT-DEL-06", "2026-09-25 16:35:00", DeliveryStage.MATERIAL_RECEIVED, "Exeter Receiving Terminal", "Site Manager", "0x110bc", "Consignment seals verified intact"),
                    DeliveryEvent("EVT-DEL-07", "2026-09-25 16:50:00", DeliveryStage.WEIGHT_VERIFIED, "Exeter Calibrated Weighbridge", "Chief Inspector", "0x5501a", "Net dry tonnage confirmed 85.0 DMT")
                )
            )
        )
        _deliveries.value = initialDeliveries

        // Regional Mining Asset Registry (Cornwall & Devon Mining Landscape)
        val initialAssets = listOf(
            RegionalAsset(
                assetId = "SWMX-AST-SC-001",
                name = "South Crofty Mine",
                district = "Camborne-Pool-Redruth",
                county = "Cornwall",
                assetType = AssetType.MINE,
                status = AssetStatus.DEVELOPMENT,
                primaryCommodities = listOf("Tin", "Copper", "Zinc"),
                latitude = 50.2248,
                longitude = -5.2750,
                historicalSummary = "One of the most famous and deepest tin mines in Cornwall. Mined continuously for over 400 years until temporary closure in 1998.",
                modernStatusNotes = "Modern high-grade tin resource under active dewatering, pilot testing, and PEA feasibility for modern green tin extraction.",
                activeLotIds = listOf("SWMX-LOT-SN-2026-001290")
            ),
            RegionalAsset(
                assetId = "SWMX-AST-HMD-002",
                name = "Hemerdon Mine (Tungsten West)",
                district = "Plympton / West Devon Border",
                county = "Devon",
                assetType = AssetType.MINE,
                status = AssetStatus.DEVELOPMENT,
                primaryCommodities = listOf("Tungsten", "Tin"),
                latitude = 50.4042,
                longitude = -4.0150,
                historicalSummary = "Discovered in 1867. One of the largest tungsten-tin deposits in the Western world with extensive open-pit infrastructure.",
                modernStatusNotes = "Designated strategic critical mineral asset under updated processing plant recommissioning and environmental permitting.",
                activeLotIds = listOf("SWMX-LOT-W-2026-000844")
            ),
            RegionalAsset(
                assetId = "SWMX-AST-DGC-003",
                name = "Devon Great Consols",
                district = "Tamar Valley / Tavistock",
                county = "Devon",
                assetType = AssetType.MINE,
                status = AssetStatus.HISTORICAL,
                primaryCommodities = listOf("Copper", "Arsenic", "Tin"),
                latitude = 50.5312,
                longitude = -4.2384,
                historicalSummary = "Once the richest copper mine in Europe and the world's greatest arsenic producer in the 1870s, producing over 700,000 tonnes of copper ore.",
                modernStatusNotes = "UNESCO World Heritage anchor site. Benchmark geochemical reference dataset preserved in SWMX historical archives.",
                historicalPeakYear = "1874"
            ),
            RegionalAsset(
                assetId = "SWMX-AST-UNT-004",
                name = "United Mines & Consolidated Mines",
                district = "Gwennap Mining District",
                county = "Cornwall",
                assetType = AssetType.MINE,
                status = AssetStatus.HISTORICAL,
                primaryCommodities = listOf("Copper", "Arsenic", "Tin", "Zinc"),
                latitude = 50.2315,
                longitude = -5.1764,
                historicalSummary = "Known in the 18th and 19th centuries as the 'Richest Square Mile in the Old World', yielding immense fortunes in rich copper lodes.",
                modernStatusNotes = "Historical mineral lode reference. Geothermal & mineralized brine testing active in surrounding regional fault zones.",
                historicalPeakYear = "1838"
            ),
            RegionalAsset(
                assetId = "SWMX-AST-LEV-005",
                name = "Levant & Geevor Mines",
                district = "St Just in Penwith",
                county = "Cornwall",
                assetType = AssetType.MINE,
                status = AssetStatus.HISTORICAL,
                primaryCommodities = listOf("Tin", "Copper", "Arsenic"),
                latitude = 50.1518,
                longitude = -5.6890,
                historicalSummary = "Submarine lodes extending over a mile under the Atlantic seabed. Geevor operated until 1990 as the last tin mine in West Cornwall.",
                modernStatusNotes = "Mining museum, educational assay archive, and historic mineral collection.",
                historicalPeakYear = "1910"
            ),
            RegionalAsset(
                assetId = "SWMX-AST-TVM-006",
                name = "Tamar Valley Minerals Hub & Depository",
                district = "Gunnislake / Calstock",
                county = "Devon",
                assetType = AssetType.WAREHOUSE,
                status = AssetStatus.ACTIVE,
                primaryCommodities = listOf("Copper Concentrate", "Tungsten", "Secondary Metals"),
                latitude = 50.5220,
                longitude = -4.2250,
                historicalSummary = "Constructed adjacent to the historic Tamar mineral railway terminal connecting Gunnislake and Morwellham Quay.",
                modernStatusNotes = "SWMX Certified Physical Depository with on-site XRF laboratory, weighbridge, and secure bonded big-bag storage.",
                certifiedWarehouseCapacityTonnes = 5000.0,
                activeLotIds = listOf("SWMX-LOT-CU-2026-004812", "SWMX-LOT-W-2026-000844")
            ),
            RegionalAsset(
                assetId = "SWMX-AST-MRW-007",
                name = "Morwellham Quay Mineral Port",
                district = "Tamar Valley",
                county = "Devon",
                assetType = AssetType.PORT,
                status = AssetStatus.HISTORICAL,
                primaryCommodities = listOf("Copper Ore", "Arsenic", "Lead"),
                latitude = 50.5015,
                longitude = -4.1980,
                historicalSummary = "The historic river port that loaded copper ore from Devon Great Consols into ketches and schooners for transport to Swansea smelters.",
                modernStatusNotes = "Living history museum and World Heritage site.",
                historicalPeakYear = "1870"
            ),
            RegionalAsset(
                assetId = "SWMX-AST-CAO-008",
                name = "Cornish Assay Office Ltd",
                district = "Redruth",
                county = "Cornwall",
                assetType = AssetType.LABORATORY,
                status = AssetStatus.ACTIVE,
                primaryCommodities = listOf("All Minerals & Metals"),
                latitude = 50.2330,
                longitude = -5.2280,
                historicalSummary = "Independent assaying tradition in Redruth dating back to the Stannary tin coinage and ticketing sales.",
                modernStatusNotes = "ISO 17025 accredited referee laboratory equipped with high-resolution ICP-OES, Fire Assay, and WD-XRF.",
                historicalPeakYear = "Modern"
            ),
            RegionalAsset(
                assetId = "SWMX-AST-PLY-009",
                name = "Plymouth Cattedown Recycling & Vaults",
                district = "Plymouth Sound",
                county = "Devon",
                assetType = AssetType.RECYCLING_PLANT,
                status = AssetStatus.ACTIVE,
                primaryCommodities = listOf("Secondary Recycled Copper", "Tin Scrap", "Lead"),
                latitude = 50.3650,
                longitude = -4.1180,
                historicalSummary = "Maritime industrial depot handling non-ferrous material recovery for South West utility and marine dismantlers.",
                modernStatusNotes = "Certified SWMX secondary metal processing and delivery hub with electronic weighbridge verification.",
                certifiedWarehouseCapacityTonnes = 8000.0,
                activeLotIds = listOf("SWMX-LOT-RCU-2026-005118")
            )
        )
        _regionalAssets.value = initialAssets

        // Assay Disputes
        val initialDisputes = listOf(
            AssayDispute(
                disputeId = "DSP-2026-0012",
                lotId = "SWMX-LOT-CU-2026-004812",
                element = "Cu",
                buyerValue = 24.64,
                sellerValue = 24.81,
                refereeValue = 24.73,
                thresholdPct = 0.25,
                status = "RESOLVED",
                resolutionNotes = "Referee assay by Cornish Assay Office (24.73% Cu) adopted per SWMX Rule 4.2. Settlement adjusted by £5,267.00.",
                settlementAdjustmentGbp = -5267.0
            )
        )
        _disputes.value = initialDisputes

        // Initial FIX Messages
        val initialFix = listOf(
            FIXMessage(
                eventId = "EVT-FIX-001284",
                event = "TRADE_EXECUTED",
                timestamp = now(),
                symbol = "SWXCU",
                refId = "TRD-2026-000421",
                quantityDmt = 25.0,
                priceGbp = 8240.0,
                fixTagFormatted = "8=FIX.4.4|35=8|49=SWMX_MATCH|56=RHINOQUANT|37=TRD-2026-000421|55=SWXCU|38=25.0|44=8240.00|15=GBP|150=2|39=2|10=182|"
            ),
            FIXMessage(
                eventId = "EVT-FIX-001285",
                event = "TICKER_UPDATE",
                timestamp = now(),
                symbol = "SWXSN",
                refId = "TICK-SN-0092",
                quantityDmt = 10.0,
                priceGbp = 24850.0,
                fixTagFormatted = "8=FIX.4.4|35=W|49=SWMX_MARKET|56=BROADCAST|55=SWXSN|269=2|270=24850.00|271=10.0|15=GBP|10=094|"
            ),
            FIXMessage(
                eventId = "EVT-FIX-001286",
                event = "LOT_RESERVED",
                timestamp = now(),
                symbol = "SWX-RCU",
                refId = "SWMX-LOT-RCU-2026-005118",
                quantityDmt = 85.0,
                priceGbp = 7690.0,
                fixTagFormatted = "8=FIX.4.4|35=U10|49=SWMX_INVENTORY|56=ESCROW|6001=SWMX-LOT-RCU-2026-005118|38=85.0|6002=RESERVED|10=210|"
            )
        )
        _fixMessages.value = initialFix

        // API Keys
        _apiKeys.value = listOf(
            ApiKeyInfo(
                keyId = "swmx_live_rhinoquant_8812f",
                keySecretMasked = "sk_live_swmx_••••••••••••9a4f",
                clientName = "RhinoQuant High-Frequency Spot Desk",
                scopes = listOf("market:read", "market:stream", "orders:read", "orders:write", "rfq:read", "rfq:write", "lots:read", "lots:write", "settlement:read"),
                createdAt = "2026-01-15"
            ),
            ApiKeyInfo(
                keyId = "swmx_live_tamar_minerals_0041b",
                keySecretMasked = "sk_live_swmx_••••••••••••31c2",
                clientName = "Tamar Valley Minerals Producer Portal",
                scopes = listOf("market:read", "lots:read", "lots:write", "rfq:read", "rfq:write", "settlement:read"),
                createdAt = "2026-03-20"
            )
        )
    }

    // --- Actions ---

    fun selectInstrument(symbol: String) {
        _selectedInstrumentSymbol.value = symbol
    }

    fun submitOrder(
        symbol: String,
        side: OrderSide,
        orderType: OrderType,
        quantityDmt: Double,
        priceGbp: Double,
        idempotencyKey: String,
        displayQuantityDmt: Double? = null
    ): Pair<Order, Trade?> {
        val orderId = "ORD-" + System.currentTimeMillis().toString().takeLast(6)
        val newOrder = Order(
            orderId = orderId,
            symbol = symbol,
            side = side,
            orderType = orderType,
            quantityDmt = quantityDmt,
            displayQuantityDmt = displayQuantityDmt,
            priceGbp = priceGbp,
            filledQuantityDmt = quantityDmt,
            status = OrderStatus.FILLED,
            idempotencyKey = idempotencyKey,
            participantId = "RHINOQUANT-DESK-01",
            participantName = "RhinoQuant Spot Trading",
            timestamp = now(),
            executionNotes = "Executed against synthetic liquidity pool"
        )
        _userOrders.update { listOf(newOrder) + it }

        // Generate matching trade
        val tradeId = "TRD-" + System.currentTimeMillis().toString().takeLast(6)
        val trade = Trade(
            tradeId = tradeId,
            symbol = symbol,
            priceGbp = priceGbp,
            quantityDmt = quantityDmt,
            side = side,
            buyer = if (side == OrderSide.BUY) "RhinoQuant Spot Trading" else "SWMX Market Liquidity",
            seller = if (side == OrderSide.SELL) "RhinoQuant Spot Trading" else "SWMX Market Liquidity",
            lotId = "SWMX-LOT-" + symbol.replace("SWX", "") + "-AUTO",
            timestamp = now(),
            deliveryTerms = "FCA Regional Depository",
            settlementStatus = "TRADE_EXECUTED"
        )
        _trades.update { listOf(trade) + it }

        // Emit FIX Message
        val fixMsg = FIXMessage(
            eventId = "EVT-FIX-" + System.currentTimeMillis().toString().takeLast(6),
            event = "TRADE_EXECUTED",
            timestamp = now(),
            symbol = symbol,
            refId = tradeId,
            quantityDmt = quantityDmt,
            priceGbp = priceGbp,
            fixTagFormatted = "8=FIX.4.4|35=8|49=SWMX_MATCH|56=RHINOQUANT|37=$tradeId|55=$symbol|38=$quantityDmt|44=$priceGbp|15=GBP|150=2|39=2|10=220|"
        )
        _fixMessages.update { listOf(fixMsg) + it.take(40) }

        return Pair(newOrder, trade)
    }

    fun submitRfq(
        buyerName: String,
        symbol: String,
        commodity: String,
        quantityDmt: Double,
        gradeSpec: String,
        deliveryLocation: String,
        deliveryWindow: String,
        incoterm: String
    ): RFQ {
        val rfqId = "SWMX-RFQ-" + System.currentTimeMillis().toString().takeLast(5)
        val instrument = _instruments.value.find { it.symbol == symbol }
        val basePrice = instrument?.lastPriceGbp ?: 8200.0

        val newRfq = RFQ(
            rfqId = rfqId,
            buyerName = buyerName,
            symbol = symbol,
            commodity = commodity,
            requestedQuantityDmt = quantityDmt,
            gradeSpec = gradeSpec,
            deliveryLocation = deliveryLocation,
            deliveryWindow = deliveryWindow,
            incoterm = incoterm,
            status = "QUOTED",
            createdAt = now(),
            quotes = listOf(
                QuoteResponse(
                    quoteId = "QTE-" + System.currentTimeMillis().toString().takeLast(5),
                    rfqId = rfqId,
                    sellerName = "Tamar Valley Minerals Hub (Depository Stock)",
                    priceGbpPerDmt = (basePrice * 0.995).roundToInt().toDouble(),
                    offeredQuantityDmt = quantityDmt,
                    gradeSummary = gradeSpec,
                    deliveryWindowDays = 7,
                    warehouseLocation = "Tamar Valley Minerals Hub (Gunnislake)",
                    incoterm = incoterm,
                    timestamp = now()
                ),
                QuoteResponse(
                    quoteId = "QTE-" + (System.currentTimeMillis() + 1).toString().takeLast(5),
                    rfqId = rfqId,
                    sellerName = "Cornish Secondary Metals Consortium",
                    priceGbpPerDmt = (basePrice * 1.008).roundToInt().toDouble(),
                    offeredQuantityDmt = quantityDmt,
                    gradeSummary = gradeSpec,
                    deliveryWindowDays = 14,
                    warehouseLocation = "Redruth Mineral Depository",
                    incoterm = incoterm,
                    timestamp = now()
                )
            )
        )
        _rfqs.update { listOf(newRfq) + it }
        return newRfq
    }

    fun acceptQuote(rfqId: String, quoteId: String): PhysicalContract? {
        val rfq = _rfqs.value.find { it.rfqId == rfqId } ?: return null
        val quote = rfq.quotes.find { it.quoteId == quoteId } ?: return null

        val contractId = "SWMX-CTR-" + System.currentTimeMillis().toString().takeLast(5)
        val contract = PhysicalContract(
            contractId = contractId,
            rfqOrOrderId = rfqId,
            symbol = rfq.symbol,
            commodity = rfq.commodity,
            buyer = rfq.buyerName,
            seller = quote.sellerName,
            lotId = "SWMX-LOT-" + rfq.symbol + "-ALLOC",
            quantityDmt = quote.offeredQuantityDmt,
            priceGbpPerDmt = quote.priceGbpPerDmt,
            totalValueGbp = quote.offeredQuantityDmt * quote.priceGbpPerDmt,
            incoterm = quote.incoterm,
            warehouse = quote.warehouseLocation,
            executionDate = now(),
            deliveryDeadline = "14 Business Days",
            currentStage = DeliveryStage.TRADE_EXECUTED,
            settled = false
        )

        _contracts.update { listOf(contract) + it }

        // Update RFQ status
        _rfqs.update { list ->
            list.map {
                if (it.rfqId == rfqId) {
                    it.copy(
                        status = "CONTRACTED",
                        contractId = contractId,
                        quotes = it.quotes.map { q -> if (q.quoteId == quoteId) q.copy(accepted = true) else q }
                    )
                } else it
            }
        }

        // Create Delivery Tracker
        val deliveryId = "SWMX-DEL-" + System.currentTimeMillis().toString().takeLast(5)
        val newDelivery = DeliveryTracker(
            deliveryId = deliveryId,
            contractId = contractId,
            lotId = contract.lotId,
            carrier = "Cornish & Devon Freight Transport Ltd",
            vehicleReg = "WK26 SWM",
            origin = quote.warehouseLocation,
            destination = rfq.deliveryLocation,
            currentStage = DeliveryStage.CONTRACT_CREATED,
            eta = "Prompt 7-Day Window",
            events = listOf(
                DeliveryEvent("EVT-01", now(), DeliveryStage.TRADE_EXECUTED, "SWMX RFQ Matching Engine", "Buyer Acceptance", "0xabc1", "RFQ quote accepted at £${quote.priceGbpPerDmt}/t"),
                DeliveryEvent("EVT-02", now(), DeliveryStage.CONTRACT_CREATED, "SWMX Clearing House", "SWMX Legal", "0xabc2", "Contract $contractId issued")
            )
        )
        _deliveries.update { listOf(newDelivery) + it }

        return contract
    }

    fun advanceDeliveryStage(deliveryId: String): DeliveryStage? {
        var newStage: DeliveryStage? = null
        _deliveries.update { list ->
            list.map { delivery ->
                if (delivery.deliveryId == deliveryId) {
                    val nextStageIndex = delivery.currentStage.ordinal + 1
                    if (nextStageIndex < DeliveryStage.entries.size) {
                        val nextStage = DeliveryStage.entries[nextStageIndex]
                        newStage = nextStage
                        val newEvent = DeliveryEvent(
                            eventId = "EVT-" + System.currentTimeMillis().toString().takeLast(5),
                            timestamp = now(),
                            stage = nextStage,
                            location = delivery.destination,
                            actor = "SWMX Logistics Authority",
                            signatureHash = "0x" + System.currentTimeMillis().toString(16),
                            notes = "Progressed to ${nextStage.title}"
                        )
                        delivery.copy(
                            currentStage = nextStage,
                            events = delivery.events + listOf(newEvent)
                        )
                    } else delivery
                } else delivery
            }
        }
        return newStage
    }

    fun resolveAssayDispute(disputeId: String, refereeGrade: Double): AssayDispute? {
        var updated: AssayDispute? = null
        _disputes.update { list ->
            list.map { dispute ->
                if (dispute.disputeId == disputeId) {
                    val adjGbp = (refereeGrade - dispute.buyerValue) * 1250.0
                    val res = dispute.copy(
                        refereeValue = refereeGrade,
                        status = "RESOLVED",
                        resolutionNotes = "Referee laboratory assay of $refereeGrade% confirmed by SWMX Chief Assayer. Adjustment applied to final settlement.",
                        settlementAdjustmentGbp = adjGbp
                    )
                    updated = res
                    res
                } else dispute
            }
        }
        return updated
    }

    // --- Regional Basis Calculation ---
    fun getRegionalBasisFor(symbol: String): RegionalBasis {
        return when (symbol) {
            "SWXCU" -> RegionalBasis(
                symbol = "SWXCU",
                commodityName = "Copper Concentrate (Cu 24.8%)",
                globalReferencePriceGbp = 8050.0,
                ukReferencePriceGbp = 8080.0,
                southWestBasisPremiumGbp = +165.0,
                freightAdjustmentGbp = +42.0,
                gradeAdjustmentGbp = -18.0,
                tcRcAdjustmentGbp = -65.0,
                warehouseInsuranceGbp = +16.0,
                indicativeSwmxPhysicalPriceGbp = 8240.0,
                basisHistory7d = listOf(145.0, 150.0, 158.0, 160.0, 162.0, 168.0, 165.0)
            )
            "SWXSN" -> RegionalBasis(
                symbol = "SWXSN",
                commodityName = "Cornish Tin (Sn 99.85%)",
                globalReferencePriceGbp = 24450.0,
                ukReferencePriceGbp = 24520.0,
                southWestBasisPremiumGbp = +320.0,
                freightAdjustmentGbp = +35.0,
                gradeAdjustmentGbp = +45.0,
                tcRcAdjustmentGbp = 0.0,
                warehouseInsuranceGbp = +20.0,
                indicativeSwmxPhysicalPriceGbp = 24850.0,
                basisHistory7d = listOf(300.0, 310.0, 315.0, 318.0, 325.0, 322.0, 320.0)
            )
            "SWXW" -> RegionalBasis(
                symbol = "SWXW",
                commodityName = "Tungsten Wolframite (WO3 62%)",
                globalReferencePriceGbp = 27100.0,
                ukReferencePriceGbp = 27250.0,
                southWestBasisPremiumGbp = +650.0,
                freightAdjustmentGbp = +45.0,
                gradeAdjustmentGbp = +55.0,
                tcRcAdjustmentGbp = -30.0,
                warehouseInsuranceGbp = +30.0,
                indicativeSwmxPhysicalPriceGbp = 27850.0,
                basisHistory7d = listOf(610.0, 625.0, 630.0, 640.0, 648.0, 652.0, 650.0)
            )
            else -> RegionalBasis(
                symbol = symbol,
                commodityName = "Secondary Recycled Copper",
                globalReferencePriceGbp = 7550.0,
                ukReferencePriceGbp = 7580.0,
                southWestBasisPremiumGbp = +110.0,
                freightAdjustmentGbp = +25.0,
                gradeAdjustmentGbp = -15.0,
                tcRcAdjustmentGbp = -20.0,
                warehouseInsuranceGbp = +10.0,
                indicativeSwmxPhysicalPriceGbp = 7690.0,
                basisHistory7d = listOf(95.0, 100.0, 105.0, 108.0, 112.0, 110.0, 110.0)
            )
        }
    }

    // --- RhinoQuant Metrics ---
    fun getQuantMetricsFor(symbol: String): QuantMetrics {
        val basis = getRegionalBasisFor(symbol)
        val instrument = _instruments.value.find { it.symbol == symbol } ?: _instruments.value.first()

        return QuantMetrics(
            symbol = symbol,
            spotPriceGbp = instrument.lastPriceGbp,
            vwapGbp = instrument.vwapGbp,
            twapGbp = instrument.lastPriceGbp * 0.998,
            bidAskSpreadGbp = when (symbol) {
                "SWXSN" -> 70.0
                "SWXCU" -> 40.0
                "SWXW" -> 120.0
                else -> 50.0
            },
            realizedVol30dPct = 18.4,
            rollingVol7dPct = 14.2,
            momentum14d = +2.8,
            zScoreBasis = +1.42,
            daysOfRegionalSupply = when (symbol) {
                "SWXCU" -> 18.5
                "SWXSN" -> 28.0
                "SWXW" -> 34.0
                else -> 12.0
            },
            bidAskImbalanceRatio = +0.28,
            priceDispersionGbp = 32.5,
            assayDispersionCuPct = 0.38,
            regionalPremiumPct = ((basis.southWestBasisPremiumGbp / basis.globalReferencePriceGbp) * 1000).roundToInt() / 10.0,
            regime = when (symbol) {
                "SWXSN" -> RegimeType.HIGH_GRADE_SCARCITY
                "SWXCU" -> RegimeType.TAMAR_CONSOLIDATION
                "SWXW" -> RegimeType.SMELTER_DEMAND_SURGE
                else -> RegimeType.REGIONAL_ARBITRAGE
            },
            correlationToLme = 0.942
        )
    }

    // --- Forward Curve Points ---
    fun getForwardCurvePointsFor(symbol: String): List<CurvePoint> {
        val spot = _instruments.value.find { it.symbol == symbol }?.lastPriceGbp ?: 8240.0
        return listOf(
            CurvePoint("SPOT", 0, spot, spot - 20, spot + 20, 0.0, 120.0, 240.0, simulated = false),
            CurvePoint("7D", 7, spot + 18.0, spot - 5, spot + 35, +18.0, 95.0, 310.0, simulated = true),
            CurvePoint("30D", 30, spot + 45.0, spot + 20, spot + 68, +45.0, 160.0, 520.0, simulated = true),
            CurvePoint("60D", 60, spot + 82.0, spot + 55, spot + 105, +82.0, 210.0, 780.0, simulated = true),
            CurvePoint("90D", 90, spot + 125.0, spot + 95, spot + 150, +125.0, 185.0, 940.0, simulated = true),
            CurvePoint("180D", 180, spot + 210.0, spot + 175, spot + 245, +210.0, 140.0, 1150.0, simulated = true),
            CurvePoint("1Y", 365, spot + 380.0, spot + 330, spot + 430, +380.0, 90.0, 1420.0, simulated = true)
        )
    }

    // --- Contained Metal & Smelter Terms Engine ---
    fun calculateContainedMetal(
        wetWeight: Double,
        moisturePct: Double,
        gradePct: Double,
        referencePriceGbp: Double,
        tcGbpPerDmt: Double = 65.0,
        rcGbpPerTonnePayable: Double = 60.0,
        arsenicPct: Double = 0.12
    ): ContainedMetalCalculation {
        val dryWeight = wetWeight * (1.0 - (moisturePct / 100.0))
        val containedMetal = dryWeight * (gradePct / 100.0)
        val payableFactor = if (gradePct >= 20.0) 0.95 else 0.90 // 95% payable for copper concentrate
        val grossPayableMetal = containedMetal * payableFactor

        val grossMetalValue = grossPayableMetal * referencePriceGbp
        val totalTc = dryWeight * tcGbpPerDmt
        val totalRc = grossPayableMetal * rcGbpPerTonnePayable
        val arsenicPenalty = if (arsenicPct > 0.10) (arsenicPct - 0.10) * 100 * 25.0 * dryWeight else 0.0

        val netSettlement = grossMetalValue - totalTc - totalRc - arsenicPenalty
        val effectivePricePerDmt = if (dryWeight > 0) netSettlement / dryWeight else 0.0

        return ContainedMetalCalculation(
            wetWeightTonnes = wetWeight,
            moisturePercent = moisturePct,
            dryWeightTonnes = (dryWeight * 100.0).roundToInt() / 100.0,
            gradePercent = gradePct,
            containedMetalTonnes = (containedMetal * 100.0).roundToInt() / 100.0,
            metalPayablePercent = payableFactor * 100.0,
            grossPayableMetalTonnes = (grossPayableMetal * 100.0).roundToInt() / 100.0,
            referencePriceGbpPerTonne = referencePriceGbp,
            treatmentChargeGbpPerDmt = tcGbpPerDmt,
            refiningChargeGbpPerTonnePayable = rcGbpPerTonnePayable,
            arsenicPenaltyGbp = (arsenicPenalty * 100.0).roundToInt() / 100.0,
            netSettlementValueGbp = (netSettlement * 100.0).roundToInt() / 100.0,
            effectivePricePerDmt = (effectivePricePerDmt * 100.0).roundToInt() / 100.0
        )
    }

    // --- Interactive REST API Simulator ---
    fun executeApiRequest(endpoint: ApiEndpoint, params: Map<String, String>): ApiResponseEnvelope {
        val start = System.currentTimeMillis()
        val symbol = params["symbol"] ?: _selectedInstrumentSymbol.value

        val (dataPayload, jsonString) = when {
            endpoint.path.contains("/markets/{symbol}/orderbook") -> {
                val book = _orderBooks.value[symbol] ?: _orderBooks.value["SWXSN"]
                Pair(book, buildOrderBookJson(book))
            }
            endpoint.path.contains("/markets/{symbol}/trades") -> {
                val list = _trades.value.filter { it.symbol == symbol }
                Pair(list, buildTradesJson(list))
            }
            endpoint.path.contains("/markets/{symbol}/curve") -> {
                val curve = getForwardCurvePointsFor(symbol)
                Pair(curve, buildCurveJson(symbol, curve))
            }
            endpoint.path.contains("/markets/{symbol}/basis") -> {
                val basis = getRegionalBasisFor(symbol)
                Pair(basis, buildBasisJson(basis))
            }
            endpoint.path.contains("/markets/{symbol}/quote") -> {
                val inst = _instruments.value.find { it.symbol == symbol }
                Pair(inst, buildQuoteJson(inst))
            }
            endpoint.path.contains("/markets") -> {
                Pair(_instruments.value, buildMarketsJson(_instruments.value))
            }
            endpoint.path.contains("/lots/{lot_id}/provenance") -> {
                val lot = _lots.value.first()
                Pair(lot, buildProvenanceJson(lot))
            }
            endpoint.path.contains("/lots") -> {
                Pair(_lots.value, buildLotsJson(_lots.value))
            }
            endpoint.path.contains("/orders") -> {
                Pair(_userOrders.value, buildOrdersJson(_userOrders.value))
            }
            endpoint.path.contains("/rfqs") -> {
                Pair(_rfqs.value, buildRfqsJson(_rfqs.value))
            }
            endpoint.path.contains("/deliveries") -> {
                Pair(_deliveries.value, buildDeliveriesJson(_deliveries.value))
            }
            endpoint.path.contains("/analytics/rhinoquant") -> {
                val quant = getQuantMetricsFor(symbol)
                Pair(quant, buildQuantJson(quant))
            }
            endpoint.path.contains("/commodities") -> {
                Pair(CommodityGroup.entries.map { it.label }, buildCommoditiesJson())
            }
            else -> Pair("OK", """{"status": "SUCCESS"}""")
        }

        val latency = (System.currentTimeMillis() - start) + 12L
        val meta = ApiResponseMeta(
            timestamp = nowIso(),
            requestId = "req_" + UUID.randomUUID().toString().take(12),
            source = "SWMX Matching & Physical Settlement Engine",
            dataStatus = "SYNTHETIC_MARKET_INFRASTRUCTURE",
            latencyMs = latency
        )

        return ApiResponseEnvelope(
            data = dataPayload,
            meta = meta,
            rawJsonFormatted = jsonString
        )
    }

    private fun buildMarketsJson(list: List<Instrument>): String {
        val items = list.joinToString(",\n    ") {
            """{
      "instrument_id": "${it.instrumentId}",
      "symbol": "${it.symbol}",
      "commodity": "${it.commodity}",
      "market_status": "${it.marketStatus.name}",
      "physical_form": "${it.physicalForm.name}",
      "last_price": ${it.lastPriceGbp},
      "currency": "GBP",
      "lot_unit": "${it.lotUnit.symbol}",
      "deliverable": ${it.deliverable},
      "assay_required": ${it.assayRequired},
      "warehouse_eligible": ${it.warehouseEligible}
    }"""
        }
        return """{
  "data": [
    $items
  ],
  "meta": {
    "count": ${list.size},
    "exchange": "SWMX",
    "region": "Cornwall & West Devon"
  }
}"""
    }

    private fun buildQuoteJson(inst: Instrument?): String {
        return """{
  "data": {
    "symbol": "${inst?.symbol ?: "SWXSN"}",
    "commodity": "${inst?.commodity}",
    "last_price": ${inst?.lastPriceGbp},
    "currency": "GBP",
    "unit": "${inst?.priceUnit}",
    "change_24h_pct": ${inst?.changePct24h},
    "vwap": ${inst?.vwapGbp},
    "day_high": ${inst?.dayHighGbp},
    "day_low": ${inst?.dayLowGbp},
    "market_status": "${inst?.marketStatus?.name}",
    "provenance_region": "${inst?.region}"
  }
}"""
    }

    private fun buildOrderBookJson(book: OrderBook?): String {
        if (book == null) return "{}"
        val bids = book.bids.joinToString(",\n      ") {
            """{"price": ${it.priceGbp}, "quantity_dmt": ${it.quantityDmt}, "lots": ${it.lotCount}}"""
        }
        val offers = book.offers.joinToString(",\n      ") {
            """{"price": ${it.priceGbp}, "quantity_dmt": ${it.quantityDmt}, "lots": ${it.lotCount}}"""
        }
        return """{
  "data": {
    "symbol": "${book.symbol}",
    "timestamp": "${book.timestamp}",
    "best_bid": ${book.bestBidGbp},
    "best_offer": ${book.bestOfferGbp},
    "spread": ${book.spreadGbp},
    "spread_pct": ${book.spreadPct},
    "mid_price": ${book.midGbp},
    "bids": [
      $bids
    ],
    "offers": [
      $offers
    ]
  }
}"""
    }

    private fun buildTradesJson(trades: List<Trade>): String {
        val items = trades.joinToString(",\n    ") {
            """{
      "trade_id": "${it.tradeId}",
      "symbol": "${it.symbol}",
      "price": ${it.priceGbp},
      "quantity_dmt": ${it.quantityDmt},
      "side": "${it.side.name}",
      "delivery_terms": "${it.deliveryTerms}",
      "settlement_status": "${it.settlementStatus}",
      "timestamp": "${it.timestamp}"
    }"""
        }
        return """{
  "data": [
    $items
  ]
}"""
    }

    private fun buildBasisJson(basis: RegionalBasis): String {
        return """{
  "data": {
    "symbol": "${basis.symbol}",
    "commodity": "${basis.commodityName}",
    "global_reference_price": ${basis.globalReferencePriceGbp},
    "south_west_basis_premium": ${basis.southWestBasisPremiumGbp},
    "freight_adjustment": ${basis.freightAdjustmentGbp},
    "grade_adjustment": ${basis.gradeAdjustmentGbp},
    "tc_rc_adjustment": ${basis.tcRcAdjustmentGbp},
    "warehouse_insurance": ${basis.warehouseInsuranceGbp},
    "indicative_swmx_physical_price": ${basis.indicativeSwmxPhysicalPriceGbp},
    "currency": "GBP",
    "calculation_formula": "Physical = GlobalRef + SWBasis + Freight + GradeAdj + TCRC + Insurance"
  }
}"""
    }

    private fun buildCurveJson(symbol: String, curve: List<CurvePoint>): String {
        val items = curve.joinToString(",\n    ") {
            """{
      "tenor": "${it.tenor}",
      "days": ${it.daysToDelivery},
      "price": ${it.priceGbp},
      "bid": ${it.bidGbp},
      "offer": ${it.offerGbp},
      "basis": ${it.basisGbp},
      "status": "${if (it.simulated) "SIMULATED" else "SPOT_LIVE"}"
    }"""
        }
        return """{
  "data": {
    "symbol": "$symbol",
    "curve_type": "SPOT_FORWARD_SIMULATED",
    "tenors": [
      $items
    ]
  }
}"""
    }

    private fun buildLotsJson(lots: List<PhysicalLot>): String {
        val items = lots.joinToString(",\n    ") {
            """{
      "lot_id": "${it.lotId}",
      "commodity": "${it.commodity}",
      "producer": "${it.producerName}",
      "quantity_wmt": ${it.quantityWmt},
      "moisture_pct": ${it.moisturePct},
      "quantity_dmt": ${it.quantityDmt},
      "grade": "${it.gradeSummary}",
      "warehouse": "${it.warehouseName}",
      "status": "${it.status}",
      "certificate_id": "${it.certificateId}",
      "traceability_hash": "${it.traceabilityHash}"
    }"""
        }
        return """{
  "data": [
    $items
  ]
}"""
    }

    private fun buildProvenanceJson(lot: PhysicalLot): String {
        return """{
  "data": {
    "lot_id": "${lot.lotId}",
    "commodity": "${lot.commodity}",
    "chain_of_custody": [
      {"step": "MINE_EXTRACTION", "facility": "${lot.mineOrFacility}", "status": "VERIFIED"},
      {"step": "MINERAL_PROCESSING", "type": "Flotation & Gravity Concentration", "status": "VERIFIED"},
      {"step": "ASSAY_SAMPLING", "laboratory": "${lot.assayProfile.primaryLaboratory}", "certificate": "${lot.certificateId}", "confidence": "99.6%"},
      {"step": "CERTIFIED_WAREHOUSE", "depository": "${lot.warehouseName}", "bay": "${lot.location}", "status": "DEPOSITED"},
      {"step": "TITLE_REGISTRY", "owner": "${lot.ownership}", "encumbrance": "${lot.encumbrance}"}
    ],
    "traceability_hash": "${lot.traceabilityHash}"
  }
}"""
    }

    private fun buildOrdersJson(orders: List<Order>): String {
        val items = orders.joinToString(",\n    ") {
            """{
      "order_id": "${it.orderId}",
      "symbol": "${it.symbol}",
      "side": "${it.side.name}",
      "type": "${it.orderType.name}",
      "quantity_dmt": ${it.quantityDmt},
      "price": ${it.priceGbp},
      "idempotency_key": "${it.idempotencyKey}",
      "status": "${it.status.name}"
    }"""
        }
        return """{
  "data": [
    $items
  ]
}"""
    }

    private fun buildRfqsJson(rfqs: List<RFQ>): String {
        val items = rfqs.joinToString(",\n    ") {
            """{
      "rfq_id": "${it.rfqId}",
      "buyer": "${it.buyerName}",
      "symbol": "${it.symbol}",
      "quantity_dmt": ${it.requestedQuantityDmt},
      "grade_spec": "${it.gradeSpec}",
      "status": "${it.status}",
      "quotes_count": ${it.quotes.size}
    }"""
        }
        return """{
  "data": [
    $items
  ]
}"""
    }

    private fun buildDeliveriesJson(del: List<DeliveryTracker>): String {
        val items = del.joinToString(",\n    ") {
            """{
      "delivery_id": "${it.deliveryId}",
      "contract_id": "${it.contractId}",
      "carrier": "${it.carrier}",
      "current_stage": "${it.currentStage.title}",
      "stage_number": ${it.currentStage.stageNumber},
      "eta": "${it.eta}"
    }"""
        }
        return """{
  "data": [
    $items
  ]
}"""
    }

    private fun buildQuantJson(quant: QuantMetrics): String {
        return """{
  "data": {
    "symbol": "${quant.symbol}",
    "engine": "RhinoQuant R-Statistical Subsystem",
    "spot_price": ${quant.spotPriceGbp},
    "vwap": ${quant.vwapGbp},
    "twap": ${quant.twapGbp},
    "realized_volatility_30d": ${quant.realizedVol30dPct},
    "rolling_volatility_7d": ${quant.rollingVol7dPct},
    "z_score_basis": ${quant.zScoreBasis},
    "days_of_supply": ${quant.daysOfRegionalSupply},
    "bid_ask_imbalance": ${quant.bidAskImbalanceRatio},
    "market_regime": "${quant.regime.label}",
    "lme_correlation": ${quant.correlationToLme}
  }
}"""
    }

    private fun buildCommoditiesJson(): String {
        return """{
  "data": {
    "historical_minerals": [
      "Tin (Cassiterite)", "Copper (Chalcopyrite)", "Tungsten (Wolframite / Scheelite)",
      "Arsenic (Arsenopyrite)", "Lead (Galena)", "Zinc (Sphalerite)", "Silver (Doré / Argentiferous Galena)",
      "Antimony", "Iron", "Manganese", "Kaolin (China Clay)"
    ],
    "deliverable_categories": [
      "BASE_METALS", "CRITICAL_MINERALS", "CONCENTRATES", "SECONDARY_RECYCLED", "INDUSTRIAL_MINERALS"
    ],
    "regional_districts": [
      "St Just", "Penzance", "Camborne-Pool-Redruth", "St Agnes", "Gwennap",
      "St Austell", "Caradon", "Liskeard", "Tavistock", "Gunnislake", "Calstock", "Bere Alston", "Plymouth"
    ]
  }
}"""
    }
}
