package com.example.swmx.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.swmx.model.*
import com.example.ui.theme.*
import java.util.UUID

@Composable
fun QuickOrderDialog(
    symbol: String,
    initialPrice: Double,
    onDismiss: () -> Unit,
    onSubmit: (OrderSide, OrderType, Double, Double, Double?) -> Unit
) {
    var side by remember { mutableStateOf(OrderSide.BUY) }
    var orderType by remember { mutableStateOf(OrderType.LIMIT) }
    var quantityText by remember { mutableStateOf("25.0") }
    var priceText by remember { mutableStateOf(initialPrice.toInt().toString()) }
    var displayQtyText by remember { mutableStateOf("5.0") }
    val idempotencyKey = remember { "IDEM-" + UUID.randomUUID().toString().take(8).uppercase() }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = TerminalSurface,
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("PLACE SPOT ORDER", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CornishAmber)
                        Text("Physical deliverable instrument: $symbol", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_order_dialog")) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Side Selector (Buy vs Sell)
                Row(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (side == OrderSide.BUY) MarketGreen else TerminalSurfaceElevated)
                            .clickable { side = OrderSide.BUY }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("BUY / BID", fontWeight = FontWeight.Bold, color = if (side == OrderSide.BUY) Color.Black else TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (side == OrderSide.SELL) MarketRed else TerminalSurfaceElevated)
                            .clickable { side = OrderSide.SELL }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("SELL / OFFER", fontWeight = FontWeight.Bold, color = if (side == OrderSide.SELL) Color.White else TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Order Type Selector
                Text("ORDER TYPE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(OrderType.LIMIT, OrderType.MARKET, OrderType.ICEBERG, OrderType.FILL_OR_KILL).forEach { type ->
                        val selected = orderType == type
                        Surface(
                            color = if (selected) TamarCyan.copy(alpha = 0.2f) else TerminalSurfaceElevated,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) TamarCyan else TerminalSurfaceBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { orderType = type }
                        ) {
                            Text(
                                text = type.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) TamarCyanBright else TextSecondary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quantity (DMT)
                Text("QUANTITY (DRY METRIC TONNES - DMT)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("order_quantity_input"),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.labelLarge.copy(color = TextPrimary)
                )

                if (orderType == OrderType.ICEBERG) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("DISPLAY QUANTITY (PEAK SIZE)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = displayQtyText,
                        onValueChange = { displayQtyText = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.labelLarge.copy(color = TextPrimary)
                    )
                }

                if (orderType != OrderType.MARKET) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("LIMIT PRICE (£/t DMT)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("order_price_input"),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.labelLarge.copy(color = TextPrimary)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Idempotency Key & Delivery Location Note
                Surface(
                    color = TerminalBackground,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Idempotency: $idempotencyKey", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("Delivery: FCA Tamar Valley Minerals Hub (Incoterms 2020)", style = MaterialTheme.typography.labelSmall, color = TextCode)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Submit Button
                Button(
                    onClick = {
                        val qty = quantityText.toDoubleOrNull() ?: 10.0
                        val prc = priceText.toDoubleOrNull() ?: initialPrice
                        val disp = if (orderType == OrderType.ICEBERG) displayQtyText.toDoubleOrNull() else null
                        onSubmit(side, orderType, qty, prc, disp)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (side == OrderSide.BUY) MarketGreen else MarketRed
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_order_button")
                ) {
                    Text(
                        text = if (side == OrderSide.BUY) "SUBMIT BUY ORDER" else "SUBMIT SELL ORDER",
                        fontWeight = FontWeight.Bold,
                        color = if (side == OrderSide.BUY) Color.Black else Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun QuickRfqDialog(
    symbol: String,
    commodityName: String,
    onDismiss: () -> Unit,
    onSubmit: (String, String, String, Double, String, String, String, String) -> Unit
) {
    var buyerName by remember { mutableStateOf("Wessex Industrial Refiners Ltd") }
    var quantityText by remember { mutableStateOf("150.0") }
    var gradeSpec by remember { mutableStateOf("Cu >= 24.5%, As <= 0.12%, Moisture <= 8.0%") }
    var deliveryLocation by remember { mutableStateOf("Tamar Valley Minerals Hub / South West") }
    var deliveryWindow by remember { mutableStateOf("14-28 Days") }
    var incoterm by remember { mutableStateOf("FCA Tamar Depository") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = TerminalSurface,
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("REQUEST FOR QUOTE (RFQ)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CornishAmber)
                        Text("Bilateral physical spot tender", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("BUYER ENTITY", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                OutlinedTextField(
                    value = buyerName,
                    onValueChange = { buyerName = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("REQUESTED QUANTITY (DMT)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("GRADE & IMPURITY SPECIFICATION", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                OutlinedTextField(
                    value = gradeSpec,
                    onValueChange = { gradeSpec = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = false,
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("DELIVERY LOCATION", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                OutlinedTextField(
                    value = deliveryLocation,
                    onValueChange = { deliveryLocation = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("WINDOW", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        OutlinedTextField(
                            value = deliveryWindow,
                            onValueChange = { deliveryWindow = it },
                            singleLine = true
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("INCOTERM", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        OutlinedTextField(
                            value = incoterm,
                            onValueChange = { incoterm = it },
                            singleLine = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val qty = quantityText.toDoubleOrNull() ?: 100.0
                        onSubmit(buyerName, symbol, commodityName, qty, gradeSpec, deliveryLocation, deliveryWindow, incoterm)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CornishAmber),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("broadcast_rfq_button")
                ) {
                    Text("BROADCAST RFQ TO PRODUCERS", fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}
