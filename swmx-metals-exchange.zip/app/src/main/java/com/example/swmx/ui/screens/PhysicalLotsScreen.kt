package com.example.swmx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.swmx.model.*
import com.example.swmx.ui.components.*
import com.example.swmx.viewmodel.SWMXViewModel
import com.example.ui.theme.*

@Composable
fun PhysicalLotsScreen(
    viewModel: SWMXViewModel,
    modifier: Modifier = Modifier
) {
    val lots by viewModel.lots.collectAsState()
    val ledger by viewModel.inventoryLedger.collectAsState()
    val disputes by viewModel.disputes.collectAsState()
    val calcState by viewModel.calcState.collectAsState()
    val calcResult by viewModel.calcResult.collectAsState()

    var selectedLot by remember { mutableStateOf<PhysicalLot?>(lots.firstOrNull()) }
    var showAssayDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            SectionHeader(
                title = "Physical Inventory Lots",
                badgeText = "${lots.size} AUDITED LOTS"
            )
        }

        // Lots List
        items(lots) { lot ->
            val isSelected = selectedLot?.lotId == lot.lotId
            Surface(
                color = if (isSelected) TerminalSurfaceElevated else TerminalSurface,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) CornishAmber else TerminalSurfaceBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { selectedLot = lot }
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lot.lotId, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = CornishAmberBright)
                        Surface(
                            color = if (lot.status == "AVAILABLE") MarketGreenBg else CornishAmber.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(3.dp)
                        ) {
                            Text(
                                text = lot.status,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (lot.status == "AVAILABLE") MarketGreenBright else CornishAmberBright,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))
                    Text("${lot.commodity} • ${lot.producerName}", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    Text("Grade: ${lot.gradeSummary}", style = MaterialTheme.typography.bodySmall, color = TamarCyanBright)

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Wet: ${lot.quantityWmt} WMT (Moist ${lot.moisturePct}%)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Dry: ${lot.quantityDmt} DMT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Depository: ${lot.warehouseName} (${lot.location})", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text("Hash: ${lot.traceabilityHash.take(18)}...", style = MaterialTheme.typography.labelSmall, color = TextCode)
                }
            }
        }

        // Contained Metal & Smelter Terms Engine
        item {
            Spacer(modifier = Modifier.height(14.dp))
            SectionHeader(
                title = "Contained Metal & Smelter Terms Engine",
                badgeText = "VALUATION MODEL"
            )

            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("CALCULATOR INPUTS", style = MaterialTheme.typography.labelSmall, color = CornishAmber, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("WET WT (WMT)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            OutlinedTextField(
                                value = calcState.wetWeightTonnes,
                                onValueChange = { v -> viewModel.updateCalcState { it.copy(wetWeightTonnes = v) } },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("MOISTURE %", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            OutlinedTextField(
                                value = calcState.moisturePercent,
                                onValueChange = { v -> viewModel.updateCalcState { it.copy(moisturePercent = v) } },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ASSAY GRADE %", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            OutlinedTextField(
                                value = calcState.gradePercent,
                                onValueChange = { v -> viewModel.updateCalcState { it.copy(gradePercent = v) } },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("REF PRICE (£/t)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            OutlinedTextField(
                                value = calcState.referencePriceGbp,
                                onValueChange = { v -> viewModel.updateCalcState { it.copy(referencePriceGbp = v) } },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = TerminalSurfaceBorder, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Calculation Results Breakdown
                    Text("SETTLEMENT BREAKDOWN", style = MaterialTheme.typography.labelSmall, color = TamarCyanBright, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Dry Metric Tonnes (DMT):", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text("${calcResult.dryWeightTonnes} DMT", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Contained Metal (100%):", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text("${calcResult.containedMetalTonnes} Tonnes", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gross Payable Metal (${calcResult.metalPayablePercent}%):", style = MaterialTheme.typography.bodySmall, color = CornishAmber)
                        Text("${calcResult.grossPayableMetalTonnes} Tonnes", style = MaterialTheme.typography.labelMedium, color = CornishAmberBright, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gross Metal Value:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text("£${String.format("%,.0f", calcResult.grossPayableMetalTonnes * calcResult.referencePriceGbpPerTonne)}", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Treatment Charge (TC £${calcResult.treatmentChargeGbpPerDmt}/dmt):", style = MaterialTheme.typography.bodySmall, color = MarketRedBright)
                        Text("-£${String.format("%,.0f", calcResult.dryWeightTonnes * calcResult.treatmentChargeGbpPerDmt)}", style = MaterialTheme.typography.labelMedium, color = MarketRedBright)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Refining Charge (RC £${calcResult.refiningChargeGbpPerTonnePayable}/t payable):", style = MaterialTheme.typography.bodySmall, color = MarketRedBright)
                        Text("-£${String.format("%,.0f", calcResult.grossPayableMetalTonnes * calcResult.refiningChargeGbpPerTonnePayable)}", style = MaterialTheme.typography.labelMedium, color = MarketRedBright)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Divider(color = TerminalSurfaceBorder, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("NET COMMERCIAL VALUE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text("Effective: £${String.format("%,.0f", calcResult.effectivePricePerDmt)}/dmt", style = MaterialTheme.typography.labelSmall, color = TextCode)
                        }
                        Text("£${String.format("%,.0f", calcResult.netSettlementValueGbp)}", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = MarketGreenBright)
                    }
                }
            }
        }

        // Assay Disputes & Referee Arbitrations
        item {
            Spacer(modifier = Modifier.height(14.dp))
            SectionHeader(
                title = "Assay Dispute Engine & Referee Office",
                badgeText = "${disputes.size} CASE"
            )
        }

        items(disputes) { disp ->
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(disp.disputeId, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = WolframPurpleBright)
                        Surface(
                            color = MarketGreenBg,
                            shape = RoundedCornerShape(3.dp)
                        ) {
                            Text(disp.status, style = MaterialTheme.typography.labelSmall, color = MarketGreenBright, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                        }
                    }
                    Text("Lot: ${disp.lotId} (Element: ${disp.element})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Seller Assay: ${disp.sellerValue}%", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Buyer Assay: ${disp.buyerValue}%", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Referee: ${disp.refereeValue ?: "Pending"}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = CornishAmberBright)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(disp.resolutionNotes, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        }

        // Double-entry Inventory Ledger
        item {
            Spacer(modifier = Modifier.height(14.dp))
            SectionHeader(
                title = "Double-Entry Depository Ledger",
                badgeText = "CUSTODIAL TRUTH"
            )
        }

        items(ledger) { entry ->
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(entry.eventType, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = if (entry.quantityDeltaDmt >= 0) MarketGreenBright else MarketRedBright)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(entry.lotId, style = MaterialTheme.typography.labelSmall, color = TextCode)
                        }
                        Text("${entry.timestamp} • Ref: ${entry.referenceId}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${if (entry.quantityDeltaDmt >= 0) "+" else ""}${entry.quantityDeltaDmt} DMT", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = if (entry.quantityDeltaDmt >= 0) MarketGreenBright else MarketRedBright)
                        Text("Bal: ${entry.balanceAfterDmt} DMT", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
