package com.example.swmx.model

enum class RegimeType(val label: String, val badgeColorHex: Long) {
    HIGH_GRADE_SCARCITY("High Grade Scarcity", 0xFFF59E0B),
    TAMAR_CONSOLIDATION("Tamar Basin Consolidation", 0xFF06B6D4),
    SMELTER_DEMAND_SURGE("Smelter Demand Surge", 0xFF10B981),
    REGIONAL_ARBITRAGE("Regional Basis Arbitrage", 0xFFA855F7),
    BALANCED_PHYSICAL("Balanced Physical Flow", 0xFF64748B)
}

data class CurvePoint(
    val tenor: String, // "SPOT", "7D", "30D", "60D", "90D", "180D", "1Y"
    val daysToDelivery: Int,
    val priceGbp: Double,
    val bidGbp: Double,
    val offerGbp: Double,
    val basisGbp: Double,
    val volumeTonnes: Double,
    val openInterestDmt: Double,
    val simulated: Boolean = true
)

data class QuantMetrics(
    val symbol: String,
    val spotPriceGbp: Double,
    val vwapGbp: Double,
    val twapGbp: Double,
    val bidAskSpreadGbp: Double,
    val realizedVol30dPct: Double,
    val rollingVol7dPct: Double,
    val momentum14d: Double,
    val zScoreBasis: Double,
    val daysOfRegionalSupply: Double,
    val bidAskImbalanceRatio: Double, // +0.4 = bid heavy, -0.4 = ask heavy
    val priceDispersionGbp: Double,
    val assayDispersionCuPct: Double,
    val regionalPremiumPct: Double,
    val regime: RegimeType,
    val correlationToLme: Double,
    val rModelStatus: String = "R-RhinoQuant engine active (v3.6.2-swmx)"
)

data class ContainedMetalCalculation(
    val wetWeightTonnes: Double,
    val moisturePercent: Double,
    val dryWeightTonnes: Double,
    val gradePercent: Double,
    val containedMetalTonnes: Double,
    val metalPayablePercent: Double,
    val grossPayableMetalTonnes: Double,
    val referencePriceGbpPerTonne: Double,
    val treatmentChargeGbpPerDmt: Double,
    val refiningChargeGbpPerTonnePayable: Double,
    val arsenicPenaltyGbp: Double,
    val netSettlementValueGbp: Double,
    val effectivePricePerDmt: Double
)
