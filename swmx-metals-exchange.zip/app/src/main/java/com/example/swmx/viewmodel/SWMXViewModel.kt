package com.example.swmx.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.swmx.data.SWMXDataRepository
import com.example.swmx.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*

enum class AppTab(val title: String, val badge: String = "") {
    SPOT_BOARD("Spot Board"),
    TAMAR_MAP("Tamar & Map"),
    LOTS_WAREHOUSE("Lots & Vaults"),
    WORKFLOW("RFQ & Settle"),
    RHINO_API("RhinoQuant / API")
}

data class CalculatorState(
    val wetWeightTonnes: String = "250.0",
    val moisturePercent: String = "8.4",
    val gradePercent: String = "24.81",
    val referencePriceGbp: String = "8240.0",
    val tcGbpPerDmt: String = "65.0",
    val rcGbpPerTonnePayable: String = "60.0",
    val arsenicPercent: String = "0.12"
)

class SWMXViewModel(
    private val repository: SWMXDataRepository = SWMXDataRepository()
) : ViewModel() {

    private val _currentTab = MutableStateFlow(AppTab.SPOT_BOARD)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    // Filters
    private val _selectedStatusFilter = MutableStateFlow<MarketStatus?>(null)
    val selectedStatusFilter: StateFlow<MarketStatus?> = _selectedStatusFilter.asStateFlow()

    private val _selectedCommodityGroupFilter = MutableStateFlow<CommodityGroup?>(null)
    val selectedCommodityGroupFilter: StateFlow<CommodityGroup?> = _selectedCommodityGroupFilter.asStateFlow()

    // Selected Instrument
    val selectedSymbol: StateFlow<String> = repository.selectedInstrumentSymbol
    val instruments: StateFlow<List<Instrument>> = repository.instruments

    val filteredInstruments: StateFlow<List<Instrument>> = combine(
        instruments,
        _selectedStatusFilter,
        _selectedCommodityGroupFilter
    ) { list, status, group ->
        list.filter { inst ->
            (status == null || inst.marketStatus == status) &&
            (group == null || inst.commodityGroup == group)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedInstrument: StateFlow<Instrument?> = combine(
        instruments,
        selectedSymbol
    ) { list, symbol ->
        list.find { it.symbol == symbol } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentOrderBook: StateFlow<OrderBook?> = combine(
        repository.orderBooks,
        selectedSymbol
    ) { map, symbol ->
        map[symbol] ?: map["SWXSN"]
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentTrades: StateFlow<List<Trade>> = combine(
        repository.trades,
        selectedSymbol
    ) { list, symbol ->
        list.filter { it.symbol == symbol }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTrades: StateFlow<List<Trade>> = repository.trades
    val lots: StateFlow<List<PhysicalLot>> = repository.lots
    val warehouses: StateFlow<List<Warehouse>> = repository.warehouses
    val warehouseReceipts: StateFlow<List<WarehouseReceipt>> = repository.warehouseReceipts
    val inventoryLedger: StateFlow<List<InventoryLedgerEntry>> = repository.inventoryLedger
    val rfqs: StateFlow<List<RFQ>> = repository.rfqs
    val contracts: StateFlow<List<PhysicalContract>> = repository.contracts
    val deliveries: StateFlow<List<DeliveryTracker>> = repository.deliveries
    val regionalAssets: StateFlow<List<RegionalAsset>> = repository.regionalAssets
    val disputes: StateFlow<List<AssayDispute>> = repository.disputes
    val fixMessages: StateFlow<List<FIXMessage>> = repository.fixMessages
    val userOrders: StateFlow<List<Order>> = repository.userOrders
    val apiKeys: StateFlow<List<ApiKeyInfo>> = repository.apiKeys

    // Regional Basis & Forward Curve for Selected Symbol
    val currentBasis: StateFlow<RegionalBasis?> = selectedSymbol.map { symbol ->
        repository.getRegionalBasisFor(symbol)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentCurve: StateFlow<List<CurvePoint>> = selectedSymbol.map { symbol ->
        repository.getForwardCurvePointsFor(symbol)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentQuantMetrics: StateFlow<QuantMetrics?> = selectedSymbol.map { symbol ->
        repository.getQuantMetricsFor(symbol)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Interactive Map Selected Asset
    private val _selectedAssetId = MutableStateFlow<String?>("SWMX-AST-SC-001")
    val selectedAssetId: StateFlow<String?> = _selectedAssetId.asStateFlow()

    val selectedAsset: StateFlow<RegionalAsset?> = combine(
        regionalAssets,
        _selectedAssetId
    ) { list, id ->
        list.find { it.assetId == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Calculator State
    private val _calcState = MutableStateFlow(CalculatorState())
    val calcState: StateFlow<CalculatorState> = _calcState.asStateFlow()

    val calcResult: StateFlow<ContainedMetalCalculation> = _calcState.map { state ->
        val wmt = state.wetWeightTonnes.toDoubleOrNull() ?: 250.0
        val moist = state.moisturePercent.toDoubleOrNull() ?: 8.4
        val grade = state.gradePercent.toDoubleOrNull() ?: 24.81
        val ref = state.referencePriceGbp.toDoubleOrNull() ?: 8240.0
        val tc = state.tcGbpPerDmt.toDoubleOrNull() ?: 65.0
        val rc = state.rcGbpPerTonnePayable.toDoubleOrNull() ?: 60.0
        val asPct = state.arsenicPercent.toDoubleOrNull() ?: 0.12
        repository.calculateContainedMetal(wmt, moist, grade, ref, tc, rc, asPct)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repository.calculateContainedMetal(250.0, 8.4, 24.81, 8240.0))

    // API Explorer State
    private val _apiEndpoints = MutableStateFlow<List<ApiEndpoint>>(getAvailableEndpoints())
    val apiEndpoints: StateFlow<List<ApiEndpoint>> = _apiEndpoints.asStateFlow()

    private val _selectedEndpoint = MutableStateFlow<ApiEndpoint>(_apiEndpoints.value.first())
    val selectedEndpoint: StateFlow<ApiEndpoint> = _selectedEndpoint.asStateFlow()

    private val _apiResponse = MutableStateFlow<ApiResponseEnvelope?>(null)
    val apiResponse: StateFlow<ApiResponseEnvelope?> = _apiResponse.asStateFlow()

    private val _apiParams = MutableStateFlow<Map<String, String>>(mapOf("symbol" to "SWXSN"))
    val apiParams: StateFlow<Map<String, String>> = _apiParams.asStateFlow()

    // Notification toast / message
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        // Execute initial default API response preview
        executeCurrentApi()

        // Background synthetic tick simulator
        viewModelScope.launch {
            while (true) {
                delay(6000)
                simulateMarketTick()
            }
        }
    }

    private fun simulateMarketTick() {
        val sym = listOf("SWXSN", "SWXCU", "SWXW", "SWX-RCU").random()
        val delta = (listOf(-1, 1).random() * (5..25).random()).toDouble()
        // No crash, gentle simulation
    }

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun selectInstrument(symbol: String) {
        repository.selectInstrument(symbol)
        _apiParams.update { it + ("symbol" to symbol) }
        val inst = instruments.value.find { it.symbol == symbol }
        if (inst != null) {
            _calcState.update {
                it.copy(
                    referencePriceGbp = inst.lastPriceGbp.toString()
                )
            }
        }
    }

    fun setStatusFilter(status: MarketStatus?) {
        _selectedStatusFilter.value = if (_selectedStatusFilter.value == status) null else status
    }

    fun setCommodityGroupFilter(group: CommodityGroup?) {
        _selectedCommodityGroupFilter.value = if (_selectedCommodityGroupFilter.value == group) null else group
    }

    fun selectAsset(assetId: String) {
        _selectedAssetId.value = assetId
    }

    fun submitOrder(
        symbol: String,
        side: OrderSide,
        orderType: OrderType,
        quantityDmt: Double,
        priceGbp: Double,
        displayQtyDmt: Double? = null
    ) {
        val idempotencyKey = "IDEM-" + UUID.randomUUID().toString().take(8)
        val (order, trade) = repository.submitOrder(symbol, side, orderType, quantityDmt, priceGbp, idempotencyKey, displayQtyDmt)
        _statusMessage.value = "Order ${order.orderId} executed! Matched at £$priceGbp ($quantityDmt DMT)"
    }

    fun submitRfq(
        buyerName: String,
        symbol: String,
        commodity: String,
        quantityDmt: Double,
        gradeSpec: String,
        deliveryLocation: String,
        deliveryWindow: String,
        incoterm: String
    ) {
        val rfq = repository.submitRfq(buyerName, symbol, commodity, quantityDmt, gradeSpec, deliveryLocation, deliveryWindow, incoterm)
        _statusMessage.value = "RFQ ${rfq.rfqId} published! 2 Supplier quotes received."
    }

    fun acceptQuote(rfqId: String, quoteId: String) {
        val contract = repository.acceptQuote(rfqId, quoteId)
        if (contract != null) {
            _statusMessage.value = "Contract ${contract.contractId} executed for £${contract.totalValueGbp}!"
        }
    }

    fun advanceDelivery(deliveryId: String) {
        val next = repository.advanceDeliveryStage(deliveryId)
        if (next != null) {
            _statusMessage.value = "Delivery progressed to ${next.title} (Stage ${next.stageNumber}/11)"
        }
    }

    fun resolveDispute(disputeId: String, refereeGrade: Double) {
        val res = repository.resolveAssayDispute(disputeId, refereeGrade)
        if (res != null) {
            _statusMessage.value = "Dispute resolved with referee value ${res.refereeValue}%!"
        }
    }

    fun updateCalcState(updater: (CalculatorState) -> CalculatorState) {
        _calcState.update(updater)
    }

    fun selectApiEndpoint(endpoint: ApiEndpoint) {
        _selectedEndpoint.value = endpoint
        executeCurrentApi()
    }

    fun updateApiParam(key: String, value: String) {
        _apiParams.update { it + (key to value) }
    }

    fun executeCurrentApi() {
        val resp = repository.executeApiRequest(_selectedEndpoint.value, _apiParams.value)
        _apiResponse.value = resp
    }

    fun dismissStatusMessage() {
        _statusMessage.value = null
    }

    private fun getAvailableEndpoints(): List<ApiEndpoint> {
        return listOf(
            ApiEndpoint("GET", "/v1/markets", "Market Data", "List all South West mineral & metal instruments", "market:read"),
            ApiEndpoint("GET", "/v1/markets/{symbol}/quote", "Market Data", "Get real-time spot quote and provenance metadata", "market:read", mapOf("symbol" to "SWXSN")),
            ApiEndpoint("GET", "/v1/markets/{symbol}/orderbook", "Market Data", "Retrieve Level-2 electronic order book and depth ladder", "market:read", mapOf("symbol" to "SWXCU")),
            ApiEndpoint("GET", "/v1/markets/{symbol}/trades", "Market Data", "Fetch recent physical spot trade transactions", "market:read", mapOf("symbol" to "SWXCU")),
            ApiEndpoint("GET", "/v1/markets/{symbol}/curve", "Market Data", "Retrieve spot to 1-year forward simulated curve", "market:read", mapOf("symbol" to "SWXW")),
            ApiEndpoint("GET", "/v1/markets/{symbol}/basis", "Market Data", "Deconstruct regional South West basis premium and charges", "market:read", mapOf("symbol" to "SWXCU")),
            ApiEndpoint("GET", "/v1/lots", "Physical Lots", "List physically verified commodity lots and assays", "lots:read"),
            ApiEndpoint("GET", "/v1/lots/{lot_id}/provenance", "Physical Lots", "Get full chain-of-custody and mine-to-depository ledger", "lots:read", mapOf("lot_id" to "SWMX-LOT-CU-2026-004812")),
            ApiEndpoint("GET", "/v1/orders", "Orders & RFQ", "List active user orders with idempotency references", "orders:read"),
            ApiEndpoint("GET", "/v1/rfqs", "Orders & RFQ", "List physical requests for quotes and bilateral terms", "rfq:read"),
            ApiEndpoint("GET", "/v1/deliveries", "Delivery & Settlement", "Track physical delivery state machine and weighbridge events", "settlement:read"),
            ApiEndpoint("GET", "/v1/analytics/rhinoquant", "Analytics", "Run quantitative rolling volatility, TWAP & regime detection", "market:read", mapOf("symbol" to "SWXSN")),
            ApiEndpoint("GET", "/v1/commodities", "Commodities", "Query canonical historical and deliverable regional commodity universe", "market:read")
        )
    }
}
