package com.example.swmx.model

enum class AssetType(val label: String, val iconName: String) {
    MINE("Mine", "landscape"),
    PROSPECT("Exploration Prospect", "radar"),
    PROCESSING_PLANT("Processing Plant", "precision_manufacturing"),
    WAREHOUSE("Certified Warehouse", "warehouse"),
    SMELTER("Smelter", "local_fire_department"),
    REFINERY("Refinery", "science"),
    RECYCLING_PLANT("Recycling Facility", "recycling"),
    PORT("Port / Marine Terminal", "directions_boat"),
    TRANSPORT_TERMINAL("Rail / Road Terminal", "local_shipping"),
    LABORATORY("Assay Laboratory", "biotech")
}

enum class AssetStatus(val label: String, val badgeColorHex: Long) {
    HISTORIC("Historic", 0xFF8B5CF6),
    HISTORICAL("Historic Heritage", 0xFF8B5CF6),
    ACTIVE("Active / Operating", 0xFF10B981),
    CARE_AND_MAINTENANCE("Care & Maintenance", 0xFFEAB308),
    EXPLORATION("Exploration", 0xFF3B82F6),
    DEVELOPMENT("Development / Feasibility", 0xFFF97316),
    CLOSED("Closed / Heritage", 0xFF64748B),
    REPROCESSING("Tailings Reprocessing", 0xFF14B8A6),
    REHABILITATION("Rehabilitation", 0xFF94A3B8),
    SYNTHETIC_DEMO("Synthetic Demo Participant", 0xFF06B6D4)
}

data class RegionalAsset(
    val assetId: String,
    val name: String,
    val district: String,
    val county: String, // "Cornwall" or "Devon"
    val assetType: AssetType,
    val status: AssetStatus,
    val primaryCommodities: List<String>,
    val latitude: Double,
    val longitude: Double,
    val historicalSummary: String,
    val modernStatusNotes: String,
    val certifiedWarehouseCapacityTonnes: Double? = null,
    val activeLotIds: List<String> = emptyList(),
    val historicalPeakYear: String? = null,
    val heritageStatus: String = "Cornwall & West Devon Mining Landscape UNESCO WHS"
)
