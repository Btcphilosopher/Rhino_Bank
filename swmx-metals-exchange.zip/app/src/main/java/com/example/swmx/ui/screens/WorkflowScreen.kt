package com.example.swmx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.swmx.model.*
import com.example.swmx.ui.components.*
import com.example.swmx.viewmodel.SWMXViewModel
import com.example.ui.theme.*

@Composable
fun WorkflowScreen(
    viewModel: SWMXViewModel,
    modifier: Modifier = Modifier
) {
    val rfqs by viewModel.rfqs.collectAsState()
    val contracts by viewModel.contracts.collectAsState()
    val deliveries by viewModel.deliveries.collectAsState()

    var showRfqDialog by remember { mutableStateOf(false) }

    if (showRfqDialog) {
        QuickRfqDialog(
            symbol = "SWXCU",
            commodityName = "Copper Concentrate",
            onDismiss = { showRfqDialog = false },
            onSubmit = { buyer, sym, comm, qty, spec, loc, win, incoterm ->
                viewModel.submitRfq(buyer, sym, comm, qty, spec, loc, win, incoterm)
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            // Physical Lifecycle Stepper Header
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "PHYSICAL COMMODITIES SPOT LIFECYCLE",
                        style = MaterialTheme.typography.labelSmall,
                        color = CornishAmber,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("DISCOVER", "QUOTE", "ORDER", "MATCH", "ASSAY", "DELIVER", "SETTLE").forEachIndexed { idx, step ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = TerminalSurfaceElevated,
                                    shape = RoundedCornerShape(4.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, TamarCyan.copy(alpha = 0.4f))
                                ) {
                                    Text(
                                        text = "${idx + 1}. $step",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                                if (idx < 6) {
                                    Text(" → ", color = TextMuted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        // RFQ (Request for Quote) Management
        item {
            SectionHeader(
                title = "Bilateral RFQ Tenders",
                actionText = "+ NEW RFQ",
                onActionClick = { showRfqDialog = true },
                badgeText = "${rfqs.size} ACTIVE"
            )
        }

        items(rfqs) { rfq ->
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(rfq.rfqId, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = CornishAmberBright)
                        Surface(
                            color = if (rfq.status == "CONTRACTED") MarketGreenBg else CornishAmber.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(3.dp)
                        ) {
                            Text(
                                text = rfq.status,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (rfq.status == "CONTRACTED") MarketGreenBright else CornishAmberBright,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${rfq.commodity} (${rfq.requestedQuantityDmt} DMT) • ${rfq.buyerName}", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    Text("Spec: ${rfq.gradeSpec}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Destination: ${rfq.deliveryLocation} (${rfq.incoterm})", style = MaterialTheme.typography.labelSmall, color = TextMuted)

                    // Received Supplier Quotes
                    if (rfq.quotes.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("RECEIVED QUOTES (${rfq.quotes.size}):", style = MaterialTheme.typography.labelSmall, color = TamarCyanBright, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))

                        rfq.quotes.forEach { quote ->
                            Surface(
                                color = TerminalSurfaceElevated,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(quote.sellerName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                                        Text("£${quote.priceGbpPerDmt.toInt()}/t DMT • ${quote.warehouseLocation}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                    }

                                    if (!quote.accepted && rfq.status != "CONTRACTED") {
                                        Button(
                                            onClick = { viewModel.acceptQuote(rfq.rfqId, quote.quoteId) },
                                            colors = ButtonDefaults.buttonColors(containerColor = MarketGreen),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.height(32.dp).testTag("accept_quote_button")
                                        ) {
                                            Text("ACCEPT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                                        }
                                    } else if (quote.accepted) {
                                        Surface(color = MarketGreenBg, shape = RoundedCornerShape(3.dp)) {
                                            Text("ACCEPTED & CONTRACTED", style = MaterialTheme.typography.labelSmall, color = MarketGreenBright, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Executed Physical Contracts
        item {
            Spacer(modifier = Modifier.height(14.dp))
            SectionHeader(
                title = "Executed Physical Spot Contracts",
                badgeText = "${contracts.size} CONTRACTS"
            )
        }

        items(contracts) { ctr ->
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(ctr.contractId, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = CornishAmberBright)
                        Text("VALUE: £${String.format("%,.0f", ctr.totalValueGbp)}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TamarCyanBright)
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text("${ctr.commodity} (${ctr.quantityDmt} DMT @ £${ctr.priceGbpPerDmt.toInt()}/t)", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    Text("Buyer: ${ctr.buyer} | Seller: ${ctr.seller}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Incoterm: ${ctr.incoterm} | Depository: ${ctr.warehouse}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(ctr.assayClause, style = MaterialTheme.typography.labelSmall, color = TextCode)
                }
            }
        }

        // 11-Stage Delivery State Machine Tracker
        item {
            Spacer(modifier = Modifier.height(14.dp))
            SectionHeader(
                title = "11-Stage Physical Delivery Machine",
                badgeText = "LOGISTICS & ESCROW"
            )
        }

        items(deliveries) { del ->
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TamarCyan.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(del.deliveryId, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TamarCyanBright)
                            Text("Contract: ${del.contractId}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }

                        // Advance Stage Action
                        if (del.currentStage != DeliveryStage.SETTLED) {
                            Button(
                                onClick = { viewModel.advanceDelivery(del.deliveryId) },
                                colors = ButtonDefaults.buttonColors(containerColor = TamarCyan),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("advance_delivery_button")
                            ) {
                                Text("ADVANCE STAGE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        } else {
                            Surface(color = MarketGreenBg, shape = RoundedCornerShape(3.dp)) {
                                Text("FULLY SETTLED", style = MaterialTheme.typography.labelSmall, color = MarketGreenBright, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Progress Bar
                    val currentStepNum = del.currentStage.stageNumber
                    LinearProgressIndicator(
                        progress = { currentStepNum / 11.0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = TamarCyanBright,
                        trackColor = TerminalSurfaceBorder,
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "STAGE $currentStepNum/11: ${del.currentStage.title}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = CornishAmberBright
                        )
                        Text(del.currentStage.description, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Carrier: ${del.carrier} (${del.vehicleReg})", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text("Route: ${del.origin} → ${del.destination}", style = MaterialTheme.typography.labelSmall, color = TextMuted)

                    // Event Timeline Log
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("AUDIT LOG (${del.events.size} EVENTS):", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    del.events.takeLast(4).forEach { evt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("• [${evt.stage.title}] ${evt.notes}", style = MaterialTheme.typography.labelSmall, color = TextPrimary, modifier = Modifier.weight(1f))
                            Text(evt.signatureHash.take(8), style = MaterialTheme.typography.labelSmall, color = TextCode)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
