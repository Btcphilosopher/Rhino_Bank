package com.example.swmx.model

enum class MarketStatus(val label: String, val description: String) {
    ACTIVE("ACTIVE", "Currently deliverable inventory & live liquidity"),
    HISTORICAL("HISTORICAL", "Documented heritage production asset / benchmark series"),
    EXPLORATION("EXPLORATION", "Active drill/sampling programme under UK mineral licenses"),
    DEVELOPMENT("DEVELOPMENT", "Under active development/feasibility towards production"),
    RECYCLING("RECYCLING", "Secondary metal recovery & industrial scrap stream"),
    ILLUSTRATIVE("ILLUSTRATIVE", "Synthetic simulation model for market calibration"),
    UNAVAILABLE("UNAVAILABLE", "Trading suspended or depleted reserve")
}

enum class CommodityGroup(val label: String) {
    BASE_METALS("Base Metals"),
    CRITICAL_MINERALS("Critical Minerals"),
    PRECIOUS_METALS("Precious Metals"),
    SECONDARY_RECYCLED("Secondary / Recycled"),
    CONCENTRATES("Mineral Concentrates"),
    INDUSTRIAL_MINERALS("Industrial Minerals")
}

enum class PhysicalForm(val label: String) {
    ORE("Run of Mine Ore"),
    CONCENTRATE("Mineral Concentrate"),
    CATHODE("Refined Cathode"),
    GRANULES("Metal Granules"),
    INGOT("Cast Ingots"),
    SCRAP("Secondary Scrap"),
    WIRE("Drawn Wire"),
    OXIDE("Processed Oxide"),
    DORE("Precious Metal Doré"),
    MIXED_NON_FERROUS("Mixed Non-Ferrous")
}

enum class WeightUnit(val symbol: String, val fullName: String) {
    DMT("DMT", "Dry Metric Tonnes"),
    WMT("WMT", "Wet Metric Tonnes"),
    MT("t", "Metric Tonnes"),
    KG("kg", "Kilograms"),
    TOZ("oz tr", "Troy Ounces"),
    CONTAINED_MT("t Cu/Sn", "Contained Metal Tonnes")
}

data class AssayProfile(
    val elements: Map<String, Double>, // e.g. "Cu" -> 24.8, "Sn" -> 61.4, "WO3" -> 62.2, "Ag_gpt" -> 42.0, "Au_gpt" -> 1.7, "As" -> 0.12, "Fe" -> 4.1, "Pb" -> 0.41, "Zn" -> 0.72, "Moisture" -> 8.4
    val primaryLaboratory: String = "Cornish Assay Office Ltd (Redruth)",
    val sampleId: String,
    val assayDate: String,
    val method: String = "XRF + ICP-OES Fusion",
    val confidencePct: Double = 99.4,
    val certificateId: String,
    val verified: Boolean = true
)

data class AssayDispute(
    val disputeId: String,
    val lotId: String,
    val element: String,
    val buyerValue: Double,
    val sellerValue: Double,
    val refereeValue: Double? = null,
    val thresholdPct: Double = 0.25,
    val status: String, // "PENDING_REFEREE", "RESOLVED", "SPLIT_DIFFERENCE"
    val resolutionNotes: String = "",
    val settlementAdjustmentGbp: Double = 0.0
)

data class PhysicalLot(
    val lotId: String, // SWMX-LOT-CU-2026-004812
    val symbol: String, // SWXCU
    val commodity: String, // Copper Concentrate
    val producerName: String,
    val mineOrFacility: String,
    val batch: String,
    val quantityWmt: Double,
    val moisturePct: Double,
    val quantityDmt: Double,
    val gradeSummary: String, // "Cu 24.8% | Ag 42g/t | As 0.12%"
    val assayProfile: AssayProfile,
    val packaging: String, // "1.5t Big Bags (UN certified)", "Bulk Container", "Bundled Ingots"
    val warehouseId: String,
    val warehouseName: String,
    val location: String, // "Tamar Valley Minerals Hub, Gunnislake"
    val productionDate: String,
    val availableDate: String,
    val deliveryWindow: String, // "Prompt (3-5 days)"
    val ownership: String,
    val encumbrance: String = "Free and Clear of Liens",
    val status: String, // "AVAILABLE", "RESERVED", "DELIVERED", "IN_TRANSIT"
    val certificateId: String,
    val traceabilityHash: String,
    val qrCodeContent: String
)

data class Warehouse(
    val warehouseId: String,
    val name: String,
    val operator: String,
    val district: String,
    val county: String,
    val capacityTonnes: Double,
    val utilizedTonnes: Double,
    val availableTonnes: Double,
    val reservedTonnes: Double,
    val commodityRestrictions: List<String>,
    val assayFacilities: Boolean,
    val loadingFacilities: String,
    val transportLinks: String,
    val storageFeeGbpPerDay: Double,
    val receiptsIssuedCount: Int
)

data class WarehouseReceipt(
    val receiptId: String, // SWMX-WHR-2026-00891
    val lotId: String,
    val commodity: String,
    val quantityDmt: Double,
    val grade: String,
    val owner: String,
    val warehouseName: String,
    val issueDate: String,
    val expiryReviewDate: String,
    val status: String, // "ACTIVE", "PLEDGED", "SETTLED"
    val qrHash: String
)

data class InventoryLedgerEntry(
    val entryId: String,
    val timestamp: String,
    val lotId: String,
    val warehouseId: String,
    val eventType: String, // "LOT_CREATED", "RESERVED", "RELEASED", "DISPATCHED", "ASSAY_ADJUSTED"
    val quantityDeltaDmt: Double,
    val balanceAfterDmt: Double,
    val referenceId: String,
    val operator: String
)

data class RegionalBasis(
    val symbol: String,
    val commodityName: String,
    val globalReferencePriceGbp: Double,
    val ukReferencePriceGbp: Double,
    val southWestBasisPremiumGbp: Double,
    val freightAdjustmentGbp: Double,
    val gradeAdjustmentGbp: Double,
    val tcRcAdjustmentGbp: Double, // Treatment/Refining Charge
    val warehouseInsuranceGbp: Double,
    val indicativeSwmxPhysicalPriceGbp: Double,
    val basisHistory7d: List<Double>
)

data class Instrument(
    val instrumentId: String, // e.g. SWMX-SN-99.95-GB-CW-001
    val symbol: String, // SWXSN
    val commodity: String, // Cornish Tin
    val commodityGroup: CommodityGroup,
    val marketStatus: MarketStatus,
    val region: String, // Cornwall / Tamar / Devon
    val country: String = "United Kingdom",
    val physicalForm: PhysicalForm,
    val minimumLot: Double,
    val lotUnit: WeightUnit,
    val priceUnit: String, // "£/t DMT", "£/kg", "£/oz"
    val currency: String = "GBP",
    val deliverable: Boolean,
    val assayRequired: Boolean,
    val warehouseEligible: Boolean,
    val lastPriceGbp: Double,
    val changePct24h: Double,
    val dayHighGbp: Double,
    val dayLowGbp: Double,
    val vwapGbp: Double,
    val volume24hDmt: Double,
    val turnoverGbp: Double,
    val activeLotsCount: Int,
    val totalAvailableInventoryDmt: Double,
    val benchmarkReference: String, // "LME Tin Cash + SW Premium"
    val description: String,
    val defaultAssayGrade: String
)
