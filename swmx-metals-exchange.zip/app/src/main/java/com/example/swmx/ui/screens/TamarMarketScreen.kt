package com.example.swmx.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.swmx.model.*
import com.example.swmx.ui.components.*
import com.example.swmx.viewmodel.SWMXViewModel
import com.example.ui.theme.*

@Composable
fun TamarMarketScreen(
    viewModel: SWMXViewModel,
    modifier: Modifier = Modifier
) {
    val regionalAssets by viewModel.regionalAssets.collectAsState()
    val selectedAssetId by viewModel.selectedAssetId.collectAsState()
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val receipts by viewModel.warehouseReceipts.collectAsState()
    val warehouses by viewModel.warehouses.collectAsState()

    var selectedCountyFilter by remember { mutableStateOf<String?>(null) } // "Cornwall", "Devon", null

    val filteredAssets = remember(regionalAssets, selectedCountyFilter) {
        if (selectedCountyFilter == null) regionalAssets
        else regionalAssets.filter { it.county.equals(selectedCountyFilter, ignoreCase = true) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            // Signature Tamar Banner
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TamarCyan.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Waves, contentDescription = null, tint = TamarCyanBright, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "THE TAMAR PHYSICAL MARKET",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TamarCyanBright,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Surface(
                            color = TamarCyan.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "REGIONAL HUB",
                                color = TamarCyanBright,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Physical gateway connecting Tamar Valley, Dartmoor, Camborne-Redruth & St Just polymetallic production and warehouse depots.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        // County Selector Pills
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Pair("ALL DISTRICTS", null),
                    Pair("CORNWALL", "Cornwall"),
                    Pair("WEST DEVON / TAMAR", "Devon")
                ).forEach { (label, county) ->
                    val isSelected = selectedCountyFilter == county
                    Surface(
                        color = if (isSelected) TamarCyan else TerminalSurfaceElevated,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TamarCyan else TerminalSurfaceBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedCountyFilter = county }
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) Color.Black else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Interactive Vector Map Canvas of Cornwall & Devon
        item {
            SectionHeader(
                title = "Regional Mining Landscape Map",
                badgeText = "20,000 HECTARES UNESCO WHS"
            )

            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(filteredAssets) {
                                detectTapGestures { offset ->
                                    // Hit test nearby asset pins
                                    val w = size.width
                                    val h = size.height
                                    // Longitude range: -5.7 to -4.0 (Cornwall west to Plymouth east)
                                    // Latitude range: 50.1 to 50.6 (St Just south to Tavistock north)
                                    filteredAssets.minByOrNull { asset ->
                                        val normX = ((asset.longitude - (-5.75)) / 1.8).toFloat() * w
                                        val normY = (1f - ((asset.latitude - 50.1) / 0.55).toFloat()) * h
                                        val dx = normX - offset.x
                                        val dy = normY - offset.y
                                        dx * dx + dy * dy
                                    }?.let { closest ->
                                        viewModel.selectAsset(closest.assetId)
                                    }
                                }
                            }
                    ) {
                        val w = size.width
                        val h = size.height

                        // Draw Grid lines
                        for (i in 1..4) {
                            val x = w * (i / 5f)
                            drawLine(
                                color = TerminalSurfaceBorder.copy(alpha = 0.5f),
                                start = Offset(x, 0f),
                                end = Offset(x, h),
                                strokeWidth = 1f
                            )
                            val y = h * (i / 5f)
                            drawLine(
                                color = TerminalSurfaceBorder.copy(alpha = 0.5f),
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1f
                            )
                        }

                        // Draw Simplified Cornish & Devon Coastline / Tamar River
                        val coastPath = Path().apply {
                            // Land polygon representation
                            moveTo(w * 0.05f, h * 0.85f) // St Just / Land's End
                            lineTo(w * 0.18f, h * 0.70f) // St Ives / Hayle
                            lineTo(w * 0.30f, h * 0.55f) // St Agnes
                            lineTo(w * 0.55f, h * 0.40f) // North Cornwall
                            lineTo(w * 0.75f, h * 0.20f) // North Devon
                            lineTo(w * 0.95f, h * 0.45f) // Dartmoor / South Devon
                            lineTo(w * 0.88f, h * 0.78f) // Plymouth Sound
                            lineTo(w * 0.65f, h * 0.75f) // Fowey / Par
                            lineTo(w * 0.45f, h * 0.85f) // Falmouth / Carrick Roads
                            lineTo(w * 0.28f, h * 0.95f) // Lizard
                            close()
                        }
                        drawPath(
                            path = coastPath,
                            color = TerminalSurfaceElevated.copy(alpha = 0.7f)
                        )
                        drawPath(
                            path = coastPath,
                            color = TerminalSurfaceBorder,
                            style = Stroke(width = 1.5f)
                        )

                        // River Tamar Boundary Line (Cornwall - Devon border)
                        val tamarRiver = Path().apply {
                            moveTo(w * 0.72f, h * 0.15f)
                            quadraticTo(w * 0.75f, h * 0.45f, w * 0.78f, h * 0.76f)
                        }
                        drawPath(
                            path = tamarRiver,
                            color = TamarCyan.copy(alpha = 0.8f),
                            style = Stroke(width = 2.5f)
                        )

                        // Plot Asset Pins
                        filteredAssets.forEach { asset ->
                            val normX = ((asset.longitude - (-5.75)) / 1.8).toFloat().coerceIn(0.05f, 0.95f) * w
                            val normY = (1f - ((asset.latitude - 50.1) / 0.55).toFloat()).coerceIn(0.05f, 0.95f) * h
                            val isSelected = asset.assetId == selectedAssetId

                            val pinColor = when (asset.status) {
                                AssetStatus.ACTIVE -> MarketGreenBright
                                AssetStatus.DEVELOPMENT -> CornishAmberBright
                                AssetStatus.HISTORICAL -> WolframPurpleBright
                                AssetStatus.EXPLORATION -> Color(0xFF60A5FA)
                                else -> TextMuted
                            }

                            // Halo for selected
                            if (isSelected) {
                                drawCircle(
                                    color = pinColor.copy(alpha = 0.35f),
                                    radius = 14f,
                                    center = Offset(normX, normY)
                                )
                            }

                            drawCircle(
                                color = pinColor,
                                radius = if (isSelected) 7f else 4.5f,
                                center = Offset(normX, normY)
                            )
                        }
                    }

                    // Map Overlay Legend / Notes
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = TerminalBackground.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "WEST: CORNWALL  |  EAST: DEVON (TAMAR LINE)",
                                style = MaterialTheme.typography.labelSmall,
                                color = TamarCyanBright,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Selected Asset Detail Card
        if (selectedAsset != null) {
            val asset = selectedAsset!!
            item {
                Surface(
                    color = TerminalSurface,
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CornishAmber.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = asset.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = CornishAmberBright
                                )
                                Text(
                                    text = "${asset.district} • ${asset.county} (${asset.assetType.label})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            Surface(
                                color = Color(asset.status.badgeColorHex).copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(asset.status.badgeColorHex))
                            ) {
                                Text(
                                    text = asset.status.label,
                                    color = Color(asset.status.badgeColorHex),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = asset.historicalSummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "MODERN STATUS: ${asset.modernStatusNotes}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TamarCyanBright
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("COMMODITIES: ${asset.primaryCommodities.joinToString(", ")}", style = MaterialTheme.typography.labelSmall, color = TextCode)
                            if (asset.certifiedWarehouseCapacityTonnes != null) {
                                Text("VAULT CAP: ${asset.certifiedWarehouseCapacityTonnes.toInt()} t", style = MaterialTheme.typography.labelSmall, color = CornishAmberBright, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Certified Warehouse Depository Network
        item {
            SectionHeader(
                title = "Certified Warehouse Network",
                badgeText = "${warehouses.size} HUBS"
            )
        }

        items(warehouses) { wh ->
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(wh.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("${wh.utilizedTonnes.toInt()} / ${wh.capacityTonnes.toInt()} t", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = CornishAmberBright)
                    }
                    Text("${wh.district}, ${wh.county} • Operator: ${wh.operator}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Transport: ${wh.transportLinks}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Storage: £${wh.storageFeeGbpPerDay}/t/day", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Active Receipts: ${wh.receiptsIssuedCount}", style = MaterialTheme.typography.labelSmall, color = TamarCyanBright)
                    }
                }
            }
        }

        // Warehouse Receipts
        item {
            Spacer(modifier = Modifier.height(12.dp))
            SectionHeader(
                title = "Tamar & Cornish Warehouse Receipts",
                badgeText = "${receipts.size} ACTIVE TITLES"
            )
        }

        items(receipts) { rec ->
            Surface(
                color = TerminalSurface,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(rec.receiptId, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = CornishAmber)
                        Surface(
                            color = MarketGreenBg,
                            shape = RoundedCornerShape(3.dp)
                        ) {
                            Text(rec.status, style = MaterialTheme.typography.labelSmall, color = MarketGreenBright, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                        }
                    }
                    Text("${rec.commodity} (${rec.quantityDmt} DMT) • ${rec.grade}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Owner: ${rec.owner}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Depository: ${rec.warehouseName}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
