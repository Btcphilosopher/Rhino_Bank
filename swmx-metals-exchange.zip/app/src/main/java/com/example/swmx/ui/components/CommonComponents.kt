package com.example.swmx.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.swmx.model.*
import com.example.ui.theme.*

@Composable
fun TerminalHeader(
    modifier: Modifier = Modifier
) {
    Surface(
        color = TerminalSurface,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, TerminalSurfaceBorder, RoundedCornerShape(0.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(MarketGreen)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SWMX TERMINAL",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CornishAmber,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = TamarCyan.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TamarCyan.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "SPOT API",
                            color = TamarCyanBright,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }

                Surface(
                    color = TerminalSurfaceElevated,
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RHINOQUANT 3.6",
                            color = WolframPurpleBright,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Cornish & Devonish Physical Commodities Exchange",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "SYNTHETIC DEMO",
                    style = MaterialTheme.typography.labelSmall,
                    color = CornishAmberBright
                )
            }
        }
    }
}

@Composable
fun MarketStatusBadge(
    status: MarketStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, borderCol) = when (status) {
        MarketStatus.ACTIVE -> Triple(MarketGreenBg, MarketGreenBright, MarketGreen)
        MarketStatus.HISTORICAL -> Triple(WolframPurple.copy(alpha = 0.2f), WolframPurpleBright, WolframPurple)
        MarketStatus.EXPLORATION -> Triple(MarketBlue.copy(alpha = 0.2f), Color(0xFF60A5FA), MarketBlue)
        MarketStatus.DEVELOPMENT -> Triple(CornishAmber.copy(alpha = 0.2f), CornishAmberBright, CornishAmber)
        MarketStatus.RECYCLING -> Triple(StatusRecycling.copy(alpha = 0.2f), Color(0xFF2DD4BF), StatusRecycling)
        MarketStatus.ILLUSTRATIVE -> Triple(TerminalSurfaceElevated, TextMuted, TerminalSurfaceBorder)
        MarketStatus.UNAVAILABLE -> Triple(MarketRedBg, MarketRedBright, MarketRed)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderCol.copy(alpha = 0.5f)),
        modifier = modifier
    ) {
        Text(
            text = status.label,
            color = textColor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun CommodityGroupBadge(
    group: CommodityGroup,
    modifier: Modifier = Modifier
) {
    Surface(
        color = TerminalSurfaceElevated,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
        modifier = modifier
    ) {
        Text(
            text = group.label,
            color = TextSecondary,
            fontSize = 10.sp,
            fontFamily = FontFamily.SansSerif,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    actionText: String? = null,
    onActionClick: (() -> Unit)? = null,
    badgeText: String? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "› ",
                color = CornishAmber,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp
            )
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            if (badgeText != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    color = TerminalSurfaceElevated,
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = TextCode,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }
            }
        }

        if (actionText != null && onActionClick != null) {
            Text(
                text = actionText,
                style = MaterialTheme.typography.labelMedium,
                color = TamarCyanBright,
                modifier = Modifier
                    .clickable { onActionClick() }
                    .padding(4.dp)
            )
        }
    }
}

@Composable
fun OrderBookLadderView(
    orderBook: OrderBook?,
    onPriceClick: (Double) -> Unit = {},
    modifier: Modifier = Modifier
) {
    if (orderBook == null) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(TerminalSurface),
            contentAlignment = Alignment.Center
        ) {
            Text("Order book initializing...", color = TextMuted, style = MaterialTheme.typography.bodySmall)
        }
        return
    }

    Surface(
        color = TerminalSurface,
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("LEVEL 2 DEPTH", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text("SPREAD: £${String.format("%.1f", orderBook.spreadGbp)} (${String.format("%.2f", orderBook.spreadPct)}%)", style = MaterialTheme.typography.labelSmall, color = CornishAmber)
            }
            Spacer(modifier = Modifier.height(8.dp))

            // Column titles
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("QTY (DMT)", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.weight(1f))
                Text("BID (£/t)", style = MaterialTheme.typography.labelSmall, color = MarketGreenBright, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                Text("OFFER (£/t)", style = MaterialTheme.typography.labelSmall, color = MarketRedBright, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                Text("QTY (DMT)", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
            }
            Divider(color = TerminalSurfaceBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

            // Rows (3 pairs of Bids & Offers)
            val rowsCount = maxOf(orderBook.bids.size, orderBook.offers.size)
            for (i in 0 until rowsCount) {
                val bid = orderBook.bids.getOrNull(i)
                val offer = orderBook.offers.getOrNull(i)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Bid Qty
                    Text(
                        text = if (bid != null) "${bid.quantityDmt}t" else "-",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    // Bid Price (with green depth background hint)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (bid != null) MarketGreenBg.copy(alpha = 0.35f) else Color.Transparent)
                            .clickable { if (bid != null) onPriceClick(bid.priceGbp) }
                            .padding(vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (bid != null) "£${bid.priceGbp.toInt()}" else "-",
                            style = MaterialTheme.typography.labelMedium,
                            color = MarketGreenBright,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Offer Price (with red depth background hint)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (offer != null) MarketRedBg.copy(alpha = 0.35f) else Color.Transparent)
                            .clickable { if (offer != null) onPriceClick(offer.priceGbp) }
                            .padding(vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (offer != null) "£${offer.priceGbp.toInt()}" else "-",
                            style = MaterialTheme.typography.labelMedium,
                            color = MarketRedBright,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Offer Qty
                    Text(
                        text = if (offer != null) "${offer.quantityDmt}t" else "-",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.End
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Divider(color = TerminalSurfaceBorder, thickness = 1.dp)
            Spacer(modifier = Modifier.height(6.dp))

            // Footnotes (VWAP, Day Range, Settlement)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("VWAP: £${orderBook.vwapGbp.toInt()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text("HIGH: £${orderBook.dayHighGbp.toInt()}  LOW: £${orderBook.dayLowGbp.toInt()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text("MID: £${orderBook.midGbp.toInt()}", style = MaterialTheme.typography.labelSmall, color = TextCode)
            }
        }
    }
}

@Composable
fun JsonCodeViewer(
    jsonText: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = TerminalBackground,
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = jsonText,
                style = MaterialTheme.typography.labelSmall,
                color = TextCode,
                fontFamily = FontFamily.Monospace,
                lineHeight = 16.sp
            )
        }
    }
}
