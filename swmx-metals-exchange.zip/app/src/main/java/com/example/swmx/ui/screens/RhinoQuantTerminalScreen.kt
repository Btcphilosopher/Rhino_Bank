package com.example.swmx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.swmx.model.*
import com.example.swmx.ui.components.*
import com.example.swmx.viewmodel.SWMXViewModel
import com.example.ui.theme.*

@Composable
fun RhinoQuantTerminalScreen(
    viewModel: SWMXViewModel,
    modifier: Modifier = Modifier
) {
    val quantMetrics by viewModel.currentQuantMetrics.collectAsState()
    val apiEndpoints by viewModel.apiEndpoints.collectAsState()
    val selectedEndpoint by viewModel.selectedEndpoint.collectAsState()
    val apiResponse by viewModel.apiResponse.collectAsState()
    val apiParams by viewModel.apiParams.collectAsState()
    val fixMessages by viewModel.fixMessages.collectAsState()
    val apiKeys by viewModel.apiKeys.collectAsState()
    val selectedSymbol by viewModel.selectedSymbol.collectAsState()

    var activeSubTab by remember { mutableStateOf("API_EXPLORER") } // "API_EXPLORER", "RHINO_QUANT", "FIX_STREAM", "API_KEYS"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            // Sub-nav tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Pair("API EXPLORER", "API_EXPLORER"),
                    Pair("RHINOQUANT ENGINE", "RHINO_QUANT"),
                    Pair("WEBSOCKET / FIX STREAM", "FIX_STREAM"),
                    Pair("API KEYS & SCOPES", "API_KEYS")
                ).forEach { (label, key) ->
                    val isSelected = activeSubTab == key
                    Surface(
                        color = if (isSelected) WolframPurple else TerminalSurfaceElevated,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) WolframPurple else TerminalSurfaceBorder),
                        modifier = Modifier.clickable { activeSubTab = key }
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) Color.White else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        when (activeSubTab) {
            "API_EXPLORER" -> {
                // Endpoint Selector Chips
                item {
                    SectionHeader(
                        title = "Select REST Endpoint",
                        badgeText = "PROGRAMMABLE API"
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        apiEndpoints.forEach { ep ->
                            val isSelected = ep.path == selectedEndpoint.path
                            Surface(
                                color = if (isSelected) TerminalSurfaceElevated else TerminalSurface,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) TamarCyan else TerminalSurfaceBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectApiEndpoint(ep) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = if (ep.method == "GET") MarketGreenBg else CornishAmber.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(3.dp)
                                    ) {
                                        Text(
                                            text = ep.method,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (ep.method == "GET") MarketGreenBright else CornishAmberBright,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(ep.path, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                        Text(ep.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    }
                                    Text(ep.requiredScope, style = MaterialTheme.typography.labelSmall, color = TextCode)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Execute Button & Query Params
                    Button(
                        onClick = { viewModel.executeCurrentApi() },
                        colors = ButtonDefaults.buttonColors(containerColor = TamarCyan),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("execute_api_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("EXECUTE ${selectedEndpoint.method} ${selectedEndpoint.path}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Response Envelope Viewer
                if (apiResponse != null) {
                    val resp = apiResponse!!
                    item {
                        SectionHeader(
                            title = "HTTP Response Payload",
                            badgeText = "200 OK • ${resp.meta.latencyMs}ms"
                        )

                        // Meta Bar
                        Surface(
                            color = TerminalSurface,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("request_id: ${resp.meta.requestId}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text("source: ${resp.meta.source} (${resp.meta.dataStatus})", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        JsonCodeViewer(jsonText = resp.rawJsonFormatted)
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }

            "RHINO_QUANT" -> {
                if (quantMetrics != null) {
                    val q = quantMetrics!!
                    item {
                        SectionHeader(
                            title = "RhinoQuant Quantitative Statistical Desk",
                            badgeText = selectedSymbol
                        )

                        Surface(
                            color = TerminalSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("MARKET REGIME:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    Surface(
                                        color = Color(q.regime.badgeColorHex).copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(q.regime.badgeColorHex))
                                    ) {
                                        Text(
                                            text = q.regime.label,
                                            color = Color(q.regime.badgeColorHex),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = TerminalSurfaceBorder, thickness = 1.dp)
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("30-Day Realized Volatility:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text("${q.realizedVol30dPct}%", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("7-Day Rolling Volatility:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text("${q.rollingVol7dPct}%", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Basis Z-Score (Deviation):", style = MaterialTheme.typography.bodySmall, color = CornishAmber)
                                    Text("+${q.zScoreBasis} σ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = CornishAmberBright)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Estimated Days of Regional Supply:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text("${q.daysOfRegionalSupply} Days", style = MaterialTheme.typography.labelMedium, color = TextCode)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Order Book Imbalance Ratio:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text("${if (q.bidAskImbalanceRatio >= 0) "+" else ""}${q.bidAskImbalanceRatio} (Bid Heavy)", style = MaterialTheme.typography.labelMedium, color = MarketGreenBright)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Correlation to Global LME Ref:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text("${q.correlationToLme}", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text("R Engine: ${q.rModelStatus}", style = MaterialTheme.typography.labelSmall, color = WolframPurpleBright)
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }

            "FIX_STREAM" -> {
                item {
                    SectionHeader(
                        title = "Live FIX / WebSocket Event Log",
                        badgeText = "${fixMessages.size} EVENTS"
                    )
                }

                items(fixMessages) { fix ->
                    Surface(
                        color = TerminalSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(color = WolframPurple.copy(alpha = 0.2f), shape = RoundedCornerShape(3.dp)) {
                                        Text(fix.event, style = MaterialTheme.typography.labelSmall, color = WolframPurpleBright, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(fix.symbol, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = CornishAmberBright)
                                }
                                Text(fix.timestamp.takeLast(8), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = fix.fixTagFormatted,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextCode,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            "API_KEYS" -> {
                item {
                    SectionHeader(
                        title = "API Credentials & OAuth Scopes",
                        badgeText = "${apiKeys.size} ACTIVE"
                    )
                }

                items(apiKeys) { key ->
                    Surface(
                        color = TerminalSurface,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalSurfaceBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(key.clientName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Surface(color = MarketGreenBg, shape = RoundedCornerShape(3.dp)) {
                                    Text("ACTIVE", style = MaterialTheme.typography.labelSmall, color = MarketGreenBright, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                }
                            }
                            Text("Key ID: ${key.keyId}", style = MaterialTheme.typography.labelSmall, color = TextCode)
                            Text("Secret: ${key.keySecretMasked}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Scopes: ${key.scopes.joinToString(", ")}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("Rate Limit: ${key.rateLimitPerMin} req/min", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
