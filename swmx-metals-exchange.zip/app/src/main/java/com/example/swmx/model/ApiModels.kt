package com.example.swmx.model

data class ApiEndpoint(
    val method: String, // "GET", "POST", "PATCH", "DELETE"
    val path: String, // "/v1/markets/{symbol}/orderbook"
    val category: String, // "Market Data", "Physical Lots", "Orders & RFQ", "Delivery & Settlement", "Analytics"
    val description: String,
    val requiredScope: String,
    val exampleParams: Map<String, String> = emptyMap(),
    val exampleRequestBody: String? = null,
    val idempotencySupported: Boolean = false
)

data class ApiResponseMeta(
    val timestamp: String,
    val requestId: String,
    val source: String = "SWMX Matching & Physical Settlement Engine",
    val dataStatus: String = "SYNTHETIC_MARKET_INFRASTRUCTURE",
    val latencyMs: Long,
    val serverRegion: String = "europe-west2 (Cornwall & Devon Edge Hub)"
)

data class ApiResponseEnvelope(
    val data: Any?,
    val meta: ApiResponseMeta,
    val error: ApiError? = null,
    val rawJsonFormatted: String
)

data class ApiError(
    val code: String,
    val message: String,
    val requestId: String
)

data class FIXMessage(
    val eventId: String,
    val event: String, // "TRADE_EXECUTED", "ORDER_ADDED", "LOT_RESERVED", "TICKER_UPDATE", "ASSAY_DISPUTE_RAISED"
    val timestamp: String,
    val symbol: String,
    val refId: String,
    val quantityDmt: Double,
    val priceGbp: Double,
    val currency: String = "GBP",
    val senderCompId: String = "SWMX_MATCH_CORE",
    val targetCompId: String = "RHINOQUANT_DESK_01",
    val fixTagFormatted: String
)

data class ApiKeyInfo(
    val keyId: String,
    val keySecretMasked: String,
    val clientName: String,
    val scopes: List<String>,
    val rateLimitPerMin: Int = 1200,
    val ipWhitelist: List<String> = listOf("10.0.0.0/8", "192.168.1.0/24"),
    val active: Boolean = true,
    val createdAt: String
)
