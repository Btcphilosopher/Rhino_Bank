package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SWMXColorScheme = darkColorScheme(
    primary = CornishAmber,
    onPrimary = Color.Black,
    primaryContainer = CornishAmber.copy(alpha = 0.2f),
    onPrimaryContainer = CornishAmberBright,
    secondary = TamarCyan,
    onSecondary = Color.Black,
    secondaryContainer = TamarCyan.copy(alpha = 0.2f),
    onSecondaryContainer = TamarCyanBright,
    tertiary = WolframPurple,
    onTertiary = Color.White,
    tertiaryContainer = WolframPurple.copy(alpha = 0.2f),
    onTertiaryContainer = WolframPurpleBright,
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = TerminalSurfaceBorder,
    outlineVariant = TerminalSurfaceBorder.copy(alpha = 0.6f),
    error = MarketRed,
    onError = Color.White,
    errorContainer = MarketRedBg,
    onErrorContainer = MarketRedBright
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SWMXColorScheme,
        typography = Typography,
        content = content
    )
}
