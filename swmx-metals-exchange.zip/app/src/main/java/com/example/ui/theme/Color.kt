package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SWMX Terminal Color Palette - High Density Dark Market Theme
val TerminalBackground = Color(0xFF090D14)
val TerminalSurface = Color(0xFF111723)
val TerminalSurfaceElevated = Color(0xFF182030)
val TerminalSurfaceBorder = Color(0xFF232D42)
val TerminalSurfaceHover = Color(0xFF1F293D)

// Brand Accents
val CornishAmber = Color(0xFFF59E0B)
val CornishAmberBright = Color(0xFFFBBF24)
val TamarCyan = Color(0xFF06B6D4)
val TamarCyanBright = Color(0xFF22D3EE)

// Metal Accents
val CopperOrange = Color(0xFFF97316)
val CopperOxide = Color(0xFFEA580C)
val TinSilver = Color(0xFFCBD5E1)
val TinMuted = Color(0xFF94A3B8)
val WolframPurple = Color(0xFFA855F7)
val WolframPurpleBright = Color(0xFFC084FC)
val ArsenicGray = Color(0xFF78716C)
val SilverBright = Color(0xFFE2E8F0)
val LeadSlate = Color(0xFF64748B)

// Market Indicators
val MarketGreen = Color(0xFF10B981)
val MarketGreenBright = Color(0xFF34D399)
val MarketGreenBg = Color(0xFF064E3B)
val MarketRed = Color(0xFFEF4444)
val MarketRedBright = Color(0xFFF87171)
val MarketRedBg = Color(0xFF450A0A)
val MarketBlue = Color(0xFF3B82F6)

// Typography & Content
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextCode = Color(0xFF38BDF8)
val TextAmber = Color(0xFFFCD34D)

// Status Colors
val StatusActive = Color(0xFF10B981)
val StatusHistorical = Color(0xFF8B5CF6)
val StatusExploration = Color(0xFF3B82F6)
val StatusDevelopment = Color(0xFFF59E0B)
val StatusRecycling = Color(0xFF14B8A6)
val StatusIllustrative = Color(0xFF64748B)
