package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.swmx.ui.components.TerminalHeader
import com.example.swmx.ui.screens.*
import com.example.swmx.viewmodel.AppTab
import com.example.swmx.viewmodel.SWMXViewModel
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SWMXApp()
            }
        }
    }
}

@Composable
fun SWMXApp(
    viewModel: SWMXViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            snackbarHostState.showSnackbar(
                message = it,
                duration = SnackbarDuration.Short
            )
            viewModel.dismissStatusMessage()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground),
        topBar = {
            TerminalHeader(
                modifier = Modifier.statusBarsPadding()
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = TerminalSurface,
                contentColor = TextPrimary,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentTab == AppTab.SPOT_BOARD,
                    onClick = { viewModel.setTab(AppTab.SPOT_BOARD) },
                    icon = { Icon(Icons.Default.ShowChart, contentDescription = "Spot Board") },
                    label = { Text("Spot", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CornishAmberBright,
                        indicatorColor = CornishAmber,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_spot_board")
                )

                NavigationBarItem(
                    selected = currentTab == AppTab.TAMAR_MAP,
                    onClick = { viewModel.setTab(AppTab.TAMAR_MAP) },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Tamar & Map") },
                    label = { Text("Tamar", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = TamarCyanBright,
                        indicatorColor = TamarCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_tamar_map")
                )

                NavigationBarItem(
                    selected = currentTab == AppTab.LOTS_WAREHOUSE,
                    onClick = { viewModel.setTab(AppTab.LOTS_WAREHOUSE) },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = "Lots & Vaults") },
                    label = { Text("Lots", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CornishAmberBright,
                        indicatorColor = CornishAmber,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_lots_warehouse")
                )

                NavigationBarItem(
                    selected = currentTab == AppTab.WORKFLOW,
                    onClick = { viewModel.setTab(AppTab.WORKFLOW) },
                    icon = { Icon(Icons.Default.SwapHoriz, contentDescription = "RFQ & Settle") },
                    label = { Text("Workflow", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = TamarCyanBright,
                        indicatorColor = TamarCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_workflow")
                )

                NavigationBarItem(
                    selected = currentTab == AppTab.RHINO_API,
                    onClick = { viewModel.setTab(AppTab.RHINO_API) },
                    icon = { Icon(Icons.Default.Terminal, contentDescription = "RhinoQuant / API") },
                    label = { Text("API / Quant", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = WolframPurpleBright,
                        indicatorColor = WolframPurple,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_rhino_api")
                )
            }
        },
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                snackbar = { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = TerminalSurfaceElevated,
                        contentColor = TextPrimary,
                        actionColor = CornishAmberBright,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .padding(16.dp)
                            .border(1.dp, CornishAmber, RoundedCornerShape(6.dp))
                    )
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TerminalBackground)
        ) {
            when (currentTab) {
                AppTab.SPOT_BOARD -> SpotBoardScreen(viewModel = viewModel)
                AppTab.TAMAR_MAP -> TamarMarketScreen(viewModel = viewModel)
                AppTab.LOTS_WAREHOUSE -> PhysicalLotsScreen(viewModel = viewModel)
                AppTab.WORKFLOW -> WorkflowScreen(viewModel = viewModel)
                AppTab.RHINO_API -> RhinoQuantTerminalScreen(viewModel = viewModel)
            }
        }
    }
}
