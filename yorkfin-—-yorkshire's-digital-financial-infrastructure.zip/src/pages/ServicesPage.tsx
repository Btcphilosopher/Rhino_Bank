import React from 'react';
import { Building2, Landmark, Zap, Layers, RefreshCw, Activity, ShieldCheck, ArrowUpRight } from 'lucide-react';

interface ServicesPageProps {
  onOpenTerminal: () => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ onOpenTerminal }) => {
  const services = [
    { name: 'DIGITAL TREASURY', desc: 'Corporate digital-asset and liquidity management with multi-signature governance, timelocks and accounting trial balance exports.', icon: Building2 },
    { name: 'TOKENISATION', desc: 'Digital representation of eligible financial assets including UK Gilts, corporate debt instruments and Grade-A commercial real estate.', icon: Landmark },
    { name: 'SETTLEMENT', desc: 'Programmable settlement infrastructure providing T+0 Delivery vs Payment with atomic cryptographic execution.', icon: RefreshCw },
    { name: 'COLLATERAL', desc: 'Digital collateral management and real-time Loan-to-Value health factor monitoring with dynamic stress testing.', icon: Zap },
    { name: 'CREDIT', desc: 'Secured programmable lending backed by on-chain tokenised sovereign debt and institutional reserves.', icon: Layers },
    { name: 'LIQUIDITY', desc: 'Institutional liquidity infrastructure with money market pools and automated interest rate jump curves.', icon: Activity },
    { name: 'DATA & INTELLIGENCE', desc: 'Financial data, risk analytics and cryptographic proof-of-reserve oracles for institutional auditing.', icon: ShieldCheck },
  ];

  return (
    <div className="px-4 md:px-8 py-8 max-w-7xl mx-auto space-y-10">
      
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block font-semibold">
          YORKFIN INSTITUTIONAL CAPABILITIES
        </span>
        <h1 className="text-3xl md:text-5xl font-bold font-sans text-slate-100">
          INSTITUTIONAL SERVICES
        </h1>
        <p className="text-xs md:text-sm text-slate-400 font-sans leading-relaxed">
          Comprehensive digital financial infrastructure built in Leeds for regional businesses, corporate treasuries and capital market participants.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((s) => {
          const Icon = s.icon;
          return (
            <div
              key={s.name}
              onClick={onOpenTerminal}
              className="p-6 rounded-xl bg-[#0f1420] stone-border hover:border-[#c5a059] transition-all cursor-pointer group space-y-4"
            >
              <div className="w-10 h-10 rounded bg-[#161f2e] border border-[#243248] flex items-center justify-center text-[#c5a059] group-hover:bg-[#c5a059] group-hover:text-[#0a0d14] transition-colors">
                <Icon className="w-5 h-5" />
              </div>

              <h3 className="text-lg font-bold font-mono text-slate-100 group-hover:text-[#c5a059] transition-colors">
                {s.name}
              </h3>

              <p className="text-xs text-slate-300 font-sans leading-relaxed">
                {s.desc}
              </p>

              <div className="text-xs font-mono text-slate-400 pt-2 flex items-center gap-1 group-hover:text-[#c5a059]">
                <span>Launch in Terminal</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
