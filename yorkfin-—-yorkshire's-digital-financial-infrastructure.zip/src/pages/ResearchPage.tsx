import React, { useState } from 'react';
import { RESEARCH_ARTICLES, ResearchArticle } from '../data/mockData';
import { BookOpen, Clock, ArrowLeft, ArrowUpRight } from 'lucide-react';

export const ResearchPage: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<ResearchArticle | null>(null);

  return (
    <div className="px-4 md:px-8 py-8 max-w-7xl mx-auto space-y-10">
      
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block font-semibold">
          YORKFIN INSTITUTIONAL RESEARCH
        </span>
        <h1 className="text-3xl md:text-5xl font-bold font-sans text-slate-100">
          QUANTITATIVE RESEARCH & PAPERS
        </h1>
        <p className="text-xs md:text-sm text-slate-400 font-sans leading-relaxed">
          In-depth whitepapers on tokenised gilts, programmable settlement, collateral management and corporate digital Sterling treasury design.
        </p>
      </div>

      {selectedArticle ? (
        /* Full Article View */
        <div className="bg-[#0f1420] stone-border rounded-xl p-8 max-w-4xl mx-auto space-y-6 font-sans">
          <button
            onClick={() => setSelectedArticle(null)}
            className="text-xs font-mono text-[#c5a059] hover:underline flex items-center gap-1.5"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Research Papers</span>
          </button>

          <div className="space-y-2 border-b border-[#1c2433] pb-4 font-mono">
            <span className="text-xs text-[#c5a059] uppercase">{selectedArticle.category}</span>
            <h2 className="text-2xl md:text-3xl font-bold font-sans text-slate-100">{selectedArticle.title}</h2>
            <p className="text-sm text-slate-300 italic font-sans">{selectedArticle.subtitle}</p>
            <div className="text-xs text-slate-400 flex items-center gap-4 pt-2">
              <span>{selectedArticle.author}</span>
              <span>·</span>
              <span>{selectedArticle.date}</span>
              <span>·</span>
              <span>{selectedArticle.readTime}</span>
            </div>
          </div>

          <div className="space-y-4 text-slate-200 text-sm leading-relaxed font-sans">
            {selectedArticle.content.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>
        </div>
      ) : (
        /* Articles Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {RESEARCH_ARTICLES.map((article) => (
            <div
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="p-6 rounded-xl bg-[#0f1420] stone-border hover:border-[#c5a059] transition-all cursor-pointer space-y-3 group"
            >
              <div className="flex items-center justify-between font-mono text-xs">
                <span className="text-[#c5a059]">{article.category}</span>
                <span className="text-slate-500">{article.readTime}</span>
              </div>

              <h3 className="text-xl font-bold text-slate-100 group-hover:text-[#c5a059] transition-colors font-sans">
                {article.title}
              </h3>

              <p className="text-xs text-slate-400 font-sans italic">
                {article.subtitle}
              </p>

              <p className="text-xs text-slate-300 font-sans leading-relaxed">
                {article.summary}
              </p>

              <div className="flex items-center justify-between text-xs font-mono text-[#c5a059] pt-2">
                <span>{article.date} · {article.author}</span>
                <ArrowUpRight className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
