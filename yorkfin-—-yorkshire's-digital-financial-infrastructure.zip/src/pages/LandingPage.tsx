import React from 'react';
import { ArrowUpRight, ShieldCheck, Terminal as TerminalIcon, Building2, Landmark, Zap, Layers, RefreshCw, Cpu, Activity, CheckCircle2 } from 'lucide-react';
import { YorkshireMap } from '../components/YorkshireMap';
import { SettlementPipeline } from '../components/SettlementPipeline';
import { DeFiExplainer } from '../components/DeFiExplainer';
import { MobilePreview } from '../components/MobilePreview';

interface LandingPageProps {
  onOpenTerminal: () => void;
  setCurrentView: (view: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onOpenTerminal, setCurrentView }) => {
  return (
    <div className="space-y-16">
      
      {/* 04 — HERO SECTION */}
      <section className="relative min-h-[85vh] flex flex-col justify-between p-6 md:p-12 overflow-hidden border-b border-[#1c2433]">
        
        {/* Photorealistic Leeds Architectural Dusk Background */}
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-30 mix-blend-luminosity scale-105"
          style={{ backgroundImage: `url('/src/assets/images/leeds_financial_district_dusk_1790858532504.jpg')` }}
        ></div>

        {/* Gradient Overlay Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0d14] via-[#0a0d14]/70 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0d14] via-[#0a0d14]/50 to-transparent"></div>

        {/* Top Hero Status Badge */}
        <div className="relative z-10 flex items-center justify-between">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#121824]/90 border border-[#232f42] text-[11px] font-mono text-slate-300 backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>LEEDS · YORKSHIRE · UK</span>
          </div>

          <div className="text-[11px] font-mono text-[#c5a059] uppercase tracking-wider hidden sm:block">
            DIGITAL FINANCIAL INFRASTRUCTURE
          </div>
        </div>

        {/* Central Hero Headline Block */}
        <div className="relative z-10 max-w-4xl space-y-6 my-auto pt-10 pb-10">
          
          <div className="space-y-3">
            <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block font-semibold">
              YORKSHIRE FINANCE · ON-CHAIN
            </span>
            
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold font-sans text-slate-100 tracking-tight leading-none">
              YORKSHIRE FINANCE.<br />
              <span className="brass-gradient-text">SETTLED DIFFERENTLY.</span>
            </h1>
          </div>

          <p className="text-base sm:text-xl text-slate-300 font-sans leading-relaxed max-w-2xl font-light">
            YORKFIN builds programmable financial infrastructure for businesses, investors and institutions across Yorkshire and the wider UK.
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
            <button
              onClick={onOpenTerminal}
              className="px-6 py-3.5 rounded text-xs font-mono font-bold tracking-wider text-[#0a0d14] bg-[#c5a059] hover:bg-[#d4af37] transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#c5a059]/10"
            >
              <TerminalIcon className="w-4 h-4" />
              <span>ENTER YORKFIN TERMINAL</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                const el = document.getElementById('yorkshire-network');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-6 py-3.5 rounded text-xs font-mono font-bold tracking-wider text-slate-200 bg-[#121926] border border-[#243147] hover:border-[#c5a059] transition-all flex items-center justify-center gap-2"
            >
              <span>EXPLORE THE NETWORK</span>
            </button>
          </div>

        </div>

        {/* Hero Bottom Data Strip */}
        <div className="relative z-10 pt-6 border-t border-[#1e2738] grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-[11px]">
          <div>
            <span className="text-slate-500 text-[9px] block uppercase">NETWORK</span>
            <span className="text-slate-200 font-bold">YORKFIN</span>
          </div>
          <div>
            <span className="text-slate-500 text-[9px] block uppercase">SETTLEMENT</span>
            <span className="text-[#c5a059] font-bold">ON-CHAIN (T+0)</span>
          </div>
          <div>
            <span className="text-slate-500 text-[9px] block uppercase">ASSETS</span>
            <span className="text-slate-200 font-bold">TOKENISED GILTS</span>
          </div>
          <div>
            <span className="text-slate-500 text-[9px] block uppercase">CUSTODY</span>
            <span className="text-slate-200 font-bold">PROGRAMMABLE</span>
          </div>
          <div>
            <span className="text-slate-500 text-[9px] block uppercase">IDENTITY</span>
            <span className="text-slate-200 font-bold">CRYPTOGRAPHIC</span>
          </div>
          <div>
            <span className="text-slate-500 text-[9px] block uppercase">STATUS</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> OPERATIONAL
            </span>
          </div>
        </div>

      </section>

      {/* 05 — THE YORKFIN PLATFORM (6 MODULES) */}
      <section className="px-4 md:px-8 max-w-7xl mx-auto space-y-10">
        
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block font-semibold">
            THE YORKFIN PLATFORM
          </span>
          <h2 className="text-3xl md:text-4xl font-bold font-sans text-slate-100">
            ONE FINANCIAL SYSTEM.
          </h2>
          <p className="text-xs md:text-sm text-slate-400 leading-relaxed font-sans">
            Accounts, assets, lending, liquidity and settlement connected through programmable financial infrastructure.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {[
            {
              title: 'YORKFIN BANK',
              desc: 'Digital institutional accounts engineered for corporate treasuries, holding companies, and financial institutions in Leeds.',
              badge: 'ACCOUNTS & DEPOSITS',
              icon: Building2
            },
            {
              title: 'YORKFIN MARKETS',
              desc: 'Tokenised financial assets. Orderbook depth across UK Gilts, corporate debt, and digital Sterling pairs with atomic DvP.',
              badge: 'CAPITAL MARKETS',
              icon: Landmark
            },
            {
              title: 'YORKFIN CREDIT',
              desc: 'On-chain secured lending without paper friction. Instant liquidity collateralised by UK Gilts and institutional assets.',
              badge: 'SECURED LENDING',
              icon: Zap
            },
            {
              title: 'YORKFIN LIQUIDITY',
              desc: 'Concentrated liquidity pools and institutional liquidity management for high-volume Sterling transfers.',
              badge: 'LIQUIDITY POOLS',
              icon: Activity
            },
            {
              title: 'YORKFIN SETTLEMENT',
              desc: 'Programmable transaction settlement in 2.8 seconds. Eliminates principal and counterparty settlement risk.',
              badge: 'T+0 FINALITY',
              icon: RefreshCw
            },
            {
              title: 'YORKFIN TREASURY',
              desc: 'Corporate digital-asset treasury management with 3-of-5 multi-signature policy controls and timelocks.',
              badge: 'TREASURY SAFE',
              icon: Layers
            },
          ].map((m) => {
            const Icon = m.icon;
            return (
              <div
                key={m.title}
                onClick={onOpenTerminal}
                className="p-6 rounded-xl bg-[#0f1420] stone-border hover:border-[#c5a059] transition-all cursor-pointer group space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded bg-[#161f2e] border border-[#243248] flex items-center justify-center text-[#c5a059] group-hover:bg-[#c5a059] group-hover:text-[#0a0d14] transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono text-[#c5a059] uppercase">
                    {m.badge}
                  </span>
                </div>

                <h3 className="text-lg font-bold font-mono text-slate-100 group-hover:text-[#c5a059] transition-colors">
                  {m.title}
                </h3>

                <p className="text-xs text-slate-300 font-sans leading-relaxed">
                  {m.desc}
                </p>

                <div className="text-xs font-mono text-slate-400 pt-2 flex items-center gap-1 group-hover:text-[#c5a059] transition-colors">
                  <span>Open Module in Terminal</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </div>
              </div>
            );
          })}

        </div>

      </section>

      {/* SETTLEMENT PIPELINE VISUAL DEMONSTRATION */}
      <section className="px-4 md:px-8 max-w-7xl mx-auto">
        <SettlementPipeline />
      </section>

      {/* YORKSHIRE NETWORK MAP */}
      <section id="yorkshire-network" className="px-4 md:px-8 max-w-7xl mx-auto">
        <YorkshireMap />
      </section>

      {/* 21 — WHY LEEDS EDITORIAL */}
      <section className="px-4 md:px-8 max-w-7xl mx-auto">
        <div className="bg-[#0e131d] stone-border rounded-xl p-8 md:p-12 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          
          <div className="space-y-4">
            <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block font-semibold">
              EDITORIAL PERSPECTIVE
            </span>
            <h2 className="text-3xl md:text-4xl font-bold font-sans text-slate-100">
              BUILT IN LEEDS.
            </h2>
            <p className="text-sm text-slate-300 font-sans leading-relaxed">
              Leeds has developed a deep financial and technology ecosystem, with established strengths across banking, lending, payments, fintech and professional services.
            </p>
            <p className="text-sm text-slate-300 font-sans leading-relaxed">
              YORKFIN takes that financial tradition and asks a different question: What would Yorkshire finance look like if the underlying infrastructure were programmable from the beginning?
            </p>
            <div className="pt-2">
              <button
                onClick={() => setCurrentView('why-leeds')}
                className="px-5 py-2.5 rounded bg-[#161e2c] border border-[#243044] hover:border-[#c5a059] text-xs font-mono text-slate-200 flex items-center gap-2 transition-colors"
              >
                <span>Read Full Editorial</span>
                <ArrowUpRight className="w-4 h-4 text-[#c5a059]" />
              </button>
            </div>
          </div>

          <div className="rounded-lg overflow-hidden border border-[#212b3d] shadow-2xl relative min-h-[280px]">
            <img 
              src="/src/assets/images/yorkfin_banking_hall_1790858545017.jpg" 
              alt="Yorkfin Banking Hall Leeds"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-3 left-3 right-3 p-3 bg-[#0a0d14]/90 backdrop-blur-md rounded border border-[#1b2332] text-[11px] font-mono text-slate-300">
              Wellington Street Financial District, Leeds LS1
            </div>
          </div>

        </div>
      </section>

      {/* WHAT IS DEFI? */}
      <DeFiExplainer />

      {/* MOBILE APP PREVIEW */}
      <section className="px-4 md:px-8 max-w-7xl mx-auto">
        <MobilePreview />
      </section>

      {/* 36 — FINAL HOMEPAGE STATEMENT */}
      <section className="px-4 md:px-8 max-w-7xl mx-auto">
        <div className="bg-[#0b0e16] stone-border rounded-xl p-8 md:p-16 text-center space-y-8 relative overflow-hidden">
          
          <div className="space-y-4 max-w-3xl mx-auto">
            <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block font-bold">
              THE INDUSTRIAL CONTINUITY
            </span>

            <h2 className="text-2xl md:text-4xl font-bold font-sans text-slate-100 uppercase tracking-tight leading-snug">
              YORKSHIRE HAS ALWAYS BEEN A PLACE THAT BUILDS THINGS.
            </h2>

            <div className="flex flex-wrap justify-center items-center gap-3 md:gap-6 text-sm md:text-base font-mono font-bold text-[#c5a059] pt-2">
              <span>STEEL.</span>
              <span>·</span>
              <span>RAILWAYS.</span>
              <span>·</span>
              <span>BANKS.</span>
              <span>·</span>
              <span>INDUSTRY.</span>
              <span>·</span>
              <span>TECHNOLOGY.</span>
            </div>

            <p className="text-xs md:text-sm text-slate-400 font-sans max-w-2xl mx-auto leading-relaxed pt-2">
              Now financial infrastructure. YORKFIN is a fictional demonstration of what happens when those traditions meet programmable finance.
            </p>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onOpenTerminal}
              className="px-8 py-4 rounded text-xs font-mono font-bold tracking-wider text-[#0a0d14] bg-[#c5a059] hover:bg-[#d4af37] transition-all flex items-center gap-2 shadow-lg"
            >
              <span>BUILD THE NEXT FINANCIAL SYSTEM</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenTerminal}
              className="px-8 py-4 rounded text-xs font-mono font-bold tracking-wider text-slate-200 bg-[#121926] border border-[#243147] hover:border-[#c5a059] transition-all"
            >
              <span>EXPLORE YORKFIN →</span>
            </button>
          </div>

        </div>
      </section>

    </div>
  );
};
