import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface WhyLeedsPageProps {
  onOpenTerminal: () => void;
}

export const WhyLeedsPage: React.FC<WhyLeedsPageProps> = ({ onOpenTerminal }) => {
  return (
    <div className="px-4 md:px-8 py-8 max-w-5xl mx-auto space-y-10">
      
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block font-semibold">
          FINANCIAL CAPITAL OF THE NORTH
        </span>
        <h1 className="text-3xl md:text-5xl font-bold font-sans text-slate-100">
          BUILT IN LEEDS.
        </h1>
        <p className="text-xs md:text-sm text-slate-400 font-sans leading-relaxed">
          Why Leeds is uniquely positioned to lead the next generation of digital financial infrastructure.
        </p>
      </div>

      <div className="bg-[#0f1420] stone-border rounded-xl p-8 md:p-12 space-y-6 font-sans leading-relaxed text-slate-200">
        
        <p className="text-base md:text-lg font-light text-slate-100">
          Leeds has developed a deep financial and technology ecosystem, with established strengths across banking, lending, payments, fintech and professional services.
        </p>

        <p className="text-sm text-slate-300">
          As the UK’s primary banking hub outside London, the city manages over £100 billion in financial assets. Yet much of the regional commercial architecture relies on traditional, multi-day clearing procedures and paper-heavy custodian transfers.
        </p>

        <div className="p-6 rounded-lg bg-[#0a0d14] border border-[#1e2738] space-y-3 font-mono text-xs">
          <h3 className="text-sm font-bold text-[#c5a059]">THE YORKSHIRE HYPOTHESIS</h3>
          <p className="text-slate-300">
            YORKFIN takes that financial tradition and asks a different question: What would Yorkshire finance look like if the underlying infrastructure were programmable from the beginning?
          </p>
        </div>

        <p className="text-sm text-slate-300">
          By unifying Sterling digital currency, tokenised UK gilts and on-chain credit facilities into a single atomic settlement protocol, YORKFIN enables regional businesses to unlock capital velocity, eliminate settlement risk and automate corporate treasury workflows.
        </p>

        <div className="pt-4 flex justify-center">
          <button
            onClick={onOpenTerminal}
            className="px-6 py-3.5 rounded text-xs font-mono font-bold tracking-wider text-[#0a0d14] bg-[#c5a059] hover:bg-[#d4af37] transition-all flex items-center gap-2"
          >
            <span>ENTER YORKFIN TERMINAL</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>

      </div>

    </div>
  );
};
