import React, { useState } from 'react';
import { PORTFOLIO_DATA, PortfolioAsset } from '../data/mockData';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { ArrowUpRight, PlusCircle, RefreshCw, ShieldCheck, PieChart as PieIcon } from 'lucide-react';

const COLORS = ['#c5a059', '#385880', '#5278a3', '#8c6b2d', '#94a3b8', '#3b82f6'];

export const PortfolioTab: React.FC = () => {
  const [assets, setAssets] = useState<PortfolioAsset[]>(PORTFOLIO_DATA);
  const [selectedAsset, setSelectedAsset] = useState<PortfolioAsset | null>(null);

  const totalValue = assets.reduce((sum, a) => sum + a.value, 0);

  return (
    <div className="space-y-6">
      
      {/* Portfolio Header Bar */}
      <div className="bg-[#0f1420] stone-border p-5 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-wider block">INSTITUTIONAL PORTFOLIO NAV</span>
          <h2 className="text-2xl font-bold font-mono text-slate-100">
            £{totalValue.toLocaleString()} <span className="text-xs text-slate-400 font-normal">(DEMO NAV)</span>
          </h2>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400 mt-1">
            <span>Realised P&L: <strong className="text-emerald-400">+£18,420,000</strong></span>
            <span>·</span>
            <span>Unrealised P&L: <strong className="text-emerald-400">+£42,190,000</strong></span>
            <span>·</span>
            <span>Weighted Yield: <strong className="text-[#c5a059]">5.18% p.a.</strong></span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => alert('Simulated Portfolio Rebalance Order Executed (Demo)')}
            className="px-3.5 py-2 rounded bg-[#161f2e] border border-[#26344a] text-xs font-mono text-slate-200 hover:border-[#c5a059] flex items-center gap-2 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#c5a059]" />
            <span>Rebalance Portfolio</span>
          </button>
        </div>
      </div>

      {/* Breakdown Charts & Summary Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Table View */}
        <div className="lg:col-span-2 bg-[#0f1420] stone-border rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1d2636]">
            <div>
              <span className="text-[10px] font-mono text-[#c5a059] uppercase">Asset Breakdown</span>
              <h3 className="text-base font-bold text-slate-100">Institutional Holding Ledger</h3>
            </div>
            <span className="text-xs font-mono text-slate-400">6 ASSET CLASSES</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-[#1c2433] text-[10px] uppercase">
                  <th className="pb-3 font-semibold">ASSET</th>
                  <th className="pb-3 font-semibold text-right">VALUE (£)</th>
                  <th className="pb-3 font-semibold text-right">ALLOCATION</th>
                  <th className="pb-3 font-semibold text-right">YIELD</th>
                  <th className="pb-3 font-semibold text-center">COLLATERAL</th>
                  <th className="pb-3 font-semibold text-right">LIQUIDITY</th>
                  <th className="pb-3 font-semibold text-center">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#171e2b]">
                {assets.map((asset) => (
                  <tr 
                    key={asset.id} 
                    onClick={() => setSelectedAsset(asset)}
                    className="hover:bg-[#141b27] transition-colors cursor-pointer"
                  >
                    <td className="py-3 font-bold text-slate-100">
                      <div>{asset.name}</div>
                      <span className="text-[10px] text-slate-400 font-normal">{asset.symbol}</span>
                    </td>
                    <td className="py-3 text-right font-bold text-slate-200">
                      £{asset.value.toLocaleString()}
                    </td>
                    <td className="py-3 text-right text-slate-300">
                      {asset.allocation}%
                    </td>
                    <td className="py-3 text-right text-emerald-400 font-bold">
                      {asset.yieldRate}%
                    </td>
                    <td className="py-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${asset.collateralEligible ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40' : 'bg-slate-800 text-slate-400'}`}>
                        {asset.collateralEligible ? `Eligible (${asset.maxLTV}% LTV)` : 'No'}
                      </span>
                    </td>
                    <td className="py-3 text-right text-slate-400 text-[11px]">
                      {asset.liquidityTier}
                    </td>
                    <td className="py-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${asset.status === 'Pledged' ? 'bg-[#312513] text-[#c5a059] border border-[#523f20]' : 'bg-[#121c2b] text-slate-300 border border-[#212d40]'}`}>
                        {asset.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Allocation Donut Chart */}
        <div className="bg-[#0f1420] stone-border rounded-xl p-5 space-y-4">
          <div className="pb-3 border-b border-[#1d2636]">
            <span className="text-[10px] font-mono text-[#c5a059] uppercase">Asset Allocation</span>
            <h3 className="text-base font-bold text-slate-100">Capital Distribution</h3>
          </div>

          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={assets}
                  dataKey="value"
                  nameKey="symbol"
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                >
                  {assets.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="#0d1117" />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#0d1117', borderColor: '#212936', borderRadius: '6px', color: '#f8fafc' }}
                  formatter={(value: any) => [`£${Number(value).toLocaleString()}`, 'Value']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 pt-2 border-t border-[#1c2433]">
            {assets.map((a, i) => (
              <div key={a.id} className="flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }}></span>
                  <span className="text-slate-300">{a.symbol}</span>
                </div>
                <span className="text-slate-400">{a.allocation}%</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Asset Inspector Modal */}
      {selectedAsset && (
        <div className="fixed inset-0 z-50 bg-[#000]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0f1420] stone-border rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2433]">
              <div>
                <span className="text-[10px] font-mono text-[#c5a059] uppercase">Asset Inspector</span>
                <h3 className="text-lg font-bold text-slate-100">{selectedAsset.name}</h3>
              </div>
              <button
                onClick={() => setSelectedAsset(null)}
                className="text-slate-400 hover:text-slate-100 font-mono text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="flex justify-between p-2 bg-[#141b27] rounded">
                <span className="text-slate-400">Value (£):</span>
                <span className="text-slate-100 font-bold">£{selectedAsset.value.toLocaleString()}</span>
              </div>
              <div className="flex justify-between p-2 bg-[#141b27] rounded">
                <span className="text-slate-400">Yield:</span>
                <span className="text-emerald-400 font-bold">{selectedAsset.yieldRate}% p.a.</span>
              </div>
              <div className="flex justify-between p-2 bg-[#141b27] rounded">
                <span className="text-slate-400">Collateral Eligibility:</span>
                <span className="text-[#c5a059] font-bold">{selectedAsset.collateralEligible ? `Eligible (Max ${selectedAsset.maxLTV}% LTV)` : 'Ineligible'}</span>
              </div>
              <div className="flex justify-between p-2 bg-[#141b27] rounded">
                <span className="text-slate-400">Liquidity Tier:</span>
                <span className="text-slate-200">{selectedAsset.liquidityTier}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedAsset(null)}
              className="w-full py-2.5 rounded bg-[#c5a059] text-[#0a0d14] font-mono text-xs font-bold"
            >
              Close Inspector
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
