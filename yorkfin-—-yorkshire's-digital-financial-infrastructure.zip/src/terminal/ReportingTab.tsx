import React from 'react';
import { Download, FileText, CheckCircle2, ShieldCheck } from 'lucide-react';

export const ReportingTab: React.FC = () => {
  return (
    <div className="space-y-6 font-mono text-xs">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] text-[#c5a059] uppercase tracking-wider block">YORKFIN REPORTING</span>
          <h2 className="text-2xl font-bold font-sans text-slate-100">
            AUDIT, ACCOUNTING & TRIAL BALANCE
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            Automated double-entry reconciliation files for corporate accountants, HMRC tax logs and institutional auditors.
          </p>
        </div>

        <button
          onClick={() => alert('Simulated Exporting Full Audit Trial Balance CSV')}
          className="px-4 py-2 rounded bg-[#c5a059] text-[#0a0d14] font-bold text-xs hover:bg-[#d4af37] transition-colors flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          <span>EXPORT FULL TRIAL BALANCE</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        <div className="bg-[#0f1420] stone-border rounded-xl p-6 space-y-4">
          <h3 className="text-base font-bold font-sans text-slate-100">Available Reports</h3>
          <div className="space-y-3">
            {[
              { name: 'Q3 2026 On-Chain Gilt Reserve Proof', date: '01 OCT 2026', format: 'PDF + Cryptographic Hash' },
              { name: 'Daily Settlement Ledger Reconciliation', date: '30 SEP 2026', format: 'CSV' },
              { name: 'Corporate Tax & Yield Accrual Log', date: '28 SEP 2026', format: 'JSON' },
              { name: 'Collateral Health & VaR Stress Audit', date: '25 SEP 2026', format: 'PDF' },
            ].map((rep, idx) => (
              <div key={idx} className="p-3 bg-[#141a26] rounded border border-[#1f2838] flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-200 block">{rep.name}</span>
                  <span className="text-slate-500 text-[10px]">{rep.date} · {rep.format}</span>
                </div>
                <button
                  onClick={() => alert(`Downloading ${rep.name} (Demo)`)}
                  className="px-2.5 py-1 rounded bg-[#1c2434] hover:bg-[#c5a059] hover:text-[#0a0d14] text-slate-200 text-[10px] font-bold transition-colors"
                >
                  DOWNLOAD
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#0f1420] stone-border rounded-xl p-6 space-y-4">
          <h3 className="text-base font-bold font-sans text-slate-100">Audit Compliance Status</h3>
          <div className="space-y-3">
            <div className="p-3 bg-[#141a26] rounded border border-[#1f2838] flex justify-between items-center">
              <span className="text-slate-300">UK GAAP Reconciliation:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> PASSED
              </span>
            </div>

            <div className="p-3 bg-[#141a26] rounded border border-[#1f2838] flex justify-between items-center">
              <span className="text-slate-300">IFRS 9 Financial Instrument Standard:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> COMPLIANT
              </span>
            </div>

            <div className="p-3 bg-[#141a26] rounded border border-[#1f2838] flex justify-between items-center">
              <span className="text-slate-300">Cryptographic Reserve Proof:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> 100% VERIFIED
              </span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
