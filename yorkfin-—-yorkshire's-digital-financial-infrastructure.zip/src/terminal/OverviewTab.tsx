import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { ArrowUpRight, ShieldCheck, Zap, Server, Activity, Landmark, Layers } from 'lucide-react';

const CHART_DATA = [
  { month: 'Apr', nav: 2100, liquidity: 620, volume: 3.1 },
  { month: 'May', nav: 2210, liquidity: 690, volume: 3.4 },
  { month: 'Jun', nav: 2280, liquidity: 720, volume: 3.7 },
  { month: 'Jul', nav: 2350, liquidity: 780, volume: 3.9 },
  { month: 'Aug', nav: 2420, liquidity: 810, volume: 4.1 },
  { month: 'Sep', nav: 2481, liquidity: 842, volume: 4.28 },
];

interface OverviewTabProps {
  onSelectTab: (tab: string) => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({ onSelectTab }) => {
  return (
    <div className="space-y-6">
      
      {/* Demo Notice Banner */}
      <div className="bg-[#121824] stone-border rounded-lg p-3.5 flex flex-col sm:flex-row items-center justify-between text-xs font-mono gap-3">
        <div className="flex items-center gap-2 text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>YORKFIN TERMINAL · LEEDS NETWORK NODE 01</span>
        </div>
        <div className="px-2.5 py-0.5 rounded bg-[#1c2434] text-[#c5a059] border border-[#2b384f] font-semibold">
          DEMO DATA — SIMULATED PROTOCOL ENVIRONMENT
        </div>
      </div>

      {/* Top Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        
        <div className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-1 hover:border-[#c5a059]/40 transition-colors">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">TOTAL ASSETS</span>
          <div className="text-xl font-bold font-mono text-slate-100">£2,481,930,420</div>
          <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 pt-1">
            <span>+2.4% Q3</span>
            <span className="text-slate-500">DEMO DATA</span>
          </div>
        </div>

        <div className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-1 hover:border-[#c5a059]/40 transition-colors">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">ON-CHAIN LIQUIDITY</span>
          <div className="text-xl font-bold font-mono text-slate-100">£842,190,000</div>
          <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 pt-1">
            <span>72.8% Available</span>
            <span className="text-slate-500">DEMO DATA</span>
          </div>
        </div>

        <div className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-1 hover:border-[#c5a059]/40 transition-colors">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">TOKENISED ASSETS</span>
          <div className="text-xl font-bold font-mono text-slate-100">£1,184,420,000</div>
          <div className="flex items-center justify-between text-[11px] font-mono text-[#c5a059] pt-1">
            <span>Gilts & Bonds</span>
            <span className="text-slate-500">DEMO DATA</span>
          </div>
        </div>

        <div className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-1 hover:border-[#c5a059]/40 transition-colors">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">ACTIVE LOANS</span>
          <div className="text-xl font-bold font-mono text-slate-100">£318,740,000</div>
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 pt-1">
            <span>Avg LTV 71.4%</span>
            <span className="text-slate-500">DEMO DATA</span>
          </div>
        </div>

        <div className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-1 hover:border-[#c5a059]/40 transition-colors">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">SETTLEMENT VOLUME</span>
          <div className="text-xl font-bold font-mono text-slate-100">£4.28bn</div>
          <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 pt-1">
            <span>T+0 Finality</span>
            <span className="text-slate-500">DEMO DATA</span>
          </div>
        </div>

      </div>

      {/* Main Chart Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div className="lg:col-span-2 bg-[#0f1420] stone-border rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1d2636]">
            <div>
              <span className="text-[10px] font-mono text-[#c5a059] uppercase">PORTFOLIO & LIQUIDITY TREND</span>
              <h3 className="text-base font-bold text-slate-100">Institutional Net Asset Growth (£ Millions)</h3>
            </div>
            <div className="flex items-center gap-2 font-mono text-xs">
              <span className="flex items-center gap-1 text-[#c5a059]">
                <span className="w-2 h-2 rounded-full bg-[#c5a059]"></span> NAV (£M)
              </span>
              <span className="flex items-center gap-1 text-slate-400">
                <span className="w-2 h-2 rounded-full bg-slate-500"></span> Liquidity (£M)
              </span>
            </div>
          </div>

          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={CHART_DATA}>
                <defs>
                  <linearGradient id="navColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#c5a059" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#c5a059" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="#475569" fontSize={11} fontFamily="monospace" />
                <YAxis stroke="#475569" fontSize={11} fontFamily="monospace" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0d1117', borderColor: '#212936', borderRadius: '6px', color: '#f8fafc' }}
                  formatter={(value: any) => [`£${value}M`, '']}
                />
                <Area type="monotone" dataKey="nav" stroke="#c5a059" strokeWidth={2} fillOpacity={1} fill="url(#navColor)" />
                <Area type="monotone" dataKey="liquidity" stroke="#64748b" strokeWidth={1.5} fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Jump & Subsystems Panel */}
        <div className="bg-[#0f1420] stone-border rounded-xl p-5 space-y-4">
          <div className="pb-3 border-b border-[#1d2636]">
            <span className="text-[10px] font-mono text-[#c5a059] uppercase">Platform Subsystems</span>
            <h3 className="text-base font-bold text-slate-100">Institutional Modules</h3>
          </div>

          <div className="space-y-2.5">
            {[
              { id: 'CREDIT', name: 'YORKFIN CREDIT', desc: 'On-chain secured lending & collateral locks', icon: Landmark },
              { id: 'COLLATERAL ENGINE', name: 'COLLATERAL ENGINE', desc: 'Dynamic price-to-LTV stress simulator', icon: Zap },
              { id: 'LIQUIDITY', name: 'YORKFIN LIQUIDITY', desc: 'Money market depth & utilisation pools', icon: Activity },
              { id: 'TREASURY', name: 'YORKFIN TREASURY', desc: 'Yorkshire Infrastructure Holdings Ltd', icon: Server },
              { id: 'ASSETS', name: 'ASSET REGISTER', desc: 'Tokenised gilts, corporate debt & property', icon: Layers },
            ].map((m) => {
              const Icon = m.icon;
              return (
                <button
                  key={m.id}
                  onClick={() => onSelectTab(m.id)}
                  className="w-full text-left p-3 rounded-lg bg-[#141a26] border border-[#20293b] hover:border-[#c5a059] transition-all flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-[#1b2332] flex items-center justify-center text-[#c5a059] group-hover:bg-[#c5a059] group-hover:text-[#0a0d14] transition-colors">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold font-mono text-slate-200 group-hover:text-[#c5a059] transition-colors">{m.name}</h4>
                      <p className="text-[11px] text-slate-400">{m.desc}</p>
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-[#c5a059] transition-colors" />
                </button>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
