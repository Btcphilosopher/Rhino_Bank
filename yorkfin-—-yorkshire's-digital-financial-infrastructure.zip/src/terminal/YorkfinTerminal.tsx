import React, { useState } from 'react';
import { OverviewTab } from './OverviewTab';
import { PortfolioTab } from './PortfolioTab';
import { MarketsTab } from './MarketsTab';
import { CreditTab } from './CreditTab';
import { CollateralEngineTab } from './CollateralEngineTab';
import { LiquidityTab } from './LiquidityTab';
import { TreasuryTab } from './TreasuryTab';
import { AssetsTab } from './AssetsTab';
import { ContractsTab } from './ContractsTab';
import { LedgerTab } from './LedgerTab';
import { IdentityTab } from './IdentityTab';
import { RiskTab } from './RiskTab';
import { GovernanceTab } from './GovernanceTab';
import { ReportingTab } from './ReportingTab';
import { SettlementPipeline } from '../components/SettlementPipeline';
import { Terminal as TerminalIcon, ShieldCheck, X } from 'lucide-react';

interface YorkfinTerminalProps {
  onClose?: () => void;
  initialTab?: string;
}

const TABS = [
  'OVERVIEW',
  'PORTFOLIO',
  'MARKETS',
  'CREDIT',
  'COLLATERAL ENGINE',
  'LIQUIDITY',
  'TREASURY',
  'SETTLEMENT',
  'ASSETS',
  'IDENTITY',
  'CONTRACTS',
  'LEDGER',
  'RISK',
  'GOVERNANCE',
  'REPORTING',
];

export const YorkfinTerminal: React.FC<YorkfinTerminalProps> = ({ onClose, initialTab = 'OVERVIEW' }) => {
  const [activeTab, setActiveTab] = useState(initialTab);

  return (
    <div className="bg-[#0a0d14] min-h-screen text-slate-100 flex flex-col font-sans border-t border-[#1c2433]">
      
      {/* Terminal Top Bar Navigation */}
      <div className="bg-[#0e121a] border-b border-[#1c2433] px-4 md:px-8 py-3 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#c5a059] flex items-center justify-center font-serif text-[#0a0d14] font-bold text-base">
            Y
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold font-mono text-slate-100 tracking-tight">YORKFIN TERMINAL</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#161f2e] text-[#c5a059] border border-[#232f42]">
                DEMO DATA
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">LEEDS FINANCIAL INFRASTRUCTURE SYSTEM</span>
          </div>
        </div>

        {/* Tab Selection Bar */}
        <div className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
          {TABS.map((tab) => {
            const isActive = activeTab === tab;
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1.5 rounded text-[11px] font-mono font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-[#c5a059] text-[#0a0d14] shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#141b27]'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="hidden lg:flex items-center gap-1.5 text-xs font-mono text-slate-400 hover:text-slate-100 bg-[#141a26] px-3 py-1.5 rounded border border-[#212b3d]"
          >
            <X className="w-4 h-4" />
            <span>EXIT TERMINAL</span>
          </button>
        )}
      </div>

      {/* Main Active Tab Render */}
      <div className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
        {activeTab === 'OVERVIEW' && <OverviewTab onSelectTab={setActiveTab} />}
        {activeTab === 'PORTFOLIO' && <PortfolioTab />}
        {activeTab === 'MARKETS' && <MarketsTab />}
        {activeTab === 'CREDIT' && <CreditTab />}
        {activeTab === 'COLLATERAL ENGINE' && <CollateralEngineTab />}
        {activeTab === 'LIQUIDITY' && <LiquidityTab />}
        {activeTab === 'TREASURY' && <TreasuryTab />}
        {activeTab === 'SETTLEMENT' && <SettlementPipeline />}
        {activeTab === 'ASSETS' && <AssetsTab />}
        {activeTab === 'IDENTITY' && <IdentityTab />}
        {activeTab === 'CONTRACTS' && <ContractsTab />}
        {activeTab === 'LEDGER' && <LedgerTab />}
        {activeTab === 'RISK' && <RiskTab />}
        {activeTab === 'GOVERNANCE' && <GovernanceTab />}
        {activeTab === 'REPORTING' && <ReportingTab />}
      </div>

    </div>
  );
};
