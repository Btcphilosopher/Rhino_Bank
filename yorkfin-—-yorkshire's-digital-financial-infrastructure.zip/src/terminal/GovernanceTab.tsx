import React, { useState } from 'react';
import { GOVERNANCE_PROPOSALS, GovernanceProposal } from '../data/mockData';
import { Vote, ShieldCheck, CheckCircle2, Clock } from 'lucide-react';

export const GovernanceTab: React.FC = () => {
  const [proposals, setProposals] = useState<GovernanceProposal[]>(GOVERNANCE_PROPOSALS);

  const handleVote = (id: string) => {
    setProposals((prev) =>
      prev.map((p) =>
        p.id === id
          ? { ...p, votesFor: p.votesFor + 1000000, totalVotes: p.totalVotes + 1000000 }
          : p
      )
    );
    alert('Simulated 1,000,000 Governance Vote Recorded (Demo)');
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] text-[#c5a059] uppercase tracking-wider block">YORKFIN GOVERNANCE</span>
          <h2 className="text-2xl font-bold font-sans text-slate-100">
            DEMO GOVERNANCE ENVIRONMENT
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            Simulated protocol risk parameters, collateral rule adjustments and technical upgrade committee voting.
          </p>
        </div>

        <div className="px-3.5 py-2 rounded bg-[#141b27] border border-[#232c3d] text-[#c5a059] font-bold">
          RISK COMMITTEE VOTING
        </div>
      </div>

      {/* Proposals List */}
      <div className="space-y-4">
        {proposals.map((prop) => {
          const percentFor = ((prop.votesFor / prop.totalVotes) * 100).toFixed(1);

          return (
            <div key={prop.id} className="bg-[#0f1420] stone-border rounded-xl p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#1c2433] gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#c5a059]">{prop.id}</span>
                    <span className="px-2 py-0.5 rounded bg-[#161d2b] text-slate-300 text-[10px]">{prop.category}</span>
                  </div>
                  <h3 className="text-base font-bold font-sans text-slate-100 mt-1">{prop.title}</h3>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`px-2.5 py-1 rounded text-xs font-bold ${prop.status === 'ACTIVE' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800' : 'bg-slate-800 text-slate-400'}`}>
                    {prop.status}
                  </span>
                  <span className="text-slate-400 text-[11px] flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#c5a059]" /> {prop.timeRemaining}
                  </span>
                </div>
              </div>

              <p className="text-slate-300 font-sans leading-relaxed">
                {prop.description}
              </p>

              {/* Vote Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>VOTES FOR: <strong className="text-emerald-400">{percentFor}%</strong> ({prop.votesFor.toLocaleString()} YF-VOTE)</span>
                  <span>TOTAL: {prop.totalVotes.toLocaleString()} YF-VOTE</span>
                </div>

                <div className="w-full h-2.5 bg-[#141a26] rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 transition-all duration-300" style={{ width: `${percentFor}%` }}></div>
                </div>
              </div>

              {prop.status === 'ACTIVE' && (
                <button
                  onClick={() => handleVote(prop.id)}
                  className="px-4 py-2 rounded bg-[#c5a059] text-[#0a0d14] font-bold text-xs hover:bg-[#d4af37] transition-colors"
                >
                  CAST DEMO VOTE (FOR)
                </button>
              )}
            </div>
          );
        })}
      </div>

    </div>
  );
};
