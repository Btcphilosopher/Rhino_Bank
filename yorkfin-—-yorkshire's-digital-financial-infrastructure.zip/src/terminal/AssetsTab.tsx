import React, { useState } from 'react';
import { TOKENISED_ASSET_REGISTER, TokenisedAsset } from '../data/mockData';
import { Search, ShieldCheck, FileCode, Landmark, ExternalLink, Filter } from 'lucide-react';

export const AssetsTab: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [activeAsset, setActiveAsset] = useState<TokenisedAsset | null>(TOKENISED_ASSET_REGISTER[0]);

  const filteredAssets = TOKENISED_ASSET_REGISTER.filter((a) => {
    const matchesSearch = a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          a.assetId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          a.issuer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'ALL' || a.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-wider block">YORKFIN ASSET REGISTER</span>
          <h2 className="text-2xl font-bold font-mono text-slate-100">
            TOKENISED ASSETS REGISTER
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            On-chain digital representation of UK government gilts, regional infrastructure debt, corporate bonds and Grade-A commercial property.
          </p>
        </div>

        <div className="px-3 py-1.5 rounded bg-[#141b27] border border-[#232c3d] text-xs font-mono text-[#c5a059]">
          ERC-3643 INSTITUTIONAL COMPLIANT
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#0f1420] p-4 rounded-xl stone-border">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search asset ID, name, or issuer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#141a26] border border-[#212b3d] rounded pl-9 pr-4 py-2 text-xs font-mono text-slate-200 focus:border-[#c5a059] outline-none"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
          {['ALL', 'Sovereign Debt', 'Infrastructure', 'Corporate Debt', 'Commercial Property'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded text-xs font-mono whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#c5a059] text-[#0a0d14] font-bold'
                  : 'bg-[#141a26] text-slate-400 hover:text-slate-200 border border-[#212b3d]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Asset Cards List */}
        <div className="lg:col-span-1 space-y-3">
          {filteredAssets.map((asset) => {
            const isSelected = activeAsset?.assetId === asset.assetId;
            return (
              <div
                key={asset.assetId}
                onClick={() => setActiveAsset(asset)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#141b27] border-[#c5a059] shadow-md shadow-[#c5a059]/5'
                    : 'bg-[#0f1420] border-[#1f2838] hover:border-[#313f56]'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold font-mono text-[#c5a059]">{asset.assetId}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#1c2434] text-slate-300">
                    {asset.category}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-100 font-sans mb-1">{asset.name}</h3>
                <p className="text-[11px] text-slate-400 font-mono mb-3">{asset.issuer}</p>

                <div className="flex items-center justify-between text-xs font-mono pt-2 border-t border-[#1c2433]">
                  <div>
                    <span className="text-slate-500 text-[10px] block">MARKET VALUE</span>
                    <span className="text-slate-200 font-bold">£{(asset.marketValue / 1000000).toFixed(1)}M</span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500 text-[10px] block">YIELD</span>
                    <span className="text-emerald-400 font-bold">{asset.yieldToMaturity}%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Detailed Asset Inspector Page */}
        {activeAsset && (
          <div className="lg:col-span-2 bg-[#0f1420] stone-border rounded-xl p-6 space-y-5 font-mono text-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#1c2433] gap-3">
              <div>
                <span className="text-[10px] text-[#c5a059] uppercase">{activeAsset.category}</span>
                <h3 className="text-xl font-bold text-slate-100 font-sans">{activeAsset.name}</h3>
                <span className="text-slate-400 text-xs">{activeAsset.assetId} · {activeAsset.issuer}</span>
              </div>
              <div className="px-3 py-1.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 text-center font-bold">
                {activeAsset.settlementStatus}
              </div>
            </div>

            <p className="text-slate-300 font-sans text-xs leading-relaxed">
              {activeAsset.description}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
                <span className="text-slate-400 text-[10px] block">FACE VALUE</span>
                <span className="text-slate-100 font-bold text-sm">£{activeAsset.faceValue.toLocaleString()}</span>
              </div>
              <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
                <span className="text-slate-400 text-[10px] block">MARKET VALUE</span>
                <span className="text-[#c5a059] font-bold text-sm">£{activeAsset.marketValue.toLocaleString()}</span>
              </div>
              <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
                <span className="text-slate-400 text-[10px] block">MATURITY DATE</span>
                <span className="text-slate-200 font-bold">{activeAsset.maturity}</span>
              </div>
              <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
                <span className="text-slate-400 text-[10px] block">COUPON / YIELD</span>
                <span className="text-emerald-400 font-bold">{activeAsset.coupon}% / {activeAsset.yieldToMaturity}%</span>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider text-[#c5a059]">
                On-Chain Architecture & Verification
              </h4>

              <div className="space-y-2">
                <div className="flex justify-between p-2.5 bg-[#121824] rounded border border-[#1b2332]">
                  <span className="text-slate-400">SMART CONTRACT ADDRESS:</span>
                  <span className="text-slate-200 text-[#c5a059] font-bold">{activeAsset.contractAddress}</span>
                </div>

                <div className="flex justify-between p-2.5 bg-[#121824] rounded border border-[#1b2332]">
                  <span className="text-slate-400">OWNERSHIP REGISTRY:</span>
                  <span className="text-slate-200">{activeAsset.ownershipRegistry}</span>
                </div>

                <div className="flex justify-between p-2.5 bg-[#121824] rounded border border-[#1b2332]">
                  <span className="text-slate-400">COLLATERAL ELIGIBILITY:</span>
                  <span className="text-emerald-400 font-bold">PLEDGABLE AS CREDIT COLLATERAL</span>
                </div>
              </div>
            </div>

            {/* Audit History */}
            <div className="space-y-2 pt-2">
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Independent Audit Records</h4>
              <div className="space-y-1.5">
                {activeAsset.auditHistory.map((audit, idx) => (
                  <div key={idx} className="p-2.5 bg-[#0b0e14] rounded border border-[#1a2232] flex items-center justify-between">
                    <div>
                      <span className="text-slate-200 font-bold block">{audit.firm}</span>
                      <span className="text-slate-500 text-[10px]">{audit.date}</span>
                    </div>
                    <span className="text-emerald-400 font-bold">{audit.result}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
