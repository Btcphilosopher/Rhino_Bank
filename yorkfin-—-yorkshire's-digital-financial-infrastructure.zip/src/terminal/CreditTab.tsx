import React, { useState } from 'react';
import { Landmark, ShieldCheck, AlertTriangle, ArrowRight, CheckCircle2 } from 'lucide-react';

export const CreditTab: React.FC = () => {
  const [borrowingAsset, setBorrowingAsset] = useState('GBP STABLECOIN (YF-GBP)');
  const [collateralAsset, setCollateralAsset] = useState('TOKENISED UK GILT 2031 (YF-GILT-2031)');
  const [loanAmount, setLoanAmount] = useState(250000);
  const [collateralAmount, setCollateralAmount] = useState(350000);
  const [maturityMonths, setMaturityMonths] = useState(12);

  const ltv = (loanAmount / collateralAmount) * 100;
  const interestRate = 5.82;
  const healthFactor = (collateralAmount * 0.82) / loanAmount; // liquidation LTV threshold 82%

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-wider block">YORKFIN CREDIT FACILITY</span>
          <h2 className="text-2xl font-bold font-mono text-slate-100">
            CREDIT WITHOUT THE PAPERWORK.
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Programmatic secured lending backed by on-chain tokenised UK Gilts and institutional assets.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-slate-300 bg-[#141b27] px-3 py-1.5 rounded border border-[#212a3d]">
          <ShieldCheck className="w-4 h-4 text-[#c5a059]" />
          <span>INSTITUTIONAL GRADE DVP</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Interactive Borrow / Credit Simulator */}
        <div className="lg:col-span-2 bg-[#0f1420] stone-border rounded-xl p-6 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#1c2433]">
            <h3 className="text-base font-bold text-slate-100 font-mono">Create Secured Credit Facility</h3>
            <span className="text-xs font-mono text-[#c5a059]">SIMULATED ON-CHAIN BORROW</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
            <div className="space-y-1.5">
              <label className="text-slate-400 block">BORROWING ASSET</label>
              <select 
                value={borrowingAsset}
                onChange={(e) => setBorrowingAsset(e.target.value)}
                className="w-full bg-[#141a26] border border-[#232c3d] rounded p-2.5 text-slate-200 focus:border-[#c5a059] outline-none"
              >
                <option>GBP STABLECOIN (YF-GBP)</option>
                <option>STERLING CASH EQUIVALENT</option>
                <option>USD STABLECOIN (YF-USD)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-400 block">COLLATERAL ASSET</label>
              <select 
                value={collateralAsset}
                onChange={(e) => setCollateralAsset(e.target.value)}
                className="w-full bg-[#141a26] border border-[#232c3d] rounded p-2.5 text-slate-200 focus:border-[#c5a059] outline-none"
              >
                <option>TOKENISED UK GILT 2031 (YF-GILT-2031)</option>
                <option>YORKSHIRE INFRASTRUCTURE DEBT (YF-INFRA-01)</option>
                <option>LEEDS COMMERCIAL REAL ESTATE (YF-PROP-LEEDS)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <label className="text-slate-400">LOAN VALUE (£)</label>
                <span className="text-slate-200 font-bold">£{loanAmount.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="50000"
                max="500000"
                step="10000"
                value={loanAmount}
                onChange={(e) => setLoanAmount(Number(e.target.value))}
                className="w-full accent-[#c5a059] bg-[#141a26] h-2 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between">
                <label className="text-slate-400">COLLATERAL PLEDGED (£)</label>
                <span className="text-[#c5a059] font-bold">£{collateralAmount.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="200000"
                max="800000"
                step="10000"
                value={collateralAmount}
                onChange={(e) => setCollateralAmount(Number(e.target.value))}
                className="w-full accent-[#c5a059] bg-[#141a26] h-2 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Collateral Ratio Bar */}
          <div className="bg-[#0a0d14] p-4 rounded-lg border border-[#1b2332] space-y-2 font-mono text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">CURRENT LTV: <strong className={ltv > 80 ? 'text-red-400' : 'text-slate-100'}>{ltv.toFixed(1)}%</strong></span>
              <span className="text-slate-400">HEALTH FACTOR: <strong className={healthFactor < 1.1 ? 'text-red-400' : 'text-emerald-400'}>{healthFactor.toFixed(2)}</strong></span>
              <span className="text-slate-400">LIQUIDATION THRESHOLD: <strong className="text-amber-400">82.0%</strong></span>
            </div>

            <div className="w-full h-3 bg-[#151c2a] rounded-full overflow-hidden relative">
              <div
                className={`h-full transition-all duration-300 ${ltv > 80 ? 'bg-red-500' : ltv > 75 ? 'bg-amber-500' : 'bg-[#c5a059]'}`}
                style={{ width: `${Math.min(ltv, 100)}%` }}
              ></div>
              <div className="absolute top-0 bottom-0 left-[82%] w-0.5 bg-red-400 shadow"></div>
            </div>
            
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>0% (Conservative)</span>
              <span>82% (Liquidation Limit)</span>
              <span>100% (Maximum Risk)</span>
            </div>
          </div>

          <button
            onClick={() => alert(`Simulated Loan Request Submitted for £${loanAmount.toLocaleString()} against ${collateralAsset}`)}
            className="w-full py-3 rounded bg-[#c5a059] text-[#0a0d14] font-mono text-xs font-bold hover:bg-[#d4af37] transition-colors flex items-center justify-center gap-2"
          >
            <span>EXECUTE ON-CHAIN CREDIT FACILITY</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Active Loan Position Card */}
        <div className="bg-[#0f1420] stone-border rounded-xl p-5 space-y-4 font-mono text-xs">
          <div className="pb-3 border-b border-[#1d2636]">
            <span className="text-[10px] text-[#c5a059] uppercase">ACTIVE BENCHMARK POSITION</span>
            <h3 className="text-base font-bold text-slate-100">FACILITY #YF-CR-882</h3>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between p-2 bg-[#141a26] rounded">
              <span className="text-slate-400">BORROWING ASSET</span>
              <span className="text-slate-200 font-bold">GBP STABLECOIN</span>
            </div>

            <div className="flex justify-between p-2 bg-[#141a26] rounded">
              <span className="text-slate-400">COLLATERAL</span>
              <span className="text-slate-200 font-bold">TOKENISED GILT</span>
            </div>

            <div className="flex justify-between p-2 bg-[#141a26] rounded">
              <span className="text-slate-400">LOAN VALUE</span>
              <span className="text-slate-100 font-bold">£250,000</span>
            </div>

            <div className="flex justify-between p-2 bg-[#141a26] rounded">
              <span className="text-slate-400">COLLATERAL PLEDGED</span>
              <span className="text-[#c5a059] font-bold">£350,000</span>
            </div>

            <div className="flex justify-between p-2 bg-[#141a26] rounded">
              <span className="text-slate-400">LTV</span>
              <span className="text-emerald-400 font-bold">71.4%</span>
            </div>

            <div className="flex justify-between p-2 bg-[#141a26] rounded">
              <span className="text-slate-400">INTEREST RATE</span>
              <span className="text-emerald-400 font-bold">5.82% p.a.</span>
            </div>

            <div className="flex justify-between p-2 bg-[#141a26] rounded">
              <span className="text-slate-400">MATURITY</span>
              <span className="text-slate-200">12 MONTHS</span>
            </div>

            <div className="flex justify-between p-2 bg-[#141a26] rounded">
              <span className="text-slate-400">STATUS</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> ACTIVE
              </span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
