import React from 'react';
import { ShieldAlert, Scale, AlertCircle, CheckCircle2, Sliders } from 'lucide-react';

export const RiskTab: React.FC = () => {
  const riskCategories = [
    { name: 'MARKET RISK', status: 'Normal', color: 'text-emerald-400 bg-emerald-950/60 border-emerald-800/40', desc: 'Asset price volatility within historical 99% VaR parameters.' },
    { name: 'LIQUIDITY RISK', status: 'Low', color: 'text-emerald-400 bg-emerald-950/60 border-emerald-800/40', desc: 'Available pool liquidity depth covers 3.2x daily peak settlement requirements.' },
    { name: 'SMART CONTRACT RISK', status: 'Reviewed', color: 'text-[#c5a059] bg-[#2a2213] border-[#42361e]', desc: 'Formal verification completed on testnet bytecode by independent UK audit firms.' },
    { name: 'COLLATERAL RISK', status: 'Moderate', color: 'text-amber-400 bg-amber-950/60 border-amber-800/40', desc: 'Real-time loan health monitoring enforces automatic 82% LTV threshold alerts.' },
    { name: 'COUNTERPARTY RISK', status: 'Monitored', color: 'text-emerald-400 bg-emerald-950/60 border-emerald-800/40', desc: 'Sovereign UK gilts and Grade-A commercial real estate backing active claims.' },
  ];

  return (
    <div className="space-y-6 font-mono text-xs">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] text-[#c5a059] uppercase tracking-wider block">YORKFIN RISK DASHBOARD</span>
          <h2 className="text-2xl font-bold font-sans text-slate-100">
            SYSTEMIC RISK & SOLVENCY MONITOR
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            Continuous real-time risk surveillance across collateral pools, oracle feeds, smart contracts, and settlement pipelines.
          </p>
        </div>

        <div className="px-3.5 py-2 rounded bg-[#141b27] border border-[#232c3d] text-slate-300 font-bold flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-[#c5a059]" />
          <span>RISK FRAMEWORK ACTIVE</span>
        </div>
      </div>

      {/* 5 Key Risk Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {riskCategories.map((r) => (
          <div key={r.name} className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-2">
            <span className="text-[10px] text-slate-400 block uppercase">{r.name}</span>
            <div className={`px-2.5 py-1 rounded text-xs font-bold border inline-block ${r.color}`}>
              {r.status}
            </div>
            <p className="text-[10px] text-slate-400 font-sans leading-snug pt-1">
              {r.desc}
            </p>
          </div>
        ))}
      </div>

      {/* Detailed Risk Breakdown */}
      <div className="bg-[#0f1420] stone-border rounded-xl p-6 space-y-4">
        <h3 className="text-base font-bold font-sans text-slate-100">Risk Stress Parameters</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-3.5 bg-[#141a26] rounded border border-[#1f2838] space-y-1">
            <span className="text-slate-400 text-[10px]">VALUE AT RISK (99% VaR 1-DAY)</span>
            <div className="text-base font-bold text-slate-100">£14,210,000</div>
            <span className="text-slate-500 text-[10px]">0.57% of Total Assets</span>
          </div>

          <div className="p-3.5 bg-[#141a26] rounded border border-[#1f2838] space-y-1">
            <span className="text-slate-400 text-[10px]">WORST-CASE GILT STRESS SPREAD</span>
            <div className="text-base font-bold text-[#c5a059]">+140 bps Shift</div>
            <span className="text-slate-500 text-[10px]">Collateral Health Retained</span>
          </div>

          <div className="p-3.5 bg-[#141a26] rounded border border-[#1f2838] space-y-1">
            <span className="text-slate-400 text-[10px]">ORACLE TIME-TO-FINALITY</span>
            <div className="text-base font-bold text-emerald-400">0.8 Seconds</div>
            <span className="text-slate-500 text-[10px]">Multi-source Feed</span>
          </div>
        </div>
      </div>

    </div>
  );
};
