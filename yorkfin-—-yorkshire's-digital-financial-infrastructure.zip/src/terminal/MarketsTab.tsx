import React, { useState } from 'react';
import { MARKETS_DATA, MarketPair } from '../data/mockData';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { RefreshCw, Search, ArrowUpRight, TrendingUp, ShieldCheck } from 'lucide-react';

export const MarketsTab: React.FC = () => {
  const [selectedPair, setSelectedPair] = useState<MarketPair>(MARKETS_DATA[0]);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-wider block">YORKFIN MARKETS</span>
          <h2 className="text-2xl font-bold font-mono text-slate-100">
            INSTITUTIONAL LIQUIDITY MARKETS
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Orderbook depth and real-time Sterling cross-rates for tokenised assets, fiat currencies and institutional reserves.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-slate-300 bg-[#141b27] px-3 py-1.5 rounded border border-[#212a3d]">
          <ShieldCheck className="w-4 h-4 text-[#c5a059]" />
          <span>ZERO PRICE FLASHING · DVP ORDERBOOK</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Markets Table */}
        <div className="lg:col-span-1 bg-[#0f1420] stone-border rounded-xl p-4 space-y-3">
          <div className="pb-2 border-b border-[#1c2433] flex justify-between items-center font-mono">
            <span className="text-xs font-bold text-slate-200">MARKETS</span>
            <span className="text-[10px] text-slate-400">7 ACTIVE PAIRS</span>
          </div>

          <div className="space-y-2">
            {MARKETS_DATA.map((pair) => {
              const isSelected = selectedPair.symbol === pair.symbol;
              return (
                <div
                  key={pair.symbol}
                  onClick={() => setSelectedPair(pair)}
                  className={`p-3 rounded-lg border font-mono text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#141b27] border-[#c5a059] shadow-sm'
                      : 'bg-[#0b0e16] border-[#1c2434] hover:border-[#2e3b52]'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-slate-100">{pair.symbol}</span>
                    <span className={`font-bold ${pair.change24h >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {pair.change24h >= 0 ? '+' : ''}{pair.change24h}%
                    </span>
                  </div>

                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>{pair.price > 100 ? pair.price.toFixed(2) : pair.price.toFixed(4)}</span>
                    <span>Vol: £{(pair.volume24h / 1000000).toFixed(1)}M</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Pair Financial Chart & Orderbook */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="bg-[#0f1420] stone-border rounded-xl p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#1c2433] gap-3 font-mono">
              <div>
                <span className="text-[10px] text-[#c5a059] uppercase">{selectedPair.name}</span>
                <h3 className="text-2xl font-bold text-slate-100">{selectedPair.symbol}</h3>
              </div>

              <div className="flex items-center gap-4 text-right">
                <div>
                  <span className="text-[10px] text-slate-400 block">LAST PRICE</span>
                  <span className="text-xl font-bold text-slate-100">
                    {selectedPair.price > 100 ? selectedPair.price.toFixed(2) : selectedPair.price.toFixed(4)}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">24H CHANGE</span>
                  <span className={`text-xl font-bold ${selectedPair.change24h >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {selectedPair.change24h}%
                  </span>
                </div>
              </div>
            </div>

            {/* Financial Line Chart */}
            <div className="h-[260px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={selectedPair.chartData}>
                  <XAxis dataKey="time" stroke="#475569" fontSize={11} fontFamily="monospace" />
                  <YAxis stroke="#475569" fontSize={11} fontFamily="monospace" domain={['auto', 'auto']} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0d1117', borderColor: '#212936', borderRadius: '6px', color: '#f8fafc' }}
                  />
                  <Line type="monotone" dataKey="price" stroke="#c5a059" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Market Depth Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs pt-2">
              <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
                <span className="text-slate-400 text-[10px] block">BID / ASK</span>
                <span className="text-slate-200 font-bold">{selectedPair.bid} / {selectedPair.ask}</span>
              </div>
              <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
                <span className="text-slate-400 text-[10px] block">SPREAD</span>
                <span className="text-[#c5a059] font-bold">{selectedPair.spread}</span>
              </div>
              <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
                <span className="text-slate-400 text-[10px] block">24H VOLUME</span>
                <span className="text-slate-200 font-bold">£{(selectedPair.volume24h / 1000000).toFixed(2)}M</span>
              </div>
              <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
                <span className="text-slate-400 text-[10px] block">SETTLEMENT</span>
                <span className="text-emerald-400 font-bold">{selectedPair.settlementStatus}</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
