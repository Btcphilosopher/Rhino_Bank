import React, { useState } from 'react';
import { SMART_CONTRACTS, SmartContractInfo } from '../data/mockData';
import { Code2, CheckCircle2, ShieldCheck, Terminal as TerminalIcon, Copy, Check } from 'lucide-react';

export const ContractsTab: React.FC = () => {
  const [selectedContract, setSelectedContract] = useState<SmartContractInfo>(SMART_CONTRACTS[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedContract.codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-wider block">YORKFIN SMART CONTRACTS</span>
          <h2 className="text-2xl font-bold font-mono text-slate-100">
            FINANCE AS CODE.
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Deterministic, open-source smart contract architecture governing digital Sterling settlement, credit, and asset tokenisation.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-slate-300 bg-[#141b27] px-3 py-1.5 rounded border border-[#212a3d]">
          <ShieldCheck className="w-4 h-4 text-[#c5a059]" />
          <span>VERIFIED BYTECODE · DEMO AUDITED</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Contracts Selector Column */}
        <div className="lg:col-span-1 space-y-2 font-mono">
          {SMART_CONTRACTS.map((contract) => {
            const isSelected = selectedContract.contractId === contract.contractId;
            return (
              <div
                key={contract.contractId}
                onClick={() => setSelectedContract(contract)}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#141b27] border-[#c5a059] shadow-md shadow-[#c5a059]/5'
                    : 'bg-[#0f1420] border-[#1f2838] hover:border-[#313f56]'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-[#c5a059]">{contract.contractId}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/40">
                    {contract.status}
                  </span>
                </div>

                <h3 className="text-xs font-bold text-slate-100 mb-1">{contract.name}</h3>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>{contract.version}</span>
                  <span>{contract.transactionCount.toLocaleString()} Tx</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Contract Code Inspector & Details */}
        <div className="lg:col-span-2 bg-[#0f1420] stone-border rounded-xl p-6 space-y-5 font-mono text-xs">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#1c2433] gap-3">
            <div>
              <span className="text-[10px] text-[#c5a059] uppercase">{selectedContract.version}</span>
              <h3 className="text-xl font-bold text-slate-100">{selectedContract.contractId} — {selectedContract.name}</h3>
              <span className="text-slate-400 text-xs">{selectedContract.description}</span>
            </div>

            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded bg-[#141b27] border border-[#232c3d] text-slate-300 hover:text-slate-100 flex items-center gap-1.5 text-xs shrink-0"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Code' : 'Copy Source'}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-2.5 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 text-[10px] block">NETWORK</span>
              <span className="text-slate-200 font-bold">{selectedContract.network}</span>
            </div>
            <div className="p-2.5 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 text-[10px] block">AUDIT STATUS</span>
              <span className="text-emerald-400 font-bold">{selectedContract.auditStatus}</span>
            </div>
            <div className="p-2.5 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 text-[10px] block">LAST UPDATE</span>
              <span className="text-slate-200">{selectedContract.lastUpdate}</span>
            </div>
            <div className="p-2.5 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 text-[10px] block">OPTIMISATION</span>
              <span className="text-[#c5a059]">{selectedContract.gasOptimisation}</span>
            </div>
          </div>

          {/* Source Code Box */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between text-slate-400 text-[11px]">
              <span className="flex items-center gap-1.5 font-bold text-slate-200">
                <Code2 className="w-4 h-4 text-[#c5a059]" />
                Solidity Smart Contract Source Inspection
              </span>
              <span className="text-[10px]">SOLIDITY v0.8.24</span>
            </div>

            <pre className="p-4 rounded-lg bg-[#070a10] border border-[#1b2332] text-slate-300 font-mono text-[11px] overflow-x-auto leading-relaxed">
              <code>{selectedContract.codeSnippet}</code>
            </pre>
          </div>

        </div>

      </div>

    </div>
  );
};
