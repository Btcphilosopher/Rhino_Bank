import React, { useState } from 'react';
import { Briefcase, ShieldCheck, Users, Lock, CheckCircle2, ArrowUpRight, AlertCircle } from 'lucide-react';

export const TreasuryTab: React.FC = () => {
  const [approvalsQueue, setApprovalsQueue] = useState([
    { id: 'APP-101', recipient: 'HM Revenue & Customs (Corporate Tax)', amount: 450000, asset: 'YF-GBP', requiredSigs: 3, currentSigs: 2, status: 'PENDING SIGNATURE' },
    { id: 'APP-102', recipient: 'Leeds Grid Substation Expansion Bond', amount: 1200000, asset: 'YF-INFRA-01', requiredSigs: 3, currentSigs: 3, status: 'EXECUTED' }
  ]);

  const handleApprove = (id: string) => {
    setApprovalsQueue((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, currentSigs: 3, status: 'EXECUTED' } : item
      )
    );
  };

  return (
    <div className="space-y-6 font-mono">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] text-[#c5a059] uppercase tracking-wider block">YORKFIN CORPORATE TREASURY</span>
          <h2 className="text-2xl font-bold font-sans text-slate-100">
            YORKSHIRE INFRASTRUCTURE HOLDINGS LTD
          </h2>
          <span className="text-xs text-slate-400">Institutional Treasury Account · LEEDS-REG-88219</span>
        </div>

        <div className="px-3.5 py-2 rounded bg-[#141b27] border border-[#232c3d] text-xs text-emerald-400 font-bold flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#c5a059]" />
          <span>MULTI-SIG 3-OF-5 ACTIVE</span>
        </div>
      </div>

      {/* Treasury Key Balances Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
        <div className="bg-[#0f1420] stone-border p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">CASH</span>
          <div className="text-base font-bold text-slate-100">£8,420,000</div>
          <span className="text-[10px] text-slate-500">Instant Liquidity</span>
        </div>

        <div className="bg-[#0f1420] stone-border p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">TOKENISED ASSETS</span>
          <div className="text-base font-bold text-[#c5a059]">£4,210,000</div>
          <span className="text-[10px] text-slate-500">Gilts & Bonds</span>
        </div>

        <div className="bg-[#0f1420] stone-border p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">DIGITAL ASSETS</span>
          <div className="text-base font-bold text-slate-100">£1,180,000</div>
          <span className="text-[10px] text-slate-500">Reserve Custody</span>
        </div>

        <div className="bg-[#0f1420] stone-border p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">COLLATERAL</span>
          <div className="text-base font-bold text-slate-100">£2,800,000</div>
          <span className="text-[10px] text-slate-500">Pledged in Credit</span>
        </div>

        <div className="bg-[#0f1420] stone-border p-3.5 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 uppercase block">LIABILITIES</span>
          <div className="text-base font-bold text-amber-400">£3,400,000</div>
          <span className="text-[10px] text-slate-500">Secured Credit Line</span>
        </div>

        <div className="bg-[#0f1420] stone-border p-3.5 rounded-xl space-y-1 bg-gradient-to-br from-[#131a26] to-[#0f1420]">
          <span className="text-[10px] text-[#c5a059] uppercase block font-bold">NET TREASURY</span>
          <div className="text-base font-bold text-emerald-400">£13,210,000</div>
          <span className="text-[10px] text-slate-500">Audit Verified</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Pending Multi-Sig Approvals */}
        <div className="lg:col-span-2 bg-[#0f1420] stone-border rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1d2636]">
            <div>
              <span className="text-[10px] text-[#c5a059] uppercase">APPROVALS QUEUE</span>
              <h3 className="text-base font-bold font-sans text-slate-100">Corporate Multi-Signature Queue</h3>
            </div>
            <span className="text-xs text-slate-400">3-OF-5 POLICY ENFORCED</span>
          </div>

          <div className="space-y-3">
            {approvalsQueue.map((app) => (
              <div key={app.id} className="p-4 rounded-lg bg-[#141a26] border border-[#212b3d] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#c5a059]">{app.id}</span>
                    <span className="text-slate-200 font-bold">{app.recipient}</span>
                  </div>
                  <div className="text-slate-400 text-[11px] mt-1">
                    Amount: <strong className="text-slate-100">£{app.amount.toLocaleString()} ({app.asset})</strong> · Signatures: <strong className="text-[#c5a059]">{app.currentSigs}/{app.requiredSigs}</strong>
                  </div>
                </div>

                {app.status === 'EXECUTED' ? (
                  <span className="px-3 py-1.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 font-bold text-center">
                    EXECUTED
                  </span>
                ) : (
                  <button
                    onClick={() => handleApprove(app.id)}
                    className="px-3.5 py-2 rounded bg-[#c5a059] text-[#0a0d14] font-bold hover:bg-[#d4af37] transition-colors"
                  >
                    SIGN & EXECUTE
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Corporate Controls & Limits */}
        <div className="bg-[#0f1420] stone-border rounded-xl p-5 space-y-4 text-xs">
          <div className="pb-3 border-b border-[#1d2636]">
            <span className="text-[10px] text-[#c5a059] uppercase">TREASURY CONTROLS</span>
            <h3 className="text-base font-bold font-sans text-slate-100">Spending Policies</h3>
          </div>

          <div className="space-y-2.5">
            <div className="p-2.5 bg-[#141a26] rounded">
              <span className="text-slate-400 text-[10px] block">DAILY TRANSACTION LIMIT</span>
              <span className="text-slate-100 font-bold">£5,000,000.00</span>
            </div>

            <div className="p-2.5 bg-[#141a26] rounded">
              <span className="text-slate-400 text-[10px] block">TIMELOCK PERIOD</span>
              <span className="text-slate-200 font-bold">2 Hours (Emergency Bypass Available)</span>
            </div>

            <div className="p-2.5 bg-[#141a26] rounded">
              <span className="text-slate-400 text-[10px] block">WHITELISTED RECIPIENTS</span>
              <span className="text-emerald-400 font-bold">14 Verified Yorkshire Entities</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
