import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, Zap, Sliders, CheckCircle2 } from 'lucide-react';

export const CollateralEngineTab: React.FC = () => {
  const [loanValue] = useState(250000); // fixed loan value
  const [collateralValue, setCollateralValue] = useState(350000); // dynamic slider value

  const ltv = (loanValue / collateralValue) * 100;
  const maxLiquidationLTV = 82.0; // 82%
  const maxBorrowAmount = collateralValue * (maxLiquidationLTV / 100);
  const healthFactor = maxBorrowAmount / loanValue;

  let riskLevel = 'NORMAL';
  let riskColor = 'text-emerald-400 border-emerald-800 bg-emerald-950/60';

  if (ltv >= maxLiquidationLTV) {
    riskLevel = 'CRITICAL — LIQUIDATION THRESHOLD BREACHED';
    riskColor = 'text-red-400 border-red-800 bg-red-950/80 animate-pulse';
  } else if (ltv >= 75) {
    riskLevel = 'WARNING — HIGH LTV CONCENTRATION';
    riskColor = 'text-amber-400 border-amber-800 bg-amber-950/60';
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-wider block">
            YORKFIN COLLATERAL ENGINE
          </span>
          <h2 className="text-2xl font-bold font-mono text-slate-100">
            DYNAMIC COLLATERAL & LIQUIDATION SIMULATOR
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Simulate collateral market fluctuations in real-time to inspect Loan-To-Value mechanics and automated health factor responses.
          </p>
        </div>

        <div className={`px-4 py-2 rounded border font-mono text-xs font-bold ${riskColor}`}>
          {riskLevel}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Interactive Dynamic Slider Controls */}
        <div className="lg:col-span-2 bg-[#0f1420] stone-border rounded-xl p-6 space-y-6">
          
          <div className="flex items-center justify-between pb-3 border-b border-[#1c2433]">
            <h3 className="text-base font-bold text-slate-100 font-mono flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#c5a059]" />
              Market Stress Testing Controls
            </h3>
            <span className="text-xs font-mono text-slate-400">SLIDER RANGE: £150k – £500k</span>
          </div>

          <div className="space-y-4 font-mono">
            <div className="flex justify-between items-center">
              <label className="text-xs text-slate-300 font-bold">
                SIMULATED COLLATERAL ASSET VALUE (£)
              </label>
              <span className="text-lg font-bold text-[#c5a059] bg-[#141b27] px-3 py-1 rounded border border-[#232c3d]">
                £{collateralValue.toLocaleString()}
              </span>
            </div>

            <input
              type="range"
              min="150000"
              max="500000"
              step="5000"
              value={collateralValue}
              onChange={(e) => setCollateralValue(Number(e.target.value))}
              className="w-full accent-[#c5a059] bg-[#131926] h-3 rounded cursor-pointer"
            />

            <div className="flex justify-between text-[11px] text-slate-500">
              <span>£150,000 (Severe Market Crash)</span>
              <span>£350,000 (Baseline)</span>
              <span>£500,000 (Market Rally)</span>
            </div>
          </div>

          {/* Real-time Dynamic Gauge Visual */}
          <div className="bg-[#0a0d14] p-5 rounded-lg border border-[#1b2332] space-y-4 font-mono">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 bg-[#111622] rounded border border-[#1e2738]">
                <span className="text-[10px] text-slate-400 block mb-1">COLLATERAL VALUE</span>
                <span className="text-sm font-bold text-[#c5a059]">£{collateralValue.toLocaleString()}</span>
              </div>
              <div className="p-3 bg-[#111622] rounded border border-[#1e2738]">
                <span className="text-[10px] text-slate-400 block mb-1">LOAN PRINCIPAL</span>
                <span className="text-sm font-bold text-slate-100">£{loanValue.toLocaleString()}</span>
              </div>
              <div className="p-3 bg-[#111622] rounded border border-[#1e2738]">
                <span className="text-[10px] text-slate-400 block mb-1">LTV RATIO</span>
                <span className={`text-sm font-bold ${ltv >= 82 ? 'text-red-400' : 'text-slate-100'}`}>
                  {ltv.toFixed(2)}%
                </span>
              </div>
              <div className="p-3 bg-[#111622] rounded border border-[#1e2738]">
                <span className="text-[10px] text-slate-400 block mb-1">HEALTH FACTOR</span>
                <span className={`text-sm font-bold ${healthFactor < 1 ? 'text-red-400 font-extrabold' : 'text-emerald-400'}`}>
                  {healthFactor.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Health Bar */}
            <div className="space-y-1 pt-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Collateral Liquidation Level Bar</span>
                <span className="text-amber-400">Liquidation Threshold: 82.00%</span>
              </div>

              <div className="w-full h-4 bg-[#141b27] rounded-full overflow-hidden relative border border-[#212c3e]">
                <div
                  className={`h-full transition-all duration-300 ${
                    ltv >= 82 ? 'bg-red-500' : ltv >= 75 ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${Math.min(ltv, 100)}%` }}
                ></div>
                <div className="absolute top-0 bottom-0 left-[82%] w-1 bg-red-400 shadow-md"></div>
              </div>
            </div>
          </div>

          {/* Explicit Risk Warning Box */}
          {ltv >= 82 ? (
            <div className="p-4 rounded-lg bg-red-950/80 border border-red-800 text-red-200 text-xs font-mono space-y-2">
              <div className="flex items-center gap-2 font-bold text-red-100">
                <ShieldAlert className="w-5 h-5 text-red-400" />
                <span>AUTOMATED LIQUIDATION WARNING</span>
              </div>
              <p>
                The Loan-to-Value ratio ({ltv.toFixed(2)}%) has exceeded the strict liquidation threshold of 82.00%. In a live system, the smart contract would automatically trigger partial collateral auction to restore loan health factor above 1.0.
              </p>
            </div>
          ) : (
            <div className="p-4 rounded-lg bg-[#0c111a] border border-[#1b2434] text-slate-300 text-xs font-mono flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-100 block mb-0.5">HEALTH FACTOR OPTIMAL ({healthFactor.toFixed(2)})</strong>
                <span>The loan position has adequate collateral margin. Health factor remains above 1.0, ensuring zero automated liquidation risk.</span>
              </div>
            </div>
          )}

        </div>

        {/* Collateral Engine Technical Specifications */}
        <div className="bg-[#0f1420] stone-border rounded-xl p-5 space-y-4 font-mono text-xs">
          <div className="pb-3 border-b border-[#1d2636]">
            <span className="text-[10px] text-[#c5a059] uppercase">SPECIFICATIONS</span>
            <h3 className="text-base font-bold text-slate-100">ENGINE INVARIANTS</h3>
          </div>

          <div className="space-y-3">
            <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 block text-[10px]">COLLATERAL ASSET</span>
              <span className="text-slate-100 font-bold">YF-GILT-2031 (Tokenised UK Gilt)</span>
            </div>

            <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 block text-[10px]">INITIAL BASE LTV</span>
              <span className="text-slate-100 font-bold">71.43%</span>
            </div>

            <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 block text-[10px]">LIQUIDATION THRESHOLD</span>
              <span className="text-amber-400 font-bold">82.00%</span>
            </div>

            <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 block text-[10px]">LIQUIDATION PENALTY</span>
              <span className="text-slate-200">2.50% (Smart-contract fee)</span>
            </div>

            <div className="p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400 block text-[10px]">PRICE ORACLE AGGREGATION</span>
              <span className="text-emerald-400">Leeds-Node Multi-Source Oracle</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
