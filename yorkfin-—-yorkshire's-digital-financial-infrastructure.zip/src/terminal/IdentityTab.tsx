import React, { useState } from 'react';
import { Key, ShieldCheck, CheckCircle2, Lock, UserCheck } from 'lucide-react';

export const IdentityTab: React.FC = () => {
  return (
    <div className="space-y-6 font-mono text-xs">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] text-[#c5a059] uppercase tracking-wider block">YORKFIN IDENTITY</span>
          <h2 className="text-2xl font-bold font-sans text-slate-100">
            ONE IDENTITY. MANY FINANCIAL SYSTEMS.
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            Privacy-preserving cryptographic identity for institutional KYC, multi-signature signing keys and regulatory permissions.
          </p>
        </div>

        <div className="px-3.5 py-2 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 font-bold flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#c5a059]" />
          <span>VERIFIED INSTITUTION</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Identity Credentials Box */}
        <div className="bg-[#0f1420] stone-border rounded-xl p-6 space-y-4">
          <div className="pb-3 border-b border-[#1d2636]">
            <span className="text-[10px] text-[#c5a059] uppercase">IDENTITY CARD</span>
            <h3 className="text-base font-bold font-sans text-slate-100">YORKFIN-ID-84A71C</h3>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400">INSTITUTION:</span>
              <span className="text-slate-100 font-bold">YORKSHIRE INFRASTRUCTURE HOLDINGS LTD</span>
            </div>

            <div className="flex justify-between p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400">KYC VERIFICATION:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> COMPLETE (DEMO)
              </span>
            </div>

            <div className="flex justify-between p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400">SIGNING KEY STATUS:</span>
              <span className="text-[#c5a059] font-bold">ACTIVE HARDWARE HSM</span>
            </div>

            <div className="flex justify-between p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400">PRIMARY WALLET:</span>
              <span className="text-slate-200 font-bold">0x84f02a...19a1</span>
            </div>

            <div className="flex justify-between p-3 bg-[#141a26] rounded border border-[#1f2838]">
              <span className="text-slate-400">AUTHORISED PERMISSIONS:</span>
              <span className="text-slate-100 font-bold">TREASURY / SETTLEMENT / CREDIT</span>
            </div>
          </div>
        </div>

        {/* Security & Access Controls */}
        <div className="bg-[#0f1420] stone-border rounded-xl p-6 space-y-4">
          <div className="pb-3 border-b border-[#1d2636]">
            <span className="text-[10px] text-[#c5a059] uppercase">CRYPTOGRAPHIC ASSURANCE</span>
            <h3 className="text-base font-bold font-sans text-slate-100">Zero-Knowledge Compliance</h3>
          </div>

          <p className="text-slate-300 font-sans text-xs leading-relaxed">
            YORKFIN identity uses zero-knowledge proof cryptography to verify institutional credentials, anti-money laundering compliance, and capital adequacy without leaking sensitive trade secrets or counterparty ledger identities.
          </p>

          <div className="p-4 rounded-lg bg-[#0b0e14] border border-[#1a2232] space-y-2">
            <div className="flex justify-between text-slate-300">
              <span>LEEDS FINANCIAL AUTHORITY ID:</span>
              <span className="text-[#c5a059] font-bold">UK-LDS-2026-9921</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>ZERO-KNOWLEDGE PROOF STATUS:</span>
              <span className="text-emerald-400 font-bold">VALIDATED ON-CHAIN</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
