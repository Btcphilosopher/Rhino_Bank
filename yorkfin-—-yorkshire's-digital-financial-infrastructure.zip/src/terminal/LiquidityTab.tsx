import React, { useState } from 'react';
import { LIQUIDITY_POOLS, LiquidityPool } from '../data/mockData';
import { Layers, Activity, ArrowRight, PlusCircle } from 'lucide-react';

export const LiquidityTab: React.FC = () => {
  const [selectedPool, setSelectedPool] = useState<LiquidityPool | null>(null);

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-wider block">YORKFIN LIQUIDITY ARCHITECTURE</span>
          <h2 className="text-2xl font-bold font-mono text-slate-100">
            LIQUIDITY IS INFRASTRUCTURE.
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Concentrated liquidity pools providing instant execution for corporate loans and tokenised security trades.
          </p>
        </div>

        <div className="px-3 py-1.5 rounded bg-[#141b27] border border-[#232c3d] text-xs font-mono text-[#c5a059]">
          INSTITUTIONAL DEPT H
        </div>
      </div>

      {/* Top Liquidity Stats Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono">
        <div className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 uppercase">TOTAL LIQUIDITY</span>
          <div className="text-2xl font-bold text-slate-100">£842.19m</div>
          <span className="text-[10px] text-slate-500">Across 5 Primary Pools</span>
        </div>

        <div className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 uppercase">AVAILABLE LIQUIDITY</span>
          <div className="text-2xl font-bold text-emerald-400">£614.82m</div>
          <span className="text-[10px] text-slate-500">73.0% Unencumbered Depth</span>
        </div>

        <div className="bg-[#0f1420] stone-border p-4 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 uppercase">UTILISED LIQUIDITY</span>
          <div className="text-2xl font-bold text-[#c5a059]">£227.37m</div>
          <span className="text-[10px] text-slate-500">27.0% Borrowed / Pledged</span>
        </div>
      </div>

      {/* Liquidity Pools Table */}
      <div className="bg-[#0f1420] stone-border rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#1d2636] font-mono">
          <div>
            <span className="text-[10px] text-[#c5a059] uppercase">Pool Register</span>
            <h3 className="text-base font-bold text-slate-100">Institutional Money Pools</h3>
          </div>
          <span className="text-xs text-slate-400">5 ACTIVE POOLS</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-[#1c2433] text-[10px] uppercase">
                <th className="pb-3 font-semibold">POOL PAIR</th>
                <th className="pb-3 font-semibold text-right">TVL (£)</th>
                <th className="pb-3 font-semibold text-right">UTILISATION</th>
                <th className="pb-3 font-semibold text-right">BORROW RATE</th>
                <th className="pb-3 font-semibold text-right">SUPPLY RATE</th>
                <th className="pb-3 font-semibold text-right">24H DEPTH</th>
                <th className="pb-3 font-semibold text-center">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#171e2b]">
              {LIQUIDITY_POOLS.map((pool) => (
                <tr key={pool.id} className="hover:bg-[#141b27] transition-colors">
                  <td className="py-3.5 font-bold text-slate-100">
                    {pool.pair}
                    <span className="block text-[10px] font-normal text-slate-500">Fee Tier: {pool.feeTier}</span>
                  </td>
                  <td className="py-3.5 text-right font-bold text-slate-200">
                    £{(pool.tvl / 1000000).toFixed(1)}m
                  </td>
                  <td className="py-3.5 text-right text-slate-300">
                    {pool.utilisationRate}%
                  </td>
                  <td className="py-3.5 text-right text-emerald-400 font-bold">
                    {pool.borrowRate}% p.a.
                  </td>
                  <td className="py-3.5 text-right text-[#c5a059] font-bold">
                    {pool.supplyRate}% p.a.
                  </td>
                  <td className="py-3.5 text-right text-slate-400">
                    £{(pool.depth24h / 1000000).toFixed(1)}m
                  </td>
                  <td className="py-3.5 text-center">
                    <button
                      onClick={() => setSelectedPool(pool)}
                      className="px-2.5 py-1 rounded bg-[#1b2434] hover:bg-[#c5a059] hover:text-[#0a0d14] text-slate-200 text-[10px] font-bold transition-colors border border-[#232d40]"
                    >
                      MANAGE POOL
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pool Detail Modal */}
      {selectedPool && (
        <div className="fixed inset-0 z-50 bg-[#000]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0f1420] stone-border rounded-xl max-w-lg w-full p-6 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2433]">
              <div>
                <span className="text-[10px] text-[#c5a059] uppercase">Pool Detail</span>
                <h3 className="text-lg font-bold text-slate-100">{selectedPool.pair}</h3>
              </div>
              <button
                onClick={() => setSelectedPool(null)}
                className="text-slate-400 hover:text-slate-100 text-sm"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400 text-[10px] block">TOTAL VALUE LOCKED</span>
                <span className="text-slate-100 font-bold text-sm">£{(selectedPool.tvl / 1000000).toFixed(1)}M</span>
              </div>
              <div className="p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400 text-[10px] block">UTILISATION</span>
                <span className="text-[#c5a059] font-bold text-sm">{selectedPool.utilisationRate}%</span>
              </div>
              <div className="p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400 text-[10px] block">SUPPLY RATE (APY)</span>
                <span className="text-emerald-400 font-bold text-sm">{selectedPool.supplyRate}%</span>
              </div>
              <div className="p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400 text-[10px] block">MY CONTRIBUTION</span>
                <span className="text-slate-200 font-bold text-sm">£{(selectedPool.myContribution / 1000000).toFixed(1)}M</span>
              </div>
            </div>

            <button
              onClick={() => {
                alert(`Added £1,000,000 Liquidity to ${selectedPool.pair} (Simulated)`);
                setSelectedPool(null);
              }}
              className="w-full py-2.5 rounded bg-[#c5a059] text-[#0a0d14] font-bold text-xs hover:bg-[#d4af37] transition-colors"
            >
              PROVIDE LIQUIDITY (DEMO)
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
