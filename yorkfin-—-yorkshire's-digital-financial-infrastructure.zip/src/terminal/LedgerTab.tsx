import React, { useState, useEffect } from 'react';
import { LEDGER_TRANSACTIONS, LedgerTransaction } from '../data/mockData';
import { Search, ShieldCheck, RefreshCw, CheckCircle2, ArrowUpRight, Lock } from 'lucide-react';

export const LedgerTab: React.FC = () => {
  const [txs, setTxs] = useState<LedgerTransaction[]>(LEDGER_TRANSACTIONS);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTx, setSelectedTx] = useState<LedgerTransaction | null>(null);
  const [liveStream, setLiveStream] = useState(true);

  // Simulate live incoming block & transaction feed
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (liveStream) {
      timer = setInterval(() => {
        const newBlock = (txs[0]?.block || 4892014) + 1;
        const randomValues = [500000, 1200000, 2500000, 10000000, 35000000];
        const newTx: LedgerTransaction = {
          block: newBlock,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
          txHash: `0x${Math.random().toString(16).substring(2, 10)}...${Math.random().toString(16).substring(2, 6)}`,
          from: 'Leeds Financial Quarter Node (0x84...19A)',
          to: 'Yorkshire Gilt Custody Escrow (0x01...GILT)',
          asset: Math.random() > 0.5 ? 'YF-GILT-2031' : 'GBP STABLECOIN (YF-GBP)',
          value: randomValues[Math.floor(Math.random() * randomValues.length)],
          status: 'SETTLED',
          gasFee: '0.00034 GBP',
          smartContract: 'YF-SETTLEMENT',
          settlementState: 'FINALITY_ACHIEVED'
        };
        setTxs((prev) => [newTx, ...prev.slice(0, 15)]);
      }, 3500);
    }
    return () => clearInterval(timer);
  }, [liveStream, txs]);

  const filteredTxs = txs.filter((t) => 
    t.txHash.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.to.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.asset.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#0f1420] stone-border p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-wider block">YORKFIN LEDGER</span>
          <h2 className="text-2xl font-bold font-mono text-slate-100">
            TRANSACTION EXPLORER & ON-CHAIN STATE
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time immutable ledger records for institutional settlement, collateral movements and digital Sterling payments.
          </p>
        </div>

        <button
          onClick={() => setLiveStream(!liveStream)}
          className="px-3.5 py-2 rounded bg-[#141b27] border border-[#232c3d] text-xs font-mono text-slate-200 hover:border-[#c5a059] flex items-center gap-2 shrink-0 transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-[#c5a059] ${liveStream ? 'animate-spin' : ''}`} />
          <span>{liveStream ? 'LIVE NETWORK STREAM' : 'PAUSED STREAM'}</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-[#0f1420] stone-border p-4 rounded-xl flex items-center gap-3">
        <Search className="w-4 h-4 text-slate-400" />
        <input
          type="text"
          placeholder="Search by Tx hash, block number, counterparty or asset..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-transparent text-xs font-mono text-slate-200 placeholder-slate-500 outline-none"
        />
      </div>

      {/* Ledger Table */}
      <div className="bg-[#0f1420] stone-border rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#1d2636] font-mono">
          <span className="text-xs font-bold text-slate-200">ON-CHAIN LEDGER BLOCKS</span>
          <span className="text-[10px] text-[#c5a059]">TESTNET SIMULATION DATA</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-[#1c2433] text-[10px] uppercase">
                <th className="pb-3 font-semibold">BLOCK</th>
                <th className="pb-3 font-semibold">TIMESTAMP</th>
                <th className="pb-3 font-semibold">TX HASH</th>
                <th className="pb-3 font-semibold">FROM / TO</th>
                <th className="pb-3 font-semibold">ASSET</th>
                <th className="pb-3 font-semibold text-right">VALUE (£)</th>
                <th className="pb-3 font-semibold text-center">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#171e2b]">
              {filteredTxs.map((tx) => (
                <tr
                  key={tx.txHash}
                  onClick={() => setSelectedTx(tx)}
                  className="hover:bg-[#141b27] transition-colors cursor-pointer"
                >
                  <td className="py-3.5 font-bold text-[#c5a059]">
                    #{tx.block}
                  </td>
                  <td className="py-3.5 text-slate-400 text-[11px]">
                    {tx.timestamp}
                  </td>
                  <td className="py-3.5 text-slate-300 font-semibold">
                    {tx.txHash}
                  </td>
                  <td className="py-3.5 text-slate-400 text-[11px] max-w-xs truncate">
                    <div>{tx.from}</div>
                    <div className="text-slate-500">→ {tx.to}</div>
                  </td>
                  <td className="py-3.5 text-slate-200 font-semibold">
                    {tx.asset}
                  </td>
                  <td className="py-3.5 text-right font-bold text-slate-100">
                    £{tx.value.toLocaleString()}
                  </td>
                  <td className="py-3.5 text-center">
                    <span className="px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 text-[10px] font-bold">
                      {tx.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction Details Modal */}
      {selectedTx && (
        <div className="fixed inset-0 z-50 bg-[#000]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0f1420] stone-border rounded-xl max-w-lg w-full p-6 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2433]">
              <div>
                <span className="text-[10px] text-[#c5a059] uppercase">TRANSACTION DETAIL</span>
                <h3 className="text-sm font-bold text-slate-100">{selectedTx.txHash}</h3>
              </div>
              <button onClick={() => setSelectedTx(null)} className="text-slate-400 hover:text-slate-100 text-sm">
                ✕
              </button>
            </div>

            <div className="space-y-2.5">
              <div className="flex justify-between p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400">BLOCK NUMBER:</span>
                <span className="text-[#c5a059] font-bold">#{selectedTx.block}</span>
              </div>
              <div className="flex justify-between p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400">TIMESTAMP:</span>
                <span className="text-slate-200">{selectedTx.timestamp}</span>
              </div>
              <div className="flex justify-between p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400">SENDER:</span>
                <span className="text-slate-200 text-[11px] truncate max-w-[200px]">{selectedTx.from}</span>
              </div>
              <div className="flex justify-between p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400">RECIPIENT:</span>
                <span className="text-slate-200 text-[11px] truncate max-w-[200px]">{selectedTx.to}</span>
              </div>
              <div className="flex justify-between p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400">ASSET & AMOUNT:</span>
                <span className="text-slate-100 font-bold">{selectedTx.asset} (£{selectedTx.value.toLocaleString()})</span>
              </div>
              <div className="flex justify-between p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400">GAS FEE:</span>
                <span className="text-slate-300">{selectedTx.gasFee}</span>
              </div>
              <div className="flex justify-between p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400">SMART CONTRACT:</span>
                <span className="text-[#c5a059] font-bold">{selectedTx.smartContract}</span>
              </div>
              <div className="flex justify-between p-2.5 bg-[#141a26] rounded">
                <span className="text-slate-400">SETTLEMENT STATE:</span>
                <span className="text-emerald-400 font-bold">{selectedTx.settlementState}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedTx(null)}
              className="w-full py-2.5 rounded bg-[#c5a059] text-[#0a0d14] font-bold text-xs"
            >
              Close Ledger Details
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
