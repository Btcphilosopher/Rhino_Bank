import React from 'react';
import { Shield, ArrowUpRight, Terminal as TerminalIcon } from 'lucide-react';

interface TopBarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  onOpenTerminal: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ currentView, setCurrentView, onOpenTerminal }) => {
  return (
    <header className="sticky top-0 z-50 bg-[#0a0d14]/90 backdrop-blur-md border-b border-[#212936] px-4 md:px-8 py-3.5 flex items-center justify-between">
      {/* Zone 1: Brand Wordmark (Single element) */}
      <div 
        onClick={() => setCurrentView('landing')}
        className="cursor-pointer group flex items-center gap-2.5"
      >
        <div className="w-8 h-8 rounded bg-gradient-to-br from-[#c5a059] to-[#8c6b2d] flex items-center justify-center font-serif text-[#0a0d14] font-bold text-lg shadow-sm">
          Y
        </div>
        <div className="flex flex-col">
          <span className="text-base md:text-lg font-bold tracking-tight text-slate-100 group-hover:text-[#c5a059] transition-colors">
            YORKFIN
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden lg:flex items-center gap-7 text-xs font-medium tracking-wide uppercase text-slate-400">
        <button
          onClick={() => setCurrentView('landing')}
          className={`hover:text-slate-100 transition-colors ${currentView === 'landing' ? 'text-[#c5a059] font-semibold border-b border-[#c5a059] pb-0.5' : ''}`}
        >
          Infrastructure
        </button>
        <button
          onClick={onOpenTerminal}
          className={`hover:text-slate-100 transition-colors ${currentView === 'terminal' ? 'text-[#c5a059] font-semibold border-b border-[#c5a059] pb-0.5' : ''}`}
        >
          Terminal
        </button>
        <button
          onClick={() => setCurrentView('research')}
          className={`hover:text-slate-100 transition-colors ${currentView === 'research' ? 'text-[#c5a059] font-semibold border-b border-[#c5a059] pb-0.5' : ''}`}
        >
          Research
        </button>
        <button
          onClick={() => setCurrentView('risk')}
          className={`hover:text-slate-100 transition-colors ${currentView === 'risk' ? 'text-[#c5a059] font-semibold border-b border-[#c5a059] pb-0.5' : ''}`}
        >
          Risk Centre
        </button>
        <button
          onClick={() => setCurrentView('services')}
          className={`hover:text-slate-100 transition-colors ${currentView === 'services' ? 'text-[#c5a059] font-semibold border-b border-[#c5a059] pb-0.5' : ''}`}
        >
          Services
        </button>
        <button
          onClick={() => setCurrentView('why-leeds')}
          className={`hover:text-slate-100 transition-colors ${currentView === 'why-leeds' ? 'text-[#c5a059] font-semibold border-b border-[#c5a059] pb-0.5' : ''}`}
        >
          Why Leeds
        </button>
      </nav>

      {/* Zone 3: Actions */}
      <div className="flex items-center gap-3">
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#141a24] border border-[#232d3d] text-[11px] font-mono text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>LEEDS NODE · OPERATIONAL</span>
        </div>

        <button
          onClick={onOpenTerminal}
          className="px-4 py-2 rounded text-xs font-semibold tracking-wider text-[#0a0d14] bg-[#c5a059] hover:bg-[#d4af37] transition-all flex items-center gap-2 shadow-sm whitespace-nowrap"
        >
          <TerminalIcon className="w-3.5 h-3.5" />
          <span>ENTER TERMINAL</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
