import React, { useState } from 'react';
import { Key, Code2, ShieldAlert, Cpu, ArrowUpRight, Scale, Eye, Layers } from 'lucide-react';

const DEFI_CONCEPTS = [
  {
    icon: Key,
    title: 'SELF-CUSTODY',
    desc: 'Assets can be controlled through cryptographic keys rather than third-party proxy accounts.',
    detail: 'Institutional treasuries retain direct cryptographic signature control over asset reserves without counterparty commingling.'
  },
  {
    icon: Code2,
    title: 'SMART CONTRACTS',
    desc: 'Financial rules can be implemented directly in deterministic, verifiable software.',
    detail: 'Automated execution removes manual back-office paper reconciliation and eliminates settlement delays.'
  },
  {
    icon: ShieldAlert,
    title: 'COLLATERAL',
    desc: 'Loans can be secured programmatically with real-time health-factor monitoring.',
    detail: 'Secured credit lines enforce dynamic collateral thresholds, mitigating unbacked credit default contagion.'
  },
  {
    icon: Cpu,
    title: 'SETTLEMENT',
    desc: 'Transactions can be recorded on shared institutional ledger infrastructure.',
    detail: 'Atomic Delivery vs Payment (DvP) ensures that transfer of cash and security occurs simultaneously or not at all.'
  },
  {
    icon: Eye,
    title: 'TRANSPARENCY',
    desc: 'Relevant transaction and contract information can be independently inspected where architecture permits.',
    detail: 'Cryptographic proof-of-reserve oracles allow continuous solvency verification without revealing private trade identities.'
  },
  {
    icon: Layers,
    title: 'COMPOSABILITY',
    desc: 'Financial applications can interact seamlessly through standardized programmable interfaces.',
    detail: 'Modular integration between credit facilities, gilt holdings, and liquidity pools creates friction-free treasury workflows.'
  }
];

const RISKS = [
  { name: 'Smart-Contract Risk', desc: 'Software logic defects or unforeseen execution paths in smart contract bytecode.' },
  { name: 'Oracle Risk', desc: 'Price feed latency or inaccurate valuation inputs during high market volatility.' },
  { name: 'Liquidity Risk', desc: 'Temporary imbalance in pool depth during sudden market stress events.' },
  { name: 'Market Risk', desc: 'Fluctuations in underlying asset collateral values impacting loan-to-value ratios.' },
  { name: 'Counterparty Risk', desc: 'Risk associated with institutional issuers or underlying asset default.' },
  { name: 'Custody / Key Management Risk', desc: 'Compromise or loss of institutional multi-signature private keys.' },
  { name: 'Regulatory Risk', desc: 'Evolution in digital asset legal frameworks and cross-border compliance standards.' }
];

export const DeFiExplainer: React.FC = () => {
  const [selectedConcept, setSelectedConcept] = useState<number | null>(null);

  return (
    <section className="py-12 bg-[#0a0d14] border-t border-[#1a212d] px-4 md:px-8">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block">
            DECENTRALIZED FINANCE FOR INSTITUTIONS
          </span>
          <h2 className="text-2xl md:text-3xl font-bold text-slate-100">
            WHAT IS DEFI?
          </h2>
          <p className="text-xs md:text-sm text-slate-400 leading-relaxed">
            A serious look at programmable financial architecture. YORKFIN applies decentralised financial mechanics to traditional Sterling banking and corporate asset management.
          </p>
        </div>

        {/* 6 Concept Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {DEFI_CONCEPTS.map((c, idx) => {
            const Icon = c.icon;
            const isExpanded = selectedConcept === idx;

            return (
              <div
                key={c.title}
                onClick={() => setSelectedConcept(isExpanded ? null : idx)}
                className={`p-5 rounded-xl border transition-all cursor-pointer ${
                  isExpanded 
                    ? 'bg-[#141b27] border-[#c5a059] shadow-lg shadow-[#c5a059]/5' 
                    : 'bg-[#0f141f] border-[#1f2838] hover:border-[#313f56]'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="w-9 h-9 rounded bg-[#182130] border border-[#27354a] flex items-center justify-center text-[#c5a059]">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-mono text-[#c5a059] uppercase">
                    MODULE 0{idx + 1}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-100 mb-2 font-mono">
                  {c.title}
                </h3>
                
                <p className="text-xs text-slate-300 leading-relaxed mb-3">
                  {c.desc}
                </p>

                <div className="text-[11px] text-slate-400 pt-2 border-t border-[#1c2534] flex items-center justify-between">
                  <span>{isExpanded ? 'Hide Architecture Detail' : 'Inspect Detail'}</span>
                  <ArrowUpRight className={`w-3.5 h-3.5 text-[#c5a059] transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                </div>

                {isExpanded && (
                  <p className="mt-3 p-3 rounded bg-[#090d14] border border-[#1b2332] text-xs text-[#c5a059] leading-relaxed">
                    {c.detail}
                  </p>
                )}
              </div>
            );
          })}
        </div>

        {/* Explicit Risk Centre Disclosures */}
        <div className="bg-[#0f1420] border border-[#1d2737] rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2.5 text-[#a33b3b] font-mono text-xs uppercase tracking-wider font-bold">
            <Scale className="w-4 h-4" />
            <span>EXPLICIT RISK DISCLOSURES — PLATFORM TRANSPARENCY</span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Programmable financial infrastructure provides significant speed and operational efficiency, but introduces specific technological and market risks that institutions must understand.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            {RISKS.map((r) => (
              <div key={r.name} className="p-3 rounded bg-[#0a0d14] border border-[#1a2232]">
                <h4 className="text-xs font-bold text-slate-200 mb-1 font-mono">{r.name}</h4>
                <p className="text-[11px] text-slate-400 leading-snug">{r.desc}</p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
