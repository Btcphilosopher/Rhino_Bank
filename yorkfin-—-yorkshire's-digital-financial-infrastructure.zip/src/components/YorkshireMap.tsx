import React, { useState } from 'react';
import { YORKSHIRE_NODES } from '../data/mockData';
import { Activity, Radio, Cpu, CheckCircle2 } from 'lucide-react';

export const YorkshireMap: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState(YORKSHIRE_NODES[0]);

  return (
    <div className="bg-[#0e131d] stone-border rounded-xl p-6 relative overflow-hidden">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 pb-4 border-b border-[#1c2433] gap-4">
        <div>
          <div className="text-[11px] font-mono text-[#c5a059] uppercase tracking-widest mb-1 flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 animate-pulse text-[#c5a059]" />
            YORKFIN DEMONSTRATION NETWORK
          </div>
          <h3 className="text-xl font-bold text-slate-100">Yorkshire Regional Settlement Grid</h3>
        </div>
        <div className="flex items-center gap-3 font-mono text-xs text-slate-400 bg-[#131a26] px-3.5 py-1.5 rounded border border-[#212c3e]">
          <span>STATUS: OPERATIONAL</span>
          <span className="text-slate-600">|</span>
          <span className="text-emerald-400 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> 8/8 NODES SYNCED
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
        
        {/* Interactive SVG Map Visual */}
        <div className="lg:col-span-2 relative min-h-[380px] bg-[#090c12] rounded-lg border border-[#1b2332] p-4 flex items-center justify-center overflow-hidden">
          
          {/* Subtle Grid Background */}
          <div className="absolute inset-0 bg-[radial-gradient(#1c2638_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>

          {/* Map Container */}
          <svg className="w-full h-[340px] relative z-10" viewBox="0 0 100 100">
            {/* Connection Lines between nodes */}
            {YORKSHIRE_NODES.map((node, i) => {
              const leeds = YORKSHIRE_NODES[0];
              return (
                <g key={`line-${i}`}>
                  <line
                    x1={leeds.x}
                    y1={leeds.y}
                    x2={node.x}
                    y2={node.y}
                    stroke={selectedNode.name === node.name ? "#c5a059" : "#1f2a3c"}
                    strokeWidth={selectedNode.name === node.name ? "1.2" : "0.6"}
                    strokeDasharray="2,2"
                  />
                  {/* Animated data pulses */}
                  <circle
                    cx={(leeds.x + node.x) / 2}
                    cy={(leeds.y + node.y) / 2}
                    r="0.8"
                    fill="#c5a059"
                  >
                    <animate
                      attributeName="opacity"
                      values="0.2;1;0.2"
                      dur={`${1.5 + i * 0.3}s`}
                      repeatCount="indefinite"
                    />
                  </circle>
                </g>
              );
            })}

            {/* Nodes */}
            {YORKSHIRE_NODES.map((node) => {
              const isSelected = selectedNode.name === node.name;
              return (
                <g 
                  key={node.name} 
                  className="cursor-pointer group"
                  onClick={() => setSelectedNode(node)}
                >
                  {/* Outer Pulsing Glow for selected */}
                  {isSelected && (
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r="5"
                      fill="none"
                      stroke="#c5a059"
                      strokeWidth="0.5"
                      opacity="0.6"
                    >
                      <animate
                        attributeName="r"
                        values="3;8;3"
                        dur="2.5s"
                        repeatCount="indefinite"
                      />
                    </circle>
                  )}

                  {/* Main Node Dot */}
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={isSelected ? "2.5" : "1.8"}
                    fill={isSelected ? "#c5a059" : node.role.includes('Primary') ? "#60a5fa" : "#94a3b8"}
                    stroke="#090c12"
                    strokeWidth="0.5"
                    className="transition-all"
                  />

                  {/* Node Label */}
                  <text
                    x={node.x}
                    y={node.y - 3.5}
                    textAnchor="middle"
                    fill={isSelected ? "#f8fafc" : "#94a3b8"}
                    fontSize="3"
                    fontWeight={isSelected ? "700" : "500"}
                    fontFamily="monospace"
                  >
                    {node.name}
                  </text>
                </g>
              );
            })}
          </svg>

          <div className="absolute bottom-3 left-3 text-[10px] font-mono text-slate-500 bg-[#0c1018]/80 px-2.5 py-1 rounded border border-[#1b2332]">
            LATITUDE 53.7997° N · LONGITUDE 1.5492° W (LEEDS HQ)
          </div>
        </div>

        {/* Node Detail Card */}
        <div className="bg-[#111724] border border-[#212b3e] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1c2536]">
            <div>
              <span className="text-[10px] font-mono text-[#c5a059] uppercase">Node Details</span>
              <h4 className="text-lg font-bold text-slate-100">{selectedNode.name}</h4>
            </div>
            <span className="px-2.5 py-1 rounded bg-[#1a2333] border border-[#2c3a52] text-[10px] font-mono text-emerald-400">
              {selectedNode.status}
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            {selectedNode.role}
          </p>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-2.5 rounded bg-[#0b0e16] border border-[#1d2738]">
              <span className="text-[10px] font-mono text-slate-400 block mb-0.5">Throughput</span>
              <span className="text-sm font-bold font-mono text-slate-100">{selectedNode.txSec}</span>
            </div>
            <div className="p-2.5 rounded bg-[#0b0e16] border border-[#1d2738]">
              <span className="text-[10px] font-mono text-slate-400 block mb-0.5">Latency</span>
              <span className="text-sm font-bold font-mono text-emerald-400">{selectedNode.ping}</span>
            </div>
          </div>

          <div className="p-3 rounded bg-[#0c1018] border border-[#1b2332] text-[11px] font-mono text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>Cryptographic Proof:</span>
              <span className="text-slate-200">VALIDATED</span>
            </div>
            <div className="flex justify-between">
              <span>Consensus Group:</span>
              <span className="text-slate-200">YORKSHIRE-CORE-01</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
