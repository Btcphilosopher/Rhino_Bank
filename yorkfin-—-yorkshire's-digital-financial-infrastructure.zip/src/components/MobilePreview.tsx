import React, { useState } from 'react';
import { Shield, Fingerprint, ArrowUpRight, ArrowDownLeft, RefreshCw, Briefcase, Landmark, Check, Lock } from 'lucide-react';

export const MobilePreview: React.FC = () => {
  const [activeTab, setActiveTab] = useState('HOME');
  const [authenticated, setAuthenticated] = useState(true);
  const [balance, setBalance] = useState(1284210);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const handleAction = (actionName: string) => {
    setActionNotice(`Initiated ${actionName} flow in mobile preview (Simulated)`);
    setTimeout(() => setActionNotice(null), 3000);
  };

  return (
    <div className="flex flex-col items-center justify-center py-6">
      <div className="text-center max-w-xl mx-auto mb-6 space-y-2">
        <span className="text-xs font-mono text-[#c5a059] uppercase tracking-widest block">
          INSTITUTIONAL MOBILE INTERFACE
        </span>
        <h3 className="text-2xl font-bold text-slate-100">YORKFIN Mobile Banking App</h3>
        <p className="text-xs text-slate-400">
          Compact, biometric-secured mobile access for corporate treasurers and institutional executives.
        </p>
      </div>

      {/* Phone Frame */}
      <div className="w-[320px] h-[620px] bg-[#000000] rounded-[42px] p-3 border-4 border-[#222b3c] shadow-2xl relative overflow-hidden flex flex-col justify-between">
        
        {/* Dynamic Notch / Island */}
        <div className="w-28 h-4 bg-[#141a24] rounded-full mx-auto mb-2 flex items-center justify-center shrink-0">
          <div className="w-2.5 h-2.5 rounded-full bg-[#0a0d14] mr-2"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-[#38455e]"></div>
        </div>

        {/* Action Notice Overlay */}
        {actionNotice && (
          <div className="absolute top-12 left-4 right-4 z-50 bg-[#c5a059] text-[#0a0d14] text-[10px] font-mono p-2 rounded text-center font-bold shadow-lg">
            {actionNotice}
          </div>
        )}

        {/* Screen Content */}
        <div className="flex-1 bg-[#0b0e16] rounded-[30px] p-4 flex flex-col justify-between overflow-y-auto border border-[#1b2332]">
          
          {!authenticated ? (
            /* Biometric Auth Lock Screen */
            <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-[#161d2b] border border-[#232e42] flex items-center justify-center text-[#c5a059]">
                <Fingerprint className="w-8 h-8 animate-pulse" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-100">YORKFIN Mobile</h4>
                <p className="text-[10px] text-slate-400 font-mono mt-1">Biometric Authentication Required</p>
              </div>
              <button
                onClick={() => setAuthenticated(true)}
                className="px-4 py-2 rounded bg-[#c5a059] text-[#0a0d14] font-mono text-xs font-bold"
              >
                Authenticate FaceID / Key
              </button>
            </div>
          ) : (
            /* Authenticated App View */
            <div className="space-y-4">
              
              {/* Header Bar */}
              <div className="flex items-center justify-between pb-2 border-b border-[#1c2434]">
                <div className="flex items-center gap-1.5">
                  <div className="w-5 h-5 rounded bg-[#c5a059] text-[#0a0d14] font-serif font-bold text-[10px] flex items-center justify-center">
                    Y
                  </div>
                  <span className="text-xs font-bold tracking-tight text-slate-100 font-mono">YORKFIN</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/40">
                    LEEDS SECURE
                  </span>
                  <button onClick={() => setAuthenticated(false)} className="text-slate-500 hover:text-slate-300">
                    <Lock className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Main Balance Display */}
              <div className="bg-gradient-to-br from-[#121824] to-[#0e131d] p-4 rounded-xl border border-[#212b3d] text-center space-y-1">
                <span className="text-[10px] font-mono text-slate-400 tracking-wider">TOTAL BALANCE</span>
                <div className="text-2xl font-bold font-mono text-slate-100">
                  £{balance.toLocaleString()}
                </div>
                <div className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded">
                  <span>+1.82%</span>
                  <span className="text-slate-400">TODAY</span>
                </div>
              </div>

              {/* Quick Action Buttons Grid */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => handleAction('SEND')}
                  className="p-2.5 rounded-lg bg-[#141a26] border border-[#212a3d] hover:border-[#c5a059] flex flex-col items-center gap-1 transition-colors"
                >
                  <ArrowUpRight className="w-4 h-4 text-[#c5a059]" />
                  <span className="text-[9px] font-mono text-slate-200">SEND</span>
                </button>

                <button
                  onClick={() => handleAction('RECEIVE')}
                  className="p-2.5 rounded-lg bg-[#141a26] border border-[#212a3d] hover:border-[#c5a059] flex flex-col items-center gap-1 transition-colors"
                >
                  <ArrowDownLeft className="w-4 h-4 text-[#c5a059]" />
                  <span className="text-[9px] font-mono text-slate-200">RECEIVE</span>
                </button>

                <button
                  onClick={() => handleAction('TRADE')}
                  className="p-2.5 rounded-lg bg-[#141a26] border border-[#212a3d] hover:border-[#c5a059] flex flex-col items-center gap-1 transition-colors"
                >
                  <RefreshCw className="w-4 h-4 text-[#c5a059]" />
                  <span className="text-[9px] font-mono text-slate-200">TRADE</span>
                </button>

                <button
                  onClick={() => handleAction('TREASURY')}
                  className="p-2.5 rounded-lg bg-[#141a26] border border-[#212a3d] hover:border-[#c5a059] flex flex-col items-center gap-1 transition-colors"
                >
                  <Briefcase className="w-4 h-4 text-[#c5a059]" />
                  <span className="text-[9px] font-mono text-slate-200">TREASURY</span>
                </button>

                <button
                  onClick={() => handleAction('CREDIT')}
                  className="p-2.5 rounded-lg bg-[#141a26] border border-[#212a3d] hover:border-[#c5a059] flex flex-col items-center gap-1 transition-colors col-span-2"
                >
                  <Landmark className="w-4 h-4 text-[#c5a059]" />
                  <span className="text-[9px] font-mono text-slate-200">CREDIT & COLLATERAL</span>
                </button>
              </div>

              {/* Recent Activity List */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Recent Activity</span>
                
                <div className="p-2 rounded bg-[#101520] border border-[#1b2332] flex items-center justify-between text-[10px]">
                  <div>
                    <span className="text-slate-200 font-medium block">YF-GILT Coupon</span>
                    <span className="text-slate-500 font-mono">11:42 AM</span>
                  </div>
                  <span className="text-emerald-400 font-mono font-bold">+£12,450.00</span>
                </div>

                <div className="p-2 rounded bg-[#101520] border border-[#1b2332] flex items-center justify-between text-[10px]">
                  <div>
                    <span className="text-slate-200 font-medium block">Collateral Pledge</span>
                    <span className="text-slate-500 font-mono">Yesterday</span>
                  </div>
                  <span className="text-slate-400 font-mono font-bold">£250,000</span>
                </div>
              </div>

            </div>
          )}

          {/* Bottom Navigation */}
          <div className="pt-2 border-t border-[#1c2434] grid grid-cols-5 gap-1 text-[8px] font-mono text-center text-slate-400">
            {['HOME', 'MARKETS', 'ASSETS', 'ACTIVITY', 'ACCOUNT'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-1 transition-colors ${
                  activeTab === tab ? 'text-[#c5a059] font-bold border-t-2 border-[#c5a059] -mt-2 pt-1' : 'hover:text-slate-200'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

        </div>

        {/* Home Indicator bar */}
        <div className="w-24 h-1 bg-[#232d3e] rounded-full mx-auto mt-2"></div>
      </div>
    </div>
  );
};
