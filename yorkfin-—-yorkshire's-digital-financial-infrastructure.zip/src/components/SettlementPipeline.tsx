import React, { useState, useEffect } from 'react';
import { Play, Check, ShieldCheck, ArrowRight, RefreshCw, Zap } from 'lucide-react';

const STEPS = [
  { id: 'ORDER', name: '01. ORDER', desc: 'Instruction created' },
  { id: 'AUTHORISE', name: '02. AUTHORISE', desc: 'Policy & limit check' },
  { id: 'SIGN', name: '03. SIGN', desc: 'Multi-sig cryptographic signature' },
  { id: 'VALIDATE', name: '04. VALIDATE', desc: 'Zero-knowledge proof verification' },
  { id: 'SETTLE', name: '05. SETTLE', desc: 'Atomic Delivery vs Payment' },
  { id: 'RECORD', name: '06. RECORD', desc: 'On-chain ledger finality' }
];

export const SettlementPipeline: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [isRunning, setIsRunning] = useState(true);
  const [txCount, setTxCount] = useState(14208);
  const [settlementTime, setSettlementTime] = useState('2.8');

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning) {
      interval = setInterval(() => {
        setActiveStep((prev) => {
          if (prev >= STEPS.length - 1) {
            setTxCount((c) => c + 1);
            setSettlementTime((2.4 + Math.random() * 0.8).toFixed(1));
            return 0;
          }
          return prev + 1;
        });
      }, 900);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  return (
    <div className="bg-[#0e131d] stone-border rounded-xl p-6 relative">
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1c2433] mb-6 gap-4">
        <div>
          <span className="text-[11px] font-mono text-[#c5a059] uppercase tracking-widest block mb-1">
            PROGRAMMABLE SETTLEMENT ENGINE
          </span>
          <h3 className="text-xl font-bold text-slate-100">Atomic DvP Settlement Pipeline</h3>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className="px-3 py-1.5 rounded bg-[#161e2c] border border-[#243044] hover:bg-[#1d273a] text-xs font-mono text-slate-200 flex items-center gap-2 transition-colors"
          >
            {isRunning ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#c5a059]" />
                <span>Simulating Live Stream</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 text-emerald-400" />
                <span>Resume Simulation</span>
              </>
            )}
          </button>

          <div className="text-right font-mono text-xs text-slate-400">
            <span className="block text-[10px] text-slate-500">SIMULATED SETTLEMENT TIME</span>
            <span className="text-emerald-400 font-bold">{settlementTime} sec</span>
          </div>
        </div>
      </div>

      {/* Pipeline Visual Steps */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {STEPS.map((step, idx) => {
          const isDone = idx < activeStep;
          const isCurrent = idx === activeStep;

          return (
            <div
              key={step.id}
              className={`p-3.5 rounded-lg border transition-all relative ${
                isCurrent
                  ? 'bg-[#182130] border-[#c5a059] shadow-md shadow-[#c5a059]/10'
                  : isDone
                  ? 'bg-[#0f1522] border-[#223046] text-slate-300'
                  : 'bg-[#0a0d14] border-[#161c28] text-slate-500'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-mono font-bold ${isCurrent ? 'text-[#c5a059]' : 'text-slate-400'}`}>
                  {step.name}
                </span>
                {isDone && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                {isCurrent && <Zap className="w-3.5 h-3.5 text-[#c5a059] animate-pulse" />}
              </div>

              <p className="text-[11px] text-slate-300 font-sans leading-tight">
                {step.desc}
              </p>

              {/* Step indicator bar */}
              <div className="w-full h-1 bg-[#151c2a] rounded-full mt-3 overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    isDone || isCurrent ? 'bg-[#c5a059]' : 'bg-transparent'
                  }`}
                  style={{ width: isDone ? '100%' : isCurrent ? '60%' : '0%' }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Settlement Metrics Footer Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-[#0a0d14] p-3.5 rounded-lg border border-[#1a2232] text-xs font-mono">
        <div>
          <span className="text-slate-500 text-[10px] block">VALIDATION</span>
          <span className="text-emerald-400 font-semibold flex items-center gap-1 mt-0.5">
            <ShieldCheck className="w-3.5 h-3.5" /> COMPLETE (DEMO)
          </span>
        </div>
        <div>
          <span className="text-slate-500 text-[10px] block">FINALITY</span>
          <span className="text-slate-200 font-semibold mt-0.5 block">CONFIRMED (T+0)</span>
        </div>
        <div>
          <span className="text-slate-500 text-[10px] block">SETTLED IN VOCABULARY</span>
          <span className="text-[#c5a059] font-semibold mt-0.5 block">ATOMIC DVP</span>
        </div>
        <div>
          <span className="text-slate-500 text-[10px] block">TOTAL DEMO TX COUNTER</span>
          <span className="text-slate-200 font-semibold mt-0.5 block">#{txCount.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
};
