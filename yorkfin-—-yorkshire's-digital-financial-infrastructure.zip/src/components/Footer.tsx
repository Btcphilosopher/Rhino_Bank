import React from 'react';
import { ShieldAlert, Globe, MapPin } from 'lucide-react';

interface FooterProps {
  setCurrentView: (view: string) => void;
  onOpenTerminal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentView, onOpenTerminal }) => {
  return (
    <footer className="bg-[#080a0f] border-t border-[#1c2330] text-slate-400 py-12 px-4 md:px-8">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Main Links & Brand */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded bg-[#c5a059] flex items-center justify-center font-serif text-[#0a0d14] font-bold text-sm">
                Y
              </div>
              <span className="text-lg font-bold text-slate-100 tracking-tight">YORKFIN</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Yorkshire Finance. Programmable digital financial infrastructure engineered in Leeds for institutions, corporate treasuries and capital markets.
            </p>
            <div className="flex items-center gap-2 text-xs font-mono text-[#c5a059]">
              <MapPin className="w-3.5 h-3.5" />
              <span>Wellington Street Financial Quarter, Leeds LS1 4AP, United Kingdom</span>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-200 mb-3.5">Platform</h4>
            <ul className="space-y-2 text-xs">
              <li><button onClick={onOpenTerminal} className="hover:text-slate-100 transition-colors">YORKFIN Terminal</button></li>
              <li><button onClick={() => setCurrentView('terminal')} className="hover:text-slate-100 transition-colors">Asset Register</button></li>
              <li><button onClick={() => setCurrentView('terminal')} className="hover:text-slate-100 transition-colors">Credit Facilities</button></li>
              <li><button onClick={() => setCurrentView('terminal')} className="hover:text-slate-100 transition-colors">Liquidity Pools</button></li>
              <li><button onClick={() => setCurrentView('terminal')} className="hover:text-slate-100 transition-colors">Corporate Treasury</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-200 mb-3.5">Architecture</h4>
            <ul className="space-y-2 text-xs">
              <li><button onClick={() => setCurrentView('terminal')} className="hover:text-slate-100 transition-colors">Smart Contracts</button></li>
              <li><button onClick={() => setCurrentView('terminal')} className="hover:text-slate-100 transition-colors">Ledger Explorer</button></li>
              <li><button onClick={() => setCurrentView('risk')} className="hover:text-slate-100 transition-colors">Collateral Risk Engine</button></li>
              <li><button onClick={() => setCurrentView('research')} className="hover:text-slate-100 transition-colors">Technical Papers</button></li>
              <li><button onClick={() => setCurrentView('terminal')} className="hover:text-slate-100 transition-colors">Cryptographic Identity</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-200 mb-3.5">Governance & Risk</h4>
            <ul className="space-y-2 text-xs">
              <li><button onClick={() => setCurrentView('risk')} className="hover:text-slate-100 transition-colors">Risk Framework</button></li>
              <li><button onClick={() => setCurrentView('terminal')} className="hover:text-slate-100 transition-colors">Risk Committee</button></li>
              <li><button onClick={() => setCurrentView('why-leeds')} className="hover:text-slate-100 transition-colors">Why Leeds Editorial</button></li>
              <li><button onClick={() => setCurrentView('services')} className="hover:text-slate-100 transition-colors">Institutional Services</button></li>
            </ul>
          </div>

        </div>

        {/* Responsible Financial Disclosures */}
        <div className="pt-8 border-t border-[#181f2c] space-y-3">
          <div className="flex items-start gap-2.5 p-3.5 rounded bg-[#0d121c] border border-[#1e2736]">
            <ShieldAlert className="w-4 h-4 text-[#c5a059] shrink-0 mt-0.5" />
            <p className="text-[11px] text-slate-400 leading-relaxed">
              <strong className="text-slate-200">DEMO & SIMULATION NOTICE:</strong> YORKFIN is a fictional conceptual financial infrastructure project designed to demonstrate on-chain institutional technology, tokenisation, and corporate treasury management in Leeds, Yorkshire. All metrics, balances, yields, and counterparty records are synthetic test data. YORKFIN is not an FCA-authorised deposit-taker or financial institution.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 font-mono gap-4 pt-2">
            <div>
              © 2026 YORKFIN (Yorkshire Finance Ltd). All rights reserved.
            </div>
            <div className="flex items-center gap-4">
              <span>LEEDS · YORK · SHEFFIELD · BRADFORD</span>
              <span>·</span>
              <span>SIMULATED NETWORK TESTNET v2.4</span>
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
};
