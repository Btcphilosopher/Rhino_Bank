export interface PortfolioAsset {
  id: string;
  name: string;
  symbol: string;
  category: 'Fiat' | 'Stablecoin' | 'Tokenised Gilt' | 'Corporate Debt' | 'Infrastructure' | 'Commercial Property' | 'Money Market';
  value: number;
  balance: number;
  allocation: number; // percentage
  yieldRate: number; // annual percentage
  collateralEligible: boolean;
  maxLTV: number;
  liquidityTier: 'Tier 1 (Instant)' | 'Tier 2 (Same Day)' | 'Tier 3 (T+1)';
  status: 'Active' | 'Pledged' | 'Locked';
}

export interface TokenisedAsset {
  assetId: string;
  name: string;
  category: string;
  issuer: string;
  currency: string;
  faceValue: number;
  marketValue: number;
  maturity: string;
  coupon: number;
  yieldToMaturity: number;
  collateralEligibility: boolean;
  settlementStatus: 'Settled' | 'Pending Verification' | 'On-Chain Sync';
  contractAddress: string;
  ownershipRegistry: string;
  auditHistory: { date: string; firm: string; result: string }[];
  description: string;
}

export interface MarketPair {
  symbol: string;
  name: string;
  price: number;
  bid: number;
  ask: number;
  spread: number;
  volume24h: number;
  liquidity: number;
  change24h: number;
  settlementStatus: 'Real-Time Instant' | 'T+0 Programmable';
  chartData: { time: string; price: number; volume: number }[];
}

export interface LiquidityPool {
  id: string;
  pair: string;
  tvl: number;
  available: number;
  utilised: number;
  utilisationRate: number;
  borrowRate: number;
  supplyRate: number;
  depth24h: number;
  feeTier: string;
  myContribution: number;
}

export interface SmartContractInfo {
  contractId: string;
  name: string;
  version: string;
  network: string;
  status: 'VERIFIED' | 'ACTIVE';
  auditStatus: string;
  lastUpdate: string;
  transactionCount: number;
  gasOptimisation: string;
  codeSnippet: string;
  description: string;
}

export interface LedgerTransaction {
  block: number;
  timestamp: string;
  txHash: string;
  from: string;
  to: string;
  asset: string;
  value: number;
  status: 'CONFIRMED' | 'SETTLED' | 'PROCESSING';
  gasFee: string;
  smartContract: string;
  settlementState: 'FINALITY_ACHIEVED' | 'CRYPTOGRAPHICAL_PROOF_VALIDATED';
}

export interface ResearchArticle {
  id: string;
  title: string;
  subtitle: string;
  author: string;
  date: string;
  readTime: string;
  category: string;
  summary: string;
  content: string[];
}

export interface GovernanceProposal {
  id: string;
  title: string;
  proposer: string;
  status: 'ACTIVE' | 'PASSED' | 'PENDING';
  votesFor: number;
  votesAgainst: number;
  totalVotes: number;
  timeRemaining: string;
  category: 'Risk Parameter' | 'Collateral Rule' | 'Fee Model' | 'Contract Upgrade';
  description: string;
}

export const PORTFOLIO_DATA: PortfolioAsset[] = [
  {
    id: 'asset-1',
    name: 'Sterling Cash Balance',
    symbol: 'GBP',
    category: 'Fiat',
    value: 842000000,
    balance: 842000000,
    allocation: 33.9,
    yieldRate: 4.85,
    collateralEligible: true,
    maxLTV: 90,
    liquidityTier: 'Tier 1 (Instant)',
    status: 'Active',
  },
  {
    id: 'asset-2',
    name: 'YORKFIN GBP Tokenised Stablecoin',
    symbol: 'YF-GBP',
    category: 'Stablecoin',
    value: 450000000,
    balance: 450000000,
    allocation: 18.1,
    yieldRate: 5.12,
    collateralEligible: true,
    maxLTV: 88,
    liquidityTier: 'Tier 1 (Instant)',
    status: 'Active',
  },
  {
    id: 'asset-3',
    name: 'UK Government Gilt 2031 (Tokenised)',
    symbol: 'YF-GILT-2031',
    category: 'Tokenised Gilt',
    value: 520000000,
    balance: 5200000,
    allocation: 21.0,
    yieldRate: 4.45,
    collateralEligible: true,
    maxLTV: 85,
    liquidityTier: 'Tier 1 (Instant)',
    status: 'Pledged',
  },
  {
    id: 'asset-4',
    name: 'Yorkshire Clean Infrastructure Debt',
    symbol: 'YF-INFRA-01',
    category: 'Infrastructure',
    value: 280000000,
    balance: 2800000,
    allocation: 11.3,
    yieldRate: 6.75,
    collateralEligible: true,
    maxLTV: 75,
    liquidityTier: 'Tier 2 (Same Day)',
    status: 'Pledged',
  },
  {
    id: 'asset-5',
    name: 'Leeds Financial Quarter Commercial Debt',
    symbol: 'YF-PROP-LEEDS',
    category: 'Commercial Property',
    value: 195000000,
    balance: 1950000,
    allocation: 7.8,
    yieldRate: 7.10,
    collateralEligible: true,
    maxLTV: 70,
    liquidityTier: 'Tier 3 (T+1)',
    status: 'Active',
  },
  {
    id: 'asset-6',
    name: 'Sterling Money Market Trust',
    symbol: 'YF-MMF-GBP',
    category: 'Money Market',
    value: 194930420,
    balance: 1949304,
    allocation: 7.9,
    yieldRate: 5.05,
    collateralEligible: true,
    maxLTV: 85,
    liquidityTier: 'Tier 1 (Instant)',
    status: 'Active',
  },
];

export const TOKENISED_ASSET_REGISTER: TokenisedAsset[] = [
  {
    assetId: 'YF-GILT-2031',
    name: 'HM Treasury UK Gilt 4.25% 2031 Tokenised',
    category: 'Sovereign Debt',
    issuer: 'UK Debt Management Office (DMO / Yorkfin Node)',
    currency: 'GBP',
    faceValue: 500000000,
    marketValue: 520000000,
    maturity: '07 DEC 2031',
    coupon: 4.25,
    yieldToMaturity: 4.45,
    collateralEligibility: true,
    settlementStatus: 'Settled',
    contractAddress: '0x84f0...29a1',
    ownershipRegistry: 'YORKFIN-UK-GOV-REGISTRY',
    auditHistory: [
      { date: '2026-09-15', firm: 'PwC UK Financial Infrastructure Audit', result: 'Clean Unqualified' },
      { date: '2026-06-01', firm: 'Yorkshire On-Chain Validator', result: 'Verified Cryptographic Reserve' }
    ],
    description: 'Direct tokenised mirror of UK Sovereign debt. On-chain settlement with T+0 instant transferability across Yorkshire nodes.'
  },
  {
    assetId: 'YF-INFRA-01',
    name: 'Yorkshire Rail & Renewable Grid Bond 2034',
    category: 'Infrastructure',
    issuer: 'Yorkshire Transport Infrastructure Finance Board',
    currency: 'GBP',
    faceValue: 250000000,
    marketValue: 280000000,
    maturity: '15 MAR 2034',
    coupon: 6.50,
    yieldToMaturity: 6.75,
    collateralEligibility: true,
    settlementStatus: 'Settled',
    contractAddress: '0x91e2...88f4',
    ownershipRegistry: 'YORKFIN-INFRA-LEDGER',
    auditHistory: [
      { date: '2026-08-20', firm: 'KPMG UK Capital Markets', result: 'Asset Backing 108% Confirmed' }
    ],
    description: 'Senior secured debt token financing high-speed regional links and grid electrification across Leeds, Sheffield and York.'
  },
  {
    assetId: 'YF-CORP-27',
    name: 'Leeds Precision Engineering Senior Bond 2029',
    category: 'Corporate Debt',
    issuer: 'Northern Industrial Engineering Group PLC',
    currency: 'GBP',
    faceValue: 150000000,
    marketValue: 158500000,
    maturity: '30 JUN 2029',
    coupon: 5.90,
    yieldToMaturity: 6.12,
    collateralEligibility: true,
    settlementStatus: 'Settled',
    contractAddress: '0x33d1...99c2',
    ownershipRegistry: 'YORKFIN-CORP-REGISTRY',
    auditHistory: [
      { date: '2026-07-10', firm: 'EY Corporate Finance', result: 'Fully Verified Senior Pledge' }
    ],
    description: 'A-rated corporate debt issued by advanced manufacturing benchmark headquartered in Sheffield and Leeds.'
  },
  {
    assetId: 'YF-PROP-LEEDS',
    name: 'Wellington Place Financial District Portfolio',
    category: 'Commercial Property',
    issuer: 'Yorkshire Commercial Real Estate Fund',
    currency: 'GBP',
    faceValue: 180000000,
    marketValue: 195000000,
    maturity: '01 OCT 2032',
    coupon: 6.80,
    yieldToMaturity: 7.10,
    collateralEligibility: true,
    settlementStatus: 'Settled',
    contractAddress: '0x55c9...11e7',
    ownershipRegistry: 'YORKFIN-LAND-REGISTRY-BRIDGE',
    auditHistory: [
      { date: '2026-09-01', firm: 'CBRE Valuation UK', result: 'NAV Appraised at £195M' }
    ],
    description: 'Prime Grade-A financial district office estate in central Leeds, generating quarterly institutional cash flows.'
  }
];

export const MARKETS_DATA: MarketPair[] = [
  {
    symbol: 'GBP / YF-GBP',
    name: 'Sterling / Tokenised GBP',
    price: 1.0000,
    bid: 0.9999,
    ask: 1.0001,
    spread: 0.0002,
    volume24h: 312450000,
    liquidity: 842190000,
    change24h: 0.01,
    settlementStatus: 'Real-Time Instant',
    chartData: Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      price: 1.0000 + (Math.sin(i) * 0.0001),
      volume: 12000000 + (i * 500000)
    }))
  },
  {
    symbol: 'USD / YF-USD',
    name: 'US Dollar / Tokenised USD',
    price: 1.2842,
    bid: 1.2840,
    ask: 1.2844,
    spread: 0.0004,
    volume24h: 184200000,
    liquidity: 420000000,
    change24h: -0.15,
    settlementStatus: 'Real-Time Instant',
    chartData: Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      price: 1.2842 + (Math.cos(i) * 0.0020),
      volume: 8000000 + (i * 300000)
    }))
  },
  {
    symbol: 'EUR / YF-EUR',
    name: 'Euro / Tokenised EUR',
    price: 1.1890,
    bid: 1.1888,
    ask: 1.1892,
    spread: 0.0004,
    volume24h: 142000000,
    liquidity: 310000000,
    change24h: +0.22,
    settlementStatus: 'Real-Time Instant',
    chartData: Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      price: 1.1890 + (Math.sin(i * 0.5) * 0.0015),
      volume: 6000000 + (i * 200000)
    }))
  },
  {
    symbol: 'YF-GILT / GBP',
    name: 'Tokenised UK Gilt 2031 / GBP',
    price: 100.00,
    bid: 99.95,
    ask: 100.05,
    spread: 0.10,
    volume24h: 89400000,
    liquidity: 520000000,
    change24h: +0.08,
    settlementStatus: 'T+0 Programmable',
    chartData: Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      price: 99.80 + (i * 0.01) + (Math.sin(i) * 0.05),
      volume: 3500000 + (i * 100000)
    }))
  },
  {
    symbol: 'YF-CORP / GBP',
    name: 'Yorkshire Corporate Debt / GBP',
    price: 105.66,
    bid: 105.50,
    ask: 105.82,
    spread: 0.32,
    volume24h: 42100000,
    liquidity: 158500000,
    change24h: +0.34,
    settlementStatus: 'T+0 Programmable',
    chartData: Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      price: 105.20 + (i * 0.02),
      volume: 1800000 + (i * 50000)
    }))
  },
  {
    symbol: 'BTC / GBP',
    name: 'Bitcoin (Institutional Custody) / GBP',
    price: 49820.00,
    bid: 49810.00,
    ask: 49830.00,
    spread: 20.00,
    volume24h: 98400000,
    liquidity: 140000000,
    change24h: +1.42,
    settlementStatus: 'Real-Time Instant',
    chartData: Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      price: 49200 + (Math.sin(i * 0.4) * 600),
      volume: 4000000
    }))
  },
  {
    symbol: 'ETH / GBP',
    name: 'Ethereum (Institutional Custody) / GBP',
    price: 2480.50,
    bid: 2479.80,
    ask: 2481.20,
    spread: 1.40,
    volume24h: 64200000,
    liquidity: 92000000,
    change24h: +0.88,
    settlementStatus: 'Real-Time Instant',
    chartData: Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      price: 2450 + (Math.cos(i * 0.3) * 30),
      volume: 2500000
    }))
  }
];

export const LIQUIDITY_POOLS: LiquidityPool[] = [
  {
    id: 'pool-1',
    pair: 'GBP / YF-GBP',
    tvl: 184200000,
    available: 105300000,
    utilised: 78900000,
    utilisationRate: 42.8,
    borrowRate: 5.42,
    supplyRate: 4.91,
    depth24h: 61800000,
    feeTier: '0.01%',
    myContribution: 25000000
  },
  {
    id: 'pool-2',
    pair: 'YF-GILT / GBP STABLECOIN',
    tvl: 312000000,
    available: 218400000,
    utilised: 93600000,
    utilisationRate: 30.0,
    borrowRate: 5.10,
    supplyRate: 4.65,
    depth24h: 94000000,
    feeTier: '0.02%',
    myContribution: 50000000
  },
  {
    id: 'pool-3',
    pair: 'USD / YF-USD',
    tvl: 142000000,
    available: 98000000,
    utilised: 44000000,
    utilisationRate: 31.0,
    borrowRate: 5.85,
    supplyRate: 5.20,
    depth24h: 48000000,
    feeTier: '0.01%',
    myContribution: 10000000
  },
  {
    id: 'pool-4',
    pair: 'YF-INFRA-01 / GBP',
    tvl: 110000000,
    available: 68200000,
    utilised: 41800000,
    utilisationRate: 38.0,
    borrowRate: 6.95,
    supplyRate: 6.30,
    depth24h: 22000000,
    feeTier: '0.05%',
    myContribution: 15000000
  },
  {
    id: 'pool-5',
    pair: 'YF-PROP-LEEDS / GBP',
    tvl: 93990000,
    available: 64920000,
    utilised: 29070000,
    utilisationRate: 30.9,
    borrowRate: 7.20,
    supplyRate: 6.55,
    depth24h: 18000000,
    feeTier: '0.05%',
    myContribution: 8000000
  }
];

export const SMART_CONTRACTS: SmartContractInfo[] = [
  {
    contractId: 'YF-SETTLEMENT',
    name: 'Yorkfin Settlement Core Engine',
    version: 'VERSION 2.4.1',
    network: 'TESTNET (YORKSHIRE-01)',
    status: 'VERIFIED',
    auditStatus: 'COMPLETED — DEMO',
    lastUpdate: '14:42:08 UTC',
    transactionCount: 4281930,
    gasOptimisation: 'High (EIP-712 Atomic Batching)',
    codeSnippet: `// YORKFIN Programmable Settlement Logic
contract YorkfinSettlementEngine is IOwnable, ISettlement {
    mapping(bytes32 => SettlementInstruction) public instructions;
    
    event SettlementExecuted(
        bytes32 indexed instructionId,
        address indexed sender,
        address indexed recipient,
        uint256 amount,
        uint64 timestamp
    );

    function executeAtomicSettlement(
        bytes32 instructionId,
        bytes memory proofSignature
    ) external returns (bool) {
        SettlementInstruction storage inst = instructions[instructionId];
        require(!inst.settled, "ERROR: Already Settled");
        require(verifyProof(inst.hash, proofSignature), "ERROR: Invalid Cryptographic Proof");
        
        inst.settled = true;
        transferAsset(inst.asset, inst.from, inst.to, inst.amount);
        emit SettlementExecuted(instructionId, inst.from, inst.to, inst.amount, uint64(block.timestamp));
        return true;
    }
}`,
    description: 'Enforces atomic DvP (Delivery vs Payment) settlement across institutional ledgers with zero principal risk.'
  },
  {
    contractId: 'YF-IDENTITY',
    name: 'Yorkfin Cryptographic Institution Registry',
    version: 'VERSION 1.9.0',
    network: 'TESTNET (YORKSHIRE-01)',
    status: 'VERIFIED',
    auditStatus: 'COMPLETED — DEMO',
    lastUpdate: '11:15:22 UTC',
    transactionCount: 18240,
    gasOptimisation: 'Zero-Knowledge Compliance Proofs',
    codeSnippet: `// YORKFIN Institutional Identity & Access
contract YorkfinIdentityRegistry {
    struct Institution {
        string leedsRegId;
        bool kycVerified;
        uint256 authorizationMask; // Treasury / Credit / Settlement
        address primarySigningKey;
    }
    
    mapping(address => Institution) public registry;
    
    function isAuthorized(address entity, uint256 requiredRole) external view returns (bool) {
        return (registry[entity].authorizationMask & requiredRole) == requiredRole;
    }
}`,
    description: 'Verifies institutional KYC, signing permissions, and multi-signature authorization masks for Leeds financial entities.'
  },
  {
    contractId: 'YF-ASSET',
    name: 'Tokenised Security & Gilt Engine',
    version: 'VERSION 3.1.2',
    network: 'TESTNET (YORKSHIRE-01)',
    status: 'VERIFIED',
    auditStatus: 'COMPLETED — DEMO',
    lastUpdate: '09:04:11 UTC',
    transactionCount: 891200,
    gasOptimisation: 'ERC-3643 Institutional Security Standard',
    codeSnippet: `// YORKFIN Asset Registry & Coupon Distribution
contract YorkfinAssetToken is IERC20, IInstitutionalAsset {
    string public isinCode;
    uint256 public maturityTimestamp;
    uint256 public couponRateBasisPoints;
    
    function distributeCoupon() external onlyIssuer {
        require(block.timestamp >= lastCouponPayment + 180 days, "Coupon Period Active");
        // Automated yield disbursement to registered token holders
    }
}`,
    description: 'ERC-3643 compliant security token architecture for UK gilts, corporate bonds, and commercial property instruments.'
  },
  {
    contractId: 'YF-CREDIT',
    name: 'On-Chain Secured Credit Module',
    version: 'VERSION 2.1.0',
    network: 'TESTNET (YORKSHIRE-01)',
    status: 'VERIFIED',
    auditStatus: 'COMPLETED — DEMO',
    lastUpdate: '13:01:45 UTC',
    transactionCount: 318740,
    gasOptimisation: 'Automated Loan-to-Value Health Checking',
    codeSnippet: `// YORKFIN Credit & Collateral Lock
contract YorkfinCreditFacility {
    struct LoanPosition {
        uint256 principalGBP;
        address collateralAsset;
        uint256 collateralAmount;
        uint256 ltvBasisPoints; // e.g. 7140 = 71.4%
        uint256 interestRateBps;
        uint64 maturityDate;
    }
}`,
    description: 'Handles collateral locking, dynamic loan-to-value calculations, and automated credit health factor monitoring.'
  },
  {
    contractId: 'YF-COLLATERAL',
    name: 'Dynamic Collateral Valuation Engine',
    version: 'VERSION 1.8.4',
    network: 'TESTNET (YORKSHIRE-01)',
    status: 'VERIFIED',
    auditStatus: 'COMPLETED — DEMO',
    lastUpdate: '14:20:01 UTC',
    transactionCount: 1420900,
    gasOptimisation: 'Multi-Oracle Aggregation',
    codeSnippet: `// Collateral valuation and health factor
function calculateHealthFactor(uint256 collateralValueGBP, uint256 loanValueGBP, uint256 liquidationLTV) 
    public pure returns (uint256 healthFactor) {
    uint256 maxBorrowCapacity = (collateralValueGBP * liquidationLTV) / 10000;
    return (maxBorrowCapacity * 1e18) / loanValueGBP;
}`,
    description: 'Monitors asset price fluctuations, risk thresholds, liquidation warnings, and stress test factors in real time.'
  },
  {
    contractId: 'YF-LIQUIDITY',
    name: 'Institutional Liquidity Pool Controller',
    version: 'VERSION 2.0.1',
    network: 'TESTNET (YORKSHIRE-01)',
    status: 'VERIFIED',
    auditStatus: 'COMPLETED — DEMO',
    lastUpdate: '12:11:50 UTC',
    transactionCount: 642100,
    gasOptimisation: 'Concentrated Institutional Depth',
    codeSnippet: `// Liquidity utilization & interest rate model
function getBorrowRate(uint256 utilizationBps) public pure returns (uint256) {
    if (utilizationBps < 8000) {
        return 400 + (utilizationBps * 200) / 8000; // Base rate curve
    } else {
        return 600 + ((utilizationBps - 8000) * 1000) / 2000; // Steep jump curve
    }
}`,
    description: 'Manages money-market liquidity pools, interest rate jump-curves, and corporate liquidity reserve allocations.'
  },
  {
    contractId: 'YF-TREASURY',
    name: 'Corporate Multi-Sig Treasury Safe',
    version: 'VERSION 3.0.0',
    network: 'TESTNET (YORKSHIRE-01)',
    status: 'VERIFIED',
    auditStatus: 'COMPLETED — DEMO',
    lastUpdate: '10:55:04 UTC',
    transactionCount: 94820,
    gasOptimisation: 'Time-Locked Policy Enforcement',
    codeSnippet: `// Policy-based multi-sig corporate treasury
struct Policy {
    uint256 maxSingleTxGBP;
    uint8 requiredSignatures;
    uint32 timelockSeconds;
}`,
    description: 'Enforces corporate spending limits, multi-signature approvals, and treasury timelocks for enterprise entities.'
  },
  {
    contractId: 'YF-GOVERNANCE',
    name: 'Protocol & Risk Parameter Governance',
    version: 'VERSION 1.4.0',
    network: 'TESTNET (YORKSHIRE-01)',
    status: 'VERIFIED',
    auditStatus: 'COMPLETED — DEMO',
    lastUpdate: '08:30:19 UTC',
    transactionCount: 4210,
    gasOptimisation: 'Snapshot Voting Weights',
    codeSnippet: `// Protocol risk & parameter updates
function executeParameterChange(uint256 proposalId) external onlyRiskCommittee {
    // Updates collateral thresholds & fee tiers across Yorkshire nodes
}`,
    description: 'Manages risk committee voting, collateral parameter adjustments, and technical protocol upgrade approvals.'
  }
];

export const LEDGER_TRANSACTIONS: LedgerTransaction[] = [
  {
    block: 4892014,
    timestamp: '2026-10-01 12:41:02',
    txHash: '0x8f4a91b2c3d4e5f67890a1b2c3d4e5f678901234',
    from: 'Yorkshire Infrastructure Holdings Ltd (0x84...19A)',
    to: 'HM Treasury Settlement Node (0x01...GILT)',
    asset: 'YF-GILT-2031',
    value: 25000000,
    status: 'SETTLED',
    gasFee: '0.00042 GBP',
    smartContract: 'YF-SETTLEMENT',
    settlementState: 'FINALITY_ACHIEVED'
  },
  {
    block: 4892013,
    timestamp: '2026-10-01 12:40:18',
    txHash: '0x71e892c4d5f6a1b2c3d4e5f67890a1b2c3d4e5f6',
    from: 'Leeds Financial Quarter Pool (0x33...LIQ)',
    to: 'Northern Engineering Group PLC (0x99...CORP)',
    asset: 'GBP STABLECOIN (YF-GBP)',
    value: 12500000,
    status: 'SETTLED',
    gasFee: '0.00038 GBP',
    smartContract: 'YF-CREDIT',
    settlementState: 'FINALITY_ACHIEVED'
  },
  {
    block: 4892012,
    timestamp: '2026-10-01 12:39:45',
    txHash: '0x62d781b3c4d5e6f7890a1b2c3d4e5f6789012345',
    from: 'Sheffield Steel Capital Ltd (0x12...SHF)',
    to: 'Yorkshire Liquidity Vault 01 (0x44...VAULT)',
    asset: 'GBP',
    value: 50000000,
    status: 'SETTLED',
    gasFee: '0.00051 GBP',
    smartContract: 'YF-LIQUIDITY',
    settlementState: 'CRYPTOGRAPHICAL_PROOF_VALIDATED'
  },
  {
    block: 4892011,
    timestamp: '2026-10-01 12:38:12',
    txHash: '0x51c670a2b3c4d5e6f7890a1b2c3d4e5f67890123',
    from: 'York Commercial Property Trust (0x88...PROP)',
    to: 'Yorkfin Custody Escrow (0x00...CUST)',
    asset: 'YF-PROP-LEEDS',
    value: 18000000,
    status: 'SETTLED',
    gasFee: '0.00029 GBP',
    smartContract: 'YF-ASSET',
    settlementState: 'FINALITY_ACHIEVED'
  },
  {
    block: 4892010,
    timestamp: '2026-10-01 12:36:55',
    txHash: '0x40b569f1a2b3c4d5e6f7890a1b2c3d4e5f678901',
    from: 'Wellington Street Treasury Node (0x22...WEL)',
    to: 'Bradford Industrial Finance (0x55...BRD)',
    asset: 'YF-INFRA-01',
    value: 8500000,
    status: 'SETTLED',
    gasFee: '0.00031 GBP',
    smartContract: 'YF-SETTLEMENT',
    settlementState: 'FINALITY_ACHIEVED'
  }
];

export const RESEARCH_ARTICLES: ResearchArticle[] = [
  {
    id: 'res-1',
    title: 'The Yorkshire Balance Sheet',
    subtitle: 'Building Regional Financial Infrastructure for the UK Capital Economy',
    author: 'Yorkfin Quantitative Research & Macro Strategy',
    date: 'SEPTEMBER 2026',
    readTime: '12 min read',
    category: 'Institutional Infrastructure',
    summary: 'An inquiry into how digital settlement, tokenised gilts and direct regional liquidity channels reduce friction for corporate borrowers and institutional investors across the North.',
    content: [
      'For two centuries, regional commerce across Yorkshire relied on physical banking halls, clearing houses, and bilateral paper contracts. Modern banking, however, remains choked by multi-day settlement cycles, fragmented collateral records, and opaque liquidity silos.',
      'By replacing paper-bound registries with programmable cryptographic state engines, YORKFIN allows institutional participants in Leeds, Sheffield, and York to settle transactions in seconds rather than days (T+0 DvP).',
      'This paper presents empirical findings from 18 months of simulated on-chain gilt settlement, demonstrating a 94% reduction in capital drag for corporate treasuries.'
    ]
  },
  {
    id: 'res-2',
    title: 'What Tokenisation Actually Changes',
    subtitle: 'Moving Beyond Speculative Tokens to Programmable Financial Claims',
    author: 'Dr. Marcus Vance, Head of Financial Engineering',
    date: 'AUGUST 2026',
    readTime: '8 min read',
    category: 'Capital Markets',
    summary: 'A critical distinction between retail crypto speculation and institutional asset tokenisation under UK legal and regulatory frameworks.',
    content: [
      'Tokenisation is not the invention of a new asset class; it is the modernization of ownership representation. A tokenised UK Gilt (such as YF-GILT-2031) retains the exact credit risk and cashflow properties of sovereign UK debt.',
      'What changes is composability: a corporate treasurer can pledge a fraction of a gilt portfolio as collateral for an intraday credit line in under 3 seconds, without manual custodian signatures or manual clearance procedures.',
      'We examine the legal enforceability of smart-contract encumbrance under English commercial law and the role of atomic settlement nodes.'
    ]
  },
  {
    id: 'res-3',
    title: 'Programmable Settlement in Sterling',
    subtitle: 'Atomic Delivery vs. Payment (DvP) and Intraday Liquidity Efficiency',
    author: 'Yorkfin Settlement Protocol Team',
    date: 'JULY 2026',
    readTime: '15 min read',
    category: 'Settlement & Clearing',
    summary: 'A mathematical model of intraday liquidity velocity when Sterling digital currency and tokenised bonds share a unified cryptographic state.',
    content: [
      'In traditional settlement, Delivery vs Payment requires counterparty risk exposure or central clearing house margin buffers. Atomic DvP executes cash movement and security transfer in a single, un-splittable state change.',
      'If either leg fails cryptographic validation, the entire transaction reverts automatically. This eliminates counterparty risk during settlement windows.'
    ]
  },
  {
    id: 'res-4',
    title: 'Stablecoins and Sterling',
    subtitle: 'Institutional Reserve Management for Digital Fiat Tokens',
    author: 'Yorkfin Risk & Compliance Committee',
    date: 'JUNE 2026',
    readTime: '10 min read',
    category: 'Digital Fiat & Reserve Design',
    summary: 'Analyzing 1:1 Sterling reserve architecture backed by Bank of England deposits and short-dated UK Treasury gilts.',
    content: [
      'For digital Sterling to function as institutional infrastructure, reserve asset quality must be flawless. YF-GBP maintains 100% reserve backing held in bankruptcy-remote custodians, subjected to daily cryptographic reserve proofs.',
      'We discuss reserve auditability, real-time proof-of-reserve oracles, and integration with high-volume corporate payroll systems.'
    ]
  }
];

export const GOVERNANCE_PROPOSALS: GovernanceProposal[] = [
  {
    id: 'YFGP-2026-08',
    title: 'Adjust Maximum LTV Threshold for Tokenised Infrastructure Debt (YF-INFRA-01)',
    proposer: 'Yorkfin Risk Committee',
    status: 'ACTIVE',
    votesFor: 84200000,
    votesAgainst: 12100000,
    totalVotes: 96300000,
    timeRemaining: '2 days 14 hours',
    category: 'Risk Parameter',
    description: 'Proposes increasing the maximum Loan-To-Value ratio for YF-INFRA-01 from 70.0% to 75.0% following positive Q3 financial performance and increased liquidity depth.'
  },
  {
    id: 'YFGP-2026-07',
    title: 'Add Leeds Grade-A Commercial Property Index as Eligible Collateral Class',
    proposer: 'Wellington Financial Group',
    status: 'PASSED',
    votesFor: 124500000,
    votesAgainst: 4200000,
    totalVotes: 128700000,
    timeRemaining: 'Concluded',
    category: 'Collateral Rule',
    description: 'Approved inclusion of Grade-A prime office real estate in central Leeds financial quarter (YF-PROP-LEEDS) as Tier 3 collateral with a 70% LTV cap.'
  },
  {
    id: 'YFGP-2026-06',
    title: 'Upgrade YF-SETTLEMENT Contract to Support EIP-712 Batch Delivery vs Payment',
    proposer: 'Yorkfin Core Engineering',
    status: 'PASSED',
    votesFor: 145000000,
    votesAgainst: 100000,
    totalVotes: 145100000,
    timeRemaining: 'Concluded',
    category: 'Contract Upgrade',
    description: 'Upgraded settlement pipeline to batch up to 1,000 atomic transactions into a single state update, reducing per-transaction verification latency to under 0.2s.'
  }
];

export const YORKSHIRE_NODES = [
  { name: 'LEEDS', role: 'Central Infrastructure & Financial Quarter', x: 45, y: 52, status: 'PRIMARY HUB', txSec: '1,420 tx/s', ping: '1.2ms' },
  { name: 'SHEFFIELD', role: 'Industrial Debt & Capital Markets Node', x: 48, y: 78, status: 'OPERATIONAL', txSec: '840 tx/s', ping: '2.1ms' },
  { name: 'BRADFORD', role: 'SME Lending & Trade Finance Node', x: 32, y: 48, status: 'OPERATIONAL', txSec: '620 tx/s', ping: '1.8ms' },
  { name: 'WAKEFIELD', role: 'Logistics & Asset Registry Node', x: 52, y: 62, status: 'OPERATIONAL', txSec: '490 tx/s', ping: '1.5ms' },
  { name: 'YORK', role: 'Sovereign Gilt Custody & Treasury Reserve', x: 68, y: 35, status: 'PRIMARY HUB', txSec: '1,100 tx/s', ping: '1.9ms' },
  { name: 'HUDDERSFIELD', role: 'Manufacturing Bond Validation Node', x: 36, y: 66, status: 'OPERATIONAL', txSec: '380 tx/s', ping: '2.4ms' },
  { name: 'HALIFAX', role: 'Building Society & Credit Reserve Node', x: 28, y: 58, status: 'OPERATIONAL', txSec: '520 tx/s', ping: '2.2ms' },
  { name: 'HARROGATE', role: 'Private Wealth & Family Office Node', x: 50, y: 32, status: 'OPERATIONAL', txSec: '410 tx/s', ping: '1.6ms' },
];
