import React, { useState } from 'react';
import { TopBar } from './components/TopBar';
import { Footer } from './components/Footer';
import { LandingPage } from './pages/LandingPage';
import { ResearchPage } from './pages/ResearchPage';
import { ServicesPage } from './pages/ServicesPage';
import { WhyLeedsPage } from './pages/WhyLeedsPage';
import { RiskTab } from './terminal/RiskTab';
import { YorkfinTerminal } from './terminal/YorkfinTerminal';

export default function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'terminal' | 'research' | 'risk' | 'services' | 'why-leeds'>('landing');

  return (
    <div className="min-h-screen bg-[#0a0d14] text-[#e2e8f0] flex flex-col font-sans selection:bg-[#c5a059]/30 selection:text-[#f8fafc]">
      
      {/* Navigation Header Bar */}
      <TopBar
        currentView={currentView}
        setCurrentView={(view) => setCurrentView(view as any)}
        onOpenTerminal={() => setCurrentView('terminal')}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {currentView === 'landing' && (
          <LandingPage
            onOpenTerminal={() => setCurrentView('terminal')}
            setCurrentView={(view) => setCurrentView(view as any)}
          />
        )}

        {currentView === 'terminal' && (
          <YorkfinTerminal onClose={() => setCurrentView('landing')} />
        )}

        {currentView === 'research' && <ResearchPage />}

        {currentView === 'risk' && (
          <div className="px-4 md:px-8 py-8 max-w-7xl mx-auto">
            <RiskTab />
          </div>
        )}

        {currentView === 'services' && (
          <ServicesPage onOpenTerminal={() => setCurrentView('terminal')} />
        )}

        {currentView === 'why-leeds' && (
          <WhyLeedsPage onOpenTerminal={() => setCurrentView('terminal')} />
        )}
      </main>

      {/* Institutional Footer */}
      <Footer
        setCurrentView={(view) => setCurrentView(view as any)}
        onOpenTerminal={() => setCurrentView('terminal')}
      />

    </div>
  );
}
