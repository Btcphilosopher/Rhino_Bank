test_that("Synthetic portfolio generation is deterministic and respects boundaries", {
  p1 <- generate_synthetic_portfolio(n_loans = 100, seed = 123)
  p2 <- generate_synthetic_portfolio(n_loans = 100, seed = 123)

  expect_equal(nrow(p1), 100)
  expect_equal(p1$current_balance, p2$current_balance)
  expect_true(all(p1$ltv > 0 & p1$ltv <= 1.0))
  expect_true(all(p1$synthetic_provenance == "RHINOBANK_SYNTHETIC_MODEL_DATA_ONLY"))
  expect_equal(unique(p1$country), "United Kingdom")
})

test_that("Portfolio stratification aggregates correctly", {
  p <- generate_synthetic_portfolio(n_loans = 500, target_notional = 1e8, seed = 42)
  strat <- stratify_portfolio(p)

  expect_equal(strat$total_loans, 500)
  expect_equal(round(strat$total_balance / 1e8, 2), 1.00)
  expect_true(strat$wac > 0.03 && strat$wac < 0.10)
  expect_true(strat$waltv > 0.50 && strat$waltv < 0.90)
})
