test_that("Monte Carlo simulation is reproducible with identical seeds", {
  tranches_dt <- data.table::data.table(
    tranche_id = c("Senior A", "Mezzanine B", "First Loss C"),
    attachment_pt = c(0.10, 0.03, 0.00),
    detachment_pt = c(1.00, 0.10, 0.03),
    coupon_spread = c(0.0080, 0.0250, 0.0800),
    initial_balance = c(9.0e7, 7.0e6, 3.0e6)
  )
  cap_struct <- build_tranche_structure(tranches_dt)

  mc1 <- run_monte_carlo_mbs(cap_struct, n_simulations = 50, seed = 777)
  mc2 <- run_monte_carlo_mbs(cap_struct, n_simulations = 50, seed = 777)

  expect_equal(mc1$mean_pool_loss_gbp, mc2$mean_pool_loss_gbp)
  expect_equal(mc1$var_99_gbp, mc2$var_99_gbp)
  expect_true(mc1$var_99_gbp >= mc1$var_95_gbp)
})
