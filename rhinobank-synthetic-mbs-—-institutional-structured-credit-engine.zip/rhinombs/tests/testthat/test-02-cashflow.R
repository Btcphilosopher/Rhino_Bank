test_that("Cash-flow engine amortisation and conservation holds", {
  init_bal <- 1e8
  cf <- run_portfolio_cashflows(
    initial_balance = init_bal,
    wac = 0.05,
    wam = 120,
    cpr_vector = rep(0.06, 60),
    cdr_vector = rep(0.01, 60),
    recovery_rate = 0.70
  )

  expect_equal(nrow(cf), 60)
  expect_equal(cf$opening_balance[1], init_bal)

  # Check that opening balance minus scheduled, prepaid, and defaults equals closing balance
  for (t in 1:10) {
    expected_closing <- cf$opening_balance[t] - cf$scheduled_principal[t] - cf$prepaid_principal[t] - cf$gross_defaults[t]
    expect_equal(round(cf$closing_balance[t], 2), round(expected_closing, 2))
  }
})

test_that("CPR to SMM conversion is exact", {
  cpr <- 0.06
  smm <- prepayment_cpr_smm(cpr)
  # (1 - SMM)^12 should equal (1 - CPR)
  expect_equal(round((1 - smm)^12, 6), round(1 - cpr, 6))
})
