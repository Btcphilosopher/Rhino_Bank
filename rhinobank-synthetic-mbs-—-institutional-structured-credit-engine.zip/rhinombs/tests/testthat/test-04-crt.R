test_that("Synthetic CRT structure partitions risk properly", {
  crt <- structure_synthetic_crt(
    reference_notional = 1e9,
    retained_first_loss_detachment = 0.025,
    mezzanine_detachment = 0.095,
    protection_spread_bps = 320
  )

  expect_equal(crt$first_loss_notional, 2.5e7)
  expect_equal(crt$protected_mezzanine_notional, 7.0e7)
  expect_equal(crt$senior_retained_notional, 9.05e8)
  # Sum of tranches must equal reference notional exactly
  expect_equal(crt$first_loss_notional + crt$protected_mezzanine_notional + crt$senior_retained_notional, 1e9)
})
