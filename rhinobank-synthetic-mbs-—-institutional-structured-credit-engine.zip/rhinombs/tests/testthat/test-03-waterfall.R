test_that("Tranche boundaries and loss fraction calculations are valid", {
  expect_error(calculate_tranche_loss_fraction(0.05, 0.10, 0.05)) # D <= A must error

  # Attachment 2%, Detachment 10%
  # Loss 1% -> 0%
  expect_equal(calculate_tranche_loss_fraction(0.01, 0.02, 0.10), 0)
  # Loss 6% -> (0.06 - 0.02) / (0.10 - 0.02) = 0.04 / 0.08 = 0.50
  expect_equal(calculate_tranche_loss_fraction(0.06, 0.02, 0.10), 0.50)
  # Loss 12% -> 1.0 (capped)
  expect_equal(calculate_tranche_loss_fraction(0.12, 0.02, 0.10), 1.0)
})

test_that("Waterfall cash-flow conservation holds strictly", {
  tranches_dt <- data.table::data.table(
    tranche_id = c("Senior A", "Mezzanine B", "Junior C", "Equity D"),
    attachment_pt = c(0.15, 0.08, 0.03, 0.00),
    detachment_pt = c(1.00, 0.15, 0.08, 0.03),
    coupon_spread = c(0.0080, 0.0180, 0.0350, 0.0800),
    initial_balance = c(8.5e7, 7.0e6, 5.0e6, 3.0e6)
  )
  cap_struct <- build_tranche_structure(tranches_dt)

  cf <- run_portfolio_cashflows(initial_balance = 1e8, wam = 120, cpr_vector = rep(0.08, 60), cdr_vector = rep(0.01, 60))
  wf <- run_waterfall_engine(cap_struct, cf)

  expect_true(wf$conservation_validated)
})
