library(testthat)
library(rhinombs)

test_check("rhinombs")
