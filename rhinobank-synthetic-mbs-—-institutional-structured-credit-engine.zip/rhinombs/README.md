# rhinombs: Institutional Synthetic MBS Credit Engine

**Rhino Bank Quantitative Credit Research & Model Risk Oversight**  
*Model Reference: RHN-MRG-MBS-2026-04 (Tier 1 Material Model)*

---

## Overview

`rhinombs` is an institutional-grade R quantitative package developed for Rhino Bank structured-credit researchers, fixed-income traders, treasury teams, model validators, and risk officers. It provides end-to-end pricing, structuring, and risk-management capabilities for synthetic mortgage-backed securities (MBS) and balance-sheet credit-risk transfer (CRT) transactions.

**Statutory Disclosure:** All mortgage portfolios, borrower profiles, and transactions modeled by this software are strictly hypothetical synthetic constructs. Simulated values do not represent executable quotes or formal credit ratings. Regulatory recognition of Significant Risk Transfer (SRT) under UK PRA SS1/23 requires separate supervisory validation.

---

## Package Architecture

```
rhinombs/
├── DESCRIPTION
├── NAMESPACE
├── README.md
├── R/
│   ├── 01_portfolio_generator.R   # Synthetic mortgage pool generator & stratification
│   ├── 02_cashflow_engine.R        # Monthly amortisation, prepayments, defaults, recoveries
│   ├── 03_default_recovery.R       # Hazard models, LGD under HPI shocks, multi-period ECL
│   ├── 04_prepayment_model.R       # SMM/CPR, refinancing incentive curve, WAL, duration
│   ├── 05_yield_curves.R           # Discount curves, SONIA/SOFR, curve shocks & shifts
│   ├── 06_waterfall_engine.R       # Capital structure, loss allocation Phi(L), triggers
│   ├── 07_synthetic_crt.R          # CRT structuring, funded CLN/guarantee, basis risk
│   ├── 08_valuation.R              # Tranche pricing, break-even spread, spread duration
│   ├── 09_risk_analytics.R         # DV01, key-rate durations, convexity, concentration
│   ├── 10_monte_carlo.R            # Gaussian copula simulation, VaR 95/99/99.9%, ES
│   ├── 11_stress_testing.R         # 12 institutional macro scenarios, reverse stress tests
│   └── 12_governance.R             # PRA SS1/23 model inventory, validation & audit trail
├── tests/
│   ├── testthat.R
│   └── testthat/
│       ├── test-01-portfolio.R
│       ├── test-02-cashflow.R
│       ├── test-03-waterfall.R
│       ├── test-04-crt.R
│       └── test-05-monte-carlo.R
└── inst/
    ├── extdata/
    │   ├── sample_mortgages.csv
    │   └── transaction_config.json
    ├── quarto/
    │   └── valuation_and_risk_report.qmd
    └── shiny/
        └── app.R
```

---

## Installation in R

```r
# Install development dependencies
install.packages(c("data.table", "dplyr", "tidyr", "Matrix", "ggplot2", "testthat", "shiny", "DT", "quarto"))

# Install rhinombs directly from local directory
devtools::install("rhinombs")

# Run test suite
testthat::test_package("rhinombs")
```

---

## Quick Example Workflow

```r
library(rhinombs)

# 1. Generate synthetic £1B prime UK mortgage portfolio
pool <- generate_synthetic_portfolio(n_loans = 5000, target_notional = 1e9, seed = 42)

# 2. Project monthly cash flows (60 periods, 8% CPR, 1.2% CDR, 70% recovery)
cf <- run_portfolio_cashflows(
  initial_balance = sum(pool$current_balance),
  wac = 0.0545,
  wam = 282,
  cpr_vector = rep(0.08, 60),
  cdr_vector = rep(0.012, 60)
)

# 3. Structure CRT tranche waterfall
tranches <- data.table::data.table(
  tranche_id = c("Senior A", "Mezzanine B", "Junior C", "Equity D"),
  attachment_pt = c(0.095, 0.050, 0.025, 0.000),
  detachment_pt = c(1.000, 0.095, 0.050, 0.025),
  coupon_spread = c(0.0080, 0.0210, 0.0380, 0.0000),
  initial_balance = c(9.05e8, 4.5e7, 2.5e7, 2.5e7)
)
cap_struct <- build_tranche_structure(tranches)

# 4. Execute waterfall allocation
waterfall <- run_waterfall_engine(cap_struct, cf)

# 5. Price tranches on SONIA yield curve
curve <- build_yield_curve()
pricing <- price_tranche_cashflows(waterfall, curve)
print(pricing)
```
