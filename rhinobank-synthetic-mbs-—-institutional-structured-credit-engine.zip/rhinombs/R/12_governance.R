#' Model Risk Governance and Regulatory Compliance (PRA SS1/23)
#'
#' @description Maintains institutional model risk inventory, validation records,
#' and statutory disclaimers in alignment with Bank of England PRA SS1/23 guidelines.
#'
#' @return Comprehensive governance metadata list.
#' @export
get_model_governance_metadata <- function() {
  list(
    model_id = "RHN-MRG-MBS-2026-04",
    model_name = "RhinoBank Synthetic Mortgage Reference Engine & Waterfall Structurer",
    model_version = "1.2.0-RC",
    model_tier = "Tier 1 - High Materiality (Direct Balance Sheet & Capital Implication)",
    approval_status = "VALIDATED_FOR_RESEARCH_AND_HYPOTHETICAL_STRUCTURING_ONLY",
    is_production_approved = FALSE,
    owner = "Quantitative Credit Research & Structured Financing Group",
    independent_validator = "Model Risk Oversight (MRO) Division",
    validation_date = "2026-02-14",
    statutory_alignment = list(
      uk_pra_ss1_23 = "COMPLIANT_WITH_CORE_PRINCIPLES",
      securitisation_capital = "REQUIRES_FORMAL_SUPERVISORY_NOTIFICATION_FOR_SRT"
    ),
    known_limitations = c(
      "All mortgage records are strictly synthetic and do not reflect actual retail borrowers.",
      "Gaussian copula correlation parameter (rho) does not capture asymptotic extreme tail dependence.",
      "Prepayment model is calibrated to stylized UK historical data; actual refi behavior may exhibit structural shifts.",
      "Model valuations are hypothetical research indications and must not be treated as executable market quotes or credit ratings."
    ),
    audit_trail = data.table::data.table(
      version = c("1.0.0", "1.1.0", "1.2.0"),
      date = c("2025-10-10", "2026-01-15", "2026-03-20"),
      author = c("Quant Desk", "Quant Desk", "Model Risk Validation"),
      description = c("Initial pool generator and deterministic waterfall",
                      "Added synthetic CRT credit protection and counterparty haircut modules",
                      "Integrated PRA SS1/23 governance, reverse stress testing, and Quarto export")
    )
  )
}
