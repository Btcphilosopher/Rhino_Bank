#' Synthetic Mortgage Portfolio Generator
#'
#' @description Generates a statistically plausible synthetic residential mortgage portfolio
#' for institutional research and structuring at Rhino Bank. All data are synthetic.
#'
#' @param n_loans Integer. Number of synthetic mortgages to simulate (default: 5000).
#' @param pool_type Character. Pool archetype: 'prime_residential', 'buy_to_let', 'high_ltv', 'mixed_credit'.
#' @param target_notional Numeric. Target total portfolio balance in GBP (default: 1e9).
#' @param seed Integer. Deterministic pseudo-random seed (default: 42).
#' @return A data.table containing synthetic mortgage records.
#' @export
generate_synthetic_portfolio <- function(n_loans = 5000,
                                         pool_type = c("prime_residential", "buy_to_let", "high_ltv", "mixed_credit"),
                                         target_notional = 1e9,
                                         seed = 42) {
  pool_type <- match.arg(pool_type)
  set.seed(seed)

  loan_ids <- sprintf("RHN-MBS-2026-%06d", seq_len(n_loans))

  # Regional distribution across UK housing markets
  regions <- c("Greater London", "South East", "North West", "West Midlands",
               "East of England", "South West", "Yorkshire & Humber", "Scotland", "Wales")
  region_probs <- c(0.28, 0.22, 0.12, 0.09, 0.09, 0.08, 0.05, 0.04, 0.03)
  loan_regions <- sample(regions, size = n_loans, replace = TRUE, prob = region_probs)

  # Property values based on regional tiers (log-normal distribution)
  base_mean_val <- ifelse(loan_regions == "Greater London", 520000,
                   ifelse(loan_regions == "South East", 390000, 240000))
  property_values <- round(rlnorm(n_loans, meanlog = log(base_mean_val), sdlog = 0.35) / 1000) * 1000
  property_values <- pmax(property_values, 95000)

  # LTV distributions conditional on pool type
  if (pool_type == "prime_residential") {
    ltv <- pmin(pmax(rnorm(n_loans, mean = 0.65, sd = 0.10), 0.30), 0.85)
    credit_grades <- sample(c("AAA", "AA", "A", "BBB"), n_loans, replace = TRUE, prob = c(0.45, 0.35, 0.15, 0.05))
    prop_type <- sample(c("Owner-Occupied"), n_loans, replace = TRUE)
  } else if (pool_type == "buy_to_let") {
    ltv <- pmin(pmax(rnorm(n_loans, mean = 0.72, sd = 0.08), 0.40), 0.80)
    credit_grades <- sample(c("AA", "A", "BBB", "BB"), n_loans, replace = TRUE, prob = c(0.20, 0.50, 0.25, 0.05))
    prop_type <- sample(c("Buy-to-Let"), n_loans, replace = TRUE)
  } else if (pool_type == "high_ltv") {
    ltv <- pmin(pmax(rnorm(n_loans, mean = 0.88, sd = 0.05), 0.80), 0.95)
    credit_grades <- sample(c("A", "BBB", "BB", "B"), n_loans, replace = TRUE, prob = c(0.15, 0.50, 0.25, 0.10))
    prop_type <- sample(c("Owner-Occupied", "Buy-to-Let"), n_loans, replace = TRUE, prob = c(0.85, 0.15))
  } else { # mixed_credit
    ltv <- pmin(pmax(rnorm(n_loans, mean = 0.73, sd = 0.14), 0.35), 0.95)
    credit_grades <- sample(c("AAA", "AA", "A", "BBB", "BB", "B"), n_loans, replace = TRUE, prob = c(0.25, 0.30, 0.22, 0.13, 0.07, 0.03))
    prop_type <- sample(c("Owner-Occupied", "Buy-to-Let"), n_loans, replace = TRUE, prob = c(0.70, 0.30))
  }

  raw_balances <- property_values * ltv
  scaling_factor <- target_notional / sum(raw_balances)
  current_balances <- round(raw_balances * scaling_factor, 2)
  orig_balances <- round(current_balances * runif(n_loans, min = 1.02, max = 1.15), 2)

  # Remaining term in months (120 to 360 months; standard 20-30 years)
  remaining_term_months <- sample(c(180, 240, 300, 360), n_loans, replace = TRUE, prob = c(0.10, 0.25, 0.45, 0.20))
  seasoning_months <- sample(6:48, n_loans, replace = TRUE)

  # Rate types: Fixed (5Y/2Y fix) vs Floating (SONIA tracker + margin)
  rate_type <- sample(c("Fixed", "Floating"), n_loans, replace = TRUE, prob = c(0.75, 0.25))

  # Coupon rates (annualized)
  base_sonia <- 0.0450 # 4.50% base rate
  spread <- ifelse(credit_grades %in% c("AAA", "AA"), 0.0125,
            ifelse(credit_grades == "A", 0.0175,
            ifelse(credit_grades == "BBB", 0.0240, 0.0350)))
  interest_rate <- round(base_sonia + spread + ifelse(rate_type == "Fixed", 0.0035, 0), 4)

  # Monthly contractual annuity payments
  monthly_r <- interest_rate / 12
  scheduled_payment <- round(current_balances * (monthly_r / (1 - (1 + monthly_r)^(-remaining_term_months))), 2)

  # DSTI (Debt Service to Income) and Delinquency state
  dsti_cat <- sample(c("<30%", "30-40%", "40-50%", ">50%"), n_loans, replace = TRUE, prob = c(0.40, 0.38, 0.16, 0.06))
  delinquency_state <- sample(c("Current", "30_Days_Arrears", "60_Days_Arrears", "90+_Days_Default"),
                              n_loans, replace = TRUE, prob = c(0.972, 0.018, 0.007, 0.003))

  portfolio_dt <- data.table::data.table(
    loan_id = loan_ids,
    country = "United Kingdom",
    currency = "GBP",
    region = loan_regions,
    property_type = prop_type,
    property_value = property_values,
    original_balance = orig_balances,
    current_balance = current_balances,
    ltv = round(current_balances / property_values, 4),
    credit_grade = credit_grades,
    rate_type = rate_type,
    contractual_rate = interest_rate,
    remaining_term_months = remaining_term_months,
    seasoning_months = seasoning_months,
    scheduled_payment = scheduled_payment,
    dsti_category = dsti_cat,
    delinquency_state = delinquency_state,
    liquidation_haircut = 0.22,
    synthetic_provenance = "RHINOBANK_SYNTHETIC_MODEL_DATA_ONLY"
  )

  return(portfolio_dt)
}

#' Stratify Portfolio Metrics
#'
#' @param portfolio_dt A data.table returned by generate_synthetic_portfolio.
#' @return A list of summary metrics and stratification tables.
#' @export
stratify_portfolio <- function(portfolio_dt) {
  total_balance <- sum(portfolio_dt$current_balance)
  wac <- sum(portfolio_dt$current_balance * portfolio_dt$contractual_rate) / total_balance
  wam <- sum(portfolio_dt$current_balance * portfolio_dt$remaining_term_months) / total_balance
  waltv <- sum(portfolio_dt$current_balance * portfolio_dt$ltv) / total_balance

  by_credit <- portfolio_dt[, .(
    count = .N,
    balance = sum(current_balance),
    pct_balance = sum(current_balance) / total_balance,
    wac = sum(current_balance * contractual_rate) / sum(current_balance),
    waltv = sum(current_balance * ltv) / sum(current_balance)
  ), by = credit_grade][order(-balance)]

  by_region <- portfolio_dt[, .(
    count = .N,
    balance = sum(current_balance),
    pct_balance = sum(current_balance) / total_balance
  ), by = region][order(-balance)]

  by_rate <- portfolio_dt[, .(
    count = .N,
    balance = sum(current_balance),
    pct_balance = sum(current_balance) / total_balance
  ), by = rate_type]

  list(
    total_loans = nrow(portfolio_dt),
    total_balance = total_balance,
    wac = wac,
    wam_months = wam,
    waltv = waltv,
    strat_credit = by_credit,
    strat_region = by_region,
    strat_rate = by_rate
  )
}
