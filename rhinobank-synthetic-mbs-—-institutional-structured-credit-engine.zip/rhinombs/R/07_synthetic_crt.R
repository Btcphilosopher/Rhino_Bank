#' Synthetic Credit-Risk Transfer (CRT) Structuring Module
#'
#' @description Models institutional synthetic risk transfer transactions for Rhino Bank,
#' distinguishing balance-sheet retained exposure from credit-protected notionals.
#'
#' @param reference_notional Numeric. Gross mortgage reference pool notional (e.g. 1e9).
#' @param retained_first_loss_detachment Numeric. Attachment/detachment of first-loss tranche (e.g. 0.025 for 2.5%).
#' @param mezzanine_detachment Numeric. Detachment point of mezzanine protection tranche (e.g. 0.095 for 9.5%).
#' @param protection_type Character. 'unfunded_financial_guarantee' or 'funded_credit_linked_note'.
#' @param protection_spread_bps Numeric. Annual protection premium paid by Rhino Bank (e.g. 320 bps).
#' @param counterparty_rating Character. 'AAA', 'AA', 'A'.
#' @param collateral_haircut Numeric. Haircut applied to posted collateral (e.g. 0.05).
#' @param protection_maturity_years Numeric. Contractual protection tenor (e.g. 5 years).
#' @return A synthetic CRT structure object.
#' @export
structure_synthetic_crt <- function(reference_notional = 1e9,
                                    retained_first_loss_detachment = 0.025,
                                    mezzanine_detachment = 0.095,
                                    protection_type = c("funded_credit_linked_note", "unfunded_financial_guarantee"),
                                    protection_spread_bps = 320,
                                    counterparty_rating = "AA",
                                    collateral_haircut = 0.05,
                                    protection_maturity_years = 5) {
  protection_type <- match.arg(protection_type)

  # Notional calculations
  first_loss_notional <- reference_notional * retained_first_loss_detachment
  mezzanine_notional <- reference_notional * (mezzanine_detachment - retained_first_loss_detachment)
  senior_retained_notional <- reference_notional * (1 - mezzanine_detachment)

  structure <- list(
    transaction_id = "RHN-SYNTH-MBS-2026-CR1",
    reference_notional = reference_notional,
    attachment_first_loss = 0.0,
    detachment_first_loss = retained_first_loss_detachment,
    first_loss_notional = first_loss_notional,
    attachment_mezzanine = retained_first_loss_detachment,
    detachment_mezzanine = mezzanine_detachment,
    protected_mezzanine_notional = mezzanine_notional,
    senior_retained_notional = senior_retained_notional,
    protection_type = protection_type,
    protection_spread_bps = protection_spread_bps,
    protection_maturity_years = protection_maturity_years,
    counterparty_rating = counterparty_rating,
    collateral_haircut = collateral_haircut,
    effective_collateral_factor = 1 - collateral_haircut,
    regulatory_disclaimer = paste(
      "DISCLAIMER: Model output is for hypothetical structuring analysis only.",
      "Achieving regulatory Significant Risk Transfer (SRT) under PRA SS1/23 and",
      "Securitisation Capital Requirements requires formal supervisory notifications,",
      "legal opinions, and transaction-specific regulatory verification."
    )
  )
  class(structure) <- c("rhinombs_synthetic_crt", "list")
  return(structure)
}

#' Calculate CRT Settlement and Cash Flows
#'
#' @param crt_structure A rhinombs_synthetic_crt object.
#' @param pool_cashflows data.table of reference pool cash flows.
#' @param discount_curve rhinombs_yield_curve object.
#' @return List of premium leg, protection leg, net present value, and counterparty exposure.
#' @export
calculate_crt_settlement <- function(crt_structure, pool_cashflows, discount_curve) {
  n_periods <- min(nrow(pool_cashflows), crt_structure$protection_maturity_years * 12)
  initial_bal <- crt_structure$reference_notional
  att <- crt_structure$attachment_mezzanine
  det <- crt_structure$detachment_mezzanine
  mezz_cap <- crt_structure$protected_mezzanine_notional

  annual_spread <- crt_structure$protection_spread_bps / 10000
  monthly_spread <- annual_spread / 12

  times <- seq_len(n_periods) / 12
  dfs <- discount_factors(discount_curve, times)

  cum_pool_loss <- 0
  active_protected_bal <- mezz_cap

  premium_payments <- numeric(n_periods)
  protection_recoveries <- numeric(n_periods)
  period_writedowns <- numeric(n_periods)
  collateral_held <- numeric(n_periods)

  for (t in seq_len(n_periods)) {
    cf <- pool_cashflows[t]
    cum_pool_loss <- cum_pool_loss + cf$net_losses
    cum_loss_frac <- cum_pool_loss / initial_bal

    # Mezzanine loss fraction
    mezz_loss_frac <- calculate_tranche_loss_fraction(cum_loss_frac, att, det)
    target_loss <- mezz_loss_frac * mezz_cap
    prior_loss <- mezz_cap - active_protected_bal
    new_writedown <- max(target_loss - prior_loss, 0)

    active_protected_bal <- max(active_protected_bal - new_writedown, 0)
    period_writedowns[t] <- new_writedown

    # Protection leg payment received by Rhino Bank from protection seller
    protection_recoveries[t] <- new_writedown

    # Premium leg paid by Rhino Bank to protection seller on remaining protected notional
    premium_payments[t] <- active_protected_bal * monthly_spread

    # Collateral held for counterparty risk mitigation
    if (crt_structure$protection_type == "funded_credit_linked_note") {
      collateral_held[t] <- active_protected_bal # 100% funded cash collateral
    } else {
      # Unfunded with margin agreement
      collateral_held[t] <- active_protected_bal * crt_structure$effective_collateral_factor
    }
  }

  pv_premium_leg <- sum(premium_payments * dfs)
  pv_protection_leg <- sum(protection_recoveries * dfs)
  net_crt_cost <- pv_premium_leg - pv_protection_leg

  list(
    periods = seq_len(n_periods),
    pv_premium_leg = pv_premium_leg,
    pv_protection_leg = pv_protection_leg,
    net_cost_to_originator = net_crt_cost,
    breakeven_spread_bps = (pv_protection_leg / sum(active_protected_bal * (1/12) * dfs)) * 10000,
    credit_event_payments = sum(protection_recoveries),
    collateral_coverage_ratio = mean(collateral_held) / mezz_cap,
    basis_risk_summary = "Zero basis risk (direct reference pool linkage; synthetic credit event matches reference mortgage defaults)."
  )
}
