#' Institutional Stress Testing and Reverse Stress Testing
#'
#' @description Evaluates mortgage portfolios under PRA/EBA-style macro scenarios
#' and computes boundary conditions that trigger tranche impairment or reserve exhaustion.
#'
#' @param capital_structure A rhinombs_capital_structure object.
#' @param initial_balance Numeric. Reference mortgage pool balance.
#' @return A data.table comparing outcomes across standard stress scenarios.
#' @export
run_stress_scenarios <- function(capital_structure, initial_balance = 1e9) {
  scenarios <- list(
    list(name = "Base Case", hpi = 0.0, unemployment = 0.042, rate_shock_bps = 0, cdr_mult = 1.0, recovery_rate = 0.72),
    list(name = "PRA Severe Macroeconomic Recession", hpi = -0.30, unemployment = 0.095, rate_shock_bps = 200, cdr_mult = 3.5, recovery_rate = 0.45),
    list(name = "UK Housing Crash (-25% HPI)", hpi = -0.25, unemployment = 0.060, rate_shock_bps = 50, cdr_mult = 2.2, recovery_rate = 0.52),
    list(name = "Stagflation & Rate Shock (+300 bps)", hpi = -0.15, unemployment = 0.075, rate_shock_bps = 300, cdr_mult = 2.8, recovery_rate = 0.55),
    list(name = "Rapid Rate Cut & Refi Surge (-250 bps)", hpi = 0.05, unemployment = 0.045, rate_shock_bps = -250, cdr_mult = 0.9, recovery_rate = 0.78),
    list(name = "Buy-to-Let Rental Yield Crisis", hpi = -0.20, unemployment = 0.065, rate_shock_bps = 150, cdr_mult = 3.0, recovery_rate = 0.50),
    list(name = "London & South East Regional Shock", hpi = -0.35, unemployment = 0.080, rate_shock_bps = 100, cdr_mult = 2.7, recovery_rate = 0.48),
    list(name = "Liquidity Squeeze & Spread Blowout (+450 bps)", hpi = -0.10, unemployment = 0.055, rate_shock_bps = 250, cdr_mult = 2.0, recovery_rate = 0.60),
    list(name = "Severe Recovery Haircut (Extended Foreclosure)", hpi = -0.20, unemployment = 0.060, rate_shock_bps = 0, cdr_mult = 1.8, recovery_rate = 0.38),
    list(name = "Correlated Mortgage Default Cluster", hpi = -0.22, unemployment = 0.085, rate_shock_bps = 150, cdr_mult = 4.2, recovery_rate = 0.46),
    list(name = "Unemployment Spike to 11.0%", hpi = -0.18, unemployment = 0.110, rate_shock_bps = 100, cdr_mult = 3.8, recovery_rate = 0.50),
    list(name = "Combined Severe Credit & Funding Run", hpi = -0.32, unemployment = 0.105, rate_shock_bps = 350, cdr_mult = 4.8, recovery_rate = 0.40)
  )

  results <- vector("list", length(scenarios))
  tranches <- capital_structure$tranches

  for (i in seq_along(scenarios)) {
    sc <- scenarios[[i]]

    # Cumulative 5-year stressed pool loss calculation
    base_5y_def <- 0.05
    stressed_def <- min(base_5y_def * sc$cdr_mult, 0.50)
    stressed_loss_rate <- stressed_def * (1 - sc$recovery_rate)
    pool_loss_gbp <- initial_balance * stressed_loss_rate

    # Compute tranche impairment
    tranche_hits <- character(0)
    for (k in seq_len(nrow(tranches))) {
      att <- tranches$attachment_pt[k]
      det <- tranches$detachment_pt[k]
      frac <- calculate_tranche_loss_fraction(stressed_loss_rate, att, det)
      if (frac > 0) {
        tranche_hits <- c(tranche_hits, sprintf("%s (%.1f%%)", tranches$tranche_id[k], frac * 100))
      }
    }

    results[[i]] <- data.table::data.table(
      scenario_name = sc$name,
      hpi_shock_pct = sc$hpi * 100,
      unemployment_rate = sc$unemployment * 100,
      rate_shock_bps = sc$rate_shock_bps,
      recovery_rate = sc$recovery_rate * 100,
      cum_pool_loss_pct = round(stressed_loss_rate * 100, 2),
      cum_pool_loss_gbp = round(pool_loss_gbp, 0),
      impaired_tranches = if (length(tranche_hits) == 0) "None" else paste(tranche_hits, collapse = ", ")
    )
  }

  out_dt <- data.table::rbindlist(results)
  return(out_dt)
}

#' Reverse Stress Testing Solver
#'
#' @description Solves for the minimal macroeconomic stress condition (e.g. HPI decline or default rate)
#' that breaches a specified target loss threshold or causes first impairment of a named tranche.
#'
#' @param capital_structure A rhinombs_capital_structure object.
#' @param target_tranche_id Character. Tranche ID to stress to impairment threshold.
#' @param initial_balance Numeric. Pool notional.
#' @return List with critical boundary thresholds and sensitivity explanation.
#' @export
reverse_stress_test <- function(capital_structure,
                                target_tranche_id = "Class B (Mezzanine)",
                                initial_balance = 1e9) {
  tranches <- capital_structure$tranches
  row_idx <- which(tranches$tranche_id == target_tranche_id)
  if (length(row_idx) == 0) stop("Target tranche ID not found in capital structure.")

  attachment_pt <- tranches$attachment_pt[row_idx]
  # Pool loss required to hit attachment point:
  breach_loss_fraction <- attachment_pt
  breach_loss_gbp <- initial_balance * breach_loss_fraction

  # Under standard recovery (0.70), required cumulative default rate:
  required_default_rate_70rec <- breach_loss_fraction / (1 - 0.70)

  # Under severe recovery (0.50):
  required_default_rate_50rec <- breach_loss_fraction / (1 - 0.50)

  list(
    target_tranche = target_tranche_id,
    attachment_point = attachment_pt,
    critical_pool_loss_fraction = breach_loss_fraction,
    critical_pool_loss_gbp = breach_loss_gbp,
    required_cum_default_rate_base_rec = required_default_rate_70rec,
    required_cum_default_rate_stressed_rec = required_default_rate_50rec,
    implied_hpi_shock_at_base_defaults = sprintf("-%.1f%% HPI decline required", min((1 - (0.75 * (1 - breach_loss_fraction))) * 100, 65)),
    governance_label = "MODEL_DERIVED_BOUNDARY_CONDITION_NOT_PREDICTION"
  )
}
