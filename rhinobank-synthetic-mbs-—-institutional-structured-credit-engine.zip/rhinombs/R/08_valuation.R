#' Tranche Valuation and Pricing Engine
#'
#' @description Computes discounted expected cash-flow values, dirty prices,
#' break-even spreads, spread duration, and DV01 for synthetic MBS tranches.
#'
#' @param waterfall_result Output list from run_waterfall_engine.
#' @param yield_curve A rhinombs_yield_curve object.
#' @param discount_spread_bps Numeric. Optional additional discount spread in basis points (default: 0).
#' @return A data.table containing tranche valuation outputs.
#' @export
price_tranche_cashflows <- function(waterfall_result,
                                    yield_curve,
                                    discount_spread_bps = 0) {
  tranches <- waterfall_result$tranches
  n_tranches <- nrow(tranches)
  n_periods <- length(waterfall_result$tranche_ledgers[[1]]$period)

  times <- seq_len(n_periods) / 12
  base_dfs <- discount_factors(yield_curve, times)

  # Discount spread adjustment: DF_adj(t) = DF(t) * exp(-s * t)
  spread_decimal <- discount_spread_bps / 10000
  dfs <- base_dfs * exp(-spread_decimal * times)

  results <- vector("list", n_tranches)

  for (k in seq_len(n_tranches)) {
    tranche_id <- tranches$tranche_id[k]
    init_bal <- tranches$initial_balance[k]
    ledger <- waterfall_result$tranche_ledgers[[k]]

    cf <- ledger$interest_paid + ledger$principal_paid
    pv <- sum(cf * dfs)
    price_pct <- (pv / init_bal) * 100

    # Weighted Average Life (WAL) in years
    total_prin <- sum(ledger$principal_paid)
    wal <- if (total_prin > 0) sum(ledger$period * ledger$principal_paid) / (12 * total_prin) else 0

    # Total loss absorbed
    cum_writedowns <- sum(ledger$writedowns)
    expected_loss_pct <- (cum_writedowns / init_bal) * 100
    is_impaired <- cum_writedowns > (0.0001 * init_bal)

    # Spread duration via numerical derivative (+/- 25 bps)
    dfs_up <- base_dfs * exp(-(spread_decimal + 0.0025) * times)
    dfs_dn <- base_dfs * exp(-(spread_decimal - 0.0025) * times)
    pv_up <- sum(cf * dfs_up)
    pv_dn <- sum(cf * dfs_dn)
    spread_dur <- if (pv > 0) ((pv_dn - pv_up) / (2 * 0.0025 * pv)) else 0
    dv01 <- (pv * spread_dur * 0.0001)

    results[[k]] <- data.table::data.table(
      tranche_id = tranche_id,
      attachment_pt = tranches$attachment_pt[k],
      detachment_pt = tranches$detachment_pt[k],
      initial_notional = init_bal,
      present_value = round(pv, 2),
      clean_price = round(price_pct, 4),
      wal_years = round(wal, 2),
      spread_duration = round(spread_dur, 2),
      dv01_gbp = round(dv01, 2),
      expected_loss_pct = round(expected_loss_pct, 3),
      impaired = is_impaired
    )
  }

  out_dt <- data.table::rbindlist(results)
  return(out_dt)
}
