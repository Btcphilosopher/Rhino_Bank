#' Prepayment and Refinancing Analytics Engine
#'
#' @description Models mortgage prepayments via baseline CPR/SMM, seasoning ramp,
#' and interest-rate refinancing incentive curves.
#'
#' @param cpr Numeric. Annualised Conditional Prepayment Rate.
#' @return Monthly SMM (Single Monthly Mortality).
#' @export
prepayment_cpr_smm <- function(cpr) {
  stopifnot(all(cpr >= 0 & cpr <= 1))
  1 - (1 - cpr)^(1/12)
}

#' Refinancing Incentive and Seasoning Curve
#'
#' @param wac Numeric. Weighted Average Coupon of mortgage pool.
#' @param refi_rate_vector Numeric vector. Market mortgage rate available for refinancing per period.
#' @param loan_age_months Integer vector. Loan age in months for seasoning adjustment.
#' @param base_turnover_cpr Numeric. Background housing turnover CPR (e.g. 0.05).
#' @param max_refi_cpr Numeric. Maximum prepayment rate during heavy refinancing (e.g. 0.40).
#' @return Vector of projected CPRs per period.
#' @export
refinancing_incentive_curve <- function(wac = 0.055,
                                        refi_rate_vector = rep(0.045, 120),
                                        loan_age_months = 1:120,
                                        base_turnover_cpr = 0.05,
                                        max_refi_cpr = 0.35) {
  n <- length(refi_rate_vector)

  # PSA-style seasoning factor: ramps linearly up to month 30, then 100%
  seasoning_factor <- pmin(loan_age_months / 30, 1.0)

  # Refinancing incentive: interest rate differential in percentage points
  diff_bps <- (wac - refi_rate_vector) * 10000

  # S-curve response function: 1 / (1 + exp(-k * (diff - threshold)))
  # Inflection at 100 bps spread advantage
  refi_component <- max_refi_cpr / (1 + exp(-0.012 * (diff_bps - 100)))

  cpr_projected <- (base_turnover_cpr + refi_component) * seasoning_factor
  cpr_projected <- pmin(pmax(cpr_projected, 0.01), max_refi_cpr)

  return(cpr_projected)
}

#' Calculate Weighted Average Life (WAL)
#'
#' @param periods Integer vector of period months.
#' @param principal_vector Numeric vector of principal received (scheduled + prepay + recoveries).
#' @return Weighted Average Life in years.
#' @export
calculate_wal <- function(periods, principal_vector) {
  total_prin <- sum(principal_vector)
  if (total_prin <= 0) return(0)
  wal_months <- sum(periods * principal_vector) / total_prin
  return(wal_months / 12)
}
