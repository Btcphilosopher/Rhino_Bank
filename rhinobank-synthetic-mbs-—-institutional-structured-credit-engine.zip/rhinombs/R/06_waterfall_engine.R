#' MBS Cash-Flow and Tranche Waterfall Engine
#'
#' @description Computes multi-tranche liability allocations, interest coupons,
#' principal amortization, write-downs, reserve account mechanics, and triggers.
#'
#' @param tranche_table data.table containing:
#'   - tranche_id: Character ('Class A (Senior)', 'Class B (Mezzanine)', etc.)
#'   - attachment_pt: Numeric (e.g. 0.12 for 12%)
#'   - detachment_pt: Numeric (e.g. 1.00 for 100%)
#'   - coupon_spread: Numeric (annual spread over SONIA, e.g. 0.0080)
#'   - initial_balance: Numeric
#' @return Validated tranche structure list.
#' @export
build_tranche_structure <- function(tranche_table) {
  dt <- data.table::as.data.table(tranche_table)

  # Validation checks
  for (i in seq_len(nrow(dt))) {
    A <- dt$attachment_pt[i]
    D <- dt$detachment_pt[i]
    if (D <= A) {
      stop(sprintf("Invalid tranche boundaries for %s: Detachment point (%.4f) must be strictly greater than Attachment point (%.4f).",
                   dt$tranche_id[i], D, A))
    }
    if (A < 0 || D > 1.0001) {
      stop(sprintf("Tranche %s boundaries [A=%.4f, D=%.4f] outside [0, 1] range.",
                   dt$tranche_id[i], A, D))
    }
  }

  structure <- list(
    tranches = dt,
    total_capital = sum(dt$initial_balance)
  )
  class(structure) <- c("rhinombs_capital_structure", "list")
  return(structure)
}

#' Tranche Loss Fraction Function
#'
#' @description Implements the canonical structured finance formula:
#' min(max((Portfolio_Loss - A) / (D - A), 0), 1)
#'
#' @param cumulative_portfolio_loss Numeric. Cumulative portfolio loss as a fraction of initial balance.
#' @param attachment_pt Numeric. Attachment point A.
#' @param detachment_pt Numeric. Detachment point D.
#' @return Tranche loss fraction between 0.0 and 1.0.
#' @export
calculate_tranche_loss_fraction <- function(cumulative_portfolio_loss, attachment_pt, detachment_pt) {
  if (detachment_pt <= attachment_pt) {
    stop("Detachment point must be strictly greater than attachment point.")
  }
  loss_fraction <- (cumulative_portfolio_loss - attachment_pt) / (detachment_pt - attachment_pt)
  return(min(max(loss_fraction, 0.0), 1.0))
}

#' Run Period-by-Period MBS Waterfall Engine
#'
#' @param capital_structure A rhinombs_capital_structure object.
#' @param pool_cashflows data.table output from run_portfolio_cashflows.
#' @param base_benchmark_rate Numeric. Current SONIA benchmark rate (e.g. 0.0450).
#' @param reserve_fund_target Numeric. Target reserve account balance.
#' @param cumulative_loss_trigger Numeric. Threshold triggering switch to strictly sequential amortization (e.g. 0.025).
#' @param delinquency_trigger Numeric. 90+ days delinquency trigger threshold (e.g. 0.035).
#' @return Detailed list containing period tranche ledgers, waterfall validation checks, and summary performance.
#' @export
run_waterfall_engine <- function(capital_structure,
                                 pool_cashflows,
                                 base_benchmark_rate = 0.045,
                                 reserve_fund_target = 1.5e7,
                                 cumulative_loss_trigger = 0.025,
                                 delinquency_trigger = 0.035) {

  tranches <- copy(capital_structure$tranches)
  n_tranches <- nrow(tranches)
  n_periods <- nrow(pool_cashflows)
  initial_pool_balance <- pool_cashflows$opening_balance[1]

  # Reserve fund initialization
  reserve_balance <- reserve_fund_target

  # Track opening and current balances for each tranche
  current_tranche_balances <- tranches$initial_balance
  cumulative_pool_loss <- 0.0

  # History storage
  tranche_history <- vector("list", n_tranches)
  for (k in seq_len(n_tranches)) {
    tranche_history[[k]] <- data.table::data.table(
      period = integer(n_periods),
      opening_balance = numeric(n_periods),
      interest_due = numeric(n_periods),
      interest_paid = numeric(n_periods),
      principal_paid = numeric(n_periods),
      writedowns = numeric(n_periods),
      closing_balance = numeric(n_periods)
    )
  }

  waterfall_ledger <- data.table::data.table(
    period = integer(n_periods),
    available_principal = numeric(n_periods),
    allocated_principal = numeric(n_periods),
    available_interest = numeric(n_periods),
    allocated_interest = numeric(n_periods),
    reserve_fund_balance = numeric(n_periods),
    trigger_breached = logical(n_periods),
    excess_spread = numeric(n_periods)
  )

  # Period loop
  for (t in seq_len(n_periods)) {
    p_cf <- pool_cashflows[t]
    avail_prin <- p_cf$total_principal
    avail_int <- p_cf$net_interest_available

    # Update cumulative pool loss
    cumulative_pool_loss <- cumulative_pool_loss + p_cf$net_losses
    cum_loss_fraction <- cumulative_pool_loss / initial_pool_balance

    # Trigger evaluation: If cumulative losses exceed threshold, lock waterfall into strictly sequential
    is_trigger_tripped <- (cum_loss_fraction >= cumulative_loss_trigger)

    # 1. Tranche write-down allocation based on attachment & detachment points
    # Priority: Subordinated/Equity tranches absorb losses before Mezzanine and Senior
    for (k in rev(seq_len(n_tranches))) { # iterate junior to senior
      att <- tranches$attachment_pt[k]
      det <- tranches$detachment_pt[k]
      tranche_cap <- (det - att) * initial_pool_balance

      # Tranche loss fraction
      frac <- calculate_tranche_loss_fraction(cum_loss_fraction, att, det)
      target_cumulative_loss <- frac * tranche_cap

      # Previous cumulative write-downs
      prev_loss <- tranches$initial_balance[k] - current_tranche_balances[k]
      incremental_writedown <- max(target_cumulative_loss - prev_loss, 0)
      incremental_writedown <- min(incremental_writedown, current_tranche_balances[k])

      current_tranche_balances[k] <- current_tranche_balances[k] - incremental_writedown
    }

    # 2. Interest payment waterfall (Senior to Junior)
    period_int_avail <- avail_int
    for (k in seq_len(n_tranches)) {
      op_bal <- current_tranche_balances[k]
      coupon_rate <- base_benchmark_rate + tranches$coupon_spread[k]
      int_due <- op_bal * (coupon_rate / 12)

      int_paid <- min(period_int_avail, int_due)
      period_int_avail <- period_int_avail - int_paid

      tranche_history[[k]]$interest_due[t] <- int_due
      tranche_history[[k]]$interest_paid[t] <- int_paid
      tranche_history[[k]]$opening_balance[t] <- op_bal
    }

    # If interest shortfall, tap reserve fund
    if (period_int_avail < 0 && reserve_balance > 0) {
      drawdown <- min(abs(period_int_avail), reserve_balance)
      reserve_balance <- reserve_balance - drawdown
      period_int_avail <- period_int_avail + drawdown
    }

    # 3. Principal payment waterfall
    # Sequential allocation: Senior tranches paid down first
    period_prin_avail <- avail_prin
    total_prin_allocated <- 0

    for (k in seq_len(n_tranches)) {
      if (period_prin_avail <= 0 || current_tranche_balances[k] <= 0) {
        tranche_history[[k]]$principal_paid[t] <- 0
        tranche_history[[k]]$closing_balance[t] <- current_tranche_balances[k]
        next
      }

      prin_paid <- min(period_prin_avail, current_tranche_balances[k])
      period_prin_avail <- period_prin_avail - prin_paid
      total_prin_allocated <- total_prin_allocated + prin_paid

      current_tranche_balances[k] <- current_tranche_balances[k] - prin_paid
      tranche_history[[k]]$principal_paid[t] <- prin_paid
      tranche_history[[k]]$closing_balance[t] <- current_tranche_balances[k]
    }

    # Excess spread replenishes reserve fund or flows to residual equity
    excess_spread <- max(period_int_avail, 0)
    if (reserve_balance < reserve_fund_target && excess_spread > 0) {
      replenish <- min(reserve_fund_target - reserve_balance, excess_spread)
      reserve_balance <- reserve_balance + replenish
      excess_spread <- excess_spread - replenish
    }

    waterfall_ledger$period[t] <- t
    waterfall_ledger$available_principal[t] <- avail_prin
    waterfall_ledger$allocated_principal[t] <- total_prin_allocated
    waterfall_ledger$available_interest[t] <- avail_int
    waterfall_ledger$allocated_interest[t] <- avail_int - period_int_avail
    waterfall_ledger$reserve_fund_balance[t] <- reserve_balance
    waterfall_ledger$trigger_breached[t] <- is_trigger_tripped
    waterfall_ledger$excess_spread[t] <- excess_spread
  }

  for (k in seq_len(n_tranches)) {
    tranche_history[[k]]$tranche_id <- tranches$tranche_id[k]
  }

  # Conservation check validation: Total principal allocated must match available principal
  validation_ok <- validate_waterfall_conservation(waterfall_ledger, pool_cashflows)

  list(
    tranches = tranches,
    tranche_ledgers = tranche_history,
    waterfall_ledger = waterfall_ledger,
    final_tranche_balances = current_tranche_balances,
    conservation_validated = validation_ok
  )
}

#' Validate Waterfall Cash-Flow Conservation
#'
#' @param waterfall_ledger data.table of waterfall outcomes.
#' @param pool_cashflows data.table of original pool cash flows.
#' @return Logical TRUE if conservation laws hold.
#' @export
validate_waterfall_conservation <- function(waterfall_ledger, pool_cashflows) {
  diff_prin <- abs(sum(waterfall_ledger$allocated_principal) - sum(pool_cashflows$total_principal))
  # Acceptable tolerance for floating-point rounding
  is_conserved <- diff_prin < 100.0
  return(is_conserved)
}
