#' Interest-Rate and Yield-Curve Engine
#'
#' @description Constructs institutional discount curves, forward rates,
#' and handles scenario rate shifts (parallel, steepening, flattening, butterfly).
#'
#' @param maturities Numeric vector of tenors in years (e.g. c(0.25, 0.5, 1, 2, 3, 5, 10, 20, 30)).
#' @param zero_rates Numeric vector of zero rates corresponding to maturities.
#' @param curve_id Character identifier (e.g., 'GBP_SONIA_BENCHMARK').
#' @return A yield curve object list.
#' @export
build_yield_curve <- function(maturities = c(0.25, 0.5, 1, 2, 3, 5, 7, 10, 15, 20, 30),
                              zero_rates = c(0.048, 0.046, 0.044, 0.042, 0.040, 0.038, 0.039, 0.041, 0.043, 0.044, 0.045),
                              curve_id = "GBP_SONIA_SIMULATED") {
  stopifnot(length(maturities) == length(zero_rates))
  stopifnot(is.unsorted(maturities) == FALSE)

  curve <- list(
    curve_id = curve_id,
    currency = "GBP",
    compounding = "continuous",
    data_status = "SIMULATED_RESEARCH_ONLY",
    maturities = maturities,
    zero_rates = zero_rates,
    timestamp = Sys.time()
  )
  class(curve) <- c("rhinombs_yield_curve", "list")
  return(curve)
}

#' Discount Factors from Yield Curve
#'
#' @param curve A rhinombs_yield_curve object.
#' @param times_years Numeric vector of payment times in years.
#' @return Numeric vector of discount factors DF(t).
#' @export
discount_factors <- function(curve, times_years) {
  # Linear interpolation of zero rates
  interpolated_rates <- approx(x = curve$maturities, y = curve$zero_rates,
                               xout = times_years, rule = 2)$y

  # Continuous compounding: DF(t) = exp(-r(t) * t)
  dfs <- exp(-interpolated_rates * times_years)
  return(dfs)
}

#' Scenario Yield Curve Shifts
#'
#' @param curve A rhinombs_yield_curve object.
#' @param shift_type Character. 'parallel', 'steepen', 'flatten', 'butterfly'.
#' @param magnitude_bps Numeric. Shift size in basis points (e.g. 100 for +1.00%).
#' @return Modified rhinombs_yield_curve object.
#' @export
shift_yield_curve <- function(curve,
                              shift_type = c("parallel", "steepen", "flatten", "butterfly"),
                              magnitude_bps = 100) {
  shift_type <- match.arg(shift_type)
  delta_r <- magnitude_bps / 10000

  m <- curve$maturities
  if (shift_type == "parallel") {
    new_rates <- curve$zero_rates + delta_r
  } else if (shift_type == "steepen") {
    # Short rates fall or stay flat; long rates rise
    slope_weight <- (m - min(m)) / (max(m) - min(m))
    new_rates <- curve$zero_rates + delta_r * (slope_weight - 0.5) * 2
  } else if (shift_type == "flatten") {
    slope_weight <- (m - min(m)) / (max(m) - min(m))
    new_rates <- curve$zero_rates - delta_r * (slope_weight - 0.5) * 2
  } else if (shift_type == "butterfly") {
    # 2Y and 30Y move in opposite direction to 5-10Y
    center <- (min(m) + max(m)) / 2
    curvature <- -4 * ((m - min(m)) / (max(m) - min(m)) - 0.5)^2 + 1
    new_rates <- curve$zero_rates + delta_r * curvature
  }

  curve$zero_rates <- pmax(new_rates, 0.0001)
  curve$curve_id <- paste0(curve$curve_id, "_", toupper(shift_type), "_", magnitude_bps, "BPS")
  return(curve)
}
