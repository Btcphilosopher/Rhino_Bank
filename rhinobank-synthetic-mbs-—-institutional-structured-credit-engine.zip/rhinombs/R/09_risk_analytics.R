#' Credit, Market, and Liquidity Risk Sensitivities
#'
#' @description Computes key-rate durations, parallel DV01, spread duration,
#' and concentration risk metrics for MBS portfolios.
#'
#' @param waterfall_result Output list from run_waterfall_engine.
#' @param yield_curve A rhinombs_yield_curve object.
#' @return Comprehensive risk sensitivity summary list.
#' @export
calculate_risk_sensitivities <- function(waterfall_result, yield_curve) {
  base_valuation <- price_tranche_cashflows(waterfall_result, yield_curve)

  # Curve parallel up (+100 bps) and down (-100 bps)
  curve_up <- shift_yield_curve(yield_curve, "parallel", 100)
  curve_dn <- shift_yield_curve(yield_curve, "parallel", -100)

  val_up <- price_tranche_cashflows(waterfall_result, curve_up)
  val_dn <- price_tranche_cashflows(waterfall_result, curve_dn)

  # Key-rate tenors
  key_tenors <- c(1, 2, 5, 10)
  key_rate_durations <- vector("list", length(key_tenors))

  for (i in seq_along(key_tenors)) {
    tenor <- key_tenors[i]
    # Localised bump of zero rate at tenor (+25 bps)
    bumped_curve <- yield_curve
    idx <- which.min(abs(bumped_curve$maturities - tenor))
    bumped_curve$zero_rates[idx] <- bumped_curve$zero_rates[idx] + 0.0025

    val_bump <- price_tranche_cashflows(waterfall_result, bumped_curve)
    krd <- (base_valuation$present_value - val_bump$present_value) / (0.0025 * base_valuation$present_value)
    key_rate_durations[[i]] <- krd
  }

  names(key_rate_durations) <- paste0("krd_", key_tenors, "y")

  list(
    portfolio_pv = sum(base_valuation$present_value),
    portfolio_dv01 = sum(base_valuation$dv01_gbp),
    tranche_valuations = base_valuation,
    rate_sensitivity = data.table::data.table(
      tranche_id = base_valuation$tranche_id,
      base_pv = base_valuation$present_value,
      pv_up_100bps = val_up$present_value,
      pv_dn_100bps = val_dn$present_value,
      effective_duration = round((val_dn$present_value - val_up$present_value) / (2 * 0.01 * base_valuation$present_value), 2)
    ),
    key_rate_durations = key_rate_durations
  )
}
