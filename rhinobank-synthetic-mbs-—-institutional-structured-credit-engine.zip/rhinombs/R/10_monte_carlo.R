#' Monte Carlo Portfolio Simulation Engine
#'
#' @description Runs stochastic credit-loss and prepayment simulations using a Gaussian
#' common-factor copula model with configurable correlation rho.
#'
#' @param capital_structure A rhinombs_capital_structure object.
#' @param n_simulations Integer. Number of Monte Carlo iterations (e.g. 1000).
#' @param initial_balance Numeric. Reference mortgage pool balance.
#' @param base_wac Numeric. Weighted average coupon.
#' @param base_wam Integer. Weighted average maturity in months.
#' @param asset_correlation Numeric. Systemic factor correlation rho (default: 0.18 per Basel mortgage IRB).
#' @param seed Integer. Deterministic simulation seed.
#' @return Comprehensive Monte Carlo simulation results list.
#' @export
run_monte_carlo_mbs <- function(capital_structure,
                                n_simulations = 1000,
                                initial_balance = 1e9,
                                base_wac = 0.055,
                                base_wam = 300,
                                asset_correlation = 0.18,
                                seed = 42) {
  set.seed(seed)
  tranches <- capital_structure$tranches
  n_tranches <- nrow(tranches)

  # Systemic macroeconomic factors Z ~ N(0, 1)
  Z_macro <- rnorm(n_simulations, mean = 0, sd = 1)

  # Output arrays
  pool_loss_amounts <- numeric(n_simulations)
  pool_loss_pcts <- numeric(n_simulations)
  tranche_losses <- matrix(0, nrow = n_simulations, ncol = n_tranches)
  colnames(tranche_losses) <- tranches$tranche_id

  base_cpr <- 0.08
  base_cdr <- 0.012

  for (i in seq_len(n_simulations)) {
    z <- Z_macro[i]
    eps <- rnorm(1, mean = 0, sd = 1)

    # Asset return: Y = sqrt(rho)*Z + sqrt(1 - rho)*eps
    Y <- sqrt(asset_correlation) * z + sqrt(1 - asset_correlation) * eps

    # Conditional default rate via Vasicek transform:
    # Stressed CDR increases when macro return Y is negative
    macro_mult <- exp(-0.65 * Y)
    sim_cdr <- min(base_cdr * macro_mult, 0.25)

    # Prepayments: inversely related to rate/economic stress
    sim_cpr <- max(min(base_cpr * exp(0.35 * Y), 0.35), 0.01)

    # Simplified 60-month horizon cumulative loss approximation
    # Cumulative gross default rate over 5 years
    cum_default_rate <- 1 - (1 - sim_cdr)^5
    recovery_rate <- max(0.70 - 0.15 * max(-z, 0), 0.35) # recovery falls in severe stress
    cum_loss_rate <- cum_default_rate * (1 - recovery_rate)

    loss_gbp <- initial_balance * cum_loss_rate
    pool_loss_amounts[i] <- loss_gbp
    pool_loss_pcts[i] <- cum_loss_rate * 100

    # Tranche loss absorption
    for (k in seq_len(n_tranches)) {
      att <- tranches$attachment_pt[k]
      det <- tranches$detachment_pt[k]
      frac <- calculate_tranche_loss_fraction(cum_loss_rate, att, det)
      tranche_losses[i, k] <- frac * tranches$initial_balance[k]
    }
  }

  # Risk analytics: VaR and Expected Shortfall
  sorted_losses <- sort(pool_loss_amounts)
  var_95 <- quantile(pool_loss_amounts, 0.95)
  var_99 <- quantile(pool_loss_amounts, 0.99)
  var_999 <- quantile(pool_loss_amounts, 0.999)

  es_99 <- mean(pool_loss_amounts[pool_loss_amounts >= var_99])
  es_999 <- mean(pool_loss_amounts[pool_loss_amounts >= var_999])

  # Convergence diagnostics (running mean of pool loss)
  running_mean <- cumsum(pool_loss_amounts) / seq_len(n_simulations)
  running_se <- sd(pool_loss_amounts) / sqrt(seq_len(n_simulations))

  # Tranche impairment frequencies
  tranche_impairment_prob <- colMeans(tranche_losses > 0)

  list(
    n_simulations = n_simulations,
    seed = seed,
    asset_correlation = asset_correlation,
    mean_pool_loss_gbp = mean(pool_loss_amounts),
    mean_pool_loss_pct = mean(pool_loss_pcts),
    var_95_gbp = as.numeric(var_95),
    var_99_gbp = as.numeric(var_99),
    var_999_gbp = as.numeric(var_999),
    expected_shortfall_99_gbp = es_99,
    expected_shortfall_999_gbp = es_999,
    convergence = data.table::data.table(
      iteration = seq_len(n_simulations),
      running_mean = running_mean,
      standard_error = running_se
    ),
    tranche_summary = data.table::data.table(
      tranche_id = tranches$tranche_id,
      mean_loss_gbp = colMeans(tranche_losses),
      impairment_probability = tranche_impairment_prob
    )
  )
}
