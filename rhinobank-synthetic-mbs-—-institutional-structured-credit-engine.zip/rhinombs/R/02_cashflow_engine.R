#' Mortgage-Level and Pool-Level Cash-Flow Engine
#'
#' @description Computes monthly deterministic or scenario-conditioned amortisation,
#' interest, prepayments, defaults, and recoveries over time.
#'
#' @param initial_balance Numeric. Aggregate opening pool balance.
#' @param wac Numeric. Weighted average coupon (annualised decimal).
#' @param wam Integer. Weighted average maturity in months.
#' @param cpr_vector Numeric vector. Annualised conditional prepayment rates per month.
#' @param cdr_vector Numeric vector. Annualised conditional default rates per month.
#' @param recovery_rate Numeric. Assumed net recovery percentage upon liquidation (0 to 1).
#' @param recovery_lag Integer. Months lag between default and recovery receipt.
#' @param servicing_fee_rate Numeric. Annualised servicing cost (e.g. 0.0025 for 25 bps).
#' @return A data.table containing monthly projection ledgers.
#' @export
run_portfolio_cashflows <- function(initial_balance = 1e9,
                                    wac = 0.055,
                                    wam = 300,
                                    cpr_vector = rep(0.08, 120),
                                    cdr_vector = rep(0.012, 120),
                                    recovery_rate = 0.70,
                                    recovery_lag = 6,
                                    servicing_fee_rate = 0.0025) {

  n_periods <- length(cpr_vector)
  stopifnot(n_periods == length(cdr_vector))

  # Pre-allocate output arrays
  period <- seq_len(n_periods)
  opening_balance <- numeric(n_periods)
  scheduled_principal <- numeric(n_periods)
  prepaid_principal <- numeric(n_periods)
  gross_defaults <- numeric(n_periods)
  recoveries <- numeric(n_periods)
  net_losses <- numeric(n_periods)
  interest_received <- numeric(n_periods)
  servicing_fees <- numeric(n_periods)
  closing_balance <- numeric(n_periods)
  total_principal_available <- numeric(n_periods)

  current_bal <- initial_balance
  pending_recoveries <- rep(0, n_periods + recovery_lag + 12)

  # Convert annualised CPR to Single Monthly Mortality (SMM): SMM = 1 - (1 - CPR)^(1/12)
  smm_vector <- 1 - (1 - cpr_vector)^(1/12)
  # Convert annualised CDR to Monthly Default Rate (MDR): MDR = 1 - (1 - CDR)^(1/12)
  mdr_vector <- 1 - (1 - cdr_vector)^(1/12)

  for (t in seq_len(n_periods)) {
    if (current_bal <= 1.0) {
      opening_balance[t] <- 0
      closing_balance[t] <- 0
      next
    }

    opening_balance[t] <- current_bal
    monthly_rate <- wac / 12
    remaining_periods <- max(wam - t + 1, 1)

    # Monthly annuity factor for scheduled amortisation
    annuity_factor <- (monthly_rate * (1 + monthly_rate)^remaining_periods) /
                      ((1 + monthly_rate)^remaining_periods - 1)
    scheduled_pmt <- current_bal * annuity_factor

    sched_interest <- current_bal * monthly_rate
    sched_prin <- min(scheduled_pmt - sched_interest, current_bal)
    sched_prin <- max(sched_prin, 0)
    scheduled_principal[t] <- sched_prin

    bal_after_sched <- max(current_bal - sched_prin, 0)

    # Prepayment calculation: SMM applied to balance after scheduled principal
    prepay <- bal_after_sched * smm_vector[t]
    prepaid_principal[t] <- prepay
    bal_after_prepay <- max(bal_after_sched - prepay, 0)

    # Default calculation: MDR applied to performing balance
    def <- bal_after_prepay * mdr_vector[t]
    gross_defaults[t] <- def

    # Schedule future recovery
    rec_amount <- def * recovery_rate
    pending_recoveries[t + recovery_lag] <- pending_recoveries[t + recovery_lag] + rec_amount
    net_losses[t] <- def * (1 - recovery_rate)

    # Recoveries received in current period
    recoveries[t] <- pending_recoveries[t]

    interest_received[t] <- sched_interest
    servicing_fees[t] <- current_bal * (servicing_fee_rate / 12)

    current_bal <- max(bal_after_prepay - def, 0)
    closing_balance[t] <- current_bal

    # Total principal generated = scheduled + prepaid + recoveries
    total_principal_available[t] <- scheduled_principal[t] + prepaid_principal[t] + recoveries[t]
  }

  dt <- data.table::data.table(
    period = period,
    opening_balance = opening_balance,
    scheduled_principal = scheduled_principal,
    prepaid_principal = prepaid_principal,
    gross_defaults = gross_defaults,
    recoveries = recoveries,
    net_losses = net_losses,
    total_principal = total_principal_available,
    interest_received = interest_received,
    servicing_fees = servicing_fees,
    net_interest_available = pmax(interest_received - servicing_fees, 0),
    closing_balance = closing_balance
  )

  return(dt)
}
