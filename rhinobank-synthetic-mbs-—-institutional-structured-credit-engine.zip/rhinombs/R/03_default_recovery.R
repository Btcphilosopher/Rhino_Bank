#' Default and Recovery Models for Synthetic Mortgage Reference Pools
#'
#' @description Implements hazard rate default modeling, LTV-driven recovery calculations,
#' and multi-period discounted Expected Credit Loss (ECL).
#'
#' @param base_pd Numeric. Baseline annual probability of default.
#' @param ltv Numeric. Current loan-to-value ratio.
#' @param credit_grade Character. Rating band ('AAA', 'AA', 'A', 'BBB', 'BB', 'B').
#' @param macro_shock_factor Numeric. Macroeconomic shock multiplier (e.g. 1.5 for stress).
#' @return Modeled annual default probability (PD).
#' @export
default_hazard_rate <- function(base_pd = 0.012,
                                ltv = 0.70,
                                credit_grade = "A",
                                macro_shock_factor = 1.0) {
  # Grade multiplier
  grade_mult <- switch(credit_grade,
    "AAA" = 0.25,
    "AA"  = 0.50,
    "A"   = 1.00,
    "BBB" = 2.20,
    "BB"  = 4.50,
    "B"   = 8.00,
    1.00
  )

  # Non-linear LTV acceleration penalty for high-LTV loans
  ltv_penalty <- exp(2.5 * max(ltv - 0.70, 0))

  pd <- base_pd * grade_mult * ltv_penalty * macro_shock_factor
  return(min(pmax(pd, 0.0001), 0.9999))
}

#' Loss Given Default (LGD) with Property Value Shocks
#'
#' @param ltv Numeric. Current loan-to-value.
#' @param hpi_shock Numeric. House Price Index shock (e.g., -0.20 for a 20% property drop).
#' @param foreclosure_costs Numeric. Repossession and legal cost fraction (e.g., 0.08).
#' @param liquidation_haircut Numeric. Distressed sale haircut (e.g., 0.15).
#' @return Loss Given Default fraction between 0 and 1.
#' @export
calculate_lgd <- function(ltv = 0.75,
                          hpi_shock = 0.0,
                          foreclosure_costs = 0.08,
                          liquidation_haircut = 0.15) {
  # Stressed property value = Original * (1 + hpi_shock)
  # Net liquidation proceeds = Stressed Value * (1 - liquidation_haircut - foreclosure_costs)
  net_proceeds_factor <- (1 + hpi_shock) * (1 - liquidation_haircut - foreclosure_costs)

  # Recovery fraction = net_proceeds / loan balance = net_proceeds_factor / LTV
  recovery_fraction <- net_proceeds_factor / ltv
  recovery_fraction <- min(pmax(recovery_fraction, 0.0), 1.0)

  lgd <- 1.0 - recovery_fraction
  return(lgd)
}

#' Multi-Period Expected Credit Loss (ECL)
#'
#' @param cashflows_dt data.table output from run_portfolio_cashflows.
#' @param discount_rate Numeric. Annualised risk-free discount rate.
#' @return List containing undiscounted ECL, discounted ECL, and period breakdown.
#' @export
calculate_ecl_multiperiod <- function(cashflows_dt, discount_rate = 0.045) {
  n_periods <- nrow(cashflows_dt)
  dt <- copy(cashflows_dt)

  monthly_r <- discount_rate / 12
  dt[, df := (1 + monthly_r)^(-period)]
  dt[, discounted_loss := net_losses * df]

  total_undiscounted_ecl <- sum(dt$net_losses)
  total_discounted_ecl <- sum(dt$discounted_loss)

  list(
    total_undiscounted_ecl = total_undiscounted_ecl,
    total_discounted_ecl = total_discounted_ecl,
    ecl_percentage = total_discounted_ecl / dt$opening_balance[1],
    period_ecl = dt[, .(period, gross_defaults, recoveries, net_losses, discounted_loss)]
  )
}
