# Rhino Bank Synthetic MBS — Shiny Institutional Research Interface
# File: inst/shiny/app.R

library(shiny)
library(data.table)
library(ggplot2)

ui <- fluidPage(
  title = "Rhino Bank Synthetic MBS Analytics",
  theme = bslib::bs_theme(version = 5, bootswatch = "flatly", primary = "#0F172A"),
  tags$head(
    tags$style(HTML("
      body { font-family: 'DM Sans', -apple-system, sans-serif; background-color: #F8FAFC; }
      .navbar { background-color: #0F172A !important; }
      .card { border-radius: 6px; border: 1px solid #E2E8F0; box-shadow: none; margin-bottom: 1rem; }
      .metric-box { background: #FFFFFF; padding: 1.25rem; border: 1px solid #E2E8F0; border-radius: 6px; }
      .metric-label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; color: #64748B; }
      .metric-value { font-size: 1.5rem; font-weight: 700; color: #0F172A; font-variant-numeric: tabular-nums; }
    "))
  ),
  navbarPage(
    title = div(strong("RHINO BANK"), " | Synthetic MBS Engine"),
    tabPanel("Executive Dashboard",
      fluidRow(
        column(3, div(class = "metric-box", div(class = "metric-label", "Gross Reference Pool"), div(class = "metric-value", "£1,000,000,000"))),
        column(3, div(class = "metric-box", div(class = "metric-label", "Protected Mezzanine Notional"), div(class = "metric-value", "£70,000,000"))),
        column(3, div(class = "metric-box", div(class = "metric-label", "Retained First-Loss"), div(class = "metric-value", "£25,000,000"))),
        column(3, div(class = "metric-box", div(class = "metric-label", "Weighted Average Coupon"), div(class = "metric-value", "5.45%")))
      ),
      br(),
      fluidRow(
        column(8,
          div(class = "card p-3 bg-white",
            h5("Cash Flow Waterfall Projections (Monthly)"),
            plotOutput("waterfallPlot", height = "360px")
          )
        ),
        column(4,
          div(class = "card p-3 bg-white",
            h5("Capital Structure & Risk Stack"),
            tableOutput("trancheSummaryTable")
          )
        )
      )
    ),
    tabPanel("Waterfall Engine",
      sidebarLayout(
        sidebarPanel(
          width = 3,
          sliderInput("cprInput", "Conditional Prepayment Rate (CPR %)", min = 1, max = 25, value = 8, step = 0.5),
          sliderInput("cdrInput", "Conditional Default Rate (CDR %)", min = 0.2, max = 10, value = 1.2, step = 0.1),
          sliderInput("recoveryInput", "Liquidation Recovery Rate (%)", min = 20, max = 95, value = 70, step = 5),
          selectInput("triggerMode", "Waterfall Amortization Mode", choices = c("Sequential Paydown", "Pro-Rata with Triggers")),
          actionButton("runWaterfallBtn", "Recompute Waterfall", class = "btn btn-dark w-100")
        ),
        mainPanel(
          width = 9,
          div(class = "card p-3 bg-white",
            h5("Period Cash Flow Ledger"),
            DT::dataTableOutput("periodLedgerTable")
          )
        )
      )
    ),
    tabPanel("Monte Carlo & Stress",
      fluidRow(
        column(4,
          div(class = "card p-3 bg-white",
            h5("Simulation Controls"),
            numericInput("mcSims", "Monte Carlo Paths", value = 1000, min = 100, max = 10000, step = 100),
            numericInput("mcSeed", "Deterministic Seed", value = 42),
            sliderInput("assetRho", "Asset Correlation (rho)", min = 0.05, max = 0.40, value = 0.18, step = 0.01),
            actionButton("runMCBtn", "Execute Simulation", class = "btn btn-primary w-100")
          )
        ),
        column(8,
          div(class = "card p-3 bg-white",
            h5("Simulated Portfolio Loss Distribution"),
            plotOutput("mcDistributionPlot", height = "360px")
          )
        )
      )
    ),
    tabPanel("Governance & Compliance",
      div(class = "card p-4 bg-white",
        h4("Model Governance Record: RHN-MRG-MBS-2026-04"),
        p(class = "text-muted", "Regulatory Framework: Bank of England / PRA SS1/23 Model Risk Management Principles."),
        tags$hr(),
        tags$ul(
          tags$li(strong("Validation Status: "), "Validated for internal research and hypothetical structuring."),
          tags$li(strong("Data Provenance: "), "Strictly synthetic mortgage reference assets. No personal data."),
          tags$li(strong("SRT Regulatory Note: "), "Significant Risk Transfer recognition requires separate supervisory approval under UK Securitisation Regulations.")
        )
      )
    )
  )
)

server <- function(input, output, session) {
  # Default waterfall mock calculation for display
  output$waterfallPlot <- renderPlot({
    periods <- 1:60
    sched <- pmax(1e7 * exp(-periods * 0.02), 0)
    prepay <- sched * 0.4
    df <- data.frame(Period = rep(periods, 2), CashFlow = c(sched, prepay), Type = rep(c("Scheduled", "Prepaid"), each = 60))
    ggplot(df, aes(x = Period, y = CashFlow / 1e6, fill = Type)) +
      geom_bar(stat = "identity") +
      scale_fill_manual(values = c("#0F172A", "#0284C7")) +
      labs(y = "Cash Flow (£ Millions)", x = "Month") +
      theme_minimal()
  })

  output$trancheSummaryTable <- renderTable({
    data.frame(
      Tranche = c("Class A (Senior)", "Class B (Mezz)", "Class C (Junior)", "Equity / FL"),
      Attachment = c("12.0%", "5.0%", "2.5%", "0.0%"),
      Detachment = c("100.0%", "12.0%", "5.0%", "2.5%"),
      Notional_GBP = c("£880,000,000", "£70,000,000", "£25,000,000", "£25,000,000"),
      Spread = c("+80 bps", "+185 bps", "+350 bps", "Residual")
    )
  })

  output$mcDistributionPlot <- renderPlot({
    set.seed(42)
    sim_losses <- rlnorm(1000, meanlog = log(35), sdlog = 0.55)
    df <- data.frame(Loss = sim_losses)
    ggplot(df, aes(x = Loss)) +
      geom_histogram(bins = 35, fill = "#0284C7", color = "#0F172A", alpha = 0.8) +
      geom_vline(xintercept = quantile(sim_losses, 0.99), color = "#DC2626", linetype = "dashed", size = 1) +
      annotate("text", x = quantile(sim_losses, 0.99) + 5, y = 50, label = "99% VaR", color = "#DC2626") +
      labs(x = "Simulated Pool Loss (£ Millions)", y = "Frequency") +
      theme_minimal()
  })
}

shinyApp(ui = ui, server = server)
