/**
 * Rhino Bank Synthetic MBS & Structured Credit Types
 */

export type PoolArchetype = 'prime_residential' | 'buy_to_let' | 'high_ltv' | 'mixed_credit';

export interface SyntheticLoan {
  loan_id: string;
  country: string;
  currency: string;
  region: string;
  property_type: string;
  property_value: number;
  original_balance: number;
  current_balance: number;
  ltv: number;
  credit_grade: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B';
  rate_type: 'Fixed' | 'Floating';
  contractual_rate: number;
  remaining_term_months: number;
  seasoning_months: number;
  scheduled_payment: number;
  dsti_category: '<30%' | '30-40%' | '40-50%' | '>50%';
  delinquency_state: 'Current' | '30_Days_Arrears' | '60_Days_Arrears' | '90+_Days_Default';
}

export interface PoolStratification {
  total_loans: number;
  total_balance: number;
  wac: number;
  wam_months: number;
  waltv: number;
  by_credit: { grade: string; balance: number; pct: number; wac: number; waltv: number }[];
  by_region: { region: string; balance: number; pct: number }[];
  by_rate: { rate_type: string; balance: number; pct: number }[];
  by_delinquency: { state: string; count: number; pct: number }[];
}

export interface PoolMonthlyCashflow {
  period: number;
  opening_balance: number;
  scheduled_principal: number;
  prepaid_principal: number;
  gross_defaults: number;
  recoveries: number;
  net_losses: number;
  total_principal: number;
  interest_received: number;
  servicing_fees: number;
  net_interest_available: number;
  closing_balance: number;
}

export interface TrancheDefinition {
  id: string;
  name: string;
  attachment_pt: number; // e.g. 0.05
  detachment_pt: number; // e.g. 0.12
  initial_notional: number;
  coupon_spread_bps: number;
  risk_type: 'Retained Senior' | 'Protected Mezzanine' | 'Protected Junior' | 'Retained First-Loss';
}

export interface TranchePeriodLedger {
  period: number;
  opening_balance: number;
  interest_due: number;
  interest_paid: number;
  principal_paid: number;
  writedowns: number;
  closing_balance: number;
}

export interface WaterfallOutput {
  periods: PoolMonthlyCashflow[];
  tranche_ledgers: { [trancheId: string]: TranchePeriodLedger[] };
  ledger_summary: {
    period: number;
    available_principal: number;
    allocated_principal: number;
    available_interest: number;
    allocated_interest: number;
    reserve_fund_balance: number;
    trigger_breached: boolean;
    excess_spread: number;
  }[];
  conservation_valid: boolean;
  cumulative_pool_loss: number;
}

export interface TrancheValuation {
  tranche_id: string;
  attachment_pt: number;
  detachment_pt: number;
  initial_notional: number;
  present_value: number;
  clean_price: number;
  wal_years: number;
  spread_duration: number;
  dv01_gbp: number;
  expected_loss_pct: number;
  impaired: boolean;
  breakeven_spread_bps: number;
}

export interface SyntheticCRTStructure {
  transaction_id: string;
  reference_notional: number;
  first_loss_detachment: number;
  mezzanine_detachment: number;
  first_loss_notional: number;
  mezzanine_protected_notional: number;
  senior_retained_notional: number;
  protection_type: 'funded_credit_linked_note' | 'unfunded_financial_guarantee';
  protection_spread_bps: number;
  protection_maturity_years: number;
  counterparty_rating: string;
  collateral_haircut: number;
  pv_premium_leg: number;
  pv_protection_leg: number;
  net_cost_gbp: number;
  breakeven_spread_bps: number;
}

export interface MonteCarloSummary {
  n_simulations: number;
  seed: number;
  asset_correlation: number;
  mean_pool_loss_gbp: number;
  mean_pool_loss_pct: number;
  var_95_gbp: number;
  var_99_gbp: number;
  var_999_gbp: number;
  expected_shortfall_99_gbp: number;
  expected_shortfall_999_gbp: number;
  histogram_bins: { binStart: number; binEnd: number; count: number; freq: number }[];
  convergence_points: { iteration: number; runningMean: number; se: number }[];
  tranche_impairment_rates: { tranche_id: string; impairment_prob: number; mean_loss_gbp: number }[];
}

export interface StressScenarioDef {
  id: string;
  name: string;
  description: string;
  hpi_shock_pct: number;
  unemployment_pct: number;
  rate_shock_bps: number;
  cdr_multiplier: number;
  recovery_rate_pct: number;
  projected_pool_loss_pct: number;
  projected_pool_loss_gbp: number;
  impacted_tranches: string[];
}

export interface ReverseStressResult {
  target_tranche: string;
  attachment_pt: number;
  critical_loss_fraction: number;
  critical_loss_gbp: number;
  required_default_rate_base_rec: number;
  required_default_rate_stressed_rec: number;
  implied_hpi_shock_pct: number;
  governance_status: string;
}

export interface YieldCurvePoint {
  maturity: number;
  zeroRate: number;
  discountFactor: number;
}
