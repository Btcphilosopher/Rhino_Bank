import {
  PoolArchetype,
  SyntheticLoan,
  PoolStratification,
  PoolMonthlyCashflow,
  TrancheDefinition,
  TranchePeriodLedger,
  WaterfallOutput,
  TrancheValuation,
  SyntheticCRTStructure,
  MonteCarloSummary,
  StressScenarioDef,
  ReverseStressResult,
  YieldCurvePoint
} from '../types/mbs';

// Deterministic Pseudo-Random Generator (Linear Congruential / Mulberry32)
export function createRNG(seed: number) {
  let s = seed >>> 0;
  return function() {
    s = (s + 0x6D2B79F5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Normal distribution approximation (Box-Muller)
export function standardNormal(rng: () => number): number {
  let u = 0, v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

// 1. Synthetic Portfolio Generator
export function generateSyntheticPool(
  archetype: PoolArchetype = 'prime_residential',
  targetNotional = 1000000000,
  loanCount = 5000,
  seed = 42
): { loans: SyntheticLoan[]; stratification: PoolStratification } {
  const rng = createRNG(seed);
  const regions = [
    { name: 'Greater London', weight: 0.28, baseVal: 520000 },
    { name: 'South East', weight: 0.22, baseVal: 390000 },
    { name: 'North West', weight: 0.12, baseVal: 240000 },
    { name: 'West Midlands', weight: 0.09, baseVal: 235000 },
    { name: 'East of England', weight: 0.09, baseVal: 330000 },
    { name: 'South West', weight: 0.08, baseVal: 310000 },
    { name: 'Yorkshire & Humber', weight: 0.05, baseVal: 210000 },
    { name: 'Scotland', weight: 0.04, baseVal: 205000 },
    { name: 'Wales', weight: 0.03, baseVal: 195000 }
  ];

  const rawLoans: Array<{
    id: string;
    region: string;
    propType: string;
    propVal: number;
    rawBalance: number;
    origBalanceMult: number;
    grade: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B';
    rateType: 'Fixed' | 'Floating';
    rate: number;
    term: number;
    seasoning: number;
    dsti: '<30%' | '30-40%' | '40-50%' | '>50%';
    delinq: 'Current' | '30_Days_Arrears' | '60_Days_Arrears' | '90+_Days_Default';
  }> = [];

  let totalRawBalance = 0;

  for (let i = 1; i <= loanCount; i++) {
    // Pick region
    const rPick = rng();
    let cumW = 0;
    let chosenRegion = regions[0];
    for (const reg of regions) {
      cumW += reg.weight;
      if (rPick <= cumW) {
        chosenRegion = reg;
        break;
      }
    }

    // Property value lognormal
    const logMean = Math.log(chosenRegion.baseVal);
    const propVal = Math.max(95000, Math.round(Math.exp(logMean + standardNormal(rng) * 0.32) / 1000) * 1000);

    // Archetype parameters
    let ltv = 0.68;
    let grade: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' = 'AA';
    let propType = 'Owner-Occupied';

    if (archetype === 'prime_residential') {
      ltv = Math.min(Math.max(0.65 + standardNormal(rng) * 0.09, 0.35), 0.85);
      const gR = rng();
      grade = gR < 0.45 ? 'AAA' : gR < 0.80 ? 'AA' : gR < 0.95 ? 'A' : 'BBB';
      propType = 'Owner-Occupied';
    } else if (archetype === 'buy_to_let') {
      ltv = Math.min(Math.max(0.72 + standardNormal(rng) * 0.07, 0.45), 0.80);
      const gR = rng();
      grade = gR < 0.20 ? 'AA' : gR < 0.70 ? 'A' : gR < 0.95 ? 'BBB' : 'BB';
      propType = 'Buy-to-Let';
    } else if (archetype === 'high_ltv') {
      ltv = Math.min(Math.max(0.88 + standardNormal(rng) * 0.05, 0.78), 0.96);
      const gR = rng();
      grade = gR < 0.15 ? 'A' : gR < 0.65 ? 'BBB' : gR < 0.90 ? 'BB' : 'B';
      propType = rng() < 0.85 ? 'Owner-Occupied' : 'Buy-to-Let';
    } else {
      ltv = Math.min(Math.max(0.73 + standardNormal(rng) * 0.12, 0.40), 0.95);
      const gR = rng();
      grade = gR < 0.25 ? 'AAA' : gR < 0.55 ? 'AA' : gR < 0.78 ? 'A' : gR < 0.90 ? 'BBB' : gR < 0.97 ? 'BB' : 'B';
      propType = rng() < 0.70 ? 'Owner-Occupied' : 'Buy-to-Let';
    }

    const rawBal = propVal * ltv;
    totalRawBalance += rawBal;

    const rateType: 'Fixed' | 'Floating' = rng() < 0.75 ? 'Fixed' : 'Floating';
    const baseMargin = grade === 'AAA' ? 0.0090 : grade === 'AA' ? 0.0115 : grade === 'A' ? 0.0150 : grade === 'BBB' ? 0.0210 : grade === 'BB' ? 0.0320 : 0.0450;
    const contractualRate = 0.0450 + baseMargin + (rateType === 'Fixed' ? 0.0030 : 0);

    const termMonths = [180, 240, 300, 360][Math.floor(rng() * 4)];
    const seasoning = Math.floor(rng() * 42) + 6;

    const dstiRoll = rng();
    const dsti: '<30%' | '30-40%' | '40-50%' | '>50%' =
      dstiRoll < 0.42 ? '<30%' : dstiRoll < 0.78 ? '30-40%' : dstiRoll < 0.94 ? '40-50%' : '>50%';

    const delinqRoll = rng();
    const delinq: 'Current' | '30_Days_Arrears' | '60_Days_Arrears' | '90+_Days_Default' =
      delinqRoll < 0.972 ? 'Current' : delinqRoll < 0.990 ? '30_Days_Arrears' : delinqRoll < 0.997 ? '60_Days_Arrears' : '90+_Days_Default';

    rawLoans.push({
      id: `RHN-MBS-2026-${String(i).padStart(6, '0')}`,
      region: chosenRegion.name,
      propType,
      propVal,
      rawBalance: rawBal,
      origBalanceMult: 1.05 + rng() * 0.10,
      grade,
      rateType,
      rate: Math.round(contractualRate * 10000) / 10000,
      term: termMonths,
      seasoning,
      dsti,
      delinq
    });
  }

  // Scale exactly to targetNotional
  const scale = targetNotional / totalRawBalance;
  const loans: SyntheticLoan[] = rawLoans.map(r => {
    const currentBal = Math.round(r.rawBalance * scale * 100) / 100;
    const origBal = Math.round(currentBal * r.origBalanceMult * 100) / 100;
    const mRate = r.rate / 12;
    const schedPmt = Math.round(currentBal * (mRate / (1 - Math.pow(1 + mRate, -r.term))) * 100) / 100;

    return {
      loan_id: r.id,
      country: 'United Kingdom',
      currency: 'GBP',
      region: r.region,
      property_type: r.propType,
      property_value: r.propVal,
      original_balance: origBal,
      current_balance: currentBal,
      ltv: Math.round((currentBal / r.propVal) * 10000) / 10000,
      credit_grade: r.grade,
      rate_type: r.rateType,
      contractual_rate: r.rate,
      remaining_term_months: r.term,
      seasoning_months: r.seasoning,
      scheduled_payment: schedPmt,
      dsti_category: r.dsti,
      delinquency_state: r.delinq
    };
  });

  // Calculate stratifications
  const totalBal = loans.reduce((acc, l) => acc + l.current_balance, 0);
  const wac = loans.reduce((acc, l) => acc + l.current_balance * l.contractual_rate, 0) / totalBal;
  const wam = loans.reduce((acc, l) => acc + l.current_balance * l.remaining_term_months, 0) / totalBal;
  const waltv = loans.reduce((acc, l) => acc + l.current_balance * l.ltv, 0) / totalBal;

  // Grade breakdown
  const grades = ['AAA', 'AA', 'A', 'BBB', 'BB', 'B'] as const;
  const byCredit = grades.map(g => {
    const subset = loans.filter(l => l.credit_grade === g);
    const bal = subset.reduce((acc, l) => acc + l.current_balance, 0);
    const subWac = bal > 0 ? subset.reduce((acc, l) => acc + l.current_balance * l.contractual_rate, 0) / bal : 0;
    const subLtv = bal > 0 ? subset.reduce((acc, l) => acc + l.current_balance * l.ltv, 0) / bal : 0;
    return { grade: g, balance: bal, pct: (bal / totalBal) * 100, wac: subWac, waltv: subLtv };
  });

  // Region breakdown
  const byRegion = regions.map(reg => {
    const subset = loans.filter(l => l.region === reg.name);
    const bal = subset.reduce((acc, l) => acc + l.current_balance, 0);
    return { region: reg.name, balance: bal, pct: (bal / totalBal) * 100 };
  }).sort((a, b) => b.balance - a.balance);

  // Rate breakdown
  const fixedLoans = loans.filter(l => l.rate_type === 'Fixed');
  const floatLoans = loans.filter(l => l.rate_type === 'Floating');
  const fixBal = fixedLoans.reduce((acc, l) => acc + l.current_balance, 0);
  const fltBal = floatLoans.reduce((acc, l) => acc + l.current_balance, 0);
  const byRate = [
    { rate_type: 'Fixed Rate (5Y/2Y Fix)', balance: fixBal, pct: (fixBal / totalBal) * 100 },
    { rate_type: 'Floating Rate (SONIA Tracker)', balance: fltBal, pct: (fltBal / totalBal) * 100 }
  ];

  // Delinquency breakdown
  const delinqStates = ['Current', '30_Days_Arrears', '60_Days_Arrears', '90+_Days_Default'] as const;
  const byDelinq = delinqStates.map(s => {
    const count = loans.filter(l => l.delinquency_state === s).length;
    return { state: s, count, pct: (count / loans.length) * 100 };
  });

  return {
    loans,
    stratification: {
      total_loans: loans.length,
      total_balance: totalBal,
      wac,
      wam_months: Math.round(wam),
      waltv,
      by_credit: byCredit,
      by_region: byRegion,
      by_rate: byRate,
      by_delinquency: byDelinq
    }
  };
}

// 2. Prepayment and SMM conversion
export function cprToSmm(cpr: number): number {
  return 1 - Math.pow(1 - cpr, 1 / 12);
}

// 3. Pool Cash-Flow Projection Engine
export function simulatePoolCashflows(
  initialBalance = 1000000000,
  wac = 0.0545,
  wam = 282,
  cprAnnual = 0.08,
  cdrAnnual = 0.012,
  recoveryRate = 0.70,
  recoveryLag = 6,
  servicingFeeBps = 25,
  periodsCount = 60
): PoolMonthlyCashflow[] {
  const result: PoolMonthlyCashflow[] = [];
  const smm = cprToSmm(cprAnnual);
  const mdr = 1 - Math.pow(1 - cdrAnnual, 1 / 12);
  const servicingRateMonthly = (servicingFeeBps / 10000) / 12;

  let currentBal = initialBalance;
  const pendingRecoveries: number[] = new Array(periodsCount + recoveryLag + 10).fill(0);

  for (let t = 1; t <= periodsCount; t++) {
    if (currentBal <= 10.0) {
      result.push({
        period: t,
        opening_balance: 0,
        scheduled_principal: 0,
        prepaid_principal: 0,
        gross_defaults: 0,
        recoveries: pendingRecoveries[t] || 0,
        net_losses: 0,
        total_principal: pendingRecoveries[t] || 0,
        interest_received: 0,
        servicing_fees: 0,
        net_interest_available: 0,
        closing_balance: 0
      });
      continue;
    }

    const opBal = currentBal;
    const mRate = wac / 12;
    const remMonths = Math.max(wam - t + 1, 1);

    // Monthly scheduled payment annuity formula
    const pmtFactor = (mRate * Math.pow(1 + mRate, remMonths)) / (Math.pow(1 + mRate, remMonths) - 1);
    const schedPayment = opBal * pmtFactor;
    const schedInterest = opBal * mRate;
    const schedPrin = Math.min(Math.max(schedPayment - schedInterest, 0), opBal);

    const balAfterSched = Math.max(opBal - schedPrin, 0);

    // Prepayment
    const prepayPrin = balAfterSched * smm;
    const balAfterPrepay = Math.max(balAfterSched - prepayPrin, 0);

    // Default
    const grossDef = balAfterPrepay * mdr;
    const recoveryAmt = grossDef * recoveryRate;
    pendingRecoveries[t + recoveryLag] = (pendingRecoveries[t + recoveryLag] || 0) + recoveryAmt;
    const netLoss = grossDef * (1 - recoveryRate);

    // Cash recoveries received in month t
    const currentRecovery = pendingRecoveries[t] || 0;

    const servicingFee = opBal * servicingRateMonthly;
    const netIntAvail = Math.max(schedInterest - servicingFee, 0);
    const totalPrin = schedPrin + prepayPrin + currentRecovery;

    currentBal = Math.max(balAfterPrepay - grossDef, 0);

    result.push({
      period: t,
      opening_balance: Math.round(opBal * 100) / 100,
      scheduled_principal: Math.round(schedPrin * 100) / 100,
      prepaid_principal: Math.round(prepayPrin * 100) / 100,
      gross_defaults: Math.round(grossDef * 100) / 100,
      recoveries: Math.round(currentRecovery * 100) / 100,
      net_losses: Math.round(netLoss * 100) / 100,
      total_principal: Math.round(totalPrin * 100) / 100,
      interest_received: Math.round(schedInterest * 100) / 100,
      servicing_fees: Math.round(servicingFee * 100) / 100,
      net_interest_available: Math.round(netIntAvail * 100) / 100,
      closing_balance: Math.round(currentBal * 100) / 100
    });
  }

  return result;
}

// 4. Canonical Tranche Loss Fraction: min(max((Portfolio Loss - A) / (D - A), 0), 1)
export function calcTrancheLossFraction(cumLossFrac: number, att: number, det: number): number {
  if (det <= att) throw new Error(`Detachment point (${det}) must be strictly greater than attachment point (${att}).`);
  const frac = (cumLossFrac - att) / (det - att);
  return Math.min(Math.max(frac, 0.0), 1.0);
}

// 5. Multi-Tranche Waterfall Engine
export function runMbsWaterfall(
  tranches: TrancheDefinition[],
  poolFlows: PoolMonthlyCashflow[],
  soniaBenchmark = 0.0450,
  reserveFundTarget = 15000000,
  cumulativeLossTrigger = 0.025,
  delinquencyTrigger = 0.035
): WaterfallOutput {
  const nPeriods = poolFlows.length;
  const initialPoolBal = poolFlows[0].opening_balance;

  // Initialize state
  const trancheBals: { [id: string]: number } = {};
  const trancheLedgers: { [id: string]: TranchePeriodLedger[] } = {};

  for (const tr of tranches) {
    trancheBals[tr.id] = tr.initial_notional;
    trancheLedgers[tr.id] = [];
  }

  let reserveBalance = reserveFundTarget;
  let cumulativeLoss = 0;
  const ledgerSummary: WaterfallOutput['ledger_summary'] = [];

  for (let t = 0; t < nPeriods; t++) {
    const cf = poolFlows[t];
    cumulativeLoss += cf.net_losses;
    const cumLossFrac = cumulativeLoss / initialPoolBal;

    const isTriggerBreached = cumLossFrac >= cumulativeLossTrigger;

    // A. Write-Down Allocations (Junior to Senior absorption)
    // First-loss / Junior tranches absorb first
    const sortedJuniorFirst = [...tranches].sort((a, b) => a.attachment_pt - b.attachment_pt);

    for (const tr of sortedJuniorFirst) {
      const att = tr.attachment_pt;
      const det = tr.detachment_pt;
      const trancheCap = (det - att) * initialPoolBal;
      const lossFrac = calcTrancheLossFraction(cumLossFrac, att, det);
      const targetLoss = lossFrac * trancheCap;
      const priorWritedown = tr.initial_notional - trancheBals[tr.id];
      const newWritedown = Math.min(Math.max(targetLoss - priorWritedown, 0), trancheBals[tr.id]);

      trancheBals[tr.id] -= newWritedown;
    }

    // B. Interest Allocation (Senior to Junior priority)
    let intAvail = cf.net_interest_available;
    const periodIntPaid: { [id: string]: number } = {};
    const periodIntDue: { [id: string]: number } = {};

    const sortedSeniorFirst = [...tranches].sort((a, b) => b.attachment_pt - a.attachment_pt);

    for (const tr of sortedSeniorFirst) {
      const opBal = trancheBals[tr.id];
      const couponRate = soniaBenchmark + (tr.coupon_spread_bps / 10000);
      const intDue = opBal * (couponRate / 12);
      const intPaid = Math.min(intAvail, intDue);

      intAvail -= intPaid;
      periodIntDue[tr.id] = intDue;
      periodIntPaid[tr.id] = intPaid;
    }

    // Reserve Fund coverage for interest shortfall
    if (intAvail < 0 && reserveBalance > 0) {
      const draw = Math.min(Math.abs(intAvail), reserveBalance);
      reserveBalance -= draw;
      intAvail += draw;
    }

    // C. Principal Allocation (Sequential: Senior down first)
    let prinAvail = cf.total_principal;
    let totalPrinAllocated = 0;
    const periodPrinPaid: { [id: string]: number } = {};

    for (const tr of sortedSeniorFirst) {
      if (prinAvail <= 0 || trancheBals[tr.id] <= 0) {
        periodPrinPaid[tr.id] = 0;
        continue;
      }
      const pPaid = Math.min(prinAvail, trancheBals[tr.id]);
      prinAvail -= pPaid;
      totalPrinAllocated += pPaid;
      trancheBals[tr.id] -= pPaid;
      periodPrinPaid[tr.id] = pPaid;
    }

    // Record period ledgers
    for (const tr of tranches) {
      trancheLedgers[tr.id].push({
        period: cf.period,
        opening_balance: Math.round(trancheBals[tr.id] + (periodPrinPaid[tr.id] || 0)),
        interest_due: Math.round((periodIntDue[tr.id] || 0) * 100) / 100,
        interest_paid: Math.round((periodIntPaid[tr.id] || 0) * 100) / 100,
        principal_paid: Math.round((periodPrinPaid[tr.id] || 0) * 100) / 100,
        writedowns: Math.round((tr.initial_notional - trancheBals[tr.id]) * 100) / 100,
        closing_balance: Math.round(trancheBals[tr.id] * 100) / 100
      });
    }

    // Excess spread replenishment of reserve fund
    let excessSpread = Math.max(intAvail, 0);
    if (reserveBalance < reserveFundTarget && excessSpread > 0) {
      const replenish = Math.min(reserveFundTarget - reserveBalance, excessSpread);
      reserveBalance += replenish;
      excessSpread -= replenish;
    }

    ledgerSummary.push({
      period: cf.period,
      available_principal: cf.total_principal,
      allocated_principal: totalPrinAllocated,
      available_interest: cf.net_interest_available,
      allocated_interest: cf.net_interest_available - intAvail,
      reserve_fund_balance: Math.round(reserveBalance),
      trigger_breached: isTriggerBreached,
      excess_spread: Math.round(excessSpread * 100) / 100
    });
  }

  // Conservation validation
  const totalPoolPrin = poolFlows.reduce((acc, c) => acc + c.total_principal, 0);
  const totalAllocPrin = ledgerSummary.reduce((acc, l) => acc + l.allocated_principal, 0);
  const isConserved = Math.abs(totalPoolPrin - totalAllocPrin) < 500;

  return {
    periods: poolFlows,
    tranche_ledgers: trancheLedgers,
    ledger_summary: ledgerSummary,
    conservation_valid: isConserved,
    cumulative_pool_loss: Math.round(cumulativeLoss)
  };
}

// 6. Tranche Valuation & Risk Sensitivities
export function priceWaterfallTranches(
  tranches: TrancheDefinition[],
  waterfall: WaterfallOutput,
  zeroCurve: YieldCurvePoint[],
  discountSpreadBps = 0
): TrancheValuation[] {
  return tranches.map(tr => {
    const ledger = waterfall.tranche_ledgers[tr.id];
    let pv = 0;
    let totalPrin = 0;
    let weightedMonths = 0;
    let totalWritedowns = 0;

    let pvUp = 0;
    let pvDn = 0;

    const discountSpreadDec = discountSpreadBps / 10000;

    for (let t = 0; t < ledger.length; t++) {
      const row = ledger[t];
      const timeYears = row.period / 12;

      // Interpolate zero rate
      const zeroRate = interpolateZeroRate(zeroCurve, timeYears);
      const df = Math.exp(-(zeroRate + discountSpreadDec) * timeYears);

      // Durations
      const dfUp = Math.exp(-(zeroRate + discountSpreadDec + 0.0025) * timeYears);
      const dfDn = Math.exp(-(zeroRate + discountSpreadDec - 0.0025) * timeYears);

      const cf = row.interest_paid + row.principal_paid;
      pv += cf * df;
      pvUp += cf * dfUp;
      pvDn += cf * dfDn;

      totalPrin += row.principal_paid;
      weightedMonths += row.period * row.principal_paid;
      totalWritedowns = row.writedowns;
    }

    const cleanPrice = (pv / tr.initial_notional) * 100;
    const walYears = totalPrin > 0 ? weightedMonths / (12 * totalPrin) : 0;
    const spreadDuration = pv > 0 ? (pvDn - pvUp) / (2 * 0.0025 * pv) : 0;
    const dv01 = (pv * spreadDuration * 0.0001);
    const expectedLossPct = (totalWritedowns / tr.initial_notional) * 100;

    // Breakeven spread
    const breakevenSpreadBps = (tr.coupon_spread_bps) + Math.max(100 - cleanPrice, 0) * 22;

    return {
      tranche_id: tr.name,
      attachment_pt: tr.attachment_pt,
      detachment_pt: tr.detachment_pt,
      initial_notional: tr.initial_notional,
      present_value: Math.round(pv),
      clean_price: Math.round(cleanPrice * 100) / 100,
      wal_years: Math.round(walYears * 10) / 10,
      spread_duration: Math.round(spreadDuration * 100) / 100,
      dv01_gbp: Math.round(dv01),
      expected_loss_pct: Math.round(expectedLossPct * 100) / 100,
      impaired: totalWritedowns > 0,
      breakeven_spread_bps: Math.round(breakevenSpreadBps)
    };
  });
}

function interpolateZeroRate(curve: YieldCurvePoint[], timeYears: number): number {
  if (timeYears <= curve[0].maturity) return curve[0].zeroRate;
  if (timeYears >= curve[curve.length - 1].maturity) return curve[curve.length - 1].zeroRate;

  for (let i = 0; i < curve.length - 1; i++) {
    if (timeYears >= curve[i].maturity && timeYears <= curve[i + 1].maturity) {
      const frac = (timeYears - curve[i].maturity) / (curve[i + 1].maturity - curve[i].maturity);
      return curve[i].zeroRate + frac * (curve[i + 1].zeroRate - curve[i].zeroRate);
    }
  }
  return 0.045;
}

// 7. Synthetic Credit-Risk Transfer (CRT) Structuring
export function calculateCRTStructure(
  referenceNotional = 1000000000,
  firstLossDetachment = 0.025,
  mezzanineDetachment = 0.095,
  protectionSpreadBps = 320,
  protectionType: 'funded_credit_linked_note' | 'unfunded_financial_guarantee' = 'funded_credit_linked_note',
  counterpartyRating = 'AA',
  collateralHaircut = 0.05,
  tenorYears = 5
): SyntheticCRTStructure {
  const firstLossNotional = referenceNotional * firstLossDetachment;
  const mezzanineProtectedNotional = referenceNotional * (mezzanineDetachment - firstLossDetachment);
  const seniorRetainedNotional = referenceNotional * (1 - mezzanineDetachment);

  // Simplified 5-year discounted legs
  const annualSpread = protectionSpreadBps / 10000;
  let pvPremium = 0;
  const dfSum = 4.38; // 5-year annuity factor approx at 4.5% SONIA
  pvPremium = mezzanineProtectedNotional * annualSpread * dfSum;

  // Expected protection recoveries leg under baseline
  const expectedDefaultLoss = referenceNotional * 0.016; // 1.6% pool loss
  // First loss absorbs 2.5%, so mezzanine suffers minimal under baseline
  const expectedMezzRecovery = Math.max(expectedDefaultLoss - firstLossNotional, 0);
  const pvProtection = expectedMezzRecovery * 0.90;

  const netCost = pvPremium - pvProtection;
  const breakevenSpread = (pvProtection / (mezzanineProtectedNotional * dfSum)) * 10000;

  return {
    transaction_id: 'RHN-SYNTH-MBS-2026-CR1',
    reference_notional: referenceNotional,
    first_loss_detachment: firstLossDetachment,
    mezzanine_detachment: mezzanineDetachment,
    first_loss_notional: firstLossNotional,
    mezzanine_protected_notional: mezzanineProtectedNotional,
    senior_retained_notional: seniorRetainedNotional,
    protection_type: protectionType,
    protection_spread_bps: protectionSpreadBps,
    protection_maturity_years: tenorYears,
    counterparty_rating: counterpartyRating,
    collateral_haircut: collateralHaircut,
    pv_premium_leg: Math.round(pvPremium),
    pv_protection_leg: Math.round(pvProtection),
    net_cost_gbp: Math.round(netCost),
    breakeven_spread_bps: Math.round(breakevenSpread)
  };
}

// 8. Monte Carlo Simulation Engine
export function runMonteCarloSimulation(
  tranches: TrancheDefinition[],
  initialBalance = 1000000000,
  nSimulations = 1000,
  assetCorrelation = 0.18,
  seed = 42
): MonteCarloSummary {
  const rng = createRNG(seed);
  const poolLosses: number[] = [];
  const trancheLossTotals: { [id: string]: number } = {};
  const trancheImpairmentCounts: { [id: string]: number } = {};

  for (const tr of tranches) {
    trancheLossTotals[tr.id] = 0;
    trancheImpairmentCounts[tr.id] = 0;
  }

  const baseCdr = 0.012;
  const convergencePoints: { iteration: number; runningMean: number; se: number }[] = [];
  let cumLossRunning = 0;

  for (let i = 1; i <= nSimulations; i++) {
    // Common systematic macroeconomic factor Z ~ N(0, 1)
    const Z = standardNormal(rng);
    const eps = standardNormal(rng);

    // Latent asset return Y = sqrt(rho)*Z + sqrt(1 - rho)*eps
    const Y = Math.sqrt(assetCorrelation) * Z + Math.sqrt(1 - assetCorrelation) * eps;

    // Stressed CDR via Vasicek factor transformation
    const macroMult = Math.exp(-0.62 * Y);
    const simCdr = Math.min(baseCdr * macroMult, 0.22);

    // 5-year cumulative pool loss
    const cumGrossDef = 1 - Math.pow(1 - simCdr, 5);
    const recovery = Math.max(0.70 - 0.15 * Math.max(-Z, 0), 0.35);
    const cumLossRate = cumGrossDef * (1 - recovery);

    const lossGbp = initialBalance * cumLossRate;
    poolLosses.push(lossGbp);
    cumLossRunning += lossGbp;

    // Track tranche loss allocations
    for (const tr of tranches) {
      const frac = calcTrancheLossFraction(cumLossRate, tr.attachment_pt, tr.detachment_pt);
      const tLoss = frac * tr.initial_notional;
      trancheLossTotals[tr.id] += tLoss;
      if (tLoss > 1000) {
        trancheImpairmentCounts[tr.id] += 1;
      }
    }

    if (i % Math.max(Math.floor(nSimulations / 20), 10) === 0 || i === nSimulations) {
      const runningMean = cumLossRunning / i;
      const runningVar = poolLosses.slice(0, i).reduce((acc, l) => acc + Math.pow(l - runningMean, 2), 0) / Math.max(i - 1, 1);
      const se = Math.sqrt(runningVar) / Math.sqrt(i);
      convergencePoints.push({
        iteration: i,
        runningMean: Math.round(runningMean),
        se: Math.round(se)
      });
    }
  }

  // Quantiles
  const sortedLosses = [...poolLosses].sort((a, b) => a - b);
  const q95Idx = Math.floor(nSimulations * 0.95);
  const q99Idx = Math.floor(nSimulations * 0.99);
  const q999Idx = Math.floor(nSimulations * 0.999);

  const var95 = sortedLosses[q95Idx] || sortedLosses[sortedLosses.length - 1];
  const var99 = sortedLosses[q99Idx] || sortedLosses[sortedLosses.length - 1];
  const var999 = sortedLosses[q999Idx] || sortedLosses[sortedLosses.length - 1];

  const tail99 = sortedLosses.slice(q99Idx);
  const es99 = tail99.reduce((a, b) => a + b, 0) / tail99.length;

  const tail999 = sortedLosses.slice(q999Idx);
  const es999 = tail999.length > 0 ? tail999.reduce((a, b) => a + b, 0) / tail999.length : var999;

  const meanPoolLoss = poolLosses.reduce((a, b) => a + b, 0) / nSimulations;

  // Histogram calculation
  const minLoss = sortedLosses[0];
  const maxLoss = sortedLosses[sortedLosses.length - 1];
  const binCount = 20;
  const binWidth = (maxLoss - minLoss) / binCount;

  const histogramBins: MonteCarloSummary['histogram_bins'] = [];
  for (let b = 0; b < binCount; b++) {
    const bStart = minLoss + b * binWidth;
    const bEnd = bStart + binWidth;
    const count = sortedLosses.filter(l => l >= bStart && (b === binCount - 1 ? l <= bEnd : l < bEnd)).length;
    histogramBins.push({
      binStart: Math.round(bStart),
      binEnd: Math.round(bEnd),
      count,
      freq: (count / nSimulations) * 100
    });
  }

  const trancheSummaries = tranches.map(tr => ({
    tranche_id: tr.name,
    impairment_prob: Math.round((trancheImpairmentCounts[tr.id] / nSimulations) * 1000) / 10,
    mean_loss_gbp: Math.round(trancheLossTotals[tr.id] / nSimulations)
  }));

  return {
    n_simulations: nSimulations,
    seed,
    asset_correlation: assetCorrelation,
    mean_pool_loss_gbp: Math.round(meanPoolLoss),
    mean_pool_loss_pct: Math.round((meanPoolLoss / initialBalance) * 10000) / 100,
    var_95_gbp: Math.round(var95),
    var_99_gbp: Math.round(var99),
    var_999_gbp: Math.round(var999),
    expected_shortfall_99_gbp: Math.round(es99),
    expected_shortfall_999_gbp: Math.round(es999),
    histogram_bins: histogramBins,
    convergence_points: convergencePoints,
    tranche_impairment_rates: trancheSummaries
  };
}

// 9. Standard 12 Institutional Stress Scenarios
export function getStandardStressScenarios(
  tranches: TrancheDefinition[],
  initialBalance = 1000000000
): StressScenarioDef[] {
  const baseDefs = [
    { id: 'sc_base', name: 'Base Case (Benign Macro)', desc: 'Current consensus UK economic conditions; stable house prices and low arrears.', hpi: 0.0, unemp: 4.2, rateShock: 0, cdrMult: 1.0, recRate: 72 },
    { id: 'sc_pra_rec', name: 'PRA Severe Macroeconomic Recession', desc: 'Bank of England / PRA annual stress test scenario: GDP collapse, severe property drops.', hpi: -30.0, unemp: 9.5, rateShock: 200, cdrMult: 3.5, recRate: 45 },
    { id: 'sc_hpi_crash', name: 'UK Housing Market Crash (-25% HPI)', desc: 'Widespread property price decline triggering negative equity across higher LTV cohorts.', hpi: -25.0, unemp: 6.0, rateShock: 50, cdrMult: 2.2, recRate: 52 },
    { id: 'sc_stagflation', name: 'Stagflation & Rate Spike (+300 bps)', desc: 'High persistent inflation forcing policy rate hikes alongside economic stagnation.', hpi: -15.0, unemp: 7.5, rateShock: 300, cdrMult: 2.8, recRate: 55 },
    { id: 'sc_rate_cut', name: 'Rapid Rate Cut & Refi Surge (-250 bps)', desc: 'Central bank emergency easing sparking rapid prepayments and contraction risk.', hpi: 5.0, unemp: 4.5, rateShock: -250, cdrMult: 0.9, recRate: 78 },
    { id: 'sc_btl_crisis', name: 'Buy-to-Let Rental Yield Shock', desc: 'Regulatory EPC penalties, tenant rent arrears, and tax pressures hitting landlord yields.', hpi: -20.0, unemp: 6.5, rateShock: 150, cdrMult: 3.0, recRate: 50 },
    { id: 'sc_london_se', name: 'London & South East Regional Distress', desc: 'Concentrated price depreciation in high-value southeastern commuter belts.', hpi: -35.0, unemp: 8.0, rateShock: 100, cdrMult: 2.7, recRate: 48 },
    { id: 'sc_spread_blow', name: 'Credit Spread Blowout (+450 bps)', desc: 'Global fixed-income liquidity freeze and secondary structured credit dislocation.', hpi: -10.0, unemp: 5.5, rateShock: 250, cdrMult: 2.0, recRate: 60 },
    { id: 'sc_rec_haircut', name: 'Foreclosure Moratorium & Extended Lag', desc: 'Courts backlogged with 24-month repossession delays and escalated legal costs.', hpi: -20.0, unemp: 6.0, rateShock: 0, cdrMult: 1.8, recRate: 38 },
    { id: 'sc_def_cluster', name: 'Correlated Mortgage Default Cluster', desc: 'Systemic contagion across leveraged household clusters and high DSTI borrowers.', hpi: -22.0, unemp: 8.5, rateShock: 150, cdrMult: 4.2, recRate: 46 },
    { id: 'sc_unemp_spike', name: 'Unemployment Spike to 11.0%', desc: 'Severe labor market dislocation with double-digit unemployment and income shocks.', hpi: -18.0, unemp: 11.0, rateShock: 100, cdrMult: 3.8, recRate: 50 },
    { id: 'sc_combined_run', name: 'Combined Severe Credit & Funding Run', desc: 'Tail compound stress: property crash, double-digit unemployment, and funding freeze.', hpi: -32.0, unemp: 10.5, rateShock: 350, cdrMult: 4.8, recRate: 40 }
  ];

  return baseDefs.map(b => {
    const base5yDef = 0.05;
    const stressedDef = Math.min(base5yDef * b.cdrMult, 0.50);
    const stressedLossRate = stressedDef * (1 - b.recRate / 100);
    const poolLossGbp = initialBalance * stressedLossRate;

    const impactedTranches: string[] = [];
    for (const tr of tranches) {
      const frac = calcTrancheLossFraction(stressedLossRate, tr.attachment_pt, tr.detachment_pt);
      if (frac > 0) {
        impactedTranches.push(`${tr.name} (${Math.round(frac * 100)}%)`);
      }
    }

    return {
      id: b.id,
      name: b.name,
      description: b.desc,
      hpi_shock_pct: b.hpi,
      unemployment_pct: b.unemp,
      rate_shock_bps: b.rateShock,
      cdr_multiplier: b.cdrMult,
      recovery_rate_pct: b.recRate,
      projected_pool_loss_pct: Math.round(stressedLossRate * 10000) / 100,
      projected_pool_loss_gbp: Math.round(poolLossGbp),
      impacted_tranches: impactedTranches.length === 0 ? ['None (Zero Impairment)'] : impactedTranches
    };
  });
}

// 10. Reverse Stress Testing Solver
export function solveReverseStressTest(
  tranches: TrancheDefinition[],
  targetTrancheId: string,
  initialBalance = 1000000000
): ReverseStressResult {
  const target = tranches.find(t => t.id === targetTrancheId) || tranches[1];
  const criticalLossFrac = target.attachment_pt;
  const criticalLossGbp = initialBalance * criticalLossFrac;

  // Implied default rates under 70% and 50% recovery
  const reqDef70 = criticalLossFrac / (1 - 0.70);
  const reqDef50 = criticalLossFrac / (1 - 0.50);

  // Approximate HPI shock required if baseline defaults held constant
  const impliedHpi = Math.min((criticalLossFrac / 0.12) * -18.5, -5.0);

  return {
    target_tranche: target.name,
    attachment_pt: target.attachment_pt,
    critical_loss_fraction: criticalLossFrac,
    critical_loss_gbp: Math.round(criticalLossGbp),
    required_default_rate_base_rec: Math.round(reqDef70 * 1000) / 10,
    required_default_rate_stressed_rec: Math.round(reqDef50 * 1000) / 10,
    implied_hpi_shock_pct: Math.round(impliedHpi * 10) / 10,
    governance_status: 'MODEL_DERIVED_BOUNDARY_CONDITION_NOT_PREDICTION'
  };
}

// Default standard SONIA yield curve
export const DEFAULT_ZERO_CURVE: YieldCurvePoint[] = [
  { maturity: 0.25, zeroRate: 0.0480, discountFactor: 0.9881 },
  { maturity: 0.50, zeroRate: 0.0465, discountFactor: 0.9770 },
  { maturity: 1.00, zeroRate: 0.0445, discountFactor: 0.9565 },
  { maturity: 2.00, zeroRate: 0.0425, discountFactor: 0.9185 },
  { maturity: 3.00, zeroRate: 0.0410, discountFactor: 0.8843 },
  { maturity: 5.00, zeroRate: 0.0395, discountFactor: 0.8208 },
  { maturity: 7.00, zeroRate: 0.0405, discountFactor: 0.7531 },
  { maturity: 10.0, zeroRate: 0.0420, discountFactor: 0.6570 },
  { maturity: 15.0, zeroRate: 0.0435, discountFactor: 0.5207 },
  { maturity: 20.0, zeroRate: 0.0445, discountFactor: 0.4107 },
  { maturity: 30.0, zeroRate: 0.0455, discountFactor: 0.2554 }
];

// Default Capital Structure
export const DEFAULT_CAPITAL_STRUCTURE: TrancheDefinition[] = [
  {
    id: 'tranche_a',
    name: 'Class A (Senior Retained)',
    attachment_pt: 0.095,
    detachment_pt: 1.000,
    initial_notional: 905000000,
    coupon_spread_bps: 80,
    risk_type: 'Retained Senior'
  },
  {
    id: 'tranche_b',
    name: 'Class B (Mezzanine Protected)',
    attachment_pt: 0.050,
    detachment_pt: 0.095,
    initial_notional: 45000000,
    coupon_spread_bps: 210,
    risk_type: 'Protected Mezzanine'
  },
  {
    id: 'tranche_c',
    name: 'Class C (Junior Protected)',
    attachment_pt: 0.025,
    detachment_pt: 0.050,
    initial_notional: 25000000,
    coupon_spread_bps: 380,
    risk_type: 'Protected Junior'
  },
  {
    id: 'tranche_d',
    name: 'Class D (First-Loss Retained)',
    attachment_pt: 0.000,
    detachment_pt: 0.025,
    initial_notional: 25000000,
    coupon_spread_bps: 0,
    risk_type: 'Retained First-Loss'
  }
];
