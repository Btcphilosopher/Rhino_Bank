import React, { useState, useMemo } from 'react';
import { TopBar } from './components/TopBar';
import { ExecutiveOverview } from './components/ExecutiveOverview';
import { ReferencePoolWorkbench } from './components/ReferencePoolWorkbench';
import { WaterfallStructureEditor } from './components/WaterfallStructureEditor';
import { SyntheticCrtWorkbench } from './components/SyntheticCrtWorkbench';
import { ValuationWorkbench } from './components/ValuationWorkbench';
import { MonteCarloSimulator } from './components/MonteCarloSimulator';
import { StressTestingLab } from './components/StressTestingLab';
import { RPackageInspector } from './components/RPackageInspector';
import { ModelGovernancePanel } from './components/ModelGovernancePanel';

import {
  PoolArchetype,
  TrancheDefinition
} from './types/mbs';

import {
  generateSyntheticPool,
  simulatePoolCashflows,
  runMbsWaterfall,
  priceWaterfallTranches,
  calculateCRTStructure,
  runMonteCarloSimulation,
  getStandardStressScenarios,
  DEFAULT_CAPITAL_STRUCTURE,
  DEFAULT_ZERO_CURVE
} from './engine/mbsEngine';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Reference Pool State
  const [archetype, setArchetype] = useState<PoolArchetype>('prime_residential');
  const [targetNotional, setTargetNotional] = useState(1000000000);
  const [loanCount, setLoanCount] = useState(5000);
  const [poolSeed, setPoolSeed] = useState(42);

  // Generate Reference Pool
  const { loans, stratification } = useMemo(() => {
    return generateSyntheticPool(archetype, targetNotional, loanCount, poolSeed);
  }, [archetype, targetNotional, loanCount, poolSeed]);

  // Waterfall Assumptions
  const [cprAnnual, setCprAnnual] = useState(0.08);
  const [cdrAnnual, setCdrAnnual] = useState(0.012);
  const [recoveryRate, setRecoveryRate] = useState(0.70);
  const [tranches, setTranches] = useState<TrancheDefinition[]>(DEFAULT_CAPITAL_STRUCTURE);

  // Pool Cash Flows
  const poolCashflows = useMemo(() => {
    return simulatePoolCashflows(
      stratification.total_balance,
      stratification.wac,
      stratification.wam_months,
      cprAnnual,
      cdrAnnual,
      recoveryRate,
      6,
      25,
      60
    );
  }, [stratification, cprAnnual, cdrAnnual, recoveryRate]);

  // Waterfall Allocation
  const waterfall = useMemo(() => {
    return runMbsWaterfall(tranches, poolCashflows);
  }, [tranches, poolCashflows]);

  // Discount Spread
  const [discountSpreadBps, setDiscountSpreadBps] = useState(0);

  // Tranche Valuations
  const valuations = useMemo(() => {
    return priceWaterfallTranches(tranches, waterfall, DEFAULT_ZERO_CURVE, discountSpreadBps);
  }, [tranches, waterfall, discountSpreadBps]);

  // Synthetic CRT Structure
  const [crtSpreadBps, setCrtSpreadBps] = useState(320);
  const [crtType, setCrtType] = useState<'funded_credit_linked_note' | 'unfunded_financial_guarantee'>('funded_credit_linked_note');
  const [crtTenor, setCrtTenor] = useState(5);
  const [crtHaircut, setCrtHaircut] = useState(0.05);

  const crt = useMemo(() => {
    return calculateCRTStructure(
      stratification.total_balance,
      0.025,
      0.095,
      crtSpreadBps,
      crtType,
      'AA',
      crtHaircut,
      crtTenor
    );
  }, [stratification.total_balance, crtSpreadBps, crtType, crtHaircut, crtTenor]);

  // Monte Carlo Simulation
  const [mcSims, setMcSims] = useState(1000);
  const [mcRho, setMcRho] = useState(0.18);
  const [mcSeed, setMcSeed] = useState(42);

  const monteCarlo = useMemo(() => {
    return runMonteCarloSimulation(tranches, stratification.total_balance, mcSims, mcRho, mcSeed);
  }, [tranches, stratification.total_balance, mcSims, mcRho, mcSeed]);

  // Stress Scenarios
  const stressScenarios = useMemo(() => {
    return getStandardStressScenarios(tranches, stratification.total_balance);
  }, [tranches, stratification.total_balance]);

  // Handlers
  const handleRegeneratePool = (newArch: PoolArchetype, notional: number, count: number, seed: number) => {
    setArchetype(newArch);
    setTargetNotional(notional);
    setLoanCount(count);
    setPoolSeed(seed);
  };

  const handleUpdateAssumptions = (newCpr: number, newCdr: number, newRec: number) => {
    setCprAnnual(newCpr);
    setCdrAnnual(newCdr);
    setRecoveryRate(newRec);
  };

  const handleUpdateCrt = (updated: any) => {
    if (updated.protection_spread_bps !== undefined) setCrtSpreadBps(updated.protection_spread_bps);
    if (updated.protection_type !== undefined) setCrtType(updated.protection_type);
    if (updated.protection_maturity_years !== undefined) setCrtTenor(updated.protection_maturity_years);
    if (updated.collateral_haircut !== undefined) setCrtHaircut(updated.collateral_haircut);
  };

  const handleExportDossier = () => {
    setActiveTab('governance');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white">
      {/* Top Bar Header */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExportDossier={handleExportDossier}
      />

      {/* Main Analytical Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8 space-y-6">
        {activeTab === 'overview' && (
          <ExecutiveOverview
            stratification={stratification}
            tranches={tranches}
            waterfall={waterfall}
            crt={crt}
            monteCarlo={monteCarlo}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'pool' && (
          <ReferencePoolWorkbench
            loans={loans}
            stratification={stratification}
            archetype={archetype}
            onRegeneratePool={handleRegeneratePool}
          />
        )}

        {activeTab === 'waterfall' && (
          <WaterfallStructureEditor
            tranches={tranches}
            waterfall={waterfall}
            cprAnnual={cprAnnual}
            cdrAnnual={cdrAnnual}
            recoveryRate={recoveryRate}
            onUpdateTranches={setTranches}
            onUpdateAssumptions={handleUpdateAssumptions}
          />
        )}

        {activeTab === 'crt' && (
          <SyntheticCrtWorkbench
            crt={crt}
            onUpdateCrt={handleUpdateCrt}
          />
        )}

        {activeTab === 'valuation' && (
          <ValuationWorkbench
            valuations={valuations}
            yieldCurve={DEFAULT_ZERO_CURVE}
            discountSpreadBps={discountSpreadBps}
            onUpdateDiscountSpread={setDiscountSpreadBps}
          />
        )}

        {activeTab === 'montecarlo' && (
          <MonteCarloSimulator
            monteCarlo={monteCarlo}
            tranches={tranches}
            onRunSimulation={(sims, rho, s) => {
              setMcSims(sims);
              setMcRho(rho);
              setMcSeed(s);
            }}
          />
        )}

        {activeTab === 'stress' && (
          <StressTestingLab
            scenarios={stressScenarios}
            tranches={tranches}
          />
        )}

        {activeTab === 'rpackage' && (
          <RPackageInspector />
        )}

        {activeTab === 'governance' && (
          <ModelGovernancePanel
            tranches={tranches}
            waterfall={waterfall}
            crt={crt}
            onExportDossier={handleExportDossier}
          />
        )}
      </main>

      {/* Institutional Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 px-6 py-4 text-xs text-slate-500 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-400">RHINO BANK PLC</span>
          <span>·</span>
          <span>Structured Credit Quantitative Engineering & Model Risk Oversight</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span>Model ID: RHN-MRG-MBS-2026-04</span>
          <span>·</span>
          <span>Bank of England PRA SS1/23 Framework</span>
          <span>·</span>
          <span>Simulated Data Only</span>
        </div>
      </footer>
    </div>
  );
}
