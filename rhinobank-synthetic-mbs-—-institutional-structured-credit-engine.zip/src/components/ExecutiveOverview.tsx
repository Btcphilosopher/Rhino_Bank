import React from 'react';
import {
  ShieldAlert,
  ArrowRight,
  TrendingDown,
  Layers,
  Banknote,
  Percent,
  Calendar
} from 'lucide-react';
import {
  PoolStratification,
  TrancheDefinition,
  WaterfallOutput,
  SyntheticCRTStructure,
  MonteCarloSummary
} from '../types/mbs';

interface ExecutiveOverviewProps {
  stratification: PoolStratification;
  tranches: TrancheDefinition[];
  waterfall: WaterfallOutput;
  crt: SyntheticCRTStructure;
  monteCarlo: MonteCarloSummary;
  onNavigateTab: (tab: string) => void;
}

export const ExecutiveOverview: React.FC<ExecutiveOverviewProps> = ({
  stratification,
  tranches,
  waterfall,
  crt,
  monteCarlo,
  onNavigateTab
}) => {
  const totalBalance = stratification.total_balance;
  const grossLoss = waterfall.cumulative_pool_loss;
  const grossLossPct = (grossLoss / totalBalance) * 100;

  // 12-month sample cash flows for overview chart
  const samplePeriods = waterfall.periods.slice(0, 18);
  const maxCf = Math.max(...samplePeriods.map(p => p.total_principal + p.net_interest_available), 1);

  return (
    <div className="space-y-6">
      {/* Top Warning / Provenance Notice */}
      <div className="p-3 bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5 rounded">
        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-white">STATUTORY RESEARCH DISCLOSURE · RHINO BANK QUANTITATIVE ENGINE: </span>
          All mortgage reference assets and counterparty configurations are hypothetical synthetic data for quantitative research, structuring and risk evaluation. Modeled prices do not represent executable quotes or rating agency assessments. Significant Risk Transfer (SRT) under PRA SS1/23 requires transaction-specific supervisory determination.
        </div>
      </div>

      {/* Hero KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded">
          <div className="text-[11px] font-medium uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Banknote className="w-3.5 h-3.5 text-slate-400" />
            Gross Reference Pool
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-white mt-1">
            £{(totalBalance / 1e6).toFixed(0)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">5,000 synthetic loans</div>
        </div>

        <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded">
          <div className="text-[11px] font-medium uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-sky-400" />
            Protected Notional
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-sky-400 mt-1">
            £{(crt.mezzanine_protected_notional / 1e6).toFixed(1)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">2.5% – 9.5% mezzanine band</div>
        </div>

        <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded">
          <div className="text-[11px] font-medium uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <TrendingDown className="w-3.5 h-3.5 text-amber-400" />
            Retained First-Loss
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-amber-300 mt-1">
            £{(crt.first_loss_notional / 1e6).toFixed(1)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">0.0% – 2.5% originator equity</div>
        </div>

        <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded">
          <div className="text-[11px] font-medium uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Percent className="w-3.5 h-3.5 text-slate-400" />
            Weighted Avg Coupon
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-white mt-1">
            {(stratification.wac * 100).toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">SONIA + 95 bps margin</div>
        </div>

        <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded">
          <div className="text-[11px] font-medium uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            Weighted Avg Life
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-white mt-1">
            {(stratification.wam_months / 12).toFixed(1)}y
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{stratification.wam_months} months remaining</div>
        </div>

        <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded">
          <div className="text-[11px] font-medium uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            99.0% VaR (5Y Horizon)
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-rose-300 mt-1">
            £{(monteCarlo.var_99_gbp / 1e6).toFixed(1)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{((monteCarlo.var_99_gbp / totalBalance) * 100).toFixed(2)}% pool loss</div>
        </div>
      </div>

      {/* Main Grid: Capital Structure & Cash Flow Waterfall */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Capital Structure Table and Risk Stack (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/50 border border-slate-800 p-4 rounded space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white tracking-wide">
              Capital Structure & Tranche Loss Absorption
            </h3>
            <button
              onClick={() => onNavigateTab('waterfall')}
              className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1 cursor-pointer"
            >
              <span>Edit Waterfall</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Multi-tier capital structure with sequential principal paydown and subordinated loss allocation:
            <span className="font-mono text-slate-300 ml-1">Φ(L) = min(max((L - A) / (D - A), 0), 1)</span>.
          </p>

          {/* Visual Stack Ladder */}
          <div className="space-y-1.5 pt-1">
            {tranches.map(tr => {
              const widthPct = ((tr.initial_notional / totalBalance) * 100).toFixed(1);
              const colorClass =
                tr.risk_type === 'Retained Senior'
                  ? 'bg-slate-700 border-slate-600 text-slate-200'
                  : tr.risk_type === 'Protected Mezzanine'
                  ? 'bg-sky-950/80 border-sky-800/80 text-sky-200'
                  : tr.risk_type === 'Protected Junior'
                  ? 'bg-indigo-950/80 border-indigo-800/80 text-indigo-200'
                  : 'bg-amber-950/80 border-amber-800/80 text-amber-200';

              return (
                <div key={tr.id} className={`p-2.5 border rounded flex items-center justify-between text-xs ${colorClass}`}>
                  <div>
                    <span className="font-semibold">{tr.name}</span>
                    <span className="text-[11px] text-slate-400 ml-2">
                      ({(tr.attachment_pt * 100).toFixed(1)}% – {(tr.detachment_pt * 100).toFixed(1)}%)
                    </span>
                  </div>
                  <div className="text-right font-mono tabular-nums">
                    <span className="font-bold">£{(tr.initial_notional / 1e6).toFixed(1)}m</span>
                    <span className="text-[11px] text-slate-400 ml-2">({widthPct}%)</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
            <span>Conservation Validation Check:</span>
            <span className={`font-mono font-medium ${waterfall.conservation_valid ? 'text-emerald-400' : 'text-rose-400'}`}>
              {waterfall.conservation_valid ? '✓ Conserved (Diff < £100)' : '⚠ Discrepancy Detected'}
            </span>
          </div>
        </div>

        {/* Right: Cash Flow Trajectory & Synthetic CRT Metrics (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/50 border border-slate-800 p-4 rounded space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white tracking-wide">
              Reference Pool Monthly Cash-Flow Projections (Months 1–18)
            </h3>
            <button
              onClick={() => onNavigateTab('crt')}
              className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1 cursor-pointer"
            >
              <span>CRT Module</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-slate-600 inline-block rounded-xs"></span>
              Scheduled Principal
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-sky-500 inline-block rounded-xs"></span>
              Prepayments (8% CPR)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-500 inline-block rounded-xs"></span>
              Net Interest Available
            </span>
          </div>

          {/* SVG Bar Chart for Cash Flow */}
          <div className="h-52 w-full pt-2">
            <svg className="w-full h-full" viewBox="0 0 540 180" preserveAspectRatio="none">
              {/* Horizontal gridlines */}
              <line x1="0" y1="40" x2="540" y2="40" stroke="#1E293B" strokeDasharray="3 3" />
              <line x1="0" y1="90" x2="540" y2="90" stroke="#1E293B" strokeDasharray="3 3" />
              <line x1="0" y1="140" x2="540" y2="140" stroke="#1E293B" strokeDasharray="3 3" />

              {samplePeriods.map((p, idx) => {
                const x = 12 + idx * 29;
                const schedH = (p.scheduled_principal / maxCf) * 120;
                const prepayH = (p.prepaid_principal / maxCf) * 120;
                const intH = (p.net_interest_available / maxCf) * 120;

                const yBase = 160;
                const ySched = yBase - schedH;
                const yPrepay = ySched - prepayH;
                const yInt = yPrepay - intH;

                return (
                  <g key={p.period}>
                    {/* Sched Principal Bar */}
                    <rect x={x} y={ySched} width="18" height={schedH} fill="#475569" rx="1" />
                    {/* Prepay Principal Bar */}
                    <rect x={x} y={yPrepay} width="18" height={prepayH} fill="#0284C7" rx="1" />
                    {/* Interest Bar */}
                    <rect x={x} y={yInt} width="18" height={intH} fill="#10B981" rx="1" />
                    {/* Month Label */}
                    {idx % 2 === 0 && (
                      <text x={x + 9} y="174" textAnchor="middle" fill="#64748B" fontSize="9" fontFamily="monospace">
                        M{p.period}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Quick Summary Grid */}
          <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-800 text-xs">
            <div>
              <div className="text-slate-400">Total Net Losses (60M)</div>
              <div className="text-white font-mono font-bold tabular-nums mt-0.5">
                £{(grossLoss / 1e6).toFixed(2)}m ({grossLossPct.toFixed(2)}%)
              </div>
            </div>
            <div>
              <div className="text-slate-400">CRT Protection Premium</div>
              <div className="text-sky-400 font-mono font-bold tabular-nums mt-0.5">
                {crt.protection_spread_bps} bps p.a.
              </div>
            </div>
            <div>
              <div className="text-slate-400">Reserve Fund Status</div>
              <div className="text-emerald-400 font-mono font-bold tabular-nums mt-0.5">
                £15.0m Target (Full)
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action / Methodology Callout */}
      <div className="p-4 bg-slate-900/40 border border-slate-800 rounded flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-white">Full Analytical Modules Available</div>
          <p className="text-xs text-slate-400 mt-0.5">
            Access loan-level stratification, Monte Carlo copula distributions, 12 macroeconomic stress tests, and the complete standalone R package codebase.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => onNavigateTab('valuation')}
            className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded cursor-pointer"
          >
            Valuation Workbench
          </button>
          <button
            onClick={() => onNavigateTab('montecarlo')}
            className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded cursor-pointer"
          >
            Monte Carlo Engine
          </button>
          <button
            onClick={() => onNavigateTab('rpackage')}
            className="px-3 py-1.5 text-xs font-medium text-sky-300 bg-sky-950 hover:bg-sky-900 border border-sky-800 rounded cursor-pointer"
          >
            Inspect R Source Code
          </button>
        </div>
      </div>
    </div>
  );
};
