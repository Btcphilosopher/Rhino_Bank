import React, { useState } from 'react';
import {
  Download,
  Filter,
  Search,
  RefreshCw,
  Building,
  CreditCard,
  MapPin,
  Clock
} from 'lucide-react';
import { PoolArchetype, SyntheticLoan, PoolStratification } from '../types/mbs';

interface ReferencePoolWorkbenchProps {
  loans: SyntheticLoan[];
  stratification: PoolStratification;
  archetype: PoolArchetype;
  onRegeneratePool: (archetype: PoolArchetype, notional: number, count: number, seed: number) => void;
}

export const ReferencePoolWorkbench: React.FC<ReferencePoolWorkbenchProps> = ({
  loans,
  stratification,
  archetype,
  onRegeneratePool
}) => {
  const [selectedArchetype, setSelectedArchetype] = useState<PoolArchetype>(archetype);
  const [notionalGbp, setNotionalGbp] = useState(1000000000);
  const [loanCount, setLoanCount] = useState(5000);
  const [seedVal, setSeedVal] = useState(42);

  // Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [gradeFilter, setGradeFilter] = useState('ALL');
  const [regionFilter, setRegionFilter] = useState('ALL');
  const [delinqFilter, setDelinqFilter] = useState('ALL');

  const filteredLoans = loans.filter(l => {
    if (searchQuery && !l.loan_id.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (gradeFilter !== 'ALL' && l.credit_grade !== gradeFilter) return false;
    if (regionFilter !== 'ALL' && l.region !== regionFilter) return false;
    if (delinqFilter !== 'ALL' && l.delinquency_state !== delinqFilter) return false;
    return true;
  });

  const exportCsv = () => {
    const headers = [
      'loan_id', 'country', 'currency', 'region', 'property_type',
      'property_value', 'original_balance', 'current_balance', 'ltv',
      'credit_grade', 'rate_type', 'contractual_rate', 'remaining_term_months',
      'seasoning_months', 'scheduled_payment', 'dsti_category', 'delinquency_state'
    ];
    const rows = loans.map(l => [
      l.loan_id, l.country, l.currency, `"${l.region}"`, `"${l.property_type}"`,
      l.property_value, l.original_balance, l.current_balance, l.ltv,
      l.credit_grade, l.rate_type, l.contractual_rate, l.remaining_term_months,
      l.seasoning_months, l.scheduled_payment, l.dsti_category, l.delinquency_state
    ].join(','));

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `rhinobank_synthetic_mortgages_${selectedArchetype}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Parameter Controls Bar */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-wide">
              Synthetic Reference Mortgage Pool Generator
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Calibrated statistical distributions for prime UK and European residential portfolios.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onRegeneratePool(selectedArchetype, notionalGbp, loanCount, seedVal)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Regenerate Portfolio</span>
            </button>
            <button
              onClick={exportCsv}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-900 bg-sky-400 hover:bg-sky-300 rounded transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV ({loans.length})</span>
            </button>
          </div>
        </div>

        {/* Form Controls */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2 border-t border-slate-800">
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">Pool Archetype</label>
            <select
              value={selectedArchetype}
              onChange={e => setSelectedArchetype(e.target.value as PoolArchetype)}
              className="w-full text-xs bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-sky-500"
            >
              <option value="prime_residential">Prime Residential (UK Standard)</option>
              <option value="buy_to_let">Buy-to-Let Specialist Pool</option>
              <option value="high_ltv">Higher-LTV First-Time Buyer Pool</option>
              <option value="mixed_credit">Mixed-Credit Quality Cohort</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">Target Notional (£)</label>
            <select
              value={notionalGbp}
              onChange={e => setNotionalGbp(Number(e.target.value))}
              className="w-full text-xs bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-sky-500"
            >
              <option value={500000000}>£500,000,000</option>
              <option value={1000000000}>£1,000,000,000 (Benchmark)</option>
              <option value={2000000000}>£2,000,000,000</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">Number of Synthetic Loans</label>
            <select
              value={loanCount}
              onChange={e => setLoanCount(Number(e.target.value))}
              className="w-full text-xs bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-sky-500"
            >
              <option value={1000}>1,000 Loans (Fast)</option>
              <option value={5000}>5,000 Loans (Standard)</option>
              <option value={10000}>10,000 Loans (Dense Stratification)</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">Deterministic Seed</label>
            <input
              type="number"
              value={seedVal}
              onChange={e => setSeedVal(Number(e.target.value))}
              className="w-full text-xs bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:outline-none focus:border-sky-500"
            />
          </div>
        </div>
      </div>

      {/* Stratification Summary Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Credit Grade Stratification */}
        <div className="bg-slate-900/50 border border-slate-800 p-3.5 rounded space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-white">
            <span className="flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-sky-400" />
              Credit Grade Stratification
            </span>
            <span className="text-slate-400 font-normal">WAC / LTV</span>
          </div>
          <div className="space-y-1.5">
            {stratification.by_credit.map(item => (
              <div key={item.grade} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-slate-200 w-8">{item.grade}</span>
                  <span className="text-slate-400">{item.pct.toFixed(1)}%</span>
                </div>
                <div className="font-mono text-slate-300 text-[11px]">
                  {(item.wac * 100).toFixed(2)}% · {(item.waltv * 100).toFixed(1)}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Regional Breakdown */}
        <div className="bg-slate-900/50 border border-slate-800 p-3.5 rounded space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-white">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              Regional Geography
            </span>
            <span className="text-slate-400 font-normal">% Balance</span>
          </div>
          <div className="space-y-1.5">
            {stratification.by_region.slice(0, 5).map(item => (
              <div key={item.region} className="flex items-center justify-between text-xs">
                <span className="text-slate-300 truncate max-w-[140px]">{item.region}</span>
                <span className="font-mono tabular-nums text-slate-200 font-medium">
                  {item.pct.toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Rate Type Mix */}
        <div className="bg-slate-900/50 border border-slate-800 p-3.5 rounded space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-white">
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              Interest Rate Type
            </span>
            <span className="text-slate-400 font-normal">Notional</span>
          </div>
          <div className="space-y-2">
            {stratification.by_rate.map(item => (
              <div key={item.rate_type} className="text-xs space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span className="truncate">{item.rate_type}</span>
                  <span className="font-mono text-white font-medium">{item.pct.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full" style={{ width: `${item.pct}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Delinquency / Arrears State */}
        <div className="bg-slate-900/50 border border-slate-800 p-3.5 rounded space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-white">
            <span className="flex items-center gap-1.5">
              <Building className="w-3.5 h-3.5 text-rose-400" />
              Arrears & Delinquency
            </span>
            <span className="text-slate-400 font-normal">Loan Count</span>
          </div>
          <div className="space-y-1.5">
            {stratification.by_delinquency.map(item => (
              <div key={item.state} className="flex items-center justify-between text-xs">
                <span className="text-slate-300 text-[11px] truncate max-w-[130px]">{item.state.replace(/_/g, ' ')}</span>
                <div className="text-right font-mono tabular-nums text-slate-200">
                  <span className="font-medium">{item.count}</span>
                  <span className="text-[11px] text-slate-400 ml-1">({item.pct.toFixed(1)}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Loan-Level Table View */}
      <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wide">
              Loan-Level Reference Asset Ledger
            </h3>
            <p className="text-xs text-slate-400">
              Displaying {filteredLoans.length} of {loans.length} synthetic mortgage accounts.
            </p>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search loan ID..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1 text-xs bg-slate-800 border border-slate-700 rounded text-slate-200 focus:outline-none focus:border-sky-500 w-36"
              />
            </div>

            <select
              value={gradeFilter}
              onChange={e => setGradeFilter(e.target.value)}
              className="text-xs bg-slate-800 border border-slate-700 rounded px-2 py-1 text-slate-300 focus:outline-none"
            >
              <option value="ALL">All Grades</option>
              <option value="AAA">AAA</option>
              <option value="AA">AA</option>
              <option value="A">A</option>
              <option value="BBB">BBB</option>
              <option value="BB">BB</option>
              <option value="B">B</option>
            </select>

            <select
              value={delinqFilter}
              onChange={e => setDelinqFilter(e.target.value)}
              className="text-xs bg-slate-800 border border-slate-700 rounded px-2 py-1 text-slate-300 focus:outline-none"
            >
              <option value="ALL">All Arrears States</option>
              <option value="Current">Current</option>
              <option value="30_Days_Arrears">30 Days Arrears</option>
              <option value="60_Days_Arrears">60 Days Arrears</option>
              <option value="90+_Days_Default">90+ Days Default</option>
            </select>
          </div>
        </div>

        {/* Data Table */}
        <div className="overflow-x-auto border border-slate-800 rounded">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-800">
            <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] tracking-wider font-semibold">
              <tr>
                <th className="px-3 py-2.5">Loan ID</th>
                <th className="px-3 py-2.5">Region</th>
                <th className="px-3 py-2.5">Type</th>
                <th className="px-3 py-2.5 text-right">Property Value</th>
                <th className="px-3 py-2.5 text-right">Current Balance</th>
                <th className="px-3 py-2.5 text-right">LTV</th>
                <th className="px-3 py-2.5 text-center">Grade</th>
                <th className="px-3 py-2.5 text-right">Coupon</th>
                <th className="px-3 py-2.5 text-right">Rem. Term</th>
                <th className="px-3 py-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {filteredLoans.slice(0, 15).map(l => (
                <tr key={l.loan_id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="px-3 py-2 font-semibold text-sky-400">{l.loan_id}</td>
                  <td className="px-3 py-2 font-sans text-slate-300 truncate max-w-[120px]">{l.region}</td>
                  <td className="px-3 py-2 font-sans text-slate-400">{l.property_type}</td>
                  <td className="px-3 py-2 text-right">£{l.property_value.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right font-medium text-white">£{l.current_balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                  <td className="px-3 py-2 text-right">{(l.ltv * 100).toFixed(1)}%</td>
                  <td className="px-3 py-2 text-center font-bold text-slate-200">{l.credit_grade}</td>
                  <td className="px-3 py-2 text-right">{(l.contractual_rate * 100).toFixed(2)}%</td>
                  <td className="px-3 py-2 text-right">{l.remaining_term_months}m</td>
                  <td className="px-3 py-2 font-sans">
                    <span className={`text-[10px] ${
                      l.delinquency_state === 'Current'
                        ? 'text-emerald-400'
                        : l.delinquency_state === '30_Days_Arrears'
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}>
                      {l.delinquency_state.replace(/_/g, ' ')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="text-[11px] text-slate-500 text-right">
          Showing top 15 records · Export full dataset for all {loans.length} loan accounts.
        </div>
      </div>
    </div>
  );
};
