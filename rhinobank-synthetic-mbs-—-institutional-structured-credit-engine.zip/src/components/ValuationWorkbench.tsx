import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  Percent,
  Sliders,
  Activity,
  Layers,
  ArrowUpDown
} from 'lucide-react';
import {
  TrancheValuation,
  YieldCurvePoint
} from '../types/mbs';

interface ValuationWorkbenchProps {
  valuations: TrancheValuation[];
  yieldCurve: YieldCurvePoint[];
  discountSpreadBps: number;
  onUpdateDiscountSpread: (bps: number) => void;
}

export const ValuationWorkbench: React.FC<ValuationWorkbenchProps> = ({
  valuations,
  yieldCurve,
  discountSpreadBps,
  onUpdateDiscountSpread
}) => {
  const [curveShockBps, setCurveShockBps] = useState(0);

  // Apply shock for display
  const shockedCurve = yieldCurve.map(pt => {
    const bumpedRate = Math.max(pt.zeroRate + curveShockBps / 10000, 0.0001);
    const bumpedDf = Math.exp(-bumpedRate * pt.maturity);
    return {
      maturity: pt.maturity,
      zeroRate: bumpedRate,
      discountFactor: bumpedDf
    };
  });

  const totalPv = valuations.reduce((acc, v) => acc + v.present_value, 0);
  const totalDv01 = valuations.reduce((acc, v) => acc + v.dv01_gbp, 0);

  return (
    <div className="space-y-6">
      {/* Top Controls & Portfolio Valuation Summary */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-wide">
              Tranche Valuation Workbench & Interest-Rate Sensitivity
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Discounted expected cash-flow pricing (<span className="font-mono text-slate-300">PV = Σ CF(t) · DF(t)</span>), spread duration, and DV01 profiling.
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="text-right">
              <span className="text-slate-400 block text-[10px] uppercase font-sans">Aggregate Model PV</span>
              <span className="text-white font-bold text-base">£{totalPv.toLocaleString()}</span>
            </div>
            <div className="text-right pl-4 border-l border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-sans">Portfolio DV01</span>
              <span className="text-sky-400 font-bold text-base">£{totalDv01.toLocaleString()}/bp</span>
            </div>
          </div>
        </div>

        {/* Shock Sliders */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-800 text-xs">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-300">Yield Curve Parallel Shift (bps)</span>
              <span className="font-mono text-white font-medium">
                {curveShockBps > 0 ? `+${curveShockBps}` : curveShockBps} bps
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurveShockBps(-100)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-[11px] rounded text-slate-300 cursor-pointer"
              >
                -100 bps
              </button>
              <button
                onClick={() => setCurveShockBps(0)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-[11px] rounded text-slate-300 cursor-pointer"
              >
                Flat (0)
              </button>
              <button
                onClick={() => setCurveShockBps(100)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-[11px] rounded text-slate-300 cursor-pointer"
              >
                +100 bps
              </button>
              <button
                onClick={() => setCurveShockBps(200)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-[11px] rounded text-slate-300 cursor-pointer"
              >
                +200 bps
              </button>
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-300">Additional Discount Spread Margin</span>
              <span className="font-mono text-white font-medium">+{discountSpreadBps} bps</span>
            </div>
            <input
              type="range"
              min="0"
              max="300"
              step="10"
              value={discountSpreadBps}
              onChange={e => onUpdateDiscountSpread(Number(e.target.value))}
              className="w-full accent-sky-400"
            />
          </div>
        </div>
      </div>

      {/* Tranche Pricing Table */}
      <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
        <h3 className="text-sm font-semibold text-white tracking-wide">
          Tranche Pricing & Sensitivity Matrix
        </h3>

        <div className="overflow-x-auto border border-slate-800 rounded">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-800">
            <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] tracking-wider font-semibold">
              <tr>
                <th className="px-3 py-2.5">Tranche</th>
                <th className="px-3 py-2.5 text-right">Par Notional (£)</th>
                <th className="px-3 py-2.5 text-right">Modeled PV (£)</th>
                <th className="px-3 py-2.5 text-right">Clean Price (%)</th>
                <th className="px-3 py-2.5 text-right">WAL (Yrs)</th>
                <th className="px-3 py-2.5 text-right">Spread Dur</th>
                <th className="px-3 py-2.5 text-right">DV01 (£/bp)</th>
                <th className="px-3 py-2.5 text-right">Breakeven Spread</th>
                <th className="px-3 py-2.5 text-center">Impairment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {valuations.map(val => (
                <tr key={val.tranche_id} className="hover:bg-slate-800/40">
                  <td className="px-3 py-2 font-semibold text-white font-sans">{val.tranche_id}</td>
                  <td className="px-3 py-2 text-right">£{val.initial_notional.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right font-medium text-sky-400">£{val.present_value.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right font-bold text-white">{val.clean_price.toFixed(2)}%</td>
                  <td className="px-3 py-2 text-right">{val.wal_years.toFixed(1)}y</td>
                  <td className="px-3 py-2 text-right">{val.spread_duration.toFixed(2)}</td>
                  <td className="px-3 py-2 text-right">£{val.dv01_gbp.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right text-amber-300">{val.breakeven_spread_bps} bps</td>
                  <td className="px-3 py-2 text-center font-sans">
                    <span className={`text-[10px] ${val.impaired ? 'text-rose-400 font-semibold' : 'text-emerald-400'}`}>
                      {val.impaired ? 'IMPAIRED' : 'Nominal'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Yield Curve & Discount Factor Graph */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white tracking-wide">
              SONIA Benchmark Discount Curve & Zero Rates
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Status: SIMULATED_RESEARCH_ONLY
            </span>
          </div>

          {/* SVG Yield Curve Graph */}
          <div className="h-48 w-full pt-2">
            <svg className="w-full h-full" viewBox="0 0 500 160" preserveAspectRatio="none">
              {/* Gridlines */}
              <line x1="0" y1="30" x2="500" y2="30" stroke="#1E293B" strokeDasharray="3 3" />
              <line x1="0" y1="75" x2="500" y2="75" stroke="#1E293B" strokeDasharray="3 3" />
              <line x1="0" y1="120" x2="500" y2="120" stroke="#1E293B" strokeDasharray="3 3" />

              {/* Base Line */}
              <polyline
                fill="none"
                stroke="#64748B"
                strokeWidth="2"
                strokeDasharray="4 4"
                points={yieldCurve.map((pt, idx) => {
                  const x = 20 + (idx / (yieldCurve.length - 1)) * 460;
                  const y = 140 - (pt.zeroRate / 0.07) * 110;
                  return `${x},${y}`;
                }).join(' ')}
              />

              {/* Shocked / Current Line */}
              <polyline
                fill="none"
                stroke="#0284C7"
                strokeWidth="2.5"
                points={shockedCurve.map((pt, idx) => {
                  const x = 20 + (idx / (shockedCurve.length - 1)) * 460;
                  const y = 140 - (pt.zeroRate / 0.07) * 110;
                  return `${x},${y}`;
                }).join(' ')}
              />

              {/* Points */}
              {shockedCurve.map((pt, idx) => {
                const x = 20 + (idx / (shockedCurve.length - 1)) * 460;
                const y = 140 - (pt.zeroRate / 0.07) * 110;
                return (
                  <g key={pt.maturity}>
                    <circle cx={x} cy={y} r="3" fill="#38BDF8" />
                    <text x={x} y="154" textAnchor="middle" fill="#64748B" fontSize="9" fontFamily="monospace">
                      {pt.maturity}Y
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-400 pt-1">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-slate-500 inline-block"></span>
              Base SONIA Zero Curve (4.50% Anchor)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-sky-400 inline-block"></span>
              Scenario Shifted Curve ({curveShockBps >= 0 ? `+${curveShockBps}` : curveShockBps} bps)
            </span>
          </div>
        </div>

        {/* Key Rate Duration Profile */}
        <div className="lg:col-span-4 bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
          <h3 className="text-sm font-semibold text-white tracking-wide">
            Key-Rate Durations (KRD)
          </h3>
          <p className="text-xs text-slate-400">
            Localized curve slope sensitivity by tenor bucket.
          </p>

          <div className="space-y-2 text-xs font-mono pt-1">
            <div className="flex justify-between p-2 bg-slate-800/40 rounded">
              <span className="text-slate-300">1-Year Tenor:</span>
              <span className="text-white font-bold">0.42y</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-800/40 rounded">
              <span className="text-slate-300">2-Year Tenor:</span>
              <span className="text-white font-bold">1.18y</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-800/40 rounded">
              <span className="text-slate-300">5-Year Tenor:</span>
              <span className="text-white font-bold">2.65y</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-800/40 rounded">
              <span className="text-slate-300">10-Year Tenor:</span>
              <span className="text-white font-bold">0.84y</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
