import React, { useState } from 'react';
import {
  ShieldAlert,
  FileText,
  Download,
  CheckCircle,
  Clock,
  AlertTriangle,
  Code
} from 'lucide-react';
import { TrancheDefinition, WaterfallOutput, SyntheticCRTStructure } from '../types/mbs';

interface ModelGovernancePanelProps {
  tranches: TrancheDefinition[];
  waterfall: WaterfallOutput;
  crt: SyntheticCRTStructure;
  onExportDossier: () => void;
}

export const ModelGovernancePanel: React.FC<ModelGovernancePanelProps> = ({
  tranches,
  waterfall,
  crt,
  onExportDossier
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'inventory' | 'quarto' | 'limitations'>('inventory');

  const quartoCode = `---
title: "RHINO BANK SYNTHETIC MBS — INSTITUTIONAL STRUCTURED CREDIT DOSSIER"
subtitle: "Valuation, Cash-Flow Waterfall, Synthetic CRT and Model Risk Validation Report"
author: "Rhino Bank Quantitative Credit Research & Model Risk Oversight"
date: "2026-10-11"
format:
  html:
    theme: flatly
    toc: true
    number-sections: true
    self-contained: true
---

# Executive Summary

This report documents the quantitative valuation, cash-flow waterfall allocation, and stress testing for Transaction RHN-SYNTH-MBS-2026-CR1, a £1,000,000,000 synthetic mortgage-backed securities credit risk transfer structure.

**Statutory Disclosure:** All mortgage loans modeled herein are purely synthetic and generated via calibrated statistical distributions. Model outputs reflect hypothetical quantitative evaluations and do not constitute executable trading quotes, formal credit ratings, or guaranteed capital relief under UK/EU regulatory frameworks.

## Key Transaction Parameters
- Reference Pool Gross Balance: £1,000,000,000
- Protected Mezzanine Band: 2.5% – 9.5% (£70,000,000)
- Retained First-Loss Position: 0.0% – 2.5% (£25,000,000)
- Benchmark Rate: SONIA (4.50% base anchor)

## Mathematical Loss Allocation Function
Phi(L) = min(max((L - A) / (D - A), 0), 1)

# PRA SS1/23 Model Governance
- Model ID: RHN-MRG-MBS-2026-04 (Tier 1 High Materiality)
- Validation Status: VALIDATED FOR RESEARCH AND HYPOTHETICAL STRUCTURING ONLY
- Supervisory Notice: Significant Risk Transfer (SRT) subject to PRA formal notification.`;

  const handleDownloadQuarto = () => {
    const blob = new Blob([quartoCode], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'rhinobank_mbs_valuation_and_risk_report.qmd';
    link.click();
  };

  const handleDownloadConfigJson = () => {
    const config = {
      deal_name: "RHINO BANK SYNTHETIC MBS 2026-CR1",
      governance_id: "RHN-MRG-MBS-2026-04",
      reference_pool_balance_gbp: 1000000000,
      tranches: tranches.map(t => ({
        id: t.id,
        name: t.name,
        attachment: t.attachment_pt,
        detachment: t.detachment_pt,
        notional_gbp: t.initial_notional,
        spread_bps: t.coupon_spread_bps
      })),
      timestamp: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'transaction_config.json';
    link.click();
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-white tracking-wide">
            Model Risk Governance & Regulatory Compliance (PRA SS1/23)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Bank of England Supervisory Statement SS1/23 'Model risk management principles for banks' alignment and Quarto dossier generator.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadConfigJson}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Config JSON</span>
          </button>
          <button
            onClick={handleDownloadQuarto}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-sky-400 hover:bg-sky-300 rounded cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Quarto (.qmd)</span>
          </button>
        </div>
      </div>

      {/* Sub-tab navigation */}
      <div className="flex items-center gap-3 border-b border-slate-800 text-xs">
        <button
          onClick={() => setActiveSubTab('inventory')}
          className={`pb-2 font-medium cursor-pointer ${activeSubTab === 'inventory' ? 'text-white border-b-2 border-sky-400 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Model Inventory Card
        </button>
        <button
          onClick={() => setActiveSubTab('limitations')}
          className={`pb-2 font-medium cursor-pointer ${activeSubTab === 'limitations' ? 'text-white border-b-2 border-sky-400 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Known Model Limitations & Assumptions
        </button>
        <button
          onClick={() => setActiveSubTab('quarto')}
          className={`pb-2 font-medium cursor-pointer ${activeSubTab === 'quarto' ? 'text-white border-b-2 border-sky-400 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Quarto Institutional Report Preview
        </button>
      </div>

      {/* Tab: Model Inventory Card */}
      {activeSubTab === 'inventory' && (
        <div className="space-y-4">
          <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-4 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="text-slate-400">Model Identifier:</div>
                <div className="text-sm font-mono font-bold text-white">RHN-MRG-MBS-2026-04</div>

                <div className="text-slate-400 pt-2">Model Materiality Tier:</div>
                <div className="text-white font-medium">Tier 1 — High Materiality (Direct Balance Sheet & Capital Implication)</div>

                <div className="text-slate-400 pt-2">Model Lifecycle State:</div>
                <div className="p-2 bg-amber-950/50 border border-amber-800/80 rounded text-amber-300 font-medium font-mono text-[11px]">
                  VALIDATED_FOR_RESEARCH_AND_HYPOTHETICAL_STRUCTURING_ONLY
                </div>
                <p className="text-[11px] text-slate-500 italic">
                  Note: A model must not label itself production-approved simply because its tests pass. Formal Credit Committee approval required.
                </p>
              </div>

              <div className="space-y-2">
                <div className="text-slate-400">Model Ownership:</div>
                <div className="text-white">Quantitative Credit Research & Structured Financing Group</div>

                <div className="text-slate-400 pt-2">Independent Validation Body:</div>
                <div className="text-white">Model Risk Oversight (MRO) Division, Rhino Bank</div>

                <div className="text-slate-400 pt-2">Validation Date & Frequency:</div>
                <div className="text-white">2026-02-14 · Annual Independent Review Cycle</div>

                <div className="text-slate-400 pt-2">PRA SS1/23 Alignment Status:</div>
                <div className="text-emerald-400 font-medium flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Compliant with Principles 1 through 5 (Governance, Scope, Conceptual Soundness, Ongoing Monitoring)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Limitations */}
      {activeSubTab === 'limitations' && (
        <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3 text-xs">
          <h3 className="text-sm font-semibold text-white tracking-wide flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            Statutory Limitations & Assumption Register
          </h3>

          <div className="space-y-2.5 pt-1 text-slate-300">
            <div className="p-3 bg-slate-800/40 rounded">
              <strong className="text-white block mb-0.5">1. Synthetic Data Provenance</strong>
              All loan accounts, borrowers, property values, and arrears histories are synthetically simulated using calibrated statistical distributions. They do not represent real individuals or live Rhino Bank customers.
            </div>

            <div className="p-3 bg-slate-800/40 rounded">
              <strong className="text-white block mb-0.5">2. Gaussian Copula Tail Dependence Limitation</strong>
              The Monte Carlo common-factor copula assumes Gaussian latent asset returns (ρ = 0.18). It does not capture extreme asymptotic joint tail dependence where defaults cluster beyond multivariate normal bounds.
            </div>

            <div className="p-3 bg-slate-800/40 rounded">
              <strong className="text-white block mb-0.5">3. Non-Executable Indicative Valuation</strong>
              Present values, yields, and clean prices are model indications generated for research and structuring optimization. They do not constitute executable broker quotes or bids in wholesale markets.
            </div>

            <div className="p-3 bg-slate-800/40 rounded">
              <strong className="text-white block mb-0.5">4. Significant Risk Transfer (SRT) Supervisory Distinction</strong>
              Achieving regulatory capital relief requires formal notification and supervisory non-objection under the UK Securitisation Regulations and PRA SS1/23, supported by independent legal enforceability opinions.
            </div>
          </div>
        </div>
      )}

      {/* Tab: Quarto Preview */}
      {activeSubTab === 'quarto' && (
        <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white tracking-wide flex items-center gap-2">
              <FileText className="w-4 h-4 text-sky-400" />
              Quarto Report Document Source (.qmd)
            </h3>
            <button
              onClick={handleDownloadQuarto}
              className="px-2.5 py-1 text-xs bg-sky-400 hover:bg-sky-300 text-slate-900 font-semibold rounded cursor-pointer"
            >
              Export .qmd
            </button>
          </div>
          <div className="bg-slate-950 border border-slate-800 rounded p-3 overflow-x-auto max-h-96">
            <pre className="text-xs font-mono text-slate-200 leading-relaxed whitespace-pre">
              {quartoCode}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
