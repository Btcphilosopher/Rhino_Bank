import React, { useState } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  Sliders,
  RotateCcw,
  Layers,
  ChevronDown,
  Check
} from 'lucide-react';
import { TrancheDefinition, WaterfallOutput } from '../types/mbs';

interface WaterfallStructureEditorProps {
  tranches: TrancheDefinition[];
  waterfall: WaterfallOutput;
  cprAnnual: number;
  cdrAnnual: number;
  recoveryRate: number;
  onUpdateTranches: (newTranches: TrancheDefinition[]) => void;
  onUpdateAssumptions: (cpr: number, cdr: number, rec: number) => void;
}

export const WaterfallStructureEditor: React.FC<WaterfallStructureEditorProps> = ({
  tranches,
  waterfall,
  cprAnnual,
  cdrAnnual,
  recoveryRate,
  onUpdateTranches,
  onUpdateAssumptions
}) => {
  const [cpr, setCpr] = useState(cprAnnual * 100);
  const [cdr, setCdr] = useState(cdrAnnual * 100);
  const [rec, setRec] = useState(recoveryRate * 100);

  // Editable tranches state
  const [editableTranches, setEditableTranches] = useState<TrancheDefinition[]>(tranches);
  const [editError, setEditError] = useState<string | null>(null);

  const handleApplyAssumptions = () => {
    onUpdateAssumptions(cpr / 100, cdr / 100, rec / 100);
  };

  const handleTrancheChange = (index: number, field: keyof TrancheDefinition, value: any) => {
    const updated = [...editableTranches];
    updated[index] = { ...updated[index], [field]: value };
    setEditableTranches(updated);
  };

  const handleSaveTranches = () => {
    // Validate boundaries
    for (const tr of editableTranches) {
      if (tr.detachment_pt <= tr.attachment_pt) {
        setEditError(`Tranche ${tr.name}: Detachment (${(tr.detachment_pt * 100).toFixed(1)}%) must be greater than Attachment (${(tr.attachment_pt * 100).toFixed(1)}%).`);
        return;
      }
    }
    setEditError(null);
    onUpdateTranches(editableTranches);
  };

  const totalPoolBalance = waterfall.periods[0].opening_balance;

  return (
    <div className="space-y-6">
      {/* Header & Control Bar */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-wide">
              MBS Tranche Waterfall Engine & Capital Structure Designer
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Multi-tier liability waterfall, performance triggers, reserve account mechanics, and strict cash-flow conservation.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-1.5 px-3 py-1 text-xs rounded border ${
              waterfall.conservation_valid
                ? 'bg-emerald-950/50 border-emerald-800 text-emerald-300'
                : 'bg-rose-950/50 border-rose-800 text-rose-300'
            }`}>
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Conservation Law: {waterfall.conservation_valid ? 'Reconciled' : 'Discrepancy'}</span>
            </div>
            <button
              onClick={handleSaveTranches}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-900 bg-sky-400 hover:bg-sky-300 rounded cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply Structure</span>
            </button>
          </div>
        </div>

        {editError && (
          <div className="p-2.5 bg-rose-950/60 border border-rose-800 rounded text-xs text-rose-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{editError}</span>
          </div>
        )}

        {/* Behavioral & Macro Assumption Sliders */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2 border-t border-slate-800">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Prepayment Rate (CPR)</span>
              <span className="font-mono text-white font-medium">{cpr.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="1"
              max="25"
              step="0.5"
              value={cpr}
              onChange={e => setCpr(Number(e.target.value))}
              onMouseUp={handleApplyAssumptions}
              onTouchEnd={handleApplyAssumptions}
              className="w-full accent-sky-400"
            />
            <span className="text-[10px] text-slate-500">SMM: {(1 - Math.pow(1 - cpr / 100, 1 / 12)).toFixed(4)}/mo</span>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Default Rate (CDR)</span>
              <span className="font-mono text-white font-medium">{cdr.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="10"
              step="0.1"
              value={cdr}
              onChange={e => setCdr(Number(e.target.value))}
              onMouseUp={handleApplyAssumptions}
              onTouchEnd={handleApplyAssumptions}
              className="w-full accent-amber-400"
            />
            <span className="text-[10px] text-slate-500">MDR: {(1 - Math.pow(1 - cdr / 100, 1 / 12)).toFixed(4)}/mo</span>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Liquidation Recovery</span>
              <span className="font-mono text-white font-medium">{rec.toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="90"
              step="5"
              value={rec}
              onChange={e => setRec(Number(e.target.value))}
              onMouseUp={handleApplyAssumptions}
              onTouchEnd={handleApplyAssumptions}
              className="w-full accent-emerald-400"
            />
            <span className="text-[10px] text-slate-500">Net LGD: {(100 - rec).toFixed(0)}%</span>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Sequential Trigger</span>
              <span className="font-mono text-white font-medium">2.5% Loss</span>
            </div>
            <div className="text-xs text-slate-400 pt-1">
              Locks waterfall into sequential paydown if pool losses exceed £25.0m.
            </div>
          </div>
        </div>
      </div>

      {/* Tranche Configuration Table */}
      <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
        <h3 className="text-sm font-semibold text-white tracking-wide">
          Tranche Capital Structure Definition
        </h3>

        <div className="overflow-x-auto border border-slate-800 rounded">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-800">
            <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] tracking-wider font-semibold">
              <tr>
                <th className="px-3 py-2.5">Tranche ID</th>
                <th className="px-3 py-2.5">Attachment (A)</th>
                <th className="px-3 py-2.5">Detachment (D)</th>
                <th className="px-3 py-2.5 text-right">Notional (£)</th>
                <th className="px-3 py-2.5 text-right">Coupon Spread</th>
                <th className="px-3 py-2.5">Classification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {editableTranches.map((tr, idx) => (
                <tr key={tr.id} className="hover:bg-slate-800/30">
                  <td className="px-3 py-2 font-semibold text-white font-sans">{tr.name}</td>
                  <td className="px-3 py-2">
                    <input
                      type="number"
                      step="0.005"
                      min="0"
                      max="1"
                      value={tr.attachment_pt}
                      onChange={e => handleTrancheChange(idx, 'attachment_pt', Number(e.target.value))}
                      className="w-20 px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200"
                    />
                  </td>
                  <td className="px-3 py-2">
                    <input
                      type="number"
                      step="0.005"
                      min="0"
                      max="1"
                      value={tr.detachment_pt}
                      onChange={e => handleTrancheChange(idx, 'detachment_pt', Number(e.target.value))}
                      className="w-20 px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200"
                    />
                  </td>
                  <td className="px-3 py-2 text-right font-medium text-slate-200">
                    £{tr.initial_notional.toLocaleString()}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <input
                      type="number"
                      step="10"
                      value={tr.coupon_spread_bps}
                      onChange={e => handleTrancheChange(idx, 'coupon_spread_bps', Number(e.target.value))}
                      className="w-20 px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200 text-right"
                    />
                    <span className="text-slate-400 ml-1 font-sans">bps</span>
                  </td>
                  <td className="px-3 py-2 font-sans text-slate-300">
                    <select
                      value={tr.risk_type}
                      onChange={e => handleTrancheChange(idx, 'risk_type', e.target.value)}
                      className="px-2 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200 text-xs"
                    >
                      <option value="Retained Senior">Retained Senior</option>
                      <option value="Protected Mezzanine">Protected Mezzanine</option>
                      <option value="Protected Junior">Protected Junior</option>
                      <option value="Retained First-Loss">Retained First-Loss</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Period-by-Period Waterfall Cash-Flow Ledger Table */}
      <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white tracking-wide">
            Period-by-Period Cash-Flow Waterfall Ledger (Months 1–24)
          </h3>
          <span className="text-xs text-slate-400">
            Cumulative Pool Losses: £{(waterfall.cumulative_pool_loss / 1e6).toFixed(2)}m
          </span>
        </div>

        <div className="overflow-x-auto border border-slate-800 rounded max-h-96">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-800">
            <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] tracking-wider font-semibold sticky top-0">
              <tr>
                <th className="px-3 py-2.5">Period</th>
                <th className="px-3 py-2.5 text-right">Avail. Principal</th>
                <th className="px-3 py-2.5 text-right">Alloc. Principal</th>
                <th className="px-3 py-2.5 text-right">Avail. Interest</th>
                <th className="px-3 py-2.5 text-right">Alloc. Interest</th>
                <th className="px-3 py-2.5 text-right">Senior Prin Paid</th>
                <th className="px-3 py-2.5 text-right">Reserve Fund</th>
                <th className="px-3 py-2.5 text-right">Excess Spread</th>
                <th className="px-3 py-2.5 text-center">Trigger</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {waterfall.ledger_summary.slice(0, 24).map(row => {
                const srLedger = waterfall.tranche_ledgers['tranche_a']?.[row.period - 1];
                const srPaid = srLedger?.principal_paid || 0;

                return (
                  <tr key={row.period} className="hover:bg-slate-800/40">
                    <td className="px-3 py-2 font-semibold text-slate-400 font-sans">M{row.period}</td>
                    <td className="px-3 py-2 text-right">£{row.available_principal.toLocaleString()}</td>
                    <td className="px-3 py-2 text-right text-emerald-400">£{row.allocated_principal.toLocaleString()}</td>
                    <td className="px-3 py-2 text-right">£{row.available_interest.toLocaleString()}</td>
                    <td className="px-3 py-2 text-right text-sky-400">£{row.allocated_interest.toLocaleString()}</td>
                    <td className="px-3 py-2 text-right text-white font-medium">£{srPaid.toLocaleString()}</td>
                    <td className="px-3 py-2 text-right">£{row.reserve_fund_balance.toLocaleString()}</td>
                    <td className="px-3 py-2 text-right text-amber-300">£{row.excess_spread.toLocaleString()}</td>
                    <td className="px-3 py-2 text-center font-sans">
                      <span className={`text-[10px] ${row.trigger_breached ? 'text-rose-400 font-semibold' : 'text-slate-500'}`}>
                        {row.trigger_breached ? 'BREACHED' : 'Nominal'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
