import React, { useState } from 'react';
import {
  Play,
  RotateCcw,
  ShieldAlert,
  TrendingDown,
  Layers,
  BarChart2,
  CheckCircle2
} from 'lucide-react';
import { MonteCarloSummary, TrancheDefinition } from '../types/mbs';

interface MonteCarloSimulatorProps {
  monteCarlo: MonteCarloSummary;
  tranches: TrancheDefinition[];
  onRunSimulation: (nSims: number, rho: number, seed: number) => void;
}

export const MonteCarloSimulator: React.FC<MonteCarloSimulatorProps> = ({
  monteCarlo,
  tranches,
  onRunSimulation
}) => {
  const [nSims, setNSims] = useState(monteCarlo.n_simulations);
  const [rho, setRho] = useState(monteCarlo.asset_correlation);
  const [seed, setSeed] = useState(monteCarlo.seed);
  const [isSimulating, setIsSimulating] = useState(false);

  const handleRun = () => {
    setIsSimulating(true);
    setTimeout(() => {
      onRunSimulation(nSims, rho, seed);
      setIsSimulating(false);
    }, 150);
  };

  const maxFreq = Math.max(...monteCarlo.histogram_bins.map(b => b.freq), 1);

  return (
    <div className="space-y-6">
      {/* Simulation Configuration Bar */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-wide">
              Monte Carlo Credit Portfolio Simulation Engine
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Gaussian common-factor copula (<span className="font-mono text-slate-300">Y = √ρ·Z + √(1-ρ)·ε</span>) with stochastic default and prepayment clustering.
            </p>
          </div>
          <button
            onClick={handleRun}
            disabled={isSimulating}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-900 bg-sky-400 hover:bg-sky-300 disabled:opacity-50 rounded cursor-pointer transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isSimulating ? 'Simulating Paths...' : `Execute ${nSims.toLocaleString()} Paths`}</span>
          </button>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-slate-800 text-xs">
          <div>
            <label className="text-slate-300 font-medium block mb-1">Path Count (N)</label>
            <select
              value={nSims}
              onChange={e => setNSims(Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none"
            >
              <option value={250}>250 Iterations (Fast Preview)</option>
              <option value={500}>500 Iterations</option>
              <option value={1000}>1,000 Iterations (Standard)</option>
              <option value={2500}>2,500 Iterations (High Precision)</option>
              <option value={5000}>5,000 Iterations (Institutional Baseline)</option>
            </select>
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-300 font-medium">Systemic Asset Correlation (ρ)</span>
              <span className="font-mono text-white font-medium">{rho.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.35"
              step="0.01"
              value={rho}
              onChange={e => setRho(Number(e.target.value))}
              className="w-full accent-sky-400"
            />
            <span className="text-[10px] text-slate-500">Basel IRB Retail Mortgage standard: 0.15 – 0.22</span>
          </div>

          <div>
            <label className="text-slate-300 font-medium block mb-1">Deterministic Seed</label>
            <input
              type="number"
              value={seed}
              onChange={e => setSeed(Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Tail Risk Metric Tiles */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3 bg-slate-900/50 border border-slate-800 rounded">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            Expected Pool Loss
          </div>
          <div className="text-lg font-bold font-mono text-white tabular-nums mt-1">
            £{(monteCarlo.mean_pool_loss_gbp / 1e6).toFixed(2)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{monteCarlo.mean_pool_loss_pct.toFixed(2)}% of pool</div>
        </div>

        <div className="p-3 bg-slate-900/50 border border-slate-800 rounded">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            95.0% VaR (5Y Horizon)
          </div>
          <div className="text-lg font-bold font-mono text-slate-200 tabular-nums mt-1">
            £{(monteCarlo.var_95_gbp / 1e6).toFixed(2)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{((monteCarlo.var_95_gbp / 1e9) * 100).toFixed(2)}% of pool</div>
        </div>

        <div className="p-3 bg-slate-900/50 border border-slate-800 rounded">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-amber-400">
            99.0% VaR (Prudential)
          </div>
          <div className="text-lg font-bold font-mono text-amber-300 tabular-nums mt-1">
            £{(monteCarlo.var_99_gbp / 1e6).toFixed(2)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{((monteCarlo.var_99_gbp / 1e9) * 100).toFixed(2)}% of pool</div>
        </div>

        <div className="p-3 bg-slate-900/50 border border-slate-800 rounded">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-rose-400">
            99.9% VaR (Extreme Tail)
          </div>
          <div className="text-lg font-bold font-mono text-rose-300 tabular-nums mt-1">
            £{(monteCarlo.var_999_gbp / 1e6).toFixed(2)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{((monteCarlo.var_999_gbp / 1e9) * 100).toFixed(2)}% of pool</div>
        </div>

        <div className="p-3 bg-slate-900/50 border border-slate-800 rounded">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-sky-400">
            99.0% Expected Shortfall
          </div>
          <div className="text-lg font-bold font-mono text-sky-300 tabular-nums mt-1">
            £{(monteCarlo.expected_shortfall_99_gbp / 1e6).toFixed(2)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">CVaR beyond 99%</div>
        </div>

        <div className="p-3 bg-slate-900/50 border border-slate-800 rounded">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-sky-400">
            99.9% Expected Shortfall
          </div>
          <div className="text-lg font-bold font-mono text-sky-300 tabular-nums mt-1">
            £{(monteCarlo.expected_shortfall_999_gbp / 1e6).toFixed(2)}m
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">CVaR beyond 99.9%</div>
        </div>
      </div>

      {/* Distribution Histogram & Convergence */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Loss Distribution Histogram (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white tracking-wide">
              Simulated Cumulative Pool Loss Density
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              N = {monteCarlo.n_simulations.toLocaleString()} paths · Seed: {monteCarlo.seed}
            </span>
          </div>

          {/* SVG Histogram */}
          <div className="h-56 w-full pt-2">
            <svg className="w-full h-full" viewBox="0 0 520 180" preserveAspectRatio="none">
              {/* Gridlines */}
              <line x1="0" y1="40" x2="520" y2="40" stroke="#1E293B" strokeDasharray="3 3" />
              <line x1="0" y1="90" x2="520" y2="90" stroke="#1E293B" strokeDasharray="3 3" />
              <line x1="0" y1="140" x2="520" y2="140" stroke="#1E293B" strokeDasharray="3 3" />

              {/* Histogram bars */}
              {monteCarlo.histogram_bins.map((bin, idx) => {
                const x = 20 + idx * 24;
                const h = (bin.freq / maxFreq) * 125;
                const y = 155 - h;

                return (
                  <g key={idx}>
                    <rect x={x} y={y} width="20" height={h} fill="#0284C7" rx="1" />
                    {idx % 4 === 0 && (
                      <text x={x + 10} y="170" textAnchor="middle" fill="#64748B" fontSize="8" fontFamily="monospace">
                        £{(bin.binStart / 1e6).toFixed(0)}m
                      </text>
                    )}
                  </g>
                );
              })}

              {/* 99% VaR Line */}
              <line x1="410" y1="10" x2="410" y2="155" stroke="#F43F5E" strokeWidth="2" strokeDasharray="4 2" />
              <text x="405" y="24" textAnchor="end" fill="#F43F5E" fontSize="9" fontWeight="bold">
                99% VaR (£{(monteCarlo.var_99_gbp / 1e6).toFixed(1)}m)
              </text>
            </svg>
          </div>

          <div className="text-xs text-slate-400 flex items-center justify-between pt-1">
            <span>Minimum Loss: £{(monteCarlo.histogram_bins[0]?.binStart / 1e6).toFixed(1)}m</span>
            <span>Maximum Tail Loss: £{(monteCarlo.histogram_bins[monteCarlo.histogram_bins.length - 1]?.binEnd / 1e6).toFixed(1)}m</span>
          </div>
        </div>

        {/* Tranche Impairment Frequencies & Convergence (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/50 border border-slate-800 rounded p-4 space-y-4">
          <h3 className="text-sm font-semibold text-white tracking-wide">
            Tranche Impairment Probability (5Y Horizon)
          </h3>

          <div className="space-y-2 text-xs">
            {monteCarlo.tranche_impairment_rates.map(t => (
              <div key={t.tranche_id} className="p-2.5 bg-slate-800/40 rounded flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-200">{t.tranche_id}</span>
                  <div className="text-[11px] text-slate-400">
                    Mean loss: £{(t.mean_loss_gbp / 1e6).toFixed(2)}m
                  </div>
                </div>
                <div className="text-right font-mono tabular-nums">
                  <span className={`font-bold text-sm ${t.impairment_prob > 20 ? 'text-rose-400' : t.impairment_prob > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {t.impairment_prob.toFixed(1)}%
                  </span>
                  <div className="text-[10px] text-slate-500">impairment freq</div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-800/30 border border-slate-700/40 rounded text-xs text-slate-400 space-y-1">
            <div className="font-semibold text-slate-200">Monte Carlo Convergence Diagnostic:</div>
            <div>
              Standard error of estimation: <span className="font-mono text-white">±£{(monteCarlo.convergence_points[monteCarlo.convergence_points.length - 1]?.se / 1e6).toFixed(2)}m</span>
            </div>
            <div className="text-[11px] text-slate-500">
              Confidence interval satisfies central limit theorem convergence criteria.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
