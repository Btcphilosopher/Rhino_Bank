import React, { useState } from 'react';
import {
  AlertTriangle,
  Flame,
  RotateCcw,
  Sliders,
  Scale,
  ShieldCheck,
  Compass
} from 'lucide-react';
import {
  StressScenarioDef,
  ReverseStressResult,
  TrancheDefinition
} from '../types/mbs';
import { solveReverseStressTest } from '../engine/mbsEngine';

interface StressTestingLabProps {
  scenarios: StressScenarioDef[];
  tranches: TrancheDefinition[];
}

export const StressTestingLab: React.FC<StressTestingLabProps> = ({
  scenarios,
  tranches
}) => {
  const [selectedTrancheId, setSelectedTrancheId] = useState(tranches[1]?.id || 'tranche_b');
  const [reverseResult, setReverseResult] = useState<ReverseStressResult>(() =>
    solveReverseStressTest(tranches, tranches[1]?.id || 'tranche_b')
  );

  const handleTrancheSelect = (id: string) => {
    setSelectedTrancheId(id);
    setReverseResult(solveReverseStressTest(tranches, id));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded">
        <h2 className="text-sm font-semibold text-white tracking-wide">
          Institutional Stress Testing & Reverse Stress Testing Suite
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Benchmarked against Bank of England / PRA annual cyclical stress test (ACS) scenarios and internal Rhino Bank extreme risk thresholds.
        </p>
      </div>

      {/* 12 Scenarios Table */}
      <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white tracking-wide">
            12 Standard Macroeconomic & Behavioral Stress Scenarios
          </h3>
          <span className="text-xs text-slate-400">5-Year Cumulative Horizon</span>
        </div>

        <div className="overflow-x-auto border border-slate-800 rounded">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-800">
            <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] tracking-wider font-semibold">
              <tr>
                <th className="px-3 py-2.5">Scenario Name</th>
                <th className="px-3 py-2.5 text-right">HPI Shock</th>
                <th className="px-3 py-2.5 text-right">Unemp.</th>
                <th className="px-3 py-2.5 text-right">Rate Shock</th>
                <th className="px-3 py-2.5 text-right">Rec. Rate</th>
                <th className="px-3 py-2.5 text-right">Pool Loss (%)</th>
                <th className="px-3 py-2.5 text-right">Pool Loss (£)</th>
                <th className="px-3 py-2.5">Impaired Tranches</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px] tabular-nums">
              {scenarios.map(sc => (
                <tr key={sc.id} className="hover:bg-slate-800/40">
                  <td className="px-3 py-2 font-semibold text-white font-sans">
                    {sc.name}
                  </td>
                  <td className={`px-3 py-2 text-right ${sc.hpi_shock_pct < 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                    {sc.hpi_shock_pct > 0 ? `+${sc.hpi_shock_pct}` : sc.hpi_shock_pct}%
                  </td>
                  <td className="px-3 py-2 text-right">{sc.unemployment_pct.toFixed(1)}%</td>
                  <td className="px-3 py-2 text-right">
                    {sc.rate_shock_bps > 0 ? `+${sc.rate_shock_bps}` : sc.rate_shock_bps} bps
                  </td>
                  <td className="px-3 py-2 text-right">{sc.recovery_rate_pct}%</td>
                  <td className={`px-3 py-2 text-right font-bold ${sc.projected_pool_loss_pct > 5.0 ? 'text-rose-400' : sc.projected_pool_loss_pct > 2.5 ? 'text-amber-400' : 'text-slate-200'}`}>
                    {sc.projected_pool_loss_pct.toFixed(2)}%
                  </td>
                  <td className="px-3 py-2 text-right font-medium text-white">
                    £{(sc.projected_pool_loss_gbp / 1e6).toFixed(1)}m
                  </td>
                  <td className="px-3 py-2 font-sans text-[11px]">
                    <span className={sc.impacted_tranches.includes('None') ? 'text-emerald-400' : 'text-rose-300 font-medium'}>
                      {sc.impacted_tranches.join(', ')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reverse Stress Testing Solver */}
      <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white tracking-wide">
              Reverse Stress Testing Solver (Boundary Vulnerability Analysis)
            </h3>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Target Tranche:</span>
            <select
              value={selectedTrancheId}
              onChange={e => handleTrancheSelect(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-white focus:outline-none"
            >
              {tranches.map(tr => (
                <option key={tr.id} value={tr.id}>
                  {tr.name} (Att: {(tr.attachment_pt * 100).toFixed(1)}%)
                </option>
              ))}
            </select>
          </div>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Reverse stress testing identifies the combinations of economic variables that would first cause principal write-downs on the selected tranche.
          <span className="text-amber-300 font-semibold ml-1">
            Label: MODEL_DERIVED_BOUNDARY_CONDITION_NOT_PREDICTION.
          </span>
        </p>

        {/* Solver Results Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
          <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded">
            <div className="text-slate-400 font-sans text-[11px]">Critical Pool Loss Required:</div>
            <div className="text-lg font-bold text-white mt-1">
              £{(reverseResult.critical_loss_gbp / 1e6).toFixed(1)}m
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {(reverseResult.critical_loss_fraction * 100).toFixed(2)}% of reference pool
            </div>
          </div>

          <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded">
            <div className="text-slate-400 font-sans text-[11px]">Req. Defaults (70% Recovery):</div>
            <div className="text-lg font-bold text-amber-300 mt-1">
              {reverseResult.required_default_rate_base_rec.toFixed(1)}%
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Under standard liquidation</div>
          </div>

          <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded">
            <div className="text-slate-400 font-sans text-[11px]">Req. Defaults (50% Stressed Rec):</div>
            <div className="text-lg font-bold text-rose-400 mt-1">
              {reverseResult.required_default_rate_stressed_rec.toFixed(1)}%
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Under stressed property repossession</div>
          </div>

          <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded">
            <div className="text-slate-400 font-sans text-[11px]">Implied HPI Shock Threshold:</div>
            <div className="text-lg font-bold text-rose-300 mt-1">
              {reverseResult.implied_hpi_shock_pct.toFixed(1)}%
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">National property price drop</div>
          </div>
        </div>
      </div>
    </div>
  );
};
