import React from 'react';
import { Download } from 'lucide-react';

interface TopBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onExportDossier: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  onExportDossier
}) => {
  const navItems = [
    { id: 'overview', label: 'Executive Overview' },
    { id: 'pool', label: 'Reference Pool' },
    { id: 'waterfall', label: 'Waterfall Structuring' },
    { id: 'crt', label: 'Synthetic CRT' },
    { id: 'valuation', label: 'Valuation & Pricing' },
    { id: 'montecarlo', label: 'Monte Carlo & Risk' },
    { id: 'stress', label: 'Stress Testing' },
    { id: 'rpackage', label: 'R Package & Tests' },
    { id: 'governance', label: 'Governance & Report' }
  ];

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      {/* Zone 1: Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-7 h-7 bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs tracking-wider text-slate-100 rounded">
          RB
        </div>
        <div className="text-base font-bold tracking-tight text-white whitespace-nowrap">
          RHINO BANK <span className="font-normal text-slate-400">STRUCTURED CREDIT</span>
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden xl:flex items-center gap-6 text-xs font-medium text-slate-400">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`transition-colors whitespace-nowrap cursor-pointer pb-1 border-b-2 ${
              activeTab === item.id
                ? 'text-white border-sky-400 font-semibold'
                : 'text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            {item.label}
          </button>
        ))}
      </nav>

      {/* Zone 3: Primary Action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onExportDossier}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-slate-900 bg-sky-400 hover:bg-sky-300 rounded transition-colors whitespace-nowrap cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Dossier</span>
        </button>
      </div>
    </header>
  );
};
