import React, { useState } from 'react';
import {
  Folder,
  FileCode,
  FileText,
  Play,
  CheckCircle,
  Copy,
  Download,
  Terminal,
  Check
} from 'lucide-react';
import {
  R_PACKAGE_REGISTRY,
  SAMPLE_TEST_SUITE_RESULTS,
  RFileItem
} from '../engine/rPackageRegistry';

export const RPackageInspector: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<RFileItem>(R_PACKAGE_REGISTRY[2]); // R/01_portfolio_generator.R
  const [copied, setCopied] = useState(false);
  const [runningTests, setRunningTests] = useState(false);
  const [testOutputVisible, setTestOutputVisible] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = selectedFile.path.split('/').pop() || 'file.R';
    link.click();
  };

  const handleRunTests = () => {
    setRunningTests(true);
    setTestOutputVisible(true);
    setTimeout(() => {
      setRunningTests(false);
    }, 400);
  };

  return (
    <div className="space-y-6">
      {/* Header & Test Runner Action */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-wide">
              R Quantitative Package Architecture & Testthat Suite (rhinombs v1.2.0)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Strictly modular institutional R codebase adhering to CRAN package standards, data.table performance, and PRA SS1/23 audit requirements.
            </p>
          </div>
          <button
            onClick={handleRunTests}
            disabled={runningTests}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-sky-400 hover:bg-sky-300 disabled:opacity-50 rounded cursor-pointer transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{runningTests ? 'Executing testthat...' : 'Run Automated testthat Suite'}</span>
          </button>
        </div>

        {/* Testthat Runner Results Modal / Drawer */}
        {testOutputVisible && (
          <div className="p-3 bg-slate-950 border border-slate-800 rounded space-y-2 text-xs font-mono">
            <div className="flex items-center justify-between text-slate-400 text-[11px] pb-1 border-b border-slate-800">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>R testthat execution: 8 test files, 41 assertions, 0 errors</span>
              </span>
              <span>R 4.4.0 (x86_64-pc-linux-gnu)</span>
            </div>
            <div className="space-y-1 text-[11px] max-h-48 overflow-y-auto">
              {SAMPLE_TEST_SUITE_RESULTS.map((res, i) => (
                <div key={i} className="flex items-start gap-2 text-slate-300">
                  <span className="text-emerald-400 font-bold">[PASS]</span>
                  <span className="text-slate-500 w-36 shrink-0">{res.suite}</span>
                  <span className="text-white flex-1">{res.testName}</span>
                  <span className="text-slate-500 text-[10px] shrink-0 font-sans">{res.durationMs}ms</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Package File Tree (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900/50 border border-slate-800 rounded p-3 space-y-3">
          <div className="text-xs font-semibold text-white px-2 flex items-center gap-1.5">
            <Folder className="w-3.5 h-3.5 text-sky-400" />
            <span>Package Files (rhinombs/)</span>
          </div>

          <div className="space-y-0.5 max-h-[520px] overflow-y-auto text-xs font-mono">
            {R_PACKAGE_REGISTRY.map(f => {
              const isSelected = selectedFile.path === f.path;
              return (
                <button
                  key={f.path}
                  onClick={() => setSelectedFile(f)}
                  className={`w-full text-left px-2.5 py-1.5 rounded flex items-center gap-2 cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-slate-800 text-sky-300 font-medium'
                      : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                  }`}
                >
                  <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-sky-400' : 'text-slate-500'}`} />
                  <span className="truncate">{f.path}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Code Viewer (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <div className="text-xs font-mono font-bold text-white flex items-center gap-2">
                <span>{selectedFile.path}</span>
                <span className="text-[10px] uppercase font-sans text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                  {selectedFile.category}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">{selectedFile.description}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 rounded cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
              <button
                onClick={handleDownload}
                className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-900 bg-sky-400 hover:bg-sky-300 rounded cursor-pointer"
              >
                <Download className="w-3 h-3" />
                <span>Save</span>
              </button>
            </div>
          </div>

          {/* Syntax Highlighted Pre Block */}
          <div className="bg-slate-950 border border-slate-800 rounded p-3 overflow-x-auto max-h-[460px]">
            <pre className="text-xs font-mono text-slate-200 leading-relaxed whitespace-pre">
              {selectedFile.content}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
