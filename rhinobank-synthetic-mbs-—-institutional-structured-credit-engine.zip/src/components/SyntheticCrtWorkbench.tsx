import React, { useState } from 'react';
import {
  ShieldAlert,
  FileText,
  DollarSign,
  Scale,
  CheckCircle,
  HelpCircle,
  AlertOctagon,
  Percent
} from 'lucide-react';
import { SyntheticCRTStructure } from '../types/mbs';

interface SyntheticCrtWorkbenchProps {
  crt: SyntheticCRTStructure;
  onUpdateCrt: (updated: Partial<SyntheticCRTStructure>) => void;
}

export const SyntheticCrtWorkbench: React.FC<SyntheticCrtWorkbenchProps> = ({
  crt,
  onUpdateCrt
}) => {
  const [spreadBps, setSpreadBps] = useState(crt.protection_spread_bps);
  const [protType, setProtType] = useState(crt.protection_type);
  const [tenor, setTenor] = useState(crt.protection_maturity_years);
  const [haircut, setHaircut] = useState(crt.collateral_haircut * 100);

  const handleApply = () => {
    onUpdateCrt({
      protection_spread_bps: spreadBps,
      protection_type: protType,
      protection_maturity_years: tenor,
      collateral_haircut: haircut / 100
    });
  };

  return (
    <div className="space-y-6">
      {/* Overview & Statutory Clarification */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded space-y-3">
        <div className="flex items-start gap-3">
          <Scale className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
          <div>
            <h2 className="text-sm font-semibold text-white tracking-wide">
              Synthetic Credit-Risk Transfer (CRT) Structuring Module
            </h2>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Unlike traditional cash securitisations where underlying mortgage titles are legally transferred to a bankruptcy-remote SPV, synthetic securitisations transfer credit default risk through bilateral credit protection contracts (funded Credit-Linked Notes or unfunded financial guarantees) while the mortgage pool remains fully on Rhino Bank’s balance sheet.
            </p>
          </div>
        </div>

        <div className="p-2.5 bg-amber-950/40 border border-amber-800/80 rounded text-xs text-amber-200 flex items-start gap-2">
          <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
          <div>
            <strong className="text-amber-100">Prudential Regulatory Boundary: </strong>
            Model calculation of reduced expected loss does not by itself confer capital relief. Significant Risk Transfer (SRT) under Bank of England / PRA SS1/23 requires rigorous quantitative risk assessment, legal enforceability review, and supervisory verification.
          </div>
        </div>
      </div>

      {/* Originator Risk Partitioning Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Retained First-Loss (0 - 2.5%) */}
        <div className="p-4 bg-slate-900/50 border border-amber-900/60 rounded space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-amber-400 flex items-center justify-between">
            <span>Retained First-Loss</span>
            <span className="font-mono text-[11px]">0.0% – 2.5%</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            £{(crt.first_loss_notional / 1e6).toFixed(1)}m
          </div>
          <div className="text-xs text-slate-400 leading-relaxed">
            Absorbs initial portfolio write-downs. Retained 100% by Rhino Bank to align originator incentives and prevent moral hazard.
          </div>
        </div>

        {/* Protected Mezzanine (2.5 - 9.5%) */}
        <div className="p-4 bg-slate-900/50 border border-sky-800/80 rounded space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-sky-400 flex items-center justify-between">
            <span>Protected Mezzanine</span>
            <span className="font-mono text-[11px]">2.5% – 9.5%</span>
          </div>
          <div className="text-2xl font-bold font-mono text-sky-300 tabular-nums">
            £{(crt.mezzanine_protected_notional / 1e6).toFixed(1)}m
          </div>
          <div className="text-xs text-slate-400 leading-relaxed">
            Transferred credit protection. Institutional investors absorb credit losses exceeding the 2.5% first-loss threshold up to 9.5%.
          </div>
        </div>

        {/* Senior Retained (9.5 - 100%) */}
        <div className="p-4 bg-slate-900/50 border border-slate-800 rounded space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center justify-between">
            <span>Senior Retained Risk</span>
            <span className="font-mono text-[11px]">9.5% – 100.0%</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            £{(crt.senior_retained_notional / 1e6).toFixed(1)}m
          </div>
          <div className="text-xs text-slate-400 leading-relaxed">
            Retained by Rhino Bank. Insulated by 9.5% subordination cushion, carrying modeled AAA credit risk equivalence.
          </div>
        </div>
      </div>

      {/* Contract & Structuring Parameters */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Protection Instrument Parameters (6 cols) */}
        <div className="lg:col-span-6 bg-slate-900/50 border border-slate-800 rounded p-4 space-y-4">
          <h3 className="text-sm font-semibold text-white tracking-wide">
            Protection Contract Mechanics & Counterparty Risk
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Protection Structure Type</label>
              <select
                value={protType}
                onChange={e => setProtType(e.target.value as any)}
                className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none"
              >
                <option value="funded_credit_linked_note">Funded Credit-Linked Note (CLN with cash collateral deposit)</option>
                <option value="unfunded_financial_guarantee">Unfunded Financial Guarantee / Credit Default Swap</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-300 font-medium block mb-1">Protection Premium (bps p.a.)</label>
                <input
                  type="number"
                  value={spreadBps}
                  onChange={e => setSpreadBps(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Protection Tenor (Years)</label>
                <input
                  type="number"
                  value={tenor}
                  onChange={e => setTenor(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-300 font-medium block mb-1">Counterparty Rating</label>
                <input
                  type="text"
                  disabled
                  value={crt.counterparty_rating}
                  className="w-full bg-slate-800/60 border border-slate-700/60 rounded px-2.5 py-1.5 text-slate-400 font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Collateral Haircut (%)</label>
                <input
                  type="number"
                  value={haircut}
                  onChange={e => setHaircut(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            <button
              onClick={handleApply}
              className="w-full mt-2 py-2 text-xs font-semibold text-slate-900 bg-sky-400 hover:bg-sky-300 rounded cursor-pointer transition-colors"
            >
              Update CRT Valuation & Settlement
            </button>
          </div>
        </div>

        {/* Right: Cash Flow Leg Economics & Valuation (6 cols) */}
        <div className="lg:col-span-6 bg-slate-900/50 border border-slate-800 rounded p-4 space-y-4">
          <h3 className="text-sm font-semibold text-white tracking-wide">
            CRT Cash-Flow Leg Valuation
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded space-y-1">
              <div className="text-slate-400 flex justify-between">
                <span>Present Value of Premium Leg (Rhino Bank Outflows):</span>
                <span className="font-mono font-semibold text-white">£{(crt.pv_premium_leg / 1e6).toFixed(2)}m</span>
              </div>
              <div className="text-[11px] text-slate-500">
                Quarterly premium payments ({spreadBps} bps) on outstanding protected notional over {tenor} years.
              </div>
            </div>

            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded space-y-1">
              <div className="text-slate-400 flex justify-between">
                <span>Expected Value of Protection Leg (Loss Inflows):</span>
                <span className="font-mono font-semibold text-emerald-400">£{(crt.pv_protection_leg / 1e6).toFixed(2)}m</span>
              </div>
              <div className="text-[11px] text-slate-500">
                Discounted recoveries received from protection seller upon reference mortgage credit events.
              </div>
            </div>

            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded space-y-1">
              <div className="text-slate-400 flex justify-between">
                <span>Net Cost to Originator:</span>
                <span className="font-mono font-bold text-amber-300">£{(crt.net_cost_gbp / 1e6).toFixed(2)}m</span>
              </div>
              <div className="text-[11px] text-slate-500">
                Breakeven Protection Spread: <span className="text-white font-mono">{crt.breakeven_spread_bps} bps p.a.</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* PRA Significant Risk Transfer (SRT) Verification Checklist */}
      <div className="bg-slate-900/50 border border-slate-800 rounded p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white tracking-wide flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            PRA SS1/23 Significant Risk Transfer (SRT) Compliance Audit Checklist
          </h3>
          <span className="text-xs text-slate-400">Pre-Submission Status</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="p-3 bg-slate-800/40 border border-slate-700/40 rounded flex items-start gap-2.5">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">Criterion 1: Substantial Credit Risk Transferred</div>
              <p className="text-slate-400 text-[11px] mt-0.5">
                Mezzanine tranche (2.5%–9.5%) absorbs the vast majority of expected losses above first-loss threshold.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-800/40 border border-slate-700/40 rounded flex items-start gap-2.5">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">Criterion 2: Enforceability of Credit Protection</div>
              <p className="text-slate-400 text-[11px] mt-0.5">
                Fully funded CLN cash deposit or qualifying eligible bank guarantee under English law.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-800/40 border border-slate-700/40 rounded flex items-start gap-2.5">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">Criterion 3: Zero Moral Hazard & First-Loss Retention</div>
              <p className="text-slate-400 text-[11px] mt-0.5">
                Originator maintains skin-in-the-game through unhedged 2.5% first-loss equity note retention.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-800/40 border border-slate-700/40 rounded flex items-start gap-2.5">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-white">Criterion 4: Maturity Mismatch Recognition</div>
              <p className="text-slate-400 text-[11px] mt-0.5">
                Protection maturity (5Y) vs mortgage WAL (~4.8Y senior) tracked with regulatory rollover capital penalty.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
