import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { FXMarketTerminal } from './components/FXMarketTerminal';
import { CurrencyFoundry } from './components/CurrencyFoundry';
import { MonetaryAuthority } from './components/MonetaryAuthority';
import { ReservesIssuance } from './components/ReservesIssuance';
import { DigitalTwinMacro } from './components/DigitalTwinMacro';
import { DerivativesYield } from './components/DerivativesYield';
import { PortfolioRisk } from './components/PortfolioRisk';
import { ScenarioCrisisLab } from './components/ScenarioCrisisLab';
import { PaymentsLedger } from './components/PaymentsLedger';
import { RhinoAIIntelligence } from './components/RhinoAIIntelligence';
import { SyntheticCurrency, ReserveAsset, MacroEconomy } from './types/currency';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('fx');
  const [currencies, setCurrencies] = useState<SyntheticCurrency[]>([]);
  const [reserves, setReserves] = useState<ReserveAsset[]>([]);
  const [macro, setMacro] = useState<MacroEconomy | undefined>(undefined);
  const [selectedCurrencyCode, setSelectedCurrencyCode] = useState<string>('RGU');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  useEffect(() => {
    fetchInitialData();
  }, []);

  // Simulation Interval Loop
  useEffect(() => {
    let interval: any = null;
    if (isSimulating) {
      interval = setInterval(() => {
        handleTickSimulation(1);
      }, 3000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isSimulating]);

  useEffect(() => {
    if (selectedCurrencyCode) {
      fetchMacro(selectedCurrencyCode);
    }
  }, [selectedCurrencyCode]);

  const fetchInitialData = async () => {
    try {
      const [cRes, rRes] = await Promise.all([
        fetch('/api/v1/currencies'),
        fetch('/api/v1/reserves')
      ]);
      const cData = await cRes.json();
      const rData = await rRes.json();
      if (cData.currencies) setCurrencies(cData.currencies);
      if (rData.reserves) setReserves(rData.reserves);
    } catch (err) {
      console.error('Failed to fetch initial state:', err);
    }
  };

  const fetchMacro = async (code: string) => {
    try {
      const res = await fetch(`/api/v1/macro/${code}`);
      const data = await res.json();
      setMacro(data.macro);
    } catch (err) {
      console.error('Failed to fetch macro metrics:', err);
    }
  };

  const handleTickSimulation = async (days: number = 1) => {
    try {
      await fetch('/api/v1/simulation/tick', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ days })
      });
      fetchInitialData();
      if (selectedCurrencyCode) fetchMacro(selectedCurrencyCode);
    } catch (err) {
      console.error('Failed to step simulation:', err);
    }
  };

  const selectedCurrency = currencies.find((c) => c.code === selectedCurrencyCode) || currencies[0];

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0b0f19] text-slate-100 overflow-hidden font-sans">
      {/* Institutional Top Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currencies={currencies}
        selectedCurrencyCode={selectedCurrencyCode}
        setSelectedCurrencyCode={setSelectedCurrencyCode}
        isSimulating={isSimulating}
        setIsSimulating={setIsSimulating}
        onTickSimulation={handleTickSimulation}
      />

      {/* Primary Workspace Container */}
      <main className="flex-1 overflow-hidden relative bg-[#0b0f19]">
        {activeTab === 'fx' && (
          <FXMarketTerminal
            currencies={currencies}
            selectedCurrencyCode={selectedCurrencyCode}
          />
        )}

        {activeTab === 'foundry' && (
          <CurrencyFoundry
            currencies={currencies}
            onCurrencyCreated={fetchInitialData}
          />
        )}

        {activeTab === 'monetary' && selectedCurrency && (
          <MonetaryAuthority
            currencies={currencies}
            selectedCurrencyCode={selectedCurrencyCode}
            onPolicyUpdated={fetchInitialData}
          />
        )}

        {activeTab === 'reserves' && selectedCurrency && (
          <ReservesIssuance
            currencies={currencies}
            reserves={reserves}
            selectedCurrencyCode={selectedCurrencyCode}
            onRefresh={fetchInitialData}
          />
        )}

        {activeTab === 'digital-twin' && selectedCurrency && (
          <DigitalTwinMacro
            macro={macro}
            currency={selectedCurrency}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'derivatives' && selectedCurrency && (
          <DerivativesYield currency={selectedCurrency} />
        )}

        {activeTab === 'portfolio' && <PortfolioRisk />}

        {activeTab === 'scenarios' && selectedCurrency && (
          <ScenarioCrisisLab currency={selectedCurrency} />
        )}

        {activeTab === 'ledger' && (
          <PaymentsLedger currencies={currencies} />
        )}

        {activeTab === 'ai' && (
          <RhinoAIIntelligence
            currencies={currencies}
            selectedCurrencyCode={selectedCurrencyCode}
          />
        )}
      </main>
    </div>
  );
}
