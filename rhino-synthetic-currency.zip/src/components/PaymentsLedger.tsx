import React, { useState, useEffect } from 'react';
import { Database, ShieldCheck, ArrowRightLeft, CheckCircle2, Lock, FileText } from 'lucide-react';
import { LedgerTransaction, SyntheticCurrency } from '../types/currency';

interface PaymentsLedgerProps {
  currencies: SyntheticCurrency[];
}

export const PaymentsLedger: React.FC<PaymentsLedgerProps> = ({ currencies }) => {
  const [ledger, setLedger] = useState<LedgerTransaction[]>([]);
  const [sourceCode, setSourceCode] = useState<string>('RGU');
  const [targetCode, setTargetCode] = useState<string>('ATU');
  const [transferAmount, setTransferAmount] = useState<number>(5000000); // 5M
  const [settlementMessage, setSettlementMessage] = useState<string>('');

  useEffect(() => {
    fetchLedger();
  }, []);

  const fetchLedger = async () => {
    try {
      const res = await fetch('/api/v1/ledger');
      const data = await res.json();
      setLedger(data.ledger || []);
    } catch (e) {
      console.error(e);
    }
  };

  const sourceCurrency = currencies.find((c) => c.code === sourceCode) || currencies[0];
  const targetCurrency = currencies.find((c) => c.code === targetCode) || currencies[1] || currencies[0];

  const fxRate = (sourceCurrency && targetCurrency)
    ? Number((sourceCurrency.unitValueUSD / targetCurrency.unitValueUSD).toFixed(4))
    : 1.0;

  const handleSettlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    const sourceValUSD = sourceCurrency?.unitValueUSD || 1.0;
    const destAmount = Number((transferAmount * fxRate).toFixed(2));
    const fee = Number((transferAmount * 0.0002 * sourceValUSD).toFixed(2));

    const newTx: LedgerTransaction = {
      tx_id: `TX-SETTLE-${Date.now().toString().slice(-6)}`,
      currencyCode: sourceCode,
      type: 'SETTLEMENT',
      sender: `Rhino Clearing Node (${sourceCode})`,
      receiver: `Correspondent Bank (${targetCode})`,
      amount: transferAmount,
      fxRateToUSD: sourceValUSD,
      valueUSD: transferAmount * sourceValUSD,
      feeUSD: fee,
      status: 'SETTLED',
      timestamp: new Date().toISOString(),
      auditHash: `0x${Math.random().toString(16).substring(2, 14)}`
    };

    setLedger([newTx, ...ledger]);
    setSettlementMessage(`Cross-border FX Settlement Completed T+0: Converted ${transferAmount.toLocaleString()} ${sourceCode} -> ${destAmount.toLocaleString()} ${targetCode} @ Rate ${fxRate}`);
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Header Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-cyan-400" />
            <h1 className="text-xl font-extrabold text-white">AUTHORITATIVE CENTRAL CURRENCY LEDGER & SETTLEMENT</h1>
            <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-xs font-mono font-bold">
              DOUBLE-ENTRY RECONCILED
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Immutable Audit Trail, Real-Time Cross-Border FX Payments & Reserve Reconciliation Verification
          </p>
        </div>

        {/* Double-Entry Verification Badge */}
        <div className="flex items-center gap-2 bg-emerald-950/60 border border-emerald-800 px-3 py-1.5 rounded font-mono text-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <div>
            <span className="font-bold text-emerald-300 block">RESERVE AUDIT VERIFIED</span>
            <span className="text-[10px] text-slate-400">TOTAL DEBITS = TOTAL CREDITS</span>
          </div>
        </div>
      </div>

      {/* Grid: Settlement Engine (5 cols) + Transaction Ledger Table (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT: Cross-Border Settlement Engine (5 cols) */}
        <div className="lg:col-span-5 bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white text-sm flex items-center gap-1.5">
              <ArrowRightLeft className="w-4 h-4 text-cyan-400" />
              CROSS-BORDER FX PAYMENT SETTLEMENT
            </span>
            <span className="text-emerald-400 font-bold">REAL-TIME T+0</span>
          </div>

          <form onSubmit={handleSettlePayment} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">SOURCE CURRENCY</label>
                <select
                  value={sourceCode}
                  onChange={(e) => setSourceCode(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white font-bold"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code}>{c.code} (${c.unitValueUSD})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">DESTINATION CURRENCY</label>
                <select
                  value={targetCode}
                  onChange={(e) => setTargetCode(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white font-bold"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code}>{c.code} (${c.unitValueUSD})</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">PAYMENT AMOUNT ({sourceCode})</label>
              <input
                type="number"
                step="500000"
                value={transferAmount}
                onChange={(e) => setTransferAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-bold"
              />
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800 space-y-1.5 text-[11px]">
              <div className="flex justify-between"><span>IMPLIED FX CONVERSION RATE:</span><strong className="text-cyan-400">1 {sourceCode} = {fxRate} {targetCode}</strong></div>
              <div className="flex justify-between"><span>DESTINATION PAYOUT:</span><strong className="text-emerald-400 font-bold">{(transferAmount * fxRate).toLocaleString()} {targetCode}</strong></div>
              <div className="flex justify-between"><span>CLEARING FEE:</span><strong className="text-slate-300">${(transferAmount * 0.0002 * (sourceCurrency?.unitValueUSD || 1)).toFixed(2)} USD (0.02%)</strong></div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold rounded shadow-lg shadow-cyan-950 transition-colors"
            >
              EXECUTE CROSS-BORDER SETTLEMENT
            </button>
          </form>

          {settlementMessage && (
            <div className="p-3 bg-slate-900 border border-cyan-800 text-cyan-300 text-xs rounded">
              {settlementMessage}
            </div>
          )}
        </div>

        {/* RIGHT: Transaction Audit Trail (7 cols) */}
        <div className="lg:col-span-7 bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white text-sm flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-cyan-400" />
              CENTRAL AUDIT LEDGER TRANSACTIONS ({ledger.length})
            </span>
            <span className="text-slate-400 text-[11px]">IMMUTABLE HASHED</span>
          </div>

          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[11px]">
                <tr>
                  <th className="p-2">TX ID</th>
                  <th className="p-2">TYPE</th>
                  <th className="p-2">SENDER / RECEIVER</th>
                  <th className="p-2 text-right">AMOUNT</th>
                  <th className="p-2 text-right">VALUE (USD)</th>
                  <th className="p-2 text-right">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {ledger.map((tx) => (
                  <tr key={tx.tx_id} className="hover:bg-slate-900/50">
                    <td className="p-2 font-bold text-cyan-400 truncate max-w-[100px]">{tx.tx_id}</td>
                    <td className="p-2">
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 text-[10px] font-bold">
                        {tx.type}
                      </span>
                    </td>
                    <td className="p-2 text-slate-300 text-[11px] truncate max-w-[150px]">
                      {tx.sender} → {tx.receiver}
                    </td>
                    <td className="p-2 text-right font-bold text-white">
                      {(tx.amount / 1e6).toFixed(2)}M {tx.currencyCode}
                    </td>
                    <td className="p-2 text-right text-cyan-300 font-bold">${(tx.valueUSD / 1e6).toFixed(2)}M</td>
                    <td className="p-2 text-right">
                      <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-bold">
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
