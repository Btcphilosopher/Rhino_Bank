import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Layers, DollarSign, Activity } from 'lucide-react';
import { FXPair, Order, Trade, SyntheticCurrency } from '../types/currency';

interface FXMarketTerminalProps {
  currencies: SyntheticCurrency[];
  selectedCurrencyCode: string;
}

export const FXMarketTerminal: React.FC<FXMarketTerminalProps> = ({ currencies, selectedCurrencyCode }) => {
  const [pairs, setPairs] = useState<FXPair[]>([]);
  const [selectedPairId, setSelectedPairId] = useState<string>(`${selectedCurrencyCode}/USD`);
  const [orderBook, setOrderBook] = useState<{ bids: Order[]; asks: Order[] }>({ bids: [], asks: [] });
  const [recentTrades, setRecentTrades] = useState<Trade[]>([]);
  
  // Order entry form state
  const [orderType, setOrderType] = useState<'LIMIT' | 'MARKET' | 'STOP'>('LIMIT');
  const [orderSide, setOrderSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderPrice, setOrderPrice] = useState<number>(1.0842);
  const [orderAmount, setOrderAmount] = useState<number>(1000000); // 1M
  const [traderName, setTraderName] = useState<string>('RhinoQuant Trading Desk');
  const [orderMessage, setOrderMessage] = useState<string>('');

  const activePair = pairs.find((p) => p.pair_id === selectedPairId) || pairs[0];

  useEffect(() => {
    fetchPairs();
  }, []);

  useEffect(() => {
    if (selectedPairId) {
      fetchOrderBook(selectedPairId);
      fetchTrades();
    }
  }, [selectedPairId]);

  const fetchPairs = async () => {
    try {
      const res = await fetch('/api/v1/fx/pairs');
      const data = await res.json();
      if (data.pairs) {
        setPairs(data.pairs);
        if (!data.pairs.some((p: FXPair) => p.pair_id === selectedPairId)) {
          setSelectedPairId(data.pairs[0]?.pair_id || `${selectedCurrencyCode}/USD`);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchOrderBook = async (pairId: string) => {
    try {
      const res = await fetch(`/api/v1/fx/orderbook/${encodeURIComponent(pairId)}`);
      const data = await res.json();
      setOrderBook({ bids: data.bids || [], asks: data.asks || [] });
      if (data.bids?.[0]?.price) {
        setOrderPrice(orderSide === 'BUY' ? data.asks[0]?.price || data.bids[0].price : data.bids[0].price);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchTrades = async () => {
    try {
      const res = await fetch('/api/v1/fx/trades');
      const data = await res.json();
      setRecentTrades(data.trades || []);
    } catch (e) {
      console.error(e);
    }
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setOrderMessage('');
    try {
      const res = await fetch('/api/v1/fx/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pair_id: selectedPairId,
          trader: traderName,
          side: orderSide,
          type: orderType,
          price: Number(orderPrice),
          amount: Number(orderAmount)
        })
      });
      const data = await res.json();
      if (data.success) {
        setOrderMessage(`Order Executed / Submitted: ${data.order.status} (${data.tradesExecuted.length} fills)`);
        fetchOrderBook(selectedPairId);
        fetchTrades();
        fetchPairs();
      } else {
        setOrderMessage(`Order Error: ${data.error}`);
      }
    } catch (err: any) {
      setOrderMessage(`Execution Failed: ${err.message}`);
    }
  };

  const baseSymbol = selectedPairId.includes('/') ? selectedPairId.split('/')[0] : 'RGU';
  const quoteSymbol = selectedPairId.includes('/') ? selectedPairId.split('/')[1] : 'USD';

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto">
      {/* Pair Selector Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {pairs.map((p) => {
          const isSelected = p.pair_id === selectedPairId;
          const isUp = p.change24h >= 0;
          return (
            <button
              key={p.pair_id}
              onClick={() => setSelectedPairId(p.pair_id)}
              className={`p-2.5 rounded text-left border transition-all ${
                isSelected
                  ? 'bg-slate-900 border-cyan-500 shadow-md shadow-cyan-950/50'
                  : 'bg-[#0f172a]/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-mono font-bold text-slate-200">
                <span>{p.pair_id}</span>
                <span className={isUp ? 'text-emerald-400' : 'text-rose-400'}>
                  {isUp ? '+' : ''}{p.change24h}%
                </span>
              </div>
              <div className="text-base font-mono font-extrabold text-white mt-1">
                {p.lastPrice}
              </div>
              <div className="text-[10px] text-slate-500 font-mono mt-0.5 flex justify-between">
                <span>VOL: ${(p.volume24h / 1e6).toFixed(1)}M</span>
                <span>VOLAT: {p.impliedVolatility30d}%</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Terminal Grid: Orderbook (Left), Order Entry & Chart (Center), Trade Stream (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* LEFT: Order Book Depth (3 cols) */}
        <div className="lg:col-span-3 bg-[#0f172a] border border-slate-800 rounded p-3 flex flex-col font-mono text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400 font-semibold">
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              MATCHING ORDER BOOK
            </span>
            <span className="text-[11px] text-slate-500">{selectedPairId}</span>
          </div>

          <div className="grid grid-cols-3 py-1.5 text-[11px] text-slate-500 border-b border-slate-800/50 font-semibold">
            <span>PRICE</span>
            <span className="text-right">SIZE</span>
            <span className="text-right">TOTAL</span>
          </div>

          {/* Asks (Sells) - Red */}
          <div className="flex-1 overflow-y-auto space-y-1 py-1 max-h-48 border-b border-slate-800/80">
            {orderBook.asks.slice().reverse().map((ask, i) => (
              <div key={ask.order_id || i} className="grid grid-cols-3 hover:bg-rose-950/30 px-1 py-0.5 rounded text-rose-300">
                <span className="font-bold">{ask.price}</span>
                <span className="text-right text-slate-300">{(ask.amount / 1e6).toFixed(2)}M</span>
                <span className="text-right text-slate-500">${((ask.price * ask.amount) / 1e6).toFixed(2)}M</span>
              </div>
            ))}
          </div>

          {/* Spread Banner */}
          <div className="py-2 px-2 my-1 bg-slate-900 border border-slate-800 rounded flex items-center justify-between text-xs">
            <span className="text-slate-400">LAST: <strong className="text-white">{activePair?.lastPrice}</strong></span>
            <span className="text-cyan-400 font-bold">SPREAD: {activePair ? ((activePair.ask - activePair.bid) * 10000).toFixed(1) : '0.0'} pips</span>
          </div>

          {/* Bids (Buys) - Green */}
          <div className="flex-1 overflow-y-auto space-y-1 py-1 max-h-48">
            {orderBook.bids.map((bid, i) => (
              <div key={bid.order_id || i} className="grid grid-cols-3 hover:bg-emerald-950/30 px-1 py-0.5 rounded text-emerald-300">
                <span className="font-bold">{bid.price}</span>
                <span className="text-right text-slate-300">{(bid.amount / 1e6).toFixed(2)}M</span>
                <span className="text-right text-slate-500">${((bid.price * bid.amount) / 1e6).toFixed(2)}M</span>
              </div>
            ))}
          </div>
        </div>

        {/* CENTER: Order Entry & Market Microstructure (5 cols) */}
        <div className="lg:col-span-5 bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <span>{selectedPairId}</span>
                <span className="text-xs font-mono font-normal px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                  RUST MATCHING ENGINE
                </span>
              </h2>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                INSTITUTIONAL PRICE-TIME PRIORITY MATCHING
              </div>
            </div>
            <div className="text-right font-mono">
              <div className="text-xl font-black text-cyan-400">{activePair?.lastPrice}</div>
              <div className="text-xs text-slate-400">BID: {activePair?.bid} | ASK: {activePair?.ask}</div>
            </div>
          </div>

          {/* Order Side Segmented Buttons */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded border border-slate-800">
            <button
              onClick={() => setOrderSide('BUY')}
              className={`py-2 text-xs font-bold font-mono rounded transition-colors ${
                orderSide === 'BUY'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              BUY {baseSymbol}
            </button>
            <button
              onClick={() => setOrderSide('SELL')}
              className={`py-2 text-xs font-bold font-mono rounded transition-colors ${
                orderSide === 'SELL'
                  ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              SELL {baseSymbol}
            </button>
          </div>

          {/* Order Type Controls */}
          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-slate-400">TYPE:</span>
            {(['LIMIT', 'MARKET', 'STOP'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setOrderType(type)}
                className={`px-3 py-1 rounded transition-colors ${
                  orderType === type
                    ? 'bg-cyan-900 text-cyan-200 border border-cyan-700 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          {/* Form Fields */}
          <form onSubmit={handlePlaceOrder} className="space-y-3 font-mono text-xs">
            <div>
              <label className="block text-slate-400 mb-1">TRADING DESK / INSTITUTION</label>
              <input
                type="text"
                value={traderName}
                onChange={(e) => setTraderName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {orderType !== 'MARKET' && (
              <div>
                <label className="block text-slate-400 mb-1">LIMIT PRICE ({quoteSymbol})</label>
                <input
                  type="number"
                  step="0.0001"
                  value={orderPrice}
                  onChange={(e) => setOrderPrice(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-cyan-500"
                />
              </div>
            )}

            <div>
              <label className="block text-slate-400 mb-1">NOTIONAL AMOUNT ({baseSymbol})</label>
              <input
                type="number"
                step="100000"
                value={orderAmount}
                onChange={(e) => setOrderAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-cyan-500"
              />
              <div className="text-[11px] text-slate-500 mt-1 flex justify-between">
                <span>ESTIMATED VALUE: ${((orderType === 'MARKET' ? activePair?.lastPrice || 1 : orderPrice) * orderAmount / 1e6).toFixed(2)}M USD</span>
                <span>CLEARING: T+0 RHINO LEDGER</span>
              </div>
            </div>

            <button
              type="submit"
              className={`w-full py-3 rounded text-sm font-extrabold transition-all shadow-lg font-mono ${
                orderSide === 'BUY'
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/80'
                  : 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-950/80'
              }`}
            >
              EXECUTE {orderSide} ORDER
            </button>
          </form>

          {orderMessage && (
            <div className="p-2.5 bg-slate-900 border border-cyan-800 text-cyan-300 text-xs font-mono rounded">
              {orderMessage}
            </div>
          )}
        </div>

        {/* RIGHT: Live Trade Stream & Participant Microstructure (4 cols) */}
        <div className="lg:col-span-4 bg-[#0f172a] border border-slate-800 rounded p-3 flex flex-col font-mono text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400 font-semibold">
            <span className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              LIVE MATCHED TRADES STREAM
            </span>
            <span className="text-emerald-400 text-[11px]">MATCHED</span>
          </div>

          <div className="grid grid-cols-4 py-1.5 text-[11px] text-slate-500 border-b border-slate-800/50 font-semibold">
            <span>TIME</span>
            <span>PRICE</span>
            <span className="text-right">SIZE</span>
            <span className="text-right">COUNTERPARTY</span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-1.5 py-2 max-h-80">
            {recentTrades.map((t) => (
              <div key={t.trade_id} className="grid grid-cols-4 hover:bg-slate-800/40 px-1 py-1 rounded border-b border-slate-800/30 text-[11px]">
                <span className="text-slate-400">{t.timestamp.split('T')[1].substring(0, 8)}</span>
                <span className={`font-bold ${t.side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {t.price}
                </span>
                <span className="text-right text-slate-200">{(t.amount / 1e6).toFixed(2)}M</span>
                <span className="text-right text-slate-400 truncate pl-1">{t.buyer.split(' ')[0]}</span>
              </div>
            ))}
          </div>

          {/* Participant Microstructure Legend */}
          <div className="mt-3 pt-3 border-t border-slate-800 text-[11px] text-slate-400 space-y-1.5">
            <div className="font-bold text-slate-200 uppercase tracking-wider mb-1">FX Microstructure Participants</div>
            <div className="flex justify-between">
              <span>RHINO MONETARY DESK:</span>
              <span className="text-cyan-400">ACTIVE INTERVENTION</span>
            </div>
            <div className="flex justify-between">
              <span>PRIMARY DEALER BANKS:</span>
              <span className="text-slate-300">BARCLAYS, JPMORGAN, BNP</span>
            </div>
            <div className="flex justify-between">
              <span>HEDGE FUNDS & QUANTS:</span>
              <span className="text-slate-300">RHINOQUANT ALPHA 1</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
