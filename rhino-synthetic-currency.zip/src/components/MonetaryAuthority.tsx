import React, { useState } from 'react';
import { Landmark, ArrowRight, Activity, Percent, ShieldCheck, DollarSign, TrendingUp, Sliders } from 'lucide-react';
import { SyntheticCurrency } from '../types/currency';

interface MonetaryAuthorityProps {
  currencies: SyntheticCurrency[];
  selectedCurrencyCode: string;
  onPolicyUpdated: () => void;
}

export const MonetaryAuthority: React.FC<MonetaryAuthorityProps> = ({ currencies, selectedCurrencyCode, onPolicyUpdated }) => {
  const currentCurrency = currencies.find((c) => c.code === selectedCurrencyCode) || currencies[0];

  const [policyRate, setPolicyRate] = useState<number>(currentCurrency?.monetary_policy?.policyRate || 3.75);
  const [reserveRatioTarget, setReserveRatioTarget] = useState<number>(currentCurrency?.monetary_policy?.reserveRatioTarget || 105.0);
  const [inflationTarget, setInflationTarget] = useState<number>(currentCurrency?.monetary_policy?.inflationTarget || 2.0);
  const [assetPurchasesActive, setAssetPurchasesActive] = useState<boolean>(currentCurrency?.monetary_policy?.assetPurchasesActive ?? true);
  const [purchaseVolumeUSD, setPurchaseVolumeUSD] = useState<number>(currentCurrency?.monetary_policy?.monthlyPurchaseVolumeUSD || 250);
  const [fxInterventionThreshold, setFxInterventionThreshold] = useState<number>(currentCurrency?.monetary_policy?.fxInterventionThreshold || 2.5);

  const [statusMessage, setStatusMessage] = useState<string>('');

  React.useEffect(() => {
    if (currentCurrency?.monetary_policy) {
      setPolicyRate(currentCurrency.monetary_policy.policyRate);
      setReserveRatioTarget(currentCurrency.monetary_policy.reserveRatioTarget);
      setInflationTarget(currentCurrency.monetary_policy.inflationTarget);
      setAssetPurchasesActive(currentCurrency.monetary_policy.assetPurchasesActive);
      setPurchaseVolumeUSD(currentCurrency.monetary_policy.monthlyPurchaseVolumeUSD);
      setFxInterventionThreshold(currentCurrency.monetary_policy.fxInterventionThreshold);
    }
  }, [currentCurrency]);

  const handleApplyPolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage('');
    try {
      const res = await fetch(`/api/v1/currencies/${currentCurrency.code}/monetary-policy`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          policyRate: Number(policyRate),
          reserveRatioTarget: Number(reserveRatioTarget),
          inflationTarget: Number(inflationTarget),
          assetPurchasesActive,
          monthlyPurchaseVolumeUSD: Number(purchaseVolumeUSD),
          fxInterventionThreshold: Number(fxInterventionThreshold)
        })
      });
      const data = await res.json();
      if (data.success) {
        setStatusMessage(`Monetary Policy Intervention Broadcasted! Version ${data.currency.monetary_policy.version} live.`);
        onPolicyUpdated();
      } else {
        setStatusMessage(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setStatusMessage(`Policy Update Failed: ${err.message}`);
    }
  };

  if (!currentCurrency) {
    return (
      <div className="p-8 text-center text-slate-400 font-mono">
        INITIALIZING MONETARY AUTHORITY STATE...
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Top Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Landmark className="w-5 h-5 text-amber-400" />
            <h1 className="text-xl font-extrabold text-white">RHINO MONETARY AUTHORITY (RMA)</h1>
            <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-xs font-mono font-bold">
              GOVERNANCE LAYER
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Centralized Monetary Control, Open Market Operations, Reserve Ratios & Causal Policy Transmission
          </p>
        </div>

        <div className="flex items-center gap-4 font-mono text-xs">
          <div className="text-right">
            <span className="text-slate-400 block">CURRENT POLICY RATE</span>
            <span className="text-2xl font-black text-amber-400">{currentCurrency.monetary_policy.policyRate}%</span>
          </div>
          <div className="text-right border-l border-slate-800 pl-4">
            <span className="text-slate-400 block">INFLATION TARGET</span>
            <span className="text-xl font-bold text-slate-200">{currentCurrency.monetary_policy.inflationTarget}%</span>
          </div>
        </div>
      </div>

      {/* Grid: Policy Terminal Controls (Left) & Causal Transmission Diagram (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT: Policy Intervention Controls (5 cols) */}
        <div className="lg:col-span-5 bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white flex items-center gap-1.5 text-sm">
              <Sliders className="w-4 h-4 text-cyan-400" />
              INTERVENTION TERMINAL: {currentCurrency.code}
            </span>
            <span className="text-slate-400 text-[11px]">VERSION {currentCurrency.monetary_policy.version}</span>
          </div>

          <form onSubmit={handleApplyPolicy} className="space-y-4">
            {/* Policy Rate Slider */}
            <div>
              <div className="flex justify-between text-slate-300 font-bold mb-1">
                <span>BENCHMARK POLICY RATE (%)</span>
                <span className="text-amber-400 font-extrabold text-sm">{policyRate}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="10.0"
                step="0.25"
                value={policyRate}
                onChange={(e) => setPolicyRate(parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                <span>0.00% (Ultra-dovish)</span>
                <span>5.00% (Neutral)</span>
                <span>10.00% (Ultra-hawkish)</span>
              </div>
            </div>

            {/* Reserve Coverage Ratio Target */}
            <div>
              <div className="flex justify-between text-slate-300 font-bold mb-1">
                <span>RESERVE COVERAGE TARGET (%)</span>
                <span className="text-cyan-400 font-extrabold text-sm">{reserveRatioTarget}%</span>
              </div>
              <input
                type="range"
                min="90"
                max="130"
                step="1"
                value={reserveRatioTarget}
                onChange={(e) => setReserveRatioTarget(parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            {/* Asset Purchases (QE / QT) */}
            <div className="bg-slate-900 p-3 rounded border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">OPEN MARKET OPERATIONS (QE/QT)</span>
                <button
                  type="button"
                  onClick={() => setAssetPurchasesActive(!assetPurchasesActive)}
                  className={`px-3 py-1 rounded text-xs font-bold transition-colors ${
                    assetPurchasesActive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {assetPurchasesActive ? 'ACTIVE (QE)' : 'INACTIVE'}
                </button>
              </div>

              {assetPurchasesActive && (
                <div>
                  <label className="block text-slate-400 mb-1">MONTHLY ASSET PURCHASE VOLUME ($M USD)</label>
                  <input
                    type="number"
                    step="50"
                    value={purchaseVolumeUSD}
                    onChange={(e) => setPurchaseVolumeUSD(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-white font-bold"
                  />
                </div>
              )}
            </div>

            {/* FX Intervention Threshold */}
            <div>
              <label className="block text-slate-400 mb-1">FX INTERVENTION THRESHOLD (% DEVIATION FROM BASKET MODEL)</label>
              <input
                type="number"
                step="0.5"
                value={fxInterventionThreshold}
                onChange={(e) => setFxInterventionThreshold(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white font-bold"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-sm rounded shadow-lg shadow-amber-950 transition-colors"
            >
              EXECUTE MONETARY POLICY INTERVENTION
            </button>
          </form>

          {statusMessage && (
            <div className="p-3 bg-slate-900 border border-amber-800 text-amber-300 text-xs rounded">
              {statusMessage}
            </div>
          )}
        </div>

        {/* RIGHT: Money Supply Aggregates & Transmission Mechanism Diagram (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4 font-mono text-xs">
          {/* Money Supply M0-M3 Breakdown */}
          <div className="bg-[#0f172a] border border-slate-800 rounded p-4 space-y-3">
            <h3 className="font-bold text-slate-200 text-sm flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              MONEY SUPPLY AGGREGATE BREAKDOWN ({currentCurrency.code})
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">M0 (BASE MONEY)</span>
                <span className="text-base font-extrabold text-white mt-1 block">
                  ${(currentCurrency.money_supply.m0 * currentCurrency.unitValueUSD / 1e9).toFixed(2)}B
                </span>
                <span className="text-[10px] text-slate-500">Physical + CB Reserves</span>
              </div>

              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">M1 (NARROW MONEY)</span>
                <span className="text-base font-extrabold text-slate-200 mt-1 block">
                  ${(currentCurrency.money_supply.m1 * currentCurrency.unitValueUSD / 1e9).toFixed(2)}B
                </span>
                <span className="text-[10px] text-slate-500">M0 + Demand Deposits</span>
              </div>

              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">M2 (BROAD MONEY)</span>
                <span className="text-base font-extrabold text-slate-200 mt-1 block">
                  ${(currentCurrency.money_supply.m2 * currentCurrency.unitValueUSD / 1e9).toFixed(2)}B
                </span>
                <span className="text-[10px] text-slate-500">M1 + Savings Funds</span>
              </div>

              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">VELOCITY OF MONEY (V)</span>
                <span className="text-base font-extrabold text-emerald-400 mt-1 block">
                  {currentCurrency.money_supply.velocity}
                </span>
                <span className="text-[10px] text-slate-500">Nominal GDP / M2</span>
              </div>
            </div>
          </div>

          {/* Monetary Transmission Mechanism Causal Chain */}
          <div className="bg-[#0f172a] border border-slate-800 rounded p-4 space-y-3 flex-1">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              CAUSAL MONETARY TRANSMISSION MECHANISM
            </h3>

            <div className="space-y-2 pt-2">
              {[
                { step: '1. POLICY RATE INTERVENTION', desc: `Benchmark rate set at ${policyRate}%`, impact: 'Directly anchors interbank borrowing rates' },
                { step: '2. MONEY MARKET & BANK FUNDING', desc: 'Commercial bank funding costs shift by delta bps', impact: 'Adjusts bank liquidity reserves & credit spreads' },
                { step: '3. CREDIT CREATION & LENDING RATES', desc: `Commercial lending rates adjust to ${(policyRate + 2.1).toFixed(2)}%`, impact: 'Modulates private sector credit expansion' },
                { step: '4. REAL ECONOMIC ACTIVITY & OUTPUT GAP', desc: 'Aggregate demand & capital expenditure shift', impact: 'Impacts synthetic GDP and consumption' },
                { step: '5. INFLATION & FX VALUATION', desc: `CPI trends toward ${inflationTarget}% target`, impact: 'Re-anchors FX parity & basket exchange rate' }
              ].map((chain, idx) => (
                <div key={idx} className="bg-slate-900 p-2.5 rounded border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-amber-400 mr-2">{chain.step}</span>
                    <span className="text-slate-200">{chain.desc}</span>
                  </div>
                  <div className="text-right text-slate-400 text-[11px]">
                    {chain.impact}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
