import React, { useState, useEffect } from 'react';
import { ShieldAlert, TrendingUp, DollarSign, Activity, PieChart, Layers } from 'lucide-react';
import { PortfolioPosition, RiskMetrics } from '../types/currency';

export const PortfolioRisk: React.FC = () => {
  const [portfolio, setPortfolio] = useState<PortfolioPosition[]>([]);
  const [risk, setRisk] = useState<RiskMetrics | null>(null);

  useEffect(() => {
    fetchPortfolioAndRisk();
  }, []);

  const fetchPortfolioAndRisk = async () => {
    try {
      const [pRes, rRes] = await Promise.all([
        fetch('/api/v1/portfolio'),
        fetch('/api/v1/risk')
      ]);
      const pData = await pRes.json();
      const rData = await rRes.json();
      setPortfolio(pData.portfolio || []);
      setRisk(rData.risk || null);
    } catch (e) {
      console.error(e);
    }
  };

  const totalUnrealizedPnL = portfolio.reduce((acc, p) => acc + p.unrealizedPnLUSD, 0);

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Header Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-cyan-400" />
            <h1 className="text-xl font-extrabold text-white">RHINO CURRENCY PORTFOLIO & RISK TERMINAL</h1>
            <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-xs font-mono font-bold">
              RHINOQUANT ANALYTICS ENGINE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Multi-Instrument FX Positions, Value-at-Risk (VaR 95/99%), Expected Shortfall & Factor Beta Decomposition
          </p>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div className="text-right">
            <span className="text-slate-400 block">TOTAL PORTFOLIO NAV</span>
            <span className="text-2xl font-black text-white">${((risk?.totalPortfolioValueUSD || 12835700000) / 1e9).toFixed(3)}B</span>
          </div>
          <div className="text-right border-l border-slate-800 pl-4">
            <span className="text-slate-400 block">DAILY UNREALIZED P&L</span>
            <span className={`text-xl font-bold ${totalUnrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {totalUnrealizedPnL >= 0 ? '+' : ''}${(totalUnrealizedPnL / 1e6).toFixed(2)}M
            </span>
          </div>
        </div>
      </div>

      {/* Risk Scoreboard Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">NET FX EXPOSURE</span>
          <span className="text-base font-extrabold text-cyan-400 mt-1 block">
            ${((risk?.netFXExposureUSD || 1500000000) / 1e6).toFixed(1)}M USD
          </span>
          <span className="text-[10px] text-slate-500">Long RGU / Short USD & EUR</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">1-DAY 95% VaR</span>
          <span className="text-base font-extrabold text-amber-400 mt-1 block">
            ${((risk?.var95_1D || 84500000) / 1e6).toFixed(1)}M USD
          </span>
          <span className="text-[10px] text-slate-500">Normal Market Conditions</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">1-DAY 99% VaR</span>
          <span className="text-base font-extrabold text-rose-400 mt-1 block">
            ${((risk?.var99_1D || 128200000) / 1e6).toFixed(1)}M USD
          </span>
          <span className="text-[10px] text-slate-500">Tail Risk Horizon</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">EXPECTED SHORTFALL (99%)</span>
          <span className="text-base font-extrabold text-rose-300 mt-1 block">
            ${((risk?.expectedShortfall99 || 154000000) / 1e6).toFixed(1)}M USD
          </span>
          <span className="text-[10px] text-slate-500">CVaR Beyond 99% Cutoff</span>
        </div>
      </div>

      {/* Main Grid: Portfolio Positions Table (8 cols) + RhinoQuant Factor Model (4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT: Portfolio Positions (8 cols) */}
        <div className="lg:col-span-8 bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white text-sm flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-cyan-400" />
              PORTFOLIO POSITIONS ({portfolio.length} ACTIVE INSTRUMENTS)
            </span>
            <span className="text-slate-400 text-[11px]">RHINO DESK CENTRAL BOOK</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[11px]">
                <tr>
                  <th className="p-2">INSTRUMENT</th>
                  <th className="p-2">SYMBOL</th>
                  <th className="p-2">SIDE</th>
                  <th className="p-2 text-right">NOTIONAL (USD)</th>
                  <th className="p-2 text-right">ENTRY</th>
                  <th className="p-2 text-right">MARK</th>
                  <th className="p-2 text-right">UNREALIZED P&L</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {portfolio.map((pos) => (
                  <tr key={pos.position_id} className="hover:bg-slate-900/50">
                    <td className="p-2 font-bold text-cyan-400">{pos.instrument}</td>
                    <td className="p-2 font-bold text-white">{pos.symbol}</td>
                    <td className="p-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        pos.direction === 'LONG' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}>
                        {pos.direction}
                      </span>
                    </td>
                    <td className="p-2 text-right text-slate-200">${(pos.notionalUSD / 1e6).toFixed(1)}M</td>
                    <td className="p-2 text-right text-slate-300">{pos.entryPrice}</td>
                    <td className="p-2 text-right text-white font-bold">{pos.currentPrice}</td>
                    <td className={`p-2 text-right font-bold ${pos.unrealizedPnLUSD >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {pos.unrealizedPnLUSD >= 0 ? '+' : ''}${(pos.unrealizedPnLUSD / 1e6).toFixed(2)}M
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* RIGHT: RhinoQuant Factor Model Betas (4 cols) */}
        <div className="lg:col-span-4 bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs flex flex-col gap-3">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="font-bold text-white text-sm flex items-center gap-1.5">
              <PieChart className="w-4 h-4 text-cyan-400" />
              RHINOQUANT FACTOR MODEL BETAS
            </h3>
            <p className="text-[11px] text-slate-400">Systemic Factor Sensitivity Decomposition</p>
          </div>

          <div className="space-y-2.5">
            {[
              { factor: 'USD INDEX FACTOR', beta: risk?.factorBetas.usdIndex || 0.38, desc: 'Sensitivity to broader DXY dollar moves' },
              { factor: 'EUR INDEX FACTOR', beta: risk?.factorBetas.eurIndex || 0.28, desc: 'Sensitivity to European monetary policy' },
              { factor: 'GLOBAL RATES FACTOR', beta: risk?.factorBetas.ratesGlobal || -0.15, desc: 'Sensitivity to sovereign yield curve shifts' },
              { factor: 'COMMODITY FACTOR', beta: risk?.factorBetas.commodities || 0.12, desc: 'Sensitivity to energy & metal basket prices' },
              { factor: 'GLOBAL GROWTH FACTOR', beta: risk?.factorBetas.growthGlobal || 0.45, desc: 'Sensitivity to world GDP output gap' },
              { factor: 'INFLATION SENSITIVITY', beta: risk?.factorBetas.inflation || -0.22, desc: 'Sensitivity to global CPI momentum' }
            ].map((f) => (
              <div key={f.factor} className="bg-slate-900 p-2.5 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-200 block">{f.factor}</span>
                  <span className="text-[10px] text-slate-500">{f.desc}</span>
                </div>
                <div className="font-black text-sm text-cyan-400">
                  {f.beta >= 0 ? '+' : ''}{f.beta}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
