import React, { useState } from 'react';
import { Network, Activity, Globe, Landmark, Layers, TrendingUp, DollarSign, Cpu, Play, Pause, RefreshCw } from 'lucide-react';
import { MacroEconomy, SyntheticCurrency } from '../types/currency';

interface DigitalTwinMacroProps {
  macro?: MacroEconomy;
  currency: SyntheticCurrency;
  onNavigateTab: (tab: string) => void;
}

export const DigitalTwinMacro: React.FC<DigitalTwinMacroProps> = ({ macro, currency, onNavigateTab }) => {
  const [selectedNode, setSelectedNode] = useState<string>('CURRENCY');

  if (!currency) {
    return (
      <div className="p-8 text-center text-slate-400 font-mono">
        INITIALIZING DIGITAL TWIN MACRO STATE...
      </div>
    );
  }

  const nodes = [
    { id: 'CURRENCY', label: 'CURRENCY DESIGN', icon: Globe, detail: `Unit: ${currency.name} (${currency.code}) · $${currency.unitValueUSD} USD`, targetTab: 'foundry' },
    { id: 'RESERVES', label: 'RESERVES', icon: Landmark, detail: `$${(currency.locked_reserves / 1e9).toFixed(2)}B Collateral · ${currency.money_supply.totalReserveCoverageRatio}% Coverage`, targetTab: 'reserves' },
    { id: 'SUPPLY', label: 'MONEY SUPPLY', icon: Layers, detail: `M0: ${(currency.circulating_supply / 1e9).toFixed(2)}B · Velocity: ${currency.money_supply.velocity}`, targetTab: 'monetary' },
    { id: 'POLICY', label: 'MONETARY POLICY', icon: Activity, detail: `Policy Rate: ${currency.monetary_policy.policyRate}% · CPI Target: ${currency.monetary_policy.inflationTarget}%`, targetTab: 'monetary' },
    { id: 'BANKING', label: 'BANKING SYSTEM', icon: Landmark, detail: `${macro?.numberOfBanks || 20} Synthetic Banks · $${macro?.bankingSystemAssetsUSD || 18200}B Assets`, targetTab: 'monetary' },
    { id: 'CREDIT', label: 'CREDIT EXPANSION', icon: TrendingUp, detail: `Credit Growth: ${macro?.creditGrowthPct || 4.8}% p.a.`, targetTab: 'monetary' },
    { id: 'ECONOMY', label: 'SYNTHETIC ECONOMY', icon: Cpu, detail: `GDP: $${macro?.nominalGDPUSD || 12450}B · Real Growth: +${macro?.realGDPGrowthPct || 2.15}%`, targetTab: 'digital-twin' },
    { id: 'TRADE', label: 'TRADE & CURRENT ACCT', icon: DollarSign, detail: `Exports: $${macro?.exportsBlnUSD || 1800}B · Current Account: +$${macro?.currentAccountBlnUSD || 200}B`, targetTab: 'fx' },
    { id: 'FX', label: 'FX MARKET', icon: Globe, detail: `Pair: ${currency.code}/USD · Price: ${currency.unitValueUSD}`, targetTab: 'fx' }
  ];

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Header Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Network className="w-5 h-5 text-cyan-400 animate-pulse" />
            <h1 className="text-xl font-extrabold text-white">FINANCIAL DIGITAL TWIN & CAUSAL MACRO ENGINE</h1>
            <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-xs font-mono font-bold">
              REAL-TIME CAUSAL GRAPH
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Rhino Bank Multi-Layer Digital Twin · Every Action Propagates Through Monetary & Real Economy Nodes
          </p>
        </div>

        <div className="font-mono text-xs flex items-center gap-3">
          <div className="text-right">
            <span className="text-slate-400 block">SYNTHETIC GDP</span>
            <span className="text-xl font-extrabold text-white">${macro?.nominalGDPUSD || 12450}B</span>
          </div>
          <div className="text-right border-l border-slate-800 pl-3">
            <span className="text-slate-400 block">HEADLINE CPI</span>
            <span className="text-lg font-bold text-emerald-400">{macro?.cpiHeadlinePct || 2.4}%</span>
          </div>
        </div>
      </div>

      {/* Interactive Causal Node Graph Visual Architecture */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-5 flex flex-col items-center gap-4">
        <div className="text-xs font-mono text-slate-400 uppercase tracking-widest text-center mb-2">
          INTERACTIVE CAUSAL MONETARY SYSTEM NODES (CLICK ANY NODE TO DRILL DOWN)
        </div>

        {/* Node Architecture Flow */}
        <div className="flex flex-col items-center gap-3 w-full max-w-4xl font-mono text-xs">
          {/* Node 1: Currency */}
          <button
            onClick={() => setSelectedNode('CURRENCY')}
            className={`p-3 rounded-lg border w-72 text-center transition-all ${
              selectedNode === 'CURRENCY' ? 'bg-cyan-950 border-cyan-400 shadow-lg shadow-cyan-950 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'
            }`}
          >
            <div className="font-extrabold text-cyan-400">CURRENCY DESIGN</div>
            <div className="text-[11px] text-slate-400 mt-1">{currency.name} ({currency.code})</div>
          </button>

          {/* Branch Downward */}
          <div className="w-0.5 h-4 bg-slate-700" />

          {/* Tri-Branch: Reserves / Supply / Policy */}
          <div className="grid grid-cols-3 gap-4 w-full">
            <button
              onClick={() => setSelectedNode('RESERVES')}
              className={`p-3 rounded-lg border text-center transition-all ${
                selectedNode === 'RESERVES' ? 'bg-cyan-950 border-cyan-400 shadow-lg shadow-cyan-950 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'
              }`}
            >
              <div className="font-extrabold text-emerald-400">RESERVES</div>
              <div className="text-[10px] text-slate-400 mt-0.5">${(currency.locked_reserves / 1e9).toFixed(2)}B Value</div>
            </button>

            <button
              onClick={() => setSelectedNode('SUPPLY')}
              className={`p-3 rounded-lg border text-center transition-all ${
                selectedNode === 'SUPPLY' ? 'bg-cyan-950 border-cyan-400 shadow-lg shadow-cyan-950 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'
              }`}
            >
              <div className="font-extrabold text-cyan-400">MONEY SUPPLY</div>
              <div className="text-[10px] text-slate-400 mt-0.5">M0: {(currency.circulating_supply / 1e9).toFixed(1)}B</div>
            </button>

            <button
              onClick={() => setSelectedNode('POLICY')}
              className={`p-3 rounded-lg border text-center transition-all ${
                selectedNode === 'POLICY' ? 'bg-cyan-950 border-cyan-400 shadow-lg shadow-cyan-950 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'
              }`}
            >
              <div className="font-extrabold text-amber-400">MONETARY POLICY</div>
              <div className="text-[10px] text-slate-400 mt-0.5">Rate: {currency.monetary_policy.policyRate}%</div>
            </button>
          </div>

          <div className="w-0.5 h-4 bg-slate-700" />

          {/* Banking -> Credit -> Economy -> Trade -> FX Pipeline */}
          <div className="grid grid-cols-5 gap-2 w-full text-[11px]">
            {[
              { id: 'BANKING', label: 'BANKING', val: `${macro?.numberOfBanks || 20} Banks` },
              { id: 'CREDIT', label: 'CREDIT', val: `+${macro?.creditGrowthPct || 4.8}%` },
              { id: 'ECONOMY', label: 'ECONOMY', val: `$${macro?.nominalGDPUSD || 12450}B` },
              { id: 'TRADE', label: 'TRADE', val: `+$${macro?.currentAccountBlnUSD || 200}B` },
              { id: 'FX', label: 'FX MARKET', val: `${currency.code}/USD` }
            ].map((step) => (
              <button
                key={step.id}
                onClick={() => setSelectedNode(step.id)}
                className={`p-2.5 rounded border text-center transition-all ${
                  selectedNode === step.id ? 'bg-cyan-950 border-cyan-400 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'
                }`}
              >
                <div className="font-bold text-cyan-300">{step.label}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">{step.val}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Node Inspection Panel */}
        {(() => {
          const activeNode = nodes.find((n) => n.id === selectedNode) || nodes[0];
          return (
            <div className="w-full bg-slate-900 border border-slate-800 rounded p-4 mt-2 font-mono text-xs flex items-center justify-between">
              <div>
                <span className="text-cyan-400 font-extrabold text-sm mr-3">ACTIVE NODE: {activeNode.label}</span>
                <span className="text-slate-200">{activeNode.detail}</span>
              </div>

              <button
                onClick={() => onNavigateTab(activeNode.targetTab)}
                className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded flex items-center gap-1.5 transition-colors"
              >
                <span>OPEN NODE CONTROLS</span>
              </button>
            </div>
          );
        })()}
      </div>

      {/* Macro Indicators Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">NOMINAL GDP</span>
          <span className="text-base font-extrabold text-white mt-1 block">${macro?.nominalGDPUSD || 12450}B</span>
          <span className="text-[10px] text-emerald-400">+{macro?.realGDPGrowthPct || 2.15}% REAL</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">CPI HEADLINE</span>
          <span className="text-base font-extrabold text-slate-200 mt-1 block">{macro?.cpiHeadlinePct || 2.40}%</span>
          <span className="text-[10px] text-slate-500">Target: {currency.monetary_policy.inflationTarget}%</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">PPI INFLATION</span>
          <span className="text-base font-extrabold text-slate-200 mt-1 block">{macro?.ppiPct || 1.85}%</span>
          <span className="text-[10px] text-slate-500">Producer Prices</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">UNEMPLOYMENT</span>
          <span className="text-base font-extrabold text-amber-400 mt-1 block">{macro?.unemploymentRatePct || 4.10}%</span>
          <span className="text-[10px] text-slate-500">Labor Market</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">CREDIT GROWTH</span>
          <span className="text-base font-extrabold text-cyan-400 mt-1 block">+{macro?.creditGrowthPct || 4.80}%</span>
          <span className="text-[10px] text-slate-500">Banking Expansion</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-3">
          <span className="text-slate-400 block">CURRENT ACCOUNT</span>
          <span className="text-base font-extrabold text-emerald-400 mt-1 block">+${macro?.currentAccountBlnUSD || 200}B</span>
          <span className="text-[10px] text-slate-500">Net Exports Trade</span>
        </div>
      </div>
    </div>
  );
};
