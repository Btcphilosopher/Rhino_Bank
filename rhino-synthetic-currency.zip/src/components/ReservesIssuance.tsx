import React, { useState } from 'react';
import { ShieldCheck, ArrowUpRight, ArrowDownRight, Layers, AlertTriangle, RefreshCw, Lock } from 'lucide-react';
import { ReserveAsset, SyntheticCurrency } from '../types/currency';

interface ReservesIssuanceProps {
  currencies: SyntheticCurrency[];
  reserves: ReserveAsset[];
  selectedCurrencyCode: string;
  onRefresh: () => void;
}

export const ReservesIssuance: React.FC<ReservesIssuanceProps> = ({
  currencies,
  reserves,
  selectedCurrencyCode,
  onRefresh
}) => {
  const currentCurrency = currencies.find((c) => c.code === selectedCurrencyCode) || currencies[0];

  // Mint / Redeem State
  const [mintAmount, setMintAmount] = useState<number>(100000000); // 100M
  const [mintReceiver, setMintReceiver] = useState<string>('Barclays Primary Dealer');
  const [redeemAmount, setRedeemAmount] = useState<number>(50000000); // 50M
  const [redeemSender, setRedeemSender] = useState<string>('JPMorgan Liquidity Vault');
  const [actionMessage, setActionMessage] = useState<string>('');

  // Stress Test Shock State
  const [usdShock, setUsdShock] = useState<number>(0);
  const [goldShock, setGoldShock] = useState<number>(0);

  const totalReserveValueUSD = reserves.reduce((acc, r) => acc + r.totalValueUSD * (1 + (r.symbol === 'USD' ? usdShock / 100 : r.symbol === 'XAU' ? goldShock / 100 : 0)), 0);
  const totalCirculatingValueUSD = (currentCurrency?.circulating_supply || 0) * (currentCurrency?.unitValueUSD || 1);
  const coverageRatio = Number((totalReserveValueUSD / totalCirculatingValueUSD * 100).toFixed(2));

  const handleIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionMessage('');
    try {
      const res = await fetch(`/api/v1/currencies/${currentCurrency.code}/issue`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: Number(mintAmount), receiver: mintReceiver })
      });
      const data = await res.json();
      if (data.success) {
        setActionMessage(`MINT SUCCESSFUL: ${data.message}`);
        onRefresh();
      } else {
        setActionMessage(`MINT ERROR: ${data.message}`);
      }
    } catch (err: any) {
      setActionMessage(`Minting failed: ${err.message}`);
    }
  };

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionMessage('');
    try {
      const res = await fetch(`/api/v1/currencies/${currentCurrency.code}/redeem`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: Number(redeemAmount), sender: redeemSender })
      });
      const data = await res.json();
      if (data.success) {
        setActionMessage(`REDEMPTION SUCCESSFUL: ${data.message}`);
        onRefresh();
      } else {
        setActionMessage(`REDEMPTION ERROR: ${data.message}`);
      }
    } catch (err: any) {
      setActionMessage(`Redemption failed: ${err.message}`);
    }
  };

  if (!currentCurrency) {
    return (
      <div className="p-8 text-center text-slate-400 font-mono">
        INITIALIZING RESERVES & ISSUANCE ENGINE...
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Top Coverage Gauge Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            <h1 className="text-xl font-extrabold text-white">RHINO RESERVE MANAGEMENT & ISSUANCE ENGINE</h1>
            <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-xs font-mono font-bold">
              100%+ COLLATERALIZED
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Institutional Reserve Asset Vault, Coverage Ratio Auditor & Mint/Redemption Lifecycle
          </p>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div className="text-right">
            <span className="text-slate-400 block">TOTAL RESERVES (USD)</span>
            <span className="text-2xl font-black text-cyan-400">${(totalReserveValueUSD / 1e9).toFixed(3)}B</span>
          </div>
          <div className="text-right border-l border-slate-800 pl-4">
            <span className="text-slate-400 block">M0 CIRCULATING VALUE</span>
            <span className="text-xl font-bold text-slate-200">${(totalCirculatingValueUSD / 1e9).toFixed(3)}B</span>
          </div>
          <div className="text-right border-l border-slate-800 pl-4">
            <span className="text-slate-400 block">COVERAGE RATIO</span>
            <span className={`text-2xl font-black ${coverageRatio >= 100 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {coverageRatio}%
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Reserve Assets (7 cols) + Issuance/Redemption Engine (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT: Reserve Assets Portfolio Table (7 cols) */}
        <div className="lg:col-span-7 bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-col gap-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white flex items-center gap-1.5 text-sm">
              <Lock className="w-4 h-4 text-cyan-400" />
              ALLOCATED RESERVE VAULT ASSETS
            </span>
            <span className="text-slate-400 text-[11px]">{reserves.length} ASSETS ALLOCATED</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[11px]">
                <tr>
                  <th className="p-2">ASSET NAME</th>
                  <th className="p-2">CATEGORY</th>
                  <th className="p-2">QUANTITY</th>
                  <th className="p-2">PRICE USD</th>
                  <th className="p-2 text-right">TOTAL VALUE</th>
                  <th className="p-2 text-right">HAIRCUT</th>
                  <th className="p-2 text-right">CUSTODIAN</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {reserves.map((r) => {
                  const val = r.totalValueUSD * (1 + (r.symbol === 'USD' ? usdShock / 100 : r.symbol === 'XAU' ? goldShock / 100 : 0));
                  return (
                    <tr key={r.asset_id} className="hover:bg-slate-900/50">
                      <td className="p-2 font-bold text-white flex items-center gap-1.5">
                        <span className="text-cyan-400">{r.symbol}</span> {r.name}
                      </td>
                      <td className="p-2 text-slate-400">{r.category}</td>
                      <td className="p-2 text-slate-300">{(r.quantity / 1e6).toFixed(2)}M</td>
                      <td className="p-2 text-slate-300">${r.marketPriceUSD.toLocaleString()}</td>
                      <td className="p-2 text-right font-bold text-cyan-300">${(val / 1e6).toFixed(1)}M</td>
                      <td className="p-2 text-right text-amber-400">{r.haircut}%</td>
                      <td className="p-2 text-right text-slate-400 text-[11px] truncate max-w-[120px]">{r.custodian}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Reserve Interactive Stress Test Sliders */}
          <div className="bg-slate-900 p-3 rounded border border-slate-800 mt-2 space-y-2">
            <div className="font-bold text-amber-400 text-xs flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              RESERVE STRESS SIMULATION (APPLY SHOCKS)
            </div>
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>USD ASSET SHOCK:</span>
                  <span className="text-rose-400 font-bold">{usdShock}%</span>
                </div>
                <input
                  type="range"
                  min="-30"
                  max="10"
                  value={usdShock}
                  onChange={(e) => setUsdShock(parseInt(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>GOLD PRICE SHOCK:</span>
                  <span className="text-amber-400 font-bold">{goldShock}%</span>
                </div>
                <input
                  type="range"
                  min="-40"
                  max="20"
                  value={goldShock}
                  onChange={(e) => setGoldShock(parseInt(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: Minting & Redemption Lifecycle Engine (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4 font-mono text-xs">
          {/* Minting Form */}
          <div className="bg-[#0f172a] border border-slate-800 rounded p-4 space-y-3">
            <h3 className="font-bold text-emerald-400 text-sm flex items-center gap-2 border-b border-slate-800 pb-2">
              <ArrowUpRight className="w-4 h-4" />
              CURRENCY ISSUANCE (MINT)
            </h3>

            <form onSubmit={handleIssue} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">ISSUANCE AMOUNT ({currentCurrency.code})</label>
                <input
                  type="number"
                  step="10000000"
                  value={mintAmount}
                  onChange={(e) => setMintAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">PRIMARY DEALER RECEIVER</label>
                <input
                  type="text"
                  value={mintReceiver}
                  onChange={(e) => setMintReceiver(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-200"
                />
              </div>

              <div className="text-[11px] text-slate-400 bg-slate-900 p-2 rounded border border-slate-800">
                REQUIRED COLLATERAL: <strong className="text-cyan-300">${((mintAmount * currentCurrency.unitValueUSD * currentCurrency.monetary_policy.reserveRatioTarget / 100) / 1e6).toFixed(2)}M USD</strong>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded shadow-lg shadow-emerald-950 transition-colors"
              >
                MINT {currentCurrency.code} & DEPOSIT TO LEDGER
              </button>
            </form>
          </div>

          {/* Redemption Form */}
          <div className="bg-[#0f172a] border border-slate-800 rounded p-4 space-y-3">
            <h3 className="font-bold text-rose-400 text-sm flex items-center gap-2 border-b border-slate-800 pb-2">
              <ArrowDownRight className="w-4 h-4" />
              CURRENCY REDEMPTION (BURN)
            </h3>

            <form onSubmit={handleRedeem} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">REDEMPTION AMOUNT ({currentCurrency.code})</label>
                <input
                  type="number"
                  step="10000000"
                  value={redeemAmount}
                  onChange={(e) => setRedeemAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">INSTITUTIONAL HOLDER SENDER</label>
                <input
                  type="text"
                  value={redeemSender}
                  onChange={(e) => setRedeemSender(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-200"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-extrabold rounded shadow-lg shadow-rose-950 transition-colors"
              >
                BURN {currentCurrency.code} & RELEASE RESERVES
              </button>
            </form>

            {actionMessage && (
              <div className="p-3 bg-slate-900 border border-cyan-800 text-cyan-300 text-xs rounded">
                {actionMessage}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
