import React, { useState } from 'react';
import { AlertTriangle, Flame, ShieldAlert, Activity, CheckCircle2, RefreshCw } from 'lucide-react';
import { ScenarioResult, SyntheticCurrency } from '../types/currency';

interface ScenarioCrisisLabProps {
  currency: SyntheticCurrency;
}

export const ScenarioCrisisLab: React.FC<ScenarioCrisisLabProps> = ({ currency }) => {
  const [selectedScenarioKey, setSelectedScenarioKey] = useState<'RATE_SHOCK_200BP' | 'USD_DROP_10PCT' | 'BANK_RUN' | 'COMMODITY_CRISIS'>('RATE_SHOCK_200BP');
  const [scenarioResult, setScenarioResult] = useState<ScenarioResult | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const handleRunScenario = async (key: typeof selectedScenarioKey) => {
    setSelectedScenarioKey(key);
    setLoading(true);
    try {
      const res = await fetch('/api/v1/scenarios/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenarioKey: key })
      });
      const data = await res.json();
      setScenarioResult(data.result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Header Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-rose-500 animate-pulse" />
            <h1 className="text-xl font-extrabold text-white">MONETARY SCENARIO & CRISIS SIMULATOR</h1>
            <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-xs font-mono font-bold">
              STRESS ENGINE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Simulate Severe Systemic Crises, Capital Flight, Devaluation Shocks & Bank Runs
          </p>
        </div>
      </div>

      {/* Scenario Triggers Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono text-xs">
        {[
          { key: 'RATE_SHOCK_200BP', label: 'HAWKISH RATE SHOCK (+200BP)', desc: 'Policy rate hike to address runaway inflation', color: 'border-amber-700 bg-amber-950/30' },
          { key: 'USD_DROP_10PCT', label: 'USD DEVALUATION (-10%)', desc: 'Sharp foreign currency & gold revaluation', color: 'border-cyan-700 bg-cyan-950/30' },
          { key: 'BANK_RUN', label: 'BANKING CRISIS / RUN', desc: 'Reserve flight, liquidity freeze & M2 velocity drop', color: 'border-rose-700 bg-rose-950/30' },
          { key: 'COMMODITY_CRISIS', label: 'ENERGY & COMMODITY SHOCK', desc: 'Oil +45%, Gas +60%, PPI inflation spike', color: 'border-orange-700 bg-orange-950/30' }
        ].map((item) => (
          <button
            key={item.key}
            onClick={() => handleRunScenario(item.key as any)}
            className={`p-3 rounded border text-left transition-all ${
              selectedScenarioKey === item.key
                ? `${item.color} shadow-lg ring-1 ring-white/20`
                : 'bg-slate-900 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="font-extrabold text-white text-xs mb-1">{item.label}</div>
            <div className="text-[11px] text-slate-400">{item.desc}</div>
          </button>
        ))}
      </div>

      {/* Scenario Outputs View */}
      {scenarioResult && (
        <div className="bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span className="text-slate-400 block text-[11px]">SCENARIO EXECUTION OUTPUT</span>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                {scenarioResult.scenarioName}
              </h2>
            </div>

            <div className="px-3 py-1 bg-slate-900 border border-slate-800 rounded font-bold text-cyan-300">
              SIMULATOR STATUS: COMPLETED
            </div>
          </div>

          {/* Shocks Applied */}
          <div className="space-y-1.5">
            <span className="text-slate-400 block font-bold">EXOGENOUS SHOCKS APPLIED:</span>
            <div className="flex flex-wrap gap-2">
              {scenarioResult.shocks.map((s, idx) => (
                <span key={idx} className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-200">
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Impact Metrics Breakdown */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2 border-t border-slate-800">
            <div className="bg-slate-900 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block">RESERVE VALUE IMPACT</span>
              <span className={`text-base font-black mt-1 block ${scenarioResult.impactOnReserveValuePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {scenarioResult.impactOnReserveValuePct >= 0 ? '+' : ''}{scenarioResult.impactOnReserveValuePct}%
              </span>
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block">CURRENCY PRICE IMPACT</span>
              <span className={`text-base font-black mt-1 block ${scenarioResult.impactOnCurrencyPricePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {scenarioResult.impactOnCurrencyPricePct >= 0 ? '+' : ''}{scenarioResult.impactOnCurrencyPricePct}%
              </span>
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block">NEW COVERAGE RATIO</span>
              <span className="text-base font-black text-cyan-400 mt-1 block">
                {scenarioResult.impactOnCoverageRatio}%
              </span>
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block">SYNTHETIC GDP IMPACT</span>
              <span className={`text-base font-black mt-1 block ${scenarioResult.impactOnGDPPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {scenarioResult.impactOnGDPPct >= 0 ? '+' : ''}{scenarioResult.impactOnGDPPct}%
              </span>
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block">INFLATION IMPACT</span>
              <span className="text-base font-black text-amber-400 mt-1 block">
                {scenarioResult.impactOnInflationPct >= 0 ? '+' : ''}{scenarioResult.impactOnInflationPct}%
              </span>
            </div>
          </div>

          {/* Recommended Action */}
          <div className="p-3 bg-slate-900 border border-cyan-800/80 rounded space-y-1">
            <span className="font-bold text-cyan-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              RECOMMENDED MONETARY AUTHORITY MITIGATION POLICY
            </span>
            <p className="text-slate-200">{scenarioResult.recommendedAction}</p>
          </div>
        </div>
      )}
    </div>
  );
};
