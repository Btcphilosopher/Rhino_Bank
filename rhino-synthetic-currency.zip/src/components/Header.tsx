import React from 'react';
import { Play, Pause, FastForward, Shield, Cpu, RefreshCw } from 'lucide-react';
import { SyntheticCurrency } from '../types/currency';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currencies: SyntheticCurrency[];
  selectedCurrencyCode: string;
  setSelectedCurrencyCode: (code: string) => void;
  isSimulating: boolean;
  setIsSimulating: (sim: boolean) => void;
  onTickSimulation: (days: number) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currencies,
  selectedCurrencyCode,
  setSelectedCurrencyCode,
  isSimulating,
  setIsSimulating,
  onTickSimulation
}) => {
  const tabs = [
    { id: 'fx', label: 'FX Exchange' },
    { id: 'foundry', label: 'Currency Foundry' },
    { id: 'monetary', label: 'Monetary Authority' },
    { id: 'reserves', label: 'Reserves & Mint' },
    { id: 'digital-twin', label: 'Digital Twin & Macro' },
    { id: 'derivatives', label: 'Yield & Volatility' },
    { id: 'portfolio', label: 'Portfolio & Risk' },
    { id: 'scenarios', label: 'Crisis & Scenarios' },
    { id: 'ledger', label: 'Central Ledger' },
    { id: 'ai', label: 'AI Intelligence' }
  ];

  const currentCurrency = currencies.find((c) => c.code === selectedCurrencyCode) || currencies[0];

  return (
    <header className="bg-[#0f172a] border-b border-slate-800 text-slate-100 shrink-0 select-none">
      {/* Top Bar - Zone 1 (Brand), Zone 2 (Nav Links), Zone 3 (Primary Controls) */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800/80">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-8 h-8 rounded bg-cyan-950 border border-cyan-800 text-cyan-400 font-black tracking-wider text-sm shadow-inner">
            RH
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-white text-base">
                RHINO SYNTHETIC CURRENCY
              </span>
              <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                RHINOQUANT 3.6
              </span>
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-2 font-mono">
              <span>CANARY WHARF / INSTITUTIONAL MONETARY SYSTEM</span>
              <span>·</span>
              <span className="text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                SIMULATION LIVE
              </span>
            </div>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden xl:flex items-center gap-1">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium transition-colors rounded-md whitespace-nowrap ${
                  isActive
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Controls & Currency Switcher */}
        <div className="flex items-center gap-3">
          {/* Active Currency Selector */}
          <div className="flex items-center gap-2 bg-slate-900 px-2.5 py-1 rounded border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">UNIT:</span>
            <select
              value={selectedCurrencyCode}
              onChange={(e) => setSelectedCurrencyCode(e.target.value)}
              className="bg-transparent text-xs font-mono font-bold text-cyan-400 focus:outline-none cursor-pointer"
            >
              {currencies.map((c) => (
                <option key={c.code} value={c.code} className="bg-slate-900 text-white">
                  {c.code} ({c.symbol}) — ${c.unitValueUSD}
                </option>
              ))}
            </select>
          </div>

          {/* Simulation Time Control Buttons */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-700">
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className={`p-1.5 rounded text-xs flex items-center gap-1 font-mono transition-colors ${
                isSimulating ? 'bg-amber-950 text-amber-400 border border-amber-800' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
              title={isSimulating ? 'Pause Auto Simulation' : 'Play Auto Simulation'}
            >
              {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => onTickSimulation(1)}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono rounded flex items-center gap-1 border border-slate-700"
              title="Step Forward 1 Day"
            >
              <FastForward className="w-3 h-3 text-cyan-400" />
              <span>+1D</span>
            </button>
          </div>
        </div>
      </div>

      {/* Secondary Tab bar for smaller viewports */}
      <div className="xl:hidden flex items-center gap-1 px-3 py-1.5 overflow-x-auto bg-[#0d1322] border-b border-slate-800 scrollbar-thin">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-2.5 py-1 text-xs font-medium whitespace-nowrap rounded ${
              activeTab === tab.id
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Live Market Ticker Strip */}
      <div className="bg-[#0b0f19] px-4 py-1.5 flex items-center justify-between text-xs font-mono border-b border-slate-800/80 text-slate-300 overflow-x-auto">
        {currentCurrency ? (
          <>
            <div className="flex items-center gap-6 shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-semibold">{currentCurrency.code}/USD:</span>
                <span className="text-white font-bold">${currentCurrency.unitValueUSD}</span>
                <span className={(currentCurrency.change24hUSD || 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {(currentCurrency.change24hUSD || 0) >= 0 ? '+' : ''}{currentCurrency.change24hUSD || 0}%
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-semibold">RESERVES:</span>
                <span className="text-slate-200">${((currentCurrency.locked_reserves || 0) / 1e9).toFixed(2)}B</span>
                <span className="text-cyan-400 font-bold">({currentCurrency.money_supply?.totalReserveCoverageRatio || 0}% COV)</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-semibold">CIRCULATION (M0):</span>
                <span className="text-slate-200">${((currentCurrency.circulating_supply || 0) / 1e9).toFixed(2)}B {currentCurrency.code}</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-semibold">POLICY RATE:</span>
                <span className="text-amber-400 font-bold">{currentCurrency.monetary_policy?.policyRate || 0}%</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-semibold">INFLATION TGT:</span>
                <span className="text-slate-300">{currentCurrency.monetary_policy?.inflationTarget || 0}%</span>
              </div>
            </div>

            <div className="hidden lg:flex items-center gap-3 text-slate-400 shrink-0">
              <span>REGIME: <strong className="text-slate-200">{currentCurrency.fx_regime}</strong></span>
              <span>·</span>
              <span>GOVERNANCE: <strong className="text-slate-200">{currentCurrency.governance_model}</strong></span>
            </div>
          </>
        ) : (
          <div className="text-slate-500 text-xs font-mono py-0.5">INITIALIZING RHINO MONETARY SYSTEM...</div>
        )}
      </div>
    </header>
  );
};
