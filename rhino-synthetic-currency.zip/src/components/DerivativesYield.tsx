import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, TrendingUp, Layers, Sliders, DollarSign } from 'lucide-react';
import { SyntheticCurrency, YieldPoint, OptionQuote } from '../types/currency';

interface DerivativesYieldProps {
  currency: SyntheticCurrency;
}

export const DerivativesYield: React.FC<DerivativesYieldProps> = ({ currency }) => {
  const [activeSubTab, setActiveSubTab] = useState<'CURVE' | 'OPTIONS' | 'VOL_SURFACE' | 'SWAPS'>('CURVE');

  if (!currency) {
    return (
      <div className="p-8 text-center text-slate-400 font-mono">
        INITIALIZING DERIVATIVES & YIELD CURVE STATE...
      </div>
    );
  }

  // Term Structure Data
  const yieldCurveData: YieldPoint[] = [
    { tenor: '1D', rate: currency.monetary_policy.policyRate - 0.1, forwardRate: 3.68, carryBp: 12, basisBp: 2 },
    { tenor: '1W', rate: currency.monetary_policy.policyRate, forwardRate: 3.76, carryBp: 15, basisBp: 4 },
    { tenor: '1M', rate: currency.monetary_policy.policyRate + 0.15, forwardRate: 3.92, carryBp: 22, basisBp: 8 },
    { tenor: '3M', rate: currency.monetary_policy.policyRate + 0.35, forwardRate: 4.15, carryBp: 35, basisBp: 12 },
    { tenor: '6M', rate: currency.monetary_policy.policyRate + 0.50, forwardRate: 4.32, carryBp: 48, basisBp: 18 },
    { tenor: '1Y', rate: currency.monetary_policy.policyRate + 0.65, forwardRate: 4.50, carryBp: 62, basisBp: 24 },
    { tenor: '2Y', rate: currency.monetary_policy.policyRate + 0.80, forwardRate: 4.68, carryBp: 75, basisBp: 30 },
    { tenor: '5Y', rate: currency.monetary_policy.policyRate + 0.95, forwardRate: 4.82, carryBp: 88, basisBp: 38 },
    { tenor: '10Y', rate: currency.monetary_policy.policyRate + 1.10, forwardRate: 4.95, carryBp: 102, basisBp: 45 }
  ];

  // Options Pricing Matrix Data
  const optionsMatrix: OptionQuote[] = [
    { strike: Number((currency.unitValueUSD * 0.95).toFixed(4)), expiry: '1M', callPrice: 0.0542, putPrice: 0.0028, impliedVol: 6.8, delta: 0.88, gamma: 1.45, vega: 0.12, theta: -0.0015, rho: 0.042 },
    { strike: Number((currency.unitValueUSD * 0.98).toFixed(4)), expiry: '1M', callPrice: 0.0285, putPrice: 0.0092, impliedVol: 6.4, delta: 0.65, gamma: 2.10, vega: 0.18, theta: -0.0028, rho: 0.038 },
    { strike: Number((currency.unitValueUSD * 1.00).toFixed(4)), expiry: '1M', callPrice: 0.0162, putPrice: 0.0160, impliedVol: 6.2, delta: 0.50, gamma: 2.45, vega: 0.22, theta: -0.0035, rho: 0.031 },
    { strike: Number((currency.unitValueUSD * 1.02).toFixed(4)), expiry: '1M', callPrice: 0.0084, putPrice: 0.0278, impliedVol: 6.5, delta: 0.32, gamma: 1.95, vega: 0.17, theta: -0.0026, rho: 0.022 },
    { strike: Number((currency.unitValueUSD * 1.05).toFixed(4)), expiry: '1M', callPrice: 0.0021, putPrice: 0.0512, impliedVol: 7.1, delta: 0.12, gamma: 1.10, vega: 0.09, theta: -0.0012, rho: 0.011 }
  ];

  // 3D Volatility Surface Grid (Tenor vs Delta)
  const volSurface = [
    { tenor: '1W', d10Call: 7.8, d25Call: 6.9, atm: 6.4, d25Put: 6.8, d10Put: 7.5 },
    { tenor: '1M', d10Call: 7.4, d25Call: 6.6, atm: 6.2, d25Put: 6.5, d10Put: 7.2 },
    { tenor: '3M', d10Call: 7.1, d25Call: 6.4, atm: 6.0, d25Put: 6.3, d10Put: 6.9 },
    { tenor: '6M', d10Call: 6.9, d25Call: 6.3, atm: 5.9, d25Put: 6.2, d10Put: 6.7 },
    { tenor: '1Y', d10Call: 6.8, d25Call: 6.2, atm: 5.8, d25Put: 6.1, d10Put: 6.6 }
  ];

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Top Bar with Sub-Tab Nav */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-cyan-400" />
            <h1 className="text-xl font-extrabold text-white">SYNTHETIC CURRENCY DERIVATIVES & TERM STRUCTURE</h1>
            <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-xs font-mono font-bold">
              BLACK-SCHOLES / GARMAN-KOHLHAGEN
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Institutional Yield Curves, Forward Rates, Options Greeks & Volatility Surface Mapping
          </p>
        </div>

        {/* Sub-tab segmented buttons */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-800 font-mono text-xs">
          {[
            { id: 'CURVE', label: 'YIELD CURVE' },
            { id: 'OPTIONS', label: 'OPTIONS & GREEKS' },
            { id: 'VOL_SURFACE', label: 'VOLATILITY SURFACE' },
            { id: 'SWAPS', label: 'CURRENCY SWAPS' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-3 py-1.5 rounded transition-colors ${
                activeSubTab === tab.id
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* SUB-VIEW 1: Yield Curve / Term Structure */}
      {activeSubTab === 'CURVE' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Chart View (7 cols) */}
          <div className="lg:col-span-7 bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-sm flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                SYNTHETIC TERM STRUCTURE YIELD CURVE ({currency.code})
              </span>
              <span className="text-amber-400 font-bold">POLICY RATE: {currency.monetary_policy.policyRate}%</span>
            </div>

            <div className="h-64 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={yieldCurveData}>
                  <XAxis dataKey="tenor" stroke="#64748b" />
                  <YAxis domain={['dataMin - 0.5', 'dataMax + 0.5']} stroke="#64748b" />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc' }} />
                  <Line type="monotone" dataKey="rate" name="Yield Rate (%)" stroke="#38bdf8" strokeWidth={3} dot={{ r: 4, fill: '#38bdf8' }} />
                  <Line type="monotone" dataKey="forwardRate" name="Forward Rate (%)" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Curve Table (5 cols) */}
          <div className="lg:col-span-5 bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs">
            <div className="font-bold text-white text-sm border-b border-slate-800 pb-2 mb-2">
              TENOR DATA BREAKDOWN
            </div>

            <table className="w-full text-left">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-2">TENOR</th>
                  <th className="p-2">SPOT YIELD</th>
                  <th className="p-2">FORWARD</th>
                  <th className="p-2 text-right">CARRY (BP)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {yieldCurveData.map((y) => (
                  <tr key={y.tenor} className="hover:bg-slate-900/50">
                    <td className="p-2 font-bold text-cyan-400">{y.tenor}</td>
                    <td className="p-2 font-bold text-white">{y.rate}%</td>
                    <td className="p-2 text-amber-400">{y.forwardRate}%</td>
                    <td className="p-2 text-right text-emerald-400">+{y.carryBp}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: Options Pricing & Greeks Matrix */}
      {activeSubTab === 'OPTIONS' && (
        <div className="bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white text-sm">
              GARMAN-KOHLHAGEN OPTIONS PRICING MATRIX ({currency.code}/USD 1M EXPIRY)
            </span>
            <span className="text-slate-400">ATM VOLATILITY: 6.2%</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[11px]">
                <tr>
                  <th className="p-2">STRIKE (USD)</th>
                  <th className="p-2">CALL PRICE</th>
                  <th className="p-2">PUT PRICE</th>
                  <th className="p-2">IV (%)</th>
                  <th className="p-2 text-right">DELTA (Δ)</th>
                  <th className="p-2 text-right">GAMMA (Γ)</th>
                  <th className="p-2 text-right">VEGA (ν)</th>
                  <th className="p-2 text-right">THETA (Θ)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {optionsMatrix.map((opt) => (
                  <tr key={opt.strike} className="hover:bg-slate-900/50">
                    <td className="p-2 font-extrabold text-cyan-300">${opt.strike}</td>
                    <td className="p-2 font-bold text-emerald-400">${opt.callPrice}</td>
                    <td className="p-2 font-bold text-rose-400">${opt.putPrice}</td>
                    <td className="p-2 text-amber-400">{opt.impliedVol}%</td>
                    <td className="p-2 text-right font-bold text-white">{opt.delta}</td>
                    <td className="p-2 text-right text-slate-300">{opt.gamma}</td>
                    <td className="p-2 text-right text-cyan-400">{opt.vega}</td>
                    <td className="p-2 text-right text-rose-400">{opt.theta}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: 3D Volatility Surface Map */}
      {activeSubTab === 'VOL_SURFACE' && (
        <div className="bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs space-y-3">
          <div className="font-bold text-white text-sm border-b border-slate-800 pb-2">
            3D VOLATILITY SMILE / SURFACE MATRIX ({currency.code}/USD)
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-2 text-left">TENOR</th>
                  <th className="p-2">10D PUT</th>
                  <th className="p-2">25D PUT</th>
                  <th className="p-2 bg-cyan-950/60 text-cyan-300 font-bold">ATM VOL</th>
                  <th className="p-2">25D CALL</th>
                  <th className="p-2">10D CALL</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {volSurface.map((v) => (
                  <tr key={v.tenor} className="hover:bg-slate-900/50">
                    <td className="p-2 text-left font-bold text-cyan-400">{v.tenor}</td>
                    <td className="p-2 text-amber-400 font-bold">{v.d10Put}%</td>
                    <td className="p-2 text-slate-200">{v.d25Put}%</td>
                    <td className="p-2 bg-cyan-950/40 text-cyan-300 font-extrabold text-sm">{v.atm}%</td>
                    <td className="p-2 text-slate-200">{v.d25Call}%</td>
                    <td className="p-2 text-amber-400 font-bold">{v.d10Call}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: Swaps */}
      {activeSubTab === 'SWAPS' && (
        <div className="bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs space-y-3">
          <div className="font-bold text-white text-sm border-b border-slate-800 pb-2">
            CROSS-CURRENCY BASIS SWAPS ({currency.code} VS USD)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="bg-slate-900 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block">1Y CROSS CURRENCY SWAP</span>
              <span className="text-lg font-bold text-white mt-1 block">FIXED 3.95% / SOFR</span>
              <span className="text-[10px] text-cyan-400">Basis: +12 bp</span>
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block">5Y CROSS CURRENCY SWAP</span>
              <span className="text-lg font-bold text-white mt-1 block">FIXED 4.35% / SOFR</span>
              <span className="text-[10px] text-cyan-400">Basis: +24 bp</span>
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block">10Y SOVEREIGN CDS SPREAD</span>
              <span className="text-lg font-bold text-amber-400 mt-1 block">18.5 BP</span>
              <span className="text-[10px] text-emerald-400">AAA Sovereign Credit Rating</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
