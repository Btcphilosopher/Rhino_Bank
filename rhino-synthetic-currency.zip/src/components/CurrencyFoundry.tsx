import React, { useState } from 'react';
import { PlusCircle, Layers, Sparkles, Sliders, CheckCircle2, History, Database, Code } from 'lucide-react';
import { SyntheticCurrency, CurrencyType, FXRegime, GovernanceModel, BasketComponent } from '../types/currency';

interface CurrencyFoundryProps {
  currencies: SyntheticCurrency[];
  onCurrencyCreated: () => void;
}

export const CurrencyFoundry: React.FC<CurrencyFoundryProps> = ({ currencies, onCurrencyCreated }) => {
  const [selectedCurrencyId, setSelectedCurrencyId] = useState<string>(currencies[0]?.currency_id || '');
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);

  // New Currency Form State
  const [name, setName] = useState<string>('Atlantic Commerce Unit');
  const [code, setCode] = useState<string>('ACU');
  const [symbol, setSymbol] = useState<string>('₢');
  const [unitOfAccount, setUnitOfAccount] = useState<string>('North Atlantic Index');
  const [type, setType] = useState<CurrencyType>('CURRENCY_BASKET');
  const [fxRegime, setFxRegime] = useState<FXRegime>('MANAGED_FLOAT');
  const [initialSupply, setInitialSupply] = useState<number>(5000000000); // 5B
  const [policyRate, setPolicyRate] = useState<number>(3.5);
  const [inflationTarget, setInflationTarget] = useState<number>(2.0);
  const [reserveRatioTarget, setReserveRatioTarget] = useState<number>(105.0);
  const [governanceModel, setGovernanceModel] = useState<GovernanceModel>('RHINO_MONETARY_AUTHORITY');

  // Basket builder components
  const [basket, setBasket] = useState<BasketComponent[]>([
    { symbol: 'USD', name: 'US Dollar', category: 'CURRENCY', weight: 40, quantity: 0.40, marketPriceUSD: 1.0, fxRateToUSD: 1.0, contribution: 0.40 },
    { symbol: 'EUR', name: 'Euro', category: 'CURRENCY', weight: 30, quantity: 0.28, marketPriceUSD: 1.085, fxRateToUSD: 1.085, contribution: 0.3038 },
    { symbol: 'GBP', name: 'British Pound', category: 'CURRENCY', weight: 20, quantity: 0.15, marketPriceUSD: 1.302, fxRateToUSD: 1.302, contribution: 0.1953 },
    { symbol: 'GOLD', name: 'Physical Gold', category: 'COMMODITY', weight: 10, quantity: 0.000038, marketPriceUSD: 2650.0, fxRateToUSD: 1.0, contribution: 0.1007 }
  ]);

  const [createMessage, setCreateMessage] = useState<string>('');

  const currentCurrency = currencies.find((c) => c.currency_id === selectedCurrencyId) || currencies[0];

  const handleWeightChange = (index: number, newWeight: number) => {
    const updated = [...basket];
    updated[index].weight = newWeight;
    setBasket(updated);
  };

  const handleCreateCurrency = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateMessage('');
    try {
      const res = await fetch('/api/v1/currencies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          code,
          symbol,
          unit_of_account: unitOfAccount,
          type,
          fx_regime: fxRegime,
          initial_supply: Number(initialSupply),
          governance_model: governanceModel,
          basket,
          monetary_policy: {
            policyRate: Number(policyRate),
            reserveRatioTarget: Number(reserveRatioTarget),
            inflationTarget: Number(inflationTarget),
            moneySupplyTargetM2: Number((initialSupply * 2.2 / 1e9).toFixed(1)),
            assetPurchasesActive: false,
            monthlyPurchaseVolumeUSD: 0,
            fxInterventionThreshold: 2.5,
            version: 1,
            lastUpdated: new Date().toISOString().split('T')[0]
          }
        })
      });

      const data = await res.json();
      if (data.success) {
        setCreateMessage(`Synthetic Currency ${code} Created Successfully!`);
        onCurrencyCreated();
        setShowCreateModal(false);
      } else {
        setCreateMessage(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setCreateMessage(`Creation failed: ${err.message}`);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Top Header & Create Button */}
      <div className="flex flex-wrap items-center justify-between bg-[#0f172a] border border-slate-800 rounded p-4 gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            SYNTHETIC CURRENCY FOUNDRY
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Institutional Synthetic Currency Creation, Basket Engineering & Master Object Manager
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs font-mono rounded flex items-center gap-2 shadow-lg shadow-cyan-950 transition-colors"
        >
          <PlusCircle className="w-4 h-4" />
          <span>CREATE NEW SYNTHETIC CURRENCY</span>
        </button>
      </div>

      {/* Main Grid: Currency Selector + Master Object Inspection */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT: Existing Currencies List (4 cols) */}
        <div className="lg:col-span-4 bg-[#0f172a] border border-slate-800 rounded p-3 flex flex-col gap-2">
          <div className="text-xs font-mono font-bold text-slate-400 border-b border-slate-800 pb-2">
            SYNTHETIC MONETARY UNITS ({currencies.length})
          </div>

          <div className="space-y-2 max-h-[600px] overflow-y-auto">
            {currencies.map((c) => {
              const isSelected = c.currency_id === selectedCurrencyId;
              return (
                <div
                  key={c.currency_id}
                  onClick={() => setSelectedCurrencyId(c.currency_id)}
                  className={`p-3 rounded border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500 shadow-md shadow-cyan-950/40'
                      : 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold font-mono text-white text-sm flex items-center gap-1.5">
                      <span className="text-cyan-400 font-black">{c.symbol}</span> {c.code}
                    </span>
                    <span className="text-[11px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                      {c.type}
                    </span>
                  </div>

                  <div className="text-xs text-slate-300 font-medium mt-1">{c.name}</div>

                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800/60 font-mono text-[11px] text-slate-400">
                    <div>UNIT VAL: <strong className="text-white">${c.unitValueUSD}</strong></div>
                    <div>RATE: <strong className="text-amber-400">{c.monetary_policy.policyRate}%</strong></div>
                    <div>M0 SUPPLY: <strong className="text-slate-200">{(c.circulating_supply / 1e9).toFixed(1)}B</strong></div>
                    <div>REGIME: <strong className="text-slate-200">{c.fx_regime}</strong></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT: Selected Currency Master Object Inspector (8 cols) */}
        {currentCurrency && (
          <div className="lg:col-span-8 bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-col gap-4 font-mono text-xs">
            {/* Header / Identity */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-2xl font-black text-cyan-400">{currentCurrency.symbol}</span>
                  <h2 className="text-xl font-extrabold text-white">{currentCurrency.name} ({currentCurrency.code})</h2>
                  <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded font-bold">
                    {currentCurrency.status}
                  </span>
                </div>
                <div className="text-slate-400 mt-1">
                  ISSUER: {currentCurrency.issuer} · CREATION: {currentCurrency.creation_date} · UNIT OF ACCOUNT: {currentCurrency.unit_of_account}
                </div>
              </div>

              <div className="text-right">
                <div className="text-2xl font-black text-cyan-400">${currentCurrency.unitValueUSD} USD</div>
                <div className="text-slate-400">CALCULATED SYNTHETIC BASKET VAL</div>
              </div>
            </div>

            {/* Basket Composition Breakdown Table */}
            <div className="space-y-2">
              <h3 className="font-bold text-slate-200 flex items-center gap-1.5 text-sm">
                <Layers className="w-4 h-4 text-cyan-400" />
                BASKET ENGINE COMPOSITION ({currentCurrency.basket.length} COMPONENTS)
              </h3>

              <div className="border border-slate-800 rounded overflow-hidden">
                <table className="w-full text-left font-mono">
                  <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="p-2">ASSET</th>
                      <th className="p-2">CATEGORY</th>
                      <th className="p-2">TARGET WEIGHT</th>
                      <th className="p-2">QUANTITY UNIT</th>
                      <th className="p-2">MKT PRICE (USD)</th>
                      <th className="p-2 text-right">CONTRIBUTION</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {currentCurrency.basket.map((b) => (
                      <tr key={b.symbol} className="hover:bg-slate-900/50">
                        <td className="p-2 font-bold text-white flex items-center gap-1.5">
                          <span className="text-cyan-400">{b.symbol}</span> {b.name}
                        </td>
                        <td className="p-2 text-slate-400">{b.category}</td>
                        <td className="p-2 font-bold text-slate-200">{b.weight}%</td>
                        <td className="p-2 text-slate-300">{b.quantity}</td>
                        <td className="p-2 text-slate-300">${b.marketPriceUSD}</td>
                        <td className="p-2 text-right font-bold text-cyan-300">${b.contribution.toFixed(4)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Monetary Policy & Money Supply Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Policy Settings */}
              <div className="bg-slate-900 p-3 rounded border border-slate-800 space-y-2">
                <h4 className="font-bold text-cyan-400 border-b border-slate-800 pb-1">MONETARY POLICY CONFIG</h4>
                <div className="flex justify-between"><span>POLICY RATE:</span><strong className="text-amber-400">{currentCurrency.monetary_policy.policyRate}%</strong></div>
                <div className="flex justify-between"><span>INFLATION TARGET:</span><strong className="text-slate-200">{currentCurrency.monetary_policy.inflationTarget}%</strong></div>
                <div className="flex justify-between"><span>RESERVE TARGET:</span><strong className="text-slate-200">{currentCurrency.monetary_policy.reserveRatioTarget}%</strong></div>
                <div className="flex justify-between"><span>M2 TARGET:</span><strong className="text-slate-200">${currentCurrency.monetary_policy.moneySupplyTargetM2}B</strong></div>
                <div className="flex justify-between"><span>INTERVENTION THRESHOLD:</span><strong className="text-slate-200">±{currentCurrency.monetary_policy.fxInterventionThreshold}%</strong></div>
              </div>

              {/* Money Supply Aggregates */}
              <div className="bg-slate-900 p-3 rounded border border-slate-800 space-y-2">
                <h4 className="font-bold text-cyan-400 border-b border-slate-800 pb-1">MONEY SUPPLY AGGREGATES</h4>
                <div className="flex justify-between"><span>M0 (BASE MONEY):</span><strong className="text-white">{(currentCurrency.money_supply.m0 / 1e9).toFixed(2)}B {currentCurrency.code}</strong></div>
                <div className="flex justify-between"><span>M1 (CURRENCY + DEMAND):</span><strong className="text-slate-200">{(currentCurrency.money_supply.m1 / 1e9).toFixed(2)}B</strong></div>
                <div className="flex justify-between"><span>M2 (BROAD MONEY):</span><strong className="text-slate-200">{(currentCurrency.money_supply.m2 / 1e9).toFixed(2)}B</strong></div>
                <div className="flex justify-between"><span>VELOCITY (V):</span><strong className="text-emerald-400">{currentCurrency.money_supply.velocity}</strong></div>
                <div className="flex justify-between"><span>RESERVE COVERAGE:</span><strong className="text-cyan-300">{currentCurrency.money_supply.totalReserveCoverageRatio}%</strong></div>
              </div>
            </div>

            {/* Historical Versioning Chain */}
            <div className="space-y-2">
              <h3 className="font-bold text-slate-200 flex items-center gap-1.5 text-sm">
                <History className="w-4 h-4 text-cyan-400" />
                IMMUTABLE MONETARY CONFIGURATION VERSION HISTORY
              </h3>

              <div className="space-y-1.5">
                {currentCurrency.versionHistory.map((v) => (
                  <div key={v.version} className="bg-slate-900 p-2.5 rounded border border-slate-800 flex justify-between items-center text-xs">
                    <div>
                      <span className="font-bold text-cyan-400 mr-2">VERSION {v.version}</span>
                      <span className="text-slate-400 mr-3">{v.timestamp}</span>
                      <span className="text-slate-200">{v.changeNote}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-amber-400 font-bold">RATE: {v.policyRate}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* CREATE NEW SYNTHETIC CURRENCY MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#0f172a] border border-cyan-700/80 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto p-5 font-mono text-xs space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                CREATE SYNTHETIC CURRENCY FROM FIRST PRINCIPLES
              </h2>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleCreateCurrency} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">CURRENCY NAME</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white font-bold"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">CODE / TICKER (3-4 LETTER)</label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-cyan-400 font-extrabold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">SYMBOL</label>
                  <input
                    type="text"
                    value={symbol}
                    onChange={(e) => setSymbol(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white font-bold text-center"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">CURRENCY TYPE</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as CurrencyType)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  >
                    <option value="CURRENCY_BASKET">CURRENCY BASKET</option>
                    <option value="COMMODITY_BASKET">COMMODITY BASKET</option>
                    <option value="REAL_ASSET_INDEX">REAL ASSET INDEX</option>
                    <option value="STABILITY_UNIT">STABILITY UNIT</option>
                    <option value="FREE_FLOAT">FREE FLOAT</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">FX REGIME</label>
                  <select
                    value={fxRegime}
                    onChange={(e) => setFxRegime(e.target.value as FXRegime)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  >
                    <option value="MANAGED_FLOAT">MANAGED FLOAT</option>
                    <option value="FREE_FLOAT">FREE FLOAT</option>
                    <option value="CRAWLING_PEG">CRAWLING PEG</option>
                    <option value="ALGORITHMIC_STABILITY">ALGORITHMIC STABILITY</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">INITIAL SUPPLY (M0)</label>
                  <input
                    type="number"
                    value={initialSupply}
                    onChange={(e) => setInitialSupply(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">POLICY RATE (%)</label>
                  <input
                    type="number"
                    step="0.25"
                    value={policyRate}
                    onChange={(e) => setPolicyRate(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-amber-400 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">RESERVE COVERAGE TARGET (%)</label>
                  <input
                    type="number"
                    value={reserveRatioTarget}
                    onChange={(e) => setReserveRatioTarget(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white"
                  />
                </div>
              </div>

              {/* Basket Component Builder */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <label className="block text-cyan-400 font-bold">BASKET WEIGHT ALLOCATION</label>
                {basket.map((comp, idx) => (
                  <div key={comp.symbol} className="flex items-center gap-3 bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="w-16 font-bold text-white">{comp.symbol}</span>
                    <span className="w-32 text-slate-400">{comp.name}</span>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={comp.weight}
                      onChange={(e) => handleWeightChange(idx, parseInt(e.target.value))}
                      className="flex-1 accent-cyan-500 cursor-pointer"
                    />
                    <span className="w-12 text-right font-bold text-cyan-300">{comp.weight}%</span>
                  </div>
                ))}
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold text-sm rounded shadow-lg shadow-cyan-950 transition-colors"
              >
                INSTANTIATE SYNTHETIC MONETARY SYSTEM
              </button>
            </form>

            {createMessage && (
              <div className="p-3 bg-slate-900 border border-cyan-800 text-cyan-300 text-xs rounded">
                {createMessage}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
