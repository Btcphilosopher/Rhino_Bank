import React, { useState } from 'react';
import { Bot, Send, Sparkles, Brain, CheckCircle2, Sliders, AlertCircle, RefreshCw } from 'lucide-react';
import { SyntheticCurrency } from '../types/currency';

interface RhinoAIIntelligenceProps {
  currencies: SyntheticCurrency[];
  selectedCurrencyCode: string;
}

export const RhinoAIIntelligence: React.FC<RhinoAIIntelligenceProps> = ({ currencies, selectedCurrencyCode }) => {
  const [query, setQuery] = useState<string>('Decompose RGU value drivers and analyze what happens if USD falls 10%.');
  const [responseAnswer, setResponseAnswer] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const samplePrompts = [
    `Why is ${selectedCurrencyCode} strengthening or weakening?`,
    `What happens if USD falls 10% on ${selectedCurrencyCode} reserves?`,
    `Which basket component contributes most to ${selectedCurrencyCode}'s price?`,
    `Simulate a 5% monetary supply expansion on ${selectedCurrencyCode}.`,
    `Compare ${selectedCurrencyCode} risk exposures with other synthetic currencies.`,
    `Decompose factor betas and 1D 99% VaR for Rhino Bank portfolio.`
  ];

  const handleAskAI = async (promptToUse?: string) => {
    const q = promptToUse || query;
    if (!q) return;
    setLoading(true);
    setResponseAnswer('');

    try {
      const res = await fetch('/api/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, currencyCode: selectedCurrencyCode })
      });
      const data = await res.json();
      setResponseAnswer(data.answer || 'No response returned from AI model.');
    } catch (err: any) {
      setResponseAnswer(`Error calling Rhino AI Intelligence: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 p-4 gap-4 overflow-y-auto font-sans">
      {/* Header Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-cyan-400 animate-pulse" />
            <h1 className="text-xl font-extrabold text-white">RHINO CURRENCY INTELLIGENCE (AI)</h1>
            <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-xs font-mono font-bold">
              GEMINI 3.8 FLASH MONETARY ENGINE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Institutional AI Quantitative Strategist · Strict Multi-Tag Decomposition ([OBSERVED], [CALCULATED], [SIMULATED], [SCENARIO], [ASSUMPTION])
          </p>
        </div>
      </div>

      {/* Main Grid: Sample Prompts (4 cols) + Chat Response Area (8 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* LEFT: Preset Prompt Buttons (4 cols) */}
        <div className="lg:col-span-4 bg-[#0f172a] border border-slate-800 rounded p-4 flex flex-col gap-3 font-mono text-xs">
          <div className="font-bold text-slate-300 border-b border-slate-800 pb-2 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            INSTITUTIONAL QUANT PROMPTS
          </div>

          <div className="space-y-2">
            {samplePrompts.map((promptText, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setQuery(promptText);
                  handleAskAI(promptText);
                }}
                className="w-full p-2.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-left text-slate-200 transition-all font-mono text-xs leading-relaxed"
              >
                {promptText}
              </button>
            ))}
          </div>

          {/* AI Decomposition Legend */}
          <div className="mt-auto pt-3 border-t border-slate-800 space-y-1.5 text-[11px]">
            <div className="font-bold text-slate-200 uppercase">Provenance Categorization Standard:</div>
            <div className="flex justify-between">
              <span className="text-cyan-400 font-bold">[OBSERVED]:</span>
              <span className="text-slate-400">Live System State</span>
            </div>
            <div className="flex justify-between">
              <span className="text-amber-400 font-bold">[CALCULATED]:</span>
              <span className="text-slate-400">Basket & Parity Formulas</span>
            </div>
            <div className="flex justify-between">
              <span className="text-emerald-400 font-bold">[SIMULATED]:</span>
              <span className="text-slate-400">Macro Transmission</span>
            </div>
            <div className="flex justify-between">
              <span className="text-rose-400 font-bold">[SCENARIO]:</span>
              <span className="text-slate-400">Stress Test Shock</span>
            </div>
          </div>
        </div>

        {/* RIGHT: Query Form & Output Panel (8 cols) */}
        <div className="lg:col-span-8 bg-[#0f172a] border border-slate-800 rounded p-4 font-mono text-xs flex flex-col gap-4">
          <form onSubmit={(e) => { e.preventDefault(); handleAskAI(); }} className="flex gap-2">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask Rhino Currency Intelligence..."
              className="flex-1 bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-bold focus:outline-none focus:border-cyan-500"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white font-bold rounded flex items-center gap-1.5 shadow-lg shadow-cyan-950 transition-colors shrink-0"
            >
              {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              <span>ANALYZE</span>
            </button>
          </form>

          {/* Response Output Box */}
          <div className="flex-1 bg-slate-900 border border-slate-800 rounded p-4 overflow-y-auto space-y-3 min-h-[350px]">
            {loading ? (
              <div className="flex items-center justify-center h-full text-slate-400 gap-2 font-mono">
                <Brain className="w-5 h-5 text-cyan-400 animate-pulse" />
                <span>RHINO QUANT AI REASONING IN PROGRESS...</span>
              </div>
            ) : responseAnswer ? (
              <div className="space-y-3 font-mono text-xs leading-relaxed text-slate-100 whitespace-pre-wrap">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-cyan-400 font-bold">
                  <Bot className="w-4 h-4" />
                  RHINO CURRENCY INTELLIGENCE RESPONSE
                </div>
                <div>{responseAnswer}</div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-500 gap-2 text-center">
                <Bot className="w-8 h-8 text-slate-700" />
                <span>Select a prompt from the left or type a custom query to trigger Gemini-powered monetary intelligence analysis.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
