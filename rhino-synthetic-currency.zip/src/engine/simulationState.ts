/**
 * RHINO SYNTHETIC CURRENCY - Simulation State Engine
 * Real-time Causal Economic Simulator, FX Matching Engine & Central Reserve Ledger
 */

import {
  SyntheticCurrency,
  ReserveAsset,
  FXPair,
  Order,
  Trade,
  MacroEconomy,
  YieldPoint,
  OptionQuote,
  PortfolioPosition,
  RiskMetrics,
  LedgerTransaction,
  ScenarioResult,
  BasketComponent
} from '../types/currency.js';

class SimulationStateEngine {
  private currencies: Map<string, SyntheticCurrency> = new Map();
  private reserves: ReserveAsset[] = [];
  private fxPairs: Map<string, FXPair> = new Map();
  private orderBooks: Map<string, { bids: Order[]; asks: Order[] }> = new Map();
  private trades: Trade[] = [];
  private ledger: LedgerTransaction[] = [];
  private macro: Map<string, MacroEconomy> = new Map();
  private portfolio: PortfolioPosition[] = [];
  private currentSimDate: Date = new Date('2026-09-27T08:00:00Z');
  private isSimulating: boolean = false;
  private simSpeed: '1D' | '1M' | '1Y' | '10Y' = '1D';

  constructor() {
    this.seedInitialState();
  }

  private seedInitialState() {
    // 1. Reserve Assets
    this.reserves = [
      {
        asset_id: 'RES-USD-01',
        name: 'US Dollar Cash & Repo',
        symbol: 'USD',
        category: 'FIAT',
        currency: 'USD',
        quantity: 4200000000, // $4.2B
        marketPriceUSD: 1.0,
        totalValueUSD: 4200000000,
        liquidityScore: 100,
        haircut: 0.0,
        duration: 0,
        yield: 4.25,
        custodian: 'Federal Reserve Bank of New York'
      },
      {
        asset_id: 'RES-TREAS-01',
        name: 'US Treasury 2Y-5Y Notes',
        symbol: 'US-T',
        category: 'GOVT_BOND',
        currency: 'USD',
        quantity: 3600000000, // $3.6B
        marketPriceUSD: 1.0,
        totalValueUSD: 3600000000,
        liquidityScore: 98,
        haircut: 2.0,
        duration: 3.2,
        yield: 3.95,
        custodian: 'Bank of New York Mellon'
      },
      {
        asset_id: 'RES-EUR-01',
        name: 'Euro Sovereign Liquidity',
        symbol: 'EUR',
        category: 'FIAT',
        currency: 'EUR',
        quantity: 2100000000, // €2.1B
        marketPriceUSD: 1.085,
        totalValueUSD: 2278500000,
        liquidityScore: 95,
        haircut: 1.5,
        duration: 0.1,
        yield: 3.10,
        custodian: 'Bundesbank / Eurosystem'
      },
      {
        asset_id: 'RES-GBP-01',
        name: 'UK Gilts & Sterling Reserve',
        symbol: 'GBP',
        category: 'GOVT_BOND',
        currency: 'GBP',
        quantity: 1100000000, // £1.1B
        marketPriceUSD: 1.302,
        totalValueUSD: 1432200000,
        liquidityScore: 92,
        haircut: 2.5,
        duration: 4.1,
        yield: 4.15,
        custodian: 'Bank of England Custody'
      },
      {
        asset_id: 'RES-GOLD-01',
        name: 'Allocated Physical Bullion',
        symbol: 'XAU',
        category: 'GOLD',
        currency: 'USD',
        quantity: 500000, // 500,000 oz
        marketPriceUSD: 2650.0,
        totalValueUSD: 1325000000,
        liquidityScore: 90,
        haircut: 5.0,
        duration: 0,
        yield: 0.0,
        custodian: 'HSBC Vaults London'
      }
    ];

    // 2. RGU - Flagship Currency Basket
    const rguBasket: BasketComponent[] = [
      { symbol: 'USD', name: 'US Dollar', category: 'CURRENCY', weight: 35, quantity: 0.38, marketPriceUSD: 1.0, fxRateToUSD: 1.0, contribution: 0.38 },
      { symbol: 'EUR', name: 'Euro', category: 'CURRENCY', weight: 30, quantity: 0.30, marketPriceUSD: 1.085, fxRateToUSD: 1.085, contribution: 0.3255 },
      { symbol: 'GBP', name: 'British Pound', category: 'CURRENCY', weight: 15, quantity: 0.12, marketPriceUSD: 1.302, fxRateToUSD: 1.302, contribution: 0.1562 },
      { symbol: 'JPY', name: 'Japanese Yen', category: 'CURRENCY', weight: 10, quantity: 15.0, marketPriceUSD: 0.0069, fxRateToUSD: 0.0069, contribution: 0.1035 },
      { symbol: 'CNY', name: 'Chinese Yuan', category: 'CURRENCY', weight: 10, quantity: 0.77, marketPriceUSD: 0.142, fxRateToUSD: 0.142, contribution: 0.1093 }
    ];

    const calculateBasketValue = (basket: BasketComponent[]) =>
      basket.reduce((acc, c) => acc + c.quantity * c.marketPriceUSD, 0);

    const rguVal = calculateBasketValue(rguBasket);

    const rgu: SyntheticCurrency = {
      currency_id: 'CUR-RGU-01',
      name: 'Rhino Global Unit',
      code: 'RGU',
      symbol: 'Ϧ',
      issuer: 'Rhino Monetary Authority',
      unit_of_account: 'Synthetic SDR Composite',
      creation_date: '2026-01-15',
      status: 'ACTIVE',
      type: 'CURRENCY_BASKET',
      fx_regime: 'MANAGED_FLOAT',
      initial_supply: 10000000000, // 10B RGU
      circulating_supply: 11900000000, // 11.9B RGU
      total_issued: 12500000000,
      total_redeemed: 600000000,
      locked_reserves: 12835700000, // $12.835B
      unitValueUSD: Number(rguVal.toFixed(4)),
      change24hUSD: 0.32,
      volume24hUSD: 42800000,
      basket: rguBasket,
      monetary_policy: {
        policyRate: 3.75,
        reserveRatioTarget: 105.0,
        inflationTarget: 2.0,
        moneySupplyTargetM2: 25.0,
        assetPurchasesActive: true,
        monthlyPurchaseVolumeUSD: 250,
        fxInterventionThreshold: 2.5,
        version: 4,
        lastUpdated: '2026-09-20'
      },
      money_supply: {
        m0: 11900000000,
        m1: 18400000000,
        m2: 24800000000,
        m3: 31200000000,
        velocity: 1.48,
        creditCreatedMoney: 12900000000,
        digitalBalances: 18400000000,
        totalReserveCoverageRatio: 107.86 // $12.835B / (11.9B * 1.0842)
      },
      governance_model: 'RHINO_MONETARY_AUTHORITY',
      issuance_policy: 'Fully backed by multi-asset reserves + 5% stability buffer',
      redemption_policy: 'Instant T+0 redemption into basket components or USD equivalent',
      versionHistory: [
        { version: 1, timestamp: '2026-01-15', changeNote: 'Initial currency genesis', policyRate: 3.0, basketSummary: '35% USD, 30% EUR, 15% GBP, 10% JPY, 10% CNY' },
        { version: 2, timestamp: '2026-04-10', changeNote: 'Rebalanced JPY and CNY weights', policyRate: 3.25, basketSummary: 'Rebalanced 5% offset' },
        { version: 3, timestamp: '2026-07-01', changeNote: 'Adjusted policy rate to address global yield shift', policyRate: 3.5, basketSummary: 'Maintained basket ratios' },
        { version: 4, timestamp: '2026-09-20', changeNote: 'Increased policy rate to 3.75%', policyRate: 3.75, basketSummary: 'Current production configuration' }
      ]
    };

    // 3. ATU - Atlantic Unit
    const atuBasket: BasketComponent[] = [
      { symbol: 'USD', name: 'US Dollar', category: 'CURRENCY', weight: 35, quantity: 0.35, marketPriceUSD: 1.0, fxRateToUSD: 1.0, contribution: 0.35 },
      { symbol: 'EUR', name: 'Euro', category: 'CURRENCY', weight: 35, quantity: 0.32, marketPriceUSD: 1.085, fxRateToUSD: 1.085, contribution: 0.3472 },
      { symbol: 'GBP', name: 'British Pound', category: 'CURRENCY', weight: 20, quantity: 0.15, marketPriceUSD: 1.302, fxRateToUSD: 1.302, contribution: 0.1953 },
      { symbol: 'CAD', name: 'Canadian Dollar', category: 'CURRENCY', weight: 10, quantity: 0.13, marketPriceUSD: 0.74, fxRateToUSD: 0.74, contribution: 0.0962 }
    ];

    const atu: SyntheticCurrency = {
      currency_id: 'CUR-ATU-02',
      name: 'Atlantic Unit',
      code: 'ATU',
      symbol: 'Ⓐ',
      issuer: 'Atlantic Banking Syndicate',
      unit_of_account: 'North Atlantic Commerce Index',
      creation_date: '2026-02-01',
      status: 'ACTIVE',
      type: 'CURRENCY_BASKET',
      fx_regime: 'CRAWLING_PEG',
      initial_supply: 5000000000,
      circulating_supply: 5800000000,
      total_issued: 6000000000,
      total_redeemed: 200000000,
      locked_reserves: 5735000000,
      unitValueUSD: Number(calculateBasketValue(atuBasket).toFixed(4)),
      change24hUSD: -0.12,
      volume24hUSD: 18500000,
      basket: atuBasket,
      monetary_policy: {
        policyRate: 3.5,
        reserveRatioTarget: 100.0,
        inflationTarget: 2.2,
        moneySupplyTargetM2: 12.0,
        assetPurchasesActive: false,
        monthlyPurchaseVolumeUSD: 0,
        fxInterventionThreshold: 2.0,
        version: 2,
        lastUpdated: '2026-08-15'
      },
      money_supply: {
        m0: 5800000000,
        m1: 8900000000,
        m2: 11800000000,
        m3: 14200000000,
        velocity: 1.35,
        creditCreatedMoney: 6000000000,
        digitalBalances: 8900000000,
        totalReserveCoverageRatio: 100.1
      },
      governance_model: 'DISCRETIONARY_COMMITTEE',
      issuance_policy: '100% reserve backed by transatlantic liquid paper',
      redemption_policy: 'T+1 settlement via correspondent network',
      versionHistory: [
        { version: 1, timestamp: '2026-02-01', changeNote: 'Genesis release', policyRate: 3.25, basketSummary: 'Transatlantic composition' },
        { version: 2, timestamp: '2026-08-15', changeNote: 'Policy rate alignment', policyRate: 3.5, basketSummary: 'Current configuration' }
      ]
    };

    // 4. ENU - Energy Unit (Commodity Backed)
    const enuBasket: BasketComponent[] = [
      { symbol: 'OIL', name: 'Brent Crude Oil (bbl)', category: 'COMMODITY', weight: 40, quantity: 0.012, marketPriceUSD: 78.5, fxRateToUSD: 1.0, contribution: 0.942 },
      { symbol: 'GAS', name: 'Henry Hub NatGas (MMBtu)', category: 'COMMODITY', weight: 25, quantity: 0.22, marketPriceUSD: 2.85, fxRateToUSD: 1.0, contribution: 0.627 },
      { symbol: 'GOLD', name: 'Physical Gold (oz)', category: 'COMMODITY', weight: 20, quantity: 0.00018, marketPriceUSD: 2650.0, fxRateToUSD: 1.0, contribution: 0.477 },
      { symbol: 'COPPER', name: 'LME Copper (lb)', category: 'COMMODITY', weight: 15, quantity: 0.085, marketPriceUSD: 4.35, fxRateToUSD: 1.0, contribution: 0.3698 }
    ];

    const enu: SyntheticCurrency = {
      currency_id: 'CUR-ENU-03',
      name: 'Energy & Commodities Unit',
      code: 'ENU',
      symbol: '⚡',
      issuer: 'Rhino Global Resource Issuer',
      unit_of_account: 'Physical Resource Basket',
      creation_date: '2026-03-10',
      status: 'ACTIVE',
      type: 'COMMODITY_BASKET',
      fx_regime: 'FREE_FLOAT',
      initial_supply: 2000000000,
      circulating_supply: 2400000000,
      total_issued: 2500000000,
      total_redeemed: 100000000,
      locked_reserves: 5800000000,
      unitValueUSD: Number(calculateBasketValue(enuBasket).toFixed(4)),
      change24hUSD: 1.45,
      volume24hUSD: 29400000,
      basket: enuBasket,
      monetary_policy: {
        policyRate: 4.25,
        reserveRatioTarget: 110.0,
        inflationTarget: 3.0,
        moneySupplyTargetM2: 6.5,
        assetPurchasesActive: true,
        monthlyPurchaseVolumeUSD: 100,
        fxInterventionThreshold: 4.0,
        version: 1,
        lastUpdated: '2026-03-10'
      },
      money_supply: {
        m0: 2400000000,
        m1: 3600000000,
        m2: 5800000000,
        m3: 7200000000,
        velocity: 1.62,
        creditCreatedMoney: 3400000000,
        digitalBalances: 3600000000,
        totalReserveCoverageRatio: 100.0
      },
      governance_model: 'RHINO_MONETARY_AUTHORITY',
      issuance_policy: 'Physical warehouse receipts and futures collateral',
      redemption_policy: 'Physical delivery or cash settlement',
      versionHistory: [
        { version: 1, timestamp: '2026-03-10', changeNote: 'Commodity unit launch', policyRate: 4.25, basketSummary: 'Oil, Gas, Gold, Copper' }
      ]
    };

    this.currencies.set(rgu.currency_id, rgu);
    this.currencies.set(atu.currency_id, atu);
    this.currencies.set(enu.currency_id, enu);

    // 5. Seed FX Pairs
    const pairs: FXPair[] = [
      { pair_id: 'RGU/USD', baseCurrency: 'RGU', quoteCurrency: 'USD', lastPrice: 1.0842, bid: 1.0841, ask: 1.0843, high24h: 1.0890, low24h: 1.0810, volume24h: 42800000, change24h: 0.32, impliedVolatility30d: 6.8 },
      { pair_id: 'RGU/EUR', baseCurrency: 'RGU', quoteCurrency: 'EUR', lastPrice: 0.9993, bid: 0.9992, ask: 0.9994, high24h: 1.0020, low24h: 0.9960, volume24h: 31200000, change24h: 0.15, impliedVolatility30d: 5.4 },
      { pair_id: 'RGU/GBP', baseCurrency: 'RGU', quoteCurrency: 'GBP', lastPrice: 0.8327, bid: 0.8326, ask: 0.8328, high24h: 0.8360, low24h: 0.8300, volume24h: 24100000, change24h: -0.08, impliedVolatility30d: 6.1 },
      { pair_id: 'RGU/JPY', baseCurrency: 'RGU', quoteCurrency: 'JPY', lastPrice: 157.13, bid: 157.10, ask: 157.16, high24h: 158.20, low24h: 156.40, volume24h: 19500000, change24h: 0.65, impliedVolatility30d: 8.2 },
      { pair_id: 'RGU/CNY', baseCurrency: 'RGU', quoteCurrency: 'CNY', lastPrice: 7.635, bid: 7.634, ask: 7.636, high24h: 7.670, low24h: 7.610, volume24h: 14200000, change24h: 0.22, impliedVolatility30d: 4.9 },
      { pair_id: 'ATU/USD', baseCurrency: 'ATU', quoteCurrency: 'USD', lastPrice: 0.9887, bid: 0.9886, ask: 0.9888, high24h: 0.9920, low24h: 0.9850, volume24h: 18500000, change24h: -0.12, impliedVolatility30d: 7.1 },
      { pair_id: 'ENU/USD', baseCurrency: 'ENU', quoteCurrency: 'USD', lastPrice: 2.4158, bid: 2.4152, ask: 2.4164, high24h: 2.4500, low24h: 2.3800, volume24h: 29400000, change24h: 1.45, impliedVolatility30d: 14.5 }
    ];

    pairs.forEach((p) => {
      this.fxPairs.set(p.pair_id, p);
      // Seed matching engine orderbook
      const bids: Order[] = [
        { order_id: `BID-${p.pair_id}-1`, pair_id: p.pair_id, trader: 'Barclays Institutional', side: 'BUY', type: 'LIMIT', price: Number((p.bid).toFixed(4)), amount: 5000000, filled: 0, status: 'OPEN', timestamp: new Date().toISOString() },
        { order_id: `BID-${p.pair_id}-2`, pair_id: p.pair_id, trader: 'BNP Paribas Quant Desk', side: 'BUY', type: 'LIMIT', price: Number((p.bid - 0.0005).toFixed(4)), amount: 12000000, filled: 0, status: 'OPEN', timestamp: new Date().toISOString() },
        { order_id: `BID-${p.pair_id}-3`, pair_id: p.pair_id, trader: 'JPMorgan FX Market Maker', side: 'BUY', type: 'LIMIT', price: Number((p.bid - 0.0010).toFixed(4)), amount: 25000000, filled: 0, status: 'OPEN', timestamp: new Date().toISOString() }
      ];
      const asks: Order[] = [
        { order_id: `ASK-${p.pair_id}-1`, pair_id: p.pair_id, trader: 'Citigroup Treasury', side: 'SELL', type: 'LIMIT', price: Number((p.ask).toFixed(4)), amount: 4500000, filled: 0, status: 'OPEN', timestamp: new Date().toISOString() },
        { order_id: `ASK-${p.pair_id}-2`, pair_id: p.pair_id, trader: 'Goldman Sachs Asset Management', side: 'SELL', type: 'LIMIT', price: Number((p.ask + 0.0005).toFixed(4)), amount: 15000000, filled: 0, status: 'OPEN', timestamp: new Date().toISOString() },
        { order_id: `ASK-${p.pair_id}-3`, pair_id: p.pair_id, trader: 'UBS Sovereign Fund', side: 'SELL', type: 'LIMIT', price: Number((p.ask + 0.0012).toFixed(4)), amount: 20000000, filled: 0, status: 'OPEN', timestamp: new Date().toISOString() }
      ];
      this.orderBooks.set(p.pair_id, { bids, asks });
    });

    // 6. Macro Digital Twin
    const rguMacro: MacroEconomy = {
      currencyCode: 'RGU',
      population: 250.0, // 250 Million
      nominalGDPUSD: 12450.0, // $12.45 Trillion synthetic economy
      realGDPGrowthPct: 2.15,
      cpiHeadlinePct: 2.40,
      cpiCorePct: 2.10,
      ppiPct: 1.85,
      unemploymentRatePct: 4.10,
      wageGrowthPct: 3.40,
      consumptionBlnUSD: 7800.0,
      investmentBlnUSD: 2450.0,
      exportsBlnUSD: 1800.0,
      importsBlnUSD: 1600.0,
      currentAccountBlnUSD: 200.0,
      creditGrowthPct: 4.80,
      bankingSystemAssetsUSD: 18200.0,
      numberOfBanks: 20,
      numberOfCorporates: 5000,
      numberOfHouseholds: 5000000
    };
    this.macro.set('RGU', rguMacro);

    // 7. Initial Portfolio Positions
    this.portfolio = [
      {
        position_id: 'POS-01',
        instrument: 'SPOT',
        symbol: 'RGU/USD',
        currency: 'RGU',
        notionalUSD: 500000000, // $500M Long Spot
        direction: 'LONG',
        entryPrice: 1.0810,
        currentPrice: 1.0842,
        unrealizedPnLUSD: 1480000,
        realizedPnLUSD: 320000,
        deltaUSD: 500000000,
        vegaUSD: 0,
        carryAnnualUSD: 18750000
      },
      {
        position_id: 'POS-02',
        instrument: 'FORWARD',
        symbol: 'RGU/EUR 3M FWD',
        currency: 'EUR',
        notionalUSD: 250000000,
        direction: 'SHORT',
        entryPrice: 1.0010,
        currentPrice: 0.9993,
        unrealizedPnLUSD: 425000,
        realizedPnLUSD: 0,
        deltaUSD: -250000000,
        vegaUSD: 0,
        carryAnnualUSD: -1625000
      },
      {
        position_id: 'POS-03',
        instrument: 'OPTION',
        symbol: 'RGU Call Strike 1.10 3M',
        currency: 'USD',
        notionalUSD: 100000000,
        direction: 'LONG',
        entryPrice: 0.012,
        currentPrice: 0.015,
        unrealizedPnLUSD: 300000,
        realizedPnLUSD: 0,
        deltaUSD: 42000000,
        vegaUSD: 185000,
        carryAnnualUSD: -240000
      }
    ];

    // 8. Initial Ledger Transactions
    this.ledger = [
      {
        tx_id: 'TX-2026-9081',
        currencyCode: 'RGU',
        type: 'ISSUANCE',
        sender: 'Rhino Reserve Vault',
        receiver: 'Barclays Capital Primary Dealer',
        amount: 250000000,
        fxRateToUSD: 1.0842,
        valueUSD: 271050000,
        feeUSD: 25000,
        status: 'SETTLED',
        timestamp: '2026-09-27T06:15:00Z',
        auditHash: '0x8f92a1c039b4f218e819a'
      },
      {
        tx_id: 'TX-2026-9082',
        currencyCode: 'RGU',
        type: 'FX_INTERVENTION',
        sender: 'Rhino Monetary Authority FX Desk',
        receiver: 'Open FX Market',
        amount: 100000000,
        fxRateToUSD: 1.0840,
        valueUSD: 108400000,
        feeUSD: 0,
        status: 'SETTLED',
        timestamp: '2026-09-27T07:30:00Z',
        auditHash: '0x1b44c82e00aef12d8a'
      }
    ];
  }

  // --- GETTERS ---
  public getCurrencies(): SyntheticCurrency[] {
    return Array.from(this.currencies.values());
  }

  public getCurrency(codeOrId: string): SyntheticCurrency | undefined {
    for (const curr of this.currencies.values()) {
      if (curr.code === codeOrId || curr.currency_id === codeOrId) return curr;
    }
    return undefined;
  }

  public getReserves(): ReserveAsset[] {
    return this.reserves;
  }

  public getFXPairs(): FXPair[] {
    return Array.from(this.fxPairs.values());
  }

  public getOrderBook(pair_id: string) {
    return this.orderBooks.get(pair_id) || { bids: [], asks: [] };
  }

  public getTrades(): Trade[] {
    return this.trades;
  }

  public getMacro(currencyCode: string = 'RGU'): MacroEconomy | undefined {
    return this.macro.get(currencyCode);
  }

  public getPortfolio(): PortfolioPosition[] {
    return this.portfolio;
  }

  public getLedger(): LedgerTransaction[] {
    return this.ledger;
  }

  // --- ACTIONS ---

  // 1. Create New Synthetic Currency
  public createCurrency(config: Partial<SyntheticCurrency>): SyntheticCurrency {
    const code = (config.code || 'NSC').toUpperCase();
    const currency_id = `CUR-${code}-${Date.now().toString().slice(-4)}`;
    
    const basket: BasketComponent[] = config.basket || [
      { symbol: 'USD', name: 'US Dollar', category: 'CURRENCY', weight: 50, quantity: 0.5, marketPriceUSD: 1.0, fxRateToUSD: 1.0, contribution: 0.5 },
      { symbol: 'EUR', name: 'Euro', category: 'CURRENCY', weight: 50, quantity: 0.46, marketPriceUSD: 1.085, fxRateToUSD: 1.085, contribution: 0.5 }
    ];

    const calculateBasketValue = (b: BasketComponent[]) =>
      b.reduce((acc, c) => acc + c.quantity * c.marketPriceUSD, 0);

    const unitVal = calculateBasketValue(basket);

    const newCurrency: SyntheticCurrency = {
      currency_id,
      name: config.name || `${code} Synthetic Unit`,
      code,
      symbol: config.symbol || '§',
      issuer: config.issuer || 'Rhino Bank Issuer',
      unit_of_account: config.unit_of_account || 'Custom Synthetic Unit',
      creation_date: new Date().toISOString().split('T')[0],
      status: 'ACTIVE',
      type: config.type || 'CURRENCY_BASKET',
      fx_regime: config.fx_regime || 'MANAGED_FLOAT',
      initial_supply: config.initial_supply || 1000000000,
      circulating_supply: config.initial_supply || 1000000000,
      total_issued: config.initial_supply || 1000000000,
      total_redeemed: 0,
      locked_reserves: (config.initial_supply || 1000000000) * unitVal * 1.05,
      unitValueUSD: Number(unitVal.toFixed(4)),
      change24hUSD: 0.0,
      volume24hUSD: 5000000,
      basket,
      monetary_policy: config.monetary_policy || {
        policyRate: 3.5,
        reserveRatioTarget: 100.0,
        inflationTarget: 2.0,
        moneySupplyTargetM2: 5.0,
        assetPurchasesActive: false,
        monthlyPurchaseVolumeUSD: 0,
        fxInterventionThreshold: 2.0,
        version: 1,
        lastUpdated: new Date().toISOString().split('T')[0]
      },
      money_supply: config.money_supply || {
        m0: config.initial_supply || 1000000000,
        m1: (config.initial_supply || 1000000000) * 1.5,
        m2: (config.initial_supply || 1000000000) * 2.2,
        m3: (config.initial_supply || 1000000000) * 2.8,
        velocity: 1.4,
        creditCreatedMoney: (config.initial_supply || 1000000000) * 1.2,
        digitalBalances: (config.initial_supply || 1000000000) * 1.5,
        totalReserveCoverageRatio: 105.0
      },
      governance_model: config.governance_model || 'RHINO_MONETARY_AUTHORITY',
      issuance_policy: config.issuance_policy || 'Collateralized reserve backed',
      redemption_policy: config.redemption_policy || 'Direct reserve redemption',
      versionHistory: [
        {
          version: 1,
          timestamp: new Date().toISOString().split('T')[0],
          changeNote: 'Currency Creation Genesis',
          policyRate: config.monetary_policy?.policyRate || 3.5,
          basketSummary: `${basket.map((b) => `${b.weight}% ${b.symbol}`).join(', ')}`
        }
      ]
    };

    this.currencies.set(currency_id, newCurrency);

    // Create FX pair vs USD
    const pair_id = `${code}/USD`;
    const pair: FXPair = {
      pair_id,
      baseCurrency: code,
      quoteCurrency: 'USD',
      lastPrice: newCurrency.unitValueUSD,
      bid: Number((newCurrency.unitValueUSD - 0.0001).toFixed(4)),
      ask: Number((newCurrency.unitValueUSD + 0.0001).toFixed(4)),
      high24h: newCurrency.unitValueUSD * 1.01,
      low24h: newCurrency.unitValueUSD * 0.99,
      volume24h: 5000000,
      change24h: 0.0,
      impliedVolatility30d: 6.0
    };
    this.fxPairs.set(pair_id, pair);
    this.orderBooks.set(pair_id, { bids: [], asks: [] });

    // Record in ledger
    this.ledger.push({
      tx_id: `TX-${Date.now()}`,
      currencyCode: code,
      type: 'ISSUANCE',
      sender: 'Rhino Reserve Foundry',
      receiver: 'Initial Vault Circulation',
      amount: newCurrency.initial_supply,
      fxRateToUSD: newCurrency.unitValueUSD,
      valueUSD: newCurrency.initial_supply * newCurrency.unitValueUSD,
      feeUSD: 0,
      status: 'SETTLED',
      timestamp: new Date().toISOString(),
      auditHash: `0x${Math.random().toString(16).substring(2, 14)}`
    });

    return newCurrency;
  }

  // 2. Issuance / Mint Engine
  public issueCurrency(code: string, amount: number, receiver: string): { success: boolean; message: string; tx?: LedgerTransaction } {
    const currency = this.getCurrency(code);
    if (!currency) return { success: false, message: `Currency ${code} not found.` };

    const requiredReservesUSD = amount * currency.unitValueUSD * (currency.monetary_policy.reserveRatioTarget / 100);
    const totalCurrentReservesUSD = this.reserves.reduce((acc, r) => acc + r.totalValueUSD, 0);

    if (totalCurrentReservesUSD < requiredReservesUSD) {
      return {
        success: false,
        message: `Insufficient reserve collateral. Required: $${(requiredReservesUSD / 1e6).toFixed(2)}M, Available: $${(totalCurrentReservesUSD / 1e6).toFixed(2)}M`
      };
    }

    // Mint
    currency.circulating_supply += amount;
    currency.total_issued += amount;
    currency.money_supply.m0 += amount;
    currency.money_supply.m1 += amount * 1.4;
    currency.money_supply.m2 += amount * 2.0;

    const tx: LedgerTransaction = {
      tx_id: `TX-MINT-${Date.now().toString().slice(-6)}`,
      currencyCode: code,
      type: 'ISSUANCE',
      sender: 'Rhino Monetary Authority Vault',
      receiver,
      amount,
      fxRateToUSD: currency.unitValueUSD,
      valueUSD: amount * currency.unitValueUSD,
      feeUSD: Number((amount * currency.unitValueUSD * 0.0001).toFixed(2)),
      status: 'SETTLED',
      timestamp: new Date().toISOString(),
      auditHash: `0x${Math.random().toString(16).substring(2, 14)}`
    };

    this.ledger.unshift(tx);
    return { success: true, message: `Successfully issued ${amount.toLocaleString()} ${code} to ${receiver}.`, tx };
  }

  // 3. Redemption Engine
  public redeemCurrency(code: string, amount: number, sender: string): { success: boolean; message: string; tx?: LedgerTransaction } {
    const currency = this.getCurrency(code);
    if (!currency) return { success: false, message: `Currency ${code} not found.` };

    if (currency.circulating_supply < amount) {
      return { success: false, message: `Redemption amount exceeds total circulating supply.` };
    }

    currency.circulating_supply -= amount;
    currency.total_redeemed += amount;
    currency.money_supply.m0 -= amount;

    const tx: LedgerTransaction = {
      tx_id: `TX-RED-${Date.now().toString().slice(-6)}`,
      currencyCode: code,
      type: 'REDEMPTION',
      sender,
      receiver: 'Rhino Reserve Vault (Burn)',
      amount,
      fxRateToUSD: currency.unitValueUSD,
      valueUSD: amount * currency.unitValueUSD,
      feeUSD: Number((amount * currency.unitValueUSD * 0.0001).toFixed(2)),
      status: 'SETTLED',
      timestamp: new Date().toISOString(),
      auditHash: `0x${Math.random().toString(16).substring(2, 14)}`
    };

    this.ledger.unshift(tx);
    return { success: true, message: `Successfully redeemed and burned ${amount.toLocaleString()} ${code}.`, tx };
  }

  // 4. Update Monetary Policy
  public updateMonetaryPolicy(code: string, updates: Partial<SyntheticCurrency['monetary_policy']>): SyntheticCurrency | undefined {
    const currency = this.getCurrency(code);
    if (!currency) return undefined;

    const oldRate = currency.monetary_policy.policyRate;
    currency.monetary_policy = {
      ...currency.monetary_policy,
      ...updates,
      version: currency.monetary_policy.version + 1,
      lastUpdated: new Date().toISOString().split('T')[0]
    };

    // Propagate causal effect to Macro digital twin!
    const macro = this.macro.get(code) || this.macro.get('RGU');
    if (macro && updates.policyRate !== undefined) {
      const deltaRate = updates.policyRate - oldRate; // e.g. +0.50
      // Higher policy rate -> lowers credit growth, slows GDP, dampens inflation, appreciates currency
      macro.creditGrowthPct = Math.max(0.5, Number((macro.creditGrowthPct - deltaRate * 0.8).toFixed(2)));
      macro.cpiHeadlinePct = Math.max(0.1, Number((macro.cpiHeadlinePct - deltaRate * 0.4).toFixed(2)));
      macro.realGDPGrowthPct = Number((macro.realGDPGrowthPct - deltaRate * 0.25).toFixed(2));
      
      // FX appreciation effect
      currency.change24hUSD += deltaRate * 0.4;
      currency.unitValueUSD = Number((currency.unitValueUSD * (1 + deltaRate * 0.005)).toFixed(4));
    }

    currency.versionHistory.unshift({
      version: currency.monetary_policy.version,
      timestamp: new Date().toISOString().split('T')[0],
      changeNote: `Policy rate set to ${currency.monetary_policy.policyRate}%, Reserve target ${currency.monetary_policy.reserveRatioTarget}%`,
      policyRate: currency.monetary_policy.policyRate,
      basketSummary: `${currency.basket.map((b) => `${b.weight}% ${b.symbol}`).join(', ')}`
    });

    return currency;
  }

  // 5. FX Order Matching Engine
  public submitOrder(orderReq: Omit<Order, 'order_id' | 'filled' | 'status' | 'timestamp'>): { success: boolean; order: Order; tradesExecuted: Trade[] } {
    const pair = this.fxPairs.get(orderReq.pair_id);
    if (!pair) throw new Error(`FX Pair ${orderReq.pair_id} not found.`);

    const ob = this.orderBooks.get(orderReq.pair_id) || { bids: [], asks: [] };
    const order: Order = {
      ...orderReq,
      order_id: `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      filled: 0,
      status: 'OPEN',
      timestamp: new Date().toISOString()
    };

    const tradesExecuted: Trade[] = [];

    if (order.side === 'BUY') {
      // Match against asks
      ob.asks.sort((a, b) => a.price - b.price);
      let remaining = order.amount;

      for (const ask of ob.asks) {
        if (ask.status !== 'OPEN') continue;
        if (order.type === 'LIMIT' && ask.price > order.price) break;

        const tradeAmount = Math.min(remaining, ask.amount - ask.filled);
        if (tradeAmount <= 0) continue;

        ask.filled += tradeAmount;
        remaining -= tradeAmount;
        if (ask.filled >= ask.amount) ask.status = 'FILLED';

        const trade: Trade = {
          trade_id: `TRD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          pair_id: order.pair_id,
          price: ask.price,
          amount: tradeAmount,
          side: 'BUY',
          buyer: order.trader,
          seller: ask.trader,
          timestamp: new Date().toISOString()
        };
        tradesExecuted.push(trade);
        this.trades.unshift(trade);
        pair.lastPrice = ask.price;

        if (remaining <= 0) break;
      }

      order.filled = order.amount - remaining;
      if (order.filled >= order.amount) {
        order.status = 'FILLED';
      } else {
        if (order.type !== 'IOC' && order.type !== 'FOK') {
          ob.bids.push(order);
          ob.bids.sort((a, b) => b.price - a.price);
        } else {
          order.status = 'CANCELLED';
        }
      }
    } else {
      // SELL: Match against bids
      ob.bids.sort((a, b) => b.price - a.price);
      let remaining = order.amount;

      for (const bid of ob.bids) {
        if (bid.status !== 'OPEN') continue;
        if (order.type === 'LIMIT' && bid.price < order.price) break;

        const tradeAmount = Math.min(remaining, bid.amount - bid.filled);
        if (tradeAmount <= 0) continue;

        bid.filled += tradeAmount;
        remaining -= tradeAmount;
        if (bid.filled >= bid.amount) bid.status = 'FILLED';

        const trade: Trade = {
          trade_id: `TRD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          pair_id: order.pair_id,
          price: bid.price,
          amount: tradeAmount,
          side: 'SELL',
          buyer: bid.trader,
          seller: order.trader,
          timestamp: new Date().toISOString()
        };
        tradesExecuted.push(trade);
        this.trades.unshift(trade);
        pair.lastPrice = bid.price;

        if (remaining <= 0) break;
      }

      order.filled = order.amount - remaining;
      if (order.filled >= order.amount) {
        order.status = 'FILLED';
      } else {
        if (order.type !== 'IOC' && order.type !== 'FOK') {
          ob.asks.push(order);
          ob.asks.sort((a, b) => a.price - b.price);
        } else {
          order.status = 'CANCELLED';
        }
      }
    }

    // Update pair bid/ask
    if (ob.bids.length > 0) pair.bid = ob.bids[0].price;
    if (ob.asks.length > 0) pair.ask = ob.asks[0].price;

    return { success: true, order, tradesExecuted };
  }

  // 6. Run Scenario Shock Engine
  public runScenario(scenarioKey: 'RATE_SHOCK_200BP' | 'USD_DROP_10PCT' | 'BANK_RUN' | 'COMMODITY_CRISIS'): ScenarioResult {
    const rgu = this.getCurrency('RGU')!;
    const macro = this.macro.get('RGU')!;

    switch (scenarioKey) {
      case 'RATE_SHOCK_200BP':
        return {
          scenarioName: 'Policy Rate Hike +200 BP (3.75% -> 5.75%)',
          shocks: ['Policy Rate +200bp', 'Credit contraction -3.2%', 'Inflation drop -0.8%'],
          impactOnReserveValuePct: +0.45,
          impactOnCurrencyPricePct: +1.85,
          impactOnCoverageRatio: 109.8,
          impactOnGDPPct: -0.65,
          impactOnInflationPct: -0.80,
          recommendedAction: 'Engage liquidity provision in money markets to prevent bank funding squeeze.'
        };
      case 'USD_DROP_10PCT':
        return {
          scenarioName: 'USD Devaluation / Sharp Depreciation (-10%)',
          shocks: ['USD Index -10.0%', 'EUR +8.2%', 'GBP +6.5%', 'Gold +14.0%'],
          impactOnReserveValuePct: -3.80,
          impactOnCurrencyPricePct: -2.10,
          impactOnCoverageRatio: 102.4,
          impactOnGDPPct: +0.40,
          impactOnInflationPct: +1.20,
          recommendedAction: 'Rebalance reserve basket by increasing physical gold and EUR sovereign bonds.'
        };
      case 'BANK_RUN':
        return {
          scenarioName: 'Severe Banking Crisis & Reserve Flight',
          shocks: ['M2 Velocity collapse -0.35', 'Deposit outflow 15%', 'Liquidity Haircuts +10%'],
          impactOnReserveValuePct: -8.50,
          impactOnCurrencyPricePct: -4.20,
          impactOnCoverageRatio: 96.5,
          impactOnGDPPct: -2.10,
          impactOnInflationPct: -1.50,
          recommendedAction: 'Activate Emergency Central Bank Repo Window & Suspend uncollateralized redemptions.'
        };
      case 'COMMODITY_CRISIS':
        return {
          scenarioName: 'Global Commodity & Energy Supply Shock',
          shocks: ['Oil +45%', 'NatGas +60%', 'Wheat +30%', 'PPI Inflation +5.2%'],
          impactOnReserveValuePct: +6.20,
          impactOnCurrencyPricePct: +3.40,
          impactOnCoverageRatio: 114.2,
          impactOnGDPPct: -1.10,
          impactOnInflationPct: +3.80,
          recommendedAction: 'Sterilize commodity export inflows to prevent domestic currency over-appreciation.'
        };
    }
  }

  // 7. Calculate Portfolio & Risk Metrics (RhinoQuant Engine)
  public getRiskMetrics(): RiskMetrics {
    const rgu = this.getCurrency('RGU')!;
    const totalVal = 12835700000;
    const netFx = 1500000000;

    return {
      totalPortfolioValueUSD: totalVal,
      netFXExposureUSD: netFx,
      dailyPnLUSD: 14200000,
      var95_1D: 84500000, // $84.5M 95% 1-day VaR
      var99_1D: 128200000, // $128.2M 99% 1-day VaR
      expectedShortfall99: 154000000,
      maxDrawdownPct: 2.85,
      factorBetas: {
        usdIndex: 0.38,
        eurIndex: 0.28,
        ratesGlobal: -0.15,
        commodities: 0.12,
        growthGlobal: 0.45,
        inflation: -0.22,
        riskSentiment: 0.18
      }
    };
  }

  // 8. Causal Simulation Step Tick
  public tickSimulation(days: number = 1) {
    const noise = () => (Math.random() - 0.5) * 0.002;
    
    this.fxPairs.forEach((pair) => {
      const delta = noise();
      pair.lastPrice = Number((pair.lastPrice * (1 + delta)).toFixed(4));
      pair.bid = Number((pair.lastPrice - 0.0001).toFixed(4));
      pair.ask = Number((pair.lastPrice + 0.0001).toFixed(4));
      pair.change24h = Number((pair.change24h + delta * 100).toFixed(2));
      pair.volume24h += Math.floor(Math.random() * 500000);
    });

    this.currencies.forEach((c) => {
      // Re-evaluate basket value
      const bVal = c.basket.reduce((acc, comp) => {
        comp.marketPriceUSD *= (1 + noise());
        comp.contribution = comp.quantity * comp.marketPriceUSD;
        return acc + comp.contribution;
      }, 0);

      c.unitValueUSD = Number(bVal.toFixed(4));
      // Recheck reserve coverage
      c.money_supply.totalReserveCoverageRatio = Number((c.locked_reserves / (c.circulating_supply * c.unitValueUSD) * 100).toFixed(2));
    });
  }
}

export const simEngine = new SimulationStateEngine();
