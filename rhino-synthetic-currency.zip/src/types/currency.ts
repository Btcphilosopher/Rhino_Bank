/**
 * RHINO SYNTHETIC CURRENCY - Type Definitions
 * Institutional Synthetic Currency Creation, Issuance, Valuation, Trading & Settlement System
 */

export type CurrencyType =
  | 'FIAT_INDEXED'
  | 'CURRENCY_BASKET'
  | 'COMMODITY_BASKET'
  | 'REAL_ASSET_INDEX'
  | 'GDP_WEIGHTED'
  | 'STABILITY_UNIT'
  | 'FREE_FLOAT';

export type FXRegime =
  | 'PEGGED'
  | 'CRAWLING_PEG'
  | 'MANAGED_FLOAT'
  | 'FREE_FLOAT'
  | 'ALGORITHMIC_STABILITY';

export type GovernanceModel =
  | 'RHINO_MONETARY_AUTHORITY'
  | 'ALGORITHMIC_DAO'
  | 'BOARD_OF_GOVERNORS'
  | 'DISCRETIONARY_COMMITTEE';

export interface BasketComponent {
  symbol: string;
  name: string;
  category: 'CURRENCY' | 'COMMODITY' | 'ASSET' | 'EQUITY';
  weight: number; // percentage, e.g. 35 = 35%
  quantity: number;
  marketPriceUSD: number;
  fxRateToUSD: number;
  contribution: number; // calculated USD value contribution
}

export interface MonetaryPolicy {
  policyRate: number; // e.g., 3.75%
  reserveRatioTarget: number; // e.g., 100% or 105%
  inflationTarget: number; // e.g., 2.0%
  moneySupplyTargetM2: number; // e.g., in Billions USD
  assetPurchasesActive: boolean; // QE / QT
  monthlyPurchaseVolumeUSD: number; // In Millions
  fxInterventionThreshold: number; // percentage deviation from basket model value
  version: number;
  lastUpdated: string;
}

export interface MoneySupply {
  m0: number; // Base money (physical + central bank reserves)
  m1: number; // Currency + Demand deposits
  m2: number; // M1 + Savings + Money market funds
  m3: number; // M2 + Institutional deposits + Repo balances
  velocity: number; // V = Nominal GDP / M2
  creditCreatedMoney: number;
  digitalBalances: number;
  totalReserveCoverageRatio: number; // Reserve Value / M0 Issued (%)
}

export interface SyntheticCurrency {
  currency_id: string;
  name: string;
  code: string;
  symbol: string;
  issuer: string;
  unit_of_account: string;
  creation_date: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'DEVELOPMENT';
  type: CurrencyType;
  fx_regime: FXRegime;
  initial_supply: number;
  circulating_supply: number;
  total_issued: number;
  total_redeemed: number;
  locked_reserves: number;
  unitValueUSD: number; // Current calculated market/basket value in USD
  change24hUSD: number; // percentage change
  volume24hUSD: number;
  basket: BasketComponent[];
  monetary_policy: MonetaryPolicy;
  money_supply: MoneySupply;
  governance_model: GovernanceModel;
  issuance_policy: string;
  redemption_policy: string;
  versionHistory: {
    version: number;
    timestamp: string;
    changeNote: string;
    policyRate: number;
    basketSummary: string;
  }[];
}

export interface ReserveAsset {
  asset_id: string;
  name: string;
  symbol: string;
  category: 'FIAT' | 'GOVT_BOND' | 'GOLD' | 'COMMODITY' | 'CASH_EQUIVALENT';
  currency: string;
  quantity: number;
  marketPriceUSD: number;
  totalValueUSD: number;
  liquidityScore: number; // 1-100
  haircut: number; // % haircut applied for stress
  duration: number; // years for bonds
  yield: number; // % annual yield
  custodian: string;
}

export interface FXPair {
  pair_id: string;
  baseCurrency: string; // e.g., RGU
  quoteCurrency: string; // e.g., USD
  lastPrice: number;
  bid: number;
  ask: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  change24h: number;
  impliedVolatility30d: number;
}

export type OrderType = 'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT' | 'IOC' | 'FOK';
export type OrderSide = 'BUY' | 'SELL';

export interface Order {
  order_id: string;
  pair_id: string;
  trader: string;
  side: OrderSide;
  type: OrderType;
  price: number;
  amount: number;
  filled: number;
  status: 'OPEN' | 'FILLED' | 'PARTIAL' | 'CANCELLED';
  timestamp: string;
}

export interface Trade {
  trade_id: string;
  pair_id: string;
  price: number;
  amount: number;
  side: OrderSide;
  buyer: string;
  seller: string;
  timestamp: string;
}

export interface YieldPoint {
  tenor: '1D' | '1W' | '1M' | '3M' | '6M' | '1Y' | '2Y' | '5Y' | '10Y';
  rate: number; // % p.a.
  forwardRate: number;
  carryBp: number;
  basisBp: number;
}

export interface OptionQuote {
  strike: number;
  expiry: string; // '1W', '1M', '3M', '6M', '1Y'
  callPrice: number;
  putPrice: number;
  impliedVol: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
}

export interface MacroEconomy {
  currencyCode: string;
  population: number; // Millions
  nominalGDPUSD: number; // Billions USD
  realGDPGrowthPct: number;
  cpiHeadlinePct: number;
  cpiCorePct: number;
  ppiPct: number;
  unemploymentRatePct: number;
  wageGrowthPct: number;
  consumptionBlnUSD: number;
  investmentBlnUSD: number;
  exportsBlnUSD: number;
  importsBlnUSD: number;
  currentAccountBlnUSD: number;
  creditGrowthPct: number;
  bankingSystemAssetsUSD: number; // Billions
  numberOfBanks: number;
  numberOfCorporates: number;
  numberOfHouseholds: number;
}

export interface PortfolioPosition {
  position_id: string;
  instrument: 'SPOT' | 'FORWARD' | 'FUTURES' | 'OPTION' | 'SWAP' | 'BOND' | 'RESERVES';
  symbol: string;
  currency: string;
  notionalUSD: number;
  direction: 'LONG' | 'SHORT';
  entryPrice: number;
  currentPrice: number;
  unrealizedPnLUSD: number;
  realizedPnLUSD: number;
  deltaUSD: number;
  vegaUSD: number;
  carryAnnualUSD: number;
}

export interface RiskMetrics {
  totalPortfolioValueUSD: number;
  netFXExposureUSD: number;
  dailyPnLUSD: number;
  var95_1D: number; // Value at Risk 95%
  var99_1D: number; // Value at Risk 99%
  expectedShortfall99: number;
  maxDrawdownPct: number;
  factorBetas: {
    usdIndex: number;
    eurIndex: number;
    ratesGlobal: number;
    commodities: number;
    growthGlobal: number;
    inflation: number;
    riskSentiment: number;
  };
}

export interface LedgerTransaction {
  tx_id: string;
  currencyCode: string;
  type: 'ISSUANCE' | 'REDEMPTION' | 'SETTLEMENT' | 'REBALANCE' | 'FX_INTERVENTION' | 'TRANSFER';
  sender: string;
  receiver: string;
  amount: number;
  fxRateToUSD: number;
  valueUSD: number;
  feeUSD: number;
  status: 'SETTLED' | 'PENDING' | 'REJECTED';
  timestamp: string;
  auditHash: string;
}

export interface ScenarioResult {
  scenarioName: string;
  shocks: string[];
  impactOnReserveValuePct: number;
  impactOnCurrencyPricePct: number;
  impactOnCoverageRatio: number;
  impactOnGDPPct: number;
  impactOnInflationPct: number;
  recommendedAction: string;
}

export interface AIQueryResponse {
  answer: string;
  decompositions?: {
    factor: string;
    impactPct: number;
    direction: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  }[];
  categoryBreakdown?: {
    observed: string[];
    calculated: string[];
    simulated: string[];
    scenarios: string[];
  };
}
