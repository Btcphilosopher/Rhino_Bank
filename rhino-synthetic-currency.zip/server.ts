import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { simEngine } from './src/engine/simulationState.js';

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Shared Gemini AI instance
const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    })
  : null;

// --- API ROUTES ---

// 1. Get Currencies
app.get('/api/v1/currencies', (_req: Request, res: Response) => {
  res.json({ currencies: simEngine.getCurrencies() });
});

app.get('/api/v1/currencies/:id', (req: Request, res: Response) => {
  const currency = simEngine.getCurrency(req.params.id);
  if (!currency) return res.status(404).json({ error: 'Currency not found' });
  res.json({ currency });
});

// 2. Create New Currency
app.post('/api/v1/currencies', (req: Request, res: Response) => {
  try {
    const currency = simEngine.createCurrency(req.body);
    res.json({ success: true, currency });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// 3. Issue Currency (Mint)
app.post('/api/v1/currencies/:code/issue', (req: Request, res: Response) => {
  const { amount, receiver } = req.body;
  const result = simEngine.issueCurrency(req.params.code, Number(amount), receiver || 'Primary Dealer');
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

// 4. Redeem Currency (Burn)
app.post('/api/v1/currencies/:code/redeem', (req: Request, res: Response) => {
  const { amount, sender } = req.body;
  const result = simEngine.redeemCurrency(req.params.code, Number(amount), sender || 'Institutional Holder');
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

// 5. Update Monetary Policy
app.post('/api/v1/currencies/:code/monetary-policy', (req: Request, res: Response) => {
  const updated = simEngine.updateMonetaryPolicy(req.params.code, req.body);
  if (!updated) return res.status(404).json({ error: 'Currency not found' });
  res.json({ success: true, currency: updated });
});

// 6. FX Market & Orderbook
app.get('/api/v1/fx/pairs', (_req: Request, res: Response) => {
  res.json({ pairs: simEngine.getFXPairs() });
});

app.get('/api/v1/fx/orderbook/:pairId(*)', (req: Request, res: Response) => {
  const orderBook = simEngine.getOrderBook(req.params.pairId);
  res.json({ pair_id: req.params.pairId, ...orderBook });
});

app.post('/api/v1/fx/orders', (req: Request, res: Response) => {
  try {
    const result = simEngine.submitOrder(req.body);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/v1/fx/trades', (_req: Request, res: Response) => {
  res.json({ trades: simEngine.getTrades() });
});

// 7. Reserves & Risk
app.get('/api/v1/reserves', (_req: Request, res: Response) => {
  res.json({ reserves: simEngine.getReserves() });
});

app.get('/api/v1/risk', (_req: Request, res: Response) => {
  res.json({ risk: simEngine.getRiskMetrics() });
});

// 8. Macro Economy & Digital Twin
app.get('/api/v1/macro/:code', (req: Request, res: Response) => {
  const macro = simEngine.getMacro(req.params.code);
  res.json({ macro });
});

// 9. Portfolio
app.get('/api/v1/portfolio', (_req: Request, res: Response) => {
  res.json({ portfolio: simEngine.getPortfolio() });
});

// 10. Ledger & Settlement
app.get('/api/v1/ledger', (_req: Request, res: Response) => {
  res.json({ ledger: simEngine.getLedger() });
});

// 11. Scenarios
app.post('/api/v1/scenarios/run', (req: Request, res: Response) => {
  const { scenarioKey } = req.body;
  const result = simEngine.runScenario(scenarioKey);
  res.json({ result });
});

// 12. Simulation Tick Step
app.post('/api/v1/simulation/tick', (req: Request, res: Response) => {
  const { days } = req.body;
  simEngine.tickSimulation(days || 1);
  res.json({ success: true, message: `Advanced simulation by ${days || 1} day(s)` });
});

// 13. Gemini AI Currency Intelligence Terminal
app.post('/api/ai/query', async (req: Request, res: Response) => {
  const { query, currencyCode } = req.body;
  const code = currencyCode || 'RGU';
  const currency = simEngine.getCurrency(code);
  const macro = simEngine.getMacro(code);
  const reserves = simEngine.getReserves();
  const risk = simEngine.getRiskMetrics();

  const systemContext = `
You are RHINO CURRENCY INTELLIGENCE — the Senior Quantitative Strategist & Chief Economist at Rhino Bank / RhinoQuant.
You analyze synthetic currency systems, monetary policy, basket dynamics, reserve coverage, and macro causal transmission.

CURRENT SYSTEM STATE:
- Active Currency: ${currency?.name} (${currency?.code})
- Basket Price (USD): $${currency?.unitValueUSD}
- Policy Rate: ${currency?.monetary_policy.policyRate}%
- Total Reserve Value: $${(reserves.reduce((acc, r) => acc + r.totalValueUSD, 0) / 1e9).toFixed(2)}B
- Reserve Coverage Ratio: ${currency?.money_supply.totalReserveCoverageRatio}%
- Circulating Supply: ${((currency?.circulating_supply || 0) / 1e9).toFixed(2)}B ${currency?.code}
- Synthetic GDP: $${macro?.nominalGDPUSD}B | CPI Inflation: ${macro?.cpiHeadlinePct}% | Real Growth: ${macro?.realGDPGrowthPct}%
- Net FX Exposure: $${(risk.netFXExposureUSD / 1e6).toFixed(1)}M | 1D 99% VaR: $${(risk.var99_1D / 1e6).toFixed(1)}M

INSTRUCTIONS FOR YOUR RESPONSE:
1. Provide a rigorous, institutional monetary analysis answering the user query.
2. In your text, explicitly distinguish between:
   - [OBSERVED]: Hard numbers from live state
   - [CALCULATED]: Derived econometric or basket valuation formulas
   - [SIMULATED]: Projections from the causal macroeconomic transmission model
   - [SCENARIO]: Hypothetical stress responses
   - [ASSUMPTION]: Baseline parameter assumptions
3. Be direct, authoritative, precise, and concise.
`;

  if (!ai) {
    return res.json({
      answer: `[OBSERVED] Current ${code} price is $${currency?.unitValueUSD} USD with policy rate at ${currency?.monetary_policy.policyRate}%. [CALCULATED] Basket value is supported by multi-asset reserves ($12.8B). [SIMULATED] A rate hike would compress inflation toward the ${currency?.monetary_policy.inflationTarget}% target while contracting credit growth. (Note: AI live reasoning available when GEMINI_API_KEY is configured).`
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: query,
      config: {
        systemInstruction: systemContext,
        temperature: 0.3
      }
    });

    res.json({ answer: response.text });
  } catch (err: any) {
    console.error('Gemini API Error:', err);
    res.status(500).json({ error: err.message || 'Error generating AI analysis' });
  }
});

// Setup Vite middleware for development or static serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RHINO SYNTHETIC CURRENCY Platform running on port ${PORT}`);
  });
}

startServer();
