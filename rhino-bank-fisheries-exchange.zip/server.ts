import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import {
  Vessel,
  FishInventoryItem,
  RFQ,
  RFQResponse,
  CommodityMarket,
  Loan,
  CatchBackedLendingApplication,
  MarineFund,
  VesselRiskAnalysis,
  LogisticsOptimisationRoute,
  SustainabilityMetrics,
  AuditLog,
  User,
  UserRole
} from "./src/types.js";

const app = express();
const PORT = 3000;

app.use(express.json());

// ==========================================
// IN-MEMORY "POSTGRESQL" DATABASE SIMULATOR
// ==========================================

const database = {
  users: [
    { id: "u-1", name: "Sarah Jenkins", email: "sarah.jenkins@rhinobank.co.uk", role: "Rhino Bank Analyst", organization: "Rhino Investment Banking" },
    { id: "u-2", name: "Arthur Pendelton", email: "arthur.p@yorkshirefishing.co.uk", role: "Captain", organization: "Yorkshire Enterprise Fleet" },
    { id: "u-3", name: "Thomas Cobble", email: "thomas@bridmarine.co.uk", role: "Fishing Vessel Owner", organization: "Cobble & Sons Marine" },
    { id: "u-4", name: "Marco Pierre", email: "marco@leedsgrill.co.uk", role: "Buyer", organization: "The Yorkshire Larder (Leeds)" },
    { id: "u-5", name: "Geoff Whitby", email: "geoff@whitbycoldstorage.co.uk", role: "Supplier", organization: "Whitby Co-operative Storage" },
    { id: "u-6", name: "Eleanor Vance", email: "vance.invest@rhinobank.co.uk", role: "Investor", organization: "Rhino Marine Capital" }
  ] as User[],

  vessels: [
    {
      id: "v-1",
      name: "FV Yorkshire Enterprise",
      owner: "Cobble & Sons Marine",
      captain: "Arthur Pendelton",
      port: "Scarborough",
      registration: "UK-Y-101",
      fishingLicence: "FL-992-ENTERPRISE",
      insuranceStatus: "Active",
      engineSizeHp: 1200,
      fuelCapacityLitres: 45000,
      fuelLevelPercent: 67,
      ageYears: 4,
      purchaseValue: 2500000,
      outstandingFinance: 1800000,
      riskRating: "AAA",
      status: "Fishing",
      latitude: 54.384,
      longitude: 0.123,
      heading: 42,
      speedKnots: 8.4,
      currentCatchEstimate: 24500,
      crewCount: 8
    },
    {
      id: "v-2",
      name: "FV Whitby Explorer",
      owner: "Whitby Co-operative Storage",
      captain: "Sarah Sterling",
      port: "Whitby",
      registration: "UK-W-203",
      fishingLicence: "FL-743-EXPLORER",
      insuranceStatus: "Active",
      engineSizeHp: 950,
      fuelCapacityLitres: 35000,
      fuelLevelPercent: 82,
      ageYears: 6,
      purchaseValue: 1800000,
      outstandingFinance: 950000,
      riskRating: "AA",
      status: "At Sea",
      latitude: 54.512,
      longitude: -0.421,
      heading: 110,
      speedKnots: 11.2,
      currentCatchEstimate: 12400,
      crewCount: 6
    },
    {
      id: "v-3",
      name: "FV Bridlington Pride",
      owner: "Cobble & Sons Marine",
      captain: "Thomas Cobble",
      port: "Bridlington",
      registration: "UK-B-305",
      fishingLicence: "FL-812-PRIDE",
      insuranceStatus: "Active",
      engineSizeHp: 800,
      fuelCapacityLitres: 28000,
      fuelLevelPercent: 100,
      ageYears: 9,
      purchaseValue: 1200000,
      outstandingFinance: 400000,
      riskRating: "A",
      status: "In Port",
      latitude: 54.084,
      longitude: -0.183,
      heading: 0,
      speedKnots: 0.0,
      currentCatchEstimate: 0,
      crewCount: 5
    },
    {
      id: "v-4",
      name: "FV Scarborough Star",
      owner: "Vance Fishing Ltd",
      captain: "Michael Vance",
      port: "Scarborough",
      registration: "UK-S-442",
      fishingLicence: "FL-331-STAR",
      insuranceStatus: "Active",
      engineSizeHp: 1100,
      fuelCapacityLitres: 40000,
      fuelLevelPercent: 41,
      ageYears: 14,
      purchaseValue: 2100000,
      outstandingFinance: 1550000,
      riskRating: "BB",
      status: "Fishing",
      latitude: 54.689,
      longitude: 0.923,
      heading: 285,
      speedKnots: 7.1,
      currentCatchEstimate: 31200,
      crewCount: 9
    },
    {
      id: "v-5",
      name: "FV Hull Monarch",
      owner: "Rhino Marine Capital",
      captain: "William Drake",
      port: "Hull",
      registration: "UK-H-501",
      fishingLicence: "FL-125-MONARCH",
      insuranceStatus: "Active",
      engineSizeHp: 1500,
      fuelCapacityLitres: 60000,
      fuelLevelPercent: 55,
      ageYears: 3,
      purchaseValue: 3400000,
      outstandingFinance: 2600000,
      riskRating: "AAA",
      status: "At Sea",
      latitude: 53.811,
      longitude: 0.442,
      heading: 180,
      speedKnots: 12.5,
      currentCatchEstimate: 18000,
      crewCount: 12
    }
  ] as Vessel[],

  fishInventory: [
    {
      id: "fish-1",
      species: "Cod",
      weightKg: 1200,
      landingDate: "2026-07-31",
      fishingVesselId: "v-1",
      fishingVesselName: "FV Yorkshire Enterprise",
      landingPort: "Scarborough",
      qualityGrade: "Premium (A+)",
      storageLocation: "Scarborough Cold Storage Hub A4",
      currentMarketPricePerKg: 8.20,
      buyerStatus: "Available",
      traceabilityCertificate: "RFID-GB-SCAR-883921"
    },
    {
      id: "fish-2",
      species: "Lobster",
      weightKg: 400,
      landingDate: "2026-08-01",
      fishingVesselId: "v-2",
      fishingVesselName: "FV Whitby Explorer",
      landingPort: "Whitby",
      qualityGrade: "Premium (A+)",
      storageLocation: "Whitby Coastal Co-op Storage Room 2",
      currentMarketPricePerKg: 18.00,
      buyerStatus: "Available",
      traceabilityCertificate: "RFID-GB-WHIT-445839"
    },
    {
      id: "fish-3",
      species: "Haddock",
      weightKg: 2500,
      landingDate: "2026-07-30",
      fishingVesselId: "v-4",
      fishingVesselName: "FV Scarborough Star",
      landingPort: "Scarborough",
      qualityGrade: "Standard (A)",
      storageLocation: "Scarborough Cold Storage Hub B1",
      currentMarketPricePerKg: 5.60,
      buyerStatus: "Reserved",
      buyerId: "u-4",
      buyerName: "Marco Pierre",
      traceabilityCertificate: "RFID-GB-SCAR-119283"
    },
    {
      id: "fish-4",
      species: "Crab",
      weightKg: 850,
      landingDate: "2026-07-31",
      fishingVesselId: "v-2",
      fishingVesselName: "FV Whitby Explorer",
      landingPort: "Whitby",
      qualityGrade: "Standard (A)",
      storageLocation: "Whitby Coastal Co-op Storage Room 1",
      currentMarketPricePerKg: 11.40,
      buyerStatus: "Available",
      traceabilityCertificate: "RFID-GB-WHIT-992384"
    },
    {
      id: "fish-5",
      species: "Skate",
      weightKg: 620,
      landingDate: "2026-07-28",
      fishingVesselId: "v-5",
      fishingVesselName: "FV Hull Monarch",
      landingPort: "Hull",
      qualityGrade: "Processing (B)",
      storageLocation: "Hull Dockside Freezer Unit 7",
      currentMarketPricePerKg: 4.10,
      buyerStatus: "Sold",
      buyerId: "u-4",
      buyerName: "Marco Pierre",
      traceabilityCertificate: "RFID-GB-HULL-332918"
    }
  ] as FishInventoryItem[],

  rfqs: [
    {
      id: "rfq-1",
      buyerId: "u-4",
      buyerName: "Marco Pierre",
      species: "Cod",
      quantityRequiredKg: 500,
      frequency: "Weekly",
      deliveryDate: "2026-08-05",
      qualityRequired: "Premium (A+)",
      status: "Open",
      createdAt: "2026-08-01",
      responses: [
        {
          id: "rfqr-1",
          rfqId: "rfq-1",
          supplierId: "v-1",
          supplierName: "FV Yorkshire Enterprise",
          pricePerKg: 8.05,
          availabilityConfirmed: true,
          deliveryDate: "2026-08-05",
          qualityCertificate: "CERT-SCAR-A1",
          status: "Pending",
          notes: "Premium hook-and-line landed cod, straight out of Scarborough storage."
        }
      ]
    },
    {
      id: "rfq-2",
      buyerId: "u-4",
      buyerName: "Marco Pierre",
      species: "Lobster",
      quantityRequiredKg: 200,
      frequency: "Once-off",
      deliveryDate: "2026-08-03",
      qualityRequired: "Premium (A+)",
      status: "Open",
      createdAt: "2026-08-01",
      responses: []
    }
  ] as RFQ[],

  commodityMarkets: [
    {
      species: "Cod",
      currentPricePerKg: 8.20,
      change24hPercent: 3.4,
      change7dPercent: 8.1,
      supplyLevel: "Medium",
      demandLevel: "High",
      forecastPrice30d: 8.95,
      historicalPrices: [
        { date: "07-25", price: 7.50, volume: 14200 },
        { date: "07-26", price: 7.62, volume: 15100 },
        { date: "07-27", price: 7.75, volume: 13900 },
        { date: "07-28", price: 7.80, volume: 16500 },
        { date: "07-29", price: 7.95, volume: 14800 },
        { date: "07-30", price: 8.00, volume: 15300 },
        { date: "07-31", price: 8.20, volume: 17200 }
      ]
    },
    {
      species: "Lobster",
      currentPricePerKg: 18.00,
      change24hPercent: 1.2,
      change7dPercent: 4.5,
      supplyLevel: "Low",
      demandLevel: "High",
      forecastPrice30d: 19.40,
      historicalPrices: [
        { date: "07-25", price: 17.20, volume: 2200 },
        { date: "07-26", price: 17.40, volume: 2100 },
        { date: "07-27", price: 17.50, volume: 2500 },
        { date: "07-28", price: 17.65, volume: 2400 },
        { date: "07-29", price: 17.80, volume: 1900 },
        { date: "07-30", price: 17.90, volume: 2300 },
        { date: "07-31", price: 18.00, volume: 2400 }
      ]
    },
    {
      species: "Haddock",
      currentPricePerKg: 5.60,
      change24hPercent: -0.8,
      change7dPercent: 2.1,
      supplyLevel: "High",
      demandLevel: "Medium",
      forecastPrice30d: 5.45,
      historicalPrices: [
        { date: "07-25", price: 5.45, volume: 21200 },
        { date: "07-26", price: 5.50, volume: 22800 },
        { date: "07-27", price: 5.55, volume: 24100 },
        { date: "07-28", price: 5.62, volume: 23100 },
        { date: "07-29", price: 5.65, volume: 22500 },
        { date: "07-30", price: 5.68, volume: 25900 },
        { date: "07-31", price: 5.60, volume: 27800 }
      ]
    },
    {
      species: "Crab",
      currentPricePerKg: 11.40,
      change24hPercent: 2.5,
      change7dPercent: 6.2,
      supplyLevel: "Low",
      demandLevel: "High",
      forecastPrice30d: 12.10,
      historicalPrices: [
        { date: "07-25", price: 10.70, volume: 4200 },
        { date: "07-26", price: 10.85, volume: 4500 },
        { date: "07-27", price: 10.95, volume: 4400 },
        { date: "07-28", price: 11.10, volume: 4800 },
        { date: "07-29", price: 11.20, volume: 4100 },
        { date: "07-30", price: 11.30, volume: 4300 },
        { date: "07-31", price: 11.40, volume: 4500 }
      ]
    }
  ] as CommodityMarket[],

  loans: [
    {
      id: "loan-1",
      vesselId: "v-1",
      vesselName: "FV Yorkshire Enterprise",
      borrowerName: "Cobble & Sons Marine",
      type: "Vessel Purchase",
      principalAmount: 1800000,
      outstandingBalance: 1800000,
      interestRatePercent: 6.2,
      termMonths: 180, // 15 years
      monthlyPayment: 15378,
      expectedAnnualRevenue: 850000,
      riskCategory: "Medium",
      status: "Performing",
      startDate: "2026-03-15"
    },
    {
      id: "loan-2",
      vesselId: "v-2",
      vesselName: "FV Whitby Explorer",
      borrowerName: "Whitby Co-operative Storage",
      type: "Vessel Purchase",
      principalAmount: 1200000,
      outstandingBalance: 950000,
      interestRatePercent: 5.8,
      termMonths: 120,
      monthlyPayment: 13204,
      expectedAnnualRevenue: 650000,
      riskCategory: "Low",
      status: "Performing",
      startDate: "2024-05-10"
    },
    {
      id: "loan-3",
      vesselId: "v-4",
      vesselName: "FV Scarborough Star",
      borrowerName: "Vance Fishing Ltd",
      type: "Vessel Purchase",
      principalAmount: 1600000,
      outstandingBalance: 1550000,
      interestRatePercent: 7.5,
      termMonths: 180,
      monthlyPayment: 14815,
      expectedAnnualRevenue: 720000,
      riskCategory: "High",
      status: "Under Observation",
      startDate: "2025-11-01"
    }
  ] as Loan[],

  catchLendingApps: [] as CatchBackedLendingApplication[],

  marineFund: {
    name: "Rhino Yorkshire Marine Growth Fund",
    totalAUM: 125500000, // £125.5 million
    cashReserve: 15500000,
    allocatedAssets: {
      vesselsFinance: 62000000,
      processingFacilities: 24000000,
      coldStorage: 14000000,
      distributionNetworks: 6000000,
      marineTech: 4000000
    },
    irrPercent: 11.4,
    roiPercent: 14.8,
    historicalYields: [
      { period: "2022", yield: 8.5 },
      { period: "2023", yield: 9.2 },
      { period: "2024", yield: 11.1 },
      { period: "2025", yield: 10.8 },
      { period: "YTD 2026", yield: 11.4 }
    ]
  } as MarineFund,

  sustainability: {
    carbonPerKgFish: 1.84, // 1.84 kg CO2 per kg catch (highly efficient vs global avg of ~2.5)
    fleetFuelEfficiencyPercent: 88.5,
    sustainableFishingMethodsPercent: 92.0, // AAA standard
    traceabilityCompliancePercent: 100.0,
    stockSustainabilityIndices: [
      { species: "Cod", indexScore: 68 },
      { species: "Lobster", indexScore: 82 },
      { species: "Haddock", indexScore: 78 },
      { species: "Crab", indexScore: 85 },
      { species: "Skate", indexScore: 55 },
      { species: "Herring", indexScore: 90 },
      { species: "Mackerel", indexScore: 84 }
    ]
  } as SustainabilityMetrics,

  auditLogs: [
    { id: "audit-1", timestamp: "2026-08-01 04:12:05", actor: "sarah.jenkins", action: "CREDIT_INQUIRY", details: "Retrieved credit risk profile for FV Yorkshire Enterprise (Rating: AAA)", ipAddress: "192.168.1.10" },
    { id: "audit-2", timestamp: "2026-08-01 04:30:11", actor: "sarah.jenkins", action: "FUND_ALLOCATION", details: "Approved £1.8M asset loan allocation for vessel purchase", ipAddress: "192.168.1.10" },
    { id: "audit-3", timestamp: "2026-08-01 05:01:24", actor: "marco.pierre", action: "INVENTORY_RESERVE", details: "Reserved 2500kg of Haddock from Scarborough Star catch", ipAddress: "10.0.4.52" }
  ] as AuditLog[]
};

// ==========================================
// R QUANTITATIVE ANALYTICS ENGINE SIMULATOR
// ==========================================

// R Monte Carlo Vessel Credit scoring simulator
function calculateRMonteCarloRisk(vessel: Vessel): VesselRiskAnalysis {
  // Inputs: Vessel age, engine, fuel efficiency, captain experience, debt levels, species reliance, volatility
  const baseDebtFactor = vessel.outstandingFinance / (vessel.purchaseValue || 1);
  const agePenalty = Math.max(0, (vessel.ageYears - 5) * 0.02);
  const fuelFactor = (100 - vessel.fuelLevelPercent) * 0.001;
  const reliabilityFactor = vessel.status === "Maintenance" ? 0.15 : 0.02;

  // Probability of Default estimation (R logistic model)
  const logOdds = -4.5 + (baseDebtFactor * 3.5) + agePenalty + fuelFactor + reliabilityFactor;
  const defaultProbability = 1 / (1 + Math.exp(-logOdds));
  const defaultProbabilityPercent = parseFloat((defaultProbability * 100).toFixed(2));

  // Value at Risk (VaR) calculation
  const monthlyRevenueEst = (vessel.purchaseValue * 0.3) / 12;
  const marketVolatility = 0.22; // 22% R calculated volatility
  const zScore95 = 1.645;
  const valueAtRiskAmount = parseFloat((monthlyRevenueEst * zScore95 * marketVolatility).toFixed(0));

  // Determine Credit Score matching Bloomberg standard
  let creditScore: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' | 'CCC' = 'AAA';
  if (defaultProbabilityPercent > 18) creditScore = 'CCC';
  else if (defaultProbabilityPercent > 12) creditScore = 'B';
  else if (defaultProbabilityPercent > 7) creditScore = 'BB';
  else if (defaultProbabilityPercent > 4) creditScore = 'BBB';
  else if (defaultProbabilityPercent > 2) creditScore = 'A';
  else if (defaultProbabilityPercent > 0.8) creditScore = 'AA';

  // Stress tests (4 R scenarios)
  const baseCaseIncome = parseFloat((vessel.currentCatchEstimate || 24500).toFixed(0));
  const fuelSurgeIncome = parseFloat((baseCaseIncome - 4500).toFixed(0));
  const stormDisruptionIncome = parseFloat((baseCaseIncome * 0.4).toFixed(0));
  const marketCrashIncome = parseFloat((baseCaseIncome * 0.7).toFixed(0));

  // 10 Monte Carlo scenario runs
  const monteCarloScenarios = Array.from({ length: 10 }).map((_, i) => {
    const randomCatch = baseCaseIncome * (0.7 + Math.random() * 0.6);
    const randomFuel = (vessel.engineSizeHp * 1.2) * (0.8 + Math.random() * 0.4);
    const netIncome = randomCatch - randomFuel;
    return {
      run: i + 1,
      projectedCatch: parseFloat(randomCatch.toFixed(0)),
      fuelCost: parseFloat(randomFuel.toFixed(0)),
      netIncome: parseFloat(netIncome.toFixed(0))
    };
  });

  return {
    vesselId: vessel.id,
    vesselName: vessel.name,
    creditScore,
    defaultProbabilityPercent,
    valueAtRiskAmount,
    monteCarloScenarios,
    stressTests: {
      baseCaseIncome,
      fuelSurgeIncome,
      stormDisruptionIncome,
      marketCrashIncome
    }
  };
}

// R ARIMA econometric forecasting simulator for commodities
function runRCommodityForecast(market: CommodityMarket, fuelCosts: number, weatherSeverity: number, seasonalityIndex: number): CommodityMarket {
  // Formula: Future Fish Price = Current Price + Supply Changes + Demand Changes + Fuel Costs + Weather Impact + Seasonality
  const currentPrice = market.currentPricePerKg;
  
  // High supply pushes price down; High demand pushes it up
  const supplyTerm = market.supplyLevel === "Low" ? 0.12 : market.supplyLevel === "High" ? -0.08 : 0.01;
  const demandTerm = market.demandLevel === "High" ? 0.15 : market.demandLevel === "Low" ? -0.05 : 0.02;
  const fuelCostTerm = (fuelCosts - 1.15) * 0.10; // extra fuel cost transfers to commodity prices
  const weatherTerm = weatherSeverity * 0.08; // bad weather restricts fishing, drives prices up
  const seasonalTerm = seasonalityIndex * 0.05;

  const totalChangePercent = supplyTerm + demandTerm + fuelCostTerm + weatherTerm + seasonalTerm;
  const forecastPrice30d = parseFloat((currentPrice * (1 + totalChangePercent)).toFixed(2));

  // Generate extended 7-day projection array
  const updatedPrices = [...market.historicalPrices];
  // Rotate historical prices so it feels dynamic
  updatedPrices.shift();
  const lastPrice = updatedPrices[updatedPrices.length - 1].price;
  const nextPrice = parseFloat((lastPrice * (1 + (Math.random() * 0.06 - 0.025))).toFixed(2));
  updatedPrices.push({
    date: new Date().toLocaleDateString("en-US", { month: "2-digit", day: "2-digit" }),
    price: nextPrice,
    volume: Math.floor(market.historicalPrices[market.historicalPrices.length - 1].volume * (0.9 + Math.random() * 0.2))
  });

  return {
    ...market,
    currentPricePerKg: nextPrice,
    forecastPrice30d,
    historicalPrices: updatedPrices
  };
}

// ==========================================
// RUST CORE LOGISTICS OPTIMIZATION ENGINE
// ==========================================

// Dijkstra-style logistics path finding
function runRustLogisticsOptimization(landingPort: string, destination: string): LogisticsOptimisationRoute {
  // We model Yorkshire road infrastructure: Ports (Scarborough, Whitby, Bridlington, Hull) -> York Hub -> Leeds / Sheffield
  const routes = {
    "Scarborough-Leeds": {
      coldStorage: "Scarborough Coastal Cold Storage A",
      distributionCentre: "York Central Marine Distribution Hub",
      transitTimeMinutes: 74,
      fuelCostGBP: 85,
      carbonKgCo2: 24.5,
      temp: -2.5
    },
    "Whitby-Leeds": {
      coldStorage: "Whitby Coastal Co-op Freezer Room 2",
      distributionCentre: "York Central Marine Distribution Hub",
      transitTimeMinutes: 89,
      fuelCostGBP: 98,
      carbonKgCo2: 28.2,
      temp: -3.0
    },
    "Bridlington-Leeds": {
      coldStorage: "Bridlington Dockside Chillers",
      distributionCentre: "East Yorkshire Transit Facility",
      transitTimeMinutes: 65,
      fuelCostGBP: 72,
      carbonKgCo2: 19.8,
      temp: -2.0
    },
    "Hull-Leeds": {
      coldStorage: "Hull Dockside Freezer Unit 7",
      distributionCentre: "M62 Logistics Corridor Hub",
      transitTimeMinutes: 58,
      fuelCostGBP: 64,
      carbonKgCo2: 18.1,
      temp: -1.8
    }
  };

  const key = `${landingPort}-${destination}` as keyof typeof routes;
  const routeData = routes[key] || routes["Scarborough-Leeds"];

  return {
    id: `opt-${landingPort.substring(0, 3).toUpperCase()}-${destination.substring(0, 3).toUpperCase()}`,
    originPort: landingPort,
    coldStorage: routeData.coldStorage,
    distributionCentre: routeData.distributionCentre,
    destination: destination,
    transitTimeMinutes: routeData.transitTimeMinutes,
    fuelCostGBP: routeData.fuelCostGBP,
    carbonKgCo2: routeData.carbonKgCo2,
    temperatureMaintainedCelsius: routeData.temp,
    capacityUtilizationPercent: Math.floor(75 + Math.random() * 20)
  };
}

// ==========================================
// GEMINI SYSTEM AI ADVISOR PORTAL
// ==========================================

let aiClient: GoogleGenAI | null = null;
try {
  if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY") {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
} catch (e) {
  console.error("Failed to initialize Google GenAI SDK:", e);
}

// REST API endpoint: Gemini intelligence
app.post("/api/analytics/ai-intelligence", async (req, res) => {
  const { query, activeVesselId, focusArea } = req.body;

  // Prepare database context summaries to feed into Gemini context
  const fleetSummary = database.vessels.map(v => 
    `- ${v.name}: Port ${v.port}, Status ${v.status}, Risk ${v.riskRating}, Financed: £${(v.purchaseValue/1e6).toFixed(1)}M, Outstanding: £${(v.outstandingFinance/1e6).toFixed(1)}M, Fuel ${v.fuelLevelPercent}%, Est. Catch: £${v.currentCatchEstimate}`
  ).join("\n");

  const marketSummary = database.commodityMarkets.map(m =>
    `- ${m.species}: Current Price £${m.currentPricePerKg}/kg, Supply ${m.supplyLevel}, Demand ${m.demandLevel}, 30D Forecast: £${m.forecastPrice30d}`
  ).join("\n");

  const systemSummary = `
Active Fund: ${database.marineFund.name}
Total assets: £${(database.marineFund.totalAUM/1e6).toFixed(1)} million, Cash reserves: £${(database.marineFund.cashReserve/1e6).toFixed(1)} million.
IRR: ${database.marineFund.irrPercent}%, ROI: ${database.marineFund.roiPercent}%.
Fleet Sustainability: ESG Score ${database.sustainability.sustainableFishingMethodsPercent}% sustainable methods, Carbon emissions: ${database.sustainability.carbonPerKgFish} kg CO2/kg fish.
  `;

  const prompt = `
You are the Executive Artificial Intelligence Officer for RHINO BANK FISHERIES EXCHANGE (the Bloomberg Terminal for Yorkshire Fishing).
We are managing, financing, and digitising the Yorkshire fishing economy (Scarborough, Whitby, Bridlington, Hull).

Here is our current real-time database state:

--- VESSEL FLEET ---
${fleetSummary}

--- WHOLESALE MARKETS ---
${marketSummary}

--- INVESTMENT PORTFOLIO & ESG ---
${systemSummary}

User is asking or focusing on: "${query || "System health diagnostic and economic forecast"}"
Focus Area: ${focusArea || "General Terminal Insights"}

Provide a highly professional, concise, analytical briefing structured strictly in a clean, financial Bloomberg reporting format.
Your briefing must include:
1. MARKET RISK DIAGNOSIS: Analysis of fish pricing volatility, fuel burdens, and stock sustainability indices.
2. LOAN DEFAULT & CREDIT ALIGNMENT: Identify vessels showing distress indicators (such as high leverage or dropping fuel levels/maintenance backlogs) and recommend interest premium adjustment.
3. LOGISTICS & HARVEST RECOMMENDATIONS: Propose optimal cold-chain routes and distribution hubs to maximize premium Grade A+ landing values.
4. ACTIONABLE EXECUTIVE GUIDANCE: 3 precise bank actions Rhino Bank should take today.

Keep your tone clinical, investment-banking-grade, analytical, and tailored to senior fisheries portfolio managers. Do not use generic SaaS filler words like "supercharge" or "empower".
  `;

  if (aiClient) {
    try {
      const response = await aiClient.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
      });

      res.json({
        report: response.text,
        timestamp: new Date().toISOString(),
        model: "gemini-3.6-flash"
      });
    } catch (err: any) {
      console.error("Gemini call error, failing back to econometric reporting:", err);
      res.json(generateFallbackAnalyticalReport(query, focusArea));
    }
  } else {
    // Generate intelligent algorithmic fallback report mimicking actual R output
    res.json(generateFallbackAnalyticalReport(query, focusArea));
  }
});

function generateFallbackAnalyticalReport(query: string, focusArea: string) {
  return {
    report: `
================================================================================
RHINO BANK FISHERIES RESEARCH - FALLBACK DIAGNOSTIC (ECONOMETRIC SIMULATION)
================================================================================
DATE: ${new Date().toLocaleDateString()} | STATUS: SIMULATION MODE ACTIVE (LOCAL R INTELLIGENCE)
--------------------------------------------------------------------------------

1. MARKET RISK DIAGNOSIS:
   - Price movements indicate strong upward pressure on Premium Lobster (+4.5% weekly) driven by supply deficits in Whitby.
   - Haddock remains over-supplied (high landings in Scarborough and Bridlington), creating a localized margin compression of -0.8%.
   - Fuel rates remain highly correlated with vessel cash-flow margins. A sustained £1.25/L fuel cost translates to an average 12.4% reduction in net catch profit across older vessels (e.g., Scarborough Star, age 14).

2. LOAN DEFAULT & CREDIT ALIGNMENT:
   - **Vessel Alert**: FV Scarborough Star (UK-S-442) presents high leverage with outstanding finance at £1.55M against a purchase valuation of £2.1M. Combined with an older hull age (14 years) and lower fuel reserves (41%), the R-logistic default probability has climbed to 9.8% (Rating: BB). We recommend strict monitoring.
   - Performing assets like FV Yorkshire Enterprise (Rating: AAA) continue to sustain comfortable yield ratios, easily carrying their 6.2% asset financing loan.

3. LOGISTICS & HARVEST RECOMMENDATIONS:
   - Scarborough hook-landed Premium Cod presents a high gross margin potential if routed immediately through the York Central Distribution corridor rather than sitting in Scarborough cold storage.
   - Bridlington landed Haddock is best diverted to food processors to prevent further wholesale spot price drops on the fresh market.

4. ACTIONABLE EXECUTIVE PORTFOLIO GUIDANCE:
   - ACTION 1: Restructure asset loan payment schedules for FV Scarborough Star to buffer fuel-surge exposure.
   - ACTION 2: Inject £4.0M capital from the Rhino Marine Growth Fund into cold storage chain expansions in Whitby to support the high-margin lobster trade.
   - ACTION 3: Launch Catch-Backed Lending program for Whitby Explorer to monetize their outstanding premium stock reserves of 400kg.
--------------------------------------------------------------------------------
    `,
    timestamp: new Date().toISOString(),
    model: "Econ-R-Simulation-v1.0"
  };
}

// ==========================================
// REST API ROUTING FOR ALL PLATFORM FEATURES
// ==========================================

// 1. FLEET & TELEMETRY
app.get("/api/vessels", (req, res) => {
  res.json(database.vessels);
});

app.get("/api/fleet/vessels/:id", (req, res) => {
  const vessel = database.vessels.find(v => v.id === req.params.id);
  if (!vessel) return res.status(404).json({ error: "Vessel not found" });
  res.json(vessel);
});

app.post("/api/vessels", (req, res) => {
  const newVessel: Vessel = {
    id: `v-${database.vessels.length + 1}`,
    name: req.body.name || "FV New Dawn",
    owner: req.body.owner || "Independent Co-op",
    captain: req.body.captain || "Unknown Captain",
    port: req.body.port || "Scarborough",
    registration: req.body.registration || `UK-S-${Math.floor(100 + Math.random() * 900)}`,
    fishingLicence: req.body.fishingLicence || `FL-${Math.floor(100 + Math.random() * 900)}-NEW`,
    insuranceStatus: "Active",
    engineSizeHp: Number(req.body.engineSizeHp) || 900,
    fuelCapacityLitres: Number(req.body.fuelCapacityLitres) || 30000,
    fuelLevelPercent: 100,
    ageYears: Number(req.body.ageYears) || 2,
    purchaseValue: Number(req.body.purchaseValue) || 1500000,
    outstandingFinance: Number(req.body.outstandingFinance) || 1000000,
    riskRating: "AA",
    status: "In Port",
    latitude: 54.284 + (Math.random() * 0.2 - 0.1),
    longitude: -0.396 + (Math.random() * 0.2 - 0.1),
    heading: 0,
    speedKnots: 0,
    currentCatchEstimate: 0,
    crewCount: Number(req.body.crewCount) || 5
  };

  database.vessels.push(newVessel);
  
  // Create audit log
  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: "sarah.jenkins",
    action: "VESSEL_REGISTER",
    details: `Registered new vessel: ${newVessel.name} (Value: £${newVessel.purchaseValue})`,
    ipAddress: "192.168.1.10"
  });

  res.status(201).json(newVessel);
});

// Update vessel telemetries or details
app.patch("/api/vessels/:id", (req, res) => {
  const idx = database.vessels.findIndex(v => v.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Vessel not found" });

  database.vessels[idx] = { ...database.vessels[idx], ...req.body };
  res.json(database.vessels[idx]);
});

// 2. FISH INVENTORY
app.get("/api/inventory", (req, res) => {
  res.json(database.fishInventory);
});

app.post("/api/inventory", (req, res) => {
  const { species, weightKg, fishingVesselId, landingPort, qualityGrade } = req.body;
  const vessel = database.vessels.find(v => v.id === fishingVesselId);
  const vName = vessel ? vessel.name : "Unknown Vessel";

  const marketRate = database.commodityMarkets.find(m => m.species === species)?.currentPricePerKg || 5.0;

  const newItem: FishInventoryItem = {
    id: `fish-${database.fishInventory.length + 1}`,
    species,
    weightKg: Number(weightKg),
    landingDate: new Date().toISOString().substring(0, 10),
    fishingVesselId,
    fishingVesselName: vName,
    landingPort,
    qualityGrade,
    storageLocation: `${landingPort} Cold Storage Unit ${Math.floor(Math.random() * 10 + 1)}`,
    currentMarketPricePerKg: marketRate,
    buyerStatus: "Available",
    traceabilityCertificate: `RFID-GB-${landingPort.substring(0, 4).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`
  };

  database.fishInventory.push(newItem);

  // Clear estimated vessel catch upon landing
  if (vessel) {
    vessel.currentCatchEstimate = 0;
    vessel.status = "In Port";
  }

  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: vessel?.captain || "system",
    action: "CATCH_LANDING",
    details: `Landed ${weightKg}kg of ${species} from ${vName} at ${landingPort}`,
    ipAddress: "192.168.1.15"
  });

  res.status(201).json(newItem);
});

// Buy or Reserve stock
app.post("/api/inventory/:id/purchase", (req, res) => {
  const item = database.fishInventory.find(f => f.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Inventory item not found" });
  if (item.buyerStatus !== "Available") return res.status(400).json({ error: "Item is no longer available" });

  const { buyerId, buyerName, reserveOnly } = req.body;

  item.buyerStatus = reserveOnly ? "Reserved" : "Sold";
  item.buyerId = buyerId;
  item.buyerName = buyerName;

  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: buyerName || "buyer",
    action: reserveOnly ? "STOCK_RESERVE" : "STOCK_PURCHASE",
    details: `${reserveOnly ? "Reserved" : "Purchased"} ${item.weightKg}kg of ${item.species} (Total: £${(item.weightKg * item.currentMarketPricePerKg).toFixed(2)})`,
    ipAddress: "10.0.8.21"
  });

  res.json(item);
});

// 3. COMMODITY MARKETS & R ECONOMETRIC FORWARDING
app.get("/api/market", (req, res) => {
  res.json(database.commodityMarkets);
});

// R economic simulation trigger: Updates market prices using ARIMA/seasonality factors
app.post("/api/market/simulate-ticker", (req, res) => {
  const fuelCosts = Number(req.body.fuelCosts) || 1.18; // £/litre
  const weatherSeverity = Number(req.body.weatherSeverity) || 0.2; // 0 (good) to 1 (storm)
  const seasonalityIndex = Number(req.body.seasonalityIndex) || 0.5;

  database.commodityMarkets = database.commodityMarkets.map(m => {
    return runRCommodityForecast(m, fuelCosts, weatherSeverity, seasonalityIndex);
  });

  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: "system.r_analytics",
    action: "MARKET_ARIMA_UPDATE",
    details: `Triggered ARIMA simulation: Fuel price £${fuelCosts}/L, Weather Index ${weatherSeverity}`,
    ipAddress: "localhost"
  });

  res.json(database.commodityMarkets);
});

// 4. B2B PROCUREMENT MARKETPLACE
app.get("/api/procurement/rfqs", (req, res) => {
  res.json(database.rfqs);
});

app.post("/api/procurement/rfqs", (req, res) => {
  const { buyerId, buyerName, species, quantityRequiredKg, frequency, deliveryDate, qualityRequired } = req.body;

  const newRFQ: RFQ = {
    id: `rfq-${database.rfqs.length + 1}`,
    buyerId,
    buyerName,
    species,
    quantityRequiredKg: Number(quantityRequiredKg),
    frequency,
    deliveryDate,
    qualityRequired,
    status: "Open",
    createdAt: new Date().toISOString().substring(0, 10),
    responses: []
  };

  database.rfqs.push(newRFQ);

  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: buyerName,
    action: "RFQ_CREATE",
    details: `Created RFQ for ${quantityRequiredKg}kg of ${species} (${frequency})`,
    ipAddress: "10.0.8.21"
  });

  res.status(201).json(newRFQ);
});

app.post("/api/procurement/rfqs/:id/respond", (req, res) => {
  const rfq = database.rfqs.find(r => r.id === req.params.id);
  if (!rfq) return res.status(404).json({ error: "RFQ not found" });

  const { supplierId, supplierName, pricePerKg, notes } = req.body;

  const newResponse: RFQResponse = {
    id: `rfqr-${Date.now()}`,
    rfqId: rfq.id,
    supplierId,
    supplierName,
    pricePerKg: Number(pricePerKg),
    availabilityConfirmed: true,
    deliveryDate: rfq.deliveryDate,
    qualityCertificate: `CERT-SCAR-Q${Math.floor(10 + Math.random() * 90)}`,
    status: "Pending",
    notes
  };

  rfq.responses.push(newResponse);

  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: supplierName,
    action: "RFQ_BID",
    details: `Submitted bid of £${pricePerKg}/kg for RFQ ${rfq.id}`,
    ipAddress: "192.168.2.1"
  });

  res.status(201).json(newResponse);
});

// Accept B2B RFQ bid
app.post("/api/procurement/rfqs/:rfqId/responses/:responseId/accept", (req, res) => {
  const rfq = database.rfqs.find(r => r.id === req.params.rfqId);
  if (!rfq) return res.status(404).json({ error: "RFQ not found" });

  const bid = rfq.responses.find(b => b.id === req.params.responseId);
  if (!bid) return res.status(404).json({ error: "Bid response not found" });

  // Update status
  bid.status = "Accepted";
  rfq.status = "Closed";
  
  // Decline all other bids
  rfq.responses.forEach(otherBid => {
    if (otherBid.id !== bid.id) {
      otherBid.status = "Declined";
    }
  });

  // Provision simulated contract and delivery invoice in database
  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: rfq.buyerName,
    action: "RFQ_ACCEPT",
    details: `Accepted supplier bid from ${bid.supplierName} (Contract Total: £${(rfq.quantityRequiredKg * bid.pricePerKg).toFixed(2)})`,
    ipAddress: "10.0.8.21"
  });

  res.json({ rfq, bid });
});

// 5. MARINE FINANCE PORTFOLIO & CATCH-BACKED FINANCE
app.get("/api/finance/fund", (req, res) => {
  // Recalculate AUM and Fund allocations dynamically
  const totalLoanOutstanding = database.loans.reduce((sum, l) => sum + l.outstandingBalance, 0);
  database.marineFund.allocatedAssets.vesselsFinance = totalLoanOutstanding + 45000000; // static base + active loans
  database.marineFund.totalAUM = database.marineFund.cashReserve + 
    Object.values(database.marineFund.allocatedAssets).reduce((sum, v) => sum + v, 0);

  res.json(database.marineFund);
});

app.get("/api/finance/loans", (req, res) => {
  res.json(database.loans);
});

app.get("/api/finance/catch-backed", (req, res) => {
  res.json(database.catchLendingApps);
});

// Apply for catch-backed lines of credit
app.post("/api/finance/catch-backed", (req, res) => {
  const { vesselId, requestAmount } = req.body;
  const vessel = database.vessels.find(v => v.id === vesselId);
  if (!vessel) return res.status(404).json({ error: "Vessel not found" });

  // Calculate simulated catch history & risk scoring (R-based modeling)
  const historicalCatch30d = vessel.purchaseValue * 0.03 + (vessel.currentCatchEstimate * 4);
  const projectedCatchNext30d = historicalCatch30d * (0.85 + Math.random() * 0.3);
  
  // Calculate risk score based on outstanding finance ratios
  const leverageRatio = vessel.outstandingFinance / (vessel.purchaseValue || 1);
  const riskScore = Math.min(100, Math.floor((1 - leverageRatio) * 100 * (vessel.riskRating === 'AAA' ? 1.0 : 0.8)));

  const newApp: CatchBackedLendingApplication = {
    id: `cbl-${database.catchLendingApps.length + 1}`,
    vesselId,
    vesselName: vessel.name,
    historicalCatchValue30d: parseFloat(historicalCatch30d.toFixed(0)),
    projectedCatchValueNext30d: parseFloat(projectedCatchNext30d.toFixed(0)),
    requestAmount: Number(requestAmount),
    riskScore,
    status: "Pending",
    appliedDate: new Date().toISOString().substring(0, 10)
  };

  database.catchLendingApps.push(newApp);

  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: vessel.owner,
    action: "FINANCE_APPLY_CATCH",
    details: `Applied for catch-backed loan of £${requestAmount} for ${vessel.name}`,
    ipAddress: "192.168.1.15"
  });

  res.status(201).json(newApp);
});

// Approve/Decline catch-backed or vessel loan applications
app.post("/api/finance/catch-backed/:id/review", (req, res) => {
  const app = database.catchLendingApps.find(a => a.id === req.params.id);
  if (!app) return res.status(404).json({ error: "Application not found" });

  const { status, approvedAmount, interestRate } = req.body;

  app.status = status; // 'Approved' | 'Declined'
  if (status === "Approved") {
    app.approvedAmount = Number(approvedAmount) || app.requestAmount;
    app.interestRate = Number(interestRate) || 6.5;

    // Add this to active loans database
    const newLoan: Loan = {
      id: `loan-${Date.now()}`,
      vesselId: app.vesselId,
      vesselName: app.vesselName,
      borrowerName: "Catch-Backed Facility",
      type: "Catch-Backed Line",
      principalAmount: app.approvedAmount,
      outstandingBalance: app.approvedAmount,
      interestRatePercent: app.interestRate,
      termMonths: 3, // short term lines of credit
      monthlyPayment: parseFloat(((app.approvedAmount * (1 + (app.interestRate/100))) / 3).toFixed(0)),
      expectedAnnualRevenue: app.projectedCatchValueNext30d * 12,
      riskCategory: app.riskScore > 75 ? "Low" : app.riskScore > 50 ? "Medium" : "High",
      status: "Performing",
      startDate: new Date().toISOString().substring(0, 10)
    };

    database.loans.push(newLoan);

    // Subtract from fund cash reserve
    database.marineFund.cashReserve -= app.approvedAmount;
  }

  database.auditLogs.unshift({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actor: "sarah.jenkins",
    action: status === "Approved" ? "FINANCE_APPROVE" : "FINANCE_DECLINE",
    details: `${status} catch-backed facility of £${approvedAmount || app.requestAmount} for ${app.vesselName}`,
    ipAddress: "192.168.1.10"
  });

  res.json(app);
});

// 6. R QUANT ENGINE stress calculations
app.get("/api/risk/vessel/:id", (req, res) => {
  const vessel = database.vessels.find(v => v.id === req.params.id);
  if (!vessel) return res.status(404).json({ error: "Vessel not found" });

  const riskProfile = calculateRMonteCarloRisk(vessel);
  res.json(riskProfile);
});

// 7. RUST OPT ROUTING LOGISTICS
app.post("/api/logistics/optimize", (req, res) => {
  const { originPort, destination } = req.body;
  const optimizedRoute = runRustLogisticsOptimization(originPort, destination);
  res.json(optimizedRoute);
});

// 8. SUSTAINABILITY METRICS
app.get("/api/sustainability", (req, res) => {
  res.json(database.sustainability);
});

// 9. AUDIT LOGS
app.get("/api/audit-logs", (req, res) => {
  res.json(database.auditLogs);
});


// ==========================================
// REAL-TIME AIS TELEMETRY SIMULATOR LOGS
// ==========================================

// Run simple telemetry updating interval (representing the live ingest pipeline)
setInterval(() => {
  database.vessels.forEach(v => {
    if (v.status === "Fishing" || v.status === "At Sea") {
      // Deplete fuel slightly
      v.fuelLevelPercent = Math.max(10, parseFloat((v.fuelLevelPercent - (0.05 + Math.random() * 0.08)).toFixed(2)));
      
      // Accumulate catches slightly
      v.currentCatchEstimate = Math.min(65000, Math.floor(v.currentCatchEstimate + (50 + Math.random() * 350)));

      // Simulate movement latitude/longitude
      v.latitude = parseFloat((v.latitude + (Math.random() * 0.004 - 0.002)).toFixed(5));
      v.longitude = parseFloat((v.longitude + (Math.random() * 0.004 - 0.002)).toFixed(5));
      
      // Update heading slightly
      if (Math.random() > 0.7) {
        v.heading = Math.floor((v.heading + (Math.random() * 30 - 15) + 360) % 360);
      }
    }
  });
}, 8000);


// ==========================================
// VITE AND DEVELOPMENT DEV SETUP MIDDLEWARE
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Rhino Bank Fisheries Core running on http://localhost:${PORT}`);
  });
}

startServer();
