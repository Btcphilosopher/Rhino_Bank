import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Anchor,
  TrendingUp,
  Package,
  Layers,
  ArrowRight,
  Calculator,
  Shield,
  Activity,
  User,
  Cpu,
  MapPin,
  Clock,
  Compass,
  FileText,
  DollarSign,
  AlertTriangle,
  Award,
  RefreshCw,
  Search,
  CheckCircle2,
  Plus,
  ArrowUpRight,
  Database,
  Truck,
  Flame,
  Globe,
  Settings,
  HelpCircle,
  FileSpreadsheet
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  LineChart,
  Line,
  Cell,
  PieChart,
  Pie
} from "recharts";

import {
  UserRole,
  Vessel,
  FishInventoryItem,
  RFQ,
  RFQResponse,
  CommodityMarket,
  Loan,
  CatchBackedLendingApplication,
  MarineFund,
  VesselRiskAnalysis,
  LogisticsOptimisationRoute,
  SustainabilityMetrics,
  AuditLog
} from "./types";
import TerminalLogs from "./components/TerminalLogs";
import AIConsultant from "./components/AIConsultant";

// Ports database for maps & logistics
const PORTS = [
  { name: "Scarborough", lat: 54.284, lng: -0.396, color: "#38bdf8" },
  { name: "Whitby", lat: 54.486, lng: -0.614, color: "#22d3ee" },
  { name: "Bridlington", lat: 54.084, lng: -0.183, color: "#34d399" },
  { name: "Hull", lat: 53.744, lng: -0.336, color: "#f472b6" }
];

export default function App() {
  // Current active user role in Bloomberg frame
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>("Rhino Bank Analyst");
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // State synchronized from full-stack backend
  const [vessels, setVessels] = useState<Vessel[]>([]);
  const [inventory, setInventory] = useState<FishInventoryItem[]>([]);
  const [markets, setMarkets] = useState<CommodityMarket[]>([]);
  const [rfqs, setRfqs] = useState<RFQ[]>([]);
  const [fund, setFund] = useState<MarineFund | null>(null);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [catchApps, setCatchApps] = useState<CatchBackedLendingApplication[]>([]);
  const [sustainability, setSustainability] = useState<SustainabilityMetrics | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // Ticker simulation settings
  const [fuelCosts, setFuelCosts] = useState(1.18);
  const [weatherSeverity, setWeatherSeverity] = useState(0.2);
  const [seasonalityIndex, setSeasonalityIndex] = useState(0.5);
  const [simulatingTicker, setSimulatingTicker] = useState(false);

  // Active vessel selected for detailed risk Monte Carlo scoring
  const [selectedRiskVesselId, setSelectedRiskVesselId] = useState<string>("v-1");
  const [vesselRiskProfile, setVesselRiskProfile] = useState<VesselRiskAnalysis | null>(null);
  const [loadingRiskProfile, setLoadingRiskProfile] = useState(false);

  // Logistics optimization calculator
  const [logisticsOrigin, setLogisticsOrigin] = useState("Scarborough");
  const [logisticsDestination, setLogisticsDestination] = useState("Leeds");
  const [optimizedRoute, setOptimizedRoute] = useState<LogisticsOptimisationRoute | null>(null);
  const [calculatingRoute, setCalculatingRoute] = useState(false);

  // Forms / Actions state
  const [registeringVessel, setRegisteringVessel] = useState(false);
  const [newVesselForm, setNewVesselForm] = useState({
    name: "",
    owner: "",
    captain: "",
    port: "Scarborough" as Vessel['port'],
    purchaseValue: 1800000,
    outstandingFinance: 1100000,
    engineHp: 950,
    crewCount: 6
  });

  const [landingCatch, setLandingCatch] = useState(false);
  const [newCatchForm, setNewCatchForm] = useState({
    species: "Cod" as FishInventoryItem['species'],
    weightKg: 800,
    fishingVesselId: "v-1",
    landingPort: "Scarborough" as FishInventoryItem['landingPort'],
    qualityGrade: "Premium (A+)" as FishInventoryItem['qualityGrade']
  });

  const [creatingRFQ, setCreatingRFQ] = useState(false);
  const [newRFQForm, setNewRFQForm] = useState({
    species: "Cod" as FishInventoryItem['species'],
    quantityRequiredKg: 500,
    frequency: "Weekly" as RFQ['frequency'],
    deliveryDate: "2026-08-08",
    qualityRequired: "Premium (A+)" as RFQ['qualityRequired']
  });

  const [applyingCatchFinance, setApplyingCatchFinance] = useState(false);
  const [catchFinanceForm, setCatchFinanceForm] = useState({
    vesselId: "v-1",
    requestAmount: 50000
  });

  // Fetch full data from APIs on load
  const loadBackendData = async () => {
    try {
      const [vRes, iRes, mRes, rRes, fRes, lRes, cRes, sRes, aRes] = await Promise.all([
        fetch("/api/vessels"),
        fetch("/api/inventory"),
        fetch("/api/market"),
        fetch("/api/procurement/rfqs"),
        fetch("/api/finance/fund"),
        fetch("/api/finance/loans"),
        fetch("/api/finance/catch-backed"),
        fetch("/api/sustainability"),
        fetch("/api/audit-logs")
      ]);

      setVessels(await vRes.json());
      setInventory(await iRes.json());
      setMarkets(await mRes.json());
      setRfqs(await rRes.json());
      setFund(await fRes.json());
      setLoans(await lRes.json());
      setCatchApps(await cRes.json());
      setSustainability(await sRes.json());
      setAuditLogs(await aRes.json());
    } catch (e) {
      console.error("Error loading terminal datasets from backend:", e);
    }
  };

  useEffect(() => {
    loadBackendData();
    // Fast telemetry poll
    const interval = setInterval(() => {
      loadBackendData();
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Recalculate credit scoring whenever selected risk vessel changes
  useEffect(() => {
    const fetchRiskProfile = async () => {
      if (!selectedRiskVesselId) return;
      setLoadingRiskProfile(true);
      try {
        const res = await fetch(`/api/risk/vessel/${selectedRiskVesselId}`);
        if (res.ok) {
          setVesselRiskProfile(await res.json());
        }
      } catch (e) {
        console.error("Error fetching risk scorecard:", e);
      } finally {
        setLoadingRiskProfile(false);
      }
    };
    fetchRiskProfile();
  }, [selectedRiskVesselId, vessels]);

  // Run logistics optimization on select changes
  const runLogisticsCalc = async () => {
    setCalculatingRoute(true);
    try {
      const res = await fetch("/api/logistics/optimize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ originPort: logisticsOrigin, destination: logisticsDestination })
      });
      if (res.ok) {
        setOptimizedRoute(await res.json());
      }
    } catch (e) {
      console.error("Logistics routing engine failed:", e);
    } finally {
      setCalculatingRoute(false);
    }
  };

  useEffect(() => {
    runLogisticsCalc();
  }, [logisticsOrigin, logisticsDestination]);

  // Trigger ARIMA Price Ticker Forecasts in Backend R Engine
  const triggerARIMATickerSim = async () => {
    setSimulatingTicker(true);
    try {
      const res = await fetch("/api/market/simulate-ticker", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fuelCosts, weatherSeverity, seasonalityIndex })
      });
      if (res.ok) {
        setMarkets(await res.json());
      }
    } catch (e) {
      console.error("ARIMA R engine simulation failed:", e);
    } finally {
      setSimulatingTicker(false);
    }
  };

  // Submit new vessel
  const handleRegisterVessel = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/vessels", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newVesselForm)
      });
      if (res.ok) {
        setRegisteringVessel(false);
        loadBackendData();
      }
    } catch (e) {
      console.error("Vessel registry error:", e);
    }
  };

  // Land new catches
  const handleLandCatch = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newCatchForm)
      });
      if (res.ok) {
        setLandingCatch(false);
        loadBackendData();
      }
    } catch (e) {
      console.error("Catch landing registry error:", e);
    }
  };

  // Purchase/Reserve stock
  const handlePurchaseStock = async (itemId: string, reserveOnly: boolean) => {
    const user = databaseSimUser();
    try {
      const res = await fetch(`/api/inventory/${itemId}/purchase`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          buyerId: user.id,
          buyerName: user.name,
          reserveOnly
        })
      });
      if (res.ok) {
        loadBackendData();
      }
    } catch (e) {
      console.error("Wholesale purchasing execution error:", e);
    }
  };

  // Create new RFQ
  const handleCreateRFQ = async (e: React.FormEvent) => {
    e.preventDefault();
    const user = databaseSimUser();
    try {
      const res = await fetch("/api/procurement/rfqs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          buyerId: user.id,
          buyerName: user.name,
          ...newRFQForm
        })
      });
      if (res.ok) {
        setCreatingRFQ(false);
        loadBackendData();
      }
    } catch (e) {
      console.error("Procurement RFQ registration failed:", e);
    }
  };

  // Bid / Respond on RFQ
  const handleRespondToRFQ = async (rfqId: string, supplierPrice: number) => {
    try {
      const res = await fetch(`/api/procurement/rfqs/${rfqId}/respond`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          supplierId: "v-1",
          supplierName: "FV Yorkshire Enterprise",
          pricePerKg: supplierPrice,
          notes: "Premium hook-and-line. Direct from Scarborough docks."
        })
      });
      if (res.ok) {
        loadBackendData();
      }
    } catch (e) {
      console.error("Bid response failed:", e);
    }
  };

  // Accept RFQ Bid
  const handleAcceptRFQBid = async (rfqId: string, bidId: string) => {
    try {
      const res = await fetch(`/api/procurement/rfqs/${rfqId}/responses/${bidId}/accept`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      if (res.ok) {
        loadBackendData();
      }
    } catch (e) {
      console.error("Bid accept transaction failed:", e);
    }
  };

  // Apply catch-backed line of credit
  const handleApplyCatchLending = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/finance/catch-backed", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(catchFinanceForm)
      });
      if (res.ok) {
        setApplyingCatchFinance(false);
        loadBackendData();
      }
    } catch (e) {
      console.error("Catch backed landing credit application error:", e);
    }
  };

  // Review (Approve/Reject) catch line of credit
  const handleReviewCatchLending = async (appId: string, status: 'Approved' | 'Declined', approvedAmount: number) => {
    try {
      const res = await fetch(`/api/finance/catch-backed/${appId}/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          approvedAmount,
          interestRate: 6.2
        })
      });
      if (res.ok) {
        loadBackendData();
      }
    } catch (e) {
      console.error("Review appraisal transaction failed:", e);
    }
  };

  // Helper matching state-based names
  const databaseSimUser = () => {
    switch (currentUserRole) {
      case "Rhino Bank Analyst": return { id: "u-1", name: "Sarah Jenkins" };
      case "Captain": return { id: "u-2", name: "Arthur Pendelton" };
      case "Fishing Vessel Owner": return { id: "u-3", name: "Thomas Cobble" };
      case "Buyer": return { id: "u-4", name: "Marco Pierre" };
      case "Supplier": return { id: "u-5", name: "Geoff Whitby" };
      case "Investor": return { id: "u-6", name: "Eleanor Vance" };
    }
  };

  // Executive summaries calculated dynamically
  const activeVesselsCount = vessels.filter(v => v.status !== "Maintenance").length;
  const totalAssetsFinanced = fund ? fund.allocatedAssets.vesselsFinance + fund.allocatedAssets.processingFacilities + fund.allocatedAssets.coldStorage + fund.allocatedAssets.distributionNetworks + fund.allocatedAssets.marineTech : 125500000;
  const portfolioYield = fund ? fund.irrPercent : 11.4;
  
  const getAverageRisk = () => {
    const ratings = vessels.map(v => v.riskRating);
    if (ratings.includes("CCC")) return "BB";
    if (ratings.includes("BB")) return "A";
    return "AAA";
  };

  return (
    <div id="bloomberg-frame" className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* 1. TOP EXECUTIVE BAR */}
      <header id="executive-banner" className="bg-slate-900 border-b-2 border-cyan-800/80 px-4 py-2.5 flex flex-wrap items-center justify-between gap-4 z-10">
        <div className="flex items-center gap-3">
          <div className="p-1.5 bg-cyan-950 border border-cyan-700/50 rounded text-cyan-400">
            <Anchor className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] text-cyan-500 font-mono tracking-widest block font-bold">RHINO BANK CO.</span>
            <h1 className="text-sm font-bold tracking-tight text-slate-100 font-mono">FISHERIES EXCHANGE TERMINAL</h1>
          </div>
        </div>

        {/* Dynamic portfolio summaries */}
        <div className="flex items-center gap-6 overflow-x-auto py-1">
          <div className="border-l border-slate-800 pl-4">
            <span className="text-[9px] text-slate-400 font-mono uppercase block">Total Financed Assets</span>
            <span className="text-sm font-bold text-slate-100 font-mono">£{(totalAssetsFinanced / 1e6).toFixed(1)}M</span>
          </div>
          <div className="border-l border-slate-800 pl-4">
            <span className="text-[9px] text-slate-400 font-mono uppercase block">Active Fleets</span>
            <span className="text-sm font-bold text-cyan-400 font-mono">{activeVesselsCount} / {vessels.length}</span>
          </div>
          <div className="border-l border-slate-800 pl-4">
            <span className="text-[9px] text-slate-400 font-mono uppercase block">Annual Landings</span>
            <span className="text-sm font-bold text-slate-100 font-mono">3,240T</span>
          </div>
          <div className="border-l border-slate-800 pl-4">
            <span className="text-[9px] text-slate-400 font-mono uppercase block">Portfolio Yield (IRR)</span>
            <span className="text-sm font-bold text-emerald-400 font-mono">{portfolioYield}%</span>
          </div>
          <div className="border-l border-slate-800 pl-4">
            <span className="text-[9px] text-slate-400 font-mono uppercase block">Avg Credit Risk</span>
            <span className="text-sm font-bold text-slate-100 font-mono flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-blue-400" />
              {getAverageRisk()}
            </span>
          </div>
          <div className="border-l border-slate-800 pl-4">
            <span className="text-[9px] text-slate-400 font-mono uppercase block">Market Trend</span>
            <span className="text-sm font-bold text-amber-400 font-mono">Bullish (ARIMA)</span>
          </div>
        </div>

        {/* Role Selector & Fast Refresh */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-2 py-1 rounded">
            <User className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[10px] text-slate-400 font-mono uppercase">User Role:</span>
            <select
              value={currentUserRole}
              onChange={(e) => {
                setCurrentUserRole(e.target.value as UserRole);
                loadBackendData();
              }}
              className="bg-transparent border-none text-[11px] font-mono text-cyan-400 font-bold focus:outline-none cursor-pointer"
            >
              <option value="Rhino Bank Analyst">Rhino Bank Analyst</option>
              <option value="Fishing Vessel Owner">Vessel Owner</option>
              <option value="Captain">Fleet Captain</option>
              <option value="Buyer">B2B Buyer</option>
              <option value="Supplier">Co-op Supplier</option>
              <option value="Investor">Rhino Investor</option>
            </select>
          </div>

          <button
            onClick={loadBackendData}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded transition-colors"
            title="Refresh Terminal Data"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* 2. MAIN WORKSPACE WITH SIDEBAR */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        
        {/* LEFT BAR NAVIGATION - BLOOMBERG INDEX */}
        <nav id="bloomberg-sidebar" className="w-full md:w-56 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0 justify-between">
          <div className="p-3 space-y-1 overflow-y-auto">
            <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block px-2 mb-2 font-mono">EXCHANGE PORTFOLIOS</span>
            
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "dashboard" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <TrendingUp className="w-4 h-4 text-cyan-500" />
              <span>[01] EXECUTIVE BOARD</span>
            </button>

            <button
              onClick={() => setActiveTab("fleet")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "fleet" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <Anchor className="w-4 h-4 text-blue-400" />
              <span>[02] VESSEL FLEET</span>
            </button>

            <button
              onClick={() => setActiveTab("market")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "market" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <Activity className="w-4 h-4 text-amber-500" />
              <span>[03] FISH EXCHANGE</span>
            </button>

            <button
              onClick={() => setActiveTab("inventory")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "inventory" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <Package className="w-4 h-4 text-emerald-500" />
              <span>[04] CATCH STORAGE</span>
            </button>

            <button
              onClick={() => setActiveTab("procurement")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "procurement" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <Layers className="w-4 h-4 text-purple-500" />
              <span>[05] B2B PROCUREMENT</span>
            </button>

            <button
              onClick={() => setActiveTab("finance")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "finance" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>[06] VESSEL FINANCE</span>
            </button>

            <button
              onClick={() => setActiveTab("risk")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "risk" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <Calculator className="w-4 h-4 text-red-500" />
              <span>[07] R RISK ENGINE</span>
            </button>

            <button
              onClick={() => setActiveTab("analytics")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "analytics" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>[08] COLDCHAIN & AI</span>
            </button>

            <button
              onClick={() => setActiveTab("sustainability")}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all text-left ${activeTab === "sustainability" ? "bg-cyan-950 text-cyan-400 font-bold border-l-2 border-cyan-500 rounded-l-none" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}`}
            >
              <Globe className="w-4 h-4 text-teal-400" />
              <span>[09] SUSTAINABILITY ESG</span>
            </button>

            <div className="border-t border-slate-800 my-4 pt-3">
              <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block px-2 mb-2 font-mono">DATABASE DIAGNOSTICS</span>
              <button
                onClick={() => setActiveTab("audit")}
                className={`w-full flex items-center gap-2 px-3 py-1.5 rounded text-[11px] font-mono transition-all text-left ${activeTab === "audit" ? "bg-slate-800 text-slate-200 font-bold" : "text-slate-500 hover:bg-slate-800 hover:text-slate-300"}`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-slate-400" />
                <span>LEDGER TRANSACTION AUDIT</span>
              </button>
            </div>
          </div>

          <div className="p-3 bg-slate-950 border-t border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
              <span>SYSTEM: ONLINE</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            </div>
            <p className="text-[10px] text-slate-500 font-mono leading-relaxed">
              Dijkstra routing and R stress matrices compile synchronously on click.
            </p>
          </div>
        </nav>

        {/* CENTER CONTENT FRAME - TAB DISPATCH */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 bg-slate-950 flex flex-col justify-between">
          <div className="flex-1">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.15 }}
                className="space-y-6"
              >

                {/* ===================================== */}
                {/* [01] TAB: EXECUTIVE BOARD (DASHBOARD) */}
                {/* ===================================== */}
                {activeTab === "dashboard" && (
                  <div className="space-y-6">
                    {/* Welcome Banner */}
                    <div className="bg-gradient-to-r from-slate-900 to-cyan-950/40 border border-slate-800 p-5 rounded-lg flex items-center justify-between">
                      <div>
                        <h2 className="text-xl font-bold tracking-tight text-slate-100 font-mono">RHINO BANK FISHERIES EXECUTIVE WORKSPACE</h2>
                        <p className="text-xs text-slate-400 mt-1 font-mono">
                          Synchronizing fleet performance, live seafood auctions, automated credit assessments, and logistics dispatchers.
                        </p>
                      </div>
                      <div className="hidden lg:flex items-center gap-3">
                        <div className="text-right font-mono">
                          <span className="text-[10px] text-slate-500 block">LOCAL TIME ZONE</span>
                          <span className="text-xs font-semibold text-cyan-400">YORKSHIRE, UK (BST)</span>
                        </div>
                      </div>
                    </div>

                    {/* Executive Analytics Section */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      
                      {/* Fund Distribution Pie Chart */}
                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                        <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider mb-4">RHINO MARINE GROWTH FUND ALLOCATIONS</h3>
                        <div className="h-[180px] flex items-center justify-center">
                          {fund ? (
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie
                                  data={[
                                    { name: "Fleet Financing", value: fund.allocatedAssets.vesselsFinance },
                                    { name: "Cold Storage Chain", value: fund.allocatedAssets.coldStorage },
                                    { name: "Processing Hubs", value: fund.allocatedAssets.processingFacilities },
                                    { name: "Distribution Networks", value: fund.allocatedAssets.distributionNetworks },
                                    { name: "Marine Tech/AI", value: fund.allocatedAssets.marineTech }
                                  ]}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={50}
                                  outerRadius={75}
                                  paddingAngle={3}
                                  dataKey="value"
                                >
                                  <Cell fill="#0ea5e9" />
                                  <Cell fill="#10b981" />
                                  <Cell fill="#a855f7" />
                                  <Cell fill="#f43f5e" />
                                  <Cell fill="#eab308" />
                                </Pie>
                                <Tooltip formatter={(value: any) => `£${(value / 1e6).toFixed(1)}M`} />
                              </PieChart>
                            </ResponsiveContainer>
                          ) : (
                            <span className="text-xs font-mono text-slate-600">Awaiting allocations...</span>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-2 mt-2 text-[10px] font-mono text-slate-400">
                          <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded bg-sky-500"></span> Fleet Finance (50%)</div>
                          <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded bg-emerald-500"></span> Cold Storage (11%)</div>
                          <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded bg-purple-500"></span> Processing (19%)</div>
                          <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded bg-rose-500"></span> Logistics (5%)</div>
                        </div>
                      </div>

                      {/* Fleet Operations Overview List */}
                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 col-span-2">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">ACTIVE FLEETS TELEMETRY MONITOR</h3>
                          <button onClick={() => setActiveTab("fleet")} className="text-[10px] text-cyan-400 font-mono flex items-center gap-1 hover:underline">
                            DETAILED AIS TRACKING <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-xs font-mono">
                            <thead>
                              <tr className="border-b border-slate-800 text-slate-500 pb-2">
                                <th className="pb-2">VESSEL</th>
                                <th className="pb-2">HOME PORT</th>
                                <th className="pb-2">STATUS</th>
                                <th className="pb-2 text-right">FUEL</th>
                                <th className="pb-2 text-right">EST. CATCH VALUE</th>
                                <th className="pb-2 text-center">RISK</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800/60">
                              {vessels.map(v => (
                                <tr key={v.id} className="hover:bg-slate-950/40">
                                  <td className="py-2.5 font-bold text-slate-200">{v.name}</td>
                                  <td className="py-2.5 text-slate-400">{v.port}</td>
                                  <td className="py-2.5">
                                    <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                                      v.status === "Fishing" ? "bg-amber-950/40 text-amber-400 border border-amber-900/30" :
                                      v.status === "At Sea" ? "bg-cyan-950/40 text-cyan-400 border border-cyan-900/30" :
                                      v.status === "In Port" ? "bg-slate-950/40 text-slate-400 border border-slate-800" :
                                      "bg-red-950/40 text-red-400 border border-red-900/30"
                                    }`}>
                                      {v.status}
                                    </span>
                                  </td>
                                  <td className="py-2.5 text-right font-semibold">{v.fuelLevelPercent}%</td>
                                  <td className="py-2.5 text-right text-emerald-400 font-bold">£{v.currentCatchEstimate.toLocaleString()}</td>
                                  <td className="py-2.5 text-center">
                                    <span className={`px-1 rounded font-bold ${
                                      v.riskRating === 'AAA' ? "text-emerald-400" :
                                      v.riskRating === 'AA' ? "text-cyan-400" :
                                      v.riskRating === 'A' ? "text-blue-400" : "text-amber-500"
                                    }`}>{v.riskRating}</span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>

                    {/* Commodity Quick ticker grids */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      {markets.map(m => (
                        <div key={m.species} className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-col justify-between">
                          <div className="flex items-center justify-between text-xs font-mono">
                            <span className="font-bold text-slate-200">{m.species} EXCHANGE</span>
                            <span className={m.change24hPercent >= 0 ? "text-emerald-400" : "text-red-400"}>
                              {m.change24hPercent >= 0 ? "+" : ""}{m.change24hPercent}%
                            </span>
                          </div>
                          <div className="my-2.5">
                            <span className="text-xl font-bold font-mono text-slate-100">£{m.currentPricePerKg.toFixed(2)}<span className="text-[10px] text-slate-500">/kg</span></span>
                          </div>
                          <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
                            <span>Supply: {m.supplyLevel}</span>
                            <span>Demand: {m.demandLevel}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}


                {/* ===================================== */}
                {/* [02] TAB: FLEET MANAGEMENT SYSTEM */}
                {/* ===================================== */}
                {activeTab === "fleet" && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                      <div>
                        <h2 className="text-base font-bold font-mono uppercase text-slate-200">FLEET ASSETS & RADAR TELEMETRY</h2>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">Monitoring outstanding marine finance, engine telemetry, and AIS landing estimations.</p>
                      </div>
                      
                      {currentUserRole === "Rhino Bank Analyst" || currentUserRole === "Fishing Vessel Owner" ? (
                        <button
                          onClick={() => setRegisteringVessel(true)}
                          className="px-3 py-1.5 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-400 text-xs font-mono font-bold rounded flex items-center gap-1.5 transition-all"
                        >
                          <Plus className="w-4 h-4" /> REGISTER NEW VESSEL ASSET
                        </button>
                      ) : null}
                    </div>

                    {/* AIS Tactical Vector Map Simulation & Details */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      
                      {/* Interactive Radar Visualizer */}
                      <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                          <span className="text-xs font-bold text-slate-300 font-mono uppercase flex items-center gap-1.5">
                            <Activity className="w-3.5 h-3.5 text-cyan-400" /> Yorkshire Coast AIS Tactical Display
                          </span>
                          <span className="text-[10px] font-mono text-slate-500">BOUNDS: NORTH SEA GRID</span>
                        </div>

                        {/* Styled Radar Map Canvas */}
                        <div className="h-[280px] bg-slate-950 border border-slate-800/80 rounded relative overflow-hidden flex items-center justify-center shadow-inner">
                          {/* Radial radar scanning ring visual */}
                          <div className="absolute w-64 h-64 border border-cyan-900/10 rounded-full animate-ping"></div>
                          <div className="absolute w-44 h-44 border border-cyan-900/20 rounded-full"></div>
                          <div className="absolute w-24 h-24 border border-cyan-900/30 rounded-full"></div>
                          
                          {/* Axis lines */}
                          <div className="absolute inset-y-0 w-px bg-cyan-900/20"></div>
                          <div className="absolute inset-x-0 h-px bg-cyan-900/20"></div>

                          {/* Scarborough Port Label */}
                          <div className="absolute left-1/2 bottom-1/4 -translate-x-1/2 flex flex-col items-center">
                            <MapPin className="w-3 h-3 text-sky-400" />
                            <span className="text-[8px] font-mono text-sky-300 uppercase tracking-widest mt-0.5">Scarborough Port</span>
                          </div>

                          {/* Whitby Port Label */}
                          <div className="absolute left-1/3 top-1/4 flex flex-col items-center">
                            <MapPin className="w-3 h-3 text-cyan-400" />
                            <span className="text-[8px] font-mono text-cyan-300 uppercase tracking-widest mt-0.5">Whitby Port</span>
                          </div>

                          {/* Floating Simulating Vessels */}
                          {vessels.map((v, idx) => {
                            // Scale coordinates slightly to sit inside our visual box
                            const leftPos = `${35 + (idx * 12)}%`;
                            const topPos = `${40 + (Math.sin(idx) * 20)}%`;
                            return (
                              <div
                                key={v.id}
                                style={{ left: leftPos, top: topPos }}
                                className="absolute flex flex-col items-center cursor-pointer group"
                                onClick={() => setSelectedRiskVesselId(v.id)}
                              >
                                <Compass className="w-4 h-4 text-amber-500 animate-spin-slow hover:scale-125 transition-transform" />
                                <span className="absolute bg-slate-900/90 border border-slate-800 text-slate-200 text-[8px] font-mono rounded px-1 -top-6 whitespace-nowrap opacity-75 group-hover:opacity-100 transition-opacity">
                                  {v.name} ({v.speedKnots}kts)
                                </span>
                              </div>
                            );
                          })}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono mt-2.5">
                          Vectors update on 8000ms ping frequency. Interactive: click vessel dots to compute quantitative risk scorecard in tab [07].
                        </div>
                      </div>

                      {/* Detailed Registry Information of Fleet */}
                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
                        <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">VESSEL REGISTRY PROFILE</h3>
                        
                        <div className="space-y-3 max-h-[300px] overflow-y-auto">
                          {vessels.map(v => (
                            <div
                              key={v.id}
                              onClick={() => setSelectedRiskVesselId(v.id)}
                              className={`p-3 rounded border text-xs font-mono transition-all cursor-pointer ${selectedRiskVesselId === v.id ? "bg-slate-950 border-cyan-800" : "bg-slate-950/40 border-slate-800 hover:bg-slate-950"}`}
                            >
                              <div className="flex items-center justify-between font-bold text-slate-200">
                                <span>{v.name}</span>
                                <span className="text-cyan-400">{v.registration}</span>
                              </div>
                              <div className="grid grid-cols-2 gap-2 mt-2 text-[10px] text-slate-400">
                                <div>Captain: {v.captain}</div>
                                <div>Age: {v.ageYears} yrs</div>
                                <div>Licence: {v.fishingLicence.substring(0,10)}</div>
                                <div>Crew size: {v.crewCount}</div>
                                <div className="col-span-2 font-bold text-slate-300 mt-1">Outstanding Debt: £{v.outstandingFinance.toLocaleString()}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* New Vessel Registry Form Overlay */}
                    {registeringVessel && (
                      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 w-full max-w-md font-mono text-xs">
                          <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">Register Asset & Outstanding Finance</h3>
                          <form onSubmit={handleRegisterVessel} className="space-y-3">
                            <div>
                              <label className="block text-slate-400 mb-1">Vessel Name</label>
                              <input
                                type="text"
                                required
                                placeholder="FV Yorkshire Pioneer"
                                value={newVesselForm.name}
                                onChange={e => setNewVesselForm({...newVesselForm, name: e.target.value})}
                                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-slate-400 mb-1">Owner Entity</label>
                                <input
                                  type="text"
                                  required
                                  value={newVesselForm.owner}
                                  placeholder="Marine Co-op"
                                  onChange={e => setNewVesselForm({...newVesselForm, owner: e.target.value})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                />
                              </div>
                              <div>
                                <label className="block text-slate-400 mb-1">Captain Name</label>
                                <input
                                  type="text"
                                  required
                                  value={newVesselForm.captain}
                                  placeholder="Sarah Drake"
                                  onChange={e => setNewVesselForm({...newVesselForm, captain: e.target.value})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                />
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-slate-400 mb-1">Landing Home Port</label>
                                <select
                                  value={newVesselForm.port}
                                  onChange={e => setNewVesselForm({...newVesselForm, port: e.target.value as Vessel['port']})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                >
                                  <option value="Scarborough">Scarborough</option>
                                  <option value="Whitby">Whitby</option>
                                  <option value="Bridlington">Bridlington</option>
                                  <option value="Hull">Hull</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-slate-400 mb-1">Engine Hp</label>
                                <input
                                  type="number"
                                  required
                                  value={newVesselForm.engineHp}
                                  onChange={e => setNewVesselForm({...newVesselForm, engineHp: Number(e.target.value)})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                />
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-slate-400 mb-1">Purchase Valuation (£)</label>
                                <input
                                  type="number"
                                  required
                                  value={newVesselForm.purchaseValue}
                                  onChange={e => setNewVesselForm({...newVesselForm, purchaseValue: Number(e.target.value)})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                />
                              </div>
                              <div>
                                <label className="block text-slate-400 mb-1">Finance Amount (£)</label>
                                <input
                                  type="number"
                                  required
                                  value={newVesselForm.outstandingFinance}
                                  onChange={e => setNewVesselForm({...newVesselForm, outstandingFinance: Number(e.target.value)})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                />
                              </div>
                            </div>
                            <div className="flex items-center gap-2 pt-3">
                              <button
                                type="submit"
                                className="flex-1 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-400 py-2 rounded font-bold"
                              >
                                REGISTER TO LEDGER
                              </button>
                              <button
                                type="button"
                                onClick={() => setRegisteringVessel(false)}
                                className="flex-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 py-2 rounded"
                              >
                                CANCEL
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    )}
                  </div>
                )}


                {/* ===================================== */}
                {/* [03] TAB: FISH COMMODITY MARKET */}
                {/* ===================================== */}
                {activeTab === "market" && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                      <div>
                        <h2 className="text-base font-bold font-mono uppercase text-slate-200">YORKSHIRE COMMODITY EXCHANGE TERMINAL</h2>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">R-based ARIMA seafood price forecasts, tracking fuel surges and weather disruptions.</p>
                      </div>

                      {/* ARIMA Parameters Panel */}
                      <div className="flex flex-wrap items-center gap-4 bg-slate-900 border border-slate-800 p-2.5 rounded text-xs font-mono">
                        <div>
                          <span className="text-slate-500 block text-[9px] uppercase">Fuel Cost (£/L)</span>
                          <input
                            type="number"
                            step="0.01"
                            value={fuelCosts}
                            onChange={(e) => setFuelCosts(Number(e.target.value))}
                            className="bg-slate-950 border border-slate-800 rounded p-1 w-16 text-cyan-400 font-bold focus:outline-none"
                          />
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[9px] uppercase">Weather Severity</span>
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.1"
                            value={weatherSeverity}
                            onChange={(e) => setWeatherSeverity(Number(e.target.value))}
                            className="accent-cyan-500 h-1.5 rounded cursor-pointer"
                          />
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[9px] uppercase">Seasonality Index</span>
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.1"
                            value={seasonalityIndex}
                            onChange={(e) => setSeasonalityIndex(Number(e.target.value))}
                            className="accent-cyan-500 h-1.5 rounded cursor-pointer"
                          />
                        </div>
                        <button
                          onClick={triggerARIMATickerSim}
                          disabled={simulatingTicker}
                          className="px-3 py-1.5 bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-400 font-bold rounded"
                        >
                          {simulatingTicker ? "ARIMA UPDATING..." : "SIMULATE PRICE TICK"}
                        </button>
                      </div>
                    </div>

                    {/* Charting Grid */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      
                      {/* Price History Charts (Recharts AreaChart) */}
                      <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4">
                        <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider mb-4">HISTORICAL SPOT MARKET COD PRICE & VOLUME PROJECTIONS (R-ARIMA)</h3>
                        <div className="h-[250px]">
                          {markets.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                              <AreaChart data={markets[0].historicalPrices}>
                                <defs>
                                  <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                                  </linearGradient>
                                </defs>
                                <XAxis dataKey="date" stroke="#475569" fontSize={10} fontFamily="monospace" />
                                <YAxis stroke="#475569" fontSize={10} fontFamily="monospace" />
                                <Tooltip formatter={(value: any) => `£${value}/kg`} />
                                <Area type="monotone" dataKey="price" stroke="#0ea5e9" strokeWidth={2} fillOpacity={1} fill="url(#colorPrice)" />
                              </AreaChart>
                            </ResponsiveContainer>
                          ) : null}
                        </div>
                      </div>

                      {/* Ticker Commodity lists */}
                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
                        <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">SPOT MARKET EXCHANGE QUOTES</h3>
                        
                        <div className="space-y-3 overflow-y-auto max-h-[250px]">
                          {markets.map(m => (
                            <div key={m.species} className="p-3 bg-slate-950 border border-slate-800 rounded font-mono text-xs flex items-center justify-between">
                              <div>
                                <span className="font-bold text-slate-200 block">{m.species} Exchange</span>
                                <span className="text-[10px] text-slate-500">30d R-Model Forecast: £{m.forecastPrice30d.toFixed(2)}/kg</span>
                              </div>
                              <div className="text-right">
                                <span className="text-sm font-bold text-slate-100 block">£{m.currentPricePerKg.toFixed(2)}/kg</span>
                                <span className={m.change24hPercent >= 0 ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>
                                  {m.change24hPercent >= 0 ? "▲" : "▼"} {Math.abs(m.change24hPercent)}%
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}


                {/* ===================================== */}
                {/* [04] TAB: FISH STOCK INVENTORY */}
                {/* ===================================== */}
                {activeTab === "inventory" && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                      <div>
                        <h2 className="text-base font-bold font-mono uppercase text-slate-200">REAL-TIME FISH COLD STORAGE INVENTORY</h2>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">Traceability logs, quality grades, RFID certificates, and instant procurement order triggers.</p>
                      </div>

                      {currentUserRole === "Captain" || currentUserRole === "Fishing Vessel Owner" ? (
                        <button
                          onClick={() => setLandingCatch(true)}
                          className="px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-400 text-xs font-mono font-bold rounded flex items-center gap-1.5 transition-all"
                        >
                          <Plus className="w-4 h-4" /> LAND HARVEST TO COLD STORAGE
                        </button>
                      ) : null}
                    </div>

                    {/* Stock Grid List */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {inventory.map(item => (
                        <div key={item.id} className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col justify-between font-mono text-xs">
                          <div>
                            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                              <span className="font-bold text-slate-200 uppercase">{item.species} (North Sea)</span>
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                item.qualityGrade.includes("Premium") ? "bg-cyan-950/40 text-cyan-400 border border-cyan-900/30" : "bg-slate-950 text-slate-400 border border-slate-800"
                              }`}>
                                {item.qualityGrade}
                              </span>
                            </div>

                            <div className="space-y-1.5 text-slate-400 text-[11px]">
                              <div className="flex justify-between"><span>Inventory ID:</span> <span className="text-slate-200 font-semibold">{item.id}</span></div>
                              <div className="flex justify-between"><span>Landed Quantity:</span> <span className="text-slate-100 font-bold">{item.weightKg} kg</span></div>
                              <div className="flex justify-between"><span>Landing Date:</span> <span>{item.landingDate}</span></div>
                              <div className="flex justify-between"><span>Origin Vessel:</span> <span className="text-slate-200">{item.fishingVesselName}</span></div>
                              <div className="flex justify-between"><span>Storage Vault:</span> <span className="text-slate-300">{item.storageLocation}</span></div>
                              <div className="flex justify-between"><span>RFID Certificate:</span> <span className="text-cyan-400 text-[9px]">{item.traceabilityCertificate}</span></div>
                              <div className="flex justify-between border-t border-slate-800 pt-1.5 mt-1.5">
                                <span>Wholesale spot value:</span>
                                <span className="text-emerald-400 font-bold text-xs">£{(item.weightKg * item.currentMarketPricePerKg).toLocaleString()}</span>
                              </div>
                            </div>
                          </div>

                          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                            <span className={`text-[10px] font-bold ${
                              item.buyerStatus === 'Available' ? "text-emerald-400" :
                              item.buyerStatus === 'Reserved' ? "text-amber-500 animate-pulse" : "text-slate-500"
                            }`}>
                              ● STATUS: {item.buyerStatus.toUpperCase()} {item.buyerName ? `(${item.buyerName})` : ""}
                            </span>

                            {item.buyerStatus === "Available" && currentUserRole === "Buyer" ? (
                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => handlePurchaseStock(item.id, true)}
                                  className="px-2 py-1 bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-400 text-[10px] rounded"
                                >
                                  RESERVE
                                </button>
                                <button
                                  onClick={() => handlePurchaseStock(item.id, false)}
                                  className="px-2 py-1 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-400 text-[10px] rounded font-bold"
                                >
                                  PURCHASE
                                </button>
                              </div>
                            ) : null}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* New Catch landing overlay */}
                    {landingCatch && (
                      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 w-full max-w-md font-mono text-xs">
                          <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">Record Landing Catch</h3>
                          <form onSubmit={handleLandCatch} className="space-y-3">
                            <div>
                              <label className="block text-slate-400 mb-1">Species Type</label>
                              <select
                                value={newCatchForm.species}
                                onChange={e => setNewCatchForm({...newCatchForm, species: e.target.value as FishInventoryItem['species']})}
                                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                              >
                                <option value="Cod">Cod</option>
                                <option value="Haddock">Haddock</option>
                                <option value="Lobster">Lobster</option>
                                <option value="Crab">Crab</option>
                                <option value="Skate">Skate</option>
                                <option value="Herring">Herring</option>
                                <option value="Mackerel">Mackerel</option>
                              </select>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-slate-400 mb-1">Catch Weight (kg)</label>
                                <input
                                  type="number"
                                  required
                                  value={newCatchForm.weightKg}
                                  onChange={e => setNewCatchForm({...newCatchForm, weightKg: Number(e.target.value)})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                />
                              </div>
                              <div>
                                <label className="block text-slate-400 mb-1">Landing Port</label>
                                <select
                                  value={newCatchForm.landingPort}
                                  onChange={e => setNewCatchForm({...newCatchForm, landingPort: e.target.value as FishInventoryItem['landingPort']})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                >
                                  <option value="Scarborough">Scarborough</option>
                                  <option value="Whitby">Whitby</option>
                                  <option value="Bridlington">Bridlington</option>
                                  <option value="Hull">Hull</option>
                                </select>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-slate-400 mb-1">Harvesting Vessel</label>
                                <select
                                  value={newCatchForm.fishingVesselId}
                                  onChange={e => setNewCatchForm({...newCatchForm, fishingVesselId: e.target.value})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                >
                                  {vessels.map(v => (
                                    <option key={v.id} value={v.id}>{v.name}</option>
                                  ))}
                                </select>
                              </div>
                              <div>
                                <label className="block text-slate-400 mb-1">Quality Grade</label>
                                <select
                                  value={newCatchForm.qualityGrade}
                                  onChange={e => setNewCatchForm({...newCatchForm, qualityGrade: e.target.value as FishInventoryItem['qualityGrade']})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                >
                                  <option value="Premium (A+)">Premium (A+)</option>
                                  <option value="Standard (A)">Standard (A)</option>
                                  <option value="Processing (B)">Processing (B)</option>
                                </select>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 pt-3">
                              <button
                                type="submit"
                                className="flex-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-400 py-2 rounded font-bold"
                              >
                                CONFIRM PORT LANDING
                              </button>
                              <button
                                type="button"
                                onClick={() => setLandingCatch(false)}
                                className="flex-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 py-2 rounded"
                              >
                                CANCEL
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    )}
                  </div>
                )}


                {/* ===================================== */}
                {/* [05] TAB: B2B PROCUREMENT MARKETPLACE */}
                {/* ===================================== */}
                {activeTab === "procurement" && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                      <div>
                        <h2 className="text-base font-bold font-mono uppercase text-slate-200">B2B WHOLESALE SEAFOOD PROCUREMENT PORTAL</h2>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">Commercial wholesale buyers place supply RFQs. Cooperatives and vessels submit instant pricing bids.</p>
                      </div>

                      {currentUserRole === "Buyer" ? (
                        <button
                          onClick={() => setCreatingRFQ(true)}
                          className="px-3 py-1.5 bg-purple-950 hover:bg-purple-900 border border-purple-800 text-purple-400 text-xs font-mono font-bold rounded flex items-center gap-1.5 transition-all"
                        >
                          <Plus className="w-4 h-4" /> EMIT COMMODITY SUPPLY RFQ
                        </button>
                      ) : null}
                    </div>

                    {/* RFQ Directory */}
                    <div className="space-y-6">
                      {rfqs.map(rfq => (
                        <div key={rfq.id} className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono text-xs">
                          <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 mb-4 gap-2">
                            <div className="flex items-center gap-3">
                              <span className="font-bold text-slate-200 text-sm">RFQ: {rfq.quantityRequiredKg}kg {rfq.species} (Weekly Contract)</span>
                              <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                                rfq.status === "Open" ? "bg-cyan-950/40 text-cyan-400 border border-cyan-800/40" : "bg-slate-950 text-slate-500 border border-slate-800"
                              }`}>{rfq.status.toUpperCase()}</span>
                            </div>
                            <div className="text-slate-500 text-[11px]">
                              Emit Entity: {rfq.buyerName} | Delivery Target: {rfq.deliveryDate}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            
                            {/* RFQ Details */}
                            <div className="bg-slate-950/50 p-3 rounded border border-slate-800/60 leading-relaxed text-slate-400">
                              <p className="font-bold text-slate-300 uppercase tracking-wider text-[10px] mb-2 border-b border-slate-900 pb-1">Contract Parameters</p>
                              <p>Requested Quality: <span className="text-slate-200">{rfq.qualityRequired}</span></p>
                              <p>Supply Interval: <span className="text-slate-200">{rfq.frequency}</span></p>
                              <p>Published On: <span>{rfq.createdAt}</span></p>
                            </div>

                            {/* RFQ Active Bid List */}
                            <div className="lg:col-span-2 space-y-2">
                              <p className="font-bold text-slate-300 uppercase tracking-wider text-[10px] border-b border-slate-800 pb-1">Supplier Bid Responses ({rfq.responses.length})</p>
                              
                              {rfq.responses.length === 0 ? (
                                <p className="text-slate-600 text-[11px] py-4">Awaiting wholesale bids from Yorkshire co-ops...</p>
                              ) : (
                                rfq.responses.map(resp => (
                                  <div key={resp.id} className="bg-slate-950 p-3 border border-slate-800/80 rounded flex flex-wrap items-center justify-between gap-4">
                                    <div>
                                      <div className="flex items-center gap-2">
                                        <span className="font-bold text-slate-200">{resp.supplierName}</span>
                                        <span className="text-[9px] text-cyan-400 bg-cyan-950/30 px-1 rounded">{resp.qualityCertificate}</span>
                                      </div>
                                      <p className="text-slate-400 text-[10px] mt-0.5 italic">"{resp.notes}"</p>
                                    </div>
                                    <div className="flex items-center gap-4">
                                      <div className="text-right">
                                        <span className="text-xs font-bold text-slate-100 block">£{resp.pricePerKg.toFixed(2)}/kg</span>
                                        <span className="text-[10px] text-slate-500">Total Contract: £{(rfq.quantityRequiredKg * resp.pricePerKg).toLocaleString()}</span>
                                      </div>

                                      {rfq.status === "Open" && currentUserRole === "Buyer" && rfq.buyerName === databaseSimUser().name ? (
                                        <button
                                          onClick={() => handleAcceptRFQBid(rfq.id, resp.id)}
                                          className="px-2.5 py-1.5 bg-purple-950 hover:bg-purple-900 border border-purple-800 text-purple-400 rounded text-[11px] font-bold"
                                        >
                                          ACCEPT CONTRACT
                                        </button>
                                      ) : (
                                        <span className={`text-[11px] font-bold ${
                                          resp.status === "Accepted" ? "text-emerald-400" : "text-slate-500"
                                        }`}>{resp.status.toUpperCase()}</span>
                                      )}
                                    </div>
                                  </div>
                                ))
                              )}

                              {/* Let Supplier/Captain bid on open RFQs */}
                              {rfq.status === "Open" && (currentUserRole === "Supplier" || currentUserRole === "Captain") ? (
                                <div className="bg-slate-950/40 border border-dashed border-slate-800 p-3 rounded flex items-center justify-between gap-4">
                                  <span className="text-[11px] text-slate-400">Bid hook-and-line premium fresh catch:</span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-slate-400">£</span>
                                    <input
                                      type="number"
                                      step="0.05"
                                      defaultValue={7.85}
                                      id={`bid-price-${rfq.id}`}
                                      className="bg-slate-950 border border-slate-800 rounded px-1.5 py-1 w-16 text-cyan-400"
                                    />
                                    <span className="text-slate-400">/kg</span>
                                    <button
                                      onClick={() => {
                                        const el = document.getElementById(`bid-price-${rfq.id}`) as HTMLInputElement;
                                        handleRespondToRFQ(rfq.id, Number(el.value));
                                      }}
                                      className="px-3 py-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-400 font-bold rounded"
                                    >
                                      SUBMIT BID
                                    </button>
                                  </div>
                                </div>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* New RFQ overlay */}
                    {creatingRFQ && (
                      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 w-full max-w-md font-mono text-xs">
                          <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">Emit Seafood RFQ</h3>
                          <form onSubmit={handleCreateRFQ} className="space-y-3">
                            <div>
                              <label className="block text-slate-400 mb-1">Target Species</label>
                              <select
                                value={newRFQForm.species}
                                onChange={e => setNewRFQForm({...newRFQForm, species: e.target.value as FishInventoryItem['species']})}
                                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                              >
                                <option value="Cod">Cod</option>
                                <option value="Haddock">Haddock</option>
                                <option value="Lobster">Lobster</option>
                                <option value="Crab">Crab</option>
                                <option value="Skate">Skate</option>
                                <option value="Herring">Herring</option>
                                <option value="Mackerel">Mackerel</option>
                              </select>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-slate-400 mb-1">Requested kg</label>
                                <input
                                  type="number"
                                  required
                                  value={newRFQForm.quantityRequiredKg}
                                  onChange={e => setNewRFQForm({...newRFQForm, quantityRequiredKg: Number(e.target.value)})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                />
                              </div>
                              <div>
                                <label className="block text-slate-400 mb-1">Supply Frequency</label>
                                <select
                                  value={newRFQForm.frequency}
                                  onChange={e => setNewRFQForm({...newRFQForm, frequency: e.target.value as RFQ['frequency']})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                >
                                  <option value="Weekly">Weekly Contract</option>
                                  <option value="Bi-weekly">Bi-weekly Contract</option>
                                  <option value="Once-off">Once-off Supply</option>
                                </select>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-slate-400 mb-1">Target Delivery</label>
                                <input
                                  type="date"
                                  required
                                  value={newRFQForm.deliveryDate}
                                  onChange={e => setNewRFQForm({...newRFQForm, deliveryDate: e.target.value})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                />
                              </div>
                              <div>
                                <label className="block text-slate-400 mb-1">Quality Grade Required</label>
                                <select
                                  value={newRFQForm.qualityRequired}
                                  onChange={e => setNewRFQForm({...newRFQForm, qualityRequired: e.target.value as FishInventoryItem['qualityGrade']})}
                                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                                >
                                  <option value="Premium (A+)">Premium (A+)</option>
                                  <option value="Standard (A)">Standard (A)</option>
                                  <option value="Processing (B)">Processing (B)</option>
                                </select>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 pt-3">
                              <button
                                type="submit"
                                className="flex-1 bg-purple-950 hover:bg-purple-900 border border-purple-800 text-purple-400 py-2 rounded font-bold"
                              >
                                EMIT RFQ BID SPEC
                              </button>
                              <button
                                type="button"
                                onClick={() => setCreatingRFQ(false)}
                                className="flex-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 py-2 rounded"
                              >
                                CANCEL
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    )}
                  </div>
                )}


                {/* ===================================== */}
                {/* [06] TAB: VESSEL FINANCE */}
                {/* ===================================== */}
                {activeTab === "finance" && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                      <div>
                        <h2 className="text-base font-bold font-mono uppercase text-slate-200">RHINO BANK FISHERIES INVESTMENT HUB</h2>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">Asset purchase lending profiles, short-term catch-backed liquidity lines, and marine growth fund yields.</p>
                      </div>

                      {currentUserRole === "Fishing Vessel Owner" || currentUserRole === "Captain" ? (
                        <button
                          onClick={() => setApplyingCatchFinance(true)}
                          className="px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-400 text-xs font-mono font-bold rounded flex items-center gap-1.5 transition-all"
                        >
                          <Plus className="w-4 h-4" /> APPLY CATCH-BACKED LIQUIDITY
                        </button>
                      ) : null}
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      
                      {/* Active Vessel Mortgages & Loans */}
                      <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
                        <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">ACTIVE VESSEL LOANS & FINANCING ACCOUNTS</h3>
                        
                        <div className="space-y-3">
                          {loans.map(loan => (
                            <div key={loan.id} className="p-4 bg-slate-950 border border-slate-800 rounded font-mono text-xs">
                              <div className="flex flex-wrap items-center justify-between font-bold border-b border-slate-900 pb-2 mb-2">
                                <span className="text-slate-200">{loan.vesselName || loan.borrowerName}</span>
                                <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                                  loan.status === 'Performing' ? "bg-emerald-950/40 text-emerald-400 border border-emerald-800/40" : "bg-yellow-950/40 text-yellow-500 border border-yellow-800/40"
                                }`}>{loan.status}</span>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-slate-400 mt-2 text-[11px]">
                                <div>Principal: <span className="text-slate-100 font-semibold">£{loan.principalAmount.toLocaleString()}</span></div>
                                <div>Outstanding: <span className="text-slate-100 font-semibold">£{loan.outstandingBalance.toLocaleString()}</span></div>
                                <div>Interest Rate: <span className="text-emerald-400 font-bold">{loan.interestRatePercent}%</span></div>
                                <div>Term: <span className="text-slate-300">{loan.termMonths} Months</span></div>
                                <div>Monthly Installment: <span className="text-slate-100 font-bold">£{loan.monthlyPayment.toLocaleString()}</span></div>
                                <div>Category: <span className="text-slate-200">{loan.type}</span></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Catch-Backed Credit Applications (Analyst Review) */}
                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
                        <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">CATCH-BACKED LIQUIDITY FACILITY APPLICATIONS</h3>
                        
                        <div className="space-y-3 max-h-[300px] overflow-y-auto">
                          {catchApps.length === 0 ? (
                            <p className="text-slate-500 text-xs font-mono py-8 text-center">No outstanding liquidity requests.</p>
                          ) : (
                            catchApps.map(app => (
                              <div key={app.id} className="p-3 bg-slate-950 border border-slate-800 rounded font-mono text-xs space-y-2">
                                <div className="flex justify-between items-center font-bold">
                                  <span className="text-slate-200">{app.vesselName}</span>
                                  <span className={`px-1.5 py-0.5 rounded text-[9px] ${
                                    app.status === 'Pending' ? 'bg-amber-950/40 text-amber-400 border border-amber-900/30' :
                                    app.status === 'Approved' ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-900/30' :
                                    'bg-red-950/40 text-red-400 border border-red-900/30'
                                  }`}>{app.status}</span>
                                </div>
                                <div className="text-[10px] text-slate-400 space-y-1">
                                  <div className="flex justify-between"><span>Request Facility:</span> <span className="text-slate-100 font-bold">£{app.requestAmount.toLocaleString()}</span></div>
                                  <div className="flex justify-between"><span>R Credit Score:</span> <span className="text-cyan-400 font-bold">{app.riskScore}/100</span></div>
                                  <div className="flex justify-between"><span>30D Catch Est:</span> <span>£{app.historicalCatchValue30d.toLocaleString()}</span></div>
                                </div>

                                {app.status === "Pending" && currentUserRole === "Rhino Bank Analyst" ? (
                                  <div className="flex items-center gap-1.5 pt-2">
                                    <button
                                      onClick={() => handleReviewCatchLending(app.id, "Approved", app.requestAmount)}
                                      className="flex-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-400 py-1 rounded text-[10px] font-bold"
                                    >
                                      APPROVE
                                    </button>
                                    <button
                                      onClick={() => handleReviewCatchLending(app.id, "Declined", 0)}
                                      className="flex-1 bg-red-950 hover:bg-red-900 border border-red-800 text-red-400 py-1 rounded text-[10px]"
                                    >
                                      DECLINE
                                    </button>
                                  </div>
                                ) : null}
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>

                    {/* New Catch Loan overlay */}
                    {applyingCatchFinance && (
                      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 w-full max-w-md font-mono text-xs">
                          <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">Apply Catch-Backed Loan</h3>
                          <form onSubmit={handleApplyCatchLending} className="space-y-4">
                            <div>
                              <label className="block text-slate-400 mb-1">Select Vessel</label>
                              <select
                                value={catchFinanceForm.vesselId}
                                onChange={e => setCatchFinanceForm({...catchFinanceForm, vesselId: e.target.value})}
                                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                              >
                                {vessels.map(v => (
                                  <option key={v.id} value={v.id}>{v.name}</option>
                                ))}
                              </select>
                            </div>
                            <div>
                              <label className="block text-slate-400 mb-1">Requested Loan Amount (£)</label>
                              <input
                                type="number"
                                required
                                value={catchFinanceForm.requestAmount}
                                onChange={e => setCatchFinanceForm({...catchFinanceForm, requestAmount: Number(e.target.value)})}
                                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-2 text-slate-100"
                              />
                              <p className="text-[10px] text-slate-500 mt-1 leading-relaxed">
                                R Credit Score is computed instantly upon submission, analyzing the vessel leverage and fuel capacities. Approved loans are deposited to accounts and subtracted from the Growth Fund cash reserves.
                              </p>
                            </div>
                            <div className="flex items-center gap-2 pt-3">
                              <button
                                type="submit"
                                className="flex-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-400 py-2 rounded font-bold"
                              >
                                SUBMIT CREDIT APP
                              </button>
                              <button
                                type="button"
                                onClick={() => setApplyingCatchFinance(false)}
                                className="flex-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 py-2 rounded"
                              >
                                CANCEL
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    )}
                  </div>
                )}


                {/* ===================================== */}
                {/* [07] TAB: R QUANT RISK ENGINE */}
                {/* ===================================== */}
                {activeTab === "risk" && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                      <div>
                        <h2 className="text-base font-bold font-mono uppercase text-slate-200">R QUANT RISK SCORING ENGINE</h2>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">Monte Carlo probability simulations, 95% Value-at-Risk matrices, and stress-tests.</p>
                      </div>

                      <div className="flex items-center gap-3 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded text-xs font-mono">
                        <span className="text-slate-400">Select Vessel:</span>
                        <select
                          value={selectedRiskVesselId}
                          onChange={(e) => setSelectedRiskVesselId(e.target.value)}
                          className="bg-transparent border-none text-cyan-400 font-bold focus:outline-none cursor-pointer"
                        >
                          {vessels.map(v => (
                            <option key={v.id} value={v.id}>{v.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {loadingRiskProfile || !vesselRiskProfile ? (
                      <div className="py-20 text-center font-mono text-xs text-slate-500 flex flex-col items-center gap-3">
                        <span className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></span>
                        <p className="animate-pulse">RUNNING LOGISTIC ESTIMATION & STRESS MODELS...</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        
                        {/* Stress Tests & Value-at-Risk Panel */}
                        <div className="lg:col-span-2 space-y-6">
                          
                          {/* Credit Rating Card */}
                          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
                            <div className="flex flex-col justify-between border-b md:border-b-0 md:border-r border-slate-800 pb-4 md:pb-0 md:pr-4">
                              <span className="text-slate-500 uppercase tracking-wider block text-[9px]">RHINO CREDIT RATING</span>
                              <span className="text-3xl font-extrabold text-cyan-400 mt-2">{vesselRiskProfile.creditScore}</span>
                              <span className="text-[10px] text-slate-400 mt-1">Recommended Finance Pool: £{(vessels.find(v => v.id === selectedRiskVesselId)?.purchaseValue || 1.5e6) * 0.8 / 1e6}M Max</span>
                            </div>
                            <div className="flex flex-col justify-between border-b md:border-b-0 md:border-r border-slate-800 pb-4 md:pb-0 md:pr-4">
                              <span className="text-slate-500 uppercase tracking-wider block text-[9px]">PROBABILITY OF DEFAULT</span>
                              <span className="text-3xl font-extrabold text-amber-500 mt-2">{vesselRiskProfile.defaultProbabilityPercent}%</span>
                              <span className="text-[10px] text-slate-400 mt-1">Calculated via R logistic regression model.</span>
                            </div>
                            <div className="flex flex-col justify-between">
                              <span className="text-slate-500 uppercase tracking-wider block text-[9px]">95% VALUE-AT-RISK (MONTHLY)</span>
                              <span className="text-3xl font-extrabold text-slate-100 mt-2">£{vesselRiskProfile.valueAtRiskAmount.toLocaleString()}</span>
                              <span className="text-[10px] text-slate-400 mt-1">Volatility baseline threshold parameter.</span>
                            </div>
                          </div>

                          {/* Stress Test Matrix */}
                          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
                            <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">PORTFOLIO DEBT-SERVICE STRESS SCENARIO ANALYSIS</h3>
                            
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono text-center">
                              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                                <span className="text-slate-500 block text-[9px]">BASE CASE</span>
                                <span className="text-sm font-bold text-slate-200 mt-1.5 block">£{vesselRiskProfile.stressTests.baseCaseIncome.toLocaleString()}</span>
                                <span className="text-[10px] text-emerald-400 block mt-1">Optimal Net</span>
                              </div>
                              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                                <span className="text-slate-500 block text-[9px]">FUEL SURGE (+50%)</span>
                                <span className="text-sm font-bold text-slate-200 mt-1.5 block">£{vesselRiskProfile.stressTests.fuelSurgeIncome.toLocaleString()}</span>
                                <span className="text-[10px] text-yellow-500 block mt-1">Margin Drop</span>
                              </div>
                              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                                <span className="text-slate-500 block text-[9px]">STORM BLOCK (-15 DAYS)</span>
                                <span className="text-sm font-bold text-slate-200 mt-1.5 block">£{vesselRiskProfile.stressTests.stormDisruptionIncome.toLocaleString()}</span>
                                <span className="text-[10px] text-red-500 block mt-1">Debt Understress</span>
                              </div>
                              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                                <span className="text-slate-500 block text-[9px]">MARKET COLLAPSE (-30%)</span>
                                <span className="text-sm font-bold text-slate-200 mt-1.5 block">£{vesselRiskProfile.stressTests.marketCrashIncome.toLocaleString()}</span>
                                <span className="text-[10px] text-red-600 block mt-1">Non-Performing</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Monte Carlo Simulated distribution list */}
                        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
                          <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">MONTE CARLO SIMULATED RUNS (10 ITERATIONS)</h3>
                          
                          <div className="space-y-2 overflow-y-auto max-h-[300px] font-mono text-xs">
                            {vesselRiskProfile.monteCarloScenarios.map(run => (
                              <div key={run.run} className="bg-slate-950 p-2.5 border border-slate-800 rounded flex justify-between items-center">
                                <div>
                                  <span className="text-slate-500 font-semibold block text-[10px]">SCENARIO #{run.run}</span>
                                  <span className="text-[10px] text-slate-400">Fuel cost: £{run.fuelCost.toLocaleString()}</span>
                                </div>
                                <div className="text-right">
                                  <span className="text-slate-200 font-bold block">Net: £{run.netIncome.toLocaleString()}</span>
                                  <span className="text-[10px] text-emerald-500">Yield OK</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}


                {/* ===================================== */}
                {/* [08] TAB: LOGISTICAL & AI ANALYTICS */}
                {/* ===================================== */}
                {activeTab === "analytics" && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                      <div>
                        <h2 className="text-base font-bold font-mono uppercase text-slate-200">LOGISTICAL RE-ROUTING & AI STRATEGIST</h2>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">Dijkstra cold-chain optimizations paired with interactive Gemini predictive advisors.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      
                      {/* Cold Chain Router */}
                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
                        <div>
                          <h3 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider mb-4">DIJKSTRA COLD CHAIN ROUTING ENGINE</h3>
                          
                          <div className="grid grid-cols-2 gap-4 font-mono text-xs mb-4">
                            <div>
                              <label className="block text-slate-400 mb-1">Origin Port</label>
                              <select
                                value={logisticsOrigin}
                                onChange={(e) => setLogisticsOrigin(e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100"
                              >
                                <option value="Scarborough">Scarborough</option>
                                <option value="Whitby">Whitby</option>
                                <option value="Bridlington">Bridlington</option>
                                <option value="Hull">Hull</option>
                              </select>
                            </div>
                            <div>
                              <label className="block text-slate-400 mb-1">Destination Target</label>
                              <select
                                value={logisticsDestination}
                                onChange={(e) => setLogisticsDestination(e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100"
                              >
                                <option value="Leeds">Leeds Restaurants</option>
                              </select>
                            </div>
                          </div>

                          {calculatingRoute || !optimizedRoute ? (
                            <div className="py-12 text-center text-slate-500 font-mono text-[11px] animate-pulse">
                              RECALCULATING COLD CHAIN WEIGHT PATHS...
                            </div>
                          ) : (
                            <div className="bg-slate-950 border border-slate-850 p-4 rounded font-mono text-xs space-y-3">
                              <div className="flex justify-between font-bold border-b border-slate-900 pb-2 text-slate-200">
                                <span>Optimal Route:</span>
                                <span className="text-cyan-400">{optimizedRoute.id}</span>
                              </div>
                              <div className="space-y-1.5 text-[11px] text-slate-400">
                                <div className="flex justify-between"><span>Route itinerary:</span> <span className="text-slate-100 font-semibold">{optimizedRoute.originPort} → {optimizedRoute.distributionCentre} → {optimizedRoute.destination}</span></div>
                                <div className="flex justify-between"><span>Transit Duration:</span> <span className="text-slate-100 font-semibold">{optimizedRoute.transitTimeMinutes} minutes</span></div>
                                <div className="flex justify-between"><span>Estimated Fuel Cost:</span> <span className="text-slate-100 font-bold">£{optimizedRoute.fuelCostGBP}</span></div>
                                <div className="flex justify-between"><span>Carbon Footprint:</span> <span className="text-teal-400 font-bold">{optimizedRoute.carbonKgCo2} kg CO2</span></div>
                                <div className="flex justify-between"><span>Cargo temperature:</span> <span className="text-cyan-400 font-bold">{optimizedRoute.temperatureMaintainedCelsius}°C (Chilled)</span></div>
                                <div className="flex justify-between"><span>Capacity Utilization:</span> <span className="text-slate-100">{optimizedRoute.capacityUtilizationPercent}%</span></div>
                              </div>
                            </div>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono mt-4">
                          Optimization weights: Dijkstra-calculated balancing road speed against cold chain refrigeration fuel overheads.
                        </div>
                      </div>

                      {/* Gemini AI Advisor Portal */}
                      <div className="h-full">
                        <AIConsultant />
                      </div>
                    </div>
                  </div>
                )}


                {/* ===================================== */}
                {/* [09] TAB: SUSTAINABILITY ANALYTICS */}
                {/* ===================================== */}
                {activeTab === "sustainability" && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                      <div>
                        <h2 className="text-base font-bold font-mono uppercase text-slate-200">FLEET SUSTAINABILITY & ESG MONITOR</h2>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">Tracking carbon per kg caught, fuel efficiency coefficients, and RFID audit loops.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
                      
                      {/* ESG Index score cards */}
                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between h-[180px]">
                        <span className="text-slate-500 uppercase tracking-wider block text-[9px]">FLEET ESG METHODOLOGY RATING</span>
                        <span className="text-4xl font-extrabold text-teal-400 mt-2">AAA</span>
                        <p className="text-slate-400 text-[10px] mt-2">
                          92% of catches landed are verified via selective hook-and-line or creel pots, bypassing bottom trawling completely.
                        </p>
                      </div>

                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between h-[180px]">
                        <span className="text-slate-500 uppercase tracking-wider block text-[9px]">CARBON INTENSITY COEFFICIENT</span>
                        <span className="text-4xl font-extrabold text-slate-100 mt-2">1.84 <span className="text-xs font-normal text-slate-500">kg CO2/kg catch</span></span>
                        <p className="text-slate-400 text-[10px] mt-2">
                          Sub-2.0 index score places Yorkshire co-operative fleets in the top 5% of global marine efficiency profiles.
                        </p>
                      </div>

                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between h-[180px]">
                        <span className="text-slate-500 uppercase tracking-wider block text-[9px]">TRACEABILITY RFID AUDITING</span>
                        <span className="text-4xl font-extrabold text-cyan-400 mt-2">100%</span>
                        <p className="text-slate-400 text-[10px] mt-2">
                          All storage vaults utilize automated satellite AIS timestamps and RFID container chips for absolute fresh seafood validation.
                        </p>
                      </div>

                      {/* Stock indices score grids */}
                      <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
                        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">MARINE STOCK SUSTAINABILITY INDEX (CONSERVATION INDEX)</h3>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 text-center">
                          {sustainability?.stockSustainabilityIndices.map(item => (
                            <div key={item.species} className="bg-slate-950 p-3 rounded border border-slate-800">
                              <span className="text-slate-400 block font-bold text-[10px] uppercase">{item.species}</span>
                              <span className="text-sm font-bold block mt-1.5 text-slate-100">{item.indexScore} / 100</span>
                              <span className={`text-[9px] block mt-1 ${item.indexScore > 75 ? "text-emerald-400" : item.indexScore > 55 ? "text-cyan-400" : "text-amber-500"}`}>
                                {item.indexScore > 75 ? "Excellent Stock" : item.indexScore > 55 ? "Stable" : "Observation"}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}


                {/* ===================================== */}
                {/* [10] TAB: AUDIT TRANSACTION LEDGER */}
                {/* ===================================== */}
                {activeTab === "audit" && (
                  <div className="space-y-6 font-mono text-xs">
                    <div className="border-b border-slate-800 pb-4">
                      <h2 className="text-base font-bold uppercase text-slate-200">BANK-GRADE AUDIT LOGS & TRANSACTION HISTORY</h2>
                      <p className="text-xs text-slate-400 mt-0.5">Continuous ledger synchronizing credit appraisals, vessel registrations, and stock reservation logs.</p>
                    </div>

                    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs">
                          <thead>
                            <tr className="border-b border-slate-800 text-slate-500 pb-2 uppercase tracking-wide text-[10px]">
                              <th className="pb-2">TIMESTAMP</th>
                              <th className="pb-2">ACTOR</th>
                              <th className="pb-2">ACTION</th>
                              <th className="pb-2">DETAILS</th>
                              <th className="pb-2">IP LOCATION</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60 text-slate-300">
                            {auditLogs.map(log => (
                              <tr key={log.id} className="hover:bg-slate-950/40">
                                <td className="py-2.5 text-slate-500">{log.timestamp}</td>
                                <td className="py-2.5 font-bold text-slate-400">{log.actor}</td>
                                <td className="py-2.5">
                                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                    log.action.includes("FINANCE") || log.action.includes("CREDIT") ? "bg-emerald-950/40 text-emerald-400 border border-emerald-900/40" :
                                    log.action.includes("WARN") ? "bg-yellow-950/40 text-yellow-500 border border-yellow-900/40" :
                                    "bg-cyan-950/40 text-cyan-400 border border-cyan-900/40"
                                  }`}>{log.action}</span>
                                </td>
                                <td className="py-2.5 font-sans text-slate-300">{log.details}</td>
                                <td className="py-2.5 text-slate-500">{log.ipAddress}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}

              </motion.div>
            </AnimatePresence>
          </div>

          {/* 3. FOOTER REAL-TIME TERMINAL CONSOLE */}
          <footer className="mt-6">
            <TerminalLogs />
          </footer>
        </main>
      </div>
    </div>
  );
}
