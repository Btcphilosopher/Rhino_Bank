import React, { useEffect, useState, useRef } from "react";
import { Terminal, Shield, Cpu, Activity } from "lucide-react";

interface LogMessage {
  id: string;
  timestamp: string;
  source: 'RUST_CORE' | 'R_ANALYTICS' | 'BANK_LEDGER' | 'AIS_TELEMETRY';
  type: 'INFO' | 'SUCCESS' | 'WARN' | 'CRITICAL';
  message: string;
}

const SAMPLE_LOGS: Omit<LogMessage, 'id' | 'timestamp'>[] = [
  { source: "AIS_TELEMETRY", type: "INFO", message: "Ingested packet for FV Yorkshire Enterprise [UK-Y-101] (54.384, 0.123)" },
  { source: "R_ANALYTICS", type: "INFO", message: "Running Monte Carlo model (1,000 runs) for Scarborough Star debt-exposure" },
  { source: "RUST_CORE", type: "SUCCESS", message: "Logistics routing optimized: Bridlington -> York Distribution -> Leeds (65 mins, £72)" },
  { source: "BANK_LEDGER", type: "INFO", message: "Auditing outstanding fleet finance totals: £63.85M asset valuation threshold" },
  { source: "AIS_TELEMETRY", type: "INFO", message: "Telemetry updated: FV Hull Monarch at speed 12.5 knots heading 180" },
  { source: "R_ANALYTICS", type: "SUCCESS", message: "ARIMA price forecasts calculated: Cod standard pricing adjusted +3.4% 24h" },
  { source: "RUST_CORE", type: "INFO", message: "Database connection pools: 16 PostgreSQL thread blocks performing optimally" },
  { source: "BANK_LEDGER", type: "SUCCESS", message: "Cleared B2B invoice B2B-IN-4491: 500kg Premium Haddock settled" },
  { source: "R_ANALYTICS", type: "WARN", message: "Stress Test Warning: Vessel Scarborough Star Value-at-Risk exceeded 15% debt-to-equity" },
  { source: "AIS_TELEMETRY", type: "INFO", message: "Ingested GPS stream: FV Whitby Explorer (54.512, -0.421) heading East" }
];

export default function TerminalLogs() {
  const [logs, setLogs] = useState<LogMessage[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize with 5 logs
    const initialLogs = Array.from({ length: 6 }).map((_, idx) => {
      const sample = SAMPLE_LOGS[idx % SAMPLE_LOGS.length];
      return {
        ...sample,
        id: `log-init-${idx}`,
        timestamp: new Date(Date.now() - (6 - idx) * 4000).toLocaleTimeString()
      } as LogMessage;
    });
    setLogs(initialLogs);

    // Simulating streaming logs
    const interval = setInterval(() => {
      const sample = SAMPLE_LOGS[Math.floor(Math.random() * SAMPLE_LOGS.length)];
      const nextLog: LogMessage = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString(),
        source: sample.source,
        type: sample.type,
        message: sample.message
      };
      setLogs(prev => [...prev.slice(-30), nextLog]); // cap at last 30 logs
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [logs]);

  const getSourceColor = (src: LogMessage['source']) => {
    switch (src) {
      case "RUST_CORE": return "text-orange-400";
      case "R_ANALYTICS": return "text-cyan-400";
      case "BANK_LEDGER": return "text-emerald-400";
      case "AIS_TELEMETRY": return "text-blue-400";
    }
  };

  const getTypeColor = (type: LogMessage['type']) => {
    switch (type) {
      case "SUCCESS": return "text-emerald-500 font-semibold";
      case "WARN": return "text-yellow-500 font-semibold";
      case "CRITICAL": return "text-red-500 font-bold animate-pulse";
      default: return "text-slate-400";
    }
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 font-mono text-xs shadow-inner flex flex-col h-[200px]">
      <div className="flex items-center justify-between border-b border-slate-900 pb-2 mb-2">
        <div className="flex items-center gap-2 text-slate-400">
          <Terminal className="w-3.5 h-3.5 text-orange-400" />
          <span className="text-slate-200 font-bold tracking-wide uppercase">RHINO BACKEND ECOSYSTEM CORE INTERNALS</span>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            RUST ASYNC ENGINE
          </span>
          <span className="text-slate-600">|</span>
          <span className="flex items-center gap-1 text-cyan-400">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
            R CORE RUNNING
          </span>
        </div>
      </div>

      <div ref={containerRef} className="flex-1 overflow-y-auto space-y-1 pr-1 scrollbar-thin">
        {logs.map(log => (
          <div key={log.id} className="leading-relaxed hover:bg-slate-900/60 px-1 py-0.5 rounded transition-colors flex items-start gap-1">
            <span className="text-slate-600">[{log.timestamp}]</span>
            <span className={`font-semibold ${getSourceColor(log.source)}`}>[{log.source}]</span>
            <span className={getTypeColor(log.type)}>[{log.type}]</span>
            <span className="text-slate-300 flex-1">{log.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
