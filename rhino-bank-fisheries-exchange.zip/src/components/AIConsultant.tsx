import React, { useState } from "react";
import { Cpu, Send, Sparkles, AlertCircle, FileText, Anchor, HelpCircle } from "lucide-react";

interface BriefingResponse {
  report: string;
  timestamp: string;
  model: string;
}

const PRESET_QUERIES = [
  {
    label: "Fleet Default Diagnostic",
    text: "Review current vessel leverage ratios, operational fuel reserves, and highlight outstanding BB-rated default risks.",
    focus: "Risk & Credit"
  },
  {
    label: "Whitby Lobster Optimization",
    text: "Formulate a trading recommendation for Whitby landed lobster based on low supply, high demand, and cold storage transport limits.",
    focus: "Seafood Procurement"
  },
  {
    label: "M62 Cold Chain Re-routing",
    text: "Determine the most fuel-efficient and lowest carbon footprint transport itinerary from Scarborough Port to Leeds restaurants.",
    focus: "Logistics"
  }
];

export default function AIConsultant() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<BriefingResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent, customText?: string) => {
    e.preventDefault();
    const finalQuery = customText || query;
    if (!finalQuery.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch("/api/analytics/ai-intelligence", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: finalQuery,
          focusArea: "Interactive Consultant"
        })
      });

      if (!response.ok) {
        throw new Error("Econ-R backend system returned an error");
      }

      const data: BriefingResponse = await response.json();
      setResult(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong communicating with the R analytics server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col h-full">
      <div className="flex items-center gap-3 border-b border-slate-800 pb-3 mb-4">
        <div className="p-2 bg-cyan-950 text-cyan-400 rounded-lg border border-cyan-800/50">
          <Cpu className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-slate-100 font-bold text-sm tracking-wide uppercase">AI Predictive Intelligence System</h3>
          <p className="text-xs text-slate-400 font-mono">Powered by Gemini 3.6 + Quantitative R Forecasting Models</p>
        </div>
      </div>

      <div className="mb-4">
        <p className="text-xs text-slate-300 font-mono mb-2 uppercase tracking-wide">Select Preset Strategic Query:</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          {PRESET_QUERIES.map((preset, idx) => (
            <button
              key={idx}
              onClick={(e) => {
                setQuery(preset.text);
                handleSubmit(e, preset.text);
              }}
              disabled={loading}
              className="text-left bg-slate-950/80 hover:bg-slate-950 border border-slate-800 hover:border-cyan-800/80 p-2.5 rounded text-xs transition-all duration-200"
            >
              <div className="flex items-center gap-1.5 text-cyan-400 font-semibold mb-1">
                <Sparkles className="w-3 h-3" />
                <span>{preset.label}</span>
              </div>
              <p className="text-slate-400 line-clamp-2 text-[10px] font-mono leading-relaxed">{preset.text}</p>
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={(e) => handleSubmit(e)} className="relative flex items-center gap-2 mb-4">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask about default probabilities, market forecasts, routing optimizations..."
          className="flex-1 bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded p-3 pr-10 text-xs font-mono text-slate-200 placeholder:text-slate-600 focus:outline-none"
          disabled={loading}
        />
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="absolute right-2.5 p-1.5 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-400 rounded transition-all disabled:opacity-40"
        >
          {loading ? (
            <span className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin block"></span>
          ) : (
            <Send className="w-3.5 h-3.5" />
          )}
        </button>
      </form>

      <div className="flex-1 bg-slate-950 border border-slate-800 rounded p-4 overflow-y-auto max-h-[380px] font-mono text-xs flex flex-col justify-between">
        {loading && (
          <div className="flex flex-col items-center justify-center py-12 text-slate-500 gap-3">
            <span className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></span>
            <p className="text-[11px] animate-pulse uppercase tracking-widest text-cyan-500">Executing econometric compilation & Gemini reasoning...</p>
          </div>
        )}

        {error && (
          <div className="flex items-start gap-2 text-red-400 p-3 bg-red-950/20 border border-red-900/50 rounded">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Execution Failure</p>
              <p className="text-[10px] text-red-500">{error}</p>
            </div>
          </div>
        )}

        {!loading && !result && !error && (
          <div className="flex flex-col items-center justify-center py-16 text-slate-600 text-center gap-2">
            <HelpCircle className="w-8 h-8 text-slate-700" />
            <p className="font-semibold uppercase tracking-wide text-slate-500">Terminal Awaiting Instructions</p>
            <p className="text-[10px] max-w-sm">Enter a custom query or trigger one of our preset quantitative models. Rhino Bank Fisheries advisory compiles real-time fleet AIS, B2B procurement bids, and fish stock data.</p>
          </div>
        )}

        {result && (
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-900 pb-2 text-[10px] text-slate-500">
              <span className="flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-cyan-500" />
                REPORT COMPLETED SUCCESSFULLY
              </span>
              <span>ENGINE: {result.model}</span>
            </div>
            <pre className="text-slate-300 whitespace-pre-wrap leading-relaxed text-[11px] font-mono select-text bg-slate-950 p-2.5 rounded border border-slate-900 shadow-inner">
              {result.report}
            </pre>
            <div className="text-[10px] text-slate-600 text-right">
              Generated: {new Date(result.timestamp).toLocaleTimeString()} | Scope: Enterprise Fisheries Exchange
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
