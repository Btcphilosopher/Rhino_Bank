export type UserRole =
  | 'Rhino Bank Analyst'
  | 'Fishing Vessel Owner'
  | 'Captain'
  | 'Buyer'
  | 'Supplier'
  | 'Investor';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  organization?: string;
}

export interface Vessel {
  id: string;
  name: string;
  owner: string;
  captain: string;
  port: 'Scarborough' | 'Whitby' | 'Bridlington' | 'Hull';
  registration: string;
  fishingLicence: string;
  insuranceStatus: 'Active' | 'Pending' | 'Expired';
  engineSizeHp: number;
  fuelCapacityLitres: number;
  fuelLevelPercent: number;
  ageYears: number;
  purchaseValue: number;
  outstandingFinance: number;
  riskRating: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' | 'CCC';
  status: 'At Sea' | 'In Port' | 'Maintenance' | 'Fishing';
  latitude: number;
  longitude: number;
  heading: number;
  speedKnots: number;
  currentCatchEstimate: number;
  crewCount: number;
}

export type FishSpecies =
  | 'Cod'
  | 'Haddock'
  | 'Lobster'
  | 'Crab'
  | 'Skate'
  | 'Herring'
  | 'Mackerel';

export interface FishInventoryItem {
  id: string;
  species: FishSpecies;
  weightKg: number;
  landingDate: string;
  fishingVesselId: string;
  fishingVesselName: string;
  landingPort: 'Scarborough' | 'Whitby' | 'Bridlington' | 'Hull';
  qualityGrade: 'Premium (A+)' | 'Standard (A)' | 'Processing (B)';
  storageLocation: string;
  currentMarketPricePerKg: number;
  buyerStatus: 'Available' | 'Reserved' | 'Sold';
  buyerId?: string;
  buyerName?: string;
  traceabilityCertificate: string;
}

export interface RFQ {
  id: string;
  buyerId: string;
  buyerName: string;
  species: FishSpecies;
  quantityRequiredKg: number;
  frequency: 'Weekly' | 'Bi-weekly' | 'Once-off';
  deliveryDate: string;
  qualityRequired: 'Premium (A+)' | 'Standard (A)' | 'Processing (B)';
  status: 'Open' | 'Closed' | 'Draft';
  createdAt: string;
  responses: RFQResponse[];
}

export interface RFQResponse {
  id: string;
  rfqId: string;
  supplierId: string;
  supplierName: string;
  pricePerKg: number;
  availabilityConfirmed: boolean;
  deliveryDate: string;
  qualityCertificate: string;
  status: 'Pending' | 'Accepted' | 'Declined';
  notes?: string;
}

export interface CommodityMarket {
  species: FishSpecies;
  currentPricePerKg: number;
  change24hPercent: number;
  change7dPercent: number;
  supplyLevel: 'Low' | 'Medium' | 'High';
  demandLevel: 'Low' | 'Medium' | 'High';
  forecastPrice30d: number;
  historicalPrices: { date: string; price: number; volume: number }[];
}

export interface Loan {
  id: string;
  vesselId?: string;
  vesselName?: string;
  borrowerName: string;
  type: 'Vessel Purchase' | 'Catch-Backed Line' | 'Equipment Upgrade';
  principalAmount: number;
  outstandingBalance: number;
  interestRatePercent: number;
  termMonths: number;
  monthlyPayment: number;
  expectedAnnualRevenue: number;
  riskCategory: 'Low' | 'Medium' | 'High';
  status: 'Performing' | 'Under Observation' | 'Non-Performing';
  startDate: string;
}

export interface CatchBackedLendingApplication {
  id: string;
  vesselId: string;
  vesselName: string;
  historicalCatchValue30d: number;
  projectedCatchValueNext30d: number;
  requestAmount: number;
  riskScore: number; // 0-100
  approvedAmount?: number;
  interestRate?: number;
  status: 'Pending' | 'Approved' | 'Declined';
  appliedDate: string;
}

export interface MarineFund {
  name: string;
  totalAUM: number;
  cashReserve: number;
  allocatedAssets: {
    vesselsFinance: number;
    processingFacilities: number;
    coldStorage: number;
    distributionNetworks: number;
    marineTech: number;
  };
  irrPercent: number;
  roiPercent: number;
  historicalYields: { period: string; yield: number }[];
}

export interface VesselRiskAnalysis {
  vesselId: string;
  vesselName: string;
  creditScore: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' | 'CCC';
  defaultProbabilityPercent: number;
  valueAtRiskAmount: number; // VaR at 95%
  monteCarloScenarios: { run: number; projectedCatch: number; fuelCost: number; netIncome: number }[];
  stressTests: {
    baseCaseIncome: number;
    fuelSurgeIncome: number; // +50% fuel costs
    stormDisruptionIncome: number; // 15 sea days lost
    marketCrashIncome: number; // -30% fish prices
  };
}

export interface LogisticsOptimisationRoute {
  id: string;
  originPort: string;
  coldStorage: string;
  distributionCentre: string;
  destination: string;
  transitTimeMinutes: number;
  fuelCostGBP: number;
  carbonKgCo2: number;
  temperatureMaintainedCelsius: number;
  capacityUtilizationPercent: number;
}

export interface SustainabilityMetrics {
  carbonPerKgFish: number; // kg CO2 per kg catch
  fleetFuelEfficiencyPercent: number;
  sustainableFishingMethodsPercent: number; // AAA standard methods
  traceabilityCompliancePercent: number; // RFID/blockchain compliance
  stockSustainabilityIndices: { species: FishSpecies; indexScore: number }[]; // 0-100
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  details: string;
  ipAddress: string;
}

export interface AISPacket {
  vesselId: string;
  vesselName: string;
  latitude: number;
  longitude: number;
  speed: number;
  heading: number;
  timestamp: string;
}
