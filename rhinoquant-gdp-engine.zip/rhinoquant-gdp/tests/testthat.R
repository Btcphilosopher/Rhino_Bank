library(testthat)
library(rhinoquant.gdp)

test_check("rhinoquant.gdp")
