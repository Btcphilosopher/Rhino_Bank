test_that("Income approach computes CE + GOS + GMI and market price reconciliation", {
  res <- gdp_income(
    compensation_employees = 900,
    operating_surplus = 400,
    mixed_income = 150,
    net_taxes_products = 80,
    net_taxes_production = 10,
    unit = "USD",
    scale = "billions"
  )

  # GVA basic = 900 + 400 + 150 = 1450
  # Market GDP = 1450 + 80 + 10 = 1540
  expect_equal(res$gva_basic, 1450)
  expect_equal(res$gdp, 1540)
  expect_equal(res$shares[["compensation_employees"]], round((900 / 1450) * 100, 2))
})
