test_that("Production approach deducts intermediate consumption and adds net taxes", {
  sectors <- data.frame(
    sector = c("Agriculture", "Manufacturing", "Services"),
    gross_output = c(200, 800, 1500),
    intermediate_consumption = c(80, 450, 600)
  )

  # GVA:
  # Ag: 200 - 80 = 120
  # Mfg: 800 - 450 = 350
  # Services: 1500 - 600 = 900
  # Total GVA = 1370
  # Net taxes = 150 - 20 = 130
  # GDP = 1370 + 130 = 1500

  res <- gdp_production(
    sectors = sectors,
    taxes_on_products = 150,
    subsidies_on_products = 20,
    unit = "USD",
    scale = "billions"
  )

  expect_equal(res$total_gva, 1370)
  expect_equal(res$net_product_taxes, 130)
  expect_equal(res$gdp, 1500)
  expect_equal(res$sector_table$gva, c(120, 350, 900))
})

test_that("Production approach rejects negative intermediate consumption", {
  bad_sectors <- data.frame(
    sector = c("Industry"),
    gross_output = c(500),
    intermediate_consumption = c(-50)
  )
  expect_error(
    gdp_production(bad_sectors, taxes_on_products = 10),
    "Intermediate consumption cannot be negative"
  )
})
