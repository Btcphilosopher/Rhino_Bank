test_that("Expenditure approach computes C + I + G + (X - M) correctly", {
  res <- gdp_expenditure(
    consumption = 1200,
    investment = 350,
    government = 400,
    exports = 280,
    imports = 310,
    unit = "USD",
    scale = "billions"
  )

  # Net exports = 280 - 310 = -30
  expect_equal(res$net_exports, -30)
  # GDP = 1200 + 350 + 400 - 30 = 1920
  expect_equal(res$gdp, 1920)
  expect_equal(unname(res$components["C"]), 1200)
  expect_equal(unname(res$components["NX"]), -30)
  expect_equal(res$metadata$scale, "billions")
})

test_that("Expenditure approach rejects negative imports or missing values", {
  expect_error(
    gdp_expenditure(consumption = 1000, investment = 200, government = 200, exports = 100, imports = -50),
    "Imports \\(M\\) cannot be negative"
  )
  expect_error(
    gdp_expenditure(consumption = NA, investment = 200, government = 200, exports = 100, imports = 50),
    "must not be missing or NA"
  )
})
