test_that("Price deflation and deflator reciprocal match exactly", {
  nominal <- c(100, 110, 126)
  deflator <- c(100, 105, 112)

  real <- gdp_nominal_to_real(nominal, deflator, base_year = 2020)
  expect_equal(real[1], 100)
  expect_equal(round(real[2], 2), round(110 / 1.05, 2))

  recalculated_deflator <- gdp_deflator(nominal, real)
  expect_equal(recalculated_deflator, deflator)
})

test_that("Growth metrics compute YoY, QoQ, annualised and CAGR correctly", {
  gdp_q <- c(100, 101, 102, 103, 104)

  # QoQ growth for 2nd obs: (101/100 - 1)*100 = 1.00%
  qoq <- gdp_growth_qoq(gdp_q)
  expect_equal(qoq[2], 1.0)

  # Annualised rate: (1.01^4 - 1)*100 ~ 4.060%
  ann <- gdp_growth_annualised(gdp_q)
  expect_equal(ann[2], 4.060)

  # YoY growth for 5th obs (lag 4): (104/100 - 1)*100 = 4.0%
  yoy <- gdp_growth_yoy(gdp_q, lag = 4)
  expect_equal(yoy[5], 4.0)

  # CAGR from 100 to 121 in 2 years: sqrt(1.21) - 1 = 10.0%
  cagr <- gdp_cagr(100, 121, 2)
  expect_equal(cagr, 10.0)

  # Per capita: 2000 billion USD / 100 million pop = 20,000 USD/person
  pc <- gdp_per_capita(2000, 100, scale_gdp = "billions", scale_pop = "millions")
  expect_equal(pc, 20000)
})
