test_that("Reconciliation detects statistical discrepancies and assesses tolerances", {
  # Perfect match
  rec_exact <- gdp_reconcile_accounts(
    expenditure = 2000,
    production = 2000,
    income = 2000,
    tolerance_pct = 0.10
  )
  expect_true(rec_exact$within_tolerance)
  expect_equal(rec_exact$audit_status, "BALANCED")

  # Small discrepancy within 0.1% tolerance
  rec_small <- gdp_reconcile_accounts(
    expenditure = 2000.5,
    production = 2000.0,
    tolerance_pct = 0.10,
    published_discrepancy = 0.5
  )
  expect_true(rec_small$within_tolerance)
  expect_equal(rec_small$primary_discrepancy$unexplained, 0)

  # Discrepancy exceeding tolerance
  rec_large <- gdp_reconcile_accounts(
    expenditure = 2100,
    production = 2000,
    tolerance_pct = 0.10
  )
  expect_false(rec_large$within_tolerance)
  expect_equal(rec_large$audit_status, "DISCREPANCY_EXCEEDS_TOLERANCE")
})
