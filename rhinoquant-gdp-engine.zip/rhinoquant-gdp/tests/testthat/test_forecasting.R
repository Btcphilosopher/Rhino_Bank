test_that("Forecasting handles horizons, prediction bounds, and out-of-sample metrics", {
  hist_series <- c(100, 102, 105, 108, 111, 115, 118, 122, 126, 130)

  fc <- gdp_forecast(hist_series, horizon = 4, model_type = "drift")

  expect_equal(length(fc$point_forecast), 4)
  expect_true(all(fc$intervals_95$lower < fc$point_forecast))
  expect_true(all(fc$intervals_95$upper > fc$point_forecast))
  expect_true(fc$backtest_metrics$mae >= 0)
  expect_true(fc$backtest_metrics$rmse >= 0)
})

test_that("Scenario sensitivity engine updates components and maintains identity", {
  baseline <- c(C = 1200, I = 350, G = 400, X = 280, M = 310)
  scen <- gdp_scenario_analysis(baseline, shocks = c(C = 10, M = 10))

  # Base GDP = 1200 + 350 + 400 + (280 - 310) = 1920
  expect_equal(scen$baseline_gdp, 1920)

  # Stressed C = 1320 (+120), Stressed M = 341 (+31)
  # Net change = +120 - 31 = +89 => 2009
  expect_equal(scen$scenario_gdp, 2009)
  expect_equal(scen$delta_abs, 89)
})
