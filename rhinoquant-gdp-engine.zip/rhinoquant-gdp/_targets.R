library(targets)
library(tarchetypes)

# Set target options:
tar_option_set(
  packages = c("data.table", "dplyr", "tidyr", "readr", "forecast", "jsonlite", "sandwich", "lmtest"),
  format = "rds"
)

# Source all R computational functions
tar_source("R")

# Targets pipeline for reproducible national accounts compilation
list(
  tar_target(
    file_us_data,
    "data/example/us_national_accounts.csv",
    format = "file"
  ),
  tar_target(
    raw_accounts,
    readr::read_csv(file_us_data, show_col_types = FALSE)
  ),
  tar_target(
    validated_accounts,
    validate_national_accounts(raw_accounts)
  ),
  tar_target(
    reconciled_gdp,
    gdp_reconcile_accounts(
      expenditure = gdp_expenditure(
        consumption = 19124.5,
        investment = 4920.8,
        government = 4872.1,
        exports = 3120.4,
        imports = 3980.2,
        scale = "billions"
      ),
      production = gdp_production(
        sectors = data.frame(
          sector = c("Goods", "Services", "Government"),
          gross_output = c(9500, 24000, 5200),
          intermediate_consumption = c(5200, 8100, 1600)
        ),
        taxes_on_products = 1620,
        subsidies_on_products = 362.4,
        scale = "billions"
      )
    )
  ),
  tar_target(
    baseline_forecast,
    gdp_forecast(
      series = validated_accounts$value[validated_accounts$measure == "Real_GDP"],
      dates = validated_accounts$period[validated_accounts$measure == "Real_GDP"],
      horizon = 8,
      model_type = "auto_arima"
    )
  )
)
