# RhinoQuant GDP Engine

> **Institutional Macroeconomic Analytics, National Accounts & GDP Modelling Platform**

RhinoQuant GDP Engine is an institutional-grade macroeconomic computational engine and national accounts workstation. Built for professional economists, central bank researchers, quantitative macro investors, sovereign risk analysts, and statistical offices, the engine implements rigorous accounting identities, price deflation dynamics, sectoral productivity decompositions, econometric diagnostics, time-series forecasting, and reproducible reporting.

---

## Core Economic Architecture

Economic calculations are the product; charts and dashboards are observations of the underlying economic engine.

### 1. The Three National Accounts Identities
- **Expenditure Approach**: $GDP = C + I + G + (X - M)$
  - $C$: Private final consumption expenditure (durable, non-durable, services)
  - $I$: Gross capital formation (gross fixed capital formation + changes in inventories + net acquisition of valuables)
  - $G$: General government final consumption expenditure
  - $X - M$: Net exports of goods and services
- **Production Approach (Gross Value Added)**: $GDP = \sum_{i} GVA_i + T_p - S_p$
  - Sectoral Gross Value Added: $GVA_i = \text{Gross Output}_i - \text{Intermediate Consumption}_i$
  - $T_p$: Taxes on products (VAT, import tariffs, excise)
  - $S_p$: Subsidies on products
- **Income Approach**: $GVA = CE + GOS + GMI$
  - Reconciled to GDP at market prices: $GDP = CE + GOS + GMI + (T_p - S_p) + (T_o - S_o)$
  - $CE$: Compensation of employees (wages, salaries, employers' social contributions)
  - $GOS$: Gross operating surplus (corporate gross profit)
  - $GMI$: Gross mixed income (unincorporated enterprise earnings)
  - $T_o - S_o$: Other taxes less subsidies on production

### 2. Multi-Method Reconciliation & Statistical Discrepancy
In actual national accounts compilation (e.g. US BEA, Eurostat, UK ONS, Japan ESRI), the three approaches draw from different statistical surveys (household surveys, VAT registers, customs records, payroll declarations), resulting in an empirical discrepancy:
$$\Delta_{ES} = GDP_{expenditure} - GDP_{production}$$
RhinoQuant does not artificially force equality. It exposes the absolute discrepancy, percentage deviation, missing components, vintage divergence, and allows explicit entry of published balancing items.

### 3. Price Adjustments: Deflators & Volume Measures
- **Nominal GDP**: $GDP_t^{\text{nominal}} = \sum_k P_{k,t} Q_{k,t}$
- **Fixed-Base Constant Prices**: $RealGDP_t = \frac{NominalGDP_t}{Deflator_t / 100}$
- **Implicit GDP Deflator**: $Deflator_t = \frac{NominalGDP_t}{RealGDP_t} \times 100$
- **Chain-Volume Measures**: Chained Laspeyres/Fisher volume indexes chaining period-to-period volume growth rates:
  $$I_{t}^{\text{chain}} = I_{t-1}^{\text{chain}} \times \left(1 + g_{t}^{\text{volume}}\right)$$

### 4. Growth Analytics & Contributions
- **Year-on-Year Growth**: $g_t^{\text{YoY}} = \left(\frac{GDP_t}{GDP_{t-4}} - 1\right) \times 100$
- **Quarter-on-Quarter (SA)**: $g_t^{\text{QoQ}} = \left(\frac{GDP_t}{GDP_{t-1}} - 1\right) \times 100$
- **Annualised Quarterly Rate**: $g_t^{\text{ann}} = \left[\left(\frac{GDP_t}{GDP_{t-1}}\right)^4 - 1\right] \times 100$
- **Compound Annual Growth Rate (CAGR)**: $CAGR = \left[\left(\frac{GDP_T}{GDP_0}\right)^{1/n} - 1\right] \times 100$
- **Component Percentage-Point Contribution to Growth**:
  $$C_k = \frac{\Delta Y_k}{GDP_{t-1}} \times 100$$
  *Crucial principle*: Percentage-point contribution differs fundamentally from the component's own growth rate.

---

## Repository Structure

```
rhinoquant-gdp/
├── DESCRIPTION              # R package specification & dependencies
├── renv.lock                # Deterministic dependency lockfile
├── README.md                # System documentation & architectural reference
├── LICENSE                  # Apache 2.0 institutional license
├── .Rprofile                # R runtime environment configuration
├── _targets.R               # Reproducible data pipeline configuration
├── config/
│   ├── defaults.yml         # Computational tolerances & default assumptions
│   └── data_sources.yml     # Official statistical API endpoints & schemas
├── R/                       # Pure, testable computational library
│   ├── gdp_expenditure.R    # C + I + G + (X - M) calculation & decomposition
│   ├── gdp_production.R     # Sectoral Output - Intermediate Consumption + Net Taxes
│   ├── gdp_income.R         # CE + GOS + GMI + Net Taxes reconciliation
│   ├── national_accounts.R  # Canonical data model & cross-account ledger
│   ├── deflation.R          # Implicit deflator, rebasing, chain-volume indexing
│   ├── growth.R             # YoY, QoQ, annualised, CAGR, per-capita, contributions
│   ├── sector_analysis.R    # GVA taxonomy, productivity, growth attribution
│   ├── time_series.R        # Seasonal adjustment, filter, stationarity checks
│   ├── forecasting.R        # ARIMA, Holt-Winters, Drift, Naive, rolling backtest
│   ├── validation.R         # National accounts schema & tolerance validation
│   ├── data_import.R        # Ingestion for CSV, JSON, Excel, RDS, API connectors
│   ├── uncertainty.R        # Prediction intervals, error metrics (MAE, RMSE, MAPE)
│   └── reporting.R          # Reproducible executive report generator
├── app/                     # R Shiny Interactive Terminal
│   ├── app.R                # Shiny UI & Server entrypoint with bslib
│   └── www/                 # Custom terminal styles
├── data/
│   ├── example/             # US, Euro Area, UK, Japan benchmark datasets
│   └── schemas/             # JSON schema validation definitions
├── tests/
│   ├── testthat.R           # Test runner
│   └── testthat/            # Unit & integration tests for all identities
├── reports/                 # RMarkdown executive report templates
└── docs/                    # Mathematical derivations & accounting conventions
```

---

## Quickstart

### R Package & Shiny Interactive Application
```r
# Restore reproducible package dependencies
renv::restore()

# Load the computational library
pkgload::load_all()

# Run the automated test suite
testthat::test_dir("tests/testthat")

# Launch the RhinoQuant Shiny Terminal
shiny::runApp("app")
```

---

## Implemented API Reference

- `gdp_expenditure(consumption, investment, government, exports, imports, unit, scale)`
- `gdp_production(sectors, taxes_on_products, subsidies_on_products, unit)`
- `gdp_income(compensation_employees, operating_surplus, mixed_income, net_taxes_products, net_taxes_production)`
- `gdp_reconcile_accounts(expenditure, production, income, tolerance_pct, published_discrepancy)`
- `gdp_nominal_to_real(nominal_gdp, deflator, base_year, method)`
- `gdp_deflator(nominal_gdp, real_gdp)`
- `gdp_growth_yoy(series, dates)`
- `gdp_growth_qoq(series, dates, seasonally_adjusted)`
- `gdp_growth_annualised(series, dates)`
- `gdp_per_capita(gdp, population, scale_gdp, scale_pop)`
- `gdp_sector_contributions(sector_data, base_total_gva)`
- `gdp_forecast(series, dates, horizon, model_type, confidence_levels)`
- `gdp_scenario_analysis(baseline, shocks, methodology)`
- `validate_national_accounts(data, schema)`
