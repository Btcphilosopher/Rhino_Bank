# RhinoQuant GDP Engine: Macroeconomic Equations & Accounting Conventions

## 1. System of National Accounts Framework
Calculations adhere strictly to the **United Nations System of National Accounts (SNA 2008)** and the **European System of Accounts (ESA 2010)**.

### The Three Approaches to Measuring GDP

#### A. Expenditure Approach
At purchasers' prices:
$$GDP = C + I + G + (X - M)$$
- **Private Final Consumption Expenditure ($C$):** Purchases of consumer goods and services by resident households and non-profit institutions serving households (NPISH).
- **Gross Capital Formation ($I$):** Gross fixed capital formation (GFCF) plus change in inventories plus net acquisition of valuables.
- **General Government Final Consumption ($G$):** Current expenditure by central, regional, and local governments for collective and individual services.
- **Exports ($X$) & Imports ($M$):** International trade in goods and services. Note: Imports enter negatively because $C, I, G$ contain imported intermediate and final goods; deducting $M$ ensures that only domestic production is counted.

#### B. Production (Value Added) Approach
At basic prices:
$$GVA_i = GrossOutput_i - IntermediateConsumption_i$$
Total economy Gross Value Added:
$$GVA = \sum_{i=1}^N GVA_i$$
Reconciled to GDP at market (purchasers') prices:
$$GDP = GVA + T_p - S_p$$
- **$T_p$:** Taxes on products (VAT, import duties, excise taxes).
- **$S_p$:** Subsidies on products.
*Crucial Principle:* Intermediate consumption is deducted at each stage to eliminate double counting.

#### C. Income Approach
At basic prices:
$$GVA = CE + GOS + GMI$$
- **$CE$:** Compensation of employees (gross wages, salaries, employer social contributions).
- **$GOS$:** Gross operating surplus of incorporated enterprises.
- **$GMI$:** Gross mixed income of unincorporated enterprises (where labor and capital returns cannot be separated).
Reconciled to GDP at market prices:
$$GDP = CE + GOS + GMI + (T_p - S_p) + (T_o - S_o)$$

---

## 2. Price Deflation & Volume Measures

### Implicit GDP Deflator
$$Deflator_t = \frac{NominalGDP_t}{RealGDP_t} \times 100$$

### Real GDP (Fixed-Base Constant Prices)
$$RealGDP_t = \frac{NominalGDP_t}{Deflator_t / 100}$$

### Chain-Volume Measures (Chained Laspeyres / Fisher)
Period-to-period volume growth rates $g_t^{vol}$ chained into an index:
$$I_t^{chain} = I_{t-1}^{chain} \times (1 + g_t^{vol})$$

---

## 3. Growth Analytics

### Quarter-on-Quarter (QoQ) Growth
$$g_t^{QoQ} = \left(\frac{GDP_t}{GDP_{t-1}} - 1\right) \times 100$$

### Annualised Quarterly Rate (SAAR)
$$g_t^{ann} = \left[\left(\frac{GDP_t}{GDP_{t-1}}\right)^4 - 1\right] \times 100$$

### Year-on-Year (YoY) Growth
$$g_t^{YoY} = \left(\frac{GDP_t}{GDP_{t-4}} - 1\right) \times 100$$

### Component Percentage-Point Contribution to Growth
$$C_k = \frac{\Delta Y_k}{GDP_{t-1}} \times 100$$
Note: $\sum_k C_k = g_{GDP,t}$. Percentage-point contributions differ mathematically from the individual component's percentage growth rate.

---

## 4. Econometric Diagnostics & Forecasting
- **Drift Benchmark:** $\hat{y}_{T+h} = y_T + h \left(\frac{y_T - y_1}{T - 1}\right)$
- **Naive Random Walk:** $\hat{y}_{T+h} = y_T$
- **ARIMA Model:** $\Phi(B)(1 - B)^d y_t = c + \Theta(B) \epsilon_t$
- **Prediction Intervals:** $\hat{y}_{T+h} \pm z_{\alpha/2} \cdot \sigma_h$
- **Forecast Error Metrics:** MAE, RMSE, and MAPE (with explicit note of MAPE limitations near zero).
