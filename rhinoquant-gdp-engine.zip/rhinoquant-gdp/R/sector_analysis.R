#' Decompose Sectoral Gross Value Added and Growth Contributions
#'
#' Evaluates industry-level dynamics:
#' \itemize{
#'   \item Gross Value Added: \eqn{GVA_i = GrossOutput_i - IntermediateConsumption_i}
#'   \item Share of Total Economy: \eqn{Share_i = \frac{GVA_i}{\sum_j GVA_j} \times 100}
#'   \item Contribution to Aggregate Growth: \eqn{Contribution_i = \frac{\Delta GVA_i}{TotalGVA_{t-1}} \times 100}
#'   \item Labour Productivity: \eqn{Productivity_i = \frac{GVA_i}{LabourInput_i}}
#' }
#'
#' @param sector_current Data.frame containing `sector`, `gross_output`, `intermediate_consumption`, and optional `employment`.
#' @param sector_previous Data.frame containing previous period values. Optional.
#'
#' @return A data.frame enriched with GVA, shares, growth rates, and growth contributions.
#' @export
gdp_sector_contributions <- function(sector_current, sector_previous = NULL) {
  if (!is.data.frame(sector_current)) {
    stop("Sector analysis error: 'sector_current' must be a data.frame.", call. = FALSE)
  }

  required <- c("sector", "gross_output", "intermediate_consumption")
  if (!all(required %in% names(sector_current))) {
    stop("Sector analysis error: 'sector_current' missing required columns.", call. = FALSE)
  }

  sector_current$gva <- sector_current$gross_output - sector_current$intermediate_consumption
  total_gva_curr <- sum(sector_current$gva)
  sector_current$share_pct <- round((sector_current$gva / total_gva_curr) * 100, 2)

  if (!is.null(sector_previous) && is.data.frame(sector_previous)) {
    sector_previous$gva_prev <- sector_previous$gross_output - sector_previous$intermediate_consumption
    total_gva_prev <- sum(sector_previous$gva_prev)

    merged <- merge(
      sector_current,
      sector_previous[, c("sector", "gva_prev")],
      by = "sector",
      all.x = TRUE
    )

    merged$gva_change <- merged$gva - merged$gva_prev
    merged$sector_growth_pct <- round(((merged$gva / merged$gva_prev) - 1) * 100, 2)
    merged$growth_contribution_pp <- round((merged$gva_change / total_gva_prev) * 100, 3)

    if ("employment" %in% names(merged) && all(!is.na(merged$employment))) {
      merged$labour_productivity <- round(merged$gva / merged$employment, 3)
    }

    return(merged[order(-merged$growth_contribution_pp), ])
  }

  if ("employment" %in% names(sector_current) && all(!is.na(sector_current$employment))) {
    sector_current$labour_productivity <- round(sector_current$gva / sector_current$employment, 3)
  }

  sector_current[order(-sector_current$share_pct), ]
}
