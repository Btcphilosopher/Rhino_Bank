#' Uncertainty Analysis and Prediction Fan Chart Builder
#'
#' Converts model point forecasts and residual standard errors into
#' calibrated probability fans:
#' \itemize{
#'   \item 50% central interval (z = 0.674)
#'   \item 80% central interval (z = 1.282)
#'   \item 95% central interval (z = 1.960)
#' }
#'
#' @param point_forecast Numeric vector of forecasted values.
#' @param std_error Numeric vector of forecast standard errors.
#'
#' @return A data.frame containing all interval boundaries.
#' @export
calculate_forecast_fan <- function(point_forecast, std_error) {
  h <- length(point_forecast)
  data.frame(
    step = seq_len(h),
    point = point_forecast,
    p50_lower = round(point_forecast - 0.674 * std_error, 2),
    p50_upper = round(point_forecast + 0.674 * std_error, 2),
    p80_lower = round(point_forecast - 1.282 * std_error, 2),
    p80_upper = round(point_forecast + 1.282 * std_error, 2),
    p95_lower = round(point_forecast - 1.960 * std_error, 2),
    p95_upper = round(point_forecast + 1.960 * std_error, 2)
  )
}
