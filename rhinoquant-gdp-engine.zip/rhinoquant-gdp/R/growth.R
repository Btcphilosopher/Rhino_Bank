#' Calculate Year-on-Year Growth Rate
#'
#' Computes the percentage change between period \eqn{t} and period \eqn{t-k}
#' (where \eqn{k = 1} for annual series, or \eqn{k = 4} for quarterly series):
#' \deqn{g_t^{YoY} = \left(\frac{GDP_t}{GDP_{t-k}} - 1\right) \times 100}
#'
#' @param series Numeric vector of GDP levels.
#' @param lag Integer. Number of lag periods (default 4 for quarterly data).
#'
#' @return Numeric vector of percentage growth rates with NA for initial lag periods.
#' @export
gdp_growth_yoy <- function(series, lag = 4) {
  if (!is.numeric(series)) stop("Growth calculation error: 'series' must be numeric.", call. = FALSE)
  n <- length(series)
  if (n <= lag) return(rep(NA_real_, n))

  growth <- rep(NA_real_, n)
  for (t in (lag + 1):n) {
    prev <- series[t - lag]
    if (!is.na(prev) && !is.na(series[t]) && abs(prev) > 1e-12) {
      growth[t] <- ((series[t] / prev) - 1) * 100
    }
  }
  round(growth, 3)
}

#' Calculate Quarter-on-Quarter Growth Rate
#'
#' Computes sequential quarterly growth from the immediately preceding quarter:
#' \deqn{g_t^{QoQ} = \left(\frac{GDP_t}{GDP_{t-1}} - 1\right) \times 100}
#'
#' @param series Numeric vector of GDP levels (must be seasonally adjusted).
#' @param seasonally_adjusted Logical. Affirms whether the series has been seasonally adjusted.
#'
#' @return Numeric vector of QoQ percentage growth rates.
#' @export
gdp_growth_qoq <- function(series, seasonally_adjusted = TRUE) {
  if (!seasonally_adjusted) {
    warning("Econometric notice: Computing sequential QoQ growth on non-seasonally adjusted data reflects seasonal patterns rather than underlying trend.", call. = FALSE)
  }
  gdp_growth_yoy(series, lag = 1)
}

#' Calculate Annualised Quarterly Growth Rate
#'
#' Compound annualised rate of growth implied by a single quarter's performance:
#' \deqn{g_{ann} = \left[\left(\frac{GDP_t}{GDP_{t-1}}\right)^4 - 1\right] \times 100}
#'
#' Note: This standard US BEA convention magnifies quarterly volatility and should
#' only be applied to seasonally adjusted quarterly data.
#'
#' @param series Numeric vector of seasonally adjusted quarterly GDP observations.
#'
#' @return Numeric vector of annualised quarterly percentage growth rates.
#' @export
gdp_growth_annualised <- function(series) {
  if (!is.numeric(series)) stop("Annualised growth error: 'series' must be numeric.", call. = FALSE)
  n <- length(series)
  if (n < 2) return(rep(NA_real_, n))

  out <- rep(NA_real_, n)
  for (t in 2:n) {
    prev <- series[t - 1]
    curr <- series[t]
    if (!is.na(prev) && !is.na(curr) && prev > 0) {
      out[t] <- (((curr / prev)^4) - 1) * 100
    }
  }
  round(out, 3)
}

#' Compound Annual Growth Rate (CAGR)
#'
#' Computes the annualized geometric growth rate between two points in time:
#' \deqn{CAGR = \left[\left(\frac{GDP_{end}}{GDP_{start}}\right)^{1/n} - 1\right] \times 100}
#'
#' @param start_value Numeric. Value at beginning of period.
#' @param end_value Numeric. Value at conclusion of period.
#' @param n_years Numeric. Time span in years.
#'
#' @return Numeric scalar CAGR percentage.
#' @export
gdp_cagr <- function(start_value, end_value, n_years) {
  if (start_value <= 0 || end_value <= 0 || n_years <= 0) {
    stop("CAGR error: Start value, end value, and years must be strictly positive.", call. = FALSE)
  }
  rate <- (((end_value / start_value)^(1 / n_years)) - 1) * 100
  round(rate, 3)
}

#' Calculate GDP Per Capita
#'
#' Derives output per individual in the population with strict scale reconciliation:
#' \deqn{GDPPerCapita = \frac{GDP \times Scale_{GDP}}{Population \times Scale_{Pop}}}
#'
#' @param gdp Numeric vector of GDP levels.
#' @param population Numeric vector of total population.
#' @param scale_gdp Character. e.g. "billions", "millions", "units".
#' @param scale_pop Character. e.g. "units", "millions", "thousands".
#'
#' @return Numeric vector of per-capita GDP in currency units per person.
#' @export
gdp_per_capita <- function(gdp, population, scale_gdp = "billions", scale_pop = "units") {
  scale_mult <- c(
    "units" = 1,
    "thousands" = 1e3,
    "millions" = 1e6,
    "billions" = 1e9,
    "trillions" = 1e12
  )

  if (length(gdp) != length(population)) {
    stop("Per capita error: GDP and population vectors must have identical lengths.", call. = FALSE)
  }
  if (any(population <= 0, na.rm = TRUE)) {
    stop("Per capita error: Population values must be strictly positive.", call. = FALSE)
  }

  gdp_in_units <- gdp * scale_mult[[scale_gdp]]
  pop_in_units <- population * scale_mult[[scale_pop]]

  round(gdp_in_units / pop_in_units, 2)
}

#' Calculate Component Percentage-Point Contributions to Real GDP Growth
#'
#' Decomposes overall GDP growth into the percentage points contributed by each
#' component \eqn{k}:
#' \deqn{Contribution_k = \frac{\Delta Y_{k,t}}{GDP_{t-1}} \times 100}
#'
#' Mathematical identity:
#' \deqn{\sum_{k} Contribution_k = g_{GDP,t}}
#'
#' @param component_changes Named numeric vector of period changes in components (\eqn{\Delta Y_k}).
#' @param base_gdp Numeric scalar of total GDP in the prior period (\eqn{GDP_{t-1}}).
#'
#' @return Named numeric vector of percentage-point contributions to aggregate growth.
#' @export
gdp_component_contributions <- function(component_changes, base_gdp) {
  if (is.null(base_gdp) || base_gdp <= 0) {
    stop("Contribution error: 'base_gdp' must be positive.", call. = FALSE)
  }
  round((component_changes / base_gdp) * 100, 3)
}
