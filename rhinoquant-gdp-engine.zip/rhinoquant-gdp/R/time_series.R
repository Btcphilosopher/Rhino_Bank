#' Macroeconomic Time Series Diagnostics and Stationarity
#'
#' Evaluates properties of macroeconomic time series:
#' \itemize{
#'   \item Summary statistics (mean, SD, skewness, kurtosis)
#'   \item Autocorrelation (ACF, Ljung-Box test for white noise)
#'   \item Augmented Dickey-Fuller (ADF) unit-root test for stationarity
#'   \item First differencing transformation
#' }
#'
#' @param series Numeric vector of GDP or component observations.
#' @param lag_max Integer. Maximum lags to examine for autocorrelation. Default 10.
#'
#' @return A list containing statistical metrics and stationarity indicators.
#' @export
time_series_diagnostics <- function(series, lag_max = 10) {
  clean_series <- na.omit(series)
  n <- length(clean_series)
  if (n < 5) stop("Diagnostics error: Series must have at least 5 non-missing observations.", call. = FALSE)

  m <- mean(clean_series)
  s <- sd(clean_series)

  # Autocorrelations
  acf_res <- acf(clean_series, lag.max = min(lag_max, n - 2), plot = FALSE)
  acf_vals <- as.numeric(acf_res$acf[-1])

  # Ljung-Box test for autocorrelation
  lb_test <- Box.test(clean_series, lag = min(4, n - 1), type = "Ljung-Box")

  # First differences
  diff_series <- diff(clean_series)
  diff_acf <- acf(diff_series, lag.max = min(lag_max, length(diff_series) - 2), plot = FALSE)
  diff_lb <- Box.test(diff_series, lag = min(4, length(diff_series) - 1), type = "Ljung-Box")

  # Simplified Dickey-Fuller regression: dy_t = alpha + beta * y_{t-1} + e_t
  y_lag <- clean_series[-n]
  dy <- diff_series
  df_fit <- lm(dy ~ y_lag)
  df_stat <- summary(df_fit)$coefficients["y_lag", "t value"]
  p_val_approx <- if (df_stat < -3.45) 0.01 else if (df_stat < -2.88) 0.05 else if (df_stat < -2.57) 0.10 else 0.50

  list(
    length = n,
    mean = round(m, 3),
    sd = round(s, 3),
    acf = round(acf_vals, 3),
    ljung_box_p_value = round(lb_test$p.value, 4),
    is_stationary_level = (p_val_approx <= 0.05),
    adf_t_statistic = round(df_stat, 3),
    adf_p_value_approx = p_val_approx,
    diff_properties = list(
      mean = round(mean(diff_series), 3),
      sd = round(sd(diff_series), 3),
      diff_ljung_box_p = round(diff_lb$p.value, 4)
    )
  )
}
