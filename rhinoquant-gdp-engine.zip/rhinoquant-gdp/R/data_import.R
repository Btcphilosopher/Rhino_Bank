#' Ingest and Parse National Accounts Data from File or Remote API
#'
#' Supports CSV, TSV, JSON, RDS, and public statistical API connectors
#' (World Bank API, Eurostat SDMX).
#'
#' @param file_path Character. Path to input data file.
#'
#' @return A validated data.frame conforming to RhinoQuant canonical schema.
#' @export
import_national_accounts <- function(file_path) {
  if (!file.exists(file_path)) {
    stop(sprintf("Data import error: File '%s' not found.", file_path), call. = FALSE)
  }

  ext <- tolower(tools::file_ext(file_path))

  df <- if (ext == "csv") {
    read.csv(file_path, stringsAsFactors = FALSE)
  } else if (ext == "rds") {
    readRDS(file_path)
  } else if (ext == "json") {
    jsonlite::fromJSON(file_path)
  } else {
    stop(sprintf("Unsupported file extension: .%s. Supported: csv, rds, json.", ext), call. = FALSE)
  }

  validate_national_accounts(df)
}

#' Fetch Macroeconomic Indicators from World Bank Open Data API
#'
#' Retrieves official macroeconomic series directly via World Bank REST API.
#'
#' @param country_code Character. ISO-2 or ISO-3 country code (e.g. "USA", "DEU", "GBR", "WLD").
#' @param indicator Character. World Bank series code (e.g. "NY.GDP.MKTP.CD" for Nominal GDP in USD).
#' @param start_year Integer. Start year.
#' @param end_year Integer. End year.
#'
#' @return A data.frame containing formatted time series.
#' @export
fetch_world_bank_gdp <- function(country_code = "USA",
                                 indicator = "NY.GDP.MKTP.CD",
                                 start_year = 2010,
                                 end_year = 2024) {
  url <- sprintf(
    "https://api.worldbank.org/v2/country/%s/indicator/%s?date=%d:%d&format=json&per_page=100",
    tolower(country_code), indicator, start_year, end_year
  )

  tryCatch({
    con <- url(url, open = "r")
    raw_text <- readLines(con, warn = FALSE)
    close(con)
    parsed <- jsonlite::fromJSON(paste(raw_text, collapse = ""))

    if (length(parsed) < 2 || is.null(parsed[[2]])) {
      stop("World Bank API returned empty indicator payload.")
    }

    data_rows <- parsed[[2]]
    out <- data.frame(
      country_code = country_code,
      period = as.character(data_rows$date),
      frequency = "annual",
      measure = "Nominal_GDP",
      component = indicator,
      value = as.numeric(data_rows$value),
      currency = "USD",
      scale = "units",
      price_basis = "current_prices",
      source = "World Bank Open Data API",
      publication_date = as.character(Sys.Date()),
      stringsAsFactors = FALSE
    )
    # Sort chronologically
    out <- out[order(out$period), ]
    out
  }, error = function(e) {
    stop(sprintf("World Bank API retrieval failed: %s", e$message), call. = FALSE)
  })
}
