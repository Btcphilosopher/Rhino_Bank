#' Calculate GDP via the Income Approach
#'
#' Evaluates the income-side macroeconomic accounting identity according to SNA 2008:
#' At basic prices:
#' \deqn{GVA = CE + GOS + GMI}
#' Reconciled to GDP at market prices:
#' \deqn{GDP = GVA + (T_p - S_p) + (T_o - S_o)}
#' where:
#' \itemize{
#'   \item \eqn{CE}: Compensation of Employees (wages, salaries, employer social contributions).
#'   \item \eqn{GOS}: Gross Operating Surplus (corporations).
#'   \item \eqn{GMI}: Gross Mixed Income (unincorporated enterprises / self-employed).
#'   \item \eqn{T_p - S_p}: Taxes less subsidies on products.
#'   \item \eqn{T_o - S_o}: Other taxes less subsidies on production.
#' }
#'
#' @param compensation_employees Numeric. Total compensation of employees (CE).
#' @param operating_surplus Numeric. Gross operating surplus (GOS).
#' @param mixed_income Numeric. Gross mixed income (GMI).
#' @param net_taxes_products Numeric. Taxes less subsidies on products (T_p - S_p).
#' @param net_taxes_production Numeric. Other taxes less subsidies on production (T_o - S_o). Default is 0.
#' @param unit Character. Currency code. Default is "USD".
#' @param scale Character. Scale magnitude ("billions", "millions", etc.). Default is "billions".
#'
#' @return A list of class `rhinoquant_income` containing:
#'   \item{gdp}{GDP at market prices.}
#'   \item{gva_basic}{Gross Value Added at basic prices.}
#'   \item{components}{Vector of primary income categories.}
#'   \item{shares}{Percentage shares of GVA.}
#'   \item{metadata}{Accounting metadata.}
#'
#' @export
gdp_income <- function(compensation_employees,
                       operating_surplus,
                       mixed_income,
                       net_taxes_products = 0,
                       net_taxes_production = 0,
                       unit = "USD",
                       scale = "billions") {
  # Input checks
  vals <- list(
    CE = compensation_employees,
    GOS = operating_surplus,
    GMI = mixed_income,
    NetTaxesProd = net_taxes_products,
    NetTaxesOther = net_taxes_production
  )

  for (k in names(vals)) {
    v <- vals[[k]]
    if (is.null(v) || is.na(v) || !is.numeric(v)) {
      stop(sprintf("Income approach error: '%s' must be a valid number.", k), call. = FALSE)
    }
  }

  gva_basic <- compensation_employees + operating_surplus + mixed_income
  total_gdp <- gva_basic + net_taxes_products + net_taxes_production

  shares <- if (abs(gva_basic) > 1e-12) {
    c(
      compensation_employees = (compensation_employees / gva_basic) * 100,
      operating_surplus = (operating_surplus / gva_basic) * 100,
      mixed_income = (mixed_income / gva_basic) * 100
    )
  } else {
    c(compensation_employees = 0, operating_surplus = 0, mixed_income = 0)
  }

  structure(
    list(
      gdp = total_gdp,
      gva_basic = gva_basic,
      net_taxes_products = net_taxes_products,
      net_taxes_production = net_taxes_production,
      components = c(
        CE = compensation_employees,
        GOS = operating_surplus,
        GMI = mixed_income,
        NetTaxesProducts = net_taxes_products,
        NetTaxesProduction = net_taxes_production
      ),
      shares = round(shares, 2),
      metadata = list(
        approach = "income",
        equation = "GDP = (CE + GOS + GMI) + (T_p - S_p) + (T_o - S_o)",
        unit = unit,
        scale = scale,
        timestamp = Sys.time()
      )
    ),
    class = "rhinoquant_income"
  )
}
