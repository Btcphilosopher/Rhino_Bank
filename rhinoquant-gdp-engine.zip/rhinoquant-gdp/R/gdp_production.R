#' Calculate GDP via the Production (Value Added) Approach
#'
#' Evaluates the production-side macroeconomic identity according to SNA 2008 / ESA 2010:
#' \deqn{GDP = \sum_{i} GVA_i + T_p - S_p}
#' where sectoral Gross Value Added is:
#' \deqn{GVA_i = GrossOutput_i - IntermediateConsumption_i}
#' and \eqn{T_p} represents taxes on products and \eqn{S_p} subsidies on products.
#'
#' Intermediate consumption is rigorously deducted to eliminate double counting.
#'
#' @param sectors A data.frame containing at least `sector` (character),
#'   `gross_output` (numeric), and `intermediate_consumption` (numeric).
#' @param taxes_on_products Numeric. Taxes on products (e.g. VAT, import duties, excise taxes).
#' @param subsidies_on_products Numeric. Subsidies on products. Default is 0.
#' @param unit Character. Currency code (e.g. "USD", "EUR"). Default is "USD".
#' @param scale Character. Magnitude scale: "units", "thousands", "millions", "billions", or "trillions".
#'
#' @return A list of class `rhinoquant_production` containing:
#'   \item{gdp}{GDP at market prices.}
#'   \item{total_gva}{Total Gross Value Added at basic prices.}
#'   \item{net_product_taxes}{Taxes on products minus subsidies on products.}
#'   \item{sector_table}{Data.frame with output, intermediate consumption, GVA, and sectoral share.}
#'   \item{metadata}{List with accounting standards, scale, unit, and timestamp.}
#'
#' @export
gdp_production <- function(sectors,
                           taxes_on_products = 0,
                           subsidies_on_products = 0,
                           unit = "USD",
                           scale = "billions") {
  if (!is.data.frame(sectors)) {
    stop("Production approach error: 'sectors' must be a data.frame.", call. = FALSE)
  }

  required_cols <- c("sector", "gross_output", "intermediate_consumption")
  missing_cols <- setdiff(required_cols, names(sectors))
  if (length(missing_cols) > 0) {
    stop(sprintf("Production approach error: 'sectors' is missing columns: %s", paste(missing_cols, collapse = ", ")), call. = FALSE)
  }

  if (any(is.na(sectors$gross_output)) || any(is.na(sectors$intermediate_consumption))) {
    stop("Production approach error: Sector output or intermediate consumption contains NA values.", call. = FALSE)
  }

  # Validate non-negative intermediate consumption
  if (any(sectors$intermediate_consumption < 0)) {
    stop("Production approach error: Intermediate consumption cannot be negative.", call. = FALSE)
  }

  if (is.null(taxes_on_products) || is.na(taxes_on_products) || !is.numeric(taxes_on_products)) {
    stop("Production approach error: 'taxes_on_products' must be a valid number.", call. = FALSE)
  }
  if (is.null(subsidies_on_products) || is.na(subsidies_on_products) || !is.numeric(subsidies_on_products)) {
    stop("Production approach error: 'subsidies_on_products' must be a valid number.", call. = FALSE)
  }

  # Calculate GVA for each sector
  sectors$gva <- sectors$gross_output - sectors$intermediate_consumption

  total_gva <- sum(sectors$gva)
  net_taxes <- taxes_on_products - subsidies_on_products
  total_gdp <- total_gva + net_taxes

  # Shares
  sectors$share_of_gva <- if (abs(total_gva) > 1e-12) {
    round((sectors$gva / total_gva) * 100, 2)
  } else {
    0
  }

  structure(
    list(
      gdp = total_gdp,
      total_gva = total_gva,
      net_product_taxes = net_taxes,
      taxes_on_products = taxes_on_products,
      subsidies_on_products = subsidies_on_products,
      sector_table = sectors,
      metadata = list(
        approach = "production",
        equation = "GDP = sum(GrossOutput_i - IntermediateConsumption_i) + Taxes_on_products - Subsidies_on_products",
        unit = unit,
        scale = scale,
        timestamp = Sys.time()
      )
    ),
    class = "rhinoquant_production"
  )
}
