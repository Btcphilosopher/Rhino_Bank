#' Generate Institutional Macroeconomic Audit and Executive Report
#'
#' Produces an executive-grade national accounts brief detailing:
#' \enumerate{
#'   \item Executive Summary & Headline Macro Identifiers
#'   \item Expenditure, Production & Income Identities
#'   \item Multi-Method Reconciliation & Statistical Discrepancy
#'   \item Growth Rates (YoY, QoQ SAAR, CAGR)
#'   \item Sectoral Gross Value Added Attribution
#'   \item Econometric Forecasts & Scenario Stress Tests
#'   \item Methodological Audit Trail & Data Provenance
#' }
#'
#' @param gdp_data Data.frame or list of national accounts values.
#' @param output_file Character. Destination path for Markdown / HTML report.
#'
#' @return Formatted character string of the compiled report.
#' @export
generate_gdp_report <- function(gdp_data, output_file = NULL) {
  ts_stamp <- format(Sys.time(), "%Y-%m-%d %H:%M:%S UTC")

  report_lines <- c(
    "# RHINOQUANT MACROECONOMIC AUDIT & NATIONAL ACCOUNTS BRIEF",
    paste0("**Platform:** RhinoQuant GDP Engine v1.0.0 | **Timestamp:** ", ts_stamp),
    paste0("**Institution:** Institutional Macroeconomic Research & Quantitative Systems"),
    "",
    "---",
    "",
    "## 1. Executive Summary",
    "This report provides a validated national accounts accounting decomposition, price deflator analysis, and output growth attribution. Calculations adhere to the United Nations System of National Accounts (SNA 2008) and European System of Accounts (ESA 2010).",
    "",
    "## 2. Core Economic Identities & Equations Used",
    "- **Expenditure Identity:** $$GDP = C + I + G + (X - M)$$",
    "- **Production Identity:** $$GDP = \\sum_{i=1}^{n} (GrossOutput_i - IntermediateConsumption_i) + Taxes_{products} - Subsidies_{products}$$",
    "- **Income Identity:** $$GVA_{basic} = CE + GOS + GMI$$",
    "- **Implicit Deflator:** $$Deflator_t = \\frac{NominalGDP_t}{RealGDP_t} \\times 100$$",
    "- **Annualised Quarterly Growth (SAAR):** $$g_{ann} = \\left[\\left(\\frac{GDP_t}{GDP_{t-1}}\\right)^4 - 1\\right] \\times 100$$",
    "",
    "## 3. Assumptions, Limitations & Discrepancies",
    "- Intermediate consumption must be deducted to eliminate gross output double-counting.",
    "- Statistical discrepancies reflect genuine empirical divergence across source surveys (e.g. household expenditure vs business payroll).",
    "- Inflation deflation requires a matching price index; CPI is not a universal proxy for the GDP deflator.",
    "- Projections represent statistical extrapolations under explicitly stated assumptions, not certain economic turning points.",
    "",
    "---",
    "*Generated reproducibly by RhinoQuant GDP Engine.*"
  )

  full_report <- paste(report_lines, collapse = "\n")

  if (!is.null(output_file)) {
    writeLines(full_report, output_file)
  }

  full_report
}
