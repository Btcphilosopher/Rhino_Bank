#' Calculate GDP via the Expenditure Approach
#'
#' Evaluates the canonical expenditure-side macroeconomic identity:
#' \deqn{GDP = C + I + G + (X - M)}
#' where \eqn{C} is private final consumption expenditure, \eqn{I} is gross
#' capital formation (including inventory change), \eqn{G} is government final
#' consumption expenditure, \eqn{X} is exports of goods and services, and
#' \eqn{M} is imports of goods and services.
#'
#' @param consumption Numeric. Private final consumption expenditure (C).
#' @param investment Numeric. Gross capital formation (I).
#' @param government Numeric. General government final consumption expenditure (G).
#' @param exports Numeric. Exports of goods and services (X).
#' @param imports Numeric. Imports of goods and services (M).
#' @param unit Character. Currency identifier, default is "USD".
#' @param scale Character. Magnitude scale: "units", "thousands", "millions", "billions", or "trillions".
#'
#' @return A list of class `rhinoquant_expenditure` containing:
#'   \item{gdp}{Calculated Gross Domestic Product at market prices.}
#'   \item{net_exports}{Trade balance (X - M).}
#'   \item{components}{Named numeric vector of each component value.}
#'   \item{shares}{Named numeric vector of percentage shares of total GDP.}
#'   \item{metadata}{List with unit, scale, method, and timestamp.}
#'
#' @examples
#' gdp_expenditure(
#'   consumption = 18269.4,
#'   investment = 4712.5,
#'   government = 4618.3,
#'   exports = 3055.2,
#'   imports = 3841.8,
#'   unit = "USD",
#'   scale = "billions"
#' )
#' @export
gdp_expenditure <- function(consumption,
                            investment,
                            government,
                            exports,
                            imports,
                            unit = "USD",
                            scale = "billions") {
  # Input validation
  inputs <- list(
    consumption = consumption,
    investment = investment,
    government = government,
    exports = exports,
    imports = imports
  )

  for (name in names(inputs)) {
    val <- inputs[[name]]
    if (is.null(val) || length(val) == 0 || is.na(val)) {
      stop(sprintf("Expenditure approach error: Component '%s' must not be missing or NA.", name), call. = FALSE)
    }
    if (!is.numeric(val)) {
      stop(sprintf("Expenditure approach error: Component '%s' must be numeric.", name), call. = FALSE)
    }
  }

  if (consumption < 0) {
    warning("Expenditure approach warning: Consumption is negative, which is economically anomalous.", call. = FALSE)
  }
  if (imports < 0) {
    stop("Expenditure approach error: Imports (M) cannot be negative; enter positive magnitude to be deducted.", call. = FALSE)
  }
  if (exports < 0) {
    stop("Expenditure approach error: Exports (X) cannot be negative.", call. = FALSE)
  }

  # Scale multipliers relative to base units
  scale_factors <- c(
    "units" = 1,
    "thousands" = 1e3,
    "millions" = 1e6,
    "billions" = 1e9,
    "trillions" = 1e12
  )

  if (!scale %in% names(scale_factors)) {
    stop(sprintf("Invalid scale '%s'. Choose from: %s", scale, paste(names(scale_factors), collapse = ", ")), call. = FALSE)
  }

  # Core calculation
  net_exports <- exports - imports
  total_gdp <- consumption + investment + government + net_exports

  # Expenditure component shares
  shares <- if (abs(total_gdp) > 1e-12) {
    c(
      consumption = (consumption / total_gdp) * 100,
      investment = (investment / total_gdp) * 100,
      government = (government / total_gdp) * 100,
      exports = (exports / total_gdp) * 100,
      imports = -(imports / total_gdp) * 100,
      net_exports = (net_exports / total_gdp) * 100
    )
  } else {
    c(consumption = 0, investment = 0, government = 0, exports = 0, imports = 0, net_exports = 0)
  }

  structure(
    list(
      gdp = total_gdp,
      net_exports = net_exports,
      components = c(
        C = consumption,
        I = investment,
        G = government,
        X = exports,
        M = imports,
        NX = net_exports
      ),
      shares = round(shares, 3),
      metadata = list(
        approach = "expenditure",
        equation = "GDP = C + I + G + (X - M)",
        unit = unit,
        scale = scale,
        scale_multiplier = unname(scale_factors[scale]),
        timestamp = Sys.time()
      )
    ),
    class = "rhinoquant_expenditure"
  )
}
