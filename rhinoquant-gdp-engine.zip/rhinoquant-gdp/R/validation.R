#' Validate National Accounts Data against Canonical Schema
#'
#' Verifies structure, non-null constraints, numerical plausibility, and
#' macroeconomic data integrity for uploaded datasets.
#'
#' Checks:
#' \itemize{
#'   \item Presence of mandatory columns: `country_code`, `period`, `measure`, `value`, `currency`, `scale`, `price_basis`.
#'   \item Detection of duplicated period observations.
#'   \item Detection of negative values in components where negative is invalid (e.g. imports, consumption, population).
#'   \item Currency and scale consistency.
#' }
#'
#' @param data A data.frame containing national accounts observations.
#' @param schema Optional JSON schema or path.
#'
#' @return A validated data.frame, or raises informative errors.
#' @export
validate_national_accounts <- function(data, schema = NULL) {
  if (!is.data.frame(data)) {
    stop("Data validation error: Object must be a data.frame.", call. = FALSE)
  }

  required_cols <- c("country_code", "period", "measure", "value", "currency", "scale", "price_basis")
  missing_cols <- setdiff(required_cols, names(data))
  if (length(missing_cols) > 0) {
    stop(sprintf("Data validation error: Missing required columns: %s", paste(missing_cols, collapse = ", ")), call. = FALSE)
  }

  if (any(is.na(data$period)) || any(data$period == "")) {
    stop("Data validation error: 'period' contains missing or blank values.", call. = FALSE)
  }

  if (any(is.na(data$value))) {
    warning("Data validation notice: Dataset contains NA values in 'value' column.", call. = FALSE)
  }

  # Check duplicate periods for the exact same country + measure + component
  group_cols <- c("country_code", "period", "measure")
  if ("component" %in% names(data)) group_cols <- c(group_cols, "component")

  dup_check <- duplicated(data[, group_cols])
  if (any(dup_check)) {
    warning(sprintf("Data validation warning: %d duplicate observation(s) identified for identical period and measure.", sum(dup_check)), call. = FALSE)
  }

  data
}
