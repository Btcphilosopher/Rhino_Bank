#' Reconcile Multiple GDP Accounting Approaches
#'
#' Evaluates differences across expenditure, production, and income estimates
#' of Gross Domestic Product.
#'
#' In official statistical compilation (e.g. US BEA, Eurostat, UK ONS, Japan ESRI),
#' empirical discrepancies arise from differing survey samples, revision vintages,
#' timing of VAT receipts, and customs trade valuations. This function computes
#' pairwise differences in both currency units and percentage terms, assesses
#' against a user-specified tolerance threshold, and incorporates published statistical
#' discrepancies without concealing raw source divergence.
#'
#' @param expenditure Result of `gdp_expenditure()` or numeric value of expenditure GDP.
#' @param production Result of `gdp_production()` or numeric value of production GDP.
#' @param income Result of `gdp_income()` or numeric value of income GDP. Optional.
#' @param tolerance_pct Numeric. Permissible discrepancy percentage threshold (default 0.10%).
#' @param published_discrepancy Numeric. Published statistical discrepancy reported by agency. Default 0.
#'
#' @return A list of class `rhinoquant_reconciliation` containing:
#'   \item{values}{Named vector of calculated GDP values by approach.}
#'   \item{differences_abs}{Matrix of absolute pairwise differences.}
#'   \item{differences_pct}{Matrix of percentage pairwise differences relative to expenditure base.}
#'   \item{unexplained_discrepancy}{Residual statistical discrepancy after accounting for published adjustment.}
#'   \item{within_tolerance}{Logical. TRUE if all pairwise differences are within `tolerance_pct`.}
#'   \item{audit_status}{Diagnostic character: 'BALANCED', 'DISCREPANCY_NOTED', or 'SEVERE_MISMATCH'.}
#'
#' @export
gdp_reconcile_accounts <- function(expenditure,
                                   production,
                                   income = NULL,
                                   tolerance_pct = 0.10,
                                   published_discrepancy = 0) {
  extract_gdp <- function(obj) {
    if (is.numeric(obj)) return(obj)
    if (is.list(obj) && "gdp" %in% names(obj)) return(obj$gdp)
    stop("Reconciliation error: Inputs must be numeric values or RhinoQuant GDP objects.", call. = FALSE)
  }

  exp_val <- extract_gdp(expenditure)
  prod_val <- extract_gdp(production)

  vals <- c(Expenditure = exp_val, Production = prod_val)
  if (!is.null(income)) {
    inc_val <- extract_gdp(income)
    vals <- c(vals, Income = inc_val)
  }

  n <- length(vals)
  diff_abs <- matrix(0, nrow = n, ncol = n, dimnames = list(names(vals), names(vals)))
  diff_pct <- matrix(0, nrow = n, ncol = n, dimnames = list(names(vals), names(vals)))

  for (i in seq_len(n)) {
    for (j in seq_len(n)) {
      diff_abs[i, j] <- vals[i] - vals[j]
      base <- abs(vals[j])
      if (base > 1e-12) {
        diff_pct[i, j] <- round(((vals[i] - vals[j]) / base) * 100, 4)
      } else {
        diff_pct[i, j] <- 0
      }
    }
  }

  # Primary discrepancy: Expenditure vs Production
  primary_diff_abs <- exp_val - prod_val
  primary_diff_pct <- if (abs(prod_val) > 1e-12) (primary_diff_abs / prod_val) * 100 else 0

  unexplained <- primary_diff_abs - published_discrepancy

  max_pct_diff <- max(abs(diff_pct))
  within_tol <- max_pct_diff <= tolerance_pct

  status <- if (max_pct_diff <= 1e-6) {
    "BALANCED"
  } else if (within_tol) {
    "DISCREPANCY_ACCEPTABLE"
  } else {
    "DISCREPANCY_EXCEEDS_TOLERANCE"
  }

  structure(
    list(
      values = vals,
      differences_abs = diff_abs,
      differences_pct = diff_pct,
      primary_discrepancy = list(
        absolute = primary_diff_abs,
        percentage = primary_diff_pct,
        published_adjustment = published_discrepancy,
        unexplained = unexplained
      ),
      tolerance_pct = tolerance_pct,
      within_tolerance = within_tol,
      audit_status = status,
      timestamp = Sys.time()
    ),
    class = "rhinoquant_reconciliation"
  )
}
