#' Calculate Real GDP from Nominal GDP and Price Deflator
#'
#' Converts nominal (current-price) GDP series to real (constant-price or
#' chain-volume) series using explicit deflator indices.
#'
#' For a fixed-base series:
#' \deqn{RealGDP_t = \frac{NominalGDP_t}{Deflator_t / 100}}
#'
#' @param nominal_gdp Numeric vector. Current-price GDP values.
#' @param deflator Numeric vector. Price deflator series with base value 100.
#' @param base_year Numeric or Character. Reference base year or period.
#' @param method Character. "fixed_base" or "chain_linked". Default is "fixed_base".
#'
#' @return Numeric vector of real GDP values with attributes retaining price basis and base year.
#' @export
gdp_nominal_to_real <- function(nominal_gdp, deflator, base_year = 2017, method = "fixed_base") {
  if (length(nominal_gdp) != length(deflator)) {
    stop("Deflation error: 'nominal_gdp' and 'deflator' vectors must have identical lengths.", call. = FALSE)
  }
  if (any(is.na(nominal_gdp)) || any(is.na(deflator))) {
    stop("Deflation error: Series contains missing or NA values.", call. = FALSE)
  }
  if (any(deflator <= 0)) {
    stop("Deflation error: Deflator index values must be strictly positive.", call. = FALSE)
  }

  real_gdp <- nominal_gdp / (deflator / 100)
  attr(real_gdp, "price_basis") <- method
  attr(real_gdp, "base_year") <- base_year
  real_gdp
}

#' Calculate Implicit GDP Price Deflator
#'
#' Computes the implicit GDP deflator as the ratio of nominal GDP to real GDP:
#' \deqn{GDPDeflator_t = \frac{NominalGDP_t}{RealGDP_t} \times 100}
#'
#' Note: The GDP deflator reflects price changes across all domestically produced
#' goods and services (including capital goods and government output), in contrast
#' to the Consumer Price Index (CPI) which reflects an urban consumer basket and includes imports.
#'
#' @param nominal_gdp Numeric vector. GDP in current prices.
#' @param real_gdp Numeric vector. GDP in constant/chained prices.
#'
#' @return Numeric vector representing the implicit price deflator indexed to 100 at the base period.
#' @export
gdp_deflator <- function(nominal_gdp, real_gdp) {
  if (length(nominal_gdp) != length(real_gdp)) {
    stop("Deflator calculation error: Series lengths must match.", call. = FALSE)
  }
  if (any(real_gdp == 0)) {
    stop("Deflator calculation error: Real GDP contains zero values, division undefined.", call. = FALSE)
  }
  round((nominal_gdp / real_gdp) * 100, 3)
}

#' Rebase Price Deflator or Constant-Price Series
#'
#' Mathematically rescales a fixed-base price index to a new reference period:
#' \deqn{Index_t^{new} = \frac{Index_t^{old}}{Index_{new\_base}^{old}} \times 100}
#'
#' Rebasing changes reported numerical levels and base period comparisons, but
#' does not alter underlying real economic volume growth rates.
#'
#' @param index_series Numeric vector. Original price or volume index.
#' @param periods Character or Numeric vector of observation periods.
#' @param new_base_period Character or Numeric. Period to set as 100.
#'
#' @return Numeric vector of rebased index values.
#' @export
rebase_series <- function(index_series, periods, new_base_period) {
  idx <- which(periods == new_base_period)
  if (length(idx) == 0) {
    stop(sprintf("Rebase error: Target period '%s' not found in provided periods.", new_base_period), call. = FALSE)
  }
  base_val <- index_series[idx[1]]
  if (base_val <= 0) {
    stop("Rebase error: Base period value must be positive.", call. = FALSE)
  }
  round((index_series / base_val) * 100, 3)
}
