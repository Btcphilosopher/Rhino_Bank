# RhinoQuant GDP Engine Runtime Profile
options(stringsAsFactors = FALSE)
options(scipen = 999)
options(digits = 7)
Sys.setenv(TZ = "UTC")

# Source R library functions into global environment if running in development mode
if (file.exists("R")) {
  r_files <- list.files("R", pattern = "\\.R$", full.names = TRUE)
  for (f in r_files) {
    source(f)
  }
}

message("RhinoQuant GDP Engine computational core loaded. Use `validate_national_accounts()` or launch `shiny::runApp('app')`.")
