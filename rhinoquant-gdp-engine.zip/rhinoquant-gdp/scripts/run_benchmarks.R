#!/usr/bin/env Rscript
# Automated benchmark and test validation script for RhinoQuant GDP Engine

message("=== RhinoQuant GDP Engine: Computational Verification ===")

# Source all R functions
r_files <- list.files("R", pattern = "\\.R$", full.names = TRUE)
for (f in r_files) {
  source(f)
}

# 1. Expenditure test
res_exp <- gdp_expenditure(
  consumption = 18269.4,
  investment = 4712.5,
  government = 4618.3,
  exports = 3055.2,
  imports = 3841.8,
  scale = "billions"
)
stopifnot(abs(res_exp$gdp - 26813.6) < 1e-4)
message(sprintf("[PASS] Expenditure Approach: GDP = %.2f billion USD", res_exp$gdp))

# 2. Production test
sectors <- data.frame(
  sector = c("Goods", "Services"),
  gross_output = c(12000, 32000),
  intermediate_consumption = c(6000, 13000)
)
res_prod <- gdp_production(sectors, taxes_on_products = 2200, subsidies_on_products = 386.4)
stopifnot(abs(res_prod$gdp - 26813.6) < 1e-4)
message(sprintf("[PASS] Production Approach: GDP = %.2f billion USD", res_prod$gdp))

# 3. Income test
res_inc <- gdp_income(
  compensation_employees = 14200,
  operating_surplus = 9100,
  mixed_income = 1700,
  net_taxes_products = 1813.6
)
stopifnot(abs(res_inc$gdp - 26813.6) < 1e-4)
message(sprintf("[PASS] Income Approach: GDP = %.2f billion USD", res_inc$gdp))

# 4. Reconciliation
rec <- gdp_reconcile_accounts(res_exp, res_prod, res_inc)
stopifnot(rec$within_tolerance)
message(sprintf("[PASS] Reconciliation Audit: Status = %s", rec$audit_status))

message("All economic identities verified successfully.")
