export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CNY';
export type Scale = 'units' | 'thousands' | 'millions' | 'billions' | 'trillions';
export type PriceBasis = 'current_prices' | 'constant_prices' | 'chained_volume';
export type Frequency = 'annual' | 'quarterly' | 'monthly';
export type SeasonalAdjustment = 'SA' | 'NSA' | 'SAAR';

export interface NationalAccountObservation {
  id: string;
  country_code: string;
  country_name: string;
  period: string;
  frequency: Frequency;
  measure: 'Nominal_GDP' | 'Real_GDP' | 'GDP_Deflator' | 'PCE' | 'GCF' | 'Govt' | 'Exports' | 'Imports' | 'GVA' | 'Statistical_Discrepancy';
  component: string;
  value: number;
  currency: Currency;
  scale: Scale;
  price_basis: PriceBasis;
  seasonal_adjustment: SeasonalAdjustment;
  source: string;
  publication_date: string;
  revision_vintage: string;
}

export interface ExpenditureComponents {
  C: number;  // Private final consumption expenditure
  I: number;  // Gross capital formation
  G: number;  // General government final consumption
  X: number;  // Exports of goods and services
  M: number;  // Imports of goods and services
}

export interface ExpenditureResult {
  gdp: number;
  net_exports: number;
  components: ExpenditureComponents;
  shares: {
    C: number;
    I: number;
    G: number;
    X: number;
    M: number;
    NX: number;
  };
  unit: Currency;
  scale: Scale;
}

export interface SectorItem {
  id: string;
  name: string;
  code: string;
  gross_output: number;
  intermediate_consumption: number;
  gva?: number;
  share_pct?: number;
  employment_thousands?: number;
  productivity?: number;
  growth_contribution_pp?: number;
}

export interface ProductionResult {
  gdp: number;
  total_gva: number;
  net_product_taxes: number;
  taxes_on_products: number;
  subsidies_on_products: number;
  sectors: SectorItem[];
  unit: Currency;
  scale: Scale;
}

export interface IncomeComponents {
  CE: number;            // Compensation of employees
  GOS: number;           // Gross operating surplus
  GMI: number;           // Gross mixed income
  net_taxes_products: number; // Taxes less subsidies on products
  net_taxes_production: number; // Other taxes less subsidies on production
}

export interface IncomeResult {
  gdp: number;
  gva_basic: number;
  components: IncomeComponents;
  shares: {
    CE: number;
    GOS: number;
    GMI: number;
  };
  unit: Currency;
  scale: Scale;
}

export interface ReconciliationResult {
  expenditure_gdp: number;
  production_gdp: number;
  income_gdp: number;
  discrepancy_exp_prod_abs: number;
  discrepancy_exp_prod_pct: number;
  discrepancy_exp_inc_abs: number;
  discrepancy_exp_inc_pct: number;
  published_discrepancy: number;
  unexplained_discrepancy: number;
  tolerance_pct: number;
  within_tolerance: boolean;
  status: 'BALANCED' | 'DISCREPANCY_ACCEPTABLE' | 'DISCREPANCY_EXCEEDS_TOLERANCE';
}

export interface ForecastPoint {
  period: string;
  point: number;
  lower_80: number;
  upper_80: number;
  lower_95: number;
  upper_95: number;
}

export interface ForecastResult {
  model_type: 'auto_arima' | 'ets' | 'drift' | 'naive';
  horizon: number;
  forecasts: ForecastPoint[];
  backtest: {
    sample_size: number;
    mae: number;
    rmse: number;
    mape: number | null;
  };
  equation_notes: string;
}

export interface ScenarioShock {
  component: 'C' | 'I' | 'G' | 'X' | 'M';
  shock_pct: number;
}

export interface ScenarioResult {
  baseline_gdp: number;
  scenario_gdp: number;
  delta_abs: number;
  delta_pct: number;
  stressed_components: ExpenditureComponents;
  contributions: {
    C: number;
    I: number;
    G: number;
    X: number;
    M: number;
  };
}

export interface CountryComparisonItem {
  country_code: string;
  country_name: string;
  reference_period: string;
  nominal_gdp_local: number;
  local_currency: Currency;
  nominal_gdp_usd: number;
  real_gdp_growth_yoy: number;
  gdp_per_capita_usd: number;
  gdp_ppp_usd: number;
  population_millions: number;
  source: string;
  last_updated: string;
}
