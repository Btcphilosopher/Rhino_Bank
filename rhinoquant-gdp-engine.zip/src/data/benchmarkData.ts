import { NationalAccountObservation, SectorItem, CountryComparisonItem } from '../types/gdp';

export interface EconomyProfile {
  country_code: string;
  country_name: string;
  currency: 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CNY';
  scale: 'billions';
  default_base_year: number;
  source_agency: string;
  population_millions: number;
  latest_period: string;
  observations: NationalAccountObservation[];
  default_sectors: SectorItem[];
  historical_real_gdp: { period: string; nominal: number; real: number; deflator: number }[];
}

export const BENCHMARK_ECONOMIES: Record<string, EconomyProfile> = {
  USA: {
    country_code: 'USA',
    country_name: 'United States',
    currency: 'USD',
    scale: 'billions',
    default_base_year: 2017,
    source_agency: 'U.S. Bureau of Economic Analysis (BEA)',
    population_millions: 336.5,
    latest_period: '2024-Q3',
    historical_real_gdp: [
      { period: '2022-Q1', nominal: 24740.5, real: 21738.9, deflator: 113.81 },
      { period: '2022-Q2', nominal: 25248.5, real: 21708.2, deflator: 116.31 },
      { period: '2022-Q3', nominal: 25726.4, real: 21851.1, deflator: 117.74 },
      { period: '2022-Q4', nominal: 26138.0, real: 21990.0, deflator: 118.86 },
      { period: '2023-Q1', nominal: 26813.6, real: 22112.3, deflator: 121.26 },
      { period: '2023-Q2', nominal: 27063.0, real: 22225.4, deflator: 121.77 },
      { period: '2023-Q3', nominal: 27610.1, real: 22490.7, deflator: 122.76 },
      { period: '2023-Q4', nominal: 27956.9, real: 22679.3, deflator: 123.27 },
      { period: '2024-Q1', nominal: 28284.5, real: 22758.8, deflator: 124.28 },
      { period: '2024-Q2', nominal: 28648.7, real: 22924.9, deflator: 124.97 },
      { period: '2024-Q3', nominal: 29016.4, real: 23084.2, deflator: 125.70 },
    ],
    default_sectors: [
      { id: '1', code: 'A', name: 'Agriculture, Forestry & Fishing', gross_output: 580, intermediate_consumption: 320, employment_thousands: 2100 },
      { id: '2', code: 'B_E', name: 'Mining, Utilities & Energy', gross_output: 1450, intermediate_consumption: 720, employment_thousands: 1350 },
      { id: '3', code: 'C', name: 'Manufacturing', gross_output: 6100, intermediate_consumption: 3750, employment_thousands: 12900 },
      { id: '4', code: 'F', name: 'Construction', gross_output: 2200, intermediate_consumption: 1240, employment_thousands: 8100 },
      { id: '5', code: 'G_I', name: 'Wholesale, Retail & Hospitality', gross_output: 5900, intermediate_consumption: 2550, employment_thousands: 25400 },
      { id: '6', code: 'J', name: 'Information & Telecommunications', gross_output: 3200, intermediate_consumption: 1150, employment_thousands: 3100 },
      { id: '7', code: 'K', name: 'Finance & Insurance', gross_output: 3850, intermediate_consumption: 1480, employment_thousands: 6800 },
      { id: '8', code: 'L', name: 'Real Estate & Rental', gross_output: 4600, intermediate_consumption: 920, employment_thousands: 2450 },
      { id: '9', code: 'M_N', name: 'Professional & Business Services', gross_output: 5100, intermediate_consumption: 1720, employment_thousands: 22800 },
      { id: '10', code: 'O_Q', name: 'Education, Health & Public Admin', gross_output: 6800, intermediate_consumption: 2250, employment_thousands: 34500 }
    ],
    observations: [
      {
        id: 'us-obs-1',
        country_code: 'USA',
        country_name: 'United States',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'Nominal_GDP',
        component: 'Total_GDP',
        value: 29016.4,
        currency: 'USD',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SAAR',
        source: 'U.S. Bureau of Economic Analysis',
        publication_date: '2024-11-27',
        revision_vintage: 'Second'
      },
      {
        id: 'us-obs-2',
        country_code: 'USA',
        country_name: 'United States',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'PCE',
        component: 'Personal_Consumption_Expenditure',
        value: 19735.6,
        currency: 'USD',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SAAR',
        source: 'U.S. Bureau of Economic Analysis',
        publication_date: '2024-11-27',
        revision_vintage: 'Second'
      },
      {
        id: 'us-obs-3',
        country_code: 'USA',
        country_name: 'United States',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'GCF',
        component: 'Gross_Private_Domestic_Investment',
        value: 5240.2,
        currency: 'USD',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SAAR',
        source: 'U.S. Bureau of Economic Analysis',
        publication_date: '2024-11-27',
        revision_vintage: 'Second'
      },
      {
        id: 'us-obs-4',
        country_code: 'USA',
        country_name: 'United States',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'Govt',
        component: 'Government_Consumption_Investment',
        value: 5068.3,
        currency: 'USD',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SAAR',
        source: 'U.S. Bureau of Economic Analysis',
        publication_date: '2024-11-27',
        revision_vintage: 'Second'
      },
      {
        id: 'us-obs-5',
        country_code: 'USA',
        country_name: 'United States',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'Exports',
        component: 'Exports_Goods_Services',
        value: 3192.1,
        currency: 'USD',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SAAR',
        source: 'U.S. Bureau of Economic Analysis',
        publication_date: '2024-11-27',
        revision_vintage: 'Second'
      },
      {
        id: 'us-obs-6',
        country_code: 'USA',
        country_name: 'United States',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'Imports',
        component: 'Imports_Goods_Services',
        value: 4219.8,
        currency: 'USD',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SAAR',
        source: 'U.S. Bureau of Economic Analysis',
        publication_date: '2024-11-27',
        revision_vintage: 'Second'
      }
    ]
  },

  EA20: {
    country_code: 'EA20',
    country_name: 'Euro Area (20 Countries)',
    currency: 'EUR',
    scale: 'billions',
    default_base_year: 2015,
    source_agency: 'Eurostat (ESA 2010)',
    population_millions: 350.2,
    latest_period: '2024-Q3',
    historical_real_gdp: [
      { period: '2022-Q1', nominal: 3290.1, real: 2854.2, deflator: 115.27 },
      { period: '2022-Q2', nominal: 3365.4, real: 2878.5, deflator: 116.92 },
      { period: '2022-Q3', nominal: 3420.2, real: 2892.4, deflator: 118.25 },
      { period: '2022-Q4', nominal: 3460.5, real: 2890.1, deflator: 119.74 },
      { period: '2023-Q1', nominal: 3510.4, real: 2910.8, deflator: 120.60 },
      { period: '2023-Q2', nominal: 3548.2, real: 2914.5, deflator: 121.74 },
      { period: '2023-Q3', nominal: 3579.5, real: 2911.2, deflator: 122.96 },
      { period: '2023-Q4', nominal: 3612.0, real: 2912.9, deflator: 124.00 },
      { period: '2024-Q1', nominal: 3658.7, real: 2921.8, deflator: 125.22 },
      { period: '2024-Q2', nominal: 3695.1, real: 2927.4, deflator: 126.23 },
      { period: '2024-Q3', nominal: 3732.4, real: 2939.1, deflator: 126.99 }
    ],
    default_sectors: [
      { id: 'ea-1', code: 'A', name: 'Agriculture, Forestry & Fishing', gross_output: 140, intermediate_consumption: 78, employment_thousands: 4800 },
      { id: 'ea-2', code: 'C', name: 'Manufacturing & Industry', gross_output: 1480, intermediate_consumption: 920, employment_thousands: 24500 },
      { id: 'ea-3', code: 'F', name: 'Construction', gross_output: 390, intermediate_consumption: 215, employment_thousands: 10200 },
      { id: 'ea-4', code: 'G_I', name: 'Trade, Transport & Food Services', gross_output: 1120, intermediate_consumption: 530, employment_thousands: 38200 },
      { id: 'ea-5', code: 'K_L', name: 'Financial, Insurance & Real Estate', gross_output: 980, intermediate_consumption: 320, employment_thousands: 9400 },
      { id: 'ea-6', code: 'O_Q', name: 'Public Admin, Health & Education', gross_output: 1250, intermediate_consumption: 410, employment_thousands: 41000 }
    ],
    observations: [
      {
        id: 'ea-obs-1',
        country_code: 'EA20',
        country_name: 'Euro Area',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'Nominal_GDP',
        component: 'Total_GDP',
        value: 3732.4,
        currency: 'EUR',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SA',
        source: 'Eurostat',
        publication_date: '2024-11-14',
        revision_vintage: 'Flash'
      },
      {
        id: 'ea-obs-2',
        country_code: 'EA20',
        country_name: 'Euro Area',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'PCE',
        component: 'Household_Consumption',
        value: 1980.2,
        currency: 'EUR',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SA',
        source: 'Eurostat',
        publication_date: '2024-11-14',
        revision_vintage: 'Flash'
      },
      {
        id: 'ea-obs-3',
        country_code: 'EA20',
        country_name: 'Euro Area',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'GCF',
        component: 'Gross_Capital_Formation',
        value: 812.5,
        currency: 'EUR',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SA',
        source: 'Eurostat',
        publication_date: '2024-11-14',
        revision_vintage: 'Flash'
      },
      {
        id: 'ea-obs-4',
        country_code: 'EA20',
        country_name: 'Euro Area',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'Govt',
        component: 'Government_Final_Consumption',
        value: 775.1,
        currency: 'EUR',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SA',
        source: 'Eurostat',
        publication_date: '2024-11-14',
        revision_vintage: 'Flash'
      },
      {
        id: 'ea-obs-5',
        country_code: 'EA20',
        country_name: 'Euro Area',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'Exports',
        component: 'Exports_Goods_Services',
        value: 1890.4,
        currency: 'EUR',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SA',
        source: 'Eurostat',
        publication_date: '2024-11-14',
        revision_vintage: 'Flash'
      },
      {
        id: 'ea-obs-6',
        country_code: 'EA20',
        country_name: 'Euro Area',
        period: '2024-Q3',
        frequency: 'quarterly',
        measure: 'Imports',
        component: 'Imports_Goods_Services',
        value: 1725.8,
        currency: 'EUR',
        scale: 'billions',
        price_basis: 'current_prices',
        seasonal_adjustment: 'SA',
        source: 'Eurostat',
        publication_date: '2024-11-14',
        revision_vintage: 'Flash'
      }
    ]
  },

  GBR: {
    country_code: 'GBR',
    country_name: 'United Kingdom',
    currency: 'GBP',
    scale: 'billions',
    default_base_year: 2022,
    source_agency: 'Office for National Statistics (ONS)',
    population_millions: 68.2,
    latest_period: '2024-Q3',
    historical_real_gdp: [
      { period: '2022-Q1', nominal: 615.2, real: 564.0, deflator: 109.08 },
      { period: '2022-Q2', nominal: 630.4, real: 564.5, deflator: 111.67 },
      { period: '2022-Q3', nominal: 642.1, real: 563.8, deflator: 113.89 },
      { period: '2022-Q4', nominal: 651.8, real: 564.9, deflator: 115.38 },
      { period: '2023-Q1', nominal: 662.3, real: 566.2, deflator: 116.97 },
      { period: '2023-Q2', nominal: 671.0, real: 566.0, deflator: 118.55 },
      { period: '2023-Q3', nominal: 678.4, real: 565.4, deflator: 119.99 },
      { period: '2023-Q4', nominal: 684.1, real: 563.8, deflator: 121.34 },
      { period: '2024-Q1', nominal: 694.5, real: 567.8, deflator: 122.31 },
      { period: '2024-Q2', nominal: 703.2, real: 570.6, deflator: 123.24 },
      { period: '2024-Q3', nominal: 708.9, real: 571.2, deflator: 124.11 }
    ],
    default_sectors: [
      { id: 'uk-1', code: 'C', name: 'Manufacturing', gross_output: 380, intermediate_consumption: 245, employment_thousands: 2600 },
      { id: 'uk-2', code: 'G', name: 'Wholesale & Retail Trade', gross_output: 420, intermediate_consumption: 195, employment_thousands: 4800 },
      { id: 'uk-3', code: 'K', name: 'Financial & Insurance Services', gross_output: 395, intermediate_consumption: 140, employment_thousands: 1550 },
      { id: 'uk-4', code: 'M', name: 'Professional, Scientific & Technical', gross_output: 350, intermediate_consumption: 125, employment_thousands: 3400 },
      { id: 'uk-5', code: 'O_Q', name: 'Public Sector, Health & Education', gross_output: 460, intermediate_consumption: 135, employment_thousands: 8600 }
    ],
    observations: []
  },

  JPN: {
    country_code: 'JPN',
    country_name: 'Japan',
    currency: 'JPY',
    scale: 'billions',
    default_base_year: 2015,
    source_agency: 'Cabinet Office, Government of Japan (ESRI)',
    population_millions: 124.5,
    latest_period: '2024-Q3',
    historical_real_gdp: [
      { period: '2022-Q1', nominal: 140500, real: 138200, deflator: 101.66 },
      { period: '2022-Q2', nominal: 142100, real: 139500, deflator: 101.86 },
      { period: '2022-Q3', nominal: 143200, real: 139100, deflator: 102.95 },
      { period: '2022-Q4', nominal: 144800, real: 139700, deflator: 103.65 },
      { period: '2023-Q1', nominal: 146900, real: 141200, deflator: 104.04 },
      { period: '2023-Q2', nominal: 148800, real: 142400, deflator: 104.49 },
      { period: '2023-Q3', nominal: 148500, real: 141100, deflator: 105.24 },
      { period: '2023-Q4', nominal: 149200, real: 141250, deflator: 105.63 },
      { period: '2024-Q1', nominal: 149600, real: 140400, deflator: 106.55 },
      { period: '2024-Q2', nominal: 151200, real: 141500, deflator: 106.86 },
      { period: '2024-Q3', nominal: 152100, real: 141800, deflator: 107.26 }
    ],
    default_sectors: [
      { id: 'jp-1', code: 'C', name: 'Manufacturing (Auto, Electronics, Steel)', gross_output: 110000, intermediate_consumption: 68000, employment_thousands: 10500 },
      { id: 'jp-2', code: 'G', name: 'Wholesale & Retail', gross_output: 54000, intermediate_consumption: 25000, employment_thousands: 10200 },
      { id: 'jp-3', code: 'K', name: 'Finance & Real Estate', gross_output: 48000, intermediate_consumption: 16000, employment_thousands: 3500 },
      { id: 'jp-4', code: 'O_Q', name: 'Medical, Health & Care Services', gross_output: 42000, intermediate_consumption: 14000, employment_thousands: 9100 }
    ],
    observations: []
  }
};

export const INTERNATIONAL_BENCHMARK_LIST: CountryComparisonItem[] = [
  {
    country_code: 'USA',
    country_name: 'United States',
    reference_period: '2024-Q3',
    nominal_gdp_local: 29016.4,
    local_currency: 'USD',
    nominal_gdp_usd: 29016.4,
    real_gdp_growth_yoy: 2.7,
    gdp_per_capita_usd: 86230,
    gdp_ppp_usd: 29016.4,
    population_millions: 336.5,
    source: 'U.S. BEA',
    last_updated: '2024-11-27'
  },
  {
    country_code: 'CHN',
    country_name: 'China',
    reference_period: '2024-Q3',
    nominal_gdp_local: 130500.0,
    local_currency: 'CNY',
    nominal_gdp_usd: 18125.0,
    real_gdp_growth_yoy: 4.8,
    gdp_per_capita_usd: 12860,
    gdp_ppp_usd: 35290.0,
    population_millions: 1409.0,
    source: 'National Bureau of Statistics',
    last_updated: '2024-10-18'
  },
  {
    country_code: 'DEU',
    country_name: 'Germany',
    reference_period: '2024-Q3',
    nominal_gdp_local: 4280.0,
    local_currency: 'EUR',
    nominal_gdp_usd: 4622.4,
    real_gdp_growth_yoy: 0.1,
    gdp_per_capita_usd: 54700,
    gdp_ppp_usd: 5685.0,
    population_millions: 84.5,
    source: 'Federal Statistical Office (Destatis)',
    last_updated: '2024-11-22'
  },
  {
    country_code: 'JPN',
    country_name: 'Japan',
    reference_period: '2024-Q3',
    nominal_gdp_local: 608400.0,
    local_currency: 'JPY',
    nominal_gdp_usd: 4110.8,
    real_gdp_growth_yoy: 0.5,
    gdp_per_capita_usd: 33020,
    gdp_ppp_usd: 6720.0,
    population_millions: 124.5,
    source: 'Cabinet Office (ESRI)',
    last_updated: '2024-11-15'
  },
  {
    country_code: 'GBR',
    country_name: 'United Kingdom',
    reference_period: '2024-Q3',
    nominal_gdp_local: 2835.6,
    local_currency: 'GBP',
    nominal_gdp_usd: 3601.2,
    real_gdp_growth_yoy: 1.0,
    gdp_per_capita_usd: 52800,
    gdp_ppp_usd: 4050.0,
    population_millions: 68.2,
    source: 'Office for National Statistics',
    last_updated: '2024-11-15'
  },
  {
    country_code: 'FRA',
    country_name: 'France',
    reference_period: '2024-Q3',
    nominal_gdp_local: 2950.0,
    local_currency: 'EUR',
    nominal_gdp_usd: 3186.0,
    real_gdp_growth_yoy: 1.3,
    gdp_per_capita_usd: 46720,
    gdp_ppp_usd: 3980.0,
    population_millions: 68.2,
    source: 'INSEE',
    last_updated: '2024-10-30'
  },
  {
    country_code: 'IND',
    country_name: 'India',
    reference_period: '2024-Q3',
    nominal_gdp_local: 325000.0,
    local_currency: 'USD',
    nominal_gdp_usd: 3950.0,
    real_gdp_growth_yoy: 5.4,
    gdp_per_capita_usd: 2780,
    gdp_ppp_usd: 14590.0,
    population_millions: 1421.0,
    source: 'Ministry of Statistics & PI',
    last_updated: '2024-11-29'
  }
];
