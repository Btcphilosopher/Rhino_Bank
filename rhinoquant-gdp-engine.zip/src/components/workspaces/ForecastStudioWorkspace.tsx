import React, { useState, useMemo } from 'react';
import { BENCHMARK_ECONOMIES } from '../../data/benchmarkData';
import { generateForecast } from '../../engine/macro_engine';
import { AlertCircle, TrendingUp, Sliders, Play } from 'lucide-react';

interface ForecastStudioWorkspaceProps {
  selectedEconomy: string;
}

export const ForecastStudioWorkspace: React.FC<ForecastStudioWorkspaceProps> = ({
  selectedEconomy
}) => {
  const eco = BENCHMARK_ECONOMIES[selectedEconomy] || BENCHMARK_ECONOMIES.USA;
  const history = eco.historical_real_gdp;

  const [modelType, setModelType] = useState<'auto_arima' | 'ets' | 'drift' | 'naive'>('auto_arima');
  const [horizon, setHorizon] = useState<number>(8);
  const [estimationWindow, setEstimationWindow] = useState<number>(history.length);

  // Run Forecast Engine
  const forecastResult = useMemo(() => {
    const activeHistory = history.slice(history.length - estimationWindow);
    const series = activeHistory.map((h) => h.real);
    const periods = activeHistory.map((h) => h.period);

    return generateForecast(series, periods, horizon, modelType);
  }, [history, estimationWindow, horizon, modelType]);

  const latestObs = history[history.length - 1];

  return (
    <div className="space-y-6">
      {/* Workspace Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#2A3644]">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
            GDP Forecast Studio & Out-of-Sample Laboratory
          </h2>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Statistical projection models, calibrated predictive intervals, and rolling-origin backtesting.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-[#A8B2BC]">Model Family:</span>
          <select
            value={modelType}
            onChange={(e) => setModelType(e.target.value as any)}
            className="bg-[#192B40] border border-[#2A3644] rounded px-3 py-1.5 text-xs text-[#F3F5F7] font-medium focus:outline-none focus:border-[#527DA5]"
          >
            <option value="auto_arima">Auto-ARIMA (1,1,0) with Drift</option>
            <option value="ets">Holt-Winters Trend Exponential Smoothing (ETS)</option>
            <option value="drift">Drift Benchmark (Random Walk with Trend)</option>
            <option value="naive">Naive Random Walk Benchmark</option>
          </select>
        </div>
      </div>

      {/* Model Spec & Diagnostics Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Out-of-Sample MAE</div>
          <div className="text-2xl font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
            {forecastResult.backtest.mae.toFixed(2)}{' '}
            <span className="text-xs text-[#A8B2BC] font-sans font-normal">{eco.currency} {eco.scale}</span>
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Mean Absolute Error ({forecastResult.backtest.sample_size} quarters backtest)</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Out-of-Sample RMSE</div>
          <div className="text-2xl font-bold font-mono text-[#527DA5] mt-1 tabular-nums">
            {forecastResult.backtest.rmse.toFixed(2)}{' '}
            <span className="text-xs text-[#A8B2BC] font-sans font-normal">{eco.currency}</span>
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Root Mean Squared Error</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Backtest MAPE</div>
          <div className="text-2xl font-bold font-mono text-[#43866B] mt-1 tabular-nums">
            {forecastResult.backtest.mape !== null ? `${forecastResult.backtest.mape.toFixed(2)}%` : 'N/A'}
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Mean Absolute Percentage Error</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Active Estimation Horizon</div>
          <div className="text-2xl font-bold font-mono text-[#D5A04B] mt-1 tabular-nums">
            +{horizon} Quarters
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Through {forecastResult.forecasts[forecastResult.forecasts.length - 1]?.period}</div>
        </div>
      </div>

      {/* Epistemological Uncertainty Caveat */}
      <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded-lg text-xs text-[#A8B2BC] flex items-start gap-3">
        <AlertCircle className="w-4 h-4 text-[#D5A04B] shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-semibold text-[#F3F5F7]">Econometric Uncertainty & Turning Point Disclosure: </span>
          Point forecasts represent mathematical expected values conditioned on historical structural persistence. Time-series models cannot reliably predict exogenous economic turning points, financial crises, fiscal shocks, or structural regulatory changes. Intervals expand with the square root of horizon time (proportional to sqrt(h)) to reflect accumulating uncertainty. Furthermore, MAPE is invalid whenever economic series approach zero.
        </div>
      </div>

      {/* Main Table: Forecast Points & Intervals */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A3644] pb-2">
            <h3 className="text-sm font-semibold text-[#F3F5F7] flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#527DA5]" />
              <span>Projected Path & Calibrated Confidence Bands</span>
            </h3>
            <span className="text-xs font-mono text-[#A8B2BC]">
              Base: {latestObs.period} ({latestObs.real.toFixed(1)} {eco.currency})
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-[#F3F5F7]">
              <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-2.5 px-3">Horizon</th>
                  <th className="py-2.5 px-3">Period</th>
                  <th className="py-2.5 px-3 text-right">Point Forecast</th>
                  <th className="py-2.5 px-3 text-right">80% Lower</th>
                  <th className="py-2.5 px-3 text-right">80% Upper</th>
                  <th className="py-2.5 px-3 text-right">95% Lower</th>
                  <th className="py-2.5 px-3 text-right">95% Upper</th>
                  <th className="py-2.5 px-3 text-right">Implied Ann. Growth</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A3644] font-mono text-[11px]">
                {forecastResult.forecasts.map((fc, idx) => {
                  const prevLevel = idx === 0 ? latestObs.real : forecastResult.forecasts[idx - 1].point;
                  const impliedAnn = (Math.pow(fc.point / prevLevel, 4) - 1) * 100;
                  return (
                    <tr key={fc.period} className="hover:bg-[#15191E]/40">
                      <td className="py-2.5 px-3 text-[#527DA5] font-semibold">T+{idx + 1}</td>
                      <td className="py-2.5 px-3 font-sans font-medium text-[#F3F5F7]">{fc.period}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-[#43866B] tabular-nums">
                        {fc.point.toFixed(1)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-[#A8B2BC] tabular-nums">
                        {fc.lower_80.toFixed(1)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-[#A8B2BC] tabular-nums">
                        {fc.upper_80.toFixed(1)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-[#566575] tabular-nums">
                        {fc.lower_95.toFixed(1)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-[#566575] tabular-nums">
                        {fc.upper_95.toFixed(1)}
                      </td>
                      <td className="py-2.5 px-3 text-right tabular-nums text-[#527DA5] font-semibold">
                        +{impliedAnn.toFixed(2)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Model Specification & Controls */}
        <div className="lg:col-span-4 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2 flex items-center gap-1.5">
            <Sliders className="w-4 h-4 text-[#527DA5]" />
            <span>Estimation Controls</span>
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                <span>Forecast Horizon</span>
                <span className="font-mono text-[#F3F5F7]">{horizon} Quarters</span>
              </div>
              <input
                type="range"
                min="1"
                max="16"
                value={horizon}
                onChange={(e) => setHorizon(parseInt(e.target.value, 10))}
                className="w-full accent-[#527DA5] h-1.5 bg-[#15191E] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                <span>Estimation Window</span>
                <span className="font-mono text-[#F3F5F7]">{estimationWindow} Periods</span>
              </div>
              <input
                type="range"
                min="6"
                max={history.length}
                value={estimationWindow}
                onChange={(e) => setEstimationWindow(parseInt(e.target.value, 10))}
                className="w-full accent-[#527DA5] h-1.5 bg-[#15191E] rounded cursor-pointer"
              />
            </div>
          </div>

          <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded space-y-2 text-xs">
            <div className="font-semibold text-[#F3F5F7]">Model Specification:</div>
            <div className="font-mono text-[11px] text-[#527DA5] break-words">
              {forecastResult.equation_notes}
            </div>
            <p className="text-[11px] text-[#566575]">
              Intervals: 80% (z = 1.282), 95% (z = 1.960). Residual volatility calibrated from sample variance σ = sqrt(Var(Δy_t)).
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
