import React, { useState, useMemo } from 'react';
import { BENCHMARK_ECONOMIES } from '../../data/benchmarkData';
import { runOlsRegression } from '../../engine/macro_engine';
import { AlertCircle, FlaskConical, CheckSquare } from 'lucide-react';

interface EconometricLabWorkspaceProps {
  selectedEconomy: string;
}

export const EconometricLabWorkspace: React.FC<EconometricLabWorkspaceProps> = ({
  selectedEconomy
}) => {
  const eco = BENCHMARK_ECONOMIES[selectedEconomy] || BENCHMARK_ECONOMIES.USA;
  const history = eco.historical_real_gdp;

  const [depVar, setDepVar] = useState<'real' | 'nominal' | 'growth'>('real');
  const [indepVar, setIndepVar] = useState<'deflator' | 'lagged_real'>('deflator');
  const [useDifferences, setUseDifferences] = useState<boolean>(true);

  // Prepare regression series
  const regressionResults = useMemo(() => {
    const rawReal = history.map((h) => h.real);
    const rawNominal = history.map((h) => h.nominal);
    const rawDeflator = history.map((h) => h.deflator);

    let y: number[] = [];
    let x: number[] = [];

    if (useDifferences) {
      // First differences (stationarity transformation)
      if (depVar === 'real') {
        for (let i = 1; i < rawReal.length; i++) y.push(rawReal[i] - rawReal[i - 1]);
      } else if (depVar === 'nominal') {
        for (let i = 1; i < rawNominal.length; i++) y.push(rawNominal[i] - rawNominal[i - 1]);
      } else {
        // growth
        for (let i = 1; i < rawReal.length; i++) y.push(((rawReal[i] / rawReal[i - 1]) - 1) * 100);
      }

      if (indepVar === 'deflator') {
        for (let i = 1; i < rawDeflator.length; i++) x.push(rawDeflator[i] - rawDeflator[i - 1]);
      } else {
        // lagged change
        for (let i = 1; i < rawReal.length; i++) x.push(i > 1 ? rawReal[i - 1] - rawReal[i - 2] : 0);
      }
    } else {
      // Trending levels (demonstrates spurious regression hazard)
      y = depVar === 'real' ? rawReal : depVar === 'nominal' ? rawNominal : rawReal;
      x = indepVar === 'deflator' ? rawDeflator : [rawReal[0], ...rawReal.slice(0, rawReal.length - 1)];
    }

    try {
      return runOlsRegression(y, x);
    } catch {
      return null;
    }
  }, [history, depVar, indepVar, useDifferences]);

  // Unit root (ADF proxy) test
  const rawReal = history.map((h) => h.real);
  const diffs: number[] = [];
  for (let i = 1; i < rawReal.length; i++) diffs.push(rawReal[i] - rawReal[i - 1]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#2A3644]">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
            Macroeconometric Diagnostics & Regression Laboratory
          </h2>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Unit-root stationarity, White heteroskedasticity-robust standard errors, and spurious regression protection.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 text-xs text-[#F3F5F7] bg-[#192B40] border border-[#2A3644] px-3 py-1.5 rounded cursor-pointer">
            <input
              type="checkbox"
              checked={useDifferences}
              onChange={(e) => setUseDifferences(e.target.checked)}
              className="accent-[#527DA5] rounded"
            />
            <span>First-Difference Transformation (Δy_t)</span>
          </label>
        </div>
      </div>

      {/* Spurious Regression Warning */}
      {!useDifferences ? (
        <div className="p-3 bg-[#C65454]/15 border border-[#C65454]/30 rounded-lg text-xs text-[#C65454] flex items-start gap-3">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-semibold">Econometric Warning (Spurious Correlation Hazard): </span>
            You are currently estimating a regression between trending non-stationary level series ($I(1)$ processes). As demonstrated by Granger and Newbold (1974), regressions between trending macroeconomic series yield spuriously high $R^2$ values and inflated t-statistics with non-standard t-distributions. Select the First-Difference transformation above to ensure valid inference.
          </div>
        </div>
      ) : (
        <div className="p-3 bg-[#43866B]/15 border border-[#43866B]/30 rounded-lg text-xs text-[#43866B] flex items-start gap-3">
          <CheckSquare className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold">Stationarity Guard Enforced: </span>
            Series differenced to $\Delta y_t = y_t - y_{'{t-1}'}$. White (1980) heteroskedasticity-consistent standard errors computed.
          </div>
        </div>
      )}

      {/* Regression Configuration & Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2 flex items-center gap-2">
            <FlaskConical className="w-4 h-4 text-[#527DA5]" />
            <span>Specification & Variables</span>
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#A8B2BC] mb-1">Dependent Variable (Y)</label>
              <select
                value={depVar}
                onChange={(e) => setDepVar(e.target.value as any)}
                className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
              >
                <option value="real">Real GDP Output</option>
                <option value="nominal">Nominal GDP Output</option>
                <option value="growth">Quarterly Output Growth Rate (%)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-[#A8B2BC] mb-1">Explanatory Variable (X)</label>
              <select
                value={indepVar}
                onChange={(e) => setIndepVar(e.target.value as any)}
                className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
              >
                <option value="deflator">GDP Price Deflator</option>
                <option value="lagged_real">Lagged Real Output (y_{'{t-1}'})</option>
              </select>
            </div>
          </div>

          <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded text-xs space-y-2">
            <div className="font-semibold text-[#F3F5F7]">Model Equation:</div>
            <div className="font-mono text-[#527DA5] text-[11px]">
              {useDifferences
                ? 'ΔY_t = α + β · ΔX_t + ε_t'
                : 'Y_t = α + β · X_t + ε_t (Non-Stationary Levels)'}
            </div>
            <p className="text-[11px] text-[#566575]">
              Estimation sample: {history.length} quarterly observations ({history[0].period} to {history[history.length - 1].period}).
            </p>
          </div>
        </div>

        {/* Estimation Output Table */}
        <div className="lg:col-span-7 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#2A3644] pb-2 flex justify-between items-center">
            <h3 className="text-sm font-semibold text-[#F3F5F7]">
              OLS Estimation with White Robust Standard Errors
            </h3>
            <span className="text-xs font-mono text-[#A8B2BC]">
              R² = {regressionResults?.r_squared.toFixed(4) || '--'}
            </span>
          </div>

          {regressionResults ? (
            <div className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left text-[#F3F5F7]">
                  <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="py-2.5 px-3">Variable</th>
                      <th className="py-2.5 px-3 text-right">Coefficient (β)</th>
                      <th className="py-2.5 px-3 text-right">Robust Std. Error</th>
                      <th className="py-2.5 px-3 text-right">t-Statistic</th>
                      <th className="py-2.5 px-3 text-right">p-Value (Robust)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2A3644] font-mono text-[11px]">
                    <tr className="hover:bg-[#15191E]/40">
                      <td className="py-2.5 px-3 font-sans font-medium text-[#F3F5F7]">Intercept (α)</td>
                      <td className="py-2.5 px-3 text-right tabular-nums text-[#F3F5F7]">{regressionResults.alpha.toFixed(3)}</td>
                      <td className="py-2.5 px-3 text-right tabular-nums text-[#A8B2BC]">--</td>
                      <td className="py-2.5 px-3 text-right tabular-nums text-[#A8B2BC]">--</td>
                      <td className="py-2.5 px-3 text-right tabular-nums text-[#A8B2BC]">--</td>
                    </tr>
                    <tr className="hover:bg-[#15191E]/40">
                      <td className="py-2.5 px-3 font-sans font-medium text-[#527DA5]">
                        {useDifferences ? 'Δ' : ''}{indepVar === 'deflator' ? 'Deflator' : 'Lagged_Output'}
                      </td>
                      <td className="py-2.5 px-3 text-right tabular-nums font-bold text-[#F3F5F7]">
                        {regressionResults.beta.toFixed(3)}
                      </td>
                      <td className="py-2.5 px-3 text-right tabular-nums text-[#A8B2BC]">
                        {regressionResults.se_beta_robust.toFixed(3)}
                      </td>
                      <td className="py-2.5 px-3 text-right tabular-nums font-semibold text-[#F3F5F7]">
                        {regressionResults.t_stat_robust.toFixed(2)}
                      </td>
                      <td className={`py-2.5 px-3 text-right tabular-nums font-bold ${
                        regressionResults.p_value_robust < 0.05 ? 'text-[#43866B]' : 'text-[#A8B2BC]'
                      }`}>
                        {regressionResults.p_value_robust < 0.001
                          ? '< 0.001'
                          : regressionResults.p_value_robust.toFixed(3)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded text-xs text-[#A8B2BC] space-y-1">
                <div className="font-semibold text-[#F3F5F7]">Causality & Identification Reminder:</div>
                <p>
                  Statistical significance ($p &lt; 0.05$) indicates empirical co-movement under the chosen specification. It does not establish causal direction or structural invariance to policy interventions (Lucas Critique, 1976).
                </p>
              </div>
            </div>
          ) : (
            <div className="text-xs text-[#C65454]">Estimation failed due to collinearity or insufficient sample variance.</div>
          )}
        </div>
      </div>
    </div>
  );
};
