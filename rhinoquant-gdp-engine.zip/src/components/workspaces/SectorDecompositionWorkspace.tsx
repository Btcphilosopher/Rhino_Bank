import React, { useState } from 'react';
import { BENCHMARK_ECONOMIES } from '../../data/benchmarkData';
import { SectorItem } from '../../types/gdp';
import { Plus, Trash2 } from 'lucide-react';

interface SectorDecompositionWorkspaceProps {
  selectedEconomy: string;
}

export const SectorDecompositionWorkspace: React.FC<SectorDecompositionWorkspaceProps> = ({
  selectedEconomy
}) => {
  const eco = BENCHMARK_ECONOMIES[selectedEconomy] || BENCHMARK_ECONOMIES.USA;
  const [sectors, setSectors] = useState<SectorItem[]>(eco.default_sectors);

  // Broad Taxonomy Aggregation Mode
  const [taxonomyMode, setTaxonomyMode] = useState<'ISIC_Rev4' | 'Broad3' | 'Custom'>('ISIC_Rev4');

  // New Sector inputs
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');
  const [newOutput, setNewOutput] = useState(1000);
  const [newInterm, setNewInterm] = useState(400);
  const [newEmp, setNewEmp] = useState(2000);

  // Compute Total GVA and enriched metrics
  const totalGrossOutput = sectors.reduce((sum, s) => sum + s.gross_output, 0);
  const totalIntermediate = sectors.reduce((sum, s) => sum + s.intermediate_consumption, 0);
  const totalGva = totalGrossOutput - totalIntermediate;
  const totalEmployment = sectors.reduce((sum, s) => sum + (s.employment_thousands || 0), 0);

  const enriched = sectors.map((s) => {
    const gva = s.gross_output - s.intermediate_consumption;
    const share = totalGva > 0 ? (gva / totalGva) * 100 : 0;
    const productivity = s.employment_thousands && s.employment_thousands > 0
      ? (gva * 1e6) / (s.employment_thousands * 1e3) // currency per worker
      : null;
    const empShare = totalEmployment > 0 && s.employment_thousands
      ? (s.employment_thousands / totalEmployment) * 100
      : null;

    return {
      ...s,
      gva,
      share,
      productivity,
      empShare
    };
  }).sort((a, b) => b.gva - a.gva);

  const handleAddSector = () => {
    if (!newName.trim()) return;
    const newSector: SectorItem = {
      id: String(Date.now()),
      code: newCode.trim() || 'NEW',
      name: newName.trim(),
      gross_output: newOutput,
      intermediate_consumption: newInterm,
      employment_thousands: newEmp
    };
    setSectors([...sectors, newSector]);
    setNewName('');
    setNewCode('');
  };

  const handleRemoveSector = (id: string) => {
    setSectors(sectors.filter((s) => s.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#2A3644]">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
            Sectoral Decomposition & Productivity Architecture
          </h2>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Gross Value Added (GVA), intermediate consumption ratios, employment shares, and labor productivity by industry.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-[#A8B2BC]">Classification Taxonomy:</span>
          <select
            value={taxonomyMode}
            onChange={(e) => setTaxonomyMode(e.target.value as any)}
            className="bg-[#192B40] border border-[#2A3644] rounded px-3 py-1.5 text-xs text-[#F3F5F7] font-medium focus:outline-none focus:border-[#527DA5]"
          >
            <option value="ISIC_Rev4">UN ISIC Rev. 4 / NACE Rev. 2</option>
            <option value="Broad3">Broad 3-Sector (Agri / Ind / Serv)</option>
            <option value="Custom">Configurable Institutional Taxonomy</option>
          </select>
        </div>
      </div>

      {/* Aggregate Sectoral Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Economy Total GVA</div>
          <div className="text-2xl font-bold font-mono text-[#43866B] mt-1 tabular-nums">
            {totalGva.toLocaleString('en-US', { maximumFractionDigits: 1 })}{' '}
            <span className="text-xs text-[#A8B2BC] font-sans font-normal">{eco.currency} {eco.scale}</span>
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Basic Prices Aggregate</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Total Gross Output</div>
          <div className="text-2xl font-bold font-mono text-[#527DA5] mt-1 tabular-nums">
            {totalGrossOutput.toLocaleString('en-US', { maximumFractionDigits: 1 })}
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Before intermediate deductions</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Intermediate Intensity</div>
          <div className="text-2xl font-bold font-mono text-[#D5A04B] mt-1 tabular-nums">
            {totalGrossOutput > 0 ? ((totalIntermediate / totalGrossOutput) * 100).toFixed(1) : 0}%
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Intermediate / Gross Output</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Aggregate Labor Productivity</div>
          <div className="text-2xl font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
            ${totalEmployment > 0 ? Math.round((totalGva * 1e6) / (totalEmployment * 1e3)).toLocaleString('en-US') : 0}
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Output per employee / annum</div>
        </div>
      </div>

      {/* Industry Table */}
      <div className="bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
        <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2">
          Sectoral Value Added & Productivity Ledger
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-[#F3F5F7]">
            <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Code</th>
                <th className="py-2.5 px-3">Industry Name</th>
                <th className="py-2.5 px-3 text-right">Gross Output</th>
                <th className="py-2.5 px-3 text-right">Intermediate Cons.</th>
                <th className="py-2.5 px-3 text-right">Gross Value Added</th>
                <th className="py-2.5 px-3 text-right">Share of GVA</th>
                <th className="py-2.5 px-3 text-right">Labor (k)</th>
                <th className="py-2.5 px-3 text-right">Labor Productivity</th>
                <th className="py-2.5 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A3644] font-mono text-[11px]">
              {enriched.map((s) => (
                <tr key={s.id} className="hover:bg-[#15191E]/40">
                  <td className="py-2.5 px-3 text-[#527DA5] font-semibold">{s.code}</td>
                  <td className="py-2.5 px-3 font-sans font-medium text-[#F3F5F7]">{s.name}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-[#A8B2BC]">{s.gross_output.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-[#C65454]">-{s.intermediate_consumption.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums font-bold text-[#43866B]">{s.gva.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-[#F3F5F7]">{s.share.toFixed(1)}%</td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-[#A8B2BC]">
                    {s.employment_thousands ? s.employment_thousands.toLocaleString() : '--'}
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-[#527DA5]">
                    {s.productivity ? `$${Math.round(s.productivity).toLocaleString()}` : '--'}
                  </td>
                  <td className="py-2.5 px-3 text-center font-sans">
                    <button
                      onClick={() => handleRemoveSector(s.id)}
                      className="text-[#566575] hover:text-[#C65454] transition-colors p-1"
                      title="Remove Sector"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Add Sector Form */}
        <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded-lg mt-3">
          <div className="text-xs font-semibold text-[#F3F5F7] mb-2 flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5 text-[#527DA5]" />
            <span>Append Custom Sector Taxonomy Node</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-6 gap-2">
            <input
              type="text"
              placeholder="Code (e.g. ICT)"
              value={newCode}
              onChange={(e) => setNewCode(e.target.value)}
              className="bg-[#192B40] border border-[#2A3644] rounded px-2.5 py-1.5 text-xs text-[#F3F5F7]"
            />
            <input
              type="text"
              placeholder="Sector Name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="bg-[#192B40] border border-[#2A3644] rounded px-2.5 py-1.5 text-xs text-[#F3F5F7] md:col-span-2"
            />
            <input
              type="number"
              placeholder="Gross Output"
              value={newOutput}
              onChange={(e) => setNewOutput(parseFloat(e.target.value) || 0)}
              className="bg-[#192B40] border border-[#2A3644] rounded px-2.5 py-1.5 text-xs text-[#F3F5F7] font-mono text-right"
            />
            <input
              type="number"
              placeholder="Interm. Cons."
              value={newInterm}
              onChange={(e) => setNewInterm(parseFloat(e.target.value) || 0)}
              className="bg-[#192B40] border border-[#2A3644] rounded px-2.5 py-1.5 text-xs text-[#F3F5F7] font-mono text-right"
            />
            <button
              onClick={handleAddSector}
              className="bg-[#527DA5] hover:bg-[#436b90] text-white text-xs font-medium rounded px-3 py-1.5 transition-colors whitespace-nowrap"
            >
              Add Sector
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
