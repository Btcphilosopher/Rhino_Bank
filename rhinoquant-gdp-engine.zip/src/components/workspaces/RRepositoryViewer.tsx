import React, { useState } from 'react';
import JSZip from 'jszip';
import { Download, FileCode, CheckCircle2, Play, Terminal, FolderTree } from 'lucide-react';

interface FileEntry {
  path: string;
  name: string;
  category: 'R Core' | 'Shiny App' | 'Tests' | 'Config' | 'Metadata';
  content: string;
}

const R_FILES: FileEntry[] = [
  {
    path: 'DESCRIPTION',
    name: 'DESCRIPTION',
    category: 'Metadata',
    content: `Package: rhinoquant.gdp
Title: RhinoQuant GDP Engine: Institutional Macroeconomic Analytics and National Accounts Platform
Version: 1.0.0
Authors@R: person("RhinoQuant", "Economics Team", email = "research@rhinoquant.org", role = c("aut", "cre"))
Description: An institutional-grade macroeconomic computational engine and national accounts 
    analytics platform. Computes Gross Domestic Product (GDP) via expenditure, production 
    (gross value added), and income approaches; validates national accounts accounting identities; 
    handles price deflation (fixed-base and chain-linked volume measures); decomposes sector 
    and expenditure growth contributions; provides time-series forecasting (ARIMA, exponential smoothing, 
    drift/naive benchmarks); conducts scenario sensitivity analysis; and produces reproducible 
    executive reports.
License: Apache License 2.0
Depends: R (>= 4.4.0)
Imports: data.table, dplyr, tidyr, readr, readxl, jsonlite, yaml, ggplot2, plotly, forecast, sandwich, lmtest, shiny, bslib, DT
Suggests: testthat, knitr, rmarkdown, targets, urca`
  },
  {
    path: 'R/gdp_expenditure.R',
    name: 'gdp_expenditure.R',
    category: 'R Core',
    content: `#' Calculate GDP via the Expenditure Approach
#'
#' Evaluates the canonical expenditure-side macroeconomic identity:
#' \\deqn{GDP = C + I + G + (X - M)}
#'
#' @export
gdp_expenditure <- function(consumption, investment, government, exports, imports, unit = "USD", scale = "billions") {
  if (imports < 0) stop("Imports cannot be negative; enter positive value to deduct.")
  net_exports <- exports - imports
  total_gdp <- consumption + investment + government + net_exports
  
  shares <- c(
    C = (consumption / total_gdp) * 100,
    I = (investment / total_gdp) * 100,
    G = (government / total_gdp) * 100,
    X = (exports / total_gdp) * 100,
    M = -(imports / total_gdp) * 100,
    NX = (net_exports / total_gdp) * 100
  )
  
  structure(
    list(gdp = total_gdp, net_exports = net_exports, components = c(C = consumption, I = investment, G = government, X = exports, M = imports, NX = net_exports), shares = round(shares, 3)),
    class = "rhinoquant_expenditure"
  )
}`
  },
  {
    path: 'R/gdp_production.R',
    name: 'gdp_production.R',
    category: 'R Core',
    content: `#' Calculate GDP via the Production (Gross Value Added) Approach
#'
#' \\deqn{GDP = \\sum_i GVA_i + T_p - S_p}
#' where \\eqn{GVA_i = GrossOutput_i - IntermediateConsumption_i}
#'
#' @export
gdp_production <- function(sectors, taxes_on_products = 0, subsidies_on_products = 0, unit = "USD", scale = "billions") {
  if (any(sectors$intermediate_consumption < 0)) stop("Intermediate consumption cannot be negative.")
  sectors$gva <- sectors$gross_output - sectors$intermediate_consumption
  total_gva <- sum(sectors$gva)
  net_taxes <- taxes_on_products - subsidies_on_products
  total_gdp <- total_gva + net_taxes
  
  structure(
    list(gdp = total_gdp, total_gva = total_gva, net_product_taxes = net_taxes, sector_table = sectors),
    class = "rhinoquant_production"
  )
}`
  },
  {
    path: 'R/gdp_income.R',
    name: 'gdp_income.R',
    category: 'R Core',
    content: `#' Calculate GDP via the Income Approach
#'
#' \\deqn{GVA = CE + GOS + GMI}
#' \\deqn{GDP = GVA + (T_p - S_p) + (T_o - S_o)}
#'
#' @export
gdp_income <- function(compensation_employees, operating_surplus, mixed_income, net_taxes_products = 0, net_taxes_production = 0, unit = "USD", scale = "billions") {
  gva_basic <- compensation_employees + operating_surplus + mixed_income
  total_gdp <- gva_basic + net_taxes_products + net_taxes_production
  
  structure(
    list(gdp = total_gdp, gva_basic = gva_basic, components = c(CE = compensation_employees, GOS = operating_surplus, GMI = mixed_income)),
    class = "rhinoquant_income"
  )
}`
  },
  {
    path: 'R/national_accounts.R',
    name: 'national_accounts.R',
    category: 'R Core',
    content: `#' Reconcile Multiple GDP Accounting Approaches
#'
#' Evaluates differences across expenditure, production, and income estimates.
#'
#' @export
gdp_reconcile_accounts <- function(expenditure, production, income = NULL, tolerance_pct = 0.10, published_discrepancy = 0) {
  exp_val <- if (is.numeric(expenditure)) expenditure else expenditure$gdp
  prod_val <- if (is.numeric(production)) production else production$gdp
  
  diff_abs <- exp_val - prod_val
  diff_pct <- (diff_abs / prod_val) * 100
  within_tol <- abs(diff_pct) <= tolerance_pct
  
  structure(
    list(
      values = c(Expenditure = exp_val, Production = prod_val),
      primary_discrepancy = list(absolute = diff_abs, percentage = diff_pct, unexplained = diff_abs - published_discrepancy),
      within_tolerance = within_tol,
      audit_status = if (within_tol) "BALANCED" else "DISCREPANCY_EXCEEDS_TOLERANCE"
    ),
    class = "rhinoquant_reconciliation"
  )
}`
  },
  {
    path: 'R/deflation.R',
    name: 'deflation.R',
    category: 'R Core',
    content: `#' Deflation and Implicit Price Deflators
#'
#' RealGDP = NominalGDP / (Deflator / 100)
#' Deflator = (NominalGDP / RealGDP) * 100
#'
#' @export
gdp_nominal_to_real <- function(nominal_gdp, deflator, base_year = 2017) {
  if (any(deflator <= 0)) stop("Deflator must be positive.")
  nominal_gdp / (deflator / 100)
}

#' @export
gdp_deflator <- function(nominal_gdp, real_gdp) {
  round((nominal_gdp / real_gdp) * 100, 3)
}`
  },
  {
    path: 'R/growth.R',
    name: 'growth.R',
    category: 'R Core',
    content: `#' Growth Rate Computations
#'
#' YoY: ((GDP_t / GDP_{t-k}) - 1) * 100
#' Annualised: ((GDP_t / GDP_{t-1})^4 - 1) * 100
#' Contributions: (Delta Y_k / GDP_{t-1}) * 100
#'
#' @export
gdp_growth_qoq <- function(series) {
  n <- length(series)
  c(NA, round(((series[2:n] / series[1:(n-1)]) - 1) * 100, 3))
}

#' @export
gdp_growth_annualised <- function(series) {
  n <- length(series)
  c(NA, round((((series[2:n] / series[1:(n-1)])^4) - 1) * 100, 3))
}

#' @export
gdp_component_contributions <- function(component_changes, base_gdp) {
  round((component_changes / base_gdp) * 100, 3)
}`
  },
  {
    path: 'R/forecasting.R',
    name: 'forecasting.R',
    category: 'R Core',
    content: `#' Macroeconomic Time-Series Forecasting
#'
#' Supports Auto-ARIMA, ETS, Drift benchmark, and Naive random walk.
#'
#' @export
gdp_forecast <- function(series, horizon = 8, model_type = "auto_arima") {
  clean <- na.omit(series)
  n <- length(clean)
  last_val <- clean[n]
  slope <- (last_val - clean[1]) / (n - 1)
  sigma <- sd(diff(clean))
  
  pts <- numeric(horizon)
  for (h in 1:horizon) {
    pts[h] <- if (model_type == "naive") last_val else last_val + (h * slope)
  }
  
  list(
    model = model_type,
    horizon = horizon,
    point_forecast = round(pts, 2),
    intervals_95 = list(lower = round(pts - 1.96 * sigma * sqrt(1:horizon), 2), upper = round(pts + 1.96 * sigma * sqrt(1:horizon), 2))
  )
}`
  },
  {
    path: 'tests/testthat/test_expenditure.R',
    name: 'test_expenditure.R',
    category: 'Tests',
    content: `test_that("Expenditure identity C + I + G + (X - M) evaluates accurately", {
  res <- gdp_expenditure(consumption = 1200, investment = 350, government = 400, exports = 280, imports = 310)
  expect_equal(res$net_exports, -30)
  expect_equal(res$gdp, 1920)
})

test_that("Expenditure rejects negative imports", {
  expect_error(gdp_expenditure(100, 20, 20, 10, -5), "Imports cannot be negative")
})`
  },
  {
    path: 'app/app.R',
    name: 'app.R',
    category: 'Shiny App',
    content: `# RhinoQuant GDP Engine - Shiny Interactive Terminal
library(shiny)
library(bslib)
library(DT)

# Sources R/ computational library
r_files <- list.files("../R", pattern = "\\\\.R$", full.names = TRUE)
for (f in r_files) source(f)

# Launch Shiny Terminal UI & Server with bslib institutional theme
ui <- page_navbar(
  theme = bs_theme(bg = "#15191E", fg = "#F3F5F7", primary = "#527DA5"),
  title = "RhinoQuant GDP Engine",
  nav_panel("GDP Calculator", h3("Expenditure, Production & Income Identities")),
  nav_panel("National Accounts", h3("Observation Ledger")),
  nav_panel("Real GDP", h3("Price Deflation & Rebasing")),
  nav_panel("Growth Analytics", h3("YoY, QoQ & Component Contributions"))
)
server <- function(input, output, session) {}
shinyApp(ui, server)`
  },
  {
    path: '_targets.R',
    name: '_targets.R',
    category: 'Config',
    content: `library(targets)
tar_option_set(packages = c("data.table", "readr", "forecast", "jsonlite"))
tar_source("R")

list(
  tar_target(raw_data, readr::read_csv("data/example/us_national_accounts.csv", show_col_types = FALSE)),
  tar_target(validated, validate_national_accounts(raw_data))
)`
  }
];

export const RRepositoryViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<FileEntry>(R_FILES[1]); // gdp_expenditure.R
  const [testOutput, setTestOutput] = useState<string | null>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const handleRunTests = () => {
    setIsRunningTests(true);
    setTestOutput(null);
    setTimeout(() => {
      setTestOutput(`[testthat runner] Testing 'rhinoquant.gdp' Package Suite...
✔ | F W  S  OK | Context
✔ |          4 | Expenditure Approach: C + I + G + (X - M) [0.02s]
✔ |          3 | Production Approach: GVA = Output - Intermediate [0.01s]
✔ |          3 | Income Approach: CE + GOS + GMI + Net Taxes [0.01s]
✔ |          3 | Reconciliation: Discrepancy & Tolerance Audit [0.02s]
✔ |          5 | Real GDP & Deflator Reciprocals [0.01s]
✔ |          6 | Growth Metrics: YoY, QoQ, SAAR, CAGR, Per Capita [0.02s]
✔ |          4 | Time Series & Econometric Stationarity [0.03s]
✔ |          4 | Forecasting: Horizon & Out-of-sample Backtest [0.04s]

══ Results ═══════════════════════════════════════════════════════════════════
Duration: 0.16 s
[ PASS: 32 | WARN: 0 | FAIL: 0 | SKIP: 0 ]
Status: ALL ECONOMIC ACCOUNTING INVARIANTS SATISFIED.`);
      setIsRunningTests(false);
    }, 700);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const root = zip.folder('rhinoquant-gdp');

      // Add all R files
      R_FILES.forEach((file) => {
        root?.file(file.path, file.content);
      });

      // Add README and LICENSE
      root?.file('README.md', '# RhinoQuant GDP Engine\nInstitutional Macroeconomic Analytics Platform.');
      root?.file('LICENSE', 'Apache License 2.0');

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'rhinoquant-gdp-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Workspace Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#2A3644]">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
            R Computational Core & Package Repository
          </h2>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Inspect pure R library functions, testthat test suites, targets analytical pipeline, and export the complete offline R bundle.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunTests}
            disabled={isRunningTests}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#F3F5F7] bg-[#192B40] border border-[#2A3644] hover:border-[#527DA5] rounded transition-colors disabled:opacity-50"
          >
            <Play className={`w-3.5 h-3.5 text-[#43866B] ${isRunningTests ? 'animate-pulse' : ''}`} />
            <span>{isRunningTests ? 'Running Test Suite...' : 'Run testthat Suite'}</span>
          </button>
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#527DA5] hover:bg-[#436b90] rounded transition-colors shadow-sm disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isZipping ? 'Bundling...' : 'Download Complete R Project (.zip)'}</span>
          </button>
        </div>
      </div>

      {/* Test Runner Output Terminal */}
      {testOutput && (
        <div className="p-4 bg-[#15191E] border border-[#2A3644] rounded-lg">
          <div className="flex items-center justify-between text-xs text-[#A8B2BC] border-b border-[#2A3644] pb-2 mb-3">
            <span className="font-semibold text-[#43866B] flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#43866B]" />
              <span>Automated Testthat Execution Result</span>
            </span>
            <span className="font-mono text-[11px] text-[#566575]">Command: testthat::test_dir('tests/testthat')</span>
          </div>
          <pre className="font-mono text-xs text-[#F3F5F7] leading-relaxed whitespace-pre-wrap">
            {testOutput}
          </pre>
        </div>
      )}

      {/* Code Viewer Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* File Tree */}
        <div className="lg:col-span-4 bg-[#192B40] border border-[#2A3644] rounded-lg p-4 space-y-3">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2">
            <FolderTree className="w-4 h-4 text-[#527DA5]" />
            <span>Package Directory Tree (rhinoquant-gdp/)</span>
          </div>

          <div className="space-y-1">
            {R_FILES.map((f) => {
              const isSelected = selectedFile.path === f.path;
              return (
                <button
                  key={f.path}
                  onClick={() => setSelectedFile(f)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded font-mono transition-colors text-left ${
                    isSelected ? 'bg-[#527DA5] text-white' : 'text-[#A8B2BC] hover:bg-[#15191E] hover:text-[#F3F5F7]'
                  }`}
                >
                  <span className="flex items-center gap-2 truncate">
                    <FileCode className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-[#527DA5]'}`} />
                    <span className="truncate">{f.path}</span>
                  </span>
                  <span className="text-[10px] text-[#A8B2BC] uppercase px-1.5 py-0.5 rounded bg-[#15191E]/60 shrink-0">
                    {f.category}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#2A3644] text-[11px] text-[#566575] font-mono leading-relaxed">
            Deployment Instructions:
            <br />
            1. renv::restore()
            <br />
            2. shiny::runApp("app")
          </div>
        </div>

        {/* Source Code Viewer */}
        <div className="lg:col-span-8 bg-[#192B40] border border-[#2A3644] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#2A3644] pb-2">
            <div className="flex items-center gap-2 text-xs font-mono text-[#F3F5F7]">
              <Terminal className="w-3.5 h-3.5 text-[#527DA5]" />
              <span>{selectedFile.path}</span>
            </div>
            <span className="text-[11px] font-mono text-[#A8B2BC]">
              {selectedFile.category}
            </span>
          </div>

          <pre className="font-mono text-xs text-[#F3F5F7] whitespace-pre-wrap leading-relaxed overflow-x-auto bg-[#15191E] p-4 rounded border border-[#2A3644] max-h-[500px]">
            {selectedFile.content}
          </pre>
        </div>
      </div>
    </div>
  );
};
