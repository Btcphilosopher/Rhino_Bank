import React, { useState, useMemo } from 'react';
import { NationalAccountObservation } from '../../types/gdp';
import { BENCHMARK_ECONOMIES } from '../../data/benchmarkData';
import { Download, Filter, Search } from 'lucide-react';

interface NationalAccountsWorkspaceProps {
  selectedEconomy: string;
}

export const NationalAccountsWorkspace: React.FC<NationalAccountsWorkspaceProps> = ({
  selectedEconomy
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMeasure, setFilterMeasure] = useState('ALL');
  const [filterVintage, setFilterVintage] = useState('ALL');

  // Collect observations across economies or for selected
  const allObservations = useMemo(() => {
    const list: NationalAccountObservation[] = [];
    if (selectedEconomy === 'ALL') {
      Object.values(BENCHMARK_ECONOMIES).forEach((eco) => {
        list.push(...eco.observations);
      });
    } else if (BENCHMARK_ECONOMIES[selectedEconomy]) {
      list.push(...BENCHMARK_ECONOMIES[selectedEconomy].observations);
    } else {
      // Fallback
      list.push(...BENCHMARK_ECONOMIES.USA.observations);
    }
    return list;
  }, [selectedEconomy]);

  // Filtered observations
  const filtered = useMemo(() => {
    return allObservations.filter((obs) => {
      const matchSearch =
        obs.country_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        obs.component.toLowerCase().includes(searchQuery.toLowerCase()) ||
        obs.period.toLowerCase().includes(searchQuery.toLowerCase());

      const matchMeasure = filterMeasure === 'ALL' || obs.measure === filterMeasure;
      const matchVintage = filterVintage === 'ALL' || obs.revision_vintage === filterVintage;

      return matchSearch && matchMeasure && matchVintage;
    });
  }, [allObservations, searchQuery, filterMeasure, filterVintage]);

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'Country_Code',
      'Country_Name',
      'Period',
      'Frequency',
      'Measure',
      'Component',
      'Value',
      'Currency',
      'Scale',
      'Price_Basis',
      'Seasonal_Adjustment',
      'Source',
      'Publication_Date',
      'Revision_Vintage'
    ];

    const rows = filtered.map((o) => [
      o.country_code,
      `"${o.country_name}"`,
      o.period,
      o.frequency,
      o.measure,
      `"${o.component}"`,
      o.value,
      o.currency,
      o.scale,
      o.price_basis,
      o.seasonal_adjustment,
      `"${o.source}"`,
      o.publication_date,
      o.revision_vintage
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RhinoQuant_NationalAccounts_${selectedEconomy}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5">
      {/* Workspace Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#2A3644]">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
            System of National Accounts Observation Ledger
          </h2>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Canonical observation schema supporting vintage tracking, price bases, seasonal adjustments, and official source provenance.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#F3F5F7] bg-[#192B40] border border-[#2A3644] hover:border-[#527DA5] rounded transition-colors whitespace-nowrap self-start md:self-auto"
        >
          <Download className="w-3.5 h-3.5 text-[#527DA5]" />
          <span>Export Ledger CSV</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3.5 bg-[#192B40] border border-[#2A3644] rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-[#A8B2BC] shrink-0" />
          <input
            type="text"
            placeholder="Search by component, period, or economy..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs font-mono text-[#F3F5F7] placeholder-[#566575] focus:outline-none focus:border-[#527DA5]"
          />
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-[#A8B2BC]">
            <Filter className="w-3.5 h-3.5" />
            <span>Measure:</span>
            <select
              value={filterMeasure}
              onChange={(e) => setFilterMeasure(e.target.value)}
              className="bg-[#15191E] border border-[#2A3644] rounded px-2 py-1 text-xs text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
            >
              <option value="ALL">All Measures</option>
              <option value="Nominal_GDP">Nominal GDP</option>
              <option value="PCE">PCE / Consumption</option>
              <option value="GCF">Gross Capital Formation</option>
              <option value="Govt">Government</option>
              <option value="Exports">Exports</option>
              <option value="Imports">Imports</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-[#A8B2BC]">
            <span>Vintage:</span>
            <select
              value={filterVintage}
              onChange={(e) => setFilterVintage(e.target.value)}
              className="bg-[#15191E] border border-[#2A3644] rounded px-2 py-1 text-xs text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
            >
              <option value="ALL">All Vintages</option>
              <option value="Second">Second Estimate</option>
              <option value="Final">Final Benchmark</option>
              <option value="Flash">Flash Estimate</option>
            </select>
          </div>
        </div>
      </div>

      {/* Observation Table */}
      <div className="bg-[#192B40] border border-[#2A3644] rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-[#F3F5F7]">
            <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider border-b border-[#2A3644]">
              <tr>
                <th className="py-2.5 px-3">Country</th>
                <th className="py-2.5 px-3">Period</th>
                <th className="py-2.5 px-3">Freq</th>
                <th className="py-2.5 px-3">Measure</th>
                <th className="py-2.5 px-3">Component Transaction</th>
                <th className="py-2.5 px-3 text-right">Value</th>
                <th className="py-2.5 px-3">Currency</th>
                <th className="py-2.5 px-3">Scale</th>
                <th className="py-2.5 px-3">Price Basis</th>
                <th className="py-2.5 px-3">SA</th>
                <th className="py-2.5 px-3">Vintage</th>
                <th className="py-2.5 px-3">Source Agency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A3644]">
              {filtered.map((obs) => (
                <tr key={obs.id} className="hover:bg-[#15191E]/40 font-mono text-[11px]">
                  <td className="py-2 px-3 font-sans font-medium text-[#F3F5F7]">
                    {obs.country_code}
                  </td>
                  <td className="py-2 px-3 text-[#A8B2BC] tabular-nums">
                    {obs.period}
                  </td>
                  <td className="py-2 px-3 text-[#566575]">
                    {obs.frequency}
                  </td>
                  <td className="py-2 px-3 text-[#527DA5] font-semibold">
                    {obs.measure}
                  </td>
                  <td className="py-2 px-3 text-[#F3F5F7] font-sans">
                    {obs.component}
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-[#F3F5F7] tabular-nums">
                    {obs.value.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}
                  </td>
                  <td className="py-2 px-3 text-[#A8B2BC]">
                    {obs.currency}
                  </td>
                  <td className="py-2 px-3 text-[#A8B2BC]">
                    {obs.scale}
                  </td>
                  <td className="py-2 px-3 text-[#566575]">
                    {obs.price_basis}
                  </td>
                  <td className="py-2 px-3 text-[#566575]">
                    {obs.seasonal_adjustment}
                  </td>
                  <td className="py-2 px-3 text-[#D5A04B]">
                    {obs.revision_vintage}
                  </td>
                  <td className="py-2 px-3 text-[#A8B2BC] font-sans truncate max-w-[180px]">
                    {obs.source}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-[#15191E] border-t border-[#2A3644] flex items-center justify-between text-xs text-[#A8B2BC]">
          <div>
            Showing <span className="font-mono text-[#F3F5F7]">{filtered.length}</span> verified observations
          </div>
          <div className="font-mono text-[11px] text-[#566575]">
            Schema Validation: ISO 8601 Periods · Non-Null Checked · Zero Silent Substitutions
          </div>
        </div>
      </div>
    </div>
  );
};
