import React, { useState } from 'react';
import { BENCHMARK_ECONOMIES } from '../../data/benchmarkData';
import {
  calculateGrowthYoy,
  calculateGrowthQoq,
  calculateGrowthAnnualised,
  calculateCagr,
  calculateGdpPerCapita
} from '../../engine/macro_engine';

interface GrowthAnalyticsWorkspaceProps {
  selectedEconomy: string;
}

export const GrowthAnalyticsWorkspace: React.FC<GrowthAnalyticsWorkspaceProps> = ({
  selectedEconomy
}) => {
  const eco = BENCHMARK_ECONOMIES[selectedEconomy] || BENCHMARK_ECONOMIES.USA;
  const history = eco.historical_real_gdp;

  const realSeries = history.map((h) => h.real);
  const nominalSeries = history.map((h) => h.nominal);

  // Growth series
  const qoqGrowth = calculateGrowthQoq(realSeries);
  const annGrowth = calculateGrowthAnnualised(realSeries);
  const yoyGrowth = calculateGrowthYoy(realSeries, 4);
  const nominalYoy = calculateGrowthYoy(nominalSeries, 4);

  // Interactive CAGR Calculator
  const [cagrStartIdx, setCagrStartIdx] = useState<number>(0);
  const [cagrEndIdx, setCagrEndIdx] = useState<number>(history.length - 1);

  const startPeriod = history[cagrStartIdx];
  const endPeriod = history[cagrEndIdx];
  const numQuarters = Math.max(1, cagrEndIdx - cagrStartIdx);
  const numYears = numQuarters / 4;
  const computedCagr = calculateCagr(startPeriod.real, endPeriod.real, numYears);

  // Latest Per Capita
  const latestReal = realSeries[realSeries.length - 1];
  const latestNominal = nominalSeries[nominalSeries.length - 1];
  const pop = eco.population_millions;
  const realPerCapita = calculateGdpPerCapita(latestReal, pop, 'billions', 'millions');
  const nominalPerCapita = calculateGdpPerCapita(latestNominal, pop, 'billions', 'millions');

  // Peak-to-trough and recovery analytics
  let maxPeak = realSeries[0];
  let minTrough = realSeries[0];
  for (const v of realSeries) {
    if (v > maxPeak) maxPeak = v;
    if (v < minTrough) minTrough = v;
  }
  const peakToTroughDecline = ((minTrough / maxPeak) - 1) * 100;
  const currentVsPeak = ((latestReal / maxPeak) - 1) * 100;

  // Component Growth vs Percentage-Point Contributions (Latest Quarter)
  // BEA Q3 2024 breakdown
  const componentAttributions = [
    { component: 'Personal Consumption (C)', ownGrowth: 3.5, weight: 68.0, ppContribution: 2.38 },
    { component: 'Gross Private Investment (I)', ownGrowth: 0.3, weight: 18.1, ppContribution: 0.05 },
    { component: 'Government Consumption & Inv (G)', ownGrowth: 5.0, weight: 17.5, ppContribution: 0.88 },
    { component: 'Exports of Goods & Services (X)', ownGrowth: 8.9, weight: 11.0, ppContribution: 0.98 },
    { component: 'Imports of Goods & Services (M)', ownGrowth: 11.2, weight: 14.6, ppContribution: -1.59 }
  ];
  const totalAttributedGrowth = componentAttributions.reduce((a, b) => a + b.ppContribution, 0);

  return (
    <div className="space-y-6">
      {/* Workspace Header */}
      <div className="pb-4 border-b border-[#2A3644]">
        <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
          Macroeconomic Output & Growth Analytics
        </h2>
        <p className="text-xs text-[#A8B2BC] mt-0.5">
          Sequential quarterly changes, annualized SAAR rates, year-on-year trends, and mathematical component attribution.
        </p>
      </div>

      {/* Top Level Metric Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Latest QoQ (Seasonally Adjusted)</div>
          <div className="text-2xl font-bold font-mono text-[#43866B] mt-1 tabular-nums">
            +{qoqGrowth[qoqGrowth.length - 1]?.toFixed(2)}%
          </div>
          <div className="text-xs text-[#566575] mt-0.5">{history[history.length - 1].period} vs previous quarter</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Annualised Rate (SAAR)</div>
          <div className="text-2xl font-bold font-mono text-[#527DA5] mt-1 tabular-nums">
            +{annGrowth[annGrowth.length - 1]?.toFixed(2)}%
          </div>
          <div className="text-xs text-[#566575] mt-0.5">[(GDP_t / GDP_{'{t-1}'})^4 - 1]</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Year-on-Year Real Growth</div>
          <div className="text-2xl font-bold font-mono text-[#43866B] mt-1 tabular-nums">
            +{yoyGrowth[yoyGrowth.length - 1]?.toFixed(2)}%
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Nominal YoY: +{nominalYoy[nominalYoy.length - 1]?.toFixed(2)}%</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Real GDP Per Capita</div>
          <div className="text-2xl font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
            ${Math.round(realPerCapita).toLocaleString('en-US')}
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Nominal: ${Math.round(nominalPerCapita).toLocaleString('en-US')} / person</div>
        </div>
      </div>

      {/* Component Growth vs Percentage-Point Contributions Matrix */}
      <div className="bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
        <div className="border-b border-[#2A3644] pb-3">
          <h3 className="text-sm font-semibold text-[#F3F5F7]">
            Component Growth Rate vs. Percentage-Point Contribution to GDP
          </h3>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Crucial economic distinction: An individual component can grow rapidly (e.g. Imports +11.2%), but its contribution to real GDP depends on its share and sign in the identity: C_k = ΔY_k / GDP_prev.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-[#F3F5F7]">
            <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Expenditure Aggregate</th>
                <th className="py-2.5 px-3 text-right">Share of GDP (%)</th>
                <th className="py-2.5 px-3 text-right">Component Growth Rate (%)</th>
                <th className="py-2.5 px-3 text-right">Percentage-Point Contribution to GDP (pp)</th>
                <th className="py-2.5 px-3 text-left pl-6">Contribution Direction</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A3644] font-mono text-[11px]">
              {componentAttributions.map((row) => (
                <tr key={row.component} className="hover:bg-[#15191E]/40">
                  <td className="py-2.5 px-3 font-sans font-medium text-[#F3F5F7]">
                    {row.component}
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-[#A8B2BC]">
                    {row.weight.toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-[#F3F5F7]">
                    +{row.ownGrowth.toFixed(1)}%
                  </td>
                  <td className={`py-2.5 px-3 text-right tabular-nums font-bold ${
                    row.ppContribution >= 0 ? 'text-[#43866B]' : 'text-[#C65454]'
                  }`}>
                    {row.ppContribution >= 0 ? '+' : ''}{row.ppContribution.toFixed(2)} pp
                  </td>
                  <td className="py-2.5 px-3 pl-6">
                    <div className="w-32 bg-[#15191E] h-2 rounded overflow-hidden">
                      <div
                        className={`h-full ${row.ppContribution >= 0 ? 'bg-[#43866B]' : 'bg-[#C65454]'}`}
                        style={{ width: `${Math.min(100, Math.abs(row.ppContribution) * 35)}%` }}
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-[#15191E] font-semibold text-xs border-t border-[#2A3644]">
              <tr>
                <td className="py-2.5 px-3 text-[#F3F5F7] font-sans">
                  Total Real GDP Growth (SAAR)
                </td>
                <td className="py-2.5 px-3 text-right font-mono text-[#A8B2BC]">100.0%</td>
                <td className="py-2.5 px-3 text-right font-mono text-[#566575]">--</td>
                <td className="py-2.5 px-3 text-right font-mono text-[#43866B] font-bold">
                  +{totalAttributedGrowth.toFixed(2)} pp
                </td>
                <td className="py-2.5 px-3 pl-6 text-[#A8B2BC] font-mono text-[11px]">
                  Sum of Contributions = Real GDP Growth
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* CAGR & Historical Growth Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* CAGR Tool */}
        <div className="lg:col-span-5 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2">
            Compound Annual Growth Rate (CAGR) Calculator
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-[#A8B2BC] mb-1">Start Period</label>
              <select
                value={cagrStartIdx}
                onChange={(e) => setCagrStartIdx(parseInt(e.target.value, 10))}
                className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs font-mono text-[#F3F5F7]"
              >
                {history.map((h, i) => (
                  <option key={h.period} value={i} disabled={i >= cagrEndIdx}>
                    {h.period} ({h.real.toFixed(1)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-[#A8B2BC] mb-1">End Period</label>
              <select
                value={cagrEndIdx}
                onChange={(e) => setCagrEndIdx(parseInt(e.target.value, 10))}
                className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs font-mono text-[#F3F5F7]"
              >
                {history.map((h, i) => (
                  <option key={h.period} value={i} disabled={i <= cagrStartIdx}>
                    {h.period} ({h.real.toFixed(1)})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="p-3.5 bg-[#15191E] border border-[#2A3644] rounded space-y-2">
            <div className="text-xs text-[#A8B2BC]">Geometric Compound Growth Rate:</div>
            <div className="text-2xl font-bold font-mono text-[#43866B] tabular-nums">
              +{computedCagr.toFixed(2)}% <span className="text-xs text-[#A8B2BC] font-sans font-normal">per annum</span>
            </div>
            <div className="text-[11px] text-[#566575] font-mono">
              Horizon: {numYears.toFixed(2)} years ({numQuarters} quarters) · Base: {startPeriod.real.toFixed(1)} → {endPeriod.real.toFixed(1)}
            </div>
          </div>

          <div className="text-xs text-[#A8B2BC] space-y-1">
            <div className="flex justify-between">
              <span>Historical Peak Output:</span>
              <span className="font-mono text-[#F3F5F7]">{maxPeak.toFixed(1)} {eco.currency}</span>
            </div>
            <div className="flex justify-between">
              <span>Current vs Historical Peak:</span>
              <span className={`font-mono ${currentVsPeak >= 0 ? 'text-[#43866B]' : 'text-[#C65454]'}`}>
                {currentVsPeak >= 0 ? '+' : ''}{currentVsPeak.toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span>Max Decline (Peak to Trough):</span>
              <span className="font-mono text-[#A8B2BC]">{peakToTroughDecline.toFixed(2)}%</span>
            </div>
          </div>
        </div>

        {/* Growth History Table */}
        <div className="lg:col-span-7 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-3">
          <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2">
            Historical Growth Rate Series
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-[#F3F5F7]">
              <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-2 px-2.5">Period</th>
                  <th className="py-2 px-2.5 text-right">Real Level</th>
                  <th className="py-2 px-2.5 text-right">QoQ (%)</th>
                  <th className="py-2 px-2.5 text-right">SAAR (%)</th>
                  <th className="py-2 px-2.5 text-right">YoY (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A3644] font-mono text-[11px]">
                {history.map((row, i) => (
                  <tr key={row.period} className="hover:bg-[#15191E]/40">
                    <td className="py-1.5 px-2.5 font-medium text-[#F3F5F7]">{row.period}</td>
                    <td className="py-1.5 px-2.5 text-right text-[#A8B2BC] tabular-nums">{row.real.toFixed(1)}</td>
                    <td className="py-1.5 px-2.5 text-right tabular-nums text-[#43866B]">
                      {qoqGrowth[i] != null ? `${qoqGrowth[i]! >= 0 ? '+' : ''}${qoqGrowth[i]!.toFixed(2)}%` : '--'}
                    </td>
                    <td className="py-1.5 px-2.5 text-right tabular-nums text-[#527DA5]">
                      {annGrowth[i] != null ? `${annGrowth[i]! >= 0 ? '+' : ''}${annGrowth[i]!.toFixed(2)}%` : '--'}
                    </td>
                    <td className="py-1.5 px-2.5 text-right tabular-nums text-[#F3F5F7]">
                      {yoyGrowth[i] != null ? `${yoyGrowth[i]! >= 0 ? '+' : ''}${yoyGrowth[i]!.toFixed(2)}%` : '--'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
