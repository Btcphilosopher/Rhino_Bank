import React, { useState } from 'react';
import { ExpenditureComponents } from '../../types/gdp';
import { runScenarioAnalysis } from '../../engine/macro_engine';
import { SlidersHorizontal, RotateCcw, AlertTriangle } from 'lucide-react';

export const ScenarioEngineWorkspace: React.FC = () => {
  // Baseline Expenditure Components (US BEA benchmark: 29016.4 B USD)
  const baseline: ExpenditureComponents = {
    C: 19735.6,
    I: 5240.2,
    G: 5068.3,
    X: 3192.1,
    M: 4219.8
  };

  // Shock State (%)
  const [shocks, setShocks] = useState<{ C: number; I: number; G: number; X: number; M: number }>({
    C: 0.0,
    I: 0.0,
    G: 0.0,
    X: 0.0,
    M: 0.0
  });

  const scenarioResult = runScenarioAnalysis(baseline, shocks);

  const resetShocks = () => {
    setShocks({ C: 0.0, I: 0.0, G: 0.0, X: 0.0, M: 0.0 });
  };

  const setPresetScenario = (name: 'recession' | 'export_boom' | 'fiscal_expansion') => {
    if (name === 'recession') {
      setShocks({ C: -3.5, I: -12.0, G: 1.5, X: -5.0, M: -8.0 });
    } else if (name === 'export_boom') {
      setShocks({ C: 2.0, I: 4.5, G: 0.5, X: 10.0, M: 4.0 });
    } else if (name === 'fiscal_expansion') {
      setShocks({ C: 1.0, I: 2.0, G: 8.0, X: 0.0, M: 2.5 });
    }
  };

  // Tornado Sensitivity Data: Impact of a isolated +/- 5% shock to each component
  const tornadoItems = [
    { name: 'Consumption (C)', posDelta: (baseline.C * 0.05), negDelta: -(baseline.C * 0.05), share: 68.0 },
    { name: 'Investment (I)', posDelta: (baseline.I * 0.05), negDelta: -(baseline.I * 0.05), share: 18.1 },
    { name: 'Government (G)', posDelta: (baseline.G * 0.05), negDelta: -(baseline.G * 0.05), share: 17.5 },
    { name: 'Exports (X)', posDelta: (baseline.X * 0.05), negDelta: -(baseline.X * 0.05), share: 11.0 },
    { name: 'Imports (M)', posDelta: -(baseline.M * 0.05), negDelta: +(baseline.M * 0.05), share: 14.5 },
  ].sort((a, b) => Math.abs(b.posDelta) - Math.abs(a.posDelta));

  const maxTornadoVal = tornadoItems[0].posDelta;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#2A3644]">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
            Deterministic Macroeconomic Scenario Engine
          </h2>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Evaluate sensitivity of aggregate expenditure GDP to component shocks without uncalibrated behavioural multiplier assumptions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setPresetScenario('recession')}
            className="px-2.5 py-1 text-xs bg-[#192B40] border border-[#2A3644] hover:border-[#527DA5] text-[#F3F5F7] rounded"
          >
            Stress: Recession
          </button>
          <button
            onClick={() => setPresetScenario('fiscal_expansion')}
            className="px-2.5 py-1 text-xs bg-[#192B40] border border-[#2A3644] hover:border-[#527DA5] text-[#F3F5F7] rounded"
          >
            Fiscal Expansion
          </button>
          <button
            onClick={resetShocks}
            className="flex items-center gap-1 px-2.5 py-1 text-xs bg-[#15191E] border border-[#2A3644] text-[#A8B2BC] hover:text-[#F3F5F7] rounded"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Baseline</span>
          </button>
        </div>
      </div>

      {/* Outcome Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Baseline GDP</div>
          <div className="text-2xl font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
            {scenarioResult.baseline_gdp.toLocaleString('en-US', { maximumFractionDigits: 1 })}
          </div>
          <div className="text-xs text-[#566575] mt-0.5">USD Billions</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Scenario Calculated GDP</div>
          <div className="text-2xl font-bold font-mono text-[#527DA5] mt-1 tabular-nums">
            {scenarioResult.scenario_gdp.toLocaleString('en-US', { maximumFractionDigits: 1 })}
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Under applied component shocks</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Absolute Change (ΔGDP)</div>
          <div className={`text-2xl font-bold font-mono mt-1 tabular-nums ${
            scenarioResult.delta_abs >= 0 ? 'text-[#43866B]' : 'text-[#C65454]'
          }`}>
            {scenarioResult.delta_abs >= 0 ? '+' : ''}{scenarioResult.delta_abs.toFixed(1)}
          </div>
          <div className="text-xs text-[#566575] mt-0.5">USD Billions</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Percentage Impact</div>
          <div className={`text-2xl font-bold font-mono mt-1 tabular-nums ${
            scenarioResult.delta_pct >= 0 ? 'text-[#43866B]' : 'text-[#C65454]'
          }`}>
            {scenarioResult.delta_pct >= 0 ? '+' : ''}{scenarioResult.delta_pct.toFixed(2)}%
          </div>
          <div className="text-xs text-[#566575] mt-0.5">Relative to baseline level</div>
        </div>
      </div>

      {/* Epistemological Distinction Warning */}
      <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded-lg text-xs text-[#A8B2BC] flex items-start gap-3">
        <AlertTriangle className="w-4 h-4 text-[#D5A04B] shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-semibold text-[#F3F5F7]">Accounting Identity vs. Causal Multipliers: </span>
          This engine performs <em>mechanical accounting sensitivity</em>: ΔGDP = ΔC + ΔI + ΔG + ΔX - ΔM. It does not assume a Keynesian multiplier (e.g. 1 / (1 - MPC)) or DSGE general equilibrium crowding-out feedback. In real economies, government spending changes induce tax, interest rate, and import leakages.
        </div>
      </div>

      {/* Tornado Sensitivity Chart & Component Sliders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders */}
        <div className="lg:col-span-6 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2 flex items-center gap-1.5">
            <SlidersHorizontal className="w-4 h-4 text-[#527DA5]" />
            <span>Component Shock Assumption Sliders (%)</span>
          </h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#F3F5F7]">Private Consumption (C)</span>
                <span className={`font-mono font-bold ${shocks.C >= 0 ? 'text-[#43866B]' : 'text-[#C65454]'}`}>
                  {shocks.C >= 0 ? '+' : ''}{shocks.C.toFixed(1)}% ({scenarioResult.contributions.C >= 0 ? '+' : ''}{scenarioResult.contributions.C.toFixed(1)} B)
                </span>
              </div>
              <input
                type="range"
                min="-15"
                max="15"
                step="0.5"
                value={shocks.C}
                onChange={(e) => setShocks({ ...shocks, C: parseFloat(e.target.value) })}
                className="w-full accent-[#527DA5] h-1.5 bg-[#15191E] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#F3F5F7]">Gross Capital Formation / Investment (I)</span>
                <span className={`font-mono font-bold ${shocks.I >= 0 ? 'text-[#43866B]' : 'text-[#C65454]'}`}>
                  {shocks.I >= 0 ? '+' : ''}{shocks.I.toFixed(1)}% ({scenarioResult.contributions.I >= 0 ? '+' : ''}{scenarioResult.contributions.I.toFixed(1)} B)
                </span>
              </div>
              <input
                type="range"
                min="-25"
                max="25"
                step="0.5"
                value={shocks.I}
                onChange={(e) => setShocks({ ...shocks, I: parseFloat(e.target.value) })}
                className="w-full accent-[#527DA5] h-1.5 bg-[#15191E] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#F3F5F7]">Government Final Consumption (G)</span>
                <span className={`font-mono font-bold ${shocks.G >= 0 ? 'text-[#43866B]' : 'text-[#C65454]'}`}>
                  {shocks.G >= 0 ? '+' : ''}{shocks.G.toFixed(1)}% ({scenarioResult.contributions.G >= 0 ? '+' : ''}{scenarioResult.contributions.G.toFixed(1)} B)
                </span>
              </div>
              <input
                type="range"
                min="-15"
                max="15"
                step="0.5"
                value={shocks.G}
                onChange={(e) => setShocks({ ...shocks, G: parseFloat(e.target.value) })}
                className="w-full accent-[#527DA5] h-1.5 bg-[#15191E] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#F3F5F7]">Exports of Goods & Services (X)</span>
                <span className={`font-mono font-bold ${shocks.X >= 0 ? 'text-[#43866B]' : 'text-[#C65454]'}`}>
                  {shocks.X >= 0 ? '+' : ''}{shocks.X.toFixed(1)}% ({scenarioResult.contributions.X >= 0 ? '+' : ''}{scenarioResult.contributions.X.toFixed(1)} B)
                </span>
              </div>
              <input
                type="range"
                min="-20"
                max="20"
                step="0.5"
                value={shocks.X}
                onChange={(e) => setShocks({ ...shocks, X: parseFloat(e.target.value) })}
                className="w-full accent-[#527DA5] h-1.5 bg-[#15191E] rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#F3F5F7]">Imports of Goods & Services (M)</span>
                <span className={`font-mono font-bold ${shocks.M >= 0 ? 'text-[#C65454]' : 'text-[#43866B]'}`}>
                  {shocks.M >= 0 ? '+' : ''}{shocks.M.toFixed(1)}% ({scenarioResult.contributions.M >= 0 ? '+' : ''}{scenarioResult.contributions.M.toFixed(1)} B)
                </span>
              </div>
              <input
                type="range"
                min="-20"
                max="20"
                step="0.5"
                value={shocks.M}
                onChange={(e) => setShocks({ ...shocks, M: parseFloat(e.target.value) })}
                className="w-full accent-[#527DA5] h-1.5 bg-[#15191E] rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Tornado Sensitivity Chart */}
        <div className="lg:col-span-6 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <div className="border-b border-[#2A3644] pb-2">
            <h3 className="text-sm font-semibold text-[#F3F5F7]">
              Tornado Sensitivity Chart (±5% Isolated Shock Impact)
            </h3>
            <p className="text-xs text-[#A8B2BC]">
              Ranks macroeconomic components by absolute leverage over aggregate GDP.
            </p>
          </div>

          <div className="space-y-4 pt-2">
            {tornadoItems.map((item) => {
              const posWidth = (Math.abs(item.posDelta) / maxTornadoVal) * 45;
              const negWidth = (Math.abs(item.negDelta) / maxTornadoVal) * 45;

              return (
                <div key={item.name} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-[#F3F5F7] font-medium">{item.name}</span>
                    <span className="text-[#A8B2BC] font-mono">
                      ±${Math.abs(item.posDelta).toFixed(1)} B (±{(item.share * 0.05).toFixed(2)}%)
                    </span>
                  </div>

                  <div className="flex items-center h-4 bg-[#15191E] rounded overflow-hidden relative">
                    {/* Center axis line */}
                    <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-[#2A3644] z-10" />

                    {/* Negative side */}
                    <div className="w-1/2 flex justify-end pr-[1px]">
                      <div
                        className="bg-[#C65454] h-3 rounded-l"
                        style={{ width: `${negWidth}%` }}
                      />
                    </div>

                    {/* Positive side */}
                    <div className="w-1/2 pl-[1px]">
                      <div
                        className="bg-[#43866B] h-3 rounded-r"
                        style={{ width: `${posWidth}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-[11px] text-[#566575] font-mono pt-3 border-t border-[#2A3644]">
            Interpretation: Because Household Consumption represents 68% of GDP, an isolated 5% fluctuation produces nearly 4x the impact of a 5% swing in gross fixed investment.
          </div>
        </div>
      </div>
    </div>
  );
};
