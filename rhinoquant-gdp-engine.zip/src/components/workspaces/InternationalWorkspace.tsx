import React, { useState } from 'react';
import { INTERNATIONAL_BENCHMARK_LIST } from '../../data/benchmarkData';
import { CountryComparisonItem } from '../../types/gdp';
import { Globe, ArrowUpDown } from 'lucide-react';

export const InternationalWorkspace: React.FC = () => {
  const [countries, setCountries] = useState<CountryComparisonItem[]>(INTERNATIONAL_BENCHMARK_LIST);
  const [comparisonBasis, setComparisonBasis] = useState<'USD_FX' | 'PPP'>('USD_FX');
  const [sortField, setSortField] = useState<keyof CountryComparisonItem>('nominal_gdp_usd');
  const [sortAsc, setSortAsc] = useState<boolean>(false);

  // Group filtering
  const [selectedGroup, setSelectedGroup] = useState<'ALL' | 'G7' | 'BRICS'>('ALL');

  const filteredCountries = countries.filter((c) => {
    if (selectedGroup === 'G7') {
      return ['USA', 'DEU', 'JPN', 'GBR', 'FRA'].includes(c.country_code);
    }
    if (selectedGroup === 'BRICS') {
      return ['CHN', 'IND'].includes(c.country_code);
    }
    return true;
  });

  const sortedCountries = [...filteredCountries].sort((a, b) => {
    const valA = a[sortField];
    const valB = b[sortField];
    if (typeof valA === 'number' && typeof valB === 'number') {
      return sortAsc ? valA - valB : valB - valA;
    }
    return 0;
  });

  const handleSort = (field: keyof CountryComparisonItem) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#2A3644]">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
            Cross-Country Macroeconomic Comparison Workstation
          </h2>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Compare international national accounts with explicit exchange rate vs. Purchasing Power Parity (PPP) conventions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Comparison basis */}
          <div className="flex items-center gap-1.5 text-xs text-[#A8B2BC]">
            <span>Valuation Basis:</span>
            <div className="flex items-center p-0.5 bg-[#15191E] border border-[#2A3644] rounded">
              <button
                onClick={() => setComparisonBasis('USD_FX')}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  comparisonBasis === 'USD_FX' ? 'bg-[#527DA5] text-white' : 'text-[#A8B2BC]'
                }`}
              >
                Market FX (USD)
              </button>
              <button
                onClick={() => setComparisonBasis('PPP')}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  comparisonBasis === 'PPP' ? 'bg-[#527DA5] text-white' : 'text-[#A8B2BC]'
                }`}
              >
                Purchasing Power Parity (PPP)
              </button>
            </div>
          </div>

          {/* Group Filter */}
          <div className="flex items-center gap-1.5 text-xs text-[#A8B2BC]">
            <span>Bloc:</span>
            <select
              value={selectedGroup}
              onChange={(e) => setSelectedGroup(e.target.value as any)}
              className="bg-[#15191E] border border-[#2A3644] rounded px-2.5 py-1 text-xs text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
            >
              <option value="ALL">All Major Economies</option>
              <option value="G7">G7 Industrialized</option>
              <option value="BRICS">Emerging Giants (BRICS)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Methodological Disclaimer */}
      <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded-lg text-xs text-[#A8B2BC] flex items-center gap-3">
        <Globe className="w-4 h-4 text-[#527DA5] shrink-0" />
        <div className="leading-relaxed">
          <span className="font-semibold text-[#F3F5F7]">Methodological Separation: </span>
          Market exchange rates reflect financial flows, interest rate differentials, and tradeable goods pricing. In contrast, Purchasing Power Parity (PPP) adjusts for non-traded domestic price disparities using an international basket. The platform never blends market FX and PPP without explicit user selection.
        </div>
      </div>

      {/* Comparison Table */}
      <div className="bg-[#192B40] border border-[#2A3644] rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-[#F3F5F7]">
            <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider border-b border-[#2A3644]">
              <tr>
                <th className="py-2.5 px-3">Economy</th>
                <th className="py-2.5 px-3">Period</th>
                <th className="py-2.5 px-3 text-right">Nominal GDP (Local)</th>
                <th
                  onClick={() => handleSort(comparisonBasis === 'USD_FX' ? 'nominal_gdp_usd' : 'gdp_ppp_usd')}
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-white"
                >
                  <span className="inline-flex items-center gap-1">
                    {comparisonBasis === 'USD_FX' ? 'GDP (USD Billions)' : 'GDP (PPP Billions)'}
                    <ArrowUpDown className="w-3 h-3 text-[#527DA5]" />
                  </span>
                </th>
                <th
                  onClick={() => handleSort('real_gdp_growth_yoy')}
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-white"
                >
                  <span className="inline-flex items-center gap-1">
                    Annual Real Growth (%)
                    <ArrowUpDown className="w-3 h-3 text-[#527DA5]" />
                  </span>
                </th>
                <th
                  onClick={() => handleSort('gdp_per_capita_usd')}
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-white"
                >
                  <span className="inline-flex items-center gap-1">
                    GDP Per Capita (USD)
                    <ArrowUpDown className="w-3 h-3 text-[#527DA5]" />
                  </span>
                </th>
                <th className="py-2.5 px-3 text-right">Population (M)</th>
                <th className="py-2.5 px-3">Source Agency</th>
                <th className="py-2.5 px-3">Release Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A3644] font-mono text-[11px]">
              {sortedCountries.map((c) => {
                const comparisonVal = comparisonBasis === 'USD_FX' ? c.nominal_gdp_usd : c.gdp_ppp_usd;
                return (
                  <tr key={c.country_code} className="hover:bg-[#15191E]/40">
                    <td className="py-2.5 px-3 font-sans font-medium text-[#F3F5F7]">
                      <span className="text-[#527DA5] font-mono mr-2">{c.country_code}</span>
                      {c.country_name}
                    </td>
                    <td className="py-2.5 px-3 text-[#A8B2BC]">{c.reference_period}</td>
                    <td className="py-2.5 px-3 text-right text-[#A8B2BC] tabular-nums">
                      {c.nominal_gdp_local.toLocaleString('en-US', { maximumFractionDigits: 1 })}{' '}
                      <span className="text-[10px] text-[#566575]">{c.local_currency}</span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-[#F3F5F7] tabular-nums">
                      ${comparisonVal.toLocaleString('en-US', { maximumFractionDigits: 1 })} B
                    </td>
                    <td className={`py-2.5 px-3 text-right tabular-nums font-semibold ${
                      c.real_gdp_growth_yoy >= 2.0 ? 'text-[#43866B]' : c.real_gdp_growth_yoy > 0 ? 'text-[#D5A04B]' : 'text-[#C65454]'
                    }`}>
                      +{c.real_gdp_growth_yoy.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#527DA5] font-semibold tabular-nums">
                      ${c.gdp_per_capita_usd.toLocaleString('en-US')}
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#A8B2BC] tabular-nums">
                      {c.population_millions.toFixed(1)}
                    </td>
                    <td className="py-2.5 px-3 font-sans text-[#A8B2BC] text-[10px]">{c.source}</td>
                    <td className="py-2.5 px-3 text-[#566575] text-[10px]">{c.last_updated}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
