import React, { useState, useId } from 'react';
import {
  Currency,
  Scale,
  ExpenditureComponents,
  SectorItem,
  IncomeComponents
} from '../../types/gdp';
import {
  calculateExpenditureGdp,
  calculateProductionGdp,
  calculateIncomeGdp,
  reconcileAccounts
} from '../../engine/macro_engine';
import { CheckCircle2, AlertTriangle, Scale as BalanceIcon } from 'lucide-react';

interface CalculatorWorkspaceProps {
  currency: Currency;
  scale: Scale;
  tolerancePct: number;
}

export const CalculatorWorkspace: React.FC<CalculatorWorkspaceProps> = ({
  currency,
  scale,
  tolerancePct
}) => {
  const compCEId = useId();
  const compGOSId = useId();
  const compGMIId = useId();
  const compNetTaxProdId = useId();
  const compNetTaxProdOtherId = useId();
  const [activeTab, setActiveTab] = useState<'expenditure' | 'production' | 'income' | 'reconciliation'>('expenditure');

  // Expenditure State (Illustrative US Benchmark)
  const [exp, setExp] = useState<ExpenditureComponents>({
    C: 19735.6,
    I: 5240.2,
    G: 5068.3,
    X: 3192.1,
    M: 4219.8
  });

  // Production State (Sectors)
  const [sectors, setSectors] = useState<SectorItem[]>([
    { id: '1', code: 'C', name: 'Manufacturing', gross_output: 6100, intermediate_consumption: 3750 },
    { id: '2', code: 'G_I', name: 'Wholesale, Retail & Transport', gross_output: 6900, intermediate_consumption: 2950 },
    { id: '3', code: 'K_L', name: 'Finance, Insurance & Real Estate', gross_output: 8450, intermediate_consumption: 2400 },
    { id: '4', code: 'M_N', name: 'Professional & Business Services', gross_output: 5100, intermediate_consumption: 1720 },
    { id: '5', code: 'O_Q', name: 'Public Administration & Health', gross_output: 6800, intermediate_consumption: 2250 },
    { id: '6', code: 'OTH', name: 'Agriculture, Mining & Utilities', gross_output: 4200, intermediate_consumption: 1800 }
  ]);
  const [taxesOnProducts, setTaxesOnProducts] = useState<number>(2084.2);
  const [subsidiesOnProducts, setSubsidiesOnProducts] = useState<number>(314.4);

  // Income State
  const [inc, setInc] = useState<IncomeComponents>({
    CE: 14850.5,
    GOS: 9680.2,
    GMI: 2716.0,
    net_taxes_products: 1769.8,
    net_taxes_production: 0
  });

  // Published statistical discrepancy adjustment input
  const [publishedDiscrepancy, setPublishedDiscrepancy] = useState<number>(0);

  // Computations
  const expResult = calculateExpenditureGdp(exp, currency, scale);
  const prodResult = calculateProductionGdp(sectors, taxesOnProducts, subsidiesOnProducts, currency, scale);
  const incResult = calculateIncomeGdp(inc, currency, scale);

  const reconResult = reconcileAccounts(
    expResult.gdp,
    prodResult.gdp,
    incResult.gdp,
    tolerancePct,
    publishedDiscrepancy
  );

  const formatNum = (val: number) => {
    return val.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  };

  return (
    <div className="space-y-6">
      {/* Workspace Header & Method Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#2A3644]">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
            National Accounts GDP Calculator
          </h2>
          <p className="text-xs text-[#A8B2BC] mt-0.5">
            Evaluate the three fundamental macroeconomic identities with pure accounting rigor and double-entry validation.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 p-1 bg-[#15191E] border border-[#2A3644] rounded-lg shrink-0">
          <button
            onClick={() => setActiveTab('expenditure')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'expenditure' ? 'bg-[#527DA5] text-white' : 'text-[#A8B2BC] hover:text-[#F3F5F7]'
            }`}
          >
            A. Expenditure (C+I+G+X-M)
          </button>
          <button
            onClick={() => setActiveTab('production')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'production' ? 'bg-[#527DA5] text-white' : 'text-[#A8B2BC] hover:text-[#F3F5F7]'
            }`}
          >
            B. Production (GVA)
          </button>
          <button
            onClick={() => setActiveTab('income')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'income' ? 'bg-[#527DA5] text-white' : 'text-[#A8B2BC] hover:text-[#F3F5F7]'
            }`}
          >
            C. Income (CE+GOS+GMI)
          </button>
          <button
            onClick={() => setActiveTab('reconciliation')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'reconciliation' ? 'bg-[#192B40] text-[#F3F5F7] border border-[#527DA5]' : 'text-[#A8B2BC] hover:text-[#F3F5F7]'
            }`}
          >
            <BalanceIcon className="w-3.5 h-3.5" />
            <span>Reconciliation & Discrepancy</span>
          </button>
        </div>
      </div>

      {/* Top Level Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Expenditure GDP</div>
          <div className="text-xl font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
            {formatNum(expResult.gdp)} <span className="text-xs text-[#A8B2BC] font-sans font-normal">{currency} {scale}</span>
          </div>
          <div className="text-xs text-[#566575] mt-1">C + I + G + (X - M)</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Production GDP</div>
          <div className="text-xl font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
            {formatNum(prodResult.gdp)} <span className="text-xs text-[#A8B2BC] font-sans font-normal">{currency} {scale}</span>
          </div>
          <div className="text-xs text-[#566575] mt-1">Total GVA + Net Product Taxes</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Income GDP</div>
          <div className="text-xl font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
            {formatNum(incResult.gdp)} <span className="text-xs text-[#A8B2BC] font-sans font-normal">{currency} {scale}</span>
          </div>
          <div className="text-xs text-[#566575] mt-1">CE + GOS + GMI + Net Taxes</div>
        </div>

        <div className="p-4 bg-[#192B40] border border-[#2A3644] rounded-lg">
          <div className="text-[11px] text-[#A8B2BC] uppercase tracking-wider">Statistical Discrepancy</div>
          <div className={`text-xl font-bold font-mono mt-1 tabular-nums flex items-center gap-2 ${
            reconResult.within_tolerance ? 'text-[#43866B]' : 'text-[#C65454]'
          }`}>
            <span>{reconResult.discrepancy_exp_prod_abs >= 0 ? '+' : ''}{formatNum(reconResult.discrepancy_exp_prod_abs)}</span>
            <span className="text-xs font-sans font-normal">({reconResult.discrepancy_exp_prod_pct.toFixed(2)}%)</span>
          </div>
          <div className="text-xs text-[#566575] mt-1 flex items-center gap-1">
            {reconResult.within_tolerance ? (
              <CheckCircle2 className="w-3.5 h-3.5 text-[#43866B]" />
            ) : (
              <AlertTriangle className="w-3.5 h-3.5 text-[#C65454]" />
            )}
            <span>{reconResult.within_tolerance ? 'Within tolerance' : 'Exceeds threshold'}</span>
          </div>
        </div>
      </div>

      {/* TAB A: EXPENDITURE APPROACH */}
      {activeTab === 'expenditure' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2A3644] pb-3">
              <div>
                <h3 className="text-sm font-semibold text-[#F3F5F7]">A. Expenditure Identity Components</h3>
                <p className="text-xs text-[#A8B2BC]">Enter purchaser price values in {currency} {scale}</p>
              </div>
              <div className="text-xs font-mono text-[#527DA5] bg-[#15191E] px-2.5 py-1 rounded border border-[#2A3644]">
                GDP = C + I + G + (X - M)
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-[#F3F5F7] font-medium">Household Final Consumption Expenditure (C)</span>
                  <span className="text-[#A8B2BC] font-mono">{expResult.shares.C.toFixed(1)}% of GDP</span>
                </div>
                <input
                  type="number"
                  value={exp.C}
                  onChange={(e) => setExp({ ...exp, C: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-[#F3F5F7] font-medium">Gross Capital Formation / Investment (I)</span>
                  <span className="text-[#A8B2BC] font-mono">{expResult.shares.I.toFixed(1)}% of GDP</span>
                </div>
                <input
                  type="number"
                  value={exp.I}
                  onChange={(e) => setExp({ ...exp, I: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-[#F3F5F7] font-medium">General Government Final Consumption (G)</span>
                  <span className="text-[#A8B2BC] font-mono">{expResult.shares.G.toFixed(1)}% of GDP</span>
                </div>
                <input
                  type="number"
                  value={exp.G}
                  onChange={(e) => setExp({ ...exp, G: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#F3F5F7] font-medium">Exports of Goods & Services (X)</span>
                    <span className="text-[#A8B2BC] font-mono">{expResult.shares.X.toFixed(1)}%</span>
                  </div>
                  <input
                    type="number"
                    value={exp.X}
                    onChange={(e) => setExp({ ...exp, X: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#F3F5F7] font-medium">Imports of Goods & Services (M)</span>
                    <span className="text-[#C65454] font-mono">Deducted ({expResult.shares.M.toFixed(1)}%)</span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    value={exp.M}
                    onChange={(e) => setExp({ ...exp, M: Math.max(0, parseFloat(e.target.value) || 0) })}
                    className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                  />
                </div>
              </div>
            </div>

            <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded text-xs space-y-1 text-[#A8B2BC]">
              <div className="font-semibold text-[#F3F5F7]">Accounting Identity Traceability:</div>
              <p>
                Net Exports (X - M) = {formatNum(exp.X)} - {formatNum(exp.M)} = <span className="font-mono text-[#F3F5F7]">{formatNum(expResult.net_exports)} {currency} {scale}</span>.
              </p>
              <p className="text-[11px] text-[#566575]">
                Why imports are deducted: Consumption (C), Investment (I), and Government (G) include imported intermediate and consumer products. Deducting M removes non-domestic value added, ensuring GDP measures purely domestic economic activity.
              </p>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
            <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-3">
              Expenditure Shares & Decomposition
            </h3>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                  <span>Consumption (C)</span>
                  <span className="font-mono text-[#F3F5F7]">{formatNum(exp.C)} ({expResult.shares.C.toFixed(1)}%)</span>
                </div>
                <div className="w-full bg-[#15191E] h-2 rounded overflow-hidden">
                  <div className="bg-[#527DA5] h-full" style={{ width: `${Math.min(100, expResult.shares.C)}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                  <span>Investment (I)</span>
                  <span className="font-mono text-[#F3F5F7]">{formatNum(exp.I)} ({expResult.shares.I.toFixed(1)}%)</span>
                </div>
                <div className="w-full bg-[#15191E] h-2 rounded overflow-hidden">
                  <div className="bg-[#43866B] h-full" style={{ width: `${Math.min(100, expResult.shares.I)}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                  <span>Government (G)</span>
                  <span className="font-mono text-[#F3F5F7]">{formatNum(exp.G)} ({expResult.shares.G.toFixed(1)}%)</span>
                </div>
                <div className="w-full bg-[#15191E] h-2 rounded overflow-hidden">
                  <div className="bg-[#D5A04B] h-full" style={{ width: `${Math.min(100, expResult.shares.G)}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                  <span>Net Exports (X - M)</span>
                  <span className="font-mono text-[#F3F5F7]">{formatNum(expResult.net_exports)} ({expResult.shares.NX.toFixed(1)}%)</span>
                </div>
                <div className="w-full bg-[#15191E] h-2 rounded overflow-hidden">
                  <div className="bg-[#A8B2BC] h-full" style={{ width: `${Math.max(2, Math.abs(expResult.shares.NX))}%` }} />
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#2A3644] flex justify-between items-center text-sm font-semibold">
              <span className="text-[#F3F5F7]">Calculated GDP:</span>
              <span className="font-mono text-base text-[#43866B] tabular-nums">
                {formatNum(expResult.gdp)} {currency}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* TAB B: PRODUCTION APPROACH */}
      {activeTab === 'production' && (
        <div className="bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#2A3644] pb-3">
            <div>
              <h3 className="text-sm font-semibold text-[#F3F5F7]">
                B. Production (Value Added) Approach
              </h3>
              <p className="text-xs text-[#A8B2BC]">
                Gross Value Added = Gross Output - Intermediate Consumption. Deducting intermediate consumption prevents double counting.
              </p>
            </div>
            <div className="text-xs font-mono text-[#527DA5] bg-[#15191E] px-2.5 py-1 rounded border border-[#2A3644]">
              GDP = sum(GVA_i) + Taxes_products - Subsidies_products
            </div>
          </div>

          {/* Sector Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-[#F3F5F7]">
              <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-2.5 px-3">Industry / Sector</th>
                  <th className="py-2.5 px-3 text-right">Gross Output</th>
                  <th className="py-2.5 px-3 text-right">Intermediate Consumption (Deducted)</th>
                  <th className="py-2.5 px-3 text-right">Gross Value Added (GVA)</th>
                  <th className="py-2.5 px-3 text-right">Share of GVA</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A3644]">
                {sectors.map((s, idx) => {
                  const gva = s.gross_output - s.intermediate_consumption;
                  const share = prodResult.total_gva > 0 ? (gva / prodResult.total_gva) * 100 : 0;
                  return (
                    <tr key={s.id} className="hover:bg-[#15191E]/40">
                      <td className="py-2.5 px-3 font-medium text-[#F3F5F7]">
                        <span className="text-[#A8B2BC] font-mono mr-2">{s.code}</span>
                        {s.name}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        <input
                          type="number"
                          value={s.gross_output}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            const updated = [...sectors];
                            updated[idx].gross_output = val;
                            setSectors(updated);
                          }}
                          aria-label={`Gross output for ${s.name}`}
                          className="w-24 bg-[#15191E] border border-[#2A3644] rounded px-2 py-1 text-right font-mono text-xs focus:outline-none focus:border-[#527DA5]"
                        />
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        <input
                          type="number"
                          min="0"
                          value={s.intermediate_consumption}
                          onChange={(e) => {
                            const val = Math.max(0, parseFloat(e.target.value) || 0);
                            const updated = [...sectors];
                            updated[idx].intermediate_consumption = val;
                            setSectors(updated);
                          }}
                          aria-label={`Intermediate consumption for ${s.name}`}
                          className="w-24 bg-[#15191E] border border-[#2A3644] rounded px-2 py-1 text-right font-mono text-xs focus:outline-none focus:border-[#527DA5]"
                        />
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold text-[#43866B] tabular-nums">
                        {formatNum(gva)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-[#A8B2BC] tabular-nums">
                        {share.toFixed(1)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-[#15191E] font-semibold text-xs border-t border-[#2A3644]">
                <tr>
                  <td className="py-2.5 px-3 text-[#F3F5F7]">Total Gross Value Added (Basic Prices)</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-[#A8B2BC]">
                    {formatNum(sectors.reduce((a, b) => a + b.gross_output, 0))}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-[#C65454]">
                    -{formatNum(sectors.reduce((a, b) => a + b.intermediate_consumption, 0))}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-[#43866B]">
                    {formatNum(prodResult.total_gva)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-[#A8B2BC]">100.0%</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Product Taxes & Subsidies adjustment */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-[#2A3644]">
            <div>
              <label className="block text-xs text-[#A8B2BC] mb-1">Taxes on Products (T_p) (VAT, excise, tariffs)</label>
              <input
                type="number"
                value={taxesOnProducts}
                onChange={(e) => setTaxesOnProducts(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#A8B2BC] mb-1">Subsidies on Products (S_p) (Deducted)</label>
              <input
                type="number"
                min="0"
                value={subsidiesOnProducts}
                onChange={(e) => setSubsidiesOnProducts(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
              />
            </div>

            <div className="p-3 bg-[#15191E] border border-[#2A3644] rounded flex flex-col justify-center">
              <div className="text-[11px] text-[#A8B2BC]">Production GDP at Market Prices:</div>
              <div className="text-base font-bold font-mono text-[#43866B] tabular-nums mt-0.5">
                {formatNum(prodResult.gdp)} {currency} {scale}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB C: INCOME APPROACH */}
      {activeTab === 'income' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2A3644] pb-3">
              <div>
                <h3 className="text-sm font-semibold text-[#F3F5F7]">C. Income Identity (Primary Incomes)</h3>
                <p className="text-xs text-[#A8B2BC]">System of National Accounts 2008 Income Account</p>
              </div>
              <div className="text-xs font-mono text-[#527DA5] bg-[#15191E] px-2.5 py-1 rounded border border-[#2A3644]">
                GVA = CE + GOS + GMI
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <label htmlFor={compCEId} className="text-[#F3F5F7] font-medium">Compensation of Employees (CE)</label>
                  <span className="text-[#A8B2BC] font-mono">{incResult.shares.CE.toFixed(1)}% of basic GVA</span>
                </div>
                <input
                  id={compCEId}
                  type="number"
                  value={inc.CE}
                  onChange={(e) => setInc({ ...inc, CE: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                />
                <p className="text-[11px] text-[#566575] mt-1">Includes gross wages, salaries, and employer actual and imputed social contributions.</p>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <label htmlFor={compGOSId} className="text-[#F3F5F7] font-medium">Gross Operating Surplus (GOS)</label>
                  <span className="text-[#A8B2BC] font-mono">{incResult.shares.GOS.toFixed(1)}% of basic GVA</span>
                </div>
                <input
                  id={compGOSId}
                  type="number"
                  value={inc.GOS}
                  onChange={(e) => setInc({ ...inc, GOS: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                />
                <p className="text-[11px] text-[#566575] mt-1">Corporate gross profit and capital consumption prior to debt servicing and taxes.</p>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <label htmlFor={compGMIId} className="text-[#F3F5F7] font-medium">Gross Mixed Income (GMI)</label>
                  <span className="text-[#A8B2BC] font-mono">{incResult.shares.GMI.toFixed(1)}% of basic GVA</span>
                </div>
                <input
                  id={compGMIId}
                  type="number"
                  value={inc.GMI}
                  onChange={(e) => setInc({ ...inc, GMI: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                />
                <p className="text-[11px] text-[#566575] mt-1">Remuneration for work undertaken by unincorporated enterprise owners where labor cannot be separated from capital returns.</p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label htmlFor={compNetTaxProdId} className="block text-xs text-[#A8B2BC] mb-1">Taxes Less Subsidies on Products</label>
                  <input
                    id={compNetTaxProdId}
                    type="number"
                    value={inc.net_taxes_products}
                    onChange={(e) => setInc({ ...inc, net_taxes_products: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                  />
                </div>
                <div>
                  <label htmlFor={compNetTaxProdOtherId} className="block text-xs text-[#A8B2BC] mb-1">Other Taxes on Production</label>
                  <input
                    id={compNetTaxProdOtherId}
                    type="number"
                    value={inc.net_taxes_production}
                    onChange={(e) => setInc({ ...inc, net_taxes_production: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
            <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-3">
              Factor Income Shares
            </h3>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                  <span>Compensation of Employees (Labor Share)</span>
                  <span className="font-mono text-[#F3F5F7]">{incResult.shares.CE.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-[#15191E] h-2 rounded overflow-hidden">
                  <div className="bg-[#527DA5] h-full" style={{ width: `${Math.min(100, incResult.shares.CE)}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                  <span>Operating Surplus (Capital Share)</span>
                  <span className="font-mono text-[#F3F5F7]">{incResult.shares.GOS.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-[#15191E] h-2 rounded overflow-hidden">
                  <div className="bg-[#43866B] h-full" style={{ width: `${Math.min(100, incResult.shares.GOS)}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-[#A8B2BC] mb-1">
                  <span>Mixed Income (Self-Employed)</span>
                  <span className="font-mono text-[#F3F5F7]">{incResult.shares.GMI.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-[#15191E] h-2 rounded overflow-hidden">
                  <div className="bg-[#D5A04B] h-full" style={{ width: `${Math.min(100, incResult.shares.GMI)}%` }} />
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#2A3644] space-y-1">
              <div className="flex justify-between text-xs text-[#A8B2BC]">
                <span>GVA at Basic Prices:</span>
                <span className="font-mono font-medium text-[#F3F5F7]">{formatNum(incResult.gva_basic)} {currency}</span>
              </div>
              <div className="flex justify-between text-xs text-[#A8B2BC]">
                <span>Net Taxes Adjustment:</span>
                <span className="font-mono font-medium text-[#F3F5F7]">+{formatNum(inc.net_taxes_products + inc.net_taxes_production)} {currency}</span>
              </div>
              <div className="flex justify-between text-sm font-semibold text-[#F3F5F7] pt-2 border-t border-[#2A3644]">
                <span>Income GDP at Market Prices:</span>
                <span className="font-mono text-[#43866B]">{formatNum(incResult.gdp)} {currency}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB D: RECONCILIATION */}
      {activeTab === 'reconciliation' && (
        <div className="bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#2A3644] pb-3">
            <div>
              <h3 className="text-sm font-semibold text-[#F3F5F7]">
                Multi-Method Reconciliation & Empirical Discrepancy
              </h3>
              <p className="text-xs text-[#A8B2BC]">
                Real statistical compilation uses survey samples with differing measurement error. The engine does not force artificial balance.
              </p>
            </div>
            <div className={`px-3 py-1 rounded text-xs font-medium border flex items-center gap-1.5 ${
              reconResult.within_tolerance
                ? 'bg-[#43866B]/15 text-[#43866B] border-[#43866B]/30'
                : 'bg-[#C65454]/15 text-[#C65454] border-[#C65454]/30'
            }`}>
              <ShieldIcon status={reconResult.status} />
              <span>{reconResult.status} (Threshold: {tolerancePct.toFixed(2)}%)</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-[#15191E] border border-[#2A3644] rounded">
              <div className="text-xs text-[#A8B2BC]">Expenditure vs Production Discrepancy</div>
              <div className="text-lg font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
                {reconResult.discrepancy_exp_prod_abs >= 0 ? '+' : ''}{formatNum(reconResult.discrepancy_exp_prod_abs)} {currency}
              </div>
              <div className="text-xs text-[#A8B2BC] mt-0.5 font-mono">
                {reconResult.discrepancy_exp_prod_pct >= 0 ? '+' : ''}{reconResult.discrepancy_exp_prod_pct.toFixed(3)}%
              </div>
            </div>

            <div className="p-4 bg-[#15191E] border border-[#2A3644] rounded">
              <div className="text-xs text-[#A8B2BC]">Expenditure vs Income Discrepancy</div>
              <div className="text-lg font-bold font-mono text-[#F3F5F7] mt-1 tabular-nums">
                {reconResult.discrepancy_exp_inc_abs >= 0 ? '+' : ''}{formatNum(reconResult.discrepancy_exp_inc_abs)} {currency}
              </div>
              <div className="text-xs text-[#A8B2BC] mt-0.5 font-mono">
                {reconResult.discrepancy_exp_inc_pct >= 0 ? '+' : ''}{reconResult.discrepancy_exp_inc_pct.toFixed(3)}%
              </div>
            </div>

            <div className="p-4 bg-[#15191E] border border-[#2A3644] rounded">
              <label className="block text-xs text-[#A8B2BC] mb-1">Published Statistical Discrepancy</label>
              <input
                type="number"
                value={publishedDiscrepancy}
                onChange={(e) => setPublishedDiscrepancy(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#192B40] border border-[#2A3644] rounded px-3 py-1.5 text-xs font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
              />
              <div className="text-[11px] text-[#566575] mt-1">
                Unexplained Residual: <span className="font-mono text-[#F3F5F7]">{formatNum(reconResult.unexplained_discrepancy)}</span>
              </div>
            </div>
          </div>

          <div className="p-4 bg-[#15191E]/60 border border-[#2A3644] rounded text-xs space-y-2 text-[#A8B2BC]">
            <div className="font-semibold text-[#F3F5F7]">Diagnostic Verification Checklist:</div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
              <div>• Compatible accounting time periods verified (Current Quarter)</div>
              <div>• Units reconciled consistently ({currency} {scale})</div>
              <div>• No double-counting in intermediate consumption</div>
              <div>• Net product taxes and subsidies reconciled to market prices</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ShieldIcon = ({ status }: { status: string }) => {
  if (status === 'BALANCED' || status === 'DISCREPANCY_ACCEPTABLE') {
    return <CheckCircle2 className="w-3.5 h-3.5" />;
  }
  return <AlertTriangle className="w-3.5 h-3.5" />;
};
