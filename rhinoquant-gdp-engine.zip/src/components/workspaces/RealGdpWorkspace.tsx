import React, { useState } from 'react';
import { BENCHMARK_ECONOMIES } from '../../data/benchmarkData';
import { nominalToReal, calculateDeflator } from '../../engine/macro_engine';
import { Info, RefreshCw } from 'lucide-react';

interface RealGdpWorkspaceProps {
  selectedEconomy: string;
}

export const RealGdpWorkspace: React.FC<RealGdpWorkspaceProps> = ({
  selectedEconomy
}) => {
  const eco = BENCHMARK_ECONOMIES[selectedEconomy] || BENCHMARK_ECONOMIES.USA;

  // State for interactive price deflation testing
  const [inputNominal, setInputNominal] = useState<number>(29016.4);
  const [inputDeflator, setInputDeflator] = useState<number>(125.70);
  const [selectedBaseYear, setSelectedBaseYear] = useState<number>(2017);
  const [newBaseYear, setNewBaseYear] = useState<number>(2022);

  const calculatedReal = nominalToReal(inputNominal, inputDeflator);
  const implicitDeflator = calculateDeflator(inputNominal, calculatedReal);

  // Historical series with rebasing
  const historical = eco.historical_real_gdp;

  // Find deflator value at new base year (e.g. 2022-Q1)
  const baseQuarter = historical.find((h) => h.period.startsWith(String(newBaseYear))) || historical[0];
  const rebaseFactor = baseQuarter.deflator / 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-[#2A3644]">
        <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
          Nominal & Real GDP Price Adjustment Engine
        </h2>
        <p className="text-xs text-[#A8B2BC] mt-0.5">
          Implicit GDP deflators, constant-price deflation, chain-volume indexing, and base-year rebasing.
        </p>
      </div>

      {/* Interactive Deflator & Real Output Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2 flex items-center justify-between">
            <span>Price Indexation Terminal</span>
            <span className="text-[11px] font-mono text-[#527DA5]">Real = Nominal / (Deflator / 100)</span>
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#A8B2BC] mb-1">
                Nominal GDP (Current Prices) - {eco.currency} {eco.scale}
              </label>
              <input
                type="number"
                value={inputNominal}
                onChange={(e) => setInputNominal(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#A8B2BC] mb-1">
                  GDP Deflator (Base = 100)
                </label>
                <input
                  type="number"
                  value={inputDeflator}
                  onChange={(e) => setInputDeflator(parseFloat(e.target.value) || 1)}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#A8B2BC] mb-1">
                  Reference Base Year
                </label>
                <input
                  type="number"
                  value={selectedBaseYear}
                  onChange={(e) => setSelectedBaseYear(parseInt(e.target.value, 10) || 2017)}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-2 text-sm font-mono text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
                />
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-[#15191E] border border-[#2A3644] rounded space-y-2">
            <div className="text-xs text-[#A8B2BC]">Resulting Real Output:</div>
            <div className="text-2xl font-bold font-mono text-[#43866B] tabular-nums">
              {calculatedReal.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}{' '}
              <span className="text-xs text-[#A8B2BC] font-sans font-normal">
                {eco.currency} {eco.scale} (Chained {selectedBaseYear} Prices)
              </span>
            </div>
            <div className="text-[11px] text-[#A8B2BC] font-mono">
              Reciprocal Verification: Deflator = (Nominal / Real) * 100 = {implicitDeflator.toFixed(2)}
            </div>
          </div>
        </div>

        {/* Methodological Guidance Note: CPI vs Deflator */}
        <div className="lg:col-span-6 bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#D5A04B] border-b border-[#2A3644] pb-2">
            <Info className="w-4 h-4 shrink-0" />
            <span>Methodological Boundary: CPI vs. GDP Deflator</span>
          </div>

          <p className="text-xs text-[#F3F5F7]/90 leading-relaxed">
            The <strong>Consumer Price Index (CPI)</strong> is <em>not</em> a substitute for the GDP deflator.
          </p>

          <div className="space-y-2 text-xs text-[#A8B2BC]">
            <div className="p-2.5 bg-[#15191E] rounded border border-[#2A3644]">
              <span className="text-[#F3F5F7] font-semibold">1. Coverage & Scope:</span>
              <p className="mt-0.5">
                The GDP deflator reflects all domestically produced goods and services (including capital machinery, commercial buildings, military equipment, and government services). CPI covers only urban household consumer baskets.
              </p>
            </div>
            <div className="p-2.5 bg-[#15191E] rounded border border-[#2A3644]">
              <span className="text-[#F3F5F7] font-semibold">2. Import Treatment:</span>
              <p className="mt-0.5">
                CPI directly includes imported consumer goods (e.g., imported oil, electronics). The GDP deflator measures <em>domestic value added only</em>; imported inflation is netted out via net export deflation.
              </p>
            </div>
            <div className="p-2.5 bg-[#15191E] rounded border border-[#2A3644]">
              <span className="text-[#F3F5F7] font-semibold">3. Weighting Methodology:</span>
              <p className="mt-0.5">
                GDP deflators use Paasche or Fisher ideal chain weights updated continuously. CPI historically uses fixed Laspeyres consumer expenditure baskets.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Base Year Rebasing Laboratory */}
      <div className="bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#2A3644] pb-3">
          <div>
            <h3 className="text-sm font-semibold text-[#F3F5F7] flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-[#527DA5]" />
              <span>Base Year Rebasing & Volume Invariance Audit</span>
            </h3>
            <p className="text-xs text-[#A8B2BC]">
              Rebasing alters price level indexes and reported currency magnitudes, but volume growth rates remain strictly invariant.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-[#A8B2BC]">Rebase Target Year:</span>
            <select
              value={newBaseYear}
              onChange={(e) => setNewBaseYear(parseInt(e.target.value, 10))}
              className="bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs text-[#F3F5F7] font-mono focus:outline-none focus:border-[#527DA5]"
            >
              <option value={2022}>2022 (Benchmark)</option>
              <option value={2023}>2023</option>
              <option value={2024}>2024</option>
            </select>
          </div>
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-[#F3F5F7]">
            <thead className="bg-[#15191E] text-[#A8B2BC] uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Period</th>
                <th className="py-2.5 px-3 text-right">Nominal GDP</th>
                <th className="py-2.5 px-3 text-right">Original Deflator ({selectedBaseYear}=100)</th>
                <th className="py-2.5 px-3 text-right">Original Real GDP</th>
                <th className="py-2.5 px-3 text-right">Rebased Deflator ({newBaseYear}=100)</th>
                <th className="py-2.5 px-3 text-right">Rebased Real GDP</th>
                <th className="py-2.5 px-3 text-right">Volume Growth (QoQ)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A3644] font-mono">
              {historical.map((row, idx) => {
                const rebasedDeflator = (row.deflator / baseQuarter.deflator) * 100;
                const rebasedReal = row.nominal / (rebasedDeflator / 100);

                const prevRow = idx > 0 ? historical[idx - 1] : null;
                const origGrowth = prevRow ? ((row.real / prevRow.real) - 1) * 100 : null;
                const rebasedPrev = prevRow ? prevRow.nominal / (((prevRow.deflator / baseQuarter.deflator) * 100) / 100) : null;
                const rebasedGrowth = rebasedPrev ? ((rebasedReal / rebasedPrev) - 1) * 100 : null;

                return (
                  <tr key={row.period} className="hover:bg-[#15191E]/40 text-[11px]">
                    <td className="py-2 px-3 font-semibold text-[#F3F5F7]">{row.period}</td>
                    <td className="py-2 px-3 text-right tabular-nums text-[#A8B2BC]">
                      {row.nominal.toFixed(1)}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-[#A8B2BC]">
                      {row.deflator.toFixed(2)}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-[#F3F5F7]">
                      {row.real.toFixed(1)}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-[#527DA5] font-semibold">
                      {rebasedDeflator.toFixed(2)}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-[#43866B] font-semibold">
                      {rebasedReal.toFixed(1)}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-[#F3F5F7]">
                      {origGrowth !== null ? (
                        <span>
                          {origGrowth >= 0 ? '+' : ''}{origGrowth.toFixed(2)}%
                          <span className="text-[#566575] ml-1">
                            (= {rebasedGrowth?.toFixed(2)}%)
                          </span>
                        </span>
                      ) : (
                        <span className="text-[#566575]">--</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
