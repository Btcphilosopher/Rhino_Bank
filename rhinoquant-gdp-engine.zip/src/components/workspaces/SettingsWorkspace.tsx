import React from 'react';
import { Currency, Scale } from '../../types/gdp';
import { Settings as SettingsIcon, Shield, Database, Terminal } from 'lucide-react';

interface SettingsWorkspaceProps {
  currency: Currency;
  onChangeCurrency: (c: Currency) => void;
  scale: Scale;
  onChangeScale: (s: Scale) => void;
  tolerancePct: number;
  onChangeTolerance: (t: number) => void;
}

export const SettingsWorkspace: React.FC<SettingsWorkspaceProps> = ({
  currency,
  onChangeCurrency,
  scale,
  onChangeScale,
  tolerancePct,
  onChangeTolerance
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-[#2A3644]">
        <h2 className="text-xl font-bold tracking-tight text-[#F3F5F7]">
          System Conventions & Institutional Settings
        </h2>
        <p className="text-xs text-[#A8B2BC] mt-0.5">
          Configure accounting conventions, numerical tolerances, currency conversion defaults, and statistical integrity standards.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Accounting & Tolerances */}
        <div className="bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2">
            <Shield className="w-4 h-4 text-[#527DA5]" />
            <span>Accounting Conventions & Tolerances</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#A8B2BC] mb-1">
                Reconciliation Statistical Tolerance Threshold (%)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="0.01"
                  max="2.00"
                  step="0.01"
                  value={tolerancePct}
                  onChange={(e) => onChangeTolerance(parseFloat(e.target.value))}
                  className="flex-1 accent-[#527DA5] h-1.5 bg-[#15191E] rounded cursor-pointer"
                />
                <span className="font-mono text-sm text-[#F3F5F7] w-16 text-right">
                  {tolerancePct.toFixed(2)}%
                </span>
              </div>
              <p className="text-[11px] text-[#566575] mt-1">
                If the percentage difference between Expenditure, Production, or Income GDP exceeds this threshold, the system flags a discrepancy audit alert.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="block text-xs text-[#A8B2BC] mb-1">Default Reporting Currency</label>
                <select
                  value={currency}
                  onChange={(e) => onChangeCurrency(e.target.value as Currency)}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs text-[#F3F5F7]"
                >
                  <option value="USD">USD ($ - United States Dollar)</option>
                  <option value="EUR">EUR (€ - Euro)</option>
                  <option value="GBP">GBP (£ - British Pound)</option>
                  <option value="JPY">JPY (¥ - Japanese Yen)</option>
                  <option value="CNY">CNY (¥ - Chinese Yuan)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-[#A8B2BC] mb-1">Magnitude Display Scale</label>
                <select
                  value={scale}
                  onChange={(e) => onChangeScale(e.target.value as Scale)}
                  className="w-full bg-[#15191E] border border-[#2A3644] rounded px-3 py-1.5 text-xs text-[#F3F5F7]"
                >
                  <option value="billions">Billions (10⁹)</option>
                  <option value="millions">Millions (10⁶)</option>
                  <option value="units">Base Currency Units</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Data Architecture & Engine Specs */}
        <div className="bg-[#192B40] border border-[#2A3644] rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#F3F5F7] border-b border-[#2A3644] pb-2">
            <Terminal className="w-4 h-4 text-[#527DA5]" />
            <span>Computational Architecture & Reproducibility</span>
          </div>

          <div className="space-y-2 text-xs text-[#A8B2BC]">
            <div className="flex justify-between py-1 border-b border-[#2A3644]/60">
              <span className="text-[#F3F5F7]">Framework Standards:</span>
              <span className="font-mono text-[#F3F5F7]">UN SNA 2008 / Eurostat ESA 2010</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#2A3644]/60">
              <span className="text-[#F3F5F7]">Primary Language:</span>
              <span className="font-mono text-[#527DA5]">R (&gt;= 4.4.0) + TypeScript Math Core</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#2A3644]/60">
              <span className="text-[#F3F5F7]">Floating-Point Precision:</span>
              <span className="font-mono text-[#F3F5F7]">IEEE 754 Double Precision (64-bit)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#2A3644]/60">
              <span className="text-[#F3F5F7]">Missing Value Policy:</span>
              <span className="font-mono text-[#D5A04B]">Explicit NA Retention (No Zero Replacement)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#F3F5F7]">Intermediate Consumption:</span>
              <span className="font-mono text-[#43866B]">Double-Counting Deduction Enforced</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
