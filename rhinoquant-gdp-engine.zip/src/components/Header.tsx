import React from 'react';
import { Download, ShieldCheck, Terminal } from 'lucide-react';

interface HeaderProps {
  onOpenReport: () => void;
  onOpenRRepo: () => void;
  isAuditPassing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenReport,
  onOpenRRepo,
  isAuditPassing
}) => {
  return (
    <header className="h-14 bg-[#192B40] border-b border-[#2A3644] px-6 flex items-center justify-between gap-8 select-none shrink-0 z-30">
      {/* Zone 1: Single text wordmark */}
      <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
        <span className="text-base font-bold tracking-tight text-[#F3F5F7] font-['Plus_Jakarta_Sans']">
          RhinoQuant GDP Engine
        </span>
        <span className="text-xs text-[#A8B2BC] font-mono tabular-nums border-l border-[#2A3644] pl-3">
          SNA 2008 / ESA 2010
        </span>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-[#A8B2BC]">
        <span className="hover:text-[#F3F5F7] transition-colors whitespace-nowrap">
          National Accounts Compendium
        </span>
        <span className="hover:text-[#F3F5F7] transition-colors whitespace-nowrap">
          BEA / Eurostat Grounded
        </span>
        <span className="hover:text-[#F3F5F7] transition-colors whitespace-nowrap">
          Double-Entry Invariants
        </span>
        <span className="hover:text-[#F3F5F7] transition-colors whitespace-nowrap flex items-center gap-1.5">
          <ShieldCheck className={`w-3.5 h-3.5 ${isAuditPassing ? 'text-[#43866B]' : 'text-[#C65454]'}`} />
          {isAuditPassing ? 'Identities Balanced' : 'Discrepancy Detected'}
        </span>
      </nav>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenRRepo}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#F3F5F7] bg-[#15191E] border border-[#2A3644] rounded hover:border-[#527DA5] transition-colors whitespace-nowrap"
          title="Inspect R package source code, tests, and targets pipeline"
        >
          <Terminal className="w-3.5 h-3.5 text-[#527DA5]" />
          <span>R Engine & Package</span>
        </button>
        <button
          onClick={onOpenReport}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#527DA5] hover:bg-[#436b90] rounded transition-colors whitespace-nowrap shadow-sm"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Audit Brief</span>
        </button>
      </div>
    </header>
  );
};
