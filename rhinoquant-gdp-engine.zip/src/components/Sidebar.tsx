import React from 'react';
import {
  Calculator,
  Database,
  TrendingUp,
  Percent,
  Layers,
  Globe2,
  LineChart,
  SlidersHorizontal,
  FlaskConical,
  FileSpreadsheet,
  FileText,
  Settings,
  FolderCode
} from 'lucide-react';
import { Currency, Scale } from '../types/gdp';

export type WorkspaceId =
  | 'calculator'
  | 'national_accounts'
  | 'real_gdp'
  | 'growth'
  | 'sector'
  | 'international'
  | 'forecast'
  | 'scenarios'
  | 'econometrics'
  | 'data_lab'
  | 'reports'
  | 'r_repository'
  | 'settings';

interface SidebarProps {
  activeWorkspace: WorkspaceId;
  onSelectWorkspace: (id: WorkspaceId) => void;
  selectedEconomy: string;
  onSelectEconomy: (code: string) => void;
  currency: Currency;
  onChangeCurrency: (c: Currency) => void;
  scale: Scale;
  onChangeScale: (s: Scale) => void;
  tolerancePct: number;
  onChangeTolerance: (t: number) => void;
}

const NAV_ITEMS: { id: WorkspaceId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'calculator', label: '1. GDP Calculator', icon: Calculator },
  { id: 'national_accounts', label: '2. National Accounts', icon: Database },
  { id: 'real_gdp', label: '3. Real GDP & Deflator', icon: Percent },
  { id: 'growth', label: '4. Growth Analytics', icon: TrendingUp },
  { id: 'sector', label: '5. Sector Decomposition', icon: Layers },
  { id: 'international', label: '6. International Comparison', icon: Globe2 },
  { id: 'forecast', label: '7. Forecast Studio', icon: LineChart },
  { id: 'scenarios', label: '8. Macro Scenario Engine', icon: SlidersHorizontal },
  { id: 'econometrics', label: '9. Econometric Lab', icon: FlaskConical },
  { id: 'data_lab', label: '10. Data Laboratory', icon: FileSpreadsheet },
  { id: 'reports', label: '11. Reports & Audit Brief', icon: FileText },
  { id: 'r_repository', label: 'R Engine & Repository', icon: FolderCode },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeWorkspace,
  onSelectWorkspace,
  selectedEconomy,
  onSelectEconomy,
  currency,
  onChangeCurrency,
  scale,
  onChangeScale,
  tolerancePct,
  onChangeTolerance,
}) => {
  return (
    <aside className="w-64 bg-[#192B40]/70 border-r border-[#2A3644] flex flex-col justify-between shrink-0 select-none overflow-y-auto">
      {/* Workspace Menu */}
      <div className="p-3">
        <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-[#A8B2BC]">
          Navigation Workspaces
        </div>
        <nav className="space-y-0.5">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeWorkspace === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectWorkspace(item.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded transition-colors text-left ${
                  isActive
                    ? 'bg-[#527DA5] text-white shadow-sm'
                    : 'text-[#F3F5F7]/80 hover:bg-[#15191E] hover:text-[#F3F5F7]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-[#A8B2BC]'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Persistent Analysis Parameters */}
      <div className="p-3.5 border-t border-[#2A3644] bg-[#15191E]/60 space-y-3">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-[#A8B2BC]">
          Session Parameters
        </div>

        <div>
          <label className="block text-[11px] text-[#A8B2BC] mb-1">Target Economy</label>
          <select
            value={selectedEconomy}
            onChange={(e) => onSelectEconomy(e.target.value)}
            className="w-full text-xs bg-[#15191E] border border-[#2A3644] rounded px-2 py-1.5 text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
          >
            <option value="USA">United States (US BEA)</option>
            <option value="EA20">Euro Area (Eurostat ESA 2010)</option>
            <option value="GBR">United Kingdom (ONS)</option>
            <option value="JPN">Japan (Cabinet Office ESRI)</option>
            <option value="CUSTOM">User Custom Dataset</option>
          </select>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="block text-[11px] text-[#A8B2BC] mb-1">Currency</label>
            <select
              value={currency}
              onChange={(e) => onChangeCurrency(e.target.value as Currency)}
              className="w-full text-xs bg-[#15191E] border border-[#2A3644] rounded px-2 py-1.5 text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="JPY">JPY (¥)</option>
              <option value="CNY">CNY (¥)</option>
            </select>
          </div>
          <div>
            <label className="block text-[11px] text-[#A8B2BC] mb-1">Magnitude</label>
            <select
              value={scale}
              onChange={(e) => onChangeScale(e.target.value as Scale)}
              className="w-full text-xs bg-[#15191E] border border-[#2A3644] rounded px-2 py-1.5 text-[#F3F5F7] focus:outline-none focus:border-[#527DA5]"
            >
              <option value="billions">Billions</option>
              <option value="millions">Millions</option>
              <option value="units">Base Units</option>
            </select>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between text-[11px] text-[#A8B2BC] mb-1">
            <span>Reconciliation Tolerance</span>
            <span className="font-mono text-[#F3F5F7]">{tolerancePct.toFixed(2)}%</span>
          </div>
          <input
            type="range"
            min="0.01"
            max="1.0"
            step="0.01"
            value={tolerancePct}
            onChange={(e) => onChangeTolerance(parseFloat(e.target.value))}
            className="w-full accent-[#527DA5] h-1 bg-[#2A3644] rounded cursor-pointer"
          />
        </div>

        <div className="pt-1 text-[10px] text-[#566575] font-mono leading-tight">
          Accounting Standard: SNA 2008 / ESA 2010<br />
          Engine Core: R 4.4+ / Pure Numerical Invariants
        </div>
      </div>
    </aside>
  );
};
