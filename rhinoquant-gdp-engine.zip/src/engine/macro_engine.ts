import {
  Currency,
  Scale,
  ExpenditureComponents,
  ExpenditureResult,
  SectorItem,
  ProductionResult,
  IncomeComponents,
  IncomeResult,
  ReconciliationResult,
  ForecastResult,
  ForecastPoint,
  ScenarioResult
} from '../types/gdp';

/**
 * Expenditure Approach: GDP = C + I + G + (X - M)
 */
export function calculateExpenditureGdp(
  components: ExpenditureComponents,
  unit: Currency = 'USD',
  scale: Scale = 'billions'
): ExpenditureResult {
  const { C, I, G, X, M } = components;
  if (M < 0) {
    throw new Error('Imports (M) cannot be negative; enter positive magnitude to deduct.');
  }

  const net_exports = X - M;
  const gdp = C + I + G + net_exports;

  const shares = {
    C: gdp !== 0 ? (C / gdp) * 100 : 0,
    I: gdp !== 0 ? (I / gdp) * 100 : 0,
    G: gdp !== 0 ? (G / gdp) * 100 : 0,
    X: gdp !== 0 ? (X / gdp) * 100 : 0,
    M: gdp !== 0 ? -(M / gdp) * 100 : 0,
    NX: gdp !== 0 ? (net_exports / gdp) * 100 : 0,
  };

  return {
    gdp,
    net_exports,
    components,
    shares,
    unit,
    scale
  };
}

/**
 * Production Approach: GDP = sum(GVA_i) + Taxes_products - Subsidies_products
 * GVA_i = GrossOutput_i - IntermediateConsumption_i
 */
export function calculateProductionGdp(
  sectors: SectorItem[],
  taxes_on_products: number = 0,
  subsidies_on_products: number = 0,
  unit: Currency = 'USD',
  scale: Scale = 'billions'
): ProductionResult {
  let total_gva = 0;

  const enrichedSectors = sectors.map((s) => {
    if (s.intermediate_consumption < 0) {
      throw new Error(`Intermediate consumption for sector ${s.name} cannot be negative.`);
    }
    const gva = s.gross_output - s.intermediate_consumption;
    total_gva += gva;

    const productivity = s.employment_thousands && s.employment_thousands > 0
      ? gva / s.employment_thousands
      : undefined;

    return {
      ...s,
      gva,
      productivity
    };
  });

  const net_product_taxes = taxes_on_products - subsidies_on_products;
  const gdp = total_gva + net_product_taxes;

  const finalSectors = enrichedSectors.map((s) => ({
    ...s,
    share_pct: total_gva !== 0 ? ((s.gva || 0) / total_gva) * 100 : 0
  }));

  return {
    gdp,
    total_gva,
    net_product_taxes,
    taxes_on_products,
    subsidies_on_products,
    sectors: finalSectors,
    unit,
    scale
  };
}

/**
 * Income Approach: GDP = (CE + GOS + GMI) + (T_p - S_p) + (T_o - S_o)
 */
export function calculateIncomeGdp(
  components: IncomeComponents,
  unit: Currency = 'USD',
  scale: Scale = 'billions'
): IncomeResult {
  const { CE, GOS, GMI, net_taxes_products, net_taxes_production } = components;
  const gva_basic = CE + GOS + GMI;
  const gdp = gva_basic + net_taxes_products + net_taxes_production;

  const shares = {
    CE: gva_basic !== 0 ? (CE / gva_basic) * 100 : 0,
    GOS: gva_basic !== 0 ? (GOS / gva_basic) * 100 : 0,
    GMI: gva_basic !== 0 ? (GMI / gva_basic) * 100 : 0,
  };

  return {
    gdp,
    gva_basic,
    components,
    shares,
    unit,
    scale
  };
}

/**
 * Multi-Method Reconciliation & Statistical Discrepancy
 */
export function reconcileAccounts(
  expenditureGdp: number,
  productionGdp: number,
  incomeGdp: number,
  tolerancePct: number = 0.10,
  publishedDiscrepancy: number = 0
): ReconciliationResult {
  const discrepancy_exp_prod_abs = expenditureGdp - productionGdp;
  const discrepancy_exp_prod_pct = productionGdp !== 0
    ? (discrepancy_exp_prod_abs / productionGdp) * 100
    : 0;

  const discrepancy_exp_inc_abs = expenditureGdp - incomeGdp;
  const discrepancy_exp_inc_pct = incomeGdp !== 0
    ? (discrepancy_exp_inc_abs / incomeGdp) * 100
    : 0;

  const unexplained_discrepancy = discrepancy_exp_prod_abs - publishedDiscrepancy;
  const maxDiscrepancyPct = Math.max(Math.abs(discrepancy_exp_prod_pct), Math.abs(discrepancy_exp_inc_pct));

  const within_tolerance = maxDiscrepancyPct <= tolerancePct;

  let status: 'BALANCED' | 'DISCREPANCY_ACCEPTABLE' | 'DISCREPANCY_EXCEEDS_TOLERANCE';
  if (maxDiscrepancyPct <= 1e-4) {
    status = 'BALANCED';
  } else if (within_tolerance) {
    status = 'DISCREPANCY_ACCEPTABLE';
  } else {
    status = 'DISCREPANCY_EXCEEDS_TOLERANCE';
  }

  return {
    expenditure_gdp: expenditureGdp,
    production_gdp: productionGdp,
    income_gdp: incomeGdp,
    discrepancy_exp_prod_abs,
    discrepancy_exp_prod_pct,
    discrepancy_exp_inc_abs,
    discrepancy_exp_inc_pct,
    published_discrepancy: publishedDiscrepancy,
    unexplained_discrepancy,
    tolerance_pct: tolerancePct,
    within_tolerance,
    status
  };
}

/**
 * Nominal to Real Deflation: Real = Nominal / (Deflator / 100)
 */
export function nominalToReal(nominalGdp: number, deflator: number): number {
  if (deflator <= 0) throw new Error('Deflator must be strictly positive.');
  return nominalGdp / (deflator / 100);
}

/**
 * Implicit Deflator: Deflator = (Nominal / Real) * 100
 */
export function calculateDeflator(nominalGdp: number, realGdp: number): number {
  if (realGdp === 0) throw new Error('Real GDP cannot be zero for deflator calculation.');
  return (nominalGdp / realGdp) * 100;
}

/**
 * Rebase Series to New Base Period (100)
 */
export function rebaseSeries(series: number[], oldBaseValue: number, newBaseValue: number): number[] {
  if (newBaseValue <= 0) throw new Error('New base value must be positive.');
  return series.map((val) => (val / newBaseValue) * 100);
}

/**
 * Growth Metrics
 */
export function calculateGrowthYoy(series: number[], lag: number = 4): (number | null)[] {
  return series.map((val, idx) => {
    if (idx < lag) return null;
    const prev = series[idx - lag];
    if (prev === 0 || prev == null) return null;
    return ((val / prev) - 1) * 100;
  });
}

export function calculateGrowthQoq(series: number[]): (number | null)[] {
  return calculateGrowthYoy(series, 1);
}

export function calculateGrowthAnnualised(series: number[]): (number | null)[] {
  return series.map((val, idx) => {
    if (idx < 1) return null;
    const prev = series[idx - 1];
    if (prev <= 0) return null;
    return (Math.pow(val / prev, 4) - 1) * 100;
  });
}

export function calculateCagr(startValue: number, endValue: number, years: number): number {
  if (startValue <= 0 || endValue <= 0 || years <= 0) {
    throw new Error('Start, end values and years must be positive.');
  }
  return (Math.pow(endValue / startValue, 1 / years) - 1) * 100;
}

export function calculateGdpPerCapita(
  gdp: number,
  population: number,
  scaleGdp: Scale = 'billions',
  scalePop: Scale = 'units'
): number {
  const multipliers: Record<Scale, number> = {
    units: 1,
    thousands: 1e3,
    millions: 1e6,
    billions: 1e9,
    trillions: 1e12
  };
  const gdpUnits = gdp * multipliers[scaleGdp];
  const popUnits = population * multipliers[scalePop];
  if (popUnits <= 0) throw new Error('Population must be positive.');
  return gdpUnits / popUnits;
}

export function calculateComponentContributions(
  changes: Record<string, number>,
  baseGdp: number
): Record<string, number> {
  if (baseGdp <= 0) throw new Error('Base GDP must be positive.');
  const contributions: Record<string, number> = {};
  for (const [key, val] of Object.entries(changes)) {
    contributions[key] = (val / baseGdp) * 100;
  }
  return contributions;
}

/**
 * Forecasting Laboratory
 */
export function generateForecast(
  history: number[],
  historyPeriods: string[],
  horizon: number = 8,
  modelType: 'auto_arima' | 'ets' | 'drift' | 'naive' = 'auto_arima'
): ForecastResult {
  const n = history.length;
  if (n < 6) throw new Error('Forecasting requires at least 6 historical points.');

  const lastPeriod = historyPeriods[n - 1] || '2024-Q3';
  const lastVal = history[n - 1];
  const firstVal = history[0];
  const driftSlope = (lastVal - firstVal) / (n - 1);

  // Residual volatility
  const diffs: number[] = [];
  for (let i = 1; i < n; i++) {
    diffs.push(history[i] - history[i - 1]);
  }
  const meanDiff = diffs.reduce((a, b) => a + b, 0) / diffs.length;
  const varianceDiff = diffs.reduce((a, b) => a + Math.pow(b - meanDiff, 2), 0) / (diffs.length - 1);
  const sigma = Math.sqrt(varianceDiff) || 50;

  // Next quarters generator
  const getNextQuarter = (current: string, step: number): string => {
    const parts = current.split('-Q');
    if (parts.length === 2) {
      let y = parseInt(parts[0], 10);
      let q = parseInt(parts[1], 10);
      for (let s = 0; s < step; s++) {
        q++;
        if (q > 4) {
          q = 1;
          y++;
        }
      }
      return `${y}-Q${q}`;
    }
    const year = parseInt(current, 10);
    if (!isNaN(year)) return `${year + step}`;
    return `Period +${step}`;
  };

  const forecasts: ForecastPoint[] = [];

  // Model-specific point estimates
  let phi = 0.42; // AR(1) coefficient
  let c = meanDiff * (1 - phi);

  let currentDiff = diffs[diffs.length - 1];
  let currentLevel = lastVal;

  let etsLevel = history[0];
  let etsTrend = driftSlope;
  const alpha = 0.6;
  const beta = 0.2;
  for (let t = 1; t < n; t++) {
    const prevLvl = etsLevel;
    etsLevel = alpha * history[t] + (1 - alpha) * (prevLvl + etsTrend);
    etsTrend = beta * (etsLevel - prevLvl) + (1 - beta) * etsTrend;
  }

  for (let h = 1; h <= horizon; h++) {
    let pointVal = 0;
    let se = sigma * Math.sqrt(h);

    if (modelType === 'naive') {
      pointVal = lastVal;
    } else if (modelType === 'drift') {
      pointVal = lastVal + (h * driftSlope);
      se = sigma * Math.sqrt(h * (1 + h / n));
    } else if (modelType === 'ets') {
      pointVal = etsLevel + (h * etsTrend);
      se = sigma * Math.sqrt(h) * 1.12;
    } else {
      // Auto-ARIMA (ARIMA(1,1,0) with drift)
      const nextDiff = c + (phi * currentDiff);
      currentLevel += nextDiff;
      pointVal = currentLevel;
      currentDiff = nextDiff;
      se = sigma * Math.sqrt(h);
    }

    forecasts.push({
      period: getNextQuarter(lastPeriod, h),
      point: pointVal,
      lower_80: pointVal - (1.282 * se),
      upper_80: pointVal + (1.282 * se),
      lower_95: pointVal - (1.960 * se),
      upper_95: pointVal + (1.960 * se)
    });
  }

  // Out-of-sample backtest on last 4 quarters
  const testSize = Math.min(4, Math.floor(n * 0.25));
  const train = history.slice(0, n - testSize);
  const actuals = history.slice(n - testSize);
  const trainSlope = (train[train.length - 1] - train[0]) / (train.length - 1);
  const preds: number[] = [];
  for (let k = 1; k <= testSize; k++) {
    preds.push(train[train.length - 1] + (k * trainSlope));
  }

  let absErrors = 0;
  let sqErrors = 0;
  let pctErrors = 0;
  for (let k = 0; k < testSize; k++) {
    const err = actuals[k] - preds[k];
    absErrors += Math.abs(err);
    sqErrors += err * err;
    if (actuals[k] !== 0) {
      pctErrors += Math.abs(err / actuals[k]);
    }
  }

  const mae = absErrors / testSize;
  const rmse = Math.sqrt(sqErrors / testSize);
  const mape = (pctErrors / testSize) * 100;

  return {
    model_type: modelType,
    horizon,
    forecasts,
    backtest: {
      sample_size: testSize,
      mae,
      rmse,
      mape: isNaN(mape) ? null : mape
    },
    equation_notes: modelType === 'auto_arima'
      ? 'ARIMA(1,1,0) with Drift: (1 - φB)(1 - B)y_t = c + ε_t'
      : modelType === 'ets'
      ? 'Holt-Winters Linear Trend ETS(A,A,N): y_t = l_{t-1} + b_{t-1} + ε_t'
      : modelType === 'drift'
      ? 'Drift Benchmark: y_{T+h} = y_T + h * ((y_T - y_1) / (T - 1))'
      : 'Naive Benchmark: y_{T+h} = y_T'
  };
}

/**
 * Deterministic Scenario Analysis
 */
export function runScenarioAnalysis(
  baseline: ExpenditureComponents,
  shocks: { C: number; I: number; G: number; X: number; M: number }
): ScenarioResult {
  const base_gdp = baseline.C + baseline.I + baseline.G + (baseline.X - baseline.M);

  const stressed_C = baseline.C * (1 + (shocks.C / 100));
  const stressed_I = baseline.I * (1 + (shocks.I / 100));
  const stressed_G = baseline.G * (1 + (shocks.G / 100));
  const stressed_X = baseline.X * (1 + (shocks.X / 100));
  const stressed_M = baseline.M * (1 + (shocks.M / 100));

  const stressed_gdp = stressed_C + stressed_I + stressed_G + (stressed_X - stressed_M);
  const delta_abs = stressed_gdp - base_gdp;
  const delta_pct = base_gdp !== 0 ? (delta_abs / base_gdp) * 100 : 0;

  return {
    baseline_gdp: base_gdp,
    scenario_gdp: stressed_gdp,
    delta_abs,
    delta_pct,
    stressed_components: {
      C: stressed_C,
      I: stressed_I,
      G: stressed_G,
      X: stressed_X,
      M: stressed_M
    },
    contributions: {
      C: stressed_C - baseline.C,
      I: stressed_I - baseline.I,
      G: stressed_G - baseline.G,
      X: stressed_X - baseline.X,
      M: -(stressed_M - baseline.M) // deduction
    }
  };
}

/**
 * Econometric Diagnostics: Simple OLS with White Heteroskedasticity-Robust Standard Errors
 */
export function runOlsRegression(y: number[], x: number[]): {
  beta: number;
  alpha: number;
  r_squared: number;
  se_beta_robust: number;
  t_stat_robust: number;
  p_value_robust: number;
} {
  const n = y.length;
  if (n !== x.length || n < 4) {
    throw new Error('Regression requires equal series lengths >= 4.');
  }

  const meanX = x.reduce((a, b) => a + b, 0) / n;
  const meanY = y.reduce((a, b) => a + b, 0) / n;

  let sxx = 0;
  let sxy = 0;
  let syy = 0;

  for (let i = 0; i < n; i++) {
    const dx = x[i] - meanX;
    const dy = y[i] - meanY;
    sxx += dx * dx;
    sxy += dx * dy;
    syy += dy * dy;
  }

  const beta = sxx !== 0 ? sxy / sxx : 0;
  const alpha = meanY - (beta * meanX);
  const r_squared = syy !== 0 ? (sxy * sxy) / (sxx * syy) : 0;

  // Residuals
  const residuals: number[] = [];
  let s0 = 0;
  for (let i = 0; i < n; i++) {
    const res = y[i] - (alpha + beta * x[i]);
    residuals.push(res);
    const dx = x[i] - meanX;
    s0 += dx * dx * res * res;
  }

  // White robust SE: sqrt( sum(dx_i^2 * e_i^2) / (sum(dx_i^2))^2 )
  const se_beta_robust = sxx !== 0 ? Math.sqrt(s0) / sxx : 0;
  const t_stat_robust = se_beta_robust !== 0 ? beta / se_beta_robust : 0;
  // Approximate two-tailed p-value from t-distribution (normal approximation)
  const z = Math.abs(t_stat_robust);
  const p_value_robust = 2 * (1 - normalCdf(z));

  return {
    beta,
    alpha,
    r_squared,
    se_beta_robust,
    t_stat_robust,
    p_value_robust
  };
}

function normalCdf(z: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(z));
  const d = 0.3989423 * Math.exp(-z * z / 2);
  const prob = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return z > 0 ? 1 - prob : prob;
}
