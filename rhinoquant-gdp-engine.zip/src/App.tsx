/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Currency, Scale } from './types/gdp';
import { Header } from './components/Header';
import { Sidebar, WorkspaceId } from './components/Sidebar';
import { CalculatorWorkspace } from './components/workspaces/CalculatorWorkspace';
import { NationalAccountsWorkspace } from './components/workspaces/NationalAccountsWorkspace';
import { RealGdpWorkspace } from './components/workspaces/RealGdpWorkspace';
import { GrowthAnalyticsWorkspace } from './components/workspaces/GrowthAnalyticsWorkspace';
import { SectorDecompositionWorkspace } from './components/workspaces/SectorDecompositionWorkspace';
import { InternationalWorkspace } from './components/workspaces/InternationalWorkspace';
import { ForecastStudioWorkspace } from './components/workspaces/ForecastStudioWorkspace';
import { ScenarioEngineWorkspace } from './components/workspaces/ScenarioEngineWorkspace';
import { EconometricLabWorkspace } from './components/workspaces/EconometricLabWorkspace';
import { DataLabWorkspace } from './components/workspaces/DataLabWorkspace';
import { ReportsWorkspace } from './components/workspaces/ReportsWorkspace';
import { RRepositoryViewer } from './components/workspaces/RRepositoryViewer';
import { SettingsWorkspace } from './components/workspaces/SettingsWorkspace';

export default function App() {
  const [activeWorkspace, setActiveWorkspace] = useState<WorkspaceId>('calculator');
  const [selectedEconomy, setSelectedEconomy] = useState<string>('USA');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [scale, setScale] = useState<Scale>('billions');
  const [tolerancePct, setTolerancePct] = useState<number>(0.10);

  return (
    <div className="min-h-screen bg-[#15191E] text-[#F3F5F7] flex flex-col font-['Plus_Jakarta_Sans'] antialiased">
      {/* Top Bar Contract adhering to Universal Design Constitution */}
      <Header
        onOpenReport={() => setActiveWorkspace('reports')}
        onOpenRRepo={() => setActiveWorkspace('r_repository')}
        isAuditPassing={true}
      />

      {/* Main Terminal Viewport */}
      <div className="flex-1 flex overflow-hidden">
        {/* Persistent Analysis Sidebar */}
        <Sidebar
          activeWorkspace={activeWorkspace}
          onSelectWorkspace={setActiveWorkspace}
          selectedEconomy={selectedEconomy}
          onSelectEconomy={(eco) => {
            setSelectedEconomy(eco);
            if (eco === 'EA20') setCurrency('EUR');
            else if (eco === 'GBR') setCurrency('GBP');
            else if (eco === 'JPN') setCurrency('JPY');
            else if (eco === 'USA') setCurrency('USD');
          }}
          currency={currency}
          onChangeCurrency={setCurrency}
          scale={scale}
          onChangeScale={setScale}
          tolerancePct={tolerancePct}
          onChangeTolerance={setTolerancePct}
        />

        {/* Central Working Area */}
        <main className="flex-1 overflow-y-auto p-6 bg-[#15191E]">
          <div className="max-w-[1400px] mx-auto">
            {activeWorkspace === 'calculator' && (
              <CalculatorWorkspace
                currency={currency}
                scale={scale}
                tolerancePct={tolerancePct}
              />
            )}

            {activeWorkspace === 'national_accounts' && (
              <NationalAccountsWorkspace
                selectedEconomy={selectedEconomy}
              />
            )}

            {activeWorkspace === 'real_gdp' && (
              <RealGdpWorkspace
                selectedEconomy={selectedEconomy}
              />
            )}

            {activeWorkspace === 'growth' && (
              <GrowthAnalyticsWorkspace
                selectedEconomy={selectedEconomy}
              />
            )}

            {activeWorkspace === 'sector' && (
              <SectorDecompositionWorkspace
                selectedEconomy={selectedEconomy}
              />
            )}

            {activeWorkspace === 'international' && (
              <InternationalWorkspace />
            )}

            {activeWorkspace === 'forecast' && (
              <ForecastStudioWorkspace
                selectedEconomy={selectedEconomy}
              />
            )}

            {activeWorkspace === 'scenarios' && (
              <ScenarioEngineWorkspace />
            )}

            {activeWorkspace === 'econometrics' && (
              <EconometricLabWorkspace
                selectedEconomy={selectedEconomy}
              />
            )}

            {activeWorkspace === 'data_lab' && (
              <DataLabWorkspace />
            )}

            {activeWorkspace === 'reports' && (
              <ReportsWorkspace
                selectedEconomy={selectedEconomy}
              />
            )}

            {activeWorkspace === 'r_repository' && (
              <RRepositoryViewer />
            )}

            {activeWorkspace === 'settings' && (
              <SettingsWorkspace
                currency={currency}
                onChangeCurrency={setCurrency}
                scale={scale}
                onChangeScale={setScale}
                tolerancePct={tolerancePct}
                onChangeTolerance={setTolerancePct}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
