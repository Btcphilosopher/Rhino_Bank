/**
 * RhinoQuant Formatting Utilities
 * Standardized institutional financial currency, percentage, and date formatters.
 */

export function formatCurrency(amount: number, currency = 'USD', compact = false): string {
  if (amount === null || amount === undefined || isNaN(amount)) return '—';

  const sign = amount < 0 ? '-' : '';
  const abs = Math.abs(amount);

  if (compact) {
    if (abs >= 1e9) {
      return `${sign}$${(abs / 1e9).toFixed(2)}B`;
    }
    if (abs >= 1e6) {
      return `${sign}$${(abs / 1e6).toFixed(2)}M`;
    }
    if (abs >= 1e3) {
      return `${sign}$${(abs / 1e3).toFixed(1)}k`;
    }
    return `${sign}$${abs.toFixed(0)}`;
  }

  return (
    sign +
    '$' +
    abs.toLocaleString('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })
  );
}

export function formatPercent(rate: number | null | undefined, decimals = 2): string {
  if (rate === null || rate === undefined || isNaN(rate) || !isFinite(rate)) {
    return 'N/A';
  }
  const pct = rate * 100;
  return `${pct >= 0 ? '' : ''}${pct.toFixed(decimals)}%`;
}

export function formatMultiple(moic: number | null | undefined): string {
  if (moic === null || moic === undefined || isNaN(moic) || !isFinite(moic)) {
    return 'N/A';
  }
  return `${moic.toFixed(2)}x`;
}

export function formatYears(years: number | null | undefined): string {
  if (years === null || years === undefined || isNaN(years)) {
    return 'Never';
  }
  return `${years.toFixed(2)} yrs`;
}
