/**
 * RhinoQuant Fund Waterfall & Fee Distribution Workstation
 * European Private Equity Waterfall, Preferred Return Hurdle, GP Catch-up, and Gross vs Net Returns.
 */

import React, { useState } from 'react';
import { CashFlowItem } from '../engine/types';
import { computeFundWaterfall, WaterfallConfig } from '../engine/fundWaterfall';
import { formatCurrency, formatPercent, formatMultiple } from '../utils/formatters';
import { Layers, ShieldCheck, DollarSign } from 'lucide-react';

interface FundWaterfallViewProps {
  items: CashFlowItem[];
  valuationDate: string;
  currency: string;
}

export const FundWaterfallView: React.FC<FundWaterfallViewProps> = ({
  items,
  valuationDate,
  currency,
}) => {
  const [config, setConfig] = useState<WaterfallConfig>({
    committedCapital: 100000000,
    managementFeeRate: 0.02,
    hurdleRate: 0.08,
    gpCatchUpRate: 1.0,
    carriedInterestRate: 0.20,
    gpCommitmentPercent: 0.02,
  });

  const waterfall = computeFundWaterfall(items, valuationDate, config);

  const handleUpdateConfig = (field: keyof WaterfallConfig, val: number) => {
    setConfig({ ...config, [field]: val });
  };

  return (
    <div className="space-y-4">
      {/* Waterfall Parameters Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-3.5 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-sky-400" />
            <h3 className="text-xs font-semibold text-slate-100 uppercase tracking-wider font-mono">
              European Whole-Fund Waterfall Distribution Rules
            </h3>
          </div>
          <span className="text-[11px] font-mono text-slate-500">
            Hurdle: {(config.hurdleRate * 100).toFixed(1)}% · Carry: {(config.carriedInterestRate * 100).toFixed(0)}%
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 font-mono text-xs">
          <div className="bg-slate-900 p-2 rounded border border-slate-800">
            <label className="text-[10px] text-slate-500 block mb-1">Fund Size / Committed</label>
            <input
              type="number"
              step="5000000"
              value={config.committedCapital}
              onChange={(e) => handleUpdateConfig('committedCapital', parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200"
            />
          </div>

          <div className="bg-slate-900 p-2 rounded border border-slate-800">
            <label className="text-[10px] text-slate-500 block mb-1">Management Fee p.a.</label>
            <select
              value={config.managementFeeRate}
              onChange={(e) => handleUpdateConfig('managementFeeRate', parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200"
            >
              <option value="0.015">1.50%</option>
              <option value="0.0175">1.75%</option>
              <option value="0.02">2.00%</option>
              <option value="0.025">2.50%</option>
            </select>
          </div>

          <div className="bg-slate-900 p-2 rounded border border-slate-800">
            <label className="text-[10px] text-slate-500 block mb-1">Preferred Return (Hurdle)</label>
            <select
              value={config.hurdleRate}
              onChange={(e) => handleUpdateConfig('hurdleRate', parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200"
            >
              <option value="0.06">6.00%</option>
              <option value="0.07">7.00%</option>
              <option value="0.08">8.00%</option>
              <option value="0.10">10.00%</option>
            </select>
          </div>

          <div className="bg-slate-900 p-2 rounded border border-slate-800">
            <label className="text-[10px] text-slate-500 block mb-1">GP Catch-Up Rate</label>
            <select
              value={config.gpCatchUpRate}
              onChange={(e) => handleUpdateConfig('gpCatchUpRate', parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200"
            >
              <option value="1.0">100% Full Catch-Up</option>
              <option value="0.8">80% / 20% Soft Catch-Up</option>
              <option value="0.5">50% Catch-Up</option>
              <option value="0.0">0% (No Catch-Up)</option>
            </select>
          </div>

          <div className="bg-slate-900 p-2 rounded border border-slate-800">
            <label className="text-[10px] text-slate-500 block mb-1">Carried Interest Split</label>
            <select
              value={config.carriedInterestRate}
              onChange={(e) => handleUpdateConfig('carriedInterestRate', parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200"
            >
              <option value="0.15">85% LP / 15% GP</option>
              <option value="0.20">80% LP / 20% GP</option>
              <option value="0.25">75% LP / 25% GP</option>
            </select>
          </div>

          <div className="bg-slate-900 p-2 rounded border border-slate-800">
            <label className="text-[10px] text-slate-500 block mb-1">GP Commitment</label>
            <select
              value={config.gpCommitmentPercent}
              onChange={(e) => handleUpdateConfig('gpCommitmentPercent', parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200"
            >
              <option value="0.01">1.0% GP Skin</option>
              <option value="0.02">2.0% GP Skin</option>
              <option value="0.05">5.0% GP Skin</option>
            </select>
          </div>
        </div>
      </div>

      {/* Gross vs Net KPI Comparison */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5 font-mono">
        <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
          <span className="text-[10px] text-slate-500 block">Gross Asset IRR</span>
          <span className="text-base font-bold text-slate-200">{formatPercent(waterfall.grossIrr)}</span>
          <span className="text-[10px] text-slate-500 block">Pre-Fees & Carry</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
          <span className="text-[10px] text-slate-500 block">Net LP IRR</span>
          <span className="text-base font-bold text-emerald-400">{formatPercent(waterfall.netLpIrr)}</span>
          <span className="text-[10px] text-slate-500 block">
            Spread: {((waterfall.grossIrr! - waterfall.netLpIrr!) * 10000).toFixed(0)} bps drag
          </span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
          <span className="text-[10px] text-slate-500 block">Gross MOIC</span>
          <span className="text-base font-bold text-slate-200">{formatMultiple(waterfall.grossMoic)}</span>
          <span className="text-[10px] text-slate-500 block">Underlying Assets</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
          <span className="text-[10px] text-slate-500 block">Net LP MOIC</span>
          <span className="text-base font-bold text-sky-400">{formatMultiple(waterfall.netLpMoic)}</span>
          <span className="text-[10px] text-slate-500 block">Net Multiple to LPs</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
          <span className="text-[10px] text-slate-500 block">Management Fees</span>
          <span className="text-base font-bold text-amber-300">
            {formatCurrency(waterfall.totalManagementFees, currency, true)}
          </span>
          <span className="text-[10px] text-slate-500 block">Accrued to GP</span>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
          <span className="text-[10px] text-slate-500 block">Total Carried Interest</span>
          <span className="text-base font-bold text-sky-300">
            {formatCurrency(waterfall.totalCarriedInterest, currency, true)}
          </span>
          <span className="text-[10px] text-slate-500 block">Catch-up + 20% Carry</span>
        </div>
      </div>

      {/* Waterfall Steps Ledger */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-lg overflow-x-auto">
        <div className="p-3 border-b border-slate-800 flex justify-between items-center">
          <h4 className="text-xs font-semibold text-slate-200 font-mono uppercase tracking-wider">
            Period-by-Period Priority Waterfall Breakdown
          </h4>
          <span className="text-[10px] text-slate-500 font-mono">Tier 1: Cap Return → Tier 2: Pref → Tier 3: Catch-up → Tier 4: Split</span>
        </div>

        <table className="w-full text-left text-xs border-collapse font-mono">
          <thead className="bg-[#111827] text-[11px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
            <tr>
              <th className="py-2 px-3">Date</th>
              <th className="py-2 px-3 text-right">Gross Dist.</th>
              <th className="py-2 px-3 text-right text-slate-300">T1: Return of Cap</th>
              <th className="py-2 px-3 text-right text-sky-300">T2: Pref (8%)</th>
              <th className="py-2 px-3 text-right text-amber-400">T3: GP Catch-Up</th>
              <th className="py-2 px-3 text-right text-amber-300">T4: Carry Split</th>
              <th className="py-2 px-3 text-right font-bold text-emerald-400 bg-emerald-950/20">
                Net to LP
              </th>
              <th className="py-2 px-3 text-right font-bold text-amber-400 bg-amber-950/20">
                Net to GP
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-300">
            {waterfall.steps.map((step, idx) => (
              <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                <td className="py-2 px-3 text-slate-400">{step.periodDate}</td>
                <td className="py-2 px-3 text-right font-semibold">
                  {formatCurrency(step.grossDistribution, currency)}
                </td>
                <td className="py-2 px-3 text-right text-slate-400">
                  {formatCurrency(step.returnOfCapitalToLp, currency)}
                </td>
                <td className="py-2 px-3 text-right text-sky-300">
                  {formatCurrency(step.preferredReturnToLp, currency)}
                </td>
                <td className="py-2 px-3 text-right text-amber-400">
                  {formatCurrency(step.gpCatchUp, currency)}
                </td>
                <td className="py-2 px-3 text-right text-amber-300">
                  {formatCurrency(step.carriedInterestToGp, currency)}
                </td>
                <td className="py-2 px-3 text-right font-bold text-emerald-300 bg-emerald-950/20">
                  {formatCurrency(step.netDistributionToLp, currency)}
                </td>
                <td className="py-2 px-3 text-right font-bold text-amber-300 bg-amber-950/20">
                  {formatCurrency(step.netDistributionToGp, currency)}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-[#111827] border-t border-slate-800 text-[11px] font-bold text-slate-200">
            <tr>
              <td className="py-2 px-3 uppercase">Total Proceeds</td>
              <td className="py-2 px-3 text-right">{formatCurrency(waterfall.totalDistributed, currency)}</td>
              <td className="py-2 px-3 text-right text-slate-400">
                {formatCurrency(waterfall.steps.reduce((s, x) => s + x.returnOfCapitalToLp, 0), currency)}
              </td>
              <td className="py-2 px-3 text-right text-sky-300">
                {formatCurrency(waterfall.steps.reduce((s, x) => s + x.preferredReturnToLp, 0), currency)}
              </td>
              <td className="py-2 px-3 text-right text-amber-400">
                {formatCurrency(waterfall.steps.reduce((s, x) => s + x.gpCatchUp, 0), currency)}
              </td>
              <td className="py-2 px-3 text-right text-amber-300">
                {formatCurrency(waterfall.steps.reduce((s, x) => s + x.carriedInterestToGp, 0), currency)}
              </td>
              <td className="py-2 px-3 text-right text-emerald-400 bg-emerald-950/40">
                {formatCurrency(waterfall.totalLpProceeds, currency)}
              </td>
              <td className="py-2 px-3 text-right text-amber-400 bg-amber-950/40">
                {formatCurrency(waterfall.totalGpProceeds, currency)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};
