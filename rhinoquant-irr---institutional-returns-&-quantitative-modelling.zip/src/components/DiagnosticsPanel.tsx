/**
 * RhinoQuant Analytical Inspector & Assumptions Panel
 * Institutional mathematical audit diagnostics, equation inspect, and parameter controls.
 */

import React from 'react';
import { CalculationResult, EngineAssumptions, DayCountConvention } from '../engine/types';
import { formatCurrency, formatPercent } from '../utils/formatters';
import { CheckCircle2, AlertTriangle, XCircle, Info, Calculator, Sliders } from 'lucide-react';

interface DiagnosticsPanelProps {
  result: CalculationResult;
  assumptions: EngineAssumptions;
  currency: string;
  onUpdateAssumptions: (newAssumptions: EngineAssumptions) => void;
}

export const DiagnosticsPanel: React.FC<DiagnosticsPanelProps> = ({
  result,
  assumptions,
  currency,
  onUpdateAssumptions,
}) => {
  const [activeTab, setActiveTab] = React.useState<'diagnostics' | 'assumptions'>('diagnostics');

  const diag = result.diagnostics;
  const isHealthy = result.convergenceStatus === 'CONVERGED';
  const hasMultipleRoots = result.convergenceStatus === 'MULTIPLE_ROOTS';
  const isInvalid = result.convergenceStatus === 'INVALID_DATA' || result.convergenceStatus === 'NO_SOLUTION';

  const handleFieldChange = (field: keyof EngineAssumptions, value: any) => {
    onUpdateAssumptions({ ...assumptions, [field]: value });
  };

  return (
    <div className="bg-[#0f172a] border border-slate-800 rounded-lg flex flex-col h-full overflow-hidden">
      {/* Tab Header */}
      <div className="flex border-b border-slate-800 bg-[#111827]">
        <button
          onClick={() => setActiveTab('diagnostics')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'diagnostics'
              ? 'border-sky-500 text-sky-400 bg-slate-900/50'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calculator className="w-3.5 h-3.5" />
          <span>Solver Inspector</span>
        </button>
        <button
          onClick={() => setActiveTab('assumptions')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'assumptions'
              ? 'border-sky-500 text-sky-400 bg-slate-900/50'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Active Assumptions</span>
        </button>
      </div>

      <div className="p-3 overflow-y-auto flex-1 space-y-3.5 text-xs">
        {activeTab === 'diagnostics' ? (
          <>
            {/* Status Header */}
            <div
              className={`p-2.5 rounded border flex items-start gap-2 ${
                isHealthy
                  ? 'bg-emerald-950/30 border-emerald-800/80 text-emerald-300'
                  : hasMultipleRoots
                  ? 'bg-amber-950/30 border-amber-800/80 text-amber-300'
                  : 'bg-rose-950/30 border-rose-800/80 text-rose-300'
              }`}
            >
              {isHealthy ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : hasMultipleRoots ? (
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              ) : (
                <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <div className="font-semibold text-xs tracking-wide">
                  {result.convergenceStatus}
                </div>
                <div className="text-[11px] opacity-90 leading-tight mt-0.5">
                  {result.selectedRootMethod}
                </div>
              </div>
            </div>

            {/* Warnings list */}
            {result.warnings.length > 0 && (
              <div className="space-y-1 bg-amber-950/20 border border-amber-900/60 rounded p-2 text-[11px] text-amber-300">
                <div className="font-semibold flex items-center gap-1 text-amber-400">
                  <Info className="w-3 h-3" /> Numerical & Economic Notes
                </div>
                {result.warnings.map((w, idx) => (
                  <div key={idx} className="leading-snug">
                    · {w}
                  </div>
                ))}
              </div>
            )}

            {/* Mathematical Model Equation */}
            <div className="space-y-1 bg-slate-900 border border-slate-800 rounded p-2">
              <div className="text-[10px] uppercase font-mono text-slate-400">Governing Equation</div>
              <div className="font-mono text-sky-300 text-[11px] leading-relaxed break-all">
                NPV(r) = Σ [ CF_i / (1 + r)^τ_i ] = 0
              </div>
              <div className="text-[10px] text-slate-400">
                τ_i = Elapsed time in fractional years using {diag.dayCount}
              </div>
            </div>

            {/* Solver Diagnostics Grid */}
            <div className="space-y-1.5">
              <div className="text-[10px] uppercase font-mono text-slate-400">Convergence Diagnostics</div>
              <div className="grid grid-cols-2 gap-1.5 font-mono text-[11px]">
                <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Method</span>
                  <span className="text-slate-200 truncate block" title={result.solverMethod}>
                    Brent / Newton
                  </span>
                </div>
                <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Iterations</span>
                  <span className="text-slate-200">{result.iterationCount}</span>
                </div>
                <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Residual |NPV|</span>
                  <span className="text-emerald-400 truncate block">
                    {result.residualNpv < 0.0001
                      ? result.residualNpv.toExponential(3)
                      : formatCurrency(result.residualNpv, currency)}
                  </span>
                </div>
                <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Sign Changes</span>
                  <span className="text-slate-200">{diag.signChanges}</span>
                </div>
              </div>
            </div>

            {/* Cash Flow Schedule Metrics */}
            <div className="space-y-1.5">
              <div className="text-[10px] uppercase font-mono text-slate-400">Dataset Structure</div>
              <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800 space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Valuation Date:</span>
                  <span className="text-slate-300">{diag.firstDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Terminal Date:</span>
                  <span className="text-slate-300">{diag.lastDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Duration Span:</span>
                  <span className="text-slate-300">{diag.spanYears.toFixed(2)} years</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Inflows / Outflows:</span>
                  <span className="text-slate-300">
                    {diag.positiveFlowsCount} pos / {diag.negativeFlowsCount} neg
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Undiscounted Total:</span>
                  <span className="text-slate-200 font-semibold">
                    {formatCurrency(diag.cumulativeCashFlow, currency)}
                  </span>
                </div>
              </div>
            </div>

            {/* Detected Multiple Roots */}
            {result.detectedRoots.length > 0 && (
              <div className="space-y-1">
                <div className="text-[10px] uppercase font-mono text-slate-400">
                  Detected Root Crossings ({result.detectedRoots.length})
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800 font-mono text-xs flex flex-wrap gap-1.5">
                  {result.detectedRoots.map((r, i) => (
                    <span
                      key={i}
                      className="bg-slate-800 text-sky-300 px-1.5 py-0.5 rounded text-[11px]"
                    >
                      r_{i + 1} = {(r * 100).toFixed(2)}%
                    </span>
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          /* Assumptions Controls Tab */
          <div className="space-y-3 font-mono">
            {/* Valuation Date */}
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Valuation Anchor Date</label>
              <input
                type="date"
                value={assumptions.valuationDate}
                onChange={(e) => handleFieldChange('valuationDate', e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded px-2 py-1 text-slate-200 text-xs focus:outline-none"
              />
            </div>

            {/* Discount Rate (for NPV) */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Discount Rate (NPV)</span>
                <span className="text-sky-400">{(assumptions.discountRate * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.01"
                max="0.30"
                step="0.005"
                value={assumptions.discountRate}
                onChange={(e) => handleFieldChange('discountRate', parseFloat(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer"
              />
            </div>

            {/* Day Count Convention */}
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Day-Count Convention</label>
              <select
                value={assumptions.dayCount}
                onChange={(e) => handleFieldChange('dayCount', e.target.value as DayCountConvention)}
                className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded px-2 py-1 text-slate-200 text-xs focus:outline-none"
              >
                <option value="ACT_365">Actual/365 Fixed (Standard XIRR)</option>
                <option value="ACT_360">Actual/360 (Money Market)</option>
                <option value="30_360">30/360 US (Real Estate & Bonds)</option>
                <option value="ACT_ACT">Actual/Actual (ISDA)</option>
              </select>
            </div>

            {/* MIRR Finance Rate */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">MIRR Financing Rate (Outflows)</span>
                <span className="text-slate-200">{(assumptions.financeRate * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.01"
                max="0.20"
                step="0.005"
                value={assumptions.financeRate}
                onChange={(e) => handleFieldChange('financeRate', parseFloat(e.target.value))}
                className="w-full accent-slate-400 cursor-pointer"
              />
            </div>

            {/* MIRR Reinvestment Rate */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">MIRR Reinvestment Rate (Inflows)</span>
                <span className="text-slate-200">{(assumptions.reinvestmentRate * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.01"
                max="0.25"
                step="0.005"
                value={assumptions.reinvestmentRate}
                onChange={(e) => handleFieldChange('reinvestmentRate', parseFloat(e.target.value))}
                className="w-full accent-slate-400 cursor-pointer"
              />
            </div>

            {/* Target Hurdle Rate */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Target Return / Hurdle Rate</span>
                <span className="text-emerald-400">{(assumptions.targetIrr * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.35"
                step="0.005"
                value={assumptions.targetIrr}
                onChange={(e) => handleFieldChange('targetIrr', parseFloat(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="p-2 bg-slate-900/60 rounded border border-slate-800 text-[10px] text-slate-500 font-sans leading-relaxed">
              Assumptions immediately recalculate NPV, MIRR, hurdle comparisons, and scenario valuations.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
