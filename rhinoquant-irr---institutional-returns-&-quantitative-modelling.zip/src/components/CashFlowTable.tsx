/**
 * RhinoQuant Spreadsheet-Grade Cash Flow Editor
 * Real-time validated financial ledger with granular capital structure & operating columns.
 */

import React, { useState } from 'react';
import { CashFlowItem, CashFlowCategory, CashFlowDriver } from '../engine/types';
import { getDriverCashFlow } from '../engine/financialMath';
import { formatCurrency } from '../utils/formatters';
import { Plus, Trash2, Copy, ArrowUpDown, Upload, Download, Check, AlertCircle } from 'lucide-react';

interface CashFlowTableProps {
  items: CashFlowItem[];
  driver: CashFlowDriver;
  currency: string;
  onUpdateItems: (newItems: CashFlowItem[]) => void;
  onUpdateDriver: (driver: CashFlowDriver) => void;
}

const CATEGORIES: { value: CashFlowCategory; label: string }[] = [
  { value: 'acquisition', label: 'Acquisition / Entry' },
  { value: 'capex', label: 'Capital Expenditure' },
  { value: 'operating', label: 'Operating CF' },
  { value: 'debt_drawdown', label: 'Debt Financing' },
  { value: 'debt_service', label: 'Debt Service' },
  { value: 'equity_contribution', label: 'Equity Contribution' },
  { value: 'distribution', label: 'Distribution' },
  { value: 'exit', label: 'Exit / Liquidation' },
  { value: 'custom', label: 'Custom' },
];

export const CashFlowTable: React.FC<CashFlowTableProps> = ({
  items,
  driver,
  currency,
  onUpdateItems,
  onUpdateDriver,
}) => {
  const [csvModalOpen, setCsvModalOpen] = useState(false);
  const [csvText, setCsvText] = useState('');
  const [csvError, setCsvError] = useState<string | null>(null);

  const handleCellChange = (id: string, field: keyof CashFlowItem, value: any) => {
    const updated = items.map((item) => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    });
    onUpdateItems(updated);
  };

  const handleAddRow = () => {
    const lastItem = items[items.length - 1];
    let nextDate = '2025-01-01';
    if (lastItem) {
      const dt = new Date(lastItem.date);
      dt.setUTCFullYear(dt.getUTCFullYear() + 1);
      nextDate = dt.toISOString().split('T')[0];
    }

    const newItem: CashFlowItem = {
      id: `cf-${Date.now()}`,
      date: nextDate,
      description: `Period ${items.length + 1} Cash Flow`,
      category: 'operating',
      operatingCashFlow: 5000000,
      capitalExpenditure: 0,
      acquisitionCost: 0,
      debtDrawdown: 0,
      debtRepayment: 0,
      interestPaid: 0,
      equityContribution: 0,
      distribution: 0,
      exitProceeds: 0,
    };

    onUpdateItems([...items, newItem]);
  };

  const handleDuplicateRow = (id: string) => {
    const target = items.find((it) => it.id === id);
    if (!target) return;
    const duplicated: CashFlowItem = {
      ...JSON.parse(JSON.stringify(target)),
      id: `cf-${Date.now()}`,
      description: `${target.description} (Copy)`,
    };
    const idx = items.findIndex((it) => it.id === id);
    const updated = [...items];
    updated.splice(idx + 1, 0, duplicated);
    onUpdateItems(updated);
  };

  const handleDeleteRow = (id: string) => {
    if (items.length <= 2) {
      alert('At least two cash flow periods are required to calculate return metrics.');
      return;
    }
    const updated = items.filter((it) => it.id !== id);
    onUpdateItems(updated);
  };

  const handleSortByDate = () => {
    const sorted = [...items].sort((a, b) => (a.date > b.date ? 1 : -1));
    onUpdateItems(sorted);
  };

  const handleExportCsv = () => {
    const headers = [
      'Date',
      'Description',
      'Category',
      'OperatingCF',
      'CapEx',
      'AcquisitionCost',
      'DebtDrawdown',
      'DebtRepayment',
      'InterestPaid',
      'EquityContribution',
      'Distribution',
      'ExitProceeds',
      'DriverEffectiveFlow',
    ];

    const rows = items.map((it) => [
      it.date,
      `"${it.description.replace(/"/g, '""')}"`,
      it.category,
      it.operatingCashFlow,
      it.capitalExpenditure,
      it.acquisitionCost,
      it.debtDrawdown,
      it.debtRepayment,
      it.interestPaid,
      it.equityContribution,
      it.distribution,
      it.exitProceeds,
      getDriverCashFlow(it, driver),
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `rhinoquant_cashflows_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleProcessCsvImport = () => {
    try {
      setCsvError(null);
      const lines = csvText.trim().split('\n');
      if (lines.length < 2) {
        setCsvError('CSV data must contain at least a header and one data row.');
        return;
      }

      const parsed: CashFlowItem[] = [];
      // Skip header row
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const cols = line.split(',').map((c) => c.replace(/^"|"$/g, '').trim());

        const date = cols[0];
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
          setCsvError(`Row ${i + 1}: Invalid date '${date}'. Expected YYYY-MM-DD.`);
          return;
        }

        parsed.push({
          id: `cf-imp-${i}-${Date.now()}`,
          date,
          description: cols[1] || `Transaction ${i}`,
          category: (cols[2] as CashFlowCategory) || 'operating',
          operatingCashFlow: parseFloat(cols[3]) || 0,
          capitalExpenditure: parseFloat(cols[4]) || 0,
          acquisitionCost: parseFloat(cols[5]) || 0,
          debtDrawdown: parseFloat(cols[6]) || 0,
          debtRepayment: parseFloat(cols[7]) || 0,
          interestPaid: parseFloat(cols[8]) || 0,
          equityContribution: parseFloat(cols[9]) || 0,
          distribution: parseFloat(cols[10]) || 0,
          exitProceeds: parseFloat(cols[11]) || 0,
        });
      }

      if (parsed.length < 2) {
        setCsvError('At least 2 cash flow rows are required.');
        return;
      }

      onUpdateItems(parsed);
      setCsvModalOpen(false);
      setCsvText('');
    } catch (err: any) {
      setCsvError(`CSV Parsing Error: ${err.message || 'Unknown error'}`);
    }
  };

  return (
    <div className="bg-[#0f172a] border border-slate-800 rounded-lg flex flex-col h-full">
      {/* Top Toolbar */}
      <div className="px-3 py-2.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-200">Cash Flow Schedule</span>
          <span className="text-slate-600 text-xs">/</span>
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-xs">
            <span className="text-slate-400 text-[11px]">Active Driver:</span>
            <select
              value={driver}
              onChange={(e) => onUpdateDriver(e.target.value as CashFlowDriver)}
              className="bg-transparent text-sky-400 font-medium focus:outline-none cursor-pointer text-xs"
            >
              <option value="equity" className="bg-slate-900 text-slate-200">
                Levered Equity Cash Flows (IRR & MOIC)
              </option>
              <option value="project" className="bg-slate-900 text-slate-200">
                Unlevered Project Cash Flows (Operating & CapEx)
              </option>
              <option value="fund" className="bg-slate-900 text-slate-200">
                Fund Investor Flows (Capital Calls & Distributions)
              </option>
              <option value="net" className="bg-slate-900 text-slate-200">
                Consolidated Net Cash Flow
              </option>
            </select>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleAddRow}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            Add Row
          </button>
          <button
            onClick={handleSortByDate}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 rounded transition-colors whitespace-nowrap"
            title="Sort chronologically by date"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            Sort
          </button>
          <button
            onClick={() => setCsvModalOpen(true)}
            className="flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 rounded transition-colors whitespace-nowrap"
            title="Import raw CSV data"
          >
            <Upload className="w-3 h-3" />
            Import
          </button>
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 rounded transition-colors whitespace-nowrap"
            title="Download CSV"
          >
            <Download className="w-3 h-3" />
            CSV
          </button>
        </div>
      </div>

      {/* Spreadsheet Table Container */}
      <div className="overflow-x-auto flex-1 max-h-[460px]">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-[#111827] sticky top-0 z-10 border-b border-slate-800 text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            <tr>
              <th className="py-2 px-2.5 w-28 whitespace-nowrap">Date</th>
              <th className="py-2 px-2.5 min-w-[140px] whitespace-nowrap">Description</th>
              <th className="py-2 px-2.5 w-32 whitespace-nowrap">Category</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-sky-400">Operating CF</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-rose-400">CapEx</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-rose-400">Acquisition</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-slate-300">Debt Draw</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-slate-400">Debt Repay</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-amber-400">Interest</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-rose-400">Equity Call</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-emerald-400">Distribution</th>
              <th className="py-2 px-2 text-right whitespace-nowrap text-emerald-300">Exit Value</th>
              <th className="py-2 px-2.5 text-right whitespace-nowrap font-bold text-white bg-slate-900/80">
                Driver Flow
              </th>
              <th className="py-2 px-2 text-center w-14">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
            {items.map((item, idx) => {
              const driverFlow = getDriverCashFlow(item, driver);
              const isNegative = driverFlow < 0;

              return (
                <tr key={item.id} className="hover:bg-slate-800/40 transition-colors group">
                  {/* Date Input */}
                  <td className="py-1.5 px-2">
                    <input
                      type="date"
                      value={item.date}
                      onChange={(e) => handleCellChange(item.id, 'date', e.target.value)}
                      className="w-full bg-slate-900/60 border border-transparent focus:border-sky-500 rounded px-1.5 py-0.5 text-slate-200 text-xs focus:outline-none"
                    />
                  </td>

                  {/* Description Input */}
                  <td className="py-1.5 px-2">
                    <input
                      type="text"
                      value={item.description}
                      onChange={(e) => handleCellChange(item.id, 'description', e.target.value)}
                      className="w-full bg-slate-900/60 border border-transparent focus:border-sky-500 rounded px-1.5 py-0.5 text-slate-200 text-xs focus:outline-none font-sans"
                    />
                  </td>

                  {/* Category Dropdown */}
                  <td className="py-1.5 px-2">
                    <select
                      value={item.category}
                      onChange={(e) => handleCellChange(item.id, 'category', e.target.value)}
                      className="w-full bg-slate-900/60 border border-transparent focus:border-sky-500 rounded px-1 py-0.5 text-slate-400 text-[11px] focus:outline-none"
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c.value} value={c.value} className="bg-slate-900 text-slate-200">
                          {c.label}
                        </option>
                      ))}
                    </select>
                  </td>

                  {/* Operating CF */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="1000"
                      value={item.operatingCashFlow}
                      onChange={(e) =>
                        handleCellChange(item.id, 'operatingCashFlow', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-sky-500 focus:bg-slate-900 rounded px-1 py-0.5 text-slate-200 focus:outline-none"
                    />
                  </td>

                  {/* CapEx */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="1000"
                      value={item.capitalExpenditure}
                      onChange={(e) =>
                        handleCellChange(item.id, 'capitalExpenditure', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-rose-500 focus:bg-slate-900 rounded px-1 py-0.5 text-rose-300 focus:outline-none"
                    />
                  </td>

                  {/* Acquisition Cost */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="10000"
                      value={item.acquisitionCost}
                      onChange={(e) =>
                        handleCellChange(item.id, 'acquisitionCost', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-rose-500 focus:bg-slate-900 rounded px-1 py-0.5 text-rose-300 focus:outline-none"
                    />
                  </td>

                  {/* Debt Drawdown */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="10000"
                      value={item.debtDrawdown}
                      onChange={(e) =>
                        handleCellChange(item.id, 'debtDrawdown', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-slate-500 focus:bg-slate-900 rounded px-1 py-0.5 text-slate-300 focus:outline-none"
                    />
                  </td>

                  {/* Debt Repayment */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="10000"
                      value={item.debtRepayment}
                      onChange={(e) =>
                        handleCellChange(item.id, 'debtRepayment', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-slate-500 focus:bg-slate-900 rounded px-1 py-0.5 text-slate-300 focus:outline-none"
                    />
                  </td>

                  {/* Interest Paid */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="1000"
                      value={item.interestPaid}
                      onChange={(e) =>
                        handleCellChange(item.id, 'interestPaid', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-amber-500 focus:bg-slate-900 rounded px-1 py-0.5 text-amber-300 focus:outline-none"
                    />
                  </td>

                  {/* Equity Contribution */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="10000"
                      value={item.equityContribution}
                      onChange={(e) =>
                        handleCellChange(item.id, 'equityContribution', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-rose-500 focus:bg-slate-900 rounded px-1 py-0.5 text-rose-300 focus:outline-none"
                    />
                  </td>

                  {/* Distribution */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="10000"
                      value={item.distribution}
                      onChange={(e) =>
                        handleCellChange(item.id, 'distribution', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-emerald-500 focus:bg-slate-900 rounded px-1 py-0.5 text-emerald-400 focus:outline-none"
                    />
                  </td>

                  {/* Exit Proceeds */}
                  <td className="py-1.5 px-1.5 text-right">
                    <input
                      type="number"
                      step="50000"
                      value={item.exitProceeds}
                      onChange={(e) =>
                        handleCellChange(item.id, 'exitProceeds', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 text-right bg-transparent border border-transparent focus:border-emerald-500 focus:bg-slate-900 rounded px-1 py-0.5 text-emerald-300 focus:outline-none"
                    />
                  </td>

                  {/* Calculated Driver Flow */}
                  <td
                    className={`py-1.5 px-2.5 text-right font-bold tabular-nums bg-slate-900/60 ${
                      isNegative ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {formatCurrency(driverFlow, currency)}
                  </td>

                  {/* Actions */}
                  <td className="py-1.5 px-2 text-center">
                    <div className="flex items-center justify-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleDuplicateRow(item.id)}
                        className="p-1 hover:text-sky-400 rounded transition-colors"
                        title="Duplicate row"
                      >
                        <Copy className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleDeleteRow(item.id)}
                        className="p-1 hover:text-rose-400 rounded transition-colors"
                        title="Delete row"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Footer Notes on Sign Convention */}
      <div className="px-3 py-1.5 bg-[#111827] border-t border-slate-800 text-[11px] font-mono text-slate-500 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-4">
          <span>Outflows/Calls: Entered as positive amounts, subtracted by formula</span>
          <span>·</span>
          <span>Inflows/Distributions: Added to net returns</span>
          <span>·</span>
          <span>Total Transactions: {items.length}</span>
        </div>
      </div>

      {/* CSV Import Modal */}
      {csvModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="bg-[#0f172a] border border-slate-700 rounded-lg max-w-2xl w-full p-4 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-sm font-semibold text-slate-100">Bulk Cash Flow CSV Import</h3>
              <button
                onClick={() => setCsvModalOpen(false)}
                className="text-slate-400 hover:text-slate-200 text-sm"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Paste comma-separated data. Expected format:
              <br />
              <code className="text-sky-400 bg-slate-900 px-1 py-0.5 rounded text-[11px]">
                Date,Description,Category,OperatingCF,CapEx,AcquisitionCost,DebtDraw,DebtRepay,Interest,EquityCall,Distribution,ExitProceeds
              </code>
            </p>

            {csvError && (
              <div className="p-2 bg-rose-950/60 border border-rose-800 rounded text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{csvError}</span>
              </div>
            )}

            <textarea
              rows={8}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder={`Date,Description,Category,OperatingCF,CapEx,AcquisitionCost,DebtDraw,DebtRepay,Interest,EquityCall,Distribution,ExitProceeds\n2025-01-01,Acquisition,acquisition,0,0,50000000,0,0,0,50000000,0,0\n2026-01-01,Year 1 Distribution,operating,0,0,0,0,0,0,0,12000000,0\n2027-01-01,Year 2 Exit,exit,0,0,0,0,0,0,0,0,65000000`}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-500"
            />

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setCsvModalOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleProcessCsvImport}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded transition-colors"
              >
                Parse & Import Schedule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
