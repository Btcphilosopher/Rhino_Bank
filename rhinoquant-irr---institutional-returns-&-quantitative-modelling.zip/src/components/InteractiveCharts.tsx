/**
 * RhinoQuant High-Performance Financial Charts
 * Pure SVG responsive interactive charts for Cumulative Cash Flows, DCF, NPV Curve, and Waterfalls.
 */

import React, { useState } from 'react';
import { CalculationResult } from '../engine/types';
import { calculateXnpv, DatedCashFlow } from '../engine/financialMath';
import { formatCurrency, formatPercent, formatMultiple } from '../utils/formatters';

interface InteractiveChartsProps {
  result: CalculationResult;
  currency: string;
}

export const InteractiveCharts: React.FC<InteractiveChartsProps> = ({ result, currency }) => {
  const [activeTab, setActiveTab] = useState<'cumulative' | 'dcf' | 'npv_curve' | 'capital_flows'>('cumulative');
  const [hoveredPoint, setHoveredPoint] = useState<{ x: number; y: number; title: string; value: string; extra?: string } | null>(null);

  const flows = result.effectiveCashFlows;

  // Render Cumulative Cash Flow Chart
  const renderCumulativeChart = () => {
    if (flows.length === 0) {
      return (
        <div className="h-64 flex items-center justify-center text-xs text-slate-500">
          No cash flow data available to render chart.
        </div>
      );
    }

    let cum = 0;
    const cumPoints: { date: string; amount: number; cum: number; years: number }[] = [];
    flows.forEach((f) => {
      cum += f.amount;
      cumPoints.push({ date: f.date, amount: f.amount, cum, years: f.years });
    });

    const width = 640;
    const height = 260;
    const padding = { top: 25, right: 30, bottom: 40, left: 70 };

    const minVal = Math.min(0, ...cumPoints.map((p) => Math.min(p.cum, p.amount)));
    const maxVal = Math.max(1e5, ...cumPoints.map((p) => Math.max(p.cum, p.amount)));
    const range = maxVal - minVal || 1;

    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const getX = (idx: number) => padding.left + (idx / Math.max(1, cumPoints.length - 1)) * chartW;
    const getY = (val: number) => padding.top + chartH - ((val - minVal) / range) * chartH;
    const zeroY = getY(0);

    const pathData = cumPoints
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(p.cum)}`)
      .join(' ');

    return (
      <div className="relative">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-64 select-none">
          {/* Zero baseline */}
          <line
            x1={padding.left}
            y1={zeroY}
            x2={width - padding.right}
            y2={zeroY}
            stroke="#475569"
            strokeDasharray="4 4"
            strokeWidth="1.2"
          />
          <text x={padding.left - 8} y={zeroY + 4} textAnchor="end" fill="#64748b" className="text-[10px] font-mono">
            $0
          </text>

          {/* Grid lines */}
          {[0.25, 0.5, 0.75, 1.0].map((frac, i) => {
            const v = minVal + frac * range;
            const y = getY(v);
            return (
              <g key={i}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#1e293b"
                  strokeWidth="1"
                />
                <text x={padding.left - 8} y={y + 4} textAnchor="end" fill="#475569" className="text-[10px] font-mono">
                  {formatCurrency(v, currency, true)}
                </text>
              </g>
            );
          })}

          {/* Net Flow Bars */}
          {cumPoints.map((p, i) => {
            const x = getX(i);
            const barW = Math.min(24, Math.max(8, chartW / (cumPoints.length * 2)));
            const barY = p.amount >= 0 ? getY(p.amount) : zeroY;
            const barH = Math.max(2, Math.abs(getY(p.amount) - zeroY));
            const isPos = p.amount >= 0;

            return (
              <rect
                key={i}
                x={x - barW / 2}
                y={barY}
                width={barW}
                height={barH}
                fill={isPos ? '#10b981' : '#f43f5e'}
                opacity={0.35}
                className="transition-all hover:opacity-80 cursor-pointer"
                onMouseEnter={() =>
                  setHoveredPoint({
                    x,
                    y: barY,
                    title: `Period: ${p.date}`,
                    value: `Net Flow: ${formatCurrency(p.amount, currency)}`,
                    extra: `Cumulative: ${formatCurrency(p.cum, currency)}`,
                  })
                }
                onMouseLeave={() => setHoveredPoint(null)}
              />
            );
          })}

          {/* Cumulative Cash Flow Line */}
          <path d={pathData} fill="none" stroke="#38bdf8" strokeWidth="2.5" />

          {/* Line points */}
          {cumPoints.map((p, i) => {
            const cx = getX(i);
            const cy = getY(p.cum);
            return (
              <circle
                key={i}
                cx={cx}
                cy={cy}
                r="4"
                fill="#0f172a"
                stroke="#38bdf8"
                strokeWidth="2"
                className="cursor-pointer hover:r-6 transition-all"
                onMouseEnter={() =>
                  setHoveredPoint({
                    x: cx,
                    y: cy,
                    title: `Date: ${p.date}`,
                    value: `Cumulative: ${formatCurrency(p.cum, currency)}`,
                    extra: `Period Net: ${formatCurrency(p.amount, currency)}`,
                  })
                }
                onMouseLeave={() => setHoveredPoint(null)}
              />
            );
          })}

          {/* X-axis labels */}
          {cumPoints.map((p, i) => {
            // Show every 1-2 periods
            if (cumPoints.length > 8 && i % 2 !== 0 && i !== cumPoints.length - 1) return null;
            const x = getX(i);
            return (
              <text
                key={i}
                x={x}
                y={height - 15}
                textAnchor="middle"
                fill="#94a3b8"
                className="text-[10px] font-mono"
              >
                {p.date.slice(2)}
              </text>
            );
          })}
        </svg>

        {hoveredPoint && (
          <div
            className="absolute z-20 pointer-events-none bg-slate-900 border border-slate-700 px-2.5 py-1.5 rounded shadow-lg text-xs font-mono"
            style={{
              left: Math.min(hoveredPoint.x + 10, width - 180),
              top: Math.max(10, hoveredPoint.y - 45),
            }}
          >
            <div className="text-slate-400 text-[10px]">{hoveredPoint.title}</div>
            <div className="text-white font-semibold">{hoveredPoint.value}</div>
            {hoveredPoint.extra && <div className="text-sky-400 text-[10px]">{hoveredPoint.extra}</div>}
          </div>
        )}
      </div>
    );
  };

  // Render NPV vs Discount Rate Curve
  const renderNpvCurve = () => {
    const width = 640;
    const height = 260;
    const padding = { top: 25, right: 30, bottom: 40, left: 70 };

    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    // Sample rates from 0% to 40% (or beyond if IRR is high)
    const maxRate = Math.min(1.0, Math.max(0.40, (result.xirr ?? 0.25) * 1.5));
    const stepCount = 50;
    const points: { rate: number; npv: number }[] = [];

    for (let i = 0; i <= stepCount; i++) {
      const r = (i / stepCount) * maxRate;
      const npv = calculateXnpv(r, flows);
      points.push({ rate: r, npv });
    }

    const minNpv = Math.min(...points.map((p) => p.npv));
    const maxNpv = Math.max(...points.map((p) => p.npv));
    const range = maxNpv - minNpv || 1;

    const getX = (r: number) => padding.left + (r / maxRate) * chartW;
    const getY = (npv: number) => padding.top + chartH - ((npv - minNpv) / range) * chartH;
    const zeroY = getY(0);

    const pathData = points
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(p.rate)} ${getY(p.npv)}`)
      .join(' ');

    const irrX = result.xirr !== null ? getX(result.xirr) : null;

    return (
      <div className="relative">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-64 select-none">
          {/* Zero NPV line */}
          <line
            x1={padding.left}
            y1={zeroY}
            x2={width - padding.right}
            y2={zeroY}
            stroke="#94a3b8"
            strokeDasharray="4 4"
            strokeWidth="1.2"
          />
          <text x={padding.left - 8} y={zeroY + 4} textAnchor="end" fill="#94a3b8" className="text-[10px] font-mono">
            NPV = $0
          </text>

          {/* Grid lines */}
          {[0.25, 0.5, 0.75, 1.0].map((frac, i) => {
            const v = minNpv + frac * range;
            const y = getY(v);
            return (
              <g key={i}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#1e293b"
                  strokeWidth="1"
                />
                <text x={padding.left - 8} y={y + 4} textAnchor="end" fill="#475569" className="text-[10px] font-mono">
                  {formatCurrency(v, currency, true)}
                </text>
              </g>
            );
          })}

          {/* NPV Line */}
          <path d={pathData} fill="none" stroke="#10b981" strokeWidth="2.5" />

          {/* Root marker at XIRR */}
          {irrX !== null && irrX >= padding.left && irrX <= width - padding.right && (
            <g>
              <line
                x1={irrX}
                y1={padding.top}
                x2={irrX}
                y2={zeroY}
                stroke="#f59e0b"
                strokeDasharray="2 2"
                strokeWidth="1.5"
              />
              <circle
                cx={irrX}
                cy={zeroY}
                r="6"
                fill="#f59e0b"
                stroke="#0f172a"
                strokeWidth="2"
                className="cursor-pointer"
                onMouseEnter={() =>
                  setHoveredPoint({
                    x: irrX,
                    y: zeroY,
                    title: 'XIRR Zero-Crossing Root',
                    value: `Discount Rate: ${formatPercent(result.xirr)}`,
                    extra: `Residual NPV: ${formatCurrency(result.residualNpv, currency)}`,
                  })
                }
                onMouseLeave={() => setHoveredPoint(null)}
              />
              <text x={irrX} y={padding.top - 6} textAnchor="middle" fill="#f59e0b" className="text-[10px] font-mono font-bold">
                IRR: {formatPercent(result.xirr)}
              </text>
            </g>
          )}

          {/* X-axis rate markers */}
          {[0, 0.1, 0.2, 0.3, 0.4].filter((r) => r <= maxRate).map((r, i) => {
            const x = getX(r);
            return (
              <text
                key={i}
                x={x}
                y={height - 15}
                textAnchor="middle"
                fill="#94a3b8"
                className="text-[10px] font-mono"
              >
                {(r * 100).toFixed(0)}%
              </text>
            );
          })}
        </svg>

        {hoveredPoint && (
          <div
            className="absolute z-20 pointer-events-none bg-slate-900 border border-slate-700 px-2.5 py-1.5 rounded shadow-lg text-xs font-mono"
            style={{
              left: Math.min(hoveredPoint.x + 10, width - 180),
              top: Math.max(10, hoveredPoint.y - 45),
            }}
          >
            <div className="text-slate-400 text-[10px]">{hoveredPoint.title}</div>
            <div className="text-white font-semibold">{hoveredPoint.value}</div>
            {hoveredPoint.extra && <div className="text-emerald-400 text-[10px]">{hoveredPoint.extra}</div>}
          </div>
        )}
      </div>
    );
  };

  // Render Discounted Cash Flows (DCF present value of each period)
  const renderDcfChart = () => {
    const width = 640;
    const height = 260;
    const padding = { top: 25, right: 30, bottom: 40, left: 70 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const dcfItems = flows.map((f) => {
      const pv = f.years === 0 ? f.amount : f.amount / Math.pow(1.10, f.years);
      return { ...f, pv };
    });

    const minVal = Math.min(0, ...dcfItems.map((p) => Math.min(p.amount, p.pv)));
    const maxVal = Math.max(1e5, ...dcfItems.map((p) => Math.max(p.amount, p.pv)));
    const range = maxVal - minVal || 1;

    const getX = (idx: number) => padding.left + (idx / Math.max(1, dcfItems.length - 1)) * chartW;
    const getY = (val: number) => padding.top + chartH - ((val - minVal) / range) * chartH;
    const zeroY = getY(0);

    return (
      <div className="relative">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-64 select-none">
          <line
            x1={padding.left}
            y1={zeroY}
            x2={width - padding.right}
            y2={zeroY}
            stroke="#475569"
            strokeDasharray="4 4"
            strokeWidth="1"
          />

          {dcfItems.map((p, i) => {
            const x = getX(i);
            const barW = Math.min(18, chartW / (dcfItems.length * 2.5));
            const isPos = p.pv >= 0;
            const barY = isPos ? getY(p.pv) : zeroY;
            const barH = Math.max(2, Math.abs(getY(p.pv) - zeroY));

            return (
              <g key={i}>
                {/* Nominal bar outline */}
                <rect
                  x={x - barW - 1}
                  y={p.amount >= 0 ? getY(p.amount) : zeroY}
                  width={barW}
                  height={Math.max(2, Math.abs(getY(p.amount) - zeroY))}
                  fill="#334155"
                  opacity={0.6}
                  rx="1"
                />
                {/* Discounted PV solid bar */}
                <rect
                  x={x + 1}
                  y={barY}
                  width={barW}
                  height={barH}
                  fill={isPos ? '#38bdf8' : '#f43f5e'}
                  rx="1"
                  className="cursor-pointer hover:opacity-80"
                  onMouseEnter={() =>
                    setHoveredPoint({
                      x,
                      y: barY,
                      title: `Date: ${p.date}`,
                      value: `Discounted PV: ${formatCurrency(p.pv, currency)}`,
                      extra: `Nominal Flow: ${formatCurrency(p.amount, currency)}`,
                    })
                  }
                  onMouseLeave={() => setHoveredPoint(null)}
                />
                <text
                  x={x}
                  y={height - 15}
                  textAnchor="middle"
                  fill="#94a3b8"
                  className="text-[10px] font-mono"
                >
                  {p.date.slice(2)}
                </text>
              </g>
            );
          })}
        </svg>

        {hoveredPoint && (
          <div
            className="absolute z-20 pointer-events-none bg-slate-900 border border-slate-700 px-2.5 py-1.5 rounded shadow-lg text-xs font-mono"
            style={{
              left: Math.min(hoveredPoint.x + 10, width - 180),
              top: Math.max(10, hoveredPoint.y - 45),
            }}
          >
            <div className="text-slate-400 text-[10px]">{hoveredPoint.title}</div>
            <div className="text-white font-semibold">{hoveredPoint.value}</div>
            {hoveredPoint.extra && <div className="text-sky-400 text-[10px]">{hoveredPoint.extra}</div>}
          </div>
        )}
      </div>
    );
  };

  // Render Capital Contributions vs Distributions
  const renderCapitalFlows = () => {
    const totalOut = result.totalContributions;
    const totalIn = result.totalDistributions;
    const netGain = result.netProfit;

    return (
      <div className="h-64 flex flex-col justify-center px-8">
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs font-mono mb-1">
              <span className="text-rose-400">Total Capital Contributions (Outflows)</span>
              <span className="text-rose-400 font-semibold">{formatCurrency(totalOut, currency)}</span>
            </div>
            <div className="h-5 bg-slate-800 rounded overflow-hidden">
              <div className="h-full bg-rose-500 rounded" style={{ width: '100%' }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs font-mono mb-1">
              <span className="text-emerald-400">Total Distributions & Proceeds (Inflows)</span>
              <span className="text-emerald-400 font-semibold">{formatCurrency(totalIn, currency)}</span>
            </div>
            <div className="h-5 bg-slate-800 rounded overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded transition-all"
                style={{
                  width: `${Math.min(100, (totalIn / Math.max(1, totalOut)) * 50)}%`,
                }}
              />
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-xs">
            <span className="text-slate-400">Net Profit Generated:</span>
            <span
              className={`font-mono text-sm font-bold ${
                netGain >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {formatCurrency(netGain, currency)} ({formatMultiple(result.moic)} MOIC)
            </span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-3">
      {/* Chart Selector Tabs */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTab('cumulative')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'cumulative'
                ? 'bg-slate-800 text-sky-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Cumulative Cash Flows
          </button>
          <button
            onClick={() => setActiveTab('npv_curve')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'npv_curve'
                ? 'bg-slate-800 text-emerald-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            NPV vs Discount Rate
          </button>
          <button
            onClick={() => setActiveTab('dcf')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'dcf'
                ? 'bg-slate-800 text-sky-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            DCF Profile
          </button>
          <button
            onClick={() => setActiveTab('capital_flows')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'capital_flows'
                ? 'bg-slate-800 text-slate-200 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Contributions vs Distributions
          </button>
        </div>

        <div className="text-[11px] font-mono text-slate-500">
          Convention: {result.diagnostics.dayCount} · Points: {result.effectiveCashFlows.length}
        </div>
      </div>

      {/* Chart Canvas */}
      {activeTab === 'cumulative' && renderCumulativeChart()}
      {activeTab === 'npv_curve' && renderNpvCurve()}
      {activeTab === 'dcf' && renderDcfChart()}
      {activeTab === 'capital_flows' && renderCapitalFlows()}
    </div>
  );
};
