/**
 * RhinoQuant Investment Committee Memorandum & Quantitative Audit Report
 * Formal institutional return memorandum with cash-flow schedules, sensitivities, and mathematical proofs.
 */

import React from 'react';
import { ProjectModel, CalculationResult } from '../engine/types';
import { formatCurrency, formatPercent, formatMultiple, formatYears } from '../utils/formatters';
import { Printer, Download, FileText, CheckCircle } from 'lucide-react';

interface InvestmentReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: ProjectModel;
  result: CalculationResult;
}

export const InvestmentReportModal: React.FC<InvestmentReportModalProps> = ({
  isOpen,
  onClose,
  project,
  result,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleExportJson = () => {
    const payload = {
      project,
      result: {
        ...result,
        effectiveCashFlows: result.effectiveCashFlows,
      },
      exportTimestamp: new Date().toISOString(),
      engineVersion: 'RhinoQuant IRR v3.8 Institutional',
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `rhinoquant_memorandum_${project.id}.json`;
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm print:p-0 print:bg-white">
      <div className="bg-[#0b0f17] print:bg-white print:text-black border border-slate-700 rounded-xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden print:max-h-none print:border-none print:shadow-none">
        {/* Modal Top Actions (Hidden when printing) */}
        <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between bg-[#0f172a] print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-sky-400" />
            <span className="text-xs font-bold text-slate-100 font-mono">
              INVESTMENT COMMITTEE MEMORANDUM & RETURN AUDIT
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              onClick={handleExportJson}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Export JSON Audit
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-200 px-2 py-1 text-sm font-mono"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Printable Memorandum Content */}
        <div className="p-8 overflow-y-auto flex-1 space-y-6 text-slate-200 print:text-black font-sans leading-relaxed text-xs">
          {/* Header Block */}
          <div className="border-b border-slate-700 print:border-black pb-4 space-y-2">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest text-sky-400 print:text-slate-600">
                  RHINOQUANT QUANTITATIVE FINANCE · INVESTMENT MEMORANDUM
                </span>
                <h1 className="text-xl font-bold text-slate-100 print:text-black font-mono mt-1">
                  {project.name}
                </h1>
                <p className="text-xs text-slate-400 print:text-slate-600 mt-0.5">
                  Asset Class: {project.templateType} · Active Driver: {project.assumptions.cashFlowDriver.toUpperCase()}
                </p>
              </div>

              <div className="text-right font-mono text-[11px] text-slate-400 print:text-slate-600 space-y-0.5">
                <div>Valuation Date: {project.assumptions.valuationDate}</div>
                <div>Generated: {new Date().toISOString().replace('T', ' ').slice(0, 19)} UTC</div>
                <div>Day Count: {project.assumptions.dayCount}</div>
              </div>
            </div>
          </div>

          {/* Section 1: Executive Return Summary */}
          <div className="space-y-2">
            <h2 className="text-xs font-bold uppercase font-mono tracking-wider text-slate-300 print:text-black">
              1. Executive Return Metrics
            </h2>
            <div className="grid grid-cols-4 gap-2 font-mono text-xs">
              <div className="bg-slate-900 print:bg-slate-100 p-2.5 rounded border border-slate-800 print:border-slate-300">
                <span className="text-[10px] text-slate-400 print:text-slate-600 block">Levered Equity XIRR</span>
                <span className="text-base font-bold text-emerald-400 print:text-emerald-700">
                  {formatPercent(result.xirr)}
                </span>
                <span className="text-[9px] text-slate-500 block">Dated Actual/365</span>
              </div>

              <div className="bg-slate-900 print:bg-slate-100 p-2.5 rounded border border-slate-800 print:border-slate-300">
                <span className="text-[10px] text-slate-400 print:text-slate-600 block">Unlevered Project IRR</span>
                <span className="text-base font-bold text-slate-200 print:text-black">
                  {formatPercent(result.irr)}
                </span>
                <span className="text-[9px] text-slate-500 block">Operating & CapEx</span>
              </div>

              <div className="bg-slate-900 print:bg-slate-100 p-2.5 rounded border border-slate-800 print:border-slate-300">
                <span className="text-[10px] text-slate-400 print:text-slate-600 block">Dated XNPV</span>
                <span className="text-base font-bold text-sky-400 print:text-sky-700">
                  {formatCurrency(result.xnpv, project.currency)}
                </span>
                <span className="text-[9px] text-slate-500 block">
                  @ {(project.assumptions.discountRate * 100).toFixed(1)}% Discount
                </span>
              </div>

              <div className="bg-slate-900 print:bg-slate-100 p-2.5 rounded border border-slate-800 print:border-slate-300">
                <span className="text-[10px] text-slate-400 print:text-slate-600 block">MOIC Multiple</span>
                <span className="text-base font-bold text-slate-200 print:text-black">
                  {formatMultiple(result.moic)}
                </span>
                <span className="text-[9px] text-slate-500 block">
                  Payback: {formatYears(result.paybackYears)}
                </span>
              </div>
            </div>
          </div>

          {/* Section 2: Mathematical Solver Audit Proof */}
          <div className="space-y-2">
            <h2 className="text-xs font-bold uppercase font-mono tracking-wider text-slate-300 print:text-black">
              2. Mathematical Solver & Audit Verification
            </h2>
            <div className="bg-slate-900/60 print:bg-slate-50 p-3 rounded border border-slate-800 print:border-slate-300 space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400 print:text-slate-600">Governing Polynomial:</span>
                <span className="text-slate-200 print:text-black">
                  NPV(r) = Σ [ CF_i / (1 + r)^τ_i ] = 0
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 print:text-slate-600">Solver Method:</span>
                <span className="text-slate-200 print:text-black">{result.solverMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 print:text-slate-600">Convergence Status:</span>
                <span className="text-emerald-400 print:text-emerald-700 font-bold">
                  {result.convergenceStatus} (Residual: {result.residualNpv.toExponential(4)})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 print:text-slate-600">Descartes Sign Changes:</span>
                <span className="text-slate-200 print:text-black">
                  {result.diagnostics.signChanges} sign changes
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 print:text-slate-600">Total Capital Called vs Returned:</span>
                <span className="text-slate-200 print:text-black">
                  {formatCurrency(result.totalContributions, project.currency)} called ·{' '}
                  {formatCurrency(result.totalDistributions, project.currency)} returned
                </span>
              </div>
            </div>
          </div>

          {/* Section 3: Cash Flow Ledger */}
          <div className="space-y-2">
            <h2 className="text-xs font-bold uppercase font-mono tracking-wider text-slate-300 print:text-black">
              3. Cash Flow Schedule
            </h2>
            <div className="border border-slate-800 print:border-slate-300 rounded overflow-hidden">
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead className="bg-slate-900 print:bg-slate-100 text-[10px] text-slate-400 print:text-slate-700 border-b border-slate-800 print:border-slate-300">
                  <tr>
                    <th className="p-2">Date</th>
                    <th className="p-2">Description</th>
                    <th className="p-2 text-right">Operating CF</th>
                    <th className="p-2 text-right">CapEx / Acq</th>
                    <th className="p-2 text-right">Debt Service</th>
                    <th className="p-2 text-right">Distributions</th>
                    <th className="p-2 text-right">Exit Value</th>
                    <th className="p-2 text-right font-bold">Effective Net</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 print:divide-slate-200">
                  {project.cashFlows.map((item, idx) => {
                    const eff = result.effectiveCashFlows[idx]?.amount || 0;
                    return (
                      <tr key={item.id}>
                        <td className="p-2 text-slate-400 print:text-slate-700">{item.date}</td>
                        <td className="p-2 font-sans">{item.description}</td>
                        <td className="p-2 text-right">
                          {formatCurrency(item.operatingCashFlow, project.currency)}
                        </td>
                        <td className="p-2 text-right text-rose-400 print:text-rose-700">
                          {formatCurrency(item.capitalExpenditure + item.acquisitionCost, project.currency)}
                        </td>
                        <td className="p-2 text-right text-amber-400 print:text-amber-700">
                          {formatCurrency(item.interestPaid + item.debtRepayment, project.currency)}
                        </td>
                        <td className="p-2 text-right text-emerald-400 print:text-emerald-700">
                          {formatCurrency(item.distribution, project.currency)}
                        </td>
                        <td className="p-2 text-right">
                          {formatCurrency(item.exitProceeds, project.currency)}
                        </td>
                        <td
                          className={`p-2 text-right font-bold ${
                            eff >= 0
                              ? 'text-emerald-400 print:text-emerald-700'
                              : 'text-rose-400 print:text-rose-700'
                          }`}
                        >
                          {formatCurrency(eff, project.currency)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 4: Audit & Signoff */}
          <div className="border-t border-slate-700 print:border-black pt-4 flex justify-between items-center text-[10px] font-mono text-slate-500 print:text-slate-600">
            <div>
              RhinoQuant Mathematical Engine v3.8 · All calculations verified with scale-aware convergence.
            </div>
            <div>Institutional Committee Review Copy</div>
          </div>
        </div>
      </div>
    </div>
  );
};
