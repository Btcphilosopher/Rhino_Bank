/**
 * RhinoQuant Multi-Scenario Engine & Sensitivity Analysis Workstation
 * Side-by-side scenario matrix, 2D heatmaps, Tornado risk rankings, and break-even solving.
 */

import React, { useState } from 'react';
import {
  CashFlowItem,
  EngineAssumptions,
  ScenarioDefinition,
  CalculationResult,
} from '../engine/types';
import { executeReturnsAnalysis } from '../engine/financialMath';
import {
  generateSensitivityMatrix,
  computeTornadoAnalysis,
  solveBreakEvenAndReverseValuation,
} from '../engine/sensitivity';
import { formatCurrency, formatPercent, formatMultiple, formatYears } from '../utils/formatters';
import { Plus, SlidersHorizontal, TrendingUp, BarChart2, Target } from 'lucide-react';

interface ScenarioEngineProps {
  baseItems: CashFlowItem[];
  scenarios: ScenarioDefinition[];
  activeScenarioId: string;
  assumptions: EngineAssumptions;
  currency: string;
  onSelectScenario: (scenarioId: string) => void;
  onUpdateScenarios: (newScenarios: ScenarioDefinition[]) => void;
}

export const ScenarioEngine: React.FC<ScenarioEngineProps> = ({
  baseItems,
  scenarios,
  activeScenarioId,
  assumptions,
  currency,
  onSelectScenario,
  onUpdateScenarios,
}) => {
  const [activeTab, setActiveTab] = useState<'matrix' | 'sensitivity_2d' | 'tornado' | 'breakeven'>('matrix');

  // Compute returns for each scenario dynamically from real cash flow adjustments
  const scenarioResults = scenarios.map((scenario) => {
    const mods = scenario.modifications;
    const exitMult = mods.exitValuationMultiplier ?? 1.0;
    const revMult = mods.revenueGrowthMultiplier ?? 1.0;
    const opexMult = mods.opexMultiplier ?? 1.0;
    const capexMult = mods.capexMultiplier ?? 1.0;
    const debtDelta = mods.debtCostDelta ?? 0.0;
    const timeShift = mods.exitDateShiftYears ?? 0;

    const adjustedItems = baseItems.map((item, idx) => {
      const isLast = idx === baseItems.length - 1;
      const clone = { ...item };

      if (clone.exitProceeds > 0 || isLast) {
        clone.exitProceeds = clone.exitProceeds * exitMult;
        if (timeShift !== 0) {
          const dt = new Date(clone.date);
          dt.setUTCFullYear(dt.getUTCFullYear() + timeShift);
          clone.date = dt.toISOString().split('T')[0];
        }
      }

      if (clone.operatingCashFlow > 0) {
        clone.operatingCashFlow = clone.operatingCashFlow * revMult - clone.operatingCashFlow * (opexMult - 1);
      }

      clone.capitalExpenditure = clone.capitalExpenditure * capexMult;
      clone.interestPaid = clone.interestPaid * (1.0 + debtDelta * 5); // sensitivity scaling

      return clone;
    });

    const calc = executeReturnsAnalysis(
      adjustedItems,
      assumptions.valuationDate,
      assumptions.dayCount,
      assumptions.cashFlowDriver,
      assumptions.discountRate,
      assumptions.financeRate,
      assumptions.reinvestmentRate
    );

    return {
      scenario,
      calc,
    };
  });

  const baseResult = scenarioResults.find((s) => s.scenario.isBase)?.calc || scenarioResults[0].calc;

  // 2D Sensitivity Matrix
  const sensitivityMatrix = generateSensitivityMatrix(
    baseItems,
    assumptions,
    'exit_vs_timing',
    'irr'
  );

  // Tornado Analysis
  const tornadoItems = computeTornadoAnalysis(baseItems, assumptions, baseResult);

  // Break-even and Reverse Valuation
  const breakEven = solveBreakEvenAndReverseValuation(
    baseItems,
    assumptions,
    assumptions.targetIrr
  );

  const handleAddCustomScenario = () => {
    const newScen: ScenarioDefinition = {
      id: `custom-${Date.now()}`,
      name: `Custom Scenario ${scenarios.length + 1}`,
      description: 'User-specified stress parameters and custom exit assumptions.',
      isBase: false,
      modifications: {
        exitValuationMultiplier: 1.10,
        revenueGrowthMultiplier: 1.05,
        debtCostDelta: 0.01,
      },
    };
    onUpdateScenarios([...scenarios, newScen]);
    onSelectScenario(newScen.id);
  };

  return (
    <div className="space-y-4">
      {/* Top Tab Controls */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('matrix')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              activeTab === 'matrix'
                ? 'bg-slate-800 text-sky-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            Side-by-Side Comparison
          </button>
          <button
            onClick={() => setActiveTab('sensitivity_2d')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              activeTab === 'sensitivity_2d'
                ? 'bg-slate-800 text-sky-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            2D Sensitivity Matrix
          </button>
          <button
            onClick={() => setActiveTab('tornado')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              activeTab === 'tornado'
                ? 'bg-slate-800 text-sky-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            Tornado Risk Ranking
          </button>
          <button
            onClick={() => setActiveTab('breakeven')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              activeTab === 'breakeven'
                ? 'bg-slate-800 text-sky-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            Break-Even & Reverse Valuation
          </button>
        </div>

        <button
          onClick={handleAddCustomScenario}
          className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded border border-slate-700"
        >
          <Plus className="w-3.5 h-3.5 text-sky-400" />
          New Scenario
        </button>
      </div>

      {/* Tab 1: Side-by-Side Comparison Table */}
      {activeTab === 'matrix' && (
        <div className="bg-[#0f172a] border border-slate-800 rounded-lg overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#111827] text-[11px] font-mono text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Scenario</th>
                <th className="py-2.5 px-3">Exit Multiple</th>
                <th className="py-2.5 px-3 text-right">Project IRR</th>
                <th className="py-2.5 px-3 text-right">Equity IRR</th>
                <th className="py-2.5 px-3 text-right text-sky-400">Dated XIRR</th>
                <th className="py-2.5 px-3 text-right">Dated XNPV</th>
                <th className="py-2.5 px-3 text-right">MOIC</th>
                <th className="py-2.5 px-3 text-right">Payback</th>
                <th className="py-2.5 px-3 text-right">Δ vs Base (XIRR)</th>
                <th className="py-2.5 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono text-slate-300">
              {scenarioResults.map(({ scenario, calc }) => {
                const isSelected = scenario.id === activeScenarioId;
                const baseXirr = baseResult.xirr ?? 0;
                const scenXirr = calc.xirr ?? 0;
                const deltaBps = ((scenXirr - baseXirr) * 10000).toFixed(0);
                const isPositiveDelta = scenXirr >= baseXirr;

                return (
                  <tr
                    key={scenario.id}
                    onClick={() => onSelectScenario(scenario.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-sky-950/30 border-l-2 border-l-sky-500'
                        : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-100 flex items-center gap-1.5">
                        <span>{scenario.name}</span>
                        {scenario.isBase && (
                          <span className="text-[10px] text-sky-400">· Base</span>
                        )}
                        {isSelected && (
                          <span className="text-[10px] text-emerald-400">· Active</span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 font-sans truncate max-w-xs mt-0.5">
                        {scenario.description}
                      </div>
                    </td>

                    <td className="py-3 px-3 text-slate-400">
                      {(scenario.modifications.exitValuationMultiplier ?? 1.0).toFixed(2)}x
                    </td>

                    <td className="py-3 px-3 text-right">{formatPercent(calc.irr)}</td>
                    <td className="py-3 px-3 text-right">{formatPercent(calc.xirr)}</td>
                    <td className="py-3 px-3 text-right font-bold text-sky-300">
                      {formatPercent(calc.xirr)}
                    </td>
                    <td className="py-3 px-3 text-right text-emerald-400">
                      {formatCurrency(calc.xnpv, currency, true)}
                    </td>
                    <td className="py-3 px-3 text-right font-bold">{formatMultiple(calc.moic)}</td>
                    <td className="py-3 px-3 text-right text-slate-400">
                      {formatYears(calc.paybackYears)}
                    </td>
                    <td
                      className={`py-3 px-3 text-right ${
                        scenario.isBase
                          ? 'text-slate-500'
                          : isPositiveDelta
                          ? 'text-emerald-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {scenario.isBase ? 'Base Reference' : `${isPositiveDelta ? '+' : ''}${deltaBps} bps`}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="text-[10px] text-slate-400">
                        {calc.convergenceStatus === 'CONVERGED' ? 'Converged' : calc.convergenceStatus}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 2: 2D Sensitivity Heatmap */}
      {activeTab === 'sensitivity_2d' && (
        <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-semibold text-slate-100">
                2D Return Matrix: Exit Valuation vs Timing Shift
              </h3>
              <p className="text-xs text-slate-400 font-sans">
                Internal Rate of Return (IRR %) sensitivity surface across varying exit valuations and exit years.
              </p>
            </div>
            <div className="text-xs font-mono text-slate-400">Metric: Dated XIRR (%)</div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center border-collapse text-xs font-mono">
              <thead>
                <tr>
                  <th className="p-2 border border-slate-800 bg-slate-900 text-slate-400 text-left">
                    {sensitivityMatrix.rowTitle} \ {sensitivityMatrix.colTitle}
                  </th>
                  {sensitivityMatrix.colLabels.map((cLabel, ci) => (
                    <th key={ci} className="p-2 border border-slate-800 bg-slate-900 text-slate-300">
                      {cLabel}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {sensitivityMatrix.grid.map((row, ri) => (
                  <tr key={ri}>
                    <td className="p-2 border border-slate-800 bg-slate-900 text-slate-300 font-semibold text-left">
                      {sensitivityMatrix.rowLabels[ri]}
                    </td>
                    {row.map((val, ci) => {
                      const isBaseCell =
                        sensitivityMatrix.rowValues[ri] === 1.0 &&
                        sensitivityMatrix.colValues[ci] === 0;

                      // Color interpolation based on IRR
                      let bgClass = 'bg-slate-900/60';
                      let textClass = 'text-slate-300';
                      if (val !== null) {
                        if (val >= 25) {
                          bgClass = 'bg-emerald-950/70';
                          textClass = 'text-emerald-300 font-bold';
                        } else if (val >= 18) {
                          bgClass = 'bg-emerald-950/40';
                          textClass = 'text-emerald-400';
                        } else if (val >= 12) {
                          bgClass = 'bg-sky-950/40';
                          textClass = 'text-sky-300';
                        } else if (val >= 5) {
                          bgClass = 'bg-amber-950/40';
                          textClass = 'text-amber-300';
                        } else {
                          bgClass = 'bg-rose-950/60';
                          textClass = 'text-rose-400';
                        }
                      }

                      return (
                        <td
                          key={ci}
                          className={`p-2.5 border border-slate-800 transition-colors ${bgClass} ${textClass} ${
                            isBaseCell ? 'ring-2 ring-sky-400 relative z-10' : ''
                          }`}
                        >
                          {val !== null ? `${val.toFixed(2)}%` : 'N/A'}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Tornado Risk Ranking Chart */}
      {activeTab === 'tornado' && (
        <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-4 space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">
              Tornado Return Sensitivity: Variable Impact Ranking
            </h3>
            <p className="text-xs text-slate-400 font-sans">
              Evaluates the swing in XIRR across key input parameters sorted by impact magnitude.
            </p>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {tornadoItems.map((item, idx) => {
              const maxSwing = Math.max(...tornadoItems.map((t) => t.swingIrr)) || 1;
              const widthPct = (item.swingIrr / maxSwing) * 100;

              return (
                <div key={idx} className="bg-slate-900 border border-slate-800 p-2.5 rounded space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-200">{item.parameter}</span>
                    <span className="text-sky-400 font-bold">
                      ±{(item.swingIrr / 2).toFixed(2)}% Swing ({item.swingIrr.toFixed(2)}% total)
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-[11px]">
                    <span className="w-20 text-rose-400 text-right truncate">{item.lowValueLabel}</span>
                    <div className="flex-1 h-3.5 bg-slate-950 rounded flex overflow-hidden">
                      <div
                        className="bg-rose-500/80 h-full transition-all"
                        style={{ width: `${widthPct / 2}%` }}
                      />
                      <div className="w-0.5 bg-white h-full" />
                      <div
                        className="bg-emerald-500/80 h-full transition-all"
                        style={{ width: `${widthPct / 2}%` }}
                      />
                    </div>
                    <span className="w-20 text-emerald-400 truncate">{item.highValueLabel}</span>
                  </div>

                  <div className="flex justify-between text-[10px] text-slate-500 pt-0.5">
                    <span>Low IRR: {item.lowIrr.toFixed(2)}%</span>
                    <span>Base IRR: {item.baseIrr.toFixed(2)}%</span>
                    <span>High IRR: {item.highIrr.toFixed(2)}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 4: Break-even & Reverse Valuation */}
      {activeTab === 'breakeven' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Break-even Exit Value */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-sky-400" /> Break-Even Exit Proceeds
            </h3>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              Calculates the minimum gross exit proceeds required to achieve the institutional hurdle return of{' '}
              <strong className="text-emerald-400">{breakEven.targetIrr.toFixed(1)}% IRR</strong>.
            </p>

            <div className="bg-slate-900 border border-slate-800 rounded p-3 space-y-2 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Target Return Hurdle:</span>
                <span className="text-emerald-400 font-bold">{breakEven.targetIrr.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Base Case Exit Proceeds:</span>
                <span className="text-slate-200">{formatCurrency(breakEven.baseExitProceeds, currency)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-800 pt-1.5">
                <span className="text-slate-300 font-semibold">Required Break-Even Exit:</span>
                <span className="text-sky-300 font-bold text-sm">
                  {formatCurrency(breakEven.requiredExitProceeds, currency)}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-500">
                <span>Exit Proceeds Buffer:</span>
                <span
                  className={
                    breakEven.exitProceedsDeltaPercent >= 0 ? 'text-amber-400' : 'text-emerald-400'
                  }
                >
                  {breakEven.exitProceedsDeltaPercent >= 0 ? '+' : ''}
                  {breakEven.exitProceedsDeltaPercent.toFixed(1)}% vs Base
                </span>
              </div>
            </div>
          </div>

          {/* Reverse Valuation Max Entry Price */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-emerald-400" /> Reverse Valuation: Max Entry Price
            </h3>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              Solves for the maximum initial acquisition price consistent with generating at least{' '}
              <strong className="text-emerald-400">{breakEven.targetIrr.toFixed(1)}% IRR</strong> given the operating plan.
            </p>

            <div className="bg-slate-900 border border-slate-800 rounded p-3 space-y-2 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Target Return Hurdle:</span>
                <span className="text-emerald-400 font-bold">{breakEven.targetIrr.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Underwritten Entry Price:</span>
                <span className="text-slate-200">{formatCurrency(breakEven.baseEntryValuation, currency)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-800 pt-1.5">
                <span className="text-slate-300 font-semibold">Maximum Affordable Entry:</span>
                <span className="text-emerald-300 font-bold text-sm">
                  {formatCurrency(breakEven.maxEntryValuation, currency)}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-500">
                <span>Valuation Headroom / Discount:</span>
                <span className="text-slate-400">
                  {breakEven.entryDiscountRequiredPercent.toFixed(1)}% headroom
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
