/**
 * RhinoQuant Primary KPI Strip
 * High-density return indicators: Project IRR, Equity IRR, XIRR, NPV, MOIC, Payback, Outlays, Distributions
 */

import React from 'react';
import { CalculationResult } from '../engine/types';
import { formatCurrency, formatPercent, formatMultiple, formatYears } from '../utils/formatters';

interface KpiStripProps {
  result: CalculationResult;
  currency: string;
  discountRate: number;
}

export const KpiStrip: React.FC<KpiStripProps> = ({ result, currency, discountRate }) => {
  const isPositiveXirr = result.xirr !== null && result.xirr > 0;
  const isPositiveNpv = result.xnpv >= 0;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 bg-[#0d131f] border border-slate-800 rounded-lg p-2.5">
      {/* 1. Project IRR */}
      <div className="bg-[#111827] border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-col justify-between">
        <span className="text-[10px] uppercase font-mono text-slate-400">Project IRR</span>
        <div className="text-base font-bold font-mono tabular-nums text-slate-100 my-0.5">
          {formatPercent(result.irr)}
        </div>
        <span className="text-[10px] text-slate-500 truncate">Periodic Unlevered</span>
      </div>

      {/* 2. Equity IRR */}
      <div className="bg-[#111827] border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-col justify-between">
        <span className="text-[10px] uppercase font-mono text-slate-400">Equity IRR</span>
        <div
          className={`text-base font-bold font-mono tabular-nums my-0.5 ${
            isPositiveXirr ? 'text-emerald-400' : 'text-slate-200'
          }`}
        >
          {formatPercent(result.xirr)}
        </div>
        <span className="text-[10px] text-slate-500 truncate">Levered (Residual)</span>
      </div>

      {/* 3. Dated XIRR */}
      <div className="bg-[#111827] border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-col justify-between">
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase font-mono text-slate-400">Dated XIRR</span>
          <span className="text-[9px] font-mono text-sky-400">{result.diagnostics.dayCount}</span>
        </div>
        <div
          className={`text-base font-bold font-mono tabular-nums my-0.5 ${
            isPositiveXirr ? 'text-emerald-400' : 'text-rose-400'
          }`}
        >
          {formatPercent(result.xirr)}
        </div>
        <span className="text-[10px] text-slate-500 truncate">
          {result.convergenceStatus === 'CONVERGED' ? 'Root Converged' : result.convergenceStatus}
        </span>
      </div>

      {/* 4. Net Present Value (NPV) */}
      <div className="bg-[#111827] border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-col justify-between">
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase font-mono text-slate-400">Dated XNPV</span>
          <span className="text-[9px] font-mono text-slate-500">{(discountRate * 100).toFixed(0)}% Disc</span>
        </div>
        <div
          className={`text-base font-bold font-mono tabular-nums my-0.5 ${
            isPositiveNpv ? 'text-emerald-400' : 'text-rose-400'
          }`}
        >
          {formatCurrency(result.xnpv, currency, true)}
        </div>
        <span className="text-[10px] text-slate-500 truncate">Discounted Value</span>
      </div>

      {/* 5. MOIC / Equity Multiple */}
      <div className="bg-[#111827] border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-col justify-between">
        <span className="text-[10px] uppercase font-mono text-slate-400">MOIC Multiple</span>
        <div className="text-base font-bold font-mono tabular-nums text-slate-100 my-0.5">
          {formatMultiple(result.moic)}
        </div>
        <span className="text-[10px] text-slate-500 truncate">Distributions / Calls</span>
      </div>

      {/* 6. Payback Period */}
      <div className="bg-[#111827] border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-col justify-between">
        <span className="text-[10px] uppercase font-mono text-slate-400">Payback Period</span>
        <div className="text-base font-bold font-mono tabular-nums text-slate-100 my-0.5">
          {formatYears(result.paybackYears)}
        </div>
        <span className="text-[10px] text-slate-500 truncate">Capital Recovery</span>
      </div>

      {/* 7. Initial Investment */}
      <div className="bg-[#111827] border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-col justify-between">
        <span className="text-[10px] uppercase font-mono text-slate-400">Initial Outlay</span>
        <div className="text-base font-bold font-mono tabular-nums text-rose-300 my-0.5">
          {formatCurrency(result.initialInvestment, currency, true)}
        </div>
        <span className="text-[10px] text-slate-500 truncate">Funded Capital</span>
      </div>

      {/* 8. Total Distributions */}
      <div className="bg-[#111827] border border-slate-800/80 rounded px-2.5 py-1.5 flex flex-col justify-between">
        <span className="text-[10px] uppercase font-mono text-slate-400">Total Proceeds</span>
        <div className="text-base font-bold font-mono tabular-nums text-emerald-300 my-0.5">
          {formatCurrency(result.totalDistributions, currency, true)}
        </div>
        <span className="text-[10px] text-slate-500 truncate">
          +{formatCurrency(result.netProfit, currency, true)} Net
        </span>
      </div>
    </div>
  );
};
