/**
 * RhinoQuant Top Bar Header
 * Complies strictly with the 3-Zone Top Bar Contract from the Universal Frontend Design Constitution.
 */

import React from 'react';
import { Command, FileText, CheckCircle2, ShieldAlert } from 'lucide-react';

export type ActiveNavTab = 'workstation' | 'scenarios' | 'quant_risk' | 'waterfall' | 'tests';

interface HeaderProps {
  activeTab: ActiveNavTab;
  onSelectTab: (tab: ActiveNavTab) => void;
  onOpenReport: () => void;
  onOpenTests: () => void;
  onOpenCommandPalette: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  onOpenReport,
  onOpenTests,
  onOpenCommandPalette,
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-5 py-3 border-b border-slate-800 bg-[#0b0f17] select-none">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-2 shrink-0">
        <span className="text-base font-bold tracking-tight text-slate-100 font-mono whitespace-nowrap">
          RhinoQuant IRR
        </span>
      </div>

      {/* Zone 2: 4–5 clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          onClick={() => onSelectTab('workstation')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'workstation'
              ? 'text-sky-400 font-semibold border-b border-sky-400'
              : ''
          }`}
        >
          Modelling Workstation
        </button>
        <button
          onClick={() => onSelectTab('scenarios')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'scenarios'
              ? 'text-sky-400 font-semibold border-b border-sky-400'
              : ''
          }`}
        >
          Scenario Engine
        </button>
        <button
          onClick={() => onSelectTab('quant_risk')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'quant_risk'
              ? 'text-sky-400 font-semibold border-b border-sky-400'
              : ''
          }`}
        >
          Quantitative Risk
        </button>
        <button
          onClick={() => onSelectTab('waterfall')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'waterfall'
              ? 'text-sky-400 font-semibold border-b border-sky-400'
              : ''
          }`}
        >
          Fund Waterfall
        </button>
        <button
          onClick={() => onSelectTab('tests')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'tests'
              ? 'text-sky-400 font-semibold border-b border-sky-400'
              : ''
          }`}
        >
          Audit Proofs
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={onOpenCommandPalette}
          className="hidden sm:flex items-center gap-1.5 px-2 py-1 text-[11px] font-mono text-slate-400 bg-slate-900 border border-slate-800 rounded hover:text-slate-200 transition-colors"
          title="Open Command Palette (⌘K)"
        >
          <Command className="w-3 h-3" />
          <span>⌘K</span>
        </button>

        <button
          onClick={onOpenReport}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm"
        >
          <FileText className="w-3.5 h-3.5 text-sky-400" />
          <span>Investment Memorandum</span>
        </button>
      </div>
    </header>
  );
};
