/**
 * RhinoQuant Quantitative Risk & Monte Carlo Simulation Console
 * Stochastic parametric simulation, percentile distributions, loss of capital probabilities, and histograms.
 */

import React, { useState } from 'react';
import { CashFlowItem, EngineAssumptions, MonteCarloParameter, MonteCarloResult } from '../engine/types';
import { runMonteCarloSimulation } from '../engine/monteCarlo';
import { formatCurrency, formatPercent, formatMultiple } from '../utils/formatters';
import { Play, RotateCcw, AlertTriangle, Activity } from 'lucide-react';

interface QuantAnalyticsProps {
  items: CashFlowItem[];
  assumptions: EngineAssumptions;
  currency: string;
}

export const QuantAnalytics: React.FC<QuantAnalyticsProps> = ({ items, assumptions, currency }) => {
  const [iterations, setIterations] = useState<number>(500);
  const [seed, setSeed] = useState<number>(42);
  const [params, setParams] = useState<MonteCarloParameter[]>([
    {
      name: 'Exit Valuation Multiplier',
      key: 'exitValuationMultiplier',
      distribution: 'lognormal',
      mean: 1.0,
      stdDev: 0.18,
    },
    {
      name: 'Operating Cash Flow Growth',
      key: 'revenueGrowthMultiplier',
      distribution: 'normal',
      mean: 1.0,
      stdDev: 0.12,
    },
    {
      name: 'Capital Expenditure Volatility',
      key: 'capexMultiplier',
      distribution: 'triangular',
      mean: 1.0,
      min: 0.85,
      mode: 1.0,
      max: 1.30,
    },
    {
      name: 'Financing Cost Shift (Debt Margin)',
      key: 'debtCostDelta',
      distribution: 'uniform',
      mean: 1.0,
      min: 0.90,
      max: 1.25,
    },
  ]);

  const [simResult, setSimResult] = useState<MonteCarloResult | null>(() => {
    return runMonteCarloSimulation(items, assumptions, params, 500, 42);
  });

  const handleRunSimulation = () => {
    const res = runMonteCarloSimulation(items, assumptions, params, iterations, seed);
    setSimResult(res);
  };

  const handleUpdateParam = (idx: number, field: string, val: any) => {
    const updated = [...params];
    updated[idx] = { ...updated[idx], [field]: val };
    setParams(updated);
  };

  // Histogram rendering
  const renderHistogram = () => {
    if (!simResult || simResult.histogram.length === 0) return null;

    const width = 640;
    const height = 220;
    const padding = { top: 20, right: 25, bottom: 35, left: 45 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const bins = simResult.histogram;
    const maxCount = Math.max(...bins.map((b) => b.count), 1);

    const getX = (idx: number) => padding.left + (idx / bins.length) * chartW;
    const barWidth = chartW / bins.length - 2;

    const minIrr = bins[0].binStart;
    const maxIrr = bins[bins.length - 1].binEnd;
    const irrRange = maxIrr - minIrr || 1;

    // Median and P10/P90 lines
    const getIrrX = (rateVal: number) =>
      padding.left + ((rateVal - minIrr) / irrRange) * chartW;

    const medianX = simResult.medianIrr !== null ? getIrrX(simResult.medianIrr) : null;
    const p10X = simResult.p10Irr !== null ? getIrrX(simResult.p10Irr) : null;
    const p90X = simResult.p90Irr !== null ? getIrrX(simResult.p90Irr) : null;

    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-56 select-none">
        {/* Bars */}
        {bins.map((b, i) => {
          const x = getX(i);
          const barH = (b.count / maxCount) * chartH;
          const y = padding.top + chartH - barH;
          const isPositive = (b.binStart + b.binEnd) / 2 >= 0;

          return (
            <g key={i}>
              <rect
                x={x}
                y={y}
                width={Math.max(2, barWidth)}
                height={barH}
                fill={isPositive ? '#10b981' : '#f43f5e'}
                opacity={0.7}
                rx="1"
              >
                <title>
                  Range: {b.binStart.toFixed(1)}% to {b.binEnd.toFixed(1)}% | Frequency: {b.count} runs
                </title>
              </rect>
              {/* X-axis labels every few bins */}
              {i % 3 === 0 && (
                <text
                  x={x + barWidth / 2}
                  y={height - 12}
                  textAnchor="middle"
                  fill="#94a3b8"
                  className="text-[9px] font-mono"
                >
                  {b.binStart.toFixed(0)}%
                </text>
              )}
            </g>
          );
        })}

        {/* P10 line */}
        {p10X !== null && p10X >= padding.left && p10X <= width - padding.right && (
          <g>
            <line
              x1={p10X}
              y1={padding.top}
              x2={p10X}
              y2={padding.top + chartH}
              stroke="#f43f5e"
              strokeDasharray="2 2"
              strokeWidth="1.5"
            />
            <text x={p10X} y={padding.top - 5} textAnchor="middle" fill="#f43f5e" className="text-[9px] font-mono">
              P10: {simResult.p10Irr?.toFixed(1)}%
            </text>
          </g>
        )}

        {/* Median P50 line */}
        {medianX !== null && medianX >= padding.left && medianX <= width - padding.right && (
          <g>
            <line
              x1={medianX}
              y1={padding.top}
              x2={medianX}
              y2={padding.top + chartH}
              stroke="#38bdf8"
              strokeWidth="2"
            />
            <text x={medianX} y={padding.top - 5} textAnchor="middle" fill="#38bdf8" className="text-[9px] font-mono font-bold">
              Median: {simResult.medianIrr?.toFixed(1)}%
            </text>
          </g>
        )}

        {/* P90 line */}
        {p90X !== null && p90X >= padding.left && p90X <= width - padding.right && (
          <g>
            <line
              x1={p90X}
              y1={padding.top}
              x2={p90X}
              y2={padding.top + chartH}
              stroke="#10b981"
              strokeDasharray="2 2"
              strokeWidth="1.5"
            />
            <text x={p90X} y={padding.top - 5} textAnchor="middle" fill="#10b981" className="text-[9px] font-mono">
              P90: {simResult.p90Irr?.toFixed(1)}%
            </text>
          </g>
        )}
      </svg>
    );
  };

  return (
    <div className="space-y-4">
      {/* Top Banner and Controls */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-sky-400" />
          <span className="text-xs font-semibold text-slate-100">
            Stochastic Monte Carlo Engine
          </span>
          <span className="text-slate-600 text-xs">/</span>
          <span className="text-xs text-slate-400">
            Deterministic Mulberry32 PRNG (Reproducible)
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-mono">
            <span className="text-slate-400 text-[11px]">Iterations:</span>
            <select
              value={iterations}
              onChange={(e) => setIterations(parseInt(e.target.value, 10))}
              className="bg-slate-900 border border-slate-800 rounded px-2 py-0.5 text-sky-300 text-xs"
            >
              <option value="200">200 runs</option>
              <option value="500">500 runs</option>
              <option value="1000">1,000 runs</option>
              <option value="2000">2,000 runs</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-mono">
            <span className="text-slate-400 text-[11px]">Seed:</span>
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(parseInt(e.target.value, 10) || 1)}
              className="w-16 bg-slate-900 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200 text-xs"
            />
          </div>

          <button
            onClick={handleRunSimulation}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Run Simulation
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Col: Parameter Distribution Configuration */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-3.5 space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
              Input Distributions
            </h4>
            <span className="text-[10px] text-slate-500 font-mono">4 Parameters</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {params.map((p, idx) => (
              <div key={idx} className="bg-slate-900/80 border border-slate-800/80 p-2.5 rounded space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-slate-200 font-semibold">{p.name}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">Distribution</label>
                    <select
                      value={p.distribution}
                      onChange={(e) => handleUpdateParam(idx, 'distribution', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-slate-300"
                    >
                      <option value="normal">Normal</option>
                      <option value="lognormal">Lognormal</option>
                      <option value="triangular">Triangular</option>
                      <option value="uniform">Uniform</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">Mean / Base</label>
                    <input
                      type="number"
                      step="0.05"
                      value={p.mean}
                      onChange={(e) => handleUpdateParam(idx, 'mean', parseFloat(e.target.value) || 1)}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-slate-200"
                    />
                  </div>
                </div>

                {p.distribution === 'normal' || p.distribution === 'lognormal' ? (
                  <div>
                    <div className="flex justify-between text-[10px] text-slate-500 mb-0.5">
                      <span>Standard Dev (σ)</span>
                      <span className="text-sky-400">{((p.stdDev ?? 0.15) * 100).toFixed(0)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.02"
                      max="0.40"
                      step="0.01"
                      value={p.stdDev ?? 0.15}
                      onChange={(e) => handleUpdateParam(idx, 'stdDev', parseFloat(e.target.value))}
                      className="w-full accent-sky-500 cursor-pointer"
                    />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div>
                      <span className="text-slate-500 block">Min</span>
                      <input
                        type="number"
                        step="0.05"
                        value={p.min ?? 0.8}
                        onChange={(e) => handleUpdateParam(idx, 'min', parseFloat(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-1 py-0.5 text-slate-300"
                      />
                    </div>
                    <div>
                      <span className="text-slate-500 block">Max</span>
                      <input
                        type="number"
                        step="0.05"
                        value={p.max ?? 1.2}
                        onChange={(e) => handleUpdateParam(idx, 'max', parseFloat(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-1 py-0.5 text-slate-300"
                      />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right Col (2 spans): Simulation Output & Distribution */}
        <div className="lg:col-span-2 space-y-4">
          {simResult && (
            <>
              {/* Risk KPI Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono">
                <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
                  <span className="text-[10px] text-slate-500 block">Median IRR (P50)</span>
                  <span className="text-base font-bold text-sky-400">
                    {simResult.medianIrr !== null ? `${simResult.medianIrr.toFixed(2)}%` : 'N/A'}
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    Mean: {simResult.meanIrr !== null ? `${simResult.meanIrr.toFixed(2)}%` : 'N/A'}
                  </span>
                </div>

                <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
                  <span className="text-[10px] text-slate-500 block">P(Negative NPV)</span>
                  <span
                    className={`text-base font-bold ${
                      simResult.probNegativeNpv > 15 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {simResult.probNegativeNpv.toFixed(1)}%
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    Discounted &lt; $0
                  </span>
                </div>

                <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
                  <span className="text-[10px] text-slate-500 block">P(Capital Loss)</span>
                  <span
                    className={`text-base font-bold ${
                      simResult.probLossOfCapital > 10 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {simResult.probLossOfCapital.toFixed(1)}%
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    MOIC &lt; 1.0x
                  </span>
                </div>

                <div className="bg-[#0f172a] border border-slate-800 rounded p-2.5">
                  <span className="text-[10px] text-slate-500 block">Converged Runs</span>
                  <span className="text-base font-bold text-slate-200">
                    {simResult.successfulRuns} / {simResult.iterations}
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    {simResult.invalidRuns} divergent flagged
                  </span>
                </div>
              </div>

              {/* Histogram View */}
              <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-3 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-semibold text-slate-200">
                    Simulated Return Distribution (IRR %)
                  </span>
                  <span className="text-[11px] font-mono text-slate-500">
                    P10: {simResult.p10Irr?.toFixed(1)}% · Median: {simResult.medianIrr?.toFixed(1)}% · P90: {simResult.p90Irr?.toFixed(1)}%
                  </span>
                </div>
                {renderHistogram()}
              </div>

              {/* Percentiles Table */}
              <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-3">
                <h4 className="text-xs font-semibold text-slate-200 mb-2 font-mono uppercase tracking-wider">
                  Percentile Spectrum
                </h4>
                <div className="grid grid-cols-7 gap-1 font-mono text-center text-xs">
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-rose-400 block">P5 (Downside)</span>
                    <span className="text-slate-200 font-bold">{simResult.p5Irr?.toFixed(2)}%</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-rose-300 block">P10</span>
                    <span className="text-slate-200 font-bold">{simResult.p10Irr?.toFixed(2)}%</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-amber-300 block">P25</span>
                    <span className="text-slate-200 font-bold">{simResult.p25Irr?.toFixed(2)}%</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-sky-600 bg-sky-950/20">
                    <span className="text-[10px] text-sky-400 block font-bold">P50 (Median)</span>
                    <span className="text-sky-300 font-bold">{simResult.medianIrr?.toFixed(2)}%</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-emerald-300 block">P75</span>
                    <span className="text-slate-200 font-bold">{simResult.p75Irr?.toFixed(2)}%</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-emerald-400 block">P90</span>
                    <span className="text-slate-200 font-bold">{simResult.p90Irr?.toFixed(2)}%</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-emerald-400 block">P95 (Outlier)</span>
                    <span className="text-slate-200 font-bold">{simResult.p95Irr?.toFixed(2)}%</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
