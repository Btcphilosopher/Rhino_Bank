/**
 * RhinoQuant Sensitivity, Break-even & Return Attribution Engine
 */

import { CashFlowItem, EngineAssumptions, CalculationResult } from './types';
import { executeReturnsAnalysis, parseDateToUtc } from './financialMath';

export interface SensitivityMatrix {
  rowTitle: string;
  rowValues: number[];
  rowLabels: string[];
  colTitle: string;
  colValues: number[];
  colLabels: string[];
  grid: (number | null)[][]; // Matrix of calculated IRR or NPV values
  metric: 'irr' | 'npv' | 'moic';
}

export interface TornadoItem {
  parameter: string;
  lowValueLabel: string;
  highValueLabel: string;
  baseIrr: number;
  lowIrr: number;
  highIrr: number;
  baseNpv: number;
  lowNpv: number;
  highNpv: number;
  swingIrr: number;
  swingNpv: number;
}

export interface BreakEvenResult {
  targetIrr: number;
  requiredExitProceeds: number;
  baseExitProceeds: number;
  exitProceedsDeltaPercent: number;
  maxEntryValuation: number;
  baseEntryValuation: number;
  entryDiscountRequiredPercent: number;
}

export interface ReturnAttributionBreakdown {
  initialEquity: number;
  totalDistributions: number;
  netGain: number;
  operatingCashFlowComponent: number;
  deleveragingComponent: number;
  valuationExpansionComponent: number;
  financingCostDrag: number;
}

// Generate a 2D sensitivity matrix
export function generateSensitivityMatrix(
  baseItems: CashFlowItem[],
  baseAssumptions: EngineAssumptions,
  type: 'exit_vs_timing' | 'leverage_vs_rate' | 'opex_vs_revenue',
  metric: 'irr' | 'npv' | 'moic' = 'irr'
): SensitivityMatrix {
  if (type === 'exit_vs_timing') {
    const exitMultipliers = [0.7, 0.85, 1.0, 1.15, 1.3];
    const exitLabels = ['-30%', '-15%', 'Base (1.0x)', '+15%', '+30%'];
    const timeShifts = [-1, 0, 1, 2];
    const timeLabels = ['-1 Year', 'Base Exit', '+1 Year', '+2 Years'];

    const grid: (number | null)[][] = [];

    for (let r = 0; r < exitMultipliers.length; r++) {
      const rowRes: (number | null)[] = [];
      const mult = exitMultipliers[r];

      for (let c = 0; c < timeShifts.length; c++) {
        const shift = timeShifts[c];

        // Clone and adjust cash flows
        const adjusted = baseItems.map((item, idx) => {
          const isLast = idx === baseItems.length - 1;
          const clone = { ...item };
          if (item.exitProceeds > 0 || isLast) {
            clone.exitProceeds = item.exitProceeds * mult;
            if (shift !== 0) {
              const dt = new Date(item.date);
              dt.setUTCFullYear(dt.getUTCFullYear() + shift);
              clone.date = dt.toISOString().split('T')[0];
            }
          }
          return clone;
        });

        const res = executeReturnsAnalysis(
          adjusted,
          baseAssumptions.valuationDate,
          baseAssumptions.dayCount,
          baseAssumptions.cashFlowDriver,
          baseAssumptions.discountRate,
          baseAssumptions.financeRate,
          baseAssumptions.reinvestmentRate
        );

        if (metric === 'irr') {
          rowRes.push(res.xirr !== null ? res.xirr * 100 : null);
        } else if (metric === 'npv') {
          rowRes.push(res.xnpv);
        } else {
          rowRes.push(res.moic);
        }
      }
      grid.push(rowRes);
    }

    return {
      rowTitle: 'Exit Valuation Multiplier',
      rowValues: exitMultipliers,
      rowLabels: exitLabels,
      colTitle: 'Exit Timing Shift',
      colValues: timeShifts,
      colLabels: timeLabels,
      grid,
      metric,
    };
  }

  // Fallback / default: Revenue Growth vs Margin sensitivity
  const revDeltas = [0.8, 0.9, 1.0, 1.1, 1.2];
  const revLabels = ['-20%', '-10%', 'Base', '+10%', '+20%'];
  const costDeltas = [0.85, 0.95, 1.0, 1.05, 1.15];
  const costLabels = ['-15% Opex', '-5% Opex', 'Base Opex', '+5% Opex', '+15% Opex'];

  const grid: (number | null)[][] = [];
  for (let r = 0; r < revDeltas.length; r++) {
    const rowRes: (number | null)[] = [];
    const rMult = revDeltas[r];
    for (let c = 0; c < costDeltas.length; c++) {
      const cMult = costDeltas[c];
      const adjusted = baseItems.map((item) => {
        const clone = { ...item };
        if (clone.operatingCashFlow > 0) {
          clone.operatingCashFlow = clone.operatingCashFlow * rMult - (clone.operatingCashFlow * (cMult - 1));
        }
        return clone;
      });

      const res = executeReturnsAnalysis(
        adjusted,
        baseAssumptions.valuationDate,
        baseAssumptions.dayCount,
        baseAssumptions.cashFlowDriver,
        baseAssumptions.discountRate
      );

      if (metric === 'irr') {
        rowRes.push(res.xirr !== null ? res.xirr * 100 : null);
      } else if (metric === 'npv') {
        rowRes.push(res.xnpv);
      } else {
        rowRes.push(res.moic);
      }
    }
    grid.push(rowRes);
  }

  return {
    rowTitle: 'Revenue Factor',
    rowValues: revDeltas,
    rowLabels: revLabels,
    colTitle: 'Operating Cost Factor',
    colValues: costDeltas,
    colLabels: costLabels,
    grid,
    metric,
  };
}

// Compute Tornado Sensitivity Chart data
export function computeTornadoAnalysis(
  items: CashFlowItem[],
  assumptions: EngineAssumptions,
  baseResult: CalculationResult
): TornadoItem[] {
  const baseIrr = (baseResult.xirr ?? 0) * 100;
  const baseNpv = baseResult.xnpv;

  const parameters = [
    {
      name: 'Exit Valuation',
      lowLabel: '-15%',
      highLabel: '+15%',
      apply: (delta: number) =>
        items.map((it) => ({
          ...it,
          exitProceeds: it.exitProceeds * (1 + delta),
        })),
    },
    {
      name: 'Initial Acquisition / Outlay',
      lowLabel: '-10% (Cheaper Entry)',
      highLabel: '+10% (Higher Entry)',
      apply: (delta: number) =>
        items.map((it, idx) => ({
          ...it,
          acquisitionCost: it.acquisitionCost * (1 + delta),
          equityContribution: idx === 0 ? it.equityContribution * (1 + delta) : it.equityContribution,
        })),
    },
    {
      name: 'Operating Cash Flow',
      lowLabel: '-15%',
      highLabel: '+15%',
      apply: (delta: number) =>
        items.map((it) => ({
          ...it,
          operatingCashFlow: it.operatingCashFlow * (1 + delta),
        })),
    },
    {
      name: 'Capital Expenditure',
      lowLabel: '-20%',
      highLabel: '+20%',
      apply: (delta: number) =>
        items.map((it) => ({
          ...it,
          capitalExpenditure: it.capitalExpenditure * (1 + delta),
        })),
    },
    {
      name: 'Debt Financing Cost (Interest)',
      lowLabel: '-100 bps',
      highLabel: '+100 bps',
      apply: (delta: number) =>
        items.map((it) => ({
          ...it,
          interestPaid: it.interestPaid * (1 + delta * 2), // amplified sensitivity
        })),
    },
  ];

  const results: TornadoItem[] = [];

  for (const param of parameters) {
    const lowFlows = param.apply(-0.15);
    const highFlows = param.apply(0.15);

    const lowRes = executeReturnsAnalysis(
      lowFlows,
      assumptions.valuationDate,
      assumptions.dayCount,
      assumptions.cashFlowDriver,
      assumptions.discountRate
    );

    const highRes = executeReturnsAnalysis(
      highFlows,
      assumptions.valuationDate,
      assumptions.dayCount,
      assumptions.cashFlowDriver,
      assumptions.discountRate
    );

    const lowIrr = (lowRes.xirr ?? 0) * 100;
    const highIrr = (highRes.xirr ?? 0) * 100;
    const lowNpv = lowRes.xnpv;
    const highNpv = highRes.xnpv;

    results.push({
      parameter: param.name,
      lowValueLabel: param.lowLabel,
      highValueLabel: param.highLabel,
      baseIrr,
      lowIrr,
      highIrr,
      baseNpv,
      lowNpv,
      highNpv,
      swingIrr: Math.abs(highIrr - lowIrr),
      swingNpv: Math.abs(highNpv - lowNpv),
    });
  }

  // Sort by impact on IRR descending
  return results.sort((a, b) => b.swingIrr - a.swingIrr);
}

// Solve for Break-even exit proceeds and reverse valuation max entry price
export function solveBreakEvenAndReverseValuation(
  items: CashFlowItem[],
  assumptions: EngineAssumptions,
  targetIrr: number
): BreakEvenResult {
  const targetRate = targetIrr; // decimal, e.g. 0.15

  // 1. Solve required exit proceeds:
  // Find current exit proceeds item (usually last item or item with exitProceeds > 0)
  const exitIdx = items.findIndex((it) => it.exitProceeds > 0) !== -1
    ? items.findIndex((it) => it.exitProceeds > 0)
    : items.length - 1;

  const baseExitProceeds = items[exitIdx]?.exitProceeds || 0;

  // Bisection to find required exit proceeds
  let lowExit = 0;
  let highExit = Math.max(1e8, baseExitProceeds * 5);
  let requiredExitProceeds = baseExitProceeds;

  for (let iter = 0; iter < 40; iter++) {
    const mid = (lowExit + highExit) / 2;
    const testItems = items.map((it, idx) =>
      idx === exitIdx ? { ...it, exitProceeds: mid } : it
    );
    const res = executeReturnsAnalysis(
      testItems,
      assumptions.valuationDate,
      assumptions.dayCount,
      assumptions.cashFlowDriver,
      targetRate
    );

    // If res.xnpv > 0, mid is higher than needed; if < 0, mid is too low
    if (res.xnpv > 0) {
      highExit = mid;
      requiredExitProceeds = mid;
    } else {
      lowExit = mid;
    }
  }

  const exitProceedsDeltaPercent =
    baseExitProceeds > 0
      ? ((requiredExitProceeds - baseExitProceeds) / baseExitProceeds) * 100
      : 0;

  // 2. Solve max entry valuation (initial outflow):
  const entryIdx = 0;
  const baseEntryValuation =
    items[entryIdx].acquisitionCost > 0
      ? items[entryIdx].acquisitionCost
      : items[entryIdx].equityContribution > 0
      ? items[entryIdx].equityContribution
      : Math.abs(items[entryIdx].operatingCashFlow);

  let lowEntry = 0;
  let highEntry = Math.max(1e8, baseEntryValuation * 3);
  let maxEntryValuation = baseEntryValuation;

  for (let iter = 0; iter < 40; iter++) {
    const mid = (lowEntry + highEntry) / 2;
    const testItems = items.map((it, idx) => {
      if (idx === entryIdx) {
        return {
          ...it,
          acquisitionCost: it.acquisitionCost > 0 ? mid : 0,
          equityContribution: it.equityContribution > 0 ? mid : 0,
        };
      }
      return it;
    });

    const res = executeReturnsAnalysis(
      testItems,
      assumptions.valuationDate,
      assumptions.dayCount,
      assumptions.cashFlowDriver,
      targetRate
    );

    if (res.xnpv > 0) {
      // Still positive NPV at target rate -> can afford to pay more
      lowEntry = mid;
      maxEntryValuation = mid;
    } else {
      highEntry = mid;
    }
  }

  const entryDiscountRequiredPercent =
    baseEntryValuation > 0
      ? ((baseEntryValuation - maxEntryValuation) / baseEntryValuation) * 100
      : 0;

  return {
    targetIrr: targetRate * 100,
    requiredExitProceeds,
    baseExitProceeds,
    exitProceedsDeltaPercent,
    maxEntryValuation,
    baseEntryValuation,
    entryDiscountRequiredPercent,
  };
}

// Return Attribution decomposition
export function computeReturnAttribution(items: CashFlowItem[]): ReturnAttributionBreakdown {
  let initialEquity = 0;
  let totalDistributions = 0;
  let operatingCashFlowTotal = 0;
  let totalCapex = 0;
  let totalInterest = 0;
  let totalDebtRepaid = 0;
  let totalDebtDrawn = 0;
  let exitProceeds = 0;

  items.forEach((it, idx) => {
    if (idx === 0) {
      initialEquity = it.equityContribution > 0 ? it.equityContribution : it.acquisitionCost - it.debtDrawdown;
    } else {
      if (it.equityContribution > 0) initialEquity += it.equityContribution;
    }
    totalDistributions += it.distribution;
    operatingCashFlowTotal += it.operatingCashFlow;
    totalCapex += it.capitalExpenditure;
    totalInterest += it.interestPaid;
    totalDebtRepaid += it.debtRepayment;
    totalDebtDrawn += it.debtDrawdown;
    exitProceeds += it.exitProceeds;
  });

  const netGain = totalDistributions + exitProceeds - initialEquity;
  const netDeleveraging = Math.max(0, totalDebtRepaid - totalDebtDrawn);

  return {
    initialEquity,
    totalDistributions: totalDistributions + exitProceeds,
    netGain,
    operatingCashFlowComponent: operatingCashFlowTotal - totalCapex,
    deleveragingComponent: netDeleveraging,
    valuationExpansionComponent: Math.max(0, exitProceeds - initialEquity),
    financingCostDrag: totalInterest,
  };
}
