/**
 * RhinoQuant Fund Waterfall & Fee Engine
 * European / American Private Equity Waterfall, Hurdle Rate, Catch-up, and Gross vs Net Returns
 */

import { CashFlowItem } from './types';
import { executeReturnsAnalysis } from './financialMath';

export interface WaterfallConfig {
  committedCapital: number;
  managementFeeRate: number; // e.g. 0.02 (2.0% per annum)
  hurdleRate: number; // e.g. 0.08 (8.0% compound hurdle)
  gpCatchUpRate: number; // e.g. 1.0 (100% catch-up) or 0.8 (80%)
  carriedInterestRate: number; // e.g. 0.20 (20% carry)
  gpCommitmentPercent: number; // e.g. 0.02 (GP commits 2% of capital)
}

export interface WaterfallStepBreakdown {
  periodDate: string;
  grossDistribution: number;
  returnOfCapitalToLp: number;
  preferredReturnToLp: number;
  gpCatchUp: number;
  carriedInterestToGp: number;
  residualToLp: number;
  netDistributionToLp: number;
  netDistributionToGp: number;
}

export interface FundWaterfallResult {
  grossIrr: number | null;
  netLpIrr: number | null;
  gpIrr: number | null;
  grossMoic: number;
  netLpMoic: number;
  totalCalled: number;
  totalDistributed: number;
  totalManagementFees: number;
  totalCarriedInterest: number;
  totalLpProceeds: number;
  totalGpProceeds: number;
  steps: WaterfallStepBreakdown[];
}

export function computeFundWaterfall(
  items: CashFlowItem[],
  valuationDate: string,
  config: WaterfallConfig
): FundWaterfallResult {
  // Sort items
  const sorted = [...items].sort((a, b) => (a.date > b.date ? 1 : -1));

  let cumulativeCapitalCalled = 0;
  let cumulativeCapitalReturned = 0;
  let cumulativePrefAccrued = 0;
  let cumulativePrefPaid = 0;
  let cumulativeCatchUpPaid = 0;
  let cumulativeCarryPaid = 0;
  let totalManagementFees = 0;
  let totalDistributed = 0;

  const steps: WaterfallStepBreakdown[] = [];
  const lpNetFlows: CashFlowItem[] = [];

  let lastDateMs = sorted.length > 0 ? new Date(sorted[0].date).getTime() : new Date().getTime();

  for (let idx = 0; idx < sorted.length; idx++) {
    const item = sorted[idx];
    const itemDateMs = new Date(item.date).getTime();
    const elapsedYears = Math.max(0, (itemDateMs - lastDateMs) / (1000 * 60 * 60 * 24 * 365.0));
    lastDateMs = itemDateMs;

    // Accrue management fee over elapsed period
    const mgmtFee = config.committedCapital * config.managementFeeRate * elapsedYears;
    totalManagementFees += mgmtFee;

    // Accrue preferred return on unreturned capital
    const unreturnedCapital = Math.max(0, cumulativeCapitalCalled - cumulativeCapitalReturned);
    const prefAccrual = unreturnedCapital * config.hurdleRate * elapsedYears;
    cumulativePrefAccrued += prefAccrual;

    const capitalCall = item.equityContribution;
    const grossDist = item.distribution + item.exitProceeds;

    if (capitalCall > 0) {
      cumulativeCapitalCalled += capitalCall;
    }

    let returnOfCap = 0;
    let prefPaid = 0;
    let catchUp = 0;
    let carryPaid = 0;
    let residualLp = 0;

    let available = grossDist;

    if (available > 0) {
      totalDistributed += available;

      // Tier 1: Return of Capital to LP
      const capOwed = Math.max(0, cumulativeCapitalCalled - cumulativeCapitalReturned);
      returnOfCap = Math.min(available, capOwed);
      cumulativeCapitalReturned += returnOfCap;
      available -= returnOfCap;

      // Tier 2: Preferred Return to LP
      if (available > 0) {
        const prefOwed = Math.max(0, cumulativePrefAccrued - cumulativePrefPaid);
        prefPaid = Math.min(available, prefOwed);
        cumulativePrefPaid += prefPaid;
        available -= prefPaid;
      }

      // Tier 3: GP Catch-up
      // Target GP profits so far: carriedInterestRate * (prefPaid + catchUp + carry)
      if (available > 0 && config.gpCatchUpRate > 0) {
        const totalProfitsLP = cumulativePrefPaid;
        const targetGpCarry = (totalProfitsLP / (1 - config.carriedInterestRate)) * config.carriedInterestRate;
        const catchUpOwed = Math.max(0, targetGpCarry - (cumulativeCatchUpPaid + cumulativeCarryPaid));
        catchUp = Math.min(available * config.gpCatchUpRate, catchUpOwed);
        cumulativeCatchUpPaid += catchUp;
        available -= catchUp;
      }

      // Tier 4: Carried Interest split (e.g. 80% LP / 20% GP)
      if (available > 0) {
        carryPaid = available * config.carriedInterestRate;
        residualLp = available * (1 - config.carriedInterestRate);
        cumulativeCarryPaid += carryPaid;
        available = 0;
      }
    }

    const netDistToLp = returnOfCap + prefPaid + residualLp;
    const netDistToGp = catchUp + carryPaid;

    steps.push({
      periodDate: item.date,
      grossDistribution: grossDist,
      returnOfCapitalToLp: returnOfCap,
      preferredReturnToLp: prefPaid,
      gpCatchUp: catchUp,
      carriedInterestToGp: carryPaid,
      residualToLp: residualLp,
      netDistributionToLp: netDistToLp,
      netDistributionToGp: netDistToGp,
    });

    // Create synthetic LP net cash flow item
    lpNetFlows.push({
      ...item,
      equityContribution: capitalCall + (mgmtFee * (1 - config.gpCommitmentPercent)),
      distribution: netDistToLp,
      exitProceeds: 0,
      operatingCashFlow: 0,
      capitalExpenditure: 0,
      acquisitionCost: 0,
      debtDrawdown: 0,
      debtRepayment: 0,
      interestPaid: 0,
    });
  }

  // Calculate gross returns
  const grossResult = executeReturnsAnalysis(
    items,
    valuationDate,
    'ACT_365',
    'fund'
  );

  // Calculate net LP returns
  const netLpResult = executeReturnsAnalysis(
    lpNetFlows,
    valuationDate,
    'ACT_365',
    'fund'
  );

  const totalCarriedInterest = cumulativeCatchUpPaid + cumulativeCarryPaid;
  const totalLpProceeds = steps.reduce((sum, s) => sum + s.netDistributionToLp, 0);
  const totalGpProceeds = steps.reduce((sum, s) => sum + s.netDistributionToGp, 0) + totalManagementFees;

  return {
    grossIrr: grossResult.xirr,
    netLpIrr: netLpResult.xirr,
    gpIrr: null,
    grossMoic: grossResult.moic,
    netLpMoic: netLpResult.moic,
    totalCalled: cumulativeCapitalCalled,
    totalDistributed,
    totalManagementFees,
    totalCarriedInterest,
    totalLpProceeds,
    totalGpProceeds,
    steps,
  };
}
