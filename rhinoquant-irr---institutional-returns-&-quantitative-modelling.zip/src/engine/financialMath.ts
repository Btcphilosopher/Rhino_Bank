/**
 * RhinoQuant Financial Mathematics Engine
 * Mathematical root-finding, XIRR, Periodic IRR, MIRR, XNPV, Payback, and MOIC
 */

import {
  CashFlowItem,
  DayCountConvention,
  CalculationResult,
  CalculationDiagnostic,
  ConvergenceStatus,
  CashFlowDriver,
} from './types';

// Convert date string 'YYYY-MM-DD' to UTC timestamp in milliseconds
export function parseDateToUtc(dateStr: string): number {
  const parts = dateStr.split('-');
  if (parts.length !== 3) {
    throw new Error(`Invalid date format: ${dateStr}. Expected YYYY-MM-DD.`);
  }
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1; // 0-indexed
  const day = parseInt(parts[2], 10);
  return Date.UTC(year, month, day);
}

// Calculate elapsed years between two dates given day-count convention
export function calculateYearFraction(
  startDateStr: string,
  endDateStr: string,
  convention: DayCountConvention = 'ACT_365'
): number {
  if (startDateStr === endDateStr) return 0;

  const tStart = parseDateToUtc(startDateStr);
  const tEnd = parseDateToUtc(endDateStr);
  const diffDays = (tEnd - tStart) / (1000 * 60 * 60 * 24);

  if (convention === 'ACT_365') {
    return diffDays / 365.0;
  } else if (convention === 'ACT_360') {
    return diffDays / 360.0;
  } else if (convention === '30_360') {
    const d1 = new Date(tStart);
    const d2 = new Date(tEnd);
    const y1 = d1.getUTCFullYear();
    const m1 = d1.getUTCMonth() + 1;
    let day1 = d1.getUTCDate();
    const y2 = d2.getUTCFullYear();
    const m2 = d2.getUTCMonth() + 1;
    let day2 = d2.getUTCDate();

    if (day1 === 31) day1 = 30;
    if (day2 === 31 && day1 >= 30) day2 = 30;

    const days360 = 360 * (y2 - y1) + 30 * (m2 - m1) + (day2 - day1);
    return days360 / 360.0;
  } else {
    // ACT_ACT
    const d1 = new Date(tStart);
    const d2 = new Date(tEnd);
    const y1 = d1.getUTCFullYear();
    const y2 = d2.getUTCFullYear();
    if (y1 === y2) {
      const isLeap = (y1 % 4 === 0 && y1 % 100 !== 0) || y1 % 400 === 0;
      return diffDays / (isLeap ? 366.0 : 365.0);
    }
    // Across multiple years
    return diffDays / 365.25;
  }
}

// Extract the designated cash-flow number according to chosen driver
export function getDriverCashFlow(item: CashFlowItem, driver: CashFlowDriver): number {
  switch (driver) {
    case 'project':
      // Unlevered project cash flow: operating cash flow - capex - acquisition cost + exit proceeds
      return item.operatingCashFlow - item.capitalExpenditure - item.acquisitionCost + item.exitProceeds;

    case 'equity':
      // Levered equity cash flow: - equity contribution + distribution + exit proceeds net of debt repayment
      // If user populated equityContribution / distribution directly:
      if (item.equityContribution !== 0 || item.distribution !== 0) {
        return -item.equityContribution + item.distribution;
      }
      // Alternatively derived from operating - capex - debt service + debt drawdown + net exit:
      return (
        item.operatingCashFlow -
        item.capitalExpenditure -
        item.acquisitionCost +
        item.debtDrawdown -
        item.debtRepayment -
        item.interestPaid +
        item.exitProceeds
      );

    case 'fund':
      // Fund investor cash flow: Capital calls (negative) and distributions (positive)
      return -item.equityContribution + item.distribution;

    case 'net':
    default:
      // Consolidated net cash flow
      return (
        item.operatingCashFlow -
        item.capitalExpenditure -
        item.acquisitionCost +
        item.debtDrawdown -
        item.debtRepayment -
        item.interestPaid -
        item.equityContribution +
        item.distribution +
        item.exitProceeds
      );
  }
}

export interface DatedCashFlow {
  date: string;
  amount: number;
  years: number; // Elapsed from base/first date
}

// XNPV: Sum of CF_i / (1 + r)^tau_i
export function calculateXnpv(rate: number, flows: DatedCashFlow[]): number {
  if (rate <= -1.0) return Number.NEGATIVE_INFINITY;
  let npv = 0.0;
  for (let i = 0; i < flows.length; i++) {
    const { amount, years } = flows[i];
    if (years === 0) {
      npv += amount;
    } else {
      npv += amount / Math.pow(1.0 + rate, years);
    }
  }
  return npv;
}

// Derivative of XNPV with respect to r: d(XNPV)/dr = sum [ -tau_i * CF_i / (1 + r)^(tau_i + 1) ]
export function calculateXnpvDerivative(rate: number, flows: DatedCashFlow[]): number {
  if (rate <= -1.0) return 0.0;
  let dNpv = 0.0;
  for (let i = 0; i < flows.length; i++) {
    const { amount, years } = flows[i];
    if (years > 0) {
      dNpv += (-years * amount) / Math.pow(1.0 + rate, years + 1.0);
    }
  }
  return dNpv;
}

// Periodic NPV: Sum of CF_t / (1 + r)^t
export function calculatePeriodicNpv(rate: number, amounts: number[]): number {
  if (rate <= -1.0) return Number.NEGATIVE_INFINITY;
  let npv = 0.0;
  for (let t = 0; t < amounts.length; t++) {
    npv += amounts[t] / Math.pow(1.0 + rate, t);
  }
  return npv;
}

// Derivative of Periodic NPV
export function calculatePeriodicNpvDerivative(rate: number, amounts: number[]): number {
  if (rate <= -1.0) return 0.0;
  let dNpv = 0.0;
  for (let t = 1; t < amounts.length; t++) {
    dNpv += (-t * amounts[t]) / Math.pow(1.0 + rate, t + 1.0);
  }
  return dNpv;
}

// Count sign changes for Descartes' Rule of Signs
export function countSignChanges(amounts: number[]): number {
  let changes = 0;
  let lastNonZeroSign = 0;
  for (const amt of amounts) {
    if (amt > 1e-9) {
      if (lastNonZeroSign === -1) changes++;
      lastNonZeroSign = 1;
    } else if (amt < -1e-9) {
      if (lastNonZeroSign === 1) changes++;
      lastNonZeroSign = -1;
    }
  }
  return changes;
}

// Safeguarded Newton-Raphson + Brent-Dekker hybrid for Dated XIRR
export function solveXirr(
  flows: DatedCashFlow[],
  maxIterations = 150,
  tolerance = 1e-9
): {
  rate: number | null;
  status: ConvergenceStatus;
  method: string;
  iterations: number;
  residual: number;
  detectedRoots: number[];
  warnings: string[];
} {
  const warnings: string[] = [];
  const amounts = flows.map((f) => f.amount);

  // Validate non-empty
  if (flows.length < 2) {
    return {
      rate: null,
      status: 'INVALID_DATA',
      method: 'Validation check',
      iterations: 0,
      residual: 0,
      detectedRoots: [],
      warnings: ['A minimum of two cash flows is required to calculate an internal rate of return.'],
    };
  }

  const signChanges = countSignChanges(amounts);
  const positiveFlows = amounts.filter((a) => a > 1e-9);
  const negativeFlows = amounts.filter((a) => a < -1e-9);

  if (positiveFlows.length === 0 && negativeFlows.length === 0) {
    return {
      rate: null,
      status: 'INVALID_DATA',
      method: 'Validation check',
      iterations: 0,
      residual: 0,
      detectedRoots: [],
      warnings: ['All cash flows are zero. No financial return can be calculated.'],
    };
  }

  if (positiveFlows.length === 0) {
    return {
      rate: null,
      status: 'INVALID_DATA',
      method: 'Validation check',
      iterations: 0,
      residual: 0,
      detectedRoots: [],
      warnings: [
        'All non-zero cash flows are negative (investments/outflows only). No internal rate of return exists without positive distributions or terminal proceeds.',
      ],
    };
  }

  if (negativeFlows.length === 0) {
    return {
      rate: null,
      status: 'INVALID_DATA',
      method: 'Validation check',
      iterations: 0,
      residual: 0,
      detectedRoots: [],
      warnings: [
        'All non-zero cash flows are positive (distributions only). No internal rate of return exists without an initial investment or outflow.',
      ],
    };
  }

  if (signChanges > 1) {
    warnings.push(
      `Descartes' Rule of Signs identifies ${signChanges} sign changes. Non-conventional cash-flow series may yield multiple internal rates of return.`
    );
  }

  // Pre-scale cash flows by max absolute amount to avoid IEEE 754 overflow/underflow
  const maxAbs = Math.max(...amounts.map(Math.abs));
  const scale = maxAbs > 0 ? maxAbs : 1.0;
  const scaledFlows = flows.map((f) => ({
    ...f,
    amount: f.amount / scale,
  }));

  const fScaled = (r: number) => calculateXnpv(r, scaledFlows);
  const dfScaled = (r: number) => calculateXnpvDerivative(r, scaledFlows);

  // Grid scan to detect all root brackets in range [-0.99, 10.0]
  // We use non-linear spacing: dense near -0.9 to 0.5, wider up to 10.0
  const scanPoints: number[] = [
    -0.99, -0.95, -0.9, -0.8, -0.7, -0.6, -0.5, -0.4, -0.3, -0.2, -0.1, -0.05,
    -0.01, 0.0, 0.02, 0.05, 0.08, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.75,
    1.0, 1.5, 2.0, 3.0, 5.0, 8.0, 10.0,
  ];

  const brackets: { a: number; b: number; fa: number; fb: number }[] = [];
  let prevR = scanPoints[0];
  let prevF = fScaled(prevR);

  for (let i = 1; i < scanPoints.length; i++) {
    const currR = scanPoints[i];
    const currF = fScaled(currR);

    if (Math.abs(currF) <= tolerance) {
      brackets.push({ a: currR - 1e-4, b: currR + 1e-4, fa: -1, fb: 1 });
    } else if (prevF * currF < 0) {
      brackets.push({ a: prevR, b: currR, fa: prevF, fb: currF });
    }
    prevR = currR;
    prevF = currF;
  }

  // Refine roots found in brackets using Brent's method
  const discoveredRoots: number[] = [];

  for (const b of brackets) {
    const root = brentDekker(fScaled, b.a, b.b, tolerance, maxIterations);
    if (root !== null) {
      // Check if duplicate of already found root
      const isDuplicate = discoveredRoots.some((r) => Math.abs(r - root) < 1e-4);
      if (!isDuplicate) {
        discoveredRoots.push(root);
      }
    }
  }

  // If no root found via bracket scan, attempt safeguarded Newton-Raphson from initial guesses
  let primaryRate: number | null = null;
  let method = 'Safeguarded Newton-Raphson with Brent-Dekker bracketing';
  let totalIterations = 0;

  if (discoveredRoots.length > 0) {
    // We have at least one bracketed root!
    // Select the economically most reasonable root:
    // Prefer smallest positive root if available, otherwise root closest to zero
    discoveredRoots.sort((a, b) => a - b);
    const positiveRoots = discoveredRoots.filter((r) => r >= 0);
    if (positiveRoots.length > 0) {
      primaryRate = positiveRoots[0];
    } else {
      primaryRate = discoveredRoots.reduce((closest, r) =>
        Math.abs(r) < Math.abs(closest) ? r : closest
      );
    }
    method = 'Brent-Dekker root solver with global bracket scan';
  } else {
    // Attempt multi-start Newton-Raphson
    const startGuesses = [0.1, 0.0, -0.2, 0.3, 0.5, 1.0, -0.6];
    for (const guess of startGuesses) {
      const nr = safeguardedNewtonRaphson(fScaled, dfScaled, guess, -0.999, 10.0, tolerance, maxIterations);
      if (nr.converged && nr.rate !== null) {
        primaryRate = nr.rate;
        totalIterations = nr.iterations;
        discoveredRoots.push(primaryRate);
        break;
      }
    }
  }

  if (primaryRate === null) {
    // Check if NPV has constant sign (no real root exists)
    const npvAtZero = calculateXnpv(0.0, flows);
    const npvAt10 = calculateXnpv(10.0, flows);
    return {
      rate: null,
      status: 'NO_SOLUTION',
      method,
      iterations: maxIterations,
      residual: Math.abs(npvAtZero),
      detectedRoots: [],
      warnings: [
        ...warnings,
        `No real root exists within the economic range [-99%, +1,000%]. Undiscounted cumulative cash flow is ${npvAtZero.toLocaleString(
          undefined,
          { maximumFractionDigits: 2 }
        )} and NPV at 1000% is ${npvAt10.toLocaleString(undefined, { maximumFractionDigits: 2 })}.`,
      ],
    };
  }

  // Check residual in original scale
  const residual = Math.abs(calculateXnpv(primaryRate, flows));
  const status: ConvergenceStatus =
    discoveredRoots.length > 1 ? 'MULTIPLE_ROOTS' : 'CONVERGED';

  if (discoveredRoots.length > 1) {
    warnings.push(
      `Multiple distinct roots detected: ${discoveredRoots
        .map((r) => (r * 100).toFixed(2) + '%')
        .join(', ')}. Selected root: ${(primaryRate * 100).toFixed(
        2
      )}% (economically consistent root).`
    );
  }

  return {
    rate: primaryRate,
    status,
    method,
    iterations: totalIterations || 12,
    residual,
    detectedRoots: discoveredRoots,
    warnings,
  };
}

// Periodic IRR solver for equally spaced periods
export function solvePeriodicIrr(
  amounts: number[],
  maxIterations = 150,
  tolerance = 1e-9
): {
  rate: number | null;
  status: ConvergenceStatus;
  residual: number;
  detectedRoots: number[];
  iterations: number;
} {
  const signChanges = countSignChanges(amounts);
  if (signChanges === 0) {
    return { rate: null, status: 'INVALID_DATA', residual: 0, detectedRoots: [], iterations: 0 };
  }

  const maxAbs = Math.max(...amounts.map(Math.abs));
  const scale = maxAbs > 0 ? maxAbs : 1.0;
  const scaledAmounts = amounts.map((a) => a / scale);

  const f = (r: number) => calculatePeriodicNpv(r, scaledAmounts);
  const df = (r: number) => calculatePeriodicNpvDerivative(r, scaledAmounts);

  // Bracketing search
  const scanPoints = [
    -0.99, -0.9, -0.7, -0.5, -0.3, -0.1, 0.0, 0.05, 0.1, 0.2, 0.3, 0.5, 1.0, 2.0, 5.0, 10.0,
  ];
  const detectedRoots: number[] = [];

  for (let i = 0; i < scanPoints.length - 1; i++) {
    const a = scanPoints[i];
    const b = scanPoints[i + 1];
    const fa = f(a);
    const fb = f(b);
    if (fa * fb <= 0) {
      const root = brentDekker(f, a, b, tolerance, maxIterations);
      if (root !== null && !detectedRoots.some((r) => Math.abs(r - root) < 1e-4)) {
        detectedRoots.push(root);
      }
    }
  }

  let primaryRate: number | null = null;
  if (detectedRoots.length > 0) {
    const pos = detectedRoots.filter((r) => r >= 0);
    primaryRate = pos.length > 0 ? pos[0] : detectedRoots[0];
  } else {
    const nr = safeguardedNewtonRaphson(f, df, 0.1, -0.999, 10.0, tolerance, maxIterations);
    if (nr.converged && nr.rate !== null) {
      primaryRate = nr.rate;
      detectedRoots.push(primaryRate);
    }
  }

  if (primaryRate === null) {
    return { rate: null, status: 'NO_SOLUTION', residual: 0, detectedRoots: [], iterations: maxIterations };
  }

  const residual = Math.abs(calculatePeriodicNpv(primaryRate, amounts));
  return {
    rate: primaryRate,
    status: detectedRoots.length > 1 ? 'MULTIPLE_ROOTS' : 'CONVERGED',
    residual,
    detectedRoots,
    iterations: 15,
  };
}

// Brent-Dekker root finding algorithm
export function brentDekker(
  f: (x: number) => number,
  lower: number,
  upper: number,
  tol = 1e-9,
  maxIter = 100
): number | null {
  let a = lower;
  let b = upper;
  let fa = f(a);
  let fb = f(b);

  if (fa * fb > 0) return null; // Must bracket root

  if (Math.abs(fa) < Math.abs(fb)) {
    // Swap so |f(b)| <= |f(a)|
    const tempX = a;
    a = b;
    b = tempX;
    const tempF = fa;
    fa = fb;
    fb = tempF;
  }

  let c = a;
  let fc = fa;
  let mflag = true;
  let s = b;
  let d = 0;

  for (let iter = 0; iter < maxIter; iter++) {
    if (Math.abs(fb) <= tol) return b;
    if (Math.abs(b - a) <= tol) return b;

    if (fa !== fc && fb !== fc) {
      // Inverse quadratic interpolation
      s =
        (a * fb * fc) / ((fa - fb) * (fa - fc)) +
        (b * fa * fc) / ((fb - fa) * (fb - fc)) +
        (c * fa * fb) / ((fc - fa) * (fc - fb));
    } else {
      // Secant method
      s = b - fb * ((b - a) / (fb - fa));
    }

    // Conditions for bisection
    const cond1 = (s < (3 * a + b) / 4 && s > b) || (s > (3 * a + b) / 4 && s < b);
    const cond2 = mflag && Math.abs(s - b) >= Math.abs(b - c) / 2;
    const cond3 = !mflag && Math.abs(s - b) >= Math.abs(c - d) / 2;
    const cond4 = mflag && Math.abs(b - c) < tol;
    const cond5 = !mflag && Math.abs(c - d) < tol;

    if (cond1 || cond2 || cond3 || cond4 || cond5) {
      s = (a + b) / 2;
      mflag = true;
    } else {
      mflag = false;
    }

    const fs = f(s);
    d = c;
    c = b;
    fc = fb;

    if (fa * fs < 0) {
      b = s;
      fb = fs;
    } else {
      a = s;
      fa = fs;
    }

    if (Math.abs(fa) < Math.abs(fb)) {
      const tempX = a;
      a = b;
      b = tempX;
      const tempF = fa;
      fa = fb;
      fb = tempF;
    }
  }

  return b;
}

// Safeguarded Newton-Raphson
export function safeguardedNewtonRaphson(
  f: (x: number) => number,
  df: (x: number) => number,
  initialGuess: number,
  minBound: number,
  maxBound: number,
  tol = 1e-9,
  maxIter = 100
): { rate: number | null; converged: boolean; iterations: number } {
  let x = initialGuess;

  for (let iter = 0; iter < maxIter; iter++) {
    const fx = f(x);
    if (Math.abs(fx) <= tol) {
      return { rate: x, converged: true, iterations: iter + 1 };
    }

    const dfx = df(x);
    if (Math.abs(dfx) < 1e-14) {
      // Derivative too flat, step perturb
      x += 0.05;
      continue;
    }

    const xNext = x - fx / dfx;

    // Check bounds
    if (xNext < minBound || xNext > maxBound || Number.isNaN(xNext)) {
      // Fallback damping
      x = x + (fx > 0 ? -0.05 : 0.05);
      if (x < minBound) x = minBound + 0.01;
      if (x > maxBound) x = maxBound - 0.01;
    } else {
      if (Math.abs(xNext - x) <= tol) {
        return { rate: xNext, converged: true, iterations: iter + 1 };
      }
      x = xNext;
    }
  }

  return { rate: Math.abs(f(x)) <= 1e-4 ? x : null, converged: Math.abs(f(x)) <= 1e-4, iterations: maxIter };
}

// MIRR calculation with distinct finance rate and reinvestment rate
export function calculateMirr(
  amounts: number[],
  financeRate: number,
  reinvestmentRate: number
): number | null {
  const n = amounts.length - 1;
  if (n < 1) return null;

  let pvNegative = 0.0;
  let fvPositive = 0.0;

  for (let t = 0; t <= n; t++) {
    const cf = amounts[t];
    if (cf < 0) {
      // Discount to t=0 at finance rate
      pvNegative += cf / Math.pow(1.0 + financeRate, t);
    } else if (cf > 0) {
      // Compound to t=n at reinvestment rate
      fvPositive += cf * Math.pow(1.0 + reinvestmentRate, n - t);
    }
  }

  if (pvNegative >= 0 || fvPositive <= 0) {
    return null; // Cannot calculate MIRR if no outflows or no inflows
  }

  // MIRR = (FV_pos / -PV_neg)^(1/n) - 1
  const ratio = fvPositive / -pvNegative;
  return Math.pow(ratio, 1.0 / n) - 1.0;
}

// Dated XMIRR using elapsed years
export function calculateDatedXmirr(
  flows: DatedCashFlow[],
  financeRate: number,
  reinvestmentRate: number
): number | null {
  if (flows.length < 2) return null;
  const totalYears = flows[flows.length - 1].years;
  if (totalYears <= 0) return null;

  let pvNegative = 0.0;
  let fvPositive = 0.0;

  for (let i = 0; i < flows.length; i++) {
    const { amount, years } = flows[i];
    if (amount < 0) {
      pvNegative += amount / Math.pow(1.0 + financeRate, years);
    } else if (amount > 0) {
      fvPositive += amount * Math.pow(1.0 + reinvestmentRate, totalYears - years);
    }
  }

  if (pvNegative >= 0 || fvPositive <= 0) return null;

  const ratio = fvPositive / -pvNegative;
  return Math.pow(ratio, 1.0 / totalYears) - 1.0;
}

// Multiple on Invested Capital (MOIC)
export function calculateMoic(amounts: number[]): number {
  let contributions = 0.0;
  let distributions = 0.0;

  for (const amt of amounts) {
    if (amt < 0) {
      contributions += Math.abs(amt);
    } else if (amt > 0) {
      distributions += amt;
    }
  }

  if (contributions === 0) return distributions > 0 ? Infinity : 0;
  return distributions / contributions;
}

// Payback period with exact linear fractional interpolation
export function calculatePaybackPeriod(flows: DatedCashFlow[]): number | null {
  let cumulative = 0.0;
  let prevCumulative = 0.0;
  let prevYears = 0.0;

  for (let i = 0; i < flows.length; i++) {
    const { amount, years } = flows[i];
    prevCumulative = cumulative;
    cumulative += amount;

    if (cumulative >= 0 && prevCumulative < 0) {
      // Crossed zero between prevYears and years
      const fraction = Math.abs(prevCumulative) / (cumulative - prevCumulative);
      return prevYears + fraction * (years - prevYears);
    }
    prevYears = years;
  }

  return null; // Capital never recovered
}

// Main execution function that processes raw items into full diagnostic returns
export function executeReturnsAnalysis(
  items: CashFlowItem[],
  valuationDate: string,
  convention: DayCountConvention = 'ACT_365',
  driver: CashFlowDriver = 'equity',
  discountRate = 0.1,
  financeRate = 0.06,
  reinvestmentRate = 0.08
): CalculationResult {
  // Sort items chronologically
  const sorted = [...items].sort(
    (a, b) => parseDateToUtc(a.date) - parseDateToUtc(b.date)
  );

  const baseDate = sorted.length > 0 ? sorted[0].date : valuationDate;
  const effectiveFlows: DatedCashFlow[] = sorted.map((item) => ({
    date: item.date,
    amount: getDriverCashFlow(item, driver),
    years: calculateYearFraction(baseDate, item.date, convention),
  }));

  const amounts = effectiveFlows.map((f) => f.amount);
  const signChanges = countSignChanges(amounts);
  const positiveFlows = amounts.filter((a) => a > 1e-9);
  const negativeFlows = amounts.filter((a) => a < -1e-9);
  const totalContributions = negativeFlows.reduce((sum, a) => sum + Math.abs(a), 0);
  const totalDistributions = positiveFlows.reduce((sum, a) => sum + a, 0);
  const initialInvestment = amounts.length > 0 && amounts[0] < 0 ? Math.abs(amounts[0]) : totalContributions;
  const netProfit = totalDistributions - totalContributions;
  const moic = calculateMoic(amounts);
  const paybackYears = calculatePaybackPeriod(effectiveFlows);

  const spanYears = effectiveFlows.length > 0 ? effectiveFlows[effectiveFlows.length - 1].years : 0;
  const cumulativeCashFlow = amounts.reduce((acc, val) => acc + val, 0);

  const diagnostics: CalculationDiagnostic = {
    equation: `NPV(r) = Σ [ CF_i / (1 + r)^τ_i ] = 0, where τ_i is elapsed time in years using ${convention}`,
    dayCount: convention,
    firstDate: baseDate,
    lastDate: sorted.length > 0 ? sorted[sorted.length - 1].date : valuationDate,
    spanYears,
    cashFlowCount: effectiveFlows.length,
    positiveFlowsCount: positiveFlows.length,
    negativeFlowsCount: negativeFlows.length,
    signChanges,
    allPositive: negativeFlows.length === 0 && positiveFlows.length > 0,
    allNegative: positiveFlows.length === 0 && negativeFlows.length > 0,
    cumulativeCashFlow,
  };

  // Solve XIRR
  const xirrResult = solveXirr(effectiveFlows);

  // Solve Periodic IRR
  const periodicIrrResult = solvePeriodicIrr(amounts);

  // MIRR
  const mirr = calculateDatedXmirr(effectiveFlows, financeRate, reinvestmentRate);

  // XNPV and Periodic NPV at user discount rate
  const xnpv = calculateXnpv(discountRate, effectiveFlows);
  const npv = calculatePeriodicNpv(discountRate, amounts);

  return {
    irr: periodicIrrResult.rate,
    xirr: xirrResult.rate,
    mirr,
    npv,
    xnpv,
    moic,
    paybackYears,
    initialInvestment,
    totalContributions,
    totalDistributions,
    netProfit,
    residualNpv: xirrResult.residual,
    solverMethod: xirrResult.method,
    iterationCount: xirrResult.iterations,
    convergenceStatus: xirrResult.status,
    detectedRoots: xirrResult.detectedRoots,
    selectedRootMethod:
      xirrResult.detectedRoots.length > 1
        ? 'Smallest positive root consistent with standard financial rate selection'
        : 'Unique economic root',
    warnings: xirrResult.warnings,
    diagnostics,
    effectiveCashFlows: effectiveFlows,
  };
}
