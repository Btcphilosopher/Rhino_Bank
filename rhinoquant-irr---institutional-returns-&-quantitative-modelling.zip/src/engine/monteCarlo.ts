/**
 * RhinoQuant Monte Carlo Simulation Engine
 * Deterministic pseudo-random number generator, parametric distributions,
 * percentile analysis, and risk metrics.
 */

import { CashFlowItem, EngineAssumptions, MonteCarloParameter, MonteCarloResult } from './types';
import { executeReturnsAnalysis } from './financialMath';

// Seeded PRNG: Mulberry32 for deterministic, reproducible results
export function createRng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s |= 0;
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Sample from Standard Normal distribution using Box-Muller transform
export function sampleStandardNormal(rng: () => number): number {
  let u1 = rng();
  let u2 = rng();
  while (u1 <= 1e-15) u1 = rng(); // Avoid log(0)
  return Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
}

// Sample from parametric distribution
export function sampleDistribution(param: MonteCarloParameter, rng: () => number): number {
  switch (param.distribution) {
    case 'normal': {
      const z = sampleStandardNormal(rng);
      const sigma = param.stdDev ?? 0.15 * param.mean;
      return Math.max(0.01, param.mean + z * sigma);
    }
    case 'lognormal': {
      const sigma = param.stdDev ?? 0.2;
      const mu = Math.log(param.mean) - 0.5 * sigma * sigma;
      const z = sampleStandardNormal(rng);
      return Math.exp(mu + sigma * z);
    }
    case 'triangular': {
      const a = param.min ?? param.mean * 0.7;
      const b = param.max ?? param.mean * 1.3;
      const c = param.mode ?? param.mean;
      const u = rng();
      const fc = (c - a) / (b - a);
      if (u < fc) {
        return a + Math.sqrt(u * (b - a) * (c - a));
      } else {
        return b - Math.sqrt((1 - u) * (b - a) * (b - c));
      }
    }
    case 'uniform':
    default: {
      const min = param.min ?? param.mean * 0.8;
      const max = param.max ?? param.mean * 1.2;
      return min + rng() * (max - min);
    }
  }
}

// Compute percentile of sorted array
export function computePercentile(sorted: number[], p: number): number {
  if (sorted.length === 0) return 0;
  const index = (p / 100) * (sorted.length - 1);
  const lower = Math.floor(index);
  const upper = Math.ceil(index);
  const weight = index - lower;
  if (lower === upper) return sorted[lower];
  return sorted[lower] * (1 - weight) + sorted[upper] * weight;
}

// Run Monte Carlo simulation
export function runMonteCarloSimulation(
  items: CashFlowItem[],
  assumptions: EngineAssumptions,
  params: MonteCarloParameter[],
  iterations = 500,
  seed = 42
): MonteCarloResult {
  const rng = createRng(seed);
  const irrValues: number[] = [];
  const npvValues: number[] = [];
  const moicValues: number[] = [];

  let invalidRuns = 0;

  for (let iter = 0; iter < iterations; iter++) {
    // Generate sampled multipliers
    let exitMult = 1.0;
    let revMult = 1.0;
    let opexMult = 1.0;
    let capexMult = 1.0;
    let debtDelta = 0.0;

    for (const p of params) {
      const sampledVal = sampleDistribution(p, rng);
      if (p.key === 'exitValuationMultiplier') exitMult = sampledVal;
      else if (p.key === 'revenueGrowthMultiplier') revMult = sampledVal;
      else if (p.key === 'opexMultiplier') opexMult = sampledVal;
      else if (p.key === 'capexMultiplier') capexMult = sampledVal;
      else if (p.key === 'debtCostDelta') debtDelta = sampledVal - 1.0;
    }

    // Apply to cash flows
    const simFlows = items.map((it, idx) => {
      const clone = { ...it };
      if (clone.exitProceeds > 0 || idx === items.length - 1) {
        clone.exitProceeds = clone.exitProceeds * exitMult;
      }
      if (clone.operatingCashFlow > 0) {
        clone.operatingCashFlow = clone.operatingCashFlow * revMult;
      }
      clone.capitalExpenditure = clone.capitalExpenditure * capexMult;
      clone.interestPaid = clone.interestPaid * (1.0 + debtDelta);
      return clone;
    });

    const res = executeReturnsAnalysis(
      simFlows,
      assumptions.valuationDate,
      assumptions.dayCount,
      assumptions.cashFlowDriver,
      assumptions.discountRate,
      assumptions.financeRate,
      assumptions.reinvestmentRate
    );

    if (res.xirr !== null && !isNaN(res.xirr) && isFinite(res.xirr)) {
      irrValues.push(res.xirr * 100);
      npvValues.push(res.xnpv);
      moicValues.push(res.moic);
    } else {
      invalidRuns++;
    }
  }

  // Sort values for statistics
  irrValues.sort((a, b) => a - b);
  npvValues.sort((a, b) => a - b);
  moicValues.sort((a, b) => a - b);

  const successfulRuns = irrValues.length;

  const meanIrr =
    successfulRuns > 0
      ? irrValues.reduce((sum, v) => sum + v, 0) / successfulRuns
      : null;

  const medianIrr = successfulRuns > 0 ? computePercentile(irrValues, 50) : null;
  const p5Irr = successfulRuns > 0 ? computePercentile(irrValues, 5) : null;
  const p10Irr = successfulRuns > 0 ? computePercentile(irrValues, 10) : null;
  const p25Irr = successfulRuns > 0 ? computePercentile(irrValues, 25) : null;
  const p75Irr = successfulRuns > 0 ? computePercentile(irrValues, 75) : null;
  const p90Irr = successfulRuns > 0 ? computePercentile(irrValues, 90) : null;
  const p95Irr = successfulRuns > 0 ? computePercentile(irrValues, 95) : null;

  const probNegativeNpv =
    npvValues.length > 0
      ? (npvValues.filter((v) => v < 0).length / npvValues.length) * 100
      : 0;

  const probLossOfCapital =
    moicValues.length > 0
      ? (moicValues.filter((v) => v < 1.0).length / moicValues.length) * 100
      : 0;

  // Build histogram for IRR distribution
  const histogram: { binStart: number; binEnd: number; count: number }[] = [];
  if (successfulRuns > 0) {
    const minVal = irrValues[0];
    const maxVal = irrValues[irrValues.length - 1];
    const binCount = Math.min(20, Math.max(10, Math.floor(Math.sqrt(successfulRuns))));
    const binWidth = (maxVal - minVal) / (binCount || 1);

    for (let i = 0; i < binCount; i++) {
      const bStart = minVal + i * binWidth;
      const bEnd = i === binCount - 1 ? maxVal + 1e-6 : minVal + (i + 1) * binWidth;
      const count = irrValues.filter((v) => v >= bStart && v < bEnd).length;
      histogram.push({ binStart: bStart, binEnd: bEnd, count });
    }
  }

  return {
    iterations,
    seed,
    successfulRuns,
    invalidRuns,
    irrValues,
    npvValues,
    moicValues,
    meanIrr,
    medianIrr,
    p5Irr,
    p10Irr,
    p25Irr,
    p75Irr,
    p90Irr,
    p95Irr,
    probNegativeNpv,
    probLossOfCapital,
    histogram,
  };
}
