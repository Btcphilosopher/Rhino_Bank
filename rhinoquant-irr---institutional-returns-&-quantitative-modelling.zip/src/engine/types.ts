/**
 * RhinoQuant IRR - Core Engine Types
 * Institutional Investment Returns & Quantitative Modelling Platform
 */

export type DayCountConvention = 'ACT_365' | 'ACT_360' | '30_360' | 'ACT_ACT';

export type CashFlowCategory =
  | 'acquisition'
  | 'capex'
  | 'operating'
  | 'debt_drawdown'
  | 'debt_service'
  | 'equity_contribution'
  | 'distribution'
  | 'exit'
  | 'custom';

export type CashFlowDriver = 'equity' | 'project' | 'net' | 'fund';

export interface CashFlowItem {
  id: string;
  date: string; // YYYY-MM-DD
  description: string;
  category: CashFlowCategory;
  operatingCashFlow: number;
  capitalExpenditure: number;
  acquisitionCost: number;
  debtDrawdown: number;
  debtRepayment: number;
  interestPaid: number;
  equityContribution: number;
  distribution: number;
  exitProceeds: number;
}

export interface EngineAssumptions {
  valuationDate: string;
  discountRate: number; // e.g. 0.10 (10%)
  financeRate: number; // For MIRR, e.g. 0.06
  reinvestmentRate: number; // For MIRR, e.g. 0.08
  hurdleRate: number; // For fund waterfall / hurdle comparisons, e.g. 0.08
  targetIrr: number; // For break-even & reverse valuation, e.g. 0.15
  dayCount: DayCountConvention;
  cashFlowDriver: CashFlowDriver;
  exitValuationMultiplier: number; // 1.0 = 100% of base
  exitDateShiftYears: number; // 0 = base date
}

export type ConvergenceStatus =
  | 'CONVERGED'
  | 'MULTIPLE_ROOTS'
  | 'NO_SOLUTION'
  | 'NUMERICAL_FAILURE'
  | 'INVALID_DATA';

export interface CalculationDiagnostic {
  equation: string;
  dayCount: DayCountConvention;
  firstDate: string;
  lastDate: string;
  spanYears: number;
  cashFlowCount: number;
  positiveFlowsCount: number;
  negativeFlowsCount: number;
  signChanges: number;
  allPositive: boolean;
  allNegative: boolean;
  cumulativeCashFlow: number;
}

export interface CalculationResult {
  irr: number | null; // Periodic IRR (annualized)
  xirr: number | null; // Exact dated XIRR
  mirr: number | null; // Modified IRR
  npv: number; // Periodic NPV at discountRate
  xnpv: number; // Dated XNPV at discountRate
  moic: number; // Multiple on Invested Capital
  paybackYears: number | null; // Exact time to recover initial capital
  initialInvestment: number;
  totalContributions: number;
  totalDistributions: number;
  netProfit: number;
  residualNpv: number; // |NPV(XIRR)| at convergence
  solverMethod: string;
  iterationCount: number;
  convergenceStatus: ConvergenceStatus;
  detectedRoots: number[];
  selectedRootMethod: string;
  warnings: string[];
  diagnostics: CalculationDiagnostic;
  effectiveCashFlows: { date: string; amount: number; years: number }[];
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  isBase: boolean;
  modifications: {
    revenueGrowthMultiplier?: number;
    opexMultiplier?: number;
    exitValuationMultiplier?: number;
    capexMultiplier?: number;
    debtCostDelta?: number; // e.g. +0.01 (+100 bps)
    exitDateShiftYears?: number;
  };
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  field: string;
  oldValue: string;
  newValue: string;
}

export interface MonteCarloParameter {
  name: string;
  key: 'exitValuationMultiplier' | 'revenueGrowthMultiplier' | 'opexMultiplier' | 'capexMultiplier' | 'debtCostDelta';
  distribution: 'normal' | 'lognormal' | 'triangular' | 'uniform';
  mean: number;
  stdDev?: number;
  min?: number;
  max?: number;
  mode?: number;
}

export interface MonteCarloResult {
  iterations: number;
  seed: number;
  successfulRuns: number;
  invalidRuns: number;
  irrValues: number[];
  npvValues: number[];
  moicValues: number[];
  meanIrr: number | null;
  medianIrr: number | null;
  p5Irr: number | null;
  p10Irr: number | null;
  p25Irr: number | null;
  p75Irr: number | null;
  p90Irr: number | null;
  p95Irr: number | null;
  probNegativeNpv: number;
  probLossOfCapital: number;
  histogram: { binStart: number; binEnd: number; count: number }[];
}

export interface ProjectModel {
  id: string;
  name: string;
  templateType: string;
  currency: string;
  createdDate: string;
  lastModifiedDate: string;
  assumptions: EngineAssumptions;
  cashFlows: CashFlowItem[];
  scenarios: ScenarioDefinition[];
  activeScenarioId: string;
  auditTrail: AuditEntry[];
}
