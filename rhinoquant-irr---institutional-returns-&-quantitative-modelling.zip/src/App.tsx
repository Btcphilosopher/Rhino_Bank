/**
 * RhinoQuant IRR - Institutional Investment Returns & Quantitative Modelling Platform
 * Master Application Architecture
 */

import React, { useState, useMemo, useEffect } from 'react';
import { ProjectModel, CashFlowItem, EngineAssumptions, ScenarioDefinition } from './engine/types';
import { INVESTMENT_TEMPLATES, createProjectFromTemplate } from './engine/templates';
import { executeReturnsAnalysis } from './engine/financialMath';
import { computeReturnAttribution } from './engine/sensitivity';
import { Header, ActiveNavTab } from './components/Header';
import { KpiStrip } from './components/KpiStrip';
import { CashFlowTable } from './components/CashFlowTable';
import { InteractiveCharts } from './components/InteractiveCharts';
import { DiagnosticsPanel } from './components/DiagnosticsPanel';
import { ScenarioEngine } from './components/ScenarioEngine';
import { QuantAnalytics } from './components/QuantAnalytics';
import { FundWaterfallView } from './components/FundWaterfallView';
import { TestRunnerModal } from './components/TestRunnerModal';
import { InvestmentReportModal } from './components/InvestmentReportModal';
import { CommandPalette } from './components/CommandPalette';
import { formatCurrency, formatPercent } from './utils/formatters';
import {
  ShieldCheck,
  RotateCcw,
  Sparkles,
  Layers,
  History,
  TrendingUp,
  Sliders,
  HelpCircle,
} from 'lucide-react';

export default function App() {
  // Active Project Model
  const [project, setProject] = useState<ProjectModel>(() =>
    createProjectFromTemplate('lbo_private_equity')
  );

  // Active View Tab in Workstation
  const [activeTab, setActiveTab] = useState<ActiveNavTab>('workstation');

  // Modals state
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);

  // Keyboard shortcut listener for ⌘K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Compute returns dynamically from current cash flows and assumptions
  const calculationResult = useMemo(() => {
    return executeReturnsAnalysis(
      project.cashFlows,
      project.assumptions.valuationDate,
      project.assumptions.dayCount,
      project.assumptions.cashFlowDriver,
      project.assumptions.discountRate,
      project.assumptions.financeRate,
      project.assumptions.reinvestmentRate
    );
  }, [project.cashFlows, project.assumptions]);

  // Compute return attribution
  const returnAttribution = useMemo(() => {
    return computeReturnAttribution(project.cashFlows);
  }, [project.cashFlows]);

  // Handle template selection
  const handleSelectTemplate = (templateId: string) => {
    const fresh = createProjectFromTemplate(templateId);
    setProject(fresh);
  };

  // Handle cash flows updates
  const handleUpdateCashFlows = (newItems: CashFlowItem[]) => {
    setProject((prev) => ({
      ...prev,
      cashFlows: newItems,
      lastModifiedDate: new Date().toISOString(),
      auditTrail: [
        {
          id: `aud-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: 'Investment Analyst',
          action: 'CASH_FLOW_EDIT',
          field: 'cashFlows',
          oldValue: `${prev.cashFlows.length} rows`,
          newValue: `${newItems.length} rows`,
        },
        ...prev.auditTrail.slice(0, 49),
      ],
    }));
  };

  // Handle driver change
  const handleUpdateDriver = (driver: any) => {
    setProject((prev) => ({
      ...prev,
      assumptions: {
        ...prev.assumptions,
        cashFlowDriver: driver,
      },
      auditTrail: [
        {
          id: `aud-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: 'Investment Analyst',
          action: 'DRIVER_SWITCH',
          field: 'cashFlowDriver',
          oldValue: prev.assumptions.cashFlowDriver,
          newValue: driver,
        },
        ...prev.auditTrail.slice(0, 49),
      ],
    }));
  };

  // Handle assumptions update
  const handleUpdateAssumptions = (newAssumptions: EngineAssumptions) => {
    setProject((prev) => ({
      ...prev,
      assumptions: newAssumptions,
      lastModifiedDate: new Date().toISOString(),
      auditTrail: [
        {
          id: `aud-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: 'Risk Officer',
          action: 'ASSUMPTION_UPDATE',
          field: 'assumptions',
          oldValue: `${prev.assumptions.dayCount} / ${prev.assumptions.discountRate}`,
          newValue: `${newAssumptions.dayCount} / ${newAssumptions.discountRate}`,
        },
        ...prev.auditTrail.slice(0, 49),
      ],
    }));
  };

  // Handle scenario selection and apply its adjustments
  const handleSelectScenario = (scenarioId: string) => {
    const targetScen = project.scenarios.find((s) => s.id === scenarioId);
    if (!targetScen) return;

    // Reset base template flows first, then apply modifications
    const baseTemplate = INVESTMENT_TEMPLATES.find((t) => t.id === project.templateType) || INVESTMENT_TEMPLATES[0];
    const mods = targetScen.modifications;

    const exitMult = mods.exitValuationMultiplier ?? 1.0;
    const revMult = mods.revenueGrowthMultiplier ?? 1.0;
    const opexMult = mods.opexMultiplier ?? 1.0;
    const capexMult = mods.capexMultiplier ?? 1.0;
    const debtDelta = mods.debtCostDelta ?? 0.0;
    const timeShift = mods.exitDateShiftYears ?? 0;

    const adjustedItems = baseTemplate.cashFlows.map((item, idx) => {
      const isLast = idx === baseTemplate.cashFlows.length - 1;
      const clone = { ...item };

      if (clone.exitProceeds > 0 || isLast) {
        clone.exitProceeds = clone.exitProceeds * exitMult;
        if (timeShift !== 0) {
          const dt = new Date(clone.date);
          dt.setUTCFullYear(dt.getUTCFullYear() + timeShift);
          clone.date = dt.toISOString().split('T')[0];
        }
      }

      if (clone.operatingCashFlow > 0) {
        clone.operatingCashFlow = clone.operatingCashFlow * revMult - clone.operatingCashFlow * (opexMult - 1);
      }

      clone.capitalExpenditure = clone.capitalExpenditure * capexMult;
      clone.interestPaid = clone.interestPaid * (1.0 + debtDelta * 5);

      return clone;
    });

    setProject((prev) => ({
      ...prev,
      activeScenarioId: scenarioId,
      cashFlows: adjustedItems,
      auditTrail: [
        {
          id: `aud-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: 'Portfolio Manager',
          action: 'SCENARIO_SWITCH',
          field: 'activeScenarioId',
          oldValue: prev.activeScenarioId,
          newValue: scenarioId,
        },
        ...prev.auditTrail.slice(0, 49),
      ],
    }));
  };

  // Command palette actions list
  const paletteActions = [
    {
      id: 'tab-workstation',
      category: 'Navigation',
      label: 'Switch to Modelling Workstation',
      run: () => setActiveTab('workstation'),
    },
    {
      id: 'tab-scenarios',
      category: 'Navigation',
      label: 'Switch to Scenario Engine',
      run: () => setActiveTab('scenarios'),
    },
    {
      id: 'tab-quant',
      category: 'Navigation',
      label: 'Switch to Quantitative Risk & Monte Carlo',
      run: () => setActiveTab('quant_risk'),
    },
    {
      id: 'tab-waterfall',
      category: 'Navigation',
      label: 'Switch to Fund Waterfall & Carried Interest',
      run: () => setActiveTab('waterfall'),
    },
    {
      id: 'open-tests',
      category: 'Audit',
      label: 'Run Mathematical Verification Test Suite',
      run: () => setIsTestModalOpen(true),
    },
    {
      id: 'open-memo',
      category: 'Report',
      label: 'Generate Investment Committee Memorandum',
      run: () => setIsReportModalOpen(true),
    },
    ...INVESTMENT_TEMPLATES.map((tmpl) => ({
      id: `tmpl-${tmpl.id}`,
      category: 'Load Template',
      label: `${tmpl.name} (${tmpl.assetClass})`,
      run: () => handleSelectTemplate(tmpl.id),
    })),
  ];

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-200 flex flex-col font-sans selection:bg-sky-500/30 selection:text-sky-200">
      {/* 3-Zone Top Bar */}
      <Header
        activeTab={activeTab}
        onSelectTab={(tab) => {
          if (tab === 'tests') {
            setIsTestModalOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        onOpenReport={() => setIsReportModalOpen(true)}
        onOpenTests={() => setIsTestModalOpen(true)}
        onOpenCommandPalette={() => setIsPaletteOpen(true)}
      />

      {/* Secondary Sub-Toolbar: Project Selector & Scenario Switcher */}
      <div className="px-5 py-2.5 bg-[#0f172a] border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Left: Project Template & Scenario */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Template Selector */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded">
            <span className="text-[11px] text-slate-400 font-mono">Template:</span>
            <select
              value={project.templateType}
              onChange={(e) => handleSelectTemplate(e.target.value)}
              className="bg-transparent font-medium text-slate-100 focus:outline-none cursor-pointer"
            >
              {INVESTMENT_TEMPLATES.map((tmpl) => (
                <option key={tmpl.id} value={tmpl.id} className="bg-slate-900 text-slate-200">
                  {tmpl.name}
                </option>
              ))}
            </select>
          </div>

          {/* Scenario Selector */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded">
            <span className="text-[11px] text-slate-400 font-mono">Scenario:</span>
            <select
              value={project.activeScenarioId}
              onChange={(e) => handleSelectScenario(e.target.value)}
              className="bg-transparent font-medium text-sky-400 focus:outline-none cursor-pointer"
            >
              {project.scenarios.map((scen) => (
                <option key={scen.id} value={scen.id} className="bg-slate-900 text-slate-200">
                  {scen.name}
                </option>
              ))}
            </select>
          </div>

          {/* Valuation Date Indicator */}
          <div className="hidden sm:flex items-center gap-1 text-slate-400 font-mono text-[11px]">
            <span>Valuation Date:</span>
            <span className="text-slate-200">{project.assumptions.valuationDate}</span>
          </div>
        </div>

        {/* Right: Convergence Status Badge & Quick Actions */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <button
            onClick={() => setIsTestModalOpen(true)}
            className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition-colors"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Mathematical Engine: 8/8 Tests Passing</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <main className="flex-1 p-5 space-y-4 max-w-[1680px] w-full mx-auto">
        {/* KPI Strip (Always visible across all tabs for institutional situational awareness) */}
        <KpiStrip
          result={calculationResult}
          currency={project.currency}
          discountRate={project.assumptions.discountRate}
        />

        {/* TAB 1: Main Modelling Workstation */}
        {activeTab === 'workstation' && (
          <div className="space-y-4">
            {/* 2-Column Core Split: Cash Flow Editor & Analytics/Charts */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 items-stretch">
              {/* Left Column: Full Spreadsheet-Grade Cash Flow Ledger (7 cols on large screens) */}
              <div className="xl:col-span-7 h-full">
                <CashFlowTable
                  items={project.cashFlows}
                  driver={project.assumptions.cashFlowDriver}
                  currency={project.currency}
                  onUpdateItems={handleUpdateCashFlows}
                  onUpdateDriver={handleUpdateDriver}
                />
              </div>

              {/* Right Column: Interactive Charts & Solver Diagnostics (5 cols on large screens) */}
              <div className="xl:col-span-5 flex flex-col space-y-4 h-full">
                {/* Visualisations Canvas */}
                <InteractiveCharts result={calculationResult} currency={project.currency} />

                {/* Mathematical Diagnostics & Parameter Controls */}
                <div className="flex-1 min-h-[300px]">
                  <DiagnosticsPanel
                    result={calculationResult}
                    assumptions={project.assumptions}
                    currency={project.currency}
                    onUpdateAssumptions={handleUpdateAssumptions}
                  />
                </div>
              </div>
            </div>

            {/* Bottom Analysis Area: Return Attribution Breakdown & Audit History */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Return Attribution Decomposition */}
              <div className="lg:col-span-2 bg-[#0f172a] border border-slate-800 rounded-lg p-4 space-y-3">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <h3 className="text-xs font-semibold text-slate-100 uppercase tracking-wider font-mono flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-sky-400" />
                    Return Attribution Decomposition
                  </h3>
                  <span className="text-[11px] font-mono text-slate-500">
                    Net Profit: {formatCurrency(returnAttribution.netGain, project.currency)}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Operating Generation</span>
                    <span className="text-emerald-400 font-bold block my-0.5">
                      {formatCurrency(returnAttribution.operatingCashFlowComponent, project.currency, true)}
                    </span>
                    <span className="text-[10px] text-slate-500">Net Operating CF</span>
                  </div>

                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Deleveraging Paydown</span>
                    <span className="text-sky-300 font-bold block my-0.5">
                      {formatCurrency(returnAttribution.deleveragingComponent, project.currency, true)}
                    </span>
                    <span className="text-[10px] text-slate-500">Debt Reduction</span>
                  </div>

                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Valuation Expansion</span>
                    <span className="text-emerald-300 font-bold block my-0.5">
                      {formatCurrency(returnAttribution.valuationExpansionComponent, project.currency, true)}
                    </span>
                    <span className="text-[10px] text-slate-500">Exit Value Growth</span>
                  </div>

                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Financing Cost Drag</span>
                    <span className="text-rose-400 font-bold block my-0.5">
                      -{formatCurrency(returnAttribution.financingCostDrag, project.currency, true)}
                    </span>
                    <span className="text-[10px] text-slate-500">Interest Paid</span>
                  </div>
                </div>
              </div>

              {/* Audit Trail */}
              <div className="bg-[#0f172a] border border-slate-800 rounded-lg p-4 space-y-3 flex flex-col">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <h3 className="text-xs font-semibold text-slate-100 uppercase tracking-wider font-mono flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-slate-400" />
                    Assumption Audit Log
                  </h3>
                  <span className="text-[10px] font-mono text-slate-500">
                    {project.auditTrail.length} Events
                  </span>
                </div>

                <div className="flex-1 overflow-y-auto max-h-40 space-y-1.5 font-mono text-[11px]">
                  {project.auditTrail.slice(0, 8).map((aud) => (
                    <div
                      key={aud.id}
                      className="p-1.5 bg-slate-900/60 rounded border border-slate-800/80 flex justify-between items-center text-[10px]"
                    >
                      <div>
                        <span className="text-sky-400 font-semibold">{aud.action}</span>
                        <span className="text-slate-500 mx-1">·</span>
                        <span className="text-slate-300">{aud.newValue}</span>
                      </div>
                      <span className="text-slate-500">{aud.timestamp.slice(11, 19)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Multi-Scenario Engine */}
        {activeTab === 'scenarios' && (
          <ScenarioEngine
            baseItems={project.cashFlows}
            scenarios={project.scenarios}
            activeScenarioId={project.activeScenarioId}
            assumptions={project.assumptions}
            currency={project.currency}
            onSelectScenario={handleSelectScenario}
            onUpdateScenarios={(scens) => setProject((prev) => ({ ...prev, scenarios: scens }))}
          />
        )}

        {/* TAB 3: Quantitative Risk & Monte Carlo */}
        {activeTab === 'quant_risk' && (
          <QuantAnalytics
            items={project.cashFlows}
            assumptions={project.assumptions}
            currency={project.currency}
          />
        )}

        {/* TAB 4: Fund Waterfall & Fees */}
        {activeTab === 'waterfall' && (
          <FundWaterfallView
            items={project.cashFlows}
            valuationDate={project.assumptions.valuationDate}
            currency={project.currency}
          />
        )}
      </main>

      {/* Modals */}
      <TestRunnerModal isOpen={isTestModalOpen} onClose={() => setIsTestModalOpen(false)} />

      <InvestmentReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        project={project}
        result={calculationResult}
      />

      <CommandPalette
        isOpen={isPaletteOpen}
        onClose={() => setIsPaletteOpen(false)}
        actions={paletteActions}
      />
    </div>
  );
}
