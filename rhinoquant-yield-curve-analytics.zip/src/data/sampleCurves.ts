/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Institutional Sample Datasets & 5-Year Term Structure Time Series
 * Namespace: rhinoquant::datasets
 */

import { RhinoCurve, TimeSeriesCurvePoint } from '../types/rhino';

export const STANDARD_TENORS = [
  { tenor: '1M', maturity: 0.0833 },
  { tenor: '3M', maturity: 0.25 },
  { tenor: '6M', maturity: 0.5 },
  { tenor: '1Y', maturity: 1.0 },
  { tenor: '2Y', maturity: 2.0 },
  { tenor: '3Y', maturity: 3.0 },
  { tenor: '5Y', maturity: 5.0 },
  { tenor: '7Y', maturity: 7.0 },
  { tenor: '10Y', maturity: 10.0 },
  { tenor: '20Y', maturity: 20.0 },
  { tenor: '30Y', maturity: 30.0 },
];

export const PRESET_CURVES: RhinoCurve[] = [
  {
    id: 'us_treasury_benchmark',
    name: 'US Treasury Benchmark (Positively Sloped)',
    timestamp: '2026-08-24 16:30:00 EST',
    currency: 'USD',
    type: 'Observed',
    units: 'PERCENT',
    source: 'Federal Reserve H.15 / Refinitiv ICAP',
    interpolationMethod: 'MonotoneSpline',
    model: 'Spline',
    version: 'rhinoquant::v3.4.1',
    scenario: 'Baseline',
    points: [
      { tenor: '1M', maturity: 0.0833, yield: 3.75 },
      { tenor: '3M', maturity: 0.25, yield: 3.82 },
      { tenor: '6M', maturity: 0.5, yield: 3.91 },
      { tenor: '1Y', maturity: 1.0, yield: 4.02 },
      { tenor: '2Y', maturity: 2.0, yield: 4.15 },
      { tenor: '3Y', maturity: 3.0, yield: 4.24 },
      { tenor: '5Y', maturity: 5.0, yield: 4.38 },
      { tenor: '7Y', maturity: 7.0, yield: 4.48 },
      { tenor: '10Y', maturity: 10.0, yield: 4.62 },
      { tenor: '20Y', maturity: 20.0, yield: 4.88 },
      { tenor: '30Y', maturity: 30.0, yield: 4.95 },
    ],
  },
  {
    id: 'us_treasury_inverted_2023',
    name: 'US Treasury Inverted Curve (2023 Tightening Cycle)',
    timestamp: '2023-07-03 17:00:00 EST',
    currency: 'USD',
    type: 'Observed',
    units: 'PERCENT',
    source: 'Historical Archive US Treasury',
    interpolationMethod: 'NelsonSiegel',
    model: 'NelsonSiegel',
    version: 'rhinoquant::v3.4.1',
    scenario: '2023 Deep Inversion',
    points: [
      { tenor: '1M', maturity: 0.0833, yield: 5.24 },
      { tenor: '3M', maturity: 0.25, yield: 5.42 },
      { tenor: '6M', maturity: 0.5, yield: 5.48 },
      { tenor: '1Y', maturity: 1.0, yield: 5.40 },
      { tenor: '2Y', maturity: 2.0, yield: 4.94 },
      { tenor: '3Y', maturity: 3.0, yield: 4.58 },
      { tenor: '5Y', maturity: 5.0, yield: 4.18 },
      { tenor: '7Y', maturity: 7.0, yield: 4.02 },
      { tenor: '10Y', maturity: 10.0, yield: 3.86 },
      { tenor: '20Y', maturity: 20.0, yield: 4.08 },
      { tenor: '30Y', maturity: 30.0, yield: 3.88 },
    ],
  },
  {
    id: 'humped_curve_cycle',
    name: 'Humped Curve (Mid-Cycle Fed Pause & Terminal Peak)',
    timestamp: '2024-11-15 16:30:00 EST',
    currency: 'USD',
    type: 'Synthetic',
    units: 'PERCENT',
    source: 'Proprietary Stress Test Library',
    interpolationMethod: 'Svensson',
    model: 'Svensson',
    version: 'rhinoquant::v3.4.1',
    scenario: 'Humped Formation',
    points: [
      { tenor: '1M', maturity: 0.0833, yield: 4.10 },
      { tenor: '3M', maturity: 0.25, yield: 4.35 },
      { tenor: '6M', maturity: 0.5, yield: 4.70 },
      { tenor: '1Y', maturity: 1.0, yield: 5.15 },
      { tenor: '2Y', maturity: 2.0, yield: 5.38 },
      { tenor: '3Y', maturity: 3.0, yield: 5.22 },
      { tenor: '5Y', maturity: 5.0, yield: 4.80 },
      { tenor: '7Y', maturity: 7.0, yield: 4.55 },
      { tenor: '10Y', maturity: 10.0, yield: 4.35 },
      { tenor: '20Y', maturity: 20.0, yield: 4.25 },
      { tenor: '30Y', maturity: 30.0, yield: 4.20 },
    ],
  },
  {
    id: 'u_shaped_basin',
    name: 'U-Shaped / Sagging Belly Basin Curve',
    timestamp: '2025-04-10 16:30:00 EST',
    currency: 'USD',
    type: 'Synthetic',
    units: 'PERCENT',
    source: 'RhinoQuant Quantitative Labs',
    interpolationMethod: 'Svensson',
    model: 'Svensson',
    version: 'rhinoquant::v3.4.1',
    scenario: 'U-Shaped Formation',
    points: [
      { tenor: '1M', maturity: 0.0833, yield: 4.90 },
      { tenor: '3M', maturity: 0.25, yield: 4.85 },
      { tenor: '6M', maturity: 0.5, yield: 4.60 },
      { tenor: '1Y', maturity: 1.0, yield: 4.10 },
      { tenor: '2Y', maturity: 2.0, yield: 3.65 },
      { tenor: '3Y', maturity: 3.0, yield: 3.52 },
      { tenor: '5Y', maturity: 5.0, yield: 3.75 },
      { tenor: '7Y', maturity: 7.0, yield: 4.10 },
      { tenor: '10Y', maturity: 10.0, yield: 4.45 },
      { tenor: '20Y', maturity: 20.0, yield: 4.80 },
      { tenor: '30Y', maturity: 30.0, yield: 5.05 },
    ],
  },
  {
    id: 'double_humped_complex',
    name: 'Double-Humped Complex Term Structure',
    timestamp: '2025-09-20 16:30:00 EST',
    currency: 'USD',
    type: 'Synthetic',
    units: 'PERCENT',
    source: 'RhinoQuant Multi-Factor NSS',
    interpolationMethod: 'Svensson',
    model: 'Svensson',
    version: 'rhinoquant::v3.4.1',
    scenario: 'Double-Hump Formation',
    points: [
      { tenor: '1M', maturity: 0.0833, yield: 3.80 },
      { tenor: '3M', maturity: 0.25, yield: 4.10 },
      { tenor: '6M', maturity: 0.5, yield: 4.65 },
      { tenor: '1Y', maturity: 1.0, yield: 4.90 },
      { tenor: '2Y', maturity: 2.0, yield: 4.55 },
      { tenor: '3Y', maturity: 3.0, yield: 4.25 },
      { tenor: '5Y', maturity: 5.0, yield: 4.15 },
      { tenor: '7Y', maturity: 7.0, yield: 4.45 },
      { tenor: '10Y', maturity: 10.0, yield: 4.85 },
      { tenor: '20Y', maturity: 20.0, yield: 4.70 },
      { tenor: '30Y', maturity: 30.0, yield: 4.50 },
    ],
  },
  {
    id: 'flat_term_structure',
    name: 'Flat Term Structure (Neutral Equilibrium)',
    timestamp: '2026-01-15 16:30:00 EST',
    currency: 'USD',
    type: 'Synthetic',
    units: 'PERCENT',
    source: 'Equilibrium Model',
    interpolationMethod: 'MonotoneSpline',
    model: 'Spline',
    version: 'rhinoquant::v3.4.1',
    scenario: 'Flat Regime',
    points: [
      { tenor: '1M', maturity: 0.0833, yield: 4.20 },
      { tenor: '3M', maturity: 0.25, yield: 4.21 },
      { tenor: '6M', maturity: 0.5, yield: 4.22 },
      { tenor: '1Y', maturity: 1.0, yield: 4.20 },
      { tenor: '2Y', maturity: 2.0, yield: 4.21 },
      { tenor: '3Y', maturity: 3.0, yield: 4.22 },
      { tenor: '5Y', maturity: 5.0, yield: 4.24 },
      { tenor: '7Y', maturity: 7.0, yield: 4.23 },
      { tenor: '10Y', maturity: 10.0, yield: 4.25 },
      { tenor: '20Y', maturity: 20.0, yield: 4.26 },
      { tenor: '30Y', maturity: 30.0, yield: 4.28 },
    ],
  },
  {
    id: 'eur_bund_benchmark',
    name: 'German Bund Yield Curve (EUR Benchmark)',
    timestamp: '2026-08-24 17:30:00 CET',
    currency: 'EUR',
    type: 'Observed',
    units: 'PERCENT',
    source: 'Deutsche Bundesbank / Eurex',
    interpolationMethod: 'NelsonSiegel',
    model: 'NelsonSiegel',
    version: 'rhinoquant::v3.4.1',
    scenario: 'Baseline EUR',
    points: [
      { tenor: '1M', maturity: 0.0833, yield: 2.30 },
      { tenor: '3M', maturity: 0.25, yield: 2.38 },
      { tenor: '6M', maturity: 0.5, yield: 2.45 },
      { tenor: '1Y', maturity: 1.0, yield: 2.52 },
      { tenor: '2Y', maturity: 2.0, yield: 2.60 },
      { tenor: '3Y', maturity: 3.0, yield: 2.68 },
      { tenor: '5Y', maturity: 5.0, yield: 2.82 },
      { tenor: '7Y', maturity: 7.0, yield: 2.94 },
      { tenor: '10Y', maturity: 10.0, yield: 3.12 },
      { tenor: '20Y', maturity: 20.0, yield: 3.38 },
      { tenor: '30Y', maturity: 30.0, yield: 3.46 },
    ],
  },
  {
    id: 'uk_gilt_benchmark',
    name: 'UK Conventional Gilt Curve (GBP Benchmark)',
    timestamp: '2026-08-24 16:30:00 GMT',
    currency: 'GBP',
    type: 'Observed',
    units: 'PERCENT',
    source: 'Bank of England / DMO',
    interpolationMethod: 'MonotoneSpline',
    model: 'Spline',
    version: 'rhinoquant::v3.4.1',
    scenario: 'Baseline GBP',
    points: [
      { tenor: '1M', maturity: 0.0833, yield: 4.45 },
      { tenor: '3M', maturity: 0.25, yield: 4.52 },
      { tenor: '6M', maturity: 0.5, yield: 4.60 },
      { tenor: '1Y', maturity: 1.0, yield: 4.70 },
      { tenor: '2Y', maturity: 2.0, yield: 4.82 },
      { tenor: '3Y', maturity: 3.0, yield: 4.90 },
      { tenor: '5Y', maturity: 5.0, yield: 5.04 },
      { tenor: '7Y', maturity: 7.0, yield: 5.16 },
      { tenor: '10Y', maturity: 10.0, yield: 5.28 },
      { tenor: '20Y', maturity: 20.0, yield: 5.48 },
      { tenor: '30Y', maturity: 30.0, yield: 5.56 },
    ],
  },
];

/**
 * Generate 5-Year Realistic Daily Historical Term Structure Dataset
 * Generates continuous macro cycles (ZIRP, rapid Fed hiking, deep inversion, normalization)
 */
export function generateHistoricalTimeSeries(numDays = 250): TimeSeriesCurvePoint[] {
  const result: TimeSeriesCurvePoint[] = [];
  const baseDate = new Date(2022, 0, 3); // Jan 2022

  for (let d = 0; d < numDays; d++) {
    const currDate = new Date(baseDate.getTime() + d * 24 * 60 * 60 * 1000 * (365 / numDays) * 4.5);
    const dateStr = currDate.toISOString().split('T')[0];

    // Progression index from 0 to 1 (2022 -> 2026)
    const prog = d / (numDays - 1);

    // Regime dynamics:
    // 2022 (prog 0.0 - 0.25): Low rates rising fast (ZIRP to 3%)
    // 2023 (prog 0.25 - 0.50): Deep inversion (front rates 5.5%, 10Y 3.8%)
    // 2024 (prog 0.50 - 0.75): Peak rates & humped formation
    // 2025-2026 (prog 0.75 - 1.0): Disinflation easing & steepening normalization
    let baseShort = 0.5;
    let baseLong = 2.0;

    if (prog < 0.25) {
      const p = prog / 0.25;
      baseShort = 0.2 + p * 3.5;
      baseLong = 1.8 + p * 1.8;
    } else if (prog < 0.50) {
      const p = (prog - 0.25) / 0.25;
      baseShort = 3.7 + p * 1.7; // reaching 5.4%
      baseLong = 3.6 + p * 0.4;  // reaching 4.0%
    } else if (prog < 0.75) {
      const p = (prog - 0.50) / 0.25;
      baseShort = 5.4 - p * 0.8;
      baseLong = 4.0 + p * 0.6;
    } else {
      const p = (prog - 0.75) / 0.25;
      baseShort = 4.6 - p * 0.8;
      baseLong = 4.6 + p * 0.35;
    }

    // Add sinusoidal cycles and realistic daily volatility
    const noise = Math.sin(d * 0.15) * 0.08 + Math.cos(d * 0.07) * 0.05;

    const yields: { [tenor: string]: number } = {};
    STANDARD_TENORS.forEach(({ tenor, maturity }) => {
      // Shape weight: 0 for 3M, 1 for 30Y
      const shapeWeight = Math.sqrt(maturity / 30.0);
      const intermediateHump = Math.sin((maturity / 30.0) * Math.PI) * (prog > 0.4 && prog < 0.8 ? 0.45 : 0.1);
      const rawYield = baseShort * (1 - shapeWeight) + baseLong * shapeWeight + intermediateHump + noise * (1 - maturity / 40);
      yields[tenor] = Number(Math.max(0.1, rawYield).toFixed(3));
    });

    result.push({
      date: dateStr,
      timestamp: currDate.getTime(),
      yields,
    });
  }

  return result;
}

export const HISTORICAL_TIME_SERIES = generateHistoricalTimeSeries(200);
