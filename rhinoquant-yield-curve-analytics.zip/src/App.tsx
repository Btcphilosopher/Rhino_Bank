/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Institutional Fixed-Income Quantitative Suite
 */

import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { CurveMachine } from './components/CurveMachine';
import { NelsonSiegelLab } from './components/NelsonSiegelLab';
import { CurveBuilder } from './components/CurveBuilder';
import { TransformationLab } from './components/TransformationLab';
import { ScenarioLab } from './components/ScenarioLab';
import { DifferenceEngine } from './components/DifferenceEngine';
import { Surface3DLab } from './components/Surface3DLab';
import { AxisLab } from './components/AxisLab';
import { FixedIncomeLab } from './components/FixedIncomeLab';
import { PcaLab } from './components/PcaLab';
import { RStudioWorkspace } from './components/RStudioWorkspace';
import { AiQuantModal } from './components/AiQuantModal';

import { RhinoCurve, CurvePoint, InterpolationMethod, SvenssonParams, ScenarioDefinition } from './types/rhino';
import { PRESET_CURVES, HISTORICAL_TIME_SERIES } from './data/sampleCurves';
import { generateDenseCurveGrid } from './math/interpolations';
import { computeGeometryMetrics } from './math/geometry';
import { computeDenseFixedIncomeAnalytics } from './math/fixedIncome';
import { PRESET_SCENARIOS } from './math/transformations';
import { generateRhinoQuantRScript } from './r/rhinoquantR';

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<string>('curve_machine');

  // Curve Library & Active Curve State
  const [presetCurves, setPresetCurves] = useState<RhinoCurve[]>(PRESET_CURVES);
  const [activeCurve, setActiveCurve] = useState<RhinoCurve>(PRESET_CURVES[0]);

  // Scenario State
  const [activeScenario, setActiveScenario] = useState<ScenarioDefinition>(PRESET_SCENARIOS[0]);

  // AI Modal State
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  // Time Series State
  const [timeSeries] = useState(HISTORICAL_TIME_SERIES);

  // 1. Compute Dense Interpolated Curve Grid (300 points from 0.08Y to 30Y)
  const denseGrid = useMemo(() => {
    return generateDenseCurveGrid(activeCurve.points, activeCurve.interpolationMethod);
  }, [activeCurve.points, activeCurve.interpolationMethod]);

  // 2. Compute Curve Geometry (dY/dX, d²Y/dX², Inflections, 2s10s spread, 2s5s10s fly)
  const geometry = useMemo(() => {
    return computeGeometryMetrics(activeCurve.points, denseGrid);
  }, [activeCurve.points, denseGrid]);

  // 3. Compute Continuous Fixed-Income Analytics (Discount Factors, Duration, Convexity, DV01, Forward Rates)
  const fixedIncomeMetrics = useMemo(() => {
    return computeDenseFixedIncomeAnalytics(denseGrid);
  }, [denseGrid]);

  // Curve Selection Handler
  const handleSelectCurve = (curveId: string) => {
    const selected = presetCurves.find((c) => c.id === curveId);
    if (selected) {
      setActiveCurve(selected);
    }
  };

  // Curve Points Update Handler
  const handleUpdateCurvePoints = (newPoints: CurvePoint[], method: InterpolationMethod) => {
    const updated: RhinoCurve = {
      ...activeCurve,
      points: newPoints,
      interpolationMethod: method,
      timestamp: new Date().toISOString(),
    };
    setActiveCurve(updated);
    setPresetCurves((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  };

  // Apply Parametric Model
  const handleApplyFittedModel = (params: SvenssonParams, modelType: 'NelsonSiegel' | 'Svensson') => {
    const updated: RhinoCurve = {
      ...activeCurve,
      model: modelType,
      interpolationMethod: modelType,
      timestamp: new Date().toISOString(),
    };
    setActiveCurve(updated);
    setPresetCurves((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    setActiveTab('curve_machine');
  };

  // Load Date from 3D Time-Series
  const handleLoadDateIntoMachine = (date: string, yields: { [tenor: string]: number }) => {
    const newPoints: CurvePoint[] = activeCurve.points.map((p) => ({
      ...p,
      yield: yields[p.tenor] !== undefined ? yields[p.tenor] : p.yield,
    }));

    const dateCurve: RhinoCurve = {
      ...activeCurve,
      id: `historical_${date}`,
      name: `US Treasury Historical (${date})`,
      timestamp: date,
      points: newPoints,
    };

    setActiveCurve(dateCurve);
    setPresetCurves((prev) => [dateCurve, ...prev.filter((c) => c.id !== dateCurve.id)]);
    setActiveTab('curve_machine');
  };

  // Export R Script
  const handleExportRScript = () => {
    const rScript = generateRhinoQuantRScript(activeCurve, activeScenario);
    const element = document.createElement('a');
    const file = new Blob([rScript], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `rhinoquant_${activeCurve.id}.R`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Export CSV
  const handleExportCsv = () => {
    let csv = 'Tenor,Maturity,Yield_Percent,Discount_Factor,Inst_Forward,Modified_Duration,Convexity,DV01_per100k\n';
    activeCurve.points.forEach((p, i) => {
      const fi = fixedIncomeMetrics[Math.min(i * 25, fixedIncomeMetrics.length - 1)];
      csv += `${p.tenor},${p.maturity},${p.yield},${fi?.discountFactor || ''},${fi?.instantaneousForward || ''},${fi?.modifiedDuration || ''},${fi?.convexity || ''},${fi?.dv01 || ''}\n`;
    });

    const element = document.createElement('a');
    const file = new Blob([csv], { type: 'text/csv' });
    element.href = URL.createObjectURL(file);
    element.download = `rhinoquant_${activeCurve.id}_points.csv`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Reset to Default Benchmark
  const handleReset = () => {
    setActiveCurve(PRESET_CURVES[0]);
    setActiveScenario(PRESET_SCENARIOS[0]);
  };

  return (
    <div className="min-h-screen bg-[#0A0B0D] text-[#E0E0E0] flex flex-col font-sans selection:bg-[#F27D26] selection:text-black">
      {/* Institutional Global Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeCurve={activeCurve}
        presetCurves={presetCurves}
        onSelectCurve={handleSelectCurve}
        onOpenAiModal={() => setIsAiModalOpen(true)}
        onExportRScript={handleExportRScript}
        onExportCsv={handleExportCsv}
        onReset={handleReset}
      />

      {/* Main Analytical Workspace Canvas */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto p-4 md:p-6 space-y-6">
        {activeTab === 'curve_machine' && (
          <CurveMachine
            activeCurve={activeCurve}
            geometry={geometry}
            denseGrid={denseGrid}
            fixedIncomeMetrics={fixedIncomeMetrics}
            onOpenAiModal={() => setIsAiModalOpen(true)}
            activeScenario={activeScenario}
            onSelectScenario={setActiveScenario}
          />
        )}

        {activeTab === 'nelson_siegel' && (
          <NelsonSiegelLab
            activeCurve={activeCurve}
            onApplyFittedModelToActiveCurve={handleApplyFittedModel}
          />
        )}

        {activeTab === 'curve_builder' && (
          <CurveBuilder
            activeCurve={activeCurve}
            onUpdateCurvePoints={handleUpdateCurvePoints}
          />
        )}

        {activeTab === 'transformations' && (
          <TransformationLab
            activeCurve={activeCurve}
            onApplyTransformation={(pts) => handleUpdateCurvePoints(pts, activeCurve.interpolationMethod)}
          />
        )}

        {activeTab === 'scenarios' && (
          <ScenarioLab
            activeCurve={activeCurve}
            activeScenario={activeScenario}
            onSelectScenario={setActiveScenario}
          />
        )}

        {activeTab === 'difference' && (
          <DifferenceEngine
            presetCurves={presetCurves}
            activeCurve={activeCurve}
          />
        )}

        {activeTab === 'surface_3d' && (
          <Surface3DLab
            timeSeries={timeSeries}
            onLoadCurveFromDate={handleLoadDateIntoMachine}
          />
        )}

        {activeTab === 'axis_lab' && (
          <AxisLab
            activeCurve={activeCurve}
            denseGrid={denseGrid}
            fixedIncomeMetrics={fixedIncomeMetrics}
          />
        )}

        {activeTab === 'fixed_income' && (
          <FixedIncomeLab
            activeCurve={activeCurve}
            denseGrid={denseGrid}
            fixedIncomeMetrics={fixedIncomeMetrics}
          />
        )}

        {activeTab === 'pca_factors' && (
          <PcaLab timeSeries={timeSeries} />
        )}

        {activeTab === 'r_studio' && (
          <RStudioWorkspace
            activeCurve={activeCurve}
            activeScenario={activeScenario}
          />
        )}
      </main>

      {/* AI Quant Strategist Dialog Modal */}
      <AiQuantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        activeCurve={activeCurve}
        geometry={geometry}
        activeScenario={activeScenario}
      />

      {/* Bottom Footer Bar */}
      <footer className="h-10 bg-[#0E1013] border-t border-[#1E2024] px-6 flex items-center justify-between text-[11px] font-mono text-[#8E9299]">
        <div className="max-w-[1720px] w-full mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#4CAF50] shadow-[0_0_8px_#4CAF5080]" />
              <span className="text-white font-medium">RHINOQUANT LIVE ENGINE</span>
            </div>
            <span className="hidden md:inline text-[#8E9299]">METHOD: C² NATURAL SPLINE • PCHIP • NSS v3.4</span>
          </div>
          <div className="flex items-center gap-4 text-[10px]">
            <span className="text-[#8E9299]">PRECISION: 10⁻⁸</span>
            <span className="text-[#F27D26] font-bold">RHINO_ENGINE_v4.2</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
