/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * High-Precision Term Structure Interpolation Engine
 * Namespace: rhinoquant::interpolation
 */

import { CurvePoint } from '../types/rhino';

export interface EvaluatedCurvePoint {
  maturity: number;
  yield: number;
  slope: number;      // dY/dX in %/year (or bps/yr)
  curvature: number;  // d²Y/dX² in %/year²
  torsion?: number;   // d³Y/dX³
}

/**
 * Linear Interpolation with piece-wise derivative
 */
export function evaluateLinear(points: CurvePoint[], t: number): EvaluatedCurvePoint {
  const sorted = [...points].sort((a, b) => a.maturity - b.maturity);
  if (sorted.length === 0) return { maturity: t, yield: 0, slope: 0, curvature: 0 };
  if (sorted.length === 1 || t <= sorted[0].maturity) {
    return { maturity: t, yield: sorted[0].yield, slope: 0, curvature: 0 };
  }
  if (t >= sorted[sorted.length - 1].maturity) {
    const last = sorted[sorted.length - 1];
    const prev = sorted[sorted.length - 2];
    const slope = (last.yield - prev.yield) / (last.maturity - prev.maturity);
    return { maturity: t, yield: last.yield, slope: 0, curvature: 0 };
  }

  for (let i = 0; i < sorted.length - 1; i++) {
    const p0 = sorted[i];
    const p1 = sorted[i + 1];
    if (t >= p0.maturity && t <= p1.maturity) {
      const dt = p1.maturity - p0.maturity;
      const slope = (p1.yield - p0.yield) / dt;
      const y = p0.yield + slope * (t - p0.maturity);
      return { maturity: t, yield: y, slope: slope, curvature: 0 };
    }
  }

  return { maturity: t, yield: sorted[0].yield, slope: 0, curvature: 0 };
}

/**
 * Natural Cubic Spline Interpolation
 * Implements C2 continuity: continuous yield, slope, and curvature
 */
export class CubicSpline {
  private x: number[] = [];
  private y: number[] = [];
  private a: number[] = [];
  private b: number[] = [];
  private c: number[] = [];
  private d: number[] = [];

  constructor(points: CurvePoint[]) {
    const sorted = [...points].sort((p1, p2) => p1.maturity - p2.maturity);
    // Remove duplicate maturities if any
    const unique: CurvePoint[] = [];
    for (const p of sorted) {
      if (unique.length === 0 || Math.abs(p.maturity - unique[unique.length - 1].maturity) > 1e-6) {
        unique.push(p);
      }
    }

    const n = unique.length;
    if (n < 2) return;

    this.x = unique.map((p) => p.maturity);
    this.y = unique.map((p) => p.yield);
    this.a = [...this.y];

    const h: number[] = [];
    for (let i = 0; i < n - 1; i++) {
      h.push(this.x[i + 1] - this.x[i]);
    }

    const alpha: number[] = [0];
    for (let i = 1; i < n - 1; i++) {
      alpha.push(
        (3 / h[i]) * (this.a[i + 1] - this.a[i]) - (3 / h[i - 1]) * (this.a[i] - this.a[i - 1])
      );
    }

    const l: number[] = [1];
    const mu: number[] = [0];
    const z: number[] = [0];

    for (let i = 1; i < n - 1; i++) {
      l.push(2 * (this.x[i + 1] - this.x[i - 1]) - h[i - 1] * mu[i - 1]);
      mu.push(h[i] / l[i]);
      z.push((alpha[i] - h[i - 1] * z[i - 1]) / l[i]);
    }

    l.push(1);
    z.push(0);
    this.c = new Array(n).fill(0);
    this.b = new Array(n - 1).fill(0);
    this.d = new Array(n - 1).fill(0);

    for (let j = n - 2; j >= 0; j--) {
      this.c[j] = z[j] - mu[j] * this.c[j + 1];
      this.b[j] =
        (this.a[j + 1] - this.a[j]) / h[j] - (h[j] * (this.c[j + 1] + 2 * this.c[j])) / 3;
      this.d[j] = (this.c[j + 1] - this.c[j]) / (3 * h[j]);
    }
  }

  evaluate(t: number): EvaluatedCurvePoint {
    const n = this.x.length;
    if (n === 0) return { maturity: t, yield: 0, slope: 0, curvature: 0 };
    if (n === 1) return { maturity: t, yield: this.y[0], slope: 0, curvature: 0 };

    // Flat extrapolation or linear boundary
    if (t <= this.x[0]) {
      const dx = t - this.x[0];
      const y = this.a[0] + this.b[0] * dx;
      return { maturity: t, yield: y, slope: this.b[0], curvature: 2 * this.c[0] };
    }
    if (t >= this.x[n - 1]) {
      const idx = n - 2;
      const dx = t - this.x[idx];
      const y = this.a[idx] + this.b[idx] * dx + this.c[idx] * dx * dx + this.d[idx] * dx * dx * dx;
      const slope = this.b[idx] + 2 * this.c[idx] * dx + 3 * this.d[idx] * dx * dx;
      const curvature = 2 * this.c[idx] + 6 * this.d[idx] * dx;
      return { maturity: t, yield: y, slope, curvature };
    }

    let i = 0;
    for (let k = 0; k < n - 1; k++) {
      if (t >= this.x[k] && t <= this.x[k + 1]) {
        i = k;
        break;
      }
    }

    const dx = t - this.x[i];
    const y = this.a[i] + this.b[i] * dx + this.c[i] * dx * dx + this.d[i] * dx * dx * dx;
    const slope = this.b[i] + 2 * this.c[i] * dx + 3 * this.d[i] * dx * dx;
    const curvature = 2 * this.c[i] + 6 * this.d[i] * dx;
    const torsion = 6 * this.d[i];

    return { maturity: t, yield: y, slope, curvature, torsion };
  }
}

/**
 * Monotone Cubic Spline (PCHIP / Fritsch-Carlson)
 * Prevents overshoot and anomalous oscillations in financial term structures
 */
export class MonotoneSpline {
  private x: number[] = [];
  private y: number[] = [];
  private m: number[] = []; // Slopes at knots

  constructor(points: CurvePoint[]) {
    const sorted = [...points].sort((p1, p2) => p1.maturity - p2.maturity);
    const unique: CurvePoint[] = [];
    for (const p of sorted) {
      if (unique.length === 0 || Math.abs(p.maturity - unique[unique.length - 1].maturity) > 1e-6) {
        unique.push(p);
      }
    }

    const n = unique.length;
    this.x = unique.map((p) => p.maturity);
    this.y = unique.map((p) => p.yield);

    if (n < 2) return;

    const delta: number[] = [];
    const h: number[] = [];
    for (let i = 0; i < n - 1; i++) {
      h.push(this.x[i + 1] - this.x[i]);
      delta.push((this.y[i + 1] - this.y[i]) / h[i]);
    }

    this.m = new Array(n).fill(0);
    this.m[0] = delta[0];
    this.m[n - 1] = delta[n - 2];

    for (let i = 1; i < n - 1; i++) {
      if (delta[i - 1] * delta[i] <= 0) {
        this.m[i] = 0;
      } else {
        const w1 = 2 * h[i] + h[i - 1];
        const w2 = h[i] + 2 * h[i - 1];
        this.m[i] = (w1 + w2) / (w1 / delta[i - 1] + w2 / delta[i]);
      }
    }
  }

  evaluate(t: number): EvaluatedCurvePoint {
    const n = this.x.length;
    if (n === 0) return { maturity: t, yield: 0, slope: 0, curvature: 0 };
    if (n === 1) return { maturity: t, yield: this.y[0], slope: 0, curvature: 0 };

    if (t <= this.x[0]) {
      const y = this.y[0] + this.m[0] * (t - this.x[0]);
      return { maturity: t, yield: y, slope: this.m[0], curvature: 0 };
    }
    if (t >= this.x[n - 1]) {
      const y = this.y[n - 1] + this.m[n - 1] * (t - this.x[n - 1]);
      return { maturity: t, yield: y, slope: this.m[n - 1], curvature: 0 };
    }

    let i = 0;
    for (let k = 0; k < n - 1; k++) {
      if (t >= this.x[k] && t <= this.x[k + 1]) {
        i = k;
        break;
      }
    }

    const h = this.x[i + 1] - this.x[i];
    const s = (t - this.x[i]) / h;
    const s2 = s * s;
    const s3 = s * s2;

    const h00 = 2 * s3 - 3 * s2 + 1;
    const h10 = s3 - 2 * s2 + s;
    const h01 = -2 * s3 + 3 * s2;
    const h11 = s3 - s2;

    const y =
      h00 * this.y[i] +
      h10 * h * this.m[i] +
      h01 * this.y[i + 1] +
      h11 * h * this.m[i + 1];

    const dh00 = (6 * s2 - 6 * s) / h;
    const dh10 = 3 * s2 - 4 * s + 1;
    const dh01 = (-6 * s2 + 6 * s) / h;
    const dh11 = 3 * s2 - 2 * s;

    const slope =
      dh00 * this.y[i] +
      dh10 * this.m[i] +
      dh01 * this.y[i + 1] +
      dh11 * this.m[i + 1];

    const d2h00 = (12 * s - 6) / (h * h);
    const d2h10 = (6 * s - 4) / h;
    const d2h01 = (-12 * s + 6) / (h * h);
    const d2h11 = (6 * s - 2) / h;

    const curvature =
      d2h00 * this.y[i] +
      d2h10 * this.m[i] +
      d2h01 * this.y[i + 1] +
      d2h11 * this.m[i + 1];

    return { maturity: t, yield: y, slope, curvature };
  }
}

/**
 * Generate a dense grid of points across maturity domain (e.g. 0.08Y / 1M to 30Y)
 */
export function generateDenseCurveGrid(
  points: CurvePoint[],
  method: 'Linear' | 'CubicSpline' | 'MonotoneSpline' | 'Polynomial' | 'NelsonSiegel' | 'Svensson',
  evaluatorFn?: (tau: number) => EvaluatedCurvePoint,
  minTau = 0.08,
  maxTau = 30,
  numSteps = 200
): EvaluatedCurvePoint[] {
  let spline: CubicSpline | null = null;
  let monoSpline: MonotoneSpline | null = null;

  if (method === 'CubicSpline') spline = new CubicSpline(points);
  if (method === 'MonotoneSpline') monoSpline = new MonotoneSpline(points);

  const results: EvaluatedCurvePoint[] = [];
  const step = (maxTau - minTau) / (numSteps - 1);

  for (let i = 0; i < numSteps; i++) {
    const tau = minTau + i * step;
    if (evaluatorFn) {
      results.push(evaluatorFn(tau));
    } else if (method === 'MonotoneSpline' && monoSpline) {
      results.push(monoSpline.evaluate(tau));
    } else if (method === 'CubicSpline' && spline) {
      results.push(spline.evaluate(tau));
    } else {
      results.push(evaluateLinear(points, tau));
    }
  }

  return results;
}
