/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Curve Transformation, Shocks & Scenario Lab Engine
 * Namespace: rhinoquant::transformations
 */

import { CurvePoint, ScenarioDefinition } from '../types/rhino';

export interface TransformationParams {
  levelShiftBps: number;       // Parallel shift (bps)
  slopeTiltBps: number;        // Slope twist (bps)
  curvatureBellyBps: number;   // Butterfly / belly curvature shock (bps)
  shortTenorAnchor: number;    // default 0.25Y / 3M
  bellyTenorAnchor: number;    // default 5.0Y
  longTenorAnchor: number;     // default 30.0Y
}

/**
 * Apply analytical Level, Slope, and Curvature transformations to curve points
 */
export function applyCurveTransformation(
  points: CurvePoint[],
  params: TransformationParams
): CurvePoint[] {
  const {
    levelShiftBps,
    slopeTiltBps,
    curvatureBellyBps,
    shortTenorAnchor = 0.25,
    bellyTenorAnchor = 5.0,
    longTenorAnchor = 30.0,
  } = params;

  return points.map((p) => {
    const tau = p.maturity;
    // 1. Parallel shift (Level)
    const levelEffect = levelShiftBps / 100;

    // 2. Linear slope tilt: -1 at shortTenorAnchor, +1 at longTenorAnchor, 0 at midpoint
    const slopeWeight = ((tau - shortTenorAnchor) / (longTenorAnchor - shortTenorAnchor)) * 2 - 1;
    const slopeEffect = (slopeTiltBps / 100) * slopeWeight;

    // 3. Butterfly / curvature shock: peak at bellyTenorAnchor, decaying towards wings
    let curvatureWeight = 0;
    if (tau <= bellyTenorAnchor) {
      curvatureWeight = (tau - shortTenorAnchor) / (bellyTenorAnchor - shortTenorAnchor);
    } else {
      curvatureWeight = (longTenorAnchor - tau) / (longTenorAnchor - bellyTenorAnchor);
    }
    curvatureWeight = Math.max(0, Math.min(1, curvatureWeight));
    // Center at 0 for wings and +1 for belly
    const curvatureEffect = (curvatureBellyBps / 100) * (2 * curvatureWeight - 1);

    const transformedYield = Math.max(0.001, p.yield + levelEffect + slopeEffect + curvatureEffect);

    return {
      ...p,
      yield: Number(transformedYield.toFixed(3)),
    };
  });
}

/**
 * Standard Institutional Scenarios
 */
export const PRESET_SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'baseline',
    name: 'Baseline Curve',
    description: 'Current active term structure with zero applied shocks.',
    type: 'PARALLEL',
    parallelShiftBps: 0,
    slopeTiltBps: 0,
    bellyShiftBps: 0,
    color: '#06b6d4', // Cyan
  },
  {
    id: 'parallel_plus_25',
    name: '+25 bps Parallel Shift',
    description: 'Uniform upward rate hike shock across all maturities.',
    type: 'PARALLEL',
    parallelShiftBps: 25,
    slopeTiltBps: 0,
    bellyShiftBps: 0,
    color: '#f59e0b', // Amber
  },
  {
    id: 'parallel_minus_25',
    name: '-25 bps Parallel Shift',
    description: 'Uniform downward easing shock across all maturities.',
    type: 'PARALLEL',
    parallelShiftBps: -25,
    slopeTiltBps: 0,
    bellyShiftBps: 0,
    color: '#10b981', // Emerald
  },
  {
    id: 'parallel_plus_100',
    name: '+100 bps Tightening Shock',
    description: 'Severe monetary tightening across the entire term structure.',
    type: 'PARALLEL',
    parallelShiftBps: 100,
    slopeTiltBps: 0,
    bellyShiftBps: 0,
    color: '#ef4444', // Red
  },
  {
    id: 'bull_steepener',
    name: 'Bull Steepener (-50bp front, -10bp long)',
    description: 'Aggressive central bank rate cuts driving front-end yields down faster than long-end.',
    type: 'BULL_STEEPENER',
    parallelShiftBps: -30,
    slopeTiltBps: 20,
    bellyShiftBps: -10,
    color: '#3b82f6', // Blue
  },
  {
    id: 'bear_steepener',
    name: 'Bear Steepener (+10bp front, +60bp long)',
    description: 'Inflation term premium resurgence and heavy fiscal issuance driving long rates higher.',
    type: 'BEAR_STEEPENER',
    parallelShiftBps: 35,
    slopeTiltBps: 25,
    bellyShiftBps: 10,
    color: '#f97316', // Orange
  },
  {
    id: 'bull_flattener',
    name: 'Bull Flattener (-15bp front, -65bp long)',
    description: 'Flight-to-duration rally with long-end yields falling significantly.',
    type: 'BULL_FLATTENER',
    parallelShiftBps: -40,
    slopeTiltBps: -25,
    bellyShiftBps: -20,
    color: '#8b5cf6', // Violet
  },
  {
    id: 'bear_flattener',
    name: 'Bear Flattener (+65bp front, +15bp long)',
    description: 'Surprise central bank rate hikes lifting front-end yields aggressively, flattening the curve.',
    type: 'BEAR_FLATTENER',
    parallelShiftBps: 40,
    slopeTiltBps: -25,
    bellyShiftBps: 20,
    color: '#ec4899', // Pink
  },
  {
    id: 'positive_butterfly',
    name: 'Positive Butterfly (+30bp belly hump)',
    description: '5Y intermediate yields rise relative to 2Y and 10Y/30Y wings (convexity sell-off).',
    type: 'BUTTERFLY',
    parallelShiftBps: 0,
    slopeTiltBps: 0,
    bellyShiftBps: 30,
    color: '#14b8a6', // Teal
  },
  {
    id: 'crisis_flight_to_quality',
    name: '2008 GFC Flight-to-Quality Shock',
    description: 'Extreme front-end collapse (-250 bps) and long-end safe-haven demand.',
    type: 'CUSTOM',
    parallelShiftBps: -120,
    slopeTiltBps: 60,
    bellyShiftBps: -50,
    color: '#a855f7', // Purple
  },
];

/**
 * Apply a predefined scenario to a set of curve points
 */
export function applyScenarioToPoints(points: CurvePoint[], scenario: ScenarioDefinition): CurvePoint[] {
  if (scenario.id === 'baseline') return points;
  return applyCurveTransformation(points, {
    levelShiftBps: scenario.parallelShiftBps,
    slopeTiltBps: scenario.slopeTiltBps,
    curvatureBellyBps: scenario.bellyShiftBps,
    shortTenorAnchor: 0.25,
    bellyTenorAnchor: 5.0,
    longTenorAnchor: 30.0,
  });
}
