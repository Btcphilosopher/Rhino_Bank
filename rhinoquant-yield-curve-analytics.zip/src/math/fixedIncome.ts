/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Fixed Income Mathematics, Duration, Convexity, DV01 & Forward Curve Engine
 * Namespace: rhinoquant::fixed_income
 */

import { FixedIncomeMetrics } from '../types/rhino';
import { EvaluatedCurvePoint } from './interpolations';

/**
 * Standard semi-annual bond price given par 100, annual coupon rate c%, yield-to-maturity y%, maturity tau
 */
export function priceCouponBond(couponRate: number, ytmPercent: number, maturityYears: number, par = 100): number {
  if (maturityYears <= 0.01) return par;
  const r = (ytmPercent / 100) / 2; // semi-annual yield
  const c = (couponRate / 100) * par / 2; // semi-annual coupon
  const n = Math.max(1, Math.round(maturityYears * 2));

  if (Math.abs(r) < 1e-7) {
    return par + c * n;
  }

  const pvCoupons = c * ((1 - Math.pow(1 + r, -n)) / r);
  const pvPar = par * Math.pow(1 + r, -n);
  return pvCoupons + pvPar;
}

/**
 * Calculate Macaulay Duration, Modified Duration, Convexity, and DV01
 */
export function calculateBondRiskMetrics(
  ytmPercent: number,
  maturityYears: number,
  couponRate = ytmPercent, // Default to par bond
  par = 100
): { macaulayDuration: number; modifiedDuration: number; convexity: number; dv01: number } {
  if (maturityYears <= 0.01) {
    return { macaulayDuration: 0, modifiedDuration: 0, convexity: 0, dv01: 0 };
  }

  const r = (ytmPercent / 100) / 2;
  const c = (couponRate / 100) * par / 2;
  const n = Math.max(1, Math.round(maturityYears * 2));
  const price = priceCouponBond(couponRate, ytmPercent, maturityYears, par);

  let weightedTimeSum = 0;
  let weightedTimeSquareSum = 0;

  for (let k = 1; k <= n; k++) {
    const t = k / 2; // time in years
    const cashFlow = (k === n) ? (c + par) : c;
    const discount = Math.pow(1 + r, -k);
    const pv = cashFlow * discount;

    weightedTimeSum += t * pv;
    weightedTimeSquareSum += t * (t + 0.5) * pv;
  }

  const macaulayDuration = weightedTimeSum / price;
  const modifiedDuration = macaulayDuration / (1 + r);
  const convexity = weightedTimeSquareSum / (price * Math.pow(1 + r, 2));
  // DV01 for $100,000 notional: ModDur * (Price/100 * 100,000) * 0.0001
  const dv01 = modifiedDuration * (price / 100 * 100000) * 0.0001;

  return {
    macaulayDuration: Number(macaulayDuration.toFixed(3)),
    modifiedDuration: Number(modifiedDuration.toFixed(3)),
    convexity: Number(convexity.toFixed(3)),
    dv01: Number(dv01.toFixed(2)),
  };
}

/**
 * Calculate Instantaneous Forward Rate:
 * f(tau) = y(tau) + tau * dy/dtau
 */
export function calculateInstantaneousForward(point: EvaluatedCurvePoint): number {
  // point.slope is in %/year
  const dy_dtau = point.slope / 100; // convert bps/yr or %/yr to decimal rate derivative
  return point.yield + point.maturity * dy_dtau;
}

/**
 * Discount Factor D(tau) = exp(-y(tau) * tau)
 */
export function calculateDiscountFactor(yieldPercent: number, maturityYears: number): number {
  return Math.exp(-(yieldPercent / 100) * maturityYears);
}

/**
 * Key-Rate Duration Decomposition across standard buckets:
 * 3M, 6M, 1Y, 2Y, 3Y, 5Y, 7Y, 10Y, 20Y, 30Y
 */
const KEY_TENORS = [0.25, 0.5, 1, 2, 3, 5, 7, 10, 20, 30];
const KEY_TENOR_LABELS = ['3M', '6M', '1Y', '2Y', '3Y', '5Y', '7Y', '10Y', '20Y', '30Y'];

export function calculateKeyRateDurations(
  maturityYears: number,
  modDuration: number
): { [tenor: string]: number } {
  const krd: { [tenor: string]: number } = {};

  // Find surrounding key tenors and allocate with tent/triangular basis functions
  for (let i = 0; i < KEY_TENORS.length; i++) {
    const center = KEY_TENORS[i];
    const left = i > 0 ? KEY_TENORS[i - 1] : 0;
    const right = i < KEY_TENORS.length - 1 ? KEY_TENORS[i + 1] : 40;

    let weight = 0;
    if (maturityYears >= left && maturityYears <= center) {
      weight = (maturityYears - left) / (center - left);
    } else if (maturityYears > center && maturityYears <= right) {
      weight = (right - maturityYears) / (right - center);
    }

    krd[KEY_TENOR_LABELS[i]] = Number((modDuration * weight).toFixed(3));
  }

  return krd;
}

/**
 * Compute Complete Fixed Income Metrics for a single point
 */
export function computeFixedIncomeAnalytics(
  maturity: number,
  yieldVal: number,
  slopeVal = 0,
  parCoupon = yieldVal
): FixedIncomeMetrics {
  const risk = calculateBondRiskMetrics(yieldVal, maturity, parCoupon);
  const instForward = calculateInstantaneousForward({ maturity, yield: yieldVal, slope: slopeVal, curvature: 0 });
  const discount = calculateDiscountFactor(yieldVal, maturity);
  const krd = calculateKeyRateDurations(maturity, risk.modifiedDuration);
  const f1y = yieldVal + (maturity / 1.0) * (slopeVal / 100);

  return {
    maturity: Number(maturity.toFixed(2)),
    yield: Number(yieldVal.toFixed(3)),
    zeroRate: Number(yieldVal.toFixed(3)),
    parRate: Number(yieldVal.toFixed(3)),
    forwardRate1Y: Number(f1y.toFixed(3)),
    instantaneousForward: Number(instForward.toFixed(3)),
    discountFactor: Number(discount.toFixed(4)),
    bondPrice100: Number(priceCouponBond(parCoupon, yieldVal, maturity).toFixed(3)),
    macaulayDuration: risk.macaulayDuration,
    modifiedDuration: risk.modifiedDuration,
    convexity: risk.convexity,
    dv01: risk.dv01,
    keyRateDurations: krd,
  };
}

/**
 * Compute Complete Fixed Income Metrics Array across dense grid
 */
export function computeDenseFixedIncomeAnalytics(denseGrid: EvaluatedCurvePoint[]): FixedIncomeMetrics[] {
  return denseGrid.map((p) => {
    const risk = calculateBondRiskMetrics(p.yield, p.maturity);
    const instForward = calculateInstantaneousForward(p);
    const discount = calculateDiscountFactor(p.yield, p.maturity);
    const krd = calculateKeyRateDurations(p.maturity, risk.modifiedDuration);

    // 1Y discrete forward rate from tau to tau+1
    const tau2 = p.maturity + 1.0;
    const f1y = p.yield + (p.maturity / 1.0) * (p.slope / 100);

    return {
      maturity: Number(p.maturity.toFixed(2)),
      yield: Number(p.yield.toFixed(3)),
      zeroRate: Number(p.yield.toFixed(3)),
      parRate: Number(p.yield.toFixed(3)),
      forwardRate1Y: Number(f1y.toFixed(3)),
      instantaneousForward: Number(instForward.toFixed(3)),
      discountFactor: Number(discount.toFixed(4)),
      bondPrice100: Number(priceCouponBond(p.yield, p.yield, p.maturity).toFixed(3)),
      macaulayDuration: risk.macaulayDuration,
      modifiedDuration: risk.modifiedDuration,
      convexity: risk.convexity,
      dv01: risk.dv01,
      keyRateDurations: krd,
    };
  });
}
