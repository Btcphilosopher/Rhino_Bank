/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Nelson-Siegel & Nelson-Siegel-Svensson Parametric Engine
 * Namespace: rhinoquant::nelson_siegel
 */

import { CurvePoint, NelsonSiegelParams, SvenssonParams, ModelFitDiagnostics } from '../types/rhino';
import { EvaluatedCurvePoint } from './interpolations';

/**
 * Basis Functions for Nelson-Siegel & Svensson
 */
export function nsBasisFunctions(tau: number, lambda: number) {
  if (tau <= 1e-6) {
    return { level: 1, slope: 1, curvature: 0 };
  }
  const x = tau / lambda;
  const expTerm = Math.exp(-x);
  const slopeFactor = (1 - expTerm) / x;
  const curvatureFactor = slopeFactor - expTerm;
  return { level: 1, slope: slopeFactor, curvature: curvatureFactor };
}

/**
 * Evaluate Nelson-Siegel Yield y(tau)
 */
export function evaluateNelsonSiegel(tau: number, p: NelsonSiegelParams): number {
  if (tau <= 1e-6) {
    return p.beta0 + p.beta1;
  }
  const basis = nsBasisFunctions(tau, p.lambda);
  return p.beta0 + p.beta1 * basis.slope + p.beta2 * basis.curvature;
}

/**
 * Evaluate Nelson-Siegel with exact analytical derivatives (Slope dY/dtau, Curvature d²Y/dtau²)
 */
export function evaluateNelsonSiegelFull(tau: number, p: NelsonSiegelParams): EvaluatedCurvePoint {
  const y = evaluateNelsonSiegel(tau, p);
  const lam = p.lambda;
  if (tau <= 1e-6) {
    // Limit as tau -> 0
    const slope = -p.beta1 / (2 * lam) + p.beta2 / lam;
    return { maturity: tau, yield: y, slope: slope * 100, curvature: 0 };
  }

  const x = tau / lam;
  const e = Math.exp(-x);

  // Analytical 1st derivative dy/dtau:
  // d(slopeFactor)/dtau = (x*e - (1 - e)) / (lam * x^2)
  // d(curvatureFactor)/dtau = d(slopeFactor)/dtau + (e / lam)
  const dSlopeFactor = (x * e - (1 - e)) / (lam * x * x);
  const dCurvFactor = dSlopeFactor + e / lam;
  const dy_dtau = p.beta1 * dSlopeFactor + p.beta2 * dCurvFactor;

  // Numerical 2nd derivative for high stability
  const dt = 0.001;
  const yPlus = evaluateNelsonSiegel(tau + dt, p);
  const yMinus = evaluateNelsonSiegel(Math.max(1e-4, tau - dt), p);
  const d2y_dtau2 = (yPlus - 2 * y + yMinus) / (dt * dt);

  return {
    maturity: tau,
    yield: y,
    slope: dy_dtau * 100, // bps/year
    curvature: d2y_dtau2 * 100, // bps/year²
  };
}

/**
 * Evaluate Nelson-Siegel Instantaneous Forward Rate:
 * f(tau) = beta0 + beta1 * exp(-tau/lambda) + beta2 * (tau/lambda) * exp(-tau/lambda)
 */
export function evaluateNelsonSiegelInstantaneousForward(tau: number, p: NelsonSiegelParams): number {
  const x = tau / p.lambda;
  const e = Math.exp(-x);
  return p.beta0 + p.beta1 * e + p.beta2 * x * e;
}

/**
 * Evaluate Svensson (NSS) Yield y(tau)
 */
export function evaluateSvensson(tau: number, p: SvenssonParams): number {
  if (tau <= 1e-6) {
    return p.beta0 + p.beta1;
  }
  const basis1 = nsBasisFunctions(tau, p.lambda);
  const basis2 = nsBasisFunctions(tau, p.lambda2);
  return (
    p.beta0 +
    p.beta1 * basis1.slope +
    p.beta2 * basis1.curvature +
    p.beta3 * basis2.curvature
  );
}

/**
 * Evaluate Svensson with full analytical derivatives
 */
export function evaluateSvenssonFull(tau: number, p: SvenssonParams): EvaluatedCurvePoint {
  const y = evaluateSvensson(tau, p);
  const dt = 0.001;
  const yPlus = evaluateSvensson(tau + dt, p);
  const yMinus = evaluateSvensson(Math.max(1e-4, tau - dt), p);
  const slope = ((yPlus - yMinus) / (2 * dt)) * 100; // bps/yr
  const curvature = ((yPlus - 2 * y + yMinus) / (dt * dt)) * 100; // bps/yr²

  return {
    maturity: tau,
    yield: y,
    slope,
    curvature,
  };
}

/**
 * Evaluate Svensson Instantaneous Forward Rate:
 * f(tau) = beta0 + beta1*exp(-tau/lam1) + beta2*(tau/lam1)*exp(-tau/lam1) + beta3*(tau/lam2)*exp(-tau/lam2)
 */
export function evaluateSvenssonInstantaneousForward(tau: number, p: SvenssonParams): number {
  const x1 = tau / p.lambda;
  const x2 = tau / p.lambda2;
  const e1 = Math.exp(-x1);
  const e2 = Math.exp(-x2);
  return p.beta0 + p.beta1 * e1 + p.beta2 * x1 * e1 + p.beta3 * x2 * e2;
}

/**
 * Nelder-Mead Simplex Non-Linear Optimizer for Term Structure Calibration
 */
function nelderMead(
  costFn: (params: number[]) => number,
  initial: number[],
  step = 0.5,
  maxIter = 600,
  tol = 1e-5
): number[] {
  const n = initial.length;
  // Initialize simplex
  const simplex: { point: number[]; cost: number }[] = [];
  simplex.push({ point: [...initial], cost: costFn(initial) });

  for (let i = 0; i < n; i++) {
    const pt = [...initial];
    pt[i] += initial[i] !== 0 ? initial[i] * step : step;
    simplex.push({ point: pt, cost: costFn(pt) });
  }

  const alpha = 1.0; // reflection
  const gamma = 2.0; // expansion
  const rho = 0.5;   // contraction
  const sigma = 0.5; // shrink

  for (let iter = 0; iter < maxIter; iter++) {
    simplex.sort((a, b) => a.cost - b.cost);
    const best = simplex[0];
    const worst = simplex[n];
    const secondWorst = simplex[n - 1];

    if (Math.abs(worst.cost - best.cost) < tol) break;

    // Centroid of all points except worst
    const centroid = new Array(n).fill(0);
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        centroid[j] += simplex[i].point[j] / n;
      }
    }

    // Reflection
    const xr = centroid.map((c, j) => c + alpha * (c - worst.point[j]));
    const costR = costFn(xr);

    if (costR < secondWorst.cost && costR >= best.cost) {
      simplex[n] = { point: xr, cost: costR };
      continue;
    }

    // Expansion
    if (costR < best.cost) {
      const xe = centroid.map((c, j) => c + gamma * (xr[j] - c));
      const costE = costFn(xe);
      if (costE < costR) {
        simplex[n] = { point: xe, cost: costE };
      } else {
        simplex[n] = { point: xr, cost: costR };
      }
      continue;
    }

    // Contraction
    const xc = centroid.map((c, j) => c + rho * (worst.point[j] - c));
    const costC = costFn(xc);
    if (costC < worst.cost) {
      simplex[n] = { point: xc, cost: costC };
      continue;
    }

    // Shrink
    for (let i = 1; i <= n; i++) {
      simplex[i].point = simplex[i].point.map((pj, j) => best.point[j] + sigma * (pj - best.point[j]));
      simplex[i].cost = costFn(simplex[i].point);
    }
  }

  simplex.sort((a, b) => a.cost - b.cost);
  return simplex[0].point;
}

/**
 * Fit Nelson-Siegel Model to Observed Points
 */
export function fitNelsonSiegel(points: CurvePoint[]): { params: NelsonSiegelParams; diagnostics: ModelFitDiagnostics } {
  const sorted = [...points].sort((a, b) => a.maturity - b.maturity);
  const shortRate = sorted[0].yield;
  const longRate = sorted[sorted.length - 1].yield;

  const costFn = (p: number[]): number => {
    const [b0, b1, b2, rawLam] = p;
    const lam = Math.max(0.1, rawLam);
    let sse = 0;
    for (const pt of sorted) {
      const pred = evaluateNelsonSiegel(pt.maturity, { beta0: b0, beta1: b1, beta2: b2, lambda: lam });
      const err = pt.yield - pred;
      sse += err * err;
    }
    return sse;
  };

  const initial = [longRate, shortRate - longRate, 0.0, 1.8];
  const opt = nelderMead(costFn, initial);

  const params: NelsonSiegelParams = {
    beta0: opt[0],
    beta1: opt[1],
    beta2: opt[2],
    lambda: Math.max(0.05, opt[3]),
  };

  const diagnostics = calculateFitDiagnostics(points, (tau) => evaluateNelsonSiegel(tau, params), 4);
  return { params, diagnostics };
}

/**
 * Fit Svensson (NSS) Model to Observed Points
 */
export function fitSvensson(points: CurvePoint[]): { params: SvenssonParams; diagnostics: ModelFitDiagnostics } {
  const sorted = [...points].sort((a, b) => a.maturity - b.maturity);
  const shortRate = sorted[0].yield;
  const longRate = sorted[sorted.length - 1].yield;

  const costFn = (p: number[]): number => {
    const [b0, b1, b2, b3, rawLam1, rawLam2] = p;
    const lam1 = Math.max(0.1, rawLam1);
    const lam2 = Math.max(0.1, rawLam2);
    let sse = 0;
    for (const pt of sorted) {
      const pred = evaluateSvensson(pt.maturity, {
        beta0: b0,
        beta1: b1,
        beta2: b2,
        beta3: b3,
        lambda: lam1,
        lambda2: lam2,
      });
      const err = pt.yield - pred;
      sse += err * err;
    }
    return sse;
  };

  const initial = [longRate, shortRate - longRate, -0.5, 0.5, 1.5, 5.0];
  const opt = nelderMead(costFn, initial, 0.4, 800);

  const params: SvenssonParams = {
    beta0: opt[0],
    beta1: opt[1],
    beta2: opt[2],
    beta3: opt[3],
    lambda: Math.max(0.05, opt[4]),
    lambda2: Math.max(0.05, opt[5]),
  };

  const diagnostics = calculateFitDiagnostics(points, (tau) => evaluateSvensson(tau, params), 6);
  return { params, diagnostics };
}

/**
 * Compute institutional econometric goodness-of-fit metrics
 */
export function calculateFitDiagnostics(
  points: CurvePoint[],
  modelFn: (maturity: number) => number,
  paramCount: number
): ModelFitDiagnostics {
  const n = points.length;
  if (n === 0) {
    return { rmse: 0, mae: 0, rSquared: 1, aic: 0, bic: 0, maxResidual: 0, residuals: [] };
  }

  let sse = 0;
  let sae = 0;
  let maxRes = 0;
  let sumY = 0;

  const residuals = points.map((pt) => {
    const fitted = modelFn(pt.maturity);
    const res = pt.yield - fitted;
    const resBps = res * 100;
    sse += res * res;
    sae += Math.abs(res);
    sumY += pt.yield;
    if (Math.abs(resBps) > maxRes) maxRes = Math.abs(resBps);
    return {
      maturity: pt.maturity,
      observed: pt.yield,
      fitted: fitted,
      residualBps: resBps,
    };
  });

  const meanY = sumY / n;
  let sst = 0;
  for (const pt of points) {
    sst += Math.pow(pt.yield - meanY, 2);
  }

  const rmseBps = Math.sqrt(sse / n) * 100;
  const maeBps = (sae / n) * 100;
  const rSquared = sst > 1e-9 ? Math.max(0, 1 - sse / sst) : 1;

  // AIC & BIC
  const k = paramCount;
  const aic = n * Math.log(Math.max(1e-9, sse / n)) + 2 * k;
  const bic = n * Math.log(Math.max(1e-9, sse / n)) + k * Math.log(n);

  return {
    rmse: rmseBps,
    mae: maeBps,
    rSquared,
    aic,
    bic,
    maxResidual: maxRes,
    residuals,
  };
}
