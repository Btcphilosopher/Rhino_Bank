/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Curve Geometry, Derivations, Inflection Point & Formation Classification Engine
 * Namespace: rhinoquant::geometry
 */

import { CurvePoint, CurveFormationType, GeometryMetrics, InflectionPoint } from '../types/rhino';
import { EvaluatedCurvePoint } from './interpolations';

/**
 * Classify yield curve formation mathematically
 */
export function classifyCurveFormation(
  denseGrid: EvaluatedCurvePoint[],
  points: CurvePoint[]
): { formation: CurveFormationType; description: string; confidence: number } {
  if (denseGrid.length < 5) {
    return { formation: 'NORMAL', description: 'Insufficient data points', confidence: 0.5 };
  }

  const sorted = [...points].sort((a, b) => a.maturity - b.maturity);
  const shortRate = sorted[0].yield;
  const longRate = sorted[sorted.length - 1].yield;
  const spread30s3m = (longRate - shortRate) * 100; // in bps

  // Find local extrema in interior (0.5Y to 25Y)
  const interior = denseGrid.filter((p) => p.maturity >= 0.5 && p.maturity <= 25);
  let localMaximaCount = 0;
  let localMinimaCount = 0;
  let hasInteriorPeak = false;
  let hasInteriorTrough = false;

  for (let i = 1; i < interior.length - 1; i++) {
    const prev = interior[i - 1];
    const curr = interior[i];
    const next = interior[i + 1];

    if (curr.yield > prev.yield + 0.005 && curr.yield > next.yield + 0.005 && curr.slope * prev.slope <= 0) {
      localMaximaCount++;
      hasInteriorPeak = true;
    }
    if (curr.yield < prev.yield - 0.005 && curr.yield < next.yield - 0.005 && curr.slope * prev.slope <= 0) {
      localMinimaCount++;
      hasInteriorTrough = true;
    }
  }

  // Check curvature sign changes
  let curvatureSignChanges = 0;
  for (let i = 1; i < denseGrid.length; i++) {
    if (denseGrid[i].curvature * denseGrid[i - 1].curvature < -0.01) {
      curvatureSignChanges++;
    }
  }

  // 1. Double Humped
  if (localMaximaCount >= 2 && localMinimaCount >= 1) {
    return {
      formation: 'DOUBLE_HUMPED',
      description: 'Term structure displays two distinct local rate maxima separated by an interior belly trough.',
      confidence: 0.95,
    };
  }

  // 2. S-Shaped
  if (curvatureSignChanges >= 2 && (hasInteriorPeak || hasInteriorTrough)) {
    return {
      formation: 'S_SHAPED',
      description: 'Multiple inflection points and alternating slope curvature along the term structure.',
      confidence: 0.9,
    };
  }

  // 3. Humped Curve
  if (hasInteriorPeak && !hasInteriorTrough) {
    return {
      formation: 'HUMPED',
      description: 'Rates rise in intermediate maturities (belly hump) before decaying towards the long end.',
      confidence: 0.94,
    };
  }

  // 4. U-Shaped (Inverted Belly / Sagging Curve)
  if (hasInteriorTrough && !hasInteriorPeak) {
    return {
      formation: 'U_SHAPED',
      description: 'Medium-term yields drop below front and long ends, creating a concave term structure basin.',
      confidence: 0.92,
    };
  }

  // 5. Inverted
  if (spread30s3m < -15 || (sorted.length > 2 && sorted[1].yield > longRate + 0.15)) {
    return {
      formation: 'INVERTED',
      description: 'Short-term yields exceed long-term yields, reflecting tight monetary policy / expected rate cuts.',
      confidence: 0.98,
    };
  }

  // 6. Flat
  if (Math.abs(spread30s3m) <= 15) {
    return {
      formation: 'FLAT',
      description: 'Near-zero term premium across 3M to 30Y with minimal maturity slope divergence.',
      confidence: 0.91,
    };
  }

  // 7. Normal / Positively Sloped
  return {
    formation: 'NORMAL',
    description: 'Positive upward sloping term structure with healthy term premium compensation across maturities.',
    confidence: 0.96,
  };
}

/**
 * Locate Critical Inflection Points, Maxima, Minima, and Curvature Extremes
 */
export function extractInflectionPoints(denseGrid: EvaluatedCurvePoint[]): InflectionPoint[] {
  const points: InflectionPoint[] = [];
  if (denseGrid.length < 3) return points;

  // Extrema: Slope = 0
  for (let i = 1; i < denseGrid.length - 1; i++) {
    const prev = denseGrid[i - 1];
    const curr = denseGrid[i];
    const next = denseGrid[i + 1];

    // Local Peak
    if (curr.yield > prev.yield && curr.yield > next.yield && curr.yield > prev.yield + 0.002) {
      points.push({
        maturity: Number(curr.maturity.toFixed(2)),
        yield: Number(curr.yield.toFixed(3)),
        type: 'LOCAL_MAX',
        label: `Peak (${curr.maturity.toFixed(1)}Y @ ${curr.yield.toFixed(2)}%)`,
        slope: Number(curr.slope.toFixed(2)),
        curvature: Number(curr.curvature.toFixed(2)),
      });
    }

    // Local Trough
    if (curr.yield < prev.yield && curr.yield < next.yield && curr.yield < prev.yield - 0.002) {
      points.push({
        maturity: Number(curr.maturity.toFixed(2)),
        yield: Number(curr.yield.toFixed(3)),
        type: 'LOCAL_MIN',
        label: `Trough (${curr.maturity.toFixed(1)}Y @ ${curr.yield.toFixed(2)}%)`,
        slope: Number(curr.slope.toFixed(2)),
        curvature: Number(curr.curvature.toFixed(2)),
      });
    }

    // Inflection Point: Curvature sign change d²Y/dX² = 0
    if (prev.curvature * next.curvature < -0.05 && Math.abs(curr.curvature) < Math.abs(prev.curvature) + 0.5) {
      points.push({
        maturity: Number(curr.maturity.toFixed(2)),
        yield: Number(curr.yield.toFixed(3)),
        type: 'INFLECTION',
        label: `Inflection d²Y/dX²=0 (${curr.maturity.toFixed(1)}Y)`,
        slope: Number(curr.slope.toFixed(2)),
        curvature: Number(curr.curvature.toFixed(2)),
      });
    }
  }

  // Maximum and Minimum Slope
  let maxSlopePt = denseGrid[0];
  let minSlopePt = denseGrid[0];
  let maxCurvPt = denseGrid[0];

  for (const pt of denseGrid) {
    if (pt.slope > maxSlopePt.slope) maxSlopePt = pt;
    if (pt.slope < minSlopePt.slope) minSlopePt = pt;
    if (Math.abs(pt.curvature) > Math.abs(maxCurvPt.curvature)) maxCurvPt = pt;
  }

  points.push({
    maturity: Number(maxSlopePt.maturity.toFixed(2)),
    yield: Number(maxSlopePt.yield.toFixed(3)),
    type: 'MAX_SLOPE',
    label: `Max Slope (${maxSlopePt.maturity.toFixed(1)}Y, +${maxSlopePt.slope.toFixed(1)} bps/yr)`,
    slope: Number(maxSlopePt.slope.toFixed(2)),
    curvature: Number(maxSlopePt.curvature.toFixed(2)),
  });

  points.push({
    maturity: Number(maxCurvPt.maturity.toFixed(2)),
    yield: Number(maxCurvPt.yield.toFixed(3)),
    type: 'MAX_CURVATURE',
    label: `Max Curvature (${maxCurvPt.maturity.toFixed(1)}Y, ${maxCurvPt.curvature.toFixed(1)} bps/yr²)`,
    slope: Number(maxCurvPt.slope.toFixed(2)),
    curvature: Number(maxCurvPt.curvature.toFixed(2)),
  });

  return points;
}

/**
 * Compute Complete Geometry Metrics for a RhinoCurve
 */
export function computeGeometryMetrics(
  points: CurvePoint[],
  denseGrid: EvaluatedCurvePoint[]
): GeometryMetrics {
  const sorted = [...points].sort((a, b) => a.maturity - b.maturity);
  const yields = sorted.map((p) => p.yield);
  const meanYield = yields.reduce((a, b) => a + b, 0) / Math.max(1, yields.length);

  // Spreads
  const findYield = (targetTau: number): number => {
    let closest = sorted[0];
    let minDiff = 999;
    for (const p of sorted) {
      const diff = Math.abs(p.maturity - targetTau);
      if (diff < minDiff) {
        minDiff = diff;
        closest = p;
      }
    }
    return closest.yield;
  };

  const y3M = findYield(0.25);
  const y2Y = findYield(2.0);
  const y5Y = findYield(5.0);
  const y10Y = findYield(10.0);
  const y30Y = findYield(30.0);

  const spread2s10s = (y10Y - y2Y) * 100;
  const spread3Ms10s = (y10Y - y3M) * 100;
  const spread5s30s = (y30Y - y5Y) * 100;
  const butterfly2s5s10s = (2 * y5Y - y2Y - y10Y) * 100;

  const inflections = extractInflectionPoints(denseGrid);
  const formationInfo = classifyCurveFormation(denseGrid, points);

  let maxSlope = -999999;
  let maxSlopeTau = 0;
  let minSlope = 999999;
  let minSlopeTau = 0;
  let maxCurv = 0;
  let maxCurvTau = 0;

  for (const p of denseGrid) {
    if (p.slope > maxSlope) {
      maxSlope = p.slope;
      maxSlopeTau = p.maturity;
    }
    if (p.slope < minSlope) {
      minSlope = p.slope;
      minSlopeTau = p.maturity;
    }
    if (Math.abs(p.curvature) > Math.abs(maxCurv)) {
      maxCurv = p.curvature;
      maxCurvTau = p.maturity;
    }
  }

  // Find steepest and flattest 2-year segments
  let steepest = { start: 1, end: 3, slope: 0 };
  let flattest = { start: 10, end: 12, slope: 9999 };
  for (let i = 0; i < denseGrid.length - 20; i++) {
    const p1 = denseGrid[i];
    const p2 = denseGrid[i + 20];
    const segSlope = Math.abs((p2.yield - p1.yield) / (p2.maturity - p1.maturity)) * 100;
    if (segSlope > steepest.slope) {
      steepest = { start: p1.maturity, end: p2.maturity, slope: segSlope };
    }
    if (segSlope < flattest.slope) {
      flattest = { start: p1.maturity, end: p2.maturity, slope: segSlope };
    }
  }

  return {
    formation: formationInfo.formation,
    formationDescription: formationInfo.description,
    formationConfidence: formationInfo.confidence,
    levelMean: meanYield,
    spread2s10s,
    spread3Ms10s,
    spread5s30s,
    butterfly2s5s10s,
    maxSlopeMaturity: maxSlopeTau,
    maxSlopeValue: maxSlope,
    minSlopeMaturity: minSlopeTau,
    minSlopeValue: minSlope,
    maxCurvatureMaturity: maxCurvTau,
    maxCurvatureValue: maxCurv,
    inflectionPoints: inflections,
    steepestSegment: steepest,
    flattestSegment: flattest,
  };
}
