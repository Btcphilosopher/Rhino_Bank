/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Scenario Stress Testing & Macro Shock Lab
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { Zap, ShieldAlert, BarChart3, TrendingDown, TrendingUp, CheckCircle } from 'lucide-react';
import { RhinoCurve, ScenarioDefinition } from '../types/rhino';
import { PRESET_SCENARIOS, applyScenarioToPoints } from '../math/transformations';
import { generateDenseCurveGrid } from '../math/interpolations';

interface ScenarioLabProps {
  activeCurve: RhinoCurve;
  activeScenario: ScenarioDefinition;
  onSelectScenario: (scenario: ScenarioDefinition) => void;
}

export const ScenarioLab: React.FC<ScenarioLabProps> = ({
  activeCurve,
  activeScenario,
  onSelectScenario,
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const [selectedScenarios, setSelectedScenarios] = useState<string[]>([activeScenario.id, 'bear_steepener', 'bull_steepener', 'gfc_2008']);

  // Compute dense grid for all selected scenarios
  const scenarioData = useMemo(() => {
    return PRESET_SCENARIOS.filter((s) => selectedScenarios.includes(s.id)).map((s) => {
      const shockedPts = applyScenarioToPoints(activeCurve.points, s);
      const grid = generateDenseCurveGrid(shockedPts, activeCurve.interpolationMethod);
      return {
        scenario: s,
        points: shockedPts,
        grid,
      };
    });
  }, [activeCurve, selectedScenarios]);

  // Baseline Grid
  const baselineGrid = useMemo(() => {
    return generateDenseCurveGrid(activeCurve.points, activeCurve.interpolationMethod);
  }, [activeCurve]);

  const handleToggleScenario = (id: string) => {
    if (selectedScenarios.includes(id)) {
      if (selectedScenarios.length > 1) {
        setSelectedScenarios(selectedScenarios.filter((s) => s !== id));
      }
    } else {
      setSelectedScenarios([...selectedScenarios, id]);
    }
  };

  // Render Multi-Scenario Chart
  useEffect(() => {
    if (!chartRef.current) return;

    const traces: Plotly.Data[] = [
      {
        x: baselineGrid.map((p) => p.maturity),
        y: baselineGrid.map((p) => p.yield),
        type: 'scatter',
        mode: 'lines',
        name: 'Baseline Curve',
        line: { color: '#E0E0E0', width: 2.5 },
      },
      ...scenarioData.map((s) => ({
        x: s.grid.map((p) => p.maturity),
        y: s.grid.map((p) => p.yield),
        type: 'scatter' as const,
        mode: 'lines' as const,
        name: s.scenario.name,
        line: { color: s.scenario.color || '#F27D26', width: 2, dash: s.scenario.id === activeScenario.id ? 'solid' : 'dash' },
      })),
    ];

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 55, r: 20, t: 25, b: 45 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Yield (%)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      legend: { orientation: 'h', y: 1.15, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(chartRef.current, traces, layout, { responsive: true, displaylogo: false });
  }, [baselineGrid, scenarioData, activeScenario]);

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">SCENARIO STRESS & CRISIS LAB</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Historical crises, monetary regime shocks, steepening/flattening twists & butterfly dislocations
            </p>
          </div>
        </div>

        <div className="text-xs font-mono text-[#8E9299]">
          Active: <span className="font-bold text-[#F27D26]">{activeScenario.name}</span>
        </div>
      </div>

      {/* Main Grid: Scenario Selector & Risk Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Scenario Selection List */}
        <div className="lg:col-span-4 bg-[#16181D] p-4 rounded border border-[#1E2024] space-y-3">
          <div className="flex items-center justify-between border-b border-[#2A2D33] pb-2">
            <span className="font-mono text-xs font-bold text-white uppercase tracking-wider">SCENARIO LIBRARY ({PRESET_SCENARIOS.length})</span>
            <span className="text-[10px] font-mono text-[#8E9299]">Select to compare</span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1 scrollbar-thin">
            {PRESET_SCENARIOS.map((s) => {
              const isSelected = selectedScenarios.includes(s.id);
              const isActive = activeScenario.id === s.id;

              return (
                <div
                  key={s.id}
                  className={`p-2.5 rounded border transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#1A1C21] border-[#F27D26] shadow-sm'
                      : isSelected
                      ? 'bg-[#1A1C21] border-[#2A2D33]'
                      : 'bg-[#0E1013] border-[#1E2024] opacity-70 hover:opacity-100'
                  }`}
                  onClick={() => onSelectScenario(s)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color || '#8E9299' }} />
                      <span className="font-mono text-xs font-bold text-white">{s.name}</span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleScenario(s.id);
                      }}
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                        isSelected ? 'bg-[#0E1013] text-[#F27D26] border-[#F27D26]/40' : 'bg-[#0E1013] text-[#8E9299] border-[#2A2D33]'
                      }`}
                    >
                      {isSelected ? 'Charted' : 'Overlay'}
                    </button>
                  </div>
                  <p className="text-[11px] text-[#8E9299] font-sans leading-relaxed">{s.description}</p>
                  <div className="mt-2 flex items-center gap-3 text-[10px] font-mono text-[#8E9299]">
                    <span>Parallel: {s.parallelShiftBps > 0 ? `+${s.parallelShiftBps}` : s.parallelShiftBps} bp</span>
                    <span>Tilt: {s.slopeTiltBps > 0 ? `+${s.slopeTiltBps}` : s.slopeTiltBps} bp</span>
                    <span>Belly: {s.bellyShiftBps > 0 ? `+${s.bellyShiftBps}` : s.bellyShiftBps} bp</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Multi-Scenario Chart & Risk Matrix */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-[#0E1013] p-4 rounded border border-[#1E2024]">
            <div className="flex items-center justify-between mb-1">
              <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">MULTI-SCENARIO OVERLAY VISUALIZATION</span>
              <span className="text-xs font-mono text-[#8E9299]">Showing {selectedScenarios.length} Scenarios</span>
            </div>
            <div ref={chartRef} className="w-full h-[360px]" />
          </div>

          {/* Scenario Impact Matrix Table */}
          <div className="bg-[#16181D] p-4 rounded border border-[#1E2024]">
            <span className="font-mono text-xs font-bold text-white uppercase tracking-wider block mb-2">SCENARIO RISK & SPREAD IMPACT MATRIX</span>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono">
                <thead>
                  <tr className="text-[#8E9299] border-b border-[#2A2D33] text-left">
                    <th className="py-1 px-2">Scenario</th>
                    <th className="py-1 px-2">2Y Shock</th>
                    <th className="py-1 px-2">5Y Shock</th>
                    <th className="py-1 px-2">10Y Shock</th>
                    <th className="py-1 px-2">30Y Shock</th>
                    <th className="py-1 px-2">Δ 2s10s</th>
                    <th className="py-1 px-2">Est. $10M P&L</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E2024]">
                  {scenarioData.map((s) => {
                    const base2Y = activeCurve.points.find((p) => p.tenor === '2Y')?.yield || 4.15;
                    const base5Y = activeCurve.points.find((p) => p.tenor === '5Y')?.yield || 4.38;
                    const base10Y = activeCurve.points.find((p) => p.tenor === '10Y')?.yield || 4.62;
                    const base30Y = activeCurve.points.find((p) => p.tenor === '30Y')?.yield || 4.95;

                    const scn2Y = s.points.find((p) => p.tenor === '2Y')?.yield || base2Y;
                    const scn5Y = s.points.find((p) => p.tenor === '5Y')?.yield || base5Y;
                    const scn10Y = s.points.find((p) => p.tenor === '10Y')?.yield || base10Y;
                    const scn30Y = s.points.find((p) => p.tenor === '30Y')?.yield || base30Y;

                    const delta2Y = (scn2Y - base2Y) * 100;
                    const delta5Y = (scn5Y - base5Y) * 100;
                    const delta10Y = (scn10Y - base10Y) * 100;
                    const delta30Y = (scn30Y - base30Y) * 100;
                    const delta2s10s = delta10Y - delta2Y;

                    // Approximate 10M DV01 P&L ($10M with 6.5Y duration -> DV01 ≈ $6,500)
                    const pnl = -(delta10Y * 6500);

                    return (
                      <tr key={s.scenario.id} className="hover:bg-[#1A1C21]">
                        <td className="py-1.5 px-2 font-bold text-white flex items-center gap-1.5">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.scenario.color || '#8E9299' }} />
                          <span>{s.scenario.name}</span>
                        </td>
                        <td className="py-1.5 px-2 text-[#4FC3F7]">{delta2Y > 0 ? `+${delta2Y.toFixed(1)}` : delta2Y.toFixed(1)} bp</td>
                        <td className="py-1.5 px-2 text-[#4CAF50]">{delta5Y > 0 ? `+${delta5Y.toFixed(1)}` : delta5Y.toFixed(1)} bp</td>
                        <td className="py-1.5 px-2 text-[#F27D26]">{delta10Y > 0 ? `+${delta10Y.toFixed(1)}` : delta10Y.toFixed(1)} bp</td>
                        <td className="py-1.5 px-2 text-[#E0E0E0]">{delta30Y > 0 ? `+${delta30Y.toFixed(1)}` : delta30Y.toFixed(1)} bp</td>
                        <td className="py-1.5 px-2 font-bold text-white">
                          {delta2s10s > 0 ? `+${delta2s10s.toFixed(1)}` : delta2s10s.toFixed(1)} bp
                        </td>
                        <td className={`py-1.5 px-2 font-bold ${pnl >= 0 ? 'text-[#4CAF50]' : 'text-[#E91E63]'}`}>
                          {pnl >= 0 ? `+$${(pnl / 1000).toFixed(1)}k` : `-$${Math.abs(pnl / 1000).toFixed(1)}k`}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
