/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Central Workspace: RHINOQUANT CURVE MACHINE
 * Multi-Axis Engine, Derivative Analyzers & Inflection Point HUD
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import Plotly from 'plotly.js-dist-min';
import {
  Activity,
  Layers,
  Sparkles,
  TrendingUp,
  Maximize2,
  Minimize2,
  Info,
  Sliders,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import {
  RhinoCurve,
  XAxisVariable,
  YAxisVariable,
  AxisConfig,
  GeometryMetrics,
  ScenarioDefinition,
  FixedIncomeMetrics,
} from '../types/rhino';
import { generateDenseCurveGrid, EvaluatedCurvePoint } from '../math/interpolations';
import { computeDenseFixedIncomeAnalytics } from '../math/fixedIncome';
import { evaluateNelsonSiegelFull, fitNelsonSiegel } from '../math/nelsonSiegel';
import { applyScenarioToPoints, PRESET_SCENARIOS } from '../math/transformations';

interface CurveMachineProps {
  activeCurve: RhinoCurve;
  geometry: GeometryMetrics;
  denseGrid: EvaluatedCurvePoint[];
  fixedIncomeMetrics: FixedIncomeMetrics[];
  onOpenAiModal: () => void;
  activeScenario?: ScenarioDefinition;
  onSelectScenario?: (scenario: ScenarioDefinition) => void;
}

export const CurveMachine: React.FC<CurveMachineProps> = ({
  activeCurve,
  geometry,
  denseGrid,
  fixedIncomeMetrics,
  onOpenAiModal,
  activeScenario = PRESET_SCENARIOS[0],
  onSelectScenario,
}) => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const derivativeChartRef = useRef<HTMLDivElement>(null);

  // Axis Engine Configuration
  const [axisConfig, setAxisConfig] = useState<AxisConfig>({
    xVar: 'MATURITY_YEARS',
    yVar: 'YIELD',
    xScale: 'linear',
    yScale: 'linear',
    inflationAssumption: 2.2,
  });

  // Display toggles
  const [showObservedPoints, setShowObservedPoints] = useState(true);
  const [showInflectionMarkers, setShowInflectionMarkers] = useState(true);
  const [showFittedOverlay, setShowFittedOverlay] = useState(false);
  const [showScenarioOverlay, setShowScenarioOverlay] = useState(true);
  const [showDerivativePane, setShowDerivativePane] = useState(true);
  const [derivativeMode, setDerivativeMode] = useState<'SLOPE' | 'CURVATURE' | 'BOTH'>('BOTH');

  // Compute Stressed Scenario Curve
  const scenarioPoints = useMemo(() => {
    return applyScenarioToPoints(activeCurve.points, activeScenario);
  }, [activeCurve.points, activeScenario]);

  const scenarioGrid = useMemo(() => {
    return generateDenseCurveGrid(scenarioPoints, activeCurve.interpolationMethod);
  }, [scenarioPoints, activeCurve.interpolationMethod]);

  // Compute Nelson-Siegel Fit
  const nsFit = useMemo(() => {
    return fitNelsonSiegel(activeCurve.points);
  }, [activeCurve.points]);

  const nsGrid = useMemo(() => {
    return denseGrid.map((p) => evaluateNelsonSiegelFull(p.maturity, nsFit.params));
  }, [denseGrid, nsFit.params]);

  // Axis Engine: Transform X coordinates
  const mapXValue = (tau: number, fi?: FixedIncomeMetrics, index = 0): number => {
    switch (axisConfig.xVar) {
      case 'MATURITY_MONTHS':
        return tau * 12;
      case 'MATURITY_DAYS':
        return tau * 365.25;
      case 'LOG_MATURITY':
        return Math.log(Math.max(0.01, tau));
      case 'DURATION':
        return fi ? fi.macaulayDuration : tau * 0.85;
      case 'MODIFIED_DURATION':
        return fi ? fi.modifiedDuration : tau * 0.82;
      case 'DV01':
        return fi ? fi.dv01 : tau * 8.2;
      case 'FORWARD_PERIOD':
        return tau + 1.0;
      case 'OBSERVATION_INDEX':
        return index + 1;
      case 'MATURITY_YEARS':
      default:
        return tau;
    }
  };

  const getXAxisTitle = (): string => {
    switch (axisConfig.xVar) {
      case 'MATURITY_MONTHS':
        return 'Maturity (Months)';
      case 'MATURITY_DAYS':
        return 'Maturity (Days)';
      case 'LOG_MATURITY':
        return 'ln(Maturity in Years)';
      case 'DURATION':
        return 'Macaulay Duration (Years)';
      case 'MODIFIED_DURATION':
        return 'Modified Duration (Years)';
      case 'DV01':
        return 'DV01 ($ per $100k Par)';
      case 'FORWARD_PERIOD':
        return 'Forward Expiry (Years)';
      case 'OBSERVATION_INDEX':
        return 'Observation Index (k)';
      case 'MATURITY_YEARS':
      default:
        return 'Maturity (Years)';
    }
  };

  // Axis Engine: Transform Y coordinates
  const mapYValue = (p: EvaluatedCurvePoint, fi?: FixedIncomeMetrics): number => {
    switch (axisConfig.yVar) {
      case 'ZERO_RATE':
      case 'SPOT_RATE':
      case 'NOMINAL_YIELD':
      case 'YIELD':
        return p.yield;
      case 'PAR_RATE':
        return p.yield;
      case 'INSTANTANEOUS_FORWARD':
        return fi ? fi.instantaneousForward : p.yield + p.maturity * (p.slope / 100);
      case 'FORWARD_RATE':
        return fi ? fi.forwardRate1Y : p.yield + 0.15;
      case 'REAL_YIELD':
        return p.yield - (axisConfig.inflationAssumption || 2.2);
      case 'INFLATION_EXPECTATION':
        return axisConfig.inflationAssumption || 2.2;
      case 'SPREAD':
        return (p.yield - activeCurve.points[0].yield) * 100; // Spread to 1M/3M in bps
      case 'DISCOUNT_FACTOR':
        return fi ? fi.discountFactor : Math.exp(-(p.yield / 100) * p.maturity);
      case 'PRICE':
        return fi ? fi.bondPrice100 : 100 * Math.exp(-(p.yield / 100) * p.maturity);
      case 'DURATION':
        return fi ? fi.modifiedDuration : p.maturity * 0.82;
      case 'CONVEXITY':
        return fi ? fi.convexity : Math.pow(p.maturity, 2) * 0.75;
      case 'SLOPE_DERIVATIVE':
        return p.slope; // bps/yr
      case 'CURVATURE_DERIVATIVE':
        return p.curvature; // bps/yr²
      case 'YIELD_CHANGE':
        return 0;
      default:
        return p.yield;
    }
  };

  const getYAxisTitle = (): string => {
    switch (axisConfig.yVar) {
      case 'ZERO_RATE':
        return 'Zero Rate (%)';
      case 'PAR_RATE':
        return 'Par Rate (%)';
      case 'INSTANTANEOUS_FORWARD':
        return 'Instantaneous Forward Rate f(τ) (%)';
      case 'FORWARD_RATE':
        return '1-Year Forward Rate (%)';
      case 'REAL_YIELD':
        return `Real Yield (%) [Inflation ${axisConfig.inflationAssumption}%]`;
      case 'SPREAD':
        return 'Spread to Short-End (bps)';
      case 'DISCOUNT_FACTOR':
        return 'Discount Factor D(τ)';
      case 'PRICE':
        return 'Par Bond Price ($ per $100)';
      case 'DURATION':
        return 'Modified Duration (Years)';
      case 'CONVEXITY':
        return 'Convexity (Years²)';
      case 'SLOPE_DERIVATIVE':
        return 'Slope dY/dX (bps/year)';
      case 'CURVATURE_DERIVATIVE':
        return 'Curvature d²Y/dX² (bps/year²)';
      case 'YIELD':
      default:
        return 'Yield to Maturity (%)';
    }
  };

  // Render Main Interactive Chart via Plotly
  useEffect(() => {
    if (!chartContainerRef.current) return;

    // 1. Primary Interpolated / Model Curve
    const xValues = denseGrid.map((p, i) => mapXValue(p.maturity, fixedIncomeMetrics[i], i));
    const yValues = denseGrid.map((p, i) => mapYValue(p, fixedIncomeMetrics[i]));

    const traces: Plotly.Data[] = [
      {
        x: xValues,
        y: yValues,
        type: 'scatter',
        mode: 'lines',
        name: `Active Curve (${activeCurve.interpolationMethod})`,
        line: { color: '#F27D26', width: 2.5 },
        hovertemplate: `<b>${getXAxisTitle()}</b>: %{x:.2f}<br><b>${getYAxisTitle()}</b>: %{y:.3f}<extra></extra>`,
      },
    ];

    // 2. Observed Knot Points
    if (showObservedPoints) {
      const obsX = activeCurve.points.map((p, i) => mapXValue(p.maturity, undefined, i));
      const obsY = activeCurve.points.map((p) => {
        const evalPt: EvaluatedCurvePoint = { maturity: p.maturity, yield: p.yield, slope: 0, curvature: 0 };
        return mapYValue(evalPt);
      });

      traces.push({
        x: obsX,
        y: obsY,
        type: 'scatter',
        mode: 'markers+text',
        name: 'Observed Tenors',
        text: activeCurve.points.map((p) => p.tenor),
        textposition: 'top center',
        textfont: { family: 'monospace', size: 10, color: '#8E9299' },
        marker: {
          color: '#F27D26',
          size: 7,
          symbol: 'circle',
          line: { color: '#FFFFFF', width: 1 },
        },
        hovertemplate: '<b>Tenor</b>: %{text}<br><b>X</b>: %{x:.2f}<br><b>Y</b>: %{y:.3f}%<extra></extra>',
      });
    }

    // 3. Fitted Nelson-Siegel Overlay
    if (showFittedOverlay) {
      const nsX = nsGrid.map((p, i) => mapXValue(p.maturity, undefined, i));
      const nsY = nsGrid.map((p) => mapYValue(p));

      traces.push({
        x: nsX,
        y: nsY,
        type: 'scatter',
        mode: 'lines',
        name: `Nelson-Siegel Fit (RMSE: ${nsFit.diagnostics.rmse.toFixed(1)} bp)`,
        line: { color: '#8E9299', width: 1.5, dash: 'dash' },
        hovertemplate: '<b>NS Fit</b>: %{y:.3f}%<extra></extra>',
      });
    }

    // 4. Stressed Scenario Overlay
    if (showScenarioOverlay && activeScenario.id !== 'baseline') {
      const scnFI = computeDenseFixedIncomeAnalytics(scenarioGrid);
      const scnX = scenarioGrid.map((p, i) => mapXValue(p.maturity, scnFI[i], i));
      const scnY = scenarioGrid.map((p, i) => mapYValue(p, scnFI[i]));

      traces.push({
        x: scnX,
        y: scnY,
        type: 'scatter',
        mode: 'lines',
        name: `Scenario: ${activeScenario.name}`,
        line: { color: activeScenario.color || '#4FC3F7', width: 2, dash: 'dot' },
        hovertemplate: '<b>Stressed</b>: %{y:.3f}%<extra></extra>',
      });
    }

    // 5. Inflection Point Markers
    if (showInflectionMarkers && geometry.inflectionPoints.length > 0) {
      const infX = geometry.inflectionPoints.map((inf) => mapXValue(inf.maturity));
      const infY = geometry.inflectionPoints.map((inf) => {
        const pt: EvaluatedCurvePoint = {
          maturity: inf.maturity,
          yield: inf.yield,
          slope: inf.slope,
          curvature: inf.curvature,
        };
        return mapYValue(pt);
      });

      traces.push({
        x: infX,
        y: infY,
        type: 'scatter',
        mode: 'markers+text',
        name: 'Critical Inflections & Extrema',
        text: geometry.inflectionPoints.map((inf) => inf.type.replace('_', ' ')),
        textposition: 'bottom center',
        textfont: { family: 'monospace', size: 9, color: '#4CAF50' },
        marker: {
          color: geometry.inflectionPoints.map((inf) =>
            inf.type === 'LOCAL_MAX'
              ? '#F27D26'
              : inf.type === 'LOCAL_MIN'
              ? '#4FC3F7'
              : inf.type === 'INFLECTION'
              ? '#4CAF50'
              : '#E91E63'
          ),
          size: 9,
          symbol: 'circle-open-dot',
          line: { width: 2 },
        },
        hovertemplate: '<b>%{text}</b><br>Maturity: %{x:.2f}Y<br>Yield: %{y:.3f}%<extra></extra>',
      });
    }

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 60, r: 20, t: 25, b: 45 },
      hovermode: 'x unified',
      xaxis: {
        title: { text: getXAxisTitle(), font: { size: 11, color: '#8E9299' } },
        gridcolor: '#1E2024',
        zerolinecolor: '#2A2D33',
        type: axisConfig.xScale,
      },
      yaxis: {
        title: { text: getYAxisTitle(), font: { size: 11, color: '#8E9299' } },
        gridcolor: '#1E2024',
        zerolinecolor: '#2A2D33',
        type: axisConfig.yScale,
      },
      legend: {
        orientation: 'h',
        y: 1.12,
        x: 0,
        font: { size: 9, color: '#8E9299' },
      },
      showlegend: true,
    };

    const config: Partial<Plotly.Config> = {
      responsive: true,
      displayModeBar: true,
      displaylogo: false,
      modeBarButtonsToRemove: ['lasso2d', 'select2d'],
    };

    Plotly.react(chartContainerRef.current, traces, layout, config);
  }, [
    denseGrid,
    activeCurve,
    axisConfig,
    showObservedPoints,
    showInflectionMarkers,
    showFittedOverlay,
    showScenarioOverlay,
    scenarioGrid,
    nsGrid,
    geometry,
  ]);

  // Render Derivative Plot (Slope & Curvature)
  useEffect(() => {
    if (!derivativeChartRef.current || !showDerivativePane) return;

    const xValues = denseGrid.map((p) => p.maturity);
    const slopeValues = denseGrid.map((p) => p.slope);
    const curvValues = denseGrid.map((p) => p.curvature);

    const traces: Plotly.Data[] = [];

    if (derivativeMode === 'SLOPE' || derivativeMode === 'BOTH') {
      traces.push({
        x: xValues,
        y: slopeValues,
        type: 'scatter',
        mode: 'lines',
        name: 'Slope dY/dX (bps/yr)',
        line: { color: '#F27D26', width: 2 },
        hovertemplate: '<b>Slope</b>: %{y:.2f} bps/yr<extra></extra>',
      });
    }

    if (derivativeMode === 'CURVATURE' || derivativeMode === 'BOTH') {
      traces.push({
        x: xValues,
        y: curvValues,
        type: 'scatter',
        mode: 'lines',
        name: 'Curvature d²Y/dX² (bps/yr²)',
        line: { color: '#4CAF50', width: 2, dash: 'dot' },
        hovertemplate: '<b>Curvature</b>: %{y:.2f} bps/yr²<extra></extra>',
      });
    }

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 15, t: 20, b: 35 },
      hovermode: 'x unified',
      xaxis: {
        title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } },
        gridcolor: '#1E2024',
      },
      yaxis: {
        title: { text: 'Derivatives', font: { size: 10, color: '#8E9299' } },
        gridcolor: '#1E2024',
        zerolinecolor: '#2A2D33',
        zerolinewidth: 1,
      },
      legend: {
        orientation: 'h',
        y: 1.15,
        x: 0,
        font: { size: 9 },
      },
    };

    Plotly.react(derivativeChartRef.current, traces, layout, { responsive: true, displaylogo: false });
  }, [denseGrid, showDerivativePane, derivativeMode]);

  return (
    <div className="space-y-4">
      {/* Top HUD: Formation Classification & Key Geometry Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3">
        {/* Formation Badge */}
        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024] col-span-1 md:col-span-2 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-[#8E9299] uppercase tracking-wider">Formation Classification</span>
            <span className="text-[10px] font-mono text-[#4CAF50] bg-[#1A1C21] px-2 py-0.5 rounded border border-[#2A2D33]">
              {(geometry.formationConfidence * 100).toFixed(0)}% Conf
            </span>
          </div>
          <div className="my-1.5 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#F27D26]" />
            <span className="font-mono text-sm font-bold text-[#F27D26] uppercase">{geometry.formation.replace('_', ' ')}</span>
          </div>
          <p className="text-[11px] text-[#8E9299] leading-tight font-sans line-clamp-2">{geometry.formationDescription}</p>
        </div>

        {/* 2s10s Spread */}
        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024] flex flex-col justify-between">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">2s10s Spread</span>
          <div className="text-lg font-mono font-bold text-white">
            {geometry.spread2s10s > 0 ? `+${geometry.spread2s10s.toFixed(1)}` : geometry.spread2s10s.toFixed(1)}{' '}
            <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">10Y Yield - 2Y Yield</div>
        </div>

        {/* 3Ms10s Spread */}
        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024] flex flex-col justify-between">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">3Ms10s Spread</span>
          <div className="text-lg font-mono font-bold text-white">
            {geometry.spread3Ms10s > 0 ? `+${geometry.spread3Ms10s.toFixed(1)}` : geometry.spread3Ms10s.toFixed(1)}{' '}
            <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Full Curve Slope</div>
        </div>

        {/* 2s5s10s Butterfly */}
        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024] flex flex-col justify-between">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">2s5s10s Fly</span>
          <div className="text-lg font-mono font-bold text-[#4CAF50]">
            {geometry.butterfly2s5s10s > 0 ? `+${geometry.butterfly2s5s10s.toFixed(1)}` : geometry.butterfly2s5s10s.toFixed(1)}{' '}
            <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">2*5Y - 2Y - 10Y</div>
        </div>

        {/* Max Slope & Curvature Location */}
        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024] flex flex-col justify-between">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">Max Curvature</span>
          <div className="text-lg font-mono font-bold text-[#4FC3F7]">
            {geometry.maxCurvatureMaturity.toFixed(1)}Y <span className="text-xs text-[#8E9299]">({geometry.maxCurvatureValue.toFixed(1)} bp)</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Peak d²Y/dX² Hump</div>
        </div>
      </div>

      {/* Axis Engine Control Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex flex-wrap items-center gap-4">
          {/* X Axis Selector */}
          <div className="flex items-center gap-2">
            <span className="text-[#8E9299] font-medium text-[10px] uppercase">
              <span className="text-[#F27D26] font-bold">X</span> AXIS:
            </span>
            <select
              value={axisConfig.xVar}
              onChange={(e) => setAxisConfig({ ...axisConfig, xVar: e.target.value as XAxisVariable })}
              className="bg-[#16181D] text-white px-2.5 py-1 rounded border border-[#2A2D33] focus:outline-none cursor-pointer text-xs"
            >
              <option value="MATURITY_YEARS">Maturity (Years)</option>
              <option value="MATURITY_MONTHS">Maturity (Months)</option>
              <option value="MATURITY_DAYS">Maturity (Days)</option>
              <option value="LOG_MATURITY">Log Maturity ln(τ)</option>
              <option value="DURATION">Macaulay Duration</option>
              <option value="MODIFIED_DURATION">Modified Duration</option>
              <option value="DV01">DV01 Risk</option>
              <option value="FORWARD_PERIOD">Forward Expiry</option>
              <option value="OBSERVATION_INDEX">Observation Index (k)</option>
            </select>
          </div>

          {/* Y Axis Selector */}
          <div className="flex items-center gap-2">
            <span className="text-[#8E9299] font-medium text-[10px] uppercase">
              <span className="text-[#F27D26] font-bold">Y</span> AXIS:
            </span>
            <select
              value={axisConfig.yVar}
              onChange={(e) => setAxisConfig({ ...axisConfig, yVar: e.target.value as YAxisVariable })}
              className="bg-[#16181D] text-white px-2.5 py-1 rounded border border-[#2A2D33] focus:outline-none cursor-pointer text-xs"
            >
              <option value="YIELD">Yield to Maturity (%)</option>
              <option value="INSTANTANEOUS_FORWARD">Instantaneous Forward f(τ) (%)</option>
              <option value="FORWARD_RATE">1-Year Forward Rate (%)</option>
              <option value="REAL_YIELD">Real Yield (Yield - Inflation)</option>
              <option value="SPREAD">Spread to Front-End (bps)</option>
              <option value="DISCOUNT_FACTOR">Discount Factor D(τ)</option>
              <option value="PRICE">Par Bond Price ($)</option>
              <option value="DURATION">Modified Duration (Years)</option>
              <option value="CONVEXITY">Convexity (Years²)</option>
              <option value="SLOPE_DERIVATIVE">Slope dY/dX (bps/yr)</option>
              <option value="CURVATURE_DERIVATIVE">Curvature d²Y/dX² (bps/yr²)</option>
            </select>
          </div>

          {/* Scale Type */}
          <div className="flex items-center gap-2">
            <span className="text-[#8E9299] text-[10px] uppercase">SCALE:</span>
            <button
              onClick={() => setAxisConfig({ ...axisConfig, xScale: axisConfig.xScale === 'linear' ? 'log' : 'linear' })}
              className={`px-2 py-0.5 rounded border text-[10px] font-mono transition-colors ${
                axisConfig.xScale === 'log'
                  ? 'bg-[#1A1C21] text-[#F27D26] border-[#F27D26]'
                  : 'bg-[#16181D] text-[#8E9299] border-[#2A2D33]'
              }`}
            >
              Log X
            </button>
          </div>
        </div>

        {/* Overlays & View Options */}
        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-1.5 text-[#E0E0E0] text-[11px] cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showObservedPoints}
              onChange={(e) => setShowObservedPoints(e.target.checked)}
              className="rounded bg-[#16181D] text-[#F27D26] focus:ring-0"
            />
            <span>Knots</span>
          </label>

          <label className="flex items-center gap-1.5 text-[#E0E0E0] text-[11px] cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showInflectionMarkers}
              onChange={(e) => setShowInflectionMarkers(e.target.checked)}
              className="rounded bg-[#16181D] text-[#4CAF50] focus:ring-0"
            />
            <span>Inflections</span>
          </label>

          <label className="flex items-center gap-1.5 text-[#E0E0E0] text-[11px] cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showFittedOverlay}
              onChange={(e) => setShowFittedOverlay(e.target.checked)}
              className="rounded bg-[#16181D] text-[#8E9299] focus:ring-0"
            />
            <span>NS Fit</span>
          </label>

          <label className="flex items-center gap-1.5 text-[#E0E0E0] text-[11px] cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showScenarioOverlay}
              onChange={(e) => setShowScenarioOverlay(e.target.checked)}
              className="rounded bg-[#16181D] text-[#4FC3F7] focus:ring-0"
            />
            <span>Scenario</span>
          </label>

          <button
            onClick={() => setShowDerivativePane(!showDerivativePane)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded border text-[11px] font-mono transition-colors ${
              showDerivativePane
                ? 'bg-[#1A1C21] text-[#F27D26] border-[#F27D26]/50'
                : 'bg-[#16181D] text-[#8E9299] border-[#2A2D33]'
            }`}
          >
            <Activity className="w-3 h-3" />
            <span>{showDerivativePane ? 'Hide Derivatives' : 'Show Derivatives'}</span>
          </button>
        </div>
      </div>

      {/* Main Chart Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Primary Yield Curve Chart Canvas */}
        <div className={`bg-[#0E1013] p-4 rounded border border-[#1E2024] ${showDerivativePane ? 'lg:col-span-8' : 'lg:col-span-12'}`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">TERM STRUCTURE VISUALIZER</span>
              <span className="text-[10px] font-mono text-[#8E9299] bg-[#16181D] px-2 py-0.5 rounded border border-[#2A2D33]">
                {activeCurve.interpolationMethod}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#8E9299]">
              <span>Tenors: {activeCurve.points.length}</span>
              <span>•</span>
              <span className="text-[#F27D26]">Model: {activeCurve.model}</span>
            </div>
          </div>

          <div ref={chartContainerRef} className="w-full h-[460px]" />
        </div>

        {/* Derivative Panes: Slope & Curvature */}
        {showDerivativePane && (
          <div className="lg:col-span-4 bg-[#0E1013] p-4 rounded border border-[#1E2024] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">DERIVATIVE GEOMETRY</span>
                <div className="flex items-center gap-1 text-[10px] font-mono">
                  <button
                    onClick={() => setDerivativeMode('SLOPE')}
                    className={`px-2 py-0.5 rounded transition-colors ${derivativeMode === 'SLOPE' ? 'bg-[#1A1C21] text-[#F27D26] border border-[#2A2D33]' : 'text-[#8E9299]'}`}
                  >
                    dY/dX
                  </button>
                  <button
                    onClick={() => setDerivativeMode('CURVATURE')}
                    className={`px-2 py-0.5 rounded transition-colors ${derivativeMode === 'CURVATURE' ? 'bg-[#1A1C21] text-[#4CAF50] border border-[#2A2D33]' : 'text-[#8E9299]'}`}
                  >
                    d²Y/dX²
                  </button>
                  <button
                    onClick={() => setDerivativeMode('BOTH')}
                    className={`px-2 py-0.5 rounded transition-colors ${derivativeMode === 'BOTH' ? 'bg-[#1A1C21] text-white border border-[#2A2D33]' : 'text-[#8E9299]'}`}
                  >
                    Both
                  </button>
                </div>
              </div>

              <div ref={derivativeChartRef} className="w-full h-[280px]" />
            </div>

            {/* Inflection Summary Table */}
            <div className="mt-3 pt-3 border-t border-[#1E2024]">
              <div className="text-[10px] font-mono text-[#8E9299] uppercase mb-1.5">Critical Inflection Coordinates</div>
              <div className="space-y-1 max-h-[130px] overflow-y-auto pr-1 text-[11px] font-mono scrollbar-thin">
                {geometry.inflectionPoints.map((inf, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-[#16181D] px-2.5 py-1 rounded border border-[#2A2D33]">
                    <span className="text-[#E0E0E0]">{inf.label}</span>
                    <span className="text-[#F27D26] font-medium">{inf.yield.toFixed(2)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Technical Diagnostics Bar */}
      <div className="bg-[#16181D] p-3 rounded border border-[#1E2024] text-xs font-mono flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-6">
          <div>
            <span className="text-[#8E9299]">Steepest:</span>{' '}
            <span className="text-[#F27D26] font-bold">
              {geometry.steepestSegment.start.toFixed(1)}Y–{geometry.steepestSegment.end.toFixed(1)}Y ({geometry.steepestSegment.slope.toFixed(1)} bp/yr)
            </span>
          </div>
          <div>
            <span className="text-[#8E9299]">Flattest:</span>{' '}
            <span className="text-[#4CAF50] font-bold">
              {geometry.flattestSegment.start.toFixed(1)}Y–{geometry.flattestSegment.end.toFixed(1)}Y ({geometry.flattestSegment.slope.toFixed(1)} bp/yr)
            </span>
          </div>
          <div>
            <span className="text-[#8E9299]">Mean Level:</span>{' '}
            <span className="text-white font-bold">{geometry.levelMean.toFixed(3)}%</span>
          </div>
          <div>
            <span className="text-[#8E9299]">Scenario:</span>{' '}
            <span className="text-[#4FC3F7] font-bold">{activeScenario.name}</span>
          </div>
        </div>

        <button
          onClick={onOpenAiModal}
          className="flex items-center gap-1.5 text-[#F27D26] hover:text-white bg-[#1A1C21] hover:bg-[#2A2D33] px-3 py-1.5 rounded border border-[#2A2D33] text-xs font-mono transition-colors cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Ask Gemini 3.7 to Diagnose Geometry</span>
        </button>
      </div>
    </div>
  );
};
