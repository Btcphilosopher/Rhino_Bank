/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Curve Transformation & Sensitivity Shock Lab
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { Layers, RotateCcw, Sliders, ArrowRight, Zap, Check } from 'lucide-react';
import { RhinoCurve, CurvePoint } from '../types/rhino';
import { applyCurveTransformation, TransformationParams } from '../math/transformations';
import { generateDenseCurveGrid } from '../math/interpolations';

interface TransformationLabProps {
  activeCurve: RhinoCurve;
  onApplyTransformation: (newPoints: CurvePoint[]) => void;
}

export const TransformationLab: React.FC<TransformationLabProps> = ({
  activeCurve,
  onApplyTransformation,
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const diffChartRef = useRef<HTMLDivElement>(null);

  const [params, setParams] = useState<TransformationParams>({
    levelShiftBps: 0,
    slopeTiltBps: 0,
    curvatureBellyBps: 0,
    shortTenorAnchor: 0.25,
    bellyTenorAnchor: 5.0,
    longTenorAnchor: 30.0,
  });

  // Calculate transformed points
  const transformedPoints = useMemo(() => {
    return applyCurveTransformation(activeCurve.points, params);
  }, [activeCurve.points, params]);

  // Dense grids for both baseline and transformed
  const baselineGrid = useMemo(() => {
    return generateDenseCurveGrid(activeCurve.points, activeCurve.interpolationMethod);
  }, [activeCurve]);

  const transformedGrid = useMemo(() => {
    return generateDenseCurveGrid(transformedPoints, activeCurve.interpolationMethod);
  }, [transformedPoints, activeCurve.interpolationMethod]);

  // Difference curve
  const spreadDeltaGrid = useMemo(() => {
    return baselineGrid.map((p, i) => ({
      maturity: p.maturity,
      deltaBps: (transformedGrid[i].yield - p.yield) * 100,
    }));
  }, [baselineGrid, transformedGrid]);

  const handleReset = () => {
    setParams({
      levelShiftBps: 0,
      slopeTiltBps: 0,
      curvatureBellyBps: 0,
      shortTenorAnchor: 0.25,
      bellyTenorAnchor: 5.0,
      longTenorAnchor: 30.0,
    });
  };

  // Render Charts
  useEffect(() => {
    if (!chartRef.current || !diffChartRef.current) return;

    // Main Chart
    const traces: Plotly.Data[] = [
      {
        x: baselineGrid.map((p) => p.maturity),
        y: baselineGrid.map((p) => p.yield),
        type: 'scatter',
        mode: 'lines',
        name: 'Baseline Curve',
        line: { color: '#8E9299', width: 1.5, dash: 'dash' },
      },
      {
        x: transformedGrid.map((p) => p.maturity),
        y: transformedGrid.map((p) => p.yield),
        type: 'scatter',
        mode: 'lines',
        name: 'Transformed Curve',
        line: { color: '#F27D26', width: 2.5 },
      },
      {
        x: transformedPoints.map((p) => p.maturity),
        y: transformedPoints.map((p) => p.yield),
        type: 'scatter',
        mode: 'markers',
        name: 'Shocked Knots',
        marker: { color: '#4CAF50', size: 7, line: { color: '#FFFFFF', width: 1 } },
      },
    ];

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 55, r: 20, t: 25, b: 45 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Yield (%)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      legend: { orientation: 'h', y: 1.12, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(chartRef.current, traces, layout, { responsive: true, displaylogo: false });

    // Difference / Shift Profile Chart
    const diffTrace: Plotly.Data = {
      x: spreadDeltaGrid.map((p) => p.maturity),
      y: spreadDeltaGrid.map((p) => p.deltaBps),
      type: 'scatter',
      mode: 'lines',
      name: 'Shift Profile ΔYield',
      fill: 'tozeroy',
      fillcolor: 'rgba(242, 125, 38, 0.15)',
      line: { color: '#F27D26', width: 2 },
    };

    const diffLayout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 20, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Δ Yield (bps)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024', zerolinecolor: '#2A2D33' },
    };

    Plotly.react(diffChartRef.current, [diffTrace], diffLayout, { responsive: true, displaylogo: false });
  }, [baselineGrid, transformedGrid, transformedPoints, spreadDeltaGrid]);

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">CURVE TRANSFORMATION ENGINE</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Continuous Level, Slope Twist, Butterfly Curvature & Key-Rate shock generator
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="flex items-center gap-1 bg-[#16181D] hover:bg-[#1A1C21] text-[#8E9299] hover:text-white px-3 py-1.5 rounded border border-[#2A2D33] text-xs font-mono transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Shocks</span>
          </button>

          <button
            onClick={() => onApplyTransformation(transformedPoints)}
            className="flex items-center gap-1 bg-[#F27D26] hover:bg-[#ff8e3d] text-black px-3.5 py-1.5 rounded font-mono font-bold text-xs shadow transition-all cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Commit Curve</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Controls & Visualizations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Sliders Control Panel */}
        <div className="lg:col-span-4 bg-[#16181D] p-4 rounded border border-[#1E2024] space-y-5">
          <div className="flex items-center justify-between border-b border-[#2A2D33] pb-2">
            <span className="font-mono text-xs font-bold text-white uppercase tracking-wider">TRANSFORMATION SLIDERS</span>
            <span className="text-[10px] font-mono text-[#4CAF50] bg-[#1A1C21] px-2 py-0.5 rounded border border-[#2A2D33]">
              Live Shifts
            </span>
          </div>

          {/* Level Shift Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#E0E0E0] font-medium">1. LEVEL SHIFT (Parallel)</span>
              <span className="text-[#F27D26] font-bold">
                {params.levelShiftBps > 0 ? `+${params.levelShiftBps}` : params.levelShiftBps} bps
              </span>
            </div>
            <input
              type="range"
              min="-200"
              max="200"
              step="1"
              value={params.levelShiftBps}
              onChange={(e) => setParams({ ...params, levelShiftBps: parseInt(e.target.value) })}
              className="w-full accent-[#F27D26] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8E9299]">
              <span>-200 bps (Easing)</span>
              <span>0 bp</span>
              <span>+200 bps (Hike)</span>
            </div>
          </div>

          {/* Slope Twist Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#E0E0E0] font-medium">2. SLOPE TWIST (Steep / Flat)</span>
              <span className="text-white font-bold">
                {params.slopeTiltBps > 0 ? `+${params.slopeTiltBps}` : params.slopeTiltBps} bps
              </span>
            </div>
            <input
              type="range"
              min="-150"
              max="150"
              step="1"
              value={params.slopeTiltBps}
              onChange={(e) => setParams({ ...params, slopeTiltBps: parseInt(e.target.value) })}
              className="w-full accent-[#F27D26] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8E9299]">
              <span>-150 bp (Flattener)</span>
              <span>0 bp</span>
              <span>+150 bp (Steepener)</span>
            </div>
          </div>

          {/* Curvature / Butterfly Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#E0E0E0] font-medium">3. BUTTERFLY / CURVATURE</span>
              <span className="text-[#4CAF50] font-bold">
                {params.curvatureBellyBps > 0 ? `+${params.curvatureBellyBps}` : params.curvatureBellyBps} bps
              </span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              step="1"
              value={params.curvatureBellyBps}
              onChange={(e) => setParams({ ...params, curvatureBellyBps: parseInt(e.target.value) })}
              className="w-full accent-[#4CAF50] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8E9299]">
              <span>-100 bp (Fly Basin)</span>
              <span>0 bp</span>
              <span>+100 bp (Fly Hump)</span>
            </div>
          </div>

          {/* Quick Preset Shock Buttons */}
          <div className="pt-3 border-t border-[#2A2D33] space-y-2">
            <span className="text-xs font-mono text-[#8E9299] font-bold block uppercase tracking-wider">QUICK PRESET SHOCKS</span>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <button
                onClick={() => setParams({ ...params, levelShiftBps: 25, slopeTiltBps: 0, curvatureBellyBps: 0 })}
                className="p-1.5 bg-[#0E1013] hover:bg-[#1A1C21] text-[#E0E0E0] rounded border border-[#2A2D33]"
              >
                +25bp Parallel
              </button>
              <button
                onClick={() => setParams({ ...params, levelShiftBps: -25, slopeTiltBps: 0, curvatureBellyBps: 0 })}
                className="p-1.5 bg-[#0E1013] hover:bg-[#1A1C21] text-[#E0E0E0] rounded border border-[#2A2D33]"
              >
                -25bp Parallel
              </button>
              <button
                onClick={() => setParams({ ...params, levelShiftBps: 0, slopeTiltBps: 40, curvatureBellyBps: 0 })}
                className="p-1.5 bg-[#0E1013] hover:bg-[#1A1C21] text-[#F27D26] rounded border border-[#2A2D33]"
              >
                +40bp Steepener
              </button>
              <button
                onClick={() => setParams({ ...params, levelShiftBps: 0, slopeTiltBps: -40, curvatureBellyBps: 0 })}
                className="p-1.5 bg-[#0E1013] hover:bg-[#1A1C21] text-[#4FC3F7] rounded border border-[#2A2D33]"
              >
                -40bp Flattener
              </button>
            </div>
          </div>
        </div>

        {/* Visualizers */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-[#0E1013] p-4 rounded border border-[#1E2024]">
            <div className="flex items-center justify-between mb-1">
              <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">BASELINE VS. TRANSFORMED CURVE</span>
              <span className="text-xs font-mono text-[#F27D26]">Total Shift Effect</span>
            </div>
            <div ref={chartRef} className="w-full h-[320px]" />
          </div>

          <div className="bg-[#0E1013] p-4 rounded border border-[#1E2024]">
            <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase block mb-1">NET YIELD SHIFT PROFILE ΔYIELD(τ) [BPS]</span>
            <div ref={diffChartRef} className="w-full h-[180px]" />
          </div>
        </div>
      </div>
    </div>
  );
};
