/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Nelson-Siegel & Svensson Parametric Research Lab
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { Cpu, RefreshCw, CheckCircle2, Sparkles, Sliders, BarChart2 } from 'lucide-react';
import { RhinoCurve, NelsonSiegelParams, SvenssonParams } from '../types/rhino';
import {
  evaluateNelsonSiegelFull,
  evaluateSvenssonFull,
  fitNelsonSiegel,
  fitSvensson,
  nsBasisFunctions,
  calculateFitDiagnostics,
} from '../math/nelsonSiegel';

interface NelsonSiegelLabProps {
  activeCurve: RhinoCurve;
  onApplyFittedModelToActiveCurve: (params: SvenssonParams, modelType: 'NelsonSiegel' | 'Svensson') => void;
}

export const NelsonSiegelLab: React.FC<NelsonSiegelLabProps> = ({
  activeCurve,
  onApplyFittedModelToActiveCurve,
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const basisChartRef = useRef<HTMLDivElement>(null);
  const residualChartRef = useRef<HTMLDivElement>(null);

  const [modelType, setModelType] = useState<'NelsonSiegel' | 'Svensson'>('Svensson');

  // Parameters State
  const [params, setParams] = useState<SvenssonParams>({
    beta0: 4.85,
    beta1: -0.95,
    beta2: 0.85,
    beta3: -0.45,
    lambda: 1.85,
    lambda2: 4.5,
  });

  // Fit active curve upon mount or curve change
  useEffect(() => {
    if (modelType === 'NelsonSiegel') {
      const fit = fitNelsonSiegel(activeCurve.points);
      setParams({
        ...fit.params,
        beta3: 0,
        lambda2: 4.0,
      });
    } else {
      const fit = fitSvensson(activeCurve.points);
      setParams(fit.params);
    }
  }, [activeCurve, modelType]);

  // Compute Diagnostics
  const diagnostics = useMemo(() => {
    if (modelType === 'NelsonSiegel') {
      return calculateFitDiagnostics(
        activeCurve.points,
        (t) => evaluateNelsonSiegelFull(t, params).yield,
        4
      );
    } else {
      return calculateFitDiagnostics(
        activeCurve.points,
        (t) => evaluateSvenssonFull(t, params).yield,
        6
      );
    }
  }, [activeCurve.points, params, modelType]);

  // Grid for Continuous Curves (0.1Y to 30Y)
  const grid = useMemo(() => {
    const taus: number[] = [];
    for (let t = 0.1; t <= 30; t += 0.15) {
      taus.push(Number(t.toFixed(2)));
    }
    return taus;
  }, []);

  const fittedCurve = useMemo(() => {
    return grid.map((t) => {
      if (modelType === 'NelsonSiegel') {
        return evaluateNelsonSiegelFull(t, params);
      } else {
        return evaluateSvenssonFull(t, params);
      }
    });
  }, [grid, params, modelType]);

  // Calibration Handler
  const handleAutoCalibrate = () => {
    if (modelType === 'NelsonSiegel') {
      const fit = fitNelsonSiegel(activeCurve.points);
      setParams({ ...fit.params, beta3: 0, lambda2: 4.0 });
    } else {
      const fit = fitSvensson(activeCurve.points);
      setParams(fit.params);
    }
  };

  // Render Main Fitted vs Observed Plot
  useEffect(() => {
    if (!chartRef.current) return;

    const traces: Plotly.Data[] = [
      // Observed Points
      {
        x: activeCurve.points.map((p) => p.maturity),
        y: activeCurve.points.map((p) => p.yield),
        type: 'scatter',
        mode: 'markers+text',
        name: 'Observed Market Yields',
        text: activeCurve.points.map((p) => p.tenor),
        textposition: 'top center',
        textfont: { family: 'monospace', size: 10, color: '#8E9299' },
        marker: { color: '#F27D26', size: 7, symbol: 'circle', line: { color: '#FFFFFF', width: 1 } },
        hovertemplate: '<b>Tenor</b>: %{text}<br><b>Observed</b>: %{y:.3f}%<extra></extra>',
      },
      // Fitted Curve
      {
        x: fittedCurve.map((p) => p.maturity),
        y: fittedCurve.map((p) => p.yield),
        type: 'scatter',
        mode: 'lines',
        name: `${modelType} Model Fit`,
        line: { color: '#4FC3F7', width: 2.5 },
        hovertemplate: '<b>Fitted</b>: %{y:.3f}%<extra></extra>',
      },
    ];

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 55, r: 20, t: 25, b: 45 },
      hovermode: 'x unified',
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Yield (%)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      legend: { orientation: 'h', y: 1.12, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(chartRef.current, traces, layout, { responsive: true, displaylogo: false });
  }, [activeCurve, fittedCurve, modelType]);

  // Render Factor Decomposition Plot
  useEffect(() => {
    if (!basisChartRef.current) return;

    const levelTrace: Plotly.Data = {
      x: grid,
      y: grid.map(() => params.beta0),
      type: 'scatter',
      mode: 'lines',
      name: `Level [β0 = ${params.beta0.toFixed(2)}]`,
      line: { color: '#8E9299', width: 1.5, dash: 'dot' },
    };

    const slopeTrace: Plotly.Data = {
      x: grid,
      y: grid.map((t) => params.beta1 * nsBasisFunctions(t, params.lambda).slope),
      type: 'scatter',
      mode: 'lines',
      name: `Slope [β1 = ${params.beta1.toFixed(2)}]`,
      line: { color: '#F27D26', width: 2 },
    };

    const curv1Trace: Plotly.Data = {
      x: grid,
      y: grid.map((t) => params.beta2 * nsBasisFunctions(t, params.lambda).curvature),
      type: 'scatter',
      mode: 'lines',
      name: `Curvature 1 [β2 = ${params.beta2.toFixed(2)}]`,
      line: { color: '#4CAF50', width: 2 },
    };

    const traces: Plotly.Data[] = [levelTrace, slopeTrace, curv1Trace];

    if (modelType === 'Svensson') {
      traces.push({
        x: grid,
        y: grid.map((t) => params.beta3 * nsBasisFunctions(t, params.lambda2).curvature),
        type: 'scatter',
        mode: 'lines',
        name: `Curvature 2 [β3 = ${params.beta3.toFixed(2)}]`,
        line: { color: '#4FC3F7', width: 2 },
      });
    }

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 25, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Factor Contribution (%)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024', zerolinecolor: '#2A2D33' },
      legend: { orientation: 'h', y: 1.15, x: 0, font: { size: 9 } },
    };

    Plotly.react(basisChartRef.current, traces, layout, { responsive: true, displaylogo: false });
  }, [grid, params, modelType]);

  // Render Residuals Chart
  useEffect(() => {
    if (!residualChartRef.current) return;

    const resTrace: Plotly.Data = {
      x: diagnostics.residuals.map((r) => r.maturity),
      y: diagnostics.residuals.map((r) => r.residualBps),
      type: 'bar',
      name: 'Residual (Observed - Fitted)',
      marker: {
        color: diagnostics.residuals.map((r) => (r.residualBps >= 0 ? '#4CAF50' : '#E91E63')),
      },
      text: diagnostics.residuals.map((r) => `${r.residualBps > 0 ? '+' : ''}${r.residualBps.toFixed(1)} bp`),
      textposition: 'auto',
      textfont: { size: 9, color: '#FFFFFF' },
    };

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 20, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Residual (bps)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024', zerolinecolor: '#2A2D33' },
    };

    Plotly.react(residualChartRef.current, [resTrace], layout, { responsive: true, displaylogo: false });
  }, [diagnostics]);

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">NELSON-SIEGEL & SVENSSON (NSS) ENGINE</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Non-linear parametric calibration, basis function decomposition & econometric diagnostics
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Model Switcher */}
          <div className="flex bg-[#16181D] p-1 rounded border border-[#2A2D33] text-xs font-mono">
            <button
              onClick={() => setModelType('NelsonSiegel')}
              className={`px-3 py-1 rounded transition-colors ${
                modelType === 'NelsonSiegel' ? 'bg-[#1A1C21] text-[#F27D26] font-bold border border-[#2A2D33]' : 'text-[#8E9299] hover:text-white'
              }`}
            >
              Nelson-Siegel (4 params)
            </button>
            <button
              onClick={() => setModelType('Svensson')}
              className={`px-3 py-1 rounded transition-colors ${
                modelType === 'Svensson' ? 'bg-[#1A1C21] text-[#F27D26] font-bold border border-[#2A2D33]' : 'text-[#8E9299] hover:text-white'
              }`}
            >
              Svensson (6 params)
            </button>
          </div>

          <button
            onClick={handleAutoCalibrate}
            className="flex items-center gap-1.5 bg-[#F27D26] hover:bg-[#ff8e3d] text-black px-3.5 py-1.5 rounded font-mono font-bold text-xs shadow cursor-pointer transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Auto-Calibrate</span>
          </button>
        </div>
      </div>

      {/* Diagnostics Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">RMSE Fit Error</span>
          <div className="text-lg font-mono font-bold text-[#4FC3F7]">
            {diagnostics.rmse.toFixed(2)} <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Root Mean Square Error</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">Mean Abs Error</span>
          <div className="text-lg font-mono font-bold text-[#4CAF50]">
            {diagnostics.mae.toFixed(2)} <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Average Tenor Residual</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">R-Squared (R²)</span>
          <div className="text-lg font-mono font-bold text-white">
            {(diagnostics.rSquared * 100).toFixed(2)}%
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Variance Explained</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">Akaike / BIC</span>
          <div className="text-lg font-mono font-bold text-[#8E9299]">
            {diagnostics.aic.toFixed(1)} <span className="text-xs text-[#8E9299]">/ {diagnostics.bic.toFixed(1)}</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Information Criteria</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">Max Residual</span>
          <div className="text-lg font-mono font-bold text-[#E91E63]">
            {diagnostics.maxResidual.toFixed(2)} <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Worst Tenor Deviation</div>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Parametric Sliders Panel */}
        <div className="lg:col-span-4 bg-[#16181D] p-4 rounded border border-[#1E2024] space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A2D33] pb-2">
            <span className="font-mono text-xs font-bold text-white uppercase tracking-wider">MODEL PARAMETERS</span>
            <span className="text-[10px] font-mono text-[#4CAF50] bg-[#1A1C21] px-2 py-0.5 rounded border border-[#2A2D33]">
              Live NSS
            </span>
          </div>

          {/* Beta 0: Level */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#E0E0E0] font-medium">β₀ — Level (Long-End)</span>
              <span className="text-[#F27D26] font-bold">{params.beta0.toFixed(3)}%</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="10.0"
              step="0.05"
              value={params.beta0}
              onChange={(e) => setParams({ ...params, beta0: parseFloat(e.target.value) })}
              className="w-full accent-[#F27D26] cursor-pointer"
            />
            <p className="text-[10px] text-[#8E9299] font-sans">Controls the asymptote / long-term interest rate anchor.</p>
          </div>

          {/* Beta 1: Slope */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#E0E0E0] font-medium">β₁ — Slope (Short-End)</span>
              <span className="text-white font-bold">{params.beta1.toFixed(3)}%</span>
            </div>
            <input
              type="range"
              min="-6.0"
              max="6.0"
              step="0.05"
              value={params.beta1}
              onChange={(e) => setParams({ ...params, beta1: parseFloat(e.target.value) })}
              className="w-full accent-[#F27D26] cursor-pointer"
            />
            <p className="text-[10px] text-[#8E9299] font-sans">Negative for normal curves; positive for inverted curves.</p>
          </div>

          {/* Beta 2: Curvature / Hump */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#E0E0E0] font-medium">β₂ — Curvature 1 (Belly)</span>
              <span className="text-[#4CAF50] font-bold">{params.beta2.toFixed(3)}%</span>
            </div>
            <input
              type="range"
              min="-8.0"
              max="8.0"
              step="0.05"
              value={params.beta2}
              onChange={(e) => setParams({ ...params, beta2: parseFloat(e.target.value) })}
              className="w-full accent-[#4CAF50] cursor-pointer"
            />
            <p className="text-[10px] text-[#8E9299] font-sans">Magnitude of medium-term curvature hump or basin.</p>
          </div>

          {/* Lambda 1: Decay Parameter */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#E0E0E0] font-medium">λ₁ — Scale / Decay Factor</span>
              <span className="text-[#4FC3F7] font-bold">{params.lambda.toFixed(3)}</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="10.0"
              step="0.05"
              value={params.lambda}
              onChange={(e) => setParams({ ...params, lambda: parseFloat(e.target.value) })}
              className="w-full accent-[#4FC3F7] cursor-pointer"
            />
            <p className="text-[10px] text-[#8E9299] font-sans">Location of maximum hump loading (τ_peak ≈ 1.79 * λ).</p>
          </div>

          {/* Svensson Extra Parameters */}
          {modelType === 'Svensson' && (
            <>
              <div className="pt-2 border-t border-[#2A2D33] space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-[#E0E0E0] font-medium">β₃ — Curvature 2 (2nd Hump)</span>
                  <span className="text-[#E91E63] font-bold">{params.beta3.toFixed(3)}%</span>
                </div>
                <input
                  type="range"
                  min="-6.0"
                  max="6.0"
                  step="0.05"
                  value={params.beta3}
                  onChange={(e) => setParams({ ...params, beta3: parseFloat(e.target.value) })}
                  className="w-full accent-[#E91E63] cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-[#E0E0E0] font-medium">λ₂ — Second Decay Factor</span>
                  <span className="text-[#8E9299] font-bold">{params.lambda2.toFixed(3)}</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="15.0"
                  step="0.1"
                  value={params.lambda2}
                  onChange={(e) => setParams({ ...params, lambda2: parseFloat(e.target.value) })}
                  className="w-full accent-[#8E9299] cursor-pointer"
                />
              </div>
            </>
          )}

          <button
            onClick={() => onApplyFittedModelToActiveCurve(params, modelType)}
            className="w-full py-2 bg-[#F27D26] hover:bg-[#ff8e3d] text-black rounded font-mono font-bold text-xs transition-all shadow cursor-pointer mt-4"
          >
            Apply Model to Active Curve
          </button>
        </div>

        {/* Visualizers Area */}
        <div className="lg:col-span-8 space-y-4">
          {/* Main Fitted Chart */}
          <div className="bg-[#0E1013] p-4 rounded border border-[#1E2024]">
            <div className="flex items-center justify-between mb-1">
              <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">OBSERVED VS. PARAMETRIC MODEL FIT</span>
              <span className="text-xs font-mono text-[#8E9299]">CCY: {activeCurve.currency}</span>
            </div>
            <div ref={chartRef} className="w-full h-[320px]" />
          </div>

          {/* Split: Factor Decomposition & Residual Diagnostics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024]">
              <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase block mb-1">FACTOR DECOMPOSITION</span>
              <div ref={basisChartRef} className="w-full h-[220px]" />
            </div>

            <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024]">
              <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase block mb-1">RESIDUAL ERROR SPREAD (BPS)</span>
              <div ref={residualChartRef} className="w-full h-[220px]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
