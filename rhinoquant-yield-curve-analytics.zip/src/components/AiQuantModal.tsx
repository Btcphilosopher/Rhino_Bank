/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Gemini 3.7 Fixed Income Quant Strategist & Econometric Modal
 */

import React, { useState } from 'react';
import { Sparkles, X, Send, Bot, RefreshCw, Layers, CheckCircle2, TrendingUp } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { RhinoCurve, GeometryMetrics, NelsonSiegelParams, ScenarioDefinition } from '../types/rhino';

interface AiQuantModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeCurve: RhinoCurve;
  geometry: GeometryMetrics;
  nsParams?: NelsonSiegelParams;
  activeScenario?: ScenarioDefinition;
}

export const AiQuantModal: React.FC<AiQuantModalProps> = ({
  isOpen,
  onClose,
  activeCurve,
  geometry,
  nsParams,
  activeScenario,
}) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);

  if (!isOpen) return null;

  const presets = [
    {
      label: 'Macro Regime & Monetary Policy Stance',
      query:
        'Analyze the macroeconomic and monetary policy implications of this yield curve formation. What is the implied market expectation for terminal rates and central bank easing?',
    },
    {
      label: 'Curve Trade Recommendations (Relative Value & Flies)',
      query:
        'Given the current 2s10s slope, 2s5s10s butterfly richness/cheapness, and curvature inflections, propose 2 actionable institutional relative-value curve trades (e.g. steepener, flattener, or box spread).',
    },
    {
      label: 'Inflection Point & Geometry Decomposition',
      query:
        'Examine the mathematical derivatives dY/dX and d²Y/dX² of this curve. Explain where the primary kinks and inflections occur and what supply/demand imbalances they reflect.',
    },
    {
      label: 'Stress Scenario & Risk Vulnerability',
      query: `Evaluate our portfolio vulnerability under the active stress scenario (${activeScenario?.name || 'Parallel Hike'}). Where is duration and convexity risk most concentrated?`,
    },
  ];

  const handleSend = async (customQuery?: string) => {
    const userQuery = customQuery || prompt;
    if (!userQuery.trim()) return;

    setLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/api/quant/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          curve: activeCurve,
          geometry,
          nsParams,
          scenario: activeScenario,
          prompt: userQuery,
        }),
      });

      const data = await res.json();
      if (data.analysis) {
        setResponse(data.analysis);
      } else {
        setResponse(
          data.error || 'Unable to generate analysis. Please ensure server is running properly.'
        );
      }
    } catch (err: any) {
      setResponse(`Error contacting Gemini 3.7 Quant API: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0E1013] border border-[#1E2024] rounded-lg w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 border-b border-[#1E2024] flex items-center justify-between bg-[#16181D]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#1A1C21] border border-[#2A2D33] text-[#F27D26]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-sans font-bold text-white text-base tracking-wide uppercase">GEMINI 3.7 QUANTITATIVE STRATEGIST</h3>
                <span className="text-[10px] font-mono bg-[#1A1C21] text-[#F27D26] px-2 py-0.5 rounded border border-[#2A2D33]">
                  Econometric Intelligence
                </span>
              </div>
              <p className="text-xs text-[#8E9299] font-sans">
                Real-time mathematical yield curve diagnostics, monetary regime analysis & trade structuring
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#8E9299] hover:text-white rounded hover:bg-[#1A1C21] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1 scrollbar-thin">
          {/* Active Context Snapshot */}
          <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024] grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
            <div>
              <span className="text-[#8E9299]">Curve:</span>{' '}
              <span className="text-white font-bold">{activeCurve.name}</span>
            </div>
            <div>
              <span className="text-[#8E9299]">Formation:</span>{' '}
              <span className="text-[#F27D26] font-bold">{geometry.formation}</span>
            </div>
            <div>
              <span className="text-[#8E9299]">2s10s Spread:</span>{' '}
              <span className="text-[#4FC3F7] font-bold">{geometry.spread2s10s.toFixed(1)} bp</span>
            </div>
            <div>
              <span className="text-[#8E9299]">2s5s10s Fly:</span>{' '}
              <span className="text-[#4CAF50] font-bold">{geometry.butterfly2s5s10s.toFixed(1)} bp</span>
            </div>
          </div>

          {/* Quick Prompts */}
          <div>
            <span className="text-xs font-mono text-[#8E9299] uppercase tracking-wider block mb-2 font-bold">
              Select Institutional Research Topic
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {presets.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPrompt(p.query);
                    handleSend(p.query);
                  }}
                  className="p-2.5 bg-[#16181D] hover:bg-[#1A1C21] text-[#E0E0E0] hover:text-white text-xs font-mono text-left rounded border border-[#1E2024] hover:border-[#F27D26]/60 transition-all cursor-pointer flex items-start gap-2"
                >
                  <TrendingUp className="w-4 h-4 text-[#F27D26] mt-0.5 shrink-0" />
                  <span>{p.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Response Box */}
          {loading && (
            <div className="bg-[#16181D] p-8 rounded border border-[#1E2024] flex flex-col items-center justify-center space-y-3">
              <RefreshCw className="w-8 h-8 text-[#F27D26] animate-spin" />
              <div className="font-mono text-xs text-[#8E9299]">
                Gemini 3.7 is synthesizing econometric yield curve dynamics...
              </div>
            </div>
          )}

          {response && (
            <div className="bg-[#16181D] p-5 rounded border border-[#2A2D33] text-[#E0E0E0] text-sm space-y-3 font-sans leading-relaxed">
              <div className="flex items-center gap-2 pb-2 border-b border-[#1E2024]">
                <Bot className="w-4 h-4 text-[#F27D26]" />
                <span className="font-mono text-xs font-bold text-white uppercase tracking-wider">QUANT STRATEGIST ASSESSMENT</span>
              </div>
              <div className="markdown-body prose prose-invert max-w-none text-[#E0E0E0] text-sm space-y-2">
                <ReactMarkdown>{response}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-[#1E2024] bg-[#16181D] flex items-center gap-3">
          <input
            type="text"
            placeholder="Ask a custom fixed-income quantitative question about this curve..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-[#0A0B0D] text-white px-3.5 py-2 rounded border border-[#2A2D33] text-xs font-mono focus:outline-none focus:border-[#F27D26]"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !prompt.trim()}
            className="flex items-center gap-1.5 bg-[#F27D26] hover:bg-[#e06c19] text-white px-4 py-2 rounded font-sans font-semibold text-xs shadow-sm transition-all cursor-pointer disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Analyze</span>
          </button>
        </div>
      </div>
    </div>
  );
};
