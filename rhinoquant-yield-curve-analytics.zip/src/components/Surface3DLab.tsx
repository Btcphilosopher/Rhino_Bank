/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * 3D Yield Surface & Historical Time-Series Evolution Lab
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import Plotly from 'plotly.js-dist-min';
import { Box, Play, Pause, RotateCcw, Eye, Layers } from 'lucide-react';
import { TimeSeriesCurvePoint, RhinoCurve } from '../types/rhino';
import { STANDARD_TENORS } from '../data/sampleCurves';

interface Surface3DLabProps {
  timeSeries: TimeSeriesCurvePoint[];
  onLoadCurveFromDate?: (date: string, yields: { [tenor: string]: number }) => void;
}

export const Surface3DLab: React.FC<Surface3DLabProps> = ({
  timeSeries,
  onLoadCurveFromDate,
}) => {
  const surfaceRef = useRef<HTMLDivElement>(null);
  const timeSeries2DRef = useRef<HTMLDivElement>(null);

  const [viewMode, setViewMode] = useState<'SURFACE_3D' | 'HEATMAP_2D' | 'TIME_SERIES_2D'>('SURFACE_3D');
  const [colorScale, setColorScale] = useState<'Viridis' | 'Plasma' | 'Turbo' | 'Jet'>('Viridis');

  // Animation state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentIdx, setCurrentIdx] = useState(timeSeries.length - 1);

  const tenors = useMemo(() => STANDARD_TENORS.map((t) => t.tenor), []);
  const maturities = useMemo(() => STANDARD_TENORS.map((t) => t.maturity), []);
  const dates = useMemo(() => timeSeries.map((t) => t.date), [timeSeries]);

  // Animation Loop
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentIdx((prev) => {
          if (prev >= timeSeries.length - 1) {
            return 0;
          }
          return prev + 1;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, timeSeries.length]);

  // Render 3D Surface / Heatmap
  useEffect(() => {
    if (!surfaceRef.current) return;

    // Build Z Matrix: rows = dates, cols = tenors/maturities
    const zMatrix: number[][] = timeSeries.map((t) => {
      return tenors.map((k) => t.yields[k] || 0);
    });

    if (viewMode === 'SURFACE_3D') {
      const data: Plotly.Data[] = [
        {
          z: zMatrix,
          x: maturities,
          y: dates,
          type: 'surface',
          colorscale: colorScale,
          showscale: true,
          contours: {
            z: { show: true, usecolormap: true, highlightcolor: '#ffffff', project: { z: false } },
          },
        },
      ];

      const layout: Partial<Plotly.Layout> = {
        autosize: true,
        paper_bgcolor: '#0E1013',
        font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
        margin: { l: 0, r: 0, t: 10, b: 0 },
        scene: {
          xaxis: { title: 'Maturity (Y)', gridcolor: '#1E2024', backgroundcolor: '#16181D' },
          yaxis: { title: 'Date', gridcolor: '#1E2024', backgroundcolor: '#16181D' },
          zaxis: { title: 'Yield (%)', gridcolor: '#1E2024', backgroundcolor: '#16181D' },
          camera: {
            eye: { x: 1.6, y: -1.6, z: 1.2 },
          },
        },
      };

      Plotly.react(surfaceRef.current, data, layout, { responsive: true, displaylogo: false });
    } else if (viewMode === 'HEATMAP_2D') {
      const data: Plotly.Data[] = [
        {
          z: zMatrix,
          x: maturities,
          y: dates,
          type: 'heatmap',
          colorscale: colorScale,
          showscale: true,
          hoverongaps: false,
        },
      ];

      const layout: Partial<Plotly.Layout> = {
        autosize: true,
        paper_bgcolor: '#0E1013',
        plot_bgcolor: '#0E1013',
        font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
        margin: { l: 70, r: 20, t: 20, b: 40 },
        xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
        yaxis: { title: { text: 'Date', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      };

      Plotly.react(surfaceRef.current, data, layout, { responsive: true, displaylogo: false });
    }
  }, [timeSeries, maturities, dates, tenors, viewMode, colorScale]);

  // Render 2D Animated Curve at current timestamp
  useEffect(() => {
    if (!timeSeries2DRef.current) return;

    const activePoint = timeSeries[currentIdx] || timeSeries[0];
    const yields = tenors.map((k) => activePoint.yields[k]);

    const traces: Plotly.Data[] = [
      {
        x: maturities,
        y: yields,
        type: 'scatter',
        mode: 'lines+markers',
        name: `Curve on ${activePoint.date}`,
        line: { color: '#F27D26', width: 2.5 },
        marker: { color: '#4CAF50', size: 7 },
      },
    ];

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 25, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Yield (%)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024', range: [0, 6.5] },
    };

    Plotly.react(timeSeries2DRef.current, traces, layout, { responsive: true, displaylogo: false });
  }, [currentIdx, timeSeries, maturities, tenors]);

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <Box className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">3D YIELD SURFACE & TIME-SERIES EVOLUTION</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Continuous 3D manifold (Maturity × Date × Yield), 2D thermal contours & dynamic playback
            </p>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-2">
          <div className="flex bg-[#16181D] p-1 rounded border border-[#2A2D33] text-xs font-mono">
            <button
              onClick={() => setViewMode('SURFACE_3D')}
              className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                viewMode === 'SURFACE_3D' ? 'bg-[#F27D26] text-black font-bold' : 'text-[#8E9299]'
              }`}
            >
              3D Surface
            </button>
            <button
              onClick={() => setViewMode('HEATMAP_2D')}
              className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                viewMode === 'HEATMAP_2D' ? 'bg-[#F27D26] text-black font-bold' : 'text-[#8E9299]'
              }`}
            >
              2D Heatmap
            </button>
          </div>

          <select
            value={colorScale}
            onChange={(e) => setColorScale(e.target.value as any)}
            className="bg-[#16181D] text-[#E0E0E0] px-2.5 py-1 rounded border border-[#2A2D33] text-xs font-mono focus:outline-none cursor-pointer"
          >
            <option value="Viridis">Viridis</option>
            <option value="Turbo">Turbo</option>
            <option value="Plasma">Plasma</option>
            <option value="Jet">Jet</option>
          </select>
        </div>
      </div>

      {/* Main Grid: 3D Surface Canvas & Historical Player */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 3D / Heatmap Canvas */}
        <div className="lg:col-span-8 bg-[#0E1013] p-4 rounded border border-[#1E2024]">
          <div className="flex items-center justify-between mb-1">
            <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">
              {viewMode === 'SURFACE_3D' ? '3D TERM STRUCTURE MANIFOLD' : 'TERM STRUCTURE HEATMAP CONTOURS'}
            </span>
            <span className="text-xs font-mono text-[#8E9299]">Time-Series: 200 Daily Snapshots</span>
          </div>
          <div ref={surfaceRef} className="w-full h-[460px]" />
        </div>

        {/* Dynamic Playback & Single-Slice Inspector */}
        <div className="lg:col-span-4 bg-[#16181D] p-4 rounded border border-[#1E2024] flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between border-b border-[#2A2D33] pb-2 mb-3">
              <span className="font-mono text-xs font-bold text-white uppercase tracking-wider">HISTORICAL TIME SCRUBBER</span>
              <span className="text-[10px] font-mono text-[#F27D26] font-bold">{timeSeries[currentIdx]?.date}</span>
            </div>

            {/* Playback Controls */}
            <div className="space-y-3">
              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="flex items-center gap-1.5 bg-[#F27D26] hover:bg-[#ff8e3d] text-black px-4 py-1.5 rounded font-mono font-bold text-xs shadow cursor-pointer transition-colors"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isPlaying ? 'Pause' : 'Play Time-Series'}</span>
                </button>
                <button
                  onClick={() => {
                    setIsPlaying(false);
                    setCurrentIdx(0);
                  }}
                  className="p-1.5 bg-[#0E1013] hover:bg-[#1A1C21] text-[#8E9299] hover:text-white rounded border border-[#2A2D33] cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

              {/* Slider */}
              <input
                type="range"
                min="0"
                max={timeSeries.length - 1}
                value={currentIdx}
                onChange={(e) => {
                  setIsPlaying(false);
                  setCurrentIdx(parseInt(e.target.value));
                }}
                className="w-full accent-[#F27D26] cursor-pointer"
              />
            </div>

            {/* 2D Slice Chart */}
            <div className="mt-4">
              <span className="text-[11px] font-mono text-[#E0E0E0] font-medium block mb-1">
                INSTANTANEOUS SNAPSHOT ({timeSeries[currentIdx]?.date})
              </span>
              <div ref={timeSeries2DRef} className="w-full h-[220px]" />
            </div>
          </div>

          {onLoadCurveFromDate && (
            <button
              onClick={() => {
                const pt = timeSeries[currentIdx];
                if (pt) onLoadCurveFromDate(pt.date, pt.yields);
              }}
              className="w-full py-2 bg-[#0E1013] hover:bg-[#1A1C21] text-[#F27D26] rounded border border-[#2A2D33] font-mono font-bold text-xs transition-colors cursor-pointer"
            >
              Load This Date into Curve Machine
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
