/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Interactive Curve Point Builder & Knot Manipulation Engine
 */

import React, { useState, useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { Sliders, Plus, Trash2, Lock, Unlock, ArrowUp, ArrowDown, Save, RotateCcw } from 'lucide-react';
import { RhinoCurve, CurvePoint, InterpolationMethod } from '../types/rhino';
import { generateDenseCurveGrid } from '../math/interpolations';

interface CurveBuilderProps {
  activeCurve: RhinoCurve;
  onUpdateCurvePoints: (points: CurvePoint[], method: InterpolationMethod) => void;
}

export const CurveBuilder: React.FC<CurveBuilderProps> = ({
  activeCurve,
  onUpdateCurvePoints,
}) => {
  const chartRef = useRef<HTMLDivElement>(null);

  const [points, setPoints] = useState<CurvePoint[]>(activeCurve.points);
  const [method, setMethod] = useState<InterpolationMethod>(activeCurve.interpolationMethod);

  // New point input form
  const [newTenor, setNewTenor] = useState('4Y');
  const [newMaturity, setNewMaturity] = useState('4.0');
  const [newYield, setNewYield] = useState('4.30');

  useEffect(() => {
    setPoints(activeCurve.points);
    setMethod(activeCurve.interpolationMethod);
  }, [activeCurve]);

  // Compute Dense Grid for display
  const denseGrid = React.useMemo(() => {
    return generateDenseCurveGrid(points, method);
  }, [points, method]);

  // Handle Point Editing
  const handleYieldChange = (index: number, val: number) => {
    const updated = [...points];
    updated[index] = { ...updated[index], yield: Number(val.toFixed(3)) };
    setPoints(updated);
    onUpdateCurvePoints(updated, method);
  };

  const handleBump = (index: number, bps: number) => {
    const updated = [...points];
    const newY = Math.max(0.01, updated[index].yield + bps / 100);
    updated[index] = { ...updated[index], yield: Number(newY.toFixed(3)) };
    setPoints(updated);
    onUpdateCurvePoints(updated, method);
  };

  const handleToggleLock = (index: number) => {
    const updated = [...points];
    updated[index] = { ...updated[index], locked: !updated[index].locked };
    setPoints(updated);
  };

  const handleDeletePoint = (index: number) => {
    if (points.length <= 3) return; // Prevent breaking interpolation
    const updated = points.filter((_, i) => i !== index);
    setPoints(updated);
    onUpdateCurvePoints(updated, method);
  };

  const handleAddPoint = () => {
    const mat = parseFloat(newMaturity);
    const yld = parseFloat(newYield);
    if (isNaN(mat) || isNaN(yld) || mat <= 0) return;

    const newPt: CurvePoint = {
      tenor: newTenor.trim() || `${mat}Y`,
      maturity: mat,
      yield: yld,
    };

    const updated = [...points, newPt].sort((a, b) => a.maturity - b.maturity);
    setPoints(updated);
    onUpdateCurvePoints(updated, method);
  };

  const handleMethodChange = (newMethod: InterpolationMethod) => {
    setMethod(newMethod);
    onUpdateCurvePoints(points, newMethod);
  };

  // Render Interactive Plotly Chart
  useEffect(() => {
    if (!chartRef.current) return;

    const traces: Plotly.Data[] = [
      {
        x: denseGrid.map((p) => p.maturity),
        y: denseGrid.map((p) => p.yield),
        type: 'scatter',
        mode: 'lines',
        name: `Interpolated (${method})`,
        line: { color: '#F27D26', width: 2.5 },
      },
      {
        x: points.map((p) => p.maturity),
        y: points.map((p) => p.yield),
        type: 'scatter',
        mode: 'markers+text',
        name: 'Control Knots',
        text: points.map((p) => p.tenor),
        textposition: 'top center',
        textfont: { family: 'monospace', size: 10, color: '#8E9299' },
        marker: {
          color: points.map((p) => (p.locked ? '#E91E63' : '#F27D26')),
          size: 8,
          symbol: points.map((p) => (p.locked ? 'square' : 'circle')),
          line: { color: '#FFFFFF', width: 1 },
        },
      },
    ];

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 55, r: 20, t: 25, b: 45 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Yield (%)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      legend: { orientation: 'h', y: 1.12, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(chartRef.current, traces, layout, { responsive: true, displaylogo: false });
  }, [points, denseGrid, method]);

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">YIELD CURVE POINT BUILDER</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Direct point manipulation, tenor bumping (+/- bps), and dynamic spline geometry
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-[#8E9299]">INTERPOLATION:</span>
          <select
            value={method}
            onChange={(e) => handleMethodChange(e.target.value as InterpolationMethod)}
            className="bg-[#16181D] text-white px-3 py-1.5 rounded border border-[#2A2D33] text-xs font-mono focus:outline-none cursor-pointer"
          >
            <option value="MonotoneSpline">Monotone Spline (PCHIP)</option>
            <option value="CubicSpline">Natural Cubic Spline (C²)</option>
            <option value="Linear">Piece-wise Linear</option>
          </select>
        </div>
      </div>

      {/* Main Grid: Control Points Table & Real-Time Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Table Panel */}
        <div className="lg:col-span-6 bg-[#16181D] p-4 rounded border border-[#1E2024] space-y-4">
          <div className="flex items-center justify-between border-b border-[#2A2D33] pb-2">
            <span className="font-mono text-xs font-bold text-white uppercase tracking-wider">CONTROL KNOTS ({points.length})</span>
            <span className="text-[10px] font-mono text-[#8E9299]">Click +/- to bump yield</span>
          </div>

          {/* Points Table */}
          <div className="overflow-x-auto max-h-[420px] overflow-y-auto pr-1 scrollbar-thin">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="text-[#8E9299] border-b border-[#1E2024] text-left">
                  <th className="py-1.5 px-2">Tenor</th>
                  <th className="py-1.5 px-2">Maturity (Y)</th>
                  <th className="py-1.5 px-2">Yield (%)</th>
                  <th className="py-1.5 px-2 text-center">Bumps</th>
                  <th className="py-1.5 px-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E2024]">
                {points.map((p, idx) => (
                  <tr key={idx} className="hover:bg-[#1A1C21] transition-colors">
                    <td className="py-1.5 px-2 font-bold text-[#F27D26]">{p.tenor}</td>
                    <td className="py-1.5 px-2 text-[#E0E0E0]">{p.maturity.toFixed(2)}Y</td>
                    <td className="py-1.5 px-2">
                      <input
                        type="number"
                        step="0.01"
                        value={p.yield}
                        disabled={p.locked}
                        onChange={(e) => handleYieldChange(idx, parseFloat(e.target.value) || 0)}
                        className={`w-20 bg-[#0E1013] px-2 py-0.5 rounded border border-[#2A2D33] text-white font-bold focus:outline-none ${
                          p.locked ? 'opacity-50 cursor-not-allowed' : ''
                        }`}
                      />
                    </td>
                    <td className="py-1.5 px-2">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          disabled={p.locked}
                          onClick={() => handleBump(idx, -5)}
                          title="-5 bps"
                          className="px-1.5 py-0.5 bg-[#0E1013] hover:bg-[#2A2D33] text-[#E91E63] rounded border border-[#2A2D33] text-[10px]"
                        >
                          -5bp
                        </button>
                        <button
                          disabled={p.locked}
                          onClick={() => handleBump(idx, -1)}
                          title="-1 bp"
                          className="px-1 py-0.5 bg-[#0E1013] hover:bg-[#2A2D33] text-[#E91E63]/80 rounded border border-[#2A2D33] text-[10px]"
                        >
                          -1bp
                        </button>
                        <button
                          disabled={p.locked}
                          onClick={() => handleBump(idx, +1)}
                          title="+1 bp"
                          className="px-1 py-0.5 bg-[#0E1013] hover:bg-[#2A2D33] text-[#4CAF50]/80 rounded border border-[#2A2D33] text-[10px]"
                        >
                          +1bp
                        </button>
                        <button
                          disabled={p.locked}
                          onClick={() => handleBump(idx, +5)}
                          title="+5 bps"
                          className="px-1.5 py-0.5 bg-[#0E1013] hover:bg-[#2A2D33] text-[#4CAF50] rounded border border-[#2A2D33] text-[10px]"
                        >
                          +5bp
                        </button>
                      </div>
                    </td>
                    <td className="py-1.5 px-2 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleToggleLock(idx)}
                          title={p.locked ? 'Unlock knot' : 'Lock knot'}
                          className="p-1 rounded text-[#8E9299] hover:text-white"
                        >
                          {p.locked ? <Lock className="w-3.5 h-3.5 text-[#E91E63]" /> : <Unlock className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          onClick={() => handleDeletePoint(idx)}
                          title="Delete Knot"
                          className="p-1 rounded text-[#8E9299] hover:text-[#E91E63]"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Add New Point Bar */}
          <div className="pt-3 border-t border-[#2A2D33]">
            <span className="text-xs font-mono text-[#E0E0E0] font-bold block mb-2">ADD CUSTOM TENOR KNOT</span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Tenor (4Y)"
                value={newTenor}
                onChange={(e) => setNewTenor(e.target.value)}
                className="w-24 bg-[#0E1013] px-2 py-1 rounded border border-[#2A2D33] text-xs font-mono text-white focus:outline-none"
              />
              <input
                type="number"
                step="0.1"
                placeholder="Years (4.0)"
                value={newMaturity}
                onChange={(e) => setNewMaturity(e.target.value)}
                className="w-24 bg-[#0E1013] px-2 py-1 rounded border border-[#2A2D33] text-xs font-mono text-white focus:outline-none"
              />
              <input
                type="number"
                step="0.01"
                placeholder="Yield %"
                value={newYield}
                onChange={(e) => setNewYield(e.target.value)}
                className="w-24 bg-[#0E1013] px-2 py-1 rounded border border-[#2A2D33] text-xs font-mono text-white focus:outline-none"
              />
              <button
                onClick={handleAddPoint}
                className="flex items-center gap-1 bg-[#F27D26] hover:bg-[#ff8e3d] text-black px-3 py-1 rounded text-xs font-mono font-bold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Knot</span>
              </button>
            </div>
          </div>
        </div>

        {/* Real-time Preview Chart */}
        <div className="lg:col-span-6 bg-[#0E1013] p-4 rounded border border-[#1E2024]">
          <div className="flex items-center justify-between mb-2">
            <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">REAL-TIME CURVE PREVIEW</span>
            <span className="text-[10px] font-mono text-[#4CAF50]">Live Spline</span>
          </div>
          <div ref={chartRef} className="w-full h-[470px]" />
        </div>
      </div>
    </div>
  );
};
