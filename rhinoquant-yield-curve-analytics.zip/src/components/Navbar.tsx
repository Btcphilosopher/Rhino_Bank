/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Institutional Navigation & Global Command Bar
 */

import React from 'react';
import {
  Activity,
  Cpu,
  Layers,
  Sliders,
  GitCompare,
  Box,
  Binary,
  Code2,
  Sparkles,
  RefreshCw,
  Download,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { RhinoCurve, Currency } from '../types/rhino';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  activeCurve: RhinoCurve;
  presetCurves: RhinoCurve[];
  onSelectCurve: (curveId: string) => void;
  onOpenAiModal: () => void;
  onExportRScript: () => void;
  onExportCsv: () => void;
  onReset: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  activeCurve,
  presetCurves,
  onSelectCurve,
  onOpenAiModal,
  onExportRScript,
  onExportCsv,
  onReset,
}) => {
  const tabs = [
    { id: 'curve_machine', label: 'Curve Machine', icon: Activity },
    { id: 'nelson_siegel', label: 'Nelson-Siegel & Svensson', icon: Cpu },
    { id: 'curve_builder', label: 'Point Builder', icon: Sliders },
    { id: 'transformations', label: 'Transformations', icon: Layers },
    { id: 'scenarios', label: 'Scenario Stress Lab', icon: Zap },
    { id: 'difference', label: 'Curve Spread & Diff', icon: GitCompare },
    { id: 'surface_3d', label: '3D Surface & Time-Series', icon: Box },
    { id: 'axis_lab', label: 'Axis Lab', icon: Binary },
    { id: 'fixed_income', label: 'Fixed-Income Analytics', icon: ShieldCheck },
    { id: 'pca_factors', label: 'PCA / Factor Engine', icon: Layers },
    { id: 'r_studio', label: 'R Studio & rhinoquant::', icon: Code2 },
  ];

  return (
    <header className="bg-[#0E1013] border-b border-[#1E2024] text-[#E0E0E0] sticky top-0 z-40">
      {/* Top Utility Bar */}
      <div className="max-w-[1720px] mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 border-b border-[#1E2024]">
        {/* Brand & Platform Identity */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 bg-[#F27D26] rounded flex items-center justify-center shadow-sm">
              <div className="w-3.5 h-3.5 border-t-2 border-l-2 border-black rotate-45 translate-y-0.5"></div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold tracking-tighter text-lg text-white font-sans">
                  RHINO<span className="text-[#F27D26]">QUANT</span>
                </span>
                <span className="text-[10px] font-mono uppercase bg-[#1A1C21] text-[#F27D26] px-2 py-0.5 rounded border border-[#2A2D33]">
                  YIELD CURVE SUITE
                </span>
                <span className="text-[10px] font-mono text-[#8E9299] hidden sm:inline-block">
                  v3.4.1 [C² SPLINES • NSS • 3D • PCA]
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Active Curve Selector & Currency & Status */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="hidden lg:flex items-center gap-2 text-[10px] font-mono px-2 py-1 bg-[#16181D] border border-[#2A2D33] rounded">
            <span className="text-[#4CAF50] font-bold">● LIVE SYSTEM</span>
            <span className="text-[#8E9299]">|</span>
            <span className="text-[#8E9299]">{activeCurve.currency}_BENCHMARK</span>
          </div>

          <div className="flex items-center gap-1.5 bg-[#16181D] px-2.5 py-1.5 rounded border border-[#2A2D33] text-xs font-mono">
            <span className="text-[#8E9299] text-[10px] uppercase">CURVE:</span>
            <select
              value={activeCurve.id}
              onChange={(e) => onSelectCurve(e.target.value)}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer max-w-[240px]"
            >
              {presetCurves.map((c) => (
                <option key={c.id} value={c.id} className="bg-[#16181D] text-[#E0E0E0]">
                  [{c.currency}] {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1 bg-[#16181D] px-2.5 py-1.5 rounded border border-[#2A2D33] text-xs font-mono">
            <span className="text-[#8E9299] text-[10px]">CCY:</span>
            <span className="text-[#F27D26] font-bold">{activeCurve.currency}</span>
          </div>

          {/* AI Fixed Income Strategist Trigger */}
          <button
            onClick={onOpenAiModal}
            className="flex items-center gap-1.5 bg-[#F27D26] hover:bg-[#ff8e3d] text-black px-3 py-1.5 rounded font-mono font-bold text-xs shadow transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>GEMINI 3.7 QUANT</span>
          </button>

          {/* Quick Actions */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={onExportRScript}
              title="Export Executable R Script"
              className="flex items-center gap-1 bg-[#16181D] hover:bg-[#1E2024] text-[#E0E0E0] hover:text-white px-2.5 py-1.5 rounded border border-[#2A2D33] text-xs font-mono transition-colors cursor-pointer"
            >
              <Code2 className="w-3.5 h-3.5 text-[#4FC3F7]" />
              <span className="hidden sm:inline">R Script</span>
            </button>

            <button
              onClick={onExportCsv}
              title="Export Curve Points CSV"
              className="flex items-center gap-1 bg-[#16181D] hover:bg-[#1E2024] text-[#E0E0E0] hover:text-white px-2.5 py-1.5 rounded border border-[#2A2D33] text-xs font-mono transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#4CAF50]" />
              <span className="hidden sm:inline">CSV</span>
            </button>

            <button
              onClick={onReset}
              title="Reset Active Parameters"
              className="p-1.5 bg-[#16181D] hover:bg-[#1E2024] text-[#8E9299] hover:text-white rounded border border-[#2A2D33] transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="max-w-[1720px] mx-auto px-4 overflow-x-auto scrollbar-thin">
        <div className="flex items-center space-x-1 py-1 min-w-max">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium uppercase tracking-wider transition-all cursor-pointer ${
                  isActive
                    ? 'text-white border-b-2 border-[#F27D26] bg-[#16181D]/60'
                    : 'text-[#8E9299] hover:text-white hover:bg-[#16181D]/40'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#F27D26]' : 'text-[#8E9299]'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
