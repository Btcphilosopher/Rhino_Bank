/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Dedicated Multi-Dimensional Axis Exploration Lab
 */

import React, { useState, useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { Binary, Sliders, ArrowRight, Layers } from 'lucide-react';
import { RhinoCurve, XAxisVariable, YAxisVariable, AxisConfig, FixedIncomeMetrics } from '../types/rhino';
import { EvaluatedCurvePoint } from '../math/interpolations';

interface AxisLabProps {
  activeCurve: RhinoCurve;
  denseGrid: EvaluatedCurvePoint[];
  fixedIncomeMetrics: FixedIncomeMetrics[];
}

export const AxisLab: React.FC<AxisLabProps> = ({
  activeCurve,
  denseGrid,
  fixedIncomeMetrics,
}) => {
  const chartRef = useRef<HTMLDivElement>(null);

  const [axisConfig, setAxisConfig] = useState<AxisConfig>({
    xVar: 'DURATION',
    yVar: 'CONVEXITY',
    xScale: 'linear',
    yScale: 'linear',
    inflationAssumption: 2.2,
  });

  const presets = [
    { name: 'Duration vs. Convexity', x: 'DURATION' as XAxisVariable, y: 'CONVEXITY' as YAxisVariable },
    { name: 'Maturity vs. Instantaneous Forward', x: 'MATURITY_YEARS' as XAxisVariable, y: 'INSTANTANEOUS_FORWARD' as YAxisVariable },
    { name: 'Duration vs. Par Bond Price', x: 'DURATION' as XAxisVariable, y: 'PRICE' as YAxisVariable },
    { name: 'DV01 Risk vs. Slope Derivative', x: 'DV01' as XAxisVariable, y: 'SLOPE_DERIVATIVE' as YAxisVariable },
    { name: 'Log Maturity vs. Discount Factor', x: 'LOG_MATURITY' as XAxisVariable, y: 'DISCOUNT_FACTOR' as YAxisVariable },
    { name: 'Maturity vs. Curvature d²Y/dX²', x: 'MATURITY_YEARS' as XAxisVariable, y: 'CURVATURE_DERIVATIVE' as YAxisVariable },
  ];

  // Axis transformations
  const mapX = (tau: number, fi: FixedIncomeMetrics): number => {
    switch (axisConfig.xVar) {
      case 'MATURITY_MONTHS': return tau * 12;
      case 'MATURITY_DAYS': return tau * 365.25;
      case 'LOG_MATURITY': return Math.log(Math.max(0.01, tau));
      case 'DURATION': return fi.macaulayDuration;
      case 'MODIFIED_DURATION': return fi.modifiedDuration;
      case 'DV01': return fi.dv01;
      case 'MATURITY_YEARS':
      default: return tau;
    }
  };

  const mapY = (p: EvaluatedCurvePoint, fi: FixedIncomeMetrics): number => {
    switch (axisConfig.yVar) {
      case 'INSTANTANEOUS_FORWARD': return fi.instantaneousForward;
      case 'FORWARD_RATE': return fi.forwardRate1Y;
      case 'REAL_YIELD': return p.yield - (axisConfig.inflationAssumption || 2.2);
      case 'DISCOUNT_FACTOR': return fi.discountFactor;
      case 'PRICE': return fi.bondPrice100;
      case 'DURATION': return fi.modifiedDuration;
      case 'CONVEXITY': return fi.convexity;
      case 'SLOPE_DERIVATIVE': return p.slope;
      case 'CURVATURE_DERIVATIVE': return p.curvature;
      case 'YIELD':
      default: return p.yield;
    }
  };

  useEffect(() => {
    if (!chartRef.current) return;

    const xValues = denseGrid.map((p, i) => mapX(p.maturity, fixedIncomeMetrics[i]));
    const yValues = denseGrid.map((p, i) => mapY(p, fixedIncomeMetrics[i]));

    const trace: Plotly.Data = {
      x: xValues,
      y: yValues,
      type: 'scatter',
      mode: 'lines+markers',
      marker: {
        color: denseGrid.map((p) => p.maturity),
        colorscale: 'Viridis',
        size: 7,
        colorbar: { title: { text: 'Maturity (Y)', font: { size: 10, color: '#8E9299' } }, len: 0.8 },
      },
      line: { color: '#F27D26', width: 2.5 },
      text: denseGrid.map((p) => `Maturity: ${p.maturity.toFixed(1)}Y`),
      hovertemplate: '<b>%{text}</b><br>X: %{x:.3f}<br>Y: %{y:.3f}<extra></extra>',
    };

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 60, r: 20, t: 25, b: 45 },
      xaxis: { title: { text: axisConfig.xVar.replace('_', ' '), font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: axisConfig.yVar.replace('_', ' '), font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
    };

    Plotly.react(chartRef.current, [trace], layout, { responsive: true, displaylogo: false });
  }, [denseGrid, fixedIncomeMetrics, axisConfig]);

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <Binary className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">MULTI-DIMENSIONAL FIXED-INCOME AXIS LAB</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Arbitrary projection engine for Duration, Convexity, DV01, Forward rates and derivatives
            </p>
          </div>
        </div>
      </div>

      {/* Axis Presets & Selectors */}
      <div className="bg-[#16181D] p-4 rounded border border-[#1E2024] space-y-3">
        <span className="text-xs font-mono text-[#8E9299] font-bold uppercase tracking-wider block">RECOMMENDED PROJECTION PRESETS</span>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
          {presets.map((p, idx) => (
            <button
              key={idx}
              onClick={() => setAxisConfig({ ...axisConfig, xVar: p.x, yVar: p.y })}
              className={`p-2 rounded border text-xs font-mono text-left transition-all cursor-pointer ${
                axisConfig.xVar === p.x && axisConfig.yVar === p.y
                  ? 'bg-[#1A1C21] text-[#F27D26] border-[#F27D26] font-bold'
                  : 'bg-[#0E1013] text-[#E0E0E0] border-[#2A2D33] hover:border-[#F27D26]/60'
              }`}
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Chart Canvas */}
      <div className="bg-[#0E1013] p-4 rounded border border-[#1E2024]">
        <div className="flex items-center justify-between mb-2">
          <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">
            PROJECTION: {axisConfig.xVar} (X) VS. {axisConfig.yVar} (Y)
          </span>
          <span className="text-xs font-mono text-[#F27D26]">Color mapped by Maturity (Y)</span>
        </div>
        <div ref={chartRef} className="w-full h-[480px]" />
      </div>
    </div>
  );
};
