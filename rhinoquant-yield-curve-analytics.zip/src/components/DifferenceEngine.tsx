/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Curve Spread & Difference Engine (Curve A vs Curve B)
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { GitCompare, ArrowRightLeft, TrendingUp } from 'lucide-react';
import { RhinoCurve } from '../types/rhino';
import { generateDenseCurveGrid } from '../math/interpolations';
import { computeGeometryMetrics } from '../math/geometry';

interface DifferenceEngineProps {
  presetCurves: RhinoCurve[];
  activeCurve: RhinoCurve;
}

export const DifferenceEngine: React.FC<DifferenceEngineProps> = ({
  presetCurves,
  activeCurve,
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const spreadChartRef = useRef<HTMLDivElement>(null);

  const [curveAId, setCurveAId] = useState<string>(activeCurve.id);
  const [curveBId, setCurveBId] = useState<string>(
    presetCurves.find((c) => c.id !== activeCurve.id)?.id || presetCurves[1].id
  );

  const curveA = useMemo(() => {
    return presetCurves.find((c) => c.id === curveAId) || activeCurve;
  }, [presetCurves, curveAId, activeCurve]);

  const curveB = useMemo(() => {
    return presetCurves.find((c) => c.id === curveBId) || presetCurves[1];
  }, [presetCurves, curveBId]);

  // Compute Grids & Geometry
  const gridA = useMemo(() => generateDenseCurveGrid(curveA.points, curveA.interpolationMethod), [curveA]);
  const gridB = useMemo(() => generateDenseCurveGrid(curveB.points, curveB.interpolationMethod), [curveB]);

  const geomA = useMemo(() => computeGeometryMetrics(curveA.points, gridA), [curveA.points, gridA]);
  const geomB = useMemo(() => computeGeometryMetrics(curveB.points, gridB), [curveB.points, gridB]);

  // Net Spread Grid B - A
  const diffGrid = useMemo(() => {
    return gridA.map((pA, i) => {
      const pB = gridB[i];
      return {
        maturity: pA.maturity,
        diffBps: (pB.yield - pA.yield) * 100,
        slopeDiff: pB.slope - pA.slope,
      };
    });
  }, [gridA, gridB]);

  // Render Charts
  useEffect(() => {
    if (!chartRef.current || !spreadChartRef.current) return;

    // Overlay Chart
    const traces: Plotly.Data[] = [
      {
        x: gridA.map((p) => p.maturity),
        y: gridA.map((p) => p.yield),
        type: 'scatter',
        mode: 'lines',
        name: `Curve A: ${curveA.name}`,
        line: { color: '#4FC3F7', width: 2.5 },
      },
      {
        x: gridB.map((p) => p.maturity),
        y: gridB.map((p) => p.yield),
        type: 'scatter',
        mode: 'lines',
        name: `Curve B: ${curveB.name}`,
        line: { color: '#F27D26', width: 2.5 },
      },
    ];

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 55, r: 20, t: 25, b: 45 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Yield (%)', font: { size: 11, color: '#8E9299' } }, gridcolor: '#1E2024' },
      legend: { orientation: 'h', y: 1.15, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(chartRef.current, traces, layout, { responsive: true, displaylogo: false });

    // Net Spread Chart
    const spreadTrace: Plotly.Data = {
      x: diffGrid.map((p) => p.maturity),
      y: diffGrid.map((p) => p.diffBps),
      type: 'scatter',
      mode: 'lines',
      name: 'Spread (Curve B - Curve A)',
      fill: 'tozeroy',
      fillcolor: 'rgba(242, 125, 38, 0.15)',
      line: { color: '#F27D26', width: 2 },
    };

    const spreadLayout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 20, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Spread B - A (bps)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024', zerolinecolor: '#2A2D33' },
    };

    Plotly.react(spreadChartRef.current, [spreadTrace], spreadLayout, { responsive: true, displaylogo: false });
  }, [gridA, gridB, diffGrid, curveA, curveB]);

  return (
    <div className="space-y-4">
      {/* Header & Curve Selectors */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <GitCompare className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">CROSS-CURVE SPREAD & DIFFERENCE ENGINE</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Comparative term structure analysis, cross-market basis spreads & relative value matrices
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Curve A Selector */}
          <div className="flex items-center gap-1.5 bg-[#16181D] px-2.5 py-1.5 rounded border border-[#2A2D33] text-xs font-mono">
            <span className="text-[#4FC3F7] font-bold">CURVE A:</span>
            <select
              value={curveAId}
              onChange={(e) => setCurveAId(e.target.value)}
              className="bg-transparent text-[#E0E0E0] focus:outline-none cursor-pointer max-w-[200px]"
            >
              {presetCurves.map((c) => (
                <option key={c.id} value={c.id} className="bg-[#16181D]">
                  [{c.currency}] {c.name}
                </option>
              ))}
            </select>
          </div>

          <ArrowRightLeft className="w-4 h-4 text-[#8E9299]" />

          {/* Curve B Selector */}
          <div className="flex items-center gap-1.5 bg-[#16181D] px-2.5 py-1.5 rounded border border-[#2A2D33] text-xs font-mono">
            <span className="text-[#F27D26] font-bold">CURVE B:</span>
            <select
              value={curveBId}
              onChange={(e) => setCurveBId(e.target.value)}
              className="bg-transparent text-[#E0E0E0] focus:outline-none cursor-pointer max-w-[200px]"
            >
              {presetCurves.map((c) => (
                <option key={c.id} value={c.id} className="bg-[#16181D]">
                  [{c.currency}] {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Comparative Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">2s10s Spread Diff (B - A)</span>
          <div className="text-lg font-mono font-bold text-[#F27D26]">
            {(geomB.spread2s10s - geomA.spread2s10s) > 0 ? `+` : ''}
            {(geomB.spread2s10s - geomA.spread2s10s).toFixed(1)} <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">
            A: {geomA.spread2s10s.toFixed(1)} bp vs B: {geomB.spread2s10s.toFixed(1)} bp
          </div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">Butterfly Diff (2s5s10s)</span>
          <div className="text-lg font-mono font-bold text-[#4FC3F7]">
            {(geomB.butterfly2s5s10s - geomA.butterfly2s5s10s) > 0 ? `+` : ''}
            {(geomB.butterfly2s5s10s - geomA.butterfly2s5s10s).toFixed(1)} <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Relative Belly Richness</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">Level Mean Diff</span>
          <div className="text-lg font-mono font-bold text-[#4CAF50]">
            {(geomB.levelMean - geomA.levelMean) > 0 ? `+` : ''}
            {((geomB.levelMean - geomA.levelMean) * 100).toFixed(1)} <span className="text-xs font-normal text-[#8E9299]">bps</span>
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Average Rate Differential</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">Formations</span>
          <div className="text-sm font-mono font-bold text-white truncate">
            {geomA.formation} vs {geomB.formation}
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Geometric Regime</div>
        </div>
      </div>

      {/* Charts Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-8 bg-[#0E1013] p-4 rounded border border-[#1E2024]">
          <div className="flex items-center justify-between mb-1">
            <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">ABSOLUTE CURVE COMPARISON</span>
            <span className="text-xs font-mono text-[#8E9299]">Overlay View</span>
          </div>
          <div ref={chartRef} className="w-full h-[360px]" />
        </div>

        <div className="lg:col-span-4 bg-[#0E1013] p-4 rounded border border-[#1E2024]">
          <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase block mb-1">NET SPREAD PROFILE ΔY(τ) [BPS]</span>
          <div ref={spreadChartRef} className="w-full h-[360px]" />
        </div>
      </div>
    </div>
  );
};
