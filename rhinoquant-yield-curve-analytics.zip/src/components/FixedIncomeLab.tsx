/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Institutional Fixed-Income Analytics, Forward Curves & DV01 Risk Ladder
 */

import React, { useState, useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { ShieldCheck, TrendingUp, DollarSign, Activity, Percent } from 'lucide-react';
import { RhinoCurve, FixedIncomeMetrics } from '../types/rhino';
import { EvaluatedCurvePoint } from '../math/interpolations';
import { computeFixedIncomeAnalytics } from '../math/fixedIncome';

interface FixedIncomeLabProps {
  activeCurve: RhinoCurve;
  denseGrid: EvaluatedCurvePoint[];
  fixedIncomeMetrics: FixedIncomeMetrics[];
}

export const FixedIncomeLab: React.FC<FixedIncomeLabProps> = ({
  activeCurve,
  denseGrid,
  fixedIncomeMetrics,
}) => {
  const forwardChartRef = useRef<HTMLDivElement>(null);
  const discountChartRef = useRef<HTMLDivElement>(null);
  const dv01ChartRef = useRef<HTMLDivElement>(null);

  // Custom bond calculator inputs
  const [calcMaturity, setCalcMaturity] = useState(10.0);
  const [calcCoupon, setCalcCoupon] = useState(4.5);
  const [calcFaceValue, setCalcFaceValue] = useState(1000000); // $1M

  // Sample discrete tenors for the risk ladder
  const ladderTenors = [1.0, 2.0, 3.0, 5.0, 7.0, 10.0, 20.0, 30.0];
  const ladderMetrics = ladderTenors.map((tau) => {
    // Find closest point in denseGrid
    let closest = denseGrid[0];
    let minDist = 999;
    for (const p of denseGrid) {
      const dist = Math.abs(p.maturity - tau);
      if (dist < minDist) {
        minDist = dist;
        closest = p;
      }
    }
    return computeFixedIncomeAnalytics(closest.maturity, closest.yield, closest.slope, closest.yield);
  });

  // Render Charts
  useEffect(() => {
    if (!forwardChartRef.current || !discountChartRef.current || !dv01ChartRef.current) return;

    // 1. Yield vs. Forward Curves Plot
    const spotTrace: Plotly.Data = {
      x: denseGrid.map((p) => p.maturity),
      y: denseGrid.map((p) => p.yield),
      type: 'scatter',
      mode: 'lines',
      name: 'Zero / Spot Rate y(τ)',
      line: { color: '#F27D26', width: 2.5 },
    };

    const instFwdTrace: Plotly.Data = {
      x: denseGrid.map((p) => p.maturity),
      y: fixedIncomeMetrics.map((fi) => fi.instantaneousForward),
      type: 'scatter',
      mode: 'lines',
      name: 'Instantaneous Forward f(τ)',
      line: { color: '#4FC3F7', width: 2, dash: 'dot' },
    };

    const fwd1YTrace: Plotly.Data = {
      x: denseGrid.map((p) => p.maturity),
      y: fixedIncomeMetrics.map((fi) => fi.forwardRate1Y),
      type: 'scatter',
      mode: 'lines',
      name: '1Y Forward Rate F(τ, τ+1)',
      line: { color: '#4CAF50', width: 2, dash: 'dash' },
    };

    const fwdLayout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 25, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Rate (%)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      legend: { orientation: 'h', y: 1.15, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(forwardChartRef.current, [spotTrace, instFwdTrace, fwd1YTrace], fwdLayout, { responsive: true, displaylogo: false });

    // 2. Discount Factor Curve D(τ)
    const dfTrace: Plotly.Data = {
      x: denseGrid.map((p) => p.maturity),
      y: fixedIncomeMetrics.map((fi) => fi.discountFactor),
      type: 'scatter',
      mode: 'lines',
      name: 'Discount Factor D(τ)',
      fill: 'tozeroy',
      fillcolor: 'rgba(76, 175, 80, 0.15)',
      line: { color: '#4CAF50', width: 2 },
    };

    const dfLayout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 20, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Discount Factor D(τ)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
    };

    Plotly.react(discountChartRef.current, [dfTrace], dfLayout, { responsive: true, displaylogo: false });

    // 3. DV01 Risk Ladder Bar Chart
    const dv01Trace: Plotly.Data = {
      x: ladderMetrics.map((m) => `${m.maturity}Y`),
      y: ladderMetrics.map((m) => m.dv01 * 10), // Per $1M
      type: 'bar',
      name: 'DV01 ($ per $1M Par)',
      marker: { color: '#F27D26' },
    };

    const dv01Layout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 20, b: 40 },
      xaxis: { title: { text: 'Tenor', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'DV01 ($ / bp / $1M)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
    };

    Plotly.react(dv01ChartRef.current, [dv01Trace], dv01Layout, { responsive: true, displaylogo: false });
  }, [denseGrid, fixedIncomeMetrics, ladderMetrics]);

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">FIXED-INCOME & FORWARD RATE ANALYTICS</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Instantaneous forward curves f(τ), continuous discount factors D(τ), Macaulay/Mod duration & DV01 ladder
            </p>
          </div>
        </div>

        <div className="text-xs font-mono text-[#8E9299]">
          Currency: <span className="text-[#F27D26] font-bold">{activeCurve.currency}</span>
        </div>
      </div>

      {/* Visualizers Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Spot vs Forward Curves */}
        <div className="lg:col-span-8 bg-[#0E1013] p-4 rounded border border-[#1E2024]">
          <div className="flex items-center justify-between mb-1">
            <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase">SPOT RATE VS. INSTANTANEOUS & 1Y FORWARD CURVES</span>
            <span className="text-xs font-mono text-[#F27D26]">f(τ) = y(τ) + τ·y'(τ)</span>
          </div>
          <div ref={forwardChartRef} className="w-full h-[360px]" />
        </div>

        {/* Discount Factor & DV01 */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-[#0E1013] p-4 rounded border border-[#1E2024]">
            <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase block mb-1">DISCOUNT FACTOR D(τ) = exp(-y·τ)</span>
            <div ref={discountChartRef} className="w-full h-[165px]" />
          </div>

          <div className="bg-[#0E1013] p-4 rounded border border-[#1E2024]">
            <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase block mb-1">DV01 RISK LADDER ($ / bp / $1M)</span>
            <div ref={dv01ChartRef} className="w-full h-[165px]" />
          </div>
        </div>
      </div>

      {/* Benchmark Risk Ladder Table */}
      <div className="bg-[#16181D] p-4 rounded border border-[#1E2024] space-y-3">
        <div className="flex items-center justify-between border-b border-[#2A2D33] pb-2">
          <span className="font-mono text-xs font-bold text-white uppercase tracking-wider">BENCHMARK TENOR RISK & SENSITIVITY LADDER</span>
          <span className="text-[10px] font-mono text-[#4CAF50] bg-[#1A1C21] px-2 py-0.5 rounded border border-[#2A2D33]">
            Analytical Fixed Income
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="text-[#8E9299] border-b border-[#2A2D33] text-left">
                <th className="py-1.5 px-3">Tenor</th>
                <th className="py-1.5 px-3">Yield (%)</th>
                <th className="py-1.5 px-3">Inst. Fwd (%)</th>
                <th className="py-1.5 px-3">Discount Factor</th>
                <th className="py-1.5 px-3">Mod Duration</th>
                <th className="py-1.5 px-3">Convexity (Y²)</th>
                <th className="py-1.5 px-3">DV01 ($/100k)</th>
                <th className="py-1.5 px-3">Par Bond Price</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E2024]">
              {ladderMetrics.map((m, idx) => (
                <tr key={idx} className="hover:bg-[#1A1C21] transition-colors">
                  <td className="py-2 px-3 font-bold text-[#F27D26]">{m.maturity}Y</td>
                  <td className="py-2 px-3 text-[#4FC3F7]">{m.yield.toFixed(3)}%</td>
                  <td className="py-2 px-3 text-white">{m.instantaneousForward.toFixed(3)}%</td>
                  <td className="py-2 px-3 text-[#4CAF50]">{m.discountFactor.toFixed(4)}</td>
                  <td className="py-2 px-3 text-[#E0E0E0]">{m.modifiedDuration.toFixed(2)}Y</td>
                  <td className="py-2 px-3 text-[#8E9299]">{m.convexity.toFixed(2)}</td>
                  <td className="py-2 px-3 font-bold text-[#F27D26]">${m.dv01.toFixed(2)}</td>
                  <td className="py-2 px-3 text-[#E0E0E0]">${m.bondPrice100.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
