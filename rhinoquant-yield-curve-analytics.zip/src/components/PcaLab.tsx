/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Term Structure Principal Component Analysis (PCA) & Factor Lab
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { Layers, RotateCcw, PieChart, TrendingUp, Sliders } from 'lucide-react';
import { PcaResult, TimeSeriesCurvePoint } from '../types/rhino';
import { computeCurvePCA, reconstructCurveFromPCA } from '../math/pca';
import { STANDARD_TENORS } from '../data/sampleCurves';

interface PcaLabProps {
  timeSeries: TimeSeriesCurvePoint[];
}

export const PcaLab: React.FC<PcaLabProps> = ({ timeSeries }) => {
  const loadingsChartRef = useRef<HTMLDivElement>(null);
  const scoresChartRef = useRef<HTMLDivElement>(null);
  const reconChartRef = useRef<HTMLDivElement>(null);

  const tenors = useMemo(() => STANDARD_TENORS.map((t) => t.tenor), []);
  const maturities = useMemo(() => STANDARD_TENORS.map((t) => t.maturity), []);

  // Compute Full PCA
  const pcaResult: PcaResult = useMemo(() => {
    return computeCurvePCA(timeSeries, tenors, maturities);
  }, [timeSeries, tenors, maturities]);

  // Factor Score Sliders for Synthesis
  const [scorePC1, setScorePC1] = useState(0.0); // Level shock
  const [scorePC2, setScorePC2] = useState(0.0); // Slope shock
  const [scorePC3, setScorePC3] = useState(0.0); // Curvature shock

  // Reconstructed Curve
  const reconstructedYields = useMemo(() => {
    return reconstructCurveFromPCA(pcaResult, scorePC1, scorePC2, scorePC3);
  }, [pcaResult, scorePC1, scorePC2, scorePC3]);

  // Render Loadings & Scores Charts
  useEffect(() => {
    if (!loadingsChartRef.current || !scoresChartRef.current || !reconChartRef.current) return;

    // 1. Factor Loadings Plot
    const pc1Trace: Plotly.Data = {
      x: maturities,
      y: pcaResult.loadings.pc1,
      type: 'scatter',
      mode: 'lines+markers',
      name: `PC1: Level (${(pcaResult.explainedVariance[0] * 100).toFixed(1)}%)`,
      line: { color: '#F27D26', width: 2.5 },
    };

    const pc2Trace: Plotly.Data = {
      x: maturities,
      y: pcaResult.loadings.pc2,
      type: 'scatter',
      mode: 'lines+markers',
      name: `PC2: Slope (${(pcaResult.explainedVariance[1] * 100).toFixed(1)}%)`,
      line: { color: '#4FC3F7', width: 2.5 },
    };

    const pc3Trace: Plotly.Data = {
      x: maturities,
      y: pcaResult.loadings.pc3,
      type: 'scatter',
      mode: 'lines+markers',
      name: `PC3: Curvature (${(pcaResult.explainedVariance[2] * 100).toFixed(1)}%)`,
      line: { color: '#4CAF50', width: 2.5 },
    };

    const loadLayout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 25, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Eigenvector Loading', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024', zerolinecolor: '#2A2D33' },
      legend: { orientation: 'h', y: 1.15, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(loadingsChartRef.current, [pc1Trace, pc2Trace, pc3Trace], loadLayout, { responsive: true, displaylogo: false });

    // 2. Historical Factor Scores Time-Series
    const dates = pcaResult.historicalFactorScores.map((s) => s.date);
    const z1 = pcaResult.historicalFactorScores.map((s) => s.pc1);
    const z2 = pcaResult.historicalFactorScores.map((s) => s.pc2);
    const z3 = pcaResult.historicalFactorScores.map((s) => s.pc3);

    const score1Trace: Plotly.Data = { x: dates, y: z1, type: 'scatter', mode: 'lines', name: 'Z1 (Level)', line: { color: '#F27D26' } };
    const score2Trace: Plotly.Data = { x: dates, y: z2, type: 'scatter', mode: 'lines', name: 'Z2 (Slope)', line: { color: '#4FC3F7' } };
    const score3Trace: Plotly.Data = { x: dates, y: z3, type: 'scatter', mode: 'lines', name: 'Z3 (Curv)', line: { color: '#4CAF50' } };

    const scoreLayout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 25, b: 40 },
      xaxis: { title: { text: 'Date', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Factor Score (Std Dev)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024', zerolinecolor: '#2A2D33' },
      legend: { orientation: 'h', y: 1.15, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(scoresChartRef.current, [score1Trace, score2Trace, score3Trace], scoreLayout, { responsive: true, displaylogo: false });

    // 3. Reconstructed Yield Curve Plot
    const meanTrace: Plotly.Data = {
      x: maturities,
      y: pcaResult.meanCurve,
      type: 'scatter',
      mode: 'lines',
      name: 'Mean Curve',
      line: { color: '#8E9299', width: 1.5, dash: 'dash' },
    };

    const reconTrace: Plotly.Data = {
      x: maturities,
      y: reconstructedYields,
      type: 'scatter',
      mode: 'lines+markers',
      name: 'PCA Synthesized',
      line: { color: '#F27D26', width: 2.5 },
      marker: { color: '#4CAF50', size: 6 },
    };

    const reconLayout: Partial<Plotly.Layout> = {
      autosize: true,
      paper_bgcolor: '#0E1013',
      plot_bgcolor: '#0E1013',
      font: { family: 'JetBrains Mono, monospace', color: '#8E9299', size: 10 },
      margin: { l: 50, r: 20, t: 25, b: 40 },
      xaxis: { title: { text: 'Maturity (Years)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      yaxis: { title: { text: 'Yield (%)', font: { size: 10, color: '#8E9299' } }, gridcolor: '#1E2024' },
      legend: { orientation: 'h', y: 1.15, x: 0, font: { size: 9, color: '#8E9299' } },
    };

    Plotly.react(reconChartRef.current, [meanTrace, reconTrace], reconLayout, { responsive: true, displaylogo: false });
  }, [pcaResult, maturities, reconstructedYields]);

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="bg-[#0E1013] p-3 rounded border border-[#1E2024] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-[#16181D] border border-[#2A2D33] text-[#F27D26]">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-sans text-sm font-bold text-white tracking-wide uppercase">PRINCIPAL COMPONENT ANALYSIS (PCA) & FACTOR ENGINE</h2>
            <p className="text-xs text-[#8E9299] font-sans">
              Empirical covariance decomposition into orthogonal Level, Slope & Curvature factors
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setScorePC1(0);
              setScorePC2(0);
              setScorePC3(0);
            }}
            className="flex items-center gap-1 bg-[#16181D] hover:bg-[#1A1C21] text-[#8E9299] hover:text-white px-3 py-1.5 rounded border border-[#2A2D33] text-xs font-mono transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Scores</span>
          </button>
        </div>
      </div>

      {/* Variance Explained HUD */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">PC1: Level</span>
          <div className="text-xl font-mono font-bold text-[#F27D26]">
            {(pcaResult.explainedVariance[0] * 100).toFixed(1)}%
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Parallel Shift Dynamics</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">PC2: Slope</span>
          <div className="text-xl font-mono font-bold text-[#4FC3F7]">
            {(pcaResult.explainedVariance[1] * 100).toFixed(1)}%
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Steepening / Flattening Twist</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">PC3: Curvature</span>
          <div className="text-xl font-mono font-bold text-[#4CAF50]">
            {(pcaResult.explainedVariance[2] * 100).toFixed(1)}%
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Belly Hump / Butterfly</div>
        </div>

        <div className="bg-[#16181D] p-3.5 rounded border border-[#1E2024]">
          <span className="text-[10px] font-mono text-[#8E9299] uppercase">Total 3-Factor Variance</span>
          <div className="text-xl font-mono font-bold text-white">
            {(pcaResult.cumulativeVariance[2] * 100).toFixed(1)}%
          </div>
          <div className="text-[9px] font-mono text-[#8E9299]">Total Curve Variance Captured</div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Factor Loadings */}
        <div className="lg:col-span-6 bg-[#0E1013] p-4 rounded border border-[#1E2024]">
          <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase block mb-1">FACTOR LOADINGS (EIGENVECTORS)</span>
          <div ref={loadingsChartRef} className="w-full h-[300px]" />
        </div>

        {/* Historical Factor Scores */}
        <div className="lg:col-span-6 bg-[#0E1013] p-4 rounded border border-[#1E2024]">
          <span className="font-sans text-xs font-semibold text-white tracking-wide uppercase block mb-1">HISTORICAL FACTOR SCORES (Z_T)</span>
          <div ref={scoresChartRef} className="w-full h-[300px]" />
        </div>
      </div>

      {/* Interactive PCA Curve Synthesizer */}
      <div className="bg-[#16181D] p-4 rounded border border-[#1E2024] space-y-4">
        <div className="flex items-center justify-between border-b border-[#2A2D33] pb-2">
          <span className="font-mono text-xs font-bold text-white uppercase tracking-wider">INTERACTIVE PCA CURVE SYNTHESIZER</span>
          <span className="text-[10px] font-mono text-[#F27D26]">y(τ) = ȳ(τ) + z₁e₁(τ) + z₂e₂(τ) + z₃e₃(τ)</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-5 space-y-4">
            {/* PC1 Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#E0E0E0] font-medium">PC1 Level Shock (z₁)</span>
                <span className="text-[#F27D26] font-bold">{scorePC1 > 0 ? `+${scorePC1.toFixed(2)}` : scorePC1.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="-3.0"
                max="3.0"
                step="0.05"
                value={scorePC1}
                onChange={(e) => setScorePC1(parseFloat(e.target.value))}
                className="w-full accent-[#F27D26] cursor-pointer"
              />
            </div>

            {/* PC2 Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#E0E0E0] font-medium">PC2 Slope Twist (z₂)</span>
                <span className="text-[#4FC3F7] font-bold">{scorePC2 > 0 ? `+${scorePC2.toFixed(2)}` : scorePC2.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="-3.0"
                max="3.0"
                step="0.05"
                value={scorePC2}
                onChange={(e) => setScorePC2(parseFloat(e.target.value))}
                className="w-full accent-[#4FC3F7] cursor-pointer"
              />
            </div>

            {/* PC3 Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#E0E0E0] font-medium">PC3 Curvature Hump (z₃)</span>
                <span className="text-[#4CAF50] font-bold">{scorePC3 > 0 ? `+${scorePC3.toFixed(2)}` : scorePC3.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="-3.0"
                max="3.0"
                step="0.05"
                value={scorePC3}
                onChange={(e) => setScorePC3(parseFloat(e.target.value))}
                className="w-full accent-[#4CAF50] cursor-pointer"
              />
            </div>
          </div>

          <div className="lg:col-span-7 bg-[#0E1013] p-3 rounded border border-[#1E2024]">
            <div ref={reconChartRef} className="w-full h-[220px]" />
          </div>
        </div>
      </div>
    </div>
  );
};
