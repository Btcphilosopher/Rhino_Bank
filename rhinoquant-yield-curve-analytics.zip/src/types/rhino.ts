/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Core Mathematical & Domain Types
 * Namespace: rhinoquant::
 */

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CHF' | 'CAD' | 'AUD';

export type CurveType = 'Observed' | 'Fitted' | 'Interpolated' | 'Shocked' | 'Synthetic' | 'Historical';

export type InterpolationMethod = 
  | 'Linear' 
  | 'CubicSpline' 
  | 'MonotoneSpline' 
  | 'Polynomial' 
  | 'NelsonSiegel' 
  | 'Svensson';

export type CurveFormationType =
  | 'NORMAL'
  | 'FLAT'
  | 'INVERTED'
  | 'HUMPED'
  | 'U_SHAPED'
  | 'DOUBLE_HUMPED'
  | 'S_SHAPED'
  | 'BULL_STEEPENER'
  | 'BEAR_STEEPENER'
  | 'BULL_FLATTENER'
  | 'BEAR_FLATTENER';

export interface CurvePoint {
  tenor: string;      // e.g. "3M", "2Y", "10Y"
  maturity: number;   // In years (e.g. 0.25, 2.0, 10.0)
  yield: number;      // Annualized yield in percent (e.g. 4.25)
  locked?: boolean;
}

export interface NelsonSiegelParams {
  beta0: number; // Level (long-term rate)
  beta1: number; // Slope (short-term component)
  beta2: number; // Curvature / Hump (medium-term component)
  lambda: number; // Decay / scale factor for peak location
}

export interface SvenssonParams extends NelsonSiegelParams {
  beta3: number;  // Second hump / curvature
  lambda2: number; // Second decay parameter
}

export interface ModelFitDiagnostics {
  rmse: number;       // Root Mean Square Error (bps)
  mae: number;        // Mean Absolute Error (bps)
  rSquared: number;   // Coefficient of determination
  aic: number;        // Akaike Information Criterion
  bic: number;        // Bayesian Information Criterion
  maxResidual: number;// Max error in bps
  residuals: { maturity: number; observed: number; fitted: number; residualBps: number }[];
}

export interface InflectionPoint {
  maturity: number;
  yield: number;
  type: 'LOCAL_MAX' | 'LOCAL_MIN' | 'INFLECTION' | 'MAX_SLOPE' | 'MIN_SLOPE' | 'MAX_CURVATURE';
  label: string;
  slope: number;      // dY/dX in bps/yr
  curvature: number;  // d²Y/dX² in bps/yr²
}

export interface GeometryMetrics {
  formation: CurveFormationType;
  formationDescription: string;
  formationConfidence: number; // 0 to 1
  levelMean: number;          // %
  spread2s10s: number;        // bps
  spread3Ms10s: number;       // bps
  spread5s30s: number;        // bps
  butterfly2s5s10s: number;   // bps (2*5Y - 2Y - 10Y)
  maxSlopeMaturity: number;
  maxSlopeValue: number;      // bps/yr
  minSlopeMaturity: number;
  minSlopeValue: number;
  maxCurvatureMaturity: number;
  maxCurvatureValue: number;  // bps/yr²
  inflectionPoints: InflectionPoint[];
  steepestSegment: { start: number; end: number; slope: number };
  flattestSegment: { start: number; end: number; slope: number };
}

export interface RhinoCurve {
  id: string;
  name: string;
  timestamp: string;
  currency: Currency;
  type: CurveType;
  points: CurvePoint[];
  units: 'PERCENT' | 'BPS' | 'DECIMAL';
  source: string;
  interpolationMethod: InterpolationMethod;
  model: 'Raw' | 'Spline' | 'NelsonSiegel' | 'Svensson';
  parameters?: Partial<SvenssonParams>;
  diagnostics?: ModelFitDiagnostics;
  geometry?: GeometryMetrics;
  scenario?: string;
  version: string;
  auditTrail?: string[];
}

export type XAxisVariable =
  | 'MATURITY_YEARS'
  | 'MATURITY_MONTHS'
  | 'MATURITY_DAYS'
  | 'LOG_MATURITY'
  | 'DURATION'
  | 'MODIFIED_DURATION'
  | 'DV01'
  | 'KEY_RATE_BUCKET'
  | 'FORWARD_PERIOD'
  | 'OBSERVATION_INDEX';

export type YAxisVariable =
  | 'YIELD'
  | 'ZERO_RATE'
  | 'PAR_RATE'
  | 'SPOT_RATE'
  | 'FORWARD_RATE'
  | 'INSTANTANEOUS_FORWARD'
  | 'REAL_YIELD'
  | 'NOMINAL_YIELD'
  | 'INFLATION_EXPECTATION'
  | 'SPREAD'
  | 'YIELD_CHANGE'
  | 'DISCOUNT_FACTOR'
  | 'PRICE'
  | 'DURATION'
  | 'CONVEXITY'
  | 'SLOPE_DERIVATIVE'
  | 'CURVATURE_DERIVATIVE';

export interface AxisConfig {
  xVar: XAxisVariable;
  yVar: YAxisVariable;
  xScale: 'linear' | 'log';
  yScale: 'linear' | 'log';
  referenceCurveId?: string;
  inflationAssumption?: number; // % e.g. 2.2%
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  type: 'PARALLEL' | 'STEEPENER' | 'FLATTENER' | 'BULL_STEEPENER' | 'BEAR_STEEPENER' | 'BULL_FLATTENER' | 'BEAR_FLATTENER' | 'BUTTERFLY' | 'CUSTOM';
  parallelShiftBps: number;
  slopeTiltBps: number;       // Short vs Long tilt
  bellyShiftBps: number;      // 5Y hump shock
  customShocks?: { [tenor: string]: number }; // bps per tenor
  color: string;
}

export interface FixedIncomeMetrics {
  maturity: number;
  yield: number;
  zeroRate: number;
  parRate: number;
  forwardRate1Y: number;
  instantaneousForward: number;
  discountFactor: number;
  bondPrice100: number;
  macaulayDuration: number;
  modifiedDuration: number;
  convexity: number;
  dv01: number; // DV01 per $100k notional
  keyRateDurations: { [tenor: string]: number };
}

export interface PcaResult {
  explainedVariance: number[]; // e.g. [0.88, 0.09, 0.02]
  cumulativeVariance: number[];
  eigenvalues: number[];
  tenors: string[];
  maturities: number[];
  loadings: {
    pc1: number[]; // Level
    pc2: number[]; // Slope
    pc3: number[]; // Curvature
  };
  historicalFactorScores: {
    date: string;
    pc1: number;
    pc2: number;
    pc3: number;
  }[];
  meanCurve: number[];
}

export interface TimeSeriesCurvePoint {
  date: string;
  timestamp: number;
  yields: { [tenor: string]: number }; // Tenor -> Yield
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  curveId: string;
  details: string;
  version: string;
}
