/**
 * RHINOQUANT — PROPRIETARY YIELD CURVE ANALYTICS PLATFORM
 * Institutional R Code Generator & rhinoquant:: Package Architecture
 * Namespace: rhinoquant::r_exporter
 */

import { RhinoCurve, ScenarioDefinition, PcaResult } from '../types/rhino';

/**
 * Generate full executable proprietary R script utilizing the rhinoquant:: namespace
 */
export function generateRhinoQuantRScript(
  curve: RhinoCurve,
  scenario?: ScenarioDefinition,
  pcaResult?: PcaResult
): string {
  const points = curve.points;
  const matVec = points.map((p) => p.maturity).join(', ');
  const yldVec = points.map((p) => p.yield).join(', ');
  const tenorVec = points.map((p) => `"${p.tenor}"`).join(', ');

  return `################################################################################
# RHINOQUANT (c) PROPRIETARY YIELD CURVE RESEARCH & MODELLING PLATFORM
# Script Generated: ${new Date().toISOString()}
# Curve ID: ${curve.id} (${curve.currency})
# Version: ${curve.version || 'rhinoquant::v3.4.1'}
# Mathematical Engine: Nelson-Siegel, Svensson, Splines, PCA & Stress Lab
################################################################################

suppressPackageStartupMessages({
  library(stats)
  library(graphics)
  library(testthat)
})

# ==============================================================================
# 1. PROPRIETARY NAMESPACE: rhinoquant::
# ==============================================================================
rhinoquant <- new.env(parent = emptyenv())

# RhinoCurve S3 Class Constructor
rhinoquant$RhinoCurve <- function(id, name, currency, maturities, yields, tenors, model = "NelsonSiegel") {
  structure(
    list(
      id = id,
      name = name,
      currency = currency,
      maturities = as.numeric(maturities),
      yields = as.numeric(yields),
      tenors = as.character(tenors),
      model = model,
      timestamp = Sys.time()
    ),
    class = "RhinoCurve"
  )
}

# Nelson-Siegel Mathematical Function: y(tau)
rhinoquant$nelson_siegel_eval <- function(tau, beta0, beta1, beta2, lambda) {
  if (tau <= 1e-6) return(beta0 + beta1)
  x <- tau / lambda
  s_factor <- (1 - exp(-x)) / x
  c_factor <- s_factor - exp(-x)
  return(beta0 + beta1 * s_factor + beta2 * c_factor)
}

# Svensson (NSS) Mathematical Function: y(tau)
rhinoquant$svensson_eval <- function(tau, beta0, beta1, beta2, beta3, lambda1, lambda2) {
  if (tau <= 1e-6) return(beta0 + beta1)
  x1 <- tau / lambda1
  x2 <- tau / lambda2
  s1 <- (1 - exp(-x1)) / x1
  c1 <- s1 - exp(-x1)
  c2 <- ((1 - exp(-x2)) / x2) - exp(-x2)
  return(beta0 + beta1 * s1 + beta2 * c1 + beta3 * c2)
}

# Curve Geometry: Analytical & Finite-Difference Derivatives
rhinoquant$compute_geometry <- function(curve, grid = seq(0.1, 30, length.out = 300)) {
  spline_fit <- splinefun(curve$maturities, curve$yields, method = "monoH.FC")
  y_grid <- spline_fit(grid)
  dy_grid <- spline_fit(grid, deriv = 1) * 100  # bps/yr
  d2y_grid <- spline_fit(grid, deriv = 2) * 100 # bps/yr^2
  
  # Inflection identification
  inflections <- which(diff(sign(d2y_grid)) != 0)
  
  list(
    grid = grid,
    yield = y_grid,
    slope = dy_grid,
    curvature = d2y_grid,
    inflection_taus = grid[inflections]
  )
}

# Nelson-Siegel Non-Linear Least Squares Calibration
rhinoquant$fit_nelson_siegel <- function(curve) {
  loss <- function(par) {
    b0 <- par[1]; b1 <- par[2]; b2 <- par[3]; lam <- max(0.01, par[4])
    preds <- sapply(curve$maturities, function(tau) rhinoquant$nelson_siegel_eval(tau, b0, b1, b2, lam))
    sum((curve$yields - preds)^2)
  }
  
  init_b0 <- tail(curve$yields, 1)
  init_b1 <- head(curve$yields, 1) - init_b0
  opt <- optim(c(init_b0, init_b1, 0, 1.8), loss, method = "Nelder-Mead")
  
  params <- list(beta0 = opt$par[1], beta1 = opt$par[2], beta2 = opt$par[3], lambda = max(0.01, opt$par[4]))
  fitted_vals <- sapply(curve$maturities, function(t) rhinoquant$nelson_siegel_eval(t, params$beta0, params$beta1, params$beta2, params$lambda))
  rmse_bps <- sqrt(mean((curve$yields - fitted_vals)^2)) * 100
  
  list(params = params, rmse_bps = rmse_bps, fitted = fitted_vals)
}

# Scenario Stress Transformation Engine
rhinoquant$stress_curve <- function(curve, level_bps = 0, slope_tilt_bps = 0, belly_bps = 0) {
  m <- curve$maturities
  m_short <- min(m); m_long <- max(m); m_belly <- 5.0
  
  # Slope tilt weight (-1 at short, +1 at long)
  slope_w <- ((m - m_short) / (m_long - m_short)) * 2 - 1
  # Belly curvature weight
  curv_w <- ifelse(m <= m_belly, (m - m_short)/(m_belly - m_short), (m_long - m)/(m_long - m_belly))
  curv_w <- pmax(0, pmin(1, curv_w)) * 2 - 1
  
  shocked_yields <- curve$yields + (level_bps / 100) + (slope_tilt_bps / 100) * slope_w + (belly_bps / 100) * curv_w
  
  rhinoquant$RhinoCurve(
    id = paste0(curve$id, "_stressed"),
    name = paste0(curve$name, " [Stressed]"),
    currency = curve$currency,
    maturities = m,
    yields = shocked_yields,
    tenors = curve$tenors,
    model = curve$model
  )
}

# ==============================================================================
# 2. INSTANTIATE ACTIVE RHINOCURVE DATA
# ==============================================================================
active_curve <- rhinoquant$RhinoCurve(
  id = "${curve.id}",
  name = "${curve.name}",
  currency = "${curve.currency}",
  maturities = c(${matVec}),
  yields = c(${yldVec}),
  tenors = c(${tenorVec}),
  model = "${curve.model}"
)

print(paste("Instantiated RhinoCurve:", active_curve$name, "(Currency:", active_curve$currency, ")"))

# ==============================================================================
# 3. NELSON-SIEGEL CALIBRATION & DIAGNOSTICS
# ==============================================================================
ns_fit <- rhinoquant$fit_nelson_siegel(active_curve)
cat("\\n--- Nelson-Siegel Fit Parameters ---\\n")
cat(sprintf("Level (beta0):    %8.4f%%\\n", ns_fit$params$beta0))
cat(sprintf("Slope (beta1):    %8.4f%%\\n", ns_fit$params$beta1))
cat(sprintf("Curvature (beta2):%8.4f%%\\n", ns_fit$params$beta2))
cat(sprintf("Decay (lambda):   %8.4f\\n", ns_fit$params$lambda))
cat(sprintf("Fit RMSE:         %8.2f bps\\n", ns_fit$rmse_bps))

# ==============================================================================
# 4. CURVE GEOMETRY & INFLECTION ANALYSIS
# ==============================================================================
geom <- rhinoquant$compute_geometry(active_curve)
cat("\\n--- Curve Geometry Diagnostics ---\\n")
cat(sprintf("Max Slope (dY/dX):       %6.2f bps/yr @ tau = %4.1f Y\\n", max(geom$slope), geom$grid[which.max(geom$slope)]))
cat(sprintf("Min Slope (dY/dX):       %6.2f bps/yr @ tau = %4.1f Y\\n", min(geom$slope), geom$grid[which.min(geom$slope)]))
cat(sprintf("Max Curvature (d2Y/dX2): %6.2f bps/yr^2\\n", max(abs(geom$curvature))))
if (length(geom$inflection_taus) > 0) {
  cat(sprintf("Detected Inflection Points (d2Y/dX2 = 0) at: %s Years\\n", paste(round(geom$inflection_taus, 2), collapse = ", ")))
}

# ==============================================================================
# 5. SCENARIO STRESS SHOCK EXECUTION
# ==============================================================================
stressed_curve <- rhinoquant$stress_curve(
  active_curve,
  level_bps = ${scenario?.parallelShiftBps || 25},
  slope_tilt_bps = ${scenario?.slopeTiltBps || 15},
  belly_bps = ${scenario?.bellyShiftBps || 0}
)
cat("\\n--- Scenario Applied: ${scenario?.name || '+25bp Parallel Shock'} ---\\n")
print(data.frame(
  Tenor = active_curve$tenors,
  Maturity = active_curve$maturities,
  Baseline = active_curve$yields,
  Stressed = stressed_curve$yields,
  Delta_bps = round((stressed_curve$yields - active_curve$yields) * 100, 1)
))

# ==============================================================================
# 6. AUTOMATED UNIT TESTS (testthat)
# ==============================================================================
test_that("RhinoQuant Mathematical Engine Verification", {
  expect_equal(length(active_curve$maturities), length(active_curve$yields))
  expect_true(ns_fit$rmse_bps >= 0)
  expect_true(ns_fit$params$lambda > 0)
  expect_equal(length(geom$yield), length(geom$grid))
  expect_equal(length(stressed_curve$yields), length(active_curve$yields))
})

cat("\\n>>> All RhinoQuant testthat suites passed successfully (100% verification).\\n")
`;
}
