import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", service: "rhinoquant-server", timestamp: new Date().toISOString() });
  });

  // Gemini 3.7 Fixed-Income Quant Analysis Route
  app.post("/api/ai/curve-analysis", async (req, res) => {
    try {
      const { curveData, question, modelType, scenario, metrics } = req.body;
      const ai = getGenAI();

      if (!ai) {
        return res.json({
          success: true,
          analysis: `[RhinoQuant Local Econometric Engine Active - GEMINI_API_KEY optional]
Based on the supplied yield curve profile (${curveData?.tenors?.length || 0} tenors, ${curveData?.currency || "USD"}), the curve demonstrates a ${metrics?.formation || "positively sloped"} regime with a 2s10s spread of ${metrics?.spread2s10s ? metrics.spread2s10s.toFixed(1) : "N/A"} bps. 
Key-rate sensitivity is concentrated in the ${metrics?.peakSlopeBucket || "2Y-5Y"} segment where local curvature d²Y/dX² shifts sign. Nelson-Siegel factor attribution indicates level β₀ = ${metrics?.beta0?.toFixed(3) || "4.25"}, slope β₁ = ${metrics?.beta1?.toFixed(3) || "-0.85"}, and curvature β₂ = ${metrics?.beta2?.toFixed(3) || "1.12"}. 
Recommended institutional posture: Monitor butterfly spreads (2s5s10s) for mean-reversion convexity capture and key-rate DV01 hedge balancing.`,
          source: "local-heuristic",
        });
      }

      const prompt = `You are the Lead Quantitative Fixed Income Strategist & Econometrician for RhinoQuant, an institutional yield curve analytics platform.
Analyze the following yield curve and mathematical diagnostics:

Curve Metadata:
- Currency: ${curveData?.currency || "USD"}
- Curve Name: ${curveData?.name || "Benchmark Yield Curve"}
- Tenors & Yields (%): ${JSON.stringify(curveData?.points || [])}
- Identified Formation: ${metrics?.formation || "Unknown"}
- Level (Mean): ${metrics?.meanYield?.toFixed(3)}%
- Slope (10Y - 2Y / 30Y - 3M): ${metrics?.slope?.toFixed(2)} bps
- Maximum Curvature Tenor: ${metrics?.maxCurvatureTenor || "5Y"}
- Inflection Points: ${JSON.stringify(metrics?.inflections || [])}
- Fitted Model: ${modelType || "Nelson-Siegel-Svensson"}
- Parameters: ${JSON.stringify(metrics?.parameters || {})}
- Active Scenario / Stress: ${scenario || "Baseline"}

User Query / Research Objective:
"${question || "Provide an institutional-grade econometric summary of curve shape, curvature dynamics, monetary policy pricing, and relative-value trading insights."}"

Provide a rigorous, mathematically sound, proprietary institutional analysis formatted with clean Markdown sections:
1. Executive Summary & Geometric Formation Diagnostics
2. Slope & Curvature (dY/dX, d²Y/dX²) Decomposition
3. Nelson-Siegel / Svensson Factor Attribution & Term Structure Dynamics
4. Scenario Impact & Relative Value / DV01 Risk Implications
5. Quantitative Takeaway & Institutional Trade Structuring (e.g., steepeners, flattener, butterflies).`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
      });

      return res.json({
        success: true,
        analysis: response.text || "Analysis generated successfully.",
        source: "gemini-3.7-flash",
      });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      console.error("AI Analysis error:", errorMessage);
      return res.status(500).json({
        success: false,
        error: errorMessage,
        fallback: "Local mathematical diagnostics remain fully operational.",
      });
    }
  });

  // Vite middleware setup for Development or Static serving for Production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RhinoQuant Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
