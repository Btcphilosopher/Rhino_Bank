import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-loaded Gemini AI client to prevent startup crashes if key is missing
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY environment variable is not defined. Briefing generation will use synthetic economic briefs.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// REST API for Economic Briefing Generation
app.post("/api/gemini/briefing", async (req, res) => {
  try {
    const {
      framework,
      scenarioName,
      scenarioDescription,
      selectedMetrics,
      econometricsSummary
    } = req.body;

    const ai = getGeminiClient();
    if (!ai) {
      // Return beautiful fallback report
      const report = `### Fallback Executive Briefing (Offline Mode)
      
*Note: This report is generated offline as the platform API key was not detected. For full real-time AI capabilities, configure your key in AI Studio Secrets.*

**Economic Assessment of ${scenarioName || "Baseline"} Scenario**
The banking system is currently modeled using the **${framework || "Endogenous Money"}** framework. This perspective highlights that commercial bank lending is the primary driver of broader monetary aggregate expansion, as loans create deposits.

**Key Findings:**
1. **Lending Activity:** Average lending growth is sustained, driven by business and mortgage refinancing. Under the ${scenarioName} scenario, this trajectory is expected to adjust dynamically over the next 24 months.
2. **Deposit and Funding Dynamics:** Retail deposits remain the stable bedrock of banking liabilities, although wholesale funding costs are under upward pressure given the macroeconomic policy rate landscape.
3. **Econometric Projections:** Vector Autoregression (VAR) analysis suggests that changes in the policy rate transmit to deposit pricing with a lag of 2 to 3 months, while lending rates are adjusted more rapidly.

**Executive Recommendation:**
Treasury and structured finance teams should prioritize liquidity preservation and funding diversification. Mitigating net interest margin compression is paramount given the high-volatility structural regime identified in the Yorkshire regional comparisons.`;
      
      return res.json({ briefing: report });
    }

    const systemPrompt = `You are an expert monetary economist, central banking researcher, and executive director of Treasury at Rhino Bank.
You write professional, institutional-quality monetary and economic intelligence briefing notes.
Your tone is objective, formal, academically rigorous, and authoritative (modeled after the Bank of England, Federal Reserve, and Bank of International Settlements).
Do not use hyperbole, marketing words, or exclamation marks. Avoid words like "supercharge", "empower", "revolutionary", or "unprecedented".
Structure your briefings using elegant Markdown headers. Reference Yorkshire regional insights where appropriate.`;

    const prompt = `Rhino Bank Executive Monetary Intelligence Briefing.
Analysis Parameters:
- Monetary Modelling Framework: ${framework || "Endogenous Money Framework"}
- Current Macroeconomic Scenario: ${scenarioName || "Baseline"}
- Scenario Description: ${scenarioDescription || "Standard baseline development under current macroeconomic forecast"}
- Key Selected Metrics under Review: ${JSON.stringify(selectedMetrics || {})}
- Econometric Modeling Context (VAR, PCA, Decomposition): ${JSON.stringify(econometricsSummary || {})}

Write a cohesive, detailed Executive Briefing of approximately 350-500 words analyzing the banking sector under these conditions. Include:
1. **Macro-Monetary Overview**: Economic assessment based on the chosen "${framework}".
2. **Credit & Liquidity Transmission**: How lending expansion, deposit growth, and the policy rate interact under the "${scenarioName}" scenario.
3. **Econometric and Statistical Insights**: Interpret the econometric indicators (VAR lag, PCA factors, and cointegration).
4. **Strategic Treasury Recommendations**: Actionable, conservative risk-management guidance for Rhino Bank's executive committee.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.2
      }
    });

    res.json({ briefing: response.text });
  } catch (error: any) {
    console.error("Gemini briefing error:", error);
    res.status(500).json({ error: "Failed to generate briefing", details: error.message });
  }
});

// Configure Vite or Static files depending on NODE_ENV
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
