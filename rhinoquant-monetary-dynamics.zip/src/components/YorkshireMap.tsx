/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { REGIONAL_INDICATORS } from '../data';
import { RegionalIndicator } from '../types';
import { MapPin, Info, TrendingUp, DollarSign, BarChart3, AlertTriangle } from 'lucide-react';

interface YorkshireMapProps {
  onRegionSelect?: (region: RegionalIndicator) => void;
  selectedRegionId?: string;
}

export default function YorkshireMap({ onRegionSelect, selectedRegionId }: YorkshireMapProps) {
  // Map visualization metric modes
  const [metricMode, setMetricMode] = useState<'lending' | 'deposits' | 'growth' | 'volatility'>('lending');
  const [hoveredRegion, setHoveredRegion] = useState<RegionalIndicator | null>(null);

  // Helper to resolve color density based on selected metric
  const getRegionColor = (region: RegionalIndicator, isActive: boolean) => {
    if (isActive) return 'fill-[#B87333] stroke-[#D4D1CA] stroke-2'; // Active Copper highlight

    let factor = 0.5;
    if (metricMode === 'lending') {
      // Scale based on lending size ($221M to $2.4B)
      factor = Math.min(1, Math.max(0.1, region.totalLending / 2500));
      return `fill-[rgba(184,115,51,${factor.toFixed(2)})] stroke-[#222222] hover:fill-[#B87333] transition-all`;
    } else if (metricMode === 'deposits') {
      factor = Math.min(1, Math.max(0.1, region.totalDeposits / 2800));
      return `fill-[rgba(94,131,192,${factor.toFixed(2)})] stroke-[#222222] hover:fill-[#5E83C0] transition-all`; // Blue
    } else if (metricMode === 'growth') {
      factor = Math.min(1, Math.max(0.1, (region.growth2026 - 4.5) / 2));
      return `fill-[rgba(138,154,134,${factor.toFixed(2)})] stroke-[#222222] hover:fill-[#8A9A86] transition-all`; // Sage
    } else {
      factor = Math.min(1, Math.max(0.1, (region.volatility - 1.2) / 1.5));
      return `fill-[rgba(178,34,34,${factor.toFixed(2)})] stroke-[#222222] hover:fill-[#B22222] transition-all`; // Madder Red
    }
  };

  // Coordinates and dimensions for stylized Yorkshire counties vector paths (relative to 500x420)
  const mapRegions = [
    {
      id: 'north_york',
      path: 'M 100 50 L 320 30 L 410 110 L 310 190 L 190 190 L 100 120 Z',
      labelX: 230,
      labelY: 100,
      data: REGIONAL_INDICATORS.find(r => r.id === 'north_york')!
    },
    {
      id: 'west_york',
      path: 'M 100 120 L 190 190 L 180 270 L 80 250 L 70 170 Z',
      labelX: 130,
      labelY: 200,
      data: REGIONAL_INDICATORS.find(r => r.id === 'west_york')!
    },
    {
      id: 'south_york',
      path: 'M 80 250 L 180 270 L 220 340 L 140 350 L 85 300 Z',
      labelX: 140,
      labelY: 300,
      data: REGIONAL_INDICATORS.find(r => r.id === 'south_york')!
    },
    {
      id: 'east_riding',
      path: 'M 310 190 L 420 160 L 460 210 L 360 290 L 270 240 L 210 190 Z',
      labelX: 330,
      labelY: 220,
      data: REGIONAL_INDICATORS.find(r => r.id === 'east_riding')!
    },
    {
      id: 'york_hum',
      path: 'M 270 240 L 360 290 L 390 350 L 290 355 L 220 340 L 180 270 Z',
      labelX: 280,
      labelY: 295,
      data: REGIONAL_INDICATORS.find(r => r.id === 'york_hum')!
    }
  ];

  return (
    <div className="bg-[#1A1A1A] border border-[#222222] rounded-sm p-6 relative flex flex-col h-full" id="yorkshire-gis-panel">
      {/* GIS Control Panel */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#222222] pb-4 mb-4">
        <div>
          <h3 className="font-serif text-lg font-bold text-[#D4D1CA] flex items-center gap-2">
            <MapPin className="w-5 h-5 text-[#B87333]" /> Yorkshire GIS Spatial Analytics
          </h3>
          <p className="text-xs text-[#8A9086] font-mono mt-0.5">County distribution of balance sheets & monetary flows</p>
        </div>
        <div className="flex flex-wrap gap-1 bg-[#0A0A0A] p-1 rounded border border-[#222222]">
          <button
            onClick={() => setMetricMode('lending')}
            className={`px-3 py-1 text-xs font-mono rounded-sm transition-all ${metricMode === 'lending' ? 'bg-[#B87333] text-[#0A0A0A] font-semibold' : 'text-[#8A9086] hover:text-[#D4D1CA]'}`}
            id="gis-btn-lending"
          >
            Lending
          </button>
          <button
            onClick={() => setMetricMode('deposits')}
            className={`px-3 py-1 text-xs font-mono rounded-sm transition-all ${metricMode === 'deposits' ? 'bg-[#5E83C0] text-[#0A0A0A] font-semibold' : 'text-[#8A9086] hover:text-[#D4D1CA]'}`}
            id="gis-btn-deposits"
          >
            Deposits
          </button>
          <button
            onClick={() => setMetricMode('growth')}
            className={`px-3 py-1 text-xs font-mono rounded-sm transition-all ${metricMode === 'growth' ? 'bg-[#8A9A86] text-[#0A0A0A] font-semibold' : 'text-[#8A9086] hover:text-[#D4D1CA]'}`}
            id="gis-btn-growth"
          >
            Growth
          </button>
          <button
            onClick={() => setMetricMode('volatility')}
            className={`px-3 py-1 text-xs font-mono rounded-sm transition-all ${metricMode === 'volatility' ? 'bg-[#B22222] text-[#D4D1CA] font-semibold' : 'text-[#8A9086] hover:text-[#D4D1CA]'}`}
            id="gis-btn-volatility"
          >
            Volatility
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-center flex-1">
        {/* SVG Map Canvas */}
        <div className="lg:col-span-3 flex justify-center relative bg-[#0A0A0A] p-4 rounded-sm border border-[#222222]">
          <svg 
            viewBox="0 0 500 400" 
            className="w-full max-w-[420px] h-auto cursor-pointer filter drop-shadow-xl select-none"
            id="yorkshire-svg"
          >
            {/* Grid references for central bank research appearance */}
            <g stroke="#1F2126" strokeWidth="0.5" strokeDasharray="3,3">
              <line x1="50" y1="0" x2="50" y2="400" />
              <line x1="150" y1="0" x2="150" y2="400" />
              <line x1="250" y1="0" x2="250" y2="400" />
              <line x1="350" y1="0" x2="350" y2="400" />
              <line x1="450" y1="0" x2="450" y2="400" />
              <line x1="0" y1="100" x2="500" y2="100" />
              <line x1="0" y1="200" x2="500" y2="200" />
              <line x1="0" y1="300" x2="500" y2="300" />
            </g>

            {/* County Paths */}
            {mapRegions.map((region) => {
              if (!region.data) return null;
              const isActive = selectedRegionId === region.data.id;
              return (
                <g key={region.id}>
                  <path
                    d={region.path}
                    className={`${getRegionColor(region.data, isActive)} transition-all duration-200`}
                    onMouseEnter={() => setHoveredRegion(region.data)}
                    onMouseLeave={() => setHoveredRegion(null)}
                    onClick={() => onRegionSelect?.(region.data)}
                  />
                  {/* County labels */}
                  <text
                    x={region.labelX}
                    y={region.labelY}
                    textAnchor="middle"
                    className="fill-[#D4D1CA] text-[10px] font-mono font-semibold pointer-events-none drop-shadow-lg"
                  >
                    {region.data.name.split(' ')[0]}
                  </text>
                </g>
              );
            })}
          </svg>

          {/* Quick HUD Hover Tooltip inside map */}
          {hoveredRegion && (
            <div className="absolute top-4 left-4 bg-[#1A1A1A] border border-[#B87333] p-3 rounded-sm shadow-2xl z-20 w-48 font-mono">
              <p className="text-xs font-bold text-[#D4D1CA] mb-1 font-serif">{hoveredRegion.name}</p>
              <div className="space-y-0.5 text-[10px]">
                <p className="text-[#8A9086] flex justify-between">Lending: <span className="text-[#D4D1CA]">£{hoveredRegion.totalLending}M</span></p>
                <p className="text-[#8A9086] flex justify-between">Deposits: <span className="text-[#D4D1CA]">£{hoveredRegion.totalDeposits}M</span></p>
                <p className="text-[#8A9086] flex justify-between">Growth: <span className="text-emerald-500">+{hoveredRegion.growth2026}%</span></p>
                <p className="text-[#8A9086] flex justify-between">Volatility: <span className="text-amber-500">{hoveredRegion.volatility}σ</span></p>
              </div>
            </div>
          )}
        </div>

        {/* Selected County Detail / Economic Briefing */}
        <div className="lg:col-span-2 flex flex-col justify-between h-full space-y-4">
          {(() => {
            const region = REGIONAL_INDICATORS.find(r => r.id === (selectedRegionId || 'west_york')) || REGIONAL_INDICATORS[0];
            return (
              <div className="bg-[#0A0A0A] border border-[#222222] p-5 rounded-sm flex flex-col justify-between h-full space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-[10px] uppercase text-[#B87333] tracking-widest font-semibold">SELECTED REGION</span>
                    <span className="text-xs bg-[#1A1A1A] text-[#8A9086] px-2 py-0.5 font-mono rounded-sm">GIS HU-2</span>
                  </div>
                  <h4 className="font-serif text-xl font-bold text-[#D4D1CA] tracking-tight">{region.name}</h4>
                  <p className="text-xs text-[#8A9086] mt-1 font-serif leading-relaxed">
                    Provides key support to regional heavy industries, manufacturing infrastructure, and commercial property investment inside Yorkshire.
                  </p>
                </div>

                {/* Regional KPIs Grid */}
                <div className="grid grid-cols-2 gap-3 font-mono my-3">
                  <div className="bg-[#1A1A1A] p-3 rounded-sm border border-[#222222]">
                    <span className="text-[9px] text-[#8A9086] block">TOTAL REGIONAL LENDING</span>
                    <span className="text-sm font-bold text-[#B87333] block mt-0.5">£{region.totalLending.toFixed(1)}M</span>
                  </div>
                  <div className="bg-[#1A1A1A] p-3 rounded-sm border border-[#222222]">
                    <span className="text-[9px] text-[#8A9086] block">TOTAL REGIONAL DEPOSITS</span>
                    <span className="text-sm font-bold text-[#5E83C0] block mt-0.5">£{region.totalDeposits.toFixed(1)}M</span>
                  </div>
                  <div className="bg-[#1A1A1A] p-3 rounded-sm border border-[#222222]">
                    <span className="text-[9px] text-[#8A9086] block">MORTGAGE SECTOR SHARE</span>
                    <span className="text-sm font-bold text-[#8A9A86] block mt-0.5">{region.mortgageShare}%</span>
                  </div>
                  <div className="bg-[#1A1A1A] p-3 rounded-sm border border-[#222222]">
                    <span className="text-[9px] text-[#8A9086] block">COMMERCIAL DENSITY</span>
                    <span className="text-sm font-bold text-amber-500 block mt-0.5">{region.commercialDensity}%</span>
                  </div>
                </div>

                {/* Footnote context */}
                <div className="bg-[#1A1A1A] p-3 rounded-sm border-l border-[#B87333] text-[11px] text-[#8A9086] leading-relaxed">
                  <div className="flex gap-2 items-start">
                    <Info className="w-4 h-4 text-[#B87333] shrink-0 mt-0.5" />
                    <span>
                      The regional credit multiplier is strictly constrained by corporate deposit availability. Outflows from {region.name.split(' ')[0]} to London clearing hubs can result in regional margin compression.
                    </span>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
}
