/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowUpRight, ArrowDownRight, TrendingUp } from 'lucide-react';

interface MetricCardProps {
  id: string;
  title: string;
  value: string | number;
  subtext?: string;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  sparklineData?: number[];
  colorTheme?: 'copper' | 'navy' | 'sage' | 'crimson' | 'neutral';
}

export default function MetricCard({
  id,
  title,
  value,
  subtext,
  trend,
  trendValue,
  sparklineData = [],
  colorTheme = 'neutral'
}: MetricCardProps) {
  // Map color themes
  const themeClasses = {
    copper: {
      text: 'text-[#B87333]',
      border: 'border-[#2A2A2A] border-t-2 border-t-[#B87333]',
      bg: 'bg-[#1A1A1A]'
    },
    navy: {
      text: 'text-[#5E83C0]',
      border: 'border-[#2A2A2A] border-t-2 border-t-[#5E83C0]',
      bg: 'bg-[#1A1A1A]'
    },
    sage: {
      text: 'text-[#8A9A86]',
      border: 'border-[#2A2A2A] border-t-2 border-t-[#8A9A86]',
      bg: 'bg-[#1A1A1A]'
    },
    crimson: {
      text: 'text-[#B22222]',
      border: 'border-[#2A2A2A] border-t-2 border-t-[#B22222]',
      bg: 'bg-[#1A1A1A]'
    },
    neutral: {
      text: 'text-[#D4D1CA]',
      border: 'border-[#2A2A2A] border-t-2 border-t-[#D4D1CA]',
      bg: 'bg-[#1A1A1A]'
    }
  };

  const selectedTheme = themeClasses[colorTheme];

  // Draw micro-sparkline path
  const drawSparkline = () => {
    if (sparklineData.length < 2) return '';
    const width = 100;
    const height = 24;
    const min = Math.min(...sparklineData);
    const max = Math.max(...sparklineData);
    const range = max - min || 1.0;

    return sparklineData
      .map((val, idx) => {
        const x = (idx / (sparklineData.length - 1)) * width;
        const y = height - ((val - min) / range) * height;
        return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  };

  return (
    <div 
      id={`metric-card-${id}`}
      className={`border rounded-lg p-5 flex flex-col justify-between transition-all duration-150 ${selectedTheme.bg} ${selectedTheme.border}`}
    >
      <div className="flex items-start justify-between">
        <span className="text-xs font-mono font-semibold tracking-wider text-[#8A9086] uppercase block">
          {title}
        </span>
        {trend && (
          <div className={`flex items-center text-xs font-mono px-2 py-0.5 rounded ${
            trend === 'up' 
              ? 'text-emerald-500 bg-[rgba(16,185,129,0.08)]' 
              : trend === 'down' 
              ? 'text-rose-500 bg-[rgba(244,63,94,0.08)]' 
              : 'text-[#8A9086] bg-[#1E2024]'
          }`}>
            {trend === 'up' ? <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" /> : <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />}
            {trendValue}
          </div>
        )}
      </div>

      <div className="mt-4 flex items-baseline justify-between">
        <div className="flex flex-col">
          <span className={`text-2xl font-serif font-bold tracking-tight ${selectedTheme.text}`} id={`metric-value-${id}`}>
            {value}
          </span>
          {subtext && (
            <span className="text-xs font-mono text-[#8A9086] mt-1" id={`metric-subtext-${id}`}>
              {subtext}
            </span>
          )}
        </div>

        {sparklineData.length > 1 && (
          <svg className="w-20 h-6 shrink-0" viewBox="0 0 100 24">
            <path
              d={drawSparkline()}
              fill="none"
              stroke={colorTheme === 'copper' ? '#B87333' : colorTheme === 'navy' ? '#5E83C0' : colorTheme === 'sage' ? '#8A9A86' : colorTheme === 'crimson' ? '#B22222' : '#D4D1CA'}
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </div>
    </div>
  );
}
