/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Coins, 
  Scale, 
  Layers, 
  ShieldCheck, 
  Percent, 
  Binary, 
  LineChart, 
  FlaskConical, 
  Map, 
  FileText,
  ChevronLeft,
  ChevronRight,
  Sparkles
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  const menuItems = [
    { id: 'overview', name: 'Executive Overview', icon: LayoutDashboard },
    { id: 'monetary', name: 'Monetary Dashboard', icon: TrendingUp },
    { id: 'credit', name: 'Credit Observatory', icon: Coins },
    { id: 'balance_sheet', name: 'Balance Sheet', icon: Scale },
    { id: 'aggregates', name: 'Monetary Aggregates', icon: Layers },
    { id: 'funding', name: 'Funding Analytics', icon: ShieldCheck },
    { id: 'interest_rates', name: 'Interest Rate Analytics', icon: Percent },
    { id: 'econometrics', name: 'Econometric Analysis', icon: Binary },
    { id: 'forecasts', name: 'Forecast Centre', icon: LineChart },
    { id: 'scenarios', name: 'Scenario Laboratory', icon: FlaskConical },
    { id: 'regions', name: 'Regional GIS Analytics', icon: Map },
    { id: 'reports', name: 'Reports & briefings', icon: FileText },
  ];

  return (
    <div 
      className={`relative h-screen bg-[#0F0F0F] border-r border-[#222222] flex flex-col justify-between transition-all duration-300 ${
        collapsed ? 'w-20' : 'w-72'
      }`}
      id="main-sidebar"
    >
      {/* Title / Brand Block */}
      <div className="p-6 border-b border-[#222222] flex items-center justify-between">
        {!collapsed ? (
          <div className="flex flex-col">
            <span className="font-mono text-[10px] tracking-[0.2em] text-[#B87333] font-bold uppercase">
              RHINO<span className="text-[#D4D1CA]">QUANT</span>
            </span>
            <span className="text-xl font-bold font-serif tracking-tight text-[#D4D1CA] mt-1">
              Monetary Dynamics
            </span>
          </div>
        ) : (
          <div className="w-full flex justify-center">
            <span className="font-serif text-2xl font-bold text-[#B87333]">R</span>
          </div>
        )}
      </div>

      {/* Menu Options */}
      <div className="flex-1 py-6 overflow-y-auto space-y-1 px-3">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`sidebar-tab-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center p-3 py-3 rounded text-left transition-all duration-150 group relative ${
                isActive 
                  ? 'bg-[#1A1A1A] text-[#D4D1CA] font-medium border-l-2 border-[#B87333]' 
                  : 'text-[#8A9086] hover:bg-[#151515] hover:text-[#D4D1CA]'
              }`}
            >
              <IconComponent 
                className={`w-4 h-4 transition-transform duration-150 group-hover:scale-105 ${
                  isActive ? 'text-[#B87333]' : 'text-[#8A9086]'
                } ${collapsed ? 'mx-auto' : 'mr-3.5'}`} 
              />
              {!collapsed && (
                <span className="text-xs uppercase tracking-wider font-mono">
                  {item.name}
                </span>
              )}
              {/* Tooltip for collapsed view */}
              {collapsed && (
                <div className="absolute left-full ml-4 px-2 py-1 bg-[#1A1A1A] border border-[#222222] text-[#D4D1CA] text-xs font-mono rounded opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity duration-150 z-50 whitespace-nowrap shadow-xl">
                  {item.name}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Footer Branding and Collapse toggle */}
      <div className="p-4 border-t border-[#222222] bg-[#0A0A0A] flex items-center justify-between">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 rounded-full bg-[#B87333] animate-pulse" />
            <span className="text-[10px] font-mono text-[#8A9086]">
              R-Engine: Active
            </span>
          </div>
        )}
        <button 
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded hover:bg-[#1A1A1A] text-[#8A9086] hover:text-[#D4D1CA] mx-auto"
          id="sidebar-toggle-btn"
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
}
