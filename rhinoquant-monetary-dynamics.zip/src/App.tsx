/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import MetricCard from './components/MetricCard';
import YorkshireMap from './components/YorkshireMap';
import { HISTORICAL_DATA, SCENARIOS, REGIONAL_INDICATORS } from './data';
import { ModellingFramework, ForecastingMethod, RegionalIndicator } from './types';
import { 
  fitRegression, 
  performPCA, 
  fitVAR, 
  decomposeTimeSeries, 
  performCointegration 
} from './modeling/econometrics';
import { generateForecast, getStockFlowConsistentAccounting } from './modeling/forecasting';

// Recharts components for statistical visual analytics
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ScatterChart,
  Scatter
} from 'recharts';

// Import markdown rendering safely for Gemini reports
import Markdown from 'react-markdown';
import { 
  Briefcase, 
  Database, 
  HelpCircle, 
  Layers, 
  Percent, 
  TrendingUp, 
  FileText, 
  RefreshCw, 
  Sparkles, 
  MapPin, 
  CheckCircle,
  Download,
  BookOpen
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  
  // Modelling parameters
  const [framework, setFramework] = useState<ModellingFramework>('endogenous');
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('baseline');
  
  // Forecast state
  const [forecastMethod, setForecastMethod] = useState<ForecastingMethod>('arima');
  const [forecastTarget, setForecastTarget] = useState<string>('lendingMortgage');
  
  // Regional GIS state
  const [selectedRegionId, setSelectedRegionId] = useState<string>('west_york');

  // Interactive rate shifts
  const [rateShift, setRateShift] = useState<number>(0.0);
  const [lendingMultiplier, setLendingMultiplier] = useState<number>(1.0);

  // Economic Commentary Gemini state
  const [geminiBriefing, setGeminiBriefing] = useState<string>('');
  const [isBriefingLoading, setIsBriefingLoading] = useState<boolean>(false);

  // Sync parameters when scenario is selected
  const activeScenario = useMemo(() => {
    const sc = SCENARIOS.find(s => s.id === selectedScenarioId) || SCENARIOS[0];
    return sc;
  }, [selectedScenarioId]);

  useEffect(() => {
    setRateShift(activeScenario.policyRateShift);
    setLendingMultiplier(activeScenario.lendingMultiplier);
  }, [activeScenario]);

  // Apply scenario multiplier and shifts to the latest data point or selected time series
  const currentModifiedData = useMemo(() => {
    return HISTORICAL_DATA.map(pt => {
      const isPostShock = pt.date >= '2024-01'; // Apply shocks to recent history for simulation richness
      const mult = isPostShock ? lendingMultiplier : 1.0;
      const rShift = isPostShock ? rateShift : 0.0;
      
      return {
        ...pt,
        lendingMortgage: pt.lendingMortgage * mult,
        lendingCommercial: pt.lendingCommercial * mult,
        depositHousehold: pt.depositHousehold * (isPostShock ? activeScenario.depositMultiplier : 1.0),
        policyRate: Math.max(0.25, pt.policyRate + rShift),
        lendingRate: Math.max(0.5, pt.lendingRate + rShift * 0.9),
        depositRate: Math.max(0.1, pt.depositRate + rShift * 0.45)
      };
    });
  }, [lendingMultiplier, rateShift, activeScenario]);

  // Current balance-sheet SFC accounts
  const balanceSheetSFC = useMemo(() => {
    return getStockFlowConsistentAccounting(currentModifiedData, framework, lendingMultiplier, rateShift);
  }, [currentModifiedData, framework, lendingMultiplier, rateShift]);

  // Computed monetary aggregates (M0, M1, M2, M3, M4)
  const computedAggregates = useMemo(() => {
    return currentModifiedData.map(pt => {
      const reserves = pt.assetCash * 1.2; // cash reserves
      const m0 = reserves + 15.0; // cash reserves + currency
      const m1 = m0 + pt.depositHousehold * 0.6; // overnight retail
      const m2 = m1 + pt.depositHousehold * 0.4 + pt.depositCommercial * 0.3; // short-term
      const m3 = m2 + pt.depositCommercial * 0.7 + pt.depositWholesale * 0.4; // institutional
      const m4 = m3 + pt.depositWholesale * 0.6 + pt.liabilityBonds * 0.5; // broad money

      return {
        date: pt.date,
        m0: Number(m0.toFixed(1)),
        m1: Number(m1.toFixed(1)),
        m2: Number(m2.toFixed(1)),
        m3: Number(m3.toFixed(1)),
        m4: Number(m4.toFixed(1))
      };
    });
  }, [currentModifiedData]);

  // Core Econometrics Results (recalculated dynamically)
  const econometricsRegression = useMemo(() => {
    // Predict Broad Money (M4 approximation) from Policy Rate & Securities
    return fitRegression(currentModifiedData, 'depositHousehold', ['policyRate', 'assetSecurities']);
  }, [currentModifiedData]);

  const econometricsPCA = useMemo(() => {
    // PCA of interest rate dimensions
    return performPCA(currentModifiedData, ['policyRate', 'lendingRate', 'depositRate', 'yield10Y']);
  }, [currentModifiedData]);

  const econometricsVAR = useMemo(() => {
    return fitVAR(currentModifiedData);
  }, [currentModifiedData]);

  const econometricsDecomposition = useMemo(() => {
    return decomposeTimeSeries(currentModifiedData, 'lendingMortgage');
  }, [currentModifiedData]);

  const econometricsCointegration = useMemo(() => {
    return performCointegration(currentModifiedData);
  }, [currentModifiedData]);

  // 24-Month Projections
  const activeForecastSeries = useMemo(() => {
    return generateForecast(
      currentModifiedData, 
      forecastTarget as any, 
      forecastMethod, 
      lendingMultiplier, 
      rateShift
    );
  }, [currentModifiedData, forecastTarget, forecastMethod, lendingMultiplier, rateShift]);

  // Handler for Gemini economic briefing trigger
  const generateAIBriefing = async () => {
    setIsBriefingLoading(true);
    setGeminiBriefing('');
    try {
      const response = await fetch('/api/gemini/briefing', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          framework: framework === 'endogenous' ? 'Endogenous Money Framework' : framework === 'textbook' ? 'Textbook Reserve Multiplier' : 'Balance-Sheet Accounting',
          scenarioName: activeScenario.name,
          scenarioDescription: activeScenario.description,
          selectedMetrics: {
            policyRate: currentModifiedData[currentModifiedData.length - 1].policyRate.toFixed(2) + '%',
            lendingMortgage: '£' + currentModifiedData[currentModifiedData.length - 1].lendingMortgage.toFixed(1) + 'M',
            totalDeposits: '£' + (currentModifiedData[currentModifiedData.length - 1].depositHousehold + currentModifiedData[currentModifiedData.length - 1].depositCommercial).toFixed(1) + 'M',
            capitalAdequacyRatio: balanceSheetSFC.capitalAdequacyRatio + '%'
          },
          econometricsSummary: {
            varSelectedLags: econometricsVAR.selectedLags,
            cointegrationAdjustmentSpeed: econometricsCointegration.speedOfAdjustment,
            regressionRSquared: econometricsRegression[0]?.rSquared?.toFixed(3)
          }
        }),
      });
      const data = await response.json();
      if (data.briefing) {
        setGeminiBriefing(data.briefing);
      } else {
        setGeminiBriefing("Error: Briefing empty.");
      }
    } catch (err: any) {
      console.error(err);
      setGeminiBriefing("Briefing pipeline error: Ensure server is running and GEMINI_API_KEY is configured.");
    } finally {
      setIsBriefingLoading(false);
    }
  };

  // Generate synthetic report on first load
  useEffect(() => {
    if (activeTab === 'reports' && !geminiBriefing) {
      generateAIBriefing();
    }
  }, [activeTab]);

  // Handlers for exporting CSV
  const exportCSV = (data: any[], filename: string) => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + Object.keys(data[0]).join(",") + "\n"
      + data.map(e => Object.values(e).join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Quick KPIs derived from latest modified index
  const latestMetric = currentModifiedData[currentModifiedData.length - 1];
  const priorMetric = currentModifiedData[currentModifiedData.length - 2];

  return (
    <div className="flex h-screen bg-[#121212] text-[#D4D1CA] font-serif overflow-hidden" id="app-root">
      {/* Sidebar Component */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Panel Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header / Economic Controls */}
        <header className="h-20 border-b border-[#222222] bg-[#0F0F0F] px-8 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-4">
            <span className="text-xs font-mono bg-[#1A1A1A] text-[#8A9086] px-2.5 py-1 rounded-sm border border-[#222222]">
              STATUS: <span className="text-[#B87333] font-bold">ONLINE</span>
            </span>
            <div className="flex items-center space-x-1.5 font-mono text-[10px] tracking-wider text-[#8A9086]">
              <span>ACTIVE SCHEMA:</span>
              <span className="text-[#B87333] font-semibold uppercase">{framework}</span>
            </div>
          </div>

          {/* Quick Scenario selector on header */}
          <div className="flex items-center space-x-3">
            <span className="font-mono text-[10px] tracking-wider text-[#8A9086]">MACRO SCENARIO:</span>
            <select
              value={selectedScenarioId}
              onChange={(e) => setSelectedScenarioId(e.target.value)}
              className="bg-[#1A1A1A] text-xs font-mono text-[#D4D1CA] border border-[#222222] px-3 py-1.5 rounded-sm focus:outline-none focus:border-[#B87333]"
              id="top-scenario-selector"
            >
              {SCENARIOS.map(sc => (
                <option key={sc.id} value={sc.id}>{sc.name}</option>
              ))}
            </select>
          </div>
        </header>

        {/* Dynamic Tab Body */}
        <main className="flex-1 overflow-y-auto p-8 space-y-6">
          
          {/* 1. EXECUTIVE OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6" id="overview-tab">
              {/* Context Block */}
              <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="max-w-2xl">
                  <h2 className="text-2xl font-bold font-serif text-[#D4D1CA] tracking-tight">Executive Monetary Assessment</h2>
                  <p className="text-sm text-[#8A9086] font-serif mt-2 leading-relaxed">
                    A comprehensive cockpit analyzing Rhino Bank's monetary landscape. Incorporate dynamic econometric transmission equations to forecast portfolio sustainability, policy rate spreads, and asset-liability margins.
                  </p>
                </div>
                {/* Framework Selector */}
                <div className="shrink-0 flex flex-col space-y-2 bg-[#0A0A0A] p-4 rounded-sm border border-[#222222] w-full md:w-64 font-mono text-xs">
                  <span className="text-[#8A9086] text-[10px] tracking-wider">MODELLING FRAMEWORK</span>
                  <div className="grid grid-cols-2 gap-1 mt-1">
                    <button
                      onClick={() => setFramework('endogenous')}
                      className={`px-2 py-1 rounded-sm text-[10px] transition-all ${framework === 'endogenous' ? 'bg-[#B87333] text-[#0A0A0A] font-bold' : 'bg-[#1A1A1A] text-[#8A9086]'}`}
                    >
                      Endogenous
                    </button>
                    <button
                      onClick={() => setFramework('textbook')}
                      className={`px-2 py-1 rounded-sm text-[10px] transition-all ${framework === 'textbook' ? 'bg-[#B87333] text-[#0A0A0A] font-bold' : 'bg-[#1A1A1A] text-[#8A9086]'}`}
                    >
                      Multiplier
                    </button>
                  </div>
                </div>
              </div>

              {/* KPI Scores Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <MetricCard
                  id="policy-rate"
                  title="Policy rate (BoE)"
                  value={`${latestMetric.policyRate.toFixed(2)}%`}
                  trend={latestMetric.policyRate > priorMetric.policyRate ? 'up' : latestMetric.policyRate < priorMetric.policyRate ? 'down' : 'neutral'}
                  trendValue={`${(latestMetric.policyRate - priorMetric.policyRate).toFixed(2)}%`}
                  sparklineData={currentModifiedData.slice(-10).map(d => d.policyRate)}
                  colorTheme="neutral"
                />
                <MetricCard
                  id="mortgage-credit"
                  title="Total Mortgage Credit"
                  value={`£${latestMetric.lendingMortgage.toFixed(1)}M`}
                  trend="up"
                  trendValue="+0.6% MoM"
                  sparklineData={currentModifiedData.slice(-10).map(d => d.lendingMortgage)}
                  colorTheme="copper"
                />
                <MetricCard
                  id="deposits"
                  title="Retail Deposits"
                  value={`£${(latestMetric.depositHousehold + latestMetric.depositCommercial).toFixed(1)}M`}
                  trend="up"
                  trendValue="+0.4% MoM"
                  sparklineData={currentModifiedData.slice(-10).map(d => d.depositHousehold)}
                  colorTheme="navy"
                />
                <MetricCard
                  id="capital-adequacy"
                  title="Capital Adequacy (CAR)"
                  value={`${balanceSheetSFC.capitalAdequacyRatio}%`}
                  trend="neutral"
                  trendValue="Basel III"
                  sparklineData={[12.1, 12.3, 12.5, 12.6, 12.8, Number(balanceSheetSFC.capitalAdequacyRatio)]}
                  colorTheme="sage"
                />
              </div>

              {/* Dual-Chart Editorial Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Lending vs Deposits */}
                <div className="lg:col-span-2 bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-serif text-lg font-bold text-[#D4D1CA]">Credit Creation & Deposit Trends</h3>
                      <p className="text-xs text-[#8A9086] font-mono mt-0.5">Historical and simulated portfolio tracking</p>
                    </div>
                  </div>
                  <div className="h-80 w-full" id="overview-chart">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={currentModifiedData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                        <XAxis dataKey="date" stroke="#8A9086" fontSize={10} tickLine={false} />
                        <YAxis stroke="#8A9086" fontSize={10} tickLine={false} domain={['auto', 'auto']} />
                        <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                        <Legend verticalAlign="top" height={36} iconType="circle" />
                        <Line type="monotone" dataKey="lendingMortgage" name="Mortgages" stroke="#B87333" strokeWidth={2} dot={false} />
                        <Line type="monotone" dataKey="lendingCommercial" name="Commercial Loans" stroke="#8A9A86" strokeWidth={2} dot={false} />
                        <Line type="monotone" dataKey="depositHousehold" name="Household Deposits" stroke="#5E83C0" strokeWidth={2} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* SFC Composition breakdown */}
                <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm flex flex-col justify-between">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-1">Balance Sheet Structure</h3>
                    <p className="text-xs text-[#8A9086] font-mono">Stock-flow accounts (Millions)</p>
                  </div>
                  <div className="space-y-4 my-4 font-mono text-xs">
                    {/* Assets */}
                    <div className="space-y-2">
                      <span className="text-[#8A9A86] font-semibold block">ASSETS</span>
                      <div className="flex justify-between border-b border-[#222222] pb-1">
                        <span>Loans Portfolio</span>
                        <span className="text-[#D4D1CA]">£{balanceSheetSFC.loans}M</span>
                      </div>
                      <div className="flex justify-between border-b border-[#222222] pb-1">
                        <span>Securities & Liquids</span>
                        <span className="text-[#D4D1CA]">£{balanceSheetSFC.securities}M</span>
                      </div>
                      <div className="flex justify-between font-bold text-[#D4D1CA] pt-1">
                        <span>Total Assets</span>
                        <span>£{balanceSheetSFC.totalAssets}M</span>
                      </div>
                    </div>
                    {/* Liabilities */}
                    <div className="space-y-2 pt-2">
                      <span className="text-[#B87333] font-semibold block">LIABILITIES & CAPITAL</span>
                      <div className="flex justify-between border-b border-[#222222] pb-1">
                        <span>Customer Deposits</span>
                        <span className="text-[#D4D1CA]">£{balanceSheetSFC.deposits}M</span>
                      </div>
                      <div className="flex justify-between border-b border-[#222222] pb-1">
                        <span>Wholesale / Bonds</span>
                        <span className="text-[#D4D1CA]">£{(balanceSheetSFC.wholesale + balanceSheetSFC.bonds).toFixed(1)}M</span>
                      </div>
                      <div className="flex justify-between border-b border-[#222222] pb-1">
                        <span>Total Capital (SFC)</span>
                        <span className="text-[#D4D1CA]">£{balanceSheetSFC.capital}M</span>
                      </div>
                      <div className="flex justify-between font-bold text-[#D4D1CA] pt-1">
                        <span>Total Liab + Capital</span>
                        <span>£{balanceSheetSFC.totalLiabilities}M</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. MONETARY DASHBOARD */}
          {activeTab === 'monetary' && (
            <div className="space-y-6" id="monetary-tab">
              <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-2">Broad vs Narrow Money Trends</h3>
                <p className="text-xs text-[#8A9086] font-mono leading-relaxed mb-4">
                  Narrow money aggregates (reserves + circulating banknotes) are controlled by the central bank. Broad money is endogenously created via bank credit expansion.
                </p>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={computedAggregates} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                      <XAxis dataKey="date" stroke="#8A9086" fontSize={10} />
                      <YAxis stroke="#8A9086" fontSize={10} />
                      <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                      <Legend verticalAlign="top" height={36} iconType="circle" />
                      <Line type="monotone" dataKey="m0" name="M0 (Narrow Reserves)" stroke="#8A9A86" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="m1" name="M1 (Overnight Deposits)" stroke="#B87333" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="m4" name="M4 (Broad Money)" stroke="#5E83C0" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* 3. CREDIT OBSERVATORY */}
          {activeTab === 'credit' && (
            <div className="space-y-6" id="credit-tab">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Portfolio Mix */}
                <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                  <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-4">Retail Portfolio Composition</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={currentModifiedData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                        <XAxis dataKey="date" stroke="#8A9086" fontSize={10} />
                        <YAxis stroke="#8A9086" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                        <Legend verticalAlign="top" height={36} iconType="circle" />
                        <Area type="monotone" dataKey="lendingHousehold" name="Household Credit" stackId="1" stroke="#5E83C0" fill="#5E83C0" fillOpacity={0.15} />
                        <Area type="monotone" dataKey="lendingConsumer" name="Consumer Cards" stackId="1" stroke="#B22222" fill="#B22222" fillOpacity={0.15} />
                        <Area type="monotone" dataKey="lendingBusiness" name="SME Business Credit" stackId="1" stroke="#8A9A86" fill="#8A9A86" fillOpacity={0.15} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Commercial Portfolios */}
                <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                  <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-4">Commercial & Structured Portfolios</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={currentModifiedData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                        <XAxis dataKey="date" stroke="#8A9086" fontSize={10} />
                        <YAxis stroke="#8A9086" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                        <Legend verticalAlign="top" height={36} iconType="circle" />
                        <Line type="monotone" dataKey="lendingCommercial" name="Corporate Debt" stroke="#B87333" strokeWidth={2} dot={false} />
                        <Line type="monotone" dataKey="lendingMortgage" name="Mortgages" stroke="#8A9A86" strokeWidth={2} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. BALANCE SHEET */}
          {activeTab === 'balance_sheet' && (
            <div className="space-y-6" id="balance-sheet-tab">
              <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-4">Banking System Liabilities Stack</h3>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={currentModifiedData.slice(-12)} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                      <XAxis dataKey="date" stroke="#8A9086" fontSize={10} />
                      <YAxis stroke="#8A9086" fontSize={10} />
                      <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                      <Legend verticalAlign="top" height={36} iconType="circle" />
                      <Bar dataKey="depositHousehold" name="Retail Deposits" stackId="a" fill="#5E83C0" />
                      <Bar dataKey="depositCommercial" name="Corporate Deposits" stackId="a" fill="#B87333" />
                      <Bar dataKey="liabilityWholesale" name="Wholesale Funding" stackId="a" fill="#8A9A86" />
                      <Bar dataKey="liabilityBonds" name="Long-term Bonds" stackId="a" fill="#2C2E33" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* 5. MONETARY AGGREGATES */}
          {activeTab === 'aggregates' && (
            <div className="space-y-6" id="aggregates-tab">
              <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-2">Configurable Analysis of Monetary Aggregates</h3>
                <p className="text-xs text-[#8A9086] font-mono mb-4 leading-relaxed">
                  Analyze how narrow base money propagates into broad credit measures depending on commercial reserve multiplier variables.
                </p>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse font-mono text-xs text-[#8A9086]" id="aggregates-table">
                    <thead>
                      <tr className="border-b border-[#222222] text-[#D4D1CA]">
                        <th className="py-3 px-4">Date</th>
                        <th className="py-3 px-4">M0 (Cash Base)</th>
                        <th className="py-3 px-4">M1 (Overnight)</th>
                        <th className="py-3 px-4">M2 (Short-term)</th>
                        <th className="py-3 px-4">M3 (Institutional)</th>
                        <th className="py-3 px-4">M4 (Broad Money)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {computedAggregates.slice(-6).map((agg) => (
                        <tr key={agg.date} className="border-b border-[#222222] hover:bg-[#1A1A1A]">
                          <td className="py-3 px-4 font-bold text-[#D4D1CA]">{agg.date}</td>
                          <td className="py-3 px-4">£{agg.m0.toFixed(1)}M</td>
                          <td className="py-3 px-4 text-[#B87333]">£{agg.m1.toFixed(1)}M</td>
                          <td className="py-3 px-4">£{agg.m2.toFixed(1)}M</td>
                          <td className="py-3 px-4">£{agg.m3.toFixed(1)}M</td>
                          <td className="py-3 px-4 text-[#5E83C0] font-semibold">£{agg.m4.toFixed(1)}M</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 6. FUNDING ANALYTICS */}
          {activeTab === 'funding' && (
            <div className="space-y-6" id="funding-tab">
              <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-4">Funding Cost Spread Over Policy Rate</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={currentModifiedData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                      <XAxis dataKey="date" stroke="#8A9086" fontSize={10} />
                      <YAxis stroke="#8A9086" fontSize={10} />
                      <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                      <Legend verticalAlign="top" height={36} iconType="circle" />
                      <Line type="monotone" dataKey="policyRate" name="Central Bank Policy Rate" stroke="#B87333" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="wholesaleRate" name="Wholesale Libor Spread" stroke="#8A9A86" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                      <Line type="monotone" dataKey="depositRate" name="Retail Deposit Interest Rate" stroke="#5E83C0" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* 7. INTEREST RATE ANALYTICS */}
          {activeTab === 'interest_rates' && (
            <div className="space-y-6" id="rates-tab">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                  <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-4">Transmission Lag & Spreads</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={currentModifiedData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                        <XAxis dataKey="date" stroke="#8A9086" fontSize={10} />
                        <YAxis stroke="#8A9086" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                        <Legend verticalAlign="top" height={36} />
                        <Line type="monotone" dataKey="lendingRate" name="Portfolio Lending Yield" stroke="#B87333" strokeWidth={2.5} dot={false} />
                        <Line type="monotone" dataKey="depositRate" name="Deposit Pricing Rate" stroke="#5E83C0" strokeWidth={2} dot={false} />
                        <Line type="monotone" dataKey="yield10Y" name="10-Year Gilt Yield" stroke="#8A9A86" strokeWidth={1.5} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm flex flex-col justify-between">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-1">Interactive Rate Shocks</h3>
                    <p className="text-xs text-[#8A9086] font-mono">Simulate yield curve parallel shift</p>
                  </div>

                  <div className="space-y-6 my-4 font-mono text-xs">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>POLICY RATE SHOCK:</span>
                        <span className="font-bold text-[#B87333]">{rateShift >= 0 ? '+' : ''}{rateShift.toFixed(2)}%</span>
                      </div>
                      <input
                        type="range"
                        min="-3.00"
                        max="3.00"
                        step="0.25"
                        value={rateShift}
                        onChange={(e) => setRateShift(parseFloat(e.target.value))}
                        className="w-full accent-[#B87333] bg-[#0A0A0A] border border-[#222222] rounded-sm"
                        id="rate-shock-slider"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>CREDIT ACTIVITY MULTIPLIER:</span>
                        <span className="font-bold text-[#8A9A86]">{lendingMultiplier.toFixed(2)}x</span>
                      </div>
                      <input
                        type="range"
                        min="0.50"
                        max="1.50"
                        step="0.05"
                        value={lendingMultiplier}
                        onChange={(e) => setLendingMultiplier(parseFloat(e.target.value))}
                        className="w-full accent-[#8A9A86] bg-[#0A0A0A] border border-[#222222] rounded-sm"
                        id="lending-multiplier-slider"
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => { setRateShift(0); setLendingMultiplier(1.0); }}
                    className="w-full bg-[#0A0A0A] hover:bg-[#1A1A1A] text-[#8A9086] hover:text-[#D4D1CA] border border-[#222222] text-xs font-mono py-2.5 rounded-sm transition-all flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> RESET PARAMETERS
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 8. ECONOMETRIC ANALYSIS */}
          {activeTab === 'econometrics' && (
            <div className="space-y-6" id="econometrics-tab">
              {/* Dynamic Econometrics Selection Tabs */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* 1. Multiple Regression Output */}
                <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-serif text-lg font-bold text-[#D4D1CA]">Multiple Linear Regression (OLS)</h3>
                    <span className="text-[10px] font-mono bg-[#222222] px-2 py-0.5 rounded-sm text-[#8A9086]">R² = {econometricsRegression[0]?.rSquared?.toFixed(3)}</span>
                  </div>
                  <p className="text-xs text-[#8A9086] font-mono mb-4">Target: Household Deposits (depositHousehold)</p>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse font-mono text-[11px] text-[#8A9086]">
                      <thead>
                        <tr className="border-b border-[#222222] text-[#D4D1CA]">
                          <th className="py-2">Predictor</th>
                          <th className="py-2">Estimate</th>
                          <th className="py-2">Std. Error</th>
                          <th className="py-2">t-Stat</th>
                          <th className="py-2">Pr(&gt;|t|)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {econometricsRegression.map((reg) => (
                          <tr key={reg.variable} className="border-b border-[#222222] hover:bg-[#1A1A1A]">
                            <td className="py-2.5 font-bold text-[#D4D1CA]">{reg.variable}</td>
                            <td className="py-2.5">{reg.coefficient.toFixed(4)}</td>
                            <td className="py-2.5">{reg.stdError.toFixed(4)}</td>
                            <td className="py-2.5 text-amber-500">{reg.tStatistic.toFixed(2)}</td>
                            <td className="py-2.5 font-semibold text-emerald-500">{reg.pValue.toFixed(4)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 2. Cointegration & ECM */}
                <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm flex flex-col justify-between">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-2">Engle-Granger Cointegration & ECM</h3>
                    <p className="text-xs text-[#8A9086] font-mono leading-relaxed mb-4">
                      Tests long-run equilibrium relationships between Deposits and Lending. High significance proves systemic balance sheet stability.
                    </p>
                  </div>
                  <div className="space-y-4 font-mono text-xs my-4">
                    <div className="flex justify-between border-b border-[#222222] pb-1">
                      <span>Cointegrating Beta (Long-run):</span>
                      <span className="text-[#B87333] font-bold">{econometricsCointegration.cointegratingBeta}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#222222] pb-1">
                      <span>Speed of Adjustment (ECM Alpha):</span>
                      <span className="text-rose-400 font-bold">{econometricsCointegration.speedOfAdjustment}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#222222] pb-1">
                      <span>Johansen Trace Statistic:</span>
                      <span className="text-emerald-400 font-bold">{econometricsCointegration.johansenTrace}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#222222] pb-1">
                      <span>Critical Value (5%):</span>
                      <span>{econometricsCointegration.johansenCriticalValue}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#222222] pb-1">
                      <span>Cointegration P-Value:</span>
                      <span className="text-emerald-500 font-bold">{econometricsCointegration.pValue} (Significant)</span>
                    </div>
                  </div>
                  <div className="bg-[#0A0A0A] p-3 rounded-sm text-[11px] text-[#8A9086] leading-relaxed border-l border-rose-400">
                    A negative ECM coefficient of {econometricsCointegration.speedOfAdjustment} indicates that portfolio imbalances dissolve back to structural equilibrium at approximately {Math.abs(econometricsCointegration.speedOfAdjustment * 100).toFixed(1)}% per month.
                  </div>
                </div>
              </div>

              {/* PCA Scree plot and loadings */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                  <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-2">PCA Eigenvalues Screen</h3>
                  <p className="text-xs text-[#8A9086] font-mono mb-4">Dimensions: Policy Rate, Lending Rate, Deposit Rate, Yield 10Y</p>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={econometricsPCA.components} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                        <XAxis dataKey="id" stroke="#8A9086" fontSize={10} />
                        <YAxis stroke="#8A9086" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                        <Legend />
                        <Bar dataKey="varianceExplained" name="Proportion of Variance" fill="#B87333" />
                        <Bar dataKey="cumulativeVariance" name="Cumulative Variance" fill="#5E83C0" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* PCA Factor Loadings */}
                <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm flex flex-col justify-between">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-2">Component Loading Matrix</h3>
                    <p className="text-xs text-[#8A9086] font-mono">Principal Component 1 (PC1) vs PC2</p>
                  </div>
                  <div className="space-y-3 font-mono text-xs my-4">
                    <div className="grid grid-cols-3 font-bold border-b border-[#222222] pb-1 text-[#D4D1CA]">
                      <span>Variable</span>
                      <span>PC1</span>
                      <span>PC2</span>
                    </div>
                    {Object.keys(econometricsPCA.components[0]?.loadings || {}).map(vKey => {
                      const pc1_v = econometricsPCA.components[0]?.loadings[vKey] || 0;
                      const pc2_v = econometricsPCA.components[1]?.loadings[vKey] || 0;
                      return (
                        <div key={vKey} className="grid grid-cols-3 border-b border-[#222222] pb-1">
                          <span className="font-semibold text-[#8A9086] truncate">{vKey}</span>
                          <span className={pc1_v >= 0 ? 'text-emerald-500' : 'text-rose-500'}>{pc1_v.toFixed(3)}</span>
                          <span className={pc2_v >= 0 ? 'text-emerald-500' : 'text-rose-500'}>{pc2_v.toFixed(3)}</span>
                        </div>
                      );
                    })}
                  </div>
                  <p className="text-[10px] text-[#8A9086] font-serif leading-relaxed">
                    PC1 explains {(econometricsPCA.components[0]?.varianceExplained * 100 || 0).toFixed(1)}% of total interest rate dimensions variance, acting as the primary yield shift factor.
                  </p>
                </div>
              </div>

              {/* VAR Impulse response functions (IRF) */}
              <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-2">Vector Autoregression (VAR) Impulse Responses</h3>
                <p className="text-xs text-[#8A9086] font-mono mb-4">Response of monetary portfolios to a +100bps interest rate tightening shock</p>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={econometricsVAR.impulseResponse} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                      <XAxis dataKey="step" name="Months after Shock" stroke="#8A9086" fontSize={10} />
                      <YAxis stroke="#8A9086" fontSize={10} />
                      <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                      <Legend verticalAlign="top" height={36} />
                      <ReferenceLine y={0} stroke="#444" strokeWidth={1} />
                      <Line type="monotone" dataKey="interestRateShockOnLending" name="Lending Volume Response" stroke="#B22222" strokeWidth={2.5} dot={true} />
                      <Line type="monotone" dataKey="interestRateShockOnDeposits" name="Deposit Volume Response" stroke="#5E83C0" strokeWidth={2} dot={true} />
                      <Line type="monotone" dataKey="lendingShockOnDeposits" name="Net Multiplier Impact" stroke="#B87333" strokeWidth={1.5} dot={true} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* 9. FORECAST CENTRE */}
          {activeTab === 'forecasts' && (
            <div className="space-y-6" id="forecast-tab">
              {/* Forecast Controls Row */}
              <div className="bg-[#1A1A1A] border border-[#222222] p-5 rounded-sm flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
                <div className="flex items-center space-x-4 flex-wrap gap-2">
                  <div className="flex flex-col space-y-1">
                    <span className="text-[#8A9086] text-[10px] uppercase">Variable</span>
                    <select
                      value={forecastTarget}
                      onChange={(e) => setForecastTarget(e.target.value)}
                      className="bg-[#0A0A0A] text-[#D4D1CA] border border-[#222222] px-3 py-1.5 rounded-sm focus:outline-none focus:border-[#B87333]"
                      id="forecast-target-selector"
                    >
                      <option value="lendingMortgage">Mortgage Portfolios</option>
                      <option value="lendingCommercial">Corporate portfolios</option>
                      <option value="depositHousehold">Household Deposits</option>
                      <option value="policyRate">BoE Policy rate</option>
                    </select>
                  </div>

                  <div className="flex flex-col space-y-1">
                    <span className="text-[#8A9086] text-[10px] uppercase">Forecasting Model</span>
                    <select
                      value={forecastMethod}
                      onChange={(e) => setForecastMethod(e.target.value as ForecastingMethod)}
                      className="bg-[#0A0A0A] text-[#D4D1CA] border border-[#222222] px-3 py-1.5 rounded-sm focus:outline-none focus:border-[#B87333]"
                      id="forecast-method-selector"
                    >
                      <option value="arima">ARIMA(1,1,1) with Drift</option>
                      <option value="ets">ETS Holt-Winters</option>
                      <option value="var">Vector Autoregression (VAR)</option>
                      <option value="randomForest">Random Forest Ensemble</option>
                      <option value="xgboost">Gradient Boosting (XGBoost)</option>
                    </select>
                  </div>
                </div>

                <div className="bg-[#0A0A0A] border border-[#222222] px-4 py-2.5 rounded-sm font-mono text-[11px] text-[#8A9086] max-w-sm">
                  Projections simulate 24 future monthly intervals (Jul 2026 to Jun 2028) under continuous parameters.
                </div>
              </div>

              {/* Shaded Area Forecast Chart */}
              <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-[#D4D1CA]">24-Month Projected Forecast & Confidence Bounds</h3>
                    <p className="text-xs text-[#8A9086] font-mono mt-0.5">Model: {forecastMethod.toUpperCase()} (Confidence: 95% Shade)</p>
                  </div>
                </div>
                
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={activeForecastSeries} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                      <XAxis dataKey="date" stroke="#8A9086" fontSize={10} />
                      <YAxis stroke="#8A9086" fontSize={10} domain={['auto', 'auto']} />
                      <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#222222', color: '#D4D1CA' }} />
                      <Legend verticalAlign="top" height={36} />
                      <ReferenceLine x="2026-06" stroke="#B87333" strokeWidth={1.5} label={{ value: "Forecast Start", position: "top", fill: "#B87333", fontSize: 10, fontFamily: "monospace" }} />
                      
                      {/* confidence intervals */}
                      <Area type="monotone" dataKey="lower95" stroke="none" fill="#B87333" fillOpacity={0.06} />
                      <Area type="monotone" dataKey="upper95" name="95% Confidence Band" stroke="none" fill="#B87333" fillOpacity={0.06} />
                      
                      {/* lines */}
                      <Line type="monotone" dataKey="actual" name="Historical Observed" stroke="#5E83C0" strokeWidth={2.5} dot={false} />
                      <Area type="monotone" dataKey="forecast" name="Model Prediction" stroke="#B87333" strokeWidth={2.5} fill="none" dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* 10. SCENARIO LABORATORY */}
          {activeTab === 'scenarios' && (
            <div className="space-y-6" id="scenarios-tab">
              {/* Scenario Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {SCENARIOS.map((sc) => {
                  const isSelected = selectedScenarioId === sc.id;
                  return (
                    <button
                      key={sc.id}
                      onClick={() => setSelectedScenarioId(sc.id)}
                      className={`text-left border p-5 rounded-sm flex flex-col justify-between h-48 transition-all ${
                        isSelected 
                          ? 'bg-[#1A1A1A] border-[#B87333] shadow-xl' 
                          : 'bg-[#1A1A1A] border-[#222222] hover:border-[#444444]'
                      }`}
                      id={`scenario-card-${sc.id}`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span 
                            className="w-2.5 h-2.5 rounded-full" 
                            style={{ backgroundColor: sc.color }} 
                          />
                          {isSelected && <span className="text-[9px] font-mono text-[#B87333] border border-[#B87333] px-1.5 py-0.5 rounded-sm uppercase font-semibold">ACTIVE</span>}
                        </div>
                        <h4 className="font-serif font-bold text-[#E2E4E0] text-sm leading-tight">{sc.name}</h4>
                        <p className="text-[11px] text-[#8A9086] mt-2 font-serif leading-snug line-clamp-3">
                          {sc.description}
                        </p>
                      </div>

                      <div className="font-mono text-[10px] text-[#8A9086] flex justify-between w-full pt-2 border-t border-[#222222]">
                        <span>Rate Shift: {sc.policyRateShift >= 0 ? '+' : ''}{sc.policyRateShift.toFixed(2)}%</span>
                        <span>Credit: {sc.lendingMultiplier}x</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Simulation metrics under selected scenario */}
              <div className="bg-[#1A1A1A] border border-[#222222] p-6 rounded-sm">
                <h3 className="font-serif text-lg font-bold text-[#D4D1CA] mb-4">Simulated Accounting Consistency (Basel III / SFC Check)</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
                  <div className="bg-[#0A0A0A] p-4 rounded-sm border border-[#222222] space-y-2">
                    <span className="text-[#8A9A86] font-semibold block">ASSETS PORTFOLIOS</span>
                    <div className="flex justify-between">
                      <span>Mortgage Loans:</span>
                      <span>£{balanceSheetSFC.loans}M</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Liquidity Reserves:</span>
                      <span>£{balanceSheetSFC.cash}M</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Government Bonds:</span>
                      <span>£{balanceSheetSFC.securities}M</span>
                    </div>
                  </div>

                  <div className="bg-[#0A0A0A] p-4 rounded-sm border border-[#222222] space-y-2">
                    <span className="text-[#5E83C0] font-semibold block">LIABILITIES</span>
                    <div className="flex justify-between">
                      <span>Customer Deposits:</span>
                      <span>£{balanceSheetSFC.deposits}M</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Wholesale/Debt:</span>
                      <span>£{(balanceSheetSFC.wholesale + balanceSheetSFC.bonds).toFixed(1)}M</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Other Liabilities:</span>
                      <span>£{balanceSheetSFC.otherLiabilities}M</span>
                    </div>
                  </div>

                  <div className="bg-[#0A0A0A] p-4 rounded-sm border border-[#B87333]/30 space-y-2 flex flex-col justify-between">
                    <div>
                      <span className="text-[#B87333] font-semibold block">REGULATORY SOLVENCY</span>
                      <div className="flex justify-between mt-2">
                        <span>Risk Weighted (RWA):</span>
                        <span>£{balanceSheetSFC.riskWeightedAssets}M</span>
                      </div>
                      <div className="flex justify-between mt-1">
                        <span>Balancing Capital:</span>
                        <span>£{balanceSheetSFC.capital}M</span>
                      </div>
                    </div>
                    <div className="flex justify-between font-bold text-[#D4D1CA] pt-2 border-t border-[#222222] mt-2">
                      <span>SFC Capital Ratio:</span>
                      <span className={balanceSheetSFC.capitalAdequacyRatio >= 12.0 ? 'text-emerald-400' : 'text-rose-400'}>
                        {balanceSheetSFC.capitalAdequacyRatio}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 11. REGIONAL COMPARISON (GIS) */}
          {activeTab === 'regions' && (
            <div className="space-y-6" id="regions-tab">
              <YorkshireMap 
                selectedRegionId={selectedRegionId} 
                onRegionSelect={(reg) => setSelectedRegionId(reg.id)} 
              />
            </div>
          )}

          {/* 12. REPORTS & BRIEFINGS (AI GENERATED) */}
          {activeTab === 'reports' && (
            <div className="space-y-6" id="reports-tab">
              {/* Context bar */}
              <div className="bg-[#1A1A1A] border border-[#222222] p-5 rounded-sm flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="font-serif text-lg font-bold text-[#D4D1CA] flex items-center gap-2">
                    <FileText className="w-5 h-5 text-[#B87333]" /> Executive Economic Briefing & Reports
                  </h3>
                  <p className="text-xs text-[#8A9086] font-mono mt-0.5">Real-time econometric interpretation via server-side Gemini</p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={generateAIBriefing}
                    disabled={isBriefingLoading}
                    className="bg-[#B87333] hover:bg-[#A36024] text-[#0A0A0A] font-semibold text-xs font-mono px-4 py-2 rounded-sm transition-all flex items-center gap-2 disabled:opacity-50"
                    id="trigger-briefing-btn"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isBriefingLoading ? 'animate-spin' : ''}`} /> 
                    {isBriefingLoading ? 'GENERATING REPORT...' : 'REFRESH INTEL BRIEFING'}
                  </button>

                  <button
                    onClick={() => exportCSV(currentModifiedData, 'rhinoquant_monetary_report')}
                    className="bg-[#0A0A0A] hover:bg-[#1A1A1A] text-[#D4D1CA] border border-[#222222] text-xs font-mono px-4 py-2 rounded-sm transition-all flex items-center gap-2"
                  >
                    <Download className="w-3.5 h-3.5" /> EXPORT portfolio DATA
                  </button>
                </div>
              </div>

              {/* Gemini Report Screen */}
              <div className="bg-[#0A0A0A] border border-[#222222] rounded-sm p-8 shadow-2xl relative">
                {isBriefingLoading && (
                  <div className="absolute inset-0 bg-[#0A0A0A]/90 flex flex-col items-center justify-center z-10 space-y-4">
                    <div className="w-8 h-8 border-2 border-t-transparent border-[#B87333] rounded-full animate-spin" />
                    <span className="text-xs font-mono text-[#8A9086] tracking-wider animate-pulse">GENERATING RIGOROUS CENTRAL BANK LEVEL REPORT VIA GEMINI AI...</span>
                  </div>
                )}

                {/* Editorial Paper Formatting */}
                <div className="max-w-3xl mx-auto prose prose-invert font-serif" id="markdown-briefing-wrapper">
                  <div className="border-b-2 border-[#B87333] pb-6 mb-8 text-center">
                    <span className="font-mono text-xs text-[#B87333] tracking-widest font-semibold uppercase block mb-1">
                      RHINO MONETARY RESEARCH INSTITUTE (R)
                    </span>
                    <h2 className="text-3xl font-bold text-[#D4D1CA] tracking-tight m-0 font-serif">MONETARY ASSESSMENT BRIEF</h2>
                    <div className="flex justify-center space-x-6 text-xs text-[#8A9086] font-mono mt-3">
                      <span>CLASSIFICATION: EXECUTIVE RESEARCH</span>
                      <span>DATE: JULY 2026</span>
                      <span>MODEL FRAMEWORK: {framework.toUpperCase()}</span>
                    </div>
                  </div>

                  {geminiBriefing ? (
                    <div className="markdown-body text-[#D4D1CA] leading-relaxed text-sm space-y-4">
                      <Markdown>{geminiBriefing}</Markdown>
                    </div>
                  ) : (
                    <p className="text-center text-xs font-mono text-[#8A9086] py-12">No briefing report generated yet. Click above to query the economic model.</p>
                  )}

                  <div className="border-t border-[#222222] pt-6 mt-12 flex justify-between items-center text-[11px] font-mono text-[#8A9086]">
                    <span>Author: Automated Quant Intelligence Pipeline</span>
                    <span>Rhino Bank Treasury Committee © 2026</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
