/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HistoricalDataPoint, Scenario, RegionalIndicator } from './types';

// Historical monthly data from January 2023 to June 2026 (42 data points)
export const HISTORICAL_DATA: HistoricalDataPoint[] = [
  {
    date: '2023-01',
    lendingHousehold: 420.5, lendingCommercial: 610.2, lendingMortgage: 1250.8, lendingBusiness: 850.4, lendingConsumer: 110.1,
    depositHousehold: 1510.5, depositCommercial: 1050.2, depositWholesale: 480.0,
    assetSecurities: 450.0, assetCash: 120.0, assetLiquid: 580.0, assetOther: 85.0,
    liabilityWholesale: 510.0, liabilityBonds: 310.0, liabilityCapital: 280.0, liabilityOther: 42.0,
    policyRate: 3.50, lendingRate: 5.25, depositRate: 2.10, wholesaleRate: 3.80, yield10Y: 3.40,
    indexYorkshireHumber: 100.0, indexWestYorkshire: 100.0, indexSouthYorkshire: 100.0, indexNorthYorkshire: 100.0, indexEastRiding: 100.0,
    rhinoMortgage: 45.1, rhinoCommercial: 58.2, rhinoDeposits: 98.4, rhinoWholesale: 12.1, rhinoCapital: 9.8
  },
  {
    date: '2023-02',
    lendingHousehold: 422.1, lendingCommercial: 611.8, lendingMortgage: 1253.2, lendingBusiness: 852.1, lendingConsumer: 110.4,
    depositHousehold: 1512.4, depositCommercial: 1052.1, depositWholesale: 483.5,
    assetSecurities: 452.1, assetCash: 122.3, assetLiquid: 582.4, assetOther: 84.8,
    liabilityWholesale: 512.5, liabilityBonds: 310.0, liabilityCapital: 281.2, liabilityOther: 41.5,
    policyRate: 4.00, lendingRate: 5.50, depositRate: 2.35, wholesaleRate: 4.25, yield10Y: 3.55,
    indexYorkshireHumber: 100.4, indexWestYorkshire: 100.6, indexSouthYorkshire: 100.2, indexNorthYorkshire: 100.1, indexEastRiding: 100.3,
    rhinoMortgage: 45.4, rhinoCommercial: 58.5, rhinoDeposits: 98.9, rhinoWholesale: 12.3, rhinoCapital: 9.9
  },
  {
    date: '2023-03',
    lendingHousehold: 423.8, lendingCommercial: 614.5, lendingMortgage: 1256.0, lendingBusiness: 855.3, lendingConsumer: 111.0,
    depositHousehold: 1515.2, depositCommercial: 1055.8, depositWholesale: 486.2,
    assetSecurities: 454.2, assetCash: 125.1, assetLiquid: 585.0, assetOther: 85.1,
    liabilityWholesale: 514.8, liabilityBonds: 312.0, liabilityCapital: 282.4, liabilityOther: 42.1,
    policyRate: 4.25, lendingRate: 5.75, depositRate: 2.50, wholesaleRate: 4.45, yield10Y: 3.62,
    indexYorkshireHumber: 101.1, indexWestYorkshire: 101.4, indexSouthYorkshire: 100.9, indexNorthYorkshire: 100.5, indexEastRiding: 100.8,
    rhinoMortgage: 45.8, rhinoCommercial: 58.9, rhinoDeposits: 99.5, rhinoWholesale: 12.5, rhinoCapital: 10.0
  },
  {
    date: '2023-04',
    lendingHousehold: 425.2, lendingCommercial: 617.2, lendingMortgage: 1258.9, lendingBusiness: 858.0, lendingConsumer: 111.5,
    depositHousehold: 1518.0, depositCommercial: 1058.4, depositWholesale: 489.0,
    assetSecurities: 455.9, assetCash: 127.8, assetLiquid: 587.2, assetOther: 86.0,
    liabilityWholesale: 516.2, liabilityBonds: 312.0, liabilityCapital: 283.5, liabilityOther: 42.5,
    policyRate: 4.25, lendingRate: 5.80, depositRate: 2.55, wholesaleRate: 4.48, yield10Y: 3.65,
    indexYorkshireHumber: 101.6, indexWestYorkshire: 102.0, indexSouthYorkshire: 101.2, indexNorthYorkshire: 100.9, indexEastRiding: 101.2,
    rhinoMortgage: 46.1, rhinoCommercial: 59.3, rhinoDeposits: 100.1, rhinoWholesale: 12.6, rhinoCapital: 10.1
  },
  {
    date: '2023-05',
    lendingHousehold: 427.0, lendingCommercial: 619.5, lendingMortgage: 1261.5, lendingBusiness: 860.2, lendingConsumer: 112.1,
    depositHousehold: 1521.1, depositCommercial: 1061.2, depositWholesale: 492.4,
    assetSecurities: 457.8, assetCash: 129.5, assetLiquid: 589.6, assetOther: 86.4,
    liabilityWholesale: 518.0, liabilityBonds: 315.0, liabilityCapital: 284.6, liabilityOther: 43.1,
    policyRate: 4.50, lendingRate: 6.00, depositRate: 2.75, wholesaleRate: 4.70, yield10Y: 3.78,
    indexYorkshireHumber: 102.2, indexWestYorkshire: 102.7, indexSouthYorkshire: 101.8, indexNorthYorkshire: 101.4, indexEastRiding: 101.7,
    rhinoMortgage: 46.4, rhinoCommercial: 59.8, rhinoDeposits: 100.8, rhinoWholesale: 12.8, rhinoCapital: 10.2
  },
  {
    date: '2023-06',
    lendingHousehold: 428.5, lendingCommercial: 622.0, lendingMortgage: 1264.8, lendingBusiness: 863.5, lendingConsumer: 112.8,
    depositHousehold: 1524.5, depositCommercial: 1064.0, depositWholesale: 495.1,
    assetSecurities: 460.1, assetCash: 131.2, assetLiquid: 591.4, assetOther: 86.9,
    liabilityWholesale: 520.1, liabilityBonds: 315.0, liabilityCapital: 285.8, liabilityOther: 43.5,
    policyRate: 5.00, lendingRate: 6.25, depositRate: 3.10, wholesaleRate: 5.15, yield10Y: 3.95,
    indexYorkshireHumber: 102.8, indexWestYorkshire: 103.4, indexSouthYorkshire: 102.4, indexNorthYorkshire: 102.0, indexEastRiding: 102.2,
    rhinoMortgage: 46.8, rhinoCommercial: 60.2, rhinoDeposits: 101.4, rhinoWholesale: 13.0, rhinoCapital: 10.3
  },
  {
    date: '2023-07',
    lendingHousehold: 429.2, lendingCommercial: 624.1, lendingMortgage: 1267.0, lendingBusiness: 866.0, lendingConsumer: 113.2,
    depositHousehold: 1527.2, depositCommercial: 1066.8, depositWholesale: 498.3,
    assetSecurities: 462.4, assetCash: 132.8, assetLiquid: 593.1, assetOther: 87.2,
    liabilityWholesale: 522.4, liabilityBonds: 318.0, liabilityCapital: 287.0, liabilityOther: 43.8,
    policyRate: 5.00, lendingRate: 6.30, depositRate: 3.20, wholesaleRate: 5.18, yield10Y: 4.02,
    indexYorkshireHumber: 103.4, indexWestYorkshire: 104.1, indexSouthYorkshire: 103.0, indexNorthYorkshire: 102.5, indexEastRiding: 102.8,
    rhinoMortgage: 47.1, rhinoCommercial: 60.5, rhinoDeposits: 102.1, rhinoWholesale: 13.1, rhinoCapital: 10.4
  },
  {
    date: '2023-08',
    lendingHousehold: 430.4, lendingCommercial: 626.8, lendingMortgage: 1269.5, lendingBusiness: 868.2, lendingConsumer: 113.6,
    depositHousehold: 1530.1, depositCommercial: 1069.2, depositWholesale: 501.2,
    assetSecurities: 464.0, assetCash: 134.5, assetLiquid: 595.0, assetOther: 87.5,
    liabilityWholesale: 524.5, liabilityBonds: 318.0, liabilityCapital: 288.1, liabilityOther: 44.1,
    policyRate: 5.25, lendingRate: 6.50, depositRate: 3.45, wholesaleRate: 5.42, yield10Y: 4.15,
    indexYorkshireHumber: 104.0, indexWestYorkshire: 104.8, indexSouthYorkshire: 103.5, indexNorthYorkshire: 103.1, indexEastRiding: 103.4,
    rhinoMortgage: 47.4, rhinoCommercial: 60.9, rhinoDeposits: 102.7, rhinoWholesale: 13.3, rhinoCapital: 10.5
  },
  {
    date: '2023-09',
    lendingHousehold: 431.1, lendingCommercial: 628.5, lendingMortgage: 1271.2, lendingBusiness: 870.4, lendingConsumer: 113.9,
    depositHousehold: 1532.5, depositCommercial: 1071.5, depositWholesale: 503.8,
    assetSecurities: 465.8, assetCash: 136.0, assetLiquid: 596.8, assetOther: 87.9,
    liabilityWholesale: 526.2, liabilityBonds: 320.0, liabilityCapital: 289.2, liabilityOther: 44.4,
    policyRate: 5.25, lendingRate: 6.55, depositRate: 3.50, wholesaleRate: 5.40, yield10Y: 4.22,
    indexYorkshireHumber: 104.5, indexWestYorkshire: 105.4, indexSouthYorkshire: 104.0, indexNorthYorkshire: 103.6, indexEastRiding: 103.9,
    rhinoMortgage: 47.6, rhinoCommercial: 61.2, rhinoDeposits: 103.3, rhinoWholesale: 13.5, rhinoCapital: 10.6
  },
  {
    date: '2023-10',
    lendingHousehold: 431.9, lendingCommercial: 630.1, lendingMortgage: 1272.8, lendingBusiness: 872.1, lendingConsumer: 114.2,
    depositHousehold: 1534.8, depositCommercial: 1073.4, depositWholesale: 506.4,
    assetSecurities: 467.2, assetCash: 137.5, assetLiquid: 598.4, assetOther: 88.1,
    liabilityWholesale: 528.0, liabilityBonds: 320.0, liabilityCapital: 290.4, liabilityOther: 44.7,
    policyRate: 5.25, lendingRate: 6.60, depositRate: 3.55, wholesaleRate: 5.38, yield10Y: 4.18,
    indexYorkshireHumber: 105.0, indexWestYorkshire: 106.0, indexSouthYorkshire: 104.5, indexNorthYorkshire: 104.0, indexEastRiding: 104.4,
    rhinoMortgage: 47.8, rhinoCommercial: 61.5, rhinoDeposits: 103.9, rhinoWholesale: 13.6, rhinoCapital: 10.7
  },
  {
    date: '2023-11',
    lendingHousehold: 432.5, lendingCommercial: 631.5, lendingMortgage: 1274.0, lendingBusiness: 874.0, lendingConsumer: 114.5,
    depositHousehold: 1536.9, depositCommercial: 1075.2, depositWholesale: 508.9,
    assetSecurities: 468.9, assetCash: 139.1, assetLiquid: 600.2, assetOther: 88.4,
    liabilityWholesale: 529.8, liabilityBonds: 322.0, liabilityCapital: 291.5, liabilityOther: 45.0,
    policyRate: 5.25, lendingRate: 6.60, depositRate: 3.55, wholesaleRate: 5.35, yield10Y: 4.10,
    indexYorkshireHumber: 105.4, indexWestYorkshire: 106.5, indexSouthYorkshire: 104.9, indexNorthYorkshire: 104.5, indexEastRiding: 104.8,
    rhinoMortgage: 48.0, rhinoCommercial: 61.8, rhinoDeposits: 104.5, rhinoWholesale: 13.7, rhinoCapital: 10.8
  },
  {
    date: '2023-12',
    lendingHousehold: 433.2, lendingCommercial: 633.2, lendingMortgage: 1275.5, lendingBusiness: 875.8, lendingConsumer: 114.9,
    depositHousehold: 1539.1, depositCommercial: 1077.5, depositWholesale: 511.5,
    assetSecurities: 470.5, assetCash: 140.5, assetLiquid: 601.8, assetOther: 88.8,
    liabilityWholesale: 531.5, liabilityBonds: 322.0, liabilityCapital: 292.8, liabilityOther: 45.4,
    policyRate: 5.25, lendingRate: 6.62, depositRate: 3.60, wholesaleRate: 5.32, yield10Y: 4.05,
    indexYorkshireHumber: 105.9, indexWestYorkshire: 107.1, indexSouthYorkshire: 105.4, indexNorthYorkshire: 105.0, indexEastRiding: 105.3,
    rhinoMortgage: 48.2, rhinoCommercial: 62.1, rhinoDeposits: 105.1, rhinoWholesale: 13.9, rhinoCapital: 10.9
  },
  {
    date: '2024-01',
    lendingHousehold: 434.0, lendingCommercial: 635.0, lendingMortgage: 1277.1, lendingBusiness: 877.5, lendingConsumer: 115.2,
    depositHousehold: 1541.5, depositCommercial: 1079.8, depositWholesale: 514.0,
    assetSecurities: 472.1, assetCash: 142.0, assetLiquid: 603.5, assetOther: 89.1,
    liabilityWholesale: 533.2, liabilityBonds: 325.0, liabilityCapital: 294.0, liabilityOther: 45.8,
    policyRate: 5.25, lendingRate: 6.65, depositRate: 3.62, wholesaleRate: 5.30, yield10Y: 4.01,
    indexYorkshireHumber: 106.3, indexWestYorkshire: 107.6, indexSouthYorkshire: 105.8, indexNorthYorkshire: 105.4, indexEastRiding: 105.7,
    rhinoMortgage: 48.4, rhinoCommercial: 62.4, rhinoDeposits: 105.8, rhinoWholesale: 14.0, rhinoCapital: 11.0
  },
  {
    date: '2024-02',
    lendingHousehold: 434.8, lendingCommercial: 636.8, lendingMortgage: 1278.8, lendingBusiness: 879.4, lendingConsumer: 115.5,
    depositHousehold: 1543.8, depositCommercial: 1081.9, depositWholesale: 516.2,
    assetSecurities: 473.8, assetCash: 143.4, assetLiquid: 605.1, assetOther: 89.4,
    liabilityWholesale: 535.0, liabilityBonds: 325.0, liabilityCapital: 295.2, liabilityOther: 46.1,
    policyRate: 5.25, lendingRate: 6.65, depositRate: 3.65, wholesaleRate: 5.28, yield10Y: 3.98,
    indexYorkshireHumber: 106.7, indexWestYorkshire: 108.1, indexSouthYorkshire: 106.2, indexNorthYorkshire: 105.8, indexEastRiding: 106.1,
    rhinoMortgage: 48.6, rhinoCommercial: 62.7, rhinoDeposits: 106.4, rhinoWholesale: 14.1, rhinoCapital: 11.1
  },
  {
    date: '2024-03',
    lendingHousehold: 435.5, lendingCommercial: 638.5, lendingMortgage: 1280.4, lendingBusiness: 881.2, lendingConsumer: 115.9,
    depositHousehold: 1546.2, depositCommercial: 1084.1, depositWholesale: 518.5,
    assetSecurities: 475.4, assetCash: 144.9, assetLiquid: 606.8, assetOther: 89.8,
    liabilityWholesale: 536.8, liabilityBonds: 328.0, liabilityCapital: 296.4, liabilityOther: 46.5,
    policyRate: 5.25, lendingRate: 6.68, depositRate: 3.68, wholesaleRate: 5.25, yield10Y: 3.95,
    indexYorkshireHumber: 107.2, indexWestYorkshire: 108.7, indexSouthYorkshire: 106.6, indexNorthYorkshire: 106.3, indexEastRiding: 106.6,
    rhinoMortgage: 48.8, rhinoCommercial: 63.0, rhinoDeposits: 107.1, rhinoWholesale: 14.3, rhinoCapital: 11.2
  },
  {
    date: '2024-04',
    lendingHousehold: 436.2, lendingCommercial: 640.2, lendingMortgage: 1282.0, lendingBusiness: 883.0, lendingConsumer: 116.2,
    depositHousehold: 1548.5, depositCommercial: 1086.2, depositWholesale: 520.8,
    assetSecurities: 477.1, assetCash: 146.4, assetLiquid: 608.4, assetOther: 90.1,
    liabilityWholesale: 538.5, liabilityBonds: 328.0, liabilityCapital: 297.5, liabilityOther: 46.8,
    policyRate: 5.25, lendingRate: 6.68, depositRate: 3.68, wholesaleRate: 5.23, yield10Y: 3.92,
    indexYorkshireHumber: 107.6, indexWestYorkshire: 109.2, indexSouthYorkshire: 107.0, indexNorthYorkshire: 106.7, indexEastRiding: 107.0,
    rhinoMortgage: 49.0, rhinoCommercial: 63.3, rhinoDeposits: 107.7, rhinoWholesale: 14.4, rhinoCapital: 11.3
  },
  {
    date: '2024-05',
    lendingHousehold: 437.0, lendingCommercial: 642.0, lendingMortgage: 1283.8, lendingBusiness: 885.0, lendingConsumer: 116.6,
    depositHousehold: 1551.0, depositCommercial: 1088.5, depositWholesale: 523.2,
    assetSecurities: 478.8, assetCash: 148.0, assetLiquid: 610.1, assetOther: 90.5,
    liabilityWholesale: 540.2, liabilityBonds: 330.0, liabilityCapital: 298.7, liabilityOther: 47.1,
    policyRate: 5.25, lendingRate: 6.65, depositRate: 3.70, wholesaleRate: 5.20, yield10Y: 3.88,
    indexYorkshireHumber: 108.1, indexWestYorkshire: 109.8, indexSouthYorkshire: 107.5, indexNorthYorkshire: 107.2, indexEastRiding: 107.5,
    rhinoMortgage: 49.2, rhinoCommercial: 63.6, rhinoDeposits: 108.4, rhinoWholesale: 14.6, rhinoCapital: 11.4
  },
  {
    date: '2024-06',
    lendingHousehold: 437.8, lendingCommercial: 644.0, lendingMortgage: 1285.5, lendingBusiness: 887.0, lendingConsumer: 117.0,
    depositHousehold: 1553.5, depositCommercial: 1090.8, depositWholesale: 525.6,
    assetSecurities: 480.5, assetCash: 149.5, assetLiquid: 611.8, assetOther: 90.8,
    liabilityWholesale: 542.0, liabilityBonds: 330.0, liabilityCapital: 299.8, liabilityOther: 47.5,
    policyRate: 5.25, lendingRate: 6.65, depositRate: 3.70, wholesaleRate: 5.18, yield10Y: 3.85,
    indexYorkshireHumber: 108.6, indexWestYorkshire: 110.4, indexSouthYorkshire: 107.9, indexNorthYorkshire: 107.7, indexEastRiding: 108.0,
    rhinoMortgage: 49.4, rhinoCommercial: 63.9, rhinoDeposits: 109.1, rhinoWholesale: 14.7, rhinoCapital: 11.5
  },
  {
    date: '2024-07',
    lendingHousehold: 438.4, lendingCommercial: 645.8, lendingMortgage: 1287.1, lendingBusiness: 888.8, lendingConsumer: 117.3,
    depositHousehold: 1555.8, depositCommercial: 1093.0, depositWholesale: 527.8,
    assetSecurities: 482.1, assetCash: 151.0, assetLiquid: 613.3, assetOther: 91.1,
    liabilityWholesale: 543.5, liabilityBonds: 332.0, liabilityCapital: 301.0, liabilityOther: 47.8,
    policyRate: 5.25, lendingRate: 6.62, depositRate: 3.68, wholesaleRate: 5.15, yield10Y: 3.81,
    indexYorkshireHumber: 109.0, indexWestYorkshire: 110.9, indexSouthYorkshire: 108.3, indexNorthYorkshire: 108.1, indexEastRiding: 108.4,
    rhinoMortgage: 49.6, rhinoCommercial: 64.1, rhinoDeposits: 109.7, rhinoWholesale: 14.8, rhinoCapital: 11.6
  },
  {
    date: '2024-08',
    lendingHousehold: 439.1, lendingCommercial: 647.5, lendingMortgage: 1288.8, lendingBusiness: 890.5, lendingConsumer: 117.6,
    depositHousehold: 1558.1, depositCommercial: 1095.2, depositWholesale: 530.1,
    assetSecurities: 483.8, assetCash: 152.5, assetLiquid: 615.0, assetOther: 91.4,
    liabilityWholesale: 545.2, liabilityBonds: 332.0, liabilityCapital: 302.1, liabilityOther: 48.1,
    policyRate: 5.00, lendingRate: 6.45, depositRate: 3.48, wholesaleRate: 4.90, yield10Y: 3.72,
    indexYorkshireHumber: 109.5, indexWestYorkshire: 111.5, indexSouthYorkshire: 108.8, indexNorthYorkshire: 108.6, indexEastRiding: 108.9,
    rhinoMortgage: 49.8, rhinoCommercial: 64.4, rhinoDeposits: 110.4, rhinoWholesale: 15.0, rhinoCapital: 11.7
  },
  {
    date: '2024-09',
    lendingHousehold: 439.9, lendingCommercial: 649.2, lendingMortgage: 1290.5, lendingBusiness: 892.4, lendingConsumer: 118.0,
    depositHousehold: 1560.4, depositCommercial: 1097.5, depositWholesale: 532.4,
    assetSecurities: 485.4, assetCash: 154.0, assetLiquid: 616.6, assetOther: 91.8,
    liabilityWholesale: 546.9, liabilityBonds: 335.0, liabilityCapital: 303.2, liabilityOther: 48.5,
    policyRate: 5.00, lendingRate: 6.42, depositRate: 3.45, wholesaleRate: 4.88, yield10Y: 3.68,
    indexYorkshireHumber: 110.0, indexWestYorkshire: 112.1, indexSouthYorkshire: 109.2, indexNorthYorkshire: 109.1, indexEastRiding: 109.4,
    rhinoMortgage: 50.0, rhinoCommercial: 64.7, rhinoDeposits: 111.0, rhinoWholesale: 15.1, rhinoCapital: 11.8
  },
  {
    date: '2024-10',
    lendingHousehold: 440.5, lendingCommercial: 651.0, lendingMortgage: 1292.1, lendingBusiness: 894.1, lendingConsumer: 118.3,
    depositHousehold: 1562.8, depositCommercial: 1099.8, depositWholesale: 534.8,
    assetSecurities: 487.1, assetCash: 155.5, assetLiquid: 618.3, assetOther: 92.1,
    liabilityWholesale: 548.5, liabilityBonds: 335.0, liabilityCapital: 304.3, liabilityOther: 48.8,
    policyRate: 5.00, lendingRate: 6.40, depositRate: 3.42, wholesaleRate: 4.85, yield10Y: 3.64,
    indexYorkshireHumber: 110.4, indexWestYorkshire: 112.6, indexSouthYorkshire: 109.6, indexNorthYorkshire: 109.5, indexEastRiding: 109.8,
    rhinoMortgage: 50.2, rhinoCommercial: 65.0, rhinoDeposits: 111.7, rhinoWholesale: 15.2, rhinoCapital: 11.9
  },
  {
    date: '2024-11',
    lendingHousehold: 441.2, lendingCommercial: 652.8, lendingMortgage: 1293.8, lendingBusiness: 895.9, lendingConsumer: 118.6,
    depositHousehold: 1565.1, depositCommercial: 1102.1, depositWholesale: 537.1,
    assetSecurities: 488.8, assetCash: 157.0, assetLiquid: 620.0, assetOther: 92.4,
    liabilityWholesale: 550.2, liabilityBonds: 338.0, liabilityCapital: 305.4, liabilityOther: 49.1,
    policyRate: 4.75, lendingRate: 6.20, depositRate: 3.25, wholesaleRate: 4.60, yield10Y: 3.55,
    indexYorkshireHumber: 110.9, indexWestYorkshire: 113.2, indexSouthYorkshire: 110.1, indexNorthYorkshire: 110.0, indexEastRiding: 110.3,
    rhinoMortgage: 50.4, rhinoCommercial: 65.3, rhinoDeposits: 112.3, rhinoWholesale: 15.4, rhinoCapital: 12.0
  },
  {
    date: '2024-12',
    lendingHousehold: 442.0, lendingCommercial: 654.5, lendingMortgage: 1295.4, lendingBusiness: 897.8, lendingConsumer: 119.0,
    depositHousehold: 1567.5, depositCommercial: 1104.5, depositWholesale: 539.5,
    assetSecurities: 490.5, assetCash: 158.5, assetLiquid: 621.7, assetOther: 92.8,
    liabilityWholesale: 552.0, liabilityBonds: 338.0, liabilityCapital: 306.6, liabilityOther: 49.5,
    policyRate: 4.75, lendingRate: 6.18, depositRate: 3.22, wholesaleRate: 4.58, yield10Y: 3.50,
    indexYorkshireHumber: 111.4, indexWestYorkshire: 113.8, indexSouthYorkshire: 110.6, indexNorthYorkshire: 110.5, indexEastRiding: 110.8,
    rhinoMortgage: 50.6, rhinoCommercial: 65.6, rhinoDeposits: 113.0, rhinoWholesale: 15.5, rhinoCapital: 12.1
  },
  {
    date: '2025-01',
    lendingHousehold: 443.1, lendingCommercial: 656.8, lendingMortgage: 1297.8, lendingBusiness: 900.2, lendingConsumer: 119.5,
    depositHousehold: 1570.4, depositCommercial: 1107.2, depositWholesale: 542.4,
    assetSecurities: 492.4, assetCash: 160.2, assetLiquid: 623.5, assetOther: 93.1,
    liabilityWholesale: 554.0, liabilityBonds: 340.0, liabilityCapital: 308.0, liabilityOther: 49.9,
    policyRate: 4.50, lendingRate: 5.95, depositRate: 3.00, wholesaleRate: 4.35, yield10Y: 3.42,
    indexYorkshireHumber: 112.0, indexWestYorkshire: 114.5, indexSouthYorkshire: 111.1, indexNorthYorkshire: 111.1, indexEastRiding: 111.3,
    rhinoMortgage: 50.9, rhinoCommercial: 65.9, rhinoDeposits: 113.8, rhinoWholesale: 15.7, rhinoCapital: 12.2
  },
  {
    date: '2025-02',
    lendingHousehold: 444.2, lendingCommercial: 659.1, lendingMortgage: 1300.2, lendingBusiness: 902.5, lendingConsumer: 120.1,
    depositHousehold: 1573.2, depositCommercial: 1110.1, depositWholesale: 545.2,
    assetSecurities: 494.2, assetCash: 162.0, assetLiquid: 625.2, assetOther: 93.5,
    liabilityWholesale: 556.1, liabilityBonds: 340.0, liabilityCapital: 309.2, liabilityOther: 50.2,
    policyRate: 4.50, lendingRate: 5.92, depositRate: 2.98, wholesaleRate: 4.32, yield10Y: 3.38,
    indexYorkshireHumber: 112.6, indexWestYorkshire: 115.1, indexSouthYorkshire: 111.7, indexNorthYorkshire: 111.7, indexEastRiding: 111.9,
    rhinoMortgage: 51.1, rhinoCommercial: 66.2, rhinoDeposits: 114.6, rhinoWholesale: 15.8, rhinoCapital: 12.3
  },
  {
    date: '2025-03',
    lendingHousehold: 445.3, lendingCommercial: 661.5, lendingMortgage: 1302.5, lendingBusiness: 905.0, lendingConsumer: 120.6,
    depositHousehold: 1576.1, depositCommercial: 1112.9, depositWholesale: 548.1,
    assetSecurities: 496.1, assetCash: 163.7, assetLiquid: 627.0, assetOther: 93.9,
    liabilityWholesale: 558.1, liabilityBonds: 342.0, liabilityCapital: 310.5, liabilityOther: 50.6,
    policyRate: 4.25, lendingRate: 5.70, depositRate: 2.75, wholesaleRate: 4.10, yield10Y: 3.32,
    indexYorkshireHumber: 113.1, indexWestYorkshire: 115.8, indexSouthYorkshire: 112.2, indexNorthYorkshire: 112.2, indexEastRiding: 112.4,
    rhinoMortgage: 51.4, rhinoCommercial: 66.5, rhinoDeposits: 115.4, rhinoWholesale: 16.0, rhinoCapital: 12.4
  },
  {
    date: '2025-04',
    lendingHousehold: 446.4, lendingCommercial: 663.8, lendingMortgage: 1304.9, lendingBusiness: 907.4, lendingConsumer: 121.2,
    depositHousehold: 1579.0, depositCommercial: 1115.8, depositWholesale: 551.0,
    assetSecurities: 498.0, assetCash: 165.5, assetLiquid: 628.7, assetOther: 94.2,
    liabilityWholesale: 560.1, liabilityBonds: 342.0, liabilityCapital: 311.7, liabilityOther: 50.9,
    policyRate: 4.25, lendingRate: 5.68, depositRate: 2.72, wholesaleRate: 4.08, yield10Y: 3.30,
    indexYorkshireHumber: 113.7, indexWestYorkshire: 116.5, indexSouthYorkshire: 112.8, indexNorthYorkshire: 112.8, indexEastRiding: 113.0,
    rhinoMortgage: 51.6, rhinoCommercial: 66.8, rhinoDeposits: 116.2, rhinoWholesale: 16.1, rhinoCapital: 12.5
  },
  {
    date: '2025-05',
    lendingHousehold: 447.5, lendingCommercial: 666.2, lendingMortgage: 1307.2, lendingBusiness: 909.8, lendingConsumer: 121.7,
    depositHousehold: 1581.9, depositCommercial: 1118.6, depositWholesale: 553.9,
    assetSecurities: 499.9, assetCash: 167.2, assetLiquid: 630.5, assetOther: 94.6,
    liabilityWholesale: 562.1, liabilityBonds: 345.0, liabilityCapital: 313.0, liabilityOther: 51.3,
    policyRate: 4.00, lendingRate: 5.45, depositRate: 2.50, wholesaleRate: 3.82, yield10Y: 3.22,
    indexYorkshireHumber: 114.3, indexWestYorkshire: 117.2, indexSouthYorkshire: 113.4, indexNorthYorkshire: 113.4, indexEastRiding: 113.6,
    rhinoMortgage: 51.9, rhinoCommercial: 67.1, rhinoDeposits: 117.0, rhinoWholesale: 16.3, rhinoCapital: 12.6
  },
  {
    date: '2025-06',
    lendingHousehold: 448.6, lendingCommercial: 668.5, lendingMortgage: 1309.6, lendingBusiness: 912.2, lendingConsumer: 122.3,
    depositHousehold: 1584.8, depositCommercial: 1121.5, depositWholesale: 556.8,
    assetSecurities: 501.8, assetCash: 169.0, assetLiquid: 632.2, assetOther: 95.0,
    liabilityWholesale: 564.1, liabilityBonds: 345.0, liabilityCapital: 314.2, liabilityOther: 51.6,
    policyRate: 4.00, lendingRate: 5.42, depositRate: 2.48, wholesaleRate: 3.80, yield10Y: 3.20,
    indexYorkshireHumber: 114.9, indexWestYorkshire: 117.9, indexSouthYorkshire: 114.0, indexNorthYorkshire: 114.0, indexEastRiding: 114.2,
    rhinoMortgage: 52.1, rhinoCommercial: 67.4, rhinoDeposits: 117.8, rhinoWholesale: 16.4, rhinoCapital: 12.7
  },
  {
    date: '2025-07',
    lendingHousehold: 449.6, lendingCommercial: 670.8, lendingMortgage: 1311.8, lendingBusiness: 914.5, lendingConsumer: 122.8,
    depositHousehold: 1587.5, depositCommercial: 1124.2, depositWholesale: 559.5,
    assetSecurities: 503.6, assetCash: 170.6, assetLiquid: 633.9, assetOther: 95.3,
    liabilityWholesale: 565.9, liabilityBonds: 348.0, liabilityCapital: 315.4, liabilityOther: 51.9,
    policyRate: 3.75, lendingRate: 5.20, depositRate: 2.25, wholesaleRate: 3.55, yield10Y: 3.12,
    indexYorkshireHumber: 115.4, indexWestYorkshire: 118.5, indexSouthYorkshire: 114.5, indexNorthYorkshire: 114.5, indexEastRiding: 114.7,
    rhinoMortgage: 52.4, rhinoCommercial: 67.7, rhinoDeposits: 118.5, rhinoWholesale: 16.6, rhinoCapital: 12.8
  },
  {
    date: '2025-08',
    lendingHousehold: 450.7, lendingCommercial: 673.1, lendingMortgage: 1314.1, lendingBusiness: 916.8, lendingConsumer: 123.4,
    depositHousehold: 1590.4, depositCommercial: 1127.1, depositWholesale: 562.4,
    assetSecurities: 505.5, assetCash: 172.3, assetLiquid: 635.6, assetOther: 95.7,
    liabilityWholesale: 567.9, liabilityBonds: 348.0, liabilityCapital: 316.6, liabilityOther: 52.3,
    policyRate: 3.50, lendingRate: 4.95, depositRate: 2.00, wholesaleRate: 3.30, yield10Y: 3.05,
    indexYorkshireHumber: 116.0, indexWestYorkshire: 119.2, indexSouthYorkshire: 115.1, indexNorthYorkshire: 115.1, indexEastRiding: 115.3,
    rhinoMortgage: 52.6, rhinoCommercial: 68.0, rhinoDeposits: 119.3, rhinoWholesale: 16.8, rhinoCapital: 12.9
  },
  {
    date: '2025-09',
    lendingHousehold: 451.8, lendingCommercial: 675.4, lendingMortgage: 1316.4, lendingBusiness: 919.2, lendingConsumer: 123.9,
    depositHousehold: 1593.2, depositCommercial: 1129.9, depositWholesale: 565.2,
    assetSecurities: 507.3, assetCash: 174.0, assetLiquid: 637.3, assetOther: 96.1,
    liabilityWholesale: 569.8, liabilityBonds: 350.0, liabilityCapital: 317.8, liabilityOther: 52.6,
    policyRate: 3.50, lendingRate: 4.92, depositRate: 1.98, wholesaleRate: 3.28, yield10Y: 3.02,
    indexYorkshireHumber: 116.6, indexWestYorkshire: 119.9, indexSouthYorkshire: 115.7, indexNorthYorkshire: 115.7, indexEastRiding: 115.9,
    rhinoMortgage: 52.9, rhinoCommercial: 68.3, rhinoDeposits: 120.1, rhinoWholesale: 16.9, rhinoCapital: 13.0
  },
  {
    date: '2025-10',
    lendingHousehold: 452.8, lendingCommercial: 677.6, lendingMortgage: 1318.6, lendingBusiness: 921.5, lendingConsumer: 124.4,
    depositHousehold: 1595.9, depositCommercial: 1132.6, depositWholesale: 567.9,
    assetSecurities: 509.1, assetCash: 175.5, assetLiquid: 638.9, assetOther: 96.4,
    liabilityWholesale: 571.6, liabilityBonds: 350.0, liabilityCapital: 319.0, liabilityOther: 52.9,
    policyRate: 3.25, lendingRate: 4.70, depositRate: 1.75, wholesaleRate: 3.05, yield10Y: 2.94,
    indexYorkshireHumber: 117.1, indexWestYorkshire: 120.5, indexSouthYorkshire: 116.2, indexNorthYorkshire: 116.2, indexEastRiding: 116.4,
    rhinoMortgage: 53.1, rhinoCommercial: 68.6, rhinoDeposits: 120.8, rhinoWholesale: 17.1, rhinoCapital: 13.1
  },
  {
    date: '2025-11',
    lendingHousehold: 453.9, lendingCommercial: 679.9, lendingMortgage: 1320.9, lendingBusiness: 923.9, lendingConsumer: 124.9,
    depositHousehold: 1598.8, depositCommercial: 1135.5, depositWholesale: 570.8,
    assetSecurities: 511.0, assetCash: 177.2, assetLiquid: 640.6, assetOther: 96.8,
    liabilityWholesale: 573.6, liabilityBonds: 352.0, liabilityCapital: 320.2, liabilityOther: 53.3,
    policyRate: 3.25, lendingRate: 4.68, depositRate: 1.72, wholesaleRate: 3.02, yield10Y: 2.92,
    indexYorkshireHumber: 117.7, indexWestYorkshire: 121.2, indexSouthYorkshire: 116.8, indexNorthYorkshire: 116.8, indexEastRiding: 117.0,
    rhinoMortgage: 53.4, rhinoCommercial: 68.9, rhinoDeposits: 121.6, rhinoWholesale: 17.3, rhinoCapital: 13.2
  },
  {
    date: '2025-12',
    lendingHousehold: 455.0, lendingCommercial: 682.2, lendingMortgage: 1323.2, lendingBusiness: 926.2, lendingConsumer: 125.5,
    depositHousehold: 1601.7, depositCommercial: 1138.4, depositWholesale: 573.7,
    assetSecurities: 512.9, assetCash: 179.0, assetLiquid: 642.3, assetOther: 97.2,
    liabilityWholesale: 575.6, liabilityBonds: 352.0, liabilityCapital: 321.4, liabilityOther: 53.6,
    policyRate: 3.00, lendingRate: 4.45, depositRate: 1.50, wholesaleRate: 2.80, yield10Y: 2.82,
    indexYorkshireHumber: 118.3, indexWestYorkshire: 121.9, indexSouthYorkshire: 117.4, indexNorthYorkshire: 117.4, indexEastRiding: 117.6,
    rhinoMortgage: 53.6, rhinoCommercial: 69.2, rhinoDeposits: 122.4, rhinoWholesale: 17.4, rhinoCapital: 13.3
  },
  {
    date: '2026-01',
    lendingHousehold: 456.1, lendingCommercial: 684.5, lendingMortgage: 1325.5, lendingBusiness: 928.6, lendingConsumer: 126.0,
    depositHousehold: 1604.6, depositCommercial: 1141.3, depositWholesale: 576.6,
    assetSecurities: 514.8, assetCash: 180.7, assetLiquid: 644.0, assetOther: 97.5,
    liabilityWholesale: 577.6, liabilityBonds: 355.0, liabilityCapital: 322.6, liabilityOther: 54.0,
    policyRate: 3.00, lendingRate: 4.42, depositRate: 1.48, wholesaleRate: 2.78, yield10Y: 2.80,
    indexYorkshireHumber: 118.9, indexWestYorkshire: 122.6, indexSouthYorkshire: 118.0, indexNorthYorkshire: 118.0, indexEastRiding: 118.2,
    rhinoMortgage: 53.9, rhinoCommercial: 69.5, rhinoDeposits: 123.1, rhinoWholesale: 17.6, rhinoCapital: 13.4
  },
  {
    date: '2026-02',
    lendingHousehold: 457.2, lendingCommercial: 686.8, lendingMortgage: 1327.8, lendingBusiness: 931.0, lendingConsumer: 126.6,
    depositHousehold: 1607.5, depositCommercial: 1144.2, depositWholesale: 579.5,
    assetSecurities: 516.7, assetCash: 182.5, assetLiquid: 645.7, assetOther: 97.9,
    liabilityWholesale: 579.6, liabilityBonds: 355.0, liabilityCapital: 323.8, liabilityOther: 54.3,
    policyRate: 3.00, lendingRate: 4.40, depositRate: 1.45, wholesaleRate: 2.75, yield10Y: 2.78,
    indexYorkshireHumber: 119.5, indexWestYorkshire: 123.3, indexSouthYorkshire: 118.6, indexNorthYorkshire: 118.6, indexEastRiding: 118.8,
    rhinoMortgage: 54.1, rhinoCommercial: 69.8, rhinoDeposits: 123.9, rhinoWholesale: 17.7, rhinoCapital: 13.5
  },
  {
    date: '2026-03',
    lendingHousehold: 458.3, lendingCommercial: 689.1, lendingMortgage: 1330.1, lendingBusiness: 933.4, lendingConsumer: 127.1,
    depositHousehold: 1610.4, depositCommercial: 1147.1, depositWholesale: 582.4,
    assetSecurities: 518.6, assetCash: 184.2, assetLiquid: 647.4, assetOther: 98.2,
    liabilityWholesale: 581.6, liabilityBonds: 358.0, liabilityCapital: 325.0, liabilityOther: 54.7,
    policyRate: 2.75, lendingRate: 4.15, depositRate: 1.25, wholesaleRate: 2.50, yield10Y: 2.70,
    indexYorkshireHumber: 120.1, indexWestYorkshire: 124.0, indexSouthYorkshire: 119.2, indexNorthYorkshire: 119.2, indexEastRiding: 119.4,
    rhinoMortgage: 54.4, rhinoCommercial: 70.1, rhinoDeposits: 124.6, rhinoWholesale: 17.9, rhinoCapital: 13.6
  },
  {
    date: '2026-04',
    lendingHousehold: 459.4, lendingCommercial: 691.4, lendingMortgage: 1332.4, lendingBusiness: 935.8, lendingConsumer: 127.7,
    depositHousehold: 1613.3, depositCommercial: 1150.0, depositWholesale: 585.3,
    assetSecurities: 520.5, assetCash: 186.0, assetLiquid: 649.1, assetOther: 98.6,
    liabilityWholesale: 583.6, liabilityBonds: 358.0, liabilityCapital: 326.2, liabilityOther: 55.0,
    policyRate: 2.75, lendingRate: 4.12, depositRate: 1.22, wholesaleRate: 2.48, yield10Y: 2.68,
    indexYorkshireHumber: 120.7, indexWestYorkshire: 124.7, indexSouthYorkshire: 119.8, indexNorthYorkshire: 119.8, indexEastRiding: 120.0,
    rhinoMortgage: 54.6, rhinoCommercial: 70.4, rhinoDeposits: 125.4, rhinoWholesale: 18.0, rhinoCapital: 13.7
  },
  {
    date: '2026-05',
    lendingHousehold: 460.5, lendingCommercial: 693.8, lendingMortgage: 1334.7, lendingBusiness: 938.2, lendingConsumer: 128.2,
    depositHousehold: 1616.2, depositCommercial: 1152.9, depositWholesale: 588.2,
    assetSecurities: 522.4, assetCash: 187.7, assetLiquid: 650.8, assetOther: 98.9,
    liabilityWholesale: 585.6, liabilityBonds: 360.0, liabilityCapital: 327.4, liabilityOther: 55.4,
    policyRate: 2.50, lendingRate: 3.90, depositRate: 1.00, wholesaleRate: 2.22, yield10Y: 2.60,
    indexYorkshireHumber: 121.3, indexWestYorkshire: 125.4, indexSouthYorkshire: 120.4, indexNorthYorkshire: 120.4, indexEastRiding: 120.6,
    rhinoMortgage: 54.9, rhinoCommercial: 70.7, rhinoDeposits: 126.1, rhinoWholesale: 18.2, rhinoCapital: 13.8
  },
  {
    date: '2026-06',
    lendingHousehold: 461.6, lendingCommercial: 696.1, lendingMortgage: 1337.0, lendingBusiness: 940.6, lendingConsumer: 128.8,
    depositHousehold: 1619.1, depositCommercial: 1155.8, depositWholesale: 591.1,
    assetSecurities: 524.3, assetCash: 189.5, assetLiquid: 652.5, assetOther: 99.3,
    liabilityWholesale: 587.6, liabilityBonds: 360.0, liabilityCapital: 328.6, liabilityOther: 55.7,
    policyRate: 2.50, lendingRate: 3.88, depositRate: 0.98, wholesaleRate: 2.20, yield10Y: 2.58,
    indexYorkshireHumber: 121.9, indexWestYorkshire: 126.1, indexSouthYorkshire: 121.0, indexNorthYorkshire: 121.0, indexEastRiding: 121.2,
    rhinoMortgage: 55.1, rhinoCommercial: 71.0, rhinoDeposits: 126.9, rhinoWholesale: 18.3, rhinoCapital: 13.9
  }
];

// Configurable Scenarios for the Laboratory
export const SCENARIOS: Scenario[] = [
  {
    id: 'baseline',
    name: 'Baseline Projection',
    description: 'The standard path under current macroeconomic forecast. Interest rates stabilize, credit expansion aligns with historical productivity indices.',
    color: '#8A9A86', // Yorkshire Stone Sage
    lendingMultiplier: 1.0,
    depositMultiplier: 1.0,
    policyRateShift: 0.0,
    economicShift: 100.0
  },
  {
    id: 'credit_expansion',
    name: 'Optimistic Credit Surge',
    description: 'Commercial business investment accelerates and regional housing market experiences an upswing. Higher commercial lending and deposit creation.',
    color: '#D4AF37', // Copper Highlights / Warm Gold
    lendingMultiplier: 1.25,
    depositMultiplier: 1.20,
    policyRateShift: -0.50,
    economicShift: 112.5
  },
  {
    id: 'monetary_shock',
    name: 'Severe Adverse (Monetary Shock)',
    description: 'Central bank pivots to sudden hawkish tightening to combat inflation. Policy rates spike, lending volumes collapse, wholesale funding costs swell.',
    color: '#B22222', // Deep Madder Red
    lendingMultiplier: 0.70,
    depositMultiplier: 0.85,
    policyRateShift: 2.25,
    economicShift: 82.0
  },
  {
    id: 'yorkshire_boom',
    name: 'Yorkshire Industrial Revival',
    description: 'Targeted green energy and infrastructure investment in West Yorkshire & Humber triggers regional lending surge and business confidence.',
    color: '#3B5E8C', // Deep Steel Blue
    lendingMultiplier: 1.15,
    depositMultiplier: 1.12,
    policyRateShift: 0.25,
    economicShift: 108.0
  }
];

// Initial Regional Banking Indicators
export const REGIONAL_INDICATORS: RegionalIndicator[] = [
  { id: 'york_hum', name: 'Yorkshire & Humber', growth2026: 5.8, volatility: 2.1, commercialDensity: 82.5, mortgageShare: 64.2, totalLending: 2474.7, totalDeposits: 2774.9 },
  { id: 'west_york', name: 'West Yorkshire', growth2026: 6.1, volatility: 2.3, commercialDensity: 94.1, mortgageShare: 58.0, totalLending: 1242.1, totalDeposits: 1380.5 },
  { id: 'south_york', name: 'South Yorkshire', growth2026: 5.5, volatility: 1.9, commercialDensity: 88.4, mortgageShare: 61.5, totalLending: 590.2, totalDeposits: 672.4 },
  { id: 'north_york', name: 'North Yorkshire', growth2026: 5.2, volatility: 1.6, commercialDensity: 45.8, mortgageShare: 78.4, totalLending: 420.5, totalDeposits: 485.3 },
  { id: 'east_riding', name: 'East Riding', growth2026: 5.6, volatility: 1.8, commercialDensity: 52.0, mortgageShare: 71.2, totalLending: 221.9, totalDeposits: 236.7 }
];
