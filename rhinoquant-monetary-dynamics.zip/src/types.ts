/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface HistoricalDataPoint {
  date: string; // YYYY-MM
  
  // Credit Portfolios (Millions)
  lendingHousehold: number;
  lendingCommercial: number;
  lendingMortgage: number;
  lendingBusiness: number;
  lendingConsumer: number;

  // Deposit Portfolios (Millions)
  depositHousehold: number;
  depositCommercial: number;
  depositWholesale: number;
  
  // Banking System Balances (Millions)
  assetSecurities: number;
  assetCash: number;
  assetLiquid: number;
  assetOther: number;
  
  liabilityWholesale: number;
  liabilityBonds: number;
  liabilityCapital: number;
  liabilityOther: number;

  // Interest Rates (%)
  policyRate: number;
  lendingRate: number;
  depositRate: number;
  wholesaleRate: number;
  yield10Y: number;

  // Regional Lending Indices (Yorkshire counties base 100 in 2018)
  indexYorkshireHumber: number;
  indexWestYorkshire: number;
  indexSouthYorkshire: number;
  indexNorthYorkshire: number;
  indexEastRiding: number;

  // Rhino Bank Specifics (Millions)
  rhinoMortgage: number;
  rhinoCommercial: number;
  rhinoDeposits: number;
  rhinoWholesale: number;
  rhinoCapital: number;
}

export type ModellingFramework = 'textbook' | 'endogenous' | 'balanceSheet' | 'stockFlow';

export type EconometricMethod = 'regression' | 'var' | 'pca' | 'decomposition' | 'cointegration';

export type ForecastingMethod = 'arima' | 'ets' | 'var' | 'randomForest' | 'xgboost';

export type FrequencyType = 'monthly' | 'quarterly' | 'annual';

export interface MonetaryAggregates {
  date: string;
  m0: number; // Cash reserves + banknotes
  m1: number; // M0 + overnight customer deposits
  m2: number; // M1 + short-term savings deposits
  m3: number; // M2 + institutional deposits + repurchase agreements + debt securities (<2yr)
  m4: number; // Broad money
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  color: string;
  lendingMultiplier: number;
  depositMultiplier: number;
  policyRateShift: number; // percentage points
  economicShift: number; // index impact
}

export interface EconometricRegression {
  variable: string;
  coefficient: number;
  stdError: number;
  tStatistic: number;
  pValue: number;
  rSquared: number;
}

export interface EconometricPCA {
  components: {
    id: string;
    varianceExplained: number;
    cumulativeVariance: number;
    loadings: { [key: string]: number };
  }[];
}

export interface EconometricVAR {
  selectedLags: number;
  aic: number;
  sc: number;
  impulseResponse: {
    step: number;
    interestRateShockOnLending: number;
    interestRateShockOnDeposits: number;
    lendingShockOnDeposits: number;
  }[];
}

export interface EconometricDecompositionPoint {
  date: string;
  original: number;
  trend: number;
  seasonal: number;
  irregular: number;
}

export interface ForecastSeriesPoint {
  date: string;
  actual?: number;
  forecast?: number;
  lower95?: number;
  upper95?: number;
}

export interface RegionalIndicator {
  id: string;
  name: string;
  growth2026: number;
  volatility: number;
  commercialDensity: number;
  mortgageShare: number;
  totalLending: number;
  totalDeposits: number;
}
