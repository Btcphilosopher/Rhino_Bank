import React, { useState } from 'react';
import { RegulatoryFramework } from './types/capital';
import { mockRegulatoryRulesets, mockPortfolioExposures, initialCET1Components, initialAT1Components, initialTier2Components } from './data/mockData';
import { calculateCapitalHierarchy, calculateCapitalRatios, generateAuditLineage } from './engine/capitalEngine';
import { calculateTotalRWA } from './engine/rwaEngine';

import { Header } from './components/Header';
import { CapitalDashboard } from './components/CapitalDashboard';
import { CapitalStackVisualizer } from './components/CapitalStackVisualizer';
import { CapitalWaterfallView } from './components/CapitalWaterfallView';
import { CreditPortfolioView } from './components/CreditPortfolioView';
import { MarketAndIrrbbView } from './components/MarketAndIrrbbView';
import { CapitalConsumptionView } from './components/CapitalConsumptionView';
import { CapitalLabView } from './components/CapitalLabView';
import { StressTestView } from './components/StressTestView';
import { CapitalOptimizationView } from './components/CapitalOptimizationView';
import { CapitalForecastView } from './components/CapitalForecastView';
import { SensitivityMatrixView } from './components/SensitivityMatrixView';
import { CapitalSurface3DView } from './components/CapitalSurface3DView';
import { RegulatoryRulesetView } from './components/RegulatoryRulesetView';
import { AuditTrailModal } from './components/AuditTrailModal';
import { AiAdvisorView } from './components/AiAdvisorView';

export function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [activeRuleset, setActiveRuleset] = useState<RegulatoryFramework>('Basel_IV');
  const [isAuditOpen, setIsAuditOpen] = useState(false);

  const currentRuleset = mockRegulatoryRulesets[activeRuleset] || mockRegulatoryRulesets.Basel_IV;

  // Calculate Capital Engine Metrics
  const hierarchy = calculateCapitalHierarchy(initialCET1Components, initialAT1Components, initialTier2Components);
  const totalRWA = calculateTotalRWA(mockPortfolioExposures, currentRuleset, 14200, 4200);
  const ratios = calculateCapitalRatios(hierarchy, totalRWA.totalRWA, currentRuleset);
  const auditSteps = generateAuditLineage('CET1 Ratio', hierarchy, totalRWA.totalRWA, ratios, currentRuleset);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeRuleset={activeRuleset}
        onRulesetChange={setActiveRuleset}
        cet1Ratio={ratios.cet1Ratio}
        status={ratios.status}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === 'dashboard' && (
          <CapitalDashboard
            hierarchy={hierarchy}
            totalRWA={totalRWA.totalRWA}
            ratios={ratios}
            ruleset={currentRuleset}
            onOpenAudit={() => setIsAuditOpen(true)}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'waterfall' && (
          <div className="space-y-6">
            <CapitalStackVisualizer
              hierarchy={hierarchy}
              ratios={ratios}
              ruleset={currentRuleset}
            />
            <CapitalWaterfallView
              hierarchy={hierarchy}
              totalRWA={totalRWA.totalRWA}
              ratios={ratios}
            />
          </div>
        )}

        {activeTab === 'portfolio' && (
          <CreditPortfolioView
            exposures={mockPortfolioExposures}
            ruleset={currentRuleset}
          />
        )}

        {activeTab === 'market_irrbb' && (
          <MarketAndIrrbbView
            hierarchy={hierarchy}
            totalRWA={totalRWA.totalRWA}
          />
        )}

        {activeTab === 'consumption' && (
          <CapitalConsumptionView
            exposures={totalRWA.calculatedExposures}
          />
        )}

        {activeTab === 'lab' && (
          <CapitalLabView
            exposures={mockPortfolioExposures}
            hierarchy={hierarchy}
            ruleset={currentRuleset}
          />
        )}

        {activeTab === 'stress' && (
          <StressTestView
            exposures={mockPortfolioExposures}
            hierarchy={hierarchy}
            ruleset={currentRuleset}
          />
        )}

        {activeTab === 'optimization' && (
          <CapitalOptimizationView
            exposures={mockPortfolioExposures}
            ruleset={currentRuleset}
            cet1Capital={hierarchy.cet1.totalCET1}
          />
        )}

        {activeTab === 'forecast' && (
          <CapitalForecastView
            hierarchy={hierarchy}
            totalRWA={totalRWA.totalRWA}
            ruleset={currentRuleset}
          />
        )}

        {activeTab === 'surface_matrix' && (
          <div className="space-y-6">
            <SensitivityMatrixView
              exposures={mockPortfolioExposures}
              hierarchy={hierarchy}
              ruleset={currentRuleset}
            />
            <CapitalSurface3DView
              exposures={mockPortfolioExposures}
              hierarchy={hierarchy}
              ruleset={currentRuleset}
            />
          </div>
        )}

        {activeTab === 'rulesets' && (
          <RegulatoryRulesetView
            activeRuleset={activeRuleset}
            onSelectRuleset={setActiveRuleset}
          />
        )}

        {activeTab === 'ai_advisor' && (
          <AiAdvisorView
            ratios={ratios}
            ruleset={currentRuleset}
            totalRWA={totalRWA.totalRWA}
          />
        )}
      </main>

      {/* Audit Lineage Modal */}
      <AuditTrailModal
        isOpen={isAuditOpen}
        onClose={() => setIsAuditOpen(false)}
        auditSteps={auditSteps}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 mt-12 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-between items-center gap-2">
          <span>RHINOBANK CAPITAL REQUIREMENTS ENGINE • INSTITUTIONAL RISK ANALYTICS</span>
          <span>VASICEK IRB MODEL • BASEL IV OUTPUT FLOOR ENABLED</span>
        </div>
      </footer>
    </div>
  );
}

export default App;
