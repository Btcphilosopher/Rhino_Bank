import React, { useState } from 'react';
import { Layers, ShieldCheck, HelpCircle, CheckCircle2, ChevronDown, ChevronRight, Lock } from 'lucide-react';
import { CapitalHierarchy, CapitalRatios, RegulatoryRuleset } from '../types/capital';

interface CapitalStackVisualizerProps {
  hierarchy: CapitalHierarchy;
  ratios: CapitalRatios;
  ruleset: RegulatoryRuleset;
}

export const CapitalStackVisualizer: React.FC<CapitalStackVisualizerProps> = ({
  hierarchy,
  ratios,
  ruleset,
}) => {
  const [selectedLayer, setSelectedLayer] = useState<'CET1' | 'AT1' | 'Tier2' | 'Buffers' | null>('CET1');

  const { cet1, at1, tier2 } = hierarchy;
  const buf = ruleset.buffers;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 p-4 border border-slate-800 rounded-lg">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>Interactive Capital Hierarchy & Regulatory Stack</span>
          </h2>
          <p className="text-xs text-slate-400">
            Click any capital tier or regulatory buffer layer to inspect underlying regulatory deductions and instrument qualifications.
          </p>
        </div>
        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">TOTAL CAPITAL:</span>{' '}
            <span className="text-cyan-400 font-bold">${hierarchy.totalCapital.toLocaleString()}M</span>
          </div>
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">RWA:</span>{' '}
            <span className="text-slate-200 font-bold">${ratios.totalRWA.toLocaleString()}M</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Visual Stack Diagram */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3">
          <h3 className="text-xs font-mono uppercase text-slate-400 tracking-wider mb-3">Capital Stack Hierarchy</h3>

          {/* Layer 1: Tier 2 Capital */}
          <div
            onClick={() => setSelectedLayer('Tier2')}
            className={`p-3.5 rounded-lg border transition cursor-pointer flex items-center justify-between ${
              selectedLayer === 'Tier2'
                ? 'bg-purple-950/40 border-purple-500 text-purple-200 ring-1 ring-purple-500/50'
                : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 rounded-full bg-purple-500" />
              <div>
                <span className="font-semibold text-sm">Tier 2 Capital (Gone-Concern Capital)</span>
                <p className="text-xs text-slate-400">Subordinated Debt, Eligible Provisions, General Credit Reserves</p>
              </div>
            </div>
            <div className="text-right font-mono">
              <span className="text-sm font-bold text-purple-400">${tier2.totalTier2.toLocaleString()}M</span>
              <span className="block text-[10px] text-slate-500">+{((tier2.totalTier2 / ratios.totalRWA) * 100).toFixed(2)}% pts</span>
            </div>
          </div>

          {/* Layer 2: Additional Tier 1 (AT1) */}
          <div
            onClick={() => setSelectedLayer('AT1')}
            className={`p-3.5 rounded-lg border transition cursor-pointer flex items-center justify-between ${
              selectedLayer === 'AT1'
                ? 'bg-blue-950/40 border-blue-500 text-blue-200 ring-1 ring-blue-500/50'
                : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 rounded-full bg-blue-500" />
              <div>
                <span className="font-semibold text-sm">Additional Tier 1 Capital (AT1)</span>
                <p className="text-xs text-slate-400">Perpetual Contingent Convertible Notes (CoCos) with write-down triggers</p>
              </div>
            </div>
            <div className="text-right font-mono">
              <span className="text-sm font-bold text-blue-400">${at1.totalAT1.toLocaleString()}M</span>
              <span className="block text-[10px] text-slate-500">+{((at1.totalAT1 / ratios.totalRWA) * 100).toFixed(2)}% pts</span>
            </div>
          </div>

          {/* Layer 3: CET1 Capital */}
          <div
            onClick={() => setSelectedLayer('CET1')}
            className={`p-4 rounded-lg border transition cursor-pointer flex items-center justify-between ${
              selectedLayer === 'CET1'
                ? 'bg-emerald-950/40 border-emerald-500 text-emerald-200 ring-1 ring-emerald-500/50'
                : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 animate-pulse" />
              <div>
                <span className="font-semibold text-base text-emerald-300">Common Equity Tier 1 (CET1)</span>
                <p className="text-xs text-slate-400">Common Shares, Retained Earnings, AOCI, less Goodwill & Regulatory Deductions</p>
              </div>
            </div>
            <div className="text-right font-mono">
              <span className="text-base font-bold text-emerald-400">${cet1.totalCET1.toLocaleString()}M</span>
              <span className="block text-xs text-emerald-500/80 font-semibold">{ratios.cet1Ratio.toFixed(2)}% Ratio</span>
            </div>
          </div>

          {/* Divider: Capital Requirements Stack */}
          <div className="pt-3 pb-1 flex items-center space-x-2">
            <div className="flex-1 h-px bg-slate-800" />
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Mandatory Regulatory Buffers Stack</span>
            <div className="flex-1 h-px bg-slate-800" />
          </div>

          {/* Buffer Layer Stack */}
          <div
            onClick={() => setSelectedLayer('Buffers')}
            className={`p-4 rounded-lg border transition cursor-pointer space-y-2.5 ${
              selectedLayer === 'Buffers'
                ? 'bg-amber-950/30 border-amber-500/60 ring-1 ring-amber-500/40'
                : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-semibold text-amber-300 flex items-center space-x-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Combined Buffer Requirement (CBR): {ratios.combinedBufferReq.toFixed(2)}%</span>
              </span>
              <span className="text-xs font-mono text-amber-400 font-bold">
                ${((ratios.totalRWA * ratios.combinedBufferReq) / 100).toLocaleString()}M
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800/80 flex justify-between items-center">
                <span className="text-slate-400">Capital Conservation Buffer (CCb)</span>
                <span className="font-mono text-slate-200 font-bold">{buf.capitalConservationBuffer}%</span>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800/80 flex justify-between items-center">
                <span className="text-slate-400">Countercyclical Buffer (CCyB)</span>
                <span className="font-mono text-slate-200 font-bold">{buf.countercyclicalBuffer}%</span>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800/80 flex justify-between items-center">
                <span className="text-slate-400">G-SIB / D-SIB Systemic Buffer</span>
                <span className="font-mono text-slate-200 font-bold">{buf.gsibBuffer}%</span>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800/80 flex justify-between items-center">
                <span className="text-slate-400">Pillar 2A Regulatory Add-on</span>
                <span className="font-mono text-slate-200 font-bold">{buf.pillar2A}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Component Inspector Panel */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5">
          {selectedLayer === 'CET1' && (
            <div className="space-y-4">
              <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                <h4 className="text-sm font-semibold text-emerald-400 flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span>CET1 Component Inspector</span>
                </h4>
                <span className="font-mono text-xs text-slate-400">${cet1.totalCET1.toLocaleString()}M Total</span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Common Stock & Share Capital</span>
                  <span className="font-mono font-bold text-slate-100">${cet1.commonShares.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Share Premium Reserves</span>
                  <span className="font-mono font-bold text-slate-100">${cet1.sharePremium.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Retained Earnings (Audited)</span>
                  <span className="font-mono font-bold text-emerald-400">+${cet1.retainedEarnings.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Accumulated Other Comprehensive Income (AOCI)</span>
                  <span className="font-mono font-bold text-slate-200">${cet1.aoci.toLocaleString()}M</span>
                </div>

                <div className="pt-2">
                  <span className="text-[10px] font-mono uppercase text-rose-400 tracking-wider">Regulatory Adjustments & Deductions</span>
                  <div className="mt-1 space-y-1">
                    <div className="flex justify-between p-1.5 rounded bg-rose-950/20 text-rose-300 text-[11px] border border-rose-900/30">
                      <span>Goodwill Deduction</span>
                      <span className="font-mono font-semibold">${cet1.lessGoodwill.toLocaleString()}M</span>
                    </div>
                    <div className="flex justify-between p-1.5 rounded bg-rose-950/20 text-rose-300 text-[11px] border border-rose-900/30">
                      <span>Other Intangible Assets Deduction</span>
                      <span className="font-mono font-semibold">${cet1.lessIntangibles.toLocaleString()}M</span>
                    </div>
                    <div className="flex justify-between p-1.5 rounded bg-rose-950/20 text-rose-300 text-[11px] border border-rose-900/30">
                      <span>Deferred Tax Assets (DTA) Deduction</span>
                      <span className="font-mono font-semibold">${cet1.lessDta.toLocaleString()}M</span>
                    </div>
                    <div className="flex justify-between p-1.5 rounded bg-rose-950/20 text-rose-300 text-[11px] border border-rose-900/30">
                      <span>Prudential Valuation Adjustment (PVA)</span>
                      <span className="font-mono font-semibold">${cet1.lessPrudentialValuation.toLocaleString()}M</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {selectedLayer === 'AT1' && (
            <div className="space-y-4">
              <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                <h4 className="text-sm font-semibold text-blue-400 flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  <span>AT1 Instrument Qualification</span>
                </h4>
                <span className="font-mono text-xs text-slate-400">${at1.totalAT1.toLocaleString()}M Total</span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Qualifying Perpetual AT1 CoCo Securities</span>
                  <span className="font-mono font-bold text-blue-400">${at1.qualifyingAT1Instruments.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Share Premium AT1</span>
                  <span className="font-mono font-bold text-slate-200">${at1.sharePremiumAT1.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-rose-950/20 text-rose-300 border border-rose-900/30">
                  <span>Deductions / Limits Applied</span>
                  <span className="font-mono font-bold">${at1.lessDeductionsAT1.toLocaleString()}M</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 text-xs text-slate-400 space-y-1">
                <span className="font-semibold text-slate-200 block">AT1 Qualification Rules:</span>
                <p>• Must be perpetual without incentive to redeem.</p>
                <p>• Mandatory loss-absorption trigger at minimum 5.125% or 7.0% CET1 ratio.</p>
                <p>• Full discretion to cancel distributions at any time.</p>
              </div>
            </div>
          )}

          {selectedLayer === 'Tier2' && (
            <div className="space-y-4">
              <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                <h4 className="text-sm font-semibold text-purple-400 flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                  <span>Tier 2 Instrument Details</span>
                </h4>
                <span className="font-mono text-xs text-slate-400">${tier2.totalTier2.toLocaleString()}M Total</span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Subordinated Debt (Min 5-Yr Maturity)</span>
                  <span className="font-mono font-bold text-purple-400">${tier2.subordinatedDebt.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">Eligible Provisions under IRB Method</span>
                  <span className="font-mono font-bold text-slate-200">${tier2.eligibleProvisions.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-300">General Credit Risk Adjustments (Standardized)</span>
                  <span className="font-mono font-bold text-slate-200">${tier2.generalCreditRiskAdjustments.toLocaleString()}M</span>
                </div>
              </div>
            </div>
          )}

          {selectedLayer === 'Buffers' && (
            <div className="space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h4 className="text-sm font-semibold text-amber-400">Combined Buffer Breakdown</h4>
                <p className="text-xs text-slate-400">Active ruleset buffer requirements configured for RhinoBank</p>
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded bg-slate-950/60 border border-slate-800 flex justify-between">
                  <div>
                    <span className="text-slate-200 font-semibold block">Capital Conservation Buffer (CCb)</span>
                    <span className="text-[10px] text-slate-400">Fixed mandatory buffer to absorb stress</span>
                  </div>
                  <span className="font-mono text-amber-400 font-bold">{buf.capitalConservationBuffer}%</span>
                </div>

                <div className="p-2.5 rounded bg-slate-950/60 border border-slate-800 flex justify-between">
                  <div>
                    <span className="text-slate-200 font-semibold block">Countercyclical Buffer (CCyB)</span>
                    <span className="text-[10px] text-slate-400">Macroprudential buffer set by national authorities</span>
                  </div>
                  <span className="font-mono text-amber-400 font-bold">{buf.countercyclicalBuffer}%</span>
                </div>

                <div className="p-2.5 rounded bg-slate-950/60 border border-slate-800 flex justify-between">
                  <div>
                    <span className="text-slate-200 font-semibold block">Systemic Buffer (G-SIB / D-SIB)</span>
                    <span className="text-[10px] text-slate-400">Institution-specific systemic importance bucket</span>
                  </div>
                  <span className="font-mono text-amber-400 font-bold">{buf.gsibBuffer}%</span>
                </div>

                <div className="p-2.5 rounded bg-slate-950/60 border border-slate-800 flex justify-between">
                  <div>
                    <span className="text-slate-200 font-semibold block">Pillar 2A Add-on</span>
                    <span className="text-[10px] text-slate-400">Supervisory risk assessment requirement</span>
                  </div>
                  <span className="font-mono text-amber-400 font-bold">{buf.pillar2A}%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
