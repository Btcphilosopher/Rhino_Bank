import React, { useState } from 'react';
import { Sparkles, Send, ShieldCheck, Loader2, Bot, BookOpen } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { CapitalRatios, RegulatoryRuleset, TotalRWA } from '../types/capital';

interface AiAdvisorViewProps {
  ratios: CapitalRatios;
  ruleset: RegulatoryRuleset;
  totalRWA: TotalRWA;
}

export const AiAdvisorView: React.FC<AiAdvisorViewProps> = ({
  ratios,
  ruleset,
  totalRWA,
}) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);

  const presets = [
    'Audit Basel IV Output Floor impact on internal IRB models',
    'Formulate RWA reduction strategy for CRE and High-Density Corporates',
    'Draft ICAAP Capital Buffer Stress Test Defense Memo',
    'Assess Impact of +200bp Interest Rate Shock on CET1 & EVE',
  ];

  const handleAsk = async (userPrompt?: string) => {
    const activeQuery = userPrompt || query;
    if (!activeQuery.trim()) return;

    setLoading(true);
    try {
      const res = await fetch('/api/ai-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: activeQuery,
          capitalContext: {
            rulesetName: ruleset.name,
            cet1Ratio: ratios.cet1Ratio,
            targetRatio: ratios.totalTargetCET1Ratio,
            totalRwa: totalRWA.finalTotalRWA,
            outputFloorApplied: totalRWA.outputFloorApplied,
            headroomAmount: ratios.cet1SurplusDeficitAmount,
            headroomPct: ratios.cet1HeadroomPercentage,
          },
        }),
      });

      const data = await res.json();
      setResponse(data.advice || 'No response returned.');
    } catch (err) {
      setResponse('Failed to reach AI Advisor endpoint. Check network or server status.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-cyan-500/10 rounded-lg text-cyan-400 border border-cyan-500/20">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-slate-100">RhinoBank Regulatory & ICAAP Strategy Advisor</h2>
            <p className="text-xs text-slate-400">
              Powered by Gemini 3.7 — Institutional quantitative risk engineering & Basel compliance intelligence.
            </p>
          </div>
        </div>
      </div>

      {/* Preset Prompts Row */}
      <div className="flex flex-wrap gap-2">
        {presets.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => {
              setQuery(preset);
              handleAsk(preset);
            }}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg text-xs font-medium transition cursor-pointer flex items-center space-x-1.5"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>{preset}</span>
          </button>
        ))}
      </div>

      {/* Query Input Form */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 flex items-center space-x-3">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
          placeholder="Ask AI Advisor about regulatory capital optimization, Basel IV rules, ICAAP buffer defense..."
          className="flex-1 bg-transparent text-slate-100 text-xs placeholder-slate-500 focus:outline-none px-2"
        />
        <button
          onClick={() => handleAsk()}
          disabled={loading}
          className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs rounded transition flex items-center space-x-1.5 cursor-pointer shadow-md shadow-cyan-950 disabled:opacity-50"
        >
          {loading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <>
              <Send className="w-3.5 h-3.5" />
              <span>Ask Advisor</span>
            </>
          )}
        </button>
      </div>

      {/* Response Display Box */}
      {response && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Bot className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-100">Institutional Strategy Memo</h3>
          </div>

          <div className="prose prose-invert prose-xs max-w-none text-slate-300 space-y-3 font-sans">
            <ReactMarkdown>{response}</ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
};
