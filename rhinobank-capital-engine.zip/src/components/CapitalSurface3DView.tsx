import React, { useRef, useEffect, useState } from 'react';
import { Globe, RefreshCw, Eye, Sliders } from 'lucide-react';
import { ExposureItem, RegulatoryRuleset, CapitalHierarchy } from '../types/capital';
import { calculateTotalRWA } from '../engine/rwaEngine';
import { calculateCapitalRatios } from '../engine/capitalEngine';

interface CapitalSurface3DViewProps {
  exposures: ExposureItem[];
  hierarchy: CapitalHierarchy;
  ruleset: RegulatoryRuleset;
}

export const CapitalSurface3DView: React.FC<CapitalSurface3DViewProps> = ({
  exposures,
  hierarchy,
  ruleset,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [rotationX, setRotationX] = useState(30);
  const [rotationY, setRotationY] = useState(45);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // Draw background grid lines & 3D projection surface wireframe
    const stepsX = 12;
    const stepsY = 12;

    const pdRange = [0.8, 2.5];
    const lgdRange = [0.8, 1.8];

    const gridPoints: Array<Array<{ x: number; y: number; z: number; ratio: number }>> = [];

    for (let i = 0; i <= stepsX; i++) {
      const row = [];
      const pd = pdRange[0] + (i / stepsX) * (pdRange[1] - pdRange[0]);
      for (let j = 0; j <= stepsY; j++) {
        const lgd = lgdRange[0] + (j / stepsY) * (lgdRange[1] - lgdRange[0]);

        const rwaObj = calculateTotalRWA(exposures, ruleset, 14200, 4200, pd, lgd);
        const ratios = calculateCapitalRatios(hierarchy, rwaObj.totalRWA, ruleset);
        const ratio = ratios.cet1Ratio;

        // 3D coordinates (x: -1 to 1, y: -1 to 1, z: 0 to 1)
        const x3d = (i / stepsX) * 2 - 1;
        const y3d = (j / stepsY) * 2 - 1;
        const z3d = (ratio - 8) / 12; // normalize CET1 ratio between 8% and 20%

        row.push({ x: x3d, y: y3d, z: z3d, ratio });
      }
      gridPoints.push(row);
    }

    // 3D Rotation projection
    const radX = (rotationX * Math.PI) / 180;
    const radY = (rotationY * Math.PI) / 180;

    const project = (x: number, y: number, z: number) => {
      // Rotate around Y
      let x1 = x * Math.cos(radY) + y * Math.sin(radY);
      let y1 = -x * Math.sin(radY) + y * Math.cos(radY);
      let z1 = z;

      // Rotate around X
      let y2 = y1 * Math.cos(radX) - z1 * Math.sin(radX);
      let z2 = y1 * Math.sin(radX) + z1 * Math.cos(radX);

      const scale = 180;
      const screenX = width / 2 + x1 * scale;
      const screenY = height / 2 - y2 * scale;
      return { screenX, screenY, zDepth: z2 };
    };

    // Draw mesh surface wires
    ctx.lineWidth = 1.2;

    for (let i = 0; i < stepsX; i++) {
      for (let j = 0; j < stepsY; j++) {
        const p1 = project(gridPoints[i][j].x, gridPoints[i][j].y, gridPoints[i][j].z);
        const p2 = project(gridPoints[i + 1][j].x, gridPoints[i + 1][j].y, gridPoints[i + 1][j].z);
        const p3 = project(gridPoints[i + 1][j + 1].x, gridPoints[i + 1][j + 1].y, gridPoints[i + 1][j + 1].z);
        const p4 = project(gridPoints[i][j + 1].x, gridPoints[i][j + 1].y, gridPoints[i][j + 1].z);

        const avgRatio = (gridPoints[i][j].ratio + gridPoints[i + 1][j].ratio + gridPoints[i + 1][j + 1].ratio + gridPoints[i][j + 1].ratio) / 4;

        ctx.beginPath();
        ctx.moveTo(p1.screenX, p1.screenY);
        ctx.lineTo(p2.screenX, p2.screenY);
        ctx.lineTo(p3.screenX, p3.screenY);
        ctx.lineTo(p4.screenX, p4.screenY);
        ctx.closePath();

        if (avgRatio >= 14) {
          ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
          ctx.strokeStyle = '#10b981';
        } else if (avgRatio >= 11) {
          ctx.fillStyle = 'rgba(6, 182, 212, 0.25)';
          ctx.strokeStyle = '#06b6d4';
        } else if (avgRatio >= 9.5) {
          ctx.fillStyle = 'rgba(245, 158, 11, 0.3)';
          ctx.strokeStyle = '#f59e0b';
        } else {
          ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
          ctx.strokeStyle = '#ef4444';
        }

        ctx.fill();
        ctx.stroke();
      }
    }
  }, [rotationX, rotationY, exposures, hierarchy, ruleset]);

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <Globe className="w-5 h-5 text-cyan-400" />
            <span>3D Capital Surface & Regulatory Resilience Topology</span>
          </h2>
          <p className="text-xs text-slate-400">
            Interactive 3D manifold plotting Z = CET1 Ratio over X = Default Rate (PD) and Y = Loss Given Default (LGD).
          </p>
        </div>

        <div className="flex items-center space-x-4 text-xs font-mono">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">ROTATION X:</span>
            <input
              type="range"
              min="0"
              max="90"
              value={rotationX}
              onChange={(e) => setRotationX(Number(e.target.value))}
              className="w-20 accent-cyan-500 cursor-pointer"
            />
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">ROTATION Y:</span>
            <input
              type="range"
              min="0"
              max="360"
              value={rotationY}
              onChange={(e) => setRotationY(Number(e.target.value))}
              className="w-20 accent-cyan-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 3D Canvas Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 flex flex-col items-center justify-center relative">
        <canvas
          ref={canvasRef}
          width={800}
          height={480}
          className="w-full max-w-3xl h-auto rounded bg-slate-950 border border-slate-850"
        />

        <div className="mt-4 flex items-center space-x-6 text-xs font-mono">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-emerald-500/40 border border-emerald-500" />
            <span className="text-slate-300">CET1 &gt; 14% (Optimal)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-cyan-500/40 border border-cyan-500" />
            <span className="text-slate-300">11% - 14% (Target Buffer)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-amber-500/40 border border-amber-500" />
            <span className="text-slate-300">9.5% - 11% (Buffer Warning)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-rose-500/40 border border-rose-500" />
            <span className="text-slate-300">&lt; 9.5% (MDA Breach)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
