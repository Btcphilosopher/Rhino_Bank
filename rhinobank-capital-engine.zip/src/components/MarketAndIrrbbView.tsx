import React, { useState } from 'react';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid 
} from 'recharts';
import { Activity, TrendingUp, Zap, Sliders, RefreshCw } from 'lucide-react';
import { defaultYieldCurve, calculateShockedCurve, calculateMarketRiskRWA, calculateIRRBB, CurveShockType } from '../engine/marketRiskEngine';
import { CapitalHierarchy, TotalRWA } from '../types/capital';

interface MarketAndIrrbbViewProps {
  hierarchy: CapitalHierarchy;
  totalRWA: TotalRWA;
}

export const MarketAndIrrbbView: React.FC<MarketAndIrrbbViewProps> = ({
  hierarchy,
  totalRWA,
}) => {
  const [activeShock, setActiveShock] = useState<CurveShockType>('Parallel_Up_200');
  const [tradingBookVal, setTradingBookVal] = useState(14200);

  const shockedCurve = calculateShockedCurve(defaultYieldCurve, activeShock);
  const marketRiskRWA = calculateMarketRiskRWA(tradingBookVal);
  const irrbb = calculateIRRBB(287000, 253000, hierarchy.totalTier1, activeShock);

  const shockButtons: Array<{ id: CurveShockType; label: string }> = [
    { id: 'Parallel_Up_200', label: '+200bp Parallel Shift' },
    { id: 'Parallel_Down_200', label: '-200bp Parallel Shift' },
    { id: 'Steepener', label: 'Curve Steepener' },
    { id: 'Flattener', label: 'Curve Flattener' },
    { id: 'Bull_Steepener', label: 'Bull Steepener' },
    { id: 'Bear_Steepener', label: 'Bear Steepener' },
    { id: 'Butterfly', label: 'Mid-Curve Butterfly' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            <span>Market Risk (FRTB) & Banking Book IRRBB Module</span>
          </h2>
          <p className="text-xs text-slate-400">
            Yield curve shock simulator, interest rate sensitivity (EVE & NII), and FRTB market risk capital consumption.
          </p>
        </div>
        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">MARKET RISK RWA:</span>{' '}
            <span className="text-emerald-400 font-bold">${marketRiskRWA.totalMarketRWA.toLocaleString()}M</span>
          </div>
        </div>
      </div>

      {/* Yield Curve Shock Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Curve Shock Controls & Chart */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <h3 className="text-sm font-semibold text-slate-100">Yield Curve Shock Scenario Analysis</h3>
            <div className="flex flex-wrap gap-1.5">
              {shockButtons.map(btn => (
                <button
                  key={btn.id}
                  onClick={() => setActiveShock(btn.id)}
                  className={`px-2.5 py-1 text-xs font-mono rounded transition cursor-pointer ${
                    activeShock === btn.id
                      ? 'bg-cyan-500 text-slate-950 font-bold'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={shockedCurve} margin={{ top: 10, right: 30, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis dataKey="tenor" stroke="#64748b" tick={{ fontSize: 12 }} />
                <YAxis stroke="#64748b" unit="%" tick={{ fontSize: 12 }} domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc', fontSize: '12px' }}
                  formatter={(val: any) => [`${Number(val).toFixed(2)}%`, 'Yield']}
                />
                <Line type="monotone" dataKey="baseRate" name="Base Yield Curve" stroke="#64748b" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="shockedRate" name="Shocked Yield Curve" stroke="#06b6d4" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Repricing Gap Table */}
          <div className="mt-4 pt-3 border-t border-slate-800">
            <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Banking Book Repricing Gaps</h4>
            <div className="grid grid-cols-5 gap-2 text-center text-xs font-mono">
              {irrbb.repricingGap.map((b, i) => (
                <div key={i} className="bg-slate-950 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">{b.bucket}</span>
                  <span className={`font-bold ${b.gap >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    ${b.gap >= 0 ? '+' : ''}${Math.round(b.gap).toLocaleString()}M
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* EVE & NII Sensitivity Impact */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-100">IRRBB Capital Impact & Sensitivities</h3>

          <div className="space-y-3">
            <h4 className="text-xs font-mono text-slate-400 uppercase">Economic Value of Equity (EVE) Shift</h4>
            <div className="space-y-2">
              {irrbb.eveSensitivity.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center text-xs bg-slate-950 p-2 rounded border border-slate-800">
                  <span className="text-slate-300">{item.scenario}</span>
                  <div className="text-right font-mono">
                    <span className={`font-bold ${item.deltaEVE >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      ${item.deltaEVE >= 0 ? '+' : ''}${Math.round(item.deltaEVE).toLocaleString()}M
                    </span>
                    <span className="block text-[10px] text-slate-500">
                      ({item.percentageEVE.toFixed(1)}% Tier 1)
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <h4 className="text-xs font-mono text-slate-400 uppercase pt-2">Net Interest Income (NII) Shift</h4>
            <div className="space-y-2">
              {irrbb.niiSensitivity.slice(0, 3).map((item, idx) => (
                <div key={idx} className="flex justify-between items-center text-xs bg-slate-950 p-2 rounded border border-slate-800">
                  <span className="text-slate-300">{item.scenario}</span>
                  <div className="text-right font-mono">
                    <span className={`font-bold ${item.deltaNII >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      ${item.deltaNII >= 0 ? '+' : ''}${Math.round(item.deltaNII).toLocaleString()}M
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
