import React from 'react';
import { Zap, Award, BarChart2, DollarSign, TrendingUp } from 'lucide-react';
import { ExposureCalculated } from '../types/capital';

interface CapitalConsumptionViewProps {
  exposures: ExposureCalculated[];
}

export const CapitalConsumptionView: React.FC<CapitalConsumptionViewProps> = ({ exposures }) => {
  // Group exposures by business line / sector
  const grouped: Record<string, {
    sector: string;
    ead: number;
    rwa: number;
    capitalConsumed: number;
    revenue: number;
    profit: number;
    itemsCount: number;
  }> = {};

  exposures.forEach(exp => {
    const sec = exp.exposureClass.replace('_', ' ');
    if (!grouped[sec]) {
      grouped[sec] = {
        sector: sec,
        ead: 0,
        rwa: 0,
        capitalConsumed: 0,
        revenue: 0,
        profit: 0,
        itemsCount: 0,
      };
    }
    grouped[sec].ead += exp.ead;
    grouped[sec].rwa += exp.rwa;
    grouped[sec].capitalConsumed += exp.capitalConsumed;
    grouped[sec].revenue += exp.annualRevenue;
    grouped[sec].profit += (exp.annualRevenue - exp.annualExpenses - exp.expectedLoss);
    grouped[sec].itemsCount += 1;
  });

  const sectorList = Object.values(grouped).map(g => {
    const capitalPerExposure = g.ead > 0 ? (g.capitalConsumed / g.ead) * 100 : 0;
    const capitalPerRevenue = g.revenue > 0 ? g.capitalConsumed / g.revenue : 0;
    const capitalPerProfit = g.profit > 0 ? g.capitalConsumed / g.profit : 0;
    const raroc = g.capitalConsumed > 0 ? (g.profit / (g.capitalConsumed * 1.1)) * 100 : 0;
    const roe = g.capitalConsumed > 0 ? (g.profit / g.capitalConsumed) * 100 : 0;

    return {
      ...g,
      capitalPerExposure,
      capitalPerRevenue,
      capitalPerProfit,
      raroc,
      roe,
    };
  });

  // Sort descending by RAROC
  sectorList.sort((a, b) => b.raroc - a.raroc);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <span>Capital Consumption & Risk-Adjusted Profitability (RAROC)</span>
          </h2>
          <p className="text-xs text-slate-400">
            Determine which business lines generate the highest return per unit of scarce capital consumed.
          </p>
        </div>
      </div>

      {/* Consumption Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase tracking-wider border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Business Line / Exposure Class</th>
              <th className="py-3 px-3 text-right">EAD ($M)</th>
              <th className="py-3 px-3 text-right">RWA ($M)</th>
              <th className="py-3 px-3 text-right">Capital Consumed ($M)</th>
              <th className="py-3 px-3 text-right">Capital / $ Exposure</th>
              <th className="py-3 px-3 text-right">Annual Profit ($M)</th>
              <th className="py-3 px-3 text-right">Capital / $ Profit</th>
              <th className="py-3 px-3 text-right">ROE (%)</th>
              <th className="py-3 px-3 text-right">RAROC (%)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {sectorList.map((sec, idx) => (
              <tr key={idx} className="hover:bg-slate-850/50 transition">
                <td className="py-3 px-4 font-semibold text-slate-100 font-sans">
                  {sec.sector}
                  <span className="text-[10px] text-slate-500 font-sans block">{sec.itemsCount} Positions</span>
                </td>
                <td className="py-3 px-3 text-right text-slate-200">${sec.ead.toLocaleString()}</td>
                <td className="py-3 px-3 text-right font-bold text-cyan-400">${Math.round(sec.rwa).toLocaleString()}</td>
                <td className="py-3 px-3 text-right font-bold text-amber-400">${Math.round(sec.capitalConsumed).toLocaleString()}</td>
                <td className="py-3 px-3 text-right text-slate-300">{sec.capitalPerExposure.toFixed(2)}%</td>
                <td className="py-3 px-3 text-right text-emerald-400 font-bold">${Math.round(sec.profit).toLocaleString()}</td>
                <td className="py-3 px-3 text-right text-slate-300">{sec.capitalPerProfit.toFixed(2)}x</td>
                <td className="py-3 px-3 text-right font-bold text-slate-200">{sec.roe.toFixed(1)}%</td>
                <td className="py-3 px-3 text-right">
                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    sec.raroc >= 18 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' :
                    sec.raroc >= 12 ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30' :
                    'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                  }`}>
                    {sec.raroc.toFixed(1)}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
