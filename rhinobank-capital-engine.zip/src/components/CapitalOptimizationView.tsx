import React, { useState } from 'react';
import { Cpu, ArrowRight, CheckCircle2, RefreshCw, Zap, TrendingUp } from 'lucide-react';
import { ExposureItem, RegulatoryRuleset, OptimizationTarget } from '../types/capital';
import { optimizeCapitalAllocation, OptimizationResult } from '../engine/optimizationEngine';

interface CapitalOptimizationViewProps {
  exposures: ExposureItem[];
  ruleset: RegulatoryRuleset;
  cet1Capital: number;
}

export const CapitalOptimizationView: React.FC<CapitalOptimizationViewProps> = ({
  exposures,
  ruleset,
  cet1Capital,
}) => {
  const [objective, setObjective] = useState<OptimizationTarget['objective']>('MAXIMIZE_RAROC');
  const [maxGrowthPct, setMaxGrowthPct] = useState(25);
  const [isOptimized, setIsOptimized] = useState(false);
  const [result, setResult] = useState<OptimizationResult | null>(null);

  const handleRunOptimization = () => {
    const res = optimizeCapitalAllocation(
      exposures,
      ruleset,
      cet1Capital,
      14200,
      4200,
      {
        objective,
        maxSingleAssetGrowthPct: maxGrowthPct,
      }
    );
    setResult(res);
    setIsOptimized(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <span>Capital Allocation & RWA Optimization Solver</span>
          </h2>
          <p className="text-xs text-slate-400">
            Quantitative optimization engine rebalancing portfolio exposures to maximize RAROC / ROE or minimize RWA density.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400 font-mono">OBJECTIVE:</span>
            <select
              value={objective}
              onChange={(e) => setObjective(e.target.value as any)}
              className="bg-slate-950 text-slate-200 border border-slate-800 rounded px-3 py-1.5 focus:outline-none font-mono cursor-pointer"
            >
              <option value="MAXIMIZE_RAROC">Maximize RAROC (%)</option>
              <option value="MAXIMIZE_ROE">Maximize ROE (%)</option>
              <option value="MINIMIZE_RWA">Minimize Total RWA ($M)</option>
              <option value="MINIMIZE_CAPITAL">Minimize Capital Consumption ($M)</option>
            </select>
          </div>

          <button
            onClick={handleRunOptimization}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs rounded transition flex items-center space-x-1.5 cursor-pointer shadow-lg shadow-cyan-950"
          >
            <Zap className="w-4 h-4" />
            <span>Execute Optimization Solver</span>
          </button>
        </div>
      </div>

      {/* Results Comparison Grid */}
      {result && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
              <span className="text-slate-500 block text-[10px] uppercase">RWA Shift</span>
              <div className="text-xl font-bold text-slate-100 mt-1 flex items-center space-x-2">
                <span>${(result.optimizedRWA / 1000).toFixed(1)}B</span>
                <span className={`text-xs ${result.rwaDelta <= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  ({result.rwaDelta <= 0 ? '' : '+'}${Math.round(result.rwaDelta).toLocaleString()}M)
                </span>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
              <span className="text-slate-500 block text-[10px] uppercase">CET1 Ratio Improvement</span>
              <div className="text-xl font-bold text-emerald-400 mt-1">
                {result.optimizedCet1Ratio.toFixed(2)}%
                <span className="text-xs text-slate-400 font-normal ml-1">
                  (was {result.originalCet1Ratio.toFixed(2)}%)
                </span>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
              <span className="text-slate-500 block text-[10px] uppercase">Weighted Portfolio RAROC</span>
              <div className="text-xl font-bold text-cyan-400 mt-1">
                {result.optimizedWeightedRaroc.toFixed(2)}%
                <span className="text-xs text-slate-400 font-normal ml-1">
                  (+{(result.optimizedWeightedRaroc - result.originalWeightedRaroc).toFixed(2)}%)
                </span>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
              <span className="text-slate-500 block text-[10px] uppercase">Weighted Portfolio ROE</span>
              <div className="text-xl font-bold text-indigo-400 mt-1">
                {result.optimizedWeightedRoe.toFixed(2)}%
              </div>
            </div>
          </div>

          {/* Reallocated Exposure Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Counterparty / Asset</th>
                  <th className="py-3 px-3">Sector</th>
                  <th className="py-3 px-3 text-right">Original EAD ($M)</th>
                  <th className="py-3 px-3 text-right">Optimized EAD ($M)</th>
                  <th className="py-3 px-3 text-right">EAD Shift (%)</th>
                  <th className="py-3 px-3 text-right">Original RWA ($M)</th>
                  <th className="py-3 px-3 text-right">Optimized RWA ($M)</th>
                  <th className="py-3 px-3 text-right">RAROC (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {result.reallocatedExposures.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-850/50 transition">
                    <td className="py-3 px-4 font-semibold text-slate-100 font-sans">{item.counterparty}</td>
                    <td className="py-3 px-3 text-slate-400 font-sans">{item.sector}</td>
                    <td className="py-3 px-3 text-right text-slate-400">${item.originalEAD.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right font-bold text-slate-100">${item.optimizedEAD.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right">
                      <span className={`font-bold ${item.eadDeltaPct > 0 ? 'text-emerald-400' : item.eadDeltaPct < 0 ? 'text-rose-400' : 'text-slate-500'}`}>
                        {item.eadDeltaPct > 0 ? '+' : ''}{item.eadDeltaPct.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right text-slate-400">${item.originalRWA.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right font-bold text-cyan-400">${item.optimizedRWA.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right text-emerald-400 font-bold">{item.raroc.toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
