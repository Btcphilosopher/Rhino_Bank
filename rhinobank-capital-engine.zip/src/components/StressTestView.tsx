import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle2, Play, Flame, BarChart } from 'lucide-react';
import { ExposureItem, RegulatoryRuleset, CapitalHierarchy, StressScenario } from '../types/capital';
import { mockStressScenarios } from '../data/mockData';
import { runStressScenario } from '../engine/stressTestEngine';

interface StressTestViewProps {
  exposures: ExposureItem[];
  hierarchy: CapitalHierarchy;
  ruleset: RegulatoryRuleset;
}

export const StressTestView: React.FC<StressTestViewProps> = ({
  exposures,
  hierarchy,
  ruleset,
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState(mockStressScenarios[0].id);

  const activeScenario = mockStressScenarios.find(s => s.id === selectedScenarioId) || mockStressScenarios[0];
  const result = runStressScenario(activeScenario, exposures, hierarchy, ruleset, 14200, 4200);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <span>Macro Stress Testing & Capital Adequacy Engine</span>
          </h2>
          <p className="text-xs text-slate-400">
            Simulate CCAR / PRA macroeconomic stress scenarios to stress-test capital buffers and MDA triggers.
          </p>
        </div>
      </div>

      {/* Scenario Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {mockStressScenarios.map((scenario) => {
          const isSelected = scenario.id === selectedScenarioId;
          return (
            <div
              key={scenario.id}
              onClick={() => setSelectedScenarioId(scenario.id)}
              className={`p-4 rounded-lg border transition cursor-pointer space-y-2 ${
                isSelected
                  ? 'bg-rose-950/40 border-rose-500 ring-1 ring-rose-500/50'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className={`text-xs font-mono font-bold uppercase ${isSelected ? 'text-rose-400' : 'text-slate-300'}`}>
                  {scenario.name}
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                  {scenario.severity}
                </span>
              </div>

              <p className="text-[11px] text-slate-400 line-clamp-2">{scenario.description}</p>

              <div className="pt-2 border-t border-slate-800/60 grid grid-cols-2 text-[10px] font-mono text-slate-400">
                <span>GDP: <strong className="text-rose-400">{scenario.gdpChange}%</strong></span>
                <span>PD: <strong className="text-amber-400">{scenario.pdMultiplier}x</strong></span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Stress Results Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scenario Parameters Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3">
          <h3 className="text-sm font-semibold text-slate-100 border-b border-slate-800 pb-2">
            Scenario Macro Assumptions: {activeScenario.name}
          </h3>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between p-2 rounded bg-slate-950">
              <span className="text-slate-400">GDP Shock</span>
              <span className="text-rose-400 font-bold">{activeScenario.gdpChange}%</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-950">
              <span className="text-slate-400">Unemployment Increase</span>
              <span className="text-amber-400 font-bold">+{activeScenario.unemploymentIncrease}%</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-950">
              <span className="text-slate-400">Property / Asset Drop</span>
              <span className="text-rose-400 font-bold">{activeScenario.assetPriceDrop}%</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-950">
              <span className="text-slate-400">Interest Rate Shift</span>
              <span className="text-indigo-400 font-bold">+{activeScenario.interestRateShiftBp} bp</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-950">
              <span className="text-slate-400">Direct Trading Losses</span>
              <span className="text-rose-400 font-bold">${activeScenario.tradingLosses}M</span>
            </div>
          </div>
        </div>

        {/* Post-Stress Capital Status */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <h3 className="text-sm font-semibold text-slate-100">Post-Stress Capital Position Comparison</h3>
            {result.postStress.bufferBreached ? (
              <span className="px-2.5 py-1 rounded text-xs font-mono font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30 flex items-center space-x-1.5 animate-pulse">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>COMBINED BUFFER BREACHED</span>
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded text-xs font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>BUFFERS INTACT</span>
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center font-mono">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">BASELINE CET1 RATIO</span>
              <span className="text-xl font-bold text-slate-200">{result.preStress.cet1Ratio.toFixed(2)}%</span>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">POST-STRESS CET1 RATIO</span>
              <span className={`text-xl font-bold ${result.postStress.cet1Ratio < ruleset.minCET1Ratio ? 'text-rose-400' : 'text-amber-400'}`}>
                {result.postStress.cet1Ratio.toFixed(2)}%
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">TOTAL STRESSED LOSSES</span>
              <span className="text-xl font-bold text-rose-400">${Math.round(result.postStress.losses).toLocaleString()}M</span>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">HEADROOM IMPACT</span>
              <span className="text-xl font-bold text-rose-400">{result.postStress.headroomDelta.toFixed(2)}% pts</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
