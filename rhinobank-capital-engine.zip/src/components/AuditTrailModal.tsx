import React from 'react';
import { X, ShieldCheck, CheckCircle2, ChevronRight, FileText } from 'lucide-react';
import { AuditLineageStep } from '../types/capital';

interface AuditTrailModalProps {
  isOpen: boolean;
  onClose: () => void;
  auditSteps: AuditLineageStep[];
}

export const AuditTrailModal: React.FC<AuditTrailModalProps> = ({
  isOpen,
  onClose,
  auditSteps,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-3xl overflow-hidden shadow-2xl space-y-4">
        {/* Modal Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-cyan-500/10 rounded-lg text-cyan-400 border border-cyan-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">Capital Calculation Lineage & Audit Trail</h3>
              <p className="text-xs text-slate-400 font-mono">Verifiable step-by-step mathematical trace for Regulatory Audit</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-100 p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content - Step-by-Step Lineage */}
        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {auditSteps.map((step) => (
            <div key={step.stepNumber} className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-2">
                <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
                  Step {step.stepNumber}: {step.title}
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  {step.outputValue}
                </span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="font-mono text-slate-300 bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">FORMULA & EXPRESSION:</span>
                  <span className="text-cyan-300 font-bold">{step.formulaName}</span>
                  <span className="block text-slate-400 mt-1">{step.expression}</span>
                </div>

                <div className="pt-2">
                  <span className="text-[10px] font-mono text-slate-500 uppercase">Input Vector Values:</span>
                  <div className="grid grid-cols-2 gap-2 mt-1 font-mono">
                    {Object.entries(step.inputs).map(([k, v]) => (
                      <div key={k} className="bg-slate-900/60 p-2 rounded border border-slate-800/80 flex justify-between">
                        <span className="text-slate-400 text-[11px]">{k}</span>
                        <span className="text-slate-100 font-bold">{typeof v === 'number' ? `$${v.toLocaleString()}M` : v}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 pt-1 font-sans">{step.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-950 px-6 py-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded transition cursor-pointer"
          >
            Close Audit Trail
          </button>
        </div>
      </div>
    </div>
  );
};
