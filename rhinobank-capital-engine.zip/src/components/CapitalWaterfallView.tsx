import React, { useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell, 
  ReferenceLine 
} from 'recharts';
import { Layers, ArrowRight, RefreshCw } from 'lucide-react';
import { CapitalHierarchy, TotalRWA, CapitalRatios } from '../types/capital';

interface CapitalWaterfallViewProps {
  hierarchy: CapitalHierarchy;
  totalRWA: TotalRWA;
  ratios: CapitalRatios;
}

export const CapitalWaterfallView: React.FC<CapitalWaterfallViewProps> = ({
  hierarchy,
  totalRWA,
  ratios,
}) => {
  const [profit, setProfit] = useState(1450);
  const [dividends, setDividends] = useState(580);
  const [losses, setLosses] = useState(250);
  const [capitalRaised, setCapitalRaised] = useState(0);
  const [deductions, setDeductions] = useState(120);

  const openingCET1 = hierarchy.cet1.totalCET1;
  const netEarningsAdded = profit - dividends;
  const netMovement = netEarningsAdded - losses + capitalRaised - deductions;
  const closingCET1 = openingCET1 + netMovement;

  const cet1WaterfallData = [
    { name: 'Opening CET1', value: openingCET1, isTotal: true, color: '#0ea5e9' },
    { name: 'Retained Earnings', value: netEarningsAdded, isTotal: false, color: '#10b981' },
    { name: 'Dividend Payout', value: -dividends, isTotal: false, color: '#f43f5e' },
    { name: 'Credit Losses', value: -losses, isTotal: false, color: '#ef4444' },
    { name: 'Capital Raising', value: capitalRaised, isTotal: false, color: '#8b5cf6' },
    { name: 'Reg Deductions', value: -deductions, isTotal: false, color: '#f59e0b' },
    { name: 'Closing CET1', value: closingCET1, isTotal: true, color: '#10b981' },
  ];

  // RWA Waterfall Movement
  const openingRWA = totalRWA.finalTotalRWA;
  const rwaGrowth = Math.round(openingRWA * 0.035);
  const rwaMigration = Math.round(openingRWA * 0.015);
  const rwaReduction = Math.round(openingRWA * 0.02);
  const closingRWA = openingRWA + rwaGrowth + rwaMigration - rwaReduction;

  const rwaWaterfallData = [
    { name: 'Opening RWA', value: openingRWA, color: '#3b82f6' },
    { name: 'Loan Growth (+3.5%)', value: rwaGrowth, color: '#f59e0b' },
    { name: 'Credit Migration', value: rwaMigration, color: '#ef4444' },
    { name: 'Asset Sales & Runoff', value: -rwaReduction, color: '#10b981' },
    { name: 'Closing RWA', value: closingRWA, color: '#6366f1' },
  ];

  const closingCET1Ratio = (closingCET1 / closingRWA) * 100;

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex justify-between items-center">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>Capital Movement & RWA Waterfall Bridge</span>
          </h2>
          <p className="text-xs text-slate-400">
            Interactive capital bridge modeling retained earnings, dividend deductions, asset growth, and closing ratios.
          </p>
        </div>
        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">CLOSING CET1:</span>{' '}
            <span className="text-emerald-400 font-bold">${closingCET1.toLocaleString()}M</span>
          </div>
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">PROJECTED CET1 RATIO:</span>{' '}
            <span className="text-cyan-400 font-bold">{closingCET1Ratio.toFixed(2)}%</span>
          </div>
        </div>
      </div>

      {/* Waterfall Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* CET1 Capital Bridge Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-sm font-semibold text-slate-100 mb-1">CET1 Capital Waterfall Bridge ($ Millions)</h3>
          <p className="text-xs text-slate-400 mb-4">Opening CET1 to Closing CET1 breakdown</p>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cet1WaterfallData} margin={{ top: 20, right: 20, left: 10, bottom: 25 }}>
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 10 }} interval={0} angle={-15} textAnchor="end" />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} domain={[0, 'auto']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc', fontSize: '12px' }}
                  formatter={(val: any) => [`$${Number(val).toLocaleString()}M`, 'Amount']}
                />
                <Bar dataKey="value">
                  {cet1WaterfallData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Controls for Bridge */}
          <div className="mt-4 pt-4 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono">
            <div>
              <label className="text-slate-400 block mb-1">Net Profit ($M)</label>
              <input
                type="number"
                value={profit}
                onChange={(e) => setProfit(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Dividends Paid ($M)</label>
              <input
                type="number"
                value={dividends}
                onChange={(e) => setDividends(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Credit Losses ($M)</label>
              <input
                type="number"
                value={losses}
                onChange={(e) => setLosses(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>
        </div>

        {/* RWA Movement Bridge Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h3 className="text-sm font-semibold text-slate-100 mb-1">RWA Movement Bridge ($ Millions)</h3>
          <p className="text-xs text-slate-400 mb-4">Opening RWA to Closing RWA growth dynamics</p>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={rwaWaterfallData} margin={{ top: 20, right: 20, left: 10, bottom: 25 }}>
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 10 }} interval={0} angle={-15} textAnchor="end" />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} domain={[0, 'auto']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc', fontSize: '12px' }}
                  formatter={(val: any) => [`$${Number(val).toLocaleString()}M`, 'RWA']}
                />
                <Bar dataKey="value">
                  {rwaWaterfallData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-800 flex justify-between items-center text-xs font-mono text-slate-400">
            <div>
              <span>OPENING RWA: </span>
              <span className="text-slate-200 font-bold">${openingRWA.toLocaleString()}M</span>
            </div>
            <ArrowRight className="w-4 h-4 text-cyan-400" />
            <div>
              <span>CLOSING RWA: </span>
              <span className="text-indigo-400 font-bold">${closingRWA.toLocaleString()}M</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
