import React from 'react';
import { Shield, Cpu, Activity, Database, BarChart3, Layers, Sliders, LineChart, FileText, Zap, Globe } from 'lucide-react';
import { RegulatoryFramework } from '../types/capital';
import { mockRegulatoryRulesets } from '../data/mockData';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  activeRuleset: RegulatoryFramework;
  onRulesetChange: (ruleset: RegulatoryFramework) => void;
  cet1Ratio: number;
  status: 'OPTIMAL' | 'ADEQUATE' | 'WARNING' | 'DEFICIT';
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  activeRuleset,
  onRulesetChange,
  cet1Ratio,
  status,
}) => {
  const currentRulesetObj = mockRegulatoryRulesets[activeRuleset];

  const tabs = [
    { id: 'dashboard', label: 'Capital Dashboard', icon: BarChart3 },
    { id: 'waterfall', label: 'Capital Stack & Waterfall', icon: Layers },
    { id: 'portfolio', label: 'Credit Portfolio & IRB', icon: Database },
    { id: 'market_irrbb', label: 'Market Risk & IRRBB', icon: Activity },
    { id: 'consumption', label: 'Capital Consumption & RAROC', icon: Zap },
    { id: 'lab', label: 'Capital Scenario Lab', icon: Sliders },
    { id: 'stress', label: 'Stress Test Engine', icon: Shield },
    { id: 'optimization', label: 'Capital Optimization', icon: Cpu },
    { id: 'forecast', label: 'Forward Projections', icon: LineChart },
    { id: 'surface_matrix', label: '3D Surfaces & Sensitivity', icon: Globe },
    { id: 'rulesets', label: 'Regulatory Rulesets', icon: FileText },
    { id: 'ai_advisor', label: 'AI Regulatory Advisor', icon: Shield },
  ];

  const getStatusBadge = () => {
    switch (status) {
      case 'OPTIMAL':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'ADEQUATE':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
      case 'WARNING':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      case 'DEFICIT':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse';
    }
  };

  return (
    <header className="bg-slate-950 border-b border-slate-800 text-slate-100 sticky top-0 z-40">
      {/* Top Status Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-4 border-b border-slate-900 text-xs">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 font-mono tracking-widest text-cyan-400 font-bold uppercase text-sm">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
            <span>RHINOBANK</span>
            <span className="text-slate-500 font-normal">/</span>
            <span className="text-slate-300 font-semibold">CAPITAL ENGINE R-3.7</span>
          </div>
          <span className="text-slate-600">|</span>
          <div className="flex items-center space-x-1.5 text-slate-400">
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-mono">JURISDICTION:</span>
            <span className="text-slate-200 font-medium">{currentRulesetObj.jurisdiction}</span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Active Ruleset Selector */}
          <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded px-2.5 py-1">
            <span className="text-slate-400 font-mono text-[11px]">RULESET:</span>
            <select
              value={activeRuleset}
              onChange={(e) => onRulesetChange(e.target.value as RegulatoryFramework)}
              className="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
            >
              <option value="Basel_IV" className="bg-slate-900">Basel IV / Finalised</option>
              <option value="Basel_III" className="bg-slate-900">Basel III Standard</option>
              <option value="US_CCAR" className="bg-slate-900">US Dodd-Frank / CCAR</option>
              <option value="EU_CRR3" className="bg-slate-900">EU CRR III / CRD VI</option>
              <option value="UK_PRA" className="bg-slate-900">UK PRA Framework</option>
            </select>
          </div>

          {/* CET1 Live Metric */}
          <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded px-3 py-1 font-mono">
            <span className="text-slate-400">CET1 RATIO:</span>
            <span className="text-emerald-400 font-bold text-sm">{cet1Ratio.toFixed(2)}%</span>
          </div>

          {/* Status Badge */}
          <div className={`px-2.5 py-1 border rounded text-[11px] font-mono font-semibold uppercase tracking-wider ${getStatusBadge()}`}>
            {status}
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="max-w-7xl mx-auto px-4 overflow-x-auto scrollbar-none">
        <nav className="flex space-x-1 py-1 font-sans text-xs font-medium">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-t-md transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-cyan-400 border-b-2 border-cyan-400 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
