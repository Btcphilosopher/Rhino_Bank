import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { 
  ShieldCheck, 
  AlertTriangle, 
  TrendingUp, 
  Layers, 
  Info,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { CapitalHierarchy, TotalRWA, CapitalRatios, RegulatoryRuleset } from '../types/capital';

interface CapitalDashboardProps {
  hierarchy: CapitalHierarchy;
  totalRWA: TotalRWA;
  ratios: CapitalRatios;
  ruleset: RegulatoryRuleset;
  onOpenAudit: () => void;
  onNavigate: (tab: string) => void;
}

export const CapitalDashboard: React.FC<CapitalDashboardProps> = ({
  hierarchy,
  totalRWA,
  ratios,
  ruleset,
  onOpenAudit,
  onNavigate,
}) => {
  const rwaBreakdown = [
    { name: 'Credit Risk RWA', value: totalRWA.creditRWA, color: '#3b82f6' },
    { name: 'Market Risk RWA', value: totalRWA.marketRWA, color: '#10b981' },
    { name: 'Operational Risk RWA', value: totalRWA.opRiskRWA, color: '#f59e0b' },
    { name: 'Other (CVA/Sec.) RWA', value: totalRWA.otherRWA, color: '#8b5cf6' },
    ...(totalRWA.outputFloorApplied ? [{ name: 'Output Floor Add-on', value: totalRWA.outputFloorRWA, color: '#ec4899' }] : []),
  ];

  const ratioData = [
    {
      name: 'CET1 Ratio',
      current: ratios.cet1Ratio,
      minReq: ratios.minCET1Req,
      bufferReq: ratios.combinedBufferReq,
      target: ratios.totalTargetCET1Ratio,
    },
    {
      name: 'Tier 1 Ratio',
      current: ratios.tier1Ratio,
      minReq: ratios.minTier1Req,
      bufferReq: ratios.combinedBufferReq,
      target: ratios.minTier1Req + ratios.combinedBufferReq + ruleset.buffers.managementBuffer,
    },
    {
      name: 'Total Capital',
      current: ratios.totalCapitalRatio,
      minReq: ratios.minTotalCapitalReq,
      bufferReq: ratios.combinedBufferReq,
      target: ratios.totalTargetCapitalRatio,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner Notice */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-cyan-500/10 rounded-lg text-cyan-400 border border-cyan-500/20">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-sm font-semibold text-slate-100">{ruleset.name}</h2>
              <span className="text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded font-mono">
                {ruleset.version}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Regulatory Minimum: CET1 {ruleset.minCET1Ratio}% | Combined Buffers: {ratios.combinedBufferReq.toFixed(2)}% | Output Floor: {ruleset.outputFloorPercentage}%
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenAudit}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono rounded border border-slate-700 transition flex items-center space-x-1.5 cursor-pointer"
          >
            <Info className="w-3.5 h-3.5 text-cyan-400" />
            <span>Audit Calculation Lineage</span>
          </button>
          <button
            onClick={() => onNavigate('lab')}
            className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-semibold text-xs rounded transition flex items-center space-x-1.5 cursor-pointer shadow-lg shadow-cyan-950"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Launch Capital Lab</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: CET1 Ratio */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">CET1 Capital Ratio</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
              +{ratios.cet1HeadroomPercentage.toFixed(2)}% Headroom
            </span>
          </div>
          <div className="mt-3 flex items-baseline space-x-2">
            <span className="text-3xl font-mono font-bold text-slate-100">{ratios.cet1Ratio.toFixed(2)}%</span>
            <span className="text-xs text-slate-500">vs {ratios.totalTargetCET1Ratio.toFixed(2)}% Target</span>
          </div>
          <div className="mt-3 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (ratios.cet1Ratio / 20) * 100)}%` }}
            />
          </div>
          <div className="mt-2 flex justify-between text-[10px] font-mono text-slate-500">
            <span>Min: {ratios.minCET1Req}%</span>
            <span>Req + Buffers: {(ratios.minCET1Req + ratios.combinedBufferReq).toFixed(1)}%</span>
            <span>Target: {ratios.totalTargetCET1Ratio.toFixed(1)}%</span>
          </div>
        </div>

        {/* Card 2: Tier 1 Capital Ratio */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">Tier 1 Capital Ratio</span>
            <span className="text-xs font-mono text-slate-400">${hierarchy.totalTier1.toLocaleString()}M</span>
          </div>
          <div className="mt-3 flex items-baseline space-x-2">
            <span className="text-3xl font-mono font-bold text-slate-100">{ratios.tier1Ratio.toFixed(2)}%</span>
            <span className="text-xs text-slate-500">vs {ratios.minTier1Req}% Min</span>
          </div>
          <div className="mt-3 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-cyan-500 h-full rounded-full"
              style={{ width: `${Math.min(100, (ratios.tier1Ratio / 22) * 100)}%` }}
            />
          </div>
          <div className="mt-2 flex justify-between text-[10px] font-mono text-slate-500">
            <span>CET1: ${hierarchy.cet1.totalCET1.toLocaleString()}M</span>
            <span>AT1: ${hierarchy.at1.totalAT1.toLocaleString()}M</span>
          </div>
        </div>

        {/* Card 3: Total Capital Ratio */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">Total Capital Ratio</span>
            <span className="text-xs font-mono text-slate-400">${hierarchy.totalCapital.toLocaleString()}M</span>
          </div>
          <div className="mt-3 flex items-baseline space-x-2">
            <span className="text-3xl font-mono font-bold text-slate-100">{ratios.totalCapitalRatio.toFixed(2)}%</span>
            <span className="text-xs text-slate-500">vs {ratios.minTotalCapitalReq}% Min</span>
          </div>
          <div className="mt-3 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-blue-500 h-full rounded-full"
              style={{ width: `${Math.min(100, (ratios.totalCapitalRatio / 25) * 100)}%` }}
            />
          </div>
          <div className="mt-2 flex justify-between text-[10px] font-mono text-slate-500">
            <span>Tier 2: ${hierarchy.tier2.totalTier2.toLocaleString()}M</span>
            <span>Target: {ratios.totalTargetCapitalRatio.toFixed(1)}%</span>
          </div>
        </div>

        {/* Card 4: Total RWA & Output Floor */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">Total Risk-Weighted Assets</span>
            {totalRWA.outputFloorApplied ? (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-pink-500/10 text-pink-400 border border-pink-500/30">
                Floor Active ({ruleset.outputFloorPercentage}%)
              </span>
            ) : (
              <span className="text-[10px] font-mono text-slate-500">Density: {((totalRWA.finalTotalRWA / 287000) * 100).toFixed(1)}%</span>
            )}
          </div>
          <div className="mt-3 flex items-baseline space-x-2">
            <span className="text-3xl font-mono font-bold text-slate-100">${(totalRWA.finalTotalRWA / 1000).toFixed(1)}B</span>
            <span className="text-xs text-slate-400">${totalRWA.finalTotalRWA.toLocaleString()}M</span>
          </div>
          <div className="mt-3 text-[11px] font-mono text-slate-400 flex justify-between">
            <span>Credit: ${(totalRWA.creditRWA / 1000).toFixed(1)}B</span>
            <span>Market: ${(totalRWA.marketRWA / 1000).toFixed(1)}B</span>
            <span>OpRisk: ${(totalRWA.opRiskRWA / 1000).toFixed(1)}B</span>
          </div>
        </div>
      </div>

      {/* Main Charts & Breakdown Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ratio Comparison Stacked Bar Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-100">Capital Ratio Stack vs Regulatory Requirements</h3>
              <p className="text-xs text-slate-400">Current capital buffer vs mandatory minimums and management targets</p>
            </div>
            <button
              onClick={() => onNavigate('waterfall')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-mono flex items-center space-x-1 cursor-pointer"
            >
              <span>Inspect Stack</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ratioData} margin={{ top: 20, right: 30, left: 10, bottom: 5 }}>
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 12 }} />
                <YAxis stroke="#64748b" unit="%" tick={{ fontSize: 12 }} domain={[0, 20]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc', fontSize: '12px' }}
                  formatter={(value: any) => [`${Number(value).toFixed(2)}%`, '']}
                />
                <Bar dataKey="minReq" name="Regulatory Minimum" fill="#ef4444" stackId="a" />
                <Bar dataKey="bufferReq" name="Combined Buffers" fill="#f59e0b" stackId="a" />
                <Bar dataKey="current" name="Capital Surplus / Current" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 grid grid-cols-3 gap-2 text-center text-xs font-mono">
            <div className="bg-slate-950/60 p-2 rounded">
              <span className="text-slate-500 block text-[10px]">CET1 HEADROOM</span>
              <span className="text-emerald-400 font-bold">${ratios.cet1SurplusDeficitAmount.toLocaleString()}M</span>
            </div>
            <div className="bg-slate-950/60 p-2 rounded">
              <span className="text-slate-500 block text-[10px]">COMBINED BUFFER REQ</span>
              <span className="text-amber-400 font-bold">{ratios.combinedBufferReq.toFixed(2)}%</span>
            </div>
            <div className="bg-slate-950/60 p-2 rounded">
              <span className="text-slate-500 block text-[10px]">MANAGEMENT TARGET</span>
              <span className="text-cyan-400 font-bold">{ratios.totalTargetCET1Ratio.toFixed(2)}%</span>
            </div>
          </div>
        </div>

        {/* RWA Composition Pie & Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">Risk-Weighted Assets (RWA) Structure</h3>
            <p className="text-xs text-slate-400 mb-2">Total RWA: ${totalRWA.finalTotalRWA.toLocaleString()}M</p>

            <div className="h-44 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={rwaBreakdown}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={3}
                  >
                    {rwaBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc', fontSize: '12px' }}
                    formatter={(val: any) => [`$${Number(val).toLocaleString()}M`, 'RWA']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-2 mt-3 pt-3 border-t border-slate-800 text-xs">
            {rwaBreakdown.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-300 font-medium">{item.name}</span>
                </div>
                <div className="font-mono text-slate-400">
                  <span>${item.value.toLocaleString()}M</span>
                  <span className="text-slate-500 text-[10px] ml-1.5">
                    ({((item.value / totalRWA.finalTotalRWA) * 100).toFixed(1)}%)
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Action Hub */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div 
          onClick={() => onNavigate('portfolio')}
          className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-lg p-4 cursor-pointer transition group"
        >
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-slate-200 group-hover:text-cyan-400 transition">Credit Risk & IRB Engine</h4>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition" />
          </div>
          <p className="text-xs text-slate-400 mt-1">Explore loan exposures, PD/LGD risk weights, F-IRB and A-IRB mathematical models.</p>
        </div>

        <div 
          onClick={() => onNavigate('stress')}
          className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-lg p-4 cursor-pointer transition group"
        >
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-slate-200 group-hover:text-cyan-400 transition">Macro Stress Test Engine</h4>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition" />
          </div>
          <p className="text-xs text-slate-400 mt-1">Simulate Severe Recession, Hawkish Rate Shocks, and CRE crashes on capital headroom.</p>
        </div>

        <div 
          onClick={() => onNavigate('optimization')}
          className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-lg p-4 cursor-pointer transition group"
        >
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-slate-200 group-hover:text-cyan-400 transition">Capital Optimization & RAROC</h4>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition" />
          </div>
          <p className="text-xs text-slate-400 mt-1">Re-allocate scarce capital to maximize ROE, RAROC, and minimize total RWA consumption.</p>
        </div>
      </div>
    </div>
  );
};
