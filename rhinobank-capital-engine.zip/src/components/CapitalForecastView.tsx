import React, { useState } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid 
} from 'recharts';
import { LineChart as ChartIcon, Calendar, TrendingUp, Sliders } from 'lucide-react';
import { CapitalHierarchy, TotalRWA, RegulatoryRuleset } from '../types/capital';
import { generateCapitalForecast } from '../engine/forecastEngine';

interface CapitalForecastViewProps {
  hierarchy: CapitalHierarchy;
  totalRWA: TotalRWA;
  ruleset: RegulatoryRuleset;
}

export const CapitalForecastView: React.FC<CapitalForecastViewProps> = ({
  hierarchy,
  totalRWA,
  ruleset,
}) => {
  const [horizonYears, setHorizonYears] = useState(5);
  const [growthPct, setGrowthPct] = useState(3.5);
  const [payoutPct, setPayoutPct] = useState(40);
  const [creditLossesM, setCreditLossesM] = useState(350);

  const forecast = generateCapitalForecast(hierarchy, totalRWA, ruleset, {
    horizonYears,
    annualAssetGrowthPct: growthPct,
    annualNiiGrowthPct: 2.5,
    dividendPayoutRatioPct: payoutPct,
    expectedAnnualCreditLosses: creditLossesM,
    plannedNewCapitalIssuanceYearly: 0,
  });

  const chartData = forecast.map(f => ({
    year: `Year ${f.year}`,
    cet1Ratio: f.cet1Ratio,
    totalCapRatio: f.totalCapitalRatio,
    target: ruleset.minCET1Ratio + ruleset.buffers.capitalConservationBuffer + ruleset.buffers.countercyclicalBuffer + ruleset.buffers.gsibBuffer + ruleset.buffers.pillar2A + ruleset.buffers.managementBuffer,
    cet1Capital: f.closingCET1,
    rwa: f.closingRWA,
  }));

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <ChartIcon className="w-5 h-5 text-cyan-400" />
            <span>Multi-Year Forward Capital & RWA Projections</span>
          </h2>
          <p className="text-xs text-slate-400">
            Project RhinoBank CET1 capital trajectory, retained earnings accretion, and buffer headroom over 1 to 10 years.
          </p>
        </div>

        {/* Horizon selector */}
        <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded border border-slate-800 text-xs font-mono">
          <span className="text-slate-400 px-2">HORIZON:</span>
          {[1, 2, 3, 5, 10].map(y => (
            <button
              key={y}
              onClick={() => setHorizonYears(y)}
              className={`px-2.5 py-1 rounded transition cursor-pointer ${
                horizonYears === y ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {y}Y
            </button>
          ))}
        </div>
      </div>

      {/* Sliders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono bg-slate-900 border border-slate-800 p-4 rounded-lg">
        <div>
          <div className="flex justify-between text-slate-300 mb-1">
            <span>Annual Asset / RWA Growth Rate</span>
            <span className="text-cyan-400 font-bold">{growthPct}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="10"
            step="0.5"
            value={growthPct}
            onChange={(e) => setGrowthPct(Number(e.target.value))}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between text-slate-300 mb-1">
            <span>Dividend Payout Ratio</span>
            <span className="text-amber-400 font-bold">{payoutPct}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="80"
            step="5"
            value={payoutPct}
            onChange={(e) => setPayoutPct(Number(e.target.value))}
            className="w-full accent-amber-500 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between text-slate-300 mb-1">
            <span>Expected Annual Credit Losses</span>
            <span className="text-rose-400 font-bold">${creditLossesM}M</span>
          </div>
          <input
            type="range"
            min="100"
            max="1500"
            step="50"
            value={creditLossesM}
            onChange={(e) => setCreditLossesM(Number(e.target.value))}
            className="w-full accent-rose-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-semibold text-slate-100 mb-4">Projected CET1 & Total Capital Ratio Trajectory</h3>

        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 30, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
              <XAxis dataKey="year" stroke="#64748b" tick={{ fontSize: 12 }} />
              <YAxis stroke="#64748b" unit="%" tick={{ fontSize: 12 }} domain={[10, 'auto']} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc', fontSize: '12px' }}
                formatter={(val: any) => [`${Number(val).toFixed(2)}%`, '']}
              />
              <Line type="monotone" dataKey="cet1Ratio" name="Projected CET1 Ratio" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} />
              <Line type="monotone" dataKey="totalCapRatio" name="Projected Total Capital" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="target" name="Target Capital Stack" stroke="#f59e0b" strokeDasharray="5 5" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Forecast Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase tracking-wider border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Year</th>
              <th className="py-3 px-3 text-right">Net Profit ($M)</th>
              <th className="py-3 px-3 text-right">Retained Earnings ($M)</th>
              <th className="py-3 px-3 text-right">Dividends ($M)</th>
              <th className="py-3 px-3 text-right">Closing CET1 ($M)</th>
              <th className="py-3 px-3 text-right">Closing RWA ($M)</th>
              <th className="py-3 px-3 text-right">CET1 Ratio (%)</th>
              <th className="py-3 px-3 text-right">Headroom ($M)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {forecast.map((yr) => (
              <tr key={yr.year} className="hover:bg-slate-850/50 transition">
                <td className="py-3 px-4 font-bold text-slate-100 font-sans">Year {yr.year}</td>
                <td className="py-3 px-3 text-right text-emerald-400 font-bold">${Math.round(yr.netProfit).toLocaleString()}</td>
                <td className="py-3 px-3 text-right text-slate-200">${Math.round(yr.retainedEarningsAdded).toLocaleString()}</td>
                <td className="py-3 px-3 text-right text-slate-400">${Math.round(yr.dividendsPaid).toLocaleString()}</td>
                <td className="py-3 px-3 text-right font-bold text-emerald-400">${Math.round(yr.closingCET1).toLocaleString()}</td>
                <td className="py-3 px-3 text-right text-indigo-400 font-bold">${Math.round(yr.closingRWA).toLocaleString()}</td>
                <td className="py-3 px-3 text-right font-bold text-cyan-400">{yr.cet1Ratio.toFixed(2)}%</td>
                <td className="py-3 px-3 text-right font-bold text-emerald-400">${Math.round(yr.headroomAmount).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
