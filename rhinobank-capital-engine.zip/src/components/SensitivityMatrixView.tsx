import React, { useState } from 'react';
import { Grid, Layers, ShieldCheck } from 'lucide-react';
import { ExposureItem, RegulatoryRuleset, CapitalHierarchy } from '../types/capital';
import { calculateTotalRWA } from '../engine/rwaEngine';
import { calculateCapitalRatios } from '../engine/capitalEngine';

interface SensitivityMatrixViewProps {
  exposures: ExposureItem[];
  hierarchy: CapitalHierarchy;
  ruleset: RegulatoryRuleset;
}

export const SensitivityMatrixView: React.FC<SensitivityMatrixViewProps> = ({
  exposures,
  hierarchy,
  ruleset,
}) => {
  const pdShifts = [0.8, 1.0, 1.2, 1.5, 2.0, 2.5];
  const lgdShifts = [0.8, 1.0, 1.2, 1.5, 1.8];

  const targetRatio = ruleset.minCET1Ratio + ruleset.buffers.capitalConservationBuffer + ruleset.buffers.countercyclicalBuffer + ruleset.buffers.gsibBuffer + ruleset.buffers.pillar2A + ruleset.buffers.managementBuffer;

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <Grid className="w-5 h-5 text-cyan-400" />
            <span>Capital Sensitivity Matrix (PD vs LGD Shocks)</span>
          </h2>
          <p className="text-xs text-slate-400">
            2D heat-map matrix evaluating CET1 ratio resilience across joint credit default and loss severity stress vectors.
          </p>
        </div>
      </div>

      {/* Heatmap Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 overflow-x-auto">
        <table className="w-full border-collapse text-center text-xs font-mono">
          <thead>
            <tr>
              <th className="p-3 bg-slate-950 text-slate-400 border border-slate-800 font-sans">
                LGD ↓ \ PD →
              </th>
              {pdShifts.map((pd) => (
                <th key={pd} className="p-3 bg-slate-950 text-cyan-400 border border-slate-800 font-bold">
                  {pd.toFixed(1)}x PD
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lgdShifts.map((lgd) => (
              <tr key={lgd}>
                <td className="p-3 bg-slate-950 text-amber-400 border border-slate-800 font-bold text-right font-sans">
                  {lgd.toFixed(1)}x LGD
                </td>
                {pdShifts.map((pd) => {
                  const rwaObj = calculateTotalRWA(exposures, ruleset, 14200, 4200, pd, lgd);
                  const ratios = calculateCapitalRatios(hierarchy, rwaObj.totalRWA, ruleset);
                  const ratio = ratios.cet1Ratio;

                  let bgClass = 'bg-emerald-950/40 text-emerald-300 border-emerald-800/40';
                  if (ratio < ruleset.minCET1Ratio) {
                    bgClass = 'bg-rose-950/80 text-rose-300 border-rose-800/80 font-bold animate-pulse';
                  } else if (ratio < targetRatio) {
                    bgClass = 'bg-amber-950/60 text-amber-300 border-amber-800/60 font-semibold';
                  } else if (ratio < targetRatio + 1.0) {
                    bgClass = 'bg-blue-950/40 text-blue-300 border-blue-800/40';
                  }

                  return (
                    <td key={pd} className={`p-4 border font-mono font-bold transition ${bgClass}`}>
                      <span className="text-sm block">{ratio.toFixed(2)}%</span>
                      <span className="text-[10px] opacity-75">
                        {ratio >= targetRatio ? `+${(ratio - targetRatio).toFixed(1)}%` : `${(ratio - targetRatio).toFixed(1)}%`}
                      </span>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
