import React, { useState } from 'react';
import { Database, Filter, Search, Sliders, Info, ShieldAlert, Award } from 'lucide-react';
import { ExposureItem, ExposureCalculated, ExposureClass, RegulatoryRuleset } from '../types/capital';
import { calculateExposureMetrics } from '../engine/creditRiskEngine';

interface CreditPortfolioViewProps {
  exposures: ExposureItem[];
  ruleset: RegulatoryRuleset;
}

export const CreditPortfolioView: React.FC<CreditPortfolioViewProps> = ({
  exposures,
  ruleset,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClass, setSelectedClass] = useState<string>('ALL');
  const [approachOverride, setApproachOverride] = useState<'ALL' | 'Standardized' | 'IRB'>('ALL');
  const [pdMultiplier, setPdMultiplier] = useState(1.0);
  const [lgdMultiplier, setLgdMultiplier] = useState(1.0);

  // Compute calculated exposures
  const calculated: ExposureCalculated[] = exposures.map(exp => {
    let item = exp;
    if (approachOverride === 'Standardized') {
      item = { ...exp, approach: 'Standardized' };
    } else if (approachOverride === 'IRB' && item.approach === 'Standardized') {
      item = { ...exp, approach: 'AIRB' };
    }
    return calculateExposureMetrics(item, ruleset, pdMultiplier, lgdMultiplier);
  });

  const filtered = calculated.filter(exp => {
    const matchesSearch = 
      exp.counterparty.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.sector.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.country.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesClass = selectedClass === 'ALL' || exp.exposureClass === selectedClass;
    return matchesSearch && matchesClass;
  });

  const totalEAD = filtered.reduce((sum, e) => sum + e.ead, 0);
  const totalRWA = filtered.reduce((sum, e) => sum + e.rwa, 0);
  const totalEL = filtered.reduce((sum, e) => sum + e.expectedLoss, 0);
  const totalRegCap = filtered.reduce((sum, e) => sum + e.regulatoryCapitalReq, 0);
  const avgDensity = totalEAD > 0 ? (totalRWA / totalEAD) * 100 : 0;

  const exposureClasses: ExposureClass[] = [
    'Sovereign', 'Bank', 'Corporate', 'SME', 'Retail',
    'Residential_Mortgage', 'CRE', 'Project_Finance', 'Equity'
  ];

  return (
    <div className="space-y-6">
      {/* Top Filter & Control Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
              <Database className="w-5 h-5 text-cyan-400" />
              <span>Credit Portfolio RWA & IRB Engine</span>
            </h2>
            <p className="text-xs text-slate-400">
              Loan-level credit exposures, PD/LGD risk weights, expected losses, and Basel IRB parameters.
            </p>
          </div>

          <div className="flex items-center space-x-3 text-xs font-mono">
            <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
              <span className="text-slate-400">TOTAL EAD:</span>{' '}
              <span className="text-slate-100 font-bold">${totalEAD.toLocaleString()}M</span>
            </div>
            <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
              <span className="text-slate-400">PORTFOLIO RWA:</span>{' '}
              <span className="text-cyan-400 font-bold">${totalRWA.toLocaleString()}M</span>
            </div>
            <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
              <span className="text-slate-400">RWA DENSITY:</span>{' '}
              <span className="text-amber-400 font-bold">{avgDensity.toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search counterparty, sector, country..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded pl-9 pr-3 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Exposure Class Selector */}
          <div>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Exposure Classes ({exposures.length})</option>
              {exposureClasses.map(cls => (
                <option key={cls} value={cls}>{cls.replace('_', ' ')}</option>
              ))}
            </select>
          </div>

          {/* Approach Override */}
          <div>
            <select
              value={approachOverride}
              onChange={(e) => setApproachOverride(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="ALL">Calculated Approach (IRB / SA Mix)</option>
              <option value="Standardized">Force Standardized Approach (SA)</option>
              <option value="IRB">Force IRB Approach (A-IRB)</option>
            </select>
          </div>

          {/* PD / LGD Shift Sliders */}
          <div className="flex items-center space-x-3 bg-slate-950 border border-slate-800 rounded px-3 py-1 font-mono">
            <div className="flex-1">
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>PD Shift:</span>
                <span className="text-cyan-400 font-bold">{pdMultiplier.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="3.0"
                step="0.1"
                value={pdMultiplier}
                onChange={(e) => setPdMultiplier(parseFloat(e.target.value))}
                className="w-full accent-cyan-500 h-1 cursor-pointer"
              />
            </div>
            <div className="flex-1">
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>LGD Shift:</span>
                <span className="text-amber-400 font-bold">{lgdMultiplier.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.1"
                value={lgdMultiplier}
                onChange={(e) => setLgdMultiplier(parseFloat(e.target.value))}
                className="w-full accent-amber-500 h-1 cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Exposure Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase tracking-wider border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Counterparty / Sector</th>
              <th className="py-3 px-3">Class</th>
              <th className="py-3 px-3 text-right">EAD ($M)</th>
              <th className="py-3 px-3 text-center">Rating</th>
              <th className="py-3 px-3 text-center">Approach</th>
              <th className="py-3 px-3 text-right">PD (%)</th>
              <th className="py-3 px-3 text-right">LGD (%)</th>
              <th className="py-3 px-3 text-right">RW (%)</th>
              <th className="py-3 px-3 text-right">RWA ($M)</th>
              <th className="py-3 px-3 text-right">EL ($M)</th>
              <th className="py-3 px-3 text-right">Reg Cap ($M)</th>
              <th className="py-3 px-3 text-right">RAROC (%)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {filtered.map((item) => (
              <tr key={item.id} className="hover:bg-slate-850/50 transition">
                <td className="py-3 px-4">
                  <span className="font-semibold text-slate-100 block font-sans">{item.counterparty}</span>
                  <span className="text-[10px] text-slate-500 font-sans">{item.sector} • {item.country}</span>
                </td>
                <td className="py-3 px-3">
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {item.exposureClass.replace('_', ' ')}
                  </span>
                </td>
                <td className="py-3 px-3 text-right font-bold text-slate-200">${item.ead.toLocaleString()}</td>
                <td className="py-3 px-3 text-center">
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    item.rating === 'AAA' || item.rating === 'AA' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' :
                    item.rating === 'A' || item.rating === 'BBB' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30' :
                    'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                  }`}>
                    {item.rating}
                  </span>
                </td>
                <td className="py-3 px-3 text-center">
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    item.approach === 'Standardized' ? 'bg-slate-800 text-slate-400' : 'bg-indigo-950 text-indigo-400 border border-indigo-800'
                  }`}>
                    {item.approach}
                  </span>
                </td>
                <td className="py-3 px-3 text-right text-slate-300">{(item.pd * 100).toFixed(2)}%</td>
                <td className="py-3 px-3 text-right text-slate-300">{(item.lgd * 100).toFixed(0)}%</td>
                <td className="py-3 px-3 text-right font-bold text-amber-400">{item.effectiveRiskWeight.toFixed(1)}%</td>
                <td className="py-3 px-3 text-right font-bold text-cyan-400">${item.rwa.toLocaleString()}</td>
                <td className="py-3 px-3 text-right text-rose-400">${item.expectedLoss.toFixed(1)}</td>
                <td className="py-3 px-3 text-right text-slate-200">${item.regulatoryCapitalReq.toFixed(1)}</td>
                <td className="py-3 px-3 text-right">
                  <span className={`font-bold ${item.raroc >= 15 ? 'text-emerald-400' : item.raroc >= 10 ? 'text-cyan-400' : 'text-slate-400'}`}>
                    {item.raroc.toFixed(1)}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
