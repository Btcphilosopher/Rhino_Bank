import React, { useState } from 'react';
import { Sliders, RefreshCw, Zap, TrendingUp, ShieldAlert, Cpu } from 'lucide-react';
import { ExposureItem, RegulatoryRuleset, CapitalHierarchy } from '../types/capital';
import { calculateTotalRWA } from '../engine/rwaEngine';
import { calculateCapitalRatios } from '../engine/capitalEngine';

interface CapitalLabViewProps {
  exposures: ExposureItem[];
  hierarchy: CapitalHierarchy;
  ruleset: RegulatoryRuleset;
}

export const CapitalLabView: React.FC<CapitalLabViewProps> = ({
  exposures,
  hierarchy,
  ruleset,
}) => {
  const [loanGrowthPct, setLoanGrowthPct] = useState(0);
  const [mortgageGrowthPct, setMortgageGrowthPct] = useState(0);
  const [pdMultiplier, setPdMultiplier] = useState(1.0);
  const [lgdMultiplier, setLgdMultiplier] = useState(1.0);
  const [rateShiftBp, setRateShiftBp] = useState(0);
  const [assetPriceShiftPct, setAssetPriceShiftPct] = useState(0);
  const [dividendPayoutPct, setDividendPayoutPct] = useState(40);
  const [newCapitalIssued, setNewCapitalIssued] = useState(0);

  // Apply real-time lab shifts to exposure items
  const adjustedExposures = exposures.map(exp => {
    let growth = 1.0;
    if (exp.exposureClass === 'Residential_Mortgage') {
      growth += mortgageGrowthPct / 100;
    } else {
      growth += loanGrowthPct / 100;
    }
    return {
      ...exp,
      ead: Math.round(exp.ead * growth),
    };
  });

  // Calculate RWA under shifts
  const rwaObj = calculateTotalRWA(adjustedExposures, ruleset, 14200 * (1 + assetPriceShiftPct / 100), 4200, pdMultiplier, lgdMultiplier);

  // Capital hits from AOCI & retained earnings
  const aociHit = rateShiftBp > 0 ? (rateShiftBp / 100) * 80 : 0;
  const labCET1 = Math.max(0, hierarchy.cet1.totalCET1 + newCapitalIssued - aociHit);

  const labHierarchy: CapitalHierarchy = {
    ...hierarchy,
    cet1: {
      ...hierarchy.cet1,
      totalCET1: labCET1,
    },
    totalTier1: labCET1 + hierarchy.at1.totalAT1,
    totalCapital: labCET1 + hierarchy.at1.totalAT1 + hierarchy.tier2.totalTier2,
  };

  const ratios = calculateCapitalRatios(labHierarchy, rwaObj.totalRWA, ruleset);

  const resetLab = () => {
    setLoanGrowthPct(0);
    setMortgageGrowthPct(0);
    setPdMultiplier(1.0);
    setLgdMultiplier(1.0);
    setRateShiftBp(0);
    setAssetPriceShiftPct(0);
    setDividendPayoutPct(40);
    setNewCapitalIssued(0);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <Sliders className="w-5 h-5 text-cyan-400 animate-pulse" />
            <span>RhinoBank Capital Scenario Lab</span>
          </h2>
          <p className="text-xs text-slate-400">
            Real-time interactive control room to simulate macro shocks, asset growth, and capital raising actions.
          </p>
        </div>

        <button
          onClick={resetLab}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono rounded border border-slate-700 transition flex items-center space-x-1.5 cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Lab Sliders</span>
        </button>
      </div>

      {/* Real-time Recalculated Output Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Simulated CET1 Ratio</span>
          <div className="text-2xl font-mono font-bold text-emerald-400 mt-1">
            {ratios.cet1Ratio.toFixed(2)}%
          </div>
          <span className="text-[10px] font-mono text-slate-500">Target: {ratios.totalTargetCET1Ratio.toFixed(2)}%</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Simulated RWA</span>
          <div className="text-2xl font-mono font-bold text-cyan-400 mt-1">
            ${(ratios.totalRWA / 1000).toFixed(1)}B
          </div>
          <span className="text-[10px] font-mono text-slate-500">${ratios.totalRWA.toLocaleString()}M</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Capital Headroom</span>
          <div className={`text-2xl font-mono font-bold mt-1 ${ratios.cet1SurplusDeficitAmount >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            ${ratios.cet1SurplusDeficitAmount.toLocaleString()}M
          </div>
          <span className="text-[10px] font-mono text-slate-500">{ratios.cet1HeadroomPercentage.toFixed(2)}% pts surplus</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Total Capital Ratio</span>
          <div className="text-2xl font-mono font-bold text-blue-400 mt-1">
            {ratios.totalCapitalRatio.toFixed(2)}%
          </div>
          <span className="text-[10px] font-mono text-slate-500">Min: {ruleset.minTotalCapitalRatio}%</span>
        </div>
      </div>

      {/* Sliders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Slider 1: Corporate Loan Growth */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-semibold">Corporate Loan Growth</span>
            <span className="font-mono text-cyan-400 font-bold">{loanGrowthPct > 0 ? '+' : ''}{loanGrowthPct}%</span>
          </div>
          <input
            type="range"
            min="-20"
            max="30"
            step="1"
            value={loanGrowthPct}
            onChange={(e) => setLoanGrowthPct(Number(e.target.value))}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Slider 2: Mortgage Portfolio Growth */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-semibold">Mortgage Portfolio Growth</span>
            <span className="font-mono text-cyan-400 font-bold">{mortgageGrowthPct > 0 ? '+' : ''}{mortgageGrowthPct}%</span>
          </div>
          <input
            type="range"
            min="-20"
            max="30"
            step="1"
            value={mortgageGrowthPct}
            onChange={(e) => setMortgageGrowthPct(Number(e.target.value))}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>

        {/* Slider 3: PD Multiplier */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-semibold">PD Migration (Default Rate)</span>
            <span className="font-mono text-amber-400 font-bold">{pdMultiplier.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="3.5"
            step="0.1"
            value={pdMultiplier}
            onChange={(e) => setPdMultiplier(Number(e.target.value))}
            className="w-full accent-amber-500 cursor-pointer"
          />
        </div>

        {/* Slider 4: LGD Multiplier */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-semibold">LGD Severity Multiplier</span>
            <span className="font-mono text-rose-400 font-bold">{lgdMultiplier.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="2.0"
            step="0.1"
            value={lgdMultiplier}
            onChange={(e) => setLgdMultiplier(Number(e.target.value))}
            className="w-full accent-rose-500 cursor-pointer"
          />
        </div>

        {/* Slider 5: Interest Rate Shift */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-semibold">Yield Curve Shift</span>
            <span className="font-mono text-indigo-400 font-bold">{rateShiftBp > 0 ? '+' : ''}{rateShiftBp} bp</span>
          </div>
          <input
            type="range"
            min="-300"
            max="400"
            step="25"
            value={rateShiftBp}
            onChange={(e) => setRateShiftBp(Number(e.target.value))}
            className="w-full accent-indigo-500 cursor-pointer"
          />
        </div>

        {/* Slider 6: Asset Prices */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-semibold">Trading Book Valuation</span>
            <span className="font-mono text-emerald-400 font-bold">{assetPriceShiftPct > 0 ? '+' : ''}{assetPriceShiftPct}%</span>
          </div>
          <input
            type="range"
            min="-30"
            max="30"
            step="2"
            value={assetPriceShiftPct}
            onChange={(e) => setAssetPriceShiftPct(Number(e.target.value))}
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        {/* Slider 7: Capital Raising */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-semibold">New CET1 Capital Issuance</span>
            <span className="font-mono text-purple-400 font-bold">${newCapitalIssued}M</span>
          </div>
          <input
            type="range"
            min="0"
            max="5000"
            step="250"
            value={newCapitalIssued}
            onChange={(e) => setNewCapitalIssued(Number(e.target.value))}
            className="w-full accent-purple-500 cursor-pointer"
          />
        </div>

        {/* Slider 8: Dividend Payout */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-semibold">Dividend Payout Ratio</span>
            <span className="font-mono text-cyan-400 font-bold">{dividendPayoutPct}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="80"
            step="5"
            value={dividendPayoutPct}
            onChange={(e) => setDividendPayoutPct(Number(e.target.value))}
            className="w-full accent-cyan-500 cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
