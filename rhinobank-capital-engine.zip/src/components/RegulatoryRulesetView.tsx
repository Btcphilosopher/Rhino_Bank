import React from 'react';
import { FileText, CheckCircle2, Sliders, Shield, Globe } from 'lucide-react';
import { RegulatoryRuleset, RegulatoryFramework } from '../types/capital';
import { mockRegulatoryRulesets } from '../data/mockData';

interface RegulatoryRulesetViewProps {
  activeRuleset: RegulatoryFramework;
  onSelectRuleset: (fw: RegulatoryFramework) => void;
}

export const RegulatoryRulesetView: React.FC<RegulatoryRulesetViewProps> = ({
  activeRuleset,
  onSelectRuleset,
}) => {
  const rulesets = Object.values(mockRegulatoryRulesets);

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center space-x-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            <span>Regulatory Frameworks & Ruleset Comparison Engine</span>
          </h2>
          <p className="text-xs text-slate-400">
            Inspect parameters across Basel III, Basel IV Output Floors, US CCAR/Dodd-Frank, EU CRR III, and UK PRA.
          </p>
        </div>
      </div>

      {/* Ruleset Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {rulesets.map((rs) => {
          const isSelected = rs.id === activeRuleset;
          return (
            <div
              key={rs.id}
              onClick={() => onSelectRuleset(rs.id)}
              className={`p-5 rounded-lg border transition cursor-pointer space-y-4 ${
                isSelected
                  ? 'bg-cyan-950/40 border-cyan-500 ring-1 ring-cyan-500/50'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-sm font-semibold text-slate-100">{rs.name}</h3>
                  <span className="text-[10px] text-slate-400 font-mono">{rs.jurisdiction} • {rs.version}</span>
                </div>
                {isSelected && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500 text-slate-950">
                    ACTIVE
                  </span>
                )}
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between p-2 rounded bg-slate-950">
                  <span className="text-slate-400">Min CET1 Ratio</span>
                  <span className="text-slate-200 font-bold">{rs.minCET1Ratio}%</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950">
                  <span className="text-slate-400">Min Tier 1 Ratio</span>
                  <span className="text-slate-200 font-bold">{rs.minTier1Ratio}%</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950">
                  <span className="text-slate-400">Min Total Capital Ratio</span>
                  <span className="text-slate-200 font-bold">{rs.minTotalCapitalRatio}%</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950">
                  <span className="text-slate-400">Output Floor Threshold</span>
                  <span className="text-pink-400 font-bold">{rs.outputFloorPercentage}%</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950">
                  <span className="text-slate-400">Combined Buffer Req</span>
                  <span className="text-amber-400 font-bold">
                    {(rs.buffers.capitalConservationBuffer + rs.buffers.countercyclicalBuffer + rs.buffers.gsibBuffer + rs.buffers.pillar2A).toFixed(2)}%
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>SME Supporting Factor:</span>
                  <span className="font-mono text-slate-200 font-bold">{rs.smeSupportingFactor ? 'Active (0.7619)' : 'None'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Infrastructure Supporting Factor:</span>
                  <span className="font-mono text-slate-200 font-bold">{rs.infraSupportingFactor ? 'Active (0.75)' : 'None'}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
