import { 
  CapitalForecastYear, 
  CapitalHierarchy, 
  TotalRWA, 
  RegulatoryRuleset 
} from '../types/capital';

export interface ForecastParams {
  horizonYears: number; // 1, 2, 3, 5, or 10
  annualAssetGrowthPct: number; // e.g. 3.5%
  annualNiiGrowthPct: number; // e.g. 2.5%
  dividendPayoutRatioPct: number; // e.g. 40%
  expectedAnnualCreditLosses: number; // $ millions
  plannedNewCapitalIssuanceYearly: number; // $ millions
}

export function generateCapitalForecast(
  initialHierarchy: CapitalHierarchy,
  initialRWA: TotalRWA,
  ruleset: RegulatoryRuleset,
  params: ForecastParams
): CapitalForecastYear[] {
  const years: CapitalForecastYear[] = [];
  
  let currentCET1 = initialHierarchy.cet1.totalCET1;
  let currentRWA = initialRWA.finalTotalRWA;

  const baseNII = 4200; // $ millions
  const baseNonNII = 1450; // $ millions
  const baseOpEx = 2800; // $ millions

  for (let i = 1; i <= params.horizonYears; i++) {
    const openingCET1 = currentCET1;
    const openingRWA = currentRWA;

    const nii = baseNII * Math.pow(1 + params.annualNiiGrowthPct / 100, i);
    const nonNii = baseNonNII * Math.pow(1 + (params.annualNiiGrowthPct * 0.8) / 100, i);
    const opex = baseOpEx * Math.pow(1 + 0.02, i); // 2% inflation

    const creditLosses = params.expectedAnnualCreditLosses * Math.pow(1 + 0.03, i - 1);
    const preTaxProfit = nii + nonNii - opex - creditLosses;
    const netProfit = Math.max(0, preTaxProfit * 0.75); // 25% corporate tax rate

    const dividendsPaid = netProfit * (params.dividendPayoutRatioPct / 100);
    const retainedEarningsAdded = netProfit - dividendsPaid;
    const newCapitalRaised = params.plannedNewCapitalIssuanceYearly;

    const closingCET1 = openingCET1 + retainedEarningsAdded + newCapitalRaised;

    // RWA growth
    const rwaGrowthAmount = openingRWA * (params.annualAssetGrowthPct / 100);
    const closingRWA = openingRWA + rwaGrowthAmount;

    const cet1Ratio = (closingCET1 / closingRWA) * 100;
    const totalCapRatio = ((closingCET1 + initialHierarchy.at1.totalAT1 + initialHierarchy.tier2.totalTier2) / closingRWA) * 100;

    const bufReq = ruleset.minCET1Ratio + ruleset.buffers.capitalConservationBuffer + ruleset.buffers.countercyclicalBuffer + ruleset.buffers.gsibBuffer + ruleset.buffers.pillar2A + ruleset.buffers.managementBuffer;
    const headroomAmount = closingCET1 - (closingRWA * bufReq / 100);

    years.push({
      year: i,
      netInterestIncome: nii,
      nonInterestIncome: nonNii,
      operatingExpenses: opex,
      creditLosses,
      netProfit,
      retainedEarningsAdded,
      dividendsPaid,
      newCapitalRaised,
      openingCET1,
      closingCET1,
      openingRWA,
      rwaGrowthAmount,
      closingRWA,
      cet1Ratio,
      totalCapitalRatio: totalCapRatio,
      headroomAmount,
    });

    currentCET1 = closingCET1;
    currentRWA = closingRWA;
  }

  return years;
}
