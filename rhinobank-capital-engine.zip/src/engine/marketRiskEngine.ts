import { MarketRiskRWA, IRRBBResults } from '../types/capital';

export interface YieldCurvePoint {
  tenor: string;
  maturityYears: number;
  baseRate: number; // % (e.g. 4.25%)
}

export const defaultYieldCurve: YieldCurvePoint[] = [
  { tenor: '1M', maturityYears: 1/12, baseRate: 5.25 },
  { tenor: '3M', maturityYears: 0.25, baseRate: 5.10 },
  { tenor: '6M', maturityYears: 0.5, baseRate: 4.85 },
  { tenor: '1Y', maturityYears: 1.0, baseRate: 4.50 },
  { tenor: '2Y', maturityYears: 2.0, baseRate: 4.20 },
  { tenor: '3Y', maturityYears: 3.0, baseRate: 4.05 },
  { tenor: '5Y', maturityYears: 5.0, baseRate: 3.90 },
  { tenor: '7Y', maturityYears: 7.0, baseRate: 3.95 },
  { tenor: '10Y', maturityYears: 10.0, baseRate: 4.05 },
  { tenor: '30Y', maturityYears: 30.0, baseRate: 4.35 },
];

export type CurveShockType = 
  | 'Parallel_Up_200' 
  | 'Parallel_Down_200' 
  | 'Steepener' 
  | 'Flattener' 
  | 'Bull_Steepener' 
  | 'Bear_Steepener' 
  | 'Butterfly'
  | 'Custom';

/**
 * Computes shocked yield curve based on shock scenario
 */
export function calculateShockedCurve(
  baseCurve: YieldCurvePoint[],
  shockType: CurveShockType,
  customShiftBp = 0
): Array<YieldCurvePoint & { shockedRate: number; deltaBp: number }> {
  return baseCurve.map(pt => {
    let deltaBp = 0;
    const t = pt.maturityYears;

    switch (shockType) {
      case 'Parallel_Up_200':
        deltaBp = 200;
        break;
      case 'Parallel_Down_200':
        deltaBp = -200;
        break;
      case 'Steepener':
        // Short rates down -100bp, long rates up +100bp
        deltaBp = -100 + (t / 30) * 200;
        break;
      case 'Flattener':
        // Short rates up +100bp, long rates down -100bp
        deltaBp = 100 - (t / 30) * 200;
        break;
      case 'Bull_Steepener':
        // Short rates down -200bp, long rates down -50bp
        deltaBp = -200 + (t / 30) * 150;
        break;
      case 'Bear_Steepener':
        // Short rates up +50bp, long rates up +200bp
        deltaBp = 50 + (t / 30) * 150;
        break;
      case 'Butterfly':
        // Mid-curve up +150bp, ends flat
        deltaBp = 150 * Math.sin((t / 30) * Math.PI);
        break;
      case 'Custom':
        deltaBp = customShiftBp;
        break;
    }

    const shockedRate = Math.max(0.01, pt.baseRate + deltaBp / 100);
    return {
      ...pt,
      shockedRate,
      deltaBp,
    };
  });
}

/**
 * Calculates Market Risk RWA under FRTB Sensitivity-Based Method & Default Risk Charge
 */
export function calculateMarketRiskRWA(
  tradingBookValue: number, // in $ millions
  shockMultiplier = 1.0
): MarketRiskRWA {
  const interestRateRisk = tradingBookValue * 0.18 * shockMultiplier * 12.5;
  const fxRisk = tradingBookValue * 0.08 * shockMultiplier * 12.5;
  const equityRisk = tradingBookValue * 0.12 * shockMultiplier * 12.5;
  const commodityRisk = tradingBookValue * 0.05 * shockMultiplier * 12.5;
  const creditSpreadRisk = tradingBookValue * 0.15 * shockMultiplier * 12.5;

  const totalMarketRWA = interestRateRisk + fxRisk + equityRisk + commodityRisk + creditSpreadRisk;

  return {
    interestRateRisk,
    fxRisk,
    equityRisk,
    commodityRisk,
    creditSpreadRisk,
    totalMarketRWA,
  };
}

/**
 * Computes Banking Book Interest Rate Risk (IRRBB) Repricing Gap and Sensitivity
 */
export function calculateIRRBB(
  totalAssets: number,
  totalLiabilities: number,
  tier1Capital: number,
  shockType: CurveShockType = 'Parallel_Up_200'
): IRRBBResults {
  // Repricing buckets
  const buckets = [
    { bucket: '< 3 Months', assetPct: 0.35, liabPct: 0.55 },
    { bucket: '3M - 1 Year', assetPct: 0.25, liabPct: 0.25 },
    { bucket: '1Y - 3 Years', assetPct: 0.20, liabPct: 0.12 },
    { bucket: '3Y - 5 Years', assetPct: 0.12, liabPct: 0.05 },
    { bucket: '> 5 Years', assetPct: 0.08, liabPct: 0.03 },
  ];

  let cumulativeGap = 0;
  const repricingGap = buckets.map(b => {
    const assets = totalAssets * b.assetPct;
    const liabilities = totalLiabilities * b.liabPct;
    const gap = assets - liabilities;
    cumulativeGap += gap;
    return {
      bucket: b.bucket,
      assets,
      liabilities,
      gap,
      cumulativeGap,
    };
  });

  // EVE (Economic Value of Equity) and NII Sensitivity under 6 standard BCBS shocks
  const scenarios: CurveShockType[] = [
    'Parallel_Up_200',
    'Parallel_Down_200',
    'Steepener',
    'Flattener',
    'Bull_Steepener',
    'Bear_Steepener',
  ];

  const durationAssets = 3.2; // years
  const durationLiabilities = 1.1; // years

  const eveSensitivity = scenarios.map(scen => {
    const shockedCurve = calculateShockedCurve(defaultYieldCurve, scen);
    const avgDeltaBp = shockedCurve.reduce((sum, p) => sum + p.deltaBp, 0) / shockedCurve.length;
    
    // EVE delta = - [Asset_Value * D_A - Liab_Value * D_L] * delta_r
    const assetValueDelta = -totalAssets * durationAssets * (avgDeltaBp / 10000);
    const liabValueDelta = -totalLiabilities * durationLiabilities * (avgDeltaBp / 10000);
    const deltaEVE = assetValueDelta - liabValueDelta;
    const percentageEVE = tier1Capital > 0 ? (deltaEVE / tier1Capital) * 100 : 0;

    return {
      scenario: scen.replace(/_/g, ' '),
      deltaEVE,
      percentageEVE,
    };
  });

  const niiSensitivity = scenarios.map(scen => {
    const gapShortTerm = repricingGap[0].gap + repricingGap[1].gap; // < 1Y gap
    const shockedCurve = calculateShockedCurve(defaultYieldCurve, scen);
    const shortTermDeltaBp = (shockedCurve[0].deltaBp + shockedCurve[1].deltaBp + shockedCurve[2].deltaBp) / 3;
    const deltaNII = gapShortTerm * (shortTermDeltaBp / 10000);
    const baseNII = totalAssets * 0.025; // assumed 2.5% net interest margin
    const percentageNII = baseNII > 0 ? (deltaNII / baseNII) * 100 : 0;

    return {
      scenario: scen.replace(/_/g, ' '),
      deltaNII,
      percentageNII,
    };
  });

  return {
    repricingGap,
    eveSensitivity,
    niiSensitivity,
  };
}
