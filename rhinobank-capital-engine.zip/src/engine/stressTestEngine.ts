import { 
  ExposureItem, 
  RegulatoryRuleset, 
  CapitalHierarchy, 
  StressScenario, 
  StressTestResult 
} from '../types/capital';
import { calculateTotalRWA } from './rwaEngine';
import { calculateCapitalHierarchy, calculateCapitalRatios } from './capitalEngine';

/**
 * Executes a stress test scenario on RhinoBank's capital position
 */
export function runStressScenario(
  scenario: StressScenario,
  exposures: ExposureItem[],
  capitalHierarchy: CapitalHierarchy,
  ruleset: RegulatoryRuleset,
  tradingBookValue: number,
  grossIncome: number
): StressTestResult {
  // 1. Calculate Pre-Stress Baseline
  const preRWA = calculateTotalRWA(exposures, ruleset, tradingBookValue, grossIncome);
  const preRatios = calculateCapitalRatios(capitalHierarchy, preRWA.totalRWA, ruleset);

  const preStress = {
    cet1Capital: capitalHierarchy.cet1.totalCET1,
    rwa: preRWA.totalRWA.finalTotalRWA,
    cet1Ratio: preRatios.cet1Ratio,
  };

  // 2. Apply Stress Shocks
  // Stress Credit Risk: apply scenario PD & LGD multipliers
  const postRWAObj = calculateTotalRWA(
    exposures,
    ruleset,
    tradingBookValue * (1 + scenario.assetPriceDrop / 100),
    grossIncome * (1 - Math.abs(scenario.gdpChange) / 10),
    scenario.pdMultiplier,
    scenario.lgdMultiplier
  );

  // Calculate Credit Default Losses arising from stress
  const preTotalEL = preRWA.calculatedExposures.reduce((s, e) => s + e.expectedLoss, 0);
  const postTotalEL = postRWAObj.calculatedExposures.reduce((s, e) => s + e.expectedLoss, 0);
  const stressedCreditLosses = postTotalEL - preTotalEL;

  // Trading Losses & AOCI hits from rate shift
  const aociRateHit = scenario.interestRateShiftBp > 0 ? (scenario.interestRateShiftBp / 100) * 120 : 0;
  const totalStressedLosses = stressedCreditLosses + scenario.tradingLosses + aociRateHit;

  // Stressed CET1 Capital
  const postCET1Capital = Math.max(0, capitalHierarchy.cet1.totalCET1 - totalStressedLosses);
  
  const postHierarchy: CapitalHierarchy = {
    ...capitalHierarchy,
    cet1: {
      ...capitalHierarchy.cet1,
      totalCET1: postCET1Capital,
    },
    totalTier1: postCET1Capital + capitalHierarchy.at1.totalAT1,
    totalCapital: postCET1Capital + capitalHierarchy.at1.totalAT1 + capitalHierarchy.tier2.totalTier2,
  };

  const postRatios = calculateCapitalRatios(postHierarchy, postRWAObj.totalRWA, ruleset);

  const headroomDelta = postRatios.cet1HeadroomPercentage - preRatios.cet1HeadroomPercentage;
  const bufferBreached = postRatios.cet1Ratio < (ruleset.minCET1Ratio + preRatios.combinedBufferReq);
  const capitalDeficitAmount = postRatios.cet1SurplusDeficitAmount < 0 ? Math.abs(postRatios.cet1SurplusDeficitAmount) : 0;

  return {
    scenario,
    preStress,
    postStress: {
      losses: totalStressedLosses,
      cet1Capital: postCET1Capital,
      rwa: postRWAObj.totalRWA.finalTotalRWA,
      cet1Ratio: postRatios.cet1Ratio,
      tier1Ratio: postRatios.tier1Ratio,
      totalCapitalRatio: postRatios.totalCapitalRatio,
      headroomDelta,
      bufferBreached,
      capitalDeficitAmount,
    },
  };
}
