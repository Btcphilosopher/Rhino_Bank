import { 
  ExposureItem, 
  ExposureCalculated, 
  RegulatoryRuleset, 
  CreditRiskRWA, 
  MarketRiskRWA, 
  OpRiskRWA, 
  OtherRWA, 
  TotalRWA, 
  ExposureClass, 
  CreditApproach 
} from '../types/capital';
import { calculateExposureMetrics, calculateStandardizedRiskWeight } from './creditRiskEngine';
import { calculateMarketRiskRWA } from './marketRiskEngine';

/**
 * Calculates Operational Risk RWA under Basel Standardized Measurement Approach (SMA)
 */
export function calculateOpRiskRWA(
  grossIncome: number, // $ millions
  tradingIncome: number,
  feeIncome: number,
  internalLossMultiplier = 1.0
): OpRiskRWA {
  // Business Indicator (BI) = Interest, Lease & Dividend Component + Services Component + Financial Component
  const BI = grossIncome + feeIncome * 1.2 + tradingIncome * 1.5;
  
  // Business Indicator Component (BIC) bucketed formula:
  // BI <= 1000m: 12%
  // 1000m < BI <= 30000m: 120m + 15% * (BI - 1000m)
  // BI > 30000m: 4470m + 18% * (BI - 30000m)
  let BIC = 0;
  if (BI <= 1000) {
    BIC = BI * 0.12;
  } else if (BI <= 30000) {
    BIC = 120 + 0.15 * (BI - 1000);
  } else {
    BIC = 4470 + 0.18 * (BI - 30000);
  }

  const opRiskCapital = BIC * internalLossMultiplier;
  const totalOpRiskRWA = opRiskCapital * 12.5;

  return {
    businessIndicator: BI,
    businessIndicatorComponent: BIC,
    internalLossMultiplier,
    totalOpRiskRWA,
  };
}

/**
 * Calculates CVA and Securitization RWA
 */
export function calculateOtherRWA(totalCreditRWA: number): OtherRWA {
  const cvaRWA = totalCreditRWA * 0.035; // ~3.5% of Credit RWA for OTC derivative CVA
  const securitisationRWA = totalCreditRWA * 0.025; // ~2.5% of Credit RWA

  return {
    cvaRWA,
    securitisationRWA,
    totalOtherRWA: cvaRWA + securitisationRWA,
  };
}

/**
 * Aggregates all RWA components and applies Basel IV Output Floor if applicable
 */
export function calculateTotalRWA(
  exposures: ExposureItem[],
  ruleset: RegulatoryRuleset,
  tradingBookValue: number,
  grossIncome: number,
  pdMultiplier = 1.0,
  lgdMultiplier = 1.0
): {
  calculatedExposures: ExposureCalculated[];
  creditRiskRWA: CreditRiskRWA;
  marketRiskRWA: MarketRiskRWA;
  opRiskRWA: OpRiskRWA;
  otherRWA: OtherRWA;
  totalRWA: TotalRWA;
} {
  // 1. Calculate each exposure item
  const calculatedExposures = exposures.map(item => 
    calculateExposureMetrics(item, ruleset, pdMultiplier, lgdMultiplier)
  );

  // 2. Aggregate Credit RWA by Class and Approach
  const emptyClassAgg: Record<ExposureClass, { ead: number; rwa: number; el: number }> = {
    Sovereign: { ead: 0, rwa: 0, el: 0 },
    Bank: { ead: 0, rwa: 0, el: 0 },
    Corporate: { ead: 0, rwa: 0, el: 0 },
    SME: { ead: 0, rwa: 0, el: 0 },
    Retail: { ead: 0, rwa: 0, el: 0 },
    Residential_Mortgage: { ead: 0, rwa: 0, el: 0 },
    CRE: { ead: 0, rwa: 0, el: 0 },
    Project_Finance: { ead: 0, rwa: 0, el: 0 },
    Specialized_Lending: { ead: 0, rwa: 0, el: 0 },
    Equity: { ead: 0, rwa: 0, el: 0 },
    Other: { ead: 0, rwa: 0, el: 0 },
  };

  const emptyApproachAgg: Record<CreditApproach, { ead: number; rwa: number }> = {
    Standardized: { ead: 0, rwa: 0 },
    FIRB: { ead: 0, rwa: 0 },
    AIRB: { ead: 0, rwa: 0 },
  };

  let totalCreditRWA = 0;
  let totalStandardizedRWA = 0;
  let totalIRBRWA = 0;
  let pureStandardizedCreditRWA = 0; // Pure SA RWA for all exposures for Output Floor comparison

  calculatedExposures.forEach(exp => {
    totalCreditRWA += exp.rwa;
    
    // Class agg
    emptyClassAgg[exp.exposureClass].ead += exp.ead;
    emptyClassAgg[exp.exposureClass].rwa += exp.rwa;
    emptyClassAgg[exp.exposureClass].el += exp.expectedLoss;

    // Approach agg
    emptyApproachAgg[exp.approach].ead += exp.ead;
    emptyApproachAgg[exp.approach].rwa += exp.rwa;

    if (exp.approach === 'Standardized') {
      totalStandardizedRWA += exp.rwa;
    } else {
      totalIRBRWA += exp.rwa;
    }

    // Pure SA risk weight equivalent
    const saRw = calculateStandardizedRiskWeight(exp, ruleset);
    pureStandardizedCreditRWA += (exp.ead * saRw) / 100;
  });

  const creditRiskRWA: CreditRiskRWA = {
    byClass: emptyClassAgg,
    byApproach: emptyApproachAgg,
    totalStandardizedRWA,
    totalIRBRWA,
    totalCreditRWA,
  };

  // 3. Market Risk RWA
  const marketRiskRWA = calculateMarketRiskRWA(tradingBookValue);

  // 4. Op Risk RWA
  const opRiskRWA = calculateOpRiskRWA(grossIncome, tradingBookValue * 0.05, grossIncome * 0.25);

  // 5. Other RWA (CVA, Securitisation)
  const otherRWA = calculateOtherRWA(totalCreditRWA);

  // Raw total RWA before floor
  const rawTotalRWA = creditRiskRWA.totalCreditRWA + marketRiskRWA.totalMarketRWA + opRiskRWA.totalOpRiskRWA + otherRWA.totalOtherRWA;

  // Pure Standardized total RWA for Output Floor
  const pureStandardizedTotalRWA = pureStandardizedCreditRWA + marketRiskRWA.totalMarketRWA + opRiskRWA.totalOpRiskRWA + otherRWA.totalOtherRWA;

  // Output Floor calculation (e.g. 72.5% of Standardized Total RWA)
  const outputFloorPercentage = ruleset.outputFloorPercentage || 0;
  const outputFloorThreshold = pureStandardizedTotalRWA * (outputFloorPercentage / 100);

  const outputFloorApplied = outputFloorPercentage > 0 && rawTotalRWA < outputFloorThreshold;
  const outputFloorRWA = outputFloorApplied ? outputFloorThreshold - rawTotalRWA : 0;
  const finalTotalRWA = Math.max(rawTotalRWA, outputFloorThreshold);

  const totalRWA: TotalRWA = {
    creditRWA: creditRiskRWA.totalCreditRWA,
    marketRWA: marketRiskRWA.totalMarketRWA,
    opRiskRWA: opRiskRWA.totalOpRiskRWA,
    otherRWA: otherRWA.totalOtherRWA,
    rawTotalRWA,
    outputFloorThreshold,
    outputFloorRWA,
    outputFloorApplied,
    finalTotalRWA,
  };

  return {
    calculatedExposures,
    creditRiskRWA,
    marketRiskRWA,
    opRiskRWA,
    otherRWA,
    totalRWA,
  };
}
