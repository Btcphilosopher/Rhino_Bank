import { ExposureItem, ExposureCalculated, ExposureClass, RegulatoryRuleset } from '../types/capital';

/**
 * Standard Normal Cumulative Distribution Function N(x) using Moro's / Abramowitz & Stegun approximation
 */
export function normCDF(x: number): number {
  if (x < -10) return 0;
  if (x > 10) return 1;
  const b1 = 0.319381530;
  const b2 = -0.356563782;
  const b3 = 1.781477937;
  const b4 = -1.821255978;
  const b5 = 1.330274429;
  const p = 0.2316419;
  const c = 0.39894228;

  if (x >= 0) {
    const t = 1.0 / (1.0 + p * x);
    return 1.0 - c * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  } else {
    const t = 1.0 / (1.0 - p * x);
    return c * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  }
}

/**
 * Inverse Standard Normal CDF N^-1(p) using Moro's algorithm
 */
export function normInv(p: number): number {
  if (p <= 0) return -7.0;
  if (p >= 1) return 7.0;

  const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
             1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
  const b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
             6.680131188771972e+01, -1.328068155288572e+01];
  const c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
             -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
  const d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
             3.754408661907416e+00];

  const pLow = 0.02425;
  const pHigh = 1 - pLow;
  let q: number, r: number;

  if (p < pLow) {
    q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
           ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  } else if (p <= pHigh) {
    q = p - 0.5;
    r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q /
           (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  } else {
    q = Math.sqrt(-2 * Math.log(1 - p));
    return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
}

/**
 * Calculates Basel IRB Asset Correlation (R or rho) based on exposure class and PD
 */
export function calculateAssetCorrelation(exposureClass: ExposureClass, pd: number): number {
  const boundedPD = Math.max(0.0003, Math.min(0.9999, pd));

  switch (exposureClass) {
    case 'Residential_Mortgage':
      return 0.15;
    case 'Retail':
      return 0.04; // QRRE standard
    case 'CRE':
      return 0.20;
    case 'SME': {
      // SME firm size correlation adjustment
      const baseR = 0.12 * ((1 - Math.exp(-50 * boundedPD)) / (1 - Math.exp(-50))) +
                    0.24 * (1 - ((1 - Math.exp(-50 * boundedPD)) / (1 - Math.exp(-50))));
      return baseR - 0.04; // typical SME discount offset
    }
    case 'Sovereign':
    case 'Bank':
    case 'Corporate':
    case 'Project_Finance':
    case 'Specialized_Lending':
    default: {
      const expFactor = (1 - Math.exp(-50 * boundedPD)) / (1 - Math.exp(-50));
      return 0.12 * expFactor + 0.24 * (1 - expFactor);
    }
  }
}

/**
 * Calculates Basel IRB Capital Requirement K factor and Risk Weight
 */
export function calculateIRBRiskWeight(
  exposureClass: ExposureClass,
  pd: number,
  lgd: number,
  maturity: number
): { kFactor: number; riskWeight: number; correlation: number; maturityAdj: number } {
  // Enforce regulatory floors on PD (e.g. 0.05% for corporates under Basel IV, 0.03% for mortgages)
  const pdFloor = exposureClass === 'Residential_Mortgage' ? 0.0003 : 0.0005;
  const boundedPD = Math.max(pdFloor, Math.min(0.9999, pd));
  const boundedLGD = Math.max(0.05, Math.min(1.0, lgd));
  const boundedM = Math.max(1.0, Math.min(5.0, maturity));

  const R = calculateAssetCorrelation(exposureClass, boundedPD);
  const invPD = normInv(boundedPD);
  const inv999 = normInv(0.999);

  // Conditional default probability at 99.9% confidence level
  const G = (invPD + Math.sqrt(R) * inv999) / Math.sqrt(1 - R);
  const conditionalPD = normCDF(G);

  // Capital requirement K before maturity adjustment
  const kBase = boundedLGD * conditionalPD - boundedLGD * boundedPD;

  // Maturity adjustment factor b(PD)
  let maturityFactor = 1.0;
  let b = 0.0;
  if (exposureClass !== 'Residential_Mortgage' && exposureClass !== 'Retail') {
    const lnPD = Math.log(boundedPD);
    b = Math.pow(0.11852 - 0.05478 * lnPD, 2);
    maturityFactor = (1 + (boundedM - 2.5) * b) / (1 - 1.5 * b);
  }

  const K = Math.max(0, kBase * maturityFactor);
  // Risk Weight % = K * 12.5 (multiplier to convert capital to RWA)
  const riskWeight = K * 12.5 * 100;

  return {
    kFactor: K,
    riskWeight: Math.max(0, riskWeight),
    correlation: R,
    maturityAdj: maturityFactor,
  };
}

/**
 * Look up Standardized Approach Risk Weight based on exposure class, rating, and LTV
 */
export function calculateStandardizedRiskWeight(
  exposure: ExposureItem,
  ruleset: RegulatoryRuleset
): number {
  const { exposureClass, rating, ltv } = exposure;

  // Check rating-based lookup for Sovereign, Bank, Corporate
  if (exposureClass === 'Sovereign') {
    switch (rating) {
      case 'AAA':
      case 'AA': return 0;
      case 'A': return 20;
      case 'BBB': return 50;
      case 'BB':
      case 'B': return 100;
      case 'CCC': return 150;
      default: return 100;
    }
  }

  if (exposureClass === 'Bank') {
    switch (rating) {
      case 'AAA':
      case 'AA': return 20;
      case 'A': return 50;
      case 'BBB': return 50;
      case 'BB':
      case 'B': return 100;
      case 'CCC': return 150;
      default: return 50;
    }
  }

  if (exposureClass === 'Corporate') {
    let rw = 100;
    switch (rating) {
      case 'AAA':
      case 'AA': rw = 20; break;
      case 'A': rw = 50; break;
      case 'BBB': rw = 75; break;
      case 'BB': rw = 100; break;
      case 'B':
      case 'CCC': rw = 150; break;
      default: rw = 100; break;
    }
    return rw;
  }

  if (exposureClass === 'SME') {
    const baseRw = 75;
    // EU CRR SME supporting factor (0.7619 discount factor)
    if (ruleset.smeSupportingFactor) {
      return baseRw * 0.7619;
    }
    return baseRw;
  }

  if (exposureClass === 'Residential_Mortgage') {
    if (ruleset.saMortgageLTVBuckets && ltv !== undefined) {
      if (ltv <= 0.50) return 20;
      if (ltv <= 0.60) return 25;
      if (ltv <= 0.80) return 30;
      if (ltv <= 0.90) return 40;
      if (ltv <= 1.00) return 50;
      return 70;
    }
    return exposure.riskWeightSA || 35;
  }

  if (exposureClass === 'CRE') {
    if (ltv !== undefined && ltv > 0.80) return 150;
    return exposure.riskWeightSA || 100;
  }

  if (exposureClass === 'Retail') {
    return 75;
  }

  if (exposureClass === 'Equity') {
    return 250;
  }

  if (exposureClass === 'Project_Finance') {
    if (ruleset.infraSupportingFactor) {
      return 75 * 0.75; // infrastructure discount
    }
    return 100;
  }

  return exposure.riskWeightSA || 100;
}

/**
 * Computes full calculated metrics for a single exposure item
 */
export function calculateExposureMetrics(
  item: ExposureItem,
  ruleset: RegulatoryRuleset,
  pdMultiplier = 1.0,
  lgdMultiplier = 1.0
): ExposureCalculated {
  const adjustedPD = Math.min(0.9999, item.pd * pdMultiplier);
  const adjustedLGD = Math.min(1.0, item.lgd * lgdMultiplier);

  let effectiveRiskWeight = item.riskWeightSA;

  if (item.approach === 'Standardized' || !ruleset.enableIRB) {
    effectiveRiskWeight = calculateStandardizedRiskWeight(item, ruleset);
  } else {
    // FIRB or AIRB approach
    const irb = calculateIRBRiskWeight(item.exposureClass, adjustedPD, adjustedLGD, item.maturity);
    effectiveRiskWeight = irb.riskWeight;
  }

  const rwa = (item.ead * effectiveRiskWeight) / 100;
  const expectedLoss = adjustedPD * adjustedLGD * item.ead;
  
  // Unexpected loss calculation at 99.9% VaR
  const regCapReq = rwa * 0.08;
  const unexpectedLoss = Math.max(0, regCapReq - expectedLoss);
  
  // Economic Capital (99.9% VaR includes buffer for systemic correlation)
  const economicCapital = regCapReq * 1.15;

  // Profitability metrics
  const netIncome = item.annualRevenue - item.annualExpenses - expectedLoss;
  const raroc = economicCapital > 0 ? (netIncome / economicCapital) * 100 : 0;
  const rorac = regCapReq > 0 ? (netIncome / regCapReq) * 100 : 0;
  
  // Allocated CET1 capital (assuming 10.5% CET1 target of RWA)
  const capitalConsumed = rwa * 0.105;
  const roe = capitalConsumed > 0 ? (netIncome / capitalConsumed) * 100 : 0;

  const capitalDensity = item.ead > 0 ? (rwa / item.ead) * 100 : 0;
  const revenuePerCapital = capitalConsumed > 0 ? item.annualRevenue / capitalConsumed : 0;
  const profitPerCapital = capitalConsumed > 0 ? netIncome / capitalConsumed : 0;

  return {
    ...item,
    pd: adjustedPD,
    lgd: adjustedLGD,
    effectiveRiskWeight,
    rwa,
    expectedLoss,
    unexpectedLoss,
    economicCapital,
    regulatoryCapitalReq: regCapReq,
    raroc,
    rorac,
    roe,
    capitalConsumed,
    capitalDensity,
    revenuePerCapital,
    profitPerCapital,
  };
}
