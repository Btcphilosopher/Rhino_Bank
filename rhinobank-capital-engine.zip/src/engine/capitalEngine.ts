import { 
  CET1Components, 
  AT1Components, 
  Tier2Components, 
  CapitalHierarchy, 
  RegulatoryRuleset, 
  TotalRWA, 
  CapitalRatios,
  AuditLineageStep
} from '../types/capital';

/**
 * Calculates net CET1, AT1, Tier 1, Tier 2 and Total Capital from component objects
 */
export function calculateCapitalHierarchy(
  cet1Inputs: CET1Components,
  at1Inputs: AT1Components,
  tier2Inputs: Tier2Components
): CapitalHierarchy {
  // CET1 Capital
  const totalCET1 = 
    cet1Inputs.commonShares +
    cet1Inputs.sharePremium +
    cet1Inputs.retainedEarnings +
    cet1Inputs.aoci +
    cet1Inputs.qualifyingReserves +
    cet1Inputs.minorityInterestCET1 +
    cet1Inputs.lessGoodwill +
    cet1Inputs.lessIntangibles +
    cet1Inputs.lessDta +
    cet1Inputs.lessPrudentialValuation +
    cet1Inputs.lessOtherDeductions;

  const cet1: CET1Components = {
    ...cet1Inputs,
    totalCET1: Math.max(0, totalCET1),
  };

  // AT1 Capital
  const totalAT1 = 
    at1Inputs.qualifyingAT1Instruments +
    at1Inputs.sharePremiumAT1 +
    at1Inputs.lessDeductionsAT1;

  const at1: AT1Components = {
    ...at1Inputs,
    totalAT1: Math.max(0, totalAT1),
  };

  const totalTier1 = cet1.totalCET1 + at1.totalAT1;

  // Tier 2 Capital
  const totalTier2 = 
    tier2Inputs.subordinatedDebt +
    tier2Inputs.eligibleProvisions +
    tier2Inputs.generalCreditRiskAdjustments +
    tier2Inputs.lessDeductionsTier2;

  const tier2: Tier2Components = {
    ...tier2Inputs,
    totalTier2: Math.max(0, totalTier2),
  };

  const totalCapital = totalTier1 + tier2.totalTier2;

  return {
    cet1,
    at1,
    tier2,
    totalTier1,
    totalCapital,
  };
}

/**
 * Calculates Capital Ratios, Regulatory Requirements, Buffers, and Headroom
 */
export function calculateCapitalRatios(
  capitalHierarchy: CapitalHierarchy,
  totalRWA: TotalRWA,
  ruleset: RegulatoryRuleset
): CapitalRatios {
  const rwa = Math.max(1.0, totalRWA.finalTotalRWA);
  const { totalCET1 } = capitalHierarchy.cet1;
  const { totalTier1, totalCapital } = capitalHierarchy;

  const cet1Ratio = (totalCET1 / rwa) * 100;
  const tier1Ratio = (totalTier1 / rwa) * 100;
  const totalCapitalRatio = (totalCapital / rwa) * 100;

  const minCET1Req = ruleset.minCET1Ratio;
  const minTier1Req = ruleset.minTier1Ratio;
  const minTotalCapitalReq = ruleset.minTotalCapitalRatio;

  const buf = ruleset.buffers;
  const combinedBufferReq = 
    buf.capitalConservationBuffer +
    buf.countercyclicalBuffer +
    buf.gsibBuffer +
    buf.pillar2A;

  const totalTargetCET1Ratio = minCET1Req + combinedBufferReq + buf.managementBuffer;
  const totalTargetCapitalRatio = minTotalCapitalReq + combinedBufferReq + buf.managementBuffer;

  // Capital Headroom in % and $
  const cet1HeadroomPercentage = cet1Ratio - totalTargetCET1Ratio;
  const cet1RequiredAmount = (rwa * totalTargetCET1Ratio) / 100;
  const cet1SurplusDeficitAmount = totalCET1 - cet1RequiredAmount;

  const tier1RequiredAmount = (rwa * (minTier1Req + combinedBufferReq)) / 100;
  const tier1SurplusDeficitAmount = totalTier1 - tier1RequiredAmount;

  const totalCapRequiredAmount = (rwa * totalTargetCapitalRatio) / 100;
  const totalCapitalSurplusDeficitAmount = totalCapital - totalCapRequiredAmount;

  let status: 'OPTIMAL' | 'ADEQUATE' | 'WARNING' | 'DEFICIT' = 'OPTIMAL';
  if (cet1SurplusDeficitAmount < 0) {
    status = 'DEFICIT';
  } else if (cet1Ratio < minCET1Req + combinedBufferReq) {
    status = 'WARNING';
  } else if (cet1HeadroomPercentage < 1.0) {
    status = 'ADEQUATE';
  }

  return {
    cet1Capital: totalCET1,
    tier1Capital: totalTier1,
    totalCapital,
    totalRWA: rwa,
    cet1Ratio,
    tier1Ratio,
    totalCapitalRatio,
    minCET1Req,
    minTier1Req,
    minTotalCapitalReq,
    combinedBufferReq,
    totalTargetCET1Ratio,
    totalTargetCapitalRatio,
    cet1SurplusDeficitAmount,
    cet1HeadroomPercentage,
    tier1SurplusDeficitAmount,
    totalCapitalSurplusDeficitAmount,
    status,
  };
}

/**
 * Generates audit lineage steps for a specific ratio or metric
 */
export function generateAuditLineage(
  metricName: string,
  capitalHierarchy: CapitalHierarchy,
  totalRWA: TotalRWA,
  ratios: CapitalRatios,
  ruleset: RegulatoryRuleset
): AuditLineageStep[] {
  const steps: AuditLineageStep[] = [
    {
      stepNumber: 1,
      title: 'CET1 Common Equity Tier 1 Aggregation',
      formulaName: 'CET1_Sum',
      expression: 'Common Shares + Premium + Retained Earnings + Reserves - Deductions',
      inputs: {
        'Common Shares': capitalHierarchy.cet1.commonShares,
        'Retained Earnings': capitalHierarchy.cet1.retainedEarnings,
        'Goodwill & Intangibles Deduction': capitalHierarchy.cet1.lessGoodwill + capitalHierarchy.cet1.lessIntangibles,
      },
      outputValue: `$${capitalHierarchy.cet1.totalCET1.toLocaleString()}M`,
      description: 'Sum of high-quality capital items less regulatory deductions specified by the selected ruleset.',
    },
    {
      stepNumber: 2,
      title: 'Risk-Weighted Assets (RWA) Determination',
      formulaName: 'Total_RWA_Formula',
      expression: 'Credit RWA + Market RWA + Operational RWA + CVA RWA (with Output Floor check)',
      inputs: {
        'Credit Risk RWA': totalRWA.creditRWA,
        'Market Risk RWA': totalRWA.marketRWA,
        'Operational Risk RWA': totalRWA.opRiskRWA,
        'Output Floor Threshold': totalRWA.outputFloorThreshold,
      },
      outputValue: `$${totalRWA.finalTotalRWA.toLocaleString()}M`,
      description: `Aggregated RWA across all risk types. ${totalRWA.outputFloorApplied ? 'Output Floor of ' + ruleset.outputFloorPercentage + '% WAS APPLIED.' : 'Output Floor threshold satisfied.'}`,
    },
    {
      stepNumber: 3,
      title: 'CET1 Ratio Computation',
      formulaName: 'CET1_Ratio = (CET1_Capital / Total_RWA) * 100',
      expression: `(${capitalHierarchy.cet1.totalCET1} / ${totalRWA.finalTotalRWA}) * 100`,
      inputs: {
        'CET1 Capital': capitalHierarchy.cet1.totalCET1,
        'Total RWA': totalRWA.finalTotalRWA,
      },
      outputValue: `${ratios.cet1Ratio.toFixed(2)}%`,
      description: 'Core solvency ratio measuring bank capacity to absorb losses on a going-concern basis.',
    },
    {
      stepNumber: 4,
      title: 'Combined Buffer & Target Stack Evaluation',
      formulaName: 'Target_Stack = Minimum (4.5%) + CCb + CCyB + GSIB + P2A + Management Buffer',
      expression: `${ruleset.minCET1Ratio}% + ${ruleset.buffers.capitalConservationBuffer}% (CCb) + ${ruleset.buffers.countercyclicalBuffer}% (CCyB) + ${ruleset.buffers.gsibBuffer}% (GSIB) + ${ruleset.buffers.pillar2A}% (P2A) + ${ruleset.buffers.managementBuffer}% (Mgmt)`,
      inputs: {
        'Regulatory Minimum': ruleset.minCET1Ratio,
        'Combined Buffer Requirement': ratios.combinedBufferReq,
        'Management Buffer Target': ruleset.buffers.managementBuffer,
      },
      outputValue: `${ratios.totalTargetCET1Ratio.toFixed(2)}%`,
      description: 'Required capital stack to avoid supervisory restrictions on distributions (MDA).',
    },
    {
      stepNumber: 5,
      title: 'Capital Headroom / Deficit Calculation',
      formulaName: 'Headroom = CET1_Capital - (Total_RWA * Target_CET1_Ratio)',
      expression: `${capitalHierarchy.cet1.totalCET1} - (${totalRWA.finalTotalRWA} * ${ratios.totalTargetCET1Ratio}%)`,
      inputs: {
        'CET1 Capital': capitalHierarchy.cet1.totalCET1,
        'Target CET1 Requirement': (totalRWA.finalTotalRWA * ratios.totalTargetCET1Ratio) / 100,
      },
      outputValue: `$${ratios.cet1SurplusDeficitAmount >= 0 ? '+' : ''}${ratios.cet1SurplusDeficitAmount.toFixed(1)}M (${ratios.cet1HeadroomPercentage >= 0 ? '+' : ''}${ratios.cet1HeadroomPercentage.toFixed(2)}% pts)`,
      description: 'Available unencumbered capital buffer above all mandatory regulatory and internal management targets.',
    },
  ];

  return steps;
}
