import { ExposureItem, ExposureCalculated, RegulatoryRuleset, OptimizationTarget } from '../types/capital';
import { calculateTotalRWA } from './rwaEngine';
import { calculateCapitalRatios } from './capitalEngine';

export interface OptimizationResult {
  originalRWA: number;
  optimizedRWA: number;
  rwaDelta: number;
  originalCet1Ratio: number;
  optimizedCet1Ratio: number;
  originalWeightedRaroc: number;
  optimizedWeightedRaroc: number;
  originalWeightedRoe: number;
  optimizedWeightedRoe: number;
  reallocatedExposures: Array<{
    id: string;
    counterparty: string;
    sector: string;
    originalEAD: number;
    optimizedEAD: number;
    eadDeltaPct: number;
    originalRWA: number;
    optimizedRWA: number;
    raroc: number;
    roe: number;
  }>;
}

/**
 * Optimizes loan portfolio allocation to achieve quantitative target (Maximize RAROC / ROE, Minimize RWA)
 */
export function optimizeCapitalAllocation(
  exposures: ExposureItem[],
  ruleset: RegulatoryRuleset,
  cet1Capital: number,
  tradingBookValue: number,
  grossIncome: number,
  target: OptimizationTarget
): OptimizationResult {
  const baseRWAObj = calculateTotalRWA(exposures, ruleset, tradingBookValue, grossIncome);
  const baseExposures = baseRWAObj.calculatedExposures;

  const originalRWA = baseRWAObj.totalRWA.finalTotalRWA;
  const originalCet1Ratio = (cet1Capital / originalRWA) * 100;

  const totalCapConsumedBase = baseExposures.reduce((s, e) => s + e.capitalConsumed, 0);
  const originalWeightedRaroc = baseExposures.reduce((s, e) => s + e.raroc * e.capitalConsumed, 0) / (totalCapConsumedBase || 1);
  const originalWeightedRoe = baseExposures.reduce((s, e) => s + e.roe * e.capitalConsumed, 0) / (totalCapConsumedBase || 1);

  // Heuristic optimization algorithm: rank exposures by efficiency score
  const maxShiftPct = (target.maxSingleAssetGrowthPct || 25) / 100;

  const rankedExposures = baseExposures.map(exp => {
    let efficiencyScore = exp.raroc;
    if (target.objective === 'MAXIMIZE_ROE') {
      efficiencyScore = exp.roe;
    } else if (target.objective === 'MINIMIZE_RWA' || target.objective === 'MINIMIZE_CAPITAL') {
      // lower risk weight is better
      efficiencyScore = 1000 - exp.effectiveRiskWeight;
    }
    return { exp, efficiencyScore };
  });

  // Sort descending by efficiency
  rankedExposures.sort((a, b) => b.efficiencyScore - a.efficiencyScore);

  const numItems = rankedExposures.length;
  const reallocatedExposures: OptimizationResult['reallocatedExposures'] = [];

  let optimizedExposures: ExposureItem[] = exposures.map(exp => ({ ...exp }));

  // Shift capital towards top efficiency quartile and away from bottom quartile
  rankedExposures.forEach((item, index) => {
    const isTopQuartile = index < Math.ceil(numItems * 0.3);
    const isBottomQuartile = index >= Math.floor(numItems * 0.7);

    let factor = 1.0;
    if (isTopQuartile) {
      factor = 1.0 + maxShiftPct; // grow top performers
    } else if (isBottomQuartile) {
      factor = Math.max(0.5, 1.0 - maxShiftPct); // shrink poor performers
    }

    const origExp = exposures.find(e => e.id === item.exp.id)!;
    const newEAD = Math.round(origExp.ead * factor);

    const matchIndex = optimizedExposures.findIndex(e => e.id === item.exp.id);
    if (matchIndex >= 0) {
      optimizedExposures[matchIndex].ead = newEAD;
    }
  });

  const optRWAObj = calculateTotalRWA(optimizedExposures, ruleset, tradingBookValue, grossIncome);
  const optExposures = optRWAObj.calculatedExposures;

  const optimizedRWA = optRWAObj.totalRWA.finalTotalRWA;
  const optimizedCet1Ratio = (cet1Capital / optimizedRWA) * 100;

  const totalCapConsumedOpt = optExposures.reduce((s, e) => s + e.capitalConsumed, 0);
  const optimizedWeightedRaroc = optExposures.reduce((s, e) => s + e.raroc * e.capitalConsumed, 0) / (totalCapConsumedOpt || 1);
  const optimizedWeightedRoe = optExposures.reduce((s, e) => s + e.roe * e.capitalConsumed, 0) / (totalCapConsumedOpt || 1);

  optExposures.forEach(optExp => {
    const origExp = baseExposures.find(e => e.id === optExp.id)!;
    const eadDeltaPct = ((optExp.ead - origExp.ead) / origExp.ead) * 100;
    reallocatedExposures.push({
      id: optExp.id,
      counterparty: optExp.counterparty,
      sector: optExp.sector,
      originalEAD: origExp.ead,
      optimizedEAD: optExp.ead,
      eadDeltaPct,
      originalRWA: origExp.rwa,
      optimizedRWA: optExp.rwa,
      raroc: optExp.raroc,
      roe: optExp.roe,
    });
  });

  return {
    originalRWA,
    optimizedRWA,
    rwaDelta: optimizedRWA - originalRWA,
    originalCet1Ratio,
    optimizedCet1Ratio,
    originalWeightedRaroc,
    optimizedWeightedRaroc,
    originalWeightedRoe,
    optimizedWeightedRoe,
    reallocatedExposures,
  };
}
