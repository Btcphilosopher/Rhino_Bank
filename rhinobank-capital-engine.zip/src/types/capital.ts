export type RegulatoryFramework = 'Basel_III' | 'Basel_IV' | 'US_CCAR' | 'EU_CRR3' | 'UK_PRA';

export type ExposureClass = 
  | 'Sovereign'
  | 'Bank'
  | 'Corporate'
  | 'SME'
  | 'Retail'
  | 'Residential_Mortgage'
  | 'CRE'
  | 'Project_Finance'
  | 'Specialized_Lending'
  | 'Equity'
  | 'Other';

export type CreditApproach = 'Standardized' | 'FIRB' | 'AIRB';

export type RatingGrade = 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' | 'CCC' | 'Unrated';

export interface BalanceSheetItem {
  id: string;
  name: string;
  category: 'Asset' | 'Liability' | 'Equity_Component';
  amount: number; // in millions $
  tierCategory?: 'CET1' | 'AT1' | 'Tier2' | 'None';
  regulatoryDeduction?: boolean;
  notes?: string;
}

export interface CET1Components {
  commonShares: number;
  sharePremium: number;
  retainedEarnings: number;
  aoci: number; // Accumulated Other Comprehensive Income
  qualifyingReserves: number;
  minorityInterestCET1: number;
  lessGoodwill: number;
  lessIntangibles: number;
  lessDta: number; // Deferred Tax Assets
  lessPrudentialValuation: number;
  lessOtherDeductions: number;
  totalCET1: number;
}

export interface AT1Components {
  qualifyingAT1Instruments: number;
  sharePremiumAT1: number;
  lessDeductionsAT1: number;
  totalAT1: number;
}

export interface Tier2Components {
  subordinatedDebt: number;
  eligibleProvisions: number;
  generalCreditRiskAdjustments: number;
  lessDeductionsTier2: number;
  totalTier2: number;
}

export interface CapitalHierarchy {
  cet1: CET1Components;
  at1: AT1Components;
  tier2: Tier2Components;
  totalTier1: number;
  totalCapital: number;
}

export interface ExposureItem {
  id: string;
  counterparty: string;
  sector: string;
  country: string;
  exposureClass: ExposureClass;
  ead: number; // Exposure at Default in millions $
  pd: number; // Probability of Default (decimal, e.g. 0.015 = 1.5%)
  lgd: number; // Loss Given Default (decimal, e.g. 0.45 = 45%)
  maturity: number; // Maturity in years (e.g. 2.5)
  collateral: number; // Collateral value in millions $
  ltv?: number; // Loan to Value ratio (decimal, e.g. 0.70)
  rating: RatingGrade;
  approach: CreditApproach;
  riskWeightSA: number; // Standardized Risk Weight % (e.g. 100)
  annualRevenue: number; // Expected gross revenue from position in millions $
  annualExpenses: number; // Direct operating cost in millions $
}

export interface ExposureCalculated extends ExposureItem {
  effectiveRiskWeight: number; // %
  rwa: number; // in millions $
  expectedLoss: number; // in millions $ (PD * LGD * EAD)
  unexpectedLoss: number; // in millions $
  economicCapital: number; // in millions $ (99.9% VaR)
  regulatoryCapitalReq: number; // 8% of RWA
  raroc: number; // % Return on Economic Capital
  rorac: number; // % Return on Regulatory Capital
  roe: number; // % Return on Equity
  capitalConsumed: number; // Allocated CET1 capital
  capitalDensity: number; // RWA / EAD
  revenuePerCapital: number;
  profitPerCapital: number;
}

export interface CreditRiskRWA {
  byClass: Record<ExposureClass, { ead: number; rwa: number; el: number }>;
  byApproach: Record<CreditApproach, { ead: number; rwa: number }>;
  totalStandardizedRWA: number;
  totalIRBRWA: number;
  totalCreditRWA: number;
}

export interface MarketRiskRWA {
  interestRateRisk: number;
  fxRisk: number;
  equityRisk: number;
  commodityRisk: number;
  creditSpreadRisk: number;
  totalMarketRWA: number;
}

export interface OpRiskRWA {
  businessIndicator: number;
  businessIndicatorComponent: number;
  internalLossMultiplier: number;
  totalOpRiskRWA: number;
}

export interface OtherRWA {
  cvaRWA: number;
  securitisationRWA: number;
  totalOtherRWA: number;
}

export interface TotalRWA {
  creditRWA: number;
  marketRWA: number;
  opRiskRWA: number;
  otherRWA: number;
  rawTotalRWA: number;
  outputFloorThreshold: number; // e.g., 72.5% of SA RWA
  outputFloorRWA: number;
  outputFloorApplied: boolean;
  finalTotalRWA: number;
}

export interface BufferRequirements {
  capitalConservationBuffer: number; // % (default 2.5%)
  countercyclicalBuffer: number; // % (e.g. 1.0%)
  gsibBuffer: number; // % (e.g. 1.5%)
  pillar2A: number; // % (e.g. 1.25%)
  pillar2B: number; // % (e.g. 1.0%)
  managementBuffer: number; // % (e.g. 1.0%)
}

export interface RegulatoryRuleset {
  id: RegulatoryFramework;
  name: string;
  jurisdiction: string;
  version: string;
  effectiveDate: string;
  minCET1Ratio: number; // % (e.g. 4.5)
  minTier1Ratio: number; // % (e.g. 6.0)
  minTotalCapitalRatio: number; // % (e.g. 8.0)
  buffers: BufferRequirements;
  outputFloorPercentage: number; // % (e.g. 72.5 for Basel IV, 0 for Basel III)
  enableIRB: boolean;
  smeSupportingFactor: boolean;
  infraSupportingFactor: boolean;
  saMortgageLTVBuckets: boolean;
}

export interface CapitalRatios {
  cet1Capital: number;
  tier1Capital: number;
  totalCapital: number;
  totalRWA: number;
  
  cet1Ratio: number; // %
  tier1Ratio: number; // %
  totalCapitalRatio: number; // %

  minCET1Req: number; // % (4.5)
  minTier1Req: number; // % (6.0)
  minTotalCapitalReq: number; // % (8.0)
  
  combinedBufferReq: number; // % (CCb + CCyB + GSIB + P2A)
  totalTargetCET1Ratio: number; // %
  totalTargetCapitalRatio: number; // %

  cet1SurplusDeficitAmount: number; // $ millions
  cet1HeadroomPercentage: number; // % points above target
  tier1SurplusDeficitAmount: number;
  totalCapitalSurplusDeficitAmount: number;

  status: 'OPTIMAL' | 'ADEQUATE' | 'WARNING' | 'DEFICIT';
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  severity: 'Moderate' | 'Severe' | 'Extreme';
  gdpChange: number; // %
  unemploymentIncrease: number; // % points
  pdMultiplier: number; // e.g. 2.5x
  lgdMultiplier: number; // e.g. 1.3x
  assetPriceDrop: number; // %
  interestRateShiftBp: number; // basis points (e.g. +200)
  creditSpreadShiftBp: number; // basis points (e.g. +150)
  tradingLosses: number; // $ millions
}

export interface StressTestResult {
  scenario: StressScenario;
  preStress: {
    cet1Capital: number;
    rwa: number;
    cet1Ratio: number;
  };
  postStress: {
    losses: number;
    cet1Capital: number;
    rwa: number;
    cet1Ratio: number;
    tier1Ratio: number;
    totalCapitalRatio: number;
    headroomDelta: number;
    bufferBreached: boolean;
    capitalDeficitAmount: number;
  };
}

export interface CapitalForecastYear {
  year: number;
  netInterestIncome: number;
  nonInterestIncome: number;
  operatingExpenses: number;
  creditLosses: number;
  netProfit: number;
  retainedEarningsAdded: number;
  dividendsPaid: number;
  newCapitalRaised: number;
  openingCET1: number;
  closingCET1: number;
  openingRWA: number;
  rwaGrowthAmount: number;
  closingRWA: number;
  cet1Ratio: number;
  totalCapitalRatio: number;
  headroomAmount: number;
}

export interface IRRBBResults {
  repricingGap: Array<{
    bucket: string;
    assets: number;
    liabilities: number;
    gap: number;
    cumulativeGap: number;
  }>;
  eveSensitivity: Array<{
    scenario: string;
    deltaEVE: number; // $ millions
    percentageEVE: number; // % of Tier 1
  }>;
  niiSensitivity: Array<{
    scenario: string;
    deltaNII: number; // $ millions
    percentageNII: number; // %
  }>;
}

export interface OptimizationTarget {
  objective: 'MAXIMIZE_RAROC' | 'MAXIMIZE_ROE' | 'MAXIMIZE_PROFIT' | 'MINIMIZE_RWA' | 'MINIMIZE_CAPITAL';
  maxTotalRWA?: number; // $ millions
  minCET1Ratio?: number; // %
  maxSectorLimitPct?: number; // %
  maxSingleAssetGrowthPct?: number; // %
}

export interface AuditLineageStep {
  stepNumber: number;
  title: string;
  formulaName: string;
  expression: string;
  inputs: Record<string, string | number>;
  outputValue: number | string;
  description: string;
}
