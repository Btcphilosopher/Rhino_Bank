import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

import { initialCET1Components, initialAT1Components, initialTier2Components, mockPortfolioExposures, mockRegulatoryRulesets, mockStressScenarios } from './src/data/mockData.js';
import { calculateCapitalHierarchy, calculateCapitalRatios } from './src/engine/capitalEngine.js';
import { calculateTotalRWA } from './src/engine/rwaEngine.js';
import { runStressScenario } from './src/engine/stressTestEngine.js';
import { generateCapitalForecast } from './src/engine/forecastEngine.js';
import { optimizeCapitalAllocation } from './src/engine/optimizationEngine.js';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.warn('Gemini AI initialization note:', err);
  }
}

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Calculate full capital summary
app.get('/api/capital-summary', (req, res) => {
  try {
    const rulesetId = (req.query.ruleset as string) || 'Basel_IV';
    const ruleset = mockRegulatoryRulesets[rulesetId] || mockRegulatoryRulesets.Basel_IV;

    const hierarchy = calculateCapitalHierarchy(initialCET1Components, initialAT1Components, initialTier2Components);
    const rwa = calculateTotalRWA(mockPortfolioExposures, ruleset, 14200, 4200);
    const ratios = calculateCapitalRatios(hierarchy, rwa.totalRWA, ruleset);

    res.json({
      ruleset,
      hierarchy,
      rwa,
      ratios,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Run Stress Test
app.post('/api/stress-test', (req, res) => {
  try {
    const { scenarioId, rulesetId } = req.body;
    const ruleset = mockRegulatoryRulesets[rulesetId] || mockRegulatoryRulesets.Basel_IV;
    const scenario = mockStressScenarios.find(s => s.id === scenarioId) || mockStressScenarios[0];

    const hierarchy = calculateCapitalHierarchy(initialCET1Components, initialAT1Components, initialTier2Components);
    const result = runStressScenario(scenario, mockPortfolioExposures, hierarchy, ruleset, 14200, 4200);

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Run Capital Optimization
app.post('/api/optimize', (req, res) => {
  try {
    const { target, rulesetId } = req.body;
    const ruleset = mockRegulatoryRulesets[rulesetId] || mockRegulatoryRulesets.Basel_IV;
    const hierarchy = calculateCapitalHierarchy(initialCET1Components, initialAT1Components, initialTier2Components);

    const result = optimizeCapitalAllocation(
      mockPortfolioExposures,
      ruleset,
      hierarchy.cet1.totalCET1,
      14200,
      4200,
      target || { objective: 'MAXIMIZE_RAROC' }
    );

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Generate Capital Forecast
app.post('/api/forecast', (req, res) => {
  try {
    const { horizonYears, annualAssetGrowthPct, dividendPayoutRatioPct, expectedAnnualCreditLosses, rulesetId } = req.body;
    const ruleset = mockRegulatoryRulesets[rulesetId] || mockRegulatoryRulesets.Basel_IV;
    const hierarchy = calculateCapitalHierarchy(initialCET1Components, initialAT1Components, initialTier2Components);
    const rwa = calculateTotalRWA(mockPortfolioExposures, ruleset, 14200, 4200);

    const forecast = generateCapitalForecast(hierarchy, rwa.totalRWA, ruleset, {
      horizonYears: horizonYears || 5,
      annualAssetGrowthPct: annualAssetGrowthPct || 3.5,
      annualNiiGrowthPct: 2.5,
      dividendPayoutRatioPct: dividendPayoutRatioPct || 40,
      expectedAnnualCreditLosses: expectedAnnualCreditLosses || 350,
      plannedNewCapitalIssuanceYearly: 0,
    });

    res.json({ forecast });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Gemini AI Regulatory & ICAAP Advisory Endpoint
app.post('/api/ai-advisor', async (req, res) => {
  try {
    const { query, capitalContext } = req.body;

    if (ai && process.env.GEMINI_API_KEY) {
      const systemInstruction = `You are a Chief Risk Officer (CRO) and Lead Regulatory Capital Mathematician for RhinoBank.
Provide concise, institutional-grade regulatory capital guidance, RWA optimization strategies, and Basel III/IV compliance analysis.
Format your output with clear markdown bullet points, quantitative references, and actionable treasury recommendations.`;

      const prompt = `Current RhinoBank Capital Context:
- Active Ruleset: ${capitalContext?.rulesetName || 'Basel IV'}
- CET1 Ratio: ${capitalContext?.cet1Ratio?.toFixed(2)}% (Target: ${capitalContext?.targetRatio?.toFixed(2)}%)
- Total RWA: $${capitalContext?.totalRwa?.toLocaleString()}M (Output Floor Applied: ${capitalContext?.outputFloorApplied ? 'YES' : 'NO'})
- Capital Headroom: $${capitalContext?.headroomAmount?.toLocaleString()}M (${capitalContext?.headroomPct?.toFixed(2)}% pts)

User Analysis Request: ${query || 'Provide a strategic audit of RhinoBank capital allocation and regulatory buffer efficiency.'}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.3,
        },
      });

      res.json({ advice: response.text });
    } else {
      // Fallback structured quantitative advice if API key is not configured
      res.json({
        advice: `### RhinoBank Quantitative Regulatory Strategy Audit
**Active Regime:** ${capitalContext?.rulesetName || 'Basel IV / Finalised Standards'}

1. **Capital Buffer & Headroom Analysis:**
   - Your current CET1 Ratio of **${capitalContext?.cet1Ratio?.toFixed(2) || '14.2'}%** exceeds mandatory regulatory minimums + combined buffers by **${capitalContext?.headroomPct?.toFixed(2) || '2.80'}% points** ($${capitalContext?.headroomAmount?.toLocaleString() || '3,840'}M headroom).
   - Under Basel IV Output Floor rules, your internal rating models (IRB) are constrained at **72.5%** of Standardized RWA, adding approximately **$1,420M** to total capital consumption.

2. **RWA Efficiency & RAROC Recommendations:**
   - **High-Capital Density Portfolios:** Commercial Real Estate (CRE) and Unsecured Credit Cards consume the highest capital per £/ $ of revenue.
   - **Optimization Strategy:** Consider shifting capital towards Prime Residential Mortgages (LTV < 60%) and EU/UK SME loans eligible for supporting discount factors to lower RWA density.

3. **ICAAP & Stress Test Readiness:**
   - Under a Severe Recession scenario (-3.8% GDP, 2.4x PD multiplier), your CET1 ratio would compress by ~310 bps to 11.1%, maintaining a positive buffer margin above maximum distributable amount (MDA) triggers.`
      });
    }
  } catch (err: any) {
    console.error('AI Advisor Error:', err);
    res.status(500).json({ error: 'Failed to generate regulatory advice' });
  }
});

// Vite Middleware for Dev / Static serving for Prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RhinoBank Capital Engine Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
