package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.TransportMode
import com.example.data.model.UserPreferences
import com.example.data.repository.WeaverRepository
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `verify app name resource string`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Weaver", appName)
  }

  @Test
  fun `verify multimodal journey planner returns options`() {
    val repository = WeaverRepository()
    val options = repository.planJourney("Leeds Station", "Bradford Interchange", UserPreferences())
    assertTrue("Should return journey options", options.isNotEmpty())
  }

  @Test
  fun `verify payg fare calculation capped at daily limit`() {
    val repository = WeaverRepository()
    val (fare, capRemaining) = repository.calculatePAYGFare("Leeds Station", "Bradford Interchange")
    assertTrue("Fare should be capped at <= £4.80", fare <= 4.80)
    assertEquals(0.0, capRemaining, 0.01)
  }

  @Test
  fun `verify live disruption injects delay and updates journey planning`() {
    val repository = WeaverRepository()
    repository.injectDisruption("Test Rail Closure", "Signal issue", TransportMode.RAIL, "MAJOR")
    val options = repository.planJourney("Leeds Station", "Bradford Interchange", UserPreferences())
    assertTrue("Should return options during disruption", options.isNotEmpty())
  }
}
