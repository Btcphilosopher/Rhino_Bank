package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.TransportModeBadge
import com.example.ui.theme.YorkshireBlueDark
import com.example.ui.theme.YorkshireBluePrimary
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.WeaverViewModel

@Composable
fun LiveJourneyScreen(
    viewModel: WeaverViewModel,
    modifier: Modifier = Modifier
) {
    val journey by viewModel.selectedJourney.collectAsState()
    val timeLeftMinutes by viewModel.liveNavigationTimeLeftMinutes.collectAsState()
    val currentLegIndex by viewModel.liveCurrentLegIndex.collectAsState()

    if (journey == null) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No active journey selected. Plan a journey first.")
        }
        return
    }

    val selected = journey!!
    val currentLeg = selected.legs.getOrNull(currentLegIndex) ?: selected.legs[0]

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(YorkshireBlueDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Instrument Header
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF10B981), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE NAVIGATION MODE",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.Home) }
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Exit navigation",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "${selected.legs.first().originName} → ${selected.legs.last().destinationName}",
                color = Color.White,
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Black
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "ARRIVING IN $timeLeftMinutes MIN",
                    color = Color(0xFF34D399),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "• On Schedule",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }
        }

        // Focused Instruction Card (Progressive Disclosure)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("live_instruction_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TransportModeBadge(
                        mode = currentLeg.mode,
                        label = currentLeg.lineOrRouteName
                    )

                    if (currentLeg.standOrPlatform.isNotEmpty()) {
                        Surface(
                            color = YorkshireBluePrimary,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = currentLeg.standOrPlatform,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "NEXT ACTION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${currentLeg.mode.displayName.uppercase()}: ${currentLeg.originName} TO ${currentLeg.destinationName}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Operator: ${currentLeg.operatorName} • ${currentLeg.durationMinutes} min leg",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )

                if (currentLeg.intermediateStops.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "STOPS REMAINING (3 STOPS)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            currentLeg.intermediateStops.take(3).forEach { stop ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RadioButtonChecked,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = stop, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Step Progression Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(
                        onClick = {
                            if (currentLegIndex > 0) {
                                viewModel.liveCurrentLegIndex.value -= 1
                            }
                        },
                        enabled = currentLegIndex > 0
                    ) {
                        Text("PREVIOUS STEP")
                    }

                    Button(
                        onClick = {
                            if (currentLegIndex < selected.legs.size - 1) {
                                viewModel.liveCurrentLegIndex.value += 1
                            } else {
                                viewModel.navigateTo(ScreenDestination.Home)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = YorkshireBluePrimary)
                    ) {
                        Text(
                            if (currentLegIndex < selected.legs.size - 1) "NEXT STEP" else "COMPLETE JOURNEY",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Bottom Disruption Test Button
        Button(
            onClick = {
                viewModel.injectSimulatedDisruption(
                    title = "Signal Fault on Rail",
                    description = "Major rail delay detected on your route (+18 min)",
                    mode = com.example.data.model.TransportMode.RAIL
                )
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
        ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("SIMULATE DISRUPTION & RE-ROUTE", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}
