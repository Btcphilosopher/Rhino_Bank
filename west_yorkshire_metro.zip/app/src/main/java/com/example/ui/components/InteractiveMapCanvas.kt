package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LocationNode
import com.example.data.model.LiveVehicle
import com.example.data.model.TransportMode
import com.example.ui.theme.YorkshireBluePrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InteractiveMapCanvas(
    locations: List<LocationNode>,
    liveVehicles: List<LiveVehicle>,
    showRail: Boolean,
    showBus: Boolean,
    showCycle: Boolean,
    showParkRide: Boolean,
    showEV: Boolean,
    showFutureMassTransit: Boolean,
    onLocationSelected: (LocationNode) -> Unit,
    modifier: Modifier = Modifier
) {
    // Map bounding box for West Yorkshire (Lat 53.60 to 53.90, Lng -2.00 to -1.40)
    val minLat = 53.60
    val maxLat = 53.90
    val minLng = -2.00
    val maxLng = -1.40

    fun toScreenPoint(lat: Double, lng: Double, width: Float, height: Float): Offset {
        val x = ((lng - minLng) / (maxLng - minLng) * width).toFloat()
        val y = ((maxLat - lat) / (maxLat - minLat) * height).toFloat()
        return Offset(x, y)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1B26))
            .testTag("interactive_map_canvas")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(locations) {
                    detectTapGestures { tapOffset ->
                        val width = size.width.toFloat()
                        val height = size.height.toFloat()
                        // Find closest location
                        val hit = locations.minByOrNull { loc ->
                            val pt = toScreenPoint(loc.lat, loc.lng, width, height)
                            (pt - tapOffset).getDistance()
                        }
                        if (hit != null) {
                            val pt = toScreenPoint(hit.lat, hit.lng, width, height)
                            if ((pt - tapOffset).getDistance() < 80f) {
                                onLocationSelected(hit)
                            }
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // 1. Draw West Yorkshire Regional Background Grid & Connectors
            // Rail Trunk Lines (Leeds - Bradford, Leeds - Wakefield, Leeds - Huddersfield, Halifax)
            if (showRail) {
                val leedsPt = toScreenPoint(53.7952, -1.5478, w, h)
                val bradfordPt = toScreenPoint(53.7915, -1.7510, w, h)
                val wakefieldPt = toScreenPoint(53.6820, -1.5061, w, h)
                val huddersfieldPt = toScreenPoint(53.6485, -1.7845, w, h)
                val halifaxPt = toScreenPoint(53.7225, -1.8540, w, h)
                val dewsburyPt = toScreenPoint(53.6912, -1.6315, w, h)

                val railColor = Color(0xFFD4351C)
                drawLine(railColor, leedsPt, bradfordPt, strokeWidth = 6f)
                drawLine(railColor, leedsPt, wakefieldPt, strokeWidth = 6f)
                drawLine(railColor, leedsPt, dewsburyPt, strokeWidth = 6f)
                drawLine(railColor, dewsburyPt, huddersfieldPt, strokeWidth = 6f)
                drawLine(railColor, bradfordPt, halifaxPt, strokeWidth = 6f)
            }

            // Bus Corridors (A647 Leeds-Bradford, A61 Leeds-Wakefield)
            if (showBus) {
                val leedsPt = toScreenPoint(53.7952, -1.5478, w, h)
                val bradfordPt = toScreenPoint(53.7915, -1.7510, w, h)
                val stourtonPt = toScreenPoint(53.7660, -1.5150, w, h)
                val busColor = Color(0xFF1D70B8)

                drawLine(busColor, leedsPt, bradfordPt, strokeWidth = 4f)
                drawLine(busColor, leedsPt, stourtonPt, strokeWidth = 4f)
            }

            // Active Cycle Network (Aire & Calder Towpath)
            if (showCycle) {
                val cycleColor = Color(0xFF008054)
                val p1 = toScreenPoint(53.8000, -1.5500, w, h)
                val p2 = toScreenPoint(53.8200, -1.6500, w, h)
                val p3 = toScreenPoint(53.8325, -1.7740, w, h)
                drawLine(cycleColor, p1, p2, strokeWidth = 3f)
                drawLine(cycleColor, p2, p3, strokeWidth = 3f)
            }

            // Future Mass Transit (PLANNED - DASHED PURPLE LINE)
            if (showFutureMassTransit) {
                val futureColor = Color(0xFFA855F7)
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)

                val mtStart = toScreenPoint(53.7930, -1.5400, w, h)
                val mtMid = toScreenPoint(53.7900, -1.6500, w, h)
                val mtEnd = toScreenPoint(53.7915, -1.7510, w, h)

                drawLine(
                    color = futureColor,
                    start = mtStart,
                    end = mtMid,
                    strokeWidth = 8f,
                    pathEffect = dashEffect
                )
                drawLine(
                    color = futureColor,
                    start = mtMid,
                    end = mtEnd,
                    strokeWidth = 8f,
                    pathEffect = dashEffect
                )
            }

            // 2. Draw Station & Interchange Pins
            locations.forEach { loc ->
                val pt = toScreenPoint(loc.lat, loc.lng, w, h)
                val nodeColor = if (loc.isInterchange) Color(0xFF38BDF8) else Color.White
                val radius = if (loc.isInterchange) 12f else 8f

                drawCircle(color = nodeColor, radius = radius, center = pt)
                drawCircle(color = Color(0xFF0F1B26), radius = radius * 0.5f, center = pt)
            }

            // 3. Draw Live Moving Vehicles
            liveVehicles.forEach { vehicle ->
                val pt = toScreenPoint(vehicle.lat, vehicle.lng, w, h)
                val vColor = when (vehicle.mode) {
                    TransportMode.BUS -> Color(0xFF3B82F6)
                    TransportMode.RAIL -> Color(0xFFEF4444)
                    else -> Color.Yellow
                }
                drawCircle(color = vColor, radius = 10f, center = pt)
                drawCircle(color = Color.White, radius = 4f, center = pt)
            }
        }

        // Overlay: Map Controls & Legend Header
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Surface(
                color = Color(0xFF1E293B).copy(alpha = 0.9f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "WEST YORKSHIRE NETWORK MAP",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Tap nodes for live departures & interchange guide",
                        fontSize = 10.sp,
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}
