package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransportMode
import com.example.ui.components.DisruptionAlertBanner
import com.example.ui.theme.YorkshireBlueDark
import com.example.ui.theme.YorkshireBluePrimary
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.WeaverViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: WeaverViewModel,
    modifier: Modifier = Modifier
) {
    val originState by viewModel.originQuery.collectAsState()
    val destinationState by viewModel.destinationQuery.collectAsState()
    val rerouteAlert by viewModel.rerouteAlert.collectAsState()
    val networkStatusList = viewModel.networkStatus
    val selectedJourney by viewModel.selectedJourney.collectAsState()

    val quickDestinations = listOf("Leeds", "Bradford", "Wakefield", "Huddersfield", "Halifax", "Dewsbury", "Keighley", "Shipley")

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // 1. Header Banner: WEAVER
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "WEAVER.OS",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "West Yorkshire",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(0xFF10B981), shape = RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "NETWORK LIVE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (rerouteAlert != null) {
            DisruptionAlertBanner(
                message = rerouteAlert!!,
                onDismiss = { viewModel.dismissRerouteAlert() }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // 2. Journey Planner Input Card ("Where are you going?")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("home_journey_input_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Where do you want to go?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = originState,
                    onValueChange = { viewModel.originQuery.value = it },
                    label = { Text("From") },
                    leadingIcon = { Icon(Icons.Default.TripOrigin, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_from"),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = destinationState,
                    onValueChange = { viewModel.destinationQuery.value = it },
                    label = { Text("To") },
                    leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_to"),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Quick Destination Chips
                Text(
                    text = "QUICK DESTINATIONS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(quickDestinations) { dest ->
                        FilterChip(
                            selected = destinationState.equals(dest, ignoreCase = true),
                            onClick = {
                                viewModel.destinationQuery.value = dest
                                viewModel.runSearch()
                            },
                            label = { Text(dest, fontSize = 12.sp) },
                            modifier = Modifier.testTag("quick_dest_$dest")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        viewModel.runSearch()
                        viewModel.navigateTo(ScreenDestination.Planner)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_plan_journey"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = YorkshireBluePrimary)
                ) {
                    Icon(Icons.Default.Directions, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PLAN JOURNEY", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Quick Action Buttons Grid
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            maxItemsInEachRow = 2,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val cardModifier = Modifier.weight(1f)

            QuickActionCard(
                title = "LIVE DEPARTURES",
                subtitle = "Bus stops & stations",
                icon = Icons.Default.Schedule,
                bgColor = Color(0xFF1D70B8),
                onClick = { viewModel.navigateTo(ScreenDestination.Departures) },
                modifier = cardModifier.testTag("quick_action_departures")
            )

            QuickActionCard(
                title = "MCARD & TICKETS",
                subtitle = "Digital pass & wallet",
                icon = Icons.Default.QrCode2,
                bgColor = Color(0xFFD97706),
                onClick = { viewModel.navigateTo(ScreenDestination.Tickets) },
                modifier = cardModifier.testTag("quick_action_tickets")
            )

            QuickActionCard(
                title = "TRANSPORT MAP",
                subtitle = "West Yorkshire network",
                icon = Icons.Default.Map,
                bgColor = Color(0xFF0F2E48),
                onClick = { viewModel.navigateTo(ScreenDestination.Map) },
                modifier = cardModifier.testTag("quick_action_map")
            )

            QuickActionCard(
                title = "WEAVER CONTROL",
                subtitle = "Digital Twin & Admin",
                icon = Icons.Default.SettingsInputComponent,
                bgColor = Color(0xFF7B2CBF),
                onClick = { viewModel.navigateTo(ScreenDestination.Control) },
                modifier = cardModifier.testTag("quick_action_control")
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. "YOUR NEXT JOURNEY" Card
        if (selectedJourney != null) {
            val journey = selectedJourney!!
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_next_journey"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "YOUR NEXT JOURNEY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 1.sp
                        )

                        Surface(
                            color = YorkshireBluePrimary,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "LEAVE IN 11 MIN",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${journey.legs.firstOrNull()?.originName ?: originState} → ${journey.legs.lastOrNull()?.destinationName ?: destinationState}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "${journey.totalMinutes} min • ${journey.legs.size} legs • ${journey.estimatedFare}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.startLiveJourney(journey) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Navigation, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("START LIVE NAVIGATION", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 5. Regional Network Status Overview
        Text(
            text = "REGIONAL NETWORK STATUS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                networkStatusList.forEach { status ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        if (status.isNormal) Color(0xFF10B981) else Color(0xFFEF4444),
                                        shape = RoundedCornerShape(4.dp)
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = status.mode.displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Text(
                            text = status.statusText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (status.isNormal) Color(0xFF10B981) else Color(0xFFEF4444)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    bgColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )

            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = subtitle,
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp
                )
            }
        }
    }
}
