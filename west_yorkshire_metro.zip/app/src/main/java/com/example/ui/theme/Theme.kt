package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = YorkshireBluePrimary,
    onPrimary = YorkshireOnPrimary,
    primaryContainer = YorkshireBlueContainer,
    secondary = WeaverAmber,
    tertiary = WeaverRailRed,
    background = WeaverDarkBackground,
    surface = WeaverDarkSurface,
    surfaceVariant = WeaverDarkSurfaceVariant,
    onBackground = WeaverDarkOnSurface,
    onSurface = WeaverDarkOnSurface,
    onSurfaceVariant = WeaverDarkOnSurfaceVariant
)

private val LightColorScheme = lightColorScheme(
    primary = YorkshireBluePrimary,
    onPrimary = YorkshireOnPrimary,
    primaryContainer = YorkshireBlueContainer,
    secondary = WeaverAmber,
    tertiary = WeaverRailRed,
    background = WeaverLightBackground,
    surface = WeaverLightSurface,
    surfaceVariant = WeaverLightSurfaceVariant,
    onBackground = WeaverLightOnSurface,
    onSurface = WeaverLightOnSurface,
    onSurfaceVariant = WeaverLightOnSurfaceVariant
)

@Composable
fun WeaverTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
