package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.TicketEntity
import com.example.ui.components.MCardView
import com.example.ui.components.SimulatedQrCodeView
import com.example.ui.theme.YorkshireBluePrimary
import com.example.viewmodel.WeaverViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(
    viewModel: WeaverViewModel,
    modifier: Modifier = Modifier
) {
    val tickets by viewModel.tickets.collectAsState()
    val paygSession by viewModel.paygSession.collectAsState()

    var showPurchaseDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "MY MCARD & TICKETS",
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Black
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Digital MCard Card
        MCardView(
            holderName = "West Yorkshire Passenger",
            cardNumber = "WY-8890-4123-9081",
            productTitle = "MCard Regional Bus & Rail Day",
            validDate = "Valid Today (All West Yorkshire)"
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Active Ticket Barcode / QR Code
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("active_ticket_qr_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ACTIVE DIGITAL TICKET QR",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                SimulatedQrCodeView(seed = "WEAVER-MCARD-WESTYORKSHIRE-2026")

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Present barcode to bus reader or rail barrier optical scanner",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. PAYG Tap In / Tap Out Simulator Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("payg_simulator_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PAY-AS-YOU-GO TAPPER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = if (paygSession.isTappedIn) "TAPPED IN at ${paygSession.originStopName}" else "READY TO TAP IN",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        color = if (paygSession.isTappedIn) Color(0xFF10B981) else Color(0xFF6B7280),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (paygSession.isTappedIn) "ACTIVE JOURNEY" else "STANDBY",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Spent Today: £${String.format("%.2f", paygSession.totalSpentToday)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Daily Bus Cap: £4.80",
                        fontSize = 13.sp,
                        color = Color(0xFF059669),
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.simulateTapIn("Leeds Station") },
                        enabled = !paygSession.isTappedIn,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_tap_in"),
                        colors = ButtonDefaults.buttonColors(containerColor = YorkshireBluePrimary)
                    ) {
                        Text("TAP IN (LEEDS)")
                    }

                    Button(
                        onClick = { viewModel.simulateTapOut("Bradford Interchange") },
                        enabled = paygSession.isTappedIn,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_tap_out"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                    ) {
                        Text("TAP OUT (BRADFORD)")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. Ticket Purchase Action
        Button(
            onClick = { showPurchaseDialog = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("btn_buy_ticket"),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = YorkshireBluePrimary)
        ) {
            Icon(Icons.Default.ShoppingCart, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("BUY REGIONAL PASS / TICKET", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 5. Stored Tickets Wallet
        Text(
            text = "STORED TICKET WALLET",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        tickets.forEach { ticket ->
            StoredTicketRow(ticket = ticket)
            Spacer(modifier = Modifier.height(8.dp))
        }
    }

    if (showPurchaseDialog) {
        AlertDialog(
            onDismissRequest = { showPurchaseDialog = false },
            title = { Text("Buy Weaver Pass / MCard") },
            text = {
                Column {
                    Text("Select a regional travel product:")
                    Spacer(modifier = Modifier.height(12.dp))

                    ListItem(
                        headlineContent = { Text("MCard Bus Day Pass (£4.80)") },
                        supportingContent = { Text("Unlimited bus travel across West Yorkshire") },
                        modifier = Modifier.clickable {
                            viewModel.purchaseTicket("MCard Regional Bus Day Pass", "£4.80", "BUS")
                            showPurchaseDialog = false
                        }
                    )

                    ListItem(
                        headlineContent = { Text("MCard Bus & Rail Day Pass (£8.50)") },
                        supportingContent = { Text("Unlimited bus and train travel across all 5 districts") },
                        modifier = Modifier.clickable {
                            viewModel.purchaseTicket("MCard Bus & Rail Day Pass", "£8.50", "BUS_RAIL")
                            showPurchaseDialog = false
                        }
                    )

                    ListItem(
                        headlineContent = { Text("Weaver Weekly Pass (£21.00)") },
                        supportingContent = { Text("7-day regional pass for all modes") },
                        modifier = Modifier.clickable {
                            viewModel.purchaseTicket("Weaver Weekly Pass", "£21.00", "WEAVER_PASS")
                            showPurchaseDialog = false
                        }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showPurchaseDialog = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}

@Composable
fun StoredTicketRow(ticket: TicketEntity) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("stored_ticket_${ticket.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = ticket.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "${ticket.validDate} • ${ticket.passengerType}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = ticket.price,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 15.sp
            )
        }
    }
}
