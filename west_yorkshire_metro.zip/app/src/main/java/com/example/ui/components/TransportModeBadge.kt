package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransportMode
import com.example.ui.theme.*

@Composable
fun getTransportColor(mode: TransportMode): Color {
    return when (mode) {
        TransportMode.BUS -> WeaverBusBlue
        TransportMode.RAIL -> WeaverRailRed
        TransportMode.WALK -> Color(0xFF475569)
        TransportMode.WHEEL -> Color(0xFF0D9488)
        TransportMode.CYCLE -> WeaverCycleGreen
        TransportMode.PARK_AND_RIDE -> WeaverParkRideBlue
        TransportMode.EV_CHARGE -> WeaverEvTeal
        TransportMode.FUTURE_MASS_TRANSIT -> WeaverFuturePurple
    }
}

@Composable
fun TransportModeBadge(
    mode: TransportMode,
    label: String? = null,
    modifier: Modifier = Modifier
) {
    val bg = getTransportColor(mode)
    val icon = when (mode) {
        TransportMode.BUS -> Icons.Default.DirectionsBus
        TransportMode.RAIL -> Icons.Default.Train
        TransportMode.WALK -> Icons.Default.DirectionsWalk
        TransportMode.WHEEL -> Icons.Default.Accessible
        TransportMode.CYCLE -> Icons.Default.DirectionsBike
        TransportMode.PARK_AND_RIDE -> Icons.Default.DirectionsCar
        TransportMode.EV_CHARGE -> Icons.Default.ElectricCar
        TransportMode.FUTURE_MASS_TRANSIT -> Icons.Default.Tram
    }

    Row(
        modifier = modifier
            .background(color = bg, shape = RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("mode_badge_${mode.name.lowercase()}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = mode.displayName,
            tint = Color.White,
            modifier = Modifier.size(16.dp)
        )
        val textToShow = label ?: mode.displayName
        if (textToShow.isNotEmpty()) {
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = textToShow,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
