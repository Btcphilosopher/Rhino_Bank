package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Weaver Palette
val YorkshireBluePrimary = Color(0xFF0F2E48)
val YorkshireBlueDark = Color(0xFF0A1F32)
val YorkshireBlueContainer = Color(0xFF1E3A54)
val YorkshireOnPrimary = Color(0xFFFFFFFF)

// Accent & Secondary
val WeaverAmber = Color(0xFFD97706)
val WeaverRailRed = Color(0xFFD4351C)
val WeaverBusBlue = Color(0xFF1D70B8)
val WeaverCycleGreen = Color(0xFF008054)
val WeaverParkRideBlue = Color(0xFF1D3557)
val WeaverEvTeal = Color(0xFF00A896)
val WeaverFuturePurple = Color(0xFF7B2CBF)

// Light Theme Surface & Backgrounds
val WeaverLightBackground = Color(0xFFF4F6F9)
val WeaverLightSurface = Color(0xFFFFFFFF)
val WeaverLightSurfaceVariant = Color(0xFFE2E8F0)
val WeaverLightOnSurface = Color(0xFF1E293B)
val WeaverLightOnSurfaceVariant = Color(0xFF64748B)

// Dark Theme Surface & Backgrounds
val WeaverDarkBackground = Color(0xFF091118)
val WeaverDarkSurface = Color(0xFF111C26)
val WeaverDarkSurfaceVariant = Color(0xFF1A2836)
val WeaverDarkOnSurface = Color(0xFFF1F5F9)
val WeaverDarkOnSurfaceVariant = Color(0xFF94A3B8)
