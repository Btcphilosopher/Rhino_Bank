package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LocationNode
import com.example.ui.components.InteractiveMapCanvas
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.WeaverViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MapScreen(
    viewModel: WeaverViewModel,
    modifier: Modifier = Modifier
) {
    val locations = viewModel.locations
    val liveVehicles by viewModel.liveVehicles.collectAsState()

    val showRail by viewModel.showRailLayer.collectAsState()
    val showBus by viewModel.showBusLayer.collectAsState()
    val showCycle by viewModel.showCycleLayer.collectAsState()
    val showParkRide by viewModel.showParkRideLayer.collectAsState()
    val showEV by viewModel.showEVLayer.collectAsState()
    val showFuture by viewModel.showFutureLayer.collectAsState()

    var selectedNode by remember { mutableStateOf<LocationNode?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Vector Map Canvas
        InteractiveMapCanvas(
            locations = locations,
            liveVehicles = liveVehicles,
            showRail = showRail,
            showBus = showBus,
            showCycle = showCycle,
            showParkRide = showParkRide,
            showEV = showEV,
            showFutureMassTransit = showFuture,
            onLocationSelected = { selectedNode = it }
        )

        // 2. Top Filter Layers Carousel Overlay
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = showRail,
                        onClick = { viewModel.showRailLayer.value = !showRail },
                        label = { Text("Rail", fontSize = 11.sp) },
                        modifier = Modifier.testTag("map_layer_rail")
                    )
                }
                item {
                    FilterChip(
                        selected = showBus,
                        onClick = { viewModel.showBusLayer.value = !showBus },
                        label = { Text("Bus", fontSize = 11.sp) },
                        modifier = Modifier.testTag("map_layer_bus")
                    )
                }
                item {
                    FilterChip(
                        selected = showCycle,
                        onClick = { viewModel.showCycleLayer.value = !showCycle },
                        label = { Text("Active Cycle", fontSize = 11.sp) },
                        modifier = Modifier.testTag("map_layer_cycle")
                    )
                }
                item {
                    FilterChip(
                        selected = showParkRide,
                        onClick = { viewModel.showParkRideLayer.value = !showParkRide },
                        label = { Text("Park & Ride", fontSize = 11.sp) },
                        modifier = Modifier.testTag("map_layer_pr")
                    )
                }
                item {
                    FilterChip(
                        selected = showEV,
                        onClick = { viewModel.showEVLayer.value = !showEV },
                        label = { Text("EV Hubs", fontSize = 11.sp) },
                        modifier = Modifier.testTag("map_layer_ev")
                    )
                }
                item {
                    FilterChip(
                        selected = showFuture,
                        onClick = { viewModel.toggleFutureNetworkLayer() },
                        label = { Text("Future Mass Transit (Planned)", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF7B2CBF),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("map_layer_future")
                    )
                }
            }
        }

        // 3. Node Inspector Bottom Sheet
        if (selectedNode != null) {
            val node = selectedNode!!
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("map_node_inspector_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = node.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "West Yorkshire District • ${node.town}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(onClick = { selectedNode = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close inspector")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Node Amenities Badges
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (node.hasLifts) {
                            AssistChip(
                                onClick = {},
                                label = { Text("Lifts & Step-Free", fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.Accessible, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            )
                        }
                        if (node.hasCycleHub) {
                            AssistChip(
                                onClick = {},
                                label = { Text("Secure Cycle Hub", fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.DirectionsBike, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.selectDepartureStop(node)
                            viewModel.navigateTo(ScreenDestination.Departures)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Schedule, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("VIEW LIVE DEPARTURES FOR THIS NODE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
