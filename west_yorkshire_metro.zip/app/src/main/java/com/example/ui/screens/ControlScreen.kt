package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NetworkFranchisePhase
import com.example.data.model.TransportMode
import com.example.ui.theme.YorkshireBlueDark
import com.example.ui.theme.YorkshireBluePrimary
import com.example.viewmodel.WeaverViewModel

@Composable
fun ControlScreen(
    viewModel: WeaverViewModel,
    modifier: Modifier = Modifier
) {
    val franchisePhase by viewModel.franchisePhase.collectAsState()
    val leedsDemand by viewModel.leedsDemandPercent.collectAsState()
    val bradfordDemand by viewModel.bradfordDemandPercent.collectAsState()
    val disruptions by viewModel.disruptions.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "OPERATIONS CONSOLE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "WEAVER CONTROL",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Black
                )
            }

            Surface(
                color = Color(0xFF7B2CBF),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "DIGITAL TWIN",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Regional Overview Banner (1.24m daily journeys)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("control_regional_overview_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = YorkshireBluePrimary)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "WEST YORKSHIRE REGIONAL FLOW",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "1.24 Million Daily Journeys",
                    color = Color.White,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricBadge("BUS", "682k")
                    MetricBadge("RAIL", "214k")
                    MetricBadge("WALK", "203k")
                    MetricBadge("CYCLE", "91k")
                    MetricBadge("P&R", "50k")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Network Franchising Phase Selector
        Text(
            text = "WEAVER NETWORK FRANCHISING STATE",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Current Active Phase: ${franchisePhase.label}",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = franchisePhase.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NetworkFranchisePhase.values().forEach { phase ->
                        FilterChip(
                            selected = franchisePhase == phase,
                            onClick = { viewModel.franchisePhase.value = phase },
                            label = { Text(phase.name, fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("franchise_phase_${phase.name.lowercase()}")
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. Peak Demand Sliders
        Text(
            text = "REGIONAL PASSENGER DEMAND SIMULATOR",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Leeds Demand Capacity: $leedsDemand%",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Slider(
                    value = leedsDemand.toFloat(),
                    onValueChange = { viewModel.leedsDemandPercent.value = it.toInt() },
                    valueRange = 0f..100f,
                    modifier = Modifier.testTag("slider_leeds_demand")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Bradford Demand Capacity: $bradfordDemand%",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Slider(
                    value = bradfordDemand.toFloat(),
                    onValueChange = { viewModel.bradfordDemandPercent.value = it.toInt() },
                    valueRange = 0f..100f,
                    modifier = Modifier.testTag("slider_bradford_demand")
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. Interactive Disruption Generator
        Text(
            text = "DISRUPTION ENGINE CONTROLS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Button(
                    onClick = {
                        viewModel.injectSimulatedDisruption(
                            title = "Calder Valley Rail Delay",
                            description = "Signal failure near Dewsbury causing 25m rail delays",
                            mode = TransportMode.RAIL
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_inject_rail_delay"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("INJECT RAIL DELAY (+25 MIN)", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = { viewModel.clearSimulatedDisruptions() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_clear_disruptions")
                ) {
                    Text("CLEAR ALL DISRUPTIONS & RE-SYNC")
                }

                if (disruptions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Active Disruption Count: ${disruptions.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFDC2626)
                    )
                }
            }
        }
    }
}

@Composable
fun MetricBadge(label: String, valText: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = valText, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
        Text(text = label, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
