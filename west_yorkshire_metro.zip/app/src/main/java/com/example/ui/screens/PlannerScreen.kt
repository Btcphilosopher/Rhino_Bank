package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JourneyOption
import com.example.ui.components.RouteTimeline
import com.example.ui.components.TransportModeBadge
import com.example.viewmodel.WeaverViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    viewModel: WeaverViewModel,
    modifier: Modifier = Modifier
) {
    val results by viewModel.journeyResults.collectAsState()
    val prefs by viewModel.userPreferences.collectAsState()
    val origin by viewModel.originQuery.collectAsState()
    val destination by viewModel.destinationQuery.collectAsState()

    var selectedTab by remember { mutableStateOf("ALL") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Search Summary Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "JOURNEY PLANNER",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                    )
                    Text(
                        text = "$origin → $destination",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                IconButton(onClick = { viewModel.runSearch() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh search")
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Routing Preference Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = prefs.fastestFirst,
                    onClick = { viewModel.updatePreferences(prefs.copy(fastestFirst = true, fewestChanges = false, lowestCost = false)) },
                    label = { Text("Fastest") },
                    leadingIcon = { Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
            item {
                FilterChip(
                    selected = prefs.fewestChanges,
                    onClick = { viewModel.updatePreferences(prefs.copy(fewestChanges = true, fastestFirst = false, lowestCost = false)) },
                    label = { Text("Fewest Changes") },
                    leadingIcon = { Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
            item {
                FilterChip(
                    selected = prefs.lowestCost,
                    onClick = { viewModel.updatePreferences(prefs.copy(lowestCost = true, fastestFirst = false, fewestChanges = false)) },
                    label = { Text("Cheapest") },
                    leadingIcon = { Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
            item {
                FilterChip(
                    selected = prefs.stepFreeOnly,
                    onClick = { viewModel.updatePreferences(prefs.copy(stepFreeOnly = !prefs.stepFreeOnly)) },
                    label = { Text("Step-Free") },
                    leadingIcon = { Icon(Icons.Default.Accessible, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
            item {
                FilterChip(
                    selected = prefs.lowCarbonFirst,
                    onClick = { viewModel.updatePreferences(prefs.copy(lowCarbonFirst = !prefs.lowCarbonFirst)) },
                    label = { Text("Low Carbon") },
                    leadingIcon = { Icon(Icons.Default.Eco, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Results List
        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No routes found for specified criteria. Try broadening preferences.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(results) { option ->
                    JourneyOptionCard(
                        option = option,
                        onStartLive = { viewModel.startLiveJourney(option) }
                    )
                }
            }
        }
    }
}

@Composable
fun JourneyOptionCard(
    option: JourneyOption,
    onStartLive: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("journey_option_card_${option.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Title & Fare
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = option.title,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "${option.totalMinutes} min",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                }

                Text(
                    text = option.estimatedFare,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF059669)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sub-metrics (Walking, Changes, Carbon)
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Walk ${option.walkMinutes}m",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "• ${option.changesCount} change${if (option.changesCount == 1) "" else "s"}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "• ${option.carbonEstimateKg} kg CO₂e",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF047857)
                )
            }

            if (option.disruptionWarning != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = Color(0xFFFEF2F2),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = option.disruptionWarning,
                            color = Color(0xFF991B1B),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Leg Mode Badges Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                option.legs.forEach { leg ->
                    TransportModeBadge(
                        mode = leg.mode,
                        label = leg.lineOrRouteName.take(8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Timeline Breakdown
            RouteTimeline(legs = option.legs)

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onStartLive,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_select_journey_${option.id}"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Navigation, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("START LIVE JOURNEY MODE", fontWeight = FontWeight.Bold)
            }
        }
    }
}
