package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.TicketEntity
import com.example.data.model.*
import com.example.data.repository.WeaverRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class ScreenDestination {
    object Home : ScreenDestination()
    object Planner : ScreenDestination()
    object LiveJourney : ScreenDestination()
    object Departures : ScreenDestination()
    object Map : ScreenDestination()
    object Tickets : ScreenDestination()
    object Control : ScreenDestination()
    object Profile : ScreenDestination()
}

data class PaygSession(
    val isTappedIn: Boolean = false,
    val originStopName: String? = null,
    val tapInTime: String? = null,
    val currentFare: Double = 0.0,
    val dailyCapAmount: Double = 4.80,
    val totalSpentToday: Double = 2.00
)

class WeaverViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = WeaverRepository()
    private val dao = AppDatabase.getInstance(application).weaverDao()

    // Navigation state
    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Home)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    // Planner state
    val originQuery = MutableStateFlow("Leeds Station")
    val destinationQuery = MutableStateFlow("Bradford Interchange")
    val userPreferences = MutableStateFlow(UserPreferences())

    private val _journeyResults = MutableStateFlow<List<JourneyOption>>(emptyList())
    val journeyResults: StateFlow<List<JourneyOption>> = _journeyResults.asStateFlow()

    private val _selectedJourney = MutableStateFlow<JourneyOption?>(null)
    val selectedJourney: StateFlow<JourneyOption?> = _selectedJourney.asStateFlow()

    // Live Journey Navigation state
    val liveCurrentLegIndex = MutableStateFlow(0)
    val liveCurrentStepIndex = MutableStateFlow(0)
    val isLiveTrackingActive = MutableStateFlow(false)
    val liveNavigationTimeLeftMinutes = MutableStateFlow(32)

    // Departures Inspector state
    val selectedDepartureStop = MutableStateFlow(repository.locations[0]) // Leeds Station
    val departuresList = MutableStateFlow<List<DepartureInfo>>(emptyList())

    // Map Layers & Selected Node
    val showRailLayer = MutableStateFlow(true)
    val showBusLayer = MutableStateFlow(true)
    val showCycleLayer = MutableStateFlow(true)
    val showParkRideLayer = MutableStateFlow(true)
    val showEVLayer = MutableStateFlow(true)
    val showFutureLayer = MutableStateFlow(false)
    val showLiveVehicles = MutableStateFlow(true)
    val selectedMapLocation = MutableStateFlow<LocationNode?>(null)

    // Data flows
    val locations: List<LocationNode> = repository.locations
    val parkAndRideFacilities: List<ParkAndRideFacility> = repository.parkAndRideFacilities
    val evChargers: List<EVChargingPoint> = repository.evChargers
    val futureMassTransitLines: List<LocationNode> = repository.futureMassTransitLines
    val disruptions: StateFlow<List<DisruptionItem>> = repository.disruptions
    val liveVehicles: StateFlow<List<LiveVehicle>> = repository.liveVehicles
    val franchisePhase = repository.franchisePhase
    val networkStatus = repository.networkStatus

    // Database flows
    val tickets: StateFlow<List<TicketEntity>> = dao.getAllTickets().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // PAYG Session State
    val paygSession = MutableStateFlow(PaygSession())

    // Regional Demand Sliders for Digital Twin Control
    val leedsDemandPercent = MutableStateFlow(82)
    val bradfordDemandPercent = MutableStateFlow(57)
    val wakefieldDemandPercent = MutableStateFlow(42)

    // Disruption Reroute Alert Banner
    val rerouteAlert = MutableStateFlow<String?>(null)

    init {
        // Initial planning
        runSearch()
        loadDepartures()
        seedInitialTicketsIfNeeded()
        startLiveVehicleTicker()
    }

    fun navigateTo(screen: ScreenDestination) {
        _currentScreen.value = screen
    }

    fun updatePreferences(newPrefs: UserPreferences) {
        userPreferences.value = newPrefs
        runSearch()
    }

    fun runSearch() {
        viewModelScope.launch {
            val results = repository.planJourney(
                originName = originQuery.value,
                destinationName = destinationQuery.value,
                prefs = userPreferences.value
            )
            _journeyResults.value = results
            if (results.isNotEmpty() && _selectedJourney.value == null) {
                _selectedJourney.value = results[0]
            }
        }
    }

    fun selectJourney(option: JourneyOption) {
        _selectedJourney.value = option
        liveCurrentLegIndex.value = 0
        liveCurrentStepIndex.value = 0
        liveNavigationTimeLeftMinutes.value = option.totalMinutes
    }

    fun startLiveJourney(option: JourneyOption) {
        selectJourney(option)
        isLiveTrackingActive.value = true
        _currentScreen.value = ScreenDestination.LiveJourney
    }

    fun loadDepartures() {
        departuresList.value = repository.getDeparturesForStop(selectedDepartureStop.value.id)
    }

    fun selectDepartureStop(node: LocationNode) {
        selectedDepartureStop.value = node
        loadDepartures()
    }

    fun toggleFutureNetworkLayer() {
        showFutureLayer.value = !showFutureLayer.value
    }

    // Live Vehicle Ticker Simulation
    private fun startLiveVehicleTicker() {
        viewModelScope.launch {
            while (true) {
                delay(3000)
                if (isLiveTrackingActive.value && liveNavigationTimeLeftMinutes.value > 1) {
                    liveNavigationTimeLeftMinutes.value -= 1
                }
            }
        }
    }

    // Disruption Simulator Action
    fun injectSimulatedDisruption(title: String, description: String, mode: TransportMode) {
        repository.injectDisruption(title, description, mode, "MAJOR")
        runSearch() // Recalculate
        rerouteAlert.value = "DISRUPTION DETECTED: $title. Journey options updated!"
    }

    fun clearSimulatedDisruptions() {
        repository.clearDisruptions()
        rerouteAlert.value = null
        runSearch()
    }

    fun dismissRerouteAlert() {
        rerouteAlert.value = null
    }

    // PAYG Tap In / Out Simulator
    fun simulateTapIn(stopName: String) {
        paygSession.value = PaygSession(
            isTappedIn = true,
            originStopName = stopName,
            tapInTime = "14:42",
            currentFare = 2.00,
            dailyCapAmount = 4.80,
            totalSpentToday = paygSession.value.totalSpentToday
        )
    }

    fun simulateTapOut(stopName: String) {
        val (fare, remainingCap) = repository.calculatePAYGFare(
            paygSession.value.originStopName ?: "Leeds",
            stopName
        )
        val newSpent = paygSession.value.totalSpentToday + fare
        paygSession.value = PaygSession(
            isTappedIn = false,
            originStopName = null,
            tapInTime = null,
            currentFare = fare,
            dailyCapAmount = 4.80,
            totalSpentToday = minOf(newSpent, 4.80)
        )
    }

    // Ticket Purchase Action
    fun purchaseTicket(title: String, price: String, modeType: String) {
        viewModelScope.launch {
            val newTicket = TicketEntity(
                id = "tck_${System.currentTimeMillis()}",
                title = title,
                modeType = modeType,
                validDate = "Valid Today",
                price = price,
                qrCodeData = "WEAVER-PASS-${System.currentTimeMillis()}",
                passengerType = "Adult",
                status = "ACTIVE"
            )
            dao.insertTicket(newTicket)
        }
    }

    private fun seedInitialTicketsIfNeeded() {
        viewModelScope.launch {
            dao.getAllTickets().firstOrNull()?.let { existing ->
                if (existing.isEmpty()) {
                    dao.insertTicket(
                        TicketEntity(
                            id = "tck_init_mcard",
                            title = "MCard Regional Bus & Rail Day Pass",
                            modeType = "BUS_RAIL",
                            validDate = "Valid Today",
                            price = "£4.80",
                            qrCodeData = "WEAVER-MCARD-WESTYORKSHIRE-2026",
                            passengerType = "Adult",
                            status = "ACTIVE"
                        )
                    )
                }
            }
        }
    }
}
