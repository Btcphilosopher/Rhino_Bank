package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.WeaverTheme
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.WeaverViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WeaverTheme {
                MainApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    weaverViewModel: WeaverViewModel = viewModel()
) {
    val currentScreen by weaverViewModel.currentScreen.collectAsState()

    // Handle Android system back press on non-Home screens
    if (currentScreen != ScreenDestination.Home) {
        BackHandler {
            weaverViewModel.navigateTo(ScreenDestination.Home)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (currentScreen != ScreenDestination.LiveJourney) {
                WeaverBottomNavigation(
                    currentScreen = currentScreen,
                    onNavigate = { weaverViewModel.navigateTo(it) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                is ScreenDestination.Home -> HomeScreen(viewModel = weaverViewModel)
                is ScreenDestination.Planner -> PlannerScreen(viewModel = weaverViewModel)
                is ScreenDestination.LiveJourney -> LiveJourneyScreen(viewModel = weaverViewModel)
                is ScreenDestination.Departures -> DeparturesScreen(viewModel = weaverViewModel)
                is ScreenDestination.Map -> MapScreen(viewModel = weaverViewModel)
                is ScreenDestination.Tickets -> TicketsScreen(viewModel = weaverViewModel)
                is ScreenDestination.Control -> ControlScreen(viewModel = weaverViewModel)
                is ScreenDestination.Profile -> ProfileScreen(viewModel = weaverViewModel)
            }
        }
    }
}

@Composable
fun WeaverBottomNavigation(
    currentScreen: ScreenDestination,
    onNavigate: (ScreenDestination) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("bottom_navigation_bar"),
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentScreen == ScreenDestination.Home,
            onClick = { onNavigate(ScreenDestination.Home) },
            icon = { Icon(if (currentScreen == ScreenDestination.Home) Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Home") },
            label = { Text("HOME") },
            modifier = Modifier.testTag("nav_tab_home")
        )

        NavigationBarItem(
            selected = currentScreen == ScreenDestination.Planner,
            onClick = { onNavigate(ScreenDestination.Planner) },
            icon = { Icon(if (currentScreen == ScreenDestination.Planner) Icons.Filled.Directions else Icons.Outlined.Directions, contentDescription = "Plan") },
            label = { Text("PLAN") },
            modifier = Modifier.testTag("nav_tab_plan")
        )

        NavigationBarItem(
            selected = currentScreen == ScreenDestination.Map,
            onClick = { onNavigate(ScreenDestination.Map) },
            icon = { Icon(if (currentScreen == ScreenDestination.Map) Icons.Filled.Map else Icons.Outlined.Map, contentDescription = "Map") },
            label = { Text("MAP") },
            modifier = Modifier.testTag("nav_tab_map")
        )

        NavigationBarItem(
            selected = currentScreen == ScreenDestination.Tickets,
            onClick = { onNavigate(ScreenDestination.Tickets) },
            icon = { Icon(if (currentScreen == ScreenDestination.Tickets) Icons.Filled.QrCode2 else Icons.Outlined.QrCode2, contentDescription = "Tickets") },
            label = { Text("TICKETS") },
            modifier = Modifier.testTag("nav_tab_tickets")
        )

        NavigationBarItem(
            selected = currentScreen == ScreenDestination.Profile,
            onClick = { onNavigate(ScreenDestination.Profile) },
            icon = { Icon(if (currentScreen == ScreenDestination.Profile) Icons.Filled.Person else Icons.Outlined.Person, contentDescription = "You") },
            label = { Text("YOU") },
            modifier = Modifier.testTag("nav_tab_you")
        )
    }
}
