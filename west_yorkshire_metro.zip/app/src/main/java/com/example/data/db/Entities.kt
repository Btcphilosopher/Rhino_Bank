package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val title: String,
    val modeType: String, // "BUS", "RAIL", "BUS_RAIL", "WEAVER_PASS"
    val validDate: String,
    val price: String,
    val qrCodeData: String,
    val passengerType: String, // "Adult", "Student", "Senior", "Child"
    val status: String, // "ACTIVE", "USED", "EXPIRED"
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_journeys")
data class SavedJourneyEntity(
    @PrimaryKey val id: String,
    val originName: String,
    val destinationName: String,
    val summaryText: String,
    val totalMinutes: Int,
    val estimatedFare: String,
    val isFavorite: Boolean = false,
    val lastPlannedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_stops")
data class FavoriteStopEntity(
    @PrimaryKey val stopId: String,
    val name: String,
    val codeName: String,
    val town: String,
    val mode: String
)
