package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class TransportMode(val displayName: String, val badgeColorHex: String) {
    BUS("Bus", "#1D70B8"),
    RAIL("Rail", "#D4351C"),
    WALK("Walk", "#4C6272"),
    WHEEL("Wheel", "#008080"),
    CYCLE("Cycle", "#008054"),
    PARK_AND_RIDE("Park & Ride", "#1D3557"),
    EV_CHARGE("EV Charge", "#00A896"),
    FUTURE_MASS_TRANSIT("Mass Transit (Planned)", "#7B2CBF")
}

data class LocationNode(
    val id: String,
    val name: String,
    val town: String, // Leeds, Bradford, Wakefield, Huddersfield, Halifax, Dewsbury, Keighley, etc.
    val code: String,
    val lat: Double,
    val lng: Double,
    val isInterchange: Boolean = false,
    val supportedModes: List<TransportMode> = listOf(TransportMode.BUS, TransportMode.WALK),
    val platformsOrStands: List<String> = emptyList(),
    val hasLifts: Boolean = true,
    val hasCycleHub: Boolean = false,
    val hasTaxiRank: Boolean = false
)

data class RouteStep(
    val instruction: String,
    val distanceText: String,
    val durationText: String
)

data class RouteLeg(
    val mode: TransportMode,
    val originName: String,
    val destinationName: String,
    val lineOrRouteName: String, // e.g. "Bus 36", "Northern Rail", "Calder Valley Line", "Walk"
    val operatorName: String, // e.g. "Weaver West Yorkshire", "Northern Rail", "Transdev", "First Leeds"
    val durationMinutes: Int,
    val departureTime: String,
    val arrivalTime: String,
    val standOrPlatform: String = "",
    val intermediateStops: List<String> = emptyList(),
    val steps: List<RouteStep> = emptyList(),
    val isStepFree: Boolean = true,
    val isDisrupted: Boolean = false,
    val disruptionNote: String? = null
)

data class JourneyOption(
    val id: String,
    val title: String, // e.g. "FASTEST", "CHEAPEST", "ACCESSIBLE"
    val totalMinutes: Int,
    val walkMinutes: Int,
    val changesCount: Int,
    val estimatedFare: String,
    val carbonEstimateKg: Double,
    val isAccessible: Boolean,
    val legs: List<RouteLeg>,
    val badgeTags: List<String> = emptyList(),
    val disruptionWarning: String? = null
)

data class DepartureInfo(
    val id: String,
    val lineName: String,
    val destination: String,
    val mode: TransportMode,
    val departureTimeStr: String,
    val minutesAway: Int,
    val platformOrStand: String,
    val delayMinutes: Int = 0,
    val operatorName: String,
    val isStepFree: Boolean = true,
    val callingPoints: List<String> = emptyList(),
    val crowdingPercent: Int = 35 // 0 to 100
)

data class LiveVehicle(
    val id: String,
    val mode: TransportMode,
    val routeName: String,
    val lat: Double,
    val lng: Double,
    val heading: Float,
    val speedKmh: Float,
    val nextStopName: String,
    val delayMinutes: Int,
    val loadPercent: Int,
    val isAccessible: Boolean = true
)

data class ParkAndRideFacility(
    val id: String,
    val name: String,
    val town: String,
    val totalSpaces: Int,
    val availableSpaces: Int,
    val dayCost: String,
    val evChargersCount: Int,
    val connectedServices: List<String>,
    val lat: Double,
    val lng: Double
)

data class EVChargingPoint(
    val id: String,
    val locationName: String,
    val town: String,
    val connectors: List<String>, // e.g., "CCS 150kW", "Type 2 22kW"
    val availableCount: Int,
    val totalCount: Int,
    val pricePerKwh: String,
    val lat: Double,
    val lng: Double
)

data class DisruptionItem(
    val id: String,
    val title: String,
    val description: String,
    val mode: TransportMode,
    val affectedLines: List<String>,
    val severity: String, // "MINOR", "MAJOR", "CRITICAL"
    val timestamp: String,
    val rerouteSuggestion: String? = null
)

data class MCardState(
    val cardNumber: String = "WY-8890-4123-9081",
    val holderName: String = "West Yorkshire Passenger",
    val ticketTitle: String = "MCard Regional Bus & Rail Day",
    val validUntil: String = "Today 23:59",
    val statusText: String = "VALID",
    val qrCodeSeed: String = "WEAVER-MCARD-VALID-2026",
    val passengerType: String = "Adult",
    val zoneText: String = "Zones 1-5 (All West Yorkshire)"
)

data class NetworkStatusSummary(
    val mode: TransportMode,
    val statusText: String,
    val isNormal: Boolean,
    val notes: String
)

enum class NetworkFranchisePhase(val label: String, val description: String) {
    CURRENT("Current Operators", "Deregulated multi-operator services"),
    TRANSITION("In Transition", "Standardized Weaver fares & unified branding"),
    FRANCHISED("Fully Franchised", "Complete Weaver regional network control")
}

data class UserPreferences(
    val fastestFirst: Boolean = true,
    val fewestChanges: Boolean = false,
    val lowestCost: Boolean = false,
    val walkLess: Boolean = false,
    val cyclePreferred: Boolean = false,
    val stepFreeOnly: Boolean = false,
    val lowCarbonFirst: Boolean = false,
    val avoidStairs: Boolean = false,
    val visualAssistance: Boolean = false
)
