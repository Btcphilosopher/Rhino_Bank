package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

class WeaverRepository {

    // --- LOCATIONS ---
    val locations = listOf(
        LocationNode(
            id = "loc_leeds_stn",
            name = "Leeds Station",
            town = "Leeds",
            code = "LDS",
            lat = 53.7952,
            lng = -1.5478,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK, TransportMode.CYCLE),
            platformsOrStands = listOf("Platform 1", "Platform 4", "Platform 6", "Platform 8", "Platform 11", "Platform 16"),
            hasLifts = true,
            hasCycleHub = true,
            hasTaxiRank = true
        ),
        LocationNode(
            id = "loc_leeds_city_sq",
            name = "Leeds City Square",
            town = "Leeds",
            code = "LCS",
            lat = 53.7960,
            lng = -1.5460,
            isInterchange = true,
            supportedModes = listOf(TransportMode.BUS, TransportMode.WALK, TransportMode.CYCLE),
            platformsOrStands = listOf("Stand A", "Stand B", "Stand C", "Stand D", "Stand E"),
            hasLifts = true
        ),
        LocationNode(
            id = "loc_leeds_bus_stn",
            name = "Leeds Bus Station (Dyer St)",
            town = "Leeds",
            code = "LBS",
            lat = 53.7971,
            lng = -1.5360,
            isInterchange = true,
            supportedModes = listOf(TransportMode.BUS, TransportMode.WALK),
            platformsOrStands = listOf("Stand 1", "Stand 5", "Stand 12", "Stand 18", "Stand 24")
        ),
        LocationNode(
            id = "loc_bradford_int",
            name = "Bradford Interchange",
            town = "Bradford",
            code = "BDI",
            lat = 53.7915,
            lng = -1.7510,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK, TransportMode.CYCLE),
            platformsOrStands = listOf("Platform 1", "Platform 2", "Stand 1", "Stand 8", "Stand 15"),
            hasLifts = true,
            hasTaxiRank = true
        ),
        LocationNode(
            id = "loc_bradford_forster",
            name = "Bradford Forster Square",
            town = "Bradford",
            code = "BDQ",
            lat = 53.7968,
            lng = -1.7518,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.WALK),
            platformsOrStands = listOf("Platform 1", "Platform 2", "Platform 3")
        ),
        LocationNode(
            id = "loc_wakefield_west",
            name = "Wakefield Westgate",
            town = "Wakefield",
            code = "WKF",
            lat = 53.6820,
            lng = -1.5061,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK, TransportMode.CYCLE),
            platformsOrStands = listOf("Platform 1", "Platform 2", "Platform 3"),
            hasLifts = true
        ),
        LocationNode(
            id = "loc_wakefield_kirkgate",
            name = "Wakefield Kirkgate",
            town = "Wakefield",
            code = "WKK",
            lat = 53.6780,
            lng = -1.4910,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK)
        ),
        LocationNode(
            id = "loc_huddersfield_stn",
            name = "Huddersfield Station",
            town = "Huddersfield",
            code = "HUD",
            lat = 53.6485,
            lng = -1.7845,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK, TransportMode.CYCLE),
            platformsOrStands = listOf("Platform 1", "Platform 2", "Platform 4", "Platform 8"),
            hasLifts = true,
            hasCycleHub = true
        ),
        LocationNode(
            id = "loc_halifax_stn",
            name = "Halifax Station",
            town = "Halifax",
            code = "HFX",
            lat = 53.7225,
            lng = -1.8540,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK),
            platformsOrStands = listOf("Platform 1", "Platform 2")
        ),
        LocationNode(
            id = "loc_dewsbury_stn",
            name = "Dewsbury Station",
            town = "Dewsbury",
            code = "DEW",
            lat = 53.6912,
            lng = -1.6315,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK),
            platformsOrStands = listOf("Platform 1", "Platform 2")
        ),
        LocationNode(
            id = "loc_stourton_pr",
            name = "Stourton Park & Ride",
            town = "Leeds",
            code = "SPR",
            lat = 53.7660,
            lng = -1.5150,
            isInterchange = true,
            supportedModes = listOf(TransportMode.PARK_AND_RIDE, TransportMode.BUS, TransportMode.EV_CHARGE),
            platformsOrStands = listOf("Bay 1", "Bay 2")
        ),
        LocationNode(
            id = "loc_elland_road_pr",
            name = "Elland Road Park & Ride",
            town = "Leeds",
            code = "ERP",
            lat = 53.7780,
            lng = -1.5720,
            isInterchange = true,
            supportedModes = listOf(TransportMode.PARK_AND_RIDE, TransportMode.BUS)
        ),
        LocationNode(
            id = "loc_headingley",
            name = "Headingley Centre",
            town = "Leeds",
            code = "HDG",
            lat = 53.8180,
            lng = -1.5780,
            supportedModes = listOf(TransportMode.BUS, TransportMode.WALK, TransportMode.CYCLE)
        ),
        LocationNode(
            id = "loc_shipley",
            name = "Shipley Station",
            town = "Shipley",
            code = "SHP",
            lat = 53.8325,
            lng = -1.7740,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK)
        ),
        LocationNode(
            id = "loc_keighley",
            name = "Keighley Interchange",
            town = "Keighley",
            code = "KEI",
            lat = 53.8670,
            lng = -1.9050,
            isInterchange = true,
            supportedModes = listOf(TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK)
        )
    )

    // --- PARK & RIDE ---
    val parkAndRideFacilities = listOf(
        ParkAndRideFacility("pr_1", "Stourton Park & Ride", "Leeds (South)", 1200, 485, "£4.00 (Incl Return Bus)", 26, listOf("PR3 Stourton Express"), 53.7660, -1.5150),
        ParkAndRideFacility("pr_2", "Elland Road Park & Ride", "Leeds (West)", 800, 210, "£4.00 (Incl Return Bus)", 12, listOf("PR1 Elland Rd Express"), 53.7780, -1.5720),
        ParkAndRideFacility("pr_3", "Temple Green Park & Ride", "Leeds (East)", 1000, 610, "£4.00 (Incl Return Bus)", 16, listOf("PR2 Temple Green Express"), 53.7890, -1.4820),
        ParkAndRideFacility("pr_4", "Bradford South Park & Ride", "Bradford", 650, 320, "£3.50 (Incl Express Bus)", 8, listOf("Bus 72X Express"), 53.7710, -1.7420)
    )

    // --- EV CHARGERS ---
    val evChargers = listOf(
        EVChargingPoint("ev_1", "Stourton Mobility Hub", "Leeds", listOf("CCS 150kW Ultra Fast", "Type 2 22kW"), 18, 26, "£0.52 / kWh", 53.7662, -1.5152),
        EVChargingPoint("ev_2", "Leeds Station Southern Entrance Hub", "Leeds", listOf("CCS 50kW Fast", "Type 2 22kW"), 6, 8, "£0.48 / kWh", 53.7940, -1.5470),
        EVChargingPoint("ev_3", "Bradford Interchange Hub", "Bradford", listOf("CCS 150kW Ultra Fast", "Type 2 22kW"), 8, 12, "£0.50 / kWh", 53.7918, -1.7512),
        EVChargingPoint("ev_4", "Wakefield Westgate Plaza", "Wakefield", listOf("CCS 50kW Rapid", "Type 2 22kW"), 4, 6, "£0.46 / kWh", 53.6822, -1.5065),
        EVChargingPoint("ev_5", "Huddersfield St George's Square", "Huddersfield", listOf("CCS 150kW Ultra Fast"), 5, 8, "£0.52 / kWh", 53.6488, -1.7842)
    )

    // --- FUTURE MASS TRANSIT LINES ---
    val futureMassTransitLines = listOf(
        LocationNode("mt_1", "Leeds - Bradford Mass Transit Line (Planned)", "West Yorkshire", "MT1", 53.7930, -1.6500, true, listOf(TransportMode.FUTURE_MASS_TRANSIT)),
        LocationNode("mt_2", "Dewsbury & Spen Valley Mass Transit Line (Planned)", "Kirklees", "MT2", 53.6800, -1.6800, true, listOf(TransportMode.FUTURE_MASS_TRANSIT)),
        LocationNode("mt_3", "Leeds South & White Rose Mass Transit Line (Planned)", "Leeds", "MT3", 53.7600, -1.5500, true, listOf(TransportMode.FUTURE_MASS_TRANSIT))
    )

    // --- DISRUPTIONS STATE ---
    private val _disruptions = MutableStateFlow<List<DisruptionItem>>(
        listOf(
            DisruptionItem(
                id = "dis_1",
                title = "Calder Valley Rail Line Delay",
                description = "Signal fault near Dewsbury causing 18-25 minute delays on Northern rail services between Leeds and Manchester Victoria.",
                mode = TransportMode.RAIL,
                affectedLines = listOf("Calder Valley Line", "TransPennine Express"),
                severity = "MAJOR",
                timestamp = "14:15",
                rerouteSuggestion = "Take Weaver Bus 72 or 229 from Leeds City Square for direct connection."
            ),
            DisruptionItem(
                id = "dis_2",
                title = "Roadworks on A647 Bradford Road",
                description = "Lane restriction near Thorne causing 8 min bus delay during peak hours.",
                mode = TransportMode.BUS,
                affectedLines = listOf("Bus 72", "Bus X6"),
                severity = "MINOR",
                timestamp = "13:30",
                rerouteSuggestion = "Rail from Bradford Interchange to Leeds Station recommended for fast transit."
            )
        )
    )
    val disruptions: StateFlow<List<DisruptionItem>> = _disruptions.asStateFlow()

    // --- LIVE VEHICLES ---
    private val _liveVehicles = MutableStateFlow<List<LiveVehicle>>(
        listOf(
            LiveVehicle("v_bus_36", TransportMode.BUS, "Bus 36 (Harrogate-Leeds)", 53.8050, -1.5450, 180f, 32f, "Leeds City Square Stand C", 2, 45),
            LiveVehicle("v_bus_72", TransportMode.BUS, "Bus 72 (Leeds-Bradford)", 53.7930, -1.6500, 270f, 40f, "Bradford Interchange Stand 4", 4, 60),
            LiveVehicle("v_rail_nt1", TransportMode.RAIL, "Northern Rail 15:10", 53.7800, -1.6000, 240f, 75f, "Bradford Interchange", 18, 80),
            LiveVehicle("v_rail_tpe", TransportMode.RAIL, "TransPennine Express", 53.7100, -1.5800, 210f, 90f, "Huddersfield Station", 0, 30),
            LiveVehicle("v_bus_229", TransportMode.BUS, "Bus 229 (Leeds-Huddersfield)", 53.7200, -1.6000, 200f, 38f, "Dewsbury Station", 1, 50)
        )
    )
    val liveVehicles: StateFlow<List<LiveVehicle>> = _liveVehicles.asStateFlow()

    // --- NETWORK FRANCHISE PHASE ---
    val franchisePhase = MutableStateFlow(NetworkFranchisePhase.TRANSITION)

    // --- REGIONAL NETWORK STATUS ---
    val networkStatus = listOf(
        NetworkStatusSummary(TransportMode.BUS, "NORMAL OPERATION", true, "High frequency services running across 5 districts"),
        NetworkStatusSummary(TransportMode.RAIL, "MINOR DELAYS (+18 min)", false, "Signal fault on Calder Valley Line"),
        NetworkStatusSummary(TransportMode.WALK, "NORMAL", true, "Clear urban walking & pedestrian corridors"),
        NetworkStatusSummary(TransportMode.CYCLE, "NORMAL", true, "Aire & Calder Canal Towpath clear"),
        NetworkStatusSummary(TransportMode.PARK_AND_RIDE, "NORMAL (62% Space Free)", true, "Stourton & Elland Rd open"),
        NetworkStatusSummary(TransportMode.FUTURE_MASS_TRANSIT, "PLANNED NETWORK", true, "Public Consultation Phase 2 Active")
    )

    // --- LIVE DEPARTURES BOARD ---
    fun getDeparturesForStop(stopId: String): List<DepartureInfo> {
        val currentDisrupted = disruptions.value.any { it.severity == "MAJOR" }
        return when (stopId) {
            "loc_leeds_stn" -> listOf(
                DepartureInfo("dep_1", "Northern Rail", "Bradford Interchange", TransportMode.RAIL, "14:32", 2, "Platform 4", if (currentDisrupted) 18 else 0, "Northern", true, listOf("Cottingley", "Morley", "Dewsbury", "Bradford Interchange"), 75),
                DepartureInfo("dep_2", "TransPennine Express", "Huddersfield", TransportMode.RAIL, "14:40", 10, "Platform 1", 0, "TransPennine Express", true, listOf("Dewsbury", "Mirfield", "Huddersfield"), 45),
                DepartureInfo("dep_3", "LNER", "London King's Cross (via Wakefield)", TransportMode.RAIL, "14:45", 15, "Platform 8", 0, "LNER", true, listOf("Wakefield Westgate", "Doncaster", "London"), 85),
                DepartureInfo("dep_4", "Northern Rail", "Halifax", TransportMode.RAIL, "14:52", 22, "Platform 6", 2, "Northern", true, listOf("Bramley", "New Pudsey", "Bradford Interchange", "Halifax"), 30),
                DepartureInfo("dep_5", "Northern Rail", "Wakefield Westgate", TransportMode.RAIL, "15:02", 32, "Platform 11", 0, "Northern", true, listOf("Outwood", "Wakefield Westgate"), 20)
            )
            "loc_leeds_city_sq" -> listOf(
                DepartureInfo("dep_b1", "Bus 36", "Bradford Interchange", TransportMode.BUS, "14:35", 5, "Stand C", 0, "Weaver / Transdev", true, listOf("Armley", "Stanningley", "Bradford"), 55),
                DepartureInfo("dep_b2", "Bus 72", "Bradford Interchange", TransportMode.BUS, "14:42", 12, "Stand B", 3, "Weaver / First", true, listOf("Kirkstall", "Pudsey", "Bradford"), 60),
                DepartureInfo("dep_b3", "Bus 229", "Huddersfield Bus Station", TransportMode.BUS, "14:48", 18, "Stand D", 0, "Weaver Bus", true, listOf("Birstall", "Dewsbury", "Huddersfield"), 40),
                DepartureInfo("dep_b4", "PR3 Express", "Stourton Park & Ride", TransportMode.BUS, "14:50", 20, "Stand E", 0, "Weaver Park & Ride", true, listOf("Direct Park & Ride"), 25)
            )
            "loc_bradford_int" -> listOf(
                DepartureInfo("dep_bd1", "Northern Rail", "Leeds Station", TransportMode.RAIL, "14:38", 8, "Platform 1", 0, "Northern", true, listOf("New Pudsey", "Bramley", "Leeds"), 65),
                DepartureInfo("dep_bd2", "Bus 72", "Leeds City Centre", TransportMode.BUS, "14:44", 14, "Stand 4", 2, "Weaver / First", true, listOf("Thornbury", "Pudsey", "Leeds"), 50),
                DepartureInfo("dep_bd3", "Bus X6 Express", "Huddersfield", TransportMode.BUS, "14:55", 25, "Stand 8", 0, "Weaver Express", true, listOf("Low Moor", "Brighouse", "Huddersfield"), 35)
            )
            "loc_wakefield_west" -> listOf(
                DepartureInfo("dep_wk1", "Northern Rail", "Leeds Station", TransportMode.RAIL, "14:36", 6, "Platform 2", 0, "Northern", true, listOf("Outwood", "Leeds"), 40),
                DepartureInfo("dep_wk2", "TransPennine Express", "Sheffield", TransportMode.RAIL, "14:48", 18, "Platform 1", 0, "TransPennine", true, listOf("Barnsley", "Meadowhall", "Sheffield"), 50)
            )
            else -> listOf(
                DepartureInfo("dep_def1", "Bus 110", "Leeds City Centre", TransportMode.BUS, "14:34", 4, "Stand A", 0, "Weaver Bus", true, listOf("City Centre"), 30),
                DepartureInfo("dep_def2", "Northern Rail", "Regional Service", TransportMode.RAIL, "14:45", 15, "Platform 1", 0, "Northern", true, listOf("Regional Terminus"), 45)
            )
        }
    }

    // --- MULTIMODAL ROUTING ENGINE ---
    fun planJourney(
        originName: String,
        destinationName: String,
        prefs: UserPreferences
    ): List<JourneyOption> {
        val hasRailDisruption = _disruptions.value.any { it.mode == TransportMode.RAIL && it.severity == "MAJOR" }

        val origin = locations.find { it.name.equals(originName, ignoreCase = true) || it.town.equals(originName, ignoreCase = true) } ?: locations[0]
        val dest = locations.find { it.name.equals(destinationName, ignoreCase = true) || it.town.equals(destinationName, ignoreCase = true) } ?: locations[3]

        // Option 1: Multimodal Rail + Bus + Walk
        val leg1Walk = RouteLeg(
            mode = if (prefs.stepFreeOnly) TransportMode.WHEEL else TransportMode.WALK,
            originName = origin.name,
            destinationName = "${origin.name} Station Concourse",
            lineOrRouteName = "Walk / Wheel Corridor",
            operatorName = "Weaver Pedestrian Network",
            durationMinutes = 5,
            departureTime = "14:30",
            arrivalTime = "14:35",
            standOrPlatform = "",
            steps = listOf(RouteStep("Walk east towards Wellington Street", "300 m", "4 min"), RouteStep("Take step-free ramp to Concourse", "100 m", "1 min"))
        )

        val railDelay = if (hasRailDisruption) 18 else 0
        val leg2Rail = RouteLeg(
            mode = TransportMode.RAIL,
            originName = "${origin.name} Station",
            destinationName = "${dest.name} Interchange",
            lineOrRouteName = "Calder Valley / Airedale Line",
            operatorName = "Northern Rail",
            durationMinutes = 20 + railDelay,
            departureTime = "14:37",
            arrivalTime = if (hasRailDisruption) "15:15" else "14:57",
            standOrPlatform = "Platform 4",
            intermediateStops = listOf("Bramley", "New Pudsey"),
            isStepFree = true,
            isDisrupted = hasRailDisruption,
            disruptionNote = if (hasRailDisruption) "Signal fault near Dewsbury (+18 min delay)" else null
        )

        val leg3Walk = RouteLeg(
            mode = TransportMode.WALK,
            originName = "${dest.name} Interchange",
            destinationName = dest.name,
            lineOrRouteName = "Walk",
            operatorName = "Weaver Active Travel",
            durationMinutes = 7,
            departureTime = if (hasRailDisruption) "15:15" else "14:57",
            arrivalTime = if (hasRailDisruption) "15:22" else "15:04"
        )

        val option1 = JourneyOption(
            id = "j_fastest",
            title = if (hasRailDisruption) "RAIL (DELAYED)" else "FASTEST",
            totalMinutes = 32 + railDelay,
            walkMinutes = 12,
            changesCount = 1,
            estimatedFare = "£4.20",
            carbonEstimateKg = 0.8,
            isAccessible = true,
            legs = listOf(leg1Walk, leg2Rail, leg3Walk),
            badgeTags = listOf("Rail Direct", "MCard Accepted", if (hasRailDisruption) "Delayed +18m" else "On Time"),
            disruptionWarning = if (hasRailDisruption) "Rail delay active: 18 min signal fault. Consider Bus option below." else null
        )

        // Option 2: Express Bus Direct (Weaver Network)
        val legBusWalk = RouteLeg(
            mode = TransportMode.WALK,
            originName = origin.name,
            destinationName = "Leeds City Square Stand C",
            lineOrRouteName = "Walk",
            operatorName = "Weaver",
            durationMinutes = 4,
            departureTime = "14:30",
            arrivalTime = "14:34"
        )

        val legBus = RouteLeg(
            mode = TransportMode.BUS,
            originName = "Leeds City Square Stand C",
            destinationName = "${dest.name} Bus Station",
            lineOrRouteName = "Weaver Bus 36 / 72 Express",
            operatorName = "Weaver West Yorkshire",
            durationMinutes = 26,
            departureTime = "14:36",
            arrivalTime = "15:02",
            standOrPlatform = "Stand C",
            intermediateStops = listOf("Armley", "Stanningley Bottom", "Thornbury Junction"),
            isStepFree = true
        )

        val legBusEndWalk = RouteLeg(
            mode = TransportMode.WALK,
            originName = "${dest.name} Bus Station",
            destinationName = dest.name,
            lineOrRouteName = "Walk",
            operatorName = "Weaver Active Travel",
            durationMinutes = 5,
            departureTime = "15:02",
            arrivalTime = "15:07"
        )

        val option2 = JourneyOption(
            id = "j_bus_direct",
            title = if (hasRailDisruption) "RECOMMENDED (BYPASS DELAY)" else "FEWEST CHANGES",
            totalMinutes = 37,
            walkMinutes = 9,
            changesCount = 0,
            estimatedFare = "£2.00 (Single Cap)",
            carbonEstimateKg = 1.2,
            isAccessible = true,
            legs = listOf(legBusWalk, legBus, legBusEndWalk),
            badgeTags = listOf("Single £2 Cap", "Direct Bus", "Low Floor Ramp", "USB & WiFi")
        )

        // Option 3: Cycle + Rail Combination
        val legCycle1 = RouteLeg(
            mode = TransportMode.CYCLE,
            originName = origin.name,
            destinationName = "${origin.name} Station Bike Hub",
            lineOrRouteName = "Cycle - Aire & Calder Towpath",
            operatorName = "West Yorkshire Cycle Network",
            durationMinutes = 9,
            departureTime = "14:30",
            arrivalTime = "14:39",
            steps = listOf(RouteStep("Cycle west on Wellington St cycle superhighway", "1.2 km", "5 min"), RouteStep("Secure bike at Leeds Station Cycle Hub", "100 m", "4 min"))
        )

        val legCycle2Rail = RouteLeg(
            mode = TransportMode.RAIL,
            originName = "${origin.name} Station",
            destinationName = "${dest.name} Station",
            lineOrRouteName = "Airedale Express",
            operatorName = "Northern Rail",
            durationMinutes = 16,
            departureTime = "14:44",
            arrivalTime = "15:00",
            standOrPlatform = "Platform 1",
            isStepFree = true
        )

        val legCycle3 = RouteLeg(
            mode = TransportMode.CYCLE,
            originName = "${dest.name} Station",
            destinationName = dest.name,
            lineOrRouteName = "Cycle - City Link",
            operatorName = "Weaver Cycle Route 1",
            durationMinutes = 6,
            departureTime = "15:00",
            arrivalTime = "15:06"
        )

        val option3 = JourneyOption(
            id = "j_cycle_rail",
            title = "CYCLE + RAIL (LOW CARBON)",
            totalMinutes = 36,
            walkMinutes = 0,
            changesCount = 1,
            estimatedFare = "£4.20",
            carbonEstimateKg = 0.2,
            isAccessible = true,
            legs = listOf(legCycle1, legCycle2Rail, legCycle3),
            badgeTags = listOf("0.2kg CO2e", "Bike Hub Parking", "Active Travel")
        )

        // Option 4: Park & Ride Combination
        val legPR1Drive = RouteLeg(
            mode = TransportMode.PARK_AND_RIDE,
            originName = origin.name,
            destinationName = "Stourton Park & Ride",
            lineOrRouteName = "Drive + Park & Charge",
            operatorName = "Personal Vehicle",
            durationMinutes = 12,
            departureTime = "14:30",
            arrivalTime = "14:42",
            steps = listOf(RouteStep("Drive south on A61 to Stourton Mobility Hub", "4.5 km", "10 min"), RouteStep("Park in EV Charging Bay 12", "-", "2 min"))
        )

        val legPR2Bus = RouteLeg(
            mode = TransportMode.BUS,
            originName = "Stourton Park & Ride",
            destinationName = "${dest.name} City Centre",
            lineOrRouteName = "PR3 Stourton Bus Express",
            operatorName = "Weaver Park & Ride",
            durationMinutes = 15,
            departureTime = "14:45",
            arrivalTime = "15:00",
            standOrPlatform = "Bay 1",
            isStepFree = true
        )

        val option4 = JourneyOption(
            id = "j_park_ride",
            title = "PARK & RIDE + BUS",
            totalMinutes = 30,
            walkMinutes = 3,
            changesCount = 1,
            estimatedFare = "£4.00 (Park + Bus)",
            carbonEstimateKg = 2.1,
            isAccessible = true,
            legs = listOf(legPR1Drive, legPR2Bus),
            badgeTags = listOf("Free Parking", "EV Chargers 150kW", "Priority Bus Lane")
        )

        val allOptions = listOf(option1, option2, option3, option4)

        return when {
            prefs.fewestChanges -> allOptions.sortedBy { it.changesCount }
            prefs.lowestCost -> allOptions.sortedBy { it.estimatedFare }
            prefs.lowCarbonFirst -> allOptions.sortedBy { it.carbonEstimateKg }
            prefs.stepFreeOnly -> allOptions.filter { it.isAccessible }
            else -> allOptions.sortedBy { it.totalMinutes }
        }
    }

    // --- DISRUPTION INJECTION & CONTROL ---
    fun injectDisruption(title: String, description: String, mode: TransportMode, severity: String) {
        val newItem = DisruptionItem(
            id = "dis_${System.currentTimeMillis()}",
            title = title,
            description = description,
            mode = mode,
            affectedLines = listOf("Calder Valley Line", "Bus 36", "Bus 72"),
            severity = severity,
            timestamp = "Just Now",
            rerouteSuggestion = "Alternative Weaver Bus / Active Travel routes automatically computed."
        )
        _disruptions.value = listOf(newItem) + _disruptions.value
    }

    fun clearDisruptions() {
        _disruptions.value = emptyList()
    }

    // --- TICKETING ENGINE ---
    fun calculatePAYGFare(touchInStop: String, touchOutStop: String): Pair<Double, Double> {
        // Returns (calculatedFare, dailyCapRemaining)
        val baseSingle = 2.00
        val dailyCap = 4.80
        val calculated = minOf(baseSingle * 2.4, dailyCap)
        return Pair(calculated, maxOf(0.0, dailyCap - calculated))
    }
}
