package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WeaverDao {
    @Query("SELECT * FROM tickets ORDER BY createdAt DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("UPDATE tickets SET status = :status WHERE id = :id")
    suspend fun updateTicketStatus(id: String, status: String)

    @Query("SELECT * FROM saved_journeys ORDER BY lastPlannedAt DESC")
    fun getSavedJourneys(): Flow<List<SavedJourneyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedJourney(journey: SavedJourneyEntity)

    @Query("SELECT * FROM favorite_stops")
    fun getFavoriteStops(): Flow<List<FavoriteStopEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteStop(stop: FavoriteStopEntity)

    @Query("DELETE FROM favorite_stops WHERE stopId = :stopId")
    suspend fun removeFavoriteStop(stopId: String)
}
