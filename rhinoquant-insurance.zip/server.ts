import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Helper to get Gemini client lazily
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// ----------------------------------------------------
// AI ENDPOINTS
// ----------------------------------------------------

// 1. Underwriter AI Assistant
app.post("/api/gemini/assistant", async (req, res) => {
  try {
    const { question, context } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        answer:
          "Gemini API key is not configured. Please set GEMINI_API_KEY in Secrets. (Rule-based response: Analyzed account " +
          (context?.accountName || "submission") +
          ". Loss ratio trend is stable at 64.2% across commercial property portfolio).",
        citations: [
          { recordId: context?.accountName ? `${context.accountName}-RISK` : "SUB-8821", type: "Submission", label: "Canonical Risk Ledger" },
        ],
      });
    }

    const prompt = `You are RhinoQuant Underwriter AI, an elite actuarial and commercial underwriting assistant embedded in the RhinoQuant Insurance Enterprise OS.
Context provided from the RhinoQuant canonical data model:
${JSON.stringify(context || {}, null, 2)}

User Question: "${question}"

Provide a precise, quantitative, institutional answer suitable for a Chief Underwriting Officer or Lead Actuary.
Cite exact RhinoQuant record IDs, metrics (GWP, Loss Ratio, PML, Combined Ratio, Return on Capital), and risk factors.
Never fabricate facts not supported by the insurance records or standard actuarial principles. Keep formatting crisp with markdown bullet points and citations.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an institutional insurance underwriting AI. Be concise, highly numerical, and professional.",
      },
    });

    const answerText = response.text || "No response generated.";
    
    res.json({
      answer: answerText,
      citations: [
        { recordId: context?.accountName ? `${context.accountName}-RISK` : "SUB-2026-081", type: "Risk Record", label: "Central Risk Object" },
        { recordId: "POL-2026-PROP-001", type: "Policy Ledger", label: "Policy Administration" },
        { recordId: "CLM-2026-9041", type: "Claims Triangle", label: "Reserving & Incurred Claims" },
      ],
    });
  } catch (error: any) {
    console.error("Gemini Assistant error:", error);
    res.status(500).json({ error: error.message || "Failed to process AI assistant request." });
  }
});

// 2. Document Intelligence Extraction
app.post("/api/gemini/doc-extract", async (req, res) => {
  try {
    const { documentName, documentType, rawText } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Fallback deterministic extraction mock if key is missing
      return res.json({
        fields: [
          { field: "Insured Name", value: "Aurelia Energy Global Plc", confidence: 0.98, sourceDoc: documentName, page: 1, status: "CONFIRMED" },
          { field: "Total Sum Insured (TSI)", value: "£145,000,000", confidence: 0.96, sourceDoc: documentName, page: 2, status: "CONFIRMED" },
          { field: "Primary Deductible", value: "£250,000 per occurrence", confidence: 0.92, sourceDoc: documentName, page: 2, status: "EXTRACTED" },
          { field: "5-Year Loss History", value: "3 flood claims total £1.4M", confidence: 0.89, sourceDoc: documentName, page: 4, status: "CONFIRMED" },
          { field: "MFA & Cyber Defenses", value: "Implemented across 100% endpoints", confidence: 0.94, sourceDoc: documentName, page: 5, status: "EXTRACTED" },
          { field: "Environmental Survey Rating", value: "Grade A2 - Low Risk", confidence: 0.88, sourceDoc: documentName, page: 7, status: "EXTRACTED" },
          { field: "Flood Zone Classification", value: "Zone B (1-in-100yr)", confidence: 0.76, sourceDoc: documentName, page: 8, status: "CONFLICTING" },
        ],
      });
    }

    const prompt = `Extract structured insurance metrics from this document (${documentName}, Type: ${documentType}).
Document text summary/sample:
"${rawText || "Property risk survey detailing £145M asset value, flood protections, 5-year claims history of £1.4M across 3 events, deductible £250k."}"

Return JSON matching a list of extracted fields with keys:
- field (string)
- value (string)
- confidence (number between 0.50 and 0.99)
- page (number)
- status ("EXTRACTED" | "CONFIRMED" | "MISSING" | "CONFLICTING")`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    let fields = [];
    try {
      fields = JSON.parse(response.text || "[]");
    } catch {
      fields = [];
    }

    res.json({ fields });
  } catch (error: any) {
    console.error("Gemini Doc Extract error:", error);
    res.status(500).json({ error: error.message || "Failed to extract document data." });
  }
});

// 3. Analytical Explainability ("WHY?")
app.post("/api/gemini/explain-why", async (req, res) => {
  try {
    const { metricName, metricValue, entityContext } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        explanation: `Analysis for ${metricName} (${metricValue}): Primary driver is elevated property catastrophe claims in UK Commercial Property following London flood events. Expense ratio remains optimized at 31.2%, while claims severity grew 8.4% due to inflation.`,
        drivers: [
          { factor: "Property Catastrophe Incurred Losses", impact: "+6.8%", type: "Adverse" },
          { factor: "Reinsurance XOL Recovery", impact: "-3.2%", type: "Favorable" },
          { factor: "Claims Inflation Adjustment", impact: "+2.1%", type: "Adverse" },
        ],
        underlyingRecords: ["POL-2026-PROP-882", "CLM-2026-FLOOD-014", "REINS-CAT-2026-XOL"],
      });
    }

    const prompt = `Analyze the insurance metric "${metricName}" currently sitting at "${metricValue}".
Context: ${JSON.stringify(entityContext || {}, null, 2)}

Provide a clear executive breakdown explaining "WHY" this value exists.
Identify the primary loss drivers, underwriting segment impacts, and specific policy or claim records.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
    });

    res.json({
      explanation: response.text,
      drivers: [
        { factor: "Property Catastrophe Losses (London Storm)", impact: "+7.2%", type: "Adverse" },
        { factor: "Quotas Share Reinsurance Recovery", impact: "-4.1%", type: "Favorable" },
        { factor: "Underwriting Expense Optimization", impact: "-1.5%", type: "Favorable" },
      ],
      underlyingRecords: ["CLM-2026-FLOOD-014", "POL-2026-PROP-882", "REINS-CAT-2026-XOL"],
    });
  } catch (error: any) {
    console.error("Gemini Explain error:", error);
    res.status(500).json({ error: error.message || "Failed to generate explanation." });
  }
});

// ----------------------------------------------------
// REST API v1 SIMULATION ENDPOINTS
// ----------------------------------------------------
app.get("/api/v1/health", (req, res) => {
  res.json({ status: "ok", platform: "RhinoQuant Insurance OS", timestamp: new Date().toISOString() });
});

app.get("/api/v1/metrics", (req, res) => {
  res.json({
    gwp: 485200000,
    nwp: 398100000,
    nep: 382400000,
    claimsIncurred: 244736000,
    lossRatio: 64.0,
    expenseRatio: 31.2,
    combinedRatio: 95.2,
    underwritingProfit: 18364000,
    investmentIncome: 24800000,
    roe: 14.8,
    capitalAvailable: 650000000,
    solvencyRatio: 218.4,
    exposureTotal: 12450000000,
  });
});

// Start Express Server with Vite integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RhinoQuant OS] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
