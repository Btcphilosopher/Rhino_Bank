import { AuditEvent } from "../types";

export type InsuranceEventType =
  | "SubmissionCreated"
  | "QuoteGenerated"
  | "PolicyBound"
  | "PolicyEndorsed"
  | "ClaimOpened"
  | "ClaimReserved"
  | "ClaimPaid"
  | "ClaimClosed"
  | "PremiumReceived"
  | "RenewalCreated"
  | "ExposureChanged"
  | "ModelUpdated";

export interface InsuranceEvent {
  id: string;
  type: InsuranceEventType;
  timestamp: string;
  summary: string;
  entityId: string;
  entityName: string;
  actor: string;
  payload?: any;
}

type EventListener = (event: InsuranceEvent) => void;

class RealtimeInsuranceEventBus {
  private listeners: EventListener[] = [];
  private eventHistory: InsuranceEvent[] = [
    {
      id: "EVT-801",
      type: "SubmissionCreated",
      timestamp: "2026-08-31 08:00:12",
      summary: "New Energy Package Submission ingested for Aurelia Energy (£250M limit)",
      entityId: "SUB-2026-081",
      entityName: "Aurelia Energy Global Plc",
      actor: "Marsh Specialty Broker API",
    },
    {
      id: "EVT-802",
      type: "ClaimOpened",
      timestamp: "2026-08-31 08:15:44",
      summary: "FNOL Registered: Storm Surge Flood at Leeds Transport Interchange",
      entityId: "CLM-2026-9041",
      entityName: "Yorkshire Infrastructure Ltd",
      actor: "FNOL Portal",
    },
    {
      id: "EVT-803",
      type: "PolicyBound",
      timestamp: "2026-08-31 08:30:00",
      summary: "Policy Bound: RQ-2026-PROP-8821 (£2.95M GWP)",
      entityId: "POL-2026-PROP-001",
      entityName: "Yorkshire Infrastructure Ltd",
      actor: "Marcus Vance (Underwriter)",
    },
    {
      id: "EVT-804",
      type: "ModelUpdated",
      timestamp: "2026-08-31 08:45:10",
      summary: "Actuarial Rating Rule Updated: Offshore Energy Surcharge set to 1.85x",
      entityId: "RUL-101",
      entityName: "Offshore Energy Hazard Rule",
      actor: "Elena Rostova (Chief Actuary)",
    },
  ];

  public subscribe(listener: EventListener): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  public publish(type: InsuranceEventType, summary: string, entityId: string, entityName: string, actor: string, payload?: any) {
    const newEvent: InsuranceEvent = {
      id: `EVT-${Math.floor(1000 + Math.random() * 9000)}`,
      type,
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      summary,
      entityId,
      entityName,
      actor,
      payload,
    };

    this.eventHistory.unshift(newEvent);
    this.listeners.forEach((listener) => listener(newEvent));
  }

  public getHistory(): InsuranceEvent[] {
    return this.eventHistory;
  }
}

export const eventBus = new RealtimeInsuranceEventBus();
