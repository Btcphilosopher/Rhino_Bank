import React, { useState } from "react";
import { WorkspaceType } from "./types";
import {
  SYNTHETIC_ACCOUNTS,
  SYNTHETIC_POLICIES,
  SYNTHETIC_CLAIMS,
  SYNTHETIC_SUBMISSIONS,
  SYNTHETIC_REINSURANCE_CONTRACTS,
  SYNTHETIC_LOSS_TRIANGLE,
  SYNTHETIC_ML_MODELS,
} from "./data/syntheticDataset";

// Components & Modals
import { Header } from "./components/Header";
import { CommandBarModal } from "./components/CommandBarModal";
import { ConnectedEntityDrawer } from "./components/ConnectedEntityDrawer";
import { ExplainWhyModal } from "./components/ExplainWhyModal";
import { AIAssistantDrawer } from "./components/AIAssistantDrawer";

// Views
import { TerminalView } from "./views/TerminalView";
import { SubmissionsView } from "./views/SubmissionsView";
import { UnderwritingView } from "./views/UnderwritingView";
import { PricingView } from "./views/PricingView";
import { ClaimsView } from "./views/ClaimsView";
import { CatastropheView } from "./views/CatastropheView";
import { ReinsuranceView } from "./views/ReinsuranceView";
import { CapitalView } from "./views/CapitalView";
import { PortfolioView } from "./views/PortfolioView";
import { ProductBuilderView } from "./views/ProductBuilderView";
import { PolicyAdminView } from "./views/PolicyAdminView";
import { ERMScenariosView } from "./views/ERMScenariosView";

export function App() {
  const [currentWorkspace, setCurrentWorkspace] = useState<WorkspaceType>("UNDERWRITER");
  const [activeTab, setActiveTab] = useState<string>("TERMINAL");
  const [selectedTenant, setSelectedTenant] = useState<string>("Syndicate 1910 - Rhino Re Group");

  // Modals & Drawers State
  const [isCommandBarOpen, setIsCommandBarOpen] = useState(false);
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);

  // Connected Entity 360 Drawer State (Req 64)
  const [connectedAccountName, setConnectedAccountName] = useState<string | null>(null);

  // Explain Why Modal State (Req 65)
  const [explainMetric, setExplainMetric] = useState<{ name: string; value: string } | null>(null);

  const handleExecuteCommand = (cmd: string, tabTarget?: string, entityTarget?: string) => {
    if (entityTarget) {
      setConnectedAccountName(entityTarget);
    }
    if (tabTarget) {
      setActiveTab(tabTarget);
    }
  };

  const handleOpenConnectedAccount = (accountName: string) => {
    setConnectedAccountName(accountName);
  };

  const handleOpenExplainWhy = (metricName: string, metricValue: string) => {
    setExplainMetric({ name: metricName, value: metricValue });
  };

  // Filter connected data for 360 Drawer
  const connectedAccountData = SYNTHETIC_ACCOUNTS.find(
    (a) => a.name.toLowerCase() === (connectedAccountName || "").toLowerCase()
  ) || SYNTHETIC_ACCOUNTS[0];

  const connectedPolicies = SYNTHETIC_POLICIES.filter(
    (p) => p.insuredName.toLowerCase() === (connectedAccountName || "").toLowerCase()
  );

  const connectedClaims = SYNTHETIC_CLAIMS.filter(
    (c) => c.insuredName.toLowerCase() === (connectedAccountName || "").toLowerCase()
  );

  const connectedSubmissions = SYNTHETIC_SUBMISSIONS.filter(
    (s) => s.insuredName.toLowerCase() === (connectedAccountName || "").toLowerCase()
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-mono flex flex-col selection:bg-amber-500 selection:text-slate-950">
      {/* Institutional Top Navigation Header */}
      <Header
        currentWorkspace={currentWorkspace}
        onWorkspaceChange={setCurrentWorkspace}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenCommandBar={() => setIsCommandBarOpen(true)}
        onOpenAIAssistant={() => setIsAIAssistantOpen(true)}
        selectedTenant={selectedTenant}
        onTenantChange={setSelectedTenant}
      />

      {/* Main View Router Workspace */}
      <main className="flex-1 pb-12">
        {activeTab === "TERMINAL" && (
          <TerminalView
            workspace={currentWorkspace}
            onOpenExplainWhy={handleOpenExplainWhy}
            onOpenConnectedAccount={handleOpenConnectedAccount}
            onTabChange={setActiveTab}
          />
        )}

        {activeTab === "SUBMISSIONS" && (
          <SubmissionsView
            submissions={SYNTHETIC_SUBMISSIONS}
            onOpenConnectedAccount={handleOpenConnectedAccount}
          />
        )}

        {activeTab === "UNDERWRITING" && (
          <UnderwritingView
            accounts={SYNTHETIC_ACCOUNTS}
            policies={SYNTHETIC_POLICIES}
            onOpenConnectedAccount={handleOpenConnectedAccount}
          />
        )}

        {activeTab === "PRICING" && <PricingView />}

        {activeTab === "CLAIMS" && (
          <ClaimsView
            claims={SYNTHETIC_CLAIMS}
            lossTriangle={SYNTHETIC_LOSS_TRIANGLE}
          />
        )}

        {activeTab === "CATASTROPHE" && <CatastropheView />}

        {activeTab === "REINSURANCE" && <ReinsuranceView treaties={SYNTHETIC_REINSURANCE_CONTRACTS} />}

        {activeTab === "CAPITAL" && <CapitalView />}

        {activeTab === "PORTFOLIO" && <PortfolioView />}

        {activeTab === "PRODUCT_BUILDER" && <ProductBuilderView />}

        {activeTab === "POLICY_ADMIN" && <PolicyAdminView policies={SYNTHETIC_POLICIES} />}

        {activeTab === "ERM_SCENARIOS" && <ERMScenariosView mlModels={SYNTHETIC_ML_MODELS} />}
      </main>

      {/* Footer Telemetry */}
      <footer className="bg-slate-950 border-t border-slate-800/80 p-2 text-center text-[11px] text-slate-500 font-mono fixed bottom-0 left-0 right-0 z-30 flex items-center justify-between px-4">
        <span>RHINOQUANT OS v4.8.2 | Syndicate 1910 - Lloyd's & International Insurance Operating System</span>
        <span className="text-amber-500 font-bold">ALL CALCULATION ENGINES VERIFIED</span>
      </footer>

      {/* Command Bar Terminal Modal (Ctrl+K) */}
      <CommandBarModal
        isOpen={isCommandBarOpen}
        onClose={() => setIsCommandBarOpen(false)}
        onExecuteCommand={handleExecuteCommand}
      />

      {/* 360-Degree Cross-Module Intelligence Drawer (Req 64) */}
      <ConnectedEntityDrawer
        isOpen={!!connectedAccountName}
        onClose={() => setConnectedAccountName(null)}
        accountName={connectedAccountName || ""}
        accountData={connectedAccountData}
        connectedPolicies={connectedPolicies.length > 0 ? connectedPolicies : SYNTHETIC_POLICIES}
        connectedClaims={connectedClaims}
        connectedSubmissions={connectedSubmissions}
        connectedReinsurance={SYNTHETIC_REINSURANCE_CONTRACTS}
      />

      {/* AI Metric Explainability Modal "WHY?" (Req 65) */}
      <ExplainWhyModal
        isOpen={!!explainMetric}
        onClose={() => setExplainMetric(null)}
        metricName={explainMetric?.name || ""}
        metricValue={explainMetric?.value || ""}
      />

      {/* RhinoQuant Underwriter AI Drawer (Req 33) */}
      <AIAssistantDrawer
        isOpen={isAIAssistantOpen}
        onClose={() => setIsAIAssistantOpen(false)}
      />
    </div>
  );
}

export default App;
