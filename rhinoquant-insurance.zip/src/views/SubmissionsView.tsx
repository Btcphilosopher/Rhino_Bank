import React, { useState } from "react";
import { Layers, FileText, Upload, CheckCircle2, AlertCircle, Plus, Search, ChevronRight, Cpu } from "lucide-react";
import { Submission, LineOfBusiness } from "../types";
import { extractDocumentIntelligence, DocExtractResponse } from "../services/gemini";

interface SubmissionsViewProps {
  submissions: Submission[];
  onOpenConnectedAccount: (accountName: string) => void;
}

export const SubmissionsView: React.FC<SubmissionsViewProps> = ({ submissions, onOpenConnectedAccount }) => {
  const [selectedSub, setSelectedSub] = useState<Submission | null>(submissions[0] || null);
  const [docExtractResult, setDocExtractResult] = useState<DocExtractResponse | null>(null);
  const [extracting, setExtracting] = useState(false);
  const [showNewModal, setShowNewModal] = useState(false);

  // New Submission Form state
  const [newBroker, setNewBroker] = useState("Marsh Specialty");
  const [newInsured, setNewInsured] = useState("Vanguard Defense Systems");
  const [newLine, setNewLine] = useState<LineOfBusiness>("CYBER");
  const [newTerms, setNewTerms] = useState("£50M Primary Liability");
  const [newGwp, setNewGwp] = useState(1850000);

  const handleExtractDocs = async (sub: Submission) => {
    setSelectedSub(sub);
    setExtracting(true);
    const result = await extractDocumentIntelligence(
      `${sub.insuredName}_ProposalForm.pdf`,
      sub.lineOfBusiness
    );
    setDocExtractResult(result);
    setExtracting(false);
  };

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">SUBMISSION INTAKE & DOCUMENT INTELLIGENCE (REQ 4 & 5)</div>
          <h1 className="text-xl font-extrabold text-slate-100">Multi-Channel Submission Intake Workbench</h1>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowNewModal(true)}
            className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-4 py-2 rounded text-xs flex items-center space-x-1.5 shadow"
          >
            <Plus className="w-4 h-4" />
            <span>NEW SUBMISSION</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 5 Cols: Submissions Queue */}
        <div className="lg:col-span-5 bg-slate-900 p-4 rounded-lg border border-slate-800 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
            <span className="font-bold text-slate-200 uppercase">Active Submissions Queue ({submissions.length})</span>
            <span className="text-[10px] text-amber-400 font-bold">LIVE INGESTION ACTIVE</span>
          </div>

          <div className="space-y-2.5 max-h-[700px] overflow-y-auto">
            {submissions.map((sub) => {
              const isSelected = selectedSub?.id === sub.id;
              return (
                <div
                  key={sub.id}
                  onClick={() => handleExtractDocs(sub)}
                  className={`p-3.5 rounded border transition-all cursor-pointer ${
                    isSelected
                      ? "bg-slate-800 border-amber-500/80 shadow-md"
                      : "bg-slate-950/80 border-slate-800 hover:bg-slate-850"
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-amber-400 font-bold">{sub.id}</span>
                    <span className="text-[10px] bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded font-bold">
                      {sub.status}
                    </span>
                  </div>

                  <div className="text-sm font-bold text-slate-100 mt-1">{sub.insuredName}</div>
                  <div className="text-xs text-slate-400 mt-0.5">{sub.lineOfBusiness} | Broker: {sub.brokerName}</div>

                  <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Target Premium:</span>
                    <span className="font-bold text-emerald-400">£{(sub.requestedPremium / 1000000).toFixed(2)}M</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 7 Cols: Selected Submission Details & Gemini Document Intelligence */}
        <div className="lg:col-span-7 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-6">
          {selectedSub ? (
            <>
              {/* Top Details Box */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs bg-amber-950 text-amber-400 border border-amber-800 px-2 py-0.5 rounded font-bold">
                      {selectedSub.id}
                    </span>
                    <span className="text-xs text-slate-400">Broker: {selectedSub.brokerName}</span>
                  </div>
                  <h2 className="text-lg font-bold text-slate-100 mt-1">{selectedSub.insuredName}</h2>
                  <div className="text-xs text-slate-400">{selectedSub.requestedTerms}</div>
                </div>

                <button
                  onClick={() => onOpenConnectedAccount(selectedSub.insuredName)}
                  className="bg-slate-800 hover:bg-amber-600 hover:text-slate-950 text-amber-400 font-bold px-3 py-1.5 rounded text-xs border border-amber-500/40 transition-colors"
                >
                  OPEN 360° LEDGER
                </button>
              </div>

              {/* Document Ingestion & Extraction Panel */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Cpu className="w-4 h-4 text-amber-400" />
                    <h3 className="text-xs font-bold text-slate-200 uppercase">
                      Gemini 3.7 AI Document Intelligence Extracted Metadata
                    </h3>
                  </div>
                  {extracting && <span className="text-xs text-amber-400 animate-pulse">Extracting OCR & PDF Text...</span>}
                </div>

                {/* File Attachment Pill */}
                <div className="bg-slate-950 p-3 rounded border border-slate-800 flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2">
                    <FileText className="w-4 h-4 text-amber-400" />
                    <span className="text-slate-200 font-semibold">{selectedSub.insuredName}_Proposal_Form_2026.pdf</span>
                    <span className="text-[10px] text-slate-500">(4.2 MB)</span>
                  </div>
                  <span className="text-xs text-emerald-400 font-bold">OCR PARSED</span>
                </div>

                {/* Extracted Fields Table */}
                {docExtractResult ? (
                  <div className="space-y-2">
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase">
                          <tr>
                            <th className="p-2.5">Field Name</th>
                            <th className="p-2.5">Extracted Value</th>
                            <th className="p-2.5">Confidence</th>
                            <th className="p-2.5">Page Citation</th>
                            <th className="p-2.5">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800">
                          {docExtractResult.fields.map((f, fIdx) => (
                            <tr key={fIdx} className="hover:bg-slate-850">
                              <td className="p-2.5 font-bold text-slate-200">{f.field}</td>
                              <td className="p-2.5 text-amber-400 font-mono font-semibold">{f.value}</td>
                              <td className="p-2.5">
                                <span className="text-emerald-400 font-bold">{(f.confidence * 100).toFixed(0)}%</span>
                              </td>
                              <td className="p-2.5 text-slate-400">Page {f.page}</td>
                              <td className="p-2.5">
                                <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-1.5 py-0.5 rounded font-bold">
                                  {f.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <div className="p-6 bg-slate-950 rounded border border-slate-800 text-center space-y-2">
                    <p className="text-xs text-slate-400">Click below to trigger Gemini 3.7 AI extraction for this submission package.</p>
                    <button
                      onClick={() => handleExtractDocs(selectedSub)}
                      className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-4 py-2 rounded text-xs"
                    >
                      RUN AI DOCUMENT EXTRACTION
                    </button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="py-20 text-center text-slate-500 text-xs">Select a submission from the left queue to inspect details.</div>
          )}
        </div>
      </div>

      {/* New Submission Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg p-6 w-full max-w-lg font-mono text-slate-100 space-y-4">
            <h3 className="text-base font-bold text-amber-400 uppercase">Ingest New Insurance Submission</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Insured Legal Entity Name</label>
                <input
                  type="text"
                  value={newInsured}
                  onChange={(e) => setNewInsured(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Submitting Broker</label>
                <input
                  type="text"
                  value={newBroker}
                  onChange={(e) => setNewBroker(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Line of Business</label>
                <select
                  value={newLine}
                  onChange={(e) => setNewLine(e.target.value as LineOfBusiness)}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 focus:outline-none focus:border-amber-500"
                >
                  <option value="PROPERTY">PROPERTY</option>
                  <option value="ENERGY">ENERGY</option>
                  <option value="CASUALTY">CASUALTY</option>
                  <option value="CYBER">CYBER</option>
                  <option value="MARINE">MARINE</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Requested Terms / Limits</label>
                <input
                  type="text"
                  value={newTerms}
                  onChange={(e) => setNewTerms(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Target Premium (£)</label>
                <input
                  type="number"
                  value={newGwp}
                  onChange={(e) => setNewGwp(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowNewModal(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded text-xs"
              >
                CANCEL
              </button>
              <button
                onClick={() => {
                  const created: Submission = {
                    id: `SUB-2026-${Math.floor(100 + Math.random() * 900)}`,
                    riskId: `RSK-${Math.floor(100 + Math.random() * 900)}`,
                    accountId: `ACC-${Math.floor(100 + Math.random() * 900)}`,
                    brokerId: "BRK-202",
                    insuredName: newInsured,
                    brokerName: newBroker,
                    lineOfBusiness: newLine,
                    status: "UNDERWRITING",
                    requestedTerms: newTerms,
                    requestedPremium: newGwp,
                    technicalPremium: Math.round(newGwp * 1.05),
                    commercialPremium: newGwp,
                    documents: [],
                    createdAt: new Date().toISOString().substring(0, 10),
                    underwritingRulesTriggered: [],
                  };
                  submissions.unshift(created);
                  setSelectedSub(created);
                  setShowNewModal(false);
                }}
                className="px-4 py-1.5 bg-amber-600 text-slate-950 font-bold rounded text-xs"
              >
                INGEST SUBMISSION
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
