import React, { useState } from "react";
import { Layers, Shield, Cpu, ArrowDownRight, CheckCircle2 } from "lucide-react";
import { ReinsuranceContract } from "../types";

interface ReinsuranceViewProps {
  treaties: ReinsuranceContract[];
}

export const ReinsuranceView: React.FC<ReinsuranceViewProps> = ({ treaties }) => {
  const [grossLossSim, setGrossLossSim] = useState(120000000); // £120M gross loss
  const [selectedOpt, setSelectedOpt] = useState<"OPT_A" | "OPT_B" | "OPT_C">("OPT_A");

  // Reinsurance Tower Calculation for £120M gross loss under Option A (25% QS + £10M xs £10M XOL + £50M xs £20M Cat XOL)
  const quotaShareRecovery = grossLossSim * 0.25; // £30M
  const remainingAfterQs = grossLossSim - quotaShareRecovery; // £90M
  const retentionAmount = Math.min(20000000, remainingAfterQs); // £20M retention
  const catXolRecovery = Math.min(50000000, Math.max(0, remainingAfterQs - retentionAmount)); // £50M
  const netLoss = remainingAfterQs - catXolRecovery;

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">REINSURANCE ENGINE & TOWER OPTIMISER (REQ 20, 21 & 57)</div>
          <h1 className="text-xl font-extrabold text-slate-100">Capital Protection & Reinsurance Tower Simulator</h1>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <span className="text-slate-400 font-bold">GROSS LOSS STRESS SIMULATOR:</span>
          <input
            type="number"
            value={grossLossSim}
            onChange={(e) => setGrossLossSim(Number(e.target.value))}
            className="bg-slate-950 border border-slate-700 text-rose-400 font-bold p-2 rounded text-xs w-40 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 6 Cols: Reinsurance Tower Visualizer */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-bold text-slate-100 uppercase">01 / Reinsurance Protection Tower</h2>
            </div>
            <span className="text-[10px] text-emerald-400 font-bold">ACTIVE PROTECTION</span>
          </div>

          {/* Tower Stack Visualizer */}
          <div className="space-y-2.5">
            <div className="bg-rose-950/80 border border-rose-800 p-3 rounded text-xs flex justify-between items-center font-bold">
              <span>01. Gross Incurred Loss Event:</span>
              <span className="text-rose-400">£{(grossLossSim / 1000000).toFixed(1)}M</span>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 p-3 rounded text-xs flex justify-between items-center">
              <div>
                <div className="font-bold text-indigo-300">02. 25% Proportional Quota Share Recovery</div>
                <div className="text-[10px] text-slate-400">Swiss Re & Munich Re (AA Rating)</div>
              </div>
              <span className="text-indigo-400 font-bold">-£{(quotaShareRecovery / 1000000).toFixed(1)}M</span>
            </div>

            <div className="bg-cyan-950/80 border border-cyan-800 p-3 rounded text-xs flex justify-between items-center">
              <div>
                <div className="font-bold text-cyan-300">03. Catastrophe XOL Layer 1 (£50M xs £20M)</div>
                <div className="text-[10px] text-slate-400">Lloyd's Syndicates Consortium</div>
              </div>
              <span className="text-cyan-400 font-bold">-£{(catXolRecovery / 1000000).toFixed(1)}M</span>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-3 rounded text-xs flex justify-between items-center font-bold">
              <span>04. Net Retained Loss to Capital Surplus:</span>
              <span className="text-amber-400 font-extrabold text-sm">£{(netLoss / 1000000).toFixed(1)}M</span>
            </div>
          </div>
        </div>

        {/* Right 6 Cols: Reinsurance Optimiser (Option A vs B vs C) */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-bold text-slate-100 uppercase">02 / Reinsurance Structure Optimiser</h2>
            </div>
            <span className="text-[10px] text-cyan-400 font-bold">REQ 57 OPTIMISATION</span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[
              { id: "OPT_A", name: "OPTION A: BALANCED QS + XOL", cost: "£28.5M", netPml: "£50.0M", score: "OPTIMAL" },
              { id: "OPT_B", name: "OPTION B: HIGH XOL RETENTION", cost: "£19.2M", netPml: "£85.0M", score: "CHEAPER COST" },
              { id: "OPT_C", name: "OPTION C: MAXIMUM QUOTA SHARE", cost: "£36.8M", netPml: "£25.0M", score: "LOW VOLATILITY" },
            ].map((opt) => (
              <div
                key={opt.id}
                onClick={() => setSelectedOpt(opt.id as any)}
                className={`p-3 rounded border cursor-pointer transition-all ${
                  selectedOpt === opt.id
                    ? "bg-slate-800 border-amber-500 shadow"
                    : "bg-slate-950 border-slate-800 hover:bg-slate-850"
                }`}
              >
                <div className="text-[10px] font-bold text-amber-400">{opt.score}</div>
                <div className="text-xs font-bold text-slate-200 mt-1">{opt.name}</div>
                <div className="text-[11px] text-slate-400 mt-2">Cost: <span className="text-slate-200 font-bold">{opt.cost}</span></div>
                <div className="text-[11px] text-slate-400">Net PML: <span className="text-amber-400 font-bold">{opt.netPml}</span></div>
              </div>
            ))}
          </div>

          <div className="p-4 bg-slate-950 rounded border border-slate-800 text-xs text-slate-300 space-y-2">
            <div className="font-bold text-amber-400 uppercase">Selected Structure Trade-Off Analysis ({selectedOpt})</div>
            <p className="text-[11px] font-sans text-slate-400 leading-relaxed">
              Option A optimizes the trade-off between ceded premium cost (£28.5M GWP) and capital reduction. It reduces Solvency II SCR capital requirement by 34% while maintaining 1-in-250yr net loss limit at £50M.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
