import React, { useState } from "react";
import { Cpu, Plus, Settings, Layers, FileCode, CheckCircle2 } from "lucide-react";

export const ProductBuilderView: React.FC = () => {
  const [productName, setProductName] = useState("Commercial Offshore Wind Energy Policy v2.4");
  const [activeTab, setActiveTab] = useState<"COVERAGES" | "RATING_RULES" | "QUESTIONS">("COVERAGES");

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">INSURANCE PRODUCT BUILDER & RATING RULES (REQ 35 & 36)</div>
          <h1 className="text-xl font-extrabold text-slate-100">{productName}</h1>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded border border-slate-800 text-xs">
          {(["COVERAGES", "RATING_RULES", "QUESTIONS"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-3 py-1.5 rounded font-bold transition-colors ${
                activeTab === t ? "bg-amber-600 text-slate-950" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        {activeTab === "COVERAGES" ? (
          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <span className="font-bold text-slate-200 uppercase">Defined Policy Coverages & Sub-Limits</span>
              <button className="bg-amber-600 text-slate-950 px-3 py-1 rounded font-bold flex items-center space-x-1">
                <Plus className="w-3.5 h-3.5" /> <span>ADD COVERAGE SECTION</span>
              </button>
            </div>

            {[
              { code: "COV-01", name: "Physical Damage & Turbine Loss", limit: "£250,000,000", deductible: "£2,500,000" },
              { code: "COV-02", name: "Business Interruption & Revenue Loss", limit: "£100,000,000", deductible: "30 Days Waiting Period" },
              { code: "COV-03", name: "Third Party Environmental Liability", limit: "£50,000,000", deductible: "£500,000" },
            ].map((c, idx) => (
              <div key={idx} className="bg-slate-950 p-3.5 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-amber-400">{c.code} - {c.name}</div>
                  <div className="text-[10px] text-slate-400">Limit: {c.limit} | Deductible: {c.deductible}</div>
                </div>
                <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                  ACTIVE RULESET
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3 text-xs">
            <div className="text-slate-200 font-bold uppercase">Visual Rating Logic Expression Editor</div>
            <div className="bg-slate-950 p-4 rounded border border-slate-800 font-mono text-emerald-400 space-y-2">
              <div>// Actuarial Rating Logic Version 2.4</div>
              <div>base_premium = total_sum_insured * 0.0185;</div>
              <div>if (peril_zone == "NORTH_SEA_FLOOD") base_premium *= 1.35;</div>
              <div>if (has_subsea_cable_protection) base_premium *= 0.90;</div>
              <div>technical_premium = base_premium * (1 + expense_pct + reinsurance_cost_pct);</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
