import React, { useState } from "react";
import { Shield, AlertTriangle, CheckCircle2, UserCheck, Settings, Sliders, ChevronRight, Lock } from "lucide-react";
import { CustomerAccount, Policy, RiskProfile, UnderwritingScoreBreakdown } from "../types";
import { computeUnderwritingScore } from "../utils/actuarial";

interface UnderwritingViewProps {
  accounts: CustomerAccount[];
  policies: Policy[];
  onOpenConnectedAccount: (accountName: string) => void;
}

export const UnderwritingView: React.FC<UnderwritingViewProps> = ({ accounts, policies, onOpenConnectedAccount }) => {
  const [selectedAcc, setSelectedAcc] = useState<CustomerAccount>(accounts[0]);
  const [overrideModal, setOverrideModal] = useState(false);
  const [overrideReason, setOverrideReason] = useState("");
  const [overrideDecision, setOverrideDecision] = useState<"ACCEPT" | "DECLINE">("ACCEPT");

  // Compute Underwriting Score dynamically
  const scoreBreakdown: UnderwritingScoreBreakdown = computeUnderwritingScore(
    { sumInsured: 145000000, hazardLevel: 3 },
    4200000,
    { revenue: selectedAcc.annualRevenue, creditRating: selectedAcc.creditRating },
    { hasMfa: true, riskControlsCount: 4 },
    { isHazardous: selectedAcc.industry.includes("Energy") || selectedAcc.industry.includes("Maritime") }
  );

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">UNDERWRITING WORKBENCH & RISK OBJECT ENGINE (REQ 6, 7 & 8)</div>
          <h1 className="text-xl font-extrabold text-slate-100">Central Risk Object & Rating Rules Evaluation</h1>
        </div>

        <div className="flex items-center space-x-2">
          <select
            value={selectedAcc.id}
            onChange={(e) => {
              const found = accounts.find((a) => a.id === e.target.value);
              if (found) setSelectedAcc(found);
            }}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs p-2 rounded focus:outline-none focus:border-amber-500 font-bold"
          >
            {accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name} ({a.industry})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 6 Cols: Central Risk Object Details */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <span className="text-[10px] bg-amber-950 text-amber-400 border border-amber-800 px-2 py-0.5 rounded font-bold">
                CENTRAL RISK OBJECT #{selectedAcc.id}
              </span>
              <h2 className="text-lg font-bold text-slate-100 mt-1">{selectedAcc.name}</h2>
            </div>
            <button
              onClick={() => onOpenConnectedAccount(selectedAcc.name)}
              className="bg-slate-800 hover:bg-amber-600 hover:text-slate-950 text-amber-400 text-xs font-bold px-3 py-1.5 rounded border border-amber-500/30"
            >
              DRILLDOWN 360° LEDGER
            </button>
          </div>

          {/* Risk Object Attributes List */}
          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3 bg-slate-950 p-3 rounded border border-slate-800">
              <div><span className="text-slate-500">Industry Sector:</span> <span className="text-slate-200 font-bold">{selectedAcc.industry}</span></div>
              <div><span className="text-slate-500">Annual Revenue:</span> <span className="text-amber-400 font-bold">£{(selectedAcc.annualRevenue / 1000000).toFixed(0)}M</span></div>
              <div><span className="text-slate-500">Credit Rating:</span> <span className="text-emerald-400 font-bold">{selectedAcc.creditRating}</span></div>
              <div><span className="text-slate-500">Insured Asset Locations:</span> <span className="text-slate-200 font-bold">14 Facilities (UK/EU)</span></div>
            </div>

            {/* Risk Controls Evaluated */}
            <div className="space-y-1.5">
              <span className="text-slate-400 font-bold uppercase text-[10px]">Evaluated Operational Risk Controls:</span>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between text-emerald-400 font-semibold">
                  <span>MFA & Cyber Defenses</span>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <div className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between text-emerald-400 font-semibold">
                  <span>Fire Suppression Systems</span>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <div className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between text-emerald-400 font-semibold">
                  <span>Flood Barriers (1-in-200yr)</span>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <div className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between text-amber-400 font-semibold">
                  <span>Business Continuity Plan</span>
                  <AlertTriangle className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* Configurable Underwriting Rules Triggered */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="text-[10px] text-amber-400 font-bold uppercase">Automated Rating Rules Fired:</div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-amber-400 font-semibold">
                  <span>RULE-101: Offshore/Energy Surcharge (1.85x)</span>
                  <span className="text-[10px] bg-amber-950 border border-amber-800 px-1.5 py-0.5 rounded">FIRED</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span>RULE-204: Limit Threshold &gt; £100M requires Referral</span>
                  <span className="text-[10px] bg-slate-800 border border-slate-700 px-1.5 py-0.5 rounded text-amber-400 font-bold">REFERRAL</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right 6 Cols: Underwriting Score Breakdown & Underwriter Decision Panel */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <div className="text-[10px] text-amber-400 font-bold uppercase">TRANSPARENT SCORE BREAKDOWN</div>
              <h2 className="text-base font-bold text-slate-100">Overall Risk Score: {scoreBreakdown.overallRiskScore} / 100</h2>
            </div>
            <span className={`text-xs px-2.5 py-1 rounded font-bold uppercase border ${
              scoreBreakdown.decisionRecommendation === "AUTO_ACCEPT"
                ? "bg-emerald-950 text-emerald-400 border-emerald-800"
                : scoreBreakdown.decisionRecommendation === "ACCEPT_WITH_LOAD"
                ? "bg-amber-950 text-amber-400 border-amber-800"
                : "bg-rose-950 text-rose-400 border-rose-800"
            }`}>
              REC: {scoreBreakdown.decisionRecommendation}
            </span>
          </div>

          {/* Sub-Score Bars */}
          <div className="space-y-3 text-xs">
            {[
              { label: "Exposure Score (Weight: 20%)", score: scoreBreakdown.exposureScore },
              { label: "Claims History Score (Weight: 25%)", score: scoreBreakdown.claimsScore },
              { label: "Financial Credit Score (Weight: 15%)", score: scoreBreakdown.financialScore },
              { label: "Operational Risk Score (Weight: 15%)", score: scoreBreakdown.operationalScore },
              { label: "Industry Peril Score (Weight: 10%)", score: scoreBreakdown.industryScore },
              { label: "Geographic Exposure Score (Weight: 5%)", score: scoreBreakdown.geographicScore },
              { label: "Risk Control Quality Score (Weight: 10%)", score: scoreBreakdown.riskControlScore },
            ].map((s, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-[11px] text-slate-300 font-semibold">
                  <span>{s.label}</span>
                  <span className="font-bold text-amber-400">{s.score}/100</span>
                </div>
                <div className="w-full bg-slate-950 h-2 rounded overflow-hidden">
                  <div
                    className={`h-full ${
                      s.score > 75 ? "bg-emerald-500" : s.score > 50 ? "bg-amber-500" : "bg-rose-500"
                    }`}
                    style={{ width: `${s.score}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>

          {/* Underwriter Action & Override Dialog */}
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3">
            <div className="text-xs font-bold text-slate-200 uppercase flex items-center space-x-1.5">
              <UserCheck className="w-4 h-4 text-amber-400" />
              <span>Consequential Decision Authority</span>
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Underwriting authorities require explicit confirmation or reasoned override for referred risk parameters.
            </p>

            <div className="flex items-center space-x-3 pt-2">
              <button
                onClick={() => setOverrideModal(true)}
                className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-4 py-2 rounded text-xs flex-1 transition-colors"
              >
                RECORD UNDERWRITER OVERRIDE / ACCEPTANCE
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Override Modal */}
      {overrideModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg p-6 w-full max-w-lg font-mono text-slate-100 space-y-4">
            <h3 className="text-base font-bold text-amber-400 uppercase">Underwriter Consequential Override Log</h3>
            <p className="text-xs text-slate-400 font-sans">
              Pursuant to Lloyd's & Solvency II underwriting governance standards, reason for overriding automated recommendation must be documented in audit trail.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1 font-bold">Override Decision</label>
                <select
                  value={overrideDecision}
                  onChange={(e) => setOverrideDecision(e.target.value as "ACCEPT" | "DECLINE")}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 focus:outline-none focus:border-amber-500"
                >
                  <option value="ACCEPT">ACCEPT WITH ADDITIONAL RATING SURCHARGE</option>
                  <option value="DECLINE">DECLINE RISK ENTIRELY</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-bold">Mandatory Reason & Audit Note</label>
                <textarea
                  rows={4}
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="State engineering controls, loss history mitigation, or senior syndicate peer review details..."
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setOverrideModal(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded text-xs"
              >
                CANCEL
              </button>
              <button
                onClick={() => {
                  setOverrideModal(false);
                  alert(`Override logged to Audit Ledger for ${selectedAcc.name}`);
                }}
                className="px-4 py-1.5 bg-amber-600 text-slate-950 font-bold rounded text-xs"
              >
                SIGN & RECORD DECISION
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
