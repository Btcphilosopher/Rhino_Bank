import React, { useState } from "react";
import { Lock, ShieldAlert, Activity, Cpu, AlertTriangle, Layers, CheckCircle2 } from "lucide-react";
import { MLModelRegistryEntry } from "../types";

interface ERMScenariosViewProps {
  mlModels: MLModelRegistryEntry[];
}

export const ERMScenariosView: React.FC<ERMScenariosViewProps> = ({ mlModels }) => {
  const [activeTab, setActiveTab] = useState<"HEATMAP" | "ORSA_PLANNING" | "ML_GOVERNANCE" | "DATA_QUALITY">("HEATMAP");

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">ENTERPRISE RISK MANAGEMENT & GOVERNANCE (REQ 30 - 32, 41, 43 - 45, 58)</div>
          <h1 className="text-xl font-extrabold text-slate-100">CRO Risk Heatmap & ML Model Governance Registry</h1>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded border border-slate-800 text-xs">
          {(["HEATMAP", "ORSA_PLANNING", "ML_GOVERNANCE", "DATA_QUALITY"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-3 py-1.5 rounded font-bold transition-colors ${
                activeTab === t ? "bg-amber-600 text-slate-950" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {t.replace("_", " ")}
            </button>
          ))}
        </div>
      </div>

      {activeTab === "HEATMAP" ? (
        /* CRO Heatmap & Concentration Alerts */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
            <div className="text-xs font-bold text-slate-200 uppercase pb-2 border-b border-slate-800">
              01 / Enterprise Risk Taxonomy Heatmap Matrix
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { risk: "Property Catastrophe Flood", level: "HIGH", score: "78/100", color: "bg-rose-950 border-rose-800 text-rose-400" },
                { risk: "Offshore Energy Pipeline Asset", level: "MEDIUM-HIGH", score: "64/100", color: "bg-amber-950 border-amber-800 text-amber-400" },
                { risk: "Cyber Ransomware Accumulation", level: "HIGH", score: "72/100", color: "bg-rose-950 border-rose-800 text-rose-400" },
                { risk: "Investment Credit Default Spread", level: "LOW-MEDIUM", score: "34/100", color: "bg-emerald-950 border-emerald-800 text-emerald-400" },
                { risk: "Operational IT Outage / SLA", level: "LOW", score: "22/100", color: "bg-emerald-950 border-emerald-800 text-emerald-400" },
                { risk: "Inflationary Claims Reserving", level: "MEDIUM", score: "52/100", color: "bg-amber-950 border-amber-800 text-amber-400" },
              ].map((r, idx) => (
                <div key={idx} className={`p-3.5 rounded border ${r.color} space-y-1`}>
                  <div className="text-[10px] uppercase font-bold text-slate-400">{r.level}</div>
                  <div className="font-bold text-xs text-slate-100">{r.risk}</div>
                  <div className="text-sm font-black">{r.score}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
            <div className="text-xs font-bold text-slate-200 uppercase pb-2 border-b border-slate-800">
              02 / Concentration Risk Accumulation Alerts
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="bg-slate-950 p-3 rounded border border-rose-800 text-rose-400 space-y-1">
                <div className="font-bold flex items-center space-x-1">
                  <AlertTriangle className="w-4 h-4" />
                  <span>ALERT: London Thames Flood Accumulation Peak</span>
                </div>
                <p className="text-[11px] text-slate-300 font-sans">
                  Total Sum Insured within 5km radius exceeds £850M capital limit (£920M current).
                </p>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-amber-800 text-amber-400 space-y-1">
                <div className="font-bold flex items-center space-x-1">
                  <ShieldAlert className="w-4 h-4" />
                  <span>WARNING: Single-Broker Ceded Premium Share</span>
                </div>
                <p className="text-[11px] text-slate-300 font-sans">
                  Marsh Specialty accounts for 29.4% of total GWP (Guideline max: 30.0%).
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : activeTab === "ML_GOVERNANCE" ? (
        /* ML Model Registry & Governance */
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <div className="text-[10px] text-amber-400 font-bold uppercase">ML MODEL REGISTRY & GOVERNANCE (REQ 44)</div>
              <h2 className="text-base font-bold text-slate-100">Audited Actuarial Machine Learning Models</h2>
            </div>
            <span className="text-xs text-emerald-400 font-bold">PRA / FCA GOVERNANCE COMPLIANT</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3">Model Name & ID</th>
                  <th className="p-3">Target Objective</th>
                  <th className="p-3">Primary Metric</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Deployment Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {mlModels.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-850">
                    <td className="p-3 font-bold text-amber-400">{m.modelName} ({m.id})</td>
                    <td className="p-3 text-slate-300">{m.targetVariable}</td>
                    <td className="p-3 font-bold text-emerald-400">
                      {m.metrics.rocAuc ? `ROC-AUC: ${m.metrics.rocAuc}` : `MAE: £${m.metrics.mae}`}
                    </td>
                    <td className="p-3">
                      <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                        {m.approvalStatus}
                      </span>
                    </td>
                    <td className="p-3 text-slate-400 text-[11px]">{m.deploymentDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Data Quality & ORSA Planning */
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 text-xs text-slate-300 space-y-3">
          <div className="text-amber-400 font-bold uppercase">Solvency II ORSA 5-Year Capital Projection</div>
          <p className="font-sans text-slate-400">
            5-Year projected solvency ratio remains robust between 212% and 224% under baseline organic growth (8% p.a.).
          </p>
        </div>
      )}
    </div>
  );
};
