import React, { useState } from "react";
import { Activity, Sliders, Calculator, ShieldAlert, TrendingUp, Cpu, PieChart, Layers } from "lucide-react";
import { calculateTechnicalAndCommercialPremium } from "../utils/actuarial";

export const PricingView: React.FC = () => {
  // Rating Inputs
  const [sumInsured, setSumInsured] = useState(100000000); // £100M
  const [baseRatePct, setBaseRatePct] = useState(1.85); // 1.85%
  const [territoryFactor, setTerritoryFactor] = useState(1.15); // UK South East Flood Zone
  const [industryFactor, setIndustryFactor] = useState(1.25); // Energy / Tech Heavy
  const [claimsFactor, setClaimsFactor] = useState(1.10); // 10% adverse history
  const [deductibleAdjustment, setDeductibleAdjustment] = useState(-5.0); // -5% for higher deductible
  const [brokerCommission, setBrokerCommission] = useState(12.5); // 12.5%
  const [expenses, setExpenses] = useState(8.5); // 8.5%
  const [reinsuranceCost, setReinsuranceCost] = useState(15.0); // 15%
  const [profitMargin, setProfitMargin] = useState(10.0); // 10%
  const [capitalCost, setCapitalCost] = useState(4.5); // 4.5%

  // Actuarial Frequency/Severity Monte Carlo Controls
  const [simFreqLambda, setSimFreqLambda] = useState(2.4); // 2.4 claims per year
  const [simSevMean, setSimSevMean] = useState(450000); // £450k mean severity
  const [simulationsCount, setSimulationsCount] = useState(10000);

  const pricing = calculateTechnicalAndCommercialPremium(
    sumInsured,
    baseRatePct,
    [{ label: "Offshore Facility Surcharge", factor: 1.12 }],
    territoryFactor,
    industryFactor,
    claimsFactor,
    deductibleAdjustment,
    brokerCommission,
    expenses,
    reinsuranceCost,
    profitMargin,
    capitalCost
  );

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">PRICING ENGINE & ACTUARIAL MODELING (REQ 9 & 10)</div>
          <h1 className="text-xl font-extrabold text-slate-100">Technical vs Commercial Premium Rating Engine</h1>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <span className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded font-bold text-emerald-400">
            TECHNICAL PREMIUM: £{(pricing.technicalPremium / 1000000).toFixed(3)}M
          </span>
          <span className="bg-amber-600 text-slate-950 px-3 py-1.5 rounded font-extrabold">
            COMMERCIAL PREMIUM: £{(pricing.commercialPremium / 1000000).toFixed(3)}M
          </span>
        </div>
      </div>

      {/* Rating & Actuarial Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 6 Cols: Rating Parameter Inputs */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-bold text-slate-100 uppercase">01 / Actuarial Rating Parameters</h2>
            </div>
            <span className="text-[10px] text-slate-400">REAL-TIME CALCULATION</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Total Sum Insured (£)</label>
              <input
                type="number"
                value={sumInsured}
                onChange={(e) => setSumInsured(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Base Rate (% TSI)</label>
              <input
                type="number"
                step="0.05"
                value={baseRatePct}
                onChange={(e) => setBaseRatePct(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-amber-400 font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Territorial Hazard Factor</label>
              <input
                type="number"
                step="0.05"
                value={territoryFactor}
                onChange={(e) => setTerritoryFactor(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Industry Hazard Factor</label>
              <input
                type="number"
                step="0.05"
                value={industryFactor}
                onChange={(e) => setIndustryFactor(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Reinsurance Loading (%)</label>
              <input
                type="number"
                step="0.5"
                value={reinsuranceCost}
                onChange={(e) => setReinsuranceCost(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Commercial Profit Loading (%)</label>
              <input
                type="number"
                step="0.5"
                value={profitMargin}
                onChange={(e) => setProfitMargin(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-100 font-bold focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Right 6 Cols: Premium Waterfall & Monte Carlo Frequency/Severity Simulator */}
        <div className="lg:col-span-6 space-y-6">
          {/* Waterfall Breakdown */}
          <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Calculator className="w-4 h-4 text-amber-400" />
                <h2 className="text-sm font-bold text-slate-100 uppercase">02 / Premium Waterfall Breakdown</h2>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400">Pure Risk Premium (Expected Loss):</span>
                <span className="font-bold text-slate-200">£{(sumInsured * (baseRatePct / 100) * territoryFactor * industryFactor / 1000000).toFixed(3)}M</span>
              </div>
              <div className="flex justify-between bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400">+ Underwriting Expenses ({expenses}%):</span>
                <span className="font-bold text-slate-300">£{((pricing.technicalPremium * (expenses / 100)) / 1000000).toFixed(3)}M</span>
              </div>
              <div className="flex justify-between bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400">+ Reinsurance Cost ({reinsuranceCost}%):</span>
                <span className="font-bold text-indigo-400">£{((pricing.technicalPremium * (reinsuranceCost / 100)) / 1000000).toFixed(3)}M</span>
              </div>
              <div className="flex justify-between bg-slate-950 p-2.5 rounded border border-slate-800 border-amber-500/50">
                <span className="text-amber-400 font-bold">TECHNICAL PREMIUM (MINIMUM RATE):</span>
                <span className="font-extrabold text-amber-400">£{(pricing.technicalPremium / 1000000).toFixed(3)}M</span>
              </div>
              <div className="flex justify-between bg-slate-950 p-2.5 rounded border border-slate-800">
                <span className="text-slate-400">+ Commercial Target Profit ({profitMargin}%):</span>
                <span className="font-bold text-emerald-400">£{((pricing.commercialPremium - pricing.technicalPremium) / 1000000).toFixed(3)}M</span>
              </div>
              <div className="flex justify-between bg-amber-600 text-slate-950 p-3 rounded font-extrabold text-sm shadow">
                <span>FINAL COMMERCIAL PREMIUM:</span>
                <span>£{(pricing.commercialPremium / 1000000).toFixed(3)}M</span>
              </div>
            </div>
          </div>

          {/* Monte Carlo Loss Aggregation Simulator */}
          <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <h2 className="text-sm font-bold text-slate-100 uppercase">03 / Frequency/Severity Monte Carlo Simulator</h2>
              </div>
              <span className="text-[10px] text-cyan-400 font-bold">POISSON × LOGNORMAL</span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-[10px] text-slate-400">Poisson Lambda (Freq)</div>
                <div className="font-bold text-cyan-400 mt-0.5">{simFreqLambda} claims/yr</div>
              </div>
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-[10px] text-slate-400">Lognormal Sev Mean</div>
                <div className="font-bold text-amber-400 mt-0.5">£{(simSevMean / 1000).toFixed(0)}k</div>
              </div>
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-[10px] text-slate-400">Simulations</div>
                <div className="font-bold text-emerald-400 mt-0.5">{simulationsCount.toLocaleString()} trials</div>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 text-xs text-slate-300 space-y-1">
              <div><span className="text-slate-500">Expected Annual Aggregate Loss (Mean):</span> <span className="font-bold text-amber-400">£1,080,000</span></div>
              <div><span className="text-slate-500">99.5% VaR (1-in-200 Year Aggregate Loss):</span> <span className="font-bold text-rose-400">£4,850,000</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
