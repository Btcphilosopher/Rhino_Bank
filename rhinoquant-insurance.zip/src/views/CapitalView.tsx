import React, { useState } from "react";
import { Activity, Shield, TrendingUp, Sliders, DollarSign } from "lucide-react";
import { runAlmDurationSensitivity, calculateRaroc } from "../utils/actuarial";

export const CapitalView: React.FC = () => {
  const [rateShockBps, setRateShockBps] = useState(100); // +100bps rate shock

  // ALM Portfolio Values
  const assetMarketValue = 850000000; // £850M investment assets
  const assetDuration = 4.2; // 4.2 years duration
  const liabilityValue = 680000000; // £680M insurance liabilities
  const liabilityDuration = 5.8; // 5.8 years duration

  const almResult = runAlmDurationSensitivity(
    assetMarketValue,
    assetDuration,
    liabilityValue,
    liabilityDuration,
    rateShockBps
  );

  const rarocScore = calculateRaroc(18400000, 24800000, 12000000, 180000000);

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">CAPITAL & ALM WORKSTATION (REQ 22 - 24, 40)</div>
          <h1 className="text-xl font-extrabold text-slate-100">Solvency II Capital & Asset-Liability Management (ALM)</h1>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <span className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded font-bold text-purple-400">
            SOLVENCY CAPITAL REQUIREMENT (SCR): £297.6M
          </span>
          <span className="bg-emerald-600 text-slate-950 px-3 py-1.5 rounded font-extrabold">
            SOLVENCY RATIO: 218.4%
          </span>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 6 Cols: Solvency II Risk Capital Breakdown */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h2 className="text-sm font-bold text-slate-100 uppercase">01 / Solvency II SCR Module Capital Allocation</h2>
            <span className="text-[10px] text-slate-400">99.5% VaR (1-in-200yr)</span>
          </div>

          <div className="space-y-3 text-xs">
            {[
              { module: "Underwriting Risk (Non-Life)", scr: "£165.2M", pct: 45 },
              { module: "Market Risk (Equity, Rates, Spreads)", scr: "£88.4M", pct: 24 },
              { module: "Counterparty Default / Credit Risk", scr: "£42.0M", pct: 11 },
              { module: "Catastrophe Risk Module", scr: "£52.8M", pct: 14 },
              { module: "Operational Risk Module", scr: "£22.0M", pct: 6 },
            ].map((m, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-slate-300 font-semibold">
                  <span>{m.module}</span>
                  <span className="font-bold text-amber-400">{m.scr}</span>
                </div>
                <div className="w-full bg-slate-950 h-2 rounded overflow-hidden">
                  <div className="bg-amber-500 h-full" style={{ width: `${m.pct * 1.8}%` }}></div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-slate-950 p-3.5 rounded border border-slate-800 text-xs flex items-center justify-between">
            <span className="text-slate-400 font-bold">Risk-Adjusted Return on Capital (RAROC):</span>
            <span className="text-emerald-400 font-extrabold text-sm">{rarocScore}%</span>
          </div>
        </div>

        {/* Right 6 Cols: ALM Duration Mismatch & Rate Shock Simulator */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h2 className="text-sm font-bold text-slate-100 uppercase">02 / Asset-Liability Duration Mismatch</h2>
            <div className="flex items-center space-x-2 text-xs">
              <span className="text-slate-400">RATE SHOCK:</span>
              <select
                value={rateShockBps}
                onChange={(e) => setRateShockBps(Number(e.target.value))}
                className="bg-slate-950 border border-slate-700 text-amber-400 font-bold p-1 rounded"
              >
                <option value={100}>+100 bps (+1.0%)</option>
                <option value={200}>+200 bps (+2.0%)</option>
                <option value={-100}>-100 bps (-1.0%)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">Asset Duration</div>
              <div className="text-base font-bold text-slate-100">{assetDuration} yrs (£850M)</div>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">Liability Duration</div>
              <div className="text-base font-bold text-amber-400">{liabilityDuration} yrs (£680M)</div>
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2 text-xs">
            <div className="font-bold text-amber-400 uppercase">Rate Shock Impact Results ({rateShockBps} bps)</div>
            <div className="flex justify-between text-slate-300">
              <span>Delta Asset Market Value:</span>
              <span className={almResult.deltaAssets < 0 ? "text-rose-400 font-bold" : "text-emerald-400 font-bold"}>
                £{(almResult.deltaAssets / 1000000).toFixed(2)}M
              </span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Delta Insurance Liability Value:</span>
              <span className="text-emerald-400 font-bold">£{(almResult.deltaLiabilities / 1000000).toFixed(2)}M</span>
            </div>
            <div className="flex justify-between font-bold text-slate-100 pt-2 border-t border-slate-800">
              <span>Net Economic Surplus:</span>
              <span className="text-amber-400 font-extrabold text-sm">
                £{(almResult.netEconomicSurplus / 1000000).toFixed(2)}M
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
