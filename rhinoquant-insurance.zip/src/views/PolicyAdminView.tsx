import React, { useState } from "react";
import { Shield, FileText, DollarSign, CheckCircle2, ChevronRight, Layers } from "lucide-react";
import { Policy } from "../types";

interface PolicyAdminViewProps {
  policies: Policy[];
}

export const PolicyAdminView: React.FC<PolicyAdminViewProps> = ({ policies }) => {
  const [selectedPol, setSelectedPol] = useState<Policy>(policies[0]);

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">POLICY LIFECYCLE & FINANCIAL LEDGER (REQ 34, 37 & 38)</div>
          <h1 className="text-xl font-extrabold text-slate-100">Insurance Administration & Double-Entry Ledger</h1>
        </div>

        <div className="flex items-center space-x-2">
          <button className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-3 py-1.5 rounded text-xs">
            ISSUE MID-TERM ENDORSEMENT
          </button>
          <button className="bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold px-3 py-1.5 rounded text-xs">
            GENERATE RENEWAL NOTICE
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 5 Cols: Policies Directory */}
        <div className="lg:col-span-5 bg-slate-900 p-4 rounded-lg border border-slate-800 space-y-3">
          <div className="text-xs font-bold text-slate-200 uppercase pb-2 border-b border-slate-800">
            Bound Policy Register ({policies.length})
          </div>

          <div className="space-y-2.5 max-h-[600px] overflow-y-auto">
            {policies.map((pol) => {
              const isSelected = selectedPol?.id === pol.id;
              return (
                <div
                  key={pol.id}
                  onClick={() => setSelectedPol(pol)}
                  className={`p-3.5 rounded border transition-all cursor-pointer ${
                    isSelected
                      ? "bg-slate-800 border-amber-500 shadow"
                      : "bg-slate-950/80 border-slate-800 hover:bg-slate-850"
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="text-amber-400">{pol.policyNumber}</span>
                    <span className="text-emerald-400 font-bold uppercase text-[10px] bg-emerald-950 border border-emerald-800 px-1.5 rounded">
                      {pol.status}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-100 mt-1">{pol.insuredName}</div>
                  <div className="text-[10px] text-slate-400">{pol.lineOfBusiness} | Limit: £{(pol.limit / 1000000).toFixed(0)}M</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 7 Cols: Policy Ledger Transactions */}
        <div className="lg:col-span-7 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-5">
          {selectedPol && (
            <>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <div className="text-xs text-amber-400 font-bold">{selectedPol.policyNumber}</div>
                  <h2 className="text-base font-bold text-slate-100">{selectedPol.insuredName}</h2>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-slate-400">GWP Ledger</div>
                  <div className="text-base font-bold text-amber-400">£{(selectedPol.gwp / 1000000).toFixed(2)}M</div>
                </div>
              </div>

              {/* Double-Entry Financial Ledger */}
              <div className="space-y-2">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Double-Entry Financial Ledger Records</div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                      <tr>
                        <th className="p-2.5">Date</th>
                        <th className="p-2.5">Account / Code</th>
                        <th className="p-2.5">Debit (£)</th>
                        <th className="p-2.5">Credit (£)</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 font-mono">
                      <tr className="hover:bg-slate-850">
                        <td className="p-2.5 text-slate-400">2026-08-31</td>
                        <td className="p-2.5 font-bold text-slate-200">1100 - Premium Receivable (Broker)</td>
                        <td className="p-2.5 font-bold text-emerald-400">£2,950,000</td>
                        <td className="p-2.5 text-slate-500">-</td>
                        <td className="p-2.5"><span className="text-emerald-400 text-[10px] font-bold">POSTED</span></td>
                      </tr>
                      <tr className="hover:bg-slate-850">
                        <td className="p-2.5 text-slate-400">2026-08-31</td>
                        <td className="p-2.5 font-bold text-slate-200">4000 - Gross Written Premium (GWP)</td>
                        <td className="p-2.5 text-slate-500">-</td>
                        <td className="p-2.5 font-bold text-amber-400">£2,950,000</td>
                        <td className="p-2.5"><span className="text-emerald-400 text-[10px] font-bold">POSTED</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
