import React, { useState } from "react";
import { Activity, Shield, TrendingUp, HelpCircle, DollarSign, PieChart as PieIcon, ArrowUpRight, ArrowDownRight, Layers } from "lucide-react";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar, Cell } from "recharts";
import { WorkspaceType } from "../types";

interface TerminalViewProps {
  workspace: WorkspaceType;
  onOpenExplainWhy: (metricName: string, metricValue: string) => void;
  onOpenConnectedAccount: (accountName: string) => void;
  onTabChange: (tab: string) => void;
}

const gwpTrendData = [
  { month: "Jan", gwp: 34.2, claims: 18.1, net: 16.1 },
  { month: "Feb", gwp: 38.5, claims: 21.4, net: 17.1 },
  { month: "Mar", gwp: 42.1, claims: 22.0, net: 20.1 },
  { month: "Apr", gwp: 39.8, claims: 20.2, net: 19.6 },
  { month: "May", gwp: 44.5, claims: 25.8, net: 18.7 },
  { month: "Jun", gwp: 48.2, claims: 32.4, net: 15.8 },
  { month: "Jul", gwp: 51.0, claims: 29.1, net: 21.9 },
  { month: "Aug", gwp: 54.8, claims: 31.0, net: 23.8 },
];

const lobPerformance = [
  { lob: "Property", gwp: 142.5, lossRatio: 68.2, combined: 99.4 },
  { lob: "Energy", gwp: 118.0, lossRatio: 58.4, combined: 89.6 },
  { lob: "Casualty", gwp: 92.4, lossRatio: 64.1, combined: 95.3 },
  { lob: "Cyber", gwp: 64.2, lossRatio: 42.8, combined: 74.0 },
  { lob: "Marine", gwp: 68.1, lossRatio: 72.5, combined: 103.7 },
];

export const TerminalView: React.FC<TerminalViewProps> = ({
  workspace,
  onOpenExplainWhy,
  onOpenConnectedAccount,
  onTabChange,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<"EXECUTIVE" | "TREND" | "FORECAST" | "SCENARIO">("EXECUTIVE");

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Sub-Tab Selector & Workspace Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold tracking-wider uppercase">INSURANCE TERMINAL (REQ 3 & 53)</div>
          <h1 className="text-xl font-extrabold text-slate-100 flex items-center space-x-2">
            <span>RHINOQUANT ENTERPRISE OPERATING TERMINAL</span>
            <span className="text-xs bg-slate-800 text-amber-400 border border-slate-700 px-2 py-0.5 rounded font-mono">
              WORKSPACE: {workspace}
            </span>
          </h1>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded border border-slate-800 text-xs">
          {(["EXECUTIVE", "TREND", "FORECAST", "SCENARIO"] as const).map((sub) => (
            <button
              key={sub}
              onClick={() => setActiveSubTab(sub)}
              className={`px-3 py-1.5 rounded font-bold transition-colors ${
                activeSubTab === sub ? "bg-amber-600 text-slate-950" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {sub} VIEW
            </button>
          ))}
        </div>
      </div>

      {/* 13 Primary Enterprise Tiles Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3.5">
        {/* Metric 1 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Gross Written Premium</span>
            <button onClick={() => onOpenExplainWhy("Gross Written Premium", "£485.2M")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-amber-400 mt-1">£485.2M</div>
          <div className="text-[10px] text-emerald-400 flex items-center mt-1 font-mono">
            <ArrowUpRight className="w-3 h-3 mr-0.5" /> +12.4% YoY
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Net Written Premium</span>
            <button onClick={() => onOpenExplainWhy("Net Written Premium", "£398.1M")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-slate-100 mt-1">£398.1M</div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Retention: 82.0%</div>
        </div>

        {/* Metric 3 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Earned Premium (NEP)</span>
            <button onClick={() => onOpenExplainWhy("Earned Premium", "£382.4M")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-cyan-400 mt-1">£382.4M</div>
          <div className="text-[10px] text-emerald-400 mt-1 font-mono">+8.1% vs Budget</div>
        </div>

        {/* Metric 4 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Incurred Claims</span>
            <button onClick={() => onOpenExplainWhy("Incurred Claims", "£244.7M")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-rose-400 mt-1">£244.7M</div>
          <div className="text-[10px] text-rose-400 flex items-center mt-1 font-mono">
            <ArrowUpRight className="w-3 h-3 mr-0.5" /> London Flood Impact
          </div>
        </div>

        {/* Metric 5 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Loss Ratio</span>
            <button onClick={() => onOpenExplainWhy("Loss Ratio", "64.0%")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-emerald-400 mt-1">64.0%</div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Target: &lt;65.0%</div>
        </div>

        {/* Metric 6 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Expense Ratio</span>
            <button onClick={() => onOpenExplainWhy("Expense Ratio", "31.2%")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-slate-200 mt-1">31.2%</div>
          <div className="text-[10px] text-emerald-400 mt-1 font-mono">-1.4% Efficiency Gain</div>
        </div>

        {/* Metric 7 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-amber-500/60 shadow-lg relative group">
          <div className="flex items-center justify-between text-[11px] text-amber-400 font-sans font-bold">
            <span>Combined Ratio</span>
            <button onClick={() => onOpenExplainWhy("Combined Ratio", "95.2%")} className="text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-2xl font-black text-amber-400 mt-1">95.2%</div>
          <div className="text-[10px] text-emerald-400 font-bold mt-1 uppercase">Underwriting Profit: +4.8%</div>
        </div>

        {/* Metric 8 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Underwriting Result</span>
            <button onClick={() => onOpenExplainWhy("Underwriting Result", "£18.4M")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-emerald-400 mt-1">+£18.4M</div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Net UW Surplus</div>
        </div>

        {/* Metric 9 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Investment Float Yield</span>
            <button onClick={() => onOpenExplainWhy("Investment Income", "£24.8M")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-cyan-400 mt-1">+£24.8M</div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Float Yield: 4.85%</div>
        </div>

        {/* Metric 10 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Return on Equity (ROE)</span>
            <button onClick={() => onOpenExplainWhy("ROE", "14.8%")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-indigo-400 mt-1">14.8%</div>
          <div className="text-[10px] text-emerald-400 mt-1 font-mono">Benchmark: 12.0%</div>
        </div>

        {/* Metric 11 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Solvency II Coverage</span>
            <button onClick={() => onOpenExplainWhy("Solvency II Ratio", "218.4%")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-purple-400 mt-1">218.4%</div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Available Cap: £650M</div>
        </div>

        {/* Metric 12 */}
        <div className="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 hover:border-amber-500/50 transition-colors relative group">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Total Sum Insured (TSI)</span>
            <button onClick={() => onOpenExplainWhy("Exposure Total", "£12.45B")} className="text-amber-500 hover:text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-xl font-extrabold text-slate-100 mt-1">£12.45B</div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">1,420 Insured Assets</div>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart: GWP vs Incurred Claims Trend */}
        <div className="lg:col-span-2 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[10px] text-amber-400 font-bold uppercase">ENTERPRISE PRODUCTION & CLAIMS TREND</div>
              <h3 className="text-sm font-bold text-slate-100">GWP vs Incurred Claims (2026 Monthly)</h3>
            </div>
            <div className="flex items-center space-x-3 text-xs">
              <span className="flex items-center space-x-1 text-amber-400">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
                <span>GWP (£M)</span>
              </span>
              <span className="flex items-center space-x-1 text-rose-400">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block"></span>
                <span>Claims (£M)</span>
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={gwpTrendData}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#020617", borderColor: "#334155", borderRadius: "6px" }}
                  labelStyle={{ color: "#fbbf24", fontWeight: "bold" }}
                />
                <Area type="monotone" dataKey="gwp" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.15} strokeWidth={2} />
                <Area type="monotone" dataKey="claims" stroke="#f43f5e" fill="#f43f5e" fillOpacity={0.15} strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Side Chart: Combined Ratio by Line of Business */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div>
            <div className="text-[10px] text-amber-400 font-bold uppercase">PORTFOLIO PROFITABILITY</div>
            <h3 className="text-sm font-bold text-slate-100">Combined Ratio by Line of Business</h3>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={lobPerformance} layout="vertical">
                <XAxis type="number" domain={[0, 120]} stroke="#64748b" fontSize={11} />
                <YAxis type="category" dataKey="lob" stroke="#64748b" fontSize={11} width={65} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#020617", borderColor: "#334155" }}
                />
                <Bar dataKey="combined" radius={[0, 4, 4, 0]}>
                  {lobPerformance.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.combined > 100 ? "#f43f5e" : entry.combined > 90 ? "#f59e0b" : "#10b981"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Connected Accounts Quick Drilldown Table */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] text-amber-400 font-bold uppercase">CONNECTED CORPORATE LEDGERS (REQUIREMENT 64)</div>
            <h3 className="text-sm font-bold text-slate-100">Institutional Insured Portfolios & Connected Records</h3>
          </div>
          <span className="text-xs text-slate-400">Click any company to open 360° connected ledger</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-3">Insured Name</th>
                <th className="p-3">Industry</th>
                <th className="p-3">Active Policies</th>
                <th className="p-3">GWP (£)</th>
                <th className="p-3">Loss Ratio</th>
                <th className="p-3">Credit Rating</th>
                <th className="p-3 text-right">360° Drilldown</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {[
                { name: "Aurelia Energy Global Plc", industry: "Energy & Offshore", count: 4, gwp: "£28.5M", loss: "58.4%", rating: "A+" },
                { name: "Yorkshire Infrastructure Ltd", industry: "Civil Engineering", count: 3, gwp: "£14.2M", loss: "71.2%", rating: "A" },
                { name: "Meridian Healthcare Trust", industry: "Medical Facilities", count: 2, gwp: "£18.9M", loss: "42.1%", rating: "AA-" },
                { name: "Atlas Logistics & Freight SE", industry: "Maritime Supply Chain", count: 5, gwp: "£31.2M", loss: "88.6%", rating: "BBB+" },
              ].map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-850 cursor-pointer" onClick={() => onOpenConnectedAccount(row.name)}>
                  <td className="p-3 font-bold text-amber-400 flex items-center space-x-1.5">
                    <span>{row.name}</span>
                  </td>
                  <td className="p-3 text-slate-300">{row.industry}</td>
                  <td className="p-3">{row.count}</td>
                  <td className="p-3 font-bold">{row.gwp}</td>
                  <td className={`p-3 font-bold ${parseFloat(row.loss) > 70 ? "text-rose-400" : "text-emerald-400"}`}>
                    {row.loss}
                  </td>
                  <td className="p-3">{row.rating}</td>
                  <td className="p-3 text-right">
                    <button className="bg-slate-800 hover:bg-amber-600 hover:text-slate-950 text-slate-200 px-2.5 py-1 rounded text-[11px] font-bold transition-colors">
                      CONNECT 360°
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
