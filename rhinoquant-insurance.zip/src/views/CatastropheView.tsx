import React, { useState } from "react";
import { Cpu, AlertTriangle, Shield, Layers, MapPin, Zap } from "lucide-react";

export const CatastropheView: React.FC = () => {
  const [activePeril, setActivePeril] = useState<"ALL" | "FLOOD" | "WINDSTORM" | "QUAKE">("ALL");
  const [scenarioSim, setScenarioSim] = useState<"NONE" | "LONDON_FLOOD" | "NORTH_SEA_STORM">("NONE");

  const locations = [
    { id: "LOC-1", name: "London Financial District HQ", lat: "51.513", lng: "-0.088", tsi: 450000000, peril: "FLOOD", hazard: "HIGH" },
    { id: "LOC-2", name: "Teesside Industrial Energy Port", lat: "54.612", lng: "-1.182", tsi: 320000000, peril: "WINDSTORM", hazard: "VERY_HIGH" },
    { id: "LOC-3", name: "Leeds Transportation Terminal", lat: "53.795", lng: "-1.547", tsi: 180000000, peril: "FLOOD", hazard: "MEDIUM" },
    { id: "LOC-4", name: "Aberdeen Offshore Logistics Hub", lat: "57.149", lng: "-2.094", tsi: 290000000, peril: "WINDSTORM", hazard: "HIGH" },
  ];

  const returnPeriods = [
    { period: "1-in-10 yr", grossLoss: 18.5, netLoss: 5.2 },
    { period: "1-in-50 yr", grossLoss: 45.2, netLoss: 12.8 },
    { period: "1-in-100 yr", grossLoss: 88.4, netLoss: 22.0 },
    { period: "1-in-250 yr (Solvency II PML)", grossLoss: 165.0, netLoss: 35.0 },
    { period: "1-in-500 yr", grossLoss: 280.0, netLoss: 50.0 },
  ];

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">CATASTROPHE RISK & EXPOSURE MAP (REQ 17 - 19)</div>
          <h1 className="text-xl font-extrabold text-slate-100">Probable Maximum Loss (PML) & Spatial Hazard Engine</h1>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <span className="text-slate-400">SELECT SIMULATED CAT SCENARIO:</span>
          <select
            value={scenarioSim}
            onChange={(e) => setScenarioSim(e.target.value as any)}
            className="bg-slate-950 border border-slate-700 text-amber-400 font-bold p-2 rounded focus:outline-none focus:border-amber-500"
          >
            <option value="NONE">BASELINE PORTFOLIO (NO EVENT)</option>
            <option value="LONDON_FLOOD">1-IN-200 YEAR THAMES FLOOD SURGE</option>
            <option value="NORTH_SEA_STORM">NORTH SEA PIPELINE EXPLOSION & STORM</option>
          </select>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Spatial Exposure Map & Asset Locations */}
        <div className="lg:col-span-7 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-bold text-slate-100 uppercase">Spatial Exposure Distribution Map</h2>
            </div>
            <div className="flex space-x-1 text-xs">
              {(["ALL", "FLOOD", "WINDSTORM", "QUAKE"] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setActivePeril(p)}
                  className={`px-2.5 py-1 rounded font-bold text-[10px] ${
                    activePeril === p ? "bg-amber-600 text-slate-950" : "bg-slate-950 text-slate-400"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Simulated Dark Terminal Map Container */}
          <div className="relative w-full h-80 bg-slate-950 rounded border border-slate-800 overflow-hidden flex items-center justify-center">
            {/* Grid Map Background */}
            <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>

            {/* Simulated Radar Sweep if Scenario Active */}
            {scenarioSim !== "NONE" && (
              <div className="absolute inset-0 border-2 border-rose-500/50 rounded-full animate-ping opacity-30"></div>
            )}

            {/* Map Markers */}
            <div className="relative z-10 w-full h-full p-6 flex flex-col justify-between">
              <div className="flex justify-between items-start text-[10px] text-slate-500 font-mono">
                <span>LAT: 51.5° N to 57.1° N</span>
                <span>LON: -2.0° W to -0.0° E</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {locations.map((loc) => (
                  <div key={loc.id} className="bg-slate-900/90 p-2.5 rounded border border-slate-800 hover:border-amber-500 text-xs">
                    <div className="flex items-center justify-between font-bold text-slate-200">
                      <span>{loc.name}</span>
                      <span className="text-[10px] bg-rose-950 text-rose-400 border border-rose-800 px-1 rounded">
                        {loc.hazard}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1">
                      Peril: <span className="text-amber-400 font-bold">{loc.peril}</span> | TSI: £{(loc.tsi / 1000000).toFixed(0)}M
                    </div>
                  </div>
                ))}
              </div>

              <div className="text-right text-[10px] text-emerald-400 font-bold">
                TOTAL EXPOSURE VISUALIZED: £1.24 BILLION
              </div>
            </div>
          </div>
        </div>

        {/* Right 5 Cols: PML & Exceedance Probability (EP) Curves */}
        <div className="lg:col-span-5 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-rose-400" />
              <h2 className="text-sm font-bold text-slate-100 uppercase">Exceedance Probability (EP) Curve</h2>
            </div>
          </div>

          <div className="space-y-2">
            {returnPeriods.map((rp, idx) => (
              <div key={idx} className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1 text-xs">
                <div className="flex justify-between font-bold text-slate-200">
                  <span>{rp.period}</span>
                  <span className="text-rose-400">Gross: £{rp.grossLoss}M</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>Reinsurance Tower Net Loss:</span>
                  <span className="text-emerald-400 font-bold">Net: £{rp.netLoss}M</span>
                </div>
              </div>
            ))}
          </div>

          {/* AAL Metrics */}
          <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-1 text-xs">
            <div className="text-[10px] text-slate-400 uppercase font-bold">Average Annual Loss (AAL)</div>
            <div className="text-lg font-extrabold text-amber-400">£8.42M per annum</div>
            <div className="text-[10px] text-slate-400">Representing 1.73% of total Portfolio GWP</div>
          </div>
        </div>
      </div>
    </div>
  );
};
