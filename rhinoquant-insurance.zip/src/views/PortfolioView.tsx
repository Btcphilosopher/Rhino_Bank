import React, { useState } from "react";
import { Briefcase, Activity, BarChart2, Users, Layers, TrendingUp } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";

export const PortfolioView: React.FC = () => {
  const [sliceBy, setSliceBy] = useState<"LINE_OF_BUSINESS" | "BROKER" | "UNDERWRITER" | "REGION">("LINE_OF_BUSINESS");

  const brokerAnalytics = [
    { name: "Marsh Specialty", gwp: 142.5, lossRatio: 58.2, commission: "12.5%", qualityScore: "A+" },
    { name: "Aon Commercial Risk", gwp: 118.0, lossRatio: 64.1, commission: "11.0%", qualityScore: "A" },
    { name: "Willis Towers Watson", gwp: 92.4, lossRatio: 72.8, commission: "14.0%", qualityScore: "B+" },
    { name: "Howden Insurance Brokers", gwp: 68.1, lossRatio: 48.4, commission: "10.5%", qualityScore: "AA" },
  ];

  return (
    <div className="p-6 space-y-6 font-mono text-slate-100 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-lg border border-slate-800">
        <div>
          <div className="text-[10px] text-amber-400 font-bold uppercase">PORTFOLIO & BROKER INTELLIGENCE (REQ 25 - 28)</div>
          <h1 className="text-xl font-extrabold text-slate-100">Portfolio Profitability & Distribution Quality Analytics</h1>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded border border-slate-800 text-xs">
          {(["LINE_OF_BUSINESS", "BROKER", "UNDERWRITER", "REGION"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSliceBy(s)}
              className={`px-3 py-1.5 rounded font-bold transition-colors ${
                sliceBy === s ? "bg-amber-600 text-slate-950" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              SLICE BY {s.replace("_", " ")}
            </button>
          ))}
        </div>
      </div>

      {/* Broker Intelligence Table */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <div className="text-[10px] text-amber-400 font-bold uppercase">DISTRIBUTION CHANNEL ANALYTICS</div>
            <h2 className="text-base font-bold text-slate-100">Broker Quality & Combined Ratio Performance</h2>
          </div>
          <span className="text-xs text-slate-400">4 Major Institutional Distribution Partners</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-3">Broker Partner</th>
                <th className="p-3">GWP (£M)</th>
                <th className="p-3">Loss Ratio</th>
                <th className="p-3">Avg Commission</th>
                <th className="p-3">Quality Score</th>
                <th className="p-3 text-right">Profitability Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {brokerAnalytics.map((b, idx) => (
                <tr key={idx} className="hover:bg-slate-850">
                  <td className="p-3 font-bold text-amber-400">{b.name}</td>
                  <td className="p-3 font-bold">£{b.gwp}M</td>
                  <td className={`p-3 font-bold ${b.lossRatio > 70 ? "text-rose-400" : "text-emerald-400"}`}>
                    {b.lossRatio}%
                  </td>
                  <td className="p-3">{b.commission}</td>
                  <td className="p-3 font-bold text-cyan-400">{b.qualityScore}</td>
                  <td className="p-3 text-right">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase border ${
                      b.lossRatio < 60
                        ? "bg-emerald-950 text-emerald-400 border-emerald-800"
                        : "bg-amber-950 text-amber-400 border-amber-800"
                    }`}>
                      {b.lossRatio < 60 ? "HIGHLY PROFITABLE" : "ACCEPTABLE TARGET"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
