import { LossTriangleData, PricingBreakdown, UnderwritingScoreBreakdown } from "../types";

// ----------------------------------------------------
// 1. RATIO CALCULATIONS
// ----------------------------------------------------
export function calculateLossRatio(incurredClaims: number, earnedPremium: number): number {
  if (earnedPremium <= 0) return 0;
  return (incurredClaims / earnedPremium) * 100;
}

export function calculateCombinedRatio(
  lossRatio: number,
  expenseRatio: number
): { combinedRatio: number; status: "PROFITABLE" | "BREAK_EVEN" | "UNPROFITABLE" } {
  const combinedRatio = lossRatio + expenseRatio;
  let status: "PROFITABLE" | "BREAK_EVEN" | "UNPROFITABLE" = "PROFITABLE";
  if (Math.abs(combinedRatio - 100) < 0.1) status = "BREAK_EVEN";
  else if (combinedRatio > 100) status = "UNPROFITABLE";
  return { combinedRatio, status };
}

// ----------------------------------------------------
// 2. CHAIN LADDER RESERVING ENGINE
// ----------------------------------------------------
export function runChainLadderReserving(triangleData: LossTriangleData) {
  const { paidTriangle, devPeriods } = triangleData;
  const n = paidTriangle.length;

  // Calculate link ratios
  const linkRatios: number[] = [];
  for (let j = 0; j < devPeriods.length - 1; j++) {
    let sumCurrent = 0;
    let sumNext = 0;
    for (let i = 0; i < n - j - 1; i++) {
      if (paidTriangle[i][j] > 0 && paidTriangle[i][j + 1] > 0) {
        sumCurrent += paidTriangle[i][j];
        sumNext += paidTriangle[i][j + 1];
      }
    }
    const ratio = sumCurrent > 0 ? sumNext / sumCurrent : 1.0;
    linkRatios.push(Number(ratio.toFixed(4)));
  }

  // Cumulative development factors (CDF)
  const cdf: number[] = new Array(devPeriods.length).fill(1.0);
  for (let j = devPeriods.length - 2; j >= 0; j--) {
    cdf[j] = cdf[j + 1] * linkRatios[j];
  }

  // Project ultimate losses and IBNR
  const ultimateLosses: number[] = [];
  const ibnr: number[] = [];

  for (let i = 0; i < n; i++) {
    const latestDevIndex = n - 1 - i;
    const latestValue = paidTriangle[i][latestDevIndex];
    const cdfFactor = cdf[latestDevIndex];
    const ultimate = Math.round(latestValue * cdfFactor);
    const lineIbnr = Math.max(0, ultimate - latestValue);

    ultimateLosses.push(ultimate);
    ibnr.push(lineIbnr);
  }

  return {
    linkRatios,
    cdf: cdf.map((v) => Number(v.toFixed(3))),
    ultimateLosses,
    ibnr,
    totalIbnr: ibnr.reduce((a, b) => a + b, 0),
    totalUltimate: ultimateLosses.reduce((a, b) => a + b, 0),
  };
}

// ----------------------------------------------------
// 3. BORNHUETTER-FERGUSON RESERVING
// ----------------------------------------------------
export function runBornhuetterFerguson(
  paidTriangle: number[][],
  expectedLosses: number[],
  cdf: number[]
) {
  const n = paidTriangle.length;
  const bfUltimate: number[] = [];
  const bfIbnr: number[] = [];

  for (let i = 0; i < n; i++) {
    const latestDevIndex = n - 1 - i;
    const latestPaid = paidTriangle[i][latestDevIndex];
    const cdfFactor = cdf[latestDevIndex];
    const percentUnreported = Math.max(0, 1 - 1 / cdfFactor);
    const expectedIbnr = Math.round(expectedLosses[i] * percentUnreported);
    const ultimate = latestPaid + expectedIbnr;

    bfIbnr.push(expectedIbnr);
    bfUltimate.push(ultimate);
  }

  return {
    bfIbnr,
    bfUltimate,
    totalBfIbnr: bfIbnr.reduce((a, b) => a + b, 0),
  };
}

// ----------------------------------------------------
// 4. UNDERWRITING SCORE ENGINE
// ----------------------------------------------------
export function computeUnderwritingScore(
  exposure: { sumInsured: number; hazardLevel: number },
  claimsHistory5yrTotal: number,
  financial: { revenue: number; creditRating: string },
  operational: { hasMfa: boolean; riskControlsCount: number },
  industry: { isHazardous: boolean }
): UnderwritingScoreBreakdown {
  const exposureScore = Math.max(20, Math.min(95, 100 - exposure.sumInsured / 10000000));
  const claimsScore = Math.max(15, Math.min(95, 100 - claimsHistory5yrTotal / 100000));
  const financialScore = financial.creditRating.startsWith("A") ? 88 : 65;
  const operationalScore = (operational.hasMfa ? 30 : 10) + operational.riskControlsCount * 15;
  const industryScore = industry.isHazardous ? 50 : 85;
  const geographicScore = 78;
  const riskControlScore = Math.min(95, operationalScore + 20);

  const overallRiskScore = Math.round(
    exposureScore * 0.2 +
      claimsScore * 0.25 +
      financialScore * 0.15 +
      operationalScore * 0.15 +
      industryScore * 0.1 +
      geographicScore * 0.05 +
      riskControlScore * 0.1
  );

  let decisionRecommendation: "AUTO_ACCEPT" | "ACCEPT_WITH_LOAD" | "REFER_TO_SENIOR" | "DECLINE" =
    "AUTO_ACCEPT";

  if (overallRiskScore < 45) decisionRecommendation = "DECLINE";
  else if (overallRiskScore < 65 || industry.isHazardous) decisionRecommendation = "REFER_TO_SENIOR";
  else if (overallRiskScore < 78) decisionRecommendation = "ACCEPT_WITH_LOAD";

  return {
    exposureScore: Math.round(exposureScore),
    claimsScore: Math.round(claimsScore),
    financialScore,
    operationalScore: Math.min(100, Math.round(operationalScore)),
    industryScore,
    geographicScore,
    riskControlScore: Math.min(100, Math.round(riskControlScore)),
    overallRiskScore,
    decisionRecommendation,
  };
}

// ----------------------------------------------------
// 5. PRICING & RATING ENGINE
// ----------------------------------------------------
export function calculateTechnicalAndCommercialPremium(
  sumInsured: number,
  baseRatePct: number,
  riskModifiers: { label: string; factor: number }[],
  territorialFactor: number,
  industryFactor: number,
  claimsFactor: number,
  deductibleAdjustmentPct: number,
  brokerCommissionPct: number,
  expensePct: number,
  reinsuranceCostPct: number,
  profitMarginPct: number,
  capitalCostPct: number
): PricingBreakdown {
  const basePremium = sumInsured * (baseRatePct / 100);

  let cumulativeModifier = 1.0;
  riskModifiers.forEach((m) => {
    cumulativeModifier *= m.factor;
  });

  const adjustedRate =
    basePremium *
    cumulativeModifier *
    territorialFactor *
    industryFactor *
    claimsFactor *
    (1 + deductibleAdjustmentPct / 100);

  const technicalPremium = Math.round(
    adjustedRate * (1 + expensePct / 100 + reinsuranceCostPct / 100 + capitalCostPct / 100)
  );

  const commercialPremium = Math.round(
    technicalPremium * (1 + profitMarginPct / 100)
  );

  const brokerCommissionAmount = Math.round(
    commercialPremium * (brokerCommissionPct / 100)
  );
  const taxesAndFees = Math.round(commercialPremium * 0.08); // 8% IPT tax
  const finalPremium = commercialPremium + taxesAndFees;

  return {
    baseRatePct,
    riskModifiers,
    territorialFactor,
    industryFactor,
    claimsFactor,
    deductibleAdjustmentPct,
    limitAdjustmentPct: 0,
    coverageAdjustmentPct: 0,
    brokerCommissionPct,
    expensePct,
    reinsuranceCostPct,
    profitMarginPct,
    capitalCostPct,
    technicalPremium,
    commercialPremium,
    brokerCommissionAmount,
    taxesAndFees,
    finalPremium,
  };
}

// ----------------------------------------------------
// 6. RAROC & ALM CALCULATIONS
// ----------------------------------------------------
export function calculateRaroc(
  underwritingProfit: number,
  investmentIncome: number,
  expectedLoss: number,
  economicCapital: number
): number {
  if (economicCapital <= 0) return 0;
  const netRiskAdjustedReturn = underwritingProfit + investmentIncome - expectedLoss;
  return Number(((netRiskAdjustedReturn / economicCapital) * 100).toFixed(2));
}

export function runAlmDurationSensitivity(
  assetMarketValue: number,
  assetDuration: number,
  liabilityValue: number,
  liabilityDuration: number,
  rateChangeBps: number // e.g. +100 or -100
) {
  const dy = rateChangeBps / 10000;
  const deltaAssets = -assetMarketValue * assetDuration * dy;
  const deltaLiabilities = -liabilityValue * liabilityDuration * dy;
  const newAssetValue = assetMarketValue + deltaAssets;
  const newLiabilityValue = liabilityValue + deltaLiabilities;
  const netEconomicSurplus = newAssetValue - newLiabilityValue;

  return {
    deltaAssets: Math.round(deltaAssets),
    deltaLiabilities: Math.round(deltaLiabilities),
    newAssetValue: Math.round(newAssetValue),
    newLiabilityValue: Math.round(newLiabilityValue),
    netEconomicSurplus: Math.round(netEconomicSurplus),
  };
}
