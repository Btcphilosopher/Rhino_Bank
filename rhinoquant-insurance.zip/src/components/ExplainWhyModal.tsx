import React, { useState, useEffect } from "react";
import { HelpCircle, X, ArrowUpRight, ShieldCheck, Activity, FileText } from "lucide-react";
import { ExplainWhyResponse, explainMetricWhy } from "../services/gemini";

interface ExplainWhyModalProps {
  isOpen: boolean;
  onClose: () => void;
  metricName: string;
  metricValue: string;
  entityContext?: any;
}

export const ExplainWhyModal: React.FC<ExplainWhyModalProps> = ({
  isOpen,
  onClose,
  metricName,
  metricValue,
  entityContext,
}) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<ExplainWhyResponse | null>(null);

  useEffect(() => {
    if (isOpen && metricName) {
      setLoading(true);
      explainMetricWhy(metricName, metricValue, entityContext).then((res) => {
        setData(res);
        setLoading(false);
      });
    }
  }, [isOpen, metricName, metricValue, entityContext]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-lg shadow-2xl w-full max-w-xl font-mono text-slate-100 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <HelpCircle className="w-5 h-5 text-amber-500" />
            <div>
              <div className="text-[10px] text-amber-400 font-bold uppercase">ANALYTICAL EXPLAINABILITY (REQUIREMENT 65)</div>
              <h3 className="text-sm font-bold text-slate-100">
                WHY IS {metricName.toUpperCase()} = {metricValue}?
              </h3>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {loading ? (
            <div className="py-8 flex flex-col items-center justify-center space-y-3">
              <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-xs text-slate-400">Querying Gemini 3.7 Flash & Ledger Records...</span>
            </div>
          ) : (
            <>
              {/* Executive Summary Explanation */}
              <div className="bg-slate-950 p-3.5 rounded border border-slate-800 text-xs leading-relaxed text-slate-200">
                {data?.explanation}
              </div>

              {/* Primary Drivers Breakdown */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold text-slate-400 uppercase">Primary Metric Drivers</div>
                {data?.drivers.map((drv, idx) => (
                  <div key={idx} className="bg-slate-950/80 p-2.5 rounded border border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-sans">{drv.factor}</span>
                    <span className={`font-bold ${drv.type === "Adverse" ? "text-rose-400" : "text-emerald-400"}`}>
                      {drv.impact} ({drv.type})
                    </span>
                  </div>
                ))}
              </div>

              {/* Citations to Underlying Records */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-[11px] font-bold text-amber-400 uppercase">Cited Canonical Records</div>
                <div className="flex flex-wrap gap-2">
                  {data?.underlyingRecords.map((rec, idx) => (
                    <span key={idx} className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-2.5 py-1 rounded text-xs flex items-center space-x-1 cursor-pointer">
                      <FileText className="w-3 h-3 text-amber-400" />
                      <span>{rec}</span>
                      <ArrowUpRight className="w-3 h-3 text-slate-400" />
                    </span>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-[10px] text-slate-500 text-right">
          Grounded on RhinoQuant Ledger Records & Gemini 3.7 Flash Reasoning
        </div>
      </div>
    </div>
  );
};
