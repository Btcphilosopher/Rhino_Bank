import React from "react";
import { X, Building2, Shield, FileText, Activity, AlertTriangle, Layers, DollarSign, Cpu } from "lucide-react";
import { CustomerAccount, Policy, Claim, Submission, ReinsuranceContract } from "../types";

interface ConnectedEntityDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  accountName: string;
  accountData?: CustomerAccount;
  connectedPolicies: Policy[];
  connectedClaims: Claim[];
  connectedSubmissions: Submission[];
  connectedReinsurance: ReinsuranceContract[];
}

export const ConnectedEntityDrawer: React.FC<ConnectedEntityDrawerProps> = ({
  isOpen,
  onClose,
  accountName,
  accountData,
  connectedPolicies,
  connectedClaims,
  connectedSubmissions,
  connectedReinsurance,
}) => {
  if (!isOpen) return null;

  const totalGwp = connectedPolicies.reduce((sum, p) => sum + p.gwp, 0);
  const totalClaimsPaid = connectedClaims.reduce((sum, c) => sum + c.paidToDate, 0);
  const totalClaimsReserved = connectedClaims.reduce((sum, c) => sum + c.reserveOutstanding, 0);
  const totalIncurred = totalClaimsPaid + totalClaimsReserved;
  const netEarnedPremium = connectedPolicies.reduce((sum, p) => sum + p.nep, 0);
  const lossRatio = netEarnedPremium > 0 ? (totalIncurred / netEarnedPremium) * 100 : 0;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-4xl bg-slate-950 border-l border-slate-800 shadow-2xl text-slate-100 font-mono flex flex-col">
      {/* Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 font-bold text-lg">
            360
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs bg-amber-950 text-amber-400 border border-amber-800 px-2 py-0.5 rounded font-bold">
                CONNECTED LEDGER
              </span>
              <span className="text-slate-400 text-xs">REQUIREMENT 64</span>
            </div>
            <h2 className="text-lg font-bold text-slate-100">{accountName}</h2>
          </div>
        </div>
        <button onClick={onClose} className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Cross-Module Pipeline Workflow Trace */}
      <div className="bg-slate-900/60 p-3 border-b border-slate-800 text-[10px] flex items-center justify-between overflow-x-auto text-slate-300">
        <span className="font-bold text-amber-400">PIPELINE TRACE:</span>
        <span className="text-emerald-400 font-bold">CUSTOMER</span>
        <span>→</span>
        <span className="text-cyan-400 font-bold">RISKS</span>
        <span>→</span>
        <span className="text-blue-400 font-bold">SUBMISSION</span>
        <span>→</span>
        <span className="text-indigo-400 font-bold">POLICY</span>
        <span>→</span>
        <span className="text-purple-400 font-bold">PREMIUM</span>
        <span>→</span>
        <span className="text-pink-400 font-bold">CLAIMS</span>
        <span>→</span>
        <span className="text-rose-400 font-bold">LOSS RATIO ({lossRatio.toFixed(1)}%)</span>
        <span>→</span>
        <span className="text-amber-400 font-bold">REINSURANCE</span>
      </div>

      {/* Content Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* KPI Summary Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Total Written Premium</div>
            <div className="text-base font-bold text-amber-400">£{(totalGwp / 1000000).toFixed(2)}M</div>
          </div>
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Incurred Claims</div>
            <div className="text-base font-bold text-rose-400">£{(totalIncurred / 1000000).toFixed(2)}M</div>
          </div>
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Loss Ratio</div>
            <div className={`text-base font-bold ${lossRatio > 70 ? "text-rose-400" : "text-emerald-400"}`}>
              {lossRatio.toFixed(1)}%
            </div>
          </div>
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Active Policies</div>
            <div className="text-base font-bold text-cyan-400">{connectedPolicies.length}</div>
          </div>
        </div>

        {/* 1. Customer & Risk Objects */}
        <div className="bg-slate-900/80 p-4 rounded border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-400">
            <Building2 className="w-4 h-4" />
            <span>01 / CUSTOMER & CENTRAL RISK OBJECT</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-300">
            <div><span className="text-slate-500">Industry:</span> {accountData?.industry || "Energy & Infrastructure"}</div>
            <div><span className="text-slate-500">Annual Revenue:</span> £{accountData ? (accountData.annualRevenue / 1000000).toFixed(0) : "4,850"}M</div>
            <div><span className="text-slate-500">Credit Rating:</span> {accountData?.creditRating || "A+"}</div>
          </div>
        </div>

        {/* 2. Submissions */}
        <div className="bg-slate-900/80 p-4 rounded border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-cyan-400">
            <FileText className="w-4 h-4" />
            <span>02 / SUBMISSIONS & DOCUMENTS INGESTION</span>
          </div>
          {connectedSubmissions.length > 0 ? (
            connectedSubmissions.map((sub) => (
              <div key={sub.id} className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-200">{sub.id} - {sub.requestedTerms}</div>
                  <div className="text-[10px] text-slate-400">Broker: {sub.brokerName} | Status: <span className="text-amber-400 font-bold">{sub.status}</span></div>
                </div>
                <div className="text-right font-bold text-emerald-400">
                  Target £{(sub.requestedPremium / 1000000).toFixed(2)}M
                </div>
              </div>
            ))
          ) : (
            <div className="text-xs text-slate-500">No active submissions in queue.</div>
          )}
        </div>

        {/* 3. Policies & Premium */}
        <div className="bg-slate-900/80 p-4 rounded border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-indigo-400">
            <Shield className="w-4 h-4" />
            <span>03 / POLICIES & PREMIUM LEDGER</span>
          </div>
          {connectedPolicies.map((pol) => (
            <div key={pol.id} className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-200">{pol.policyNumber} ({pol.lineOfBusiness})</div>
                <div className="text-[10px] text-slate-400">Effective: {pol.effectiveDate} to {pol.expiryDate} | Limit: £{(pol.limit / 1000000).toFixed(0)}M</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-amber-400">GWP: £{(pol.gwp / 1000000).toFixed(2)}M</div>
                <div className="text-[10px] text-slate-400">NEP: £{(pol.nep / 1000000).toFixed(2)}M</div>
              </div>
            </div>
          ))}
        </div>

        {/* 4. Claims & Reserving */}
        <div className="bg-slate-900/80 p-4 rounded border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-pink-400">
            <AlertTriangle className="w-4 h-4" />
            <span>04 / CLAIMS & RESERVES</span>
          </div>
          {connectedClaims.length > 0 ? (
            connectedClaims.map((clm) => (
              <div key={clm.id} className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-200">{clm.claimNumber} - {clm.cause}</div>
                  <div className="text-[10px] text-slate-400">Location: {clm.locationName} | Status: <span className="text-rose-400">{clm.status}</span></div>
                </div>
                <div className="text-right font-bold text-rose-400">
                  Incurred: £{((clm.paidToDate + clm.reserveOutstanding) / 1000000).toFixed(2)}M
                </div>
              </div>
            ))
          ) : (
            <div className="text-xs text-slate-500">No active claims reported for this account.</div>
          )}
        </div>

        {/* 5. Reinsurance & Capital Protection */}
        <div className="bg-slate-900/80 p-4 rounded border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-emerald-400">
            <Layers className="w-4 h-4" />
            <span>05 / REINSURANCE & CAPITAL PROTECTION</span>
          </div>
          {connectedReinsurance.map((r) => (
            <div key={r.id} className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-200">{r.treatyName}</div>
                <div className="text-[10px] text-slate-400">Reinsurer: {r.reinsurerName} ({r.creditRating})</div>
              </div>
              <div className="text-right text-emerald-400 font-bold">
                Recovery: £{(r.recoveriesToDate / 1000000).toFixed(2)}M
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
