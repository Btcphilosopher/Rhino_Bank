import React, { useState, useEffect } from "react";
import { Search, Terminal, ArrowRight, Shield, Layers, Activity, FileText, X } from "lucide-react";

interface CommandBarModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExecuteCommand: (command: string, tabTarget?: string, entityTarget?: string) => void;
}

interface CommandItem {
  command: string;
  category: string;
  description: string;
  tabTarget: string;
  entityTarget?: string;
}

export const CommandBarModal: React.FC<CommandBarModalProps> = ({ isOpen, onClose, onExecuteCommand }) => {
  const [inputQuery, setInputQuery] = useState("");

  const commandPresets: CommandItem[] = [
    { command: "ACME RISK", category: "CONNECTED ENTITY", description: "Open 360-degree connected risk profile for ACME Corp / Aurelia Energy", tabTarget: "UNDERWRITING", entityTarget: "Aurelia Energy Global Plc" },
    { command: "AURELIA ENERGY", category: "CONNECTED ENTITY", description: "360-degree linked insurance ledger for Aurelia Energy", tabTarget: "UNDERWRITING", entityTarget: "Aurelia Energy Global Plc" },
    { command: "YORKSHIRE INFRASTRUCTURE", category: "CONNECTED ENTITY", description: "360-degree linked insurance ledger for Yorkshire Infra", tabTarget: "UNDERWRITING", entityTarget: "Yorkshire Infrastructure Ltd" },
    { command: "PROPERTY PML", category: "CATASTROPHE", description: "View Probable Maximum Loss & AAL curves for Commercial Property", tabTarget: "CATASTROPHE" },
    { command: "UK FLOOD", category: "CATASTROPHE SCENARIO", description: "Simulate UK Flood & Storm Surge catastrophe event losses", tabTarget: "CATASTROPHE" },
    { command: "LOSS TRIANGLE", category: "ACTUARIAL RESERVING", description: "Inspect Paid & Incurred Claims Loss Development Triangles", tabTarget: "CLAIMS" },
    { command: "COMBINED RATIO", category: "PROFITABILITY", description: "Break down Loss Ratio + Expense Ratio combined profitability", tabTarget: "PORTFOLIO" },
    { command: "REINSURANCE TOWER", category: "REINSURANCE", description: "Examine Quota Share, Surplus & Excess of Loss Reinsurance Tower", tabTarget: "REINSURANCE" },
    { command: "CYBER PORTFOLIO", category: "PORTFOLIO SLICE", description: "Analyze Cyber Risk & Ransomware Exposure Portfolio", tabTarget: "PORTFOLIO" },
    { command: "CAPITAL", category: "SOLVENCY II", description: "Review Solvency II & Economic Risk Capital Allocation", tabTarget: "CAPITAL" },
    { command: "NEW SUBMISSION", category: "SUBMISSION INTAKE", description: "Open Intake Workbench to create or ingest a new submission", tabTarget: "SUBMISSIONS" },
  ];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        if (isOpen) onClose();
        else onExecuteCommand("OPEN");
      } else if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose, onExecuteCommand]);

  if (!isOpen) return null;

  const filteredCommands = commandPresets.filter(
    (c) =>
      c.command.toLowerCase().includes(inputQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(inputQuery.toLowerCase()) ||
      c.category.toLowerCase().includes(inputQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-start justify-center pt-20 p-4">
      <div className="bg-slate-900 border border-slate-700/90 rounded-lg shadow-2xl w-full max-w-2xl overflow-hidden font-mono text-slate-100 flex flex-col">
        {/* Terminal Input Bar */}
        <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center space-x-3">
          <Terminal className="w-5 h-5 text-amber-500" />
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Type terminal command (e.g. ACME RISK, PROPERTY PML, LOSS TRIANGLE)..."
            className="flex-1 bg-transparent text-slate-100 placeholder-slate-500 text-sm focus:outline-none"
            autoFocus
          />
          <button onClick={onClose} className="text-slate-500 hover:text-slate-300">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Command List */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-slate-800/50">
          {filteredCommands.length > 0 ? (
            filteredCommands.map((cmd, idx) => (
              <div
                key={idx}
                onClick={() => {
                  onExecuteCommand(cmd.command, cmd.tabTarget, cmd.entityTarget);
                  onClose();
                }}
                className="p-2.5 hover:bg-slate-800/80 rounded cursor-pointer transition-colors flex items-center justify-between group"
              >
                <div className="flex items-start space-x-3">
                  <span className="text-[10px] bg-slate-800 group-hover:bg-amber-950 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded font-bold uppercase mt-0.5">
                    {cmd.category}
                  </span>
                  <div>
                    <div className="font-bold text-xs text-slate-200 group-hover:text-amber-400">
                      {cmd.command}
                    </div>
                    <div className="text-[11px] text-slate-400 font-sans">{cmd.description}</div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-amber-400 transform group-hover:translate-x-1 transition-transform" />
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs font-sans">
              No terminal command matched "{inputQuery}". Try typing <span className="text-amber-400 font-mono">ACME RISK</span> or <span className="text-amber-400 font-mono">PROPERTY PML</span>.
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-950 px-3 py-1.5 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500 font-sans">
          <span>Use <kbd className="bg-slate-800 text-slate-300 px-1 rounded">↑</kbd> <kbd className="bg-slate-800 text-slate-300 px-1 rounded">↓</kbd> to navigate, <kbd className="bg-slate-800 text-slate-300 px-1 rounded">ENTER</kbd> to select</span>
          <span>Press <kbd className="bg-slate-800 text-slate-300 px-1 rounded">ESC</kbd> to exit</span>
        </div>
      </div>
    </div>
  );
};
