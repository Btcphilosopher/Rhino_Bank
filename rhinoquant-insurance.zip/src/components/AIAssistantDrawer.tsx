import React, { useState } from "react";
import { Bot, Send, X, Shield, FileText, ArrowUpRight, Sparkles } from "lucide-react";
import { askUnderwriterAI } from "../services/gemini";

interface AIAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  contextData?: any;
}

interface Message {
  sender: "user" | "ai";
  text: string;
  citations?: { recordId: string; type: string; label: string }[];
  timestamp: string;
}

export const AIAssistantDrawer: React.FC<AIAssistantDrawerProps> = ({ isOpen, onClose, contextData }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: "ai",
      text: "Greetings. I am RhinoQuant Underwriter AI. I inspect canonical insurance ledgers, loss triangles, catastrophe PML models, and underwriting rules. Ask me any analytical question.",
      citations: [{ recordId: "RQ-MASTER-LEDGER", type: "Ledger", label: "Enterprise Operating Terminal" }],
      timestamp: "08:30",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const quickQuestions = [
    "What are the major risks in this submission?",
    "Why is this account being referred?",
    "How has the loss ratio changed over 5 years?",
    "Which assumptions drive the technical premium?",
    "What are our top 3 property catastrophe exposures?",
  ];

  const handleSend = async (queryText?: string) => {
    const q = queryText || input;
    if (!q.trim() || loading) return;

    const userMsg: Message = {
      sender: "user",
      text: q,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInput("");
    setLoading(true);

    const aiRes = await askUnderwriterAI(q, contextData);

    const aiMsg: Message = {
      sender: "ai",
      text: aiRes.answer,
      citations: aiRes.citations,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, aiMsg]);
    setLoading(false);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-lg bg-slate-950 border-l border-slate-800 shadow-2xl text-slate-100 font-mono flex flex-col">
      {/* Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] bg-amber-950 text-amber-400 border border-amber-800 px-1.5 py-0.5 rounded font-bold">
                RHINOQUANT AI
              </span>
              <span className="text-slate-400 text-[10px]">GEMINI 3.7 FLASH</span>
            </div>
            <h2 className="text-sm font-bold text-slate-100">Underwriter AI Assistant</h2>
          </div>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex flex-col ${m.sender === "user" ? "items-end" : "items-start"}`}
          >
            <div
              className={`max-w-[88%] p-3 rounded text-xs leading-relaxed ${
                m.sender === "user"
                  ? "bg-amber-600 text-slate-950 font-semibold"
                  : "bg-slate-900 border border-slate-800 text-slate-200"
              }`}
            >
              <div className="whitespace-pre-wrap">{m.text}</div>

              {/* Record Citations */}
              {m.citations && m.citations.length > 0 && (
                <div className="mt-3 pt-2 border-t border-slate-800 space-y-1">
                  <div className="text-[10px] text-amber-400 font-bold uppercase">CITATIONS</div>
                  <div className="flex flex-wrap gap-1.5">
                    {m.citations.map((c, cIdx) => (
                      <span
                        key={cIdx}
                        className="bg-slate-950 text-slate-300 border border-slate-800 px-2 py-0.5 rounded text-[10px] flex items-center space-x-1"
                      >
                        <FileText className="w-2.5 h-2.5 text-amber-400" />
                        <span>{c.recordId}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <span className="text-[10px] text-slate-500 mt-1">{m.timestamp}</span>
          </div>
        ))}

        {loading && (
          <div className="flex items-center space-x-2 text-xs text-amber-400 bg-slate-900 p-3 rounded border border-slate-800">
            <Sparkles className="w-4 h-4 animate-spin text-amber-400" />
            <span>RhinoQuant AI inspecting canonical records & loss triangles...</span>
          </div>
        )}
      </div>

      {/* Preset Suggestions */}
      <div className="p-2 bg-slate-900/60 border-t border-slate-800 text-[10px] space-y-1">
        <div className="text-slate-400 font-bold uppercase px-1">Institutional Prompts:</div>
        <div className="flex flex-wrap gap-1">
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700/80 text-[10px] text-left transition-colors"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center space-x-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask RhinoQuant Underwriter AI..."
          className="flex-1 bg-slate-950 text-slate-100 text-xs px-3 py-2 rounded border border-slate-800 focus:outline-none focus:border-amber-500"
        />
        <button
          onClick={() => handleSend()}
          disabled={loading}
          className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-3 py-2 rounded text-xs flex items-center space-x-1"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
