import React, { useState, useEffect } from "react";
import {
  Terminal,
  Search,
  Bot,
  Shield,
  Briefcase,
  Activity,
  Layers,
  ChevronDown,
  Bell,
  Cpu,
  Lock,
  Building2,
} from "lucide-react";
import { WorkspaceType } from "../types";
import { eventBus, InsuranceEvent } from "../data/eventBus";
import { SIMULATED_DATA_NOTICE } from "../data/syntheticDataset";

interface HeaderProps {
  currentWorkspace: WorkspaceType;
  onWorkspaceChange: (ws: WorkspaceType) => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenCommandBar: () => void;
  onOpenAIAssistant: () => void;
  selectedTenant: string;
  onTenantChange: (tenant: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentWorkspace,
  onWorkspaceChange,
  activeTab,
  onTabChange,
  onOpenCommandBar,
  onOpenAIAssistant,
  selectedTenant,
  onTenantChange,
}) => {
  const [latestEvent, setLatestEvent] = useState<InsuranceEvent | null>(null);

  useEffect(() => {
    const unsub = eventBus.subscribe((evt) => {
      setLatestEvent(evt);
    });
    const history = eventBus.getHistory();
    if (history.length > 0) setLatestEvent(history[0]);
    return unsub;
  }, []);

  const navTabs = [
    { id: "TERMINAL", label: "01 TERMINAL", icon: Terminal },
    { id: "SUBMISSIONS", label: "02 SUBMISSIONS & DOCS", icon: Layers },
    { id: "UNDERWRITING", label: "03 UNDERWRITING & RISK", icon: Shield },
    { id: "PRICING", label: "04 PRICING & ACTUARIAL", icon: Activity },
    { id: "CLAIMS", label: "05 CLAIMS & RESERVING", icon: Briefcase },
    { id: "CATASTROPHE", label: "06 CAT & EXPOSURE MAP", icon: Cpu },
    { id: "REINSURANCE", label: "07 REINSURANCE & TOWER", icon: Layers },
    { id: "CAPITAL", label: "08 CAPITAL & SOLVENCY", icon: Activity },
    { id: "PORTFOLIO", label: "09 PORTFOLIO ANALYTICS", icon: Briefcase },
    { id: "PRODUCT_BUILDER", label: "10 PRODUCT BUILDER", icon: Cpu },
    { id: "POLICY_ADMIN", label: "11 POLICY & LEDGER", icon: Shield },
    { id: "ERM_SCENARIOS", label: "12 ERM & SCENARIOS", icon: Lock },
  ];

  return (
    <header className="bg-slate-950 border-b border-slate-800 text-slate-100 flex flex-col font-mono text-xs select-none sticky top-0 z-40">
      {/* Top Telemetry & Banner */}
      <div className="bg-slate-900 border-b border-slate-800/80 px-4 py-1 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center space-x-4">
          <span className="flex items-center space-x-1 font-bold text-amber-400 tracking-wider">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
            <span>RHINOQUANT OS v4.8.2</span>
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
            {SIMULATED_DATA_NOTICE}
          </span>
        </div>

        {/* Live Ticker */}
        <div className="hidden lg:flex items-center space-x-2 text-slate-300 max-w-xl truncate">
          <span className="text-cyan-400 font-bold uppercase">LIVE EVENT:</span>
          {latestEvent ? (
            <span className="truncate">
              [{latestEvent.type}] {latestEvent.summary} ({latestEvent.actor})
            </span>
          ) : (
            <span>Event Bus Listening...</span>
          )}
        </div>

        <div className="flex items-center space-x-3 text-slate-400">
          <span className="hidden sm:inline">TENANT:</span>
          <select
            value={selectedTenant}
            onChange={(e) => onTenantChange(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 px-2 py-0.5 rounded text-[11px] focus:outline-none focus:border-amber-500"
          >
            <option value="Syndicate 1910 - Rhino Re Group">Syndicate 1910 - Rhino Re Group</option>
            <option value="Northstar Commercial Insurer">Northstar Commercial Insurer</option>
            <option value="Aurelia Underwriting MGA">Aurelia Underwriting MGA</option>
            <option value="Aon Broking Account">Aon Broking Account</option>
          </select>
          <span className="text-emerald-400 font-mono">LATENCY: 12ms</span>
        </div>
      </div>

      {/* Main Command Header */}
      <div className="px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Brand & Workspace */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => onTabChange("TERMINAL")}>
            <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center font-bold text-slate-950 shadow-md">
              RQ
            </div>
            <div>
              <div className="font-extrabold text-sm tracking-tight text-slate-100 flex items-center space-x-1">
                <span>RHINOQUANT</span>
                <span className="text-amber-500 font-bold">INSURANCE</span>
              </div>
              <div className="text-[10px] text-slate-400">Enterprise Actuarial & Operating Terminal</div>
            </div>
          </div>

          <div className="h-6 w-px bg-slate-800 hidden md:block"></div>

          {/* Workspace Persona Selector */}
          <div className="relative">
            <div className="text-[10px] text-slate-500 font-sans uppercase">Workspace Role</div>
            <div className="flex items-center space-x-1.5 bg-slate-900 hover:bg-slate-850 px-2.5 py-1 rounded border border-slate-700 cursor-pointer text-slate-200 text-xs font-semibold">
              <Building2 className="w-3.5 h-3.5 text-amber-400" />
              <select
                value={currentWorkspace}
                onChange={(e) => onWorkspaceChange(e.target.value as WorkspaceType)}
                className="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
              >
                <option value="UNDERWRITER" className="bg-slate-900 text-slate-200">Underwriter Workbench</option>
                <option value="ACTUARY" className="bg-slate-900 text-slate-200">Actuarial Workstation</option>
                <option value="CLAIMS" className="bg-slate-900 text-slate-200">Claims Workstation</option>
                <option value="CRO" className="bg-slate-900 text-slate-200">CRO Risk Dashboard</option>
                <option value="CFO" className="bg-slate-900 text-slate-200">CFO Capital & Profitability</option>
                <option value="REINSURANCE" className="bg-slate-900 text-slate-200">Reinsurance Manager</option>
                <option value="BROKER" className="bg-slate-900 text-slate-200">Broker Intelligence</option>
                <option value="PORTFOLIO_MANAGER" className="bg-slate-900 text-slate-200">Portfolio Analytics</option>
              </select>
            </div>
          </div>
        </div>

        {/* Center Terminal Command Bar Input Trigger */}
        <div className="flex-1 max-w-xl mx-2">
          <button
            onClick={onOpenCommandBar}
            className="w-full bg-slate-900 hover:bg-slate-850 border border-slate-700/80 hover:border-amber-500/50 rounded px-3 py-1.5 flex items-center justify-between text-slate-400 text-xs transition-colors group"
          >
            <div className="flex items-center space-x-2">
              <Search className="w-3.5 h-3.5 text-amber-500 group-hover:text-amber-400" />
              <span className="text-slate-300 font-mono">
                Type Terminal Command... (e.g. <span className="text-amber-400">ACME RISK</span>, <span className="text-cyan-400">PROPERTY PML</span>, <span className="text-emerald-400">LOSS TRIANGLE</span>)
              </span>
            </div>
            <kbd className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px] font-mono border border-slate-700">
              Ctrl+K
            </kbd>
          </button>
        </div>

        {/* Right Action Trigger Buttons */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onOpenAIAssistant}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-bold px-3 py-1.5 rounded shadow text-xs transition-all"
          >
            <Bot className="w-4 h-4 text-slate-950" />
            <span>RHINO AI ASSISTANT</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Bar */}
      <div className="bg-slate-900/90 px-4 flex items-center space-x-1 overflow-x-auto border-t border-slate-800 scrollbar-none">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`px-3 py-1.5 text-[11px] font-semibold whitespace-nowrap border-b-2 transition-all flex items-center space-x-1.5 ${
                isActive
                  ? "border-amber-500 text-amber-400 bg-slate-800/80"
                  : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? "text-amber-400" : "text-slate-500"}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
