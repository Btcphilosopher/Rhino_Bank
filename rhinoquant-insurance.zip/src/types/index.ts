export type WorkspaceType =
  | "UNDERWRITER"
  | "ACTUARY"
  | "CLAIMS"
  | "CRO"
  | "CFO"
  | "REINSURANCE"
  | "BROKER"
  | "MGA"
  | "PORTFOLIO_MANAGER";

export type LineOfBusiness =
  | "PROPERTY"
  | "CASUALTY"
  | "MARINE"
  | "AVIATION"
  | "ENERGY"
  | "CYBER"
  | "FINANCIAL_LINES"
  | "PROFESSIONAL_INDEMNITY"
  | "D_AND_O"
  | "TRADE_CREDIT"
  | "MOTOR"
  | "HOME"
  | "LIFE"
  | "HEALTH"
  | "REINSURANCE";

export interface CustomerAccount {
  id: string;
  name: string;
  industry: string;
  region: string;
  annualRevenue: number;
  totalAssets: number;
  employeeCount: number;
  creditRating: string;
  riskScore: number;
  activePoliciesCount: number;
  totalGwp: number;
  lossRatio: number;
  createdAt: string;
}

export interface Broker {
  id: string;
  name: string;
  code: string;
  contactEmail: string;
  tier: "PLATINUM" | "GOLD" | "SILVER" | "DIRECT";
  totalGwp: number;
  lossRatio: number;
  retentionRate: number;
  commissionAvg: number;
  hitRate: number;
}

export interface RiskLocation {
  id: string;
  name: string;
  address: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  sumInsured: number;
  deductible: number;
  occupancy: string;
  constructionType: string;
  perilExposures: {
    floodRisk: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
    windstormRisk: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
    quakeRisk: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
    wildfireRisk: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
    hailRisk: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
  };
}

export interface RiskProfile {
  id: string;
  accountId: string;
  insuredName: string;
  lineOfBusiness: LineOfBusiness;
  locations: RiskLocation[];
  annualRevenue: number;
  assetValue: number;
  employeeCount: number;
  operationsDescription: string;
  coverageRequested: string;
  limitRequested: number;
  deductibleRequested: number;
  priorClaims5yrCount: number;
  priorClaims5yrTotal: number;
  riskControls: string[];
  externalRatings: Record<string, string>;
}

export interface DocField {
  field: string;
  value: string;
  confidence: number;
  sourceDoc: string;
  page: number;
  timestamp: string;
  status: "EXTRACTED" | "CONFIRMED" | "MISSING" | "CONFLICTING";
}

export interface DocItem {
  id: string;
  submissionId: string;
  documentName: string;
  documentType: string;
  uploadDate: string;
  status: "EXTRACTED" | "CONFIRMED" | "MISSING" | "CONFLICTING";
  fields: DocField[];
}

export interface Submission {
  id: string;
  riskId: string;
  accountId: string;
  brokerId: string;
  insuredName: string;
  brokerName: string;
  lineOfBusiness: LineOfBusiness;
  status: "DRAFT" | "UNDERWRITING" | "QUOTED" | "BOUND" | "DECLINED" | "REFERRED";
  requestedTerms: string;
  requestedPremium: number;
  technicalPremium: number;
  commercialPremium: number;
  documents: DocItem[];
  createdAt: string;
  underwritingRulesTriggered: string[];
  referralReason?: string;
}

export interface UnderwritingScoreBreakdown {
  exposureScore: number;
  claimsScore: number;
  financialScore: number;
  operationalScore: number;
  industryScore: number;
  geographicScore: number;
  riskControlScore: number;
  overallRiskScore: number;
  decisionRecommendation: "AUTO_ACCEPT" | "ACCEPT_WITH_LOAD" | "REFER_TO_SENIOR" | "DECLINE";
  overrideExplanation?: string;
  isOverridden?: boolean;
}

export interface PricingFactor {
  label: string;
  factor: number;
}

export interface PricingBreakdown {
  baseRatePct: number;
  riskModifiers: PricingFactor[];
  territorialFactor: number;
  industryFactor: number;
  claimsFactor: number;
  deductibleAdjustmentPct: number;
  limitAdjustmentPct: number;
  coverageAdjustmentPct: number;
  brokerCommissionPct: number;
  expensePct: number;
  reinsuranceCostPct: number;
  profitMarginPct: number;
  capitalCostPct: number;
  technicalPremium: number;
  commercialPremium: number;
  brokerCommissionAmount: number;
  taxesAndFees: number;
  finalPremium: number;
}

export interface Policy {
  id: string;
  policyNumber: string;
  submissionId: string;
  accountId: string;
  insuredName: string;
  brokerName: string;
  lineOfBusiness: LineOfBusiness;
  effectiveDate: string;
  expiryDate: string;
  status: "ACTIVE" | "EXPIRED" | "CANCELLED" | "ENDORSED" | "BOUND";
  gwp: number;
  nwp: number;
  nep: number;
  limit: number;
  deductible: number;
  currency: string;
  version: number;
  underwriterName: string;
  documents: string[];
}

export interface Claim {
  id: string;
  claimNumber: string;
  policyId: string;
  accountId: string;
  insuredName: string;
  lineOfBusiness: LineOfBusiness;
  dateOfLoss: string;
  reportedDate: string;
  cause: string;
  locationName: string;
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  triageCategory: "AUTOMATED_EXPRESS" | "STANDARD_ADJUSTER" | "SENIOR_COMPLEX" | "LITIGATION_LEGAL";
  reservePaid: number;
  reserveOutstanding: number;
  paidToDate: number;
  recoveries: number;
  status: "FNOL" | "OPEN" | "TRIAGED" | "UNDER_INVESTIGATION" | "SETTLEMENT" | "CLOSED";
  handlerName: string;
  fraudScore: number;
  fraudSignals: string[];
  description: string;
}

export interface LossTriangleData {
  accidentYears: number[];
  devPeriods: number[]; // 12, 24, 36, 48, 60, 72
  paidTriangle: number[][];
  incurredTriangle: number[][];
  reportedCounts: number[][];
  developmentFactors: number[];
  ultimateLosses: number[];
  ibnr: number[];
}

export interface ReinsuranceContract {
  id: string;
  treatyName: string;
  reinsurerName: string;
  type: "QUOTA_SHARE" | "SURPLUS" | "EXCESS_OF_LOSS" | "STOP_LOSS" | "FACULTATIVE" | "CAT_XOL";
  linesOfBusiness: LineOfBusiness[];
  attachmentPoint: number;
  limit: number;
  quotaSharePct?: number;
  premiumCost: number;
  utilizationPct: number;
  recoveriesToDate: number;
  creditRating: string;
}

export interface PMLPoint {
  returnPeriodYears: number; // 10, 25, 50, 100, 200, 500
  grossPml: number;
  netPml: number;
  aal: number;
}

export interface CatastropheScenario {
  id: string;
  eventName: string;
  peril: "FLOOD" | "WINDSTORM" | "EARTHQUAKE" | "WILDFIRE" | "HAIL" | "STORM_SURGE";
  region: string;
  returnPeriodYears: number;
  estimatedGrossLoss: number;
  reinsuranceRecovery: number;
  netLoss: number;
  impactedLocationsCount: number;
}

export interface CapitalAllocation {
  lineOfBusiness: LineOfBusiness;
  requiredCapital: number;
  allocatedAssets: number;
  underwritingProfit: number;
  investmentIncome: number;
  rarocPct: number;
}

export interface MLModelRegistryEntry {
  id: string;
  modelName: string;
  version: string;
  targetVariable: string;
  trainingDatasetVersion: string;
  features: string[];
  metrics: {
    precision?: number;
    recall?: number;
    rocAuc?: number;
    mae?: number;
    rmse?: number;
  };
  approvalStatus: "PRODUCTION" | "STAGING" | "RETIRED";
  deploymentDate: string;
  lastTrainedDate: string;
}

export interface RatingRule {
  id: string;
  name: string;
  lineOfBusiness: LineOfBusiness;
  conditionExpr: string;
  multiplier: number;
  version: number;
  author: string;
  updatedAt: string;
  isActive: boolean;
}

export interface FinancialLedgerEntry {
  id: string;
  date: string;
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  policyId?: string;
  claimId?: string;
  description: string;
  user: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  objectType: string;
  objectId: string;
  oldValue?: string;
  newValue?: string;
  reason?: string;
  ipAddress: string;
}

export interface InvestmentAsset {
  id: string;
  assetName: string;
  category: "GOVT_BONDS" | "CORP_BONDS" | "EQUITIES" | "PRIVATE_CREDIT" | "REAL_ESTATE" | "CASH_EQUIVALENTS";
  marketValue: number;
  durationYears: number;
  yieldPct: number;
  creditRating: string;
  liquidityTier: "T1_IMMEDIATE" | "T2_DAYS" | "T3_ILLIQUID";
}

export interface ProductSchema {
  id: string;
  productName: string;
  lineOfBusiness: LineOfBusiness;
  coverages: string[];
  maxLimit: number;
  minDeductible: number;
  requiredQuestions: string[];
  baseRateFormula: string;
  version: string;
  status: "ACTIVE" | "DRAFT" | "ARCHIVED";
}
