package com.example

import com.example.rhinooilspot.domain.engine.*
import com.example.rhinooilspot.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class RhinoOilMarketEngineTest {

    @Test
    fun testAssayBlending() {
        val brent = AssayEngine.getGradeById("BRENT")
        val wti = AssayEngine.getGradeById("WTI_MIDLAND")
        assertNotNull(brent)
        assertNotNull(wti)

        val diet = listOf(
            CrudeBlendComponent(brent!!, 0.5),
            CrudeBlendComponent(wti!!, 0.5)
        )
        val result = AssayEngine.blendCrudes(diet)

        // Blended API should be between 38.0 and 41.2
        assertTrue(result.blendedApi in 38.0..41.5)
        // Blended Sulfur should be between 0.20 and 0.40
        assertTrue(result.blendedSulfurWtPct in 0.20..0.40)
    }

    @Test
    fun testPhysicalDifferentialCalculation() {
        val forties = AssayEngine.getGradeById("FORTIES")
        assertNotNull(forties)

        val (diff, trace) = DifferentialEngine.calculateIndicativeDifferential(
            grade = forties!!,
            benchmarkSpot = 78.42
        )

        assertNotNull(trace)
        assertEquals("Dated Brent", trace.baseBenchmark)
        assertTrue(trace.steps.isNotEmpty())
        assertTrue(diff in -2.0..2.0)
    }

    @Test
    fun testRefineryEconomics() {
        val ref = RefineryEconomicsEngine.SAMPLE_REFINERIES.first()
        val result = RefineryEconomicsEngine.evaluateRefineryRun(ref, 78.42)

        assertTrue(result.grossRefineryMarginPerBbl > 0.0)
        assertTrue(result.netRefineryMarginPerBbl > 0.0)
        assertTrue(result.dailyNetMarginUsd > 100_000.0)
    }

    @Test
    fun testStorageCarryArbitrage() {
        val terminal = HubAndBalanceEngine.STORAGE_TERMINALS.first()
        val result = StorageCarryEngine.calculateStorageArbitrage(terminal, 78.42, 79.50, 6)

        assertEquals(6, result.monthsDuration)
        assertTrue(result.totalCostOfCarry > 0.0)
    }

    @Test
    fun testVoyageEconomics() {
        val forties = AssayEngine.getGradeById("FORTIES")!!
        val houndPoint = FreightAndVoyageEngine.PORTS_DATABASE.first { it.id == "PORT_HOUND_POINT" }
        val rotterdam = FreightAndVoyageEngine.PORTS_DATABASE.first { it.id == "PORT_ROTTERDAM" }

        val calc = FreightAndVoyageEngine.calculateVoyageEconomics(
            cargoSizeBbl = 600_000L,
            grade = forties,
            originPort = houndPoint,
            destinationPort = rotterdam,
            vesselClass = VesselClass.AFRAMAX
        )

        assertTrue(calc.freightCostPerBbl > 0.0)
        assertTrue(calc.totalVoyageCostUsd > 10_000.0)
        assertTrue(calc.indicativeNetback > 0.0)
    }
}
