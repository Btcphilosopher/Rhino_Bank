package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.engine.StorageCarryEngine
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.components.ProvenanceBadge
import com.example.rhinooilspot.ui.theme.*

@Composable
fun StorageHubsScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val hubBalances by viewModel.hubBalances.collectAsState()
    val storageTerminals by viewModel.storageTerminals.collectAsState()
    val forwardCurves by viewModel.forwardCurves.collectAsState()
    val benchmarks by viewModel.benchmarks.collectAsState()

    val brent = benchmarks.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Global Storage Hub Balances
        item {
            Text(
                text = "GLOBAL PHYSICAL STORAGE HUBS & INVENTORY BALANCES",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        items(hubBalances) { hub ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hub_card_${hub.hubId}"),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = hub.hubName,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                        )
                        ProvenanceBadge(hub.provenance)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Commercial: ${hub.commercialInventoryMbbl} mbbl (${String.format("%.1f", hub.utilizationPct)}% Cap)",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermCyan, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Cover: ${hub.daysOfDemandCover} days",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermEmeraldBright, fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { (hub.utilizationPct / 100f).toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (hub.utilizationPct > 80) TermCrimsonBright else TermGold,
                        trackColor = TermBorder
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Floating Storage: ${hub.floatingStorageMbbl} mbbl • Strategic SPR: ${hub.strategicInventoryMbbl} mbbl",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                        )
                        Text(
                            text = "In/Out: ${hub.inboundFlowKbpd.toInt()} / ${hub.outboundFlowKbpd.toInt()} kb/d",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                        )
                    }
                }
            }
        }

        // Section 2: Storage Terminals & Cost of Carry Arbitrage
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STORAGE TERMINAL RATES & CARRY ARBITRAGE",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
                )
                Text(
                    text = "TAP TO INSPECT CARRY ARB",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                )
            }
        }

        items(storageTerminals) { term ->
            val brentM6 = forwardCurves["BRENT"]?.points?.find { it.monthOffset == 6 }?.price ?: 79.82
            val carryCalc = remember(term, brent, brentM6) {
                StorageCarryEngine.calculateStorageArbitrage(term, brent, brentM6, 6)
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.inspectStorageCarry(term) }
                    .testTag("storage_terminal_${term.id}"),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.3f)) {
                        Text(
                            text = term.name,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                        )
                        Text(
                            text = "${term.hubName} • Cap: ${term.totalCapacityMbbl} mbbl (${String.format("%.1f", term.utilizationPct)}% full)",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                        )
                        Text(
                            text = "Tank Rent: $${term.tankMonthlyRentalUsdPerBbl}/bbl/mo • Pump Fee: $${term.pumpInOutCostUsdPerBbl}/bbl",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "M6 Carry Profit",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                        )
                        Text(
                            text = "${if (carryCalc.netArbitrageProfitPerBbl >= 0) "+" else ""}${String.format("%.2f", carryCalc.netArbitrageProfitPerBbl)} $/bbl",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = if (carryCalc.isArbitrageFeasible) TermEmeraldBright else TermCrimsonBright,
                                fontSize = 16.sp
                            )
                        )
                        Text(
                            text = if (carryCalc.isArbitrageFeasible) "ARB OPEN (${String.format("%.1f", carryCalc.annualisedReturnPct)}% p.a.)" else "NO CARRY ARB (BACKWARDATED)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (carryCalc.isArbitrageFeasible) TermEmeraldBright else TermDimSlate,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
