package com.example.rhinooilspot.domain.model

data class PipelineFlow(
    val pipelineName: String,
    val origin: String,
    val destination: String,
    val capacityKbpd: Double,
    val currentFlowKbpd: Double,
    val tariffUsdPerBbl: Double
) {
    val utilizationPct: Double get() = (currentFlowKbpd / capacityKbpd) * 100.0
}

data class StorageTerminal(
    val id: String,
    val name: String,
    val hubName: String,
    val region: Region,
    val totalCapacityMbbl: Double,
    val workingInventoryMbbl: Double,
    val tankMonthlyRentalUsdPerBbl: Double = 0.45,
    val pumpInOutCostUsdPerBbl: Double = 0.08,
    val lossAndDegradationPctPerMo: Double = 0.05
) {
    val utilizationPct: Double get() = (workingInventoryMbbl / totalCapacityMbbl) * 100.0
    val availableSpaceMbbl: Double get() = totalCapacityMbbl - workingInventoryMbbl
}

data class HubBalance(
    val hubId: String,
    val hubName: String,
    val location: String,
    val region: Region,
    val commercialInventoryMbbl: Double,
    val strategicInventoryMbbl: Double,
    val floatingStorageMbbl: Double,
    val refineryStorageMbbl: Double,
    val totalCapacityMbbl: Double,
    val weeklyChangeMbbl: Double,
    val daysOfDemandCover: Double,
    val inboundFlowKbpd: Double,
    val outboundFlowKbpd: Double,
    val pipelines: List<PipelineFlow>,
    val provenance: PriceProvenance
) {
    val totalInventoryMbbl: Double get() = commercialInventoryMbbl + strategicInventoryMbbl + floatingStorageMbbl + refineryStorageMbbl
    val utilizationPct: Double get() = (totalInventoryMbbl / totalCapacityMbbl) * 100.0
}

data class StorageCarryCalculation(
    val terminalName: String,
    val spotPrice: Double,
    val forwardPrice: Double,
    val monthsDuration: Int,
    val forwardSpread: Double,              // forwardPrice - spotPrice
    val totalTankRentalCost: Double,        // $/bbl over period
    val financingCostUsd: Double,           // SOFR + spread rate * spot * time
    val throughputAndPumpFees: Double,
    val insuranceAndLossCost: Double,
    val totalCostOfCarry: Double,           // sum of costs
    val netArbitrageProfitPerBbl: Double,   // forwardSpread - totalCostOfCarry
    val annualisedReturnPct: Double,
    val isArbitrageFeasible: Boolean,
    val provenance: PriceProvenance
)
