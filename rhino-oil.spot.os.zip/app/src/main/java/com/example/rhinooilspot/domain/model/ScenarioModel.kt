package com.example.rhinooilspot.domain.model

data class ScenarioImpact(
    val datedBrentShiftUsd: Double,
    val wtiShiftUsd: Double,
    val dubaiShiftUsd: Double,
    val freightRateShiftPct: Double,
    val dieselCrackShiftUsd: Double,
    val gasolineCrackShiftUsd: Double,
    val refiningMarginShiftUsd: Double,
    val regionalInventoryChangePct: Double,
    val narrative: String
)

data class MarketScenario(
    val id: String,
    val title: String,
    val category: String, // "GEOPOLITICAL", "SUPPLY_OUTAGE", "WEATHER", "DEMAND_SURGE"
    val description: String,
    val productionImpactKbpd: Double, // negative for outage, positive for surge
    val durationDays: Int,
    val affectedRegion: Region,
    val defaultImpact: ScenarioImpact
)
