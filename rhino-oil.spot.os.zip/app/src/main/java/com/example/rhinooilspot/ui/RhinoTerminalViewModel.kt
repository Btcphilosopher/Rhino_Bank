package com.example.rhinooilspot.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.rhinooilspot.data.MarketNewsItem
import com.example.rhinooilspot.data.MarketRepository
import com.example.rhinooilspot.data.OilMarketSimulator
import com.example.rhinooilspot.domain.engine.*
import com.example.rhinooilspot.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ScreenTab(val title: String, val shortCode: String) {
    OIL_NOW("1. OIL NOW", "ALT+1"),
    BRENT_COMPLEX("2. BRENT COMPLEX", "ALT+2"),
    WTI_CUSHING("3. WTI / CUSHING", "ALT+3"),
    CARGO_BOARD("4. CARGO BOARD", "ALT+4"),
    FREIGHT_VOYAGES("5. FREIGHT & VOYAGE", "ALT+5"),
    REFINERY_CRACKS("6. REFINERY & CRACKS", "ALT+6"),
    STORAGE_HUBS("7. STORAGE & HUBS", "ALT+7"),
    CRUDE_SLATE_ARB("8. SLATE & ARB", "ALT+8"),
    SUPPLY_SHOCKS("9. SUPPLY SHOCKS", "ALT+9"),
    RISK_PNL("10. RISK & P&L", "ALT+0")
}

data class TerminalUiState(
    val currentTab: ScreenTab = ScreenTab.OIL_NOW,
    val selectedCurrency: Currency = Currency.USD,
    val selectedUnit: UnitType = UnitType.USD_PER_BBL,
    val isCommandPaletteOpen: Boolean = false,
    val activeCalculationTrace: CalculationTrace? = null,
    val selectedCrudeForInspection: CrudeGrade? = null,
    val selectedCargoForInspection: Cargo? = null,
    val selectedRefinery: Refinery? = null,
    val selectedHub: HubBalance? = null,
    val selectedPort: Port? = null,
    val activeFilterRegion: Region? = null
)

class RhinoTerminalViewModel(
    private val repository: MarketRepository = MarketRepository()
) : ViewModel() {

    private val simulator = OilMarketSimulator(repository, viewModelScope)

    private val _uiState = MutableStateFlow(TerminalUiState())
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    val benchmarks: StateFlow<List<BenchmarkPrice>> = repository.benchmarks
    val cargoes: StateFlow<List<Cargo>> = repository.cargoes
    val orderBooks: StateFlow<Map<String, PhysicalOrderBook>> = repository.orderBooks
    val vessels: StateFlow<List<Vessel>> = repository.vessels
    val forwardCurves: StateFlow<Map<String, ForwardCurve>> = repository.forwardCurves
    val refineries: StateFlow<List<Refinery>> = repository.refineries
    val hubBalances: StateFlow<List<HubBalance>> = repository.hubBalances
    val storageTerminals: StateFlow<List<StorageTerminal>> = repository.storageTerminals
    val crackSpreads: StateFlow<List<CrackSpread>> = repository.crackSpreads
    val productPrices: StateFlow<List<ProductPrice>> = repository.productPrices
    val activeScenario: StateFlow<MarketScenario?> = repository.activeScenario
    val positions: StateFlow<List<PhysicalPosition>> = repository.positions
    val newsStream: StateFlow<List<MarketNewsItem>> = repository.newsStream

    init {
        simulator.start()
        // Set initial selected refinery
        val defaultRef = refineries.value.firstOrNull()
        _uiState.update { it.copy(selectedRefinery = defaultRef) }
    }

    override fun onCleared() {
        super.onCleared()
        simulator.stop()
    }

    fun selectTab(tab: ScreenTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun setCurrency(currency: Currency) {
        _uiState.update { it.copy(selectedCurrency = currency) }
    }

    fun setUnit(unit: UnitType) {
        _uiState.update { it.copy(selectedUnit = unit) }
    }

    fun openCommandPalette() {
        _uiState.update { it.copy(isCommandPaletteOpen = true) }
    }

    fun closeCommandPalette() {
        _uiState.update { it.copy(isCommandPaletteOpen = false) }
    }

    fun executeCommand(command: String) {
        closeCommandPalette()
        val cmd = command.trim().uppercase()
        when {
            cmd.contains("BRENT") && cmd.contains("COMPLEX") -> selectTab(ScreenTab.BRENT_COMPLEX)
            cmd.contains("BRENT") -> selectTab(ScreenTab.BRENT_COMPLEX)
            cmd.contains("WTI") || cmd.contains("CUSHING") -> selectTab(ScreenTab.WTI_CUSHING)
            cmd.contains("CARGO") -> selectTab(ScreenTab.CARGO_BOARD)
            cmd.contains("FREIGHT") || cmd.contains("VOYAGE") -> selectTab(ScreenTab.FREIGHT_VOYAGES)
            cmd.contains("REFINERY") || cmd.contains("CRACK") -> selectTab(ScreenTab.REFINERY_CRACKS)
            cmd.contains("STORAGE") || cmd.contains("HUB") || cmd.contains("CURVE") -> selectTab(ScreenTab.STORAGE_HUBS)
            cmd.contains("SLATE") || cmd.contains("ARB") || cmd.contains("OPTIM") -> selectTab(ScreenTab.CRUDE_SLATE_ARB)
            cmd.contains("SHOCK") || cmd.contains("SCENARIO") -> selectTab(ScreenTab.SUPPLY_SHOCKS)
            cmd.contains("RISK") || cmd.contains("PNL") || cmd.contains("POSITION") -> selectTab(ScreenTab.RISK_PNL)
            else -> selectTab(ScreenTab.OIL_NOW)
        }
    }

    fun openCalculationTrace(trace: CalculationTrace) {
        _uiState.update { it.copy(activeCalculationTrace = trace) }
    }

    fun closeCalculationTrace() {
        _uiState.update { it.copy(activeCalculationTrace = null) }
    }

    fun inspectCrudeDifferential(grade: CrudeGrade) {
        val brent = benchmarks.value.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
        val (_, trace) = DifferentialEngine.calculateIndicativeDifferential(grade, brent)
        _uiState.update { it.copy(selectedCrudeForInspection = grade, activeCalculationTrace = trace) }
    }

    fun inspectCargoValuation(cargo: Cargo) {
        val brent = benchmarks.value.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
        val (_, trace) = DifferentialEngine.calculateIndicativeDifferential(cargo.grade, brent)
        _uiState.update { it.copy(selectedCargoForInspection = cargo, activeCalculationTrace = trace) }
    }

    fun inspectRefineryMargin(refinery: Refinery) {
        val brent = benchmarks.value.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
        val runResult = RefineryEconomicsEngine.evaluateRefineryRun(refinery, brent)

        val trace = CalculationTrace(
            title = "${refinery.name} Margin Breakdown",
            itemIdentifier = refinery.id,
            category = "REFINERY_MARGIN",
            baseBenchmark = "Dated Brent",
            baseBenchmarkPrice = brent,
            finalCalculatedValue = runResult.netRefineryMarginPerBbl,
            finalUnit = "$/bbl",
            steps = listOf(
                CalculationStep("Total Gross Product Revenue", "∑(Yield_i × Price_i)", "Assays cut market value", runResult.totalProductRevenuePerBbl, "Gross value of refined fuel cuts per barrel"),
                CalculationStep("Feedstock Delivered Crude Cost", "-FeedstockCost", "Dated Brent & grade differentials", -runResult.crudeFeedstockCostPerBbl, "Purchase price and delivery logistics of crude slate"),
                CalculationStep("Gross Refinery Margin (GRM)", "Revenue - Feedstock", "Product minus crude delta", runResult.grossRefineryMarginPerBbl, "Spread before operational overhead"),
                CalculationStep("Variable Utility & Catalyst OpEx", "-OpEx", "${refinery.type.label} (${refinery.type.opexPerBbl} $/bbl base + desulfurization)", -runResult.variableOpexPerBbl, "Power, natural gas, steam, hydrogen, and catalyst cost"),
                CalculationStep("Net Cash Refinery Margin", "GRM - OpEx", "Final cash profit per barrel", runResult.netRefineryMarginPerBbl, "Daily cash generation: $${String.format("%,.0f", runResult.dailyNetMarginUsd)}/day")
            ),
            methodology = "Linear Assay Distillation Yields & Cracking Upgrade v3.7",
            calculationTimestamp = "2026-09-23 12:55 BST",
            dataProvenance = runResult.provenance
        )
        _uiState.update { it.copy(selectedRefinery = refinery, activeCalculationTrace = trace) }
    }

    fun inspectStorageCarry(terminal: StorageTerminal) {
        val brent = benchmarks.value.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
        val brentM6 = forwardCurves.value["BRENT"]?.points?.find { it.monthOffset == 6 }?.price ?: 79.82
        val carryResult = StorageCarryEngine.calculateStorageArbitrage(terminal, brent, brentM6, 6)

        val trace = CalculationTrace(
            title = "${terminal.name} Storage Economics",
            itemIdentifier = terminal.id,
            category = "STORAGE_CARRY",
            baseBenchmark = "Dated Brent Spot",
            baseBenchmarkPrice = brent,
            finalCalculatedValue = carryResult.netArbitrageProfitPerBbl,
            finalUnit = "$/bbl",
            steps = listOf(
                CalculationStep("Spot Entry Price", "Spot", "$${carryResult.spotPrice}/bbl", carryResult.spotPrice, "Prompt physical crude purchase"),
                CalculationStep("Forward M6 Curve Reference", "Forward_M6", "$${carryResult.forwardPrice}/bbl", carryResult.forwardPrice, "ICE Brent 6-Month forward hedge price"),
                CalculationStep("Forward Spread (M6 - Spot)", "F - S", "$${String.format("%.2f", carryResult.forwardSpread)}/bbl", carryResult.forwardSpread, "Gross forward curve price differential"),
                CalculationStep("Tank Rental (6 Months)", "-Rent", "$${terminal.tankMonthlyRentalUsdPerBbl}/bbl/mo × 6 mo", -carryResult.totalTankRentalCost, "Dedicated commercial crude tank lease"),
                CalculationStep("Financing Working Capital", "-SOFR", "5.25% SOFR + 1.75% spread", -carryResult.financingCostUsd, "Cost of debt capital tied up in inventory"),
                CalculationStep("Throughput Pump Fees & Loss", "-Pump+Loss", "In/Out fees + 0.05%/mo loss", -(carryResult.throughputAndPumpFees + carryResult.insuranceAndLossCost), "Terminal handling and volatile vapor loss"),
                CalculationStep("Net Arbitrage Profit / Carry Spread", "Spread - CarryCost", "Arbitrage feasibility indicator", carryResult.netArbitrageProfitPerBbl, "Annualised Return: ${String.format("%.1f", carryResult.annualisedReturnPct)}%")
            ),
            methodology = "Full Cost-of-Carry Arbitrage Model v3.7",
            calculationTimestamp = "2026-09-23 12:55 BST",
            dataProvenance = carryResult.provenance
        )
        _uiState.update { it.copy(activeCalculationTrace = trace) }
    }

    fun applyScenario(scenario: MarketScenario?) {
        repository.applyScenario(scenario)
    }

    fun setFilterRegion(region: Region?) {
        _uiState.update { it.copy(activeFilterRegion = region) }
    }

    fun selectRefinery(refinery: Refinery) {
        _uiState.update { it.copy(selectedRefinery = refinery) }
    }

    fun selectHub(hub: HubBalance) {
        _uiState.update { it.copy(selectedHub = hub) }
    }

    fun formatPrice(valueUsd: Double): String {
        val curr = _uiState.value.selectedCurrency
        val converted = valueUsd * curr.rateToUsd
        return "${curr.symbol}${String.format("%.2f", converted)}"
    }
}
