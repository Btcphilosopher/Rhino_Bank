package com.example.rhinooilspot.domain.engine

import com.example.rhinooilspot.domain.model.*

object RefineryEconomicsEngine {

    val DEFAULT_PRODUCT_PRICES: List<ProductPrice> by lazy {
        listOf(
            ProductPrice(
                id = "PROD_GASOLINE",
                name = "Eurobob Non-Oxy Gasoline 10ppm",
                code = "GASOLINE",
                spotPricePerBbl = 91.80,
                change = 0.45,
                region = Region.NORTH_SEA,
                densityKgPerL = 0.745,
                provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "Platts / Argus", "12:50 BST")
            ),
            ProductPrice(
                id = "PROD_DIESEL",
                name = "Ultra-Low Sulfur Diesel (ULSD 10ppm)",
                code = "DIESEL",
                spotPricePerBbl = 97.40,
                change = 0.85,
                region = Region.NORTH_SEA,
                densityKgPerL = 0.835,
                provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "Platts / ICE", "12:50 BST")
            ),
            ProductPrice(
                id = "PROD_JET",
                name = "Jet A-1 Aviation Fuel",
                code = "JET_KERO",
                spotPricePerBbl = 95.10,
                change = 0.60,
                region = Region.NORTH_SEA,
                densityKgPerL = 0.795,
                provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "Platts Cargoes", "12:50 BST")
            ),
            ProductPrice(
                id = "PROD_NAPHTHA",
                name = "Open-Spec Naphtha",
                code = "NAPHTHA",
                spotPricePerBbl = 69.20,
                change = -0.30,
                region = Region.NORTH_SEA,
                densityKgPerL = 0.710,
                provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "Argus Petrochemical", "12:50 BST")
            ),
            ProductPrice(
                id = "PROD_VLSFO",
                name = "Very Low Sulfur Fuel Oil 0.5% S",
                code = "VLSFO",
                spotPricePerBbl = 63.80,
                change = -0.15,
                region = Region.NORTH_SEA,
                densityKgPerL = 0.940,
                provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "Bunker Market", "12:50 BST")
            ),
            ProductPrice(
                id = "PROD_HSFO",
                name = "High Sulfur Fuel Oil 3.5% S",
                code = "HSFO",
                spotPricePerBbl = 52.40,
                change = -0.55,
                region = Region.NORTH_SEA,
                densityKgPerL = 0.985,
                provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "Bunkerwire", "12:50 BST")
            ),
            ProductPrice(
                id = "PROD_LPG",
                name = "LPG / Propane-Butane Mix",
                code = "LPG",
                spotPricePerBbl = 46.50,
                change = 0.10,
                region = Region.NORTH_SEA,
                densityKgPerL = 0.540,
                provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "Gas Market", "12:50 BST")
            )
        )
    }

    fun calculateCrackSpreads(benchmarkSpot: Double): List<CrackSpread> {
        val gasoline = DEFAULT_PRODUCT_PRICES.find { it.code == "GASOLINE" }?.spotPricePerBbl ?: 91.80
        val diesel = DEFAULT_PRODUCT_PRICES.find { it.code == "DIESEL" }?.spotPricePerBbl ?: 97.40
        val jet = DEFAULT_PRODUCT_PRICES.find { it.code == "JET_KERO" }?.spotPricePerBbl ?: 95.10
        val fuelOil = DEFAULT_PRODUCT_PRICES.find { it.code == "VLSFO" }?.spotPricePerBbl ?: 63.80

        val gasoline1to1 = gasoline - benchmarkSpot
        val diesel1to1 = diesel - benchmarkSpot
        val jet1to1 = jet - benchmarkSpot
        val fuelOil1to1 = fuelOil - benchmarkSpot
        // Standard 3:2:1 Refinery Crack: (2 * Gasoline + 1 * Diesel - 3 * Crude) / 3
        val crack321 = ((2.0 * gasoline + 1.0 * diesel) - (3.0 * benchmarkSpot)) / 3.0

        val prov = PriceProvenance(ProvenanceStatus.PUBLISHED, "Rhino Crack Engine", "12:55 BST")

        return listOf(
            CrackSpread("3:2:1 Complex Refinery Crack", "3:2:1", "Gasoline (2) + Diesel (1) vs Crude (3)", "Dated Brent", "3:2:1", crack321, 0.58, prov),
            CrackSpread("1:1 ULSD Diesel Crack", "DIESEL", "ULSD 10ppm vs Dated Brent", "Dated Brent", "1:1", diesel1to1, 0.54, prov),
            CrackSpread("1:1 Gasoline Crack", "GASOLINE", "Eurobob Non-Oxy vs Dated Brent", "Dated Brent", "1:1", gasoline1to1, 0.14, prov),
            CrackSpread("1:1 Jet Fuel Crack", "JET_KERO", "Jet A-1 vs Dated Brent", "Dated Brent", "1:1", jet1to1, 0.29, prov),
            CrackSpread("1:1 VLSFO Fuel Oil Crack", "VLSFO", "VLSFO 0.5% vs Dated Brent", "Dated Brent", "1:1", fuelOil1to1, -0.46, prov)
        )
    }

    fun evaluateRefineryRun(
        refinery: Refinery,
        crudeDeliveredPricePerBbl: Double,
        activeProductPrices: List<ProductPrice> = DEFAULT_PRODUCT_PRICES
    ): RefineryRunResult {
        val blend = AssayEngine.blendCrudes(refinery.activeCrudeDiet)
        val yields = blend.blendedYields

        val gasPrice = activeProductPrices.find { it.code == "GASOLINE" }?.spotPricePerBbl ?: 91.80
        val dslPrice = activeProductPrices.find { it.code == "DIESEL" }?.spotPricePerBbl ?: 97.40
        val jetPrice = activeProductPrices.find { it.code == "JET_KERO" }?.spotPricePerBbl ?: 95.10
        val naphPrice = activeProductPrices.find { it.code == "NAPHTHA" }?.spotPricePerBbl ?: 69.20
        val vlsfoPrice = activeProductPrices.find { it.code == "VLSFO" }?.spotPricePerBbl ?: 63.80
        val hsfoPrice = activeProductPrices.find { it.code == "HSFO" }?.spotPricePerBbl ?: 52.40
        val lpgPrice = activeProductPrices.find { it.code == "LPG" }?.spotPricePerBbl ?: 46.50

        // Upgrade conversion factors depending on Refinery Complexity
        val (gasYieldPct, dslYieldPct, resYieldPct) = when (refinery.type) {
            RefineryType.HYDROSKIMMING -> {
                // Low conversion: more fuel oil / naphtha, minimal upgrade
                Triple(yields.gasolinePct * 0.9, yields.dieselGasoilPct * 0.95, yields.residuePct + (yields.vgoPct * 0.6))
            }
            RefineryType.MEDIUM_CONVERSION -> {
                // FCC upgrades VGO into Gasoline
                val upgradedGas = yields.gasolinePct + (yields.vgoPct * 0.55)
                val upgradedDsl = yields.dieselGasoilPct + (yields.vgoPct * 0.25)
                Triple(upgradedGas, upgradedDsl, yields.residuePct * 0.85)
            }
            RefineryType.COMPLEX_DEEP -> {
                // Hydrocracker + Coker destroys heavy residue into high-value diesel & gasoline
                val upgradedGas = yields.gasolinePct + (yields.vgoPct * 0.40) + (yields.residuePct * 0.30)
                val upgradedDsl = yields.dieselGasoilPct + (yields.vgoPct * 0.50) + (yields.residuePct * 0.45)
                Triple(upgradedGas, upgradedDsl, yields.residuePct * 0.15)
            }
        }

        val outputYields = listOf(
            ProductOutputYield(activeProductPrices.first { it.code == "LPG" }, yields.lpgPct, (refinery.throughputBpd * yields.lpgPct / 100.0).toLong(), lpgPrice, (yields.lpgPct / 100.0) * lpgPrice),
            ProductOutputYield(activeProductPrices.first { it.code == "NAPHTHA" }, yields.naphthaPct, (refinery.throughputBpd * yields.naphthaPct / 100.0).toLong(), naphPrice, (yields.naphthaPct / 100.0) * naphPrice),
            ProductOutputYield(activeProductPrices.first { it.code == "GASOLINE" }, gasYieldPct, (refinery.throughputBpd * gasYieldPct / 100.0).toLong(), gasPrice, (gasYieldPct / 100.0) * gasPrice),
            ProductOutputYield(activeProductPrices.first { it.code == "JET_KERO" }, yields.jetKeroPct, (refinery.throughputBpd * yields.jetKeroPct / 100.0).toLong(), jetPrice, (yields.jetKeroPct / 100.0) * jetPrice),
            ProductOutputYield(activeProductPrices.first { it.code == "DIESEL" }, dslYieldPct, (refinery.throughputBpd * dslYieldPct / 100.0).toLong(), dslPrice, (dslYieldPct / 100.0) * dslPrice),
            ProductOutputYield(activeProductPrices.first { it.code == "VLSFO" }, resYieldPct, (refinery.throughputBpd * resYieldPct / 100.0).toLong(), vlsfoPrice, (resYieldPct / 100.0) * vlsfoPrice)
        )

        val totalGrossRevenuePerBbl = outputYields.sumOf { it.revenuePerBblCrude }
        val grossMarginPerBbl = totalGrossRevenuePerBbl - crudeDeliveredPricePerBbl
        val variableOpexPerBbl = refinery.type.opexPerBbl + (blend.blendedSulfurWtPct * 0.45) // extra hydrogen/desulfurizer energy cost
        val netMarginPerBbl = grossMarginPerBbl - variableOpexPerBbl
        val dailyNetMarginUsd = netMarginPerBbl * refinery.throughputBpd

        return RefineryRunResult(
            refinery = refinery,
            crudeFeedstockCostPerBbl = crudeDeliveredPricePerBbl,
            totalProductRevenuePerBbl = totalGrossRevenuePerBbl,
            variableOpexPerBbl = variableOpexPerBbl,
            grossRefineryMarginPerBbl = grossMarginPerBbl,
            netRefineryMarginPerBbl = netMarginPerBbl,
            dailyNetMarginUsd = dailyNetMarginUsd,
            yields = outputYields,
            sulfurConstraintMet = blend.blendedSulfurWtPct <= 2.5,
            apiGravityProcessed = blend.blendedApi,
            provenance = PriceProvenance(ProvenanceStatus.MODELLED, "Rhino Refinery Economics Engine v3.7", "12:55 BST")
        )
    }

    val SAMPLE_REFINERIES: List<Refinery> by lazy {
        val brent = AssayEngine.getGradeById("BRENT") ?: AssayEngine.CRUDE_DATABASE.first()
        val wti = AssayEngine.getGradeById("WTI_MIDLAND") ?: brent
        val dubai = AssayEngine.getGradeById("DUBAI") ?: brent

        listOf(
            Refinery(
                id = "REF_PERNIS_ROTTERDAM",
                name = "Pernis Refinery (Rotterdam)",
                location = "Rotterdam, Netherlands",
                region = Region.NORTH_SEA,
                type = RefineryType.COMPLEX_DEEP,
                nameplateCapacityBpd = 404_000L,
                activeCrudeDiet = listOf(
                    CrudeBlendComponent(brent, 0.60),
                    CrudeBlendComponent(wti, 0.40)
                ),
                throughputBpd = 370_000L,
                units = listOf(
                    RefineryUnit("CDU-1 & CDU-2", 404_000L, 370_000L),
                    RefineryUnit("Hydrocracker (HCU)", 95_000L, 92_000L),
                    RefineryUnit("Delayed Coker (DCU)", 65_000L, 62_000L),
                    RefineryUnit("Continuous Catalytic Reformer", 55_000L, 51_000L),
                    RefineryUnit("Diesel Hydrotreater (DHT)", 140_000L, 138_000L)
                ),
                port = Port("PORT_ROTTERDAM", "Port of Rotterdam", "NLRTM", "Netherlands", Region.NORTH_SEA, 51.92f, 4.47f, 24.0, true)
            ),
            Refinery(
                id = "REF_BAYTOWN_TX",
                name = "Baytown Complex (Texas)",
                location = "Baytown, Texas, USA",
                region = Region.NORTH_AMERICA,
                type = RefineryType.COMPLEX_DEEP,
                nameplateCapacityBpd = 560_000L,
                activeCrudeDiet = listOf(
                    CrudeBlendComponent(wti, 0.70),
                    CrudeBlendComponent(AssayEngine.getGradeById("MARS") ?: brent, 0.30)
                ),
                throughputBpd = 525_000L,
                units = listOf(
                    RefineryUnit("Atmospheric Distillation Towers", 560_000L, 525_000L),
                    RefineryUnit("Fluid Catalytic Cracker (FCC)", 180_000L, 175_000L),
                    RefineryUnit("Hydrocracker Units", 110_000L, 105_000L),
                    RefineryUnit("Flexicoker", 85_000L, 82_000L)
                ),
                port = Port("PORT_HOUSTON", "Port of Houston", "USHOU", "United States", Region.NORTH_AMERICA, 29.76f, -95.36f, 15.5, false)
            ),
            Refinery(
                id = "REF_JURONG_SINGAPORE",
                name = "Jurong Island Refinery (Singapore)",
                location = "Jurong Island, Singapore",
                region = Region.ASIA_PACIFIC,
                type = RefineryType.MEDIUM_CONVERSION,
                nameplateCapacityBpd = 290_000L,
                activeCrudeDiet = listOf(
                    CrudeBlendComponent(dubai, 0.50),
                    CrudeBlendComponent(AssayEngine.getGradeById("MURBAN") ?: brent, 0.50)
                ),
                throughputBpd = 265_000L,
                units = listOf(
                    RefineryUnit("Crude Distillation Unit (CDU)", 290_000L, 265_000L),
                    RefineryUnit("Vacuum Distillation Unit (VDU)", 120_000L, 110_000L),
                    RefineryUnit("Residue FCC Unit", 85_000L, 80_000L),
                    RefineryUnit("Kerosene/Jet Merox Unit", 45_000L, 42_000L)
                ),
                port = Port("PORT_SINGAPORE", "Port of Singapore", "SGSIN", "Singapore", Region.ASIA_PACIFIC, 1.29f, 103.85f, 22.0, true)
            )
        )
    }
}
