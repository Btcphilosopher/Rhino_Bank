package com.example.rhinooilspot.domain.model

data class RefineryUnit(
    val name: String,
    val capacityBpd: Long,
    val currentThroughputBpd: Long,
    val status: String = "OPERATIONAL"
)

data class Refinery(
    val id: String,
    val name: String,
    val location: String,
    val region: Region,
    val type: RefineryType,
    val nameplateCapacityBpd: Long,
    val activeCrudeDiet: List<CrudeBlendComponent>,
    val throughputBpd: Long,
    val units: List<RefineryUnit>,
    val port: Port
) {
    val utilizationPct: Double get() = (throughputBpd.toDouble() / nameplateCapacityBpd.toDouble()) * 100.0
}

data class ProductOutputYield(
    val product: ProductPrice,
    val yieldVolPct: Double,
    val bpdVolume: Long,
    val pricePerBbl: Double,
    val revenuePerBblCrude: Double
)

data class RefineryRunResult(
    val refinery: Refinery,
    val crudeFeedstockCostPerBbl: Double,
    val totalProductRevenuePerBbl: Double,
    val variableOpexPerBbl: Double,
    val grossRefineryMarginPerBbl: Double,  // Revenue - Feedstock
    val netRefineryMarginPerBbl: Double,    // GRM - Variable Opex
    val dailyNetMarginUsd: Double,
    val yields: List<ProductOutputYield>,
    val sulfurConstraintMet: Boolean,
    val apiGravityProcessed: Double,
    val provenance: PriceProvenance
)

data class SlateOptimizationResult(
    val refineryName: String,
    val optimalBlend: List<CrudeBlendComponent>,
    val grossMarginPerBbl: Double,
    val netMarginPerBbl: Double,
    val baselineMarginPerBbl: Double,
    val marginUpliftPerBbl: Double,
    val resultingApi: Double,
    val resultingSulfurWtPct: Double,
    val constraints: Map<String, String>,
    val provenance: PriceProvenance
)
