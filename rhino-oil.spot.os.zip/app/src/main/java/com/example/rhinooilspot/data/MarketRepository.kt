package com.example.rhinooilspot.data

import com.example.rhinooilspot.domain.engine.*
import com.example.rhinooilspot.domain.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class MarketNewsItem(
    val id: String,
    val time: String,
    val headline: String,
    val source: String,
    val category: String,
    val impact: String
)

class MarketRepository {

    private val _benchmarks = MutableStateFlow<List<BenchmarkPrice>>(initialBenchmarks())
    val benchmarks: StateFlow<List<BenchmarkPrice>> = _benchmarks.asStateFlow()

    private val _cargoes = MutableStateFlow<List<Cargo>>(initialCargoes())
    val cargoes: StateFlow<List<Cargo>> = _cargoes.asStateFlow()

    private val _orderBooks = MutableStateFlow<Map<String, PhysicalOrderBook>>(initialOrderBooks())
    val orderBooks: StateFlow<Map<String, PhysicalOrderBook>> = _orderBooks.asStateFlow()

    private val _vessels = MutableStateFlow<List<Vessel>>(initialVessels())
    val vessels: StateFlow<List<Vessel>> = _vessels.asStateFlow()

    private val _forwardCurves = MutableStateFlow<Map<String, ForwardCurve>>(initialForwardCurves())
    val forwardCurves: StateFlow<Map<String, ForwardCurve>> = _forwardCurves.asStateFlow()

    private val _refineries = MutableStateFlow<List<Refinery>>(RefineryEconomicsEngine.SAMPLE_REFINERIES)
    val refineries: StateFlow<List<Refinery>> = _refineries.asStateFlow()

    private val _hubBalances = MutableStateFlow<List<HubBalance>>(HubAndBalanceEngine.GLOBAL_HUB_BALANCES)
    val hubBalances: StateFlow<List<HubBalance>> = _hubBalances.asStateFlow()

    private val _storageTerminals = MutableStateFlow<List<StorageTerminal>>(HubAndBalanceEngine.STORAGE_TERMINALS)
    val storageTerminals: StateFlow<List<StorageTerminal>> = _storageTerminals.asStateFlow()

    private val _productPrices = MutableStateFlow<List<ProductPrice>>(RefineryEconomicsEngine.DEFAULT_PRODUCT_PRICES)
    val productPrices: StateFlow<List<ProductPrice>> = _productPrices.asStateFlow()

    private val _crackSpreads = MutableStateFlow<List<CrackSpread>>(RefineryEconomicsEngine.calculateCrackSpreads(78.42))
    val crackSpreads: StateFlow<List<CrackSpread>> = _crackSpreads.asStateFlow()

    private val _activeScenario = MutableStateFlow<MarketScenario?>(null)
    val activeScenario: StateFlow<MarketScenario?> = _activeScenario.asStateFlow()

    private val _positions = MutableStateFlow<List<PhysicalPosition>>(RiskPnLEngine.INITIAL_PORTFOLIO_POSITIONS)
    val positions: StateFlow<List<PhysicalPosition>> = _positions.asStateFlow()

    private val _newsStream = MutableStateFlow<List<MarketNewsItem>>(initialNews())
    val newsStream: StateFlow<List<MarketNewsItem>> = _newsStream.asStateFlow()

    fun updateBenchmarkPrice(id: String, delta: Double) {
        _benchmarks.update { list ->
            list.map { b ->
                if (b.id == id) {
                    val newPrice = Math.max(10.0, b.spotPrice + delta)
                    val newChange = b.change + delta
                    val newChangePct = (newChange / (newPrice - newChange)) * 100.0
                    b.copy(
                        spotPrice = Math.round(newPrice * 100.0) / 100.0,
                        change = Math.round(newChange * 100.0) / 100.0,
                        changePct = Math.round(newChangePct * 100.0) / 100.0
                    )
                } else b
            }
        }
        val brent = _benchmarks.value.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
        _crackSpreads.value = RefineryEconomicsEngine.calculateCrackSpreads(brent)
    }

    fun applyScenario(scenario: MarketScenario?) {
        _activeScenario.value = scenario
        if (scenario != null) {
            val impact = scenario.defaultImpact
            updateBenchmarkPrice("DATED_BRENT", impact.datedBrentShiftUsd)
            updateBenchmarkPrice("WTI_CUSHING", impact.wtiShiftUsd)
            updateBenchmarkPrice("DUBAI", impact.dubaiShiftUsd)
            addNews(
                MarketNewsItem(
                    id = "NEWS_${System.currentTimeMillis()}",
                    time = "12:55 BST",
                    headline = "SCENARIO ACTIVATED: ${scenario.title}",
                    source = "Rhino Geopolitical Simulation Engine",
                    category = scenario.category,
                    impact = impact.narrative
                )
            )
        } else {
            _benchmarks.value = initialBenchmarks()
            _crackSpreads.value = RefineryEconomicsEngine.calculateCrackSpreads(78.42)
            addNews(
                MarketNewsItem(
                    id = "NEWS_${System.currentTimeMillis()}",
                    time = "12:55 BST",
                    headline = "BASELINE RESET: Live Market Conditions Restored",
                    source = "Rhino Terminal",
                    category = "SYSTEM",
                    impact = "All physical differentials and benchmark prices reset to published baseline."
                )
            )
        }
    }

    fun addNews(item: MarketNewsItem) {
        _newsStream.update { (listOf(item) + it).take(20) }
    }

    fun addPosition(position: PhysicalPosition) {
        _positions.update { it + position }
    }

    fun removePosition(id: String) {
        _positions.update { it.filterNot { pos -> pos.id == id } }
    }

    companion object {
        fun initialBenchmarks(): List<BenchmarkPrice> {
            val provPub = PriceProvenance(ProvenanceStatus.PUBLISHED, "Platts / ICE / Argus", "12:55 BST")
            val provAssessed = PriceProvenance(ProvenanceStatus.ASSESSED, "S&P Global Commodity Insights", "12:55 BST")

            return listOf(
                BenchmarkPrice("DATED_BRENT", "Dated Brent (BFOET+WTI)", "BRENT", 78.42, 0.31, 0.40, 78.85, 77.90, "1.45M b/d", Currency.USD, provPub),
                BenchmarkPrice("WTI_CUSHING", "WTI Cushing (NYMEX CL)", "WTI", 74.91, 0.22, 0.29, 75.30, 74.45, "1.82M b/d", Currency.USD, provPub),
                BenchmarkPrice("DUBAI", "Dubai Crude Assessment", "DUBAI", 76.18, 0.14, 0.18, 76.45, 75.80, "850k b/d", Currency.USD, provAssessed),
                BenchmarkPrice("BRENT_M1", "ICE Brent Futures (M1)", "LCOc1", 78.55, 0.28, 0.36, 78.98, 78.10, "245k lots", Currency.USD, provPub),
                BenchmarkPrice("BRENT_M2", "ICE Brent Futures (M2)", "LCOc2", 78.88, 0.24, 0.31, 79.20, 78.40, "180k lots", Currency.USD, provPub),
                BenchmarkPrice("MURBAN", "IFAD Murban Futures", "MURBAN", 77.63, 0.35, 0.45, 77.95, 77.15, "420k b/d", Currency.USD, provPub),
                BenchmarkPrice("BONNY_LIGHT", "Bonny Light Physical (FOB)", "BONNY", 79.32, 0.41, 0.52, 79.70, 78.80, "320k b/d", Currency.USD, provAssessed),
                BenchmarkPrice("WCS", "Western Canadian Select (Hardisty)", "WCS", 62.41, -0.15, -0.24, 62.80, 61.95, "550k b/d", Currency.USD, provAssessed)
            )
        }

        fun initialCargoes(): List<Cargo> {
            val brent = AssayEngine.getGradeById("BRENT")!!
            val forties = AssayEngine.getGradeById("FORTIES")!!
            val oseberg = AssayEngine.getGradeById("OSEBERG")!!
            val wtiMidland = AssayEngine.getGradeById("WTI_MIDLAND")!!
            val bonny = AssayEngine.getGradeById("BONNY_LIGHT")!!
            val arabLight = AssayEngine.getGradeById("ARAB_LIGHT")!!
            val murban = AssayEngine.getGradeById("MURBAN")!!
            val tupi = AssayEngine.getGradeById("TUPI")!!

            val ports = FreightAndVoyageEngine.PORTS_DATABASE
            val houndPoint = ports.first { it.id == "PORT_HOUND_POINT" }
            val rotterdam = ports.first { it.id == "PORT_ROTTERDAM" }
            val corpus = ports.first { it.id == "PORT_CORPUS_CHRISTI" }
            val ningbo = ports.first { it.id == "PORT_NINGBO" }
            val bonnyPort = ports.first { it.id == "PORT_BONNY" }
            val rasTanura = ports.first { it.id == "PORT_RAS_TANURA" }
            val fujairah = ports.first { it.id == "PORT_FUJAIRAH" }
            val chiba = ports.first { it.id == "PORT_CHIBA" }
            val sture = ports.first { it.id == "PORT_STURE" }
            val santos = ports.first { it.id == "PORT_SANTOS" }
            val singapore = ports.first { it.id == "PORT_SINGAPORE" }

            val vessels = initialVessels()
            val provOff = PriceProvenance(ProvenanceStatus.MODELLED, "Physical Cargo Offer Book", "12:50 BST")
            val provBid = PriceProvenance(ProvenanceStatus.MODELLED, "Physical Cargo Bid Book", "12:50 BST")
            val provFixed = PriceProvenance(ProvenanceStatus.PUBLISHED, "Reported Fixtures", "12:45 BST")

            return listOf(
                Cargo("NS-48291", forties, 600_000L, "BP Oil International", "Shell Trading", houndPoint, rotterdam, "10-12 Oct 2026", "14-16 Oct 2026", Incoterm.CIF, "Dated Brent", -0.45, 77.97, vessels[0], CargoStatus.OFFER, provOff),
                Cargo("US-99120", wtiMidland, 700_000L, "Trafigura Pte", "TotalEnergies", corpus, rotterdam, "02-04 Nov 2026", "18-20 Nov 2026", Incoterm.CIF, "Dated Brent", 0.25, 78.67, vessels[1], CargoStatus.FIXED, provFixed),
                Cargo("WA-33012", bonny, 1_000_000L, "NNPC / Chevron", "Reliance Industries", bonnyPort, ningbo, "25-27 Oct 2026", "20-22 Nov 2026", Incoterm.FOB, "Dated Brent", 0.90, 79.32, vessels[2], CargoStatus.ON_WATER, provFixed),
                Cargo("ME-10294", arabLight, 2_000_000L, "Saudi Aramco", "Sinopec Corp", rasTanura, ningbo, "05-07 Nov 2026", "26-28 Nov 2026", Incoterm.FOB, "Dubai", 1.20, 77.38, vessels[3], CargoStatus.LOADING, provFixed),
                Cargo("ME-55102", murban, 2_000_000L, "ADNOC Trading", "ENEOS Corp", fujairah, chiba, "12-14 Nov 2026", "02-04 Dec 2026", Incoterm.FOB, "Dubai", 1.45, 77.63, null, CargoStatus.OFFER, provOff),
                Cargo("NS-71204", oseberg, 600_000L, "Equinor ASA", "ExxonMobil", sture, rotterdam, "18-20 Oct 2026", "22-24 Oct 2026", Incoterm.CIF, "Dated Brent", 0.85, 79.27, null, CargoStatus.BID, provBid),
                Cargo("LA-88231", tupi, 1_000_000L, "Petrobras", "Unipec Asia", santos, singapore, "01-03 Nov 2026", "28-30 Nov 2026", Incoterm.FOB, "Dated Brent", -0.30, 78.12, null, CargoStatus.OFFER, provOff)
            )
        }

        fun initialVessels(): List<Vessel> {
            return listOf(
                Vessel("VES_001", "MT NAVION BALTIC", "IMO9412034", VesselClass.AFRAMAX, "Norway", 2018, 13.8, 28.0, 58.20f, 1.40f, 185f, "Rotterdam", "14 Oct 18:00"),
                Vessel("VES_002", "MT EAGLE COLUMBUS", "IMO9628100", VesselClass.SUEZMAX, "Singapore", 2020, 14.2, 38.0, 32.50f, -48.20f, 65f, "Rotterdam", "18 Nov 06:00"),
                Vessel("VES_003", "MT SEAWAYS DISCOVERY", "IMO9538812", VesselClass.SUEZMAX, "Marshall Islands", 2019, 13.5, 39.0, -12.40f, 42.10f, 75f, "Ningbo", "20 Nov 12:00"),
                Vessel("VES_004", "MT TI EUROPE", "IMO9248837", VesselClass.VLCC, "Belgium", 2022, 14.5, 52.0, 24.10f, 58.90f, 120f, "Ningbo", "26 Nov 08:00")
            )
        }

        fun initialOrderBooks(): Map<String, PhysicalOrderBook> {
            val prov = PriceProvenance(ProvenanceStatus.SYNTHETIC, "Simulated Liquidity Engine", "12:55 BST")
            val fortiesBids = listOf(
                OrderBookLevel(-0.48, 600_000L, 1),
                OrderBookLevel(-0.55, 600_000L, 2),
                OrderBookLevel(-0.65, 1_200_000L, 2),
                OrderBookLevel(-0.80, 600_000L, 1)
            )
            val fortiesOffers = listOf(
                OrderBookLevel(-0.42, 600_000L, 1),
                OrderBookLevel(-0.35, 600_000L, 1),
                OrderBookLevel(-0.20, 1_200_000L, 2),
                OrderBookLevel(-0.05, 600_000L, 1)
            )
            return mapOf(
                "FORTIES" to PhysicalOrderBook("FORTIES", "Forties North Sea", "Dated Brent", 78.42, fortiesBids, fortiesOffers, -0.45, prov),
                "WTI_MIDLAND" to PhysicalOrderBook("WTI_MIDLAND", "WTI Midland FOB USGC", "Dated Brent", 78.42,
                    listOf(OrderBookLevel(0.20, 700_000L, 2), OrderBookLevel(0.12, 1_400_000L, 2)),
                    listOf(OrderBookLevel(0.28, 700_000L, 1), OrderBookLevel(0.35, 700_000L, 1)),
                    0.24, prov)
            )
        }

        fun initialForwardCurves(): Map<String, ForwardCurve> {
            return mapOf(
                "BRENT" to StorageCarryEngine.generateForwardCurve("BRENT", "ICE Brent Forward Curve", 78.42, CurveStructure.BACKWARDATION),
                "WTI" to StorageCarryEngine.generateForwardCurve("WTI", "NYMEX WTI Forward Curve", 74.91, CurveStructure.BACKWARDATION),
                "DUBAI" to StorageCarryEngine.generateForwardCurve("DUBAI", "Platts Dubai Forward Curve", 76.18, CurveStructure.BACKWARDATION)
            )
        }

        fun initialNews(): List<MarketNewsItem> {
            return listOf(
                MarketNewsItem("NEWS_001", "12:52 BST", "Dated Brent assessed at $78.42/bbl (+0.31) with Forties setting prompt CIF NWE marker.", "Platts Desk", "PRICING", "Prompt market remains tightly backwardated with M1/M2 spread holding at +$0.33/bbl."),
                MarketNewsItem("NEWS_002", "12:44 BST", "US Permian exports via Corpus Christi reach weekly record 2.4 mb/d as VLCC loading activity expands.", "Corpus Harbor Commission", "LOGISTICS", "Aframax TC freight to Rotterdam steady at WS 145 ($2.81/bbl delivered)."),
                MarketNewsItem("NEWS_003", "12:30 BST", "Cushing crude inventories register 0.85 mbbl draw to 38.4 mbbl on robust Midwest and Gulf Coast refinery utilization.", "EIA Weekly Report", "INVENTORY", "Cushing utilization at 49.2%; WTI Houston MEH premium holds at +$1.10/bbl over Cushing."),
                MarketNewsItem("NEWS_004", "12:15 BST", "European diesel crack spreads firm to $18.98/bbl on low Rhine water levels and seasonal autumn agricultural demand.", "ICE Europe", "REFINERY", "Complex deep conversion refiners in Rotterdam posting cash margins above $11.40/bbl.")
            )
        }
    }
}
