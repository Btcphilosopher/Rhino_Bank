package com.example.rhinooilspot.domain.model

enum class PositionType {
    PHYSICAL_CARGO_LONG,
    PHYSICAL_CARGO_SHORT,
    STORAGE_LONG,
    FREIGHT_CHARTER,
    REFINED_PRODUCT_LONG,
    PAPER_FUTURES_HEDGE
}

data class PhysicalPosition(
    val id: String,
    val description: String,
    val type: PositionType,
    val quantity: Double,
    val unit: String,            // "BBL", "MT", "Voyages"
    val entryPriceUsd: Double,
    val currentMarketPriceUsd: Double,
    val benchmarkRef: String,
    val differential: Double,
    val freightCostUsd: Double = 0.0,
    val storageCostUsd: Double = 0.0,
    val location: String,
    val valueAtRisk95Usd: Double = 0.0
) {
    val mtmValueUsd: Double get() = quantity * currentMarketPriceUsd
    val entryValueUsd: Double get() = quantity * entryPriceUsd
    val unrealizedPnlUsd: Double get() = (currentMarketPriceUsd - entryPriceUsd) * quantity - freightCostUsd - storageCostUsd
}

data class PnLAttribution(
    val totalPnlUsd: Double,
    val flatPricePnlUsd: Double,
    val basisDifferentialPnlUsd: Double,
    val freightPnlUsd: Double,
    val storageAndCarryPnlUsd: Double,
    val qualityAdjustmentPnlUsd: Double,
    val fxPnlUsd: Double,
    val hedgeOffsetPnlUsd: Double,
    val reportingCurrency: Currency = Currency.USD
)

data class PortfolioRisk(
    val netCrudeExposureBbl: Long,
    val netProductExposureTons: Long,
    val totalMtmPortfolioValueUsd: Double,
    val totalUnrealizedPnlUsd: Double,
    val oneDayVaR95Usd: Double,
    val stressLossWorstCaseUsd: Double,
    val crudeDeltaDv01Usd: Double,  // PnL per $1/bbl flat price move
    val basisDv01Usd: Double,       // PnL per $0.10/bbl diff move
    val freightDv01Usd: Double      // PnL per 1 WS point move
)
