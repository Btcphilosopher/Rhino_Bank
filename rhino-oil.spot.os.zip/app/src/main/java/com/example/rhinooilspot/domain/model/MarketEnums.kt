package com.example.rhinooilspot.domain.model

enum class MarketStatus {
    OPEN,
    CLOSED,
    PRE_MARKET,
    POST_MARKET,
    SETTLED
}

enum class ProvenanceStatus {
    LIVE,
    PUBLISHED,
    ASSESSED,
    INDICATIVE,
    MODELLED,
    SYNTHETIC,
    DELAYED,
    HISTORICAL
}

data class PriceProvenance(
    val status: ProvenanceStatus,
    val source: String,
    val timestamp: String,
    val methodology: String = "Physical Differential Engine v3.7",
    val confidence: Double = 0.98,
    val auditFormula: String = ""
)

enum class Incoterm(val fullName: String) {
    FOB("Free On Board"),
    CIF("Cost, Insurance & Freight"),
    DES("Delivered Ex-Ship"),
    DAP("Delivered at Place"),
    CFR("Cost and Freight")
}

enum class VesselClass(val label: String, val capacityBbl: Long, val deadweightTons: Long) {
    VLCC("Very Large Crude Carrier", 2_000_000L, 300_000L),
    SUEZMAX("Suezmax", 1_000_000L, 150_000L),
    AFRAMAX("Aframax", 600_000L, 110_000L),
    PANAMAX("Panamax", 400_000L, 70_000L),
    LR2("Long Range 2", 750_000L, 115_000L),
    MR("Medium Range", 300_000L, 45_000L)
}

enum class RefineryType(val label: String, val complexityNci: Double, val opexPerBbl: Double) {
    HYDROSKIMMING("Hydroskimming (CDU + Reformer)", 4.0, 2.10),
    MEDIUM_CONVERSION("Medium Conversion (CDU + FCC)", 7.5, 3.85),
    COMPLEX_DEEP("Complex Deep Conversion (Hydrocracker + Coker)", 12.0, 5.40)
}

enum class UnitType(val symbol: String, val label: String, val bblMultiplier: Double) {
    USD_PER_BBL("$/bbl", "US Dollars per Barrel", 1.0),
    USD_PER_TONNE("$/t", "US Dollars per Metric Tonne", 0.136), // ~7.35 bbl/tonne avg
    EUR_PER_BBL("€/bbl", "Euros per Barrel", 1.0),
    GBP_PER_BBL("£/bbl", "British Pounds per Barrel", 1.0)
}

enum class Currency(val code: String, val symbol: String, val rateToUsd: Double) {
    USD("USD", "$", 1.0),
    GBP("GBP", "£", 0.77),
    EUR("EUR", "€", 0.92),
    JPY("JPY", "¥", 152.4),
    CNY("CNY", "¥", 7.24),
    CAD("CAD", "C$", 1.37),
    NOK("NOK", "kr", 10.6),
    AED("AED", "د.إ", 3.67),
    SAR("SAR", "﷼", 3.75)
}

enum class Region(val label: String) {
    NORTH_SEA("North Sea"),
    NORTH_AMERICA("North America / USGC"),
    MIDDLE_EAST("Middle East / AG"),
    WEST_AFRICA("West Africa (WAF)"),
    NORTH_AFRICA("North Africa / Med"),
    LATIN_AMERICA("Latin America / Brazil"),
    ASIA_PACIFIC("Asia-Pacific"),
    RUSSIA_EURASIA("Russia / Eurasia")
}
