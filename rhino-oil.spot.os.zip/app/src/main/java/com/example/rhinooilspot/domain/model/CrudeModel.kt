package com.example.rhinooilspot.domain.model

data class AssayYields(
    val lpgPct: Double,         // Liquefied Petroleum Gas
    val naphthaPct: Double,     // Light / Heavy Naphtha
    val gasolinePct: Double,    // Reformate / Motor Spirit
    val jetKeroPct: Double,     // Jet A-1 / Kerosene
    val dieselGasoilPct: Double,// Ultra-Low Sulfur Diesel / Gasoil
    val vgoPct: Double,         // Vacuum Gas Oil
    val residuePct: Double      // Atmospheric / Vacuum Residue (HSFO/VLSFO)
) {
    val total: Double get() = lpgPct + naphthaPct + gasolinePct + jetKeroPct + dieselGasoilPct + vgoPct + residuePct
}

data class CrudeAssay(
    val apiGravity: Double,       // e.g. 38.0 API
    val sulfurWtPct: Double,      // e.g. 0.40 % wt
    val viscosityCst50: Double,   // Viscosity @ 50°C in cSt
    val tanMgKohPerG: Double,     // Total Acid Number
    val nickelPpm: Double,        // Nickel content (ppm)
    val vanadiumPpm: Double,      // Vanadium content (ppm)
    val pourPointC: Double,       // Pour point in °C
    val yields: AssayYields
) {
    val specificGravity: Double get() = 141.5 / (apiGravity + 131.5)
    val densityKgPerM3: Double get() = specificGravity * 1000.0
    val barrelsPerMetricTonne: Double get() = 6.2898 / specificGravity
    val isSweet: Boolean get() = sulfurWtPct < 0.5
    val isLight: Boolean get() = apiGravity > 35.0
    val isHeavy: Boolean get() = apiGravity < 28.0
}

data class CrudeGrade(
    val id: String,
    val name: String,
    val code: String,
    val region: Region,
    val country: String,
    val loadingTerminal: String,
    val benchmarkRef: String,
    val baseDifferential: Double, // $/bbl vs benchmark
    val assay: CrudeAssay,
    val typicalCargoSizeBbl: Long = 600_000L,
    val standardVesselClass: VesselClass = VesselClass.AFRAMAX,
    val description: String = ""
)

data class CrudeBlendComponent(
    val grade: CrudeGrade,
    val volumeFraction: Double // 0.0 to 1.0 (sums to 1.0)
)

data class CrudeBlendResult(
    val components: List<CrudeBlendComponent>,
    val blendedApi: Double,
    val blendedSulfurWtPct: Double,
    val blendedViscosityCst: Double,
    val blendedYields: AssayYields,
    val blendedSpecificGravity: Double,
    val indicativeRefineryMargin: Double
)
