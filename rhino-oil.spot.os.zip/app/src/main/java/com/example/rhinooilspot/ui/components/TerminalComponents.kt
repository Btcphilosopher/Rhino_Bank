package com.example.rhinooilspot.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.ScreenTab
import com.example.rhinooilspot.ui.theme.*

@Composable
fun ProvenanceBadge(
    provenance: PriceProvenance,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val (bgColor, textColor, text) = when (provenance.status) {
        ProvenanceStatus.LIVE -> Triple(TermEmerald.copy(alpha = 0.2f), TermEmeraldBright, "● LIVE")
        ProvenanceStatus.PUBLISHED -> Triple(TermCyan.copy(alpha = 0.2f), TermCyan, "PUBLISHED")
        ProvenanceStatus.ASSESSED -> Triple(TermGold.copy(alpha = 0.2f), TermGoldBright, "ASSESSED")
        ProvenanceStatus.INDICATIVE -> Triple(TermIndigo.copy(alpha = 0.2f), TermIndigo, "INDICATIVE")
        ProvenanceStatus.MODELLED -> Triple(Color(0xFF8B5CF6).copy(alpha = 0.2f), Color(0xFFA78BFA), "MODELLED")
        ProvenanceStatus.SYNTHETIC -> Triple(TermDimSlate.copy(alpha = 0.3f), TermMutedSlate, "SYNTHETIC")
        ProvenanceStatus.DELAYED -> Triple(TermGold.copy(alpha = 0.15f), TermGold, "DELAYED 15M")
        ProvenanceStatus.HISTORICAL -> Triple(TermDimSlate.copy(alpha = 0.2f), TermDimSlate, "HISTORICAL")
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(3.dp))
            .background(bgColor)
            .border(0.5.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(3.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        )
    }
}

@Composable
fun TerminalHeaderBar(
    currentTab: ScreenTab,
    selectedCurrency: Currency,
    onCurrencyChange: (Currency) -> Unit,
    activeScenario: MarketScenario?,
    onOpenCommandPalette: () -> Unit,
    onResetScenario: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showCurrencyDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TermBlack)
            .border(androidx.compose.foundation.BorderStroke(1.dp, TermBorder))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & System ID
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(TermGold)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "RHINO OIL.SPOT.OS",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = TermGoldBright,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(TermEmerald.copy(alpha = 0.15f))
                        .border(0.5.dp, TermEmerald.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "MARKET OPEN • LON/NYC/SGP",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TermEmeraldBright,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // Time & Controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "23 SEP 2026 12:55 BST",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 11.sp,
                        color = TermMutedSlate,
                        fontWeight = FontWeight.Medium
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))

                // Currency selector
                Box {
                    OutlinedButton(
                        onClick = { showCurrencyDropdown = true },
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("currency_selector_btn"),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = TermCardBg,
                            contentColor = TermWhite
                        ),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorderLight),
                        shape = RoundedCornerShape(3.dp)
                    ) {
                        Text(
                            text = "${selectedCurrency.symbol} ${selectedCurrency.code}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TermGold
                            )
                        )
                    }

                    DropdownMenu(
                        expanded = showCurrencyDropdown,
                        onDismissRequest = { showCurrencyDropdown = false },
                        modifier = Modifier.background(TermCardBgElevated)
                    ) {
                        Currency.values().forEach { curr ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${curr.symbol} ${curr.code} (${curr.name})",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = TermWhite)
                                    )
                                },
                                onClick = {
                                    onCurrencyChange(curr)
                                    showCurrencyDropdown = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Command launcher
                IconButton(
                    onClick = onOpenCommandPalette,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(TermCardBgElevated)
                        .testTag("cmd_palette_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search & Commands",
                        tint = TermGold,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Active Scenario Banner if active
        if (activeScenario != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(3.dp))
                    .background(TermCrimson.copy(alpha = 0.15f))
                    .border(0.5.dp, TermCrimsonBright.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "⚠ SHOCK SCENARIO ACTIVE:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TermCrimsonBright,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = activeScenario.title,
                        style = MaterialTheme.typography.labelSmall.copy(color = TermWhite),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = "RESET BASELINE",
                    modifier = Modifier
                        .clickable(onClick = onResetScenario)
                        .padding(horizontal = 4.dp),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TermGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                )
            }
        }
    }
}

@Composable
fun MarketTickerMarquee(
    benchmarks: List<BenchmarkPrice>,
    onBenchmarkClick: (BenchmarkPrice) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TermDarkBg)
            .border(androidx.compose.foundation.BorderStroke(1.dp, TermBorder))
            .horizontalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        benchmarks.forEach { bm ->
            val isPositive = bm.change >= 0.0
            val changeColor = if (isPositive) TermEmeraldBright else TermCrimsonBright
            val changeSign = if (isPositive) "+" else ""

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .clickable { onBenchmarkClick(bm) }
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = bm.symbol,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TermMutedSlate
                    )
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = String.format("%.2f", bm.spotPrice),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TermWhite
                    )
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "$changeSign${String.format("%.2f", bm.change)}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = changeColor
                    )
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = "│", color = TermBorder)
            }
        }
    }
}

@Composable
fun TerminalNavBar(
    selectedTab: ScreenTab,
    onTabSelected: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TermBlack)
            .border(androidx.compose.foundation.BorderStroke(1.dp, TermBorder))
            .horizontalScroll(scrollState)
            .padding(horizontal = 6.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        ScreenTab.values().forEach { tab ->
            val isSelected = tab == selectedTab
            val bgColor = if (isSelected) TermGold else TermCardBg
            val textColor = if (isSelected) TermBlack else TermMutedSlate
            val borderColor = if (isSelected) TermGoldBright else TermBorder

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(bgColor)
                    .border(0.5.dp, borderColor, RoundedCornerShape(3.dp))
                    .clickable { onTabSelected(tab) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("nav_tab_${tab.name}")
            ) {
                Text(
                    text = tab.title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = textColor
                    )
                )
            }
        }
    }
}

@Composable
fun CalculationInspectorSheet(
    trace: CalculationTrace,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.85f)
                .testTag("calculation_inspector_dialog"),
            colors = CardDefaults.cardColors(containerColor = TermCardBgElevated),
            shape = RoundedCornerShape(6.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, TermGold.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = null,
                                tint = TermGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CALCULATION EXPLORER",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TermGoldBright
                                )
                            )
                        }
                        Text(
                            text = trace.title,
                            style = MaterialTheme.typography.titleMedium.copy(color = TermWhite)
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TermMutedSlate
                        )
                    }
                }

                Divider(color = TermBorder, modifier = Modifier.padding(vertical = 10.dp))

                // Summary Value Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(TermDarkBg)
                        .border(1.dp, TermBorder, RoundedCornerShape(4.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "FINAL MODELLED VALUE",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                        )
                        Text(
                            text = "${String.format("%.2f", trace.finalCalculatedValue)} ${trace.finalUnit}",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                color = TermEmeraldBright,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "PROVENANCE",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                        )
                        ProvenanceBadge(trace.dataProvenance)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "STEP-BY-STEP MATHEMATICAL ARITHMETIC",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TermGold
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Steps List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    items(trace.steps) { step ->
                        val isPositive = step.impactUsdPerBbl >= 0
                        val impactColor = if (isPositive) TermEmeraldBright else TermCrimsonBright
                        val sign = if (isPositive) "+" else ""

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(TermDarkBg)
                                .border(0.5.dp, TermBorder, RoundedCornerShape(3.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = step.formulaSymbol,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TermGold
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = step.stepName,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = TermWhite
                                        )
                                    )
                                }
                                Text(
                                    text = "$sign${String.format("%.2f", step.impactUsdPerBbl)} $/bbl",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = impactColor
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Input: ${step.inputValue}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                                )
                                Text(
                                    text = step.explanation,
                                    style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Footer Metadata
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TermDarkBg)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "Engine: ${trace.modelVersion} • Timestamp: ${trace.calculationTimestamp}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                    )
                    Text(
                        text = "Formula: ${trace.dataProvenance.auditFormula.ifEmpty { trace.methodology }}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                    )
                }
            }
        }
    }
}

@Composable
fun CommandPaletteDialog(
    onCommand: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val presetCommands = listOf(
        Pair("OIL NOW", "Global physical overview & flow map"),
        Pair("BRENT COMPLEX", "Dated Brent, BFOET, EFP, CFD & Spreads"),
        Pair("WTI CUSHING", "WTI Cushing, Houston, Midland & Pipeline flows"),
        Pair("CARGO BOARD", "Physical spot cargoes & bids/offers"),
        Pair("FREIGHT & VOYAGE", "Tanker shipping, Worldscale & Voyage calculator"),
        Pair("REFINERY & CRACKS", "Assay yields, 3:2:1 crack & refinery margins"),
        Pair("STORAGE & HUBS", "Global inventory, carry economics & curves"),
        Pair("CRUDE SLATE ARBITRAGE", "Crude slate optimizer & transatlantic arb"),
        Pair("SUPPLY SHOCKS", "Geopolitical & weather outage scenarios"),
        Pair("RISK & P&L", "Physical positions, VaR & P&L attribution")
    )

    val filtered = remember(searchQuery) {
        if (searchQuery.isBlank()) presetCommands
        else presetCommands.filter {
            it.first.contains(searchQuery, ignoreCase = true) || it.second.contains(searchQuery, ignoreCase = true)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .height(450.dp)
                .testTag("command_palette_modal"),
            colors = CardDefaults.cardColors(containerColor = TermCardBgElevated),
            shape = RoundedCornerShape(6.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, TermGold)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                // Search Input Field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Enter command or search (e.g. BRENT, REFINERY, CARGO)...", style = MaterialTheme.typography.bodyMedium.copy(color = TermDimSlate)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("command_search_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TermGold,
                        unfocusedBorderColor = TermBorder,
                        focusedTextColor = TermWhite,
                        unfocusedTextColor = TermWhite,
                        focusedContainerColor = TermDarkBg,
                        unfocusedContainerColor = TermDarkBg
                    ),
                    trailingIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TermMutedSlate)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "COMMAND DIRECTORY (KEYBOARD NAVIGATION)",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermGold, fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(4.dp))

                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(filtered) { (title, desc) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .clickable { onCommand(title) }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TermWhite
                                    )
                                )
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = TermGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Divider(color = TermBorder, thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}
