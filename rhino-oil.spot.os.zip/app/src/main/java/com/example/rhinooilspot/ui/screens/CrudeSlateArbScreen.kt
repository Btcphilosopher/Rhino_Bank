package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.engine.AssayEngine
import com.example.rhinooilspot.domain.engine.CrudeSlateOptimizer
import com.example.rhinooilspot.domain.engine.FreightAndVoyageEngine
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.components.ProvenanceBadge
import com.example.rhinooilspot.ui.theme.*

@Composable
fun CrudeSlateArbScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val refineries by viewModel.refineries.collectAsState()
    val benchmarks by viewModel.benchmarks.collectAsState()

    val brent = benchmarks.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
    val defaultRef = refineries.first()

    val candidateGrades = remember {
        listOf("BRENT", "FORTIES", "WTI_MIDLAND", "MARS", "DUBAI", "BONNY_LIGHT").mapNotNull {
            AssayEngine.getGradeById(it)
        }
    }

    val prices = remember(brent) {
        candidateGrades.associate { it.id to (brent + it.baseDifferential) }
    }

    val optResult = remember(defaultRef, brent) {
        CrudeSlateOptimizer.optimizeSlate(defaultRef, candidateGrades, prices)
    }

    // Physical Arbitrage Matrix
    val arbResult = remember(brent) {
        val wtiMidland = AssayEngine.getGradeById("WTI_MIDLAND")!!
        FreightAndVoyageEngine.calculatePhysicalArbitrage(
            grade = wtiMidland,
            originFobPrice = 78.42 + 0.25,
            destinationBenchmarkPrice = 81.80, // CIF Rotterdam
            freightCostPerBbl = 2.81,
            portAndTerminalPerBbl = 0.28,
            insurancePerBbl = 0.12
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Refinery Crude Slate LP Optimizer Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("crude_slate_optimizer_card"),
                colors = CardDefaults.cardColors(containerColor = TermCardBgElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermGold.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "LINEAR PROGRAMMING (LP) SLATE OPTIMIZATION",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermGold, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${defaultRef.name} Target Diet",
                                style = MaterialTheme.typography.titleMedium.copy(color = TermWhite, fontWeight = FontWeight.Black)
                            )
                        }
                        ProvenanceBadge(optResult.provenance)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "OPTIMAL NET CASH MARGIN", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(
                                text = "$${String.format("%.2f", optResult.netMarginPerBbl)} /bbl",
                                style = MaterialTheme.typography.displayLarge.copy(color = TermEmeraldBright)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "+$${String.format("%.2f", optResult.marginUpliftPerBbl)} Uplift vs Baseline",
                                style = MaterialTheme.typography.bodyLarge.copy(color = TermGoldBright, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Resulting Blend: ${String.format("%.1f", optResult.resultingApi)}° API • ${String.format("%.2f", optResult.resultingSulfurWtPct)}% S",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                            )
                        }
                    }

                    Divider(color = TermBorder, modifier = Modifier.padding(vertical = 8.dp))

                    Text(text = "OPTIMAL CRUDE FEEDSTOCK BLEND FRACTIONS", style = MaterialTheme.typography.labelSmall.copy(color = TermGold, fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(4.dp))

                    optResult.optimalBlend.forEach { comp ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "• ${comp.grade.name} (${comp.grade.code})",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TermWhite, fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "${String.format("%.1f", comp.volumeFraction * 100.0)}% Slate (${String.format("%,d", (defaultRef.throughputBpd * comp.volumeFraction).toLong())} bpd)",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TermCyan, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Physical Transatlantic Export Arbitrage Matrix
        item {
            Text(
                text = "PHYSICAL TRANSATLANTIC ARBITRAGE (USGC → ROTTERDAM)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("transatlantic_arb_card"),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${arbResult.crudeGrade.name} Arbitrage Window",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                        )
                        ProvenanceBadge(arbResult.provenance)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "USGC FOB Origin Price", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(text = "$${String.format("%.2f", arbResult.originFobPrice)}/bbl", style = MaterialTheme.typography.bodyLarge.copy(color = TermWhite, fontWeight = FontWeight.Bold))
                        }
                        Column {
                            Text(text = "Tanker Freight & Port", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(text = "+$${String.format("%.2f", arbResult.freightCostPerBbl + arbResult.portAndTerminalPerBbl)}/bbl", style = MaterialTheme.typography.bodyLarge.copy(color = TermCyan, fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Delivered CIF Cost", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(text = "$${String.format("%.2f", arbResult.deliveredCostPerBbl)}/bbl", style = MaterialTheme.typography.bodyLarge.copy(color = TermWhite, fontWeight = FontWeight.Bold))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (arbResult.isProfitable) TermEmerald.copy(alpha = 0.15f) else TermCrimson.copy(alpha = 0.15f))
                            .border(0.5.dp, if (arbResult.isProfitable) TermEmeraldBright else TermCrimsonBright, RoundedCornerShape(3.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (arbResult.isProfitable) "ARBITRAGE WINDOW OPEN" else "ARBITRAGE CLOSED",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (arbResult.isProfitable) TermEmeraldBright else TermCrimsonBright
                            )
                        )
                        Text(
                            text = "Net Arb Profit: +$${String.format("%.2f", arbResult.arbitrageDifferential)} /bbl",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = if (arbResult.isProfitable) TermEmeraldBright else TermCrimsonBright
                            )
                        )
                    }
                }
            }
        }
    }
}
