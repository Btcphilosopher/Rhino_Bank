package com.example.rhinooilspot.domain.model

data class CalculationStep(
    val stepName: String,
    val formulaSymbol: String,
    val inputValue: String,
    val impactUsdPerBbl: Double,
    val explanation: String
)

data class CalculationTrace(
    val title: String,
    val itemIdentifier: String,
    val category: String, // "CARGO_VALUATION", "PHYSICAL_DIFFERENTIAL", "REFINERY_MARGIN", "STORAGE_CARRY", "VOYAGE_NETBACK"
    val baseBenchmark: String,
    val baseBenchmarkPrice: Double,
    val finalCalculatedValue: Double,
    val finalUnit: String,
    val steps: List<CalculationStep>,
    val methodology: String,
    val modelVersion: String = "RHINO-SPOT-ENGINE-v3.7.2-JVM",
    val calculationTimestamp: String,
    val dataProvenance: PriceProvenance
)
