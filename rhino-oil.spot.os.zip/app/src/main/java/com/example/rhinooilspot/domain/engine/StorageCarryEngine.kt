package com.example.rhinooilspot.domain.engine

import com.example.rhinooilspot.domain.model.*

object StorageCarryEngine {

    fun generateForwardCurve(
        benchmarkId: String,
        benchmarkName: String,
        spotPrice: Double,
        baseStructure: CurveStructure = CurveStructure.BACKWARDATION
    ): ForwardCurve {
        val tenors = listOf(
            Pair("Spot (Prompt)", 0),
            Pair("M1 (Nov 26)", 1),
            Pair("M2 (Dec 26)", 2),
            Pair("M3 (Jan 27)", 3),
            Pair("M4 (Feb 27)", 4),
            Pair("M5 (Mar 27)", 5),
            Pair("M6 (Apr 27)", 6),
            Pair("M9 (Jul 27)", 9),
            Pair("M12 (Oct 27)", 12),
            Pair("M24 (Oct 28)", 24)
        )

        val points = tenors.map { (tenor, mOffset) ->
            if (mOffset == 0) {
                ForwardPoint(tenor, 0, spotPrice, 0.31, 0.0, 0.0)
            } else {
                val spread = when (baseStructure) {
                    CurveStructure.BACKWARDATION -> {
                        // Prices slope downward over time (prompt premium)
                        -0.35 * Math.pow(mOffset.toDouble(), 0.82)
                    }
                    CurveStructure.CONTANGO -> {
                        // Prices slope upward over time (future premium / carry)
                        0.42 * Math.pow(mOffset.toDouble(), 0.88)
                    }
                    CurveStructure.FLAT -> {
                        0.02 * mOffset
                    }
                }
                val price = spotPrice + spread
                val impliedCarry = (spread / spotPrice) * (12.0 / mOffset) * 100.0
                val pointChange = 0.28 - (mOffset * 0.03)

                ForwardPoint(tenor, mOffset, price, pointChange, spread, impliedCarry)
            }
        }

        val m1Price = points.find { it.monthOffset == 1 }?.price ?: (spotPrice - 0.35)
        val m2Price = points.find { it.monthOffset == 2 }?.price ?: (spotPrice - 0.65)
        val m1M2Spread = m1Price - m2Price

        return ForwardCurve(
            benchmarkId = benchmarkId,
            benchmarkName = benchmarkName,
            points = points,
            structure = baseStructure,
            promptCalendarSpread = m1M2Spread
        )
    }

    fun calculateStorageArbitrage(
        terminal: StorageTerminal,
        spotPrice: Double,
        forwardPrice: Double,
        monthsDuration: Int = 6,
        sofrRateAnnualPct: Double = 5.25,
        financingSpreadPct: Double = 1.75
    ): StorageCarryCalculation {
        val forwardSpread = forwardPrice - spotPrice // e.g. M6 - Spot

        // Tank rental over full storage period
        val totalTankRent = terminal.tankMonthlyRentalUsdPerBbl * monthsDuration

        // Financing cost of physical inventory capital tied up
        val totalAnnualFinancingRate = (sofrRateAnnualPct + financingSpreadPct) / 100.0
        val financingCost = spotPrice * totalAnnualFinancingRate * (monthsDuration / 12.0)

        // Pump in / pump out throughput fee
        val pumpCost = terminal.pumpInOutCostUsdPerBbl * 2.0 // in + out

        // Insurance & volatile evaporation loss
        val insuranceAndLoss = spotPrice * (terminal.lossAndDegradationPctPerMo / 100.0) * monthsDuration

        val totalCostOfCarry = totalTankRent + financingCost + pumpCost + insuranceAndLoss
        val netArbitrageProfit = forwardSpread - totalCostOfCarry
        val annualisedReturn = if (spotPrice > 0) (netArbitrageProfit / spotPrice) * (12.0 / monthsDuration) * 100.0 else 0.0

        val isFeasible = netArbitrageProfit > 0.0

        return StorageCarryCalculation(
            terminalName = "${terminal.name} (${terminal.hubName})",
            spotPrice = spotPrice,
            forwardPrice = forwardPrice,
            monthsDuration = monthsDuration,
            forwardSpread = forwardSpread,
            totalTankRentalCost = totalTankRent,
            financingCostUsd = financingCost,
            throughputAndPumpFees = pumpCost,
            insuranceAndLossCost = insuranceAndLoss,
            totalCostOfCarry = totalCostOfCarry,
            netArbitrageProfitPerBbl = netArbitrageProfit,
            annualisedReturnPct = annualisedReturn,
            isArbitrageFeasible = isFeasible,
            provenance = PriceProvenance(
                ProvenanceStatus.MODELLED,
                "Rhino Storage Arbitrage Engine",
                "12:55 BST",
                "NetArb = (Forward - Spot) - [TankRent + Financing(SOFR) + PumpFees + Insurance/Loss]"
            )
        )
    }
}
