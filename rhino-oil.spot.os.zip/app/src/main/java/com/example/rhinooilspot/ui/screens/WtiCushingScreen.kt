package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.engine.AssayEngine
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.components.ProvenanceBadge
import com.example.rhinooilspot.ui.theme.*

@Composable
fun WtiCushingScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val benchmarks by viewModel.benchmarks.collectAsState()
    val hubBalances by viewModel.hubBalances.collectAsState()

    val wti = benchmarks.find { it.id == "WTI_CUSHING" }?.spotPrice ?: 74.91
    val brent = benchmarks.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
    val cushingHub = hubBalances.find { it.hubId == "HUB_CUSHING" }

    val usGrades = remember {
        listOf("WTI_CUSHING", "WTI_MIDLAND", "WTI_HOUSTON", "MARS", "LLS", "WCS").mapNotNull {
            AssayEngine.getGradeById(it)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Hero Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("wti_cushing_hero_card"),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermCyan.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "NORTH AMERICA PHYSICAL & PIPELINE COMPLEX",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermCyan, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "WTI & CUSHING HUB OS",
                                style = MaterialTheme.typography.headlineMedium.copy(color = TermWhite, fontWeight = FontWeight.Black)
                            )
                        }
                        ProvenanceBadge(PriceProvenance(ProvenanceStatus.PUBLISHED, "NYMEX / Argus USGC", "12:55 BST"))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${String.format("%.2f", wti)}/bbl",
                            style = MaterialTheme.typography.displayLarge.copy(color = TermCyan)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "WTI-Brent Spread: -$${String.format("%.2f", brent - wti)}/bbl",
                                style = MaterialTheme.typography.bodyLarge.copy(color = TermCrimsonBright, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Permian Basin → USGC Export Arb OPEN",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermEmeraldBright, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Cushing Inventory Balances
        if (cushingHub != null) {
            item {
                Text(
                    text = "CUSHING STORAGE TANK FARM UTILIZATION",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TermCardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Commercial Inventory: ${cushingHub.commercialInventoryMbbl} mbbl / ${cushingHub.totalCapacityMbbl} mbbl",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TermWhite, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${String.format("%.1f", cushingHub.utilizationPct)}% Full",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TermGoldBright, fontWeight = FontWeight.Bold)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Progress bar for tank utilization
                        LinearProgressIndicator(
                            progress = { (cushingHub.utilizationPct / 100f).toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = TermGold,
                            trackColor = TermBorder
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Weekly Change: ${cushingHub.weeklyChangeMbbl} mbbl (Draw)",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermEmeraldBright, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Days of Cover: ${cushingHub.daysOfDemandCover} days",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                            )
                        }
                    }
                }
            }

            // Section 3: Key Pipeline Inflow/Outflow Grid
            item {
                Text(
                    text = "CUSHING PIPELINE FLOW NETWORK",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
                )
            }

            items(cushingHub.pipelines) { pipe ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TermCardBg),
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = pipe.pipelineName,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                            )
                            Text(
                                text = "${pipe.origin} → ${pipe.destination} • Tariff: $${String.format("%.2f", pipe.tariffUsdPerBbl)}/bbl",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${pipe.currentFlowKbpd.toInt()} / ${pipe.capacityKbpd.toInt()} kb/d",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermCyan)
                            )
                            Text(
                                text = "${String.format("%.1f", pipe.utilizationPct)}% Cap",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                            )
                        }
                    }
                }
            }
        }

        // Section 4: US Crude Physical Differentials
        item {
            Text(
                text = "US CRUDE GRADES & REGIONAL DIFFERENTIALS",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        items(usGrades) { grade ->
            val diff = grade.baseDifferential
            val isPos = diff >= 0
            val diffColor = if (isPos) TermEmeraldBright else TermCrimsonBright
            val outright = (if (grade.benchmarkRef.contains("Brent")) brent else wti) + diff

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.inspectCrudeDifferential(grade) }
                    .testTag("us_grade_${grade.id}"),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = grade.name,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                        )
                        Text(
                            text = "${if (isPos) "+" else ""}${String.format("%.2f", diff)} vs ${grade.benchmarkRef}",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = diffColor)
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "API: ${grade.assay.apiGravity}° • S: ${grade.assay.sulfurWtPct}%",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                        )
                        Text(
                            text = "Outright: $${String.format("%.2f", outright)}/bbl",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermWhite, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}
