package com.example.rhinooilspot.domain.model

data class BenchmarkPrice(
    val id: String,
    val name: String,
    val symbol: String,
    val spotPrice: Double,
    val change: Double,
    val changePct: Double,
    val high: Double,
    val low: Double,
    val volume: String,
    val currency: Currency = Currency.USD,
    val provenance: PriceProvenance,
    val unit: String = "$/bbl"
)

enum class QuoteType {
    BID,
    OFFER,
    MID,
    TRADE,
    ASSESSMENT,
    INDICATION
}

data class PhysicalQuote(
    val id: String,
    val crudeGradeId: String,
    val crudeName: String,
    val type: QuoteType,
    val quantityBbl: Long,
    val benchmarkRef: String,
    val differential: Double,     // $/bbl over benchmark
    val outrightPrice: Double,    // Benchmark spot + differential
    val incoterm: Incoterm,
    val location: String,
    val loadingWindow: String,
    val seller: String,
    val buyer: String,
    val provenance: PriceProvenance
)

data class OrderBookLevel(
    val differential: Double,
    val volumeBbl: Long,
    val count: Int
)

data class PhysicalOrderBook(
    val crudeGradeId: String,
    val crudeName: String,
    val benchmarkRef: String,
    val benchmarkSpot: Double,
    val bids: List<OrderBookLevel>,
    val offers: List<OrderBookLevel>,
    val midDifferential: Double,
    val provenance: PriceProvenance
)

data class ForwardPoint(
    val tenor: String,       // "Spot", "M1 (Nov 26)", "M2 (Dec 26)", etc.
    val monthOffset: Int,
    val price: Double,
    val change: Double,
    val spreadVsPrompt: Double, // price - spot
    val impliedCarryPctPerAnnum: Double
)

data class ForwardCurve(
    val benchmarkId: String,
    val benchmarkName: String,
    val points: List<ForwardPoint>,
    val structure: CurveStructure, // CONTANGO or BACKWARDATION
    val promptCalendarSpread: Double // M1 - M2
)

enum class CurveStructure {
    CONTANGO,
    BACKWARDATION,
    FLAT
}

data class ProductPrice(
    val id: String,
    val name: String,
    val code: String,
    val spotPricePerBbl: Double,
    val change: Double,
    val region: Region,
    val densityKgPerL: Double = 0.75, // For $/bbl to $/tonne conversions
    val provenance: PriceProvenance
)

data class CrackSpread(
    val name: String,
    val productCode: String,
    val productName: String,
    val crudeBenchmarkRef: String,
    val ratioDescription: String, // e.g. "1:1 Diesel", "3:2:1 Refinery"
    val crackValuePerBbl: Double,
    val change: Double,
    val provenance: PriceProvenance
)
