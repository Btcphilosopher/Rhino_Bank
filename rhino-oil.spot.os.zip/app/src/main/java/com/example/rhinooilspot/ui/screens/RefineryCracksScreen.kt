package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.engine.RefineryEconomicsEngine
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.components.ProvenanceBadge
import com.example.rhinooilspot.ui.theme.*

@Composable
fun RefineryCracksScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val benchmarks by viewModel.benchmarks.collectAsState()
    val refineries by viewModel.refineries.collectAsState()
    val crackSpreads by viewModel.crackSpreads.collectAsState()

    val brent = benchmarks.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42

    var selectedRefinery by remember { mutableStateOf(refineries.first()) }
    val runResult = remember(selectedRefinery, brent) {
        RefineryEconomicsEngine.evaluateRefineryRun(selectedRefinery, brent)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Refinery Selector Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                refineries.forEach { ref ->
                    val isSel = ref.id == selectedRefinery.id
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isSel) TermGold else TermCardBg)
                            .border(0.5.dp, if (isSel) TermGoldBright else TermBorder, RoundedCornerShape(3.dp))
                            .clickable { selectedRefinery = ref }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${ref.name} (${ref.type.label})",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) TermBlack else TermWhite
                            )
                        )
                    }
                }
            }
        }

        // Section 2: Margin Breakdown Hero Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.inspectRefineryMargin(selectedRefinery) }
                    .testTag("refinery_margin_hero_card"),
                colors = CardDefaults.cardColors(containerColor = TermCardBgElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermGold.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${selectedRefinery.name.uppercase()} ECONOMICS",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermGold, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "NET CASH REFINERY MARGIN",
                                style = MaterialTheme.typography.titleMedium.copy(color = TermWhite, fontWeight = FontWeight.Black)
                            )
                        }
                        ProvenanceBadge(runResult.provenance)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${String.format("%.2f", runResult.netRefineryMarginPerBbl)} /bbl",
                            style = MaterialTheme.typography.displayLarge.copy(color = TermEmeraldBright)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Daily Net Profit: $${String.format("%,.0f", runResult.dailyNetMarginUsd)}/day",
                                style = MaterialTheme.typography.bodyLarge.copy(color = TermGoldBright, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Throughput: ${String.format("%,d", selectedRefinery.throughputBpd)} bpd (${String.format("%.1f", selectedRefinery.utilizationPct)}% Cap)",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                            )
                        }
                    }

                    Divider(color = TermBorder, modifier = Modifier.padding(vertical = 8.dp))

                    // Step summary
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Gross Product Revenue: $${String.format("%.2f", runResult.totalProductRevenuePerBbl)}", style = MaterialTheme.typography.labelSmall.copy(color = TermWhite))
                        Text(text = "Feedstock Cost: -$${String.format("%.2f", runResult.crudeFeedstockCostPerBbl)}", style = MaterialTheme.typography.labelSmall.copy(color = TermCrimsonBright))
                        Text(text = "OpEx: -$${String.format("%.2f", runResult.variableOpexPerBbl)}", style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate))
                    }
                }
            }
        }

        // Section 3: Product Crack Spreads Monitor
        item {
            Text(
                text = "GLOBAL REFINED PRODUCT CRACK SPREADS",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        items(crackSpreads) { crack ->
            val isPos = crack.crackValuePerBbl >= 0
            val color = if (isPos) TermEmeraldBright else TermCrimsonBright

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = crack.name,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                        )
                        Text(
                            text = "${crack.productCode} vs ${crack.crudeBenchmarkRef} (${crack.ratioDescription})",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "$${String.format("%.2f", crack.crackValuePerBbl)} /bbl",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = color, fontSize = 16.sp)
                        )
                        Text(
                            text = "${if (crack.change >= 0) "+" else ""}${String.format("%.2f", crack.change)} Today",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                        )
                    }
                }
            }
        }

        // Section 4: Distillation Yields & Output Revenues
        item {
            Text(
                text = "REFINERY PRODUCT CUTS & REVENUE BREAKDOWN",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        items(runResult.yields) { y ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = y.product.name,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                        )
                        Text(
                            text = "Yield: ${String.format("%.1f", y.yieldVolPct)}% Vol • ${String.format("%,d", y.bpdVolume)} bpd",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "$${String.format("%.2f", y.pricePerBbl)} /bbl",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                        )
                        Text(
                            text = "Rev: $${String.format("%.2f", y.revenuePerBblCrude)} /bbl crude",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermEmeraldBright, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}
