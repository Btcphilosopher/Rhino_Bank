package com.example.rhinooilspot.domain.engine

import com.example.rhinooilspot.domain.model.*

object ScenarioPropagationEngine {

    val PRESET_SCENARIOS: List<MarketScenario> by lazy {
        listOf(
            MarketScenario(
                id = "SCENARIO_NORTH_SEA_OUTAGE",
                title = "North Sea Pipeline / Platform Outage (-500 kb/d)",
                category = "SUPPLY_OUTAGE",
                description = "Forties Pipeline System (FPS) unexpected compressor trip reducing North Sea prompt supply.",
                productionImpactKbpd = -500.0,
                durationDays = 21,
                affectedRegion = Region.NORTH_SEA,
                defaultImpact = ScenarioImpact(
                    datedBrentShiftUsd = 3.85,
                    wtiShiftUsd = 1.60,
                    dubaiShiftUsd = 1.95,
                    freightRateShiftPct = 8.5,
                    dieselCrackShiftUsd = 2.40,
                    gasolineCrackShiftUsd = 1.80,
                    refiningMarginShiftUsd = -1.10,
                    regionalInventoryChangePct = -7.2,
                    narrative = "Dated Brent physical differential surges +$1.45/bbl. North Sea prompt backwardation steepens sharply."
                )
            ),
            MarketScenario(
                id = "SCENARIO_HORMUZ_BOTTLENECK",
                title = "Strait of Hormuz Geopolitical Squeeze (-2.2 mb/d)",
                category = "GEOPOLITICAL",
                description = "Militant threats & tanker insurance surge around the Strait of Hormuz bottleneck.",
                productionImpactKbpd = -2200.0,
                durationDays = 45,
                affectedRegion = Region.MIDDLE_EAST,
                defaultImpact = ScenarioImpact(
                    datedBrentShiftUsd = 12.40,
                    wtiShiftUsd = 9.80,
                    dubaiShiftUsd = 14.20,
                    freightRateShiftPct = 65.0,
                    dieselCrackShiftUsd = 8.50,
                    gasolineCrackShiftUsd = 5.20,
                    refiningMarginShiftUsd = 4.30,
                    regionalInventoryChangePct = -14.5,
                    narrative = "VLCC TD3C spot freight spikes past WS 130. Middle East crude OSP differentials surge into Asia. Asian refiners aggressively bid Atlantic basin cargoes."
                )
            ),
            MarketScenario(
                id = "SCENARIO_PERMIAN_BOOM",
                title = "US Permian Pipeline Expansion Surge (+1.2 mb/d)",
                category = "DEMAND_SURGE",
                description = "New 1.2 mb/d deepwater Corpus Christi export corridor opens with low pipeline tariffs.",
                productionImpactKbpd = 1200.0,
                durationDays = 90,
                affectedRegion = Region.NORTH_AMERICA,
                defaultImpact = ScenarioImpact(
                    datedBrentShiftUsd = -2.75,
                    wtiShiftUsd = -4.10,
                    dubaiShiftUsd = -1.80,
                    freightRateShiftPct = 12.0,
                    dieselCrackShiftUsd = -1.20,
                    gasolineCrackShiftUsd = -0.90,
                    refiningMarginShiftUsd = 1.85,
                    regionalInventoryChangePct = 8.4,
                    narrative = "WTI-Brent spread widens to -$5.80/bbl. USGC crude export arbitrage wide open to Rotterdam and Ningbo."
                )
            ),
            MarketScenario(
                id = "SCENARIO_EUROPE_REFINERY_FIRE",
                title = "European Mega-Refinery Outage (-450 kb/d Runs)",
                category = "SUPPLY_OUTAGE",
                description = "Unplanned CDU / FCC explosion at major NWE refinery shutting crude intake.",
                productionImpactKbpd = 0.0,
                durationDays = 30,
                affectedRegion = Region.NORTH_SEA,
                defaultImpact = ScenarioImpact(
                    datedBrentShiftUsd = -1.40,
                    wtiShiftUsd = -0.60,
                    dubaiShiftUsd = -0.40,
                    freightRateShiftPct = -5.0,
                    dieselCrackShiftUsd = 6.20,
                    gasolineCrackShiftUsd = 4.80,
                    refiningMarginShiftUsd = 5.60,
                    regionalInventoryChangePct = 4.5,
                    narrative = "Regional crude demand drops causing local crude differentials to weaken, while refined product cracks surge due to fuel supply deficit."
                )
            ),
            MarketScenario(
                id = "SCENARIO_GULF_HURRICANE",
                title = "Category 4 Hurricane in Gulf of Mexico",
                category = "WEATHER",
                description = "Severe hurricane shutting offshore GOM platforms, LOOP offshore terminal, and Houston refineries.",
                productionImpactKbpd = -1400.0,
                durationDays = 14,
                affectedRegion = Region.NORTH_AMERICA,
                defaultImpact = ScenarioImpact(
                    datedBrentShiftUsd = 4.20,
                    wtiShiftUsd = 5.80,
                    dubaiShiftUsd = 2.10,
                    freightRateShiftPct = 18.0,
                    dieselCrackShiftUsd = 5.10,
                    gasolineCrackShiftUsd = 7.40,
                    refiningMarginShiftUsd = 3.90,
                    regionalInventoryChangePct = -6.0,
                    narrative = "USGC port closures, LOOP shut-in. Gasoline RBOB cracks skyrocket as US refining capacity temporarily curtails."
                )
            )
        )
    }
}
