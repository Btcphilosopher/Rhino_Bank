package com.example.rhinooilspot.domain.engine

import com.example.rhinooilspot.domain.model.*

object DifferentialEngine {

    fun calculateIndicativeDifferential(
        grade: CrudeGrade,
        benchmarkSpot: Double,
        loadingWindowDaysOut: Int = 14,
        freightAdjustmentUsd: Double = 0.0,
        inventoryTightnessScore: Double = 0.0 // -1.0 (glut) to +1.0 (tight)
    ): Pair<Double, CalculationTrace> {
        val assay = grade.assay

        // 1. API Gravity value differential: Benchmark base is 38 API
        val apiDiff = assay.apiGravity - 38.0
        val apiImpact = (apiDiff * 0.08).coerceIn(-2.5, 1.2) // heavy penalty vs light bonus

        // 2. Sulfur penalty: Benchmark base is 0.40% S
        val sulfurDiff = assay.sulfurWtPct - 0.40
        val sulfurImpact = -(sulfurDiff * 1.65) // sour crude sulfur desulfurization penalty

        // 3. TAN / Acidity penalty (if TAN > 0.5 mg KOH/g metallurgy corrosion penalty)
        val tanImpact = if (assay.tanMgKohPerG > 0.5) -(assay.tanMgKohPerG - 0.5) * 0.90 else 0.0

        // 4. Heavy Metals penalty (Nickel + Vanadium ppm)
        val metalPpm = assay.nickelPpm + assay.vanadiumPpm
        val metalImpact = if (metalPpm > 30.0) -(metalPpm - 30.0) * 0.015 else 0.0

        // 5. Prompt loading window premium / discount
        val windowImpact = if (loadingWindowDaysOut <= 10) 0.15 else if (loadingWindowDaysOut > 25) -0.10 else 0.0

        // 6. Regional market supply/inventory tightness
        val inventoryImpact = inventoryTightnessScore * 0.45

        // 7. Base historical grade premium / discount
        val baseGradeDiff = grade.baseDifferential

        // Total calculated physical differential
        val totalCalculatedDiff = baseGradeDiff + (apiImpact * 0.3) + (sulfurImpact * 0.3) + tanImpact + metalImpact + windowImpact + inventoryImpact + freightAdjustmentUsd
        val outrightPhysicalPrice = benchmarkSpot + totalCalculatedDiff

        val steps = listOf(
            CalculationStep(
                stepName = "Benchmark Base Spot",
                formulaSymbol = "P_base",
                inputValue = "${grade.benchmarkRef} @ $$benchmarkSpot/bbl",
                impactUsdPerBbl = benchmarkSpot,
                explanation = "Live prompt published benchmark marker"
            ),
            CalculationStep(
                stepName = "Base Grade Historical Differential",
                formulaSymbol = "Δ_grade",
                inputValue = "${String.format("%.2f", baseGradeDiff)} $/bbl",
                impactUsdPerBbl = baseGradeDiff,
                explanation = "Standard physical contractual spread vs ${grade.benchmarkRef}"
            ),
            CalculationStep(
                stepName = "Assay API Gravity Adjustment",
                formulaSymbol = "Δ_API",
                inputValue = "${assay.apiGravity}° API (Ref 38.0°)",
                impactUsdPerBbl = apiImpact * 0.3,
                explanation = "Yield uplift for lighter distillation fractions"
            ),
            CalculationStep(
                stepName = "Sulfur Desulfurization Penalty",
                formulaSymbol = "Δ_S",
                inputValue = "${assay.sulfurWtPct}% wt S (Ref 0.40%)",
                impactUsdPerBbl = sulfurImpact * 0.3,
                explanation = "Hydrotreater hydrogen consumption and sweetening cost"
            ),
            CalculationStep(
                stepName = "Acidity & Heavy Metals Penalty",
                formulaSymbol = "Δ_TAN+Metals",
                inputValue = "TAN ${assay.tanMgKohPerG} mg KOH/g, ${metalPpm.toInt()} ppm Ni+V",
                impactUsdPerBbl = tanImpact + metalImpact,
                explanation = "Metallurgy metallurgy corrosion & catalyst poisoning deduction"
            ),
            CalculationStep(
                stepName = "Loading Window Timing",
                formulaSymbol = "Δ_window",
                inputValue = "$loadingWindowDaysOut days out",
                impactUsdPerBbl = windowImpact,
                explanation = "Prompt cargo promptness / laycan tightness"
            ),
            CalculationStep(
                stepName = "Regional Supply Tightness & Logistics",
                formulaSymbol = "Δ_tightness+freight",
                inputValue = "Tightness: $inventoryTightnessScore, Freight adj: $freightAdjustmentUsd",
                impactUsdPerBbl = inventoryImpact + freightAdjustmentUsd,
                explanation = "Regional tank utilization and export arb pull"
            )
        )

        val trace = CalculationTrace(
            title = "${grade.name} Physical Differential",
            itemIdentifier = grade.id,
            category = "PHYSICAL_DIFFERENTIAL",
            baseBenchmark = grade.benchmarkRef,
            baseBenchmarkPrice = benchmarkSpot,
            finalCalculatedValue = totalCalculatedDiff,
            finalUnit = "$/bbl",
            steps = steps,
            methodology = "Physical Differential Engine (Assay Yield + Logistics Netback v3.7)",
            calculationTimestamp = "2026-09-23 12:55:00 BST",
            dataProvenance = PriceProvenance(
                status = ProvenanceStatus.MODELLED,
                source = "Rhino Spot Differential Engine",
                timestamp = "2026-09-23 12:55:00 BST",
                methodology = "API/Sulfur yield netback + laycan tightness regression",
                confidence = 0.96,
                auditFormula = "Diff = BaseDiff + 0.3*ΔAPI + 0.3*ΔS + ΔTAN + ΔMetals + ΔWindow + ΔInventory + ΔFreight"
            )
        )

        return Pair(totalCalculatedDiff, trace)
    }
}
