package com.example.rhinooilspot.data

import kotlinx.coroutines.*
import kotlin.random.Random

class OilMarketSimulator(
    private val repository: MarketRepository,
    private val scope: CoroutineScope
) {
    private var job: Job? = null
    private val random = Random(2037)

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(2200L + random.nextLong(1200L))

                // 1. Tick benchmark prices slightly (+- $0.02 to $0.08)
                val targetId = when (random.nextInt(4)) {
                    0 -> "DATED_BRENT"
                    1 -> "WTI_CUSHING"
                    2 -> "DUBAI"
                    else -> "BRENT_M1"
                }
                val delta = (random.nextDouble(-0.06, 0.07) * 100.0).toInt() / 100.0
                if (delta != 0.0) {
                    repository.updateBenchmarkPrice(targetId, delta)
                }

                // 2. Occasionally add realistic market news
                if (random.nextInt(12) == 0) {
                    val headlines = listOf(
                        "North Sea loading program: 12 cargoes scheduled for November laycan.",
                        "ARA commercial crude stock draws 420k bbl over the last 48 hours.",
                        "VLCC spot rates on TD3C fixed at WS 63.0 (+0.5) by Asian refiner.",
                        "Singapore bunker demand for VLSFO 0.5% picks up ahead of month-end replenishment.",
                        "Permian Basin pipeline flows to Houston running at 94% nominal capacity."
                    )
                    val selectedHeadline = headlines[random.nextInt(headlines.size)]
                    repository.addNews(
                        MarketNewsItem(
                            id = "SIM_${System.currentTimeMillis()}",
                            time = "12:55 BST",
                            headline = selectedHeadline,
                            source = "Rhino Event Simulator",
                            category = "TICKER",
                            impact = "Simulated real-time liquidity and logistics event."
                        )
                    )
                }
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }
}
