package com.example.rhinooilspot.domain.engine

import com.example.rhinooilspot.domain.model.*

object FreightAndVoyageEngine {

    val PORTS_DATABASE: List<Port> by lazy {
        listOf(
            Port("PORT_SULLOM_VOE", "Sullom Voe Terminal", "GBSVE", "United Kingdom", Region.NORTH_SEA, 60.45f, -1.28f, 24.0, true, 95_000.0),
            Port("PORT_HOUND_POINT", "Hound Point (Forth)", "GBHPT", "United Kingdom", Region.NORTH_SEA, 56.00f, -3.37f, 21.5, true, 85_000.0),
            Port("PORT_STURE", "Sture Terminal", "NOSTU", "Norway", Region.NORTH_SEA, 60.61f, 4.85f, 22.0, true, 90_000.0),
            Port("PORT_ROTTERDAM", "Port of Rotterdam", "NLRTM", "Netherlands", Region.NORTH_SEA, 51.92f, 4.47f, 24.0, true, 140_000.0),
            Port("PORT_HOUSTON", "Houston Ship Channel", "USHOU", "United States", Region.NORTH_AMERICA, 29.76f, -95.36f, 15.5, false, 125_000.0),
            Port("PORT_CORPUS_CHRISTI", "Port of Corpus Christi", "USCRP", "United States", Region.NORTH_AMERICA, 27.80f, -97.39f, 16.5, false, 110_000.0),
            Port("PORT_LOOP", "LOOP Offshore Port", "USLOP", "United States", Region.NORTH_AMERICA, 28.88f, -90.02f, 30.0, true, 180_000.0),
            Port("PORT_RAS_TANURA", "Ras Tanura Terminal", "SARAS", "Saudi Arabia", Region.MIDDLE_EAST, 26.64f, 50.16f, 28.0, true, 160_000.0),
            Port("PORT_FUJAIRAH", "Port of Fujairah", "AEFJR", "United Arab Emirates", Region.MIDDLE_EAST, 25.18f, 56.36f, 26.0, true, 150_000.0),
            Port("PORT_BONNY", "Bonny Offshore Terminal", "NGBON", "Nigeria", Region.WEST_AFRICA, 4.43f, 7.16f, 23.0, true, 130_000.0),
            Port("PORT_SANTOS", "Santos / Angra dos Reis", "BRSSZ", "Brazil", Region.LATIN_AMERICA, -23.96f, -46.33f, 22.0, true, 140_000.0),
            Port("PORT_SINGAPORE", "Port of Singapore", "SGSIN", "Singapore", Region.ASIA_PACIFIC, 1.29f, 103.85f, 24.0, true, 135_000.0),
            Port("PORT_NINGBO", "Port of Ningbo-Zhoushan", "CNNGB", "China", Region.ASIA_PACIFIC, 29.86f, 121.54f, 25.0, true, 145_000.0),
            Port("PORT_CHIBA", "Port of Chiba / Tokyo Bay", "JPCHB", "Japan", Region.ASIA_PACIFIC, 35.60f, 140.10f, 24.0, true, 155_000.0),
            Port("PORT_AUGUSTA", "Port of Augusta (Sicily)", "ITAUG", "Italy", Region.NORTH_AFRICA, 37.23f, 15.22f, 20.0, true, 105_000.0)
        )
    }

    val FREIGHT_BENCHMARKS: List<FreightRoute> by lazy {
        val rasTanura = PORTS_DATABASE.first { it.id == "PORT_RAS_TANURA" }
        val ningbo = PORTS_DATABASE.first { it.id == "PORT_NINGBO" }
        val bonny = PORTS_DATABASE.first { it.id == "PORT_BONNY" }
        val rotterdam = PORTS_DATABASE.first { it.id == "PORT_ROTTERDAM" }
        val houndPoint = PORTS_DATABASE.first { it.id == "PORT_HOUND_POINT" }
        val corpus = PORTS_DATABASE.first { it.id == "PORT_CORPUS_CHRISTI" }

        val prov = PriceProvenance(ProvenanceStatus.PUBLISHED, "Baltic Exchange / Clarkson", "12:50 BST")

        listOf(
            FreightRoute(
                id = "FR_TD3C",
                code = "TD3C",
                name = "Middle East Gulf (Ras Tanura) to China (Ningbo) VLCC 270k mt",
                vesselClass = VesselClass.VLCC,
                originPort = rasTanura,
                destinationPort = ningbo,
                distanceNauticalMiles = 6200.0,
                worldscaleRate = 62.5,
                flatRateUsdPerTonne = 19.80,
                marketRateUsdPerTonne = (62.5 * 19.80) / 100.0, // $12.38/t
                rateUsdPerBbl = ((62.5 * 19.80) / 100.0) / 7.33, // ~$1.69/bbl
                change = 1.8,
                provenance = prov
            ),
            FreightRoute(
                id = "FR_TD20",
                code = "TD20",
                name = "West Africa (Bonny) to UK Continent (Rotterdam) Suezmax 130k mt",
                vesselClass = VesselClass.SUEZMAX,
                originPort = bonny,
                destinationPort = rotterdam,
                distanceNauticalMiles = 4300.0,
                worldscaleRate = 88.0,
                flatRateUsdPerTonne = 15.60,
                marketRateUsdPerTonne = (88.0 * 15.60) / 100.0,
                rateUsdPerBbl = ((88.0 * 15.60) / 100.0) / 7.33,
                change = -0.7,
                provenance = prov
            ),
            FreightRoute(
                id = "FR_TD7",
                code = "TD7",
                name = "North Sea (Hound Point) to UK Continent (Rotterdam) Aframax 80k mt",
                vesselClass = VesselClass.AFRAMAX,
                originPort = houndPoint,
                destinationPort = rotterdam,
                distanceNauticalMiles = 460.0,
                worldscaleRate = 125.0,
                flatRateUsdPerTonne = 6.40,
                marketRateUsdPerTonne = (125.0 * 6.40) / 100.0,
                rateUsdPerBbl = ((125.0 * 6.40) / 100.0) / 7.33, // ~$1.09/bbl
                change = 3.2,
                provenance = prov
            ),
            FreightRoute(
                id = "FR_USGC_NWE",
                code = "TC_USGC_NWE",
                name = "US Gulf Coast (Corpus Christi) to Rotterdam Aframax 70k mt",
                vesselClass = VesselClass.AFRAMAX,
                originPort = corpus,
                destinationPort = rotterdam,
                distanceNauticalMiles = 5100.0,
                worldscaleRate = 145.0,
                flatRateUsdPerTonne = 14.20,
                marketRateUsdPerTonne = (145.0 * 14.20) / 100.0,
                rateUsdPerBbl = ((145.0 * 14.20) / 100.0) / 7.33, // ~$2.81/bbl
                change = -1.2,
                provenance = prov
            )
        )
    }

    fun calculateVoyageEconomics(
        cargoSizeBbl: Long,
        grade: CrudeGrade,
        originPort: Port,
        destinationPort: Port,
        vesselClass: VesselClass = VesselClass.AFRAMAX,
        bunkerFuelPricePerTonne: Double = 580.0,
        dailyDemurrageUsd: Double = 35_000.0,
        fobPricePerBbl: Double = 78.42
    ): VoyageCalculation {
        // Approximate nautical miles calculation based on port coordinates
        val dLat = Math.abs(destinationPort.lat - originPort.lat)
        val dLng = Math.abs(destinationPort.lng - originPort.lng)
        val distanceNm = (Math.sqrt((dLat * dLat + dLng * dLng).toDouble()) * 60.0 * 1.35).coerceAtLeast(350.0)

        val vesselSpeedKnots = 13.5
        val seaDays = (distanceNm / (vesselSpeedKnots * 24.0)) + 0.5
        val portDays = 3.0 // 1.5 days load + 1.5 days discharge
        val totalDays = seaDays + portDays

        val dailyBunkerTons = when (vesselClass) {
            VesselClass.VLCC -> 52.0
            VesselClass.SUEZMAX -> 38.0
            VesselClass.AFRAMAX -> 28.0
            else -> 22.0
        }
        val dailyCharterRateUsd = when (vesselClass) {
            VesselClass.VLCC -> 48_000.0
            VesselClass.SUEZMAX -> 34_000.0
            VesselClass.AFRAMAX -> 26_000.0
            else -> 19_000.0
        }

        val totalBunkerCost = (seaDays * dailyBunkerTons * bunkerFuelPricePerTonne) + (portDays * 4.0 * bunkerFuelPricePerTonne)
        val charterHireCost = totalDays * dailyCharterRateUsd
        val portCosts = originPort.portChargesUsd + destinationPort.portChargesUsd
        val insuranceCost = cargoSizeBbl * fobPricePerBbl * 0.0015 // 0.15% cargo transit insurance

        val totalVoyageCost = totalBunkerCost + charterHireCost + portCosts + insuranceCost
        val freightPerBbl = totalVoyageCost / cargoSizeBbl.toDouble()
        val cifDeliveredPrice = fobPricePerBbl + freightPerBbl

        // Destination value: benchmark at destination + grade differential
        val destRefineryValue = cifDeliveredPrice + 1.40 // Indicative gross margin
        val netback = destRefineryValue - freightPerBbl - (portCosts / cargoSizeBbl)

        val prov = PriceProvenance(ProvenanceStatus.MODELLED, "Rhino Voyage Economics Engine v3.7", "12:55 BST")

        return VoyageCalculation(
            cargoSizeBbl = cargoSizeBbl,
            cargoGrade = grade,
            originPort = originPort,
            destinationPort = destinationPort,
            vesselClass = vesselClass,
            distanceNm = distanceNm,
            seaDays = seaDays,
            portDays = portDays,
            totalDays = totalDays,
            bunkerFuelPricePerTonne = bunkerFuelPricePerTonne,
            totalBunkerCostUsd = totalBunkerCost,
            charterHireCostUsd = charterHireCost,
            portCostUsd = portCosts,
            insuranceCostUsd = insuranceCost,
            demurrageRatePerDayUsd = dailyDemurrageUsd,
            totalVoyageCostUsd = totalVoyageCost,
            freightCostPerBbl = freightPerBbl,
            fobCrudePrice = fobPricePerBbl,
            cifDeliveredPrice = cifDeliveredPrice,
            destinationRefineryValue = destRefineryValue,
            indicativeNetback = netback,
            provenance = prov
        )
    }

    fun calculatePhysicalArbitrage(
        grade: CrudeGrade,
        originFobPrice: Double,
        destinationBenchmarkPrice: Double,
        freightCostPerBbl: Double,
        portAndTerminalPerBbl: Double = 0.28,
        insurancePerBbl: Double = 0.12
    ): ArbitrageResult {
        val totalDelivered = originFobPrice + freightCostPerBbl + portAndTerminalPerBbl + insurancePerBbl
        val arbDiff = destinationBenchmarkPrice - totalDelivered
        val isProfitable = arbDiff > 0.0

        return ArbitrageResult(
            crudeGrade = grade,
            originMarketName = "${grade.loadingTerminal} (FOB)",
            originFobPrice = originFobPrice,
            destinationMarketName = "Rotterdam / NWE (CIF)",
            freightCostPerBbl = freightCostPerBbl,
            portAndTerminalPerBbl = portAndTerminalPerBbl,
            insuranceAndLossPerBbl = insurancePerBbl,
            deliveredCostPerBbl = totalDelivered,
            destinationRefineryBenchmark = destinationBenchmarkPrice,
            arbitrageDifferential = arbDiff,
            isProfitable = isProfitable,
            provenance = PriceProvenance(
                ProvenanceStatus.MODELLED,
                "Rhino Physical Arbitrage Engine",
                "12:55 BST",
                "Arb = DestBenchmark - (OriginFOB + Freight + Port + Insurance)"
            )
        )
    }
}
