package com.example.rhinooilspot.domain.engine

import com.example.rhinooilspot.domain.model.*

object HubAndBalanceEngine {

    val STORAGE_TERMINALS: List<StorageTerminal> by lazy {
        listOf(
            StorageTerminal("TERM_CUSHING_ENBRIDGE", "Enbridge Cushing Terminal", "Cushing Hub, OK", Region.NORTH_AMERICA, 26.0, 18.2, 0.42, 0.06),
            StorageTerminal("TERM_CUSHING_ENTERPRISE", "Enterprise Cushing Terminal", "Cushing Hub, OK", Region.NORTH_AMERICA, 19.5, 14.1, 0.45, 0.07),
            StorageTerminal("TERM_CUSHING_PLAINS", "Plains All American Cushing", "Cushing Hub, OK", Region.NORTH_AMERICA, 24.0, 17.5, 0.40, 0.06),
            StorageTerminal("TERM_ROTTERDAM_VOPAK", "Vopak Terminal Europoort", "Rotterdam", Region.NORTH_SEA, 28.5, 23.1, 0.55, 0.09),
            StorageTerminal("TERM_SINGAPORE_JURONG", "Jurong Port Tank Terminals", "Singapore", Region.ASIA_PACIFIC, 22.0, 16.8, 0.50, 0.08),
            StorageTerminal("TERM_FUJAIRAH_VTTI", "VTTI Fujairah Terminal", "Fujairah", Region.MIDDLE_EAST, 16.0, 11.2, 0.38, 0.06),
            StorageTerminal("TERM_SALDANHA_BAY", "Saldanha Bay Strategic Tank Farm", "South Africa", Region.WEST_AFRICA, 45.0, 31.5, 0.32, 0.05)
        )
    }

    val GLOBAL_HUB_BALANCES: List<HubBalance> by lazy {
        val prov = PriceProvenance(ProvenanceStatus.PUBLISHED, "EIA / IEA / Rhino Analytics", "12:45 BST")

        listOf(
            HubBalance(
                hubId = "HUB_CUSHING",
                hubName = "Cushing Oklahoma Delivery Hub",
                location = "Cushing, Oklahoma, USA",
                region = Region.NORTH_AMERICA,
                commercialInventoryMbbl = 38.4,
                strategicInventoryMbbl = 0.0,
                floatingStorageMbbl = 0.0,
                refineryStorageMbbl = 6.2,
                totalCapacityMbbl = 78.0,
                weeklyChangeMbbl = -0.85,
                daysOfDemandCover = 22.4,
                inboundFlowKbpd = 2850.0,
                outboundFlowKbpd = 2970.0,
                pipelines = listOf(
                    PipelineFlow("Basin Pipeline (Permian to Cushing)", "Wink, TX", "Cushing, OK", 450.0, 410.0, 1.45),
                    PipelineFlow("Centurion Pipeline (Permian to Cushing)", "Midland, TX", "Cushing, OK", 300.0, 280.0, 1.35),
                    PipelineFlow("Seaway Pipeline (Cushing to Freeport USGC)", "Cushing, OK", "Freeport, TX", 850.0, 810.0, 2.10),
                    PipelineFlow("Marketlink Pipeline (Cushing to Port Arthur)", "Cushing, OK", "Port Arthur, TX", 750.0, 720.0, 2.25)
                ),
                provenance = prov
            ),
            HubBalance(
                hubId = "HUB_ROTTERDAM",
                hubName = "Rotterdam / ARA Hub (Amsterdam-Rotterdam-Antwerp)",
                location = "Rotterdam Port & Europoort",
                region = Region.NORTH_SEA,
                commercialInventoryMbbl = 52.6,
                strategicInventoryMbbl = 18.0,
                floatingStorageMbbl = 4.5,
                refineryStorageMbbl = 14.2,
                totalCapacityMbbl = 110.0,
                weeklyChangeMbbl = 1.10,
                daysOfDemandCover = 36.8,
                inboundFlowKbpd = 1850.0,
                outboundFlowKbpd = 1720.0,
                pipelines = listOf(
                    PipelineFlow("RRP (Rotterdam-Rhein Pipeline to Germany)", "Rotterdam, NL", "Cologne, DE", 400.0, 360.0, 0.95),
                    PipelineFlow("RAPL (Rotterdam-Antwerp Pipeline)", "Rotterdam, NL", "Antwerp, BE", 300.0, 275.0, 0.75)
                ),
                provenance = prov
            ),
            HubBalance(
                hubId = "HUB_SINGAPORE",
                hubName = "Singapore / Malacca Strait Storage Hub",
                location = "Jurong Island & Malacca Strait",
                region = Region.ASIA_PACIFIC,
                commercialInventoryMbbl = 44.8,
                strategicInventoryMbbl = 0.0,
                floatingStorageMbbl = 8.2, // VLCC floating storage in Malacca Strait
                refineryStorageMbbl = 12.5,
                totalCapacityMbbl = 85.0,
                weeklyChangeMbbl = -0.40,
                daysOfDemandCover = 28.5,
                inboundFlowKbpd = 2400.0,
                outboundFlowKbpd = 2450.0,
                pipelines = listOf(
                    PipelineFlow("Jurong Island Subsea Terminal Grid", "Bukom", "Jurong Island", 500.0, 480.0, 0.40)
                ),
                provenance = prov
            )
        )
    }
}
