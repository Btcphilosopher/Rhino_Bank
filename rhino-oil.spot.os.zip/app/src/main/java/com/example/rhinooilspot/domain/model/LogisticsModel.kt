package com.example.rhinooilspot.domain.model

enum class CargoStatus {
    OFFER,
    BID,
    FIXED,
    LOADING,
    ON_WATER,
    DISCHARGING,
    COMPLETED
}

data class Port(
    val id: String,
    val name: String,
    val code: String,
    val country: String,
    val region: Region,
    val lat: Float,
    val lng: Float,
    val maxDraftMeters: Double = 22.0,
    val acceptsVlcc: Boolean = true,
    val portChargesUsd: Double = 120_000.0
)

data class Vessel(
    val id: String,
    val name: String,
    val imo: String,
    val vesselClass: VesselClass,
    val flag: String,
    val builtYear: Int,
    val speedKnots: Double = 13.5,
    val bunkerConsumptionTonsPerDay: Double = 42.0,
    val currentLat: Float,
    val currentLng: Float,
    val headingDeg: Float = 0f,
    val destinationPort: String = "",
    val eta: String = ""
)

data class FreightRoute(
    val id: String,
    val code: String,            // e.g. "TD3C", "TD20", "TD6", "TC14"
    val name: String,            // e.g. "Arabian Gulf to China (VLCC)"
    val vesselClass: VesselClass,
    val originPort: Port,
    val destinationPort: Port,
    val distanceNauticalMiles: Double,
    val worldscaleRate: Double,  // e.g. WS 62.5
    val flatRateUsdPerTonne: Double, // Worldscale base flat rate
    val marketRateUsdPerTonne: Double, // ws * flat / 100
    val rateUsdPerBbl: Double,   // $/bbl
    val change: Double,
    val provenance: PriceProvenance
)

data class Cargo(
    val id: String,
    val grade: CrudeGrade,
    val quantityBbl: Long,
    val seller: String,
    val buyer: String,
    val loadPort: Port,
    val dischargePort: Port,
    val loadingWindow: String,
    val deliveryWindow: String,
    val incoterm: Incoterm,
    val benchmarkBasis: String,
    val differential: Double,     // $/bbl over benchmark
    val outrightDeliveredPrice: Double,
    val vessel: Vessel?,
    val status: CargoStatus,
    val provenance: PriceProvenance
)

data class VoyageCalculation(
    val cargoSizeBbl: Long,
    val cargoGrade: CrudeGrade,
    val originPort: Port,
    val destinationPort: Port,
    val vesselClass: VesselClass,
    val distanceNm: Double,
    val seaDays: Double,
    val portDays: Double,
    val totalDays: Double,
    val bunkerFuelPricePerTonne: Double,
    val totalBunkerCostUsd: Double,
    val charterHireCostUsd: Double,
    val portCostUsd: Double,
    val insuranceCostUsd: Double,
    val demurrageRatePerDayUsd: Double,
    val totalVoyageCostUsd: Double,
    val freightCostPerBbl: Double,
    val fobCrudePrice: Double,
    val cifDeliveredPrice: Double,
    val destinationRefineryValue: Double,
    val indicativeNetback: Double,
    val provenance: PriceProvenance
)

data class ArbitrageResult(
    val crudeGrade: CrudeGrade,
    val originMarketName: String,
    val originFobPrice: Double,
    val destinationMarketName: String,
    val freightCostPerBbl: Double,
    val portAndTerminalPerBbl: Double,
    val insuranceAndLossPerBbl: Double,
    val deliveredCostPerBbl: Double,
    val destinationRefineryBenchmark: Double,
    val arbitrageDifferential: Double, // destinationRefineryBenchmark - deliveredCost
    val isProfitable: Boolean,
    val provenance: PriceProvenance
)
