package com.example.rhinooilspot.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.data.MarketNewsItem
import com.example.rhinooilspot.domain.engine.FreightAndVoyageEngine
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.ScreenTab
import com.example.rhinooilspot.ui.components.ProvenanceBadge
import com.example.rhinooilspot.ui.theme.*

@Composable
fun OilNowScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val benchmarks by viewModel.benchmarks.collectAsState()
    val cargoes by viewModel.cargoes.collectAsState()
    val newsStream by viewModel.newsStream.collectAsState()
    val crackSpreads by viewModel.crackSpreads.collectAsState()

    val brent = benchmarks.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
    val wti = benchmarks.find { it.id == "WTI_CUSHING" }?.spotPrice ?: 74.91
    val dubai = benchmarks.find { it.id == "DUBAI" }?.spotPrice ?: 76.18
    val brentM1 = benchmarks.find { it.id == "BRENT_M1" }?.spotPrice ?: 78.55
    val brentM2 = benchmarks.find { it.id == "BRENT_M2" }?.spotPrice ?: 78.88

    val m1M2Spread = brentM1 - brentM2
    val wtiBrentSpread = wti - brent
    val dubaiBrentSpread = dubai - brent

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Top Benchmark Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Dated Brent
                BenchmarkCard(
                    title = "Dated Brent (BFOET)",
                    symbol = "DATED",
                    price = brent,
                    change = 0.31,
                    unit = "$/bbl",
                    provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "Platts / Argus", "12:55 BST"),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectTab(ScreenTab.BRENT_COMPLEX) }
                )
                // WTI Cushing
                BenchmarkCard(
                    title = "WTI Cushing (CL)",
                    symbol = "WTI",
                    price = wti,
                    change = 0.22,
                    unit = "$/bbl",
                    provenance = PriceProvenance(ProvenanceStatus.PUBLISHED, "NYMEX / ICE", "12:55 BST"),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectTab(ScreenTab.WTI_CUSHING) }
                )
                // Dubai Crude
                BenchmarkCard(
                    title = "Dubai Assessment",
                    symbol = "DUBAI",
                    price = dubai,
                    change = 0.14,
                    unit = "$/bbl",
                    provenance = PriceProvenance(ProvenanceStatus.ASSESSED, "Platts Asia", "12:55 BST"),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectTab(ScreenTab.STORAGE_HUBS) }
                )
            }
        }

        // Section 2: Spread Strip & Key Metrics
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TermCardBg)
                    .border(1.dp, TermBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SpreadMetricItem("Brent M1/M2", "${if (m1M2Spread >= 0) "+" else ""}${String.format("%.2f", m1M2Spread)}", TermGold)
                SpreadMetricItem("WTI-Brent", "${String.format("%.2f", wtiBrentSpread)}", TermCrimsonBright)
                SpreadMetricItem("Dubai-Brent", "${String.format("%.2f", dubaiBrentSpread)}", TermMutedSlate)
                SpreadMetricItem("TD3C Freight", "WS 62.5", TermCyan)
                SpreadMetricItem("3:2:1 Crack", "$16.85", TermEmeraldBright)
                SpreadMetricItem("Cushing Stock", "38.4 mbbl", TermWhite)
            }
        }

        // Section 3: Interactive World Physical Oil Flow Map
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .testTag("world_oil_flow_map"),
                colors = CardDefaults.cardColors(containerColor = TermBlack),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = null,
                                tint = TermGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "GLOBAL PHYSICAL OIL FLOW & TANKER ARBITRAGE MAP",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TermWhite,
                                    fontSize = 12.sp
                                )
                            )
                        }
                        Text(
                            text = "LIVE VESSEL TELEMETRY",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermEmeraldBright)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    WorldOilFlowCanvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MapLegendDot("North Sea (Hound Point)", TermGold)
                        MapLegendDot("USGC (Corpus Christi)", TermCyan)
                        MapLegendDot("Middle East (Ras Tanura)", Color(0xFFF97316))
                        MapLegendDot("Rotterdam / Pernis", TermEmeraldBright)
                        MapLegendDot("Asia (Ningbo/Chiba)", TermIndigo)
                    }
                }
            }
        }

        // Section 4: Physical Cargoes Prompt Board Strip
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PROMPT PHYSICAL CARGO BOARD",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TermGold
                    )
                )
                Text(
                    text = "VIEW FULL BOARD →",
                    modifier = Modifier.clickable { viewModel.selectTab(ScreenTab.CARGO_BOARD) },
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TermCyan,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        items(cargoes.take(3)) { cargo ->
            CargoRowCard(
                cargo = cargo,
                onInspect = { viewModel.inspectCargoValuation(cargo) }
            )
        }

        // Section 5: Real-Time Market Alerts & News Wire
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "INSTITUTIONAL MARKET NEWS & TICKER WIRE",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TermGold
                )
            )
        }

        items(newsStream.take(4)) { news ->
            NewsWireCard(news = news)
        }
    }
}

@Composable
fun BenchmarkCard(
    title: String,
    symbol: String,
    price: Double,
    change: Double,
    unit: String,
    provenance: PriceProvenance,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val isPos = change >= 0
    val color = if (isPos) TermEmeraldBright else TermCrimsonBright
    val sign = if (isPos) "+" else ""

    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("benchmark_card_$symbol"),
        colors = CardDefaults.cardColors(containerColor = TermCardBg),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = symbol,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TermGold
                    )
                )
                ProvenanceBadge(provenance)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "$${String.format("%.2f", price)}",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = TermWhite,
                    fontSize = 20.sp
                )
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$sign${String.format("%.2f", change)} $unit",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TermDimSlate,
                        fontSize = 9.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun SpreadMetricItem(label: String, value: String, valueColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.sp,
                color = TermDimSlate
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        )
    }
}

@Composable
fun WorldOilFlowCanvas(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "tankerMotion")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Background subtle grid lines
        for (i in 1..5) {
            drawLine(
                color = Color(0xFF1E293B).copy(alpha = 0.4f),
                start = Offset(0f, (h / 6f) * i),
                end = Offset(w, (h / 6f) * i),
                strokeWidth = 0.5f
            )
            drawLine(
                color = Color(0xFF1E293B).copy(alpha = 0.4f),
                start = Offset((w / 6f) * i, 0f),
                end = Offset((w / 6f) * i, h),
                strokeWidth = 0.5f
            )
        }

        // Major physical oil Hub Positions (normalized approx)
        val northSea = Offset(w * 0.48f, h * 0.22f)
        val rotterdam = Offset(w * 0.50f, h * 0.28f)
        val usgcCorpus = Offset(w * 0.22f, h * 0.42f)
        val westAfricaBonny = Offset(w * 0.50f, h * 0.58f)
        val middleEastRasTanura = Offset(w * 0.65f, h * 0.40f)
        val singapore = Offset(w * 0.80f, h * 0.60f)
        val chinaNingbo = Offset(w * 0.85f, h * 0.38f)

        // Draw Shipping Corridors (Dashed paths)
        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)

        // Route 1: USGC to Rotterdam (WTI Export)
        drawLine(
            color = TermCyan.copy(alpha = 0.6f),
            start = usgcCorpus,
            end = rotterdam,
            strokeWidth = 1.5f,
            pathEffect = dashEffect
        )

        // Route 2: North Sea to Rotterdam (Forties CIF)
        drawLine(
            color = TermGold.copy(alpha = 0.8f),
            start = northSea,
            end = rotterdam,
            strokeWidth = 2f
        )

        // Route 3: Middle East to China (TD3C VLCC)
        drawLine(
            color = Color(0xFFF97316).copy(alpha = 0.6f),
            start = middleEastRasTanura,
            end = chinaNingbo,
            strokeWidth = 1.5f,
            pathEffect = dashEffect
        )

        // Route 4: West Africa to China (Bonny Light)
        drawLine(
            color = TermEmeraldBright.copy(alpha = 0.5f),
            start = westAfricaBonny,
            end = singapore,
            strokeWidth = 1.2f,
            pathEffect = dashEffect
        )

        // Animated Tanker Vessels along paths
        // USGC -> Rotterdam tanker
        val t1X = usgcCorpus.x + (rotterdam.x - usgcCorpus.x) * pulse
        val t1Y = usgcCorpus.y + (rotterdam.y - usgcCorpus.y) * pulse
        drawCircle(color = TermCyan, radius = 4f, center = Offset(t1X, t1Y))
        drawCircle(color = TermCyan.copy(alpha = 0.3f), radius = 8f * pulse, center = Offset(t1X, t1Y))

        // ME -> China tanker
        val t2X = middleEastRasTanura.x + (chinaNingbo.x - middleEastRasTanura.x) * pulse
        val t2Y = middleEastRasTanura.y + (chinaNingbo.y - middleEastRasTanura.y) * pulse
        drawCircle(color = Color(0xFFF97316), radius = 4.5f, center = Offset(t2X, t2Y))

        // Hub Markers
        drawCircle(color = TermGold, radius = 5f, center = northSea)
        drawCircle(color = TermEmeraldBright, radius = 6f, center = rotterdam)
        drawCircle(color = TermCyan, radius = 5f, center = usgcCorpus)
        drawCircle(color = Color(0xFFF97316), radius = 5.5f, center = middleEastRasTanura)
        drawCircle(color = TermIndigo, radius = 5f, center = singapore)
        drawCircle(color = TermWhite, radius = 5f, center = chinaNingbo)
    }
}

@Composable
fun MapLegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 8.sp,
                color = TermMutedSlate
            )
        )
    }
}

@Composable
fun CargoRowCard(
    cargo: Cargo,
    onInspect: () -> Unit
) {
    val diffColor = if (cargo.differential >= 0) TermEmeraldBright else TermCrimsonBright
    val diffSign = if (cargo.differential >= 0) "+" else ""

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onInspect)
            .testTag("cargo_card_${cargo.id}"),
        colors = CardDefaults.cardColors(containerColor = TermCardBg),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = cargo.grade.name,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TermWhite
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${String.format("%,d", cargo.quantityBbl)} bbl",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                    )
                }
                Text(
                    text = "${cargo.loadPort.name} → ${cargo.dischargePort.name} • ${cargo.loadingWindow}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "$diffSign${String.format("%.2f", cargo.differential)}",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = diffColor
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "vs ${cargo.benchmarkBasis}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Outright: $${String.format("%.2f", cargo.outrightDeliveredPrice)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermWhite)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    ProvenanceBadge(cargo.provenance)
                }
            }
        }
    }
}

@Composable
fun NewsWireCard(news: MarketNewsItem) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(3.dp))
            .background(TermCardBg)
            .border(0.5.dp, TermBorder, RoundedCornerShape(3.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = news.time,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TermGold,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "• ${news.source}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .background(TermBorder)
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = news.category,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 8.sp,
                        color = TermCyan
                    )
                )
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = news.headline,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = TermWhite
            )
        )
        Text(
            text = news.impact,
            style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
        )
    }
}
