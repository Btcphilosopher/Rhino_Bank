package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.engine.AssayEngine
import com.example.rhinooilspot.domain.engine.FreightAndVoyageEngine
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.components.ProvenanceBadge
import com.example.rhinooilspot.ui.theme.*

@Composable
fun FreightVoyageScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val benchmarks = FreightAndVoyageEngine.FREIGHT_BENCHMARKS
    val ports = FreightAndVoyageEngine.PORTS_DATABASE
    val crudes = AssayEngine.CRUDE_DATABASE

    var selectedGrade by remember { mutableStateOf(crudes.first()) }
    var originPort by remember { mutableStateOf(ports.first { it.id == "PORT_CORPUS_CHRISTI" }) }
    var destinationPort by remember { mutableStateOf(ports.first { it.id == "PORT_ROTTERDAM" }) }
    var selectedVesselClass by remember { mutableStateOf(VesselClass.AFRAMAX) }
    var cargoSizeBbl by remember { mutableStateOf(700_000L) }
    var bunkerPrice by remember { mutableStateOf(580.0) }

    val voyageResult = remember(selectedGrade, originPort, destinationPort, selectedVesselClass, cargoSizeBbl, bunkerPrice) {
        FreightAndVoyageEngine.calculateVoyageEconomics(
            cargoSizeBbl = cargoSizeBbl,
            grade = selectedGrade,
            originPort = originPort,
            destinationPort = destinationPort,
            vesselClass = selectedVesselClass,
            bunkerFuelPricePerTonne = bunkerPrice,
            fobPricePerBbl = 78.42 + selectedGrade.baseDifferential
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Freight Market Benchmarks
        item {
            Text(
                text = "BALTIC TANKER FREIGHT BENCHMARKS (DIRTY & CLEAN)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        items(benchmarks) { route ->
            val isPos = route.change >= 0
            val changeColor = if (isPos) TermEmeraldBright else TermCrimsonBright

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("freight_route_${route.code}"),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.3f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${route.code} • ${route.vesselClass.name}",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermCyan)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            ProvenanceBadge(route.provenance)
                        }
                        Text(
                            text = route.name,
                            style = MaterialTheme.typography.labelSmall.copy(color = TermWhite),
                            maxLines = 1
                        )
                        Text(
                            text = "Distance: ${route.distanceNauticalMiles.toInt()} NM • Flat: $${String.format("%.2f", route.flatRateUsdPerTonne)}/t",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "WS ${String.format("%.1f", route.worldscaleRate)}",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black, color = TermWhite, fontSize = 18.sp)
                        )
                        Text(
                            text = "$${String.format("%.2f", route.rateUsdPerBbl)} /bbl",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TermGoldBright)
                        )
                        Text(
                            text = "${if (isPos) "+" else ""}${String.format("%.1f", route.change)} WS",
                            style = MaterialTheme.typography.labelSmall.copy(color = changeColor, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Section 2: Interactive Voyage Economics & Netback Calculator
        item {
            Text(
                text = "INSTITUTIONAL TANKER VOYAGE & ARBITRAGE CALCULATOR",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("voyage_calculator_card"),
                colors = CardDefaults.cardColors(containerColor = TermCardBgElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermGold.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Vessel Class Selector Chips
                    Text(text = "VESSEL CLASS & CARGO CAPACITY", style = MaterialTheme.typography.labelSmall.copy(color = TermGold, fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            Triple(VesselClass.AFRAMAX, 700_000L, "Aframax (700k bbl)"),
                            Triple(VesselClass.SUEZMAX, 1_000_000L, "Suezmax (1.0M bbl)"),
                            Triple(VesselClass.VLCC, 2_000_000L, "VLCC (2.0M bbl)")
                        ).forEach { (vc, cap, label) ->
                            val isSel = selectedVesselClass == vc
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (isSel) TermCyan else TermCardBg)
                                    .border(0.5.dp, if (isSel) TermWhite else TermBorder, RoundedCornerShape(3.dp))
                                    .clickable {
                                        selectedVesselClass = vc
                                        cargoSizeBbl = cap
                                    }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) TermBlack else TermWhite
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Origin & Destination Quick Selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "LOAD PORT (ORIGIN)", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(
                                text = originPort.name,
                                style = MaterialTheme.typography.bodyLarge.copy(color = TermWhite, fontWeight = FontWeight.Bold)
                            )
                        }
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = TermGold, modifier = Modifier.padding(top = 8.dp))
                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                            Text(text = "DISCHARGE PORT (DEST)", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(
                                text = destinationPort.name,
                                style = MaterialTheme.typography.bodyLarge.copy(color = TermWhite, fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Divider(color = TermBorder, modifier = Modifier.padding(vertical = 10.dp))

                    // Calculation Results Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "VOYAGE DISTANCE & DURATION", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(
                                text = "${voyageResult.distanceNm.toInt()} NM • ${String.format("%.1f", voyageResult.seaDays)} Sea Days + 3 Port Days",
                                style = MaterialTheme.typography.bodyLarge.copy(color = TermWhite, fontWeight = FontWeight.Bold)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "TOTAL VOYAGE COST", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(
                                text = "$${String.format("%,.0f", voyageResult.totalVoyageCostUsd)}",
                                style = MaterialTheme.typography.bodyLarge.copy(color = TermGoldBright, fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Delivered CIF & Netback Summary Banner
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(TermDarkBg)
                            .border(1.dp, TermBorder, RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "FREIGHT UNIT COST", style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate))
                            Text(
                                text = "$${String.format("%.2f", voyageResult.freightCostPerBbl)} /bbl",
                                style = MaterialTheme.typography.headlineMedium.copy(color = TermCyan, fontWeight = FontWeight.Black)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "DELIVERED CIF PRICE", style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate))
                            Text(
                                text = "$${String.format("%.2f", voyageResult.cifDeliveredPrice)} /bbl",
                                style = MaterialTheme.typography.headlineMedium.copy(color = TermWhite, fontWeight = FontWeight.Black)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "INDICATIVE NETBACK", style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate))
                            Text(
                                text = "$${String.format("%.2f", voyageResult.indicativeNetback)} /bbl",
                                style = MaterialTheme.typography.headlineMedium.copy(color = TermEmeraldBright, fontWeight = FontWeight.Black)
                            )
                        }
                    }
                }
            }
        }
    }
}
