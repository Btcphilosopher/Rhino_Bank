package com.example.rhinooilspot.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Institutional Terminal Palette (Bloomberg × London Trading Floor × Engineering Workstation)
val TermBlack = Color(0xFF070B0E)
val TermDarkBg = Color(0xFF0D131A)
val TermCardBg = Color(0xFF131C24)
val TermCardBgElevated = Color(0xFF1B2631)
val TermBorder = Color(0xFF243342)
val TermBorderLight = Color(0xFF334659)

// Accent Colors
val TermGold = Color(0xFFF59E0B)       // Bloomberg Amber
val TermGoldBright = Color(0xFFFBBF24)
val TermEmerald = Color(0xFF10B981)    // Profit / Up / Bullish
val TermEmeraldBright = Color(0xFF34D399)
val TermCrimson = Color(0xFFEF4444)    // Loss / Down / Bearish
val TermCrimsonBright = Color(0xFFF87171)
val TermCyan = Color(0xFF38BDF8)       // Logistics / Vessel / Freight
val TermIndigo = Color(0xFF818CF8)     // Analytics / Refinery
val TermMutedSlate = Color(0xFF94A3B8)
val TermDimSlate = Color(0xFF64748B)
val TermWhite = Color(0xFFF8FAFC)

val TerminalColorScheme = darkColorScheme(
    primary = TermGold,
    onPrimary = TermBlack,
    primaryContainer = TermCardBgElevated,
    onPrimaryContainer = TermGoldBright,
    secondary = TermCyan,
    onSecondary = TermBlack,
    secondaryContainer = TermBorder,
    onSecondaryContainer = TermCyan,
    tertiary = TermEmerald,
    onTertiary = TermBlack,
    background = TermDarkBg,
    onBackground = TermWhite,
    surface = TermCardBg,
    onSurface = TermWhite,
    surfaceVariant = TermCardBgElevated,
    onSurfaceVariant = TermMutedSlate,
    outline = TermBorder
)

val TerminalTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        letterSpacing = (-0.5).sp,
        color = TermWhite
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        letterSpacing = 0.sp,
        color = TermWhite
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        letterSpacing = 0.15.sp,
        color = TermWhite
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp,
        letterSpacing = 0.15.sp,
        color = TermWhite
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        letterSpacing = 0.25.sp,
        color = TermWhite
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        letterSpacing = 0.25.sp,
        color = TermMutedSlate
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        letterSpacing = 0.5.sp,
        color = TermDimSlate
    )
)

@Composable
fun RhinoTerminalTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = TerminalTypography,
        content = content
    )
}
