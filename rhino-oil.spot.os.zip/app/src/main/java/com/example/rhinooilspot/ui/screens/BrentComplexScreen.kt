package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.engine.AssayEngine
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.components.ProvenanceBadge
import com.example.rhinooilspot.ui.theme.*

@Composable
fun BrentComplexScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val benchmarks by viewModel.benchmarks.collectAsState()
    val forwardCurves by viewModel.forwardCurves.collectAsState()

    val brent = benchmarks.find { it.id == "DATED_BRENT" }?.spotPrice ?: 78.42
    val brentCurve = forwardCurves["BRENT"]

    // BFOET + WTI Midland Grades
    val bfoetGrades = remember {
        listOf("BRENT", "FORTIES", "OSEBERG", "EKOFISK", "TROLL", "WTI_MIDLAND").mapNotNull {
            AssayEngine.getGradeById(it)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Dated Brent Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("brent_complex_hero_card"),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermGold.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "NORTH SEA PHYSICAL BENCHMARK",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermGold, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "DATED BRENT COMPLEX",
                                style = MaterialTheme.typography.headlineMedium.copy(color = TermWhite, fontWeight = FontWeight.Black)
                            )
                        }
                        ProvenanceBadge(PriceProvenance(ProvenanceStatus.PUBLISHED, "Platts Window Assessment", "12:55 BST"))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${String.format("%.2f", brent)}/bbl",
                            style = MaterialTheme.typography.displayLarge.copy(color = TermGoldBright)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "+$0.31 (+0.40%) Today",
                                style = MaterialTheme.typography.bodyLarge.copy(color = TermEmeraldBright, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Marker Setter: Forties (Hound Point CIF)",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                            )
                        }
                    }

                    Divider(color = TermBorder, modifier = Modifier.padding(vertical = 8.dp))

                    Text(
                        text = "The Dated Brent assessment reflects the cheapest-to-deliver of the 6 constituent grades in the North Sea physical basket (BFOET + WTI Midland CIF Rotterdam).",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TermMutedSlate, fontSize = 11.sp)
                    )
                }
            }
        }

        // Section 2: Forward Spreads & Derivatives (EFP, CFD, Calendar Spreads)
        item {
            Text(
                text = "BRENT DERIVATIVES & PHYSICAL LINKAGES",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DerivativeCard(
                    name = "Brent CFD (Week 1-2)",
                    value = "+$0.18",
                    desc = "Contract for Differences (Physical vs Futures)",
                    modifier = Modifier.weight(1f)
                )
                DerivativeCard(
                    name = "Brent EFP (M1)",
                    value = "-$0.13",
                    desc = "Exchange of Futures for Physicals",
                    modifier = Modifier.weight(1f)
                )
                DerivativeCard(
                    name = "M1/M2 Calendar Spread",
                    value = "+$0.33",
                    desc = "Backwardation prompt premium",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section 3: BFOET Basket Grades & Physical Differentials
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BFOET + WTI BASKET (6 GRADES)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
                )
                Text(
                    text = "TAP TO INSPECT ASSAY & ARITHMETIC",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                )
            }
        }

        items(bfoetGrades) { grade ->
            BfoetGradeCard(
                grade = grade,
                benchmarkSpot = brent,
                isCheapest = grade.id == "FORTIES",
                onInspect = { viewModel.inspectCrudeDifferential(grade) }
            )
        }

        // Section 4: Forward Curve Points
        item {
            Text(
                text = "ICE BRENT FORWARD CURVE STRUCTURE (BACKWARDATED)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        if (brentCurve != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TermCardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        brentCurve.points.take(6).forEach { pt ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = pt.tenor,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TermWhite, fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = "$${String.format("%.2f", pt.price)}/bbl",
                                    style = MaterialTheme.typography.bodyLarge.copy(color = TermGold, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${if (pt.spreadVsPrompt >= 0) "+" else ""}${String.format("%.2f", pt.spreadVsPrompt)} vs Spot",
                                    style = MaterialTheme.typography.labelSmall.copy(color = if (pt.spreadVsPrompt <= 0) TermEmeraldBright else TermCrimsonBright)
                                )
                            }
                            Divider(color = TermBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DerivativeCard(
    name: String,
    value: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = TermCardBg),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = name, style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate, fontWeight = FontWeight.Bold))
            Text(text = value, style = MaterialTheme.typography.titleMedium.copy(color = TermGoldBright, fontWeight = FontWeight.Bold))
            Text(text = desc, style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate, fontSize = 8.sp), maxLines = 1)
        }
    }
}

@Composable
fun BfoetGradeCard(
    grade: CrudeGrade,
    benchmarkSpot: Double,
    isCheapest: Boolean,
    onInspect: () -> Unit
) {
    val diff = grade.baseDifferential
    val diffColor = if (diff >= 0) TermEmeraldBright else TermCrimsonBright
    val outright = benchmarkSpot + diff

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onInspect)
            .testTag("bfoet_grade_${grade.id}"),
        colors = CardDefaults.cardColors(containerColor = TermCardBg),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(
            if (isCheapest) 1.dp else 0.5.dp,
            if (isCheapest) TermGold else TermBorder
        )
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = grade.name,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                    )
                    if (isCheapest) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(TermGold.copy(alpha = 0.2f))
                                .border(0.5.dp, TermGold, RoundedCornerShape(2.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "CHEAPEST-TO-DELIVER (SETTER)",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = TermGold, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
                Text(
                    text = "${if (diff >= 0) "+" else ""}${String.format("%.2f", diff)} $/bbl",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = diffColor)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "API: ${grade.assay.apiGravity}° • S: ${grade.assay.sulfurWtPct}% • TAN: ${grade.assay.tanMgKohPerG}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                )
                Text(
                    text = "Outright: $${String.format("%.2f", outright)}/bbl",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermWhite, fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "${grade.loadingTerminal} (${grade.country}) • Std Cargo: ${String.format("%,d", grade.typicalCargoSizeBbl)} bbl",
                style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
            )
        }
    }
}
