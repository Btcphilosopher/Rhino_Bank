package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.engine.RiskPnLEngine
import com.example.rhinooilspot.domain.model.PhysicalPosition
import com.example.rhinooilspot.domain.model.PositionType
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.theme.*

@Composable
fun RiskPnLScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val positions by viewModel.positions.collectAsState()
    val (risk, attribution) = remember(positions) {
        RiskPnLEngine.calculatePortfolioMetrics(positions)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Portfolio Executive Summary Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("portfolio_executive_summary_card"),
                colors = CardDefaults.cardColors(containerColor = TermCardBgElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermGold.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "TRADING BOOK PORTFOLIO & RISK",
                                style = MaterialTheme.typography.labelSmall.copy(color = TermGold, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "TOTAL UNREALIZED P&L (MTM)",
                                style = MaterialTheme.typography.titleMedium.copy(color = TermWhite, fontWeight = FontWeight.Black)
                            )
                        }

                        Text(
                            text = "+$${String.format("%,.0f", attribution.totalPnlUsd)}",
                            style = MaterialTheme.typography.headlineMedium.copy(color = TermEmeraldBright, fontWeight = FontWeight.Black)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "1-Day VaR (95% Conf)", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(text = "$${String.format("%,.0f", risk.oneDayVaR95Usd)}", style = MaterialTheme.typography.bodyLarge.copy(color = TermCrimsonBright, fontWeight = FontWeight.Bold))
                        }
                        Column {
                            Text(text = "Net Physical Exposure", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(text = "${String.format("%,d", risk.netCrudeExposureBbl)} bbl", style = MaterialTheme.typography.bodyLarge.copy(color = TermCyan, fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Flat Price Delta DV01", style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
                            Text(text = "$${String.format("%,.0f", risk.crudeDeltaDv01Usd)} / $0.01", style = MaterialTheme.typography.bodyLarge.copy(color = TermWhite, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Section 2: P&L Attribution Waterfall
        item {
            Text(
                text = "P&L ATTRIBUTION WATERFALL (MULTI-FACTOR DECOMPOSITION)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    WaterfallRow("Flat Price Market Shift", attribution.flatPricePnlUsd, "Gross underlying benchmark price move")
                    WaterfallRow("Physical Basis / Differential", attribution.basisDifferentialPnlUsd, "Grade premium/discount movements vs Dated Brent")
                    WaterfallRow("Freight & Charter Cost", attribution.freightPnlUsd, "Tanker bunker rate and Worldscale shifts")
                    WaterfallRow("Storage & Time Carry", attribution.storageAndCarryPnlUsd, "Time decay and contango carry capture")
                    WaterfallRow("Assay Quality Adjustment", attribution.qualityAdjustmentPnlUsd, "Sulfur and API blending uplift")
                    WaterfallRow("FX / Currency Translation", attribution.fxPnlUsd, "Non-USD cargo currency revaluations")
                    WaterfallRow("Paper Futures Hedge Offset", attribution.hedgeOffsetPnlUsd, "ICE Brent futures hedge short leg")
                }
            }
        }

        // Section 3: Physical & Financial Trading Book Positions
        item {
            Text(
                text = "ACTIVE PHYSICAL BOOK POSITIONS (${positions.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
            )
        }

        items(positions) { pos ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("portfolio_position_${pos.id}"),
                colors = CardDefaults.cardColors(containerColor = TermCardBg),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(TermBorder)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = pos.type.name,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = TermCyan)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = pos.description,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                            )
                        }

                        Text(
                            text = "${if (pos.unrealizedPnlUsd >= 0) "+" else ""}$${String.format("%,.0f", pos.unrealizedPnlUsd)}",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = if (pos.unrealizedPnlUsd >= 0) TermEmeraldBright else TermCrimsonBright
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Size: ${String.format("%,d", pos.quantity.toLong())} ${pos.unit} • Entry: $${String.format("%.2f", pos.entryPriceUsd)} • MTM: $${String.format("%.2f", pos.currentMarketPriceUsd)}",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                        )
                        Text(
                            text = "VaR 95%: $${String.format("%,.0f", pos.valueAtRisk95Usd)}",
                            style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WaterfallRow(label: String, valueUsd: Double, explanation: String) {
    val isPos = valueUsd >= 0
    val color = if (isPos) TermEmeraldBright else TermCrimsonBright
    val sign = if (isPos) "+" else ""

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = TermWhite))
            Text(text = "$sign$${String.format("%,.0f", valueUsd)}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = color))
        }
        Text(text = explanation, style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate, fontSize = 9.sp))
        Divider(color = TermBorder.copy(alpha = 0.5f), thickness = 0.5.dp, modifier = Modifier.padding(top = 2.dp))
    }
}
