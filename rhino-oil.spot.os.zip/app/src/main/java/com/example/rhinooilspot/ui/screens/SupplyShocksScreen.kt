package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.engine.ScenarioPropagationEngine
import com.example.rhinooilspot.domain.model.MarketScenario
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.theme.*

@Composable
fun SupplyShocksScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val activeScenario by viewModel.activeScenario.collectAsState()
    val scenarios = ScenarioPropagationEngine.PRESET_SCENARIOS

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "GEOPOLITICAL & SUPPLY SHOCK PROPAGATION ENGINE",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
                    )
                    Text(
                        text = "Simulate major supply disruptions and watch prices, freight, and cracks adjust in real time.",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                    )
                }

                if (activeScenario != null) {
                    Button(
                        onClick = { viewModel.applyScenario(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = TermCrimson),
                        shape = RoundedCornerShape(3.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("reset_scenarios_btn")
                    ) {
                        Text(text = "RESET BASELINE", style = MaterialTheme.typography.labelSmall.copy(color = TermWhite, fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        items(scenarios) { scenario ->
            val isActive = activeScenario?.id == scenario.id
            val impact = scenario.defaultImpact

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (isActive) viewModel.applyScenario(null)
                        else viewModel.applyScenario(scenario)
                    }
                    .testTag("scenario_card_${scenario.id}"),
                colors = CardDefaults.cardColors(containerColor = if (isActive) TermCardBgElevated else TermCardBg),
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(
                    if (isActive) 1.5.dp else 0.5.dp,
                    if (isActive) TermGold else TermBorder
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (isActive) TermGold else TermBorder)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = scenario.category,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isActive) TermBlack else TermCyan
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = scenario.title,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActive) TermGoldBright else TermWhite
                                )
                            )
                        }

                        if (isActive) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(TermEmerald.copy(alpha = 0.2f))
                                    .border(0.5.dp, TermEmeraldBright, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "● SIMULATING",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TermEmeraldBright, fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = scenario.description,
                        style = MaterialTheme.typography.bodyMedium.copy(color = TermMutedSlate, fontSize = 11.sp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Simulated Impact Metrics
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(TermDarkBg)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ImpactItem("Dated Brent", "${if (impact.datedBrentShiftUsd >= 0) "+" else ""}$${String.format("%.2f", impact.datedBrentShiftUsd)}", if (impact.datedBrentShiftUsd >= 0) TermCrimsonBright else TermEmeraldBright)
                        ImpactItem("WTI Cushing", "${if (impact.wtiShiftUsd >= 0) "+" else ""}$${String.format("%.2f", impact.wtiShiftUsd)}", if (impact.wtiShiftUsd >= 0) TermCrimsonBright else TermEmeraldBright)
                        ImpactItem("Freight TD3C", "${if (impact.freightRateShiftPct >= 0) "+" else ""}${String.format("%.0f", impact.freightRateShiftPct)}%", TermCyan)
                        ImpactItem("Diesel Crack", "${if (impact.dieselCrackShiftUsd >= 0) "+" else ""}$${String.format("%.2f", impact.dieselCrackShiftUsd)}", TermEmeraldBright)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Narrative: ${impact.narrative}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                    )
                }
            }
        }
    }
}

@Composable
fun ImpactItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = TermDimSlate))
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = color))
    }
}
