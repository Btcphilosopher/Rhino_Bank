package com.example.rhinooilspot.domain.engine

import com.example.rhinooilspot.domain.model.*

object RiskPnLEngine {

    val INITIAL_PORTFOLIO_POSITIONS: List<PhysicalPosition> by lazy {
        listOf(
            PhysicalPosition(
                id = "POS_001",
                description = "North Sea Forties Physical Cargo (Oct 12-14 Laycan)",
                type = PositionType.PHYSICAL_CARGO_LONG,
                quantity = 600_000.0,
                unit = "BBL",
                entryPriceUsd = 77.20,
                currentMarketPriceUsd = 77.97, // 78.42 - 0.45
                benchmarkRef = "Dated Brent",
                differential = -0.45,
                freightCostUsd = 650_000.0,
                storageCostUsd = 0.0,
                location = "Hound Point / Aframax Navion",
                valueAtRisk95Usd = 920_000.0
            ),
            PhysicalPosition(
                id = "POS_002",
                description = "WTI Midland FOB Corpus Christi (Nov 1-3 Laycan)",
                type = PositionType.PHYSICAL_CARGO_LONG,
                quantity = 700_000.0,
                unit = "BBL",
                entryPriceUsd = 77.80,
                currentMarketPriceUsd = 78.67,
                benchmarkRef = "Dated Brent",
                differential = 0.25,
                freightCostUsd = 1_850_000.0,
                storageCostUsd = 0.0,
                location = "Corpus Christi / Suezmax Eagle",
                valueAtRisk95Usd = 1_150_000.0
            ),
            PhysicalPosition(
                id = "POS_003",
                description = "Rotterdam Vopak Tank Farm Contango Carry Inventory",
                type = PositionType.STORAGE_LONG,
                quantity = 1_200_000.0,
                unit = "BBL",
                entryPriceUsd = 76.50,
                currentMarketPriceUsd = 78.42,
                benchmarkRef = "Dated Brent",
                differential = 0.0,
                freightCostUsd = 0.0,
                storageCostUsd = 540_000.0,
                location = "Rotterdam Europoort Tank #401-406",
                valueAtRisk95Usd = 1_680_000.0
            ),
            PhysicalPosition(
                id = "POS_004",
                description = "ICE Brent Futures Short M1/M2 Paper Hedge",
                type = PositionType.PAPER_FUTURES_HEDGE,
                quantity = -1_800_000.0,
                unit = "BBL",
                entryPriceUsd = 78.10,
                currentMarketPriceUsd = 78.55,
                benchmarkRef = "ICE Brent M1",
                differential = 0.0,
                freightCostUsd = 0.0,
                storageCostUsd = 0.0,
                location = "ICE Futures Europe",
                valueAtRisk95Usd = 450_000.0
            )
        )
    }

    fun calculatePortfolioMetrics(positions: List<PhysicalPosition>): Pair<PortfolioRisk, PnLAttribution> {
        var totalMtm = 0.0
        var totalUnrealized = 0.0
        var netCrudeBbl = 0L
        var totalVaR = 0.0

        for (pos in positions) {
            totalMtm += pos.mtmValueUsd
            totalUnrealized += pos.unrealizedPnlUsd
            if (pos.unit == "BBL") {
                netCrudeBbl += pos.quantity.toLong()
            }
            totalVaR += pos.valueAtRisk95Usd * pos.valueAtRisk95Usd // quadratic sum for diversified VaR
        }

        val diversifiedVaR = Math.sqrt(totalVaR) * 0.85 // 15% diversification benefit
        val stressWorstCase = diversifiedVaR * 2.85

        val flatPricePnl = 1_420_000.0
        val basisDiffPnl = 680_000.0
        val freightPnl = -210_000.0
        val storagePnl = 490_000.0
        val qualityPnl = 85_000.0
        val fxPnl = 145_000.0
        val hedgeOffset = -810_000.0

        val totalAttributionPnl = flatPricePnl + basisDiffPnl + freightPnl + storagePnl + qualityPnl + fxPnl + hedgeOffset

        val risk = PortfolioRisk(
            netCrudeExposureBbl = netCrudeBbl,
            netProductExposureTons = 45_000L,
            totalMtmPortfolioValueUsd = totalMtm,
            totalUnrealizedPnlUsd = totalUnrealized,
            oneDayVaR95Usd = diversifiedVaR,
            stressLossWorstCaseUsd = stressWorstCase,
            crudeDeltaDv01Usd = netCrudeBbl * 1.0,
            basisDv01Usd = netCrudeBbl * 0.10,
            freightDv01Usd = 28_500.0
        )

        val attribution = PnLAttribution(
            totalPnlUsd = totalAttributionPnl,
            flatPricePnlUsd = flatPricePnl,
            basisDifferentialPnlUsd = basisDiffPnl,
            freightPnlUsd = freightPnl,
            storageAndCarryPnlUsd = storagePnl,
            qualityAdjustmentPnlUsd = qualityPnl,
            fxPnlUsd = fxPnl,
            hedgeOffsetPnlUsd = hedgeOffset
        )

        return Pair(risk, attribution)
    }
}
