package com.example.rhinooilspot.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rhinooilspot.ui.components.*
import com.example.rhinooilspot.ui.screens.*
import com.example.rhinooilspot.ui.theme.*

@Composable
fun TerminalApp(
    viewModel: RhinoTerminalViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val benchmarks by viewModel.benchmarks.collectAsState()
    val activeScenario by viewModel.activeScenario.collectAsState()

    RhinoTerminalTheme {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .testTag("terminal_main_scaffold"),
            containerColor = TermDarkBg,
            contentWindowInsets = WindowInsets.systemBars
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(TermDarkBg)
            ) {
                // Top Header Bar
                TerminalHeaderBar(
                    currentTab = uiState.currentTab,
                    selectedCurrency = uiState.selectedCurrency,
                    onCurrencyChange = { viewModel.setCurrency(it) },
                    activeScenario = activeScenario,
                    onOpenCommandPalette = { viewModel.openCommandPalette() },
                    onResetScenario = { viewModel.applyScenario(null) }
                )

                // High-Density Marquee Ticker
                MarketTickerMarquee(
                    benchmarks = benchmarks,
                    onBenchmarkClick = { bm ->
                        if (bm.symbol.contains("WTI")) viewModel.selectTab(ScreenTab.WTI_CUSHING)
                        else if (bm.symbol.contains("BRENT") || bm.symbol.contains("DATED")) viewModel.selectTab(ScreenTab.BRENT_COMPLEX)
                        else viewModel.selectTab(ScreenTab.OIL_NOW)
                    }
                )

                // Main Navigation Tabs
                TerminalNavBar(
                    selectedTab = uiState.currentTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )

                // Central Workspace Switcher
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Crossfade(
                        targetState = uiState.currentTab,
                        label = "tabCrossfade"
                    ) { tab ->
                        when (tab) {
                            ScreenTab.OIL_NOW -> OilNowScreen(viewModel = viewModel)
                            ScreenTab.BRENT_COMPLEX -> BrentComplexScreen(viewModel = viewModel)
                            ScreenTab.WTI_CUSHING -> WtiCushingScreen(viewModel = viewModel)
                            ScreenTab.CARGO_BOARD -> CargoBoardScreen(viewModel = viewModel)
                            ScreenTab.FREIGHT_VOYAGES -> FreightVoyageScreen(viewModel = viewModel)
                            ScreenTab.REFINERY_CRACKS -> RefineryCracksScreen(viewModel = viewModel)
                            ScreenTab.STORAGE_HUBS -> StorageHubsScreen(viewModel = viewModel)
                            ScreenTab.CRUDE_SLATE_ARB -> CrudeSlateArbScreen(viewModel = viewModel)
                            ScreenTab.SUPPLY_SHOCKS -> SupplyShocksScreen(viewModel = viewModel)
                            ScreenTab.RISK_PNL -> RiskPnLScreen(viewModel = viewModel)
                        }
                    }
                }
            }

            // Calculation Trace Sheet Dialog
            if (uiState.activeCalculationTrace != null) {
                CalculationInspectorSheet(
                    trace = uiState.activeCalculationTrace!!,
                    onDismiss = { viewModel.closeCalculationTrace() }
                )
            }

            // Quick Launcher / Bloomberg Command Palette
            if (uiState.isCommandPaletteOpen) {
                CommandPaletteDialog(
                    onCommand = { cmd -> viewModel.executeCommand(cmd) },
                    onDismiss = { viewModel.closeCommandPalette() }
                )
            }
        }
    }
}
