package com.example.rhinooilspot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rhinooilspot.domain.model.*
import com.example.rhinooilspot.ui.RhinoTerminalViewModel
import com.example.rhinooilspot.ui.components.ProvenanceBadge
import com.example.rhinooilspot.ui.theme.*

@Composable
fun CargoBoardScreen(
    viewModel: RhinoTerminalViewModel,
    modifier: Modifier = Modifier
) {
    val cargoes by viewModel.cargoes.collectAsState()
    val orderBooks by viewModel.orderBooks.collectAsState()

    var selectedRegion by remember { mutableStateOf<Region?>(null) }
    var selectedStatus by remember { mutableStateOf<CargoStatus?>(null) }

    val filteredCargoes = remember(cargoes, selectedRegion, selectedStatus) {
        cargoes.filter { c ->
            (selectedRegion == null || c.grade.region == selectedRegion) &&
            (selectedStatus == null || c.status == selectedStatus)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TermDarkBg)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Filter Chips Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChipItem("ALL REGIONS", selectedRegion == null) { selectedRegion = null }
                Region.values().forEach { r ->
                    FilterChipItem(r.name.replace("_", " "), selectedRegion == r) { selectedRegion = r }
                }
            }
        }

        // Section 1: Physical Order Book Depth (Forties Benchmark Depth)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("physical_orderbook_card"),
                colors = CardDefaults.cardColors(containerColor = TermCardBgElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, TermGold.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "FORTIES CIF ROTTERDAM WINDOW ORDER BOOK",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermGold)
                        )
                        ProvenanceBadge(PriceProvenance(ProvenanceStatus.PUBLISHED, "Platts eWindow", "12:55 BST"))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Bids Column
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "BIDS (BUYERS)", style = MaterialTheme.typography.labelSmall.copy(color = TermEmeraldBright, fontWeight = FontWeight.Bold))
                            OrderBookRow("-0.45 $/bbl", "600k bbl", "Shell Trading", TermEmeraldBright)
                            OrderBookRow("-0.50 $/bbl", "600k bbl", "TotalEnergies", TermEmeraldBright)
                            OrderBookRow("-0.65 $/bbl", "1,200k bbl", "Vitol Geneva", TermEmeraldBright)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Offers Column
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "OFFERS (SELLERS)", style = MaterialTheme.typography.labelSmall.copy(color = TermCrimsonBright, fontWeight = FontWeight.Bold))
                            OrderBookRow("-0.42 $/bbl", "600k bbl", "BP Oil Intl", TermCrimsonBright)
                            OrderBookRow("-0.35 $/bbl", "600k bbl", "Equinor", TermCrimsonBright)
                            OrderBookRow("-0.20 $/bbl", "1,200k bbl", "Trafigura", TermCrimsonBright)
                        }
                    }
                }
            }
        }

        // Section 2: Physical Cargo Prompt Listings
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE SPOT PHYSICAL CARGOES (${filteredCargoes.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                )
                Text(
                    text = "CLICK CARGO TO TRACE VALUATION",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                )
            }
        }

        items(filteredCargoes) { cargo ->
            CargoDetailedCard(
                cargo = cargo,
                onInspect = { viewModel.inspectCargoValuation(cargo) }
            )
        }
    }
}

@Composable
fun FilterChipItem(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(if (isSelected) TermGold else TermCardBg)
            .border(0.5.dp, if (isSelected) TermGoldBright else TermBorder, RoundedCornerShape(3.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) TermBlack else TermMutedSlate
            )
        )
    }
}

@Composable
fun OrderBookRow(price: String, size: String, trader: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = price, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = color))
        Text(text = size, style = MaterialTheme.typography.labelSmall.copy(color = TermWhite))
        Text(text = trader, style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate))
    }
}

@Composable
fun CargoDetailedCard(
    cargo: Cargo,
    onInspect: () -> Unit
) {
    val diffColor = if (cargo.differential >= 0) TermEmeraldBright else TermCrimsonBright
    val sign = if (cargo.differential >= 0) "+" else ""

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onInspect)
            .testTag("cargo_item_${cargo.id}"),
        colors = CardDefaults.cardColors(containerColor = TermCardBg),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(TermBorder)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(text = cargo.id, style = MaterialTheme.typography.labelSmall.copy(color = TermGold, fontSize = 9.sp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = cargo.grade.name,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TermWhite)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "(${cargo.incoterm.name})",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                    )
                }

                Text(
                    text = "$sign${String.format("%.2f", cargo.differential)} $/bbl",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = diffColor)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Logistics & Window Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Route: ${cargo.loadPort.name} → ${cargo.dischargePort.name}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermWhite)
                )
                Text(
                    text = "Outright: $${String.format("%.2f", cargo.outrightDeliveredPrice)}/bbl",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TermGoldBright)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Parties & Vessel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Load Laycan: ${cargo.loadingWindow} • Size: ${String.format("%,d", cargo.quantityBbl)} bbl",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermDimSlate)
                )
                Text(
                    text = "Counterparties: ${cargo.seller} / ${cargo.buyer}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TermMutedSlate)
                )
            }

            if (cargo.vessel != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "🚢 Vessel: ${cargo.vessel.name} (${cargo.vessel.vesselClass.name}) • ETA: ${cargo.vessel.eta}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TermCyan)
                    )
                    ProvenanceBadge(cargo.provenance)
                }
            }
        }
    }
}
