package com.example.rhinooilspot.domain.engine

import com.example.rhinooilspot.domain.model.*

object AssayEngine {

    fun blendCrudes(components: List<CrudeBlendComponent>): CrudeBlendResult {
        if (components.isEmpty()) {
            throw IllegalArgumentException("Crude blend must have at least one component")
        }

        val totalVol = components.sumOf { it.volumeFraction }
        val normalizedComponents = components.map {
            it.copy(volumeFraction = it.volumeFraction / totalVol)
        }

        // 1. Calculate blended Specific Gravity (SG is volume additive)
        val blendedSg = normalizedComponents.sumOf { it.volumeFraction * it.grade.assay.specificGravity }
        val blendedApi = (141.5 / blendedSg) - 131.5

        // 2. Calculate blended Sulfur (Sulfur is mass additive)
        var totalMass = 0.0
        var totalSulfurMass = 0.0
        for (comp in normalizedComponents) {
            val compMass = comp.volumeFraction * comp.grade.assay.specificGravity
            totalMass += compMass
            totalSulfurMass += compMass * comp.grade.assay.sulfurWtPct
        }
        val blendedSulfur = if (totalMass > 0) totalSulfurMass / totalMass else 0.0

        // 3. Blend yields (volume weighted)
        val blendedYields = AssayYields(
            lpgPct = normalizedComponents.sumOf { it.volumeFraction * it.grade.assay.yields.lpgPct },
            naphthaPct = normalizedComponents.sumOf { it.volumeFraction * it.grade.assay.yields.naphthaPct },
            gasolinePct = normalizedComponents.sumOf { it.volumeFraction * it.grade.assay.yields.gasolinePct },
            jetKeroPct = normalizedComponents.sumOf { it.volumeFraction * it.grade.assay.yields.jetKeroPct },
            dieselGasoilPct = normalizedComponents.sumOf { it.volumeFraction * it.grade.assay.yields.dieselGasoilPct },
            vgoPct = normalizedComponents.sumOf { it.volumeFraction * it.grade.assay.yields.vgoPct },
            residuePct = normalizedComponents.sumOf { it.volumeFraction * it.grade.assay.yields.residuePct }
        )

        // 4. Blend Viscosity (Refutas VBN / power approximation)
        val blendedViscosity = normalizedComponents.sumOf {
            it.volumeFraction * Math.log(Math.log(it.grade.assay.viscosityCst50 + 0.8))
        }.let { Math.exp(Math.exp(it)) - 0.8 }.coerceAtLeast(1.0)

        // 5. Calculate indicative refinery margin
        val lightCutMargin = (blendedYields.gasolinePct + blendedYields.jetKeroPct + blendedYields.dieselGasoilPct) * 0.12
        val sulfurPenalty = blendedSulfur * 1.50
        val indicativeMargin = 8.50 + lightCutMargin - sulfurPenalty

        return CrudeBlendResult(
            components = normalizedComponents,
            blendedApi = blendedApi,
            blendedSulfurWtPct = blendedSulfur,
            blendedViscosityCst = blendedViscosity,
            blendedYields = blendedYields,
            blendedSpecificGravity = blendedSg,
            indicativeRefineryMargin = indicativeMargin
        )
    }

    val CRUDE_DATABASE: List<CrudeGrade> by lazy {
        listOf(
            CrudeGrade(
                id = "BRENT",
                name = "Dated Brent",
                code = "BRT",
                region = Region.NORTH_SEA,
                country = "United Kingdom",
                loadingTerminal = "Sullom Voe Terminal",
                benchmarkRef = "Dated Brent",
                baseDifferential = 0.0,
                assay = CrudeAssay(
                    apiGravity = 38.0,
                    sulfurWtPct = 0.40,
                    viscosityCst50 = 3.2,
                    tanMgKohPerG = 0.12,
                    nickelPpm = 2.0,
                    vanadiumPpm = 3.0,
                    pourPointC = -3.0,
                    yields = AssayYields(2.5, 7.5, 23.0, 14.5, 29.5, 15.0, 8.0)
                ),
                description = "Light sweet North Sea crude, global physical and financial benchmark."
            ),
            CrudeGrade(
                id = "FORTIES",
                name = "Forties",
                code = "FTIS",
                region = Region.NORTH_SEA,
                country = "United Kingdom",
                loadingTerminal = "Hound Point",
                benchmarkRef = "Dated Brent",
                baseDifferential = -0.45,
                assay = CrudeAssay(
                    apiGravity = 38.7,
                    sulfurWtPct = 0.75,
                    viscosityCst50 = 3.8,
                    tanMgKohPerG = 0.35,
                    nickelPpm = 4.0,
                    vanadiumPpm = 7.0,
                    pourPointC = -6.0,
                    yields = AssayYields(2.8, 8.2, 22.0, 13.8, 28.2, 16.0, 9.0)
                ),
                description = "Primary constituent of the North Sea BFOET benchmark basket, medium sour."
            ),
            CrudeGrade(
                id = "OSEBERG",
                name = "Oseberg",
                code = "OSB",
                region = Region.NORTH_SEA,
                country = "Norway",
                loadingTerminal = "Sture Terminal",
                benchmarkRef = "Dated Brent",
                baseDifferential = 0.85,
                assay = CrudeAssay(
                    apiGravity = 37.8,
                    sulfurWtPct = 0.27,
                    viscosityCst50 = 2.9,
                    tanMgKohPerG = 0.15,
                    nickelPpm = 1.5,
                    vanadiumPpm = 2.0,
                    pourPointC = -15.0,
                    yields = AssayYields(2.6, 9.0, 24.5, 15.0, 31.0, 13.0, 4.9)
                ),
                description = "Low-sulfur premium North Sea Norwegian crude with rich middle distillates."
            ),
            CrudeGrade(
                id = "EKOFISK",
                name = "Ekofisk",
                code = "EKO",
                region = Region.NORTH_SEA,
                country = "Norway",
                loadingTerminal = "Teesside",
                benchmarkRef = "Dated Brent",
                baseDifferential = 0.65,
                assay = CrudeAssay(
                    apiGravity = 39.1,
                    sulfurWtPct = 0.18,
                    viscosityCst50 = 2.8,
                    tanMgKohPerG = 0.10,
                    nickelPpm = 1.0,
                    vanadiumPpm = 1.5,
                    pourPointC = -9.0,
                    yields = AssayYields(2.9, 9.5, 25.0, 15.5, 30.5, 12.0, 4.6)
                ),
                description = "Very light sweet North Sea crude, high naphtha and gasoline cuts."
            ),
            CrudeGrade(
                id = "TROLL",
                name = "Troll",
                code = "TRL",
                region = Region.NORTH_SEA,
                country = "Norway",
                loadingTerminal = "Mongstad",
                benchmarkRef = "Dated Brent",
                baseDifferential = 1.15,
                assay = CrudeAssay(
                    apiGravity = 36.0,
                    sulfurWtPct = 0.15,
                    viscosityCst50 = 3.5,
                    tanMgKohPerG = 0.22,
                    nickelPpm = 1.2,
                    vanadiumPpm = 1.8,
                    pourPointC = -12.0,
                    yields = AssayYields(2.2, 7.0, 21.0, 16.5, 34.0, 14.0, 5.3)
                ),
                description = "Ultra-low sulfur North Sea crude highly valued for European diesel/gasoil production."
            ),
            CrudeGrade(
                id = "WTI_MIDLAND",
                name = "WTI Midland",
                code = "WTIM",
                region = Region.NORTH_AMERICA,
                country = "United States",
                loadingTerminal = "Corpus Christi / Houston",
                benchmarkRef = "Dated Brent",
                baseDifferential = 0.25,
                assay = CrudeAssay(
                    apiGravity = 41.2,
                    sulfurWtPct = 0.20,
                    viscosityCst50 = 2.1,
                    tanMgKohPerG = 0.08,
                    nickelPpm = 0.8,
                    vanadiumPpm = 1.0,
                    pourPointC = -18.0,
                    yields = AssayYields(3.5, 11.5, 28.0, 14.0, 27.0, 11.5, 4.5)
                ),
                description = "Permian Basin light sweet crude, now included in the Dated Brent physical assessment basket."
            ),
            CrudeGrade(
                id = "WTI_CUSHING",
                name = "WTI Cushing",
                code = "CL",
                region = Region.NORTH_AMERICA,
                country = "United States",
                loadingTerminal = "Cushing Hub, Oklahoma",
                benchmarkRef = "WTI Cushing",
                baseDifferential = 0.0,
                assay = CrudeAssay(
                    apiGravity = 40.5,
                    sulfurWtPct = 0.24,
                    viscosityCst50 = 2.4,
                    tanMgKohPerG = 0.10,
                    nickelPpm = 1.1,
                    vanadiumPpm = 1.3,
                    pourPointC = -15.0,
                    yields = AssayYields(3.2, 10.8, 27.0, 14.5, 27.5, 12.0, 5.0)
                ),
                description = "The physical delivery benchmark for NYMEX light sweet crude futures."
            ),
            CrudeGrade(
                id = "WTI_HOUSTON",
                name = "WTI Houston (MEH)",
                code = "MEH",
                region = Region.NORTH_AMERICA,
                country = "United States",
                loadingTerminal = "Magellan East Houston",
                benchmarkRef = "WTI Cushing",
                baseDifferential = 1.10,
                assay = CrudeAssay(
                    apiGravity = 40.8,
                    sulfurWtPct = 0.22,
                    viscosityCst50 = 2.3,
                    tanMgKohPerG = 0.09,
                    nickelPpm = 0.9,
                    vanadiumPpm = 1.1,
                    pourPointC = -16.0,
                    yields = AssayYields(3.3, 11.0, 27.5, 14.2, 27.3, 11.8, 4.9)
                ),
                description = "Waterborne export parity benchmark along the Houston Ship Channel."
            ),
            CrudeGrade(
                id = "MARS",
                name = "Mars Blend",
                code = "MARS",
                region = Region.NORTH_AMERICA,
                country = "United States",
                loadingTerminal = "LOOP (Louisiana Offshore Oil Port)",
                benchmarkRef = "WTI Cushing",
                baseDifferential = -1.85,
                assay = CrudeAssay(
                    apiGravity = 28.8,
                    sulfurWtPct = 1.80,
                    viscosityCst50 = 8.5,
                    tanMgKohPerG = 0.40,
                    nickelPpm = 12.0,
                    vanadiumPpm = 28.0,
                    pourPointC = -9.0,
                    yields = AssayYields(1.8, 5.5, 16.5, 11.5, 27.5, 21.0, 16.2)
                ),
                description = "Gulf of Mexico medium sour crude processed by complex USGC cokers and hydrocrackers."
            ),
            CrudeGrade(
                id = "LLS",
                name = "Light Louisiana Sweet",
                code = "LLS",
                region = Region.NORTH_AMERICA,
                country = "United States",
                loadingTerminal = "St. James Terminal, LA",
                benchmarkRef = "WTI Cushing",
                baseDifferential = 2.20,
                assay = CrudeAssay(
                    apiGravity = 35.6,
                    sulfurWtPct = 0.45,
                    viscosityCst50 = 4.2,
                    tanMgKohPerG = 0.20,
                    nickelPpm = 3.5,
                    vanadiumPpm = 6.0,
                    pourPointC = -12.0,
                    yields = AssayYields(2.4, 8.0, 24.0, 13.5, 29.0, 15.5, 7.6)
                ),
                description = "Premier US Gulf Coast light sweet refinery feedstock."
            ),
            CrudeGrade(
                id = "DUBAI",
                name = "Dubai Crude",
                code = "DUB",
                region = Region.MIDDLE_EAST,
                country = "United Arab Emirates",
                loadingTerminal = "Fateh Terminal",
                benchmarkRef = "Dubai",
                baseDifferential = 0.0,
                assay = CrudeAssay(
                    apiGravity = 31.0,
                    sulfurWtPct = 2.05,
                    viscosityCst50 = 7.8,
                    tanMgKohPerG = 0.25,
                    nickelPpm = 8.0,
                    vanadiumPpm = 22.0,
                    pourPointC = -15.0,
                    yields = AssayYields(1.9, 6.2, 17.5, 12.0, 28.0, 20.0, 14.4)
                ),
                description = "Medium sour benchmark for Middle East crude pricing into Asia-Pacific refiners."
            ),
            CrudeGrade(
                id = "OMAN",
                name = "Oman Crude",
                code = "OMN",
                region = Region.MIDDLE_EAST,
                country = "Oman",
                loadingTerminal = "Mina Al Fahal",
                benchmarkRef = "Dubai",
                baseDifferential = 0.35,
                assay = CrudeAssay(
                    apiGravity = 31.5,
                    sulfurWtPct = 1.25,
                    viscosityCst50 = 6.9,
                    tanMgKohPerG = 0.18,
                    nickelPpm = 6.0,
                    vanadiumPpm = 18.0,
                    pourPointC = -12.0,
                    yields = AssayYields(2.0, 6.8, 18.5, 12.8, 29.0, 19.0, 11.9)
                ),
                description = "DME futures deliverable sour grade traded directly by Asian refiners."
            ),
            CrudeGrade(
                id = "MURBAN",
                name = "Murban",
                code = "MRB",
                region = Region.MIDDLE_EAST,
                country = "United Arab Emirates",
                loadingTerminal = "Fujairah Terminal",
                benchmarkRef = "Dubai",
                baseDifferential = 1.45,
                assay = CrudeAssay(
                    apiGravity = 40.2,
                    sulfurWtPct = 0.70,
                    viscosityCst50 = 2.6,
                    tanMgKohPerG = 0.10,
                    nickelPpm = 1.5,
                    vanadiumPpm = 3.0,
                    pourPointC = -21.0,
                    yields = AssayYields(3.0, 10.5, 26.5, 15.0, 28.5, 12.0, 4.5)
                ),
                description = "Light sweet Abu Dhabi export crude bypassing the Strait of Hormuz via Fujairah pipeline."
            ),
            CrudeGrade(
                id = "ARAB_LIGHT",
                name = "Arab Light",
                code = "ARBL",
                region = Region.MIDDLE_EAST,
                country = "Saudi Arabia",
                loadingTerminal = "Ras Tanura",
                benchmarkRef = "Dubai",
                baseDifferential = 1.20,
                assay = CrudeAssay(
                    apiGravity = 33.4,
                    sulfurWtPct = 1.77,
                    viscosityCst50 = 5.8,
                    tanMgKohPerG = 0.14,
                    nickelPpm = 5.5,
                    vanadiumPpm = 16.0,
                    pourPointC = -24.0,
                    yields = AssayYields(2.1, 7.4, 20.0, 13.0, 29.5, 17.5, 10.5)
                ),
                description = "Flagship Saudi Aramco export grade sold under monthly Official Selling Prices (OSP)."
            ),
            CrudeGrade(
                id = "BONNY_LIGHT",
                name = "Bonny Light",
                code = "BNY",
                region = Region.WEST_AFRICA,
                country = "Nigeria",
                loadingTerminal = "Bonny Inshore Terminal",
                benchmarkRef = "Dated Brent",
                baseDifferential = 0.90,
                assay = CrudeAssay(
                    apiGravity = 35.3,
                    sulfurWtPct = 0.15,
                    viscosityCst50 = 3.1,
                    tanMgKohPerG = 0.18,
                    nickelPpm = 1.8,
                    vanadiumPpm = 2.2,
                    pourPointC = 6.0,
                    yields = AssayYields(2.4, 8.5, 23.5, 15.2, 32.0, 13.0, 5.4)
                ),
                description = "High-quality light sweet Nigerian crude with high kerosene and gasoil yields."
            ),
            CrudeGrade(
                id = "FORCADOS",
                name = "Forcados",
                code = "FRC",
                region = Region.WEST_AFRICA,
                country = "Nigeria",
                loadingTerminal = "Forcados Terminal",
                benchmarkRef = "Dated Brent",
                baseDifferential = 0.70,
                assay = CrudeAssay(
                    apiGravity = 30.5,
                    sulfurWtPct = 0.20,
                    viscosityCst50 = 5.2,
                    tanMgKohPerG = 0.38,
                    nickelPpm = 3.0,
                    vanadiumPpm = 4.0,
                    pourPointC = -15.0,
                    yields = AssayYields(1.8, 6.0, 18.0, 14.5, 33.5, 18.0, 8.2)
                ),
                description = "Low-pour sweet Nigerian grade yielding top-tier marine gasoil and jet fuel."
            ),
            CrudeGrade(
                id = "TUPI",
                name = "Tupi (Lula)",
                code = "TUPI",
                region = Region.LATIN_AMERICA,
                country = "Brazil",
                loadingTerminal = "Santos Basin FPSO / Angra dos Reis",
                benchmarkRef = "Dated Brent",
                baseDifferential = -0.30,
                assay = CrudeAssay(
                    apiGravity = 29.5,
                    sulfurWtPct = 0.42,
                    viscosityCst50 = 8.2,
                    tanMgKohPerG = 0.45,
                    nickelPpm = 5.0,
                    vanadiumPpm = 7.0,
                    pourPointC = -3.0,
                    yields = AssayYields(1.7, 5.8, 17.0, 13.2, 31.5, 20.0, 10.8)
                ),
                description = "Brazilian pre-salt medium sweet crude, staple diet for Chinese and Indian refiners."
            ),
            CrudeGrade(
                id = "WCS",
                name = "Western Canadian Select",
                code = "WCS",
                region = Region.NORTH_AMERICA,
                country = "Canada",
                loadingTerminal = "Hardisty / Trans Mountain Westridge",
                benchmarkRef = "WTI Cushing",
                baseDifferential = -12.50,
                assay = CrudeAssay(
                    apiGravity = 20.5,
                    sulfurWtPct = 3.50,
                    viscosityCst50 = 85.0,
                    tanMgKohPerG = 1.10,
                    nickelPpm = 35.0,
                    vanadiumPpm = 95.0,
                    pourPointC = -30.0,
                    yields = AssayYields(1.1, 3.8, 11.5, 7.5, 21.0, 24.5, 30.6)
                ),
                description = "Heavy sour Canadian oil sands bitumen blend, feedstock for deep coking refineries."
            ),
            CrudeGrade(
                id = "MAYA",
                name = "Maya Crude",
                code = "MAYA",
                region = Region.LATIN_AMERICA,
                country = "Mexico",
                loadingTerminal = "Cayo Arcas / Dos Bocas",
                benchmarkRef = "WTI Cushing",
                baseDifferential = -5.80,
                assay = CrudeAssay(
                    apiGravity = 21.8,
                    sulfurWtPct = 3.40,
                    viscosityCst50 = 65.0,
                    tanMgKohPerG = 0.70,
                    nickelPpm = 45.0,
                    vanadiumPpm = 250.0,
                    pourPointC = -25.0,
                    yields = AssayYields(1.2, 4.2, 12.8, 8.0, 22.5, 23.5, 27.8)
                ),
                description = "Heavy sour Mexican benchmark crude with high metal content and asphalt yields."
            ),
            CrudeGrade(
                id = "URALS",
                name = "Urals (Primorsk/Novorossiysk)",
                code = "URLS",
                region = Region.RUSSIA_EURASIA,
                country = "Russia",
                loadingTerminal = "Primorsk / Novorossiysk",
                benchmarkRef = "Dated Brent",
                baseDifferential = -8.20,
                assay = CrudeAssay(
                    apiGravity = 31.2,
                    sulfurWtPct = 1.70,
                    viscosityCst50 = 7.1,
                    tanMgKohPerG = 0.22,
                    nickelPpm = 7.0,
                    vanadiumPpm = 25.0,
                    pourPointC = -15.0,
                    yields = AssayYields(1.9, 6.5, 18.0, 12.5, 28.5, 19.5, 13.1)
                ),
                description = "Medium sour Russian export blend traded under geopolitical price cap mechanisms."
            )
        )
    }

    fun getGradeById(id: String): CrudeGrade? = CRUDE_DATABASE.find { it.id.equals(id, ignoreCase = true) || it.code.equals(id, ignoreCase = true) }
}
