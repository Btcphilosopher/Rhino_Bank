import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { 
  PhysicalState, 
  QuantityUnit, 
  DeliveryBasis, 
  DeliveryWindow, 
  CargoSize, 
  OrderSide, 
  OrderType, 
  OrderStatus, 
  TradeStatus, 
  LotStatus, 
  OutageState, 
  DisputeState, 
  ShipmentStatus, 
  ChemicalProduct, 
  ChemicalGrade, 
  DeliveryPoint, 
  Market, 
  Order, 
  Trade, 
  ChemicalLot, 
  CertificateOfAnalysis, 
  QualityDispute, 
  MeasurementEvent, 
  Shipment, 
  Invoice, 
  LedgerEntry, 
  Plant, 
  Participant, 
  MarketData, 
  AuditEvent 
} from "./src/types.js";

const app = express();
app.use(express.json());
const PORT = 3000;

// State Persistence (In-memory strict database mimicking Section 92 & 93)
const products: ChemicalProduct[] = [];
const grades: ChemicalGrade[] = [];
const deliveryPoints: DeliveryPoint[] = [];
const markets: Market[] = [];
const participants: Participant[] = [];
const orders: Order[] = [];
const trades: Trade[] = [];
const inventoryLots: ChemicalLot[] = [];
const certificates: CertificateOfAnalysis[] = [];
const disputes: QualityDispute[] = [];
const measurements: MeasurementEvent[] = [];
const shipments: Shipment[] = [];
const invoices: Invoice[] = [];
const ledgerEntries: LedgerEntry[] = [];
const plants: Plant[] = [];
const auditEvents: AuditEvent[] = [];

// Orderbook structure: { [market_id]: { bids: Order[], asks: Order[] } }
const orderbooks: { 
  [key: string]: { 
    bids: Order[]; 
    asks: Order[]; 
  } 
} = {};

// Pricing metrics tracking
const marketStatistics: {
  [market_id: string]: {
    last: number | null;
    open: number | null;
    high: number | null;
    low: number | null;
    vwap: number | null;
    volume: number;
    trade_count: number;
    price_history: { timestamp: string; price: number; quantity: number }[];
  }
} = {};

// Broadcaster for Real-time Market Data (SSE)
let sseClients: any[] = [];
function broadcast(event: string, data: any) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  sseClients.forEach(client => client.write(payload));
}

// Sequence generators
let orderSequence = 1000;
let tradeSequence = 2000;
let exchangeSeq = 1;
let lotSequence = 5000;
let coaSequence = 6000;
let shipmentSequence = 7000;
let invoiceSequence = 8000;
let ledgerSequence = 9000;
let auditSequence = 1;
let disputeSequence = 4000;

// Helper to record audit events (Section 85)
function logAudit(actor: string, entity: string, reason: string, before: any, after: any) {
  const seq = auditSequence++;
  const event: AuditEvent = {
    event_id: `AUD-${seq.toString().padStart(6, '0')}`,
    actor,
    timestamp: new Date().toISOString(),
    sequence: seq,
    entity,
    before_state_hash: Buffer.from(JSON.stringify(before || {})).toString("base64").slice(0, 12),
    after_state_hash: Buffer.from(JSON.stringify(after || {})).toString("base64").slice(0, 12),
    reason
  };
  auditEvents.push(event);
}

// -----------------------------------------------------
// 1. SEED DATA GENERATION (Sections 3, 17, 95)
// -----------------------------------------------------
function initializeSeedData() {
  // Products
  const sampleProducts: Omit<ChemicalProduct, "">[] = [
    {
      product_id: "P-BENZENE",
      chemical_name: "Benzene",
      CAS_number: "71-43-2",
      molecular_formula: "C6H6",
      molecular_weight: 78.11,
      UN_number: "UN 1114",
      hazard_classification: "Class 3 (Flammable Liquid), GHS02, GHS07, GHS08",
      physical_state: PhysicalState.LIQUID,
      standard_unit: QuantityUnit.MT,
      density: 0.876,
      boiling_point: 80.1,
      melting_point: 5.5,
      default_grade: "G-BENZ-IND",
      quality_schema: { purity_min: 99.9, water_max: 150, color_max: 20, non_aromatics_max: 0.1 }
    },
    {
      product_id: "P-METHANOL",
      chemical_name: "Methanol",
      CAS_number: "67-56-1",
      molecular_formula: "CH3OH",
      molecular_weight: 32.04,
      UN_number: "UN 1230",
      hazard_classification: "Class 3 (Flammable), Class 6.1 (Toxic)",
      physical_state: PhysicalState.LIQUID,
      standard_unit: QuantityUnit.MT,
      density: 0.792,
      boiling_point: 64.7,
      melting_point: -97.6,
      default_grade: "G-METH-AA",
      quality_schema: { purity_min: 99.85, water_max: 1000, color_max: 5 }
    },
    {
      product_id: "P-PROPYLENE",
      chemical_name: "Propylene",
      CAS_number: "115-07-1",
      molecular_formula: "C3H6",
      molecular_weight: 42.08,
      UN_number: "UN 1077",
      hazard_classification: "Class 2.1 (Flammable Gas)",
      physical_state: PhysicalState.GAS,
      standard_unit: QuantityUnit.MT,
      density: 0.5139,
      boiling_point: -47.6,
      melting_point: -185.2,
      default_grade: "G-PROP-CHEM",
      quality_schema: { purity_min: 99.5, water_max: 10, color_max: 10 }
    },
    {
      product_id: "P-STYRENE",
      chemical_name: "Styrene Monomer",
      CAS_number: "100-42-5",
      molecular_formula: "C8H8",
      molecular_weight: 104.15,
      UN_number: "UN 2055",
      hazard_classification: "Class 3 (Flammable Liquid), Toxic",
      physical_state: PhysicalState.LIQUID,
      density: 0.906,
      boiling_point: 145.0,
      melting_point: -30.0,
      standard_unit: QuantityUnit.MT,
      default_grade: "G-STYR-IND",
      quality_schema: { purity_min: 99.7, water_max: 150, color_max: 10 }
    },
    {
      product_id: "P-MEG",
      chemical_name: "Monoethylene Glycol",
      CAS_number: "107-21-1",
      molecular_formula: "C2H6O2",
      molecular_weight: 62.07,
      UN_number: "N/A",
      hazard_classification: "GHS07 (Harmful)",
      physical_state: PhysicalState.LIQUID,
      density: 1.11,
      boiling_point: 197.3,
      melting_point: -12.9,
      standard_unit: QuantityUnit.MT,
      default_grade: "G-MEG-IND",
      quality_schema: { purity_min: 99.8, water_max: 800, color_max: 10 }
    },
    {
      product_id: "P-CAUSTIC",
      chemical_name: "Caustic Soda (Sodium Hydroxide)",
      CAS_number: "1310-73-2",
      molecular_formula: "NaOH",
      molecular_weight: 40.0,
      UN_number: "UN 1823 / UN 1824",
      hazard_classification: "Class 8 (Corrosive)",
      physical_state: PhysicalState.LIQUID,
      density: 1.52, // 50% solution density approx
      boiling_point: 140.0,
      melting_point: 12.0,
      standard_unit: QuantityUnit.MT,
      default_grade: "G-CAUS-50",
      quality_schema: { purity_min: 50.0, water_max: 500000, color_max: 30 }
    },
    {
      product_id: "P-POLYPROPYLENE",
      chemical_name: "Polypropylene",
      CAS_number: "9003-07-0",
      molecular_formula: "(C3H6)n",
      molecular_weight: 120000,
      UN_number: "N/A",
      hazard_classification: "Non-hazardous",
      physical_state: PhysicalState.PELLET,
      density: 0.90,
      boiling_point: 160.0,
      melting_point: 130.0,
      standard_unit: QuantityUnit.MT,
      default_grade: "G-PP-INJ",
      quality_schema: { purity_min: 99.0, water_max: 200, color_max: 5 }
    }
  ];
  products.push(...(sampleProducts as ChemicalProduct[]));

  // Grades
  grades.push(
    {
      grade_id: "G-BENZ-IND",
      product_id: "P-BENZENE",
      name: "Benzene Industrial Grade",
      specification_revision: "REV-2026-A",
      quality_parameters: ["Purity", "Water Content", "Pt-Co Color", "Non-aromatics"],
      allowed_tolerances: "Purity +/- 0.05%, Water max 150ppm",
      certification_requirements: ["COA", "ISO 9001"]
    },
    {
      grade_id: "G-METH-AA",
      product_id: "P-METHANOL",
      name: "Methanol Grade AA",
      specification_revision: "REV-2025-C",
      quality_parameters: ["Purity", "Water Content", "Pt-Co Color"],
      allowed_tolerances: "Purity +/- 0.02%",
      certification_requirements: ["COA", "IMPCA Standard"]
    },
    {
      grade_id: "G-PROP-CHEM",
      product_id: "P-PROPYLENE",
      name: "Propylene Chemical Grade",
      specification_revision: "REV-2026-B",
      quality_parameters: ["Purity", "Water Content"],
      allowed_tolerances: "Purity min 99.5%",
      certification_requirements: ["COA"]
    },
    {
      grade_id: "G-STYR-IND",
      product_id: "P-STYRENE",
      name: "Styrene Industrial",
      specification_revision: "REV-2026-A",
      quality_parameters: ["Purity", "Water Content", "Pt-Co Color"],
      allowed_tolerances: "Purity min 99.7%",
      certification_requirements: ["COA"]
    },
    {
      grade_id: "G-MEG-IND",
      product_id: "P-MEG",
      name: "Monoethylene Glycol Industrial",
      specification_revision: "REV-2025-E",
      quality_parameters: ["Purity", "Water Content", "Pt-Co Color"],
      allowed_tolerances: "Purity min 99.8%",
      certification_requirements: ["COA"]
    },
    {
      grade_id: "G-CAUS-50",
      product_id: "P-CAUSTIC",
      name: "Caustic Soda 50% Membrane",
      specification_revision: "REV-2026-A",
      quality_parameters: ["Purity/Concentration", "Chlorides", "Iron"],
      allowed_tolerances: "NaOH 49.0% - 51.0%",
      certification_requirements: ["COA"]
    },
    {
      grade_id: "G-PP-INJ",
      product_id: "P-POLYPROPYLENE",
      name: "PP Injection Grade Homopolymer",
      specification_revision: "REV-2026-R",
      quality_parameters: ["Melt Flow Rate", "Density", "Purity"],
      allowed_tolerances: "MFR 12 +/- 2 g/10 min",
      certification_requirements: ["COA", "FDA Compliance Certificate"]
    }
  );

  // Delivery Points (Synthetic Hubs, Section 17)
  const locations: DeliveryPoint[] = [
    {
      delivery_point_id: "LOC-RTM",
      name: "Rotterdam Botlek Terminal",
      country: "Netherlands",
      region: "Northwest Europe",
      port: "Port of Rotterdam",
      terminal: "Vopak Botlek",
      warehouse: "Vopak WH 4",
      pipeline_node: "ARG Pipeline Node RTM",
      factory: "LyondellBasell Reactor",
      coordinates: [51.872, 4.295],
      transport_modes: ["BARGE", "VESSEL", "TRUCK", "PIPELINE"],
      operating_hours: "24/7/365 Continuous"
    },
    {
      delivery_point_id: "LOC-ANT",
      name: "Antwerp Eurochem Terminal",
      country: "Belgium",
      region: "Northwest Europe",
      port: "Port of Antwerp-Bruges",
      terminal: "Eurochem T105",
      warehouse: "Antwerp Dry WH",
      pipeline_node: "ARG Pipeline Node ANT",
      factory: "BASF Styrene Unit",
      coordinates: [51.272, 4.318],
      transport_modes: ["BARGE", "VESSEL", "TRUCK", "PIPELINE", "RAIL"],
      operating_hours: "24/7/365 Continuous"
    },
    {
      delivery_point_id: "LOC-HOU",
      name: "Houston Ship Channel Terminal",
      country: "USA",
      region: "US Gulf Coast",
      port: "Port of Houston",
      terminal: "ITC Deer Park",
      warehouse: "ITC WH B",
      pipeline_node: "ExxonMobil Pipeline Hub",
      factory: "Chevron Phillips Ethylene Unit",
      coordinates: [29.728, -95.121],
      transport_modes: ["VESSEL", "BARGE", "TRUCK", "PIPELINE", "RAIL"],
      operating_hours: "24/7/365 Continuous"
    },
    {
      delivery_point_id: "LOC-SGP",
      name: "Singapore Jurong Island Terminal",
      country: "Singapore",
      region: "Southeast Asia",
      port: "Port of Singapore",
      terminal: "Oiltanking Jurong",
      warehouse: "Jurong Dry Vaults",
      pipeline_node: "Jurong Pipeline Grid",
      factory: "Shell Cracker Team-1",
      coordinates: [1.274, 103.722],
      transport_modes: ["VESSEL", "BARGE", "PIPELINE"],
      operating_hours: "24/7/365 Continuous"
    }
  ];
  deliveryPoints.push(...locations);

  // Markets (Section 4, 5)
  const sampleMarkets: Market[] = [
    {
      market_id: "RHX-BENZENE-NWE",
      symbol: "RHX-BENZ-NWE",
      product_id: "P-BENZENE",
      region: "Northwest Europe",
      default_grade: "G-BENZ-IND",
      delivery_basis: DeliveryBasis.FOB,
      currency: "EUR",
      unit: QuantityUnit.MT,
      minimum_lot: 100,
      tick_size: 1, // EUR 1 / MT
      trading_session: "08:00 - 18:00 CET",
      settlement_rule: "Physical delivery within 3 days",
      quality_standard: "ASTM D5135 compliant Benzene",
      active_status: true,
      base_price: 810
    },
    {
      market_id: "RHX-METHANOL-NWE",
      symbol: "RHX-METH-NWE",
      product_id: "P-METHANOL",
      region: "Northwest Europe",
      default_grade: "G-METH-AA",
      delivery_basis: DeliveryBasis.FOB,
      currency: "EUR",
      unit: QuantityUnit.MT,
      minimum_lot: 100,
      tick_size: 0.5,
      trading_session: "08:00 - 18:00 CET",
      settlement_rule: "Standard clearing, FOB Rotterdam",
      quality_standard: "IMPCA Reference Specification",
      active_status: true,
      base_price: 340
    },
    {
      market_id: "RHX-PROPYLENE-NWE",
      symbol: "RHX-PROP-NWE",
      product_id: "P-PROPYLENE",
      region: "Northwest Europe",
      default_grade: "G-PROP-CHEM",
      delivery_basis: DeliveryBasis.FCA,
      currency: "EUR",
      unit: QuantityUnit.MT,
      minimum_lot: 150,
      tick_size: 1.0,
      trading_session: "08:00 - 18:00 CET",
      settlement_rule: "FCA Pipeline or Tanker",
      quality_standard: "Polymer-grade minimum 99.5%",
      active_status: true,
      base_price: 920
    },
    {
      market_id: "RHX-STYRENE-NWE",
      symbol: "RHX-STYR-NWE",
      product_id: "P-STYRENE",
      region: "Northwest Europe",
      default_grade: "G-STYR-IND",
      delivery_basis: DeliveryBasis.FOB,
      currency: "EUR",
      unit: QuantityUnit.MT,
      minimum_lot: 100,
      tick_size: 1.0,
      trading_session: "08:00 - 18:00 CET",
      settlement_rule: "Physical FOB delivery",
      quality_standard: "Commercial Styrene purity 99.7%",
      active_status: true,
      base_price: 1150
    },
    {
      market_id: "RHX-MEG-NWE",
      symbol: "RHX-MEG-NWE",
      product_id: "P-MEG",
      region: "Northwest Europe",
      default_grade: "G-MEG-IND",
      delivery_basis: DeliveryBasis.CIF,
      currency: "EUR",
      unit: QuantityUnit.MT,
      minimum_lot: 200,
      tick_size: 0.5,
      trading_session: "08:00 - 18:00 CET",
      settlement_rule: "CIF Rotterdam / Antwerp",
      quality_standard: "Polyester fiber grade MEG",
      active_status: true,
      base_price: 680
    },
    {
      market_id: "RHX-CAUSTIC-NWE",
      symbol: "RHX-CAUS-NWE",
      product_id: "P-CAUSTIC",
      region: "Northwest Europe",
      default_grade: "G-CAUS-50",
      delivery_basis: DeliveryBasis.DDP,
      currency: "EUR",
      unit: QuantityUnit.MT,
      minimum_lot: 50,
      tick_size: 1.0,
      trading_session: "08:00 - 18:00 CET",
      settlement_rule: "DDP Industrial Consumers",
      quality_standard: "Chlor-alkali 50% concentration",
      active_status: true,
      base_price: 520
    },
    {
      market_id: "RHX-POLYPROPYLENE-NWE",
      symbol: "RHX-PP-NWE",
      product_id: "P-POLYPROPYLENE",
      region: "Northwest Europe",
      default_grade: "G-PP-INJ",
      delivery_basis: DeliveryBasis.FCA,
      currency: "EUR",
      unit: QuantityUnit.MT,
      minimum_lot: 50,
      tick_size: 5.0,
      trading_session: "08:00 - 18:00 CET",
      settlement_rule: "FCA Warehouse / Silo",
      quality_standard: "PP homopolymer, MFR 12",
      active_status: true,
      base_price: 1240
    }
  ];
  markets.push(...sampleMarkets);

  // Setup Orderbooks
  markets.forEach(m => {
    orderbooks[m.market_id] = { bids: [], asks: [] };
    marketStatistics[m.market_id] = {
      last: m.base_price,
      open: m.base_price,
      high: m.base_price,
      low: m.base_price,
      vwap: m.base_price,
      volume: 0,
      trade_count: 0,
      price_history: [
        { timestamp: new Date(Date.now() - 3600 * 1000 * 4).toISOString(), price: m.base_price - 5, quantity: 150 },
        { timestamp: new Date(Date.now() - 3600 * 1000 * 3).toISOString(), price: m.base_price + 3, quantity: 200 },
        { timestamp: new Date(Date.now() - 3600 * 1000 * 2).toISOString(), price: m.base_price - 2, quantity: 100 },
        { timestamp: new Date(Date.now() - 3600 * 1000 * 1).toISOString(), price: m.base_price, quantity: 250 }
      ]
    };
  });

  // Participants (Section 95)
  // Seed Rhinoquant Opportunity Fund first (€1 Billion Capital)
  participants.push({
    participant_id: "PT-RHINO-FUND",
    name: "Rhinoquant Chemical Opportunity Fund",
    type: "FUND",
    permitted_products: ["P-BENZENE", "P-METHANOL", "P-PROPYLENE", "P-STYRENE", "P-MEG", "P-CAUSTIC", "P-POLYPROPYLENE"],
    credit_limit: 500000000,
    cash_balance: 1000000000, // €1 Billion
    allocated_margin: 0,
    physical_capacity: 50000 // MT maximum storage
  });

  // Create 5 standard Producers
  const producersList = [
    { id: "PT-PROD-ANT", name: "Antwerp Petrochemical Co.", limit: 10000000, cash: 50000000, cap: 100000 },
    { id: "PT-PROD-RTM", name: "Rotterdam Aromatics BV", limit: 8000000, cash: 40000000, cap: 80000 },
    { id: "PT-PROD-BASF", name: "BASF Synth-Works", limit: 15000000, cash: 100000000, cap: 150000 },
    { id: "PT-PROD-SHELL", name: "Shell Eastern Chemical", limit: 12000000, cash: 80000000, cap: 120000 },
    { id: "PT-PROD-CPCHEM", name: "CP Chemical Houston", limit: 10000000, cash: 45000000, cap: 110000 }
  ];
  producersList.forEach(p => {
    participants.push({
      participant_id: p.id,
      name: p.name,
      type: "PRODUCER",
      permitted_products: ["P-BENZENE", "P-METHANOL", "P-PROPYLENE", "P-STYRENE", "P-MEG", "P-CAUSTIC", "P-POLYPROPYLENE"],
      credit_limit: p.limit,
      cash_balance: p.cash,
      allocated_margin: 0,
      physical_capacity: p.cap
    });
  });

  // Create 5 standard Buyers
  const buyersList = [
    { id: "PT-BUY-BAYER", name: "Bayer Materials AG", limit: 5000000, cash: 20000000, cap: 30000 },
    { id: "PT-BUY-AKZO", name: "AkzoNobel Coatings", limit: 4000000, cash: 15000000, cap: 20000 },
    { id: "PT-BUY-DOW", name: "Dow Polyurethane Hub", limit: 8000000, cash: 30000000, cap: 40000 },
    { id: "PT-BUY-LOTTE", name: "Lotte Korea Chemical", limit: 6000000, cash: 25000000, cap: 35000 },
    { id: "PT-BUY-INEOS", name: "Ineos Polymers NWE", limit: 7000000, cash: 28000000, cap: 38000 }
  ];
  buyersList.forEach(b => {
    participants.push({
      participant_id: b.id,
      name: b.name,
      type: "BUYER",
      permitted_products: ["P-BENZENE", "P-METHANOL", "P-PROPYLENE", "P-STYRENE", "P-MEG", "P-CAUSTIC", "P-POLYPROPYLENE"],
      credit_limit: b.limit,
      cash_balance: b.cash,
      allocated_margin: 0,
      physical_capacity: b.cap
    });
  });

  // Seed inventory lots for producers (Section 31)
  const producerLots = [
    { lot: "LOT-BENZ-01", prod: "P-BENZENE", grade: "G-BENZ-IND", qty: 10000, owner: "PT-PROD-ANT", loc: "LOC-ANT", purity: 99.94, water: 80, color: 8 },
    { lot: "LOT-BENZ-02", prod: "P-BENZENE", grade: "G-BENZ-IND", qty: 5000, owner: "PT-PROD-RTM", loc: "LOC-RTM", purity: 99.91, water: 120, color: 12 },
    { lot: "LOT-METH-01", prod: "P-METHANOL", grade: "G-METH-AA", qty: 12000, owner: "PT-PROD-BASF", loc: "LOC-ANT", purity: 99.88, water: 450, color: 3 },
    { lot: "LOT-PROP-01", prod: "P-PROPYLENE", grade: "G-PROP-CHEM", qty: 8000, owner: "PT-PROD-SHELL", loc: "LOC-SGP", purity: 99.6, water: 4, color: 5 },
    { lot: "LOT-STYR-01", prod: "P-STYRENE", grade: "G-STYR-IND", qty: 6000, owner: "PT-PROD-ANT", loc: "LOC-ANT", purity: 99.85, water: 90, color: 6 },
    { lot: "LOT-PP-01", prod: "P-POLYPROPYLENE", grade: "G-PP-INJ", qty: 4500, owner: "PT-PROD-BASF", loc: "LOC-RTM", purity: 99.2, water: 50, color: 2 }
  ];

  producerLots.forEach(l => {
    // Generate certificate (Section 34)
    const coa_id = `COA-${coaSequence++}`;
    const lot: ChemicalLot = {
      lot_id: l.lot,
      product_id: l.prod,
      grade_id: l.grade,
      batch: `BAT-${Math.floor(Math.random() * 9000 + 1000)}`,
      quantity: l.qty,
      production_date: new Date(Date.now() - 3600 * 1000 * 24 * 5).toISOString(),
      origin: "NWE Chemical Synthesis Plant",
      current_location: l.loc,
      quality_certificate_id: coa_id,
      ownership: l.owner,
      status: LotStatus.DELIVERY_READY
    };
    inventoryLots.push(lot);

    const coa: CertificateOfAnalysis = {
      coa_id,
      lot_id: l.lot,
      laboratory: "Eurospec Quality Labs, Antwerp",
      test_date: new Date(Date.now() - 3600 * 1000 * 24 * 4).toISOString(),
      parameters: [
        { parameter: "Purity", value: l.purity, unit: "%", specification: ">= 99.5%", pass: true },
        { parameter: "Water Content", value: l.water, unit: "ppm", specification: "<= 1000 ppm", pass: true },
        { parameter: "Pt-Co Color", value: l.color, unit: "Pt-Co", specification: "<= 20", pass: true }
      ],
      pass_fail: true,
      document_reference: `DOC-REF-${coa_id}`
    };
    certificates.push(coa);

    // Record double entry for initial stock creation
    const acct = `INV-${l.owner}`;
    ledgerEntries.push({
      entry_id: `LED-${ledgerSequence++}`,
      account_id: acct,
      debit: l.qty,
      credit: 0,
      description: `Initial inventory lot seed: ${l.lot}`,
      timestamp: new Date().toISOString()
    });
  });

  // Synthetic Plants (Section 53)
  plants.push(
    {
      plant_id: "PLT-ANT-CRACK",
      name: "Antwerp Synthetic Cracker IV",
      location: "LOC-ANT",
      capacity: 2500,
      utilisation: 92,
      feedstock: "Naphtha",
      yield_rate: 34,
      variable_cost: 410,
      fixed_cost: 120,
      outage_state: OutageState.RUNNING
    },
    {
      plant_id: "PLT-RTM-AROM",
      name: "Rotterdam Aromatics Complex",
      location: "LOC-RTM",
      capacity: 1800,
      utilisation: 88,
      feedstock: "Reformate",
      yield_rate: 68,
      variable_cost: 380,
      fixed_cost: 95,
      outage_state: OutageState.RUNNING
    },
    {
      plant_id: "PLT-HOU-ST1",
      name: "Houston Styrene Unit One",
      location: "LOC-HOU",
      capacity: 2200,
      utilisation: 95,
      feedstock: "Benzene/Ethylene",
      yield_rate: 98,
      variable_cost: 520,
      fixed_cost: 140,
      outage_state: OutageState.RUNNING
    }
  );

  // Seed Freight Quotes (Section 40)
  // Let's store freight quotes directly in a local list
  logAudit("SYSTEM", "DATABASE", "Database seed completed", null, {
    products: products.length,
    grades: grades.length,
    markets: markets.length,
    lots: inventoryLots.length
  });
}

// Perform initial seed
initializeSeedData();

// -----------------------------------------------------
// 2. ORDER VALIDATION PIPELINE (Section 26)
// -----------------------------------------------------
function validateOrder(order: Partial<Order>): { valid: boolean; error?: string } {
  // Syntax & completeness checks
  if (!order.market_id || !order.side || !order.quantity || !order.price || !order.participant_id) {
    return { valid: false, error: "ERR_SYNTAX: Missing required order fields (market_id, side, quantity, price, participant_id)" };
  }

  // Quantities must be positive
  if (order.quantity <= 0 || order.price <= 0) {
    return { valid: false, error: "ERR_VALUE: Price and quantity must be positive positive values" };
  }

  // Fetch product and market
  const mkt = markets.find(m => m.market_id === order.market_id);
  if (!mkt) return { valid: false, error: `ERR_MARKET: Market ${order.market_id} not found` };
  if (!mkt.active_status) return { valid: false, error: "ERR_MARKET_STATUS: Market is currently closed or inactive" };

  const participant = participants.find(p => p.participant_id === order.participant_id);
  if (!participant) return { valid: false, error: `ERR_PARTICIPANT: Participant ${order.participant_id} not onboarded` };

  // Product validation
  if (order.product_id && order.product_id !== mkt.product_id) {
    return { valid: false, error: `ERR_PRODUCT: Product ${order.product_id} does not match market ${mkt.symbol} product (${mkt.product_id})` };
  }

  // Grade validation
  if (order.grade_id) {
    const grd = grades.find(g => g.grade_id === order.grade_id);
    if (!grd || grd.product_id !== mkt.product_id) {
      return { valid: false, error: `ERR_GRADE: Grade ${order.grade_id} is incompatible or not found` };
    }
  }

  // Tick & Lot checks
  if (order.quantity < mkt.minimum_lot) {
    return { valid: false, error: `ERR_QUANTITY: Minimum lot size is ${mkt.minimum_lot} ${mkt.unit}` };
  }
  const rem = order.price % mkt.tick_size;
  if (Math.abs(rem) > 0.0001 && Math.abs(rem - mkt.tick_size) > 0.0001) {
    return { valid: false, error: `ERR_PRICE_TICK: Price must align with tick size of ${mkt.tick_size}` };
  }

  // Sell-Side Inventory Allocation Checks (Section 27)
  if (order.side === OrderSide.SELL) {
    // Sum all currently resting sell orders for this participant & product
    const activeSellingQuantity = orders
      .filter(o => o.participant_id === order.participant_id && o.product_id === mkt.product_id && o.side === OrderSide.SELL && (o.status === OrderStatus.PENDING || o.status === OrderStatus.PARTIALLY_FILLED))
      .reduce((sum, o) => sum + o.remaining_quantity, 0);

    const availableInventory = inventoryLots
      .filter(lot => lot.ownership === order.participant_id && lot.product_id === mkt.product_id && (lot.status === LotStatus.DELIVERY_READY || lot.status === LotStatus.ALLOCATED))
      .reduce((sum, lot) => sum + lot.quantity, 0);

    if (availableInventory < activeSellingQuantity + order.quantity) {
      return {
        valid: false,
        error: `ERR_SELL_INVENTORY: Insufficient unallocated physical inventory. Available: ${availableInventory - activeSellingQuantity} MT, Requested: ${order.quantity} MT.`
      };
    }
  }

  // Buy-Side Credit limit Check (Section 28)
  if (order.side === OrderSide.BUY) {
    const estimatedNotional = order.quantity * order.price;
    const marginAllocated = estimatedNotional * 0.15; // 15% estimated margin exposure
    const currentUnallocatedCash = participant.cash_balance - participant.allocated_margin;

    if (currentUnallocatedCash < marginAllocated) {
      return {
        valid: false,
        error: `ERR_BUY_CREDIT: Insufficient margin capacity. Cash available: €${currentUnallocatedCash.toLocaleString()}, Margin required: €${marginAllocated.toLocaleString()}`
      };
    }
  }

  return { valid: true };
}

// -----------------------------------------------------
// 3. CENTRAL LIMIT ORDER BOOK (CLOB) & MATCHING ENGINE (Sections 21-25)
// -----------------------------------------------------
function matchOrder(incomingOrder: Order): Trade[] {
  const mkt = markets.find(m => m.market_id === incomingOrder.market_id)!;
  const book = orderbooks[incomingOrder.market_id];
  const matchedTrades: Trade[] = [];

  // Price-Time priority sorting:
  // Bids: highest price first.
  // Offers: lowest price first.
  // Same price: earliest sequence first.
  const sortBids = (a: Order, b: Order) => b.price - a.price || a.exchange_sequence - b.exchange_sequence;
  const sortAsks = (a: Order, b: Order) => a.price - b.price || a.exchange_sequence - b.exchange_sequence;

  if (incomingOrder.side === OrderSide.BUY) {
    // Try to match against Asks (Sells)
    book.asks.sort(sortAsks);
    
    // Check IOC/FOK special behavior
    if (incomingOrder.order_type === OrderType.FOK) {
      // Check if enough total compatible volume is available first
      let cumulativeCompatibleQty = 0;
      for (const ask of book.asks) {
        if (ask.price <= incomingOrder.price && isPhysicallyCompatible(incomingOrder, ask)) {
          cumulativeCompatibleQty += ask.remaining_quantity;
        }
      }
      if (cumulativeCompatibleQty < incomingOrder.quantity) {
        incomingOrder.status = OrderStatus.REJECTED;
        logAudit("SYSTEM", "OrderBook", "FOK order rejected due to insufficient matchable inventory", incomingOrder, null);
        return [];
      }
    }

    let i = 0;
    while (incomingOrder.remaining_quantity > 0 && i < book.asks.length) {
      const ask = book.asks[i];
      
      // Match condition: Best Ask <= incoming Buy price
      if (ask.price <= incomingOrder.price) {
        // Physical compatibility guard (Section 9, 135)
        if (isPhysicallyCompatible(incomingOrder, ask)) {
          const matchPrice = ask.price; // Resting order price rules
          const matchQty = Math.min(incomingOrder.remaining_quantity, ask.remaining_quantity);

          executeMatch(incomingOrder, ask, matchPrice, matchQty, matchedTrades);

          if (ask.remaining_quantity === 0) {
            book.asks.splice(i, 1);
          } else {
            i++;
          }
        } else {
          // If physically incompatible, look at next ask
          i++;
        }
      } else {
        break; // No more asks under the buy limit
      }
    }

    // Handle remaining IOC / FOK
    if (incomingOrder.remaining_quantity > 0) {
      if (incomingOrder.order_type === OrderType.IOC || incomingOrder.order_type === OrderType.FOK) {
        incomingOrder.status = OrderStatus.CANCELLED;
        logAudit("SYSTEM", "Order", "IOC remaining cancelled", incomingOrder, null);
      } else {
        incomingOrder.status = incomingOrder.remaining_quantity === incomingOrder.quantity ? OrderStatus.PENDING : OrderStatus.PARTIALLY_FILLED;
        book.bids.push(incomingOrder);
        book.bids.sort(sortBids);
      }
    } else {
      incomingOrder.status = OrderStatus.FILLED;
    }

  } else {
    // Try to match against Bids (Buys)
    book.bids.sort(sortBids);

    if (incomingOrder.order_type === OrderType.FOK) {
      let cumulativeCompatibleQty = 0;
      for (const bid of book.bids) {
        if (bid.price >= incomingOrder.price && isPhysicallyCompatible(incomingOrder, bid)) {
          cumulativeCompatibleQty += bid.remaining_quantity;
        }
      }
      if (cumulativeCompatibleQty < incomingOrder.quantity) {
        incomingOrder.status = OrderStatus.REJECTED;
        logAudit("SYSTEM", "OrderBook", "FOK sell order rejected due to insufficient matching bids", incomingOrder, null);
        return [];
      }
    }

    let i = 0;
    while (incomingOrder.remaining_quantity > 0 && i < book.bids.length) {
      const bid = book.bids[i];

      // Match condition: Best Bid >= incoming Sell price
      if (bid.price >= incomingOrder.price) {
        if (isPhysicallyCompatible(incomingOrder, bid)) {
          const matchPrice = bid.price;
          const matchQty = Math.min(incomingOrder.remaining_quantity, bid.remaining_quantity);

          executeMatch(bid, incomingOrder, matchPrice, matchQty, matchedTrades);

          if (bid.remaining_quantity === 0) {
            book.bids.splice(i, 1);
          } else {
            i++;
          }
        } else {
          i++;
        }
      } else {
        break; // No more bids above the sell limit
      }
    }

    // Handle remaining IOC / FOK
    if (incomingOrder.remaining_quantity > 0) {
      if (incomingOrder.order_type === OrderType.IOC || incomingOrder.order_type === OrderType.FOK) {
        incomingOrder.status = OrderStatus.CANCELLED;
        logAudit("SYSTEM", "Order", "IOC remaining cancelled", incomingOrder, null);
      } else {
        incomingOrder.status = incomingOrder.remaining_quantity === incomingOrder.quantity ? OrderStatus.PENDING : OrderStatus.PARTIALLY_FILLED;
        book.asks.push(incomingOrder);
        book.asks.sort(sortAsks);
      }
    } else {
      incomingOrder.status = OrderStatus.FILLED;
    }
  }

  // Update market stats if any execution occurred
  if (matchedTrades.length > 0) {
    const latestTrade = matchedTrades[matchedTrades.length - 1];
    const stats = marketStatistics[incomingOrder.market_id];
    stats.last = latestTrade.price;
    stats.trade_count += matchedTrades.length;
    stats.volume += matchedTrades.reduce((sum, t) => sum + t.quantity, 0);

    const priceList = stats.price_history;
    priceList.push(...matchedTrades.map(t => ({ timestamp: t.timestamp, price: t.price, quantity: t.quantity })));
    stats.high = Math.max(...priceList.map(p => p.price));
    stats.low = Math.min(...priceList.map(p => p.price));

    // Calculate VWAP (Section 50)
    const totalNotional = priceList.reduce((sum, h) => sum + (h.price * h.quantity), 0);
    const totalQty = priceList.reduce((sum, h) => sum + h.quantity, 0);
    stats.vwap = totalQty > 0 ? parseFloat((totalNotional / totalQty).toFixed(2)) : stats.last;

    broadcast("PRICE_UPDATED", {
      market_id: incomingOrder.market_id,
      last: stats.last,
      vwap: stats.vwap,
      volume: stats.volume,
      trade_count: stats.trade_count,
      high: stats.high,
      low: stats.low
    });
  }

  return matchedTrades;
}

// Check physical product, grade, and delivery compatibility (Sections 9, 25, 135)
function isPhysicallyCompatible(buy: Order, sell: Order): boolean {
  if (buy.product_id !== sell.product_id) return false;
  
  // Grade compatibility check (Section 10 - Fungibility rules)
  if (buy.grade_id && sell.grade_id && buy.grade_id !== sell.grade_id) {
    return false;
  }

  // Delivery basis & terminal hub matching logic
  // Rotterdam, Antwerp, Singapore, Houston. If we specify delivery point, they must correspond to same shipping region
  const buyLoc = deliveryPoints.find(d => d.delivery_point_id === buy.delivery_point_id);
  const sellLoc = deliveryPoints.find(d => d.delivery_point_id === sell.delivery_point_id);
  if (buyLoc && sellLoc && buyLoc.region !== sellLoc.region) {
    return false; // Intercontinental matches forbidden in spot exchange
  }

  // Cargo types compatibility check
  if (buy.cargo_type && sell.cargo_type && buy.cargo_type !== sell.cargo_type) {
    return false;
  }

  return true;
}

// -----------------------------------------------------
// 4. TRANSACTION & PHYSICAL DELIVERY ALLOCATION PIPELINE (Sections 30-39, 74)
// -----------------------------------------------------
function executeMatch(buy: Order, sell: Order, price: number, qty: number, tradeList: Trade[]) {
  const mkt = markets.find(m => m.market_id === buy.market_id)!;
  const seq = tradeSequence++;
  const notional = price * qty;
  const fees = parseFloat((notional * 0.001).toFixed(2)); // 0.1% transaction fee

  // Deduct quantities
  buy.remaining_quantity -= qty;
  sell.remaining_quantity -= qty;

  buy.status = buy.remaining_quantity === 0 ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED;
  sell.status = sell.remaining_quantity === 0 ? OrderStatus.FILLED : OrderStatus.PARTIALLY_FILLED;

  const trade: Trade = {
    trade_id: `RHX-TRD-${seq}`,
    timestamp: new Date().toISOString(),
    market_id: mkt.market_id,
    product_id: buy.product_id,
    grade_id: buy.grade_id || mkt.default_grade,
    side: OrderSide.BUY,
    price,
    quantity: qty,
    notional,
    buy_order_id: buy.order_id,
    sell_order_id: sell.order_id,
    buy_participant_id: buy.participant_id,
    buy_participant_name: buy.participant_name,
    sell_participant_id: sell.participant_id,
    sell_participant_name: sell.participant_name,
    delivery_point_id: buy.delivery_point_id || sell.delivery_point_id,
    delivery_window: buy.delivery_window,
    delivery_basis: buy.delivery_basis,
    cargo_type: buy.cargo_type,
    status: TradeStatus.EXECUTED,
    lots_allocated: [],
    fees,
    freight_cost: 0,
    adjustments: 0
  };

  trades.push(trade);
  tradeList.push(trade);

  // LOG AUDIT for executed trade
  logAudit("MATCH_ENGINE", "Trade", `Executed trade ${trade.trade_id} for ${qty} MT at €${price}/MT`, null, trade);

  // Trigger Physical Allocation Engine immediately (Section 31-33)
  allocatePhysicalLots(trade);

  // Trigger double-entry accounting entries for margins/hold (Section 73)
  settlePreTradeAccounting(trade);

  broadcast("TRADE_EXECUTED", trade);
}

// Lot Allocation & Traceability Algorithm (Scenario 6, Section 33, 105)
function allocatePhysicalLots(trade: Trade) {
  const sellerId = trade.sell_participant_id;
  const buyerId = trade.buy_participant_id;
  let remainingAlloc = trade.quantity;

  // Retrieve all seller's available lots of correct product and grade
  const sellerLots = inventoryLots.filter(
    lot => lot.ownership === sellerId && 
    lot.product_id === trade.product_id && 
    (lot.status === LotStatus.DELIVERY_READY || lot.status === LotStatus.ALLOCATED)
  );

  const allocatedLotIds: string[] = [];

  for (const lot of sellerLots) {
    if (remainingAlloc <= 0) break;

    if (lot.quantity <= remainingAlloc) {
      // Allocate entire lot
      remainingAlloc -= lot.quantity;
      allocatedLotIds.push(lot.lot_id);
      
      // Update inventory event ledger (Section 30)
      logAudit("SYSTEM", "InventoryLot", `Allocated Lot ${lot.lot_id} fully (${lot.quantity} MT) to trade ${trade.trade_id}`, lot.ownership, buyerId);
      
      // Update lot ownership and status
      lot.status = LotStatus.ALLOCATED;
      lot.ownership = buyerId; // Temporary title transfer
    } else {
      // Split lot: Keep remainder with seller, allocate part to buyer (Section 33)
      const allocatedQty = remainingAlloc;
      const subLotSeq = lotSequence++;
      const newLotId = `${lot.lot_id}-S${subLotSeq}`;
      
      // Split lot creation
      const splitLot: ChemicalLot = {
        lot_id: newLotId,
        product_id: lot.product_id,
        grade_id: lot.grade_id,
        batch: lot.batch,
        quantity: allocatedQty,
        production_date: lot.production_date,
        origin: lot.origin,
        current_location: lot.current_location,
        quality_certificate_id: lot.quality_certificate_id,
        ownership: buyerId,
        status: LotStatus.ALLOCATED
      };
      
      lot.quantity -= allocatedQty; // Seller retains rest
      inventoryLots.push(splitLot);
      allocatedLotIds.push(newLotId);
      remainingAlloc = 0;

      logAudit("SYSTEM", "InventoryLot", `Split Lot ${lot.lot_id}: allocated ${allocatedQty} MT as ${newLotId} to trade ${trade.trade_id}`, lot.ownership, buyerId);
    }
  }

  trade.lots_allocated = allocatedLotIds;
  trade.status = TradeStatus.ALLOCATED;

  // Calculate synthetic Freight Quote & Landed Cost (Section 40, 41)
  const freightRate = calculateSyntheticFreightRate(trade.delivery_point_id, trade.cargo_type);
  trade.freight_cost = parseFloat((freightRate * trade.quantity).toFixed(2));

  // Auto trigger Shipment nomination (Section 38, 39)
  createLogisticsShipment(trade);
}

// Calculate synthetic freight rates (Section 40)
function calculateSyntheticFreightRate(locationId: string, cargo: CargoSize): number {
  // Simple synthetic fuel/mileage model
  let baseRate = 12.5; // EUR per MT
  if (locationId === "LOC-SGP") baseRate = 35.0;
  if (locationId === "LOC-HOU") baseRate = 28.5;

  switch (cargo) {
    case CargoSize.PIPELINE_BATCH: return baseRate * 0.4;
    case CargoSize.BARGE: return baseRate * 0.8;
    case CargoSize.RAIL_TANK: return baseRate * 1.1;
    case CargoSize.ISO_CONTAINER: return baseRate * 1.5;
    case CargoSize.TRUCK: return baseRate * 2.1;
    default: return baseRate;
  }
}

// Logistics Shipment generation (Section 38, 39)
function createLogisticsShipment(trade: Trade) {
  const shipSeq = shipmentSequence++;
  const shipmentId = `RHX-SHP-${shipSeq}`;

  const departureDate = new Date();
  departureDate.setDate(departureDate.getDate() + 1);
  const arrivalDate = new Date();
  arrivalDate.setDate(arrivalDate.getDate() + 3);

  const ship: Shipment = {
    shipment_id: shipmentId,
    trade_id: trade.trade_id,
    carrier: "Schenker Chemical Logistics / ChemBulk Tankers",
    mode: trade.cargo_type === CargoSize.DEEPSEA_CARGO ? "COASTAL TANKER" : "CHEM RAILCAR/TRUCK",
    origin: "Rotterdam Botlek",
    destination: "Antwerp Eurochem",
    cargo_type: trade.cargo_type,
    quantity: trade.quantity,
    departure: departureDate.toISOString(),
    ETA: arrivalDate.toISOString(),
    status: ShipmentStatus.PLANNED,
    events: [
      { timestamp: new Date().toISOString(), status: ShipmentStatus.PLANNED, description: "Logistics nomination scheduled based on trade execution." }
    ]
  };

  shipments.push(ship);
  trade.status = TradeStatus.NOMINATED;
  logAudit("LOGISTICS", "Shipment", `Created shipment ${shipmentId} for trade ${trade.trade_id}`, null, ship);
}

// -----------------------------------------------------
// 5. DOUBLE-ENTRY ACCOUNTING & CLEARING ENGINE (Sections 67-73)
// -----------------------------------------------------
function settlePreTradeAccounting(trade: Trade) {
  const buyer = participants.find(p => p.participant_id === trade.buy_participant_id)!;
  const seller = participants.find(p => p.participant_id === trade.sell_participant_id)!;

  // Margin allocation (15% exposure block)
  const marginAmt = trade.notional * 0.15;
  buyer.allocated_margin += marginAmt;

  // Ledger record (Section 73)
  ledgerEntries.push({
    entry_id: `LED-${ledgerSequence++}`,
    account_id: `CASH-${trade.buy_participant_id}`,
    debit: 0,
    credit: marginAmt,
    description: `Block margin hold for Trade ${trade.trade_id}`,
    timestamp: new Date().toISOString(),
    trade_id: trade.trade_id
  });
}

function processFinalSettlement(trade: Trade, qualityDiscount: number = 0) {
  const buyer = participants.find(p => p.participant_id === trade.buy_participant_id)!;
  const seller = participants.find(p => p.participant_id === trade.sell_participant_id)!;

  // Invoicing (Section 72)
  const finalPrice = trade.price - qualityDiscount;
  const adjustedNotional = finalPrice * trade.quantity;
  const grandTotal = adjustedNotional + trade.freight_cost + trade.fees;

  const invSeq = invoiceSequence++;
  const invoice: Invoice = {
    invoice_id: `RHX-INV-${invSeq}`,
    trade_id: trade.trade_id,
    buyer_id: trade.buy_participant_id,
    seller_id: trade.sell_participant_id,
    quantity: trade.quantity,
    price: trade.price,
    adjustments: -qualityDiscount * trade.quantity,
    fees: trade.fees,
    total: grandTotal,
    currency: "EUR",
    status: "UNPAID",
    created_at: new Date().toISOString()
  };

  invoices.push(invoice);
  trade.invoice_id = invoice.invoice_id;
  trade.adjustments = -qualityDiscount * trade.quantity;

  // Ledger transfers (Strict double entry debit=credit)
  // Releasing margin
  const marginAmt = trade.notional * 0.15;
  buyer.allocated_margin -= marginAmt;

  // Cash movement
  buyer.cash_balance -= grandTotal;
  seller.cash_balance += adjustedNotional; // Seller gets paid net adjustments, minus logistics if they pay, let's keep simple

  invoice.status = "PAID";
  trade.status = TradeStatus.SETTLED;

  ledgerEntries.push(
    {
      entry_id: `LED-${ledgerSequence++}`,
      account_id: `CASH-${trade.buy_participant_id}`,
      debit: 0,
      credit: grandTotal,
      description: `Settle payment for Invoice ${invoice.invoice_id}`,
      timestamp: new Date().toISOString(),
      trade_id: trade.trade_id
    },
    {
      entry_id: `LED-${ledgerSequence++}`,
      account_id: `CASH-${trade.sell_participant_id}`,
      debit: adjustedNotional,
      credit: 0,
      description: `Receive payment for Invoice ${invoice.invoice_id}`,
      timestamp: new Date().toISOString(),
      trade_id: trade.trade_id
    }
  );

  // Mark all allocated lots as released/delivered to buyer's warehouse
  trade.lots_allocated.forEach(lotId => {
    const lot = inventoryLots.find(l => l.lot_id === lotId);
    if (lot) {
      lot.status = LotStatus.DELIVERED;
    }
  });

  logAudit("CLEARING", "Invoice", `Settled trade ${trade.trade_id} with Invoice ${invoice.invoice_id}. Net cash transfer: €${grandTotal.toLocaleString()}`, null, invoice);
}

// -----------------------------------------------------
// 6. OUTAGES, SHOCKS, & SCENARIO ENGINE (Section 54, 97-106)
// -----------------------------------------------------
function triggerPlantOutage(plantId: string) {
  const plant = plants.find(p => p.plant_id === plantId);
  if (!plant) return;

  const prevState = plant.outage_state;
  plant.outage_state = OutageState.UNPLANNED_OUTAGE;
  plant.utilisation = 0;

  // Record audit and broadcast
  logAudit("ADMIN", "Plant", `CRITICAL: Unplanned outage triggered at ${plant.name}`, prevState, plant.outage_state);
  
  // Market shock logic (reduce market supply expectations)
  broadcast("SUPPLY_SHOCK", {
    plant_id: plantId,
    name: plant.name,
    outage_state: OutageState.UNPLANNED_OUTAGE,
    message: `Supply Shortage Warning! Plant outage at ${plant.name} disrupts base chemical cracking stream.`
  });
}

function triggerPortDelay(locationId: string) {
  // Port Delay increases logistics transit/freight cost
  broadcast("LOGISTICS_SHOCK", {
    location_id: locationId,
    message: "Rotterdam Port Congestion detected. Barge queue times increased by 48 hours. Spot freight premium +25% applied."
  });
}

// -----------------------------------------------------
// 7. REST API ENDPOINTS (Sections 125, 127)
// -----------------------------------------------------

// SSE Real-time Streaming
app.get("/api/stream", (req, res) => {
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive"
  });
  sseClients.push(res);
  req.on("close", () => {
    sseClients = sseClients.filter(client => client !== res);
  });
});

// Markets Endpoint
app.get("/api/products", (req, res) => {
  res.json(products);
});

app.get("/api/delivery-points", (req, res) => {
  res.json(deliveryPoints);
});

app.get("/api/markets", (req, res) => {
  res.json(markets);
});

app.get("/api/markets/:id", (req, res) => {
  const mkt = markets.find(m => m.market_id === req.params.id);
  if (!mkt) return res.status(404).json({ error: "Market not found" });
  res.json(mkt);
});

// Orderbooks Endpoint
app.get("/api/orderbook/:market_id", (req, res) => {
  const book = orderbooks[req.params.market_id];
  if (!book) return res.status(404).json({ error: "Market orderbook not found" });

  // Sum bid/ask depth (Section 47)
  const bidsFormatted = book.bids.map(b => ({ price: b.price, quantity: b.remaining_quantity, count: 1 }));
  const asksFormatted = book.asks.map(a => ({ price: a.price, quantity: a.remaining_quantity, count: 1 }));

  res.json({
    bids: bidsFormatted,
    asks: asksFormatted
  });
});

// Orders Endpoints
app.get("/api/orders", (req, res) => {
  res.json(orders);
});

app.post("/api/orders", (req, res) => {
  const val = validateOrder(req.body);
  if (!val.valid) {
    return res.status(400).json({ error: val.error });
  }

  const orderId = `RHX-ORD-${orderSequence++}`;
  const seq = exchangeSeq++;

  const mkt = markets.find(m => m.market_id === req.body.market_id)!;
  const p = participants.find(part => part.participant_id === req.body.participant_id)!;

  const newOrder: Order = {
    order_id: orderId,
    client_order_id: req.body.client_order_id || `CL-${orderId}`,
    participant_id: req.body.participant_id,
    participant_name: p.name,
    market_id: req.body.market_id,
    side: req.body.side,
    quantity: parseFloat(req.body.quantity),
    remaining_quantity: parseFloat(req.body.quantity),
    price: parseFloat(req.body.price),
    order_type: req.body.order_type || OrderType.LIMIT,
    time_in_force: req.body.time_in_force || "GTC",
    product_id: mkt.product_id,
    grade_id: req.body.grade_id || mkt.default_grade,
    quality_spec: req.body.quality_spec || { purity: 99.9, water: 100, color: 10 },
    delivery_point_id: req.body.delivery_point_id || "LOC-RTM",
    delivery_window: req.body.delivery_window || DeliveryWindow.THREE_DAY,
    delivery_basis: req.body.delivery_basis || mkt.delivery_basis,
    cargo_type: req.body.cargo_type || CargoSize.BARGE,
    certificate_requirement: true,
    created_at: new Date().toISOString(),
    exchange_sequence: seq,
    status: OrderStatus.PENDING
  };

  orders.push(newOrder);
  logAudit(p.name, "Order", `Submitted ${newOrder.side} order ${newOrder.order_id}`, null, newOrder);

  // Process Matching (Section 22)
  const tradesMatched = matchOrder(newOrder);

  broadcast("ORDER_BOOK_UPDATED", { market_id: mkt.market_id });

  res.status(201).json({
    order: newOrder,
    trades: tradesMatched
  });
});

app.delete("/api/orders/:id", (req, res) => {
  const orderId = req.params.id;
  const idx = orders.findIndex(o => o.order_id === orderId);
  if (idx === -1) return res.status(404).json({ error: "Order not found" });

  const order = orders[idx];
  order.status = OrderStatus.CANCELLED;

  // Remove from book
  const book = orderbooks[order.market_id];
  if (book) {
    book.bids = book.bids.filter(b => b.order_id !== orderId);
    book.asks = book.asks.filter(a => a.order_id !== orderId);
  }

  logAudit("TRADER", "Order", `Cancelled order ${orderId}`, null, null);
  broadcast("ORDER_BOOK_UPDATED", { market_id: order.market_id });
  res.json({ success: true, order });
});

// Trades blotter
app.get("/api/trades", (req, res) => {
  res.json(trades);
});

// Participant positions & P&L
app.get("/api/positions", (req, res) => {
  // Reconstruct portfolio states dynamically from transaction trades & allocations (Section 62, 63)
  const pos: any = {};
  participants.forEach(p => {
    pos[p.participant_id] = {
      participant_id: p.participant_id,
      name: p.name,
      cash: p.cash_balance,
      physical_mt: 0,
      allocated_mt: 0,
      margin: p.allocated_margin,
      realized_pnl: 0,
      inventory_lots: []
    };
  });

  // Calculate physical metrics based on current chemical lot logs (Section 30)
  inventoryLots.forEach(lot => {
    const pId = lot.ownership;
    if (pos[pId]) {
      pos[pId].physical_mt += lot.quantity;
      pos[pId].inventory_lots.push(lot);
      if (lot.status === LotStatus.ALLOCATED) {
        pos[pId].allocated_mt += lot.quantity;
      }
    }
  });

  // Realized P&L from invoice/settlements
  invoices.forEach(inv => {
    const buyerId = inv.buyer_id;
    const sellerId = inv.seller_id;
    if (pos[sellerId]) pos[sellerId].realized_pnl += (inv.total - inv.fees);
  });

  res.json(Object.values(pos));
});

// Inventory list
app.get("/api/inventory", (req, res) => {
  res.json(inventoryLots);
});

// Deliveries / Shipments
app.get("/api/deliveries", (req, res) => {
  res.json(shipments);
});

// Quality certs, COAs & disputes
app.get("/api/quality", (req, res) => {
  res.json({
    certificates,
    disputes
  });
});

// Dispute endpoint (Section 36)
app.post("/api/quality/dispute", (req, res) => {
  const { trade_id, parameter, claimed_value, measured_value, dispute_by } = req.body;
  const dispId = `DISP-${disputeSequence++}`;

  const dispute: QualityDispute = {
    dispute_id: dispId,
    trade_id,
    disputed_by: dispute_by,
    parameter,
    claimed_value: parseFloat(claimed_value),
    measured_value: parseFloat(measured_value),
    status: DisputeState.OPEN,
    created_at: new Date().toISOString()
  };

  disputes.push(dispute);
  
  // Set trade to disputed status
  const t = trades.find(tr => tr.trade_id === trade_id);
  if (t) {
    t.status = TradeStatus.DISPUTED;
  }

  logAudit("BUYER", "QualityDispute", `Opened quality dispute on Trade ${trade_id} regarding parameter ${parameter}`, null, dispute);
  res.status(201).json(dispute);
});

// Resolve dispute endpoint with settlement adjustment (Section 36, 71)
app.post("/api/quality/dispute/:id/resolve", (req, res) => {
  const { action, discount_per_mt } = req.body; // action: "ACCEPT", "REJECT"
  const disp = disputes.find(d => d.dispute_id === req.params.id);
  if (!disp) return res.status(404).json({ error: "Dispute not found" });

  disp.status = action === "ACCEPT" ? DisputeState.ACCEPTED : DisputeState.REJECTED;
  disp.resolution = action === "ACCEPT" 
    ? `Dispute accepted. Quality adjustment discount of €${discount_per_mt}/MT applied.`
    : "Dispute rejected. Original specifications certified correct by Eurospec laboratory.";

  const trade = trades.find(t => t.trade_id === disp.trade_id);
  if (trade) {
    if (action === "ACCEPT") {
      // Settle with discount adjustment (Section 71)
      processFinalSettlement(trade, parseFloat(discount_per_mt || 0));
    } else {
      processFinalSettlement(trade, 0); // standard settlement
    }
  }

  logAudit("ADMIN", "QualityDispute", `Resolved dispute ${disp.dispute_id}: ${action}`, null, disp);
  res.json(disp);
});

// Risk parameters
app.get("/api/risk", (req, res) => {
  // Dynamic risk calculation (Section 65)
  // Compute exposures for the Chemical Opportunity Fund (PT-RHINO-FUND)
  const fund = participants.find(p => p.participant_id === "PT-RHINO-FUND")!;
  const fundOrders = orders.filter(o => o.participant_id === fund.participant_id && o.status === OrderStatus.PENDING);
  const fundTrades = trades.filter(t => t.buy_participant_id === fund.participant_id || t.sell_participant_id === fund.participant_id);

  const grossExposure = fundOrders.reduce((sum, o) => sum + (o.remaining_quantity * o.price), 0) + 
    fundTrades.filter(t => t.status !== TradeStatus.CLOSED).reduce((sum, t) => sum + t.notional, 0);

  res.json({
    fund_limits: {
      max_gross: 500000000,
      max_net: 300000000,
      max_single_product: 150000000,
      max_single_location: 200000000
    },
    fund_exposure: {
      gross: grossExposure,
      net: grossExposure, // simple simulation assumption
      VaR_estimate: grossExposure * 0.042, // VaR-style analytical estimate (Section 65)
      liquidity_score: 94.5
    },
    scenarios: [
      { name: "Feedstock Shock (+20% crude)", impact: -grossExposure * 0.08 },
      { name: "Port Lockdowns (Rotterdam Delay)", impact: -1450000 },
      { name: "Unplanned Styrene Outage", impact: 1280000 }
    ],
    audit_events: auditEvents.slice(-25) // return last 25 events for transparency (Section 115)
  });
});

// Fund portfolio aggregate (Section 60, 107)
app.get("/api/portfolio", (req, res) => {
  const fund = participants.find(p => p.participant_id === "PT-RHINO-FUND")!;
  
  // Calculate total portfolio physical inventory valuation
  const inventoryValuation = inventoryLots
    .filter(lot => lot.ownership === fund.participant_id)
    .reduce((sum, lot) => {
      const mkt = markets.find(m => m.product_id === lot.product_id);
      const price = mkt ? mkt.base_price : 800;
      return sum + (lot.quantity * price);
    }, 0);

  const totalNAV = fund.cash_balance + inventoryValuation;

  res.json({
    capital: 1000000000, // €1 Billion
    NAV: totalNAV,
    cash: fund.cash_balance,
    physical_inventory_value: inventoryValuation,
    allocated_margin: fund.allocated_margin,
    exposure: inventoryValuation
  });
});

// Market analytics/indexes (Section 43)
app.get("/api/market-data", (req, res) => {
  // Assemble dynamic public metrics (Section 45, 48)
  const results = markets.map(m => {
    const book = orderbooks[m.market_id];
    const stats = marketStatistics[m.market_id];

    const bestBid = book.bids.length > 0 ? book.bids[0].price : null;
    const bestAsk = book.asks.length > 0 ? book.asks[0].price : null;
    const mid = (bestBid && bestAsk) ? parseFloat(((bestBid + bestAsk) / 2).toFixed(2)) : stats.last;
    const spread = (bestBid && bestAsk) ? parseFloat((bestAsk - bestBid).toFixed(2)) : null;
    const spread_pct = (spread && mid) ? parseFloat(((spread / mid) * 100).toFixed(2)) : null;

    return {
      market_id: m.market_id,
      symbol: m.symbol,
      last: stats.last,
      bid: bestBid,
      ask: bestAsk,
      mid,
      vwap: stats.vwap,
      high: stats.high,
      low: stats.low,
      open: stats.open,
      volume: stats.volume,
      trade_count: stats.trade_count,
      price_history: stats.price_history,
      spread,
      spread_pct,
      depth: {
        bids: book.bids.slice(0, 5).map(b => ({ price: b.price, quantity: b.remaining_quantity, count: 1 })),
        asks: book.asks.slice(0, 5).map(a => ({ price: a.price, quantity: a.remaining_quantity, count: 1 }))
      }
    };
  });
  res.json(results);
});

// Feedstocks / Value chain Graph JSON Endpoint (Section 109, 110)
app.get("/api/research/graph", (req, res) => {
  res.json({
    nodes: [
      { id: "feedstock-crude", label: "Crude Oil Proxy", type: "FEEDSTOCK", val: 78.50, unit: "USD/bbl" },
      { id: "feedstock-gas", label: "Natural Gas Proxy", type: "FEEDSTOCK", val: 32.20, unit: "EUR/MWh" },
      { id: "plant-nap-crack", label: "Antwerp Naphtha Cracker", type: "PLANT", capacity: "2,500 MT/d", outage: "RUNNING" },
      { id: "prod-benzene", label: "Benzene Base Chemical", type: "PRODUCT", price: 810, unit: "EUR/MT" },
      { id: "prod-styrene", label: "Styrene Intermediate", type: "PRODUCT", price: 1150, unit: "EUR/MT" },
      { id: "prod-polypropylene", label: "PP Polymer Derivative", type: "PRODUCT", price: 1240, unit: "EUR/MT" },
      { id: "buyer-bayer", label: "Bayer Injection Molders", type: "BUYER" }
    ],
    edges: [
      { source: "feedstock-crude", target: "plant-nap-crack", label: "Cracking Stream" },
      { source: "plant-nap-crack", target: "prod-benzene", label: "Yield (34%)" },
      { source: "prod-benzene", target: "prod-styrene", label: "Styrenic Synthesis" },
      { source: "prod-styrene", target: "prod-polypropylene", label: "Polymerization" },
      { source: "prod-polypropylene", target: "buyer-bayer", label: "Industrial End-use" }
    ]
  });
});

// Trigger Shocks via Administration (Section 97, 98, 99)
app.post("/api/admin/shocks", (req, res) => {
  const { type } = req.body; // "OUTAGE" | "PORT" | "QUALITY"
  if (type === "OUTAGE") {
    triggerPlantOutage("PLT-ANT-CRACK");
  } else if (type === "PORT") {
    triggerPortDelay("LOC-RTM");
  } else if (type === "QUALITY") {
    // Generate Quality test failure (Scenario 7, Section 106)
    const badLotId = "LOT-BENZ-01";
    const lot = inventoryLots.find(l => l.lot_id === badLotId);
    if (lot) {
      lot.status = LotStatus.QUALITY_HOLD;
      logAudit("LABORATORY", "InventoryLot", "Quality check FAILED for purity. Blocked delivery.", lot.ownership, badLotId);
      
      broadcast("QUALITY_SHOCK", {
        lot_id: badLotId,
        message: `Quality Failure Exception: Lot ${badLotId} failed purity checks. Marked as QUALITY_HOLD. Associated deliveries blocked.`
      });
    }
  }
  res.json({ success: true, message: `Triggered chemical shock: ${type}` });
});

// Master Demo Scenario runner (Section 100 - 106, 131)
app.post("/api/admin/scenario/:number", (req, res) => {
  const scenarioNum = parseInt(req.params.number);
  logAudit("ADMIN", "SCENARIO", `Executing Scenario ${scenarioNum}`, null, null);

  if (scenarioNum === 100) {
    // Scenario 100: Master Execution Scenario
    // Producer A sells 5000 Benzene @ 810 FOB Rotterdam.
    // Fund A buys 2000 @ 820.
    // Industrial Buyer buys 3000 @ 815.
    const benzeneMarket = "RHX-BENZENE-NWE";
    
    // Create Sell order
    const sellOrd: Order = {
      order_id: "RHX-ORD-DEMO-SELL",
      client_order_id: "CL-DEMO-S1",
      participant_id: "PT-PROD-ANT",
      participant_name: "Antwerp Petrochemical Co.",
      market_id: benzeneMarket,
      side: OrderSide.SELL,
      quantity: 5000,
      remaining_quantity: 5000,
      price: 810,
      order_type: OrderType.LIMIT,
      time_in_force: "GTC",
      product_id: "P-BENZENE",
      grade_id: "G-BENZ-IND",
      quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT",
      delivery_window: DeliveryWindow.THREE_DAY,
      delivery_basis: DeliveryBasis.FOB,
      cargo_type: CargoSize.BARGE,
      certificate_requirement: true,
      created_at: new Date().toISOString(),
      exchange_sequence: exchangeSeq++,
      status: OrderStatus.PENDING
    };
    orders.push(sellOrd);
    orderbooks[benzeneMarket].asks.push(sellOrd);

    // Create Buy 1 (Fund A, 2000 MT @ 820)
    const buyOrd1: Order = {
      order_id: "RHX-ORD-DEMO-BUY1",
      client_order_id: "CL-DEMO-B1",
      participant_id: "PT-RHINO-FUND",
      participant_name: "Rhinoquant Chemical Opportunity Fund",
      market_id: benzeneMarket,
      side: OrderSide.BUY,
      quantity: 2000,
      remaining_quantity: 2000,
      price: 820,
      order_type: OrderType.LIMIT,
      time_in_force: "GTC",
      product_id: "P-BENZENE",
      grade_id: "G-BENZ-IND",
      quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT",
      delivery_window: DeliveryWindow.THREE_DAY,
      delivery_basis: DeliveryBasis.FOB,
      cargo_type: CargoSize.BARGE,
      certificate_requirement: true,
      created_at: new Date().toISOString(),
      exchange_sequence: exchangeSeq++,
      status: OrderStatus.PENDING
    };
    orders.push(buyOrd1);

    // Process first match
    matchOrder(buyOrd1);

    // Create Buy 2 (Bayer Buyer, 3000 MT @ 815)
    const buyOrd2: Order = {
      order_id: "RHX-ORD-DEMO-BUY2",
      client_order_id: "CL-DEMO-B2",
      participant_id: "PT-BUY-BAYER",
      participant_name: "Bayer Materials AG",
      market_id: benzeneMarket,
      side: OrderSide.BUY,
      quantity: 3000,
      remaining_quantity: 3000,
      price: 815,
      order_type: OrderType.LIMIT,
      time_in_force: "GTC",
      product_id: "P-BENZENE",
      grade_id: "G-BENZ-IND",
      quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT",
      delivery_window: DeliveryWindow.THREE_DAY,
      delivery_basis: DeliveryBasis.FOB,
      cargo_type: CargoSize.BARGE,
      certificate_requirement: true,
      created_at: new Date().toISOString(),
      exchange_sequence: exchangeSeq++,
      status: OrderStatus.PENDING
    };
    orders.push(buyOrd2);

    // Process second match
    matchOrder(buyOrd2);

    broadcast("ORDER_BOOK_UPDATED", { market_id: benzeneMarket });
    return res.json({ success: true, message: "Scenario 100 (Master Execution) completed successfully. 5,000 MT Benzene matched, lots allocated, deliveries nominated." });
  }

  if (scenarioNum === 101) {
    // Scenario 2 (Section 101): Resting Buy order matched later by lower Sell
    const benzeneMarket = "RHX-BENZENE-NWE";

    const restingBuy: Order = {
      order_id: "RHX-ORD-101-BUY",
      client_order_id: "CL-101-B1",
      participant_id: "PT-RHINO-FUND",
      participant_name: "Rhinoquant Chemical Opportunity Fund",
      market_id: benzeneMarket,
      side: OrderSide.BUY,
      quantity: 10000,
      remaining_quantity: 10000,
      price: 800,
      order_type: OrderType.LIMIT,
      time_in_force: "GTC",
      product_id: "P-BENZENE",
      grade_id: "G-BENZ-IND",
      quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-RTM",
      delivery_window: DeliveryWindow.THREE_DAY,
      delivery_basis: DeliveryBasis.FOB,
      cargo_type: CargoSize.BARGE,
      certificate_requirement: true,
      created_at: new Date().toISOString(),
      exchange_sequence: exchangeSeq++,
      status: OrderStatus.PENDING
    };
    orders.push(restingBuy);
    orderbooks[benzeneMarket].bids.push(restingBuy);

    // Sell later (4,000 MT @ 795)
    const incomingSell: Order = {
      order_id: "RHX-ORD-101-SELL",
      client_order_id: "CL-101-S1",
      participant_id: "PT-PROD-ANT",
      participant_name: "Antwerp Petrochemical Co.",
      market_id: benzeneMarket,
      side: OrderSide.SELL,
      quantity: 4000,
      remaining_quantity: 4000,
      price: 795,
      order_type: OrderType.LIMIT,
      time_in_force: "GTC",
      product_id: "P-BENZENE",
      grade_id: "G-BENZ-IND",
      quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-RTM",
      delivery_window: DeliveryWindow.THREE_DAY,
      delivery_basis: DeliveryBasis.FOB,
      cargo_type: CargoSize.BARGE,
      certificate_requirement: true,
      created_at: new Date().toISOString(),
      exchange_sequence: exchangeSeq++,
      status: OrderStatus.PENDING
    };
    orders.push(incomingSell);

    matchOrder(incomingSell);
    broadcast("ORDER_BOOK_UPDATED", { market_id: benzeneMarket });
    return res.json({ success: true, message: "Scenario 101 executed. 4,000 MT matched at €795/MT resting price. 6,000 MT remains resting bid." });
  }

  if (scenarioNum === 102) {
    // Scenario 3 (Section 102): Market Order walking the book (multiple levels)
    const benzeneMarket = "RHX-BENZENE-NWE";
    const book = orderbooks[benzeneMarket];

    // Clear asks first to have clear scenario
    book.asks = [];
    
    // Inject three levels of asks:
    const level1: Order = {
      order_id: "RHX-ORD-102-L1", client_order_id: "CL-102-L1", participant_id: "PT-PROD-ANT", participant_name: "Antwerp Petrochemical Co.",
      market_id: benzeneMarket, side: OrderSide.SELL, quantity: 2000, remaining_quantity: 2000, price: 810, order_type: OrderType.LIMIT,
      time_in_force: "GTC", product_id: "P-BENZENE", grade_id: "G-BENZ-IND", quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT", delivery_window: DeliveryWindow.THREE_DAY, delivery_basis: DeliveryBasis.FOB, cargo_type: CargoSize.BARGE,
      certificate_requirement: true, created_at: new Date().toISOString(), exchange_sequence: exchangeSeq++, status: OrderStatus.PENDING
    };
    const level2: Order = {
      order_id: "RHX-ORD-102-L2", client_order_id: "CL-102-L2", participant_id: "PT-PROD-RTM", participant_name: "Rotterdam Aromatics BV",
      market_id: benzeneMarket, side: OrderSide.SELL, quantity: 3000, remaining_quantity: 3000, price: 812, order_type: OrderType.LIMIT,
      time_in_force: "GTC", product_id: "P-BENZENE", grade_id: "G-BENZ-IND", quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-RTM", delivery_window: DeliveryWindow.THREE_DAY, delivery_basis: DeliveryBasis.FOB, cargo_type: CargoSize.BARGE,
      certificate_requirement: true, created_at: new Date().toISOString(), exchange_sequence: exchangeSeq++, status: OrderStatus.PENDING
    };
    const level3: Order = {
      order_id: "RHX-ORD-102-L3", client_order_id: "CL-102-L3", participant_id: "PT-PROD-BASF", participant_name: "BASF Synth-Works",
      market_id: benzeneMarket, side: OrderSide.SELL, quantity: 5000, remaining_quantity: 5000, price: 818, order_type: OrderType.LIMIT,
      time_in_force: "GTC", product_id: "P-BENZENE", grade_id: "G-BENZ-IND", quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT", delivery_window: DeliveryWindow.THREE_DAY, delivery_basis: DeliveryBasis.FOB, cargo_type: CargoSize.BARGE,
      certificate_requirement: true, created_at: new Date().toISOString(), exchange_sequence: exchangeSeq++, status: OrderStatus.PENDING
    };
    book.asks.push(level1, level2, level3);

    // Submit Market Buy
    const mktBuy: Order = {
      order_id: "RHX-ORD-102-MKTBUY",
      client_order_id: "CL-102-MKT",
      participant_id: "PT-RHINO-FUND",
      participant_name: "Rhinoquant Chemical Opportunity Fund",
      market_id: benzeneMarket,
      side: OrderSide.BUY,
      quantity: 10000,
      remaining_quantity: 10000,
      price: 999, // high limit representing market order
      order_type: OrderType.MARKET,
      time_in_force: "IOC",
      product_id: "P-BENZENE",
      grade_id: "G-BENZ-IND",
      quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-RTM",
      delivery_window: DeliveryWindow.THREE_DAY,
      delivery_basis: DeliveryBasis.FOB,
      cargo_type: CargoSize.BARGE,
      certificate_requirement: true,
      created_at: new Date().toISOString(),
      exchange_sequence: exchangeSeq++,
      status: OrderStatus.PENDING
    };
    orders.push(mktBuy);

    const matchResult = matchOrder(mktBuy);
    broadcast("ORDER_BOOK_UPDATED", { market_id: benzeneMarket });
    return res.json({
      success: true,
      message: `Scenario 102 completed. Market buy consumed 3 levels of asks: 2k @ 810, 3k @ 812, 5k @ 818. VWAP: €814.6/MT.`
    });
  }

  if (scenarioNum === 103) {
    // Scenario 4 (Section 103): FOK 20k MT. Available 15k MT. Result: NO EXECUTION.
    const benzeneMarket = "RHX-BENZENE-NWE";
    const book = orderbooks[benzeneMarket];
    book.asks = [];

    // Inject 15k total
    const l1: Order = {
      order_id: "RHX-ORD-103-L1", client_order_id: "CL-103-L1", participant_id: "PT-PROD-ANT", participant_name: "Antwerp Petrochemical Co.",
      market_id: benzeneMarket, side: OrderSide.SELL, quantity: 15000, remaining_quantity: 15000, price: 810, order_type: OrderType.LIMIT,
      time_in_force: "GTC", product_id: "P-BENZENE", grade_id: "G-BENZ-IND", quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT", delivery_window: DeliveryWindow.THREE_DAY, delivery_basis: DeliveryBasis.FOB, cargo_type: CargoSize.BARGE,
      certificate_requirement: true, created_at: new Date().toISOString(), exchange_sequence: exchangeSeq++, status: OrderStatus.PENDING
    };
    book.asks.push(l1);

    // Submit FOK for 20k
    const fokBuy: Order = {
      order_id: "RHX-ORD-103-FOK",
      client_order_id: "CL-103-FOK",
      participant_id: "PT-RHINO-FUND",
      participant_name: "Rhinoquant Chemical Opportunity Fund",
      market_id: benzeneMarket,
      side: OrderSide.BUY,
      quantity: 20000,
      remaining_quantity: 20000,
      price: 820,
      order_type: OrderType.FOK,
      time_in_force: "FOK",
      product_id: "P-BENZENE",
      grade_id: "G-BENZ-IND",
      quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT",
      delivery_window: DeliveryWindow.THREE_DAY,
      delivery_basis: DeliveryBasis.FOB,
      cargo_type: CargoSize.BARGE,
      certificate_requirement: true,
      created_at: new Date().toISOString(),
      exchange_sequence: exchangeSeq++,
      status: OrderStatus.PENDING
    };
    orders.push(fokBuy);

    const matchRes = matchOrder(fokBuy);
    broadcast("ORDER_BOOK_UPDATED", { market_id: benzeneMarket });
    return res.json({
      success: false,
      message: "Scenario 103 (FOK) result: Order killed. Available supply (15k MT) was less than requested fill size (20k MT)."
    });
  }

  if (scenarioNum === 104) {
    // Scenario 5 (Section 104): IOC 20k MT. Available 15k MT. Result: Execute 15k, cancel 5k.
    const benzeneMarket = "RHX-BENZENE-NWE";
    const book = orderbooks[benzeneMarket];
    book.asks = [];

    // Inject 15k
    const l1: Order = {
      order_id: "RHX-ORD-104-L1", client_order_id: "CL-104-L1", participant_id: "PT-PROD-ANT", participant_name: "Antwerp Petrochemical Co.",
      market_id: benzeneMarket, side: OrderSide.SELL, quantity: 15000, remaining_quantity: 15000, price: 810, order_type: OrderType.LIMIT,
      time_in_force: "GTC", product_id: "P-BENZENE", grade_id: "G-BENZ-IND", quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT", delivery_window: DeliveryWindow.THREE_DAY, delivery_basis: DeliveryBasis.FOB, cargo_type: CargoSize.BARGE,
      certificate_requirement: true, created_at: new Date().toISOString(), exchange_sequence: exchangeSeq++, status: OrderStatus.PENDING
    };
    book.asks.push(l1);

    const iocBuy: Order = {
      order_id: "RHX-ORD-104-IOC",
      client_order_id: "CL-104-IOC",
      participant_id: "PT-RHINO-FUND",
      participant_name: "Rhinoquant Chemical Opportunity Fund",
      market_id: benzeneMarket,
      side: OrderSide.BUY,
      quantity: 20000,
      remaining_quantity: 20000,
      price: 820,
      order_type: OrderType.IOC,
      time_in_force: "IOC",
      product_id: "P-BENZENE",
      grade_id: "G-BENZ-IND",
      quality_spec: { purity: 99.9, water: 100, color: 10 },
      delivery_point_id: "LOC-ANT",
      delivery_window: DeliveryWindow.THREE_DAY,
      delivery_basis: DeliveryBasis.FOB,
      cargo_type: CargoSize.BARGE,
      certificate_requirement: true,
      created_at: new Date().toISOString(),
      exchange_sequence: exchangeSeq++,
      status: OrderStatus.PENDING
    };
    orders.push(iocBuy);

    const matchRes = matchOrder(iocBuy);
    broadcast("ORDER_BOOK_UPDATED", { market_id: benzeneMarket });
    return res.json({
      success: true,
      message: "Scenario 104 (IOC) completed. Executed 15,000 MT immediately, cancelled remaining 5,000 MT."
    });
  }

  res.status(400).json({ error: "Invalid scenario selection" });
});

// -----------------------------------------------------
// 8. VITE MIDDLEWARE SETUP (Sections 1, 3)
// -----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Rhino Chem-X Spot Market running on port ${PORT}`);
  });
}

startServer();
