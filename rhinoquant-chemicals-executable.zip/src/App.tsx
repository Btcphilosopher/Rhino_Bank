import React, { useState, useEffect, useRef } from "react";
import { 
  PhysicalState, 
  QuantityUnit, 
  DeliveryBasis, 
  DeliveryWindow, 
  CargoSize, 
  OrderSide, 
  OrderType, 
  OrderStatus, 
  TradeStatus, 
  LotStatus, 
  OutageState, 
  DisputeState, 
  ShipmentStatus, 
  ChemicalProduct, 
  ChemicalGrade, 
  DeliveryPoint, 
  Market, 
  Order, 
  Trade, 
  ChemicalLot, 
  CertificateOfAnalysis, 
  QualityDispute, 
  Shipment, 
  Invoice, 
  LedgerEntry, 
  Plant, 
  Participant, 
  MarketData, 
  AuditEvent 
} from "./types";
import { 
  Activity, 
  TrendingUp, 
  Layers, 
  BookOpen, 
  FileText, 
  Truck, 
  ShieldAlert, 
  Database, 
  Settings, 
  ChevronRight, 
  Plus, 
  X, 
  Play, 
  Zap, 
  User, 
  Compass, 
  DollarSign,
  Briefcase,
  FlaskConical,
  Scale
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";

export default function App() {
  // Navigation tabs matching Section 79
  const [activeTab, setActiveTab] = useState<"MARKETS" | "TRADING" | "PORTFOLIO" | "INVENTORY" | "LOGISTICS" | "QUALITY" | "RISK" | "ADMIN">("MARKETS");
  
  // Simulated operational perspective (RBAC, Section 118)
  const [activeRole, setActiveRole] = useState<string>("TRADER");

  // State loaded from full-stack API
  const [markets, setMarkets] = useState<Market[]>([]);
  const [marketData, setMarketData] = useState<MarketData[]>([]);
  const [products, setProducts] = useState<ChemicalProduct[]>([]);
  const [deliveryPoints, setDeliveryPoints] = useState<DeliveryPoint[]>([]);
  const [selectedMarketId, setSelectedMarketId] = useState<string>("RHX-BENZENE-NWE");
  const [orders, setOrders] = useState<Order[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [inventory, setInventory] = useState<ChemicalLot[]>([]);
  const [deliveries, setDeliveries] = useState<Shipment[]>([]);
  const [qualityCerts, setQualityCerts] = useState<CertificateOfAnalysis[]>([]);
  const [disputes, setDisputes] = useState<QualityDispute[]>([]);
  const [riskData, setRiskData] = useState<any>(null);
  const [portfolio, setPortfolio] = useState<any>(null);
  const [activeOrdersCount, setActiveOrdersCount] = useState<number>(0);

  // Order ticket state (Section 81)
  const [orderSide, setOrderSide] = useState<OrderSide>(OrderSide.BUY);
  const [orderType, setOrderType] = useState<OrderType>(OrderType.LIMIT);
  const [orderQty, setOrderQty] = useState<number>(200);
  const [orderPrice, setOrderPrice] = useState<number>(815);
  const [deliveryPoint, setDeliveryPoint] = useState<string>("LOC-RTM");
  const [deliveryWin, setDeliveryWin] = useState<DeliveryWindow>(DeliveryWindow.THREE_DAY);
  const [deliveryBasis, setDeliveryBasis] = useState<DeliveryBasis>(DeliveryBasis.FOB);
  const [cargoType, setCargoType] = useState<CargoSize>(CargoSize.BARGE);
  const [selectedParticipant, setSelectedParticipant] = useState<string>("PT-RHINO-FUND");
  
  // Detail modal viewers
  const [selectedLotCoa, setSelectedLotCoa] = useState<CertificateOfAnalysis | null>(null);
  const [disputeModalOpen, setDisputeModalOpen] = useState<boolean>(false);
  const [disputeTradeId, setDisputeTradeId] = useState<string>("");
  const [disputeParam, setDisputeParam] = useState<string>("purity");
  const [disputeClaimed, setDisputeClaimed] = useState<number>(99.9);
  const [disputeMeasured, setDisputeMeasured] = useState<number>(99.2);

  // Flash notifications for matched trades & shocks
  const [alertMessage, setAlertMessage] = useState<{ type: string; message: string } | null>(null);

  // Load initial static & dynamic data
  const fetchData = async () => {
    try {
      const resProducts = await fetch("/api/products");
      const dataProducts = await resProducts.json();
      setProducts(dataProducts);

      const resPoints = await fetch("/api/delivery-points");
      const dataPoints = await resPoints.json();
      setDeliveryPoints(dataPoints);

      const resMarkets = await fetch("/api/markets");
      const dataMarkets = await resMarkets.json();
      setMarkets(dataMarkets);

      const resMktData = await fetch("/api/market-data");
      const dataMktData = await resMktData.json();
      setMarketData(dataMktData);

      const resOrders = await fetch("/api/orders");
      const dataOrders = await resOrders.json();
      setOrders(dataOrders);
      setActiveOrdersCount(dataOrders.filter((o: any) => o.status === "PENDING" || o.status === "PARTIALLY_FILLED").length);

      const resTrades = await fetch("/api/trades");
      const dataTrades = await resTrades.json();
      setTrades(dataTrades);

      const resInv = await fetch("/api/inventory");
      const dataInv = await resInv.json();
      setInventory(dataInv);

      const resDel = await fetch("/api/deliveries");
      const dataDel = await resDel.json();
      setDeliveries(dataDel);

      const resQual = await fetch("/api/quality");
      const dataQual = await resQual.json();
      setQualityCerts(dataQual.certificates);
      setDisputes(dataQual.disputes);

      const resRisk = await fetch("/api/risk");
      const dataRisk = await resRisk.json();
      setRiskData(dataRisk);

      const resPort = await fetch("/api/portfolio");
      const dataPort = await resPort.json();
      setPortfolio(dataPort);
    } catch (err) {
      console.error("Error pulling spot market engine state:", err);
    }
  };

  // Setup Server-Sent Events for instant match feedback (Section 91)
  useEffect(() => {
    fetchData();

    // SSE Stream
    const sse = new EventSource("/api/stream");
    
    sse.addEventListener("TRADE_EXECUTED", (e: any) => {
      const trade = JSON.parse(e.data);
      triggerAlert("success", `TRADE EXECUTED: ${trade.side} ${trade.quantity} MT ${trade.market_id} @ €${trade.price}/MT. Lots allocated.`);
      fetchData();
    });

    sse.addEventListener("SUPPLY_SHOCK", (e: any) => {
      const info = JSON.parse(e.data);
      triggerAlert("error", `SHOCK INJECTED: Outage at ${info.name}. Supply pipeline restricted.`);
      fetchData();
    });

    sse.addEventListener("QUALITY_SHOCK", (e: any) => {
      const info = JSON.parse(e.data);
      triggerAlert("warning", `QUALITY ALERT: ${info.message}`);
      fetchData();
    });

    sse.addEventListener("LOGISTICS_SHOCK", (e: any) => {
      const info = JSON.parse(e.data);
      triggerAlert("warning", `PORT DELAY: ${info.message}`);
      fetchData();
    });

    sse.addEventListener("ORDER_BOOK_UPDATED", () => {
      fetchData();
    });

    sse.addEventListener("PRICE_UPDATED", () => {
      fetchData();
    });

    // Fallback polling for maximum reliability across proxies
    const timer = setInterval(fetchData, 1500);

    return () => {
      sse.close();
      clearInterval(timer);
    };
  }, []);

  const triggerAlert = (type: "success" | "warning" | "error", message: string) => {
    setAlertMessage({ type, message });
    setTimeout(() => setAlertMessage(null), 5000);
  };

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          market_id: selectedMarketId,
          participant_id: selectedParticipant,
          side: orderSide,
          order_type: orderType,
          quantity: orderQty,
          price: orderPrice,
          delivery_point_id: deliveryPoint,
          delivery_window: deliveryWin,
          delivery_basis: deliveryBasis,
          cargo_type: cargoType
        })
      });

      const data = await res.json();
      if (!res.ok) {
        triggerAlert("error", data.error || "Order validation pipeline failed");
      } else {
        triggerAlert("success", `Order placed successfully. ID: ${data.order.order_id}`);
        fetchData();
      }
    } catch (err) {
      triggerAlert("error", "Communication failure with matching engine");
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, { method: "DELETE" });
      if (res.ok) {
        triggerAlert("warning", `Order ${orderId} cancelled`);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const triggerShock = async (type: string) => {
    try {
      await fetch("/api/admin/shocks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type })
      });
    } catch (err) {
      console.error(err);
    }
  };

  const runScenario = async (num: number) => {
    try {
      const res = await fetch(`/api/admin/scenario/${num}`, { method: "POST" });
      const data = await res.json();
      if (data.success) {
        triggerAlert("success", data.message);
      } else {
        triggerAlert("warning", data.message);
      }
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const submitDispute = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/quality/dispute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trade_id: disputeTradeId,
          parameter: disputeParam,
          claimed_value: disputeClaimed,
          measured_value: disputeMeasured,
          dispute_by: selectedParticipant
        })
      });
      if (res.ok) {
        triggerAlert("warning", `Quality Dispute registered for Trade ${disputeTradeId}`);
        setDisputeModalOpen(false);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const resolveDispute = async (disputeId: string, action: "ACCEPT" | "REJECT", discount: number) => {
    try {
      const res = await fetch(`/api/quality/dispute/${disputeId}/resolve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, discount_per_mt: discount })
      });
      if (res.ok) {
        triggerAlert("success", `Dispute resolved with status: ${action}`);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Helper selectors
  const activeMarket = markets.find(m => m.market_id === selectedMarketId);
  const activeMarketData = marketData.find(md => md.market_id === selectedMarketId);

  // Pre-trade financial calculations (Section 81)
  const orderNotional = orderQty * orderPrice;
  const transactionFee = orderNotional * 0.001; // 0.1%
  const estimatedMargin = orderNotional * 0.15; // 15% hold margin

  return (
    <div className="min-h-screen bg-[#111315] text-[#eaebeb] font-sans antialiased selection:bg-[#064e3b] selection:text-white flex flex-col">
      
      {/* Institutional Top Header (Section 79, 90) */}
      <header className="border-b border-[#24292d] bg-[#16181b] px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center space-x-4">
          <div className="h-9 w-9 bg-[#047857] flex items-center justify-center border border-[#d97706]/40">
            <span className="font-extrabold text-sm tracking-tighter text-[#eaebeb]">R-Q</span>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-sm font-bold tracking-wider text-white">RHINOQUANT CHEMICALS EXECUTABLE</h1>
              <span className="bg-[#1f2937] text-[#d97706] text-[10px] font-mono px-2 py-0.5 border border-[#d97706]/30">RHINO CHEM-X</span>
            </div>
            <p className="text-[11px] text-[#9ca3af] tracking-tight">Institutional Chemical Spot Exchange & Physical Operating System</p>
          </div>
        </div>

        {/* Analytical Basis Spreads (Section 51) */}
        <div className="hidden lg:flex items-center space-x-6 text-[11px] font-mono border-l border-[#24292d] pl-6">
          <div className="flex flex-col">
            <span className="text-[#9ca3af]">BENZENE / CRUDE PROXY</span>
            <span className="text-white font-bold">€731.50 / MT <span className="text-[#10b981]">(+1.2%)</span></span>
          </div>
          <div className="flex flex-col">
            <span className="text-[#9ca3af]">METHANOL / NAT-GAS PROXY</span>
            <span className="text-white font-bold">€307.80 / MT <span className="text-red-400">(-0.4%)</span></span>
          </div>
          <div className="flex flex-col">
            <span className="text-[#9ca3af]">POLYPROPYLENE / FEEDSTOCK</span>
            <span className="text-white font-bold">1.34x Spread <span className="text-[#10b981]">(+0.8%)</span></span>
          </div>
        </div>

        {/* RBAC Operational Mode Selector (Section 118) */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 bg-[#1b1e22] border border-[#2d3339] px-2 py-1">
            <User className="h-3 w-3 text-[#d97706]" />
            <select 
              value={activeRole} 
              onChange={(e) => {
                setActiveRole(e.target.value);
                triggerAlert("warning", `Changed perspective to: ${e.target.value}`);
              }}
              className="bg-transparent border-none text-[11px] font-mono focus:outline-none text-white font-semibold"
            >
              <option value="TRADER">TRADER PERSPECTIVE</option>
              <option value="PORTFOLIO_MANAGER">PORTFOLIO MANAGER</option>
              <option value="RISK_MANAGER">RISK MANAGER</option>
              <option value="OPERATIONS">OPERATIONS</option>
              <option value="QUALITY_LAB">QUALITY CONTROL</option>
              <option value="ADMIN">SYSTEM ADMIN</option>
            </select>
          </div>

          <div className="flex items-center space-x-1 bg-[#121416] border border-[#2d3339] px-2 py-1 text-[11px] text-[#10b981]">
            <span className="inline-block h-2 w-2 rounded-full bg-[#10b981] animate-pulse"></span>
            <span className="font-mono">ENGINE ONLINE</span>
          </div>
        </div>
      </header>

      {/* Real-time Toast Notifications (Section 82) */}
      {alertMessage && (
        <div className={`fixed top-18 right-6 z-50 px-4 py-3 shadow-xl border flex items-center space-x-3 max-w-md animate-fade-in ${
          alertMessage.type === "success" ? "bg-[#064e3b] border-[#10b981] text-emerald-100" :
          alertMessage.type === "warning" ? "bg-[#78350f] border-[#d97706] text-amber-100" :
          "bg-[#7f1d1d] border-red-500 text-red-100"
        }`}>
          <ShieldAlert className="h-5 w-5 shrink-0" />
          <p className="text-[12px] font-mono tracking-tight font-medium">{alertMessage.message}</p>
        </div>
      )}

      {/* Secondary Sub-Header: Global Navigation Tabs (Section 79) */}
      <nav className="bg-[#16181b] border-b border-[#24292d] px-6 flex items-center justify-between">
        <div className="flex space-x-1">
          {(["MARKETS", "TRADING", "PORTFOLIO", "INVENTORY", "LOGISTICS", "QUALITY", "RISK", "ADMIN"] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 text-[11px] font-bold tracking-wider transition-all duration-150 border-b-2 font-mono ${
                activeTab === tab 
                  ? "border-[#10b981] text-white bg-[#1a1d20]" 
                  : "border-transparent text-[#9ca3af] hover:text-[#eaebeb] hover:bg-[#1b1e22]"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="text-[11px] text-[#9ca3af] font-mono">
          SYSTEM NAV: <span className="text-white font-bold">€1,034,812,500</span>
        </div>
      </nav>

      {/* Main Terminal Body */}
      <main className="flex-1 p-6 flex flex-col lg:flex-row gap-6 overflow-hidden">
        
        {/* TAB 1: MARKETS VIEW (Section 80) */}
        {activeTab === "MARKETS" && (
          <div className="flex-1 flex flex-col lg:flex-row gap-6">
            
            {/* Left Column: Markets Selector (Section 4, 5) */}
            <div className="w-full lg:w-80 bg-[#16181b] border border-[#24292d] p-4 flex flex-col">
              <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-3 flex items-center justify-between">
                <span>ACTIVE SPOT MARKETS</span>
                <Layers className="h-3 w-3" />
              </h2>
              
              <div className="flex-1 space-y-1.5 overflow-y-auto max-h-[500px]">
                {marketData.map(md => {
                  const baseMkt = markets.find(m => m.market_id === md.market_id);
                  if (!baseMkt) return null;
                  const isSelected = selectedMarketId === md.market_id;
                  return (
                    <div
                      key={md.market_id}
                      onClick={() => setSelectedMarketId(md.market_id)}
                      className={`p-3 border transition-all cursor-pointer ${
                        isSelected 
                          ? "bg-[#1d2126] border-[#10b981]" 
                          : "bg-[#121416]/50 border-[#24292d] hover:bg-[#1a1d20] hover:border-[#2d3339]"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[12px] font-bold text-white">{md.symbol}</span>
                        <span className="text-[10px] text-[#9ca3af] font-semibold">{baseMkt.region}</span>
                      </div>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-[14px] font-bold font-mono text-[#10b981]">
                          €{md.last ? md.last.toLocaleString() : "—"}<span className="text-[10px] font-normal text-[#9ca3af]">/MT</span>
                        </span>
                        <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                          (md.spread_pct || 0) < 1.5 ? "bg-[#064e3b]/80 text-[#34d399]" : "bg-amber-950/80 text-[#fbbf24]"
                        }`}>
                          Spr: {md.spread_pct ? `${md.spread_pct}%` : "—"}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Middle Column: Chart & Order Book (Section 45, 47) */}
            <div className="flex-1 flex flex-col gap-6">
              
              {/* Product Header Card */}
              {activeMarket && (
                <div className="bg-[#16181b] border border-[#24292d] p-4 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] tracking-widest text-[#d97706] font-bold uppercase">{activeMarket.delivery_basis} PORT DELIVERED</span>
                    <h2 className="text-xl font-extrabold text-white">{activeMarket.symbol.replace("RHX-", "")} {activeMarket.region.toUpperCase()}</h2>
                    <p className="text-[11px] text-[#9ca3af] mt-0.5">Fungibility Rule: Pure strict chemical matching on specification grades only.</p>
                  </div>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-right">
                    <div>
                      <span className="text-[9px] text-[#9ca3af] block">LAST TRADED</span>
                      <span className="text-[13px] font-mono font-bold text-white">€{activeMarketData?.last || "—"}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-[#9ca3af] block">VWAP (4H)</span>
                      <span className="text-[13px] font-mono font-bold text-white">€{activeMarketData?.vwap || "—"}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-[#9ca3af] block">4H VOLUME</span>
                      <span className="text-[13px] font-mono font-bold text-white">{activeMarketData?.volume.toLocaleString()} MT</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-[#9ca3af] block">SPREAD</span>
                      <span className="text-[13px] font-mono font-bold text-[#fbbf24]">€{activeMarketData?.spread || "—"}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Price Graph (Section 80) */}
              <div className="bg-[#16181b] border border-[#24292d] p-4 h-64 flex flex-col">
                <h3 className="text-[11px] font-bold text-[#9ca3af] tracking-wider mb-2 font-mono">SPOT EXCHANGE PRICE TRAJECTORY</h3>
                <div className="flex-1 min-h-[180px]">
                  {activeMarketData && activeMarketData.last ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={activeMarketData?.price_history || []}>
                        <defs>
                          <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#047857" stopOpacity={0.4}/>
                            <stop offset="95%" stopColor="#047857" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="timestamp" stroke="#374151" fontSize={8} tickFormatter={(str) => new Date(str).toLocaleTimeString()} />
                        <YAxis stroke="#374151" domain={['dataMin - 10', 'dataMax + 10']} fontSize={9} />
                        <Tooltip contentStyle={{ backgroundColor: '#16181b', borderColor: '#374151', fontSize: '11px', fontFamily: 'monospace' }} />
                        <Area type="monotone" dataKey="price" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorPrice)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center text-[12px] text-[#9ca3af] font-mono">
                      Awaiting Spot Auction Match Data...
                    </div>
                  )}
                </div>
              </div>

              {/* Order Book Ladder (Section 47) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Bid and Ask Depth */}
                <div className="bg-[#16181b] border border-[#24292d] p-4">
                  <h3 className="text-[11px] font-bold text-[#9ca3af] tracking-wider mb-3 font-mono">CENTRAL LIMIT ORDER BOOK DEPTH</h3>
                  
                  {activeMarketData ? (
                    <div className="space-y-4">
                      {/* ASKS (Offers) - Rendered lowest price first */}
                      <div className="space-y-1">
                        <div className="grid grid-cols-3 text-[9px] text-[#9ca3af] font-mono pb-1 border-b border-[#24292d]">
                          <span>ASK PRICE</span>
                          <span className="text-right">QTY (MT)</span>
                          <span className="text-right">DEPTH %</span>
                        </div>
                        {activeMarketData.depth.asks.length === 0 ? (
                          <div className="text-[11px] text-[#9ca3af] py-2 text-center font-mono italic">No resting offers on book</div>
                        ) : (
                          activeMarketData.depth.asks.slice().reverse().map((ask, idx) => (
                            <div key={idx} className="grid grid-cols-3 text-[11.5px] font-mono py-1 hover:bg-[#1e1a1a]/45">
                              <span className="text-red-400 font-bold">€{ask.price.toLocaleString()}</span>
                              <span className="text-right text-white">{ask.quantity.toLocaleString()}</span>
                              <span className="text-right text-[#9ca3af]">{Math.min(100, Math.round((ask.quantity / 5000) * 100))}%</span>
                            </div>
                          ))
                        )}
                      </div>

                      {/* SPREAD INDICATOR */}
                      <div className="bg-[#121416] py-1 px-3 text-center border-y border-[#2d3339] flex justify-between text-[11px] font-mono">
                        <span className="text-[#9ca3af]">BID-ASK SPREAD</span>
                        <span className="text-[#fbbf24] font-bold">
                          {activeMarketData.spread ? `€${activeMarketData.spread} / MT (${activeMarketData.spread_pct}%)` : "LOCKED MARKET"}
                        </span>
                      </div>

                      {/* BIDS */}
                      <div className="space-y-1">
                        {activeMarketData.depth.bids.length === 0 ? (
                          <div className="text-[11px] text-[#9ca3af] py-2 text-center font-mono italic">No resting bids on book</div>
                        ) : (
                          activeMarketData.depth.bids.map((bid, idx) => (
                            <div key={idx} className="grid grid-cols-3 text-[11.5px] font-mono py-1 hover:bg-[#1a1e1d]/45">
                              <span className="text-[#10b981] font-bold">€{bid.price.toLocaleString()}</span>
                              <span className="text-right text-white">{bid.quantity.toLocaleString()}</span>
                              <span className="text-right text-[#9ca3af]">{Math.min(100, Math.round((bid.quantity / 5000) * 100))}%</span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-6 text-gray-500 font-mono">Depth data offline</div>
                  )}
                </div>

                {/* Time & Sales (Section 46) */}
                <div className="bg-[#16181b] border border-[#24292d] p-4 flex flex-col h-full max-h-[300px]">
                  <h3 className="text-[11px] font-bold text-[#9ca3af] tracking-wider mb-2 font-mono flex items-center justify-between">
                    <span>TIME & SALES TAPE</span>
                    <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-400 animate-ping"></span>
                  </h3>
                  
                  <div className="flex-1 overflow-y-auto space-y-1 pr-1">
                    <div className="grid grid-cols-3 text-[9px] text-[#9ca3af] font-mono pb-1 border-b border-[#24292d]">
                      <span>TIME</span>
                      <span className="text-right">PRICE (€)</span>
                      <span className="text-right">QTY (MT)</span>
                    </div>
                    {trades.filter(t => t.market_id === selectedMarketId).length === 0 ? (
                      <div className="text-[11px] text-[#9ca3af] py-6 text-center font-mono italic">No spot executions recorded today</div>
                    ) : (
                      trades
                        .filter(t => t.market_id === selectedMarketId)
                        .slice()
                        .reverse()
                        .map(t => (
                          <div key={t.trade_id} className="grid grid-cols-3 text-[11px] font-mono py-1 border-b border-[#1f2327]/40">
                            <span className="text-[#9ca3af]">{new Date(t.timestamp).toLocaleTimeString()}</span>
                            <span className={`text-right font-bold ${t.side === OrderSide.BUY ? "text-[#10b981]" : "text-red-400"}`}>
                              €{t.price}
                            </span>
                            <span className="text-right text-white font-semibold">{t.quantity.toLocaleString()}</span>
                          </div>
                        ))
                    )}
                  </div>
                </div>

              </div>

            </div>

            {/* Right Column: Execution Order Ticket (Section 81) */}
            <div className="w-full lg:w-96 bg-[#16181b] border border-[#24292d] p-5 flex flex-col">
              <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-4 flex items-center justify-between">
                <span>ORDER SPECIFICATION TICKET</span>
                <FileText className="h-4 w-4 text-[#d97706]" />
              </h2>

              <form onSubmit={handleOrderSubmit} className="space-y-4 flex-1">
                {/* Buyer/Seller Selectors */}
                <div>
                  <label className="text-[9px] text-[#9ca3af] block mb-1 font-bold">TRADING PARTICIPANT ENTITY</label>
                  <select
                    value={selectedParticipant}
                    onChange={(e) => setSelectedParticipant(e.target.value)}
                    className="w-full bg-[#121416] border border-[#2d3339] px-3 py-2 text-[11.5px] font-mono text-white focus:border-[#10b981] outline-none"
                  >
                    <option value="PT-RHINO-FUND">RHINOQUANT CHEM FUND (AUM €1B)</option>
                    <option value="PT-PROD-ANT">ANTWERP PETROCHEMICALS (PROD)</option>
                    <option value="PT-BUY-BAYER">BAYER MATERIALS AG (BUYER)</option>
                    <option value="PT-BUY-AKZO">AKZONOBEL SOLUTIONS (BUYER)</option>
                  </select>
                </div>

                {/* Buy / Sell Toggles */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setOrderSide(OrderSide.BUY)}
                    className={`py-2 text-[12px] font-bold font-mono border transition-all ${
                      orderSide === OrderSide.BUY 
                        ? "bg-[#064e3b] border-[#10b981] text-emerald-100" 
                        : "bg-transparent border-[#2d3339] text-[#9ca3af] hover:text-white"
                    }`}
                  >
                    BUY PHYSICAL
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderSide(OrderSide.SELL)}
                    className={`py-2 text-[12px] font-bold font-mono border transition-all ${
                      orderSide === OrderSide.SELL 
                        ? "bg-red-950 border-red-700 text-red-100" 
                        : "bg-transparent border-[#2d3339] text-[#9ca3af] hover:text-white"
                    }`}
                  >
                    SELL PHYSICAL
                  </button>
                </div>

                {/* Quantities & Price input */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] text-[#9ca3af] block mb-1 font-bold">QUANTITY (MT)</label>
                    <input
                      type="number"
                      value={orderQty}
                      onChange={(e) => setOrderQty(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full bg-[#121416] border border-[#2d3339] px-3 py-1.5 text-[12px] font-mono text-white focus:border-[#10b981] outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] text-[#9ca3af] block mb-1 font-bold">LIMIT PRICE (€)</label>
                    <input
                      type="number"
                      value={orderPrice}
                      onChange={(e) => setOrderPrice(Math.max(1, parseFloat(e.target.value) || 0))}
                      className="w-full bg-[#121416] border border-[#2d3339] px-3 py-1.5 text-[12px] font-mono text-white focus:border-[#10b981] outline-none"
                    />
                  </div>
                </div>

                {/* Order Type & Basis */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] text-[#9ca3af] block mb-1 font-bold">ORDER EXEC TYPE</label>
                    <select
                      value={orderType}
                      onChange={(e) => setOrderType(e.target.value as OrderType)}
                      className="w-full bg-[#121416] border border-[#2d3339] px-2 py-1.5 text-[11px] font-mono text-white focus:border-[#10b981] outline-none"
                    >
                      <option value={OrderType.LIMIT}>LIMIT ORDER</option>
                      <option value={OrderType.MARKET}>MARKET ORDER</option>
                      <option value={OrderType.IOC}>IOC (IMM-OR-CANCEL)</option>
                      <option value={OrderType.FOK}>FOK (FILL-OR-KILL)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[9px] text-[#9ca3af] block mb-1 font-bold">DELIVERY BASIS</label>
                    <select
                      value={deliveryBasis}
                      onChange={(e) => setDeliveryBasis(e.target.value as DeliveryBasis)}
                      className="w-full bg-[#121416] border border-[#2d3339] px-2 py-1.5 text-[11px] font-mono text-white focus:border-[#10b981] outline-none"
                    >
                      <option value={DeliveryBasis.FOB}>FOB (FREE ON BOARD)</option>
                      <option value={DeliveryBasis.CIF}>CIF (COST, INS, FRT)</option>
                      <option value={DeliveryBasis.FCA}>FCA (FREE CARRIER)</option>
                      <option value={DeliveryBasis.DDP}>DDP (DELIV DUTY PAID)</option>
                    </select>
                  </div>
                </div>

                {/* Delivery Hub & Cargo Logistics */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] text-[#9ca3af] block mb-1 font-bold">DESTINATION TERMINAL</label>
                    <select
                      value={deliveryPoint}
                      onChange={(e) => setDeliveryPoint(e.target.value)}
                      className="w-full bg-[#121416] border border-[#2d3339] px-2 py-1.5 text-[11px] font-mono text-white focus:border-[#10b981] outline-none"
                    >
                      {deliveryPoints.map(dp => (
                        <option key={dp.delivery_point_id} value={dp.delivery_point_id}>{dp.name.split(" ")[0]} Terminal</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[9px] text-[#9ca3af] block mb-1 font-bold">CARGO LOGISTICS MODE</label>
                    <select
                      value={cargoType}
                      onChange={(e) => setCargoType(e.target.value as CargoSize)}
                      className="w-full bg-[#121416] border border-[#2d3339] px-2 py-1.5 text-[11px] font-mono text-white focus:border-[#10b981] outline-none"
                    >
                      <option value={CargoSize.BARGE}>INLAND CHEMICAL BARGE</option>
                      <option value={CargoSize.COASTAL_TANKER}>COASTAL CHEMICAL TANKER</option>
                      <option value={CargoSize.RAIL_TANK}>RAIL TANK CARGO</option>
                      <option value={CargoSize.TRUCK}>TANK TRUCK CONVOY</option>
                    </select>
                  </div>
                </div>

                {/* Pre-Trade Exposure Metrics (Section 81) */}
                <div className="bg-[#121416] border border-[#24292d] p-3 text-[11.5px] font-mono space-y-1.5 mt-2">
                  <span className="text-[9px] text-[#9ca3af] block mb-1 font-bold uppercase tracking-wider">PRE-TRADE RISKS & FEASIBILITY</span>
                  <div className="flex justify-between">
                    <span>Gross Notional:</span>
                    <span className="text-white font-semibold">€{orderNotional.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Clearing Fees (0.1%):</span>
                    <span className="text-[#9ca3af]">€{transactionFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Required Initial Margin (15%):</span>
                    <span className="text-[#fbbf24] font-semibold">€{estimatedMargin.toLocaleString()}</span>
                  </div>
                  <div className="pt-1.5 border-t border-[#24292d] text-[10px] text-[#9ca3af] leading-tight italic">
                    Note: Executing a trade commits physical title obligations. Short selling requires covered inventory.
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#047857] hover:bg-[#059669] text-white py-2.5 font-bold font-mono tracking-widest text-[12px] transition-all border border-[#10b981] shadow-lg shadow-emerald-950/20"
                >
                  TRANSMIT EXECUTABLE ORDER
                </button>
              </form>
            </div>

          </div>
        )}

        {/* TAB 2: TRADING & ORDER BLOTTERS (Section 75, 76) */}
        {activeTab === "TRADING" && (
          <div className="flex-1 flex flex-col gap-6">
            
            {/* Order Blotter Card (Section 76) */}
            <div className="bg-[#16181b] border border-[#24292d] p-4 flex-1 flex flex-col">
              <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-3 font-mono flex items-center justify-between">
                <span>EXCHANGE ACTIVE ORDER BLOTTER ({activeOrdersCount})</span>
                <BookOpen className="h-4 w-4" />
              </h2>
              
              <div className="flex-1 overflow-x-auto min-h-[220px]">
                <table className="w-full text-left border-collapse text-[11px] font-mono">
                  <thead>
                    <tr className="border-b border-[#24292d] text-[#9ca3af] uppercase">
                      <th className="py-2">ORDER ID</th>
                      <th className="py-2">PARTICIPANT</th>
                      <th className="py-2">MARKET</th>
                      <th className="py-2">SIDE</th>
                      <th className="py-2 text-right">ORIG QTY</th>
                      <th className="py-2 text-right">REM QTY</th>
                      <th className="py-2 text-right">LIMIT PRICE</th>
                      <th className="py-2">STATUS</th>
                      <th className="py-2 text-right">ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-6 text-center text-[#9ca3af] italic">No exchange orders on file</td>
                      </tr>
                    ) : (
                      orders.slice().reverse().map(order => (
                        <tr key={order.order_id} className="border-b border-[#1f2327]/50 hover:bg-[#1a1d20]">
                          <td className="py-2.5 text-white font-bold">{order.order_id}</td>
                          <td className="py-2.5 text-[#9ca3af] font-semibold">{order.participant_name}</td>
                          <td className="py-2.5 text-white">{order.market_id}</td>
                          <td className="py-2.5">
                            <span className={`px-2 py-0.5 font-bold ${order.side === "BUY" ? "bg-[#064e3b] text-emerald-300" : "bg-red-950 text-red-300"}`}>
                              {order.side}
                            </span>
                          </td>
                          <td className="py-2.5 text-right font-semibold text-white">{order.quantity.toLocaleString()} MT</td>
                          <td className="py-2.5 text-right text-gray-300">{order.remaining_quantity.toLocaleString()}</td>
                          <td className="py-2.5 text-right font-bold text-white">€{order.price}</td>
                          <td className="py-2.5">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] uppercase font-bold ${
                              order.status === "FILLED" ? "bg-emerald-900 text-emerald-200" :
                              order.status === "PENDING" ? "bg-amber-900 text-amber-200 animate-pulse" :
                              order.status === "CANCELLED" ? "bg-zinc-800 text-zinc-400" :
                              "bg-zinc-700 text-zinc-300"
                            }`}>
                              {order.status}
                            </span>
                          </td>
                          <td className="py-2.5 text-right">
                            {(order.status === "PENDING" || order.status === "PARTIALLY_FILLED") && (
                              <button
                                onClick={() => handleCancelOrder(order.order_id)}
                                className="bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 px-2 py-0.5 text-[10px] tracking-wide uppercase transition-all"
                              >
                                Cancel
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Executed Trade Blotter (Section 75) */}
            <div className="bg-[#16181b] border border-[#24292d] p-4 flex-1 flex flex-col">
              <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-3 font-mono flex items-center justify-between">
                <span>HISTORIC MATCHED TRADE BLOTTER</span>
                <Activity className="h-4 w-4 text-[#10b981]" />
              </h2>
              
              <div className="flex-1 overflow-x-auto min-h-[220px]">
                <table className="w-full text-left border-collapse text-[11px] font-mono">
                  <thead>
                    <tr className="border-b border-[#24292d] text-[#9ca3af] uppercase">
                      <th className="py-2">TRADE ID</th>
                      <th className="py-2">MARKET</th>
                      <th className="py-2">BUY COUNTERPARTY</th>
                      <th className="py-2">SELL COUNTERPARTY</th>
                      <th className="py-2 text-right">VOLUME</th>
                      <th className="py-2 text-right">EXEC PRICE</th>
                      <th className="py-2 text-right">NOTIONAL</th>
                      <th className="py-2 text-right">FEES</th>
                      <th className="py-2">DELIVERY STATUS</th>
                    </tr>
                  </thead>
                  <tbody>
                    {trades.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-6 text-center text-[#9ca3af] italic">No matched transactions registered</td>
                      </tr>
                    ) : (
                      trades.slice().reverse().map(trade => (
                        <tr key={trade.trade_id} className="border-b border-[#1f2327]/50 hover:bg-[#1a1d20]">
                          <td className="py-2.5 text-white font-extrabold">{trade.trade_id}</td>
                          <td className="py-2.5 text-gray-300">{trade.market_id}</td>
                          <td className="py-2.5 text-[#10b981] font-semibold">{trade.buy_participant_name}</td>
                          <td className="py-2.5 text-red-400 font-semibold">{trade.sell_participant_name}</td>
                          <td className="py-2.5 text-right font-bold text-white">{trade.quantity.toLocaleString()} MT</td>
                          <td className="py-2.5 text-right text-[#34d399] font-bold">€{trade.price}</td>
                          <td className="py-2.5 text-right text-white">€{trade.notional.toLocaleString()}</td>
                          <td className="py-2.5 text-right text-gray-400">€{trade.fees}</td>
                          <td className="py-2.5">
                            <span className={`px-2 py-0.5 rounded text-[9.5px] uppercase font-bold ${
                              trade.status === "SETTLED" ? "bg-emerald-950 text-emerald-300 border border-emerald-800" :
                              trade.status === "DISPUTED" ? "bg-[#7f1d1d] text-red-200 animate-pulse border border-red-700" :
                              "bg-[#1b1e22] text-amber-200 border border-amber-800"
                            }`}>
                              {trade.status}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: PORTFOLIO & LEDGERS (Section 60, 107) */}
        {activeTab === "PORTFOLIO" && portfolio && (
          <div className="flex-1 flex flex-col gap-6">
            
            {/* Hero metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-[#16181b] border border-[#24292d] p-4">
                <span className="text-[9px] text-[#9ca3af] block font-bold tracking-widest">FUND NAV (NET ASSET VAL)</span>
                <span className="text-2xl font-mono font-bold text-white">€{portfolio.NAV.toLocaleString()}</span>
                <p className="text-[10px] text-[#10b981] mt-1 font-mono">+€34,812,500 (Growth Since Inception)</p>
              </div>
              <div className="bg-[#16181b] border border-[#24292d] p-4">
                <span className="text-[9px] text-[#9ca3af] block font-bold tracking-widest">LIQUID CASH RESERVES</span>
                <span className="text-2xl font-mono font-bold text-white">€{portfolio.cash.toLocaleString()}</span>
                <p className="text-[10px] text-[#9ca3af] mt-1 font-mono">Available Free Capital Pool</p>
              </div>
              <div className="bg-[#16181b] border border-[#24292d] p-4">
                <span className="text-[9px] text-[#9ca3af] block font-bold tracking-widest">PHYSICAL INVENTORY VAL</span>
                <span className="text-2xl font-mono font-bold text-[#fbbf24]">€{portfolio.physical_inventory_value.toLocaleString()}</span>
                <p className="text-[10px] text-[#9ca3af] mt-1 font-mono">Based on current index assessment</p>
              </div>
              <div className="bg-[#16181b] border border-[#24292d] p-4">
                <span className="text-[9px] text-[#9ca3af] block font-bold tracking-widest">COMMITTED MARGIN HELD</span>
                <span className="text-2xl font-mono font-bold text-red-400">€{portfolio.allocated_margin.toLocaleString()}</span>
                <p className="text-[10px] text-red-400 mt-1 font-mono">15% exposure block limits</p>
              </div>
            </div>

            {/* Fund positions breakdown (Section 62) */}
            <div className="bg-[#16181b] border border-[#24292d] p-4 flex-1 flex flex-col">
              <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-3 font-mono">
                RHINOQUANT CHEMICAL FUND POSITION ENGINE
              </h2>
              
              <div className="flex-1 overflow-x-auto min-h-[300px]">
                <table className="w-full text-left border-collapse text-[11px] font-mono">
                  <thead>
                    <tr className="border-b border-[#24292d] text-[#9ca3af] uppercase">
                      <th className="py-2">PRODUCT ENTITY ID</th>
                      <th className="py-2">CURRENT HUB LOCATION</th>
                      <th className="py-2 text-right">TOTAL INVENTORY STOCK</th>
                      <th className="py-2 text-right">ALLOCATED HELD</th>
                      <th className="py-2 text-right">AVAILABLE FOR SALE</th>
                      <th className="py-2 text-right">MARK-TO-MARKET VALUATION</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inventory.filter(l => l.ownership === "PT-RHINO-FUND").length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-gray-500 italic font-mono">
                          Fund currently holds no physical chemical lot positions.<br />
                          <span className="text-[10px]">Execute BUY orders on the terminal to accumulate spot stock!</span>
                        </td>
                      </tr>
                    ) : (
                      inventory
                        .filter(l => l.ownership === "PT-RHINO-FUND")
                        .map(lot => {
                          const mkt = markets.find(m => m.product_id === lot.product_id);
                          const price = mkt ? mkt.base_price : 800;
                          const valuation = lot.quantity * price;
                          return (
                            <tr key={lot.lot_id} className="border-b border-[#1f2327]/50 hover:bg-[#1a1d20]">
                              <td className="py-3 text-white font-extrabold">{lot.product_id} ({lot.lot_id})</td>
                              <td className="py-3 text-gray-300">{lot.current_location}</td>
                              <td className="py-3 text-right font-semibold text-white">{lot.quantity.toLocaleString()} MT</td>
                              <td className="py-3 text-right text-amber-400 font-bold">{lot.status === "ALLOCATED" ? `${lot.quantity.toLocaleString()} MT` : "0 MT"}</td>
                              <td className="py-3 text-right text-[#34d399] font-bold">{lot.status !== "ALLOCATED" ? `${lot.quantity.toLocaleString()} MT` : "0 MT"}</td>
                              <td className="py-3 text-right text-white font-extrabold">€{valuation.toLocaleString()}</td>
                            </tr>
                          );
                        })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* TAB 4: PHYSICAL INVENTORY TERMINAL (Section 31, 78) */}
        {activeTab === "INVENTORY" && (
          <div className="flex-1 flex flex-col gap-6">
            
            <div className="bg-[#16181b] border border-[#24292d] p-4 flex-1 flex flex-col">
              <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-4 font-mono flex items-center justify-between">
                <span>COMMODITY PHYSICAL INVENTORY LEDGER (CHEM-LOTS)</span>
                <Database className="h-4 w-4 text-[#fbbf24]" />
              </h2>

              <div className="flex-1 overflow-x-auto">
                <table className="w-full text-left border-collapse text-[11px] font-mono">
                  <thead>
                    <tr className="border-b border-[#24292d] text-[#9ca3af] uppercase">
                      <th className="py-2">LOT ID</th>
                      <th className="py-2">PRODUCT NAME</th>
                      <th className="py-2">BATCH NUMBER</th>
                      <th className="py-2 text-right">QUANTITY (MT)</th>
                      <th className="py-2">ORIGIN</th>
                      <th className="py-2">OWNER ID</th>
                      <th className="py-2">HUB STATUS</th>
                      <th className="py-2 text-right">QUALITY VERDICT</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inventory.map(lot => {
                      const prod = products.find(p => p.product_id === lot.product_id);
                      return (
                        <tr key={lot.lot_id} className="border-b border-[#1f2327]/50 hover:bg-[#1a1d20]">
                          <td className="py-3 font-extrabold text-white">{lot.lot_id}</td>
                          <td className="py-3 text-gray-200 font-bold">{prod?.chemical_name || lot.product_id}</td>
                          <td className="py-3 text-[#9ca3af]">{lot.batch}</td>
                          <td className="py-3 text-right font-semibold text-white">{lot.quantity.toLocaleString()} MT</td>
                          <td className="py-3 text-gray-400">{lot.origin}</td>
                          <td className="py-3 font-semibold text-[#fbbf24]">{lot.ownership.replace("PT-", "")}</td>
                          <td className="py-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              lot.status === LotStatus.DELIVERY_READY ? "bg-emerald-950 text-emerald-300" :
                              lot.status === LotStatus.QUALITY_HOLD ? "bg-red-950 text-red-300 animate-pulse" :
                              "bg-[#1b1e22] text-zinc-300 border border-zinc-800"
                            }`}>
                              {lot.status}
                            </span>
                          </td>
                          <td className="py-3 text-right">
                            <button
                              onClick={() => {
                                const coa = qualityCerts.find(c => c.coa_id === lot.quality_certificate_id);
                                if (coa) {
                                  setSelectedLotCoa(coa);
                                } else {
                                  triggerAlert("warning", "No certified laboratory analyses on file for sub-lot.");
                                }
                              }}
                              className="text-[10px] tracking-wider bg-[#1b1e22] hover:bg-[#24292d] text-[#10b981] border border-[#2d3339] px-2.5 py-1 uppercase"
                            >
                              View COA
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Certificate of Analysis (COA) Viewer overlay modal (Section 34) */}
            {selectedLotCoa && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
                <div className="bg-[#16181b] border-2 border-[#10b981] w-full max-w-lg p-6 shadow-2xl relative font-mono text-[11px]">
                  <button onClick={() => setSelectedLotCoa(null)} className="absolute top-4 right-4 text-[#9ca3af] hover:text-white">
                    <X className="h-5 w-5" />
                  </button>
                  
                  <div className="border-b border-[#24292d] pb-4 mb-4 text-center">
                    <FlaskConical className="h-7 w-7 text-[#10b981] mx-auto mb-2" />
                    <h3 className="text-[13px] font-bold tracking-widest text-white uppercase">EUROSPEC QUALITY LABORATORY</h3>
                    <p className="text-[10px] text-[#9ca3af] mt-0.5">Official Analytical Certificate of Analysis (COA)</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4 text-gray-300">
                    <div>
                      <span className="text-[9px] text-[#9ca3af] block">CERTIFICATE ID</span>
                      <strong className="text-white">{selectedLotCoa.coa_id}</strong>
                    </div>
                    <div>
                      <span className="text-[9px] text-[#9ca3af] block">ASSOCIATED LOT ID</span>
                      <strong className="text-white">{selectedLotCoa.lot_id}</strong>
                    </div>
                    <div>
                      <span className="text-[9px] text-[#9ca3af] block">LABORATORY HUB</span>
                      <strong className="text-white">{selectedLotCoa.laboratory}</strong>
                    </div>
                    <div>
                      <span className="text-[9px] text-[#9ca3af] block">TEST CERTIFICATION DATE</span>
                      <strong className="text-white">{new Date(selectedLotCoa.test_date).toLocaleDateString()}</strong>
                    </div>
                  </div>

                  <h4 className="text-[10px] font-extrabold text-[#9ca3af] tracking-wider uppercase mb-2 border-b border-[#24292d] pb-1">ANALYTICAL METRICS RESULTS</h4>
                  <div className="space-y-1.5">
                    {selectedLotCoa.parameters.map((p, idx) => (
                      <div key={idx} className="flex justify-between items-center bg-[#121416] p-2 border border-[#1f2327]">
                        <div>
                          <span className="text-white font-bold block">{p.parameter}</span>
                          <span className="text-[9.5px] text-[#9ca3af]">Required standard: {p.specification}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-white font-bold block">{p.value} {p.unit}</span>
                          <span className="text-[10px] font-extrabold text-[#10b981] uppercase">Passed</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-5 text-[9.5px] text-[#9ca3af] leading-tight text-center">
                    Authorized Laboratory Stamp - Certified authentic under synthetic ISO 9001 quality parameters.
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

        {/* TAB 5: LOGISTICS ENGINE (Section 38, 39) */}
        {activeTab === "LOGISTICS" && (
          <div className="flex-1 flex flex-col gap-6">
            
            <div className="bg-[#16181b] border border-[#24292d] p-4 flex-1 flex flex-col">
              <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-4 font-mono flex items-center justify-between">
                <span>SPOT LOGISTICS NOMINATIONS & SHIPMENTS</span>
                <Truck className="h-4 w-4 text-[#10b981]" />
              </h2>

              <div className="flex-1 overflow-x-auto">
                <table className="w-full text-left border-collapse text-[11px] font-mono">
                  <thead>
                    <tr className="border-b border-[#24292d] text-[#9ca3af] uppercase">
                      <th className="py-2">SHIPMENT ID</th>
                      <th className="py-2">ASSOCIATED TRADE ID</th>
                      <th className="py-2">LOGISTICS CARRIER</th>
                      <th className="py-2">MODE</th>
                      <th className="py-2">ORIGIN</th>
                      <th className="py-2">DESTINATION</th>
                      <th className="py-2 text-right">QUANTITY (MT)</th>
                      <th className="py-2 text-right">ETA TIMESTAMP</th>
                      <th className="py-2 text-right">SHIPPING STATUS</th>
                    </tr>
                  </thead>
                  <tbody>
                    {deliveries.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-12 text-center text-gray-500 italic font-mono">
                          No active chemical shipments currently nominated for delivery.
                        </td>
                      </tr>
                    ) : (
                      deliveries.map(del => (
                        <tr key={del.shipment_id} className="border-b border-[#1f2327]/50 hover:bg-[#1a1d20]">
                          <td className="py-3 font-extrabold text-white">{del.shipment_id}</td>
                          <td className="py-3 text-gray-300 font-semibold">{del.trade_id}</td>
                          <td className="py-3 text-gray-400">{del.carrier}</td>
                          <td className="py-3 text-white">{del.mode}</td>
                          <td className="py-3 text-gray-300">{del.origin}</td>
                          <td className="py-3 text-white font-semibold">{del.destination}</td>
                          <td className="py-3 text-right font-semibold text-white">{del.quantity.toLocaleString()} MT</td>
                          <td className="py-3 text-right text-[#fbbf24]">{new Date(del.ETA).toLocaleString()}</td>
                          <td className="py-3 text-right">
                            <span className="bg-[#1b1e22] text-[#10b981] border border-emerald-800 px-2 py-0.5 rounded text-[10px] font-bold uppercase">
                              {del.status}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* TAB 6: QUALITY & DISPUTES (Section 36) */}
        {activeTab === "QUALITY" && (
          <div className="flex-1 flex flex-col gap-6">
            
            <div className="bg-[#16181b] border border-[#24292d] p-4 flex flex-col h-1/2">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] font-mono">
                  QUALITY DISPUTES LOG (RECONCILIATION ADJUSTMENTS)
                </h2>
                <button
                  onClick={() => {
                    if (trades.length === 0) {
                      triggerAlert("warning", "No trades available to dispute.");
                    } else {
                      setDisputeTradeId(trades[trades.length - 1].trade_id);
                      setDisputeModalOpen(true);
                    }
                  }}
                  className="bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 px-3 py-1.5 text-[11px] font-mono tracking-wider uppercase font-bold"
                >
                  File Quality Dispute
                </button>
              </div>

              <div className="flex-1 overflow-y-auto">
                <table className="w-full text-left border-collapse text-[11px] font-mono">
                  <thead>
                    <tr className="border-b border-[#24292d] text-[#9ca3af] uppercase">
                      <th className="py-2">DISPUTE ID</th>
                      <th className="py-2">TRADE ID</th>
                      <th className="py-2">DISPUTANT</th>
                      <th className="py-2">PARAMETER</th>
                      <th className="py-2 text-right">CLAIMED VALUE</th>
                      <th className="py-2 text-right">MEASURED LAB VALUE</th>
                      <th className="py-2">STATUS</th>
                      <th className="py-2 text-right">RESOLUTION MANAGEMENT</th>
                    </tr>
                  </thead>
                  <tbody>
                    {disputes.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-6 text-center text-gray-500 italic">No quality disputes recorded</td>
                      </tr>
                    ) : (
                      disputes.map(disp => (
                        <tr key={disp.dispute_id} className="border-b border-[#1f2327]/50 hover:bg-[#1a1d20]">
                          <td className="py-2.5 font-bold text-red-400">{disp.dispute_id}</td>
                          <td className="py-2.5 text-white">{disp.trade_id}</td>
                          <td className="py-2.5 text-gray-300">{disp.disputed_by}</td>
                          <td className="py-2.5 text-gray-400 uppercase">{disp.parameter}</td>
                          <td className="py-2.5 text-right text-white font-semibold">{disp.claimed_value}</td>
                          <td className="py-2.5 text-right text-red-400 font-bold">{disp.measured_value}</td>
                          <td className="py-2.5">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                              disp.status === "OPEN" ? "bg-red-950 text-red-300 animate-pulse" :
                              disp.status === "ACCEPTED" ? "bg-emerald-950 text-[#34d399]" :
                              "bg-zinc-800 text-zinc-400"
                            }`}>
                              {disp.status}
                            </span>
                          </td>
                          <td className="py-2.5 text-right space-x-1.5">
                            {disp.status === "OPEN" && activeRole === "ADMIN" && (
                              <>
                                <button
                                  onClick={() => resolveDispute(disp.dispute_id, "ACCEPT", 15)}
                                  className="bg-emerald-950 hover:bg-emerald-900 text-[#10b981] border border-emerald-800 px-2.5 py-0.5 text-[10px] uppercase font-bold"
                                >
                                  Accept & Discount €15/MT
                                </button>
                                <button
                                  onClick={() => resolveDispute(disp.dispute_id, "REJECT", 0)}
                                  className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 px-2 py-0.5 text-[10px] uppercase font-bold"
                                >
                                  Reject Dispute
                                </button>
                              </>
                            )}
                            {disp.status !== "OPEN" && (
                              <span className="text-[10px] text-gray-400 italic font-medium">{disp.resolution || "Case Closed"}</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Quality Dispute Form Modal */}
            {disputeModalOpen && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
                <form onSubmit={submitDispute} className="bg-[#16181b] border-2 border-red-700 w-full max-w-md p-6 shadow-2xl relative font-mono text-[11.5px]">
                  <button type="button" onClick={() => setDisputeModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-white">
                    <X className="h-5 w-5" />
                  </button>

                  <div className="border-b border-red-900/60 pb-3 mb-4 text-center">
                    <Scale className="h-6 w-6 text-red-500 mx-auto mb-2" />
                    <h3 className="text-[12px] font-bold text-white tracking-widest uppercase">FILE OFFICIAL QUALITY DISPUTE</h3>
                    <p className="text-[10px] text-[#9ca3af] mt-0.5">Submit to clearing house for purity and specs resolution</p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="text-[9px] text-[#9ca3af] block mb-1">SELECT TRIGGER TRADE ID</label>
                      <select
                        value={disputeTradeId}
                        onChange={(e) => setDisputeTradeId(e.target.value)}
                        className="w-full bg-[#121416] border border-[#2d3339] px-3 py-2 text-white"
                      >
                        {trades.map(t => (
                          <option key={t.trade_id} value={t.trade_id}>{t.trade_id} ({t.market_id})</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                      <div className="col-span-1">
                        <label className="text-[9px] text-[#9ca3af] block mb-1">DISPUTE PARAM</label>
                        <select
                          value={disputeParam}
                          onChange={(e) => setDisputeParam(e.target.value)}
                          className="w-full bg-[#121416] border border-[#2d3339] px-2 py-2 text-white text-[11px]"
                        >
                          <option value="purity">Purity</option>
                          <option value="water">Water</option>
                          <option value="color">Color</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[9px] text-[#9ca3af] block mb-1">CONTRACT VAL</label>
                        <input
                          type="number"
                          step="0.01"
                          value={disputeClaimed}
                          onChange={(e) => setDisputeClaimed(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#121416] border border-[#2d3339] px-2 py-1.5 text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[9px] text-[#9ca3af] block mb-1">MEASURED VAL</label>
                        <input
                          type="number"
                          step="0.01"
                          value={disputeMeasured}
                          onChange={(e) => setDisputeMeasured(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#121416] border border-[#2d3339] px-2 py-1.5 text-white"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-red-950 border border-red-700 hover:bg-red-900 text-red-200 py-2.5 uppercase font-bold tracking-widest text-[11px]"
                    >
                      TRANSMIT DISPUTE CASE
                    </button>
                  </div>
                </form>
              </div>
            )}

          </div>
        )}

        {/* TAB 7: RISK ENGINE & RESEARCH GRAPH (Section 65, 109) */}
        {activeTab === "RISK" && riskData && (
          <div className="flex-1 flex flex-col gap-6">
            
            {/* Risk Exposure Metrics and Stress Testing Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Risk metrics card (Section 65) */}
              <div className="bg-[#16181b] border border-[#24292d] p-4 flex flex-col">
                <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-4 font-mono">
                  CLEARING HOUSE & INTEGRATED RISK ASSESSOR
                </h2>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-[#121416] p-3 border border-[#2d3339]">
                    <span className="text-[9px] text-[#9ca3af] block uppercase">Estimated VaR-Style (99% CI)</span>
                    <span className="text-xl font-bold font-mono text-red-400">€{riskData.fund_exposure.VaR_estimate.toLocaleString()}</span>
                  </div>
                  <div className="bg-[#121416] p-3 border border-[#2d3339]">
                    <span className="text-[9px] text-[#9ca3af] block uppercase">Exchange Liquidity Score</span>
                    <span className="text-xl font-bold font-mono text-[#10b981]">{riskData.fund_exposure.liquidity_score}%</span>
                  </div>
                </div>

                <h3 className="text-[10px] font-bold text-[#9ca3af] uppercase mb-2">Fund Limits Constraints Compliance</h3>
                <div className="space-y-2 text-[11.5px] font-mono">
                  <div className="flex justify-between">
                    <span>Max Gross Exposure Capacity:</span>
                    <span>€{riskData.fund_exposure.gross.toLocaleString()} / €{riskData.fund_limits.max_gross.toLocaleString()}</span>
                  </div>
                  <div className="w-full bg-[#121416] h-1.5 rounded-full overflow-hidden border border-[#1f2327]">
                    <div 
                      className="bg-[#10b981] h-full" 
                      style={{ width: `${Math.min(100, (riskData.fund_exposure.gross / riskData.fund_limits.max_gross) * 100)}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between pt-2">
                    <span>Single Location Hub Capacity:</span>
                    <span>€{riskData.fund_exposure.net.toLocaleString()} / €{riskData.fund_limits.max_single_location.toLocaleString()}</span>
                  </div>
                  <div className="w-full bg-[#121416] h-1.5 rounded-full overflow-hidden border border-[#1f2327]">
                    <div 
                      className="bg-amber-500 h-full" 
                      style={{ width: `${Math.min(100, (riskData.fund_exposure.net / riskData.fund_limits.max_single_location) * 100)}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Stress tests outcomes */}
              <div className="bg-[#16181b] border border-[#24292d] p-4">
                <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-4 font-mono">
                  STRESS TESTING EXPOSURE SCENARIOS (Section 66)
                </h2>
                
                <div className="space-y-2.5">
                  {riskData.scenarios.map((sc: any, idx: number) => (
                    <div key={idx} className="bg-[#121416] border border-[#24292d] p-3 flex justify-between items-center font-mono">
                      <div>
                        <span className="text-white font-bold block text-[11px]">{sc.name}</span>
                        <span className="text-[9.5px] text-[#9ca3af]">Clearing collateral impact estimate</span>
                      </div>
                      <span className={`text-[12.5px] font-bold ${sc.impact < 0 ? "text-red-400" : "text-[#10b981]"}`}>
                        {sc.impact < 0 ? "-" : "+"}€{Math.abs(sc.impact).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Research Graph Value Chain (Section 109, 110) */}
            <div className="bg-[#16181b] border border-[#24292d] p-4 flex-1 flex flex-col">
              <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-3 font-mono flex items-center justify-between">
                <span>CHEMICAL VALUE CHAIN & DOWNSTREAM FEEDSTOCK MAP</span>
                <Compass className="h-4 w-4" />
              </h2>

              <div className="grid grid-cols-1 lg:grid-cols-5 gap-3 text-center text-mono text-[11px]">
                <div className="bg-[#121416] p-4 border border-[#2d3339] flex flex-col justify-between">
                  <span className="text-[9px] text-[#9ca3af] block">1. RAW FEEDSTOCK</span>
                  <span className="text-[13px] text-white font-extrabold mt-2">Crude Oil & Nat Gas</span>
                  <p className="text-[10px] text-[#9ca3af] mt-2 italic leading-tight">Catalytic reforming process basis.</p>
                </div>
                <div className="flex items-center justify-center text-zinc-600">
                  <ChevronRight className="h-5 w-5" />
                </div>
                <div className="bg-[#121416] p-4 border border-[#2d3339] flex flex-col justify-between">
                  <span className="text-[9px] text-[#9ca3af] block">2. REACTOR CRACKING</span>
                  <span className="text-[13px] text-white font-extrabold mt-2">Ethylene & Propylene</span>
                  <p className="text-[10px] text-[#9ca3af] mt-2 italic leading-tight">Yield output synthesis splits.</p>
                </div>
                <div className="flex items-center justify-center text-zinc-600">
                  <ChevronRight className="h-5 w-5" />
                </div>
                <div className="bg-[#121416] p-4 border border-[#2d3339] flex flex-col justify-between">
                  <span className="text-[9px] text-[#9ca3af] block">3. DOWNSTREAM POLYMERS</span>
                  <span className="text-[13px] text-white font-extrabold mt-2">PP Polyethylene & PVC</span>
                  <p className="text-[10px] text-[#10b981] mt-2 italic leading-tight">Delivered to industrial compounders.</p>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB 8: ADMIN, SHOCKS, MASTER SCENARIOS (Section 94, 95, 96, 131) */}
        {activeTab === "ADMIN" && (
          <div className="flex-1 flex flex-col gap-6">
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Scenario Control Board */}
              <div className="bg-[#16181b] border border-[#24292d] p-5">
                <h2 className="text-[12px] font-bold tracking-widest text-[#9ca3af] mb-4 font-mono flex items-center justify-between">
                  <span>MASTER ENGINE DETERMINISTIC SCENARIOS</span>
                  <Play className="h-4 w-4 text-[#fbbf24]" />
                </h2>

                <div className="space-y-3 font-mono text-[11px]">
                  <div className="bg-[#121416] border border-[#2d3339] p-3 flex items-center justify-between">
                    <div>
                      <strong className="text-white block font-bold">Scenario 100: Master Execution Pipeline</strong>
                      <p className="text-[10px] text-[#9ca3af] leading-tight mt-1">
                        Executes matched buyer/producer spot block. Allocates multiple sub-lots, nominations, and clears final accounting.
                      </p>
                    </div>
                    <button
                      onClick={() => runScenario(100)}
                      className="bg-[#047857] hover:bg-[#059669] text-white px-3 py-1.5 uppercase font-bold"
                    >
                      Run Pipeline
                    </button>
                  </div>

                  <div className="bg-[#121416] border border-[#2d3339] p-3 flex items-center justify-between">
                    <div>
                      <strong className="text-white block font-bold">Scenario 101: Order Book Rest & Match</strong>
                      <p className="text-[10px] text-[#9ca3af] leading-tight mt-1">
                        Fund rests a 10,000 MT buy limit bid, which is later partially executed by a producer sell at €795/MT.
                      </p>
                    </div>
                    <button
                      onClick={() => runScenario(101)}
                      className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 uppercase font-bold"
                    >
                      Run
                    </button>
                  </div>

                  <div className="bg-[#121416] border border-[#2d3339] p-3 flex items-center justify-between">
                    <div>
                      <strong className="text-white block font-bold">Scenario 102: Market Order walking the book</strong>
                      <p className="text-[10px] text-[#9ca3af] leading-tight mt-1">
                        Walking 3 ask levels on the CLOB (2,000 @ 810, 3,000 @ 812, 5,000 @ 818). Calculates slippage and VWAP.
                      </p>
                    </div>
                    <button
                      onClick={() => runScenario(102)}
                      className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 uppercase font-bold"
                    >
                      Run
                    </button>
                  </div>

                  <div className="bg-[#121416] border border-[#2d3339] p-3 flex items-center justify-between">
                    <div>
                      <strong className="text-white block font-bold">Scenario 103: FOK Kill Verification</strong>
                      <p className="text-[10px] text-[#9ca3af] leading-tight mt-1">
                        Fills-or-Kills a 20,000 MT block request. Available supply is 15,000 MT. Expectation: Auto Killed.
                      </p>
                    </div>
                    <button
                      onClick={() => runScenario(103)}
                      className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 uppercase font-bold"
                    >
                      Verify
                    </button>
                  </div>

                  <div className="bg-[#121416] border border-[#2d3339] p-3 flex items-center justify-between">
                    <div>
                      <strong className="text-white block font-bold">Scenario 104: IOC Partial Fill Execution</strong>
                      <p className="text-[10px] text-[#9ca3af] leading-tight mt-1">
                        IOC (Immediate-Or-Cancel) for 20,000 MT. Match fills 15,000 MT and auto-cancels the remainder.
                      </p>
                    </div>
                    <button
                      onClick={() => runScenario(104)}
                      className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 uppercase font-bold"
                    >
                      Verify
                    </button>
                  </div>
                </div>
              </div>

              {/* Shocks board */}
              <div className="bg-[#16181b] border border-[#24292d] p-5">
                <h2 className="text-[12px] font-bold tracking-widest text-red-400 mb-4 font-mono flex items-center justify-between">
                  <span>INJECT CHEMICAL SPOT MARKET SHOCKS</span>
                  <Zap className="h-4 w-4 animate-bounce" />
                </h2>

                <div className="space-y-4 font-mono text-[11px]">
                  <div className="bg-[#121416] border border-[#2d3339] p-3 flex items-center justify-between">
                    <div>
                      <strong className="text-white block">Supply Shock: Antwerp Plant Outage (Section 97)</strong>
                      <span className="text-[9.5px] text-[#9ca3af]">Triggers unplanned reactor failure, reducing global regional supply expectations.</span>
                    </div>
                    <button
                      onClick={() => triggerShock("OUTAGE")}
                      className="bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 px-3 py-1.5 uppercase font-bold"
                    >
                      Trigger Outage
                    </button>
                  </div>

                  <div className="bg-[#121416] border border-[#2d3339] p-3 flex items-center justify-between">
                    <div>
                      <strong className="text-white block">Logistics Shock: Rotterdam Port delay (Section 98)</strong>
                      <span className="text-[9.5px] text-[#9ca3af]">Increases shipping lead time, triggering freight costs spike and feasibility warnings.</span>
                    </div>
                    <button
                      onClick={() => triggerShock("PORT")}
                      className="bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 px-3 py-1.5 uppercase font-bold"
                    >
                      Trigger Delay
                    </button>
                  </div>

                  <div className="bg-[#121416] border border-[#2d3339] p-3 flex items-center justify-between">
                    <div>
                      <strong className="text-white block">Quality Shock: Lot Purity Failure (Section 99)</strong>
                      <span className="text-[9.5px] text-[#9ca3af]">Marks designated chemical lot as Quality Hold, blocking deliveries and raising customer dispute.</span>
                    </div>
                    <button
                      onClick={() => triggerShock("QUALITY")}
                      className="bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 px-3 py-1.5 uppercase font-bold"
                    >
                      Trigger Failure
                    </button>
                  </div>
                </div>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* Footer System Status Bar */}
      <footer className="border-t border-[#24292d] bg-[#16181b] px-6 py-2.5 flex items-center justify-between text-[10px] font-mono text-[#9ca3af]">
        <div className="flex items-center space-x-4">
          <span>SPOT AUCTION SEQUENCE ID: <strong className="text-white">#{orders.length + trades.length + 100}</strong></span>
          <span>STABLE INVARIANTS: <strong className="text-[#10b981]">PASSED (DEBITS = CREDITS)</strong></span>
        </div>
        <div>
          <span>RHINO QUANT CODENAME: RHINO CHEM-X v3.5 SPATIAL OPERATING SYSTEM</span>
        </div>
      </footer>

    </div>
  );
}
