export enum PhysicalState {
  LIQUID = "LIQUID",
  GAS = "GAS",
  SOLID = "SOLID",
  POWDER = "POWDER",
  PELLET = "PELLET",
  FLAKE = "FLAKE",
  GRANULE = "GRANULE"
}

export enum QuantityUnit {
  KG = "KG",
  MT = "MT",
  LITRE = "LITRE",
  M3 = "M3",
  BARREL_EQUIVALENT = "BARREL_EQUIVALENT"
}

export enum DeliveryBasis {
  EX_WORKS = "EX-WORKS",
  FCA = "FCA",
  FOB = "FOB",
  CFR = "CFR",
  CIF = "CIF",
  DAP = "DAP",
  DDP = "DDP",
  DELIVERED = "DELIVERED"
}

export enum DeliveryWindow {
  SPOT_TODAY = "SPOT_TODAY",
  NEXT_DAY = "NEXT_DAY",
  INTRADAY = "INTRADAY",
  THREE_DAY = "3_DAY",
  SEVEN_DAY = "7_DAY",
  MONTH_WINDOW = "MONTH_WINDOW"
}

export enum CargoSize {
  TRUCK = "TRUCK",
  ISO_CONTAINER = "ISO_CONTAINER",
  RAIL_TANK = "RAIL_TANK",
  BARGE = "BARGE",
  COASTAL_TANKER = "COASTAL_TANKER",
  DEEPSEA_CARGO = "DEEPSEA_CARGO",
  PIPELINE_BATCH = "PIPELINE_BATCH"
}

export enum OrderSide {
  BUY = "BUY",
  SELL = "SELL"
}

export enum OrderType {
  LIMIT = "LIMIT",
  MARKET = "MARKET",
  IOC = "IOC",
  FOK = "FOK",
  GTC = "GTC",
  GTD = "GTD",
  ICEBERG = "ICEBERG"
}

export enum OrderStatus {
  PENDING = "PENDING",
  PARTIALLY_FILLED = "PARTIALLY_FILLED",
  FILLED = "FILLED",
  CANCELLED = "CANCELLED",
  REJECTED = "REJECTED"
}

export enum TradeStatus {
  ORDERED = "ORDERED",
  EXECUTED = "EXECUTED",
  CONFIRMED = "CONFIRMED",
  CLEARED = "CLEARED",
  ALLOCATED = "ALLOCATED",
  NOMINATED = "NOMINATED",
  SHIPPED = "SHIPPED",
  DELIVERED = "DELIVERED",
  QUALITY_ACCEPTED = "QUALITY_ACCEPTED",
  SETTLED = "SETTLED",
  CLOSED = "CLOSED",
  DISPUTED = "DISPUTED",
  CANCELLED = "CANCELLED",
  DEFAULTED = "DEFAULTED",
  FAILED = "FAILED"
}

export enum TitleState {
  AVAILABLE = "AVAILABLE",
  ALLOCATED = "ALLOCATED",
  IN_TRANSIT = "IN_TRANSIT",
  DELIVERED = "DELIVERED",
  RELEASED = "RELEASED",
  DISPUTED = "DISPUTED"
}

export enum LotStatus {
  QUALITY_HOLD = "QUALITY_HOLD",
  DELIVERY_READY = "DELIVERY_READY",
  DELIVERED = "DELIVERED",
  ALLOCATED = "ALLOCATED",
  RELEASED = "RELEASED"
}

export enum OutageState {
  RUNNING = "RUNNING",
  REDUCED = "REDUCED",
  MAINTENANCE = "MAINTENANCE",
  UNPLANNED_OUTAGE = "UNPLANNED_OUTAGE",
  RESTART = "RESTART"
}

export enum DisputeState {
  OPEN = "OPEN",
  UNDER_REVIEW = "UNDER_REVIEW",
  ACCEPTED = "ACCEPTED",
  REJECTED = "REJECTED",
  RESOLVED = "RESOLVED"
}

export enum ShipmentStatus {
  PLANNED = "PLANNED",
  BOOKED = "BOOKED",
  LOADING = "LOADING",
  IN_TRANSIT = "IN_TRANSIT",
  ARRIVED = "ARRIVED",
  UNLOADING = "UNLOADING",
  COMPLETED = "COMPLETED",
  EXCEPTION = "EXCEPTION"
}

export interface ChemicalProduct {
  product_id: string;
  chemical_name: string;
  CAS_number: string;
  molecular_formula: string;
  molecular_weight: number;
  UN_number: string;
  hazard_classification: string;
  physical_state: PhysicalState;
  standard_unit: QuantityUnit;
  density: number; // in g/cm3 or MT/m3
  boiling_point: number; // in Celsius
  melting_point: number; // in Celsius
  default_grade: string;
  quality_schema: {
    purity_min: number; // %
    water_max: number; // ppm or %
    color_max: number; // Pt-Co
    non_aromatics_max?: number; // %
    acidity_max?: number; // mg KOH/g
  };
}

export interface ChemicalGrade {
  grade_id: string;
  product_id: string;
  name: string;
  specification_revision: string;
  quality_parameters: string[];
  allowed_tolerances: string;
  certification_requirements: string[];
}

export interface DeliveryPoint {
  delivery_point_id: string;
  name: string;
  country: string;
  region: string;
  port: string;
  terminal: string;
  warehouse: string;
  pipeline_node: string;
  factory: string;
  coordinates: [number, number]; // [lat, lng]
  transport_modes: string[];
  operating_hours: string;
}

export interface Market {
  market_id: string;
  symbol: string;
  product_id: string;
  region: string;
  default_grade: string;
  delivery_basis: DeliveryBasis;
  currency: string; // EUR, USD, GBP
  unit: QuantityUnit;
  minimum_lot: number;
  tick_size: number;
  trading_session: string;
  settlement_rule: string;
  quality_standard: string;
  active_status: boolean;
  base_price: number;
}

export interface Order {
  order_id: string;
  client_order_id: string;
  participant_id: string;
  participant_name: string;
  market_id: string;
  side: OrderSide;
  quantity: number;
  remaining_quantity: number;
  price: number;
  order_type: OrderType;
  time_in_force: string; // GTC, IOC, FOK, etc.
  product_id: string;
  grade_id: string;
  quality_spec: {
    purity: number;
    water: number;
    color: number;
  };
  delivery_point_id: string;
  delivery_window: DeliveryWindow;
  delivery_basis: DeliveryBasis;
  cargo_type: CargoSize;
  certificate_requirement: boolean;
  created_at: string;
  exchange_sequence: number;
  status: OrderStatus;
}

export interface Trade {
  trade_id: string;
  timestamp: string;
  market_id: string;
  product_id: string;
  grade_id: string;
  side: OrderSide; // side of the executor
  price: number;
  quantity: number;
  notional: number;
  buy_order_id: string;
  sell_order_id: string;
  buy_participant_id: string;
  buy_participant_name: string;
  sell_participant_id: string;
  sell_participant_name: string;
  delivery_point_id: string;
  delivery_window: DeliveryWindow;
  delivery_basis: DeliveryBasis;
  cargo_type: CargoSize;
  status: TradeStatus;
  lots_allocated: string[]; // Lot IDs
  fees: number;
  freight_cost: number;
  adjustments: number; // quality premium/discount, etc.
  invoice_id?: string;
  dispute_id?: string;
}

export interface ChemicalLot {
  lot_id: string;
  product_id: string;
  grade_id: string;
  batch: string;
  quantity: number;
  production_date: string;
  origin: string;
  current_location: string;
  quality_certificate_id: string;
  ownership: string; // Participant ID
  status: LotStatus;
}

export interface CertificateOfAnalysis {
  coa_id: string;
  lot_id: string;
  laboratory: string;
  test_date: string;
  parameters: {
    parameter: string;
    value: number;
    unit: string;
    specification: string;
    pass: boolean;
  }[];
  pass_fail: boolean;
  document_reference: string;
}

export interface QualityDispute {
  dispute_id: string;
  trade_id: string;
  disputed_by: string; // Participant ID
  parameter: string; // purity, colour, water, contamination, quantity
  claimed_value: number;
  measured_value: number;
  status: DisputeState;
  resolution?: string;
  created_at: string;
}

export interface MeasurementEvent {
  measurement_id: string;
  trade_id?: string;
  lot_id?: string;
  method: "WEIGHBRIDGE" | "FLOW_METER" | "TANK_GAUGE" | "MANUAL_CERTIFIED_MEASUREMENT";
  quantity: number;
  unit: QuantityUnit;
  instrument: string;
  timestamp: string;
  uncertainty: number; // e.g. 0.02 (%)
}

export interface Shipment {
  shipment_id: string;
  trade_id: string;
  carrier: string;
  mode: string; // TRUCK, BARGE, VESSEL, etc.
  origin: string; // Port/Hub Name
  destination: string; // Port/Hub Name
  cargo_type: CargoSize;
  quantity: number;
  departure: string;
  ETA: string;
  status: ShipmentStatus;
  events: {
    timestamp: string;
    status: ShipmentStatus;
    description: string;
  }[];
}

export interface Invoice {
  invoice_id: string;
  trade_id: string;
  buyer_id: string;
  seller_id: string;
  quantity: number;
  price: number;
  adjustments: number; // e.g. quality adjustments (+/-)
  fees: number;
  total: number;
  currency: string;
  status: "UNPAID" | "PAID" | "REVERSED";
  created_at: string;
}

export interface LedgerEntry {
  entry_id: string;
  account_id: string; // Participant / Fund Cash or Asset account
  debit: number;
  credit: number;
  description: string;
  timestamp: string;
  trade_id?: string;
}

export interface Plant {
  plant_id: string;
  name: string;
  location: string;
  capacity: number; // MT per day
  utilisation: number; // %
  feedstock: string; // e.g. Naphtha, Natural Gas, Benzene
  yield_rate: number; // % yield
  variable_cost: number; // EUR/MT
  fixed_cost: number; // EUR/MT
  outage_state: OutageState;
}

export interface Participant {
  participant_id: string;
  name: string;
  type: "PRODUCER" | "BUYER" | "TRADER" | "FUND" | "DISTRIBUTOR";
  permitted_products: string[];
  credit_limit: number;
  cash_balance: number;
  allocated_margin: number;
  physical_capacity: number; // storage limit
}

export interface MarketData {
  market_id: string;
  symbol: string;
  last: number | null;
  bid: number | null;
  ask: number | null;
  mid: number | null;
  vwap: number | null;
  high: number | null;
  low: number | null;
  open: number | null;
  volume: number;
  trade_count: number;
  spread: number | null;
  spread_pct: number | null;
  price_history: { timestamp: string; price: number; quantity: number }[];
  depth: {
    bids: { price: number; quantity: number; count: number }[];
    asks: { price: number; quantity: number; count: number }[];
  };
}

export interface AuditEvent {
  event_id: string;
  actor: string;
  timestamp: string;
  sequence: number;
  entity: string; // e.g. "Order", "Trade", "Lot"
  before_state_hash: string;
  after_state_hash: string;
  reason: string;
}
