"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { Product, CartItem, Depot, SavedList, OrderRecord, TradeAccount } from "./types";
import { PRODUCTS, DEPOTS, INITIAL_ACCOUNT, INITIAL_SAVED_LISTS, INITIAL_ORDERS } from "./data";

interface StoreContextType {
  // Account
  account: TradeAccount;
  isLoggedIn: boolean;
  setIsLoggedIn: (v: boolean) => void;

  // Selected Depot
  selectedDepot: Depot;
  setSelectedDepot: (d: Depot) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotalExVat: number;
  cartTotalIncVat: number;
  cartTotalSavings: number;
  cartItemCount: number;

  // Modals & Overlays
  isCartOpen: boolean;
  setIsCartOpen: (v: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (v: boolean) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedProductModal: Product | null;
  setSelectedProductModal: (p: Product | null) => void;
  selectedDepotModal: Depot | null;
  setSelectedDepotModal: (d: Depot | null) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (v: boolean) => void;
  isTradeRegisterOpen: boolean;
  setIsTradeRegisterOpen: (v: boolean) => void;

  // Filtering
  selectedCategory: string | null;
  setSelectedCategory: (cat: string | null) => void;

  // Lists & Orders
  savedLists: SavedList[];
  addListToCart: (listId: string) => void;
  orders: OrderRecord[];
  addOrder: (order: OrderRecord) => void;

  // Quick Order Term state
  quickOrderSearch: string;
  setQuickOrderSearch: (s: string) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

// Helper to calculate applicable bulk unit price based on product bulk pricing table
export function getBulkUnitPrice(product: Product, quantity: number): number {
  if (!product.bulkPricing || product.bulkPricing.length === 0) {
    return product.priceExVat;
  }
  // Sort descending by minQty
  const sorted = [...product.bulkPricing].sort((a, b) => b.minQty - a.minQty);
  const match = sorted.find((tier) => quantity >= tier.minQty);
  return match ? match.priceExVat : product.priceExVat;
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [account, setAccount] = useState<TradeAccount>(INITIAL_ACCOUNT);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [selectedDepot, setSelectedDepot] = useState<Depot>(DEPOTS[0]);
  
  // Initial demo cart items
  const [cart, setCart] = useState<CartItem[]>([
    {
      product: PRODUCTS[0], // Coca Cola
      quantity: 10,
      appliedUnitPrice: getBulkUnitPrice(PRODUCTS[0], 10),
    },
    {
      product: PRODUCTS[3], // Veg Oil 20L
      quantity: 5,
      appliedUnitPrice: getBulkUnitPrice(PRODUCTS[3], 5),
    },
    {
      product: PRODUCTS[7], // Crown Blue Roll
      quantity: 10,
      appliedUnitPrice: getBulkUnitPrice(PRODUCTS[7], 10),
    },
  ]);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProductModal, setSelectedProductModal] = useState<Product | null>(null);
  const [selectedDepotModal, setSelectedDepotModal] = useState<Depot | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isTradeRegisterOpen, setIsTradeRegisterOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const [savedLists, setSavedLists] = useState<SavedList[]>(INITIAL_SAVED_LISTS);
  const [orders, setOrders] = useState<OrderRecord[]>(INITIAL_ORDERS);
  const [quickOrderSearch, setQuickOrderSearch] = useState("");

  // Cart helper actions
  const addToCart = (product: Product, qty: number = 1) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex((item) => item.product.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        const newQty = updated[existingIndex].quantity + qty;
        updated[existingIndex] = {
          product,
          quantity: newQty,
          appliedUnitPrice: getBulkUnitPrice(product, newQty),
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            product,
            quantity: qty,
            appliedUnitPrice: getBulkUnitPrice(product, qty),
          },
        ];
      }
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          return {
            ...item,
            quantity,
            appliedUnitPrice: getBulkUnitPrice(item.product, quantity),
          };
        }
        return item;
      })
    );
  };

  const clearCart = () => setCart([]);

  // Compute totals
  const cartTotalExVat = cart.reduce((sum, item) => sum + item.appliedUnitPrice * item.quantity, 0);
  const cartTotalIncVat = cart.reduce((sum, item) => {
    const vatAmount = item.appliedUnitPrice * item.quantity * item.product.vatRate;
    return sum + (item.appliedUnitPrice * item.quantity + vatAmount);
  }, 0);

  // Compute savings compared to base single case price
  const cartTotalSavings = cart.reduce((sum, item) => {
    const basePrice = item.product.bulkPricing && item.product.bulkPricing.length > 0
      ? Math.max(...item.product.bulkPricing.map(t => t.priceExVat))
      : item.product.priceExVat;
    const diff = Math.max(0, basePrice - item.appliedUnitPrice);
    return sum + diff * item.quantity;
  }, 0);

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const addListToCart = (listId: string) => {
    const list = savedLists.find((l) => l.id === listId);
    if (!list) return;
    list.items.forEach((item) => {
      const p = PRODUCTS.find((prod) => prod.id === item.productId);
      if (p) {
        addToCart(p, item.quantity);
      }
    });
    setIsCartOpen(true);
  };

  const addOrder = (newOrder: OrderRecord) => {
    setOrders((prev) => [newOrder, ...prev]);
  };

  return (
    <StoreContext.Provider
      value={{
        account,
        isLoggedIn,
        setIsLoggedIn,
        selectedDepot,
        setSelectedDepot,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartTotalExVat,
        cartTotalIncVat,
        cartTotalSavings,
        cartItemCount,
        isCartOpen,
        setIsCartOpen,
        isSearchOpen,
        setIsSearchOpen,
        searchQuery,
        setSearchQuery,
        selectedProductModal,
        setSelectedProductModal,
        selectedDepotModal,
        setSelectedDepotModal,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isTradeRegisterOpen,
        setIsTradeRegisterOpen,
        selectedCategory,
        setSelectedCategory,
        savedLists,
        addListToCart,
        orders,
        addOrder,
        quickOrderSearch,
        setQuickOrderSearch,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error("useStore must be used within a StoreProvider");
  }
  return context;
}
