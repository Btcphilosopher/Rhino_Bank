export interface Product {
  id: string;
  sku: string;
  name: string;
  brand: string;
  category: string;
  packSize: string; // e.g. "24 × 330ml"
  unitType: "CASE" | "PALLET" | "PACK" | "BOX";
  priceExVat: number; // e.g. 17.40
  vatRate: number; // e.g. 0.20
  availableStock: number;
  featured?: boolean;
  isNew?: boolean;
  dealTag?: string;
  discountPercentage?: number;
  imageUrl: string;
  aisle: string; // e.g. "A01"
  bulkPricing: {
    minQty: number;
    priceExVat: number;
  }[];
  costPerUnit: number; // e.g. 0.725
  suggestedRrp: number; // e.g. 1.20
  description?: string;
  origin?: string;
}

export interface Category {
  id: string;
  name: string;
  code: string;
  itemCount: number;
  imageUrl: string;
  subcategories: string[];
}

export interface Depot {
  id: string;
  name: string;
  city: string;
  region: string;
  address: string;
  postcode: string;
  phone: string;
  status: "OPEN" | "BUSY" | "CLOSING_SOON";
  openingHours: string;
  coordinates: { x: number; y: number }; // Percentage offset on Britain map (0-100)
  stockCapacityPercent: number;
  services: string[];
  todayCollectionSlots: string[];
  manager: string;
}

export interface BusinessSector {
  id: string;
  name: string;
  tagline: string;
  description: string;
  imageUrl: string;
  popularCategories: string[];
  averageOrderValue: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  appliedUnitPrice: number; // Price per case after bulk discount
}

export interface SavedList {
  id: string;
  name: string;
  description: string;
  itemCount: number;
  items: {
    productId: string;
    quantity: number;
  }[];
}

export interface OrderRecord {
  id: string;
  date: string;
  status: "ORDER RECEIVED" | "PICKING" | "PICKED" | "LOADED" | "DEPARTED" | "ON ROUTE" | "DELIVERED";
  itemsCount: number;
  totalExVat: number;
  totalIncVat: number;
  savings: number;
  depotName: string;
  deliveryAddress: string;
  estimatedDelivery: string;
  trackingStepIndex: number;
}

export interface TradeAccount {
  companyName: string;
  accountNumber: string;
  vatNumber: string;
  sector: string;
  creditLimit: number;
  creditUsed: number;
  preferredDepotId: string;
  primaryContact: string;
  email: string;
  deliveryAddress: string;
  monthlySpendHistory: { month: string; spend: number }[];
}
