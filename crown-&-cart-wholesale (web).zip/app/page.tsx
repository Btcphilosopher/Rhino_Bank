"use client";

import React from "react";
import Header from "@/components/header/Header";
import Hero from "@/components/hero/Hero";
import StockYourBusinessSection from "@/components/home/StockYourBusinessSection";
import DigitalDepotSection from "@/components/digital-depot/DigitalDepotSection";
import CatalogueSection from "@/components/catalogue/CatalogueSection";
import DealsSection from "@/components/deals/DealsSection";
import DepotFinder from "@/components/depot/DepotFinder";
import LogisticsAndSectors from "@/components/logistics/LogisticsAndSectors";
import BusinessTerminal from "@/components/terminal/BusinessTerminal";
import CartOverlays from "@/components/cart/CartOverlays";
import SearchOverlay from "@/components/search/SearchOverlay";
import Footer from "@/components/footer/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-[#F5F2EA] flex flex-col selection:bg-[#0B1B36] selection:text-white">
      {/* Dynamic Overlays & Modals */}
      <SearchOverlay />
      <CartOverlays />

      {/* Main Structural Layout */}
      <Header />
      <Hero />
      <StockYourBusinessSection />
      
      {/* Digital Depot Transformational Interaction */}
      <DigitalDepotSection />
      
      {/* Dense Catalogue Grid */}
      <CatalogueSection />

      {/* Editorial Deals Campaigns */}
      <DealsSection />

      {/* Technical Schematic Map & Finder */}
      <DepotFinder />

      {/* Cash & Carry, Delivery route simulations and Business Sectors */}
      <LogisticsAndSectors />

      {/* Quick Order spreadsheet sheet terminal & saved list management */}
      <BusinessTerminal />

      {/* Substantial footer */}
      <Footer />
    </main>
  );
}
