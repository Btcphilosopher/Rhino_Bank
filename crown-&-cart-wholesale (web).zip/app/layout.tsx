import type { Metadata } from 'next';
import './globals.css';
import { StoreProvider } from '@/lib/store';

export const metadata: Metadata = {
  title: 'Crown & Cart Wholesale | Anglo-Futurist Cash-and-Carry Network',
  description: 'National British wholesale distribution platform. Trade pricing, live depot inventory, and scheduled business delivery.',
  openGraph: {
    title: 'Crown & Cart Wholesale',
    description: 'National British wholesale distribution platform. Trade pricing, live depot inventory, and scheduled business delivery.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Crown & Cart Wholesale',
    description: 'National British wholesale distribution platform. Trade pricing, live depot inventory, and scheduled business delivery.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="bg-[#F5F2EA] text-[#1A1F26]">
      <body suppressHydrationWarning className="antialiased selection:bg-[#0B1B36] selection:text-white">
        <StoreProvider>{children}</StoreProvider>
      </body>
    </html>
  );
}
