"use client";

import React, { useEffect, useState } from "react";
import { useStore } from "@/lib/store";
import { DEPOTS } from "@/lib/data";
import { Anchor, Compass, ShieldCheck, Mail, MapPin, ExternalLink, HelpCircle } from "lucide-react";

export default function Footer() {
  const { setSelectedDepot } = useStore();
  const [mapAnimated, setMapAnimated] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setMapAnimated(true);
    }, 600);
    return () => clearTimeout(timer);
  }, []);

  const footerLinks = [
    {
      title: "PROCUREMENT",
      items: [
        { label: "SHOP CATALOGUE", href: "#catalogue-section" },
        { label: "TRADE DEALS", href: "#deals-section" },
        { label: "QUICK TERMINAL", href: "#quick-order-section" },
        { label: "SAVED LISTS", href: "#quick-order-section" },
      ],
    },
    {
      title: "DISTRIBUTION",
      items: [
        { label: "DEPOT MAP", href: "#depot-section" },
        { label: "DELIVERY ROUTES", href: "#delivery-section" },
        { label: "CLICK & COLLECT", href: "#depot-section" },
        { label: "COLD CHAIN LOGISTICS", href: "#delivery-section" },
      ],
    },
    {
      title: "CORPORATE",
      items: [
        { label: "ABOUT CROWN & CART", href: "#" },
        { label: "SUPPLIER OPPORTUNITIES", href: "#" },
        { label: "B2B TAX STANDARDS", href: "#" },
        { label: "HMRC EX VAT INVOICES", href: "#" },
      ],
    },
    {
      title: "HELP & SUPPORT",
      items: [
        { label: "CONTACT DESK", href: "#" },
        { label: "TRADE CREDIT ENQUIRIES", href: "#" },
        { label: "COMPLIANCE & LEGAL", href: "#" },
        { label: "ACCESSIBILITY GUIDELINES", href: "#" },
      ],
    },
  ];

  return (
    <footer className="bg-[#071226] text-white border-t-2 border-[#0B1B36] pt-16 pb-8 font-sans">
      <div className="max-w-[1360px] mx-auto px-4 md:px-8">
        
        {/* MAIN FOOTER COLUMNS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-12 border-b border-white/10 items-start">
          
          {/* Fictional Wordmark & info (4 columns) */}
          <div className="lg:col-span-4 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white text-[#0B1B36] flex items-center justify-center font-bold text-base border border-white">
                C&C
              </div>
              <div className="flex flex-col">
                <span className="font-mono text-[9px] tracking-[0.25em] text-slate-400 uppercase leading-none">
                  EST. 1968 • BRITAIN
                </span>
                <span className="font-black text-lg tracking-tighter uppercase leading-none mt-1">
                  CROWN <span className="text-slate-400 font-light">&</span> CART
                </span>
              </div>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Crown & Cart Wholesale Distribution PLC is a national British logistics and cash-and-carry infrastructure partner. Standard ex-VAT pricing models apply to all business trade accounts.
            </p>

            <div className="font-mono text-[10px] space-y-1.5 text-slate-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>HMRC AUDITED EX-VAT SYSTEM v2.6</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-500" />
                <span>TRADE-DESK@CROWNCARTWHOLESALE.CO.UK</span>
              </div>
            </div>
          </div>

          {/* Links columns (5 columns) */}
          <div className="lg:col-span-5 grid grid-cols-2 sm:grid-cols-4 gap-6 md:gap-8 font-mono text-[11px] tracking-wider">
            {footerLinks.map((col) => (
              <div key={col.title} className="space-y-4">
                <span className="text-slate-400 font-bold block text-[10px] uppercase">
                  {col.title}
                </span>
                <ul className="space-y-2.5 text-slate-300">
                  {col.items.map((item) => (
                    <li key={item.label}>
                      <a href={item.href} className="hover:text-amber-400 hover:underline transition-colors block">
                        {item.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Outline Britain Map drawing in the footer! (3 columns) */}
          <div className="lg:col-span-3 border border-white/10 p-5 bg-white/5 relative aspect-square flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 opacity-5 pointer-events-none">
              {Array.from({ length: 16 }).map((_, i) => (
                <div key={i} className="border border-white/40" />
              ))}
            </div>

            <svg
              viewBox="0 0 100 100"
              className="absolute inset-0 w-full h-full p-3 pointer-events-none opacity-20"
              fill="none"
              stroke="white"
              strokeWidth="0.5"
            >
              <path
                d="M 40,5 C 38,10 32,15 35,20 C 37,23 48,22 46,26 C 42,28 35,24 38,32 C 40,35 48,34 50,38 C 55,42 50,48 54,48 C 58,48 64,44 64,32 C 64,30 68,36 72,40 C 76,44 80,55 84,66 C 88,72 80,78 74,78 C 65,78 58,74 48,79 C 42,79 40,75 44,77 C 48,82 46,88 50,95 C 48,97 32,95 28,90 C 24,85 28,78 30,72 C 32,68 28,64 26,60 C 24,56 22,48 26,41 C 28,38 34,40 38,35 C 39,25 35,18 40,5 Z"
                className="stroke-white animate-draw-line"
                strokeWidth="0.8"
              />
            </svg>

            {/* Sequential dots of depots appearing */}
            {mapAnimated &&
              DEPOTS.map((depot, index) => (
                <div
                  key={depot.id}
                  onClick={() => {
                    setSelectedDepot(depot);
                    const el = document.getElementById("depot-section");
                    if (el) el.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="absolute w-1.5 h-1.5 rounded-full bg-emerald-400 hover:bg-amber-400 cursor-pointer border border-white/30 transition-colors"
                  style={{
                    left: `${depot.coordinates.x}%`,
                    top: `${depot.coordinates.y}%`,
                    animationDelay: `${index * 150}ms`,
                  }}
                  title={depot.name}
                />
              ))}

            <div className="absolute bottom-3 left-3 right-3 flex justify-between font-mono text-[8px] text-slate-500 uppercase tracking-widest">
              <span>DRAWING MAP ACTIVE</span>
              <span>70+ DOCKS LISTED</span>
            </div>
          </div>

        </div>

        {/* BOTTOM METADATA & COPYRIGHT */}
        <div className="pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500 font-mono">
          <div className="flex flex-wrap items-center gap-4">
            <span>© 2026 CROWN & CART WHOLESALE SYSTEM. ALL RIGHTS RESERVED.</span>
            <span>•</span>
            <span>PLC REF. GB-849201-92</span>
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">PRIVACY CODE</a>
            <a href="#" className="hover:text-white transition-colors">CREDIT COMPLIANCE</a>
            <a href="#" className="hover:text-white transition-colors">ACCESSIBILITY AA</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
