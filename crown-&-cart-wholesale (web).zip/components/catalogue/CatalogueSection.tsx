"use client";

import React, { useState } from "react";
import { useStore } from "@/lib/store";
import { CATEGORIES, PRODUCTS } from "@/lib/data";
import { Product } from "@/lib/types";
import { Search, Calculator, Check, ArrowRight, Tag, Info, Sliders, Sparkles, X, Plus, Minus, ShoppingBag } from "lucide-react";

export default function CatalogueSection() {
  const {
    cart,
    addToCart,
    updateQuantity,
    selectedCategory,
    setSelectedCategory,
    selectedProductModal,
    setSelectedProductModal,
    searchQuery,
    setSearchQuery,
    setIsCartOpen,
  } = useStore();

  const [activeSearch, setActiveSearch] = useState("");
  const [calcCost, setCalcCost] = useState(17.40);
  const [calcRetail, setCalcRetail] = useState(24.00);

  // Filter products by category and active search
  const filteredProducts = PRODUCTS.filter((p) => {
    const matchesCategory = selectedCategory ? p.category === selectedCategory : true;
    const matchesSearch = activeSearch
      ? p.name.toLowerCase().includes(activeSearch.toLowerCase()) ||
        p.brand.toLowerCase().includes(activeSearch.toLowerCase()) ||
        p.sku.toLowerCase().includes(activeSearch.toLowerCase())
      : true;
    return matchesCategory && matchesSearch;
  });

  // Calculate margin parameters
  const profit = Math.max(0, calcRetail / 1.2 - calcCost); // Assume 20% VAT on selling price
  const margin = calcRetail > 0 ? (profit / (calcRetail / 1.2)) * 100 : 0;
  const markup = calcCost > 0 ? (profit / calcCost) * 100 : 0;

  // Handle opening product modal and pre-setting margin calculator
  const openProductDetail = (p: Product) => {
    setSelectedProductModal(p);
    setCalcCost(p.priceExVat);
    // Suggest standard retail markup
    setCalcRetail(parseFloat((p.priceExVat * 1.35 * (1 + p.vatRate)).toFixed(2)));
  };

  return (
    <section id="catalogue-section" className="py-16 md:py-24 bg-white border-b border-[#1A1F26]/10">
      <div className="max-w-[1360px] mx-auto px-4 md:px-8">
        
        {/* SECTION HEADER */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12 pb-6 border-b border-[#1A1F26]/15">
          <div>
            <span className="font-mono text-xs tracking-widest text-[#0A5C36] font-bold uppercase block mb-2">
              NATIONAL LOGISTICS CATALOGUE
            </span>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase text-[#0B1B36] font-sans">
              SHOP WHOLESALE.
            </h2>
          </div>

          {/* Inline Live Search / Autocomplete Filter */}
          <div className="relative max-w-md w-full">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono text-xs text-slate-400">SKU/BRAND:</span>
            <input
              type="text"
              placeholder="Search product directory..."
              value={activeSearch}
              onChange={(e) => setActiveSearch(e.target.value)}
              className="w-full bg-[#F5F2EA] border-2 border-[#0B1B36] pl-28 pr-10 py-3 font-sans text-sm focus:outline-none focus:bg-white transition-all square-card"
            />
            {activeSearch ? (
              <button
                onClick={() => setActiveSearch("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-[#0B1B36]"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            )}
          </div>
        </div>

        {/* CATEGORIES HORIZONTAL PANEL */}
        <div className="mb-10 space-y-4">
          <div className="flex items-center justify-between font-mono text-xs text-slate-500 tracking-wider">
            <span>CHOOSE SECTOR CATEGORY ({CATEGORIES.length} DEPARTMENTS)</span>
            {selectedCategory && (
              <button
                onClick={() => setSelectedCategory(null)}
                className="text-[#C82A2A] font-bold hover:underline"
              >
                CLEAR FILTER [×]
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {CATEGORIES.map((cat, idx) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(isSelected ? null : cat.id)}
                  className={`border-2 p-4 text-left flex flex-col justify-between h-36 transition-all relative overflow-hidden group ${
                    isSelected
                      ? "border-[#0A5C36] bg-[#E6F4ED]"
                      : "border-[#0B1B36] hover:border-[#0A5C36] bg-white"
                  }`}
                >
                  <div className="absolute top-0 right-0 w-16 h-16 opacity-10 group-hover:opacity-20 transition-opacity">
                    <img src={cat.imageUrl} alt="" className="w-full h-full object-cover" />
                  </div>

                  <span className="font-mono text-xs font-bold text-slate-400">
                    {cat.code}
                  </span>

                  <div className="z-10">
                    <h3 className="font-sans font-black text-sm uppercase text-[#0B1B36] leading-tight group-hover:text-[#0A5C36] transition-colors">
                      {cat.name}
                    </h3>
                    <span className="font-mono text-[10px] text-slate-500 block mt-1">
                      {cat.itemCount} LINES
                    </span>
                  </div>

                  {/* Tiny indicator line on hover */}
                  <div className="absolute bottom-0 left-0 h-1 bg-[#0A5C36] w-0 group-hover:w-full transition-all duration-300" />
                </button>
              );
            })}
          </div>
        </div>

        {/* PRODUCTS DENSE GRID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map((p) => {
            const inCartItem = cart.find((item) => item.product.id === p.id);
            return (
              <div
                key={p.id}
                className="bg-white border-2 border-[#0B1B36] p-5 flex flex-col justify-between h-full hover:shadow-lg transition-all relative group"
              >
                {/* Offer or Deal Ribbon */}
                {p.dealTag && (
                  <div className="absolute -top-3 left-4 bg-[#C82A2A] text-white font-mono text-[10px] font-bold uppercase px-2.5 py-0.5 border border-[#0B1B36] z-10">
                    {p.dealTag}
                  </div>
                )}

                {/* SKU Header info */}
                <div className="flex items-center justify-between font-mono text-[10px] text-slate-500 mb-3 border-b border-slate-100 pb-2">
                  <span>SKU: {p.sku}</span>
                  <span>AISLE: {p.aisle}</span>
                </div>

                {/* Main Product Image Container */}
                <div
                  onClick={() => openProductDetail(p)}
                  className="h-44 flex items-center justify-center p-3 cursor-pointer overflow-hidden bg-[#FAF8F3] border border-slate-100 relative"
                >
                  <img
                    src={p.imageUrl}
                    alt={p.name}
                    className="h-full object-contain group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-[#0B1B36]/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="bg-[#0B1B36] text-white font-mono text-[10px] px-3 py-1.5 uppercase font-bold tracking-wider">
                      SPECIFICATION ↗
                    </span>
                  </div>
                </div>

                {/* Text details */}
                <div className="mt-4 space-y-1">
                  <span className="font-mono text-[10px] text-slate-400 tracking-wider uppercase block">
                    {p.brand}
                  </span>
                  <h3
                    onClick={() => openProductDetail(p)}
                    className="font-bold text-[#0B1B36] hover:text-[#0A5C36] cursor-pointer text-base leading-snug line-clamp-2 font-sans"
                  >
                    {p.name}
                  </h3>
                  <div className="flex items-center gap-2 font-mono text-xs text-slate-600">
                    <span className="bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-[#0B1B36]">
                      {p.unitType}
                    </span>
                    <span>{p.packSize}</span>
                  </div>
                </div>

                {/* Pricing Block */}
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-end justify-between">
                  <div>
                    <span className="font-mono text-[10px] text-slate-400 block uppercase leading-none">
                      TRADE PRICE
                    </span>
                    <div className="flex items-baseline gap-1 mt-1">
                      <span className="text-2xl font-black text-[#0B1B36] font-mono leading-none">
                        £{p.priceExVat.toFixed(2)}
                      </span>
                      <span className="font-mono text-[10px] text-[#C82A2A] font-bold">
                        EX VAT
                      </span>
                    </div>
                    <span className="font-mono text-[10px] text-slate-500 block">
                      £{(p.priceExVat * (1 + p.vatRate)).toFixed(2)} INC VAT
                    </span>
                  </div>

                  {/* Add to Basket Action */}
                  {inCartItem ? (
                    <div className="flex items-center border-2 border-[#0A5C36] bg-[#E6F4ED]">
                      <button
                        onClick={() => updateQuantity(p.id, inCartItem.quantity - 1)}
                        className="px-2.5 py-1.5 text-[#0A5C36] hover:bg-emerald-100 transition-colors font-mono font-bold"
                      >
                        -
                      </button>
                      <span className="px-3 font-mono text-xs font-bold text-[#0A5C36]">
                        {inCartItem.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(p.id, inCartItem.quantity + 1)}
                        className="px-2.5 py-1.5 text-[#0A5C36] hover:bg-emerald-100 transition-colors font-mono font-bold"
                      >
                        +
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => addToCart(p, 1)}
                      className="bg-[#0B1B36] hover:bg-[#0A5C36] text-white px-4 py-2 text-xs font-mono font-bold uppercase transition-colors"
                    >
                      + ADD
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* NO RESULTS VIEW */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-16 border-2 border-dashed border-slate-300 p-8">
            <span className="font-mono text-sm text-slate-500 uppercase block mb-2">
              0 ARCHIVE RESULTS FOUND
            </span>
            <p className="text-slate-600 max-w-md mx-auto text-sm">
              No trade lines matched your active filters. Try clearing your search parameters.
            </p>
            <button
              onClick={() => {
                setActiveSearch("");
                setSelectedCategory(null);
              }}
              className="mt-4 bg-[#0B1B36] text-white text-xs font-mono px-4 py-2 uppercase font-semibold"
            >
              RESET ENGINE FILTERS
            </button>
          </div>
        )}

        {/* SIGNATURE 02: THE WHOLESALE PRICE BREAK & MARGIN CALCULATOR DIALOGUE */}
        {selectedProductModal && (
          <div className="fixed inset-0 z-50 bg-[#071226]/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#FAF8F3] border-2 border-[#0B1B36] max-w-4xl w-full max-h-[90vh] overflow-y-auto flex flex-col md:flex-row relative square-card">
              
              {/* Close Button */}
              <button
                onClick={() => setSelectedProductModal(null)}
                className="absolute top-4 right-4 bg-[#0B1B36] hover:bg-[#C82A2A] text-white p-2 border border-white/20 z-10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>

              {/* LEFT HALF: Product Details & Price Break Ladder */}
              <div className="w-full md:w-1/2 p-6 md:p-8 border-b md:border-b-0 md:border-r border-slate-200 space-y-6">
                <div>
                  <span className="bg-[#0A5C36] text-white font-mono text-[10px] px-2.5 py-0.5 font-bold uppercase block w-fit mb-3">
                    AISLE {selectedProductModal.aisle} • SKU {selectedProductModal.sku}
                  </span>
                  <h3 className="text-2xl md:text-3xl font-black uppercase text-[#0B1B36] tracking-tight leading-none">
                    {selectedProductModal.name}
                  </h3>
                  <span className="font-mono text-xs text-slate-500 block mt-1">
                    BRAND: {selectedProductModal.brand} | PACK: {selectedProductModal.packSize}
                  </span>
                </div>

                {/* Product Image */}
                <div className="h-48 bg-white p-4 border border-slate-200 flex items-center justify-center">
                  <img src={selectedProductModal.imageUrl} alt="" className="h-full object-contain" />
                </div>

                {/* Dynamic Price Ladder */}
                <div className="space-y-3 font-mono">
                  <span className="text-[11px] text-slate-500 uppercase tracking-wider block">
                    WHOLESALE MULTI-CASE DISCOUNT TIERS
                  </span>
                  <div className="grid grid-cols-4 gap-2 text-center text-xs">
                    {selectedProductModal.bulkPricing.map((tier) => (
                      <div
                        key={tier.minQty}
                        className="bg-white border border-[#0B1B36] p-2 hover:bg-[#E6F4ED] transition-colors"
                      >
                        <span className="block font-bold text-[#0B1B36]">{tier.minQty}+ {selectedProductModal.unitType}s</span>
                        <span className="block text-slate-800 font-bold mt-1">£{tier.priceExVat.toFixed(2)}</span>
                        <span className="block text-[9px] text-emerald-600 font-medium">ex VAT</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="font-mono text-[11px] text-slate-400 uppercase block">SPECIFICATION DIRECTIVE</span>
                  <p className="text-slate-600 text-xs font-sans mt-1 leading-relaxed">
                    {selectedProductModal.description || "Premium wholesale supply. High quality guaranteed retail distribution lines across the United Kingdom."}
                  </p>
                </div>
              </div>

              {/* RIGHT HALF: Margin Calculator */}
              <div className="w-full md:w-1/2 p-6 md:p-8 bg-white flex flex-col justify-between">
                <div className="space-y-6">
                  <div className="flex items-center gap-2 text-[#0A5C36] font-mono text-xs font-bold uppercase border-b pb-3">
                    <Calculator className="w-4 h-4" />
                    <span>TRADE MARGIN CALCULATOR</span>
                  </div>

                  <div>
                    <h4 className="font-mono text-xs text-slate-500 uppercase">WHAT COULD YOUR BUSINESS MAKE?</h4>
                    <p className="text-slate-600 text-xs font-sans mt-1">
                      Drag or edit target retail selling price (inc VAT) to estimate your gross profit margin profile.
                    </p>
                  </div>

                  {/* Calculator Inputs */}
                  <div className="space-y-4">
                    {/* Trade Cost Unit */}
                    <div className="bg-[#FAF8F3] border border-[#0B1B36] p-3 font-mono text-xs flex justify-between items-center">
                      <span className="text-slate-600 uppercase">YOUR UNIT COST (EX VAT):</span>
                      <span className="text-base font-black text-[#0B1B36]">£{calcCost.toFixed(2)}</span>
                    </div>

                    {/* Selling Price input & slider */}
                    <div className="space-y-2 font-mono text-xs">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-600 uppercase">SELLING PRICE (INC VAT):</span>
                        <div className="flex items-center border border-[#0B1B36] px-2 py-1">
                          <span className="text-slate-500 mr-1">£</span>
                          <input
                            type="number"
                            step="0.05"
                            value={calcRetail}
                            onChange={(e) => setCalcRetail(Math.max(0, parseFloat(e.target.value) || 0))}
                            className="w-16 focus:outline-none font-bold text-right"
                          />
                        </div>
                      </div>
                      <input
                        type="range"
                        min={calcCost}
                        max={calcCost * 2.5}
                        step="0.1"
                        value={calcRetail}
                        onChange={(e) => setCalcRetail(parseFloat(e.target.value))}
                        className="w-full accent-[#0A5C36] cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Profit Margin Output Display */}
                  <div className="border border-[#0B1B36] p-4 space-y-3 bg-[#E6F4ED]/50">
                    <div className="flex justify-between items-center font-sans">
                      <span className="font-mono text-xs text-slate-600 uppercase">GROSS PROFIT PER CASE:</span>
                      <span className="text-xl font-mono font-black text-[#0A5C36]">£{profit.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-mono text-xs text-slate-600 uppercase">GP MARGIN:</span>
                      <span className="text-xl font-mono font-black text-[#0A5C36]">{margin.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-mono text-xs text-slate-600 uppercase">MARKUP RETURN:</span>
                      <span className="text-base font-mono font-bold text-slate-700">{markup.toFixed(1)}%</span>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 flex items-center gap-3">
                  <button
                    onClick={() => {
                      addToCart(selectedProductModal, 1);
                      setSelectedProductModal(null);
                    }}
                    className="flex-1 bg-[#0A5C36] hover:bg-emerald-700 text-white py-3.5 text-xs font-mono uppercase font-bold text-center transition-colors"
                  >
                    ADD TO CART & ANALYSE
                  </button>
                  <button
                    onClick={() => setSelectedProductModal(null)}
                    className="bg-[#0B1B36] hover:bg-slate-800 text-white px-5 py-3.5 text-xs font-mono uppercase font-bold transition-colors"
                  >
                    CLOSE
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
}
