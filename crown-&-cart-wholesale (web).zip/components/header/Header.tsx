"use client";

import React, { useState, useEffect } from "react";
import { useStore } from "@/lib/store";
import { Search, ShoppingBag, User, MapPin, Truck, HelpCircle, Phone, ArrowRight, Menu, X, ShieldCheck, Zap } from "lucide-react";

export default function Header() {
  const {
    account,
    selectedDepot,
    cartItemCount,
    cartTotalExVat,
    setIsCartOpen,
    setIsSearchOpen,
    setIsTradeRegisterOpen,
    setSelectedDepotModal,
  } = useStore();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full transition-all duration-300">
      {/* TOP UTILITY BAR (Compresses on scroll) */}
      <div
        className={`bg-[#071226] text-[#E2E5E8] text-xs transition-all duration-300 overflow-hidden border-b border-white/10 ${
          isScrolled ? "max-h-0 opacity-0 py-0" : "max-h-12 opacity-100 py-2.5"
        }`}
      >
        <div className="max-w-[1360px] mx-auto px-4 md:px-8 flex flex-wrap justify-between items-center gap-2">
          {/* Left utility info */}
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 font-mono text-[11px] tracking-wider text-emerald-400 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              TRADE CUSTOMER: {account.companyName}
            </span>
            <button
              onClick={() => setSelectedDepotModal(selectedDepot)}
              className="hidden sm:flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              <span>DEPOT: <strong className="text-white font-medium">{selectedDepot.name}</strong> ({selectedDepot.status})</span>
            </button>
          </div>

          {/* Right utility links */}
          <div className="flex items-center gap-6 font-mono text-[11px] tracking-widest text-slate-300">
            <button
              onClick={() => scrollToSection("depot-section")}
              className="hover:text-white transition-colors uppercase"
            >
              DEPOT FINDER
            </button>
            <button
              onClick={() => scrollToSection("delivery-section")}
              className="hidden md:block hover:text-white transition-colors uppercase"
            >
              DELIVERY
            </button>
            <button
              onClick={() => setIsTradeRegisterOpen(true)}
              className="hidden lg:block hover:text-white transition-colors uppercase text-amber-400 font-bold"
            >
              TRADE CREDIT: £{(account.creditLimit - account.creditUsed).toLocaleString()} AVAIL
            </button>
            <button
              onClick={() => scrollToSection("tools-section")}
              className="hover:text-white transition-colors uppercase"
            >
              ACCOUNT
            </button>
          </div>
        </div>
      </div>

      {/* PRIMARY NAVIGATION HEADER */}
      <div
        className={`bg-[#0B1B36] text-white transition-all duration-300 border-b border-white/10 ${
          isScrolled ? "py-3 shadow-xl backdrop-blur-md bg-[#0B1B36]/95" : "py-4 md:py-5"
        }`}
      >
        <div className="max-w-[1360px] mx-auto px-4 md:px-8 flex items-center justify-between gap-4">
          {/* LOGO & BRAND */}
          <div className="flex items-center gap-8">
            <a href="#" className="group flex items-center gap-3">
              {/* Crown & Cart Symbol */}
              <div className="w-9 h-9 bg-white text-[#0B1B36] flex items-center justify-center font-bold text-lg tracking-tighter border border-white group-hover:bg-[#0A5C36] group-hover:text-white transition-colors">
                C&C
              </div>
              <div className="flex flex-col">
                <span className="font-mono text-[10px] tracking-[0.25em] text-slate-400 uppercase leading-none">
                  EST. 1968 • BRITAIN
                </span>
                <span className="font-black text-xl md:text-2xl tracking-tighter uppercase leading-none mt-1">
                  CROWN <span className="text-slate-400 font-light">&</span> CART
                </span>
              </div>
            </a>

            {/* DESKTOP NAV LINKS */}
            <nav className="hidden lg:flex items-center gap-6 font-mono text-xs tracking-wider uppercase font-semibold text-slate-200">
              <button
                onClick={() => scrollToSection("catalogue-section")}
                className="hover:text-amber-400 transition-colors py-1 relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-amber-400 hover:after:w-full after:transition-all"
              >
                SHOP
              </button>
              <button
                onClick={() => scrollToSection("deals-section")}
                className="hover:text-amber-400 transition-colors py-1 text-emerald-400 font-bold relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-emerald-400 hover:after:w-full after:transition-all"
              >
                DEALS
              </button>
              <button
                onClick={() => scrollToSection("sectors-section")}
                className="hover:text-amber-400 transition-colors py-1 relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-amber-400 hover:after:w-full after:transition-all"
              >
                BUSINESS
              </button>
              <button
                onClick={() => scrollToSection("depot-section")}
                className="hover:text-amber-400 transition-colors py-1 relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-amber-400 hover:after:w-full after:transition-all"
              >
                DEPOTS
              </button>
              <button
                onClick={() => scrollToSection("delivery-section")}
                className="hover:text-amber-400 transition-colors py-1 relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-amber-400 hover:after:w-full after:transition-all"
              >
                DELIVERY
              </button>
              <button
                onClick={() => scrollToSection("quick-order-section")}
                className="hover:text-amber-400 transition-colors py-1 text-amber-300 font-mono relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-amber-300 hover:after:w-full after:transition-all"
              >
                QUICK ORDER
              </button>
            </nav>
          </div>

          {/* ACTIONS: SEARCH, ACCOUNT, BASKET */}
          <div className="flex items-center gap-3 md:gap-4">
            {/* Search Trigger */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-slate-200 px-3 md:px-4 py-2 text-xs font-mono border border-white/20 transition-all group"
            >
              <Search className="w-4 h-4 text-slate-300 group-hover:text-white" />
              <span className="hidden md:inline font-sans">SEARCH WHOLESALE</span>
              <kbd className="hidden sm:inline-block bg-white/10 text-[10px] px-1.5 py-0.5 rounded text-slate-300 border border-white/10 font-mono">
                /
              </kbd>
            </button>

            {/* Quick Order Terminal Button */}
            <button
              onClick={() => scrollToSection("quick-order-section")}
              className="hidden sm:flex items-center gap-1.5 bg-[#0A5C36] hover:bg-emerald-700 text-white px-3 py-2 text-xs font-mono uppercase font-bold border border-emerald-500 transition-all"
            >
              <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
              <span>TERMINAL</span>
            </button>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center gap-3 bg-white text-[#0B1B36] hover:bg-[#F5F2EA] px-3.5 md:px-5 py-2 font-mono text-xs font-bold transition-all border border-white"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4 text-[#0B1B36]" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#C82A2A] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                    {cartItemCount}
                  </span>
                )}
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[10px] text-slate-500 uppercase leading-none">BASKET</span>
                <span className="text-xs font-mono font-bold leading-none mt-0.5">
                  £{cartTotalExVat.toFixed(2)}
                </span>
              </div>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-200 hover:text-white border border-white/20"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* MOBILE MENU DROPDOWN */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#071226] border-t border-white/10 p-4 space-y-3 font-mono text-xs uppercase animate-fade-up">
            <button
              onClick={() => scrollToSection("catalogue-section")}
              className="block w-full text-left py-2 border-b border-white/10 hover:text-amber-400"
            >
              01 • SHOP WHOLESALE
            </button>
            <button
              onClick={() => scrollToSection("deals-section")}
              className="block w-full text-left py-2 border-b border-white/10 text-emerald-400 font-bold"
            >
              02 • TRADE DEALS & OFFERS
            </button>
            <button
              onClick={() => scrollToSection("sectors-section")}
              className="block w-full text-left py-2 border-b border-white/10 hover:text-amber-400"
            >
              03 • SECTOR SOLUTIONS
            </button>
            <button
              onClick={() => scrollToSection("quick-order-section")}
              className="block w-full text-left py-2 border-b border-white/10 text-amber-300"
            >
              04 • RAPID QUICK ORDER TERMINAL
            </button>
            <button
              onClick={() => scrollToSection("depot-section")}
              className="block w-full text-left py-2 border-b border-white/10 hover:text-amber-400"
            >
              05 • NATIONAL DEPOT MAP
            </button>
            <button
              onClick={() => scrollToSection("delivery-section")}
              className="block w-full text-left py-2 border-b border-white/10 hover:text-amber-400"
            >
              06 • LOGISTICS & TRACKING
            </button>
            <button
              onClick={() => scrollToSection("tools-section")}
              className="block w-full text-left py-2 hover:text-amber-400"
            >
              07 • MARGIN CALCULATOR & LEDGER
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
