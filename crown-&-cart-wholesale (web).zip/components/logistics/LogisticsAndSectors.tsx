"use client";

import React, { useState } from "react";
import { BUSINESS_SECTORS } from "@/lib/data";
import { Shield, Truck, Navigation, Award, CheckCircle2, ShoppingBag, Eye, HelpCircle } from "lucide-react";

export default function LogisticsAndSectors() {
  const [activeSector, setActiveSector] = useState(BUSINESS_SECTORS[0]);
  const [trackingStep, setTrackingStep] = useState(4); // 4 = ON ROUTE, 6 = DELIVERED, etc.

  const steps = [
    { label: "ORDER RECEIVED", time: "06:15 AM" },
    { label: "PICKING STOCK", time: "08:30 AM" },
    { label: "PICKED", time: "09:45 AM" },
    { label: "LOADED ON VEHICLE", time: "10:30 AM" },
    { label: "DEPARTED COLD STORE", time: "11:15 AM" },
    { label: "ON ROUTE (ROUTE LON-W-07)", time: "LIVE" },
    { label: "DELIVERED", time: "PENDING" },
  ];

  return (
    <section className="bg-white border-b border-[#1A1F26]/10">
      
      {/* 1. CASH & CARRY SECTION: WALK IN. LOAD UP. GET MOVING */}
      <div className="relative min-h-[500px] flex items-center justify-center bg-cover bg-center text-white" style={{ backgroundImage: `linear-gradient(to right, rgba(11, 27, 54, 0.95), rgba(7, 18, 38, 0.8)), url('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?q=80&w=1600&auto=format&fit=crop')` }}>
        
        {/* Scrollable layout simulated overlay of warehouse aisle markings */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 overflow-hidden opacity-10 pointer-events-none hidden md:flex flex-col justify-around font-mono text-4xl font-black select-none text-right pr-12">
          <span>A01 • BEVERAGES</span>
          <span>A02 • BULK DRY GOODS</span>
          <span>A03 • COLD CHAIN</span>
          <span>A04 • CANNED CATERING</span>
          <span>G01 • INDUSTRIAL CLEAN</span>
          <span>G02 • BLUE CENTREFOLD</span>
        </div>

        <div className="max-w-[1360px] mx-auto px-4 md:px-8 py-16 w-full relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <span className="font-mono text-xs tracking-widest text-emerald-400 font-bold uppercase block">
              PHYSICAL DEPOT PROCUREMENT
            </span>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase leading-[0.9] font-sans">
              WALK IN.<br />
              LOAD UP.<br />
              GET MOVING.
            </h2>
            <p className="text-slate-300 font-sans text-base md:text-lg max-w-lg leading-relaxed">
              Prefer to buy by hand? Step into any of our nationwide wholesale cash-and-carry facilities. Scan barcoded items directly as you walk aisles.
            </p>

            <div className="grid grid-cols-2 gap-4 font-mono text-xs text-slate-200">
              <div className="border border-white/10 p-3 bg-white/5">
                <span className="text-emerald-400 font-bold block">✓ SHOP IN DEPOT</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Use trade keycard</span>
              </div>
              <div className="border border-white/10 p-3 bg-white/5">
                <span className="text-emerald-400 font-bold block">✓ SCAN AS YOU SHOP</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Mobile barcode scan</span>
              </div>
              <div className="border border-white/10 p-3 bg-white/5">
                <span className="text-emerald-400 font-bold block">✓ LIVE PALLET COUNT</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Aisle shelf check</span>
              </div>
              <div className="border border-white/10 p-3 bg-white/5">
                <span className="text-emerald-400 font-bold block">✓ SECURE CREDIT CHECKOUT</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Fast terminal tap</span>
              </div>
            </div>
          </div>

          <div className="bg-white/10 border border-white/20 p-6 md:p-8 backdrop-blur-md font-mono text-xs max-w-md w-full space-y-4">
            <span className="text-slate-300 block font-bold text-[10px] tracking-widest">DEPOT INVENTORY DISPATCH PROTOCOL</span>
            <div className="space-y-2 text-slate-200">
              <div className="flex justify-between border-b border-white/10 pb-2">
                <span>VEHICLE REGISTRATION:</span>
                <strong className="text-white">UK76 CCW</strong>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-2">
                <span>BAY ASSIGNMENT:</span>
                <strong className="text-white">LOADING BAY 04</strong>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-2">
                <span>PRE-CLEARANCE STATUS:</span>
                <strong className="text-emerald-400 font-bold">APPROVED EX VAT</strong>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Register your vehicle prior to arrival to enable automatic terminal loading bay routing and invoice pre-staging.
            </p>
          </div>
        </div>
      </div>

      {/* 2. DELIVERY SECTION: WE'LL BRING IT TO YOU */}
      <div id="delivery-section" className="py-16 md:py-24 bg-[#FAF8F3] border-b border-[#1A1F26]/10">
        <div className="max-w-[1360px] mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-4 space-y-6">
            <span className="font-mono text-xs tracking-widest text-[#0A5C36] font-bold uppercase block">
              NATIONAL LOGISTICS SYSTEM
            </span>
            <h2 className="text-4xl md:text-5xl font-black tracking-tighter uppercase text-[#0B1B36] font-sans">
              WE WILL BRING IT TO YOU.
            </h2>
            <p className="text-slate-600 font-sans text-sm md:text-base leading-relaxed">
              With over 350 multi-temperature articulated vehicles, our fleet guarantees cold chain integrity from depot dock straight to your storage cupboards.
            </p>

            <div className="font-mono text-xs space-y-2 text-slate-700">
              <div className="flex justify-between border-b pb-2">
                <span>DELIVERY CODE:</span>
                <strong className="text-[#0B1B36]">CC-104829</strong>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span>NEXT DAY RE-ROUTE:</span>
                <strong className="text-[#0B1B36]">CUT-OFF 21:00</strong>
              </div>
              <div className="flex justify-between">
                <span>REFRIGERATED:</span>
                <strong className="text-emerald-600 font-bold">-18°C TO +4°C CONTROLLABLE</strong>
              </div>
            </div>
          </div>

          {/* Logistics Tracking Route Animation & Status */}
          <div className="lg:col-span-8 bg-white border-2 border-[#0B1B36] p-6 md:p-8 square-card space-y-6">
            <div className="flex items-center justify-between font-mono text-xs border-b pb-3">
              <span className="text-slate-500">LIVE ROUTE SIMULATION: DEPOT LONDON WEST ➜ RE Richmond</span>
              <span className="text-[#C82A2A] font-bold animate-pulse uppercase text-[10px]">VEHICLE ON ROUTE</span>
            </div>

            {/* Simulated Logistics Route Map (Conceptual railway style route) */}
            <div className="relative py-8">
              <div className="absolute top-1/2 left-0 right-0 h-1 bg-[#0B1B36] -translate-y-1/2" />
              
              {/* Animated Cargo Vehicle Dot */}
              <div
                className="absolute top-1/2 -translate-y-1/2 bg-emerald-500 text-white w-6 h-6 rounded-full flex items-center justify-center font-mono text-[9px] font-bold border-2 border-[#0B1B36] shadow-md transition-all duration-[3000ms] animate-bounce"
                style={{ left: "70%" }}
              >
                C&C
              </div>

              {/* End points */}
              <div className="flex justify-between relative z-10">
                <div className="bg-white border-2 border-[#0B1B36] px-2.5 py-1 font-mono text-[10px] font-bold text-[#0B1B36]">
                  DEPOT DOCK
                </div>
                <div className="bg-[#E6F4ED] border-2 border-[#0A5C36] px-2.5 py-1 font-mono text-[10px] font-bold text-[#0A5C36]">
                  YOUR BUSINESS OUTLET
                </div>
              </div>
            </div>

            {/* TIMELINE TRACKER INDICATORS */}
            <div className="space-y-3 font-mono text-xs">
              <span className="text-slate-400 block uppercase font-bold text-[10px] tracking-wider">ORDER PROGRESS TIMELINE:</span>
              <div className="relative border-l-2 border-[#0B1B36] pl-6 space-y-3.5">
                {steps.map((st, sIdx) => {
                  const isCurrent = sIdx === trackingStep;
                  const isCompleted = sIdx < trackingStep;
                  return (
                    <div key={st.label} className="relative flex justify-between items-center text-[11px]">
                      {/* Circle Dot bullet */}
                      <span className={`absolute -left-[30px] top-1 w-2.5 h-2.5 rounded-full border ${
                        isCurrent
                          ? "bg-amber-400 border-[#0B1B36] scale-125 animate-pulse"
                          : isCompleted
                          ? "bg-emerald-500 border-[#0B1B36]"
                          : "bg-white border-slate-300"
                      }`} />
                      <span className={`${isCurrent ? "font-bold text-[#0B1B36]" : isCompleted ? "text-slate-700" : "text-slate-400"}`}>
                        {st.label}
                      </span>
                      <span className="text-slate-400 text-[10px]">{st.time}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* 3. BUSINESS SECTORS: BUILT FOR PEOPLE WHO BUY FOR A LIVING */}
      <div id="sectors-section" className="py-16 md:py-24 bg-white">
        <div className="max-w-[1360px] mx-auto px-4 md:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="font-mono text-xs tracking-widest text-[#0A5C36] font-bold uppercase block mb-2">
              COMMERCIAL SECTOR SPECIALIZATION
            </span>
            <h2 className="text-3xl md:text-5xl font-black tracking-tighter uppercase text-[#0B1B36] font-sans">
              BUILT FOR BUSINESS.
            </h2>
            <p className="text-slate-600 font-sans mt-2 text-sm md:text-base">
              Custom inventory streams optimized for the precise requirements of your industry sector.
            </p>
          </div>

          {/* TWO PANEL INTERACTIVE HOVER MATRIX */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            
            {/* SECTOR MENU TILES (7 columns) */}
            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {BUSINESS_SECTORS.map((sec) => {
                const isActive = activeSector.id === sec.id;
                return (
                  <div
                    key={sec.id}
                    onMouseEnter={() => setActiveSector(sec)}
                    className={`border-2 p-5 text-left flex flex-col justify-between cursor-pointer transition-all duration-300 ${
                      isActive
                        ? "border-[#0A5C36] bg-[#E6F4ED]"
                        : "border-[#0B1B36] bg-white hover:border-[#0A5C36]"
                    }`}
                  >
                    <div>
                      <span className="font-mono text-[10px] text-slate-400 uppercase tracking-widest block">
                        SECTOR INDEX: {sec.id.toUpperCase()}
                      </span>
                      <h3 className="font-sans font-black text-lg text-[#0B1B36] uppercase mt-1 leading-tight">
                        {sec.name}
                      </h3>
                      <p className="text-slate-600 text-xs font-sans mt-2 leading-relaxed">
                        {sec.tagline}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-slate-200 mt-4 flex items-center justify-between font-mono text-[10px]">
                      <span className="text-slate-400">AVG SPEND: {sec.averageOrderValue}</span>
                      <span className="text-[#0A5C36] font-bold hover:underline uppercase">VIEW LINES →</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* HOVER DYNAMIC BACKGROUND VISUAL CARD (5 columns) */}
            <div className="lg:col-span-5 bg-[#0B1B36] border-2 border-[#0B1B36] p-8 flex flex-col justify-between relative text-white overflow-hidden">
              <div
                className="absolute inset-0 bg-cover bg-center transition-all duration-500 opacity-30 grayscale contrast-125 scale-105"
                style={{ backgroundImage: `url('${activeSector.imageUrl}')` }}
              />

              <div className="absolute inset-0 bg-gradient-to-t from-[#0B1B36] via-transparent to-transparent" />

              <div className="relative z-10 space-y-2">
                <span className="bg-[#C82A2A] text-white font-mono text-[9px] px-2 py-0.5 font-bold uppercase tracking-wider block w-fit">
                  SECTOR SPECIFICATION PROFILE
                </span>
                <h3 className="text-3xl font-black uppercase text-white font-sans tracking-tight">
                  {activeSector.name}
                </h3>
              </div>

              <div className="relative z-10 space-y-4">
                <p className="text-slate-200 text-xs font-sans leading-relaxed">
                  {activeSector.description}
                </p>

                <div className="font-mono text-[10px] space-y-1 border-t border-white/10 pt-3">
                  <span className="text-slate-400 uppercase block font-bold mb-1">POPULAR DEPARTMENT CODES:</span>
                  <div className="flex flex-wrap gap-1">
                    {activeSector.popularCategories.map((cat) => (
                      <span key={cat} className="bg-white/15 px-2 py-0.5 border border-white/10">
                        {cat.toUpperCase()}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      </div>

    </section>
  );
}
