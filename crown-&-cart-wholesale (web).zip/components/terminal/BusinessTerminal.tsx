"use client";

import React, { useState } from "react";
import { useStore } from "@/lib/store";
import { PRODUCTS, INITIAL_SAVED_LISTS } from "@/lib/data";
import { Terminal, Shield, Plus, Check, FileSpreadsheet, ArrowUpRight, Award, Trash2 } from "lucide-react";

export default function BusinessTerminal() {
  const {
    account,
    cart,
    addToCart,
    addListToCart,
    updateQuantity,
  } = useStore();

  const [activeTab, setActiveTab] = useState<"quick-order" | "saved-lists" | "ledger">("quick-order");
  const [selectedListId, setSelectedListId] = useState(INITIAL_SAVED_LISTS[0].id);

  // Terminal Row highlight trace status feedback
  const [highlightedRow, setHighlightedRow] = useState<string | null>(null);

  const handleTerminalAdd = (productId: string) => {
    const p = PRODUCTS.find((p) => p.id === productId);
    if (p) {
      addToCart(p, 1);
      setHighlightedRow(productId);
      setTimeout(() => setHighlightedRow(null), 850);
    }
  };

  return (
    <section id="quick-order-section" className="py-16 md:py-24 bg-[#0B1B36] text-white border-b border-black">
      <div className="max-w-[1360px] mx-auto px-4 md:px-8">
        
        {/* SECTION HEADER */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 pb-6 border-b border-white/15">
          <div>
            <div className="flex items-center gap-2 font-mono text-xs tracking-widest text-amber-300 font-bold uppercase mb-2">
              <Terminal className="w-4 h-4 text-amber-300" />
              <span>MORE THAN A WHOLESALER • BUSINESS TOOLS</span>
            </div>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase text-white font-sans">
              BUSINESS TERMINAL.
            </h2>
            <p className="text-slate-300 font-sans mt-2 max-w-xl text-base md:text-lg">
              Unlock our ultra-fast procurement environment. Designed for professional volume buyers who procure stock for a living.
            </p>
          </div>

          {/* Interactive Mode Tabs */}
          <div className="flex items-center bg-white/5 border border-white/15 font-mono text-xs uppercase font-bold p-1">
            <button
              onClick={() => setActiveTab("quick-order")}
              className={`px-5 py-2.5 transition-colors ${
                activeTab === "quick-order" ? "bg-amber-400 text-[#0B1B36]" : "text-slate-300 hover:text-white"
              }`}
            >
              QUICK ORDER TERMINAL
            </button>
            <button
              onClick={() => setActiveTab("saved-lists")}
              className={`px-5 py-2.5 transition-colors ${
                activeTab === "saved-lists" ? "bg-amber-400 text-[#0B1B36]" : "text-slate-300 hover:text-white"
              }`}
            >
              SAVED LISTS
            </button>
            <button
              onClick={() => setActiveTab("ledger")}
              className={`px-5 py-2.5 transition-colors ${
                activeTab === "ledger" ? "bg-amber-400 text-[#0B1B36]" : "text-slate-300 hover:text-white"
              }`}
            >
              THE TRADE LEDGER
            </button>
          </div>
        </div>

        {/* 1. QUICK ORDER TERMINAL WORKSPACE */}
        {activeTab === "quick-order" && (
          <div className="bg-white text-[#1A1F26] border-2 border-white overflow-hidden square-card">
            <div className="bg-slate-100 px-6 py-3 border-b-2 border-[#0B1B36] font-mono text-xs flex justify-between items-center text-slate-700">
              <span className="flex items-center gap-1.5 font-bold">
                <FileSpreadsheet className="w-4 h-4 text-[#0B1B36]" />
                RAPID INPUT ENTRY SHEET v1.4
              </span>
              <span>TYPE SKU OR BRAND • PRESS (+) FOR IMMEDIATE TERMINAL DESPATCH</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <th className="p-4 uppercase">SKU CODE</th>
                    <th className="p-4 uppercase">BRAND / PRODUCT DETAILS</th>
                    <th className="p-4 uppercase">AISLE</th>
                    <th className="p-4 uppercase text-center">PACK SIZE</th>
                    <th className="p-4 text-right uppercase">TRADE PRICE (EX VAT)</th>
                    <th className="p-4 text-center uppercase">LIVE STOCK</th>
                    <th className="p-4 text-center uppercase">ACTION</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {PRODUCTS.map((prod) => {
                    const isRowHighlighted = highlightedRow === prod.id;
                    const inCartItem = cart.find((item) => item.product.id === prod.id);
                    return (
                      <tr
                        key={prod.id}
                        className={`transition-colors border-b ${
                          isRowHighlighted
                            ? "bg-emerald-50 text-emerald-950 font-bold"
                            : "hover:bg-[#FAF8F3]"
                        }`}
                      >
                        <td className="p-4 font-bold text-slate-800">{prod.sku}</td>
                        <td className="p-4">
                          <span className="text-[10px] text-slate-400 uppercase tracking-widest block font-sans">
                            {prod.brand}
                          </span>
                          <span className="font-sans font-bold text-slate-900 block leading-tight">
                            {prod.name}
                          </span>
                        </td>
                        <td className="p-4 text-slate-500">{prod.aisle}</td>
                        <td className="p-4 text-center">
                          <span className="bg-slate-100 text-slate-700 font-bold px-2 py-0.5 border">
                            {prod.packSize}
                          </span>
                        </td>
                        <td className="p-4 text-right font-bold text-[#0B1B36]">
                          £{prod.priceExVat.toFixed(2)}
                        </td>
                        <td className="p-4 text-center text-slate-500">
                          {prod.availableStock > 100 ? (
                            <span className="text-emerald-600 font-bold">100+ CASES READY</span>
                          ) : (
                            <span className="text-amber-600 font-semibold">{prod.availableStock} CASES AVAIL</span>
                          )}
                        </td>
                        <td className="p-4 text-center">
                          {inCartItem ? (
                            <div className="inline-flex items-center bg-emerald-50 border border-emerald-500 text-emerald-800">
                              <button
                                onClick={() => updateQuantity(prod.id, inCartItem.quantity - 1)}
                                className="px-2 py-1 hover:bg-emerald-100 font-bold"
                              >
                                -
                              </button>
                              <span className="px-2.5 font-bold text-xs">{inCartItem.quantity}</span>
                              <button
                                onClick={() => updateQuantity(prod.id, inCartItem.quantity + 1)}
                                className="px-2 py-1 hover:bg-emerald-100 font-bold"
                              >
                                +
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => handleTerminalAdd(prod.id)}
                              className="bg-[#0B1B36] hover:bg-[#0A5C36] text-white px-3 py-1.5 font-bold font-mono transition-colors uppercase"
                            >
                              + ADD ROW
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 2. SAVED GROCERY LISTS */}
        {activeTab === "saved-lists" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left lists select menu (4 columns) */}
            <div className="lg:col-span-4 space-y-3 font-mono text-xs">
              <span className="text-slate-400 uppercase tracking-widest block mb-2 font-bold text-[10px]">
                SAVED PROCUREMENT TAB LISTS:
              </span>
              {INITIAL_SAVED_LISTS.map((list) => {
                const isSelected = selectedListId === list.id;
                return (
                  <button
                    key={list.id}
                    onClick={() => setSelectedListId(list.id)}
                    className={`w-full text-left p-4 border-2 transition-all block relative ${
                      isSelected
                        ? "border-amber-400 bg-white/10"
                        : "border-white/15 hover:border-white/30 text-slate-300"
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <strong className="text-sm font-bold uppercase">{list.name}</strong>
                      <span className="bg-white/15 text-white px-2 py-0.5 text-[10px] font-bold">
                        {list.itemCount} LINES
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block font-sans">
                      {list.description}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Right List Detail & Instant Cart Injection (8 columns) */}
            <div className="lg:col-span-8 bg-white text-[#1A1F26] border-2 border-white p-6 md:p-8 square-card space-y-6">
              {(() => {
                const list = INITIAL_SAVED_LISTS.find((l) => l.id === selectedListId);
                if (!list) return null;
                return (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b pb-4">
                      <div>
                        <span className="font-mono text-xs text-slate-400 uppercase block">ACTIVE LIST SPECIFICATION</span>
                        <h3 className="text-xl font-sans font-black text-[#0B1B36] uppercase">
                          {list.name}
                        </h3>
                      </div>

                      <button
                        onClick={() => addListToCart(list.id)}
                        className="bg-[#0A5C36] hover:bg-emerald-700 text-white font-mono text-xs font-bold px-6 py-3 uppercase flex items-center gap-2"
                      >
                        <span>ADD ALL {list.itemCount} ITEMS TO CART</span>
                        <ArrowUpRight className="w-4 h-4 text-amber-300" />
                      </button>
                    </div>

                    <div className="space-y-3 font-mono text-xs">
                      {list.items.map((item) => {
                        const p = PRODUCTS.find((prod) => prod.id === item.productId);
                        if (!p) return null;
                        return (
                          <div key={p.id} className="p-3 bg-[#FAF8F3] border border-slate-200 flex justify-between items-center">
                            <div>
                              <strong className="text-slate-800 font-bold uppercase">{p.name}</strong>
                              <span className="block text-[10px] text-slate-400 mt-0.5">
                                SKU: {p.sku} | PACK: {p.packSize}
                              </span>
                            </div>
                            <div className="flex items-center gap-6">
                              <span>BASE COST: £{(p.priceExVat).toFixed(2)} ex VAT</span>
                              <span className="bg-[#0B1B36] text-white px-2.5 py-1 font-bold">
                                {item.quantity} CASE(S)
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </div>

          </div>
        )}

        {/* 3. THE TRADE LEDGER (ANNUAL PROCUREMENTS) */}
        {activeTab === "ledger" && (
          <div className="bg-white text-[#1A1F26] border-2 border-white p-6 md:p-8 square-card grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* LEDGER DETAILS CARD (4 columns) */}
            <div className="lg:col-span-4 space-y-6">
              <div className="border-b pb-4">
                <span className="font-mono text-xs text-slate-500 uppercase block">CROWN & CART OFFICIAL LEDGER</span>
                <h3 className="text-2xl font-black text-[#0B1B36] uppercase font-sans mt-1">
                  THE GREEN DRAGON
                </h3>
                <span className="font-mono text-xs text-slate-500 block">ACCOUNT: {account.accountNumber}</span>
              </div>

              <div className="space-y-4 font-mono text-xs text-slate-600">
                <div className="flex justify-between border-b pb-2">
                  <span>MONTHLY PROCUREMENT SPEND:</span>
                  <strong className="text-[#0B1B36] text-sm">£18,420.00</strong>
                </div>
                <div className="flex justify-between border-b pb-2">
                  <span>ANNUAL COMPREHENSIVE SAVINGS:</span>
                  <strong className="text-emerald-600 text-sm">£1,284.00 SAVED</strong>
                </div>
                <div className="flex justify-between">
                  <span>AUTHORIZED LINE LIMIT CREDIT:</span>
                  <strong className="text-[#0B1B36]">£25,000.00 EX VAT APPROVED</strong>
                </div>
              </div>

              <p className="text-slate-600 font-sans text-xs leading-relaxed">
                Ledger statement verified in compliance with HM Revenue & Customs (HMRC) standard ex-VAT billing guidelines.
              </p>
            </div>

            {/* INTERACTIVE MONTHLY BAR CHART VISUALIZATION (8 columns) */}
            <div className="lg:col-span-8 border-2 border-[#0B1B36] p-6 bg-[#FAF8F3] font-mono text-xs space-y-6">
              <div className="flex items-center justify-between border-b pb-3 text-[#0B1B36] font-bold">
                <span>HISTORICAL SPEND BAR CHART DIAGRAM (EX VAT)</span>
                <span>OCT EST: £19,250.00</span>
              </div>

              {/* BAR CHART HEIGHTS BAR CONTAINER */}
              <div className="h-56 flex items-end justify-between gap-2.5 pt-4">
                {account.monthlySpendHistory.map((history) => {
                  const percentHeight = (history.spend / 20000) * 100;
                  return (
                    <div key={history.month} className="flex-1 flex flex-col items-center gap-2 group">
                      <span className="text-[9px] text-[#0B1B36] font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                        £{history.spend.toLocaleString()}
                      </span>
                      {/* BAR SURFACE */}
                      <div
                        className="w-full bg-[#0B1B36] hover:bg-[#0A5C36] transition-colors relative"
                        style={{ height: `${percentHeight}px` }}
                      >
                        <div className="absolute top-0 left-0 right-0 h-1 bg-amber-400" />
                      </div>
                      <span className="text-[10px] font-bold text-slate-600 block">
                        {history.month}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="text-[10px] text-slate-400 uppercase text-center border-t pt-3">
                CROWN & CART FINANCIAL ANALYTICS INFRASTRUCTURE
              </div>
            </div>

          </div>
        )}

      </div>
    </section>
  );
}
