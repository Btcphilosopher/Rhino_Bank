"use client";

import React, { useState, useEffect, useRef } from "react";
import { useStore } from "@/lib/store";
import { PRODUCTS, CATEGORIES } from "@/lib/data";
import { Search, X, Package, Tag, Compass, HelpCircle, ArrowRight } from "lucide-react";

export default function SearchOverlay() {
  const { isSearchOpen, setIsSearchOpen, searchQuery, setSearchQuery, setSelectedProductModal } = useStore();
  const [internalQuery, setInternalQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input automatically when search opens
  useEffect(() => {
    if (isSearchOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isSearchOpen]);

  // Handle shortcut listener '/' key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "/" && !isSearchOpen) {
        // Prevent default browser search behavior if any
        e.preventDefault();
        setIsSearchOpen(true);
      } else if (e.key === "Escape" && isSearchOpen) {
        setIsSearchOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isSearchOpen, setIsSearchOpen]);

  const filteredProducts = internalQuery
    ? PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(internalQuery.toLowerCase()) ||
          p.brand.toLowerCase().includes(internalQuery.toLowerCase()) ||
          p.sku.toLowerCase().includes(internalQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  const matchedCategories = internalQuery
    ? CATEGORIES.filter((c) => c.name.toLowerCase().includes(internalQuery.toLowerCase())).slice(0, 3)
    : [];

  const handleProductClick = (product: any) => {
    setSelectedProductModal(product);
    setIsSearchOpen(false);
  };

  const regulars = PRODUCTS.slice(0, 3);
  const recentSearches = ["Coca Cola Cans", "PG Tips 1100", "Vegetable Oil 20L"];

  if (!isSearchOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#071226]/95 backdrop-blur-md flex flex-col justify-start text-white p-6 md:p-12">
      
      {/* HEADER CONTROLS */}
      <div className="max-w-[1100px] mx-auto w-full flex justify-between items-center pb-6 border-b border-white/10 mb-8 font-mono text-xs text-slate-400">
        <span>CROWN & CART DIRECTORY LOOKUP ENGINE v2.6</span>
        <button
          onClick={() => setIsSearchOpen(false)}
          className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 border border-white/10 flex items-center gap-1.5"
        >
          <span>CLOSE</span>
          <kbd className="bg-white/10 text-[10px] px-1.5 py-0.5 rounded border border-white/10">ESC</kbd>
        </button>
      </div>

      {/* HUGE SEARCH BOX CONTAINER */}
      <div className="max-w-[1100px] mx-auto w-full space-y-8">
        <div className="space-y-3">
          <label className="font-mono text-xs text-emerald-400 font-bold uppercase tracking-widest block">
            TRADE SEARCH INDEX
          </label>
          <h2 className="text-3xl md:text-5xl font-black uppercase text-white font-sans tracking-tight">
            WHAT ARE YOU LOOKING FOR?
          </h2>
        </div>

        {/* INPUT INPUT BOX */}
        <div className="relative">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-400" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Type Brand name, Aisle number, or SKU code (e.g. CC-330-24)..."
            value={internalQuery}
            onChange={(e) => setInternalQuery(e.target.value)}
            className="w-full bg-white/5 border-2 border-white/20 pl-16 pr-10 py-5 font-sans text-lg md:text-2xl focus:outline-none focus:border-white transition-all square-card"
          />
          {internalQuery && (
            <button
              onClick={() => setInternalQuery("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/10 p-1.5 text-white hover:bg-white/20 rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* LOOKUP RESULTS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 pt-4">
          
          {/* Left search results (8 columns) */}
          <div className="lg:col-span-8 space-y-6">
            {internalQuery ? (
              <div className="space-y-4">
                <span className="font-mono text-xs text-slate-400 uppercase tracking-widest block font-bold mb-2">
                  MATCHING DIRECTORY LINES ({filteredProducts.length} FOUND):
                </span>

                <div className="space-y-3 font-mono text-xs">
                  {filteredProducts.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => handleProductClick(p)}
                      className="p-4 bg-white/5 border border-white/10 hover:border-emerald-400 hover:bg-white/10 transition-all flex justify-between items-center cursor-pointer"
                    >
                      <div className="flex items-center gap-4">
                        <Package className="w-5 h-5 text-emerald-400" />
                        <div>
                          <strong className="text-sm font-bold block text-white">{p.name}</strong>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                            SKU: {p.sku} | BRAND: {p.brand} | AISLE: {p.aisle}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <strong className="text-sm font-bold text-emerald-400 block">
                          £{p.priceExVat.toFixed(2)}
                        </strong>
                        <span className="text-[9px] text-slate-400">ex VAT</span>
                      </div>
                    </div>
                  ))}

                  {matchedCategories.map((c) => (
                    <div
                      key={c.id}
                      className="p-4 bg-white/5 border border-white/10 flex justify-between items-center cursor-pointer text-slate-300"
                    >
                      <div className="flex items-center gap-4">
                        <Compass className="w-5 h-5 text-emerald-400" />
                        <div>
                          <strong className="text-sm font-bold block text-white">{c.name}</strong>
                          <span className="text-[10px] text-slate-400 font-sans block">{c.itemCount} Lines Listed</span>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-400" />
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-6 font-mono text-xs text-slate-400">
                <div>
                  <span className="text-slate-500 uppercase tracking-widest block font-bold text-[10px] mb-3">
                    RECENT DISPATCH QUERIES:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {recentSearches.map((term) => (
                      <button
                        key={term}
                        onClick={() => setInternalQuery(term)}
                        className="bg-white/5 hover:bg-white/10 text-white border border-white/10 px-3.5 py-1.5 transition-colors"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 uppercase tracking-widest block font-bold text-[10px] mb-3">
                    YOUR REGULAR PURCHASES:
                  </span>
                  <div className="space-y-2">
                    {regulars.map((p) => (
                      <div
                        key={p.id}
                        onClick={() => handleProductClick(p)}
                        className="p-3 bg-white/5 border border-white/10 hover:bg-white/10 transition-colors flex justify-between items-center cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <Package className="w-4 h-4 text-slate-400" />
                          <span>{p.name} ({p.packSize})</span>
                        </div>
                        <span className="text-emerald-400">£{p.priceExVat.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right auxiliary lookup guide (4 columns) */}
          <div className="lg:col-span-4 bg-white/5 border border-white/10 p-6 md:p-8 space-y-4 font-mono text-xs">
            <span className="text-emerald-400 uppercase tracking-widest text-[10px] font-bold block border-b border-white/10 pb-2">
              HOW TO USE DIRECTORY LOOKUP
            </span>
            <div className="space-y-3.5 text-slate-300 leading-relaxed font-sans">
              <p>
                <strong>MISSPELINGS OKAY:</strong> Our lookup engine dynamically audits fuzzy queries and misspellings instantly.
              </p>
              <p>
                <strong>BARCODE ENTRY:</strong> Enter full barcode string numbers or internal SKUs to identify physical shelf assignments.
              </p>
              <p>
                <strong>SHORTCUTS:</strong> Press <kbd className="bg-white/10 px-1 border border-white/20">ESC</kbd> to dismiss this overlay. Press <kbd className="bg-white/10 px-1 border border-white/20">/</kbd> from standard view to open.
              </p>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
