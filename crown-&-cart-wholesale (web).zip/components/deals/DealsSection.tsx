"use client";

import React from "react";
import { useStore } from "@/lib/store";
import { PRODUCTS } from "@/lib/data";
import { ArrowRight, Tag, Percent, Flame, BadgeAlert, Coins } from "lucide-react";

export default function DealsSection() {
  const { addToCart, setSelectedProductModal } = useStore();

  // Find products that are featured or have deal tags
  const dealProducts = PRODUCTS.filter((p) => p.featured || p.dealTag);

  const campaignDeals = [
    {
      title: "BUY MORE. PAY LESS.",
      tagline: "BULK PALLET DISCOUNTS AVAILABLE ONLINE NOW",
      desc: "Save up to 18% on essential high volume beverage & ambient culinary ingredients when purchasing by the pallet tier.",
      bgImage: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?q=80&w=1200&auto=format&fit=crop",
      badge: "SEASONAL BULK",
      productId: "prod-001",
    },
    {
      title: "PROFIT DRIVERS.",
      tagline: "OPTIMIZE YOUR OUTLET'S GP MARGIN",
      desc: "Carefully curated high retail yield products selected by our retail analyst team to maximize your back-of-house margin.",
      bgImage: "https://images.unsplash.com/photo-1556910103-1c02745aae4d?q=80&w=1200&auto=format&fit=crop",
      badge: "HIGH MARGIN",
      productId: "prod-004",
    },
  ];

  return (
    <section id="deals-section" className="py-16 md:py-24 bg-[#0B1B36] text-white border-b border-black">
      <div className="max-w-[1360px] mx-auto px-4 md:px-8">
        
        {/* SECTION HEADER */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 pb-6 border-b border-white/15">
          <div>
            <div className="flex items-center gap-2 font-mono text-xs tracking-widest text-emerald-400 font-bold uppercase mb-2">
              <Tag className="w-4 h-4 text-emerald-400" />
              <span>WHOLESALE CAMPAIGN ART DIRECTION</span>
            </div>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase text-white font-sans">
              TRADE DEALS & OFFERS.
            </h2>
            <p className="text-slate-300 font-sans mt-2 max-w-xl text-base md:text-lg">
              No paper coupons. No gimmicks. Raw volume economics tailored for British commercial business purchasers.
            </p>
          </div>
        </div>

        {/* CAMPAIGN EDITORIAL BILLBOARDS */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {campaignDeals.map((deal) => (
            <div
              key={deal.title}
              className="relative min-h-[420px] border-2 border-white/20 p-8 flex flex-col justify-between group overflow-hidden bg-cover bg-center"
              style={{
                backgroundImage: `linear-gradient(to right, rgba(7, 18, 38, 0.95), rgba(7, 18, 38, 0.7)), url('${deal.bgImage}')`,
              }}
            >
              {/* Top info and tag */}
              <div className="flex items-center justify-between font-mono text-xs">
                <span className="bg-[#C82A2A] text-white px-2.5 py-0.5 font-bold tracking-widest uppercase">
                  {deal.badge}
                </span>
                <span className="text-slate-400">VALID UNTIL: 15 OCT 2026</span>
              </div>

              {/* Main typography */}
              <div className="space-y-3 z-10 max-w-lg">
                <span className="font-mono text-xs text-emerald-400 font-bold tracking-widest block">
                  {deal.tagline}
                </span>
                <h3 className="text-3xl md:text-5xl font-black tracking-tighter uppercase text-white leading-[0.9] font-sans">
                  {deal.title}
                </h3>
                <p className="text-slate-300 text-sm md:text-base font-sans font-light leading-relaxed">
                  {deal.desc}
                </p>
              </div>

              {/* Action */}
              <div className="pt-4 border-t border-white/10 z-10 flex items-center justify-between">
                <span className="font-mono text-[10px] text-slate-400">
                  CROWN & CART WHOLESALE SYSTEM
                </span>
                <button
                  onClick={() => {
                    const p = PRODUCTS.find((p) => p.id === deal.productId);
                    if (p) setSelectedProductModal(p);
                  }}
                  className="bg-white text-[#0B1B36] hover:bg-emerald-400 hover:text-[#0B1B36] font-mono text-xs font-bold px-6 py-3 uppercase flex items-center gap-2 transition-all"
                >
                  <span>ANALYSE MARGINS</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* DEAL PRODUCTS DENSE GRID */}
        <div className="border border-white/10 bg-[#071226]/85 p-6 md:p-8">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-white/10 font-mono text-xs tracking-wider">
            <span className="text-slate-400">ACTIVE PROMOTIONAL CODES (APPLIED AT TIER THRESHOLDS)</span>
            <span className="text-emerald-400 font-semibold">ALL PRODUCTS TAX COMPLIANT WITH UK STANDARDS</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {dealProducts.map((p) => (
              <div
                key={p.id}
                className="bg-[#0B1B36] border border-white/15 p-4 flex flex-col justify-between hover:border-emerald-500 transition-colors"
              >
                <div className="flex items-center justify-between font-mono text-[10px] text-slate-400 mb-2">
                  <span>SKU: {p.sku}</span>
                  <span className="text-emerald-400 font-bold">{p.dealTag || "DEAL"}</span>
                </div>

                <div className="h-32 bg-white/5 border border-white/10 flex items-center justify-center p-2">
                  <img src={p.imageUrl} alt="" className="h-full object-contain mix-blend-screen" />
                </div>

                <div className="mt-3 space-y-1">
                  <span className="font-mono text-[9px] text-slate-400 uppercase tracking-widest block">
                    {p.brand}
                  </span>
                  <h4 className="font-sans font-bold text-sm text-white leading-tight line-clamp-2">
                    {p.name}
                  </h4>
                  <span className="font-mono text-[11px] text-slate-300 block">
                    PACK: {p.packSize}
                  </span>
                </div>

                <div className="pt-3 mt-3 border-t border-white/10 flex items-end justify-between font-mono">
                  <div>
                    <span className="text-slate-400 text-[9px] block">PROMO BASE RATE</span>
                    <span className="text-lg font-bold text-emerald-400 block">
                      £{p.priceExVat.toFixed(2)} <span className="text-[9px] text-slate-400 font-normal">EX VAT</span>
                    </span>
                  </div>

                  <button
                    onClick={() => addToCart(p, 1)}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold py-1.5 px-3 uppercase transition-colors"
                  >
                    + ADD
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
