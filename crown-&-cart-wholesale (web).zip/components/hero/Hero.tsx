"use client";

import React, { useState, useEffect } from "react";
import { ArrowUpRight, MapPin, Package, ShieldCheck, Truck, Layers } from "lucide-react";

export default function Hero() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative bg-[#071226] text-white overflow-hidden min-h-[85vh] md:min-h-[90vh] flex flex-col justify-between border-b border-slate-800">
      {/* BACKGROUND WAREHOUSE PHOTOGRAPHY WITH PARALLAX */}
      <div
        className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-75 ease-out opacity-45 mix-blend-luminosity grayscale contrast-125"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?q=80&w=2000&auto=format&fit=crop')`,
          transform: `translateY(${scrollY * 0.12}px) scale(1.05)`,
        }}
      />

      {/* GRADIENT OVERLAY */}
      <div className="absolute inset-0 z-0 bg-gradient-to-r from-[#071226] via-[#071226]/85 to-transparent" />
      <div className="absolute inset-0 z-0 bg-gradient-to-t from-[#071226] via-transparent to-black/30" />

      {/* TOP DECORATIVE INDUSTRIAL METADATA */}
      <div className="relative z-10 max-w-[1360px] mx-auto w-full px-4 md:px-8 pt-8 md:pt-12">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/15 pb-4 font-mono text-xs tracking-widest text-slate-300 uppercase">
          <div className="flex items-center gap-3">
            <span className="bg-[#0A5C36] text-white px-2 py-0.5 font-bold text-[10px]">
              TRADE WHOLESALE
            </span>
            <span className="text-slate-400">NATIONAL LOGISTICS INFRASTRUCTURE</span>
          </div>
          <div className="hidden sm:flex items-center gap-6 text-[11px] text-slate-300">
            <span>2026 CATALOGUE</span>
            <span>•</span>
            <span>DELIVERED / COLLECT</span>
            <span>•</span>
            <span className="text-amber-400 font-bold">LIVE DEPOT STOCK</span>
          </div>
        </div>
      </div>

      {/* HERO MAIN CONTENT */}
      <div className="relative z-10 max-w-[1360px] mx-auto w-full px-4 md:px-8 py-12 md:py-20 flex flex-col lg:flex-row lg:items-end justify-between gap-12">
        {/* Left Column: Huge Anglo-Futurist Headlines */}
        <div className="max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 backdrop-blur-md px-3 py-1 text-xs font-mono text-slate-200">
            <Layers className="w-3.5 h-3.5 text-amber-300" />
            <span>ANGLO-FUTURIST WHOLESALE DISTRIBUTION</span>
          </div>

          <h1 className="text-5xl sm:text-7xl md:text-8xl font-black tracking-tighter uppercase leading-[0.88] text-white font-sans">
            BUY BETTER.<br />
            STOCK FASTER.<br />
            <span className="text-slate-400 font-light">RUN YOUR</span><br />
            BUSINESS.
          </h1>

          <p className="text-lg md:text-xl text-slate-300 max-w-xl font-sans font-light leading-relaxed">
            Thousands of products. Trade pricing. Live inventory. Next-day delivery or 15-minute depot collection across Great Britain.
          </p>

          {/* Action CTAs */}
          <div className="pt-2 flex flex-wrap items-center gap-4 font-mono text-xs uppercase font-bold">
            <button
              onClick={() => scrollToSection("catalogue-section")}
              className="bg-white text-[#0B1B36] hover:bg-[#F5F2EA] px-8 py-4 flex items-center gap-3 border border-white transition-all group"
            >
              <span>SHOP WHOLESALE</span>
              <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </button>

            <button
              onClick={() => scrollToSection("depot-section")}
              className="bg-transparent text-white hover:bg-white/10 px-8 py-4 flex items-center gap-3 border border-white/30 transition-all"
            >
              <MapPin className="w-4 h-4 text-emerald-400" />
              <span>FIND A DEPOT</span>
            </button>

            <button
              onClick={() => scrollToSection("digital-depot-section")}
              className="hidden md:flex items-center gap-2 text-amber-300 hover:text-white px-4 py-4 transition-colors"
            >
              <span>EXPLORE DIGITAL DEPOT ↓</span>
            </button>
          </div>
        </div>

        {/* Right Column: Live Infrastructure Status Card */}
        <div className="bg-[#0B1B36]/90 border border-white/20 backdrop-blur-md p-6 max-w-md w-full space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <span className="text-slate-400 uppercase tracking-widest text-[10px]">DEPOT NETWORK STATUS</span>
            <span className="inline-flex items-center gap-1.5 text-emerald-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              70 DEPOTS ONLINE
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4 text-slate-200">
            <div className="border border-white/10 p-3 bg-white/5">
              <span className="text-[10px] text-slate-400 block">LONDON WEST</span>
              <span className="text-base font-bold text-white block mt-0.5">OPEN NOW</span>
              <span className="text-[10px] text-emerald-400 block mt-1">94% Stock Available</span>
            </div>
            <div className="border border-white/10 p-3 bg-white/5">
              <span className="text-[10px] text-slate-400 block">NEXT DELIVERY</span>
              <span className="text-base font-bold text-amber-300 block mt-0.5">TODAY 14:00</span>
              <span className="text-[10px] text-slate-300 block mt-1">Route LON-W-07</span>
            </div>
          </div>

          <div className="text-[11px] text-slate-300 flex items-center justify-between pt-1">
            <span className="text-slate-400">Avg. Order Turnover:</span>
            <span className="font-bold text-white">£1,284.20 ex VAT</span>
          </div>
        </div>
      </div>

      {/* METRICS RULE BANNER */}
      <div className="relative z-10 bg-[#0A5C36] text-white py-3 border-t border-emerald-500 font-mono text-xs tracking-wider uppercase font-semibold">
        <div className="max-w-[1360px] mx-auto px-4 md:px-8 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Truck className="w-4 h-4 text-amber-300" />
            <span>NATIONAL WHOLESALE NETWORK</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-[11px]">
            <span>70+ CASH & CARRY DEPOTS</span>
            <span>•</span>
            <span>12,000+ TRADE LINES</span>
            <span>•</span>
            <span>SCHEDULED FLEET DELIVERY</span>
            <span>•</span>
            <span>BULK PALLET TIERS</span>
          </div>
          <div className="text-right">
            <span className="text-amber-300 font-bold">EX VAT TRANSPARENCY</span>
          </div>
        </div>
      </div>
    </section>
  );
}
