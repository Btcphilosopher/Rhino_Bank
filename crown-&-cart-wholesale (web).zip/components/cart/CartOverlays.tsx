"use client";

import React, { useState } from "react";
import { useStore } from "@/lib/store";
import { X, Trash2, ShieldCheck, ShoppingBag, CreditCard, Award, HelpCircle, Truck, FileText } from "lucide-react";

export default function CartOverlays() {
  const {
    account,
    cart,
    updateQuantity,
    removeFromCart,
    clearCart,
    cartTotalExVat,
    cartTotalIncVat,
    cartTotalSavings,
    cartItemCount,
    isCartOpen,
    setIsCartOpen,
    isCheckoutOpen,
    setIsCheckoutOpen,
    isTradeRegisterOpen,
    setIsTradeRegisterOpen,
    addOrder,
    orders,
  } = useStore();

  // Trade Register state
  const [regCompanyName, setRegCompanyName] = useState("");
  const [regVatNumber, setRegVatNumber] = useState("");
  const [regCreditRequest, setRegCreditRequest] = useState("5000");
  const [regRegistered, setRegRegistered] = useState(false);

  // Simulated Order Successful placement state
  const [orderPlacedId, setOrderPlacedId] = useState<string | null>(null);

  const handlePlaceOrder = () => {
    const newOrderId = `CC-${Math.floor(100000 + Math.random() * 900000)}`;
    const newOrder = {
      id: newOrderId,
      date: "25 SEPT 2026",
      status: "ORDER RECEIVED" as const,
      itemsCount: cartItemCount,
      totalExVat: cartTotalExVat,
      totalIncVat: cartTotalIncVat,
      savings: cartTotalSavings,
      depotName: "LONDON WEST DEPOT",
      deliveryAddress: account.deliveryAddress || "The Green Dragon, Richmond",
      estimatedDelivery: "TOMORROW 10:00 - 12:00",
      trackingStepIndex: 0,
    };
    
    addOrder(newOrder);
    setOrderPlacedId(newOrderId);
    clearCart();
    setIsCheckoutOpen(false);
  };

  const handleRegisterTrade = (e: React.FormEvent) => {
    e.preventDefault();
    setRegRegistered(true);
    setTimeout(() => {
      setIsTradeRegisterOpen(false);
      setRegRegistered(false);
    }, 1500);
  };

  return (
    <>
      {/* 1. RIGHT SIDE BAGGAGE CART DRAWER */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-[#071226]/80 backdrop-blur-sm flex justify-end">
          {/* Overlay dismissal zone */}
          <div className="flex-1" onClick={() => setIsCartOpen(false)} />

          <div className="bg-[#FAF8F3] max-w-lg w-full h-full border-l-2 border-[#0B1B36] flex flex-col justify-between p-6 md:p-8 relative shadow-2xl animate-fade-up">
            
            <div className="space-y-6 flex-1 overflow-y-auto pr-2">
              <div className="flex justify-between items-center border-b pb-4">
                <div className="flex items-center gap-2 text-[#0B1B36]">
                  <ShoppingBag className="w-5 h-5" />
                  <h3 className="text-xl font-sans font-black uppercase tracking-tight">
                    TRADE BASKET
                  </h3>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="bg-slate-100 p-2 hover:bg-slate-200 text-[#0B1B36]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Cart Items List */}
              {cart.length > 0 ? (
                <div className="space-y-4">
                  {cart.map((item) => {
                    const vatAmount = item.appliedUnitPrice * item.quantity * item.product.vatRate;
                    return (
                      <div
                        key={item.product.id}
                        className="bg-white border-2 border-[#0B1B36] p-4 flex gap-4 justify-between items-start font-mono text-xs"
                      >
                        <div className="w-12 h-12 bg-white p-1 border flex items-center justify-center shrink-0">
                          <img src={item.product.imageUrl} alt="" className="h-full object-contain" />
                        </div>

                        <div className="flex-1 space-y-1">
                          <strong className="text-[#0B1B36] font-bold uppercase leading-tight font-sans line-clamp-1">
                            {item.product.name}
                          </strong>
                          <span className="text-[10px] text-slate-500 block">
                            SKU: {item.product.sku} | PACK: {item.product.packSize}
                          </span>
                          <span className="text-emerald-700 font-bold block">
                            £{item.appliedUnitPrice.toFixed(2)} ex VAT <span className="text-[9px] text-slate-400 font-normal">({item.product.unitType})</span>
                          </span>
                        </div>

                        <div className="flex flex-col items-end gap-2 shrink-0">
                          <div className="flex items-center bg-slate-100 border">
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                              className="px-2 py-0.5 hover:bg-slate-200"
                            >
                              -
                            </button>
                            <span className="px-2 font-bold">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                              className="px-2 py-0.5 hover:bg-slate-200"
                            >
                              +
                            </button>
                          </div>
                          <button
                            onClick={() => removeFromCart(item.product.id)}
                            className="text-slate-400 hover:text-[#C82A2A]"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-16 font-mono text-xs text-slate-400 border border-dashed border-slate-300">
                  YOUR COMMERCE BASKET IS EMPTY
                </div>
              )}
            </div>

            {/* Cart Summary & CTA bottom */}
            {cart.length > 0 && (
              <div className="border-t border-slate-200 pt-6 space-y-4">
                <div className="bg-[#E6F4ED] text-[#0A5C36] p-3 font-mono text-xs font-bold text-center border border-[#0A5C36]">
                  YOU ARE SAVING £{cartTotalSavings.toFixed(2)} EX VAT AT CURRENT BULK TIER CODES
                </div>

                <div className="font-mono text-xs space-y-2 text-slate-700">
                  <div className="flex justify-between">
                    <span>NET EX VAT SUBTOTAL:</span>
                    <strong className="text-[#0B1B36] font-bold">£{cartTotalExVat.toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>ESTIMATED UK VAT CHARGE (20%):</span>
                    <strong className="text-slate-800">£{(cartTotalIncVat - cartTotalExVat).toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between text-sm border-t pt-2 border-slate-200 text-[#0B1B36] font-bold">
                    <span>COMPREHENSIVE TOTAL INC VAT:</span>
                    <span className="text-lg font-black text-[#0B1B36]">£{cartTotalIncVat.toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      setIsCheckoutOpen(true);
                    }}
                    className="flex-1 bg-[#0A5C36] hover:bg-emerald-700 text-white py-3.5 font-mono text-xs font-bold uppercase tracking-wider text-center"
                  >
                    PROCEED TO CHECKOUT
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* 2. CHECKOUT MODAL OVERLAY */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 bg-[#071226]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border-2 border-[#0B1B36] max-w-2xl w-full p-6 md:p-8 space-y-6 relative square-card">
            <button
              onClick={() => setIsCheckoutOpen(false)}
              className="absolute top-4 right-4 bg-slate-100 p-2 hover:bg-slate-200 text-[#0B1B36]"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="border-b pb-4">
              <span className="font-mono text-xs text-[#0A5C36] font-bold uppercase block mb-1">
                SECURE CHECKOUT TERMINAL
              </span>
              <h3 className="text-2xl font-black text-[#0B1B36] uppercase font-sans">
                CONFIRM COMMERCIAL INVOICE
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
              <div className="space-y-4">
                <span className="text-slate-400 block font-bold text-[10px] tracking-wider uppercase">DELIVERY LOGISTICS INFO:</span>
                <div className="space-y-1 text-slate-700 font-sans">
                  <strong className="text-[#0B1B36] font-semibold block uppercase">RECIPIENT ACCOUNT:</strong>
                  <span className="block text-xs">{account.companyName}</span>
                  <span className="block text-xs text-slate-500 mt-1">148 High Street, Richmond, TW9 1YB</span>
                </div>

                <div className="space-y-1 text-slate-700 font-sans">
                  <strong className="text-[#0B1B36] font-semibold block uppercase font-mono text-xs">CREDIT TERMS:</strong>
                  <span className="block text-xs">30-DAY INVOICE ACCOUNT AUTHORIZED</span>
                  <span className="block text-[11px] text-emerald-600 font-bold font-mono">AVAILABLE LIMIT: £{(account.creditLimit - account.creditUsed).toLocaleString()}</span>
                </div>
              </div>

              <div className="space-y-4 bg-slate-50 p-4 border border-slate-200">
                <span className="text-slate-400 block font-bold text-[10px] tracking-wider uppercase">COST RECONCILIATION:</span>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>NET CHARGE EX VAT:</span>
                    <strong className="text-slate-800">£{cartTotalExVat.toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>TAX CHARGES:</span>
                    <strong className="text-slate-800">£{(cartTotalIncVat - cartTotalExVat).toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between font-bold text-[#0A5C36]">
                    <span>LEDGER SAVINGS:</span>
                    <strong>-£{cartTotalSavings.toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between font-bold text-sm border-t pt-2 border-slate-300 text-[#0B1B36]">
                    <span>TOTAL COMPREHENSIVE:</span>
                    <strong className="text-base text-[#0B1B36]">£{cartTotalIncVat.toFixed(2)}</strong>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t flex justify-end gap-3 font-mono text-xs">
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="bg-slate-100 hover:bg-slate-200 text-[#0B1B36] px-5 py-3 font-bold transition-colors uppercase"
              >
                BACK TO BASKET
              </button>
              <button
                onClick={handlePlaceOrder}
                className="bg-[#0A5C36] hover:bg-emerald-700 text-white px-8 py-3 font-bold transition-colors uppercase"
              >
                PLACE OFFICIAL TRADE ORDER
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. ORDER PLACED SUCCESS NOTIFICATION OVERLAY */}
      {orderPlacedId && (
        <div className="fixed inset-0 z-50 bg-[#071226]/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#FAF8F3] border-4 border-[#0A5C36] max-w-lg w-full p-8 text-center space-y-6 relative square-card">
            <div className="w-16 h-16 bg-[#E6F4ED] text-[#0A5C36] rounded-full flex items-center justify-center mx-auto border-2 border-[#0A5C36]">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className="font-mono text-xs text-[#0A5C36] font-bold uppercase block">
                INVOICE TRANSMISSION DESPATCHED
              </span>
              <h3 className="text-3xl font-black text-[#0B1B36] uppercase font-sans">
                ORDER SUCCESSFUL!
              </h3>
              <p className="text-slate-600 text-sm font-sans max-w-sm mx-auto leading-relaxed">
                Your order <strong className="text-[#0B1B36] font-mono">{orderPlacedId}</strong> has been logged in the Crown & Cart national logistic queues.
              </p>
            </div>

            <div className="bg-white border-2 border-slate-200 p-4 font-mono text-xs text-left text-slate-700 max-w-sm mx-auto">
              <div>• DESTINATION: <span className="font-bold text-[#0B1B36]">THE GREEN DRAGON RICHMOND</span></div>
              <div className="mt-1">• ROUTING DOCK: <span className="font-bold text-[#0B1B36]">LONDON WEST (TW8 9DN)</span></div>
              <div className="mt-1">• EST ARRIVAL: <span className="font-bold text-[#0A5C36]">TOMORROW 10:00 AM</span></div>
            </div>

            <button
              onClick={() => setOrderPlacedId(null)}
              className="bg-[#0B1B36] hover:bg-[#0A5C36] text-white px-8 py-3.5 font-mono text-xs font-bold uppercase w-full transition-colors"
            >
              RETURN TO TRADE TERMINAL
            </button>
          </div>
        </div>
      )}

      {/* 4. TRADE REGISTRATION & CREDIT REQUEST MODAL */}
      {isTradeRegisterOpen && (
        <div className="fixed inset-0 z-50 bg-[#071226]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleRegisterTrade}
            className="bg-white border-2 border-[#0B1B36] max-w-lg w-full p-6 md:p-8 space-y-6 relative square-card"
          >
            <button
              type="button"
              onClick={() => setIsTradeRegisterOpen(false)}
              className="absolute top-4 right-4 bg-slate-100 p-2 hover:bg-slate-200 text-[#0B1B36]"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="border-b pb-4">
              <span className="font-mono text-xs text-[#0A5C36] font-bold uppercase block mb-1">
                B2B REGISTER CREDENTIALS
              </span>
              <h3 className="text-2xl font-black text-[#0B1B36] uppercase font-sans">
                TRADE ACCOUNT RE-CREDIT
              </h3>
            </div>

            {regRegistered ? (
              <div className="text-center py-10 space-y-3 font-mono text-xs text-[#0A5C36] font-bold uppercase">
                <div className="w-10 h-10 bg-[#E6F4ED] rounded-full flex items-center justify-center mx-auto mb-2 border border-[#0A5C36]">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <span>SUBMITTING CREDIT LINE APPLICATION...</span>
                <span className="block text-slate-400 font-normal">Our underwriting desk is auditing credentials.</span>
              </div>
            ) : (
              <div className="space-y-4 font-mono text-xs">
                <div className="space-y-1.5">
                  <label className="text-slate-600 block uppercase font-bold text-[10px]">COMPANY BUSINESS NAME:</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. THE ROYAL OAK PUB"
                    value={regCompanyName}
                    onChange={(e) => setRegCompanyName(e.target.value)}
                    className="w-full bg-slate-50 border border-[#0B1B36] p-3 font-sans text-xs focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0B1B36] square-card"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-600 block uppercase font-bold text-[10px]">VERIFIED UK VAT ID NUMBER:</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. GB 123 4567 89"
                    value={regVatNumber}
                    onChange={(e) => setRegVatNumber(e.target.value)}
                    className="w-full bg-slate-50 border border-[#0B1B36] p-3 font-sans text-xs focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0B1B36] square-card"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-600 block uppercase font-bold text-[10px]">REQUESTED CREDIT CAPACITY LINE (£):</label>
                  <select
                    value={regCreditRequest}
                    onChange={(e) => setRegCreditRequest(e.target.value)}
                    className="w-full bg-slate-50 border border-[#0B1B36] p-3 font-sans text-xs focus:bg-white focus:outline-none square-card"
                  >
                    <option value="5000">£5,000 LIMIT (Instant Approval)</option>
                    <option value="15000">£15,000 LIMIT (Underwritten)</option>
                    <option value="50000">£50,000 LIMIT (Pallet Volume Audit)</option>
                  </select>
                </div>

                <p className="text-slate-500 font-sans text-[11px] leading-relaxed">
                  By submitting this application form, you authorize Crown & Cart Wholesale to perform commercial company credit references in compliance with UK B2B lending regulations.
                </p>

                <div className="pt-4 border-t flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsTradeRegisterOpen(false)}
                    className="bg-slate-100 hover:bg-slate-200 text-[#0B1B36] py-3 px-5 font-bold uppercase transition-colors"
                  >
                    CANCEL
                  </button>
                  <button
                    type="submit"
                    className="bg-[#0B1B36] hover:bg-[#0A5C36] text-white py-3 px-6 font-bold uppercase transition-colors"
                  >
                    SUBMIT APPLICATION
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      )}
    </>
  );
}
