"use client";

import React, { useState } from "react";
import { useStore } from "@/lib/store";
import { DEPOTS } from "@/lib/data";
import { Depot } from "@/lib/types";
import { Map, MapPin, Compass, Clock, CheckCircle2, ChevronRight, Phone, ShieldCheck, Mail, Building, X } from "lucide-react";

export default function DepotFinder() {
  const { selectedDepot, setSelectedDepot, selectedDepotModal, setSelectedDepotModal } = useStore();
  const [hoveredDepot, setHoveredDepot] = useState<Depot | null>(null);

  const handleSelectDepot = (depot: Depot) => {
    setSelectedDepot(depot);
    setSelectedDepotModal(depot);
  };

  return (
    <section id="depot-section" className="py-16 md:py-24 bg-[#F5F2EA] border-b border-[#1A1F26]/10">
      <div className="max-w-[1360px] mx-auto px-4 md:px-8">
        
        {/* SECTION HEADER */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 pb-6 border-b border-[#1A1F26]/15">
          <div>
            <div className="flex items-center gap-2 font-mono text-xs tracking-widest text-[#0A5C36] font-bold uppercase mb-2">
              <Compass className="w-4 h-4 text-[#0A5C36]" />
              <span>SIGNATURE VISUAL IDEA • EXPERIENCE 03</span>
            </div>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase text-[#0B1B36] font-sans">
              FIND YOUR DEPOT.
            </h2>
            <p className="text-slate-600 font-sans mt-2 max-w-xl text-base md:text-lg">
              Interact with our streamlined B2B logistical map of Great Britain. Select your preferred cash-and-carry hub.
            </p>
          </div>
        </div>

        {/* MAP & INFORMATION SIDE-BY-SIDE PANELS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT: Beautiful SVG Schematic Map of Britain (5 columns) */}
          <div className="lg:col-span-5 bg-[#0B1B36] border-2 border-[#0B1B36] p-6 relative aspect-[3/4] flex items-center justify-center overflow-hidden">
            {/* Outline decorative tech grid */}
            <div className="absolute inset-0 grid grid-cols-6 grid-rows-8 opacity-10 pointer-events-none">
              {Array.from({ length: 48 }).map((_, i) => (
                <div key={i} className="border border-white/40" />
              ))}
            </div>

            {/* Fictional Simplified Britain Landmass SVG outline */}
            <svg
              viewBox="0 0 100 100"
              className="absolute inset-0 w-full h-full p-4 pointer-events-none select-none opacity-20"
              fill="none"
              stroke="white"
              strokeWidth="0.5"
            >
              {/* Scotland & England land schematic */}
              <path
                d="M 40,5 C 38,10 32,15 35,20 C 37,23 48,22 46,26 C 42,28 35,24 38,32 C 40,35 48,34 50,38 C 55,42 50,48 54,48 C 58,48 64,44 64,32 C 64,30 68,36 72,40 C 76,44 80,55 84,66 C 88,72 80,78 74,78 C 65,78 58,74 48,79 C 42,79 40,75 44,77 C 48,82 46,88 50,95 C 48,97 32,95 28,90 C 24,85 28,78 30,72 C 32,68 28,64 26,60 C 24,56 22,48 26,41 C 28,38 34,40 38,35 C 39,25 35,18 40,5 Z"
                className="stroke-white"
                strokeWidth="1"
              />
              {/* Wales land schematic */}
              <path
                d="M 42,70 C 40,73 38,75 40,78 C 42,80 46,78 48,79 C 46,76 44,72 42,70 Z"
                className="stroke-emerald-400"
                strokeWidth="0.8"
              />
            </svg>

            {/* Connecting Logistic Lines (British Rail style schematic representation) */}
            <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full p-4 pointer-events-none">
              {/* Line network linking major depots */}
              <polyline
                points="42,28 54,48 58,64 74,78 48,79"
                fill="none"
                stroke="rgba(16, 185, 129, 0.4)"
                strokeWidth="0.75"
                strokeDasharray="2,2"
              />
              <polyline
                points="62,44 54,48 64,32"
                fill="none"
                stroke="rgba(16, 185, 129, 0.4)"
                strokeWidth="0.75"
                strokeDasharray="2,2"
              />
              <polyline
                points="58,64 77,69"
                fill="none"
                stroke="rgba(16, 185, 129, 0.4)"
                strokeWidth="0.75"
                strokeDasharray="2,2"
              />
            </svg>

            {/* Depot interactive point markers */}
            {DEPOTS.map((depot) => {
              const isSelected = selectedDepot.id === depot.id;
              const isHovered = hoveredDepot?.id === depot.id;
              return (
                <button
                  key={depot.id}
                  onClick={() => handleSelectDepot(depot)}
                  onMouseEnter={() => setHoveredDepot(depot)}
                  onMouseLeave={() => setHoveredDepot(null)}
                  className="absolute group z-10 transition-transform hover:scale-125 focus:outline-none"
                  style={{ left: `${depot.coordinates.x}%`, top: `${depot.coordinates.y}%` }}
                >
                  <span className="relative flex h-4 w-4 items-center justify-center">
                    {isSelected && (
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    )}
                    <span
                      className={`relative inline-flex rounded-full h-2.5 w-2.5 border border-white ${
                        isSelected ? "bg-emerald-400" : "bg-white hover:bg-emerald-400"
                      }`}
                    />
                  </span>

                  {/* Tiny Hover tooltip */}
                  {(isHovered || isSelected) && (
                    <div className="absolute left-1/2 -translate-x-1/2 bottom-5 bg-[#0B1B36] border border-white/20 text-white text-[9px] px-2 py-1 font-mono tracking-wider uppercase whitespace-nowrap z-30">
                      {depot.city} • {depot.stockCapacityPercent}% STOCK
                    </div>
                  )}
                </button>
              );
            })}

            {/* Map metadata tags overlay */}
            <div className="absolute bottom-4 left-4 font-mono text-[9px] text-slate-400 uppercase tracking-widest space-y-1">
              <span>CROWN & CART GIS NETWORK v2.6</span>
              <span>GRID MERCATOR REF. UK-0012</span>
            </div>
          </div>

          {/* RIGHT: Detailed Listing & Panel display (7 columns) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* ACTIVE SELECTED DEPOT PANEL CARD */}
            <div className="bg-white border-2 border-[#0B1B36] p-6 md:p-8 square-card relative space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
                <div>
                  <span className="font-mono text-xs text-slate-500 uppercase tracking-widest block">
                    CURRENT PREFERRED COLLECTION POINT
                  </span>
                  <h3 className="text-2xl md:text-3xl font-black text-[#0B1B36] uppercase tracking-tight">
                    {selectedDepot.name}
                  </h3>
                  <span className="font-mono text-xs text-emerald-600 font-bold block mt-1">
                    STATUS: {selectedDepot.status} NOW • CAPACITY {selectedDepot.stockCapacityPercent}%
                  </span>
                </div>

                <div className="bg-[#E6F4ED] text-[#0A5C36] px-4 py-2 font-mono text-xs font-bold border border-[#0A5C36] text-center">
                  COLLECTION SLOT READY
                </div>
              </div>

              {/* Grid details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Contact and address */}
                <div className="space-y-3 font-sans text-sm">
                  <div className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-slate-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-[#0B1B36] font-semibold block">DEPOT STREET ADDRESS:</strong>
                      <span className="text-slate-600 text-xs block leading-relaxed mt-0.5">
                        {selectedDepot.address}, {selectedDepot.postcode}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <Clock className="w-4 h-4 text-slate-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-[#0B1B36] font-semibold block">OPENING HOURS:</strong>
                      <span className="text-slate-600 text-xs block leading-relaxed mt-0.5">
                        {selectedDepot.openingHours}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <Building className="w-4 h-4 text-slate-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-[#0B1B36] font-semibold block">DEPOT GENERAL MANAGER:</strong>
                      <span className="text-slate-600 text-xs block leading-relaxed mt-0.5 font-mono">
                        {selectedDepot.manager}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Services & Today's Slots */}
                <div className="space-y-4 font-mono text-xs">
                  <div>
                    <span className="text-slate-400 block uppercase font-bold text-[10px] tracking-wider mb-1.5">
                      AUTHORIZED ON-SITE SERVICES:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedDepot.services.map((serv) => (
                        <span key={serv} className="bg-slate-100 text-[#0B1B36] border border-slate-200 px-2.5 py-1 text-[10px] font-semibold">
                          {serv}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-400 block uppercase font-bold text-[10px] tracking-wider mb-1.5">
                      AVAILABLE COURIER SLOTS (TODAY):
                    </span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {selectedDepot.todayCollectionSlots.map((slot) => (
                        <span key={slot} className="border border-[#0B1B36] text-[#0B1B36] p-1.5 text-center text-[10px] font-bold">
                          {slot}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

              </div>

              {/* Map Action Confirm */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between font-mono text-xs text-slate-500">
                <span>DEPOT DIRECT TELEPHONE: <strong className="text-[#0B1B36]">{selectedDepot.phone}</strong></span>
                <span className="bg-[#0B1B36] text-white px-3 py-1 font-bold text-[10px]">ACTIVE CACHING ROUTE</span>
              </div>
            </div>

            {/* DEPOTS LIST TABLE */}
            <div className="bg-white border border-slate-300 overflow-hidden font-sans">
              <div className="bg-[#0B1B36] text-white px-4 py-3 font-mono text-xs uppercase font-bold tracking-wider">
                NATIONAL CASH & CARRY LOCATIONS DIRECTORY
              </div>
              <div className="divide-y divide-slate-200 max-h-[220px] overflow-y-auto">
                {DEPOTS.map((dep) => {
                  const isActive = selectedDepot.id === dep.id;
                  return (
                    <div
                      key={dep.id}
                      onClick={() => handleSelectDepot(dep)}
                      className={`p-3.5 flex items-center justify-between gap-4 cursor-pointer hover:bg-[#FAF8F3] transition-colors ${
                        isActive ? "bg-[#E6F4ED]" : ""
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <MapPin className={`w-4 h-4 ${isActive ? "text-[#0A5C36]" : "text-slate-400"}`} />
                        <div>
                          <strong className="text-sm text-[#0B1B36] block font-semibold">{dep.name}</strong>
                          <span className="text-xs text-slate-500 font-mono">{dep.region}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 font-mono text-xs">
                        <span className="text-slate-500 uppercase text-[10px]">{dep.postcode}</span>
                        <span className={`px-2 py-0.5 text-[10px] font-bold ${isActive ? "bg-[#0A5C36] text-white" : "bg-slate-100 text-slate-700"}`}>
                          {isActive ? "SELECTED" : "SELECT"}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

        </div>

        {/* DEPOT DETAIL MODAL TRIGGERED OVERLAY */}
        {selectedDepotModal && (
          <div className="fixed inset-0 z-50 bg-[#071226]/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white border-2 border-[#0B1B36] max-w-lg w-full p-6 space-y-6 relative square-card">
              <button
                onClick={() => setSelectedDepotModal(null)}
                className="absolute top-4 right-4 bg-slate-100 hover:bg-slate-200 text-[#0B1B36] p-2 transition-colors border border-slate-200"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="border-b pb-4">
                <span className="font-mono text-xs text-[#0A5C36] font-bold uppercase block mb-1">
                  OFFICIAL INVENTORY CERTIFICATION
                </span>
                <h3 className="text-2xl font-black text-[#0B1B36] uppercase tracking-tight">
                  {selectedDepotModal.name}
                </h3>
                <span className="font-mono text-xs text-slate-500 block">
                  NETWORK PATHWAY: CC-DEP-{selectedDepotModal.id.toUpperCase()}
                </span>
              </div>

              <div className="space-y-4 font-sans text-sm">
                <div className="bg-slate-50 p-4 border space-y-2">
                  <strong className="text-slate-700 block uppercase text-xs font-mono">DEPOT SIGN-IN REQUIREMENTS:</strong>
                  <p className="text-slate-600 text-xs leading-relaxed">
                    All business members must present a valid Crown & Cart trade membership card or verified digital token at the physical trade kiosk counter.
                  </p>
                </div>

                <div className="space-y-1 text-slate-600">
                  <div className="flex justify-between">
                    <span>Region Code:</span>
                    <strong className="font-mono text-[#0B1B36]">{selectedDepotModal.region}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Manager Sign-Off:</span>
                    <strong className="text-[#0B1B36]">{selectedDepotModal.manager}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Live Stock Level:</span>
                    <strong className="text-[#0A5C36]">{selectedDepotModal.stockCapacityPercent}% Capacity Ready</strong>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t flex justify-end gap-3">
                <button
                  onClick={() => setSelectedDepotModal(null)}
                  className="bg-[#0B1B36] hover:bg-[#0A5C36] text-white py-3 px-6 text-xs font-mono uppercase font-bold transition-colors"
                >
                  CONFIRM PREFERRED COLLECTION POINT
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
