"use client";

import React from "react";
import { ArrowUpRight, ShoppingBag, MapPin, Truck } from "lucide-react";

export default function StockYourBusinessSection() {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const panels = [
    {
      num: "01",
      title: "SHOP WHOLESALE",
      tag: "TRADE CATALOGUE",
      desc: "12,000+ British trade lines. Transparent ex-VAT tier pricing with bulk case discounts applied automatically.",
      cta: "EXPLORE CATALOGUE",
      targetId: "catalogue-section",
      imageUrl: "https://images.unsplash.com/photo-1578916171728-46686eac8d58?q=80&w=800&auto=format&fit=crop",
      icon: ShoppingBag,
    },
    {
      num: "02",
      title: "CLICK & COLLECT",
      tag: "LOCAL DEPOT NETWORK",
      desc: "Order online in under 2 minutes. Express drive-thru collection ready at your selected depot in 15 minutes.",
      cta: "FIND LOCAL DEPOT",
      targetId: "depot-section",
      imageUrl: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?q=80&w=800&auto=format&fit=crop",
      icon: MapPin,
    },
    {
      num: "03",
      title: "SCHEDULED DELIVERY",
      tag: "NATIONAL FLEET",
      desc: "Multi-temp refrigerated multi-drop delivery direct to your kitchen, store, or pub back-door.",
      cta: "VIEW FLEET ROUTES",
      targetId: "delivery-section",
      imageUrl: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?q=80&w=800&auto=format&fit=crop",
      icon: Truck,
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-[#F5F2EA] border-b border-[#1A1F26]/10">
      <div className="max-w-[1360px] mx-auto px-4 md:px-8">
        {/* SECTION HEADER */}
        <div className="mb-12 border-b border-[#1A1F26]/15 pb-6">
          <span className="font-mono text-xs tracking-widest text-slate-500 uppercase block mb-2">
            THREE WAYS TO PROCUREMENT
          </span>
          <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase text-[#0B1B36] font-sans">
            STOCK YOUR BUSINESS.
          </h2>
        </div>

        {/* THREE PANELS */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {panels.map((p) => {
            const IconComp = p.icon;
            return (
              <div
                key={p.num}
                className="bg-white border-2 border-[#0B1B36] flex flex-col justify-between group hover:-translate-y-1 transition-all duration-300 shadow-md"
              >
                {/* IMAGE TOP WITH NUMBER OVERLAY */}
                <div className="relative h-64 overflow-hidden border-b-2 border-[#0B1B36]">
                  <img
                    src={p.imageUrl}
                    alt={p.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B1B36] via-transparent to-transparent opacity-80" />

                  {/* NUMBER BADGE */}
                  <div className="absolute top-4 left-4 bg-[#0B1B36] text-white px-3 py-1 font-mono text-2xl font-black border border-white/20">
                    {p.num}
                  </div>

                  {/* TAG */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-white font-mono text-xs uppercase font-bold">
                    <span className="bg-[#0A5C36] px-2 py-0.5">{p.tag}</span>
                    <IconComp className="w-5 h-5 text-amber-300" />
                  </div>
                </div>

                {/* CONTENT */}
                <div className="p-6 md:p-8 space-y-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-2xl font-black uppercase text-[#0B1B36] font-sans tracking-tight">
                      {p.title}
                    </h3>
                    <p className="text-slate-600 text-sm md:text-base font-sans mt-2 leading-relaxed">
                      {p.desc}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-200">
                    <button
                      onClick={() => scrollToSection(p.targetId)}
                      className="w-full bg-[#0B1B36] hover:bg-[#0A5C36] text-white py-3 px-4 font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-between transition-colors group-hover:bg-[#0A5C36]"
                    >
                      <span>{p.cta}</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
