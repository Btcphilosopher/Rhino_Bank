"use client";

import React, { useState } from "react";
import { useStore } from "@/lib/store";
import { PRODUCTS } from "@/lib/data";
import { Layers, Scan, ArrowRight, ShieldCheck, CheckCircle2 } from "lucide-react";

export default function DigitalDepotSection() {
  const { addToCart, setSelectedProductModal } = useStore();
  const [digitalModePercent, setDigitalModePercent] = useState(60); // 0 = Physical Warehouse, 100 = Digital Catalogue

  const aisleProducts = PRODUCTS.slice(0, 4);

  return (
    <section id="digital-depot-section" className="py-16 md:py-24 bg-[#FAF8F3] border-b border-[#1A1F26]/10 relative overflow-hidden">
      <div className="max-w-[1360px] mx-auto px-4 md:px-8">
        {/* SECTION HEADER */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-[#1A1F26]/15">
          <div>
            <div className="flex items-center gap-2 font-mono text-xs tracking-widest text-[#0A5C36] font-bold uppercase mb-2">
              <Scan className="w-4 h-4" />
              <span>SIGNATURE INTERACTION • EXPERIENCE 01</span>
            </div>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase text-[#0B1B36] font-sans">
              THE DIGITAL DEPOT.
            </h2>
            <p className="text-slate-600 font-sans mt-2 max-w-xl text-base md:text-lg">
              Watch physical warehouse aisles morph seamlessly into real-time trade stock & digital ordering terminals.
            </p>
          </div>

          {/* Interactive Mode Slider Control */}
          <div className="bg-[#0B1B36] text-white p-4 square-card border border-slate-700 min-w-[280px]">
            <div className="flex items-center justify-between font-mono text-xs mb-2">
              <span className="text-slate-300">AISLE VIEW STATE</span>
              <span className="text-emerald-400 font-bold">
                {digitalModePercent < 30 ? "PHYSICAL AISLE" : digitalModePercent < 70 ? "HYBRID DATA" : "DIGITAL TERMINAL"}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={digitalModePercent}
              onChange={(e) => setDigitalModePercent(Number(e.target.value))}
              className="w-full accent-[#0A5C36] cursor-pointer"
            />
            <div className="flex justify-between font-mono text-[10px] text-slate-400 mt-1">
              <span>0% PHYSICAL</span>
              <span>50% OVERLAY</span>
              <span>100% DIGITAL</span>
            </div>
          </div>
        </div>

        {/* INTERACTIVE TRANSFORMATIONAL DISPLAY CONTAINER */}
        <div className="relative border-2 border-[#0B1B36] bg-[#071226] overflow-hidden min-h-[500px]">
          {/* PHYSICAL WAREHOUSE IMAGE (Layer 1) */}
          <div
            className="absolute inset-0 bg-cover bg-center transition-opacity duration-300"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?q=80&w=1600&auto=format&fit=crop')`,
              opacity: (100 - digitalModePercent) / 100,
            }}
          >
            <div className="absolute inset-0 bg-black/40" />
            
            {/* AISLE MARKERS ON PHYSICAL VIEW */}
            <div className="absolute top-8 left-8 bg-[#0B1B36] text-white px-4 py-2 font-mono text-sm font-bold border border-white/30">
              AISLE A01 • SOFT DRINKS & MIXERS
            </div>
            <div className="absolute top-8 right-8 bg-[#0A5C36] text-white px-4 py-2 font-mono text-sm font-bold border border-white/30">
              DEPOT: LONDON WEST
            </div>

            <div className="absolute bottom-8 left-8 max-w-md bg-black/80 text-white p-4 font-mono text-xs border border-white/20">
              <span className="text-amber-400 font-bold block mb-1">PHYSICAL CASH-AND-CARRY</span>
              <span>Real-time aisle stock, pallet tiers, and trade customer loading bay status.</span>
            </div>
          </div>

          {/* DIGITAL OVERLAY & CATALOGUE TILES (Layer 2) */}
          <div
            className="relative z-10 p-6 md:p-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 transition-all duration-300"
            style={{
              backgroundColor: `rgba(11, 27, 54, ${digitalModePercent / 100})`,
            }}
          >
            {aisleProducts.map((product, idx) => (
              <div
                key={product.id}
                className="bg-[#FAF8F3] text-[#1A1F26] border-2 border-[#0B1B36] p-5 flex flex-col justify-between space-y-4 shadow-xl transition-all hover:-translate-y-1"
                style={{
                  transform: `translateY(${(100 - digitalModePercent) * (idx % 2 === 0 ? 0.3 : -0.3)}px)`,
                  opacity: Math.max(0.15, digitalModePercent / 100),
                }}
              >
                {/* AISLE & SKU HEADER */}
                <div className="flex items-center justify-between font-mono text-xs border-b border-[#1A1F26]/15 pb-2">
                  <span className="bg-[#0B1B36] text-white px-2 py-0.5 font-bold">
                    AISLE {product.aisle}
                  </span>
                  <span className="text-slate-600">{product.sku}</span>
                </div>

                {/* PRODUCT IMAGE & BRAND */}
                <div className="relative h-40 bg-white border border-slate-200 p-2 flex items-center justify-center overflow-hidden">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="h-full object-contain hover:scale-105 transition-transform duration-300"
                  />
                  {digitalModePercent > 40 && (
                    <div className="absolute top-2 right-2 bg-[#0A5C36] text-white font-mono text-[10px] px-2 py-0.5 font-bold">
                      {product.availableStock} CASES
                    </div>
                  )}
                </div>

                {/* TITLE & PACK */}
                <div>
                  <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest block">
                    {product.brand}
                  </span>
                  <h3 className="font-bold text-base text-[#0B1B36] leading-snug line-clamp-2 font-sans mt-0.5">
                    {product.name}
                  </h3>
                  <span className="font-mono text-xs text-slate-600 block mt-1">
                    PACK: {product.packSize}
                  </span>
                </div>

                {/* PRICING & STOCK */}
                <div className="pt-2 border-t border-[#1A1F26]/15 flex items-end justify-between">
                  <div>
                    <span className="text-2xl font-black text-[#0B1B36] font-mono block leading-none">
                      £{product.priceExVat.toFixed(2)}
                    </span>
                    <span className="font-mono text-[10px] text-slate-500 block">EX VAT</span>
                  </div>

                  <button
                    onClick={() => addToCart(product, 1)}
                    className="bg-[#0B1B36] hover:bg-[#0A5C36] text-white px-3 py-2 font-mono text-xs font-bold transition-colors uppercase"
                  >
                    + ADD
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* BOTTOM DIGITAL DEPOT MESSAGE */}
          <div className="relative z-20 bg-[#0A5C36] text-white p-4 font-mono text-xs uppercase flex flex-wrap items-center justify-between gap-4 border-t-2 border-[#0B1B36]">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-300" />
              <span className="font-bold tracking-wider">THE DEPOT IS NOW DIGITAL</span>
            </div>
            <div className="text-slate-200">
              PHYSICAL DEPOT PREMISES ↔ LIVE CATALOGUE SYNCHRONISATION
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
