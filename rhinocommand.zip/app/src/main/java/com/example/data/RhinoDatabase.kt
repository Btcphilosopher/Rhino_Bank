package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Department::class,
        Task::class,
        ApprovalStep::class,
        Meeting::class,
        Document::class,
        AuditLog::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RhinoDatabase : RoomDatabase() {
    abstract fun rhinoDao(): RhinoDao

    companion object {
        @Volatile
        private var INSTANCE: RhinoDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): RhinoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RhinoDatabase::class.java,
                    "rhino_command_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(RhinoDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class RhinoDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.rhinoDao())
                }
            }
        }

        suspend fun populateDatabase(dao: RhinoDao) {
            // 1. Prepopulate Departments
            val depts = listOf(
                Department("BOARD", "Board of Directors", 3),
                Department("EXECO", "Executive Committee", 2),
                Department("TREASURY", "Treasury", 5),
                Department("CORPFIN", "Corporate Finance", 4),
                Department("RISK", "Risk Management", 6),
                Department("COMPLIANCE", "Compliance", 4),
                Department("OPS", "Operations & Systems", 12),
                Department("TECH", "Technology division", 15),
                Department("RESEARCH", "RhinoQuant Research", 5),
                Department("LEGAL", "Legal & General Governance", 3)
            )
            dao.insertDepartments(depts)

            // 2. Prepopulate Tasks
            val task1Id = dao.insertTask(Task(
                title = "Basel III Liquidity Coverage Ratio",
                description = "Configure automated daily LCR reporting pipeline across international nodes to adhere strictly to the Basel Committee and PRA liquidity standards.",
                type = "Treasury Action",
                priority = "CRITICAL",
                status = "AWAITING_APPROVAL",
                delegatorDept = "EXECO",
                assigneeDept = "TREASURY",
                assigneeIndividual = "Marcus Vance (Treasury Lead)",
                deadline = System.currentTimeMillis() + 86400000 * 10,
                estimatedEffort = "14 days",
                actualEffort = "11 days",
                dependencies = "Model Validation parameters approval",
                labels = "Liquidity, Regulatory"
            ))

            val task2Id = dao.insertTask(Task(
                title = "Gemini AI Algorithmic Credit scoring policy",
                description = "Draft full operational framework and ethical risk matrix for client credit scoring models leveraging Google Gemini AI integrations on secure local servers.",
                type = "Risk Review",
                priority = "HIGH",
                status = "DELEGATED",
                delegatorDept = "BOARD",
                assigneeDept = "RISK",
                assigneeIndividual = "Dr. Elaine Finch (Risk Chair)",
                deadline = System.currentTimeMillis() + 86400000 * 7,
                estimatedEffort = "6 days",
                actualEffort = "Pending",
                dependencies = "Legal compliance whitepaper",
                labels = "AI, Risk, Ethics"
            ))

            dao.insertTask(Task(
                title = "Sovereign Bond Stress Testing Under Hyperinflation",
                description = "Perform extensive Monte Carlo simulation of sovereign debt yields under runaway inflationary shocks and quantitative tightening projections.",
                type = "Research Request",
                priority = "HIGH",
                status = "IN_PROGRESS",
                delegatorDept = "EXECO",
                assigneeDept = "RESEARCH",
                assigneeIndividual = "RhinoQuant Research Team",
                deadline = System.currentTimeMillis() + 86400000 * 4,
                estimatedEffort = "5 days",
                actualEffort = "Pending",
                dependencies = "Treasury macro yield feeds",
                labels = "Macro, Stress-Test"
            ))

            dao.insertTask(Task(
                title = "Securitization Audit & Escrow Check",
                description = "Standard operational validation of Mortgage Backed Securities (MBS) escrow ledgers to verify reserve balances against transaction records.",
                type = "Compliance Review",
                priority = "MEDIUM",
                status = "COMPLETED",
                delegatorDept = "COMPLIANCE",
                assigneeDept = "OPS",
                assigneeIndividual = "Sarah Jenkins (Operations Manager)",
                deadline = System.currentTimeMillis() - 86400000,
                estimatedEffort = "3 days",
                actualEffort = "2 days",
                dependencies = "None",
                labels = "MBS, Audit, Reserves"
            ))

            // 3. Prepopulate Approval Steps for Task 1
            dao.insertApprovalStep(ApprovalStep(
                taskId = task1Id.toInt(),
                role = "Risk Officer",
                status = "APPROVED",
                approverName = "Dr. Elaine Finch",
                comments = "LCR calculation stress scenarios are aligned with worst-case macroeconomic factors."
            ))
            dao.insertApprovalStep(ApprovalStep(
                taskId = task1Id.toInt(),
                role = "Compliance Officer",
                status = "APPROVED",
                approverName = "Lord Alistair Sterling",
                comments = "Regulatory disclosure filings formatted successfully."
            ))
            dao.insertApprovalStep(ApprovalStep(
                taskId = task1Id.toInt(),
                role = "CEO",
                status = "PENDING",
                approverName = "Chief Executive Tom",
                comments = ""
            ))

            // 4. Prepopulate Meetings
            dao.insertMeeting(Meeting(
                title = "Annual Capital Adequacy Review Committee",
                type = "Committee Meeting",
                timestamp = System.currentTimeMillis() - 86400000 * 2,
                location = "Room 402 - Boardroom / Secure Bridge",
                agenda = "1. Liquidity risk reporting update\n2. AI model ethical guardrails\n3. Sovereign bond asset ratios.",
                decisions = "Approved high-level parameters for sovereign assets allocation.\nDelegated daily LCR configuration task to Treasury division."
            ))
            dao.insertMeeting(Meeting(
                title = "Board of Directors Strategic Alignment Meeting",
                type = "Board Meeting",
                timestamp = System.currentTimeMillis() + 86400000 * 5,
                location = "Executive Boardroom A / Hybrid VC Link",
                agenda = "1. M&A pipeline discussion\n2. Q3 audit program oversight\n3. IT infrastructure investment allocation.",
                decisions = "Awaiting formal reports from Ops & Risk on security compliance."
            ))

            // 5. Prepopulate Documents
            dao.insertDocument(Document(
                title = "Group Capital Adequacy & Basel III Policy",
                category = "Policy",
                version = "v4.1",
                status = "Approved",
                ownerDept = "Compliance",
                hash = "f3a24b1c7d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f90"
            ))
            dao.insertDocument(Document(
                title = "Algorithmic Credit Scoring Guidelines",
                category = "Board Paper",
                version = "v1.0",
                status = "In Review",
                ownerDept = "Risk",
                hash = "2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d"
            ))
            dao.insertDocument(Document(
                title = "M&A Acquisition Feasibility Study",
                category = "Investment Memorandum",
                version = "v2.3",
                status = "Draft",
                ownerDept = "Corporate Finance",
                hash = "9e8f7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e"
            ))

            // 6. Prepopulate Audit Logs
            dao.insertAuditLog(AuditLog(
                actor = "Governance System",
                action = "RhinoCommand Initialized",
                details = "Initialized database with Department definitions, system workflows, and baseline documents."
            ))
            dao.insertAuditLog(AuditLog(
                taskId = task1Id.toInt(),
                actor = "Risk Officer (Elaine Finch)",
                action = "Approval Step Completed",
                details = "Signed off on Risk parameter modeling for Basel III Liquidity project."
            ))
            dao.insertAuditLog(AuditLog(
                taskId = task2Id.toInt(),
                actor = "Board Representative",
                action = "Strategic Task Delegated",
                details = "Assigned Gemini credit scoring review to Risk Department."
            ))
        }
    }
}
