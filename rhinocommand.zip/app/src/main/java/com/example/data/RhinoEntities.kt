package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "departments")
data class Department(
    @PrimaryKey val id: String,
    val name: String,
    val teamCount: Int
)

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val type: String, // "Strategic Project", "Operational Task", "Research Request", "Treasury Action", "Risk Review", "Compliance Review", "Document Approval"
    val priority: String, // "CRITICAL", "HIGH", "MEDIUM", "LOW"
    val status: String, // "BACKLOG", "DELEGATED", "IN_PROGRESS", "AWAITING_APPROVAL", "COMPLETED", "RECALLED", "ESCALATED"
    val delegatorDept: String,
    val assigneeDept: String,
    val assigneeIndividual: String,
    val deadline: Long,
    val estimatedEffort: String,
    val actualEffort: String = "Pending",
    val dependencies: String = "",
    val labels: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "approval_steps")
data class ApprovalStep(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val taskId: Int,
    val role: String, // "CEO", "Risk Officer", "Compliance Officer", "Treasury Officer", "Legal Counsel", "Board Chair"
    val status: String, // "PENDING", "APPROVED", "REJECTED"
    val approverName: String,
    val updatedAt: Long = System.currentTimeMillis(),
    val comments: String = ""
)

@Entity(tableName = "meetings")
data class Meeting(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val type: String, // "Board Meeting", "Committee Meeting", "Risk Review"
    val timestamp: Long,
    val location: String,
    val agenda: String,
    val decisions: String // JSON or newline-separated values
)

@Entity(tableName = "documents")
data class Document(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String, // "Policy", "Report", "Board Paper", "Investment Memorandum", "Financial Model"
    val version: String,
    val status: String, // "Approved", "Draft", "In Review"
    val ownerDept: String,
    val updatedAt: Long = System.currentTimeMillis(),
    val hash: String // SHA-256 placeholder representing digital signature / immutability
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val taskId: Int? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val actor: String,
    val action: String,
    val details: String
)
