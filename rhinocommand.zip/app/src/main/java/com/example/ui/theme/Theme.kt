package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = CopperGold,
    secondary = BrushedSteelLight,
    tertiary = YorkshireStoneMedium,
    background = GraphiteBlack,
    surface = GraphiteCharcoal,
    onPrimary = GraphiteBlack,
    onSecondary = GraphiteBlack,
    onTertiary = GraphiteBlack,
    onBackground = YorkshireStoneLight,
    onSurface = YorkshireStoneLight,
    surfaceVariant = GraphiteGray,
    onSurfaceVariant = BrushedSteelLight,
    outline = BrushedSteelDark,
    error = InstitutionalRed
  )

private val LightColorScheme =
  lightColorScheme(
    primary = CopperCopper,
    secondary = DeepNavy,
    tertiary = BrushedSteelDark,
    background = YorkshireStoneLight,
    surface = YorkshireStoneLight,
    onPrimary = YorkshireStoneLight,
    onSecondary = YorkshireStoneLight,
    onTertiary = YorkshireStoneLight,
    onBackground = GraphiteBlack,
    onSurface = GraphiteBlack,
    surfaceVariant = YorkshireStoneMedium,
    onSurfaceVariant = GraphiteCharcoal,
    outline = BrushedSteelDark,
    error = InstitutionalRed
  )

@Composable
fun RhinoCommandTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false, // Set to false to force Yorkshire Futurism palette
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
