package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class RhinoTab {
    DASHBOARD,
    DELEGATION_CENTER,
    MEETINGS,
    DOCUMENTS,
    AUDIT_LOGS
}

enum class ExecutiveRole(val title: String, val dept: String, val userName: String) {
    CHIEF_EXECUTIVE("Chief Executive Officer", "EXECO", "CEO Tom Pendelton"),
    BOARD_MEMBER("Board Director", "BOARD", "Lord Alistair Sterling"),
    DEPARTMENT_HEAD("Head of Risk & Compliance", "RISK", "Dr. Elaine Finch"),
    TEAM_MEMBER("Lead Treasury Analyst", "TREASURY", "Marcus Vance")
}

class RhinoViewModel(application: Application) : AndroidViewModel(application) {

    private val database: RhinoDatabase = RhinoDatabase.getDatabase(application, viewModelScope)
    private val repository = RhinoRepository(database.rhinoDao())

    // Active Screen Tab
    private val _activeTab = MutableStateFlow(RhinoTab.DASHBOARD)
    val activeTab: StateFlow<RhinoTab> = _activeTab.asStateFlow()

    // Active Executive Persona Role
    private val _currentRole = MutableStateFlow(ExecutiveRole.CHIEF_EXECUTIVE)
    val currentRole: StateFlow<ExecutiveRole> = _currentRole.asStateFlow()

    // Data streams from database
    val departments: StateFlow<List<Department>> = repository.allDepartments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTasks: StateFlow<List<Task>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val meetings: StateFlow<List<Meeting>> = repository.allMeetings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val documents: StateFlow<List<Document>> = repository.allDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLog>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Search Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Delegation Filters
    private val _selectedDeptFilter = MutableStateFlow<String?>("ALL")
    val selectedDeptFilter: StateFlow<String?> = _selectedDeptFilter.asStateFlow()

    private val _selectedPriorityFilter = MutableStateFlow<String?>("ALL")
    val selectedPriorityFilter: StateFlow<String?> = _selectedPriorityFilter.asStateFlow()

    fun setTab(tab: RhinoTab) {
        _activeTab.value = tab
    }

    fun setRole(role: ExecutiveRole) {
        _currentRole.value = role
        // Log persona shift for transparency
        viewModelScope.launch {
            repository.createDocument(
                Document(
                    title = "Audit Protocol Token Issued for ${role.userName}",
                    category = "Security Access",
                    version = "Session v1.2",
                    status = "Approved",
                    ownerDept = role.dept,
                    hash = "sec_${System.currentTimeMillis().toString().hashCode()}"
                ),
                "Security System"
            )
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setDeptFilter(dept: String?) {
        _selectedDeptFilter.value = dept
    }

    fun setPriorityFilter(priority: String?) {
        _selectedPriorityFilter.value = priority
    }

    // Business Delegation Actions
    fun delegateTask(
        title: String,
        description: String,
        type: String,
        priority: String,
        assigneeDept: String,
        assigneeIndividual: String,
        deadlineDays: Int,
        estimatedEffort: String,
        dependencies: String,
        labels: String
    ) {
        viewModelScope.launch {
            val actor = _currentRole.value.userName
            val status = if (priority == "CRITICAL" || type == "Treasury Action" || type == "Risk Review") {
                "AWAITING_APPROVAL"
            } else {
                "DELEGATED"
            }
            val newTask = Task(
                title = title,
                description = description,
                type = type,
                priority = priority,
                status = status,
                delegatorDept = _currentRole.value.dept,
                assigneeDept = assigneeDept,
                assigneeIndividual = assigneeIndividual,
                deadline = System.currentTimeMillis() + (86400000L * deadlineDays),
                estimatedEffort = estimatedEffort,
                dependencies = dependencies,
                labels = labels
            )
            repository.delegateTask(newTask, actor)
        }
    }

    fun updateApprovalStep(step: ApprovalStep, isApproved: Boolean, comments: String) {
        viewModelScope.launch {
            val actor = _currentRole.value.userName
            val newStatus = if (isApproved) "APPROVED" else "REJECTED"
            repository.updateApprovalStepStatus(step, newStatus, comments, actor)
            
            // Check if all steps approved and auto-mark task as COMPLETED or IN_PROGRESS
            checkApprovalChainState(step.taskId)
        }
    }

    private suspend fun checkApprovalChainState(taskId: Int) {
        val stepsFlow = repository.getApprovalStepsForTask(taskId).firstOrNull() ?: return
        val allApproved = stepsFlow.all { it.status == "APPROVED" }
        if (allApproved) {
            repository.completeTask(taskId, "9 hours (Auto)", "System Governor")
        }
    }

    fun completeTask(taskId: Int, actualEffort: String) {
        viewModelScope.launch {
            val actor = _currentRole.value.userName
            repository.completeTask(taskId, actualEffort, actor)
        }
    }

    fun recallTask(taskId: Int) {
        viewModelScope.launch {
            val actor = _currentRole.value.userName
            repository.recallTask(taskId, actor)
        }
    }

    fun escalateTask(taskId: Int) {
        viewModelScope.launch {
            val actor = _currentRole.value.userName
            repository.escalateTask(taskId, actor)
        }
    }

    fun createMeeting(title: String, type: String, location: String, agenda: String, decisions: String) {
        viewModelScope.launch {
            val actor = _currentRole.value.userName
            val newMeeting = Meeting(
                title = title,
                type = type,
                timestamp = System.currentTimeMillis() + 86400000 * 3, // 3 days in future
                location = location,
                agenda = agenda,
                decisions = decisions
            )
            repository.createMeeting(newMeeting, actor)
        }
    }

    fun createDocument(title: String, category: String, version: String, ownerDept: String) {
        viewModelScope.launch {
            val actor = _currentRole.value.userName
            val randomHash = (title + version + System.currentTimeMillis().toString()).hashCode().toString(16)
            val newDoc = Document(
                title = title,
                category = category,
                version = version,
                status = "In Review",
                ownerDept = ownerDept,
                hash = "sha256_$randomHash"
            )
            repository.createDocument(newDoc, actor)
        }
    }

    // Load approval steps for a specific task dynamically in UI
    fun getApprovalStepsFlow(taskId: Int): Flow<List<ApprovalStep>> {
        return repository.getApprovalStepsForTask(taskId)
    }
}
