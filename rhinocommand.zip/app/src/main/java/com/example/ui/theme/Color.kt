package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Graphite Black (Base backgrounds)
val GraphiteBlack = Color(0xFF0A0E14) // Deep background color
val GraphiteCharcoal = Color(0xFF050505) // Nav/Bottom bar dark background
val GraphiteGray = Color(0xFF151921) // Slate Blue-Gray card backgrounds

// Yorkshire Stone (Light Warm Elements)
val YorkshireStoneLight = Color(0xFFE4E3E0) // Base Text Color
val YorkshireStoneMedium = Color(0xFF848482) // Muted Stone Gray
val YorkshireStoneDark = Color(0xFF6B6A68)

// Brushed Steel (Metallic accents/borders)
val BrushedSteelLight = Color(0xFF848482)
val BrushedSteelDark = Color(0xFF424241)

// Deep Navy (Institutional trust / panels)
val DeepNavy = Color(0xFF0E141E)
val DeepNavyLight = Color(0xFF151F2E)

// Copper Accents (High priority / brand focal points)
val CopperCopper = Color(0xFFB87333) // Precision Copper
val CopperGold = Color(0xFFD98845) // Lighter copper
val CopperRust = Color(0xFF7D461B) // Deep warm rust

// Secondary/Status Indicators
val InstitutionalGreen = Color(0xFF10B981) // Emerald organization green
val InstitutionalAmber = Color(0xFFF59E0B)
val InstitutionalRed = Color(0xFFEF4444)
val InstitutionalBlue = Color(0xFF3B82F6)
