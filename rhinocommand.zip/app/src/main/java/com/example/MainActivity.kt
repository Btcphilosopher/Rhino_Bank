package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val viewModel: RhinoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RhinoCommandTheme(darkTheme = true) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    RhinoMainScreen(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun RhinoMainScreen(viewModel: RhinoViewModel, modifier: Modifier = Modifier) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. TOP HEADER PANEL WITH ARCHITECTURAL BORDER & ROLE SELECTOR
        HeaderPanel(
            currentRole = currentRole,
            onRoleChange = { viewModel.setRole(it) }
        )

        // 2. SUB-NAVIGATION CONTROL TAB BAR
        TabNavigationRow(
            activeTab = activeTab,
            onTabSelected = { viewModel.setTab(it) }
        )

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), thickness = 1.dp)

        // 3. MAIN WORKSPACE AREA WITH CROSS-FADE ANIMATION
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "MainContentSwap"
            ) { tab ->
                when (tab) {
                    RhinoTab.DASHBOARD -> DashboardScreen(viewModel)
                    RhinoTab.DELEGATION_CENTER -> DelegationCenterScreen(viewModel)
                    RhinoTab.MEETINGS -> MeetingsScreen(viewModel)
                    RhinoTab.DOCUMENTS -> DocumentsScreen(viewModel)
                    RhinoTab.AUDIT_LOGS -> AuditLogsScreen(viewModel)
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: SECTION HEADER & DESIGN ACCENT
// ==========================================
@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF848482),
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Color(0xFF848482).copy(alpha = 0.25f))
        )
        Spacer(modifier = Modifier.height(8.dp))
    }
}

// ==========================================
// COMPONENT: HEADER PANEL & ROLE SELECTOR
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeaderPanel(
    currentRole: ExecutiveRole,
    onRoleChange: (ExecutiveRole) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0A0E14))
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "RhinoCommand Terminal",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFB87333),
                letterSpacing = 2.sp,
                modifier = Modifier.padding(bottom = 3.dp)
            )
            Text(
                text = "Executive Oversight",
                fontSize = 22.sp,
                fontFamily = FontFamily.Serif,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                color = Color(0xFFE4E3E0),
                fontWeight = FontWeight.Normal
            )
        }

        Box {
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier
                    .clickable { expanded = true }
                    .testTag("role_selector_button")
            ) {
                Box(
                    modifier = Modifier
                        .background(Color(0xFFB87333).copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .border(1.dp, Color(0xFFB87333).copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "ROLE: ${currentRole.dept}",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFB87333),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Switch Role",
                            tint = Color(0xFFB87333),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ID: RH-0901-${currentRole.name.take(3).uppercase()}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF848482)
                )
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(Color(0xFF151921))
            ) {
                ExecutiveRole.values().forEach { role ->
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = role.userName,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE4E3E0)
                                )
                                Text(
                                    text = "${role.title} (${role.dept})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF848482)
                                )
                            }
                        },
                        onClick = {
                            onRoleChange(role)
                            expanded = false
                        },
                        modifier = Modifier.testTag("role_option_${role.name}")
                    )
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: TAB NAVIGATION ROW
// ==========================================
@Composable
fun TabNavigationRow(
    activeTab: RhinoTab,
    onTabSelected: (RhinoTab) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF050505))
            .horizontalScroll(androidx.compose.foundation.rememberScrollState())
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val tabs = listOf(
            RhinoTab.DASHBOARD to "COMMAND",
            RhinoTab.DELEGATION_CENTER to "DELEGATION",
            RhinoTab.MEETINGS to "MEETINGS",
            RhinoTab.DOCUMENTS to "DOCUMENTS",
            RhinoTab.AUDIT_LOGS to "AUDIT"
        )

        tabs.forEach { (tab, label) ->
            val isSelected = activeTab == tab
            Box(
                modifier = Modifier
                    .clickable { onTabSelected(tab) }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
                    .testTag("nav_tab_$label"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .background(Color(0xFFB87333), RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    } else {
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .background(Color.Transparent)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    Text(
                        text = label,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = if (isSelected) Color(0xFFB87333) else Color(0xFF848482)
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN: EXECUTIVE DASHBOARD
// ==========================================
@Composable
fun DashboardScreen(viewModel: RhinoViewModel) {
    val tasks by viewModel.allTasks.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val departments by viewModel.departments.collectAsStateWithLifecycle()

    val totalCount = tasks.size
    val openCount = tasks.count { it.status != "COMPLETED" }
    val completedCount = tasks.count { it.status == "COMPLETED" }
    val escalatedCount = tasks.count { it.status == "ESCALATED" }
    val awaitingApprovalCount = tasks.count { it.status == "AWAITING_APPROVAL" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Hero Brand Board Statement
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF151921))
            ) {
                // Left side copper border
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .fillMaxHeight()
                        .background(Color(0xFFB87333))
                )
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "COMMERCIAL STRATEGY & RISK OVERSIGHT",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB87333),
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Authorized Session for ${currentRole.userName}",
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Serif,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        color = Color(0xFFE4E3E0)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Secure institutional routing enabled. System is currently tracking $totalCount active bank delegations, corporate audits, and liquidity assessments.",
                        fontSize = 12.sp,
                        color = Color(0xFF848482)
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // High-fidelity Metric Cards Grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF848482).copy(alpha = 0.2f)) // Grid border lines
                    .border(1.dp, Color(0xFF848482).copy(alpha = 0.2f))
            ) {
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0A0E14))
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "OPEN ISSUES",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF848482),
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = openCount.toString(),
                                fontSize = 24.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Delegated corporate actions",
                                fontSize = 10.sp,
                                color = Color(0xFF848482)
                            )
                        }
                    }
                    // Vertical grid line
                    Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color(0xFF848482).copy(alpha = 0.2f)))
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0A0E14))
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "AWAITING APPROVAL",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB87333),
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = awaitingApprovalCount.toString(),
                                fontSize = 24.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFB87333),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Pending sign-offs",
                                fontSize = 10.sp,
                                color = Color(0xFF848482)
                            )
                        }
                    }
                }
                // Horizontal grid line
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF848482).copy(alpha = 0.2f)))
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0A0E14))
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "CRITICAL ESCALATIONS",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEF4444),
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = escalatedCount.toString(),
                                fontSize = 24.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFEF4444),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Urgent board review",
                                fontSize = 10.sp,
                                color = Color(0xFF848482)
                            )
                        }
                    }
                    // Vertical grid line
                    Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color(0xFF848482).copy(alpha = 0.2f)))
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0A0E14))
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "COMPLETED ACTIONS",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981),
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = completedCount.toString(),
                                fontSize = 24.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Audited & closed",
                                fontSize = 10.sp,
                                color = Color(0xFF848482)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Departmental Overviews & Workload Chart
        item {
            SectionHeader(title = "ORGANISATIONAL WORKLOAD")
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF151921)),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF848482).copy(alpha = 0.15f), RoundedCornerShape(2.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    departments.forEach { dept ->
                        val deptTasksCount = tasks.count { it.assigneeDept == dept.id }
                        val openDeptTasksCount = tasks.count { it.assigneeDept == dept.id && it.status != "COMPLETED" }
                        
                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = dept.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFE4E3E0)
                                )
                                Text(
                                    text = "$openDeptTasksCount active / $deptTasksCount total",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFB87333)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            // Workload bar
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .background(Color(0xFF0A0E14))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(
                                            fraction = if (totalCount > 0) deptTasksCount.toFloat() / totalCount else 0f
                                        )
                                        .fillMaxHeight()
                                        .background(
                                            if (openDeptTasksCount > 2) Color(0xFFEF4444) else Color(0xFFB87333)
                                        )
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Strategic Priority Tasks Preview
        item {
            SectionHeader(title = "CRITICAL PRIORITY PIPELINE")
        }

        val highPriorityTasks = tasks.filter { it.priority == "CRITICAL" || it.priority == "HIGH" }
        if (highPriorityTasks.isEmpty()) {
            item {
                Text(
                    text = "No critical priorities currently flagged in queue.",
                    fontSize = 13.sp,
                    color = Color(0xFF848482),
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(highPriorityTasks) { task ->
                TaskMinimalItem(task = task, onClick = {
                    // Navigate to delegation center or trigger details
                })
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

// ==========================================
// SCREEN: DELEGATION CENTER & TASK WORKSPACE
// ==========================================
@Composable
fun DelegationCenterScreen(viewModel: RhinoViewModel) {
    val tasks by viewModel.allTasks.collectAsStateWithLifecycle()
    val departments by viewModel.departments.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedTaskForDetail by remember { mutableStateOf<Task?>(null) }

    val filteredTasks = tasks.filter {
        it.title.contains(searchQuery, ignoreCase = true) ||
                it.description.contains(searchQuery, ignoreCase = true) ||
                it.assigneeDept.contains(searchQuery, ignoreCase = true) ||
                it.type.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Filters & Search bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                label = { Text("Search system registry...") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = YorkshireStoneLight,
                    unfocusedTextColor = YorkshireStoneLight,
                    focusedBorderColor = CopperGold,
                    unfocusedBorderColor = BrushedSteelDark
                ),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = CopperGold) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("search_field"),
                shape = RoundedCornerShape(4.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Only Board and Executive members can directly spin up strategic tasks
            val canDelegate = currentRole == ExecutiveRole.CHIEF_EXECUTIVE || currentRole == ExecutiveRole.BOARD_MEMBER
            if (canDelegate) {
                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CopperCopper),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .height(56.dp)
                        .testTag("delegate_action_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Delegate", tint = YorkshireStoneLight)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("DELEGATE", fontWeight = FontWeight.Bold, color = YorkshireStoneLight)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Main List of Delegated Corporate Actions
        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            items(filteredTasks) { task ->
                TaskCardItem(
                    task = task,
                    onClick = { selectedTaskForDetail = task }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    // Task Details & Dynamic Approvals Panel
    selectedTaskForDetail?.let { task ->
        TaskDetailDialog(
            task = task,
            viewModel = viewModel,
            onDismiss = { selectedTaskForDetail = null }
        )
    }

    // Delegate Task Creation Form Dialog
    if (showCreateDialog) {
        DelegateCreateDialog(
            departments = departments,
            onDismiss = { showCreateDialog = false },
            onConfirm = { title, desc, type, priority, dept, assignee, deadline, effort, deps, labels ->
                viewModel.delegateTask(
                    title, desc, type, priority, dept, assignee, deadline, effort, deps, labels
                )
                showCreateDialog = false
            }
        )
    }
}

// ==========================================
// COMPONENT: TASK CARD ITEM
// ==========================================
@Composable
fun TaskCardItem(task: Task, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(2.dp))
            .background(Color(0xFF151921))
            .border(1.dp, Color(0xFF848482).copy(alpha = 0.15f), RoundedCornerShape(2.dp))
            .clickable { onClick() }
    ) {
        val priorityColor = when (task.priority) {
            "CRITICAL" -> Color(0xFFEF4444)
            "HIGH" -> Color(0xFFF59E0B)
            "MEDIUM" -> Color(0xFF3B82F6)
            else -> Color(0xFF848482)
        }
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight()
                .background(priorityColor)
        )

        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = task.type.uppercase(),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF848482),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                PriorityBadge(priority = task.priority)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = task.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE4E3E0)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = task.description,
                fontSize = 12.sp,
                color = Color(0xFF848482),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Apartment,
                        contentDescription = "Dept",
                        tint = Color(0xFF848482),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "DEPT: ${task.delegatorDept} ➔ ${task.assigneeDept}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF848482)
                    )
                }

                StatusBadge(status = task.status)
            }
        }
    }
}

@Composable
fun TaskMinimalItem(task: Task, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(2.dp))
            .background(Color(0xFF151921))
            .border(1.dp, Color(0xFF848482).copy(alpha = 0.1f), RoundedCornerShape(2.dp))
            .clickable { onClick() }
    ) {
        val priorityColor = when (task.priority) {
            "CRITICAL" -> Color(0xFFEF4444)
            "HIGH" -> Color(0xFFF59E0B)
            "MEDIUM" -> Color(0xFF3B82F6)
            else -> Color(0xFF848482)
        }
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight()
                .background(priorityColor)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFE4E3E0),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Assignee: ${task.assigneeIndividual} | Dept: ${task.assigneeDept}",
                    fontSize = 11.sp,
                    color = Color(0xFF848482)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            StatusBadge(status = task.status)
        }
    }
}

@Composable
fun PriorityBadge(priority: String) {
    val color = when (priority) {
        "CRITICAL" -> Color(0xFFEF4444)
        "HIGH" -> Color(0xFFF59E0B)
        "MEDIUM" -> Color(0xFF3B82F6)
        else -> Color(0xFF848482)
    }
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.1f), RoundedCornerShape(2.dp))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = priority,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
fun StatusBadge(status: String) {
    val color = when (status) {
        "COMPLETED" -> Color(0xFF10B981)
        "AWAITING_APPROVAL" -> Color(0xFFB87333)
        "ESCALATED" -> Color(0xFFEF4444)
        "RECALLED" -> Color(0xFFF59E0B)
        "IN_PROGRESS" -> Color(0xFF3B82F6)
        else -> Color(0xFF848482)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .background(color, RoundedCornerShape(3.dp))
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = status.replace("_", " "),
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

// ==========================================
// DIALOG: TASK DETAILS & APPROVAL WORKFLOWS
// ==========================================
@Composable
fun TaskDetailDialog(
    task: Task,
    viewModel: RhinoViewModel,
    onDismiss: () -> Unit
) {
    val approvalSteps by viewModel.getApprovalStepsFlow(task.id).collectAsStateWithLifecycle(initialValue = emptyList())
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()

    var approvalComments by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = GraphiteCharcoal),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BrushedSteelLight.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                .padding(2.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TASK DOSSIER #${task.id}".uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = CopperGold,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = YorkshireStoneLight,
                                fontWeight = FontWeight.Black
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = YorkshireStoneLight)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Metadata Core Values
                item {
                    Text(
                        text = "DELEGATION SPECIFICATION",
                        style = MaterialTheme.typography.labelMedium,
                        color = CopperGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = YorkshireStoneLight
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ASSIGNEE DEPT", style = MaterialTheme.typography.labelSmall, color = BrushedSteelLight)
                            Text(task.assigneeDept, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = YorkshireStoneLight)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("INDIVIDUAL LEAD", style = MaterialTheme.typography.labelSmall, color = BrushedSteelLight)
                            Text(task.assigneeIndividual, style = MaterialTheme.typography.bodyMedium, color = YorkshireStoneLight)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ESTIMATED EFFORT", style = MaterialTheme.typography.labelSmall, color = BrushedSteelLight)
                            Text(task.estimatedEffort, style = MaterialTheme.typography.bodyMedium, color = YorkshireStoneLight)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ACTUAL EFFORT", style = MaterialTheme.typography.labelSmall, color = BrushedSteelLight)
                            Text(task.actualEffort, style = MaterialTheme.typography.bodyMedium, color = YorkshireStoneLight)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    if (task.dependencies.isNotEmpty()) {
                        Text("SYSTEM DEPENDENCIES", style = MaterialTheme.typography.labelSmall, color = BrushedSteelLight)
                        Text(task.dependencies, style = MaterialTheme.typography.bodyMedium, color = YorkshireStoneLight)
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    if (task.labels.isNotEmpty()) {
                        Text("TAG CLASSIFICATION", style = MaterialTheme.typography.labelSmall, color = BrushedSteelLight)
                        Text(task.labels, style = MaterialTheme.typography.bodyMedium, color = CopperGold)
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }

                // Dynamic Approvals Chain View
                if (approvalSteps.isNotEmpty()) {
                    item {
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "EXECUTIVE APPROVAL WORKFLOW",
                            style = MaterialTheme.typography.labelMedium,
                            color = CopperGold,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    items(approvalSteps) { step ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(GraphiteGray)
                                .border(1.dp, BrushedSteelDark.copy(alpha = 0.2f))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${step.role} Approval",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = YorkshireStoneLight
                                )
                                Text(
                                    text = "Approver: ${step.approverName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BrushedSteelLight
                                )
                                if (step.comments.isNotEmpty()) {
                                    Text(
                                        text = "Comments: \"${step.comments}\"",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = CopperGold,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }

                            // State representation
                            val stepBadgeColor = when (step.status) {
                                "APPROVED" -> InstitutionalGreen
                                "REJECTED" -> InstitutionalRed
                                else -> BrushedSteelLight
                            }
                            Box(
                                modifier = Modifier
                                    .background(stepBadgeColor.copy(alpha = 0.15f))
                                    .border(1.dp, stepBadgeColor, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(step.status, style = MaterialTheme.typography.labelSmall, color = stepBadgeColor, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // Interactive Sign-off Panel for Authorized Roles
                    val activePendingStep = approvalSteps.firstOrNull { it.status == "PENDING" }
                    if (activePendingStep != null) {
                        val isUserAuthorized = (currentRole.name == "CHIEF_EXECUTIVE" && activePendingStep.role == "CEO") ||
                                (currentRole.name == "BOARD_MEMBER" && activePendingStep.role == "Board Chair") ||
                                (currentRole.name == "DEPARTMENT_HEAD" && activePendingStep.role == "Risk Officer") ||
                                (currentRole.name == "TEAM_MEMBER" && activePendingStep.role == "Treasury Officer")

                        if (isUserAuthorized) {
                            item {
                                Spacer(modifier = Modifier.height(12.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DeepNavy),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, CopperGold.copy(alpha = 0.3f))
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = "SIGN SIGNATURE DISCLOSURE & SECURE PASS",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CopperGold
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        OutlinedTextField(
                                            value = approvalComments,
                                            onValueChange = { approvalComments = it },
                                            label = { Text("Audit Notes/Comments...") },
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedTextColor = YorkshireStoneLight,
                                                unfocusedTextColor = YorkshireStoneLight,
                                                focusedBorderColor = CopperGold,
                                                unfocusedBorderColor = BrushedSteelDark
                                            ),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            Button(
                                                onClick = {
                                                    viewModel.updateApprovalStep(activePendingStep, false, approvalComments)
                                                    onDismiss()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = InstitutionalRed),
                                                shape = RoundedCornerShape(2.dp)
                                            ) {
                                                Text("REJECT", fontWeight = FontWeight.Bold, color = YorkshireStoneLight)
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    viewModel.updateApprovalStep(activePendingStep, true, approvalComments)
                                                    onDismiss()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = InstitutionalGreen),
                                                shape = RoundedCornerShape(2.dp)
                                            ) {
                                                Text("APPROVE", fontWeight = FontWeight.Bold, color = YorkshireStoneLight)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Escalation/Recall Panel for Executive Powers
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Complete manual trigger for assignees when approvals are green or non-existent
                        if (task.status == "DELEGATED" || task.status == "IN_PROGRESS") {
                            Button(
                                onClick = {
                                    viewModel.completeTask(task.id, "Auto Sign-off")
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = InstitutionalGreen),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Complete")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("COMPLETE", color = YorkshireStoneLight)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        // Chief Exec & Board can escalate or recall tasks
                        val isExecutive = currentRole == ExecutiveRole.CHIEF_EXECUTIVE || currentRole == ExecutiveRole.BOARD_MEMBER
                        if (isExecutive && task.status != "COMPLETED") {
                            Button(
                                onClick = {
                                    viewModel.escalateTask(task.id)
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = InstitutionalRed),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = "Escalate")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ESCALATE", color = YorkshireStoneLight)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Button(
                                onClick = {
                                    viewModel.recallTask(task.id)
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = InstitutionalAmber),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Undo, contentDescription = "Recall")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("RECALL", color = YorkshireStoneLight)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// DIALOG: CREATE DELEGATED ACTION FORM
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DelegateCreateDialog(
    departments: List<Department>,
    onDismiss: () -> Unit,
    onConfirm: (
        title: String,
        description: String,
        type: String,
        priority: String,
        assigneeDept: String,
        assigneeIndividual: String,
        deadlineDays: Int,
        estimatedEffort: String,
        dependencies: String,
        labels: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Strategic Project") }
    var priority by remember { mutableStateOf("HIGH") }
    var assigneeDept by remember { mutableStateOf("TREASURY") }
    var assigneeIndividual by remember { mutableStateOf("") }
    var deadlineDays by remember { mutableStateOf("10") }
    var estimatedEffort by remember { mutableStateOf("5 days") }
    var dependencies by remember { mutableStateOf("") }
    var labels by remember { mutableStateOf("") }

    val types = listOf(
        "Strategic Project", "Operational Task", "Research Request",
        "Treasury Action", "Risk Review", "Compliance Review", "Document Approval"
    )
    val priorities = listOf("CRITICAL", "HIGH", "MEDIUM", "LOW")

    var typeExpanded by remember { mutableStateOf(false) }
    var priorityExpanded by remember { mutableStateOf(false) }
    var deptExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = GraphiteCharcoal),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BrushedSteelLight.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                .padding(2.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                item {
                    Text(
                        text = "NEW EXECUTIVE DELEGATION",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = CopperGold
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Title Input
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Delegated Action Title") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = YorkshireStoneLight,
                            unfocusedTextColor = YorkshireStoneLight,
                            focusedBorderColor = CopperGold,
                            unfocusedBorderColor = BrushedSteelDark
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_task_title"),
                        shape = RoundedCornerShape(4.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Description Input
                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Detailed Directives") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = YorkshireStoneLight,
                            unfocusedTextColor = YorkshireStoneLight,
                            focusedBorderColor = CopperGold,
                            unfocusedBorderColor = BrushedSteelDark
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(4.dp),
                        minLines = 3
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Dropdowns: Type & Priority & Department
                item {
                    // Type Selection
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = type,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Action Type") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = YorkshireStoneLight,
                                unfocusedTextColor = YorkshireStoneLight,
                                focusedBorderColor = CopperGold,
                                unfocusedBorderColor = BrushedSteelDark
                            ),
                            trailingIcon = {
                                IconButton(onClick = { typeExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Type", tint = CopperGold)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        DropdownMenu(
                            expanded = typeExpanded,
                            onDismissRequest = { typeExpanded = false },
                            modifier = Modifier.background(GraphiteGray)
                        ) {
                            types.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text(t, color = YorkshireStoneLight) },
                                    onClick = {
                                        type = t
                                        typeExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                item {
                    // Priority Selection
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = priority,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Strategic Priority") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = YorkshireStoneLight,
                                unfocusedTextColor = YorkshireStoneLight,
                                focusedBorderColor = CopperGold,
                                unfocusedBorderColor = BrushedSteelDark
                            ),
                            trailingIcon = {
                                IconButton(onClick = { priorityExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Priority", tint = CopperGold)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        DropdownMenu(
                            expanded = priorityExpanded,
                            onDismissRequest = { priorityExpanded = false },
                            modifier = Modifier.background(GraphiteGray)
                        ) {
                            priorities.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p, color = YorkshireStoneLight) },
                                    onClick = {
                                        priority = p
                                        priorityExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                item {
                    // Department Target Selection
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = assigneeDept,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Assignee Department") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = YorkshireStoneLight,
                                unfocusedTextColor = YorkshireStoneLight,
                                focusedBorderColor = CopperGold,
                                unfocusedBorderColor = BrushedSteelDark
                            ),
                            trailingIcon = {
                                IconButton(onClick = { deptExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Department", tint = CopperGold)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        DropdownMenu(
                            expanded = deptExpanded,
                            onDismissRequest = { deptExpanded = false },
                            modifier = Modifier.background(GraphiteGray)
                        ) {
                            departments.forEach { d ->
                                DropdownMenuItem(
                                    text = { Text("${d.name} (${d.id})", color = YorkshireStoneLight) },
                                    onClick = {
                                        assigneeDept = d.id
                                        deptExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Individual and Deadline/effort Inputs
                item {
                    OutlinedTextField(
                        value = assigneeIndividual,
                        onValueChange = { assigneeIndividual = it },
                        label = { Text("Lead Director/Individual") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = YorkshireStoneLight,
                            unfocusedTextColor = YorkshireStoneLight,
                            focusedBorderColor = CopperGold,
                            unfocusedBorderColor = BrushedSteelDark
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(4.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = deadlineDays,
                            onValueChange = { deadlineDays = it },
                            label = { Text("Days to Deadline") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = YorkshireStoneLight,
                                unfocusedTextColor = YorkshireStoneLight,
                                focusedBorderColor = CopperGold,
                                unfocusedBorderColor = BrushedSteelDark
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(4.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedTextField(
                            value = estimatedEffort,
                            onValueChange = { estimatedEffort = it },
                            label = { Text("Effort Estimate") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = YorkshireStoneLight,
                                unfocusedTextColor = YorkshireStoneLight,
                                focusedBorderColor = CopperGold,
                                unfocusedBorderColor = BrushedSteelDark
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                item {
                    OutlinedTextField(
                        value = dependencies,
                        onValueChange = { dependencies = it },
                        label = { Text("Pre-requisite / Dependencies") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = YorkshireStoneLight,
                            unfocusedTextColor = YorkshireStoneLight,
                            focusedBorderColor = CopperGold,
                            unfocusedBorderColor = BrushedSteelDark
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(4.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                item {
                    OutlinedTextField(
                        value = labels,
                        onValueChange = { labels = it },
                        label = { Text("Tags / Classifications (Comma Separated)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = YorkshireStoneLight,
                            unfocusedTextColor = YorkshireStoneLight,
                            focusedBorderColor = CopperGold,
                            unfocusedBorderColor = BrushedSteelDark
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(4.dp)
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = GraphiteGray),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("CANCEL", color = YorkshireStoneLight)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (title.isNotEmpty()) {
                                    onConfirm(
                                        title,
                                        description,
                                        type,
                                        priority,
                                        assigneeDept,
                                        assigneeIndividual,
                                        deadlineDays.toIntOrNull() ?: 10,
                                        estimatedEffort,
                                        dependencies,
                                        labels
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CopperCopper),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.testTag("confirm_delegation_button")
                        ) {
                            Text("SIGN & DELEGATE", fontWeight = FontWeight.Bold, color = YorkshireStoneLight)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN: MEETING MANAGEMENT & DECISION LOGS
// ==========================================
@Composable
fun MeetingsScreen(viewModel: RhinoViewModel) {
    val meetings by viewModel.meetings.collectAsStateWithLifecycle()
    var showCreateMeetingDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionHeader(
                title = "BOARD & COMMITTEE ALIGNMENTS",
                modifier = Modifier.weight(1.5f)
            )

            Button(
                onClick = { showCreateMeetingDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = CopperCopper),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .testTag("schedule_meeting_button")
            ) {
                Icon(Icons.Default.CalendarMonth, contentDescription = "Add Meeting", tint = YorkshireStoneLight)
                Spacer(modifier = Modifier.width(4.dp))
                Text("SCHEDULE", color = YorkshireStoneLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn {
            items(meetings) { meeting ->
                MeetingCardItem(meeting = meeting)
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    if (showCreateMeetingDialog) {
        CreateMeetingDialog(
            onDismiss = { showCreateMeetingDialog = false },
            onConfirm = { title, type, location, agenda, decisions ->
                viewModel.createMeeting(title, type, location, agenda, decisions)
                showCreateMeetingDialog = false
            }
        )
    }
}

@Composable
fun MeetingCardItem(meeting: Meeting) {
    val sdf = SimpleDateFormat("EEEE, dd MMM yyyy - HH:mm", Locale.getDefault())
    val formattedDate = sdf.format(Date(meeting.timestamp))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(2.dp))
            .background(Color(0xFF151921))
            .border(1.dp, Color(0xFF848482).copy(alpha = 0.15f), RoundedCornerShape(2.dp))
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight()
                .background(Color(0xFFB87333)) // Copper brand accent
        )

        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = meeting.type.uppercase(),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF848482),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = meeting.location,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF848482)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = meeting.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE4E3E0)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = formattedDate,
                fontSize = 11.sp,
                color = Color(0xFF848482)
            )

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = Color(0xFF848482).copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "AGENDA",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFB87333),
                letterSpacing = 1.sp
            )
            Text(
                text = meeting.agenda,
                fontSize = 12.sp,
                color = Color(0xFFE4E3E0),
                modifier = Modifier.padding(top = 2.dp)
            )

            if (meeting.decisions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "DECISIONS & STRATEGIC MANDATES",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF10B981),
                    letterSpacing = 1.sp
                )
                Text(
                    text = meeting.decisions,
                    fontSize = 12.sp,
                    color = Color(0xFFE4E3E0),
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

@Composable
fun CreateMeetingDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, type: String, location: String, agenda: String, decisions: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Committee Meeting") }
    var location by remember { mutableStateOf("Secure Room 402") }
    var agenda by remember { mutableStateOf("") }
    var decisions by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = GraphiteCharcoal),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BrushedSteelLight.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                .padding(2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "SCHEDULE BOARD ASSEMBLY",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = CopperGold
                )
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Meeting Title") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = YorkshireStoneLight,
                        unfocusedTextColor = YorkshireStoneLight,
                        focusedBorderColor = CopperGold,
                        unfocusedBorderColor = BrushedSteelDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Secure Coordinates / Room") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = YorkshireStoneLight,
                        unfocusedTextColor = YorkshireStoneLight,
                        focusedBorderColor = CopperGold,
                        unfocusedBorderColor = BrushedSteelDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = agenda,
                    onValueChange = { agenda = it },
                    label = { Text("Meeting Agenda Program") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = YorkshireStoneLight,
                        unfocusedTextColor = YorkshireStoneLight,
                        focusedBorderColor = CopperGold,
                        unfocusedBorderColor = BrushedSteelDark
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = decisions,
                    onValueChange = { decisions = it },
                    label = { Text("Registered Decisions & Task Mandates") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = YorkshireStoneLight,
                        unfocusedTextColor = YorkshireStoneLight,
                        focusedBorderColor = CopperGold,
                        unfocusedBorderColor = BrushedSteelDark
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = GraphiteGray)) {
                        Text("CANCEL", color = YorkshireStoneLight)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { if (title.isNotEmpty()) onConfirm(title, type, location, agenda, decisions) },
                        colors = ButtonDefaults.buttonColors(containerColor = CopperCopper)
                    ) {
                        Text("SIGN & PUBLISH", color = YorkshireStoneLight, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN: CORPORATE DOCUMENT REGISTRY
// ==========================================
@Composable
fun DocumentsScreen(viewModel: RhinoViewModel) {
    val docs by viewModel.documents.collectAsStateWithLifecycle()
    var showCreateDocDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionHeader(
                title = "IMMUTABLE BOARD PAPER CRYPTO-REGISTRY",
                modifier = Modifier.weight(1.5f)
            )

            Button(
                onClick = { showCreateDocDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = CopperCopper),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .testTag("upload_document_button")
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = "Add Document", tint = YorkshireStoneLight)
                Spacer(modifier = Modifier.width(4.dp))
                Text("REGISTER v_DRAFT", color = YorkshireStoneLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn {
            items(docs) { doc ->
                DocumentCardItem(doc = doc)
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    if (showCreateDocDialog) {
        CreateDocDialog(
            onDismiss = { showCreateDocDialog = false },
            onConfirm = { title, category, version, dept ->
                viewModel.createDocument(title, category, version, dept)
                showCreateDocDialog = false
            }
        )
    }
}

@Composable
fun DocumentCardItem(doc: Document) {
    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
    val formattedDate = sdf.format(Date(doc.updatedAt))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(2.dp))
            .background(Color(0xFF151921))
            .border(1.dp, Color(0xFF848482).copy(alpha = 0.15f), RoundedCornerShape(2.dp))
    ) {
        val isApproved = doc.status == "Approved"
        val statusColor = if (isApproved) Color(0xFF10B981) else Color(0xFFF59E0B)

        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight()
                .background(statusColor)
        )

        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${doc.category.uppercase()} [${doc.version}]",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF848482),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Box(
                    modifier = Modifier
                        .background(statusColor.copy(alpha = 0.1f), RoundedCornerShape(2.dp))
                        .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(2.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = doc.status.uppercase(),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = doc.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE4E3E0)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Owner: ${doc.ownerDept} | Last Compiled: $formattedDate",
                fontSize = 11.sp,
                color = Color(0xFF848482)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Encryption cryptographic hashes illustrating investment-banking-grade immutability
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A0E14))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = "Crypto Hash",
                    tint = Color(0xFF848482),
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "DIGITAL SIGNATURE: ${doc.hash.take(36)}...",
                    fontSize = 9.sp,
                    color = Color(0xFF848482),
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun CreateDocDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, category: String, version: String, dept: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Policy") }
    var version by remember { mutableStateOf("v1.0") }
    var ownerDept by remember { mutableStateOf("RISK") }

    val categories = listOf("Policy", "Report", "Board Paper", "Investment Memorandum", "Financial Model")

    var categoryExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = GraphiteCharcoal),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BrushedSteelLight.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                .padding(2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "REGISTER POLICY PAPER",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = CopperGold
                )
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Document / Policy Title") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = YorkshireStoneLight,
                        unfocusedTextColor = YorkshireStoneLight,
                        focusedBorderColor = CopperGold,
                        unfocusedBorderColor = BrushedSteelDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Document Classification") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = YorkshireStoneLight,
                            unfocusedTextColor = YorkshireStoneLight,
                            focusedBorderColor = CopperGold,
                            unfocusedBorderColor = BrushedSteelDark
                        ),
                        trailingIcon = {
                            IconButton(onClick = { categoryExpanded = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Category", tint = CopperGold)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    DropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false },
                        modifier = Modifier.background(GraphiteGray)
                    ) {
                        categories.forEach { c ->
                            DropdownMenuItem(
                                text = { Text(c, color = YorkshireStoneLight) },
                                onClick = {
                                    category = c
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = version,
                        onValueChange = { version = it },
                        label = { Text("Version Tag (e.g. v2.1)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = YorkshireStoneLight,
                            unfocusedTextColor = YorkshireStoneLight,
                            focusedBorderColor = CopperGold,
                            unfocusedBorderColor = BrushedSteelDark
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = ownerDept,
                        onValueChange = { ownerDept = it },
                        label = { Text("Custodian Dept") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = YorkshireStoneLight,
                            unfocusedTextColor = YorkshireStoneLight,
                            focusedBorderColor = CopperGold,
                            unfocusedBorderColor = BrushedSteelDark
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = GraphiteGray)) {
                        Text("CANCEL", color = YorkshireStoneLight)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { if (title.isNotEmpty()) onConfirm(title, category, version, ownerDept) },
                        colors = ButtonDefaults.buttonColors(containerColor = CopperCopper)
                    ) {
                        Text("REGISTER & SIGN", color = YorkshireStoneLight, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN: IMMUTABLE SECURE AUDIT LEDGER
// ==========================================
@Composable
fun AuditLogsScreen(viewModel: RhinoViewModel) {
    val logs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                SectionHeader(title = "RHINOCOMMAND SYSTEM LEDGER [IMMUTABLE]")
                Text(
                    text = "Total Secure Blockchain-Signed Records: ${logs.size}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF848482),
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Immutable Ledger",
                tint = Color(0xFF10B981),
                modifier = Modifier
                    .size(24.dp)
                    .padding(bottom = 8.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0E14)),
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, Color(0xFF848482).copy(alpha = 0.15f), RoundedCornerShape(2.dp))
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
            ) {
                items(logs) { log ->
                    val dateFormatted = sdf.format(Date(log.timestamp))
                    val isActionPositive = log.action.contains("Approved") || log.action.contains("Completed")
                    val actionColor = if (isActionPositive) Color(0xFF10B981) else Color(0xFFB87333)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color(0xFF151921))
                            .border(1.dp, Color(0xFF848482).copy(alpha = 0.1f), RoundedCornerShape(2.dp))
                    ) {
                        // Small colored indicator line on left of log item
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .fillMaxHeight()
                                .background(actionColor)
                        )

                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "[$dateFormatted]",
                                    fontSize = 10.sp,
                                    color = Color(0xFF848482),
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = log.action.uppercase(),
                                    fontSize = 10.sp,
                                    color = actionColor,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ACTOR: ${log.actor}",
                                fontSize = 10.sp,
                                color = Color(0xFFE4E3E0),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            if (log.taskId != null && log.taskId > 0) {
                                Text(
                                    text = "TASK REFERENCE: #${log.taskId}",
                                    fontSize = 10.sp,
                                    color = Color(0xFFB87333),
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = log.details,
                                fontSize = 12.sp,
                                color = Color(0xFF848482)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}
