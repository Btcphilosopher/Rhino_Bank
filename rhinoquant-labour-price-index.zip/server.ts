import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

// Standard initialization of Gemini AI with correct telemetries
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const PORT = 3000;

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes - Always registered before Vite middleware
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  // Secure economic intelligence proxy utilizing Gemini 3.6 Flash
  app.post("/api/gemini/advisor", async (req, res) => {
    try {
      const { 
        region, 
        sector, 
        cpiInflation, 
        interestRate, 
        wageInflationForecast, 
        unemploymentForecast, 
        customTopic, 
        reportType 
      } = req.body;

      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ 
          error: "GEMINI_API_KEY environment variable is not defined in the backend secrets." 
        });
      }

      // Construction of a professional, economically rigorous system prompt
      const systemInstruction = `You are the Chief Quantitative Economist, regional labour market statistician, and Senior Investment Risk Architect at Rhino Bank.
You are writing a highly professional, institutional-grade analytical briefing for the bank's Executive Board, credit underwriters, and regional portfolio managers.
Your style is authoritative, precise, empirical, and rigorous. Do not use generic corporate platitudes, hype words like "supercharge", "empower", or "revolutionary".
Use professional financial terminology (e.g., wage-push inflation, marginal revenue product of labour, labour supply elasticity, debt service coverage ratio, EBITDA compression, capital-labour substitution).
All analyses must ground themselves deeply in Yorkshire and the Humber's economic realities (e.g., manufacturing in South Yorkshire steel mills/advanced engineering, agricultural sectors in North Yorkshire, transport and logistics hubs along the M62 Corridor and Aire Valley in West Yorkshire, and maritime/wind turbine ports in Kingston upon Hull).`;

      let prompt = "";
      if (reportType === "economist_advisor") {
        prompt = `Generate a detailed regional economic analysis briefing addressing:
- Region under review: ${region || "Yorkshire & Humber"}
- Key Industrial Sector: ${sector || "Manufacturing"}
- Selected Macroeconomic Scenarios: CPI Inflation is at ${cpiInflation || "3"}%, Interest Rates are at ${interestRate || "4.5"}%.
- Labour model outcomes: Forecasted Wage Inflation is ${wageInflationForecast || "3.2"}%, and Unemployment is ${unemploymentForecast || "3.8"}%.

Structure your executive response using clean Markdown with these sections:
1. **EXECUTIVE BRIEFING**: A precise 2-paragraph summary of how this macroeconomic scenario affects Yorkshire's overall labour price structure and banking resilience.
2. **LABOUR MARKET DYNAMICS**: Explain localized sector vulnerabilities (e.g. skills bidding, wage premiums, and supply shortages for occupations in ${region}).
3. **RHINO BANK STRATEGIC IMPLICATIONS**: Give exact recommendations for commercial loan positioning, interest rate hedges, and regional sector risk profiles (e.g. should we tighten lending in ${sector}?).
4. **CREDIT ASSESSMENT MITIGANTS**: Specific covenant advice for commercial credit officers evaluating high labour intensity businesses.`;
      } else if (reportType === "credit_assessment") {
        prompt = `Generate a rigorous Commercial Credit Risk Assessment Report for a hypothetical project in:
- Region: ${region || "West Yorkshire"}
- Sector: ${sector || "Logistics"}
- Project Scope: ${customTopic || "Strategic expansion project involving heavy direct-labor investment"}
- Econometric backdrop: LPI wage inflation at ${wageInflationForecast || "3.2"}%, Interest rates at ${interestRate || "4.5"}%.

Provide professional corporate credit advice covering:
1. **LABOUR PRICE INDEX (LPI) RISK DIAGNOSIS**: How wage inflation persistent in this specific region/sector threatens the borrower's EBITDA and interest coverage.
2. **OPERATING CAPACITY ASSESSMENT**: Evaluating labour shortages and recruitment friction risks for the project.
3. **RHINO BANK CREDIT DECISION**: Clear credit recommendation (Approve, Approve with strict conditions, or Decline) with detailed justification.
4. **MANDATED COVENANTS & MITIGANTS**: Specific operational and financial covenants (e.g., DSCR floors, automation targets, capital asset buffers) to impose on the borrower.`;
      } else {
        // Custom interactive query
        prompt = `As Rhino Bank's Chief Economist, answer the following strategic query from our regional investment team:
"${customTopic || "What is the economic impact of the Humber green energy port on local skilled trade wage rates?"}"

Incorporate these statistical parameters if relevant:
- Target Region: ${region || "Kingston upon Hull"}
- Focus Sector: ${sector || "Engineering"}
- Local LPI wage trend: ${wageInflationForecast || "3.2"}%
- Interest rates: ${interestRate || "4.5"}%

Structure your reply in a highly professional, empirical memo format. Do not use self-praise or sales-pitch wording.`;
      }

      // Query Gemini using the modern @google/genai SDK
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.6,
        }
      });

      const adviceText = response.text || "No response generated from the economic advisor.";

      res.json({
        success: true,
        advice: adviceText,
        modelUsed: "gemini-3.6-flash",
        timestamp: new Date().toISOString()
      });

    } catch (err: any) {
      console.error("Gemini Advisor Endpoint Error:", err);
      res.status(500).json({ 
        success: false, 
        error: "Failed to generate AI commentary. Check server logs or Secrets configuration.",
        details: err.message 
      });
    }
  });

  // Serve static assets in production, otherwise Vite handles them
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RhinoQuant Server running on http://0.0.0.0:${PORT} [NODE_ENV=${process.env.NODE_ENV || 'development'}]`);
  });
}

startServer().catch((err) => {
  console.error("Fatal Server Startup Error:", err);
});
