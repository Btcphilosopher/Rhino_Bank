import { useState, useMemo } from "react";
import { DEFAULT_LOAN_PROJECTS, evaluateCreditProject } from "../data/macroData";
import { CreditProject } from "../types";
import { Landmark, TrendingDown, ShieldCheck, HelpCircle, FileText, CheckCircle, AlertTriangle } from "lucide-react";

export default function CreditRiskAssessment() {
  const [selectedProjectId, setSelectedProjectId] = useState<string>("proj-1");
  const [localWageInflation, setLocalWageInflation] = useState<number>(3.5); // annualized simulated trend

  // Active project selection
  const activeProject = useMemo(() => {
    return DEFAULT_LOAN_PROJECTS.find(p => p.id === selectedProjectId) || DEFAULT_LOAN_PROJECTS[0];
  }, [selectedProjectId]);

  // Compute credit report
  const creditReport = useMemo(() => {
    return evaluateCreditProject(activeProject, localWageInflation);
  }, [activeProject, localWageInflation]);

  return (
    <div className="bg-[#161616] border border-[#2A2A2A] rounded-xl p-5 shadow-2xl animate-fade-in" id="credit-risk-assessment-panel">
      <div className="mb-5 pb-3 border-b border-[#2A2A2A] flex justify-between items-start md:items-center flex-col md:flex-row gap-4">
        <div>
          <h3 className="text-lg font-semibold text-white tracking-tight flex items-center gap-2">
            <Landmark className="w-5 h-5 text-[#D97706]" />
            Rhino Bank Credit Risk Assessment Portal
          </h3>
          <p className="text-xs text-[#8E9297]">
            Automated underwriting tool aligning commercial lending project cash flows against local regional LPI volatility.
          </p>
        </div>

        {/* Project Selector */}
        <div className="flex flex-col">
          <label className="text-[9px] text-[#8E9297] font-mono uppercase mb-0.5">Corporate Borrower Project</label>
          <select
            value={selectedProjectId}
            onChange={(e) => setSelectedProjectId(e.target.value)}
            className="bg-[#0F0F0F] border border-[#2A2A2A] rounded px-2.5 py-1.5 text-xs text-[#D1CEBD] font-mono outline-none focus:border-[#D97706]"
          >
            {DEFAULT_LOAN_PROJECTS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} (£{(p.loanAmount / 1000000).toFixed(1)}M)
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Project Technical parameters */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0F0F0F] border border-[#2A2A2A] rounded-lg p-4 font-mono text-xs space-y-3">
            <h4 className="text-[10px] font-bold text-[#8E9297] uppercase tracking-wider border-b border-[#2A2A2A] pb-2 mb-2">
              Project Parameters & Underwriting Metrics
            </h4>

            <div>
              <span className="text-[#8E9297] text-[10px] block uppercase">PROJECT SCOPE</span>
              <p className="text-[#D1CEBD] font-sans text-xs mt-1 leading-relaxed">
                {activeProject.description}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <span className="text-[#8E9297] text-[9px] block">LOAN PRINCIPAL</span>
                <span className="text-[#D1CEBD] font-bold text-sm">£{activeProject.loanAmount.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-[#8E9297] text-[9px] block">LOAN TERM / RATE</span>
                <span className="text-[#D1CEBD] font-bold text-sm">{activeProject.termYears} Yrs @ {activeProject.requestedInterestRate}%</span>
              </div>
              <div>
                <span className="text-[#8E9297] text-[9px] block">LABOUR INTENSITY</span>
                <span className="text-[#D97706] font-bold text-sm">{activeProject.labourIntensityPct}% of revenue</span>
              </div>
              <div>
                <span className="text-[#8E9297] text-[9px] block">LPI ELASTICITY Coefficient</span>
                <span className="text-blue-400 font-bold text-sm">{activeProject.estimatedLpiElasticity.toFixed(2)}</span>
              </div>
            </div>

            {/* Simulated Local Wage Inflation slide trigger */}
            <div className="border-t border-[#2A2A2A] pt-3 mt-2 space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#8E9297]">Simulated Annual Wage Trend:</span>
                <span className="text-[#D97706] font-bold">{localWageInflation.toFixed(1)}%</span>
              </div>
              <input 
                type="range" 
                min="1.0" 
                max="10.0" 
                step="0.1" 
                value={localWageInflation} 
                onChange={(e) => setLocalWageInflation(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-[#2A2A2A] rounded-lg appearance-none cursor-pointer accent-[#D97706]"
              />
              <div className="flex justify-between text-[9px] text-[#8E9297] font-sans">
                <span>1.0% (Stable Costs)</span>
                <span>10.0% (Severe Wage Spiral)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Real-time Risk Calculations, credit decision & required covenants */}
        <div className="lg:col-span-7 flex flex-col justify-between gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* LPI risk score card */}
            <div className="bg-[#0F0F0F] p-4 border border-[#2A2A2A] rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[9px] text-[#8E9297] font-mono uppercase block">LPI Exposure Risk Score</span>
                <span className={`text-3xl font-black font-mono mt-1 block ${
                  creditReport.lpiRiskScore > 70 ? "text-red-500" : creditReport.lpiRiskScore > 45 ? "text-yellow-500" : "text-green-500"
                }`}>
                  {creditReport.lpiRiskScore} <span className="text-xs text-[#8E9297] font-normal">/ 100</span>
                </span>
                <span className="text-[10px] text-[#8E9297] font-sans mt-0.5 block">Sensitivity of cash to wage hikes.</span>
              </div>
              <div className="shrink-0 p-3 bg-[#161616] border border-[#2A2A2A] rounded-lg">
                <FileText className={`w-6 h-6 ${
                  creditReport.lpiRiskScore > 70 ? "text-red-500 animate-pulse" : creditReport.lpiRiskScore > 45 ? "text-yellow-500" : "text-green-500"
                }`} />
              </div>
            </div>

            {/* Operating cash flow EBITDA impact */}
            <div className="bg-[#0F0F0F] p-4 border border-[#2A2A2A] rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[9px] text-[#8E9297] font-mono uppercase block">Est. Annual EBITDA Impact</span>
                <span className="text-2xl font-black text-red-400 font-mono mt-1 block">
                  -£{Math.abs(creditReport.labourCostImpact).toLocaleString()}
                </span>
                <span className="text-[10px] text-[#8E9297] font-sans mt-0.5 block">Incremental wage cost exposure.</span>
              </div>
              <div className="shrink-0 p-3 bg-[#161616] border border-[#2A2A2A] rounded-lg">
                <TrendingDown className="w-6 h-6 text-red-400" />
              </div>
            </div>
          </div>

          {/* Underwriter Recommendation Hud */}
          <div className="bg-[#0F0F0F] border border-[#2A2A2A] rounded-lg p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-2.5 mb-3">
              <span className="text-xs font-mono font-semibold text-[#8E9297]">RHINO UNDERWRITER DECISION:</span>
              <span className={`px-3 py-1 text-xs font-mono uppercase font-bold rounded-full ${
                creditReport.recommendation === "Approve" 
                  ? "bg-green-950/40 text-green-400 border border-green-800/40" 
                  : creditReport.recommendation === "Approve with Covenants"
                  ? "bg-yellow-950/40 text-yellow-400 border border-yellow-800/40"
                  : "bg-red-950/40 text-red-400 border border-red-800/40"
              }`}>
                {creditReport.recommendation}
              </span>
            </div>

            <p className="text-xs text-[#D1CEBD] italic font-serif leading-relaxed px-1 border-l-2 border-[#D97706]/40 py-0.5">
              &ldquo;{creditReport.comments}&rdquo;
            </p>

            {/* Imposed Credit Covenants */}
            <div className="mt-4">
              <span className="text-[10px] text-[#8E9297] font-mono uppercase block mb-2 font-bold">Mandated Credit Covenants & Risk Mitigants:</span>
              <ul className="space-y-1.5">
                {creditReport.keyMitigants.map((mit, i) => (
                  <li key={i} className="text-[11px] text-[#D1CEBD] flex items-start gap-1.5 font-sans leading-relaxed">
                    <span className="text-[#D97706] font-bold text-xs shrink-0 mt-0.5">▪</span>
                    <span>{mit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
