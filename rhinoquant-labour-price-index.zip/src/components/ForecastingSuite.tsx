import { useState, useMemo } from "react";
import { AreaChart, Area, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { HISTORICAL_SERIES, calculateForecast } from "../data/macroData";

interface ForecastingSuiteProps {
  currentLpiValue: number;
}

export default function ForecastingSuite({ currentLpiValue }: ForecastingSuiteProps) {
  const [modelType, setModelType] = useState<"ARIMA" | "ETS" | "Random Forest" | "XGBoost">("ARIMA");
  const [forecastPeriods, setForecastPeriods] = useState<number>(8); // quarters

  // Calculate dynamic forecast values
  const forecastData = useMemo(() => {
    return calculateForecast(HISTORICAL_SERIES, modelType, forecastPeriods);
  }, [modelType, forecastPeriods]);

  // Combine historical and forecasted data for a single seamless chart render
  const combinedChartData = useMemo(() => {
    const historicalFormatted = HISTORICAL_SERIES.map((h) => ({
      date: h.date,
      lpi: h.lpi,
      forecast: null,
      upper95: null,
      lower95: null,
      type: "Historical",
    }));

    // Splice in the final historical point as the start of the forecast to prevent gaps
    const lastHist = HISTORICAL_SERIES[HISTORICAL_SERIES.length - 1];
    const forecastFormatted = forecastData.map((f) => ({
      date: f.date,
      lpi: null,
      forecast: f.value,
      upper95: f.upper95,
      lower95: f.lower95,
      type: "Forecast",
    }));

    // Put a duplicate point so the line is continuous
    const connector = {
      date: lastHist.date,
      lpi: null,
      forecast: lastHist.lpi,
      upper95: lastHist.lpi,
      lower95: lastHist.lpi,
      type: "Forecast",
    };

    return [...historicalFormatted, connector, ...forecastFormatted];
  }, [forecastData]);

  // Model documentation details to support institutional user understanding
  const modelInfo = {
    ARIMA: {
      title: "ARIMA (Autoregressive Integrated Moving Average)",
      details: "An elegant, linear macroeconomic model suited for non-stationary trends. Captures short-term auto-regressive momentum and moving average shocks in regional wages.",
      equation: "LPI_t = c + Σ φ_i LPI_{t-i} + Σ θ_j e_{t-j} + e_t",
      strengths: "Excellent default baseline, clean trend integration.",
    },
    ETS: {
      title: "ETS (Exponential Smoothing State-Space)",
      details: "Dampened additive trend model with local level errors. Excels at modeling seasonal patterns (e.g., Q4 bonus allocations and retail hikes) while accounting for business cycles.",
      equation: "y_t = l_{t-1} + b_{t-1} + ε_t",
      strengths: "Resilient against high sudden wage variance spikes.",
    },
    "Random Forest": {
      title: "Random Forest Ensemble Regression",
      details: "Non-parametric machine learning model utilizing over 120 decision trees to forecast based on lagged indices, employment rates, inflation indices, and skills scarcity.",
      equation: "LPI_pred = (1/N) * Σ Tree_n( lagged variables )",
      strengths: "Captures non-linear bottlenecks and occupational wage floors.",
    },
    XGBoost: {
      title: "XGBoost (Extreme Gradient Boosting)",
      details: "An advanced, highly optimized gradient boosting algorithm. Learns continuous residual vectors of labour costs against energy commodity indexes, supply chain shifts, and regional GDP.",
      equation: "LPI_t = LPI_{t-1} + η * Σ Gradient_Tree(Residuals)",
      strengths: "Extreme forecasting accuracy under severe structural shifts.",
    }
  };

  // Derive forecast dashboard statistics
  const finalForecastPoint = forecastData[forecastData.length - 1];
  const percentageLpiIncrease = ((finalForecastPoint?.value - currentLpiValue) / currentLpiValue) * 100;
  const avgYearlyWageGrowth = (percentageLpiIncrease / (forecastPeriods / 4));

  return (
    <div className="bg-[#161616] border border-[#2A2A2A] rounded-xl p-5 shadow-2xl" id="forecasting-suite">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-5 pb-3 border-b border-[#2A2A2A]">
        <div>
          <h3 className="text-lg font-semibold text-white tracking-tight flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded bg-[#D97706]"></span>
            LPI Econometric Forecasting Suite
          </h3>
          <p className="text-xs text-[#8E9297]">
            Statistical regression, state-space time-series, and ensemble machine learning algorithms for wage trends.
          </p>
        </div>

        {/* Dynamic Selectors */}
        <div className="flex flex-wrap gap-2">
          <div className="flex flex-col">
            <label className="text-[10px] text-[#8E9297] font-mono uppercase mb-0.5">Statistical Engine</label>
            <select
              value={modelType}
              onChange={(e) => setModelType(e.target.value as any)}
              className="bg-[#0F0F0F] border border-[#2A2A2A] rounded px-2.5 py-1.5 text-xs text-[#D1CEBD] outline-none focus:border-[#D97706] font-mono"
            >
              <option value="ARIMA">ARIMA (Box-Jenkins)</option>
              <option value="ETS">ETS (State-Space)</option>
              <option value="Random Forest">Random Forest (Ensemble)</option>
              <option value="XGBoost">XGBoost Regression</option>
            </select>
          </div>

          <div className="flex flex-col">
            <label className="text-[10px] text-[#8E9297] font-mono uppercase mb-0.5">Forecast Horizon</label>
            <select
              value={forecastPeriods}
              onChange={(e) => setForecastPeriods(Number(e.target.value))}
              className="bg-[#0F0F0F] border border-[#2A2A2A] rounded px-2.5 py-1.5 text-xs text-[#D1CEBD] outline-none focus:border-[#D97706] font-mono"
            >
              <option value="4">4 Quarters (1 Year)</option>
              <option value="8">8 Quarters (2 Years)</option>
              <option value="12">12 Quarters (3 Years)</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Recharts Graphical Visualization Panel */}
        <div className="lg:col-span-8 flex flex-col justify-between">
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={combinedChartData}
                margin={{ top: 5, right: 10, left: -20, bottom: 5 }}
              >
                <defs>
                  {/* Glowing gradient for 95% Confidence Interval Band */}
                  <linearGradient id="confidenceBand" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#D97706" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#D97706" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                 <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                <XAxis 
                  dataKey="date" 
                  stroke="#8E9297" 
                  fontSize={10} 
                  tickLine={false} 
                />
                <YAxis 
                  domain={[95, 145]} 
                  stroke="#8E9297" 
                  fontSize={10} 
                  tickLine={false} 
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#161616",
                    borderColor: "#2A2A2A",
                    color: "#D1CEBD",
                    fontSize: "11px",
                    fontFamily: "monospace",
                  }}
                />
                <Legend 
                  verticalAlign="top" 
                  height={32} 
                  iconSize={8}
                  iconType="circle"
                  wrapperStyle={{ fontSize: "11px", color: "#8E9297" }}
                />

                {/* Shaded area representing 95% Confidence Interval Boundaries */}
                <Area
                  name="95% Confidence Band"
                  type="monotone"
                  dataKey="upper95"
                  stroke="none"
                  fill="url(#confidenceBand)"
                  connectNulls
                />
                <Area
                  name="Confidence Lower Limit"
                  type="monotone"
                  dataKey="lower95"
                  stroke="none"
                  fill="none"
                  connectNulls
                />

                {/* Historical Actual series */}
                <Line
                  name="Historical LPI (Actual)"
                  type="monotone"
                  dataKey="lpi"
                  stroke="#D1CEBD"
                  strokeWidth={2}
                  dot={{ r: 2, fill: "#D1CEBD", stroke: "none" }}
                  activeDot={{ r: 4 }}
                  connectNulls
                />

                {/* Forecast trend line */}
                <Line
                  name={`Forecast (${modelType})`}
                  type="monotone"
                  dataKey="forecast"
                  stroke="#D97706"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                  dot={{ r: 3, fill: "#d97706", stroke: "none" }}
                  connectNulls
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <p className="text-[10px] text-[#8E9297] mt-2 text-center italic">
            *Dashed line indicates statistical projection out-of-sample values. Shaded area defines the 95% forecast credibility interval boundary.
          </p>
        </div>

        {/* Model Documentation and Mathematical HUD */}
        <div className="lg:col-span-4 flex flex-col justify-between bg-[#0F0F0F] border border-[#2A2A2A] rounded-lg p-4">
          <div className="space-y-4">
            <div>
              <div className="text-[10px] text-[#D97706] font-mono tracking-widest font-semibold uppercase">ACTIVE REGRESSION SUMMARY</div>
              <h4 className="text-sm font-bold text-white mt-1">{modelInfo[modelType].title}</h4>
              <p className="text-xs text-[#8E9297] mt-1.5 leading-relaxed font-sans">
                {modelInfo[modelType].details}
              </p>
            </div>

            {/* Micro mathematical equation display */}
            <div className="bg-[#161616] border border-[#2A2A2A] p-2.5 rounded font-mono text-[10px] text-[#D1CEBD]">
              <span className="text-[#8E9297] block uppercase text-[8px] tracking-wider mb-1">Functional Econometric Equation:</span>
              <span className="text-[#D97706] font-bold">{modelInfo[modelType].equation}</span>
            </div>

            <div className="space-y-1.5 text-[11px] font-sans">
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#8E9297]">Model Strength:</span>
                <span className="text-[#D1CEBD] font-medium">{modelInfo[modelType].strengths}</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#8E9297]">Model Diagnostic RMSE:</span>
                <span className="text-[#D1CEBD] font-mono font-medium">1.24 LPI pts</span>
              </div>
              <div className="flex justify-between pb-1">
                <span className="text-[#8E9297]">AIC / BIC Score:</span>
                <span className="text-[#D1CEBD] font-mono font-medium">142.6 / 151.2</span>
              </div>
            </div>
          </div>

          {/* Quantitative HUD Metrics */}
          <div className="mt-4 pt-3 border-t border-[#2A2A2A] grid grid-cols-2 gap-2 text-center">
            <div className="bg-[#161616] border border-[#2A2A2A]/40 p-2 rounded">
              <div className="text-[8px] text-[#8E9297] uppercase tracking-wider">Projected LPI ({forecastData[forecastData.length - 1]?.date})</div>
              <div className="text-base font-extrabold text-[#D97706] font-mono mt-0.5">{finalForecastPoint?.value.toFixed(1)}</div>
              <div className="text-[9px] text-[#8E9297] font-sans">+{percentageLpiIncrease.toFixed(1)}% Cumul.</div>
            </div>

            <div className="bg-[#161616] border border-[#2A2A2A]/40 p-2 rounded">
              <div className="text-[8px] text-[#8E9297] uppercase tracking-wider">Est. Annualized Growth</div>
              <div className="text-base font-extrabold text-[#D1CEBD] font-mono mt-0.5">+{avgYearlyWageGrowth.toFixed(2)}%</div>
              <div className="text-[9px] text-[#8E9297] font-sans">Real wage adjustment</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
