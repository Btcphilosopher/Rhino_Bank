import { useState, useMemo } from "react";
import { evaluateScenario } from "../data/macroData";
import { Sliders, HelpCircle, AlertTriangle, CheckCircle2, TrendingUp, DollarSign } from "lucide-react";

export default function ScenarioModeller() {
  // Scenario Factor Sliders
  const [cpiInflation, setCpiInflation] = useState<number>(3.2); // BoE standard target is 2.0%
  const [interestRate, setInterestRate] = useState<number>(4.5);
  const [housePriceGrowth, setHousePriceGrowth] = useState<number>(3.0);
  const [businessInvestment, setBusinessInvestment] = useState<number>(100);
  const [gdpGrowth, setGdpGrowth] = useState<number>(1.2);

  // Compute regression outputs
  const scenarioResult = useMemo(() => {
    return evaluateScenario({
      cpiInflation,
      interestRate,
      housePriceGrowth,
      businessInvestment,
      gdpGrowth,
    });
  }, [cpiInflation, interestRate, housePriceGrowth, businessInvestment, gdpGrowth]);

  // Specific elasticities for visual feedback
  const elasticities = [
    { factor: "CPI Wage-Price Feed", value: 1.15, desc: "Wage index response per +1% inflation", type: "Positive" },
    { factor: "Financing Cost / Rates", value: -0.65, desc: "Hiring cooling impact per +1% interest rate", type: "Negative" },
    { factor: "Regional GDP Growth", value: 0.45, desc: "Wages push per +1% regional output increase", type: "Positive" },
    { factor: "Business Investment", value: 0.35, desc: "Skills hiring premium per +10 index points", type: "Positive" },
    { factor: "House Price Wealth Effect", value: 0.15, desc: "Cost-of-living demand side pull factor", type: "Positive" },
  ];

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-2xl" id="economic-modelling-scenario">
      <div className="mb-5 pb-3 border-b border-neutral-800">
        <h3 className="text-lg font-semibold text-neutral-100 tracking-tight flex items-center gap-2">
          <Sliders className="w-5 h-5 text-amber-500" />
          Macroeconomic Scenario Modeller & Elasticity Engine
        </h3>
        <p className="text-xs text-neutral-400">
          Simulate how changes in monetary policy, inflation spikes, and regional GDP fluctuations feed into the Labour Price Index (LPI) using multivariate elasticity formulas.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders Input Controls */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-neutral-950 p-4 border border-neutral-800 rounded-lg space-y-4">
            <h4 className="text-xs font-bold font-mono text-neutral-400 uppercase tracking-wider mb-2">Macroeconomic Input Matrix</h4>
            
            {/* CPI Inflation */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">CPI Consumer Prices:</span>
                <span className="text-amber-500 font-bold">{cpiInflation.toFixed(1)}%</span>
              </div>
              <input 
                type="range" 
                min="0.5" 
                max="10.0" 
                step="0.1" 
                value={cpiInflation} 
                onChange={(e) => setCpiInflation(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[9px] text-neutral-500">
                <span>0.5% (Deflationary)</span>
                <span>10.0% (Severe Spiral)</span>
              </div>
            </div>

            {/* BoE Base Rates */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Bank of England Base Rate:</span>
                <span className="text-neutral-200 font-bold">{interestRate.toFixed(2)}%</span>
              </div>
              <input 
                type="range" 
                min="1.0" 
                max="8.0" 
                step="0.25" 
                value={interestRate} 
                onChange={(e) => setInterestRate(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[9px] text-neutral-500">
                <span>1.0% (Ultra Low)</span>
                <span>8.0% (Heavy Restrictive)</span>
              </div>
            </div>

            {/* Regional GDP Growth */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Yorkshire GDP Growth:</span>
                <span className="text-blue-400 font-bold">{gdpGrowth.toFixed(1)}%</span>
              </div>
              <input 
                type="range" 
                min="-3.0" 
                max="5.0" 
                step="0.1" 
                value={gdpGrowth} 
                onChange={(e) => setGdpGrowth(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[9px] text-neutral-500">
                <span>-3.0% (Recession)</span>
                <span>5.0% (Boom Profile)</span>
              </div>
            </div>

            {/* Business Investment Index */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Corporate Capex/Investment Index:</span>
                <span className="text-neutral-200 font-bold">{businessInvestment} <span className="text-[10px] text-neutral-500">pts</span></span>
              </div>
              <input 
                type="range" 
                min="50" 
                max="150" 
                step="5" 
                value={businessInvestment} 
                onChange={(e) => setBusinessInvestment(parseInt(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[9px] text-neutral-500">
                <span>50 (Risk Averse)</span>
                <span>150 (High Automation)</span>
              </div>
            </div>

            {/* House Prices */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Yorkshire House Price Growth:</span>
                <span className="text-neutral-200 font-bold">{housePriceGrowth.toFixed(1)}%</span>
              </div>
              <input 
                type="range" 
                min="-5.0" 
                max="12.0" 
                step="0.5" 
                value={housePriceGrowth} 
                onChange={(e) => setHousePriceGrowth(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[9px] text-neutral-500">
                <span>-5% (Asset Slump)</span>
                <span>12% (Housing Boom)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Simulation Outputs HUD */}
        <div className="lg:col-span-7 flex flex-col justify-between gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* LPI Forecast Box */}
            <div className="bg-neutral-950 p-4 border border-neutral-800 rounded-lg text-center flex flex-col justify-between">
              <span className="text-[10px] text-neutral-500 font-mono uppercase">Scenario LPI Value</span>
              <div className="text-2xl font-black text-amber-500 font-mono my-2">{scenarioResult.forecastLPI.toFixed(1)}</div>
              <p className="text-[10px] text-neutral-400 font-sans leading-tight">
                Index baseline deviation of <span className="text-amber-500 font-semibold font-mono">{(scenarioResult.forecastLPI - 131.5).toFixed(1)}</span> pts.
              </p>
            </div>

            {/* Wage Inflation Forecast Box */}
            <div className="bg-neutral-950 p-4 border border-neutral-800 rounded-lg text-center flex flex-col justify-between">
              <span className="text-[10px] text-neutral-500 font-mono uppercase">Wage Inflation YOY</span>
              <div className="text-2xl font-black text-neutral-200 font-mono my-2">{scenarioResult.wageInflationForecast.toFixed(1)}%</div>
              <p className="text-[10px] text-neutral-400 font-sans leading-tight">
                Reflects localized bidding and salary adjustments.
              </p>
            </div>

            {/* Unemployment Forecast Box */}
            <div className="bg-neutral-950 p-4 border border-neutral-800 rounded-lg text-center flex flex-col justify-between">
              <span className="text-[10px] text-neutral-500 font-mono uppercase">Unemployment Rate</span>
              <div className="text-2xl font-black text-blue-400 font-mono my-2">{scenarioResult.unemploymentForecast.toFixed(1)}%</div>
              <p className="text-[10px] text-neutral-400 font-sans leading-tight">
                Reflects corporate capacity, layoffs, or shortage loads.
              </p>
            </div>
          </div>

          {/* AI Advisor Risk Warning Panel */}
          <div className={`p-4 rounded-lg border flex gap-3 ${
            scenarioResult.wageInflationForecast > 5.5 
              ? "bg-red-950/20 border-red-900/40 text-red-200" 
              : scenarioResult.unemploymentForecast > 5.5
              ? "bg-yellow-950/20 border-yellow-900/40 text-yellow-200"
              : "bg-green-950/20 border-green-900/40 text-green-200"
          }`}>
            <div className="shrink-0 mt-0.5">
              {scenarioResult.wageInflationForecast > 5.5 ? (
                <AlertTriangle className="w-5 h-5 text-red-500" />
              ) : (
                <CheckCircle2 className={`w-5 h-5 ${scenarioResult.unemploymentForecast > 5.5 ? "text-yellow-500" : "text-green-500"}`} />
              )}
            </div>
            <div>
              <div className="text-xs font-bold font-mono tracking-wider uppercase mb-0.5">RHINO QUANT RISK ADVISORY</div>
              <p className="text-xs leading-relaxed font-sans">{scenarioResult.riskAssessment}</p>
            </div>
          </div>

          {/* Elasticity Regression Coefficients Details */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-lg p-4 font-mono text-xs">
            <h4 className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider border-b border-neutral-800 pb-2 mb-3">
              Econometric Regression Coefficients (Elasticity matrix)
            </h4>
            <div className="space-y-2">
              {elasticities.map((el) => (
                <div key={el.factor} className="flex justify-between items-center text-[11px]">
                  <div>
                    <span className="text-neutral-300 font-semibold">{el.factor}</span>
                    <span className="text-neutral-500 text-[10px] block font-sans mt-0.5">{el.desc}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      el.value > 0 ? "bg-green-950/40 text-green-400" : "bg-red-950/40 text-red-400"
                    }`}>
                      {el.value > 0 ? "+" : ""}{el.value.toFixed(2)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
