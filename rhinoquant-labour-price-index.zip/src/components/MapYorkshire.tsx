import { REGIONS_METADATA } from "../data/macroData";

interface MapYorkshireProps {
  selectedRegion: string;
  onSelectRegion: (region: string) => void;
  lpiMetrics: Record<string, { avgWage: number; vacancies: number; productivity: number; lpi: number }>;
}

export default function MapYorkshire({ selectedRegion, onSelectRegion, lpiMetrics }: MapYorkshireProps) {
  // SVG regions paths designed to align perfectly like a geographical puzzle
  // Rendered on a 500x400 coordinate space
  const regionsPaths = [
    {
      id: "North Yorkshire",
      name: "North Yorkshire",
      path: "M 50,50 L 300,30 L 450,110 L 320,180 L 250,150 L 150,160 Z",
      labelX: 220,
      labelY: 90,
      colorClass: "fill-stone-800/80 stroke-stone-500 hover:fill-amber-900/40",
      activeColorClass: "fill-amber-900/50 stroke-amber-500 shadow-lg",
      cities: "York, Harrogate, Harrogate Spa, Scarborough, Selby",
    },
    {
      id: "West Yorkshire",
      name: "West Yorkshire",
      path: "M 150,160 L 250,150 L 290,200 L 270,250 L 120,240 L 110,190 Z",
      labelX: 190,
      labelY: 200,
      colorClass: "fill-slate-800/80 stroke-slate-500 hover:fill-blue-900/40",
      activeColorClass: "fill-blue-950/60 stroke-blue-500",
      cities: "Leeds, Bradford, Wakefield, Huddersfield, Halifax",
    },
    {
      id: "South Yorkshire",
      name: "South Yorkshire",
      path: "M 120,240 L 270,250 L 310,290 L 280,340 L 160,330 L 140,290 Z",
      labelX: 220,
      labelY: 295,
      colorClass: "fill-neutral-800/80 stroke-neutral-500 hover:fill-copper-900/40",
      activeColorClass: "fill-amber-950/60 stroke-amber-600",
      cities: "Sheffield, Doncaster, Rotherham, Barnsley",
    },
    {
      id: "East Riding of Yorkshire",
      name: "East Riding",
      path: "M 320,180 L 450,110 L 480,180 L 410,240 L 310,210 Z",
      labelX: 390,
      labelY: 175,
      colorClass: "fill-zinc-800/80 stroke-zinc-500 hover:fill-orange-950/40",
      activeColorClass: "fill-amber-950/50 stroke-amber-500",
      cities: "Beverley, Bridlington, Goole",
    },
    {
      id: "Kingston upon Hull",
      name: "Hull",
      path: "M 410,240 L 480,180 L 490,220 L 430,260 Z",
      labelX: 450,
      labelY: 235,
      colorClass: "fill-yellow-950/40 stroke-yellow-600/60 hover:fill-amber-900/60",
      activeColorClass: "fill-amber-950/80 stroke-amber-400",
      cities: "Hull City, Port & Docks, Sutton",
    }
  ];

  return (
    <div className="bg-[#161616] border border-[#2A2A2A] rounded-xl p-5 shadow-2xl relative overflow-hidden" id="gis-mapping-module">
      {/* Visual Design Elements: Yorkshire Rose Motif Watermark */}
      <div className="absolute top-2 right-2 opacity-5 pointer-events-none">
        <svg width="150" height="150" viewBox="0 0 100 100" className="text-white fill-current">
          <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="2" fill="none" />
          <path d="M 50 10 C 35 15, 20 30, 15 50 C 20 70, 35 85, 50 90 C 65 85, 80 70, 85 50 C 80 30, 65 15, 50 10 Z" stroke="currentColor" strokeWidth="1" fill="none" />
          <circle cx="50" cy="50" r="15" fill="none" stroke="currentColor" strokeWidth="1" />
        </svg>
      </div>

      <div className="mb-4">
        <h3 className="text-lg font-semibold text-white tracking-tight flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#D97706] animate-pulse"></span>
          Geographic GIS Intelligence Map
        </h3>
        <p className="text-xs text-[#8E9297]">
          Interactive LPI heat mapping. Select a region below to drill down into sub-regional indicators, enterprise zones, and urban clusters.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* SVG Interactive Canvas */}
        <div className="lg:col-span-7 flex justify-center bg-[#0F0F0F]/50 rounded-lg p-3 border border-[#2A2A2A]/40">
          <svg viewBox="0 0 520 380" className="w-full h-auto max-h-[340px] select-none">
            {/* Legend Overlay */}
            <g transform="translate(15, 300)" className="text-[10px] fill-[#8E9297]">
              <rect width="12" height="12" className="fill-blue-950/60 stroke-blue-500" />
              <text x="18" y="10" className="fill-[#D1CEBD]">West Yorks (Finance Hub)</text>

              <rect y="16" width="12" height="12" className="fill-[#D97706]/20 stroke-[#D97706]" />
              <text x="18" y="26" className="fill-[#D1CEBD]">South Yorks (Engineering)</text>

              <rect y="32" width="12" height="12" className="fill-yellow-950/40 stroke-yellow-500/60" />
              <text x="18" y="42" className="fill-[#D1CEBD]">Port of Hull (Offshore Green)</text>
            </g>

            {/* Render Puzzle Pieces */}
            {regionsPaths.map((reg) => {
              const isActive = selectedRegion === reg.id;
              const metric = lpiMetrics[reg.id] || { lpi: 100, avgWage: 15 };
              // Calculate dynamic heatmap style based on active state or values
              return (
                <g key={reg.id} className="cursor-pointer group" onClick={() => onSelectRegion(reg.id)}>
                  {/* Outer glow for active region */}
                  {isActive && (
                    <path
                      d={reg.path}
                      className="fill-none stroke-amber-500/30 stroke-[8px] animate-pulse"
                    />
                  )}
                  
                  {/* Primary shape */}
                  <path
                    d={reg.path}
                    className={`transition-all duration-300 stroke-[1.5px] ${
                      isActive 
                        ? reg.id === "West Yorkshire" ? "fill-blue-900/60 stroke-blue-400" :
                          reg.id === "South Yorkshire" ? "fill-[#D97706]/20 stroke-[#D97706]" :
                          reg.id === "Kingston upon Hull" ? "fill-yellow-900/80 stroke-yellow-400" :
                          "fill-[#D97706]/10 stroke-[#D97706]"
                        : "fill-[#1A1A1A] stroke-[#2A2A2A] group-hover:fill-[#222222] group-hover:stroke-[#8E9297]"
                    }`}
                  />

                  {/* Micro Marker Dot for Key Cities */}
                  <circle 
                    cx={reg.labelX} 
                    cy={reg.labelY + 8} 
                    r={isActive ? 4 : 2.5} 
                    className={`${isActive ? "fill-[#D97706] animate-ping" : "fill-[#8E9297]"}`} 
                  />

                  {/* Name Label */}
                  <text
                    x={reg.labelX}
                    y={reg.labelY - 5}
                    textAnchor="middle"
                    className={`text-[10px] font-bold tracking-tight transition-all pointer-events-none ${
                      isActive ? "fill-[#D97706] font-bold text-[11px]" : "fill-[#D1CEBD] group-hover:fill-white"
                    }`}
                  >
                    {reg.name}
                  </text>
                  
                  {/* LPI value badge beneath */}
                  <text
                    x={reg.labelX}
                    y={reg.labelY + 22}
                    textAnchor="middle"
                    className={`text-[9px] pointer-events-none font-medium ${
                      isActive ? "fill-white font-bold" : "fill-[#8E9297]"
                    }`}
                  >
                    LPI: {metric.lpi.toFixed(1)}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected Region Detailed Profile HUD */}
        <div className="lg:col-span-5 self-stretch flex flex-col justify-between bg-[#0F0F0F] border border-[#2A2A2A] rounded-lg p-4 font-mono text-xs">
          {(() => {
            const meta = REGIONS_METADATA.find(r => r.name === selectedRegion) || REGIONS_METADATA[0];
            const metrics = lpiMetrics[selectedRegion] || { avgWage: 18.5, vacancies: 1500, productivity: 110.2, lpi: 126.4 };
            return (
              <div className="flex flex-col h-full justify-between gap-4">
                {/* Header */}
                <div className="border-b border-[#2A2A2A] pb-2">
                  <div className="text-[#D97706] text-[10px] tracking-widest font-bold">REGIONAL TELEMETRY // ACTIVE</div>
                  <div className="text-lg font-bold text-white uppercase tracking-tight font-sans mt-0.5">{meta.name}</div>
                </div>

                {/* Sub-Regional Cities Grid */}
                <div>
                  <div className="text-[#8E9297] text-[9px] uppercase tracking-wider mb-1">Key Urban Clusters & Wards:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {meta.cities.map((city) => (
                      <span key={city} className="px-2 py-0.5 bg-[#161616] border border-[#2A2A2A] text-[#D1CEBD] rounded text-[10px] hover:border-[#D97706]/30 transition-colors">
                        {city}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Economic Stats Index Values */}
                <div className="space-y-2 py-1 bg-[#161616]/30 p-2.5 rounded border border-[#2A2A2A]/40">
                  <div className="flex justify-between items-center">
                    <span className="text-[#8E9297]">Labour Price Index (LPI):</span>
                    <span className="text-[#D97706] font-bold">{metrics.lpi.toFixed(1)} <span className="text-[10px] font-normal text-[#8E9297]">pts</span></span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[#8E9297]">Hourly Wage (Average):</span>
                    <span className="text-[#D1CEBD]">£{metrics.avgWage.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[#8E9297]">Total Active Vacancies:</span>
                    <span className="text-[#D1CEBD]">{metrics.vacancies.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[#8E9297]">Productivity (Output/Hr):</span>
                    <span className="text-blue-400 font-semibold">{metrics.productivity.toFixed(1)} <span className="text-[10px] text-[#8E9297]">idx</span></span>
                  </div>
                </div>

                {/* Enterprise Zones Info */}
                <div>
                  <div className="text-[#8E9297] text-[9px] uppercase tracking-wider mb-1">Active Enterprise Zones:</div>
                  <div className="text-xs font-sans text-[#D1CEBD] leading-relaxed bg-[#D97706]/10 border border-[#D97706]/30 rounded p-2 text-[11px]">
                    <span className="font-bold text-[#D97706]">Zone Focus:</span> {meta.enterpriseZones.join(", ")}
                    <p className="text-[10px] text-[#8E9297] mt-1 font-mono">
                      Eligible for regional tax incentives, accelerating strategic business capital intensity and labour utilization.
                    </p>
                  </div>
                </div>

                {/* Action Trigger info */}
                <div className="text-[10px] text-[#8E9297] text-center italic mt-auto border-t border-[#2A2A2A]/50 pt-2 font-sans">
                  *Click other sectors on the SVG map to switch target datasets.
                </div>
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
}
