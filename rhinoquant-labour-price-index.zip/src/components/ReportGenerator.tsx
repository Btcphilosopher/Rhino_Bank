import { useState } from "react";
import { FileText, Download, Play, Square, Loader, Sparkles, Volume2, VolumeX, AlertTriangle } from "lucide-react";

interface ReportGeneratorProps {
  selectedRegion: string;
  selectedSector: string;
  wageInflation: number;
  unemployment: number;
}

export default function ReportGenerator({ selectedRegion, selectedSector, wageInflation, unemployment }: ReportGeneratorProps) {
  const [reportType, setReportType] = useState<"economist_advisor" | "credit_assessment" | "custom">("economist_advisor");
  const [customTopic, setCustomTopic] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [advisorContent, setAdvisorContent] = useState<string | null>(null);
  
  // TTS State
  const [speaking, setSpeaking] = useState<boolean>(false);
  const [utterance, setUtterance] = useState<SpeechSynthesisUtterance | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  // Standard corporate presets
  const reportPresets = [
    { title: "Daily Market Summary", format: "PDF", size: "145 KB", code: "DMS-2026" },
    { title: "Weekly Labour Bulletin", format: "Excel", size: "1.2 MB", code: "WLB-WK31" },
    { title: "Monthly Wage Inflation Report", format: "PowerPoint", size: "4.8 MB", code: "MWR-JUL26" },
    { title: "Regional Yorkshire Labour Review", format: "PDF", size: "2.4 MB", code: "RYR-2026-Q2" },
    { title: "Advanced Manufacturing Productivity Briefing", format: "PDF", size: "890 KB", code: "AMPB-2026" }
  ];

  // Call Express API route which acts as our proxy to the Gemini model
  const generateBoardBriefing = async () => {
    setLoading(true);
    setAdvisorContent(null);
    stopAudioBriefing();

    try {
      const response = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          region: selectedRegion,
          sector: selectedSector,
          wageInflationForecast: wageInflation,
          unemploymentForecast: unemployment,
          customTopic: customTopic,
          reportType: reportType
        })
      });

      const data = await response.json();
      if (data.success) {
        setAdvisorContent(data.advice);
      } else {
        setAdvisorContent(`### API Error\nFailed to query the Chief Economist. Reason: ${data.error || "Unknown Error"}`);
      }
    } catch (err: any) {
      setAdvisorContent(`### Connection Error\nCould not connect to the RhinoBank API proxy. Details: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Safe Custom Markdown Parser to avoid React 19 peer-dependency breaks
  const renderMarkdown = (text: string) => {
    if (!text) return null;
    const lines = text.split("\n");
    return lines.map((line, i) => {
      // Headers
      if (line.startsWith("### ")) {
        return <h5 key={i} className="text-sm font-bold font-mono text-[#D97706] uppercase tracking-wider mt-4 mb-2">{line.slice(4)}</h5>;
      }
      if (line.startsWith("## ")) {
        return <h4 key={i} className="text-base font-bold text-white border-b border-[#2A2A2A] pb-1 mt-5 mb-2.5 font-sans uppercase tracking-tight">{line.slice(3)}</h4>;
      }
      if (line.startsWith("# ")) {
        return <h3 key={i} className="text-lg font-black text-white mt-6 mb-3 font-sans tracking-tight uppercase border-b-2 border-[#D97706]/30 pb-1.5">{line.slice(2)}</h3>;
      }
      
      // Bullet points
      if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
        const itemContent = line.replace(/^[\s\-\*]+/, "");
        return (
          <li key={i} className="text-xs text-[#D1CEBD] ml-4 list-disc list-inside leading-relaxed mb-1.5 font-sans">
            {parseInlineStyling(itemContent)}
          </li>
        );
      }

      // Ordered Lists
      if (/^\d+\.\s/.test(line.trim())) {
        const itemContent = line.replace(/^\d+\.\s+/, "");
        const num = line.match(/^\d+/)![0];
        return (
          <div key={i} className="text-xs text-[#D1CEBD] flex items-start gap-2 leading-relaxed mb-2 mt-2 font-sans pl-2">
            <span className="text-[#D97706] font-bold font-mono shrink-0">{num}.</span>
            <span>{parseInlineStyling(itemContent)}</span>
          </div>
        );
      }

      // Simple blank line
      if (line.trim() === "") {
        return <div key={i} className="h-2" />;
      }

      // Fallback Paragraph
      return (
        <p key={i} className="text-xs text-[#D1CEBD] leading-relaxed mb-3 font-sans">
          {parseInlineStyling(line)}
        </p>
      );
    });
  };

  const parseInlineStyling = (text: string) => {
    // Basic bold parsing **text**
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, index) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return <strong key={index} className="text-[#D97706] font-bold">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  // Browser-native speech synthesis to read economist briefs out loud
  const triggerAudioBriefing = () => {
    if (!advisorContent) return;

    if (speaking) {
      stopAudioBriefing();
      return;
    }

    // Strip Markdown symbols for a clean oral narration
    const speakText = advisorContent
      .replace(/[#\*_\[\]\(\)\-\d\.\:]/g, "")
      .replace(/\n+/g, " ")
      .slice(0, 1000); // safety length cap for web speech

    const newUtterance = new SpeechSynthesisUtterance(speakText);
    newUtterance.rate = 1.0;
    newUtterance.pitch = 1.0;
    
    // Attempt to locate a high-quality British English voice for Rhino Bank authenticity
    const voices = window.speechSynthesis.getVoices();
    const ukVoice = voices.find(v => v.lang.includes("GB") || v.lang.includes("UK"));
    if (ukVoice) {
      newUtterance.voice = ukVoice;
    }

    newUtterance.onend = () => {
      setSpeaking(false);
    };

    newUtterance.onerror = () => {
      setSpeaking(false);
    };

    setUtterance(newUtterance);
    setSpeaking(true);
    window.speechSynthesis.speak(newUtterance);
  };

  const stopAudioBriefing = () => {
    window.speechSynthesis.cancel();
    setSpeaking(false);
  };

  // Dynamic file export triggers
  const downloadReportPreset = (title: string, code: string) => {
    // Generate simulated CSV file of historical data as a sample download
    const csvContent = "data:text/csv;charset=utf-8,RhinoQuant Institutional Labor Report\nReport Title," + title + "\nCode," + code + "\nRegion," + selectedRegion + "\nSector," + selectedSector + "\nAnnual Wage Inflation Simulated," + wageInflation + "%\nUnemployment Estimated," + unemployment + "%\nGenerated Timestamp," + new Date().toISOString();
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `${code}_rhino_quant.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-[#161616] border border-[#2A2A2A] rounded-xl p-5 shadow-2xl" id="executive-reporting-engine">
      <div className="mb-5 pb-3 border-b border-[#2A2A2A]">
        <h3 className="text-lg font-semibold text-white tracking-tight flex items-center gap-2">
          <FileText className="w-5 h-5 text-[#D97706]" />
          Executive Economic Briefing & AI Advisor
        </h3>
        <p className="text-xs text-[#8E9297]">
          Access pre-compiled statutory ONS indices or leverage our server-side LLM advisor to generate customized banking briefings.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Statutory presets & AI parameterization form */}
        <div className="lg:col-span-5 space-y-4">
          {/* Statutory download dashboard presets */}
          <div className="bg-[#0F0F0F] p-4 border border-[#2A2A2A] rounded-lg space-y-3">
            <h4 className="text-xs font-bold font-mono text-[#8E9297] uppercase tracking-wider mb-1.5">Statutory Presets & Bulletins</h4>
            <div className="space-y-2">
              {reportPresets.map((preset) => (
                <div key={preset.code} className="flex justify-between items-center bg-[#161616] border border-[#2A2A2A]/60 p-2 rounded text-xs">
                  <div className="flex flex-col">
                    <span className="text-[#D1CEBD] font-medium font-sans">{preset.title}</span>
                    <span className="text-[10px] text-[#8E9297] font-mono mt-0.5">{preset.code} • {preset.format} ({preset.size})</span>
                  </div>
                  <button 
                    onClick={() => downloadReportPreset(preset.title, preset.code)}
                    className="p-1.5 hover:bg-[#0F0F0F] border border-[#2A2A2A] rounded text-[#8E9297] hover:text-[#D97706] transition-colors cursor-pointer"
                    title="Export File"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Dynamic AI brief triggers */}
          <div className="bg-[#0F0F0F] p-4 border border-[#2A2A2A] rounded-lg space-y-3">
            <h4 className="text-xs font-bold font-mono text-[#8E9297] uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#D97706]" />
              AI Chief Economist Advisor
            </h4>

            <div className="space-y-1">
              <label className="text-[9px] text-[#8E9297] font-mono uppercase">Briefing Objective</label>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => setReportType("economist_advisor")}
                  className={`px-2 py-1.5 text-[10px] font-mono border rounded cursor-pointer ${
                    reportType === "economist_advisor" ? "bg-[#D97706]/10 text-[#D97706] border-[#D97706]/50 font-bold" : "bg-[#161616] text-[#8E9297] border-[#2A2A2A]"
                  }`}
                >
                  Regional Overview
                </button>
                <button
                  type="button"
                  onClick={() => setReportType("credit_assessment")}
                  className={`px-2 py-1.5 text-[10px] font-mono border rounded cursor-pointer ${
                    reportType === "credit_assessment" ? "bg-[#D97706]/10 text-[#D97706] border-[#D97706]/50 font-bold" : "bg-[#161616] text-[#8E9297] border-[#2A2A2A]"
                  }`}
                >
                  Credit Underwriting
                </button>
                <button
                  type="button"
                  onClick={() => setReportType("custom")}
                  className={`px-2 py-1.5 text-[10px] font-mono border rounded cursor-pointer ${
                    reportType === "custom" ? "bg-[#D97706]/10 text-[#D97706] border-[#D97706]/50 font-bold" : "bg-[#161616] text-[#8E9297] border-[#2A2A2A]"
                  }`}
                >
                  Custom Memo
                </button>
              </div>
            </div>

            {/* If Custom Query is active show text box */}
            {reportType === "custom" && (
              <div className="space-y-1">
                <label className="text-[9px] text-[#8E9297] font-mono uppercase">Strategic Focus Query</label>
                <textarea
                  value={customTopic}
                  onChange={(e) => setCustomTopic(e.target.value)}
                  placeholder="e.g. Impact of AI coders on Sheffield tech salaries..."
                  className="w-full bg-[#161616] border border-[#2A2A2A] rounded p-2 text-xs text-[#D1CEBD] outline-none focus:border-[#D97706] font-sans"
                  rows={2}
                />
              </div>
            )}

            {/* If credit risk selected allow specialized parameterization input */}
            {reportType === "credit_assessment" && (
              <div className="space-y-1">
                <label className="text-[9px] text-[#8E9297] font-mono uppercase">Borrower Project Objective</label>
                <input
                  type="text"
                  value={customTopic}
                  onChange={(e) => setCustomTopic(e.target.value)}
                  placeholder="e.g. Leeds logistics hub expansion project"
                  className="w-full bg-[#161616] border border-[#2A2A2A] rounded px-2 py-1.5 text-xs text-[#D1CEBD] outline-none focus:border-[#D97706]"
                />
              </div>
            )}

            <button
              onClick={generateBoardBriefing}
              disabled={loading}
              className="w-full py-2 bg-[#D97706] hover:bg-amber-500 disabled:bg-[#161616] disabled:text-[#8E9297] text-neutral-900 text-xs font-bold rounded flex items-center justify-center gap-2 transition-colors font-mono cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader className="w-4 h-4 animate-spin text-neutral-900" />
                  Calculating Econometric Factors...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-neutral-900" />
                  Generate Strategic Briefing
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Beautiful rendered Editorial Briefing Panel */}
        <div className="lg:col-span-7 bg-[#0F0F0F] border border-[#2A2A2A] rounded-lg p-5 overflow-y-auto max-h-[460px] flex flex-col justify-between">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-full py-12 text-center text-[#8E9297] font-mono text-xs gap-3">
              <Loader className="w-8 h-8 text-[#D97706] animate-spin" />
              <div className="space-y-1">
                <p className="text-[#D1CEBD] font-semibold uppercase tracking-wider text-[10px]">LPI Model Alignment Active</p>
                <p className="text-[10px]">Basing econometric variables in {selectedRegion}...</p>
                <p className="text-[10px] italic">"Evaluating wage-push factors against corporate cash portfolios..."</p>
              </div>
            </div>
          ) : advisorContent ? (
            <div className="space-y-4">
              {/* Controls panel: Play audio narration, Copy Text, etc. */}
              <div className="flex justify-between items-center border-b border-[#2A2A2A] pb-2 mb-2">
                <span className="text-[9px] text-[#8E9297] font-mono uppercase tracking-widest">CHIEF ADVISOR BOARD BRIEFING</span>
                
                <div className="flex gap-2">
                  {/* TTS Narrator button */}
                  <button
                    onClick={triggerAudioBriefing}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-mono font-bold border transition-colors cursor-pointer ${
                      speaking 
                        ? "bg-red-950/40 text-red-400 border-red-800/40 hover:bg-red-900/40" 
                        : "bg-[#D97706]/10 text-[#D97706] border-[#D97706]/40 hover:bg-[#D97706]/20"
                    }`}
                    title={speaking ? "Stop Audio" : "Listen Out Loud"}
                  >
                    {speaking ? (
                      <>
                        <VolumeX className="w-3.5 h-3.5" />
                        STOP
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5" />
                        LISTEN (TTS)
                      </>
                    )}
                  </button>

                  {/* Copy button */}
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(advisorContent);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="px-2 py-1 text-[10px] font-mono text-[#8E9297] hover:text-white border border-[#2A2A2A] hover:border-[#D97706]/50 bg-[#161616] rounded cursor-pointer"
                  >
                    {copied ? "COPIED!" : "COPY RAW"}
                  </button>
                </div>
              </div>

              {/* Rendered content */}
              <div className="prose prose-invert prose-xs max-w-none text-left">
                {renderMarkdown(advisorContent)}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full py-12 text-center text-[#8E9297] font-mono text-xs gap-2">
              <Sparkles className="w-8 h-8 text-neutral-700 mb-2 animate-pulse" />
              <p className="text-[#D1CEBD] font-semibold uppercase tracking-wider text-[10px]">Economic Simulation Engine Ready</p>
              <p className="max-w-xs text-center text-[10px] leading-relaxed text-[#8E9297] mt-1">
                Click the "Generate Strategic Briefing" button on the left to activate Gemini and receive expert banking commentary modeled against current stats.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
