export interface WageRecord {
  year: number;
  quarter: number;
  region: string; // North Yorkshire, West Yorkshire, South Yorkshire, East Riding, Hull
  localAuthority: string;
  sector: string; // Manufacturing, Engineering, Construction, Healthcare, Finance, etc.
  occupation: string;
  avgHourlyWage: number;
  medianWage: number;
  weeklyEarnings: number;
  annualSalary: number;
  overtimeRate: number;
  bonusRate: number;
  contractorRate: number;
  vacancyCount: number;
  productivityIndex: number; // Output per hour (indexed, 2021=100)
}

export interface HistoricalSeries {
  date: string; // YYYY-MM
  lpi: number; // Labour Price Index (2021-Q1 = 100)
  nominalWage: number;
  realWage: number;
  wageInflationYoy: number;
  productivity: number;
  vacancies: number;
  gdpIndex: number;
}

export interface SkillPremium {
  skill: string;
  category: string;
  baseHourly: number;
  premiumPct: number; // Premium compared to regional base
  demandLevel: "High" | "Medium" | "Low";
  shortageIndex: number; // 1-10 scale
}

export interface EconomicFactors {
  interestRate: number; // %
  cpiInflation: number; // %
  housePriceGrowth: number; // %
  businessInvestment: number; // index
  gdpGrowth: number; // %
}

export interface ScenarioResult {
  factors: EconomicFactors;
  forecastLPI: number;
  wageInflationForecast: number;
  unemploymentForecast: number;
  riskAssessment: string;
}

export interface CreditProject {
  id: string;
  name: string;
  sector: string;
  region: string;
  loanAmount: number; // in GBP
  termYears: number;
  requestedInterestRate: number;
  labourIntensityPct: number; // wage bill as % of revenue
  estimatedLpiElasticity: number; // sensitivity of project margins to LPI increase
  description: string;
}

export interface CreditRiskReport {
  project: CreditProject;
  lpiRiskScore: number; // 1 to 100
  labourCostImpact: number; // estimated change in EBITDA
  recommendation: "Approve" | "Approve with Covenants" | "Decline";
  keyMitigants: string[];
  comments: string;
}
