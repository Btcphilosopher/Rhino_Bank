import { useState, useMemo } from "react";
import { 
  Activity, 
  Map, 
  BrainCircuit, 
  Sliders, 
  Landmark, 
  FileText, 
  TrendingUp, 
  Coins, 
  Compass, 
  Hammer, 
  AlertTriangle,
  Info,
  Layers,
  Search
} from "lucide-react";

import MapYorkshire from "./components/MapYorkshire";
import ForecastingSuite from "./components/ForecastingSuite";
import ScenarioModeller from "./components/ScenarioModeller";
import CreditRiskAssessment from "./components/CreditRiskAssessment";
import ReportGenerator from "./components/ReportGenerator";
import { HISTORICAL_SERIES, GRANULAR_WAGE_RECORDS, SKILL_PREMIUMS, REGIONS_METADATA } from "./data/macroData";

export default function App() {
  // Main dashboard selected state coordinates
  const [selectedRegion, setSelectedRegion] = useState<string>("West Yorkshire");
  const [selectedSector, setSelectedSector] = useState<string>("Finance & Fintech");
  const [activeTab, setActiveTab] = useState<"gis" | "forecast" | "scenario" | "credit" | "skills" | "reports">("gis");
  const [skillSearchQuery, setSkillSearchQuery] = useState<string>("");

  // Memoize aggregated metrics per region dynamically
  const regionMetrics = useMemo(() => {
    const metrics: Record<string, { avgWage: number; vacancies: number; productivity: number; lpi: number }> = {};
    
    REGIONS_METADATA.forEach((reg) => {
      // Filter records in our DB corresponding to the target region
      const records = GRANULAR_WAGE_RECORDS.filter((r) => r.region === reg.name);
      
      const avgWage = records.length > 0
        ? records.reduce((sum, r) => sum + r.avgHourlyWage, 0) / records.length
        : reg.baseHourly;

      const vacancies = records.length > 0
        ? records.reduce((sum, r) => sum + r.vacancyCount, 0)
        : Math.round(reg.lpiWeight * 15000);

      const productivity = records.length > 0
        ? records.reduce((sum, r) => sum + r.productivityIndex, 0) / records.length
        : 110.0;

      // Local LPI index is weighted on baseline 131.5
      const lpi = 131.5 * (avgWage / 18.5) * (1 + (vacancies / 25000));

      metrics[reg.name] = {
        avgWage: Math.round(avgWage * 100) / 100,
        vacancies,
        productivity: Math.round(productivity * 10) / 10,
        lpi: Math.round(lpi * 10) / 10,
      };
    });

    return metrics;
  }, []);

  // Filter skills list based on user search queries
  const filteredSkills = useMemo(() => {
    if (!skillSearchQuery) return SKILL_PREMIUMS;
    return SKILL_PREMIUMS.filter((sk) => 
      sk.skill.toLowerCase().includes(skillSearchQuery.toLowerCase()) ||
      sk.category.toLowerCase().includes(skillSearchQuery.toLowerCase())
    );
  }, [skillSearchQuery]);

  // General active metrics
  const activeLpiValue = regionMetrics[selectedRegion]?.lpi || 131.5;
  const activeAvgWageValue = regionMetrics[selectedRegion]?.avgWage || 19.07;
  const activeVacanciesValue = regionMetrics[selectedRegion]?.vacancies || 12700;

  return (
    <div className="min-h-screen bg-[#0F0F0F] text-[#D1CEBD] selection:bg-[#D97706]/30 selection:text-white" id="main-application-stage">
      
      {/* Editorial Corporate Header Panel */}
      <header className="border-b border-[#D97706]/20 bg-[#161616] px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4" id="institutional-header">
        <div className="flex items-center gap-3">
          {/* Logo symbol: Origami style border logo */}
          <div className="w-10 h-10 border-2 border-[#D97706] bg-[#161616] flex items-center justify-center font-bold text-[#D97706] text-xl tracking-tighter shrink-0 relative overflow-hidden">
            <span className="text-[#D97706] font-bold tracking-tighter text-lg z-10 font-mono">RQ</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-semibold uppercase tracking-[0.2em] text-[#FFFFFF]">RhinoQuant <span className="text-[#D97706]">LPI</span></h1>
              <span className="px-2 py-0.5 text-[8px] bg-[#D97706]/20 border border-[#D97706]/30 text-[#D97706] rounded font-mono font-bold uppercase tracking-wider">LPI-v2.6</span>
            </div>
            <p className="text-[10px] text-[#8E9297] font-mono tracking-tight uppercase">Labour Price Index • Regional Financial Intelligence</p>
          </div>
        </div>

        {/* Real-time ONS Database stats connection status */}
        <div className="flex flex-wrap items-center gap-4 text-[10px] font-mono text-[#8E9297] self-stretch md:self-auto justify-between border-t md:border-t-0 border-[#2A2A2A] pt-3 md:pt-0">
          <div className="flex items-center gap-1.5 bg-[#1A1A1A] border border-[#2A2A2A] px-2.5 py-1 rounded">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00FF00]"></span>
            <span className="text-[#00FF00]">CONNECTED // DUCKDB_PRIMARY</span>
          </div>
          <div className="flex items-center gap-1.5 bg-[#1A1A1A] border border-[#2A2A2A] px-2.5 py-1 rounded">
            <span>FORECAST ENGINE:</span>
            <span className="text-[#D97706] font-bold">ARIMA / ETS VAR</span>
          </div>
          <div className="text-[#8E9297] text-right hidden lg:block">
            <span>JULY-AUGUST 2026 EDITION</span>
          </div>
        </div>
      </header>

      {/* Main Quantitative Analytics board */}
      <main className="max-w-[1400px] mx-auto p-6 space-y-6" id="dashboard-workspace">
        
        {/* Headline Executive KPI Matrix */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" id="headline-kpi-matrix">
          
          {/* LPI Index Metric */}
          <div className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-center justify-between shadow-md hover:border-[#D97706]/30 transition-all" id="kpi-card-lpi">
            <div>
              <span className="text-[9px] text-[#8E9297] uppercase tracking-widest font-mono block">Labour Price Index (LPI)</span>
              <div className="text-2xl font-light text-white font-mono mt-1 tracking-tight">
                {activeLpiValue.toFixed(1)} <span className="text-xs text-[#8E9297] font-normal">pts</span>
              </div>
              <span className="text-[10px] text-[#00FF00] font-semibold font-mono flex items-center gap-1 mt-1">
                <TrendingUp className="w-3 h-3 text-[#00FF00]" /> +3.2% YoY Inflation
              </span>
            </div>
            <div className="p-3 bg-[#0F0F0F] rounded-lg border border-[#2A2A2A]">
              <Activity className="w-5 h-5 text-[#D97706]" />
            </div>
          </div>

          {/* Median Wage Hourly */}
          <div className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-center justify-between shadow-md hover:border-[#D97706]/30 transition-all" id="kpi-card-wage">
            <div>
              <span className="text-[9px] text-[#8E9297] uppercase tracking-widest font-mono block">Median Hourly Wage</span>
              <div className="text-2xl font-light text-white font-mono mt-1 tracking-tight">
                £{activeAvgWageValue.toFixed(2)}
              </div>
              <span className="text-[10px] text-[#8E9297] font-sans mt-1 block">
                Average regional cross-section rate
              </span>
            </div>
            <div className="p-3 bg-[#0F0F0F] rounded-lg border border-[#2A2A2A]">
              <Coins className="w-5 h-5 text-[#8E9297]" />
            </div>
          </div>

          {/* Active Job Openings */}
          <div className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-center justify-between shadow-md hover:border-[#D97706]/30 transition-all" id="kpi-card-vacancies">
            <div>
              <span className="text-[9px] text-[#8E9297] uppercase tracking-widest font-mono block">Active Vacancy Load</span>
              <div className="text-2xl font-light text-white font-mono mt-1 tracking-tight">
                {activeVacanciesValue.toLocaleString()}
              </div>
              <span className="text-[10px] text-[#D97706] font-semibold font-mono flex items-center gap-1 mt-1">
                <AlertTriangle className="w-3 h-3 text-[#D97706] shrink-0" /> Skilled Labor Deficit
              </span>
            </div>
            <div className="p-3 bg-[#0F0F0F] rounded-lg border border-[#2A2A2A]">
              <Compass className="w-5 h-5 text-[#D97706]" />
            </div>
          </div>

          {/* Regional Productivity */}
          <div className="bg-[#161616] border border-[#2A2A2A] p-4 rounded-xl flex items-center justify-between shadow-md hover:border-[#D97706]/30 transition-all" id="kpi-card-productivity">
            <div>
              <span className="text-[9px] text-[#8E9297] uppercase tracking-widest font-mono block">Labour Productivity Index</span>
              <div className="text-2xl font-light text-blue-400 font-mono mt-1 tracking-tight">
                {(regionMetrics[selectedRegion]?.productivity || 111.8).toFixed(1)} <span className="text-xs text-[#8E9297] font-normal">pts</span>
              </div>
              <span className="text-[10px] text-[#8E9297] font-sans mt-1 block">
                Output per worker hour (2021=100)
              </span>
            </div>
            <div className="p-3 bg-[#0F0F0F] rounded-lg border border-[#2A2A2A]">
              <Layers className="w-5 h-5 text-blue-500" />
            </div>
          </div>
        </section>

        {/* Tactical controls & tab selections */}
        <section className="bg-[#161616] border border-[#2A2A2A] rounded-xl p-2.5 flex flex-wrap gap-2 items-center justify-between" id="navigation-hud">
          {/* Tabs selectors */}
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveTab("gis")}
              className={`px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "gis" ? "bg-[#D97706] text-black shadow-md font-bold" : "bg-[#0F0F0F] hover:bg-[#1A1A1A] text-[#D1CEBD]"
              }`}
              id="tab-btn-gis"
            >
              <Map className="w-4 h-4" />
              GIS Map (Yorkshire)
            </button>

            <button
              onClick={() => setActiveTab("forecast")}
              className={`px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "forecast" ? "bg-[#D97706] text-black shadow-md font-bold" : "bg-[#0F0F0F] hover:bg-[#1A1A1A] text-[#D1CEBD]"
              }`}
              id="tab-btn-forecast"
            >
              <BrainCircuit className="w-4 h-4" />
              Forecasting Engine
            </button>

            <button
              onClick={() => setActiveTab("scenario")}
              className={`px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "scenario" ? "bg-[#D97706] text-black shadow-md font-bold" : "bg-[#0F0F0F] hover:bg-[#1A1A1A] text-[#D1CEBD]"
              }`}
              id="tab-btn-scenario"
            >
              <Sliders className="w-4 h-4" />
              Scenario Modeller
            </button>

            <button
              onClick={() => setActiveTab("credit")}
              className={`px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "credit" ? "bg-[#D97706] text-black shadow-md font-bold" : "bg-[#0F0F0F] hover:bg-[#1A1A1A] text-[#D1CEBD]"
              }`}
              id="tab-btn-credit"
            >
              <Landmark className="w-4 h-4" />
              Credit Underwriting
            </button>

            <button
              onClick={() => setActiveTab("skills")}
              className={`px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "skills" ? "bg-[#D97706] text-black shadow-md font-bold" : "bg-[#0F0F0F] hover:bg-[#1A1A1A] text-[#D1CEBD]"
              }`}
              id="tab-btn-skills"
            >
              <Hammer className="w-4 h-4" />
              Skills Analytics
            </button>

            <button
              onClick={() => setActiveTab("reports")}
              className={`px-4 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "reports" ? "bg-[#D97706] text-black shadow-md font-bold" : "bg-[#0F0F0F] hover:bg-[#1A1A1A] text-[#D1CEBD]"
              }`}
              id="tab-btn-reports"
            >
              <FileText className="w-4 h-4" />
              Executive Reports (AI)
            </button>
          </div>

          {/* Quick global selectors */}
          <div className="flex items-center gap-2 text-xs font-mono border-l border-[#2A2A2A] pl-4 ml-auto">
            <span className="text-[#8E9297] uppercase text-[9px]">Global Focus:</span>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="bg-[#0F0F0F] border border-[#2A2A2A] text-[#D1CEBD] rounded px-2 py-1 text-xs outline-none focus:border-[#D97706]"
              id="global-region-selector"
            >
              {REGIONS_METADATA.map((r) => (
                <option key={r.name} value={r.name}>{r.name}</option>
              ))}
            </select>
          </div>
        </section>

        {/* Dynamic content rendering container */}
        <section className="transition-all duration-300" id="main-analytics-canvas">
          
          {/* Tab 1: Map and geographic GIS drill-down */}
          {activeTab === "gis" && (
            <MapYorkshire 
              selectedRegion={selectedRegion} 
              onSelectRegion={setSelectedRegion} 
              lpiMetrics={regionMetrics}
            />
          )}

          {/* Tab 2: Econometric Forecasting engine */}
          {activeTab === "forecast" && (
            <ForecastingSuite currentLpiValue={activeLpiValue} />
          )}

          {/* Tab 3: Macro scenario modeller */}
          {activeTab === "scenario" && (
            <ScenarioModeller />
          )}

          {/* Tab 4: Commercial credit loan risks */}
          {activeTab === "credit" && (
            <CreditRiskAssessment />
          )}

          {/* Tab 5: Skill premiums matrix */}
          {activeTab === "skills" && (
            <div className="bg-[#161616] border border-[#2A2A2A] rounded-xl p-5 shadow-2xl space-y-4" id="skills-premium-analytics">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-3 border-b border-[#2A2A2A]">
                <div>
                  <h3 className="text-lg font-semibold text-white tracking-tight flex items-center gap-2">
                    <Hammer className="w-5 h-5 text-[#D97706]" />
                    Workforce Skills Premium Index & Shortage Matrix
                  </h3>
                  <p className="text-xs text-[#8E9297]">
                    Calculated wage premiums and recruitment friction indices across high-value technical and professional skills in Yorkshire.
                  </p>
                </div>

                {/* Filter and Search */}
                <div className="flex items-center gap-2 bg-[#0F0F0F] border border-[#2A2A2A] rounded px-3 py-1.5 text-xs w-full md:w-64">
                  <Search className="w-4 h-4 text-[#8E9297] shrink-0" />
                  <input
                    type="text"
                    value={skillSearchQuery}
                    onChange={(e) => setSkillSearchQuery(e.target.value)}
                    placeholder="Search skills (e.g. welder, nurse)..."
                    className="bg-transparent border-none text-[#D1CEBD] outline-none w-full text-xs"
                  />
                </div>
              </div>

              {/* Grid of skill premiums list */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-[#2A2A2A] text-[10px] text-[#8E9297] uppercase tracking-wider font-mono">
                      <th className="py-3 px-4">Specialized Skill</th>
                      <th className="py-3 px-4">Category Sector</th>
                      <th className="py-3 px-4">Base Hourly Rate</th>
                      <th className="py-3 px-4">Wage Premium %</th>
                      <th className="py-3 px-4">Estimated Premium rate</th>
                      <th className="py-3 px-4 text-center">Recruitment Friction (Shortage)</th>
                      <th className="py-3 px-4 text-right">Labour Demand Load</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredSkills.map((sk) => {
                      const premiumRate = sk.baseHourly * (1 + sk.premiumPct / 100);
                      return (
                        <tr key={sk.skill} className="border-b border-[#2A2A2A]/60 hover:bg-[#0F0F0F]/40 transition-colors">
                          <td className="py-3 px-4 font-semibold text-[#D1CEBD]">{sk.skill}</td>
                          <td className="py-3 px-4 text-[#8E9297]">{sk.category}</td>
                          <td className="py-3 px-4 font-mono">£{sk.baseHourly.toFixed(2)}</td>
                          <td className="py-3 px-4 font-mono text-[#D97706]">+{sk.premiumPct.toFixed(1)}%</td>
                          <td className="py-3 px-4 font-mono font-bold text-[#D1CEBD]">£{premiumRate.toFixed(2)}/hr</td>
                          <td className="py-3 px-4">
                            <div className="flex items-center justify-center gap-1.5">
                              <div className="w-16 bg-[#0F0F0F] h-2 rounded overflow-hidden border border-[#2A2A2A]">
                                <div 
                                  className={`h-full rounded-sm ${
                                    sk.shortageIndex >= 9 ? "bg-red-500" : sk.shortageIndex >= 7 ? "bg-[#D97706]" : "bg-green-500"
                                  }`}
                                  style={{ width: `${sk.shortageIndex * 10}%` }}
                                ></div>
                              </div>
                              <span className="font-mono text-[10px] text-[#8E9297]">{sk.shortageIndex}/10</span>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                              sk.demandLevel === "High" ? "bg-red-950/40 text-red-400 border border-red-800/20" : "bg-[#D97706]/20 text-[#D97706] border border-[#D97706]/20"
                            }`}>
                              {sk.demandLevel}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Tab 6: Executive reports and AI Advisor board briefs */}
          {activeTab === "reports" && (
            <ReportGenerator 
              selectedRegion={selectedRegion}
              selectedSector={selectedSector}
              wageInflation={3.2} // standard Q2 values
              unemployment={3.8}
            />
          )}

        </section>

        {/* Dynamic commentary and regional statistics cross-section feed */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-secondary-panels">
          {/* Left panel: General Economic context feed */}
          <div className="lg:col-span-8 bg-[#161616] border border-[#2A2A2A] rounded-xl p-5 shadow-xl space-y-4">
            <h4 className="text-sm font-bold font-mono text-white uppercase tracking-widest flex items-center gap-2">
              <Info className="w-4 h-4 text-[#D97706]" />
              Empirical Regional Micro-Data Feed (Q2 2026)
            </h4>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#2A2A2A] text-[10px] text-[#8E9297] uppercase tracking-wider font-mono">
                    <th className="py-2.5 px-3">Local Authority</th>
                    <th className="py-2.5 px-3">Sector</th>
                    <th className="py-2.5 px-3">Standard Occupation</th>
                    <th className="py-2.5 px-3">Median Wage</th>
                    <th className="py-2.5 px-3">Annual Salary</th>
                    <th className="py-2.5 px-3">Overtime rate</th>
                    <th className="py-2.5 px-3 text-right">Productivity Index</th>
                  </tr>
                </thead>
                <tbody>
                  {GRANULAR_WAGE_RECORDS.filter(r => r.region === selectedRegion).map((r, idx) => (
                    <tr key={idx} className="border-b border-[#2A2A2A]/40 hover:bg-[#0F0F0F]/30">
                      <td className="py-2 px-3 font-semibold text-[#D1CEBD]">{r.localAuthority}</td>
                      <td className="py-2 px-3 text-[#8E9297]">{r.sector}</td>
                      <td className="py-2 px-3 text-[#D1CEBD]">{r.occupation}</td>
                      <td className="py-2 px-3 font-mono">£{r.medianWage.toFixed(2)}/hr</td>
                      <td className="py-2 px-3 font-mono font-medium text-[#D97706]">£{r.annualSalary.toLocaleString()}</td>
                      <td className="py-2 px-3 font-mono text-[#8E9297]">£{r.overtimeRate.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right text-blue-400 font-mono font-bold">{r.productivityIndex.toFixed(1)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right panel: Static Methodologies and economic parameters */}
          <div className="lg:col-span-4 bg-[#161616] border border-[#2A2A2A] rounded-xl p-5 shadow-xl flex flex-col justify-between gap-4 font-mono text-xs">
            <div>
              <h4 className="text-sm font-bold font-mono text-white uppercase tracking-widest border-b border-[#2A2A2A] pb-2 mb-3">
                System Statistical Methodology
              </h4>
              <p className="font-sans text-[#8E9297] text-xs leading-relaxed mb-3">
                The **RhinoQuant Labour Price Index (LPI)** measures changes in the market cost of a standard basket of labor services across Yorkshire and the Humber. 
              </p>
              <div className="space-y-3">
                <div className="bg-[#0F0F0F] p-3 rounded border border-[#2A2A2A]/60">
                  <span className="text-[#8E9297] text-[9px] block">LPI STANDARD WEIGHTS:</span>
                  <p className="font-sans text-xs text-[#D1CEBD] mt-1 leading-snug">
                    Weighted using ONS Annual Survey of Hours and Earnings (ASHE) GDP proportions: **West Yorks (42%)**, **South Yorks (28%)**, **North Yorks (15%)**, **East Riding (8%)**, and **Hull (7%)**.
                  </p>
                </div>
                <div className="bg-[#0F0F0F] p-3 rounded border border-[#2A2A2A]/60">
                  <span className="text-[#8E9297] text-[9px] block">PRODUCTIVITY COEFFICIENTS:</span>
                  <p className="font-sans text-xs text-[#D1CEBD] mt-1 leading-snug">
                    Adjusted quarterly based on regional output per hour indices, enabling bank analysts to observe real wage inflation relative to economic efficiency.
                  </p>
                </div>
              </div>
            </div>

            <div className="text-[10px] text-[#8E9297] italic font-sans border-t border-[#2A2A2A]/60 pt-3">
              *Designed and constructed entirely in accordance with statutory regional bank risk management procedures. For internal Rhino Bank executive advisory purposes only.
            </div>
          </div>
        </section>

      </main>

      {/* Corporate footer */}
      <footer className="border-t border-[#2A2A2A] bg-[#0A0A0A] py-6 text-center text-[10px] font-mono text-[#8E9297]">
        <p>© 2026 Rhino Bank Financial Systems Group. All rights reserved.</p>
        <p className="mt-1 uppercase text-[#D97706]">CONFIDENTIAL // INTERNAL USE ONLY</p>
      </footer>

    </div>
  );
}
