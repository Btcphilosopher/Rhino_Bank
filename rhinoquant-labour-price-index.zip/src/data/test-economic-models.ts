import { calculateForecast, evaluateScenario, evaluateCreditProject } from "./macroData";
import { HistoricalSeries, CreditProject } from "../types";

// Mini automated test runner mimicking professional testing frameworks
export function runAutomatedEconometricSuite() {
  console.log("=========================================");
  console.log("RHINOQUANT ECO-METRIC AUTOMATED TESTING SUITE");
  console.log("=========================================");

  let passes = 0;
  let failures = 0;

  function assert(condition: boolean, message: string) {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passes++;
    } else {
      console.error(`[FAIL] ${message}`);
      failures++;
    }
  }

  try {
    // Test 1: Forecast Generation (ARIMA vs ETS)
    const dummySeries: HistoricalSeries[] = [
      { date: "2025-03", lpi: 100.0, nominalWage: 15, realWage: 15, wageInflationYoy: 2, productivity: 100, vacancies: 1000, gdpIndex: 100 },
      { date: "2025-06", lpi: 101.5, nominalWage: 15.2, realWage: 15.1, wageInflationYoy: 2.2, productivity: 101, vacancies: 1050, gdpIndex: 101 },
      { date: "2025-09", lpi: 103.0, nominalWage: 15.4, realWage: 15.2, wageInflationYoy: 2.4, productivity: 102, vacancies: 1100, gdpIndex: 102 },
      { date: "2025-12", lpi: 104.5, nominalWage: 15.6, realWage: 15.3, wageInflationYoy: 2.6, productivity: 103, vacancies: 1150, gdpIndex: 103 },
    ];

    const arimaForecast = calculateForecast(dummySeries, "ARIMA", 4);
    assert(arimaForecast.length === 4, "ARIMA forecast produces exact forecasted periods.");
    assert(arimaForecast[0].value > 104.5, "ARIMA forecast correctly captures positive trend momentum.");
    assert(arimaForecast[3].upper95 > arimaForecast[3].value, "Forecast upper confidence limit exceeds baseline forecast values.");

    // Test 2: Multivariate Scenario Planner Elasticities
    const baselineResult = evaluateScenario({
      cpiInflation: 2.0, // baseline
      interestRate: 4.5, // baseline
      housePriceGrowth: 3.0, // baseline
      businessInvestment: 100, // baseline
      gdpGrowth: 1.5, // baseline
    });

    const highInflationResult = evaluateScenario({
      cpiInflation: 5.0, // inflation spike
      interestRate: 4.5,
      housePriceGrowth: 3.0,
      businessInvestment: 100,
      gdpGrowth: 1.5,
    });

    assert(highInflationResult.forecastLPI > baselineResult.forecastLPI, "Wage-price feed-through is positive under high inflation scenarios.");
    assert(highInflationResult.wageInflationForecast > baselineResult.wageInflationForecast, "Scenario correctly reflects elevated nominal wage inflation.");

    // Test 3: Commercial Credit Assessment Exposure scoring
    const sampleProj: CreditProject = {
      id: "test-proj",
      name: "Leeds Warehouse Expansion",
      sector: "Logistics & Transport",
      region: "West Yorkshire",
      loanAmount: 5000000,
      termYears: 10,
      requestedInterestRate: 6.0,
      labourIntensityPct: 50, // high intensity
      estimatedLpiElasticity: 1.2,
      description: "Sample high labor project"
    };

    const riskReportLow = evaluateCreditProject(sampleProj, 2.0); // 2% wage inflation
    const riskReportHigh = evaluateCreditProject(sampleProj, 6.0); // 6% severe wage inflation

    assert(riskReportHigh.lpiRiskScore > riskReportLow.lpiRiskScore, "Project risk score scales upward with elevated local wage inflation.");
    assert(Math.abs(riskReportHigh.labourCostImpact) > Math.abs(riskReportLow.labourCostImpact), "EBITDA wage cost erosion increases with simulated index values.");

    console.log("=========================================");
    console.log(`TEST RESULTS: ${passes} PASSES, ${failures} FAILURES`);
    console.log("=========================================");

  } catch (err: any) {
    console.error("Test execution aborted with error:", err);
  }
}
