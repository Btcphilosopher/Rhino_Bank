import { HistoricalSeries, SkillPremium, WageRecord, CreditProject, CreditRiskReport } from "../types";

// Master List of Regions and their Local Authorities
export const REGIONS_METADATA = [
  {
    name: "West Yorkshire",
    cities: ["Leeds", "Bradford", "Wakefield", "Huddersfield", "Halifax"],
    enterpriseZones: ["Aire Valley Leeds", "M62 Corridor"],
    lpiWeight: 0.42, // West Yorkshire dominates regional GDP
    baseHourly: 16.50,
  },
  {
    name: "South Yorkshire",
    cities: ["Sheffield", "Doncaster", "Rotherham", "Barnsley"],
    enterpriseZones: ["Advanced Manufacturing Park (AMP)", "Markham Vale"],
    lpiWeight: 0.28,
    baseHourly: 15.20,
  },
  {
    name: "North Yorkshire",
    cities: ["York", "Harrogate", "Scarborough", "Ripon"],
    enterpriseZones: ["York Science Park", "Catterick Logistics Hub"],
    lpiWeight: 0.15,
    baseHourly: 15.80,
  },
  {
    name: "East Riding of Yorkshire",
    cities: ["Beverley", "Bridlington", "Goole"],
    enterpriseZones: ["Goole 36 Enterprise Zone"],
    lpiWeight: 0.08,
    baseHourly: 14.60,
  },
  {
    name: "Kingston upon Hull",
    cities: ["Hull City Center", "Docks", "Sutton"],
    enterpriseZones: ["Humber Green Port", "Siemens Gamesa Wind Zone"],
    lpiWeight: 0.07,
    baseHourly: 14.90,
  }
];

// Major Sectors and their average traits
export const SECTORS_METADATA = [
  { name: "Manufacturing", weight: 0.15, productivity: 112, volatility: "Medium" },
  { name: "Engineering", weight: 0.10, productivity: 124, volatility: "High" },
  { name: "Construction", weight: 0.08, productivity: 98, volatility: "High" },
  { name: "Healthcare", weight: 0.12, productivity: 85, volatility: "Low" },
  { name: "Finance & Fintech", weight: 0.09, productivity: 145, volatility: "High" },
  { name: "Education", weight: 0.08, productivity: 90, volatility: "Low" },
  { name: "Logistics & Transport", weight: 0.11, productivity: 105, volatility: "Medium" },
  { name: "Technology", weight: 0.07, productivity: 138, volatility: "High" },
  { name: "Hospitality & Retail", weight: 0.10, productivity: 75, volatility: "Low" },
  { name: "Professional Services", weight: 0.10, productivity: 120, volatility: "Medium" }
];

// Skill Wage Premium Data (RhinoQuant Estimations 2026)
export const SKILL_PREMIUMS: SkillPremium[] = [
  { skill: "Software Engineering (React/Node)", category: "Technology", baseHourly: 24.50, premiumPct: 62.5, demandLevel: "High", shortageIndex: 9 },
  { skill: "Data Analysts (Python/SQL)", category: "Technology", baseHourly: 21.00, premiumPct: 45.0, demandLevel: "High", shortageIndex: 8 },
  { skill: "Precision Welder (ASME IX)", category: "Manufacturing", baseHourly: 16.50, premiumPct: 51.5, demandLevel: "High", shortageIndex: 9 },
  { skill: "High-Voltage Electrician", category: "Construction", baseHourly: 17.00, premiumPct: 48.0, demandLevel: "High", shortageIndex: 8 },
  { skill: "CNC Machine Operator", category: "Manufacturing", baseHourly: 15.00, premiumPct: 22.0, demandLevel: "Medium", shortageIndex: 6 },
  { skill: "Registered Nurse (ICU/Critical Care)", category: "Healthcare", baseHourly: 18.50, premiumPct: 35.0, demandLevel: "High", shortageIndex: 10 },
  { skill: "Consultant Physician", category: "Healthcare", baseHourly: 42.00, premiumPct: 110.0, demandLevel: "High", shortageIndex: 9 },
  { skill: "STEM Secondary Teacher", category: "Education", baseHourly: 19.00, premiumPct: 25.0, demandLevel: "Medium", shortageIndex: 7 },
  { skill: "Senior Corporate Accountant", category: "Finance", baseHourly: 25.00, premiumPct: 55.0, demandLevel: "High", shortageIndex: 7 },
  { skill: "Commercial Solicitor", category: "Professional Services", baseHourly: 30.00, premiumPct: 70.0, demandLevel: "High", shortageIndex: 6 },
  { skill: "HGV Class 1 Driver", category: "Logistics", baseHourly: 14.50, premiumPct: 38.0, demandLevel: "High", shortageIndex: 9 },
  { skill: "Scrum Master & PM", category: "Professional Services", baseHourly: 22.00, premiumPct: 40.0, demandLevel: "Medium", shortageIndex: 5 },
  { skill: "Bricklayer & Mason", category: "Construction", baseHourly: 15.50, premiumPct: 32.0, demandLevel: "High", shortageIndex: 8 }
];

// Historical Series (January 2021 to June 2026)
export const HISTORICAL_SERIES: HistoricalSeries[] = [
  // 2021
  { date: "2021-03", lpi: 100.0, nominalWage: 14.50, realWage: 14.50, wageInflationYoy: 1.8, productivity: 100.0, vacancies: 12500, gdpIndex: 100.0 },
  { date: "2021-06", lpi: 101.2, nominalWage: 14.67, realWage: 14.58, wageInflationYoy: 2.2, productivity: 100.8, vacancies: 13200, gdpIndex: 101.5 },
  { date: "2021-09", lpi: 102.5, nominalWage: 14.86, realWage: 14.65, wageInflationYoy: 2.8, productivity: 101.5, vacancies: 14100, gdpIndex: 102.8 },
  { date: "2021-12", lpi: 103.9, nominalWage: 15.07, realWage: 14.72, wageInflationYoy: 3.9, productivity: 101.9, vacancies: 14900, gdpIndex: 103.9 },
  // 2022 (High inflation spikes LPI)
  { date: "2022-03", lpi: 105.8, nominalWage: 15.34, realWage: 14.68, wageInflationYoy: 5.8, productivity: 102.1, vacancies: 16800, gdpIndex: 104.2 },
  { date: "2022-06", lpi: 107.6, nominalWage: 15.60, realWage: 14.55, wageInflationYoy: 6.3, productivity: 102.4, vacancies: 17500, gdpIndex: 104.8 },
  { date: "2022-09", lpi: 109.9, nominalWage: 15.94, realWage: 14.49, wageInflationYoy: 7.2, productivity: 103.0, vacancies: 18200, gdpIndex: 105.1 },
  { date: "2022-12", lpi: 112.4, nominalWage: 16.30, realWage: 14.50, wageInflationYoy: 8.1, productivity: 103.5, vacancies: 19100, gdpIndex: 105.6 },
  // 2023 (LPI index catches up to inflation)
  { date: "2023-03", lpi: 114.8, nominalWage: 16.65, realWage: 14.63, wageInflationYoy: 8.5, productivity: 103.8, vacancies: 18500, gdpIndex: 105.9 },
  { date: "2023-06", lpi: 116.9, nominalWage: 16.95, realWage: 14.71, wageInflationYoy: 8.6, productivity: 104.2, vacancies: 17900, gdpIndex: 106.3 },
  { date: "2023-09", lpi: 118.7, nominalWage: 17.21, realWage: 14.82, wageInflationYoy: 8.0, productivity: 104.9, vacancies: 17200, gdpIndex: 106.8 },
  { date: "2023-12", lpi: 120.2, nominalWage: 17.43, realWage: 14.96, wageInflationYoy: 6.9, productivity: 105.3, vacancies: 16500, gdpIndex: 107.4 },
  // 2024
  { date: "2024-03", lpi: 121.8, nominalWage: 17.66, realWage: 15.15, wageInflationYoy: 6.1, productivity: 105.8, vacancies: 15800, gdpIndex: 108.1 },
  { date: "2024-06", lpi: 123.1, nominalWage: 17.85, realWage: 15.28, wageInflationYoy: 5.3, productivity: 106.4, vacancies: 15200, gdpIndex: 108.9 },
  { date: "2024-09", lpi: 124.2, nominalWage: 18.01, realWage: 15.39, wageInflationYoy: 4.6, productivity: 107.1, vacancies: 14900, gdpIndex: 109.5 },
  { date: "2024-12", lpi: 125.1, nominalWage: 18.14, realWage: 15.48, wageInflationYoy: 4.1, productivity: 107.8, vacancies: 14400, gdpIndex: 110.1 },
  // 2025
  { date: "2025-03", lpi: 126.3, nominalWage: 18.31, realWage: 15.64, wageInflationYoy: 3.7, productivity: 108.4, vacancies: 14100, gdpIndex: 110.8 },
  { date: "2025-06", lpi: 127.4, nominalWage: 18.47, realWage: 15.76, wageInflationYoy: 3.5, productivity: 109.1, vacancies: 13800, gdpIndex: 111.4 },
  { date: "2025-09", lpi: 128.5, nominalWage: 18.63, realWage: 15.88, wageInflationYoy: 3.4, productivity: 109.9, vacancies: 13500, gdpIndex: 112.2 },
  { date: "2025-12", lpi: 129.4, nominalWage: 18.76, realWage: 15.98, wageInflationYoy: 3.4, productivity: 110.5, vacancies: 13200, gdpIndex: 112.9 },
  // 2026 (Recent data)
  { date: "2026-03", lpi: 130.6, nominalWage: 18.94, realWage: 16.14, wageInflationYoy: 3.4, productivity: 111.2, vacancies: 12900, gdpIndex: 113.5 },
  { date: "2026-06", lpi: 131.5, nominalWage: 19.07, realWage: 16.22, wageInflationYoy: 3.2, productivity: 111.8, vacancies: 12700, gdpIndex: 114.1 }
];

// Mock database of highly realistic granular wage records (cross-sections)
// Generating a structured grid representing actual Yorkshire labour realities in Q2 2026
export const GRANULAR_WAGE_RECORDS: WageRecord[] = [
  // West Yorkshire
  {
    year: 2026, quarter: 2, region: "West Yorkshire", localAuthority: "Leeds",
    sector: "Finance & Fintech", occupation: "Fintech Risk Analyst",
    avgHourlyWage: 28.50, medianWage: 26.20, weeklyEarnings: 1068.75, annualSalary: 55575,
    overtimeRate: 42.75, bonusRate: 5500, contractorRate: 350, vacancyCount: 145, productivityIndex: 138.4
  },
  {
    year: 2026, quarter: 2, region: "West Yorkshire", localAuthority: "Leeds",
    sector: "Logistics & Transport", occupation: "HGV Depo Supervisor",
    avgHourlyWage: 18.20, medianWage: 17.10, weeklyEarnings: 728.00, annualSalary: 37856,
    overtimeRate: 27.30, bonusRate: 1500, contractorRate: 210, vacancyCount: 94, productivityIndex: 109.2
  },
  {
    year: 2026, quarter: 2, region: "West Yorkshire", localAuthority: "Bradford",
    sector: "Manufacturing", occupation: "Textile Machine Weaver",
    avgHourlyWage: 13.80, medianWage: 13.10, weeklyEarnings: 517.50, annualSalary: 26910,
    overtimeRate: 20.70, bonusRate: 400, contractorRate: 160, vacancyCount: 38, productivityIndex: 101.5
  },
  {
    year: 2026, quarter: 2, region: "West Yorkshire", localAuthority: "Huddersfield",
    sector: "Engineering", occupation: "Gearbox Design Engineer",
    avgHourlyWage: 24.80, medianWage: 23.50, weeklyEarnings: 930.00, annualSalary: 48360,
    overtimeRate: 37.20, bonusRate: 3200, contractorRate: 290, vacancyCount: 42, productivityIndex: 118.9
  },

  // South Yorkshire
  {
    year: 2026, quarter: 2, region: "South Yorkshire", localAuthority: "Sheffield",
    sector: "Engineering", occupation: "Additive Manufacturing Metallurgist",
    avgHourlyWage: 27.20, medianWage: 25.80, weeklyEarnings: 1020.00, annualSalary: 53040,
    overtimeRate: 40.80, bonusRate: 4200, contractorRate: 320, vacancyCount: 65, productivityIndex: 129.5
  },
  {
    year: 2026, quarter: 2, region: "South Yorkshire", localAuthority: "Sheffield",
    sector: "Manufacturing", occupation: "Specialist Forging Press Tech",
    avgHourlyWage: 21.40, medianWage: 19.80, weeklyEarnings: 856.00, annualSalary: 44512,
    overtimeRate: 32.10, bonusRate: 2000, contractorRate: 245, vacancyCount: 52, productivityIndex: 116.1
  },
  {
    year: 2026, quarter: 2, region: "South Yorkshire", localAuthority: "Doncaster",
    sector: "Logistics & Transport", occupation: "Rail Freight Yard Director",
    avgHourlyWage: 26.50, medianWage: 24.50, weeklyEarnings: 993.75, annualSalary: 51675,
    overtimeRate: 39.75, bonusRate: 5000, contractorRate: 310, vacancyCount: 48, productivityIndex: 111.0
  },
  {
    year: 2026, quarter: 2, region: "South Yorkshire", localAuthority: "Rotherham",
    sector: "Construction", occupation: "Nuclear Facility Welder",
    avgHourlyWage: 29.80, medianWage: 28.10, weeklyEarnings: 1192.00, annualSalary: 61984,
    overtimeRate: 44.70, bonusRate: 6000, contractorRate: 380, vacancyCount: 31, productivityIndex: 121.3
  },

  // North Yorkshire
  {
    year: 2026, quarter: 2, region: "North Yorkshire", localAuthority: "York",
    sector: "Technology", occupation: "Cybersecurity Analyst",
    avgHourlyWage: 29.10, medianWage: 27.50, weeklyEarnings: 1091.25, annualSalary: 56745,
    overtimeRate: 43.65, bonusRate: 4800, contractorRate: 360, vacancyCount: 78, productivityIndex: 132.7
  },
  {
    year: 2026, quarter: 2, region: "North Yorkshire", localAuthority: "York",
    sector: "Hospitality & Retail", occupation: "Bespoke Chocolatier / Chef",
    avgHourlyWage: 14.20, medianWage: 13.50, weeklyEarnings: 568.00, annualSalary: 29536,
    overtimeRate: 21.30, bonusRate: 500, contractorRate: 175, vacancyCount: 112, productivityIndex: 94.2
  },
  {
    year: 2026, quarter: 2, region: "North Yorkshire", localAuthority: "Harrogate",
    sector: "Healthcare", occupation: "Geriatric Care Clinical Lead",
    avgHourlyWage: 23.50, medianWage: 21.80, weeklyEarnings: 881.25, annualSalary: 45825,
    overtimeRate: 35.25, bonusRate: 1200, contractorRate: 260, vacancyCount: 84, productivityIndex: 102.1
  },

  // East Riding
  {
    year: 2026, quarter: 2, region: "East Riding of Yorkshire", localAuthority: "Beverley",
    sector: "Professional Services", occupation: "Agricultural Land Surveyor",
    avgHourlyWage: 23.90, medianWage: 22.40, weeklyEarnings: 896.25, annualSalary: 46605,
    overtimeRate: 35.85, bonusRate: 2500, contractorRate: 275, vacancyCount: 22, productivityIndex: 108.4
  },
  {
    year: 2026, quarter: 2, region: "East Riding of Yorkshire", localAuthority: "Goole",
    sector: "Logistics & Transport", occupation: "Intermodal Shipping Planner",
    avgHourlyWage: 19.40, medianWage: 18.20, weeklyEarnings: 776.00, annualSalary: 40352,
    overtimeRate: 29.10, bonusRate: 1800, contractorRate: 220, vacancyCount: 46, productivityIndex: 114.3
  },

  // Hull
  {
    year: 2026, quarter: 2, region: "Kingston upon Hull", localAuthority: "Hull",
    sector: "Engineering", occupation: "Wind Turbine Blade Laminator",
    avgHourlyWage: 21.80, medianWage: 20.20, weeklyEarnings: 817.50, annualSalary: 42510,
    overtimeRate: 32.70, bonusRate: 2200, contractorRate: 250, vacancyCount: 120, productivityIndex: 119.5
  },
  {
    year: 2026, quarter: 2, region: "Kingston upon Hull", localAuthority: "Hull",
    sector: "Logistics & Transport", occupation: "Deepsea Cargo Inspector",
    avgHourlyWage: 18.90, medianWage: 17.50, weeklyEarnings: 756.00, annualSalary: 39312,
    overtimeRate: 28.35, bonusRate: 1400, contractorRate: 210, vacancyCount: 54, productivityIndex: 108.1
  }
];

// Default Projects Submitted for Commercial Credit Assessment in Rhino Bank
export const DEFAULT_LOAN_PROJECTS: CreditProject[] = [
  {
    id: "proj-1",
    name: "Humber Green Port Expansion",
    sector: "Logistics & Transport",
    region: "Kingston upon Hull",
    loanAmount: 18500000,
    termYears: 12,
    requestedInterestRate: 6.25,
    labourIntensityPct: 45.0,
    estimatedLpiElasticity: 1.15, // Very sensitive to wage increases due to high labour content
    description: "Construction of a new deepwater terminal berth and autonomous logistics yard to support offshore wind turbine shipping. Will require 240 construction workers and 120 ongoing logistics operators."
  },
  {
    id: "proj-2",
    name: "Leeds South-Bank Tech Cluster Hub",
    sector: "Technology",
    region: "West Yorkshire",
    loanAmount: 24000000,
    termYears: 15,
    requestedInterestRate: 5.75,
    labourIntensityPct: 20.0,
    estimatedLpiElasticity: 0.45, // Low elasticity as high margins can absorb developer rate changes
    description: "Commercial real estate and high-density digital infrastructure for fintech start-ups. Extremely low direct labor operating cost, but highly sensitive to local digital talent density."
  },
  {
    id: "proj-3",
    name: "Doncaster Steel Forging Modernisation",
    sector: "Manufacturing",
    region: "South Yorkshire",
    loanAmount: 8200000,
    termYears: 7,
    requestedInterestRate: 7.00,
    labourIntensityPct: 35.0,
    estimatedLpiElasticity: 0.95, // High sensitivity; operating margins are highly compressed (circa 8%)
    description: "Purchase of high-efficiency robotics presses to replace aging machinery. Project intends to increase capital intensity and reduce labour requirements by 25% while boosting hourly output by 40%."
  },
  {
    id: "proj-4",
    name: "York Bio-Research & Science Lab Phase III",
    sector: "Healthcare",
    region: "North Yorkshire",
    loanAmount: 12500000,
    termYears: 10,
    requestedInterestRate: 6.00,
    labourIntensityPct: 55.0,
    estimatedLpiElasticity: 0.85, // Highly sensitive to specialist nurses and research technician salaries
    description: "Clinical testing facility expansion for biological assays. High reliance on specialized biochemistry skills which are currently facing a critical recruitment shortage in North Yorkshire."
  }
];

// Analytical calculations supporting forecasting and regressions in TypeScript
export function calculateForecast(
  series: HistoricalSeries[],
  modelType: "ARIMA" | "ETS" | "Random Forest" | "XGBoost",
  steps: number = 8 // 8 quarters (2 years)
): { date: string; value: number; upper95: number; lower95: number }[] {
  // Extract recent trend
  const lastLpi = series[series.length - 1].lpi;
  const recentGains = series.slice(-6).map((x, i, arr) => (i > 0 ? x.lpi - arr[i-1].lpi : 0)).slice(1);
  const avgQuarterlyGrowth = recentGains.reduce((a, b) => a + b, 0) / recentGains.length;

  const result: { date: string; value: number; upper95: number; lower95: number }[] = [];
  let currentVal = lastLpi;
  let year = 2026;
  let month = 6; // starts after 2026-06

  // Variance factor depending on the model
  const volatility = modelType === "ARIMA" ? 1.1 : modelType === "ETS" ? 0.9 : modelType === "Random Forest" ? 1.4 : 1.2;

  for (let i = 1; i <= steps; i++) {
    month += 3;
    if (month > 12) {
      month -= 12;
      year += 1;
    }
    const dateStr = `${year}-${month.toString().padStart(2, '0')}`;
    
    // Add realistic cyclicality based on step index
    const cyclicFactor = Math.sin(i * 1.5) * 0.3;
    
    // Growth rates change slightly per model type to simulate forecasting variance
    let stepGrowth = avgQuarterlyGrowth;
    if (modelType === "ETS") {
      stepGrowth = avgQuarterlyGrowth * (1 - (i * 0.05)); // dampening trend
    } else if (modelType === "Random Forest") {
      stepGrowth = avgQuarterlyGrowth * (1 + cyclicFactor); // machine learning learns cyclical patterns
    } else if (modelType === "XGBoost") {
      stepGrowth = avgQuarterlyGrowth * 0.85 + (i % 2 === 0 ? 0.2 : -0.1);
    }

    currentVal += stepGrowth;
    
    // Confidence intervals expand with sqrt(time)
    const confidenceRange = Math.sqrt(i) * 1.5 * volatility;

    result.push({
      date: dateStr,
      value: Math.round(currentVal * 10) / 10,
      upper95: Math.round((currentVal + confidenceRange) * 10) / 10,
      lower95: Math.round((currentVal - confidenceRange) * 10) / 10
    });
  }

  return result;
}

// Interactive Econometric Relationship Engine
// Calculates simulated regression outcome: LPI responsiveness
export function evaluateScenario(
  factors: { interestRate: number; cpiInflation: number; housePriceGrowth: number; businessInvestment: number; gdpGrowth: number }
): { forecastLPI: number; wageInflationForecast: number; unemploymentForecast: number; riskAssessment: string } {
  // Multivariate linear regression simulation matching econometric literature
  // LPI increases with inflation, GDP growth, house price wealth effect, decreases with high interest rates
  const baseLpi = 131.5;
  const deltaInflation = factors.cpiInflation - 2.0; // deviation from 2% target
  const deltaRates = factors.interestRate - 4.5; // deviation from base 4.5%
  const deltaGdp = factors.gdpGrowth - 1.5; // deviation from 1.5% long-term regional growth
  const deltaHouse = factors.housePriceGrowth - 3.0; // deviation from 3% trend
  const deltaInvest = (factors.businessInvestment - 100) / 10; // dev from baseline 100 index

  // Coefficients (elasticities)
  const coeffInflation = 1.15; // highly responsive to general prices (wage-price spiral)
  const coeffRates = -0.65; // higher rates cool hiring and slow wage pressure
  const coeffGdp = 0.45; // stronger GDP increases labor demand
  const coeffHouse = 0.15; // mild positive wealth effect
  const coeffInvest = 0.35; // capital investment increases skill-seeking hiring

  const change = (deltaInflation * coeffInflation) + (deltaRates * coeffRates) + (deltaGdp * coeffGdp) + (deltaHouse * coeffHouse) + (deltaInvest * coeffInvest);
  const forecastLPI = Math.round((baseLpi + change) * 10) / 10;

  // Derive annual wage inflation forecast
  const wageInflationForecast = Math.round((3.2 + (deltaInflation * 0.7) + (deltaRates * -0.3) + (deltaGdp * 0.25)) * 10) / 10;

  // Derive unemployment forecast
  const baseUnemp = 3.8; // 3.8% current regional average
  const unemploymentForecast = Math.max(2.0, Math.round((baseUnemp + (deltaRates * 0.4) - (deltaGdp * 0.5) - (deltaInvest * 0.2)) * 10) / 10);

  // Determine qualitative risk
  let riskAssessment = "Stable Growth Profile. Wage expansion is aligned with productivity gains. Balanced lending environment.";
  if (wageInflationForecast > 5.5) {
    riskAssessment = "HIGH WAGE-PRICE RISK. Severe inflationary spirals identified. Commercial margins will compress. Underwrite project credit with strict cash flow covenants.";
  } else if (unemploymentForecast > 6.0) {
    riskAssessment = "ECONOMIC SLOWDOWN RISK. Weak labor demand. Substantial spare capacity, risk of rising loan delinquencies across consumer-facing and retail portfolios.";
  } else if (factors.interestRate > 6.5) {
    riskAssessment = "MONETARY TIGHTENING SQUEEZE. Extreme financing costs colliding with wage persistence. Major default risk for high-leverage property developers.";
  } else if (wageInflationForecast < 1.5) {
    riskAssessment = "DEFLATIONARY / STAGNANT PROFILE. Sluggish local demand. Low commercial motivation, regional banking strategies should favor capital preservation.";
  }

  return {
    forecastLPI,
    wageInflationForecast,
    unemploymentForecast,
    riskAssessment
  };
}

// Compute loan credit risk assessment based on project traits and current LPI trends
export function evaluateCreditProject(
  project: CreditProject,
  currentLpiTrend: number // annualized inflation trend (e.g. 3.2%)
): CreditRiskReport {
  // LPI Risk score increases with labour intensity, elasticity, and localized premium demands
  let rawScore = 30; // base score
  
  // High labor intensity multiplies risk
  rawScore += (project.labourIntensityPct / 10) * 4;
  
  // High sensitivity to index changes
  rawScore += (project.estimatedLpiElasticity * 20);

  // If local wage trend is elevated
  rawScore += (currentLpiTrend * 2.5);

  // Adjust by sector specific premium risks
  if (project.sector === "Engineering" || project.sector === "Logistics & Transport") {
    rawScore += 10; // sectors facing deep welder/HGV shortages
  } else if (project.sector === "Technology") {
    rawScore -= 5; // offset by massive profit margins
  }

  const lpiRiskScore = Math.min(100, Math.max(1, Math.round(rawScore)));

  // Estimate loan EBITDA impact (negative cash flow change)
  const annualRevEst = project.loanAmount * 0.25; // simple standard asset turnover proxy
  const baseLabourCost = annualRevEst * (project.labourIntensityPct / 100);
  const incrementalLabourCost = baseLabourCost * (currentLpiTrend / 100) * project.estimatedLpiElasticity;
  const labourCostImpact = -Math.round(incrementalLabourCost);

  // Make credit banking recommendation
  let recommendation: "Approve" | "Approve with Covenants" | "Decline" = "Approve";
  const keyMitigants: string[] = [];

  if (lpiRiskScore > 70) {
    recommendation = "Decline";
    keyMitigants.push("Reduce loan-to-value (LTV) below 50% to mitigate capital loss.");
    keyMitigants.push("Require personal/corporate guarantees from parent industrial group.");
  } else if (lpiRiskScore > 45) {
    recommendation = "Approve with Covenants";
    keyMitigants.push("Mandate annual debt-service coverage ratio (DSCR) threshold of 1.35x.");
    keyMitigants.push("Require hedging of interest rates and quarterly labor supply audits.");
    keyMitigants.push("Establish cash sweep mechanism if local LPI inflation exceeds 5%.");
  } else {
    recommendation = "Approve";
    keyMitigants.push("Standard corporate clean covenants.");
    keyMitigants.push("Standard bi-annual economic data reporting.");
  }

  // Comments matching commercial banking voice
  let comments = "";
  if (recommendation === "Decline") {
    comments = `Project exhibits an unsustainable high labour expenditure footprint (${project.labourIntensityPct}%) colliding with severe regional wage pressure in ${project.region}. The debt-servicing capability would deteriorate rapidly under current forecasting trends.`;
  } else if (recommendation === "Approve with Covenants") {
    comments = `Solid underlying commercial fundamentals. However, the high elasticity parameter (${project.estimatedLpiElasticity}) means the borrower's operating margins are vulnerable to localized workforce bidding. Approved subject to structured credit covenants.`;
  } else {
    comments = `Robust defensive profile. Low labour dependency or excellent margin structures. Project is highly bankable under Rhino Bank's regional growth strategy.`;
  }

  return {
    project,
    lpiRiskScore,
    labourCostImpact,
    recommendation,
    keyMitigants,
    comments
  };
}
