export type KilnArchitecture = 'HOFFMANN' | 'TUNNEL' | 'INTERMITTENT';

export type ChamberState = 
  | 'EMPTY'
  | 'LOADING'
  | 'LOADED'
  | 'PREHEATING'
  | 'FIRING'
  | 'SOAK'
  | 'COOLING'
  | 'READY_TO_UNLOAD'
  | 'UNLOADING'
  | 'MAINTENANCE'
  | 'FAULT';

export type FuelType = 'NATURAL_GAS' | 'LPG' | 'HYDROGEN' | 'BIOGAS' | 'BIOMASS_COAL' | 'ELECTRIC';

export interface ProductRecipe {
  id: string;
  name: string;
  category: string;
  densityKgM3: number;
  specificHeatJkgK: number;
  thermalConductivityWmK: number;
  moisturePercent: number;
  firingPeakTempC: number;
  soakDurationHours: number;
  targetStrengthNmm2: number;
  targetAbsorptionPercent: number;
  firingColor: 'PALE' | 'BUFF' | 'ORANGE' | 'RED' | 'DEEP_RED' | 'BROWN' | 'DARK';
  colorHex: string;
}

export interface Chamber {
  id: number;
  name: string;
  state: ChamberState;
  atmosphereTempC: number;
  brickSurfaceTempC: number;
  brickCoreTempC: number;
  moisturePercent: number;
  damperPositionPercent: number;
  fluePressurePa: number;
  gasFlowM3h: number;
  fuelDoseKgH: number;
  refractoryTempC: number;
  refractoryCondition: 'NEW' | 'GOOD' | 'DEGRADED' | 'SEVERE' | 'REPLACE';
  batchId?: string;
  productRecipeId?: string;
  sinteringIndex: number; // 0 to 1
  quartzTransformedPercent: number;
  defectRisk: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  defectType?: 'CRACKING' | 'UNDERFIRING' | 'OVERFIRING' | 'WARPING' | 'COLOUR_VARIATION';
}

export interface TunnelZone {
  id: number;
  name: string;
  type: 'PREHEAT' | 'FIRING' | 'SOAK' | 'COOLING';
  targetTempC: number;
  actualTempC: number;
  burnerPowerPercent: number;
  airflowM3h: number;
  pressurePa: number;
}

export interface KilnCar {
  id: string;
  positionZone: number;
  speedMh: number;
  batchId: string;
  productName: string;
  surfaceTempC: number;
  coreTempC: number;
  massTonnes: number;
}

export interface FiringFrontState {
  activeChamberIndex: number;
  progressPercent: number;
  speedChambersPerDay: number;
  preheatChambers: number[];
  firingChambers: number[];
  coolingChambers: number[];
  loadingChambers: number[];
  totalHeatPowerMW?: number;
}

export interface CombustionState {
  fuelType: FuelType;
  fuelFlowKgH: number;
  lhvMJkg: number;
  thermalInputMW: number;
  excessAirLambda: number;
  stoichAirM3kg: number;
  flameTempC: number;
  co2RateKgH: number;
  co2FactorKgMJ: number;
}

export interface DraughtNetworkState {
  fanRpm: number;
  fanPowerKW: number;
  chimneyStackPressurePa: number;
  totalExhaustFlowM3h: number;
  primaryAirM3h: number;
  secondaryAirM3h: number;
  mainDamperPercent: number;
}

export interface EnergyMetrics {
  fuelInputMW: number;
  usefulProcessHeatMW: number;
  exhaustLossMW: number;
  wallRadiationLossMW: number;
  recoveredToDryerMW: number;
  efficiencyPercent: number;
  kwhPerTonne: number;
  mjPerKg: number;
  co2PerTonne: number;
}

export interface BatchGenealogy {
  batchId: string;
  productName: string;
  recipeId: string;
  claySource: string;
  formingLine: string;
  dryerId: string;
  kilnId: string;
  chambersUsed: string;
  startTimeIso: string;
  peakTempC: number;
  soakHours: number;
  coolingRate: string;
  qualityStatus: 'PASS' | 'WARNING' | 'REJECT';
  defectSummary: string;
  strengthNmm2: number;
  absorptionPercent: number;
  estColour: string;
}

export interface FiringCurvePoint {
  timeHours: number;
  targetTempC: number;
  actualAtmosphereC: number;
  actualSurfaceC: number;
  actualCoreC: number;
  phase: string;
}

export interface TelemetrySnapshot {
  timestamp: string;
  timeOffsetHours: number;
  firingFrontChamber: number;
  peakAtmosphereC: number;
  peakBrickCoreC: number;
  totalFuelMW: number;
  draughtPa: number;
  productionTonneH: number;
  efficiencyPercent: number;
  activeAlarmsCount: number;
  chambers: Chamber[];
}

export interface KilnScenario {
  id: string;
  name: string;
  description: string;
  fuelType?: FuelType;
  damperFailureChamber?: number;
  fanRpmModifier?: number;
  clayMoisturePercent?: number;
  refractoryLeakChamber?: number;
}

export interface AIAnalysisResult {
  summary: string;
  thermalLagAssessment: string;
  defectRisks: { chamberId: number; risk: string; cause: string; recommendation: string }[];
  fuelEfficiencyOptimization: string;
  overallHealthScore: number;
  recommendedActions: string[];
}
