import { ProductRecipe, FuelType, KilnScenario } from './kiln.types';

export const DEFAULT_RECIPES: ProductRecipe[] = [
  {
    id: 'YORKSHIRE_STOCK',
    name: 'Yorkshire Stock Facing Brick',
    category: 'Facing Brick',
    densityKgM3: 1950,
    specificHeatJkgK: 920,
    thermalConductivityWmK: 0.85,
    moisturePercent: 3.5,
    firingPeakTempC: 1080,
    soakDurationHours: 6,
    targetStrengthNmm2: 35,
    targetAbsorptionPercent: 9.5,
    firingColor: 'RED',
    colorHex: '#B93829'
  },
  {
    id: 'ENGINEERING_CLASS_A',
    name: 'Class A Blue Engineering Brick',
    category: 'Engineering Brick',
    densityKgM3: 2300,
    specificHeatJkgK: 880,
    thermalConductivityWmK: 1.1,
    moisturePercent: 2.0,
    firingPeakTempC: 1180,
    soakDurationHours: 10,
    targetStrengthNmm2: 125,
    targetAbsorptionPercent: 4.5,
    firingColor: 'DARK',
    colorHex: '#3F3F46'
  },
  {
    id: 'TERRACOTTA_TILE',
    name: 'Terracotta Architectural Tile',
    category: 'Terracotta',
    densityKgM3: 1850,
    specificHeatJkgK: 950,
    thermalConductivityWmK: 0.72,
    moisturePercent: 4.2,
    firingPeakTempC: 1020,
    soakDurationHours: 4,
    targetStrengthNmm2: 25,
    targetAbsorptionPercent: 12.0,
    firingColor: 'ORANGE',
    colorHex: '#D97706'
  },
  {
    id: 'BUFF_ARCHITECTURAL',
    name: 'Buff Architectural Facing Brick',
    category: 'Architectural Brick',
    densityKgM3: 2050,
    specificHeatJkgK: 900,
    thermalConductivityWmK: 0.90,
    moisturePercent: 2.8,
    firingPeakTempC: 1120,
    soakDurationHours: 8,
    targetStrengthNmm2: 50,
    targetAbsorptionPercent: 7.0,
    firingColor: 'BUFF',
    colorHex: '#D97706'
  },
  {
    id: 'PAVING_BLOCK',
    name: 'Heavy Clay Paving Block',
    category: 'Paving Product',
    densityKgM3: 2200,
    specificHeatJkgK: 890,
    thermalConductivityWmK: 1.05,
    moisturePercent: 2.2,
    firingPeakTempC: 1150,
    soakDurationHours: 8,
    targetStrengthNmm2: 80,
    targetAbsorptionPercent: 6.0,
    firingColor: 'DEEP_RED',
    colorHex: '#881337'
  }
];

export const FUEL_PROPERTIES: Record<FuelType, { name: string; lhvMJkg: number; co2KgPerMJ: number; stoichAirM3kg: number }> = {
  NATURAL_GAS: { name: 'Natural Gas (Methane)', lhvMJkg: 48.0, co2KgPerMJ: 0.056, stoichAirM3kg: 9.52 },
  LPG: { name: 'LPG (Propane/Butane)', lhvMJkg: 46.3, co2KgPerMJ: 0.063, stoichAirM3kg: 12.1 },
  HYDROGEN: { name: 'Green Hydrogen (100% H2)', lhvMJkg: 120.0, co2KgPerMJ: 0.0, stoichAirM3kg: 2.38 },
  BIOGAS: { name: 'Upgraded Biogas', lhvMJkg: 35.0, co2KgPerMJ: 0.012, stoichAirM3kg: 7.2 },
  BIOMASS_COAL: { name: 'Pulverised Coal / Biomass', lhvMJkg: 27.5, co2KgPerMJ: 0.098, stoichAirM3kg: 6.8 },
  ELECTRIC: { name: 'Direct Electric Heating', lhvMJkg: 3.6, co2KgPerMJ: 0.0, stoichAirM3kg: 0.0 }
};

export const PRESET_SCENARIOS: KilnScenario[] = [
  {
    id: 'BASELINE',
    name: 'Baseline Operational State',
    description: 'Optimal firing of Yorkshire Stock facing bricks with balanced draught and uniform stoking.'
  },
  {
    id: 'DAMPER_JAM_CH07',
    name: 'Damper Failure — Chamber 07 Jammed 15%',
    description: 'Chamber 07 exhaust flue damper suffers mechanical failure and restricts airflow, producing local positive pressure and atmosphere stagnation.'
  },
  {
    id: 'HIGH_MOISTURE',
    name: 'High Moisture Green Brick Batch (6.5%)',
    description: 'Incompletely dried green brick batch enters Chamber 02, causing rapid steam generation and severe thermal lag in preheating.'
  },
  {
    id: 'FAN_TRIP',
    name: 'Exhaust Fan Speed Drop (-35%)',
    description: 'Main exhaust fan power fluctuation reduces overall draught pressure from -28 Pa to -12 Pa, causing combustion excess air drop and soot risk.'
  },
  {
    id: 'FAST_COOLING_QUARTZ',
    name: 'Uncontrolled Rapid Cooling (Quartz Crack Risk)',
    description: 'Cold secondary air surge through Chamber 04 forces rapid cooling through 573°C alpha-beta quartz transition threshold (>75°C/h), risking thermal shock cracking.'
  },
  {
    id: 'HYDROGEN_CONVERSION',
    name: 'Electrification & Hydrogen Blend (70% H2)',
    description: 'Switching fuel supply to 70% Green Hydrogen blend. Calculates reduction in carbon emissions, higher water vapor flue content, and flame speed effects.'
  }
];
