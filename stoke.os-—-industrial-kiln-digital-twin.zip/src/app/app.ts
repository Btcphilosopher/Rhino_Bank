import { ChangeDetectionStrategy, Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header';
import { ControlRoomComponent } from './components/control-room/control-room';
import { KilnMapComponent } from './components/kiln-map/kiln-map';
import { Kiln3dTwinComponent } from './components/kiln-3d-twin/kiln-3d-twin';
import { ChamberCrossSectionComponent } from './components/chamber-cross-section/chamber-cross-section';
import { FiringCurveComponent } from './components/firing-curve/firing-curve';
import { ElectrificationLabComponent } from './components/electrification-lab/electrification-lab';
import { QualityGenealogyComponent } from './components/quality-genealogy/quality-genealogy';
import { ScenarioTimeMachineComponent } from './components/scenario-time-machine/scenario-time-machine';
import { AiDiagnosticsComponent } from './components/ai-diagnostics/ai-diagnostics';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderComponent,
    ControlRoomComponent,
    KilnMapComponent,
    Kiln3dTwinComponent,
    ChamberCrossSectionComponent,
    FiringCurveComponent,
    ElectrificationLabComponent,
    QualityGenealogyComponent,
    ScenarioTimeMachineComponent,
    AiDiagnosticsComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  @ViewChild(HeaderComponent) headerComponent!: HeaderComponent;

  get currentTab(): string {
    return this.headerComponent ? this.headerComponent.activeTab : 'CONTROL';
  }
}
