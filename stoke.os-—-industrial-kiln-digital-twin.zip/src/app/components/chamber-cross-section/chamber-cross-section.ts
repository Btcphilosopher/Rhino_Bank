import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';

@Component({
  selector: 'app-chamber-cross-section',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4">
      
      <!-- Top Control Bar -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-amber-500">layers</mat-icon>
            <h2 class="text-base font-bold text-white font-mono">CHAMBER {{ activeChamber.id < 10 ? '0' + activeChamber.id : activeChamber.id }} ENGINEERING CROSS-SECTION</h2>
          </div>
          <p class="text-xs text-stone-400 mt-1 font-mono">
            Internal profile showing refractory arch, brick stack setting density, stoking ports, hot gas streamlines, and temperature probes.
          </p>
        </div>

        <!-- Chamber Selector Strip -->
        <div class="flex items-center gap-1 bg-stone-950 p-1 rounded-lg border border-stone-800 overflow-x-auto text-xs font-mono">
          @for (ch of sim.chambers(); track ch.id) {
            <button 
              (click)="sim.setActiveChamber(ch.id)"
              [class]="ch.id === activeChamber.id ? 'bg-amber-600 text-stone-950 font-bold' : 'text-stone-400 hover:text-stone-200'"
              class="px-2 py-1 rounded transition-colors">
              {{ ch.id < 10 ? '0' + ch.id : ch.id }}
            </button>
          }
        </div>
      </div>

      <!-- Main Interactive Cross Section Schematic -->
      <div class="bg-stone-950 border border-stone-800 rounded-xl p-6 relative min-h-[460px] flex items-center justify-center overflow-hidden">
        
        <svg class="w-full max-w-[850px] h-[400px] text-stone-300 font-mono text-xs" viewBox="0 0 850 400">
          
          <!-- Outer Masonry Wall & Arch Roof -->
          <path d="M 120 360 L 120 180 Q 425 60 730 180 L 730 360 Z" fill="#1c1917" stroke="#44403c" stroke-width="4" />
          <path d="M 150 360 L 150 190 Q 425 90 700 190 L 700 360 Z" fill="#09090b" stroke="#27272a" stroke-width="2" />

          <!-- Refractory Arch Insulation Tag -->
          <text x="425" y="110" text-anchor="middle" fill="#78716c" font-size="11">REFRACTORY ARCH MASONRY (1,400°C RATING)</text>

          <!-- Top Stoking Fuel Ports -->
          <rect x="300" y="100" width="16" height="30" fill="#27272a" stroke="#78716c" />
          <rect x="417" y="85" width="16" height="30" fill="#27272a" stroke="#78716c" />
          <rect x="534" y="100" width="16" height="30" fill="#27272a" stroke="#78716c" />

          <!-- Flame Jets (Active if FIRING) -->
          @if (activeChamber.state === 'FIRING' || activeChamber.state === 'SOAK') {
            <polygon points="308,130 302,210 314,210" fill="#f97316" opacity="0.85" />
            <polygon points="425,115 418,220 432,220" fill="#ef4444" opacity="0.95" />
            <polygon points="542,130 536,210 548,210" fill="#f97316" opacity="0.85" />
          }

          <!-- Brick Setting Stack (Gridded bricks in chamber) -->
          <g transform="translate(180, 220)">
            @for (row of [0,1,2,3,4]; track row) {
              @for (col of [0,1,2,3,4,5,6,7,8,9]; track col) {
                <rect 
                  [attr.x]="col * 48" 
                  [attr.y]="row * 24" 
                  width="42" 
                  height="18" 
                  rx="2"
                  [attr.fill]="getBrickColorByTemp(activeChamber.brickCoreTempC)" 
                  stroke="#1c1917" 
                  stroke-width="1.5" />
              }
            }
          </g>

          <!-- Hot Gas Flow Streamline Vectors -->
          <g stroke="#f59e0b" stroke-width="2" fill="none" opacity="0.75" stroke-dasharray="8 4">
            <path d="M 160 170 Q 425 150 690 170" />
            <path d="M 160 210 Q 425 200 690 210" />
            <path d="M 160 250 Q 425 240 690 250" />
          </g>

          <!-- Bottom Flue Exhaust Damper Outlet -->
          <rect x="660" y="320" width="80" height="40" fill="#18181b" stroke="#3f3f46" stroke-width="2" />
          <rect 
            x="660" 
            [attr.y]="320 + (100 - activeChamber.damperPositionPercent) * 0.4" 
            width="80" 
            [attr.height]="activeChamber.damperPositionPercent * 0.4" 
            fill="#0284c7" 
            opacity="0.8" />

          <text x="700" y="380" text-anchor="middle" fill="#38bdf8" font-size="11">
            FLUE DAMPER {{ activeChamber.damperPositionPercent }}%
          </text>

          <!-- Temperature Probes & Readouts -->
          <!-- Atmosphere Probe -->
          <circle cx="260" cy="160" r="5" fill="#f59e0b" />
          <line x1="260" y1="160" x2="200" y2="120" stroke="#f59e0b" stroke-width="1.5" />
          <rect x="90" y="95" width="130" height="32" rx="4" fill="#18181b" stroke="#f59e0b" />
          <text x="155" y="115" text-anchor="middle" fill="#f59e0b" font-weight="bold">ATM: {{ activeChamber.atmosphereTempC }} °C</text>

          <!-- Brick Surface Probe -->
          <circle cx="420" cy="225" r="5" fill="#f97316" />
          <line x1="420" y1="225" x2="420" y2="170" stroke="#f97316" stroke-width="1.5" />
          <rect x="355" y="145" width="130" height="32" rx="4" fill="#18181b" stroke="#f97316" />
          <text x="420" y="165" text-anchor="middle" fill="#f97316" font-weight="bold">SURFACE: {{ activeChamber.brickSurfaceTempC }} °C</text>

          <!-- Brick Core Probe -->
          <circle cx="420" cy="270" r="5" fill="#38bdf8" />
          <line x1="420" y1="270" x2="490" y2="330" stroke="#38bdf8" stroke-width="1.5" />
          <rect x="490" y="315" width="130" height="32" rx="4" fill="#18181b" stroke="#38bdf8" />
          <text x="555" y="335" text-anchor="middle" fill="#38bdf8" font-weight="bold">CORE: {{ activeChamber.brickCoreTempC }} °C</text>

        </svg>

      </div>

      <!-- Thermal Lag & Kinetics Panel -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4">
          <div class="text-xs font-mono font-bold text-stone-400 mb-2">THERMAL LAG (PENETRATION DELTA)</div>
          <div class="text-2xl font-bold font-mono text-amber-400">
            Δ {{ activeChamber.atmosphereTempC - activeChamber.brickCoreTempC }} °C
          </div>
          <p class="text-xs text-stone-500 mt-2 font-mono">
            Difference between kiln atmosphere gas and brick core center. Core temperature governs sintering kinetics.
          </p>
        </div>

        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4">
          <div class="text-xs font-mono font-bold text-stone-400 mb-2">CLAY DEHYDROXYLATION & SINTERING</div>
          <div class="text-2xl font-bold font-mono text-emerald-400">
            Index: {{ activeChamber.sinteringIndex | number:'1.2-2' }}
          </div>
          <p class="text-xs text-stone-500 mt-2 font-mono">
            Arrhenius rate accumulation for clay mineral fusion and strength development.
          </p>
        </div>

        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4">
          <div class="text-xs font-mono font-bold text-stone-400 mb-2">QUARTZ INVERSION (573°C) REGION</div>
          <div class="text-2xl font-bold font-mono text-cyan-300">
            {{ activeChamber.quartzTransformedPercent }}%
          </div>
          <p class="text-xs text-stone-500 mt-2 font-mono">
            Alpha-to-beta silica crystal phase change. Cooling rate must stay under 50°C/h to avoid dunting cracks.
          </p>
        </div>

      </div>

    </div>
  `
})
export class ChamberCrossSectionComponent {
  readonly sim = inject(KilnSimulationService);

  get activeChamber() {
    return this.sim.activeChamberDetail();
  }

  getBrickColorByTemp(temp: number): string {
    if (temp >= 1050) return '#b91c1c';
    if (temp >= 900) return '#c2410c';
    if (temp >= 600) return '#d97706';
    if (temp >= 300) return '#a16207';
    if (temp >= 100) return '#71717a';
    return '#3f3f46';
  }
}
