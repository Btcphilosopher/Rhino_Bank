import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';
import { PRESET_SCENARIOS } from '../../models/kiln.constants';

@Component({
  selector: 'app-scenario-time-machine',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Control Header -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-amber-500">history</mat-icon>
            <h2 class="text-base font-bold text-white font-mono">SCENARIO ENGINE & TIME MACHINE REPLAY</h2>
          </div>
          <p class="text-xs text-stone-400 mt-1 font-mono">
            Inject operational failure scenarios or scrub backwards through historical firing cycle snapshots.
          </p>
        </div>

        @if (sim.replayIndex() !== null) {
          <button 
            (click)="sim.setReplayIndex(null)"
            class="px-3 py-1.5 bg-rose-900/80 hover:bg-rose-800 text-rose-200 text-xs font-mono rounded-lg border border-rose-700 flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">live_tv</mat-icon>
            RETURN TO LIVE SIMULATION
          </button>
        }
      </div>

      <!-- Time Machine Replay Slider -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-5 space-y-4">
        <div class="flex items-center justify-between font-mono text-xs">
          <span class="text-stone-300 font-bold flex items-center gap-2">
            <mat-icon class="!w-4 !h-4 !text-base text-amber-500">replay</mat-icon>
            HISTORICAL TELEMETRY BUFFER ({{ sim.telemetryHistory().length }} SNAPSHOTS RECORDED)
          </span>

          <span class="text-amber-400 font-bold">
            {{ sim.replayIndex() !== null ? 'REPLAY SNAPSHOT #' + sim.replayIndex() : 'LIVE ENGINE FEED' }}
          </span>
        </div>

        @if (sim.telemetryHistory().length > 0) {
          <input 
            type="range" 
            min="0" 
            [max]="sim.telemetryHistory().length - 1"
            [value]="sim.replayIndex() ?? (sim.telemetryHistory().length - 1)"
            (input)="onReplaySliderChange($event)"
            class="w-full accent-amber-500 cursor-pointer h-2 bg-stone-950 rounded-lg" />
        } @else {
          <div class="text-center py-4 text-xs font-mono text-stone-500">
            Recording telemetry snapshots... (Snapshots capture every ~10 simulation seconds)
          </div>
        }
      </div>

      <!-- Scenario Injector Preset Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (sc of scenarios; track sc.id) {
          <div 
            [class]="sim.selectedScenarioId() === sc.id ? 'border-amber-500 bg-stone-900' : 'border-stone-800 bg-stone-950/80'"
            class="p-4 rounded-xl border flex flex-col justify-between space-y-3 transition-all">
            <div>
              <div class="flex items-center justify-between mb-2">
                <span class="text-xs font-bold font-mono text-white">{{ sc.name }}</span>
                @if (sim.selectedScenarioId() === sc.id) {
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold">ACTIVE</span>
                }
              </div>
              <p class="text-xs text-stone-400 font-mono leading-relaxed">
                {{ sc.description }}
              </p>
            </div>

            <button 
              (click)="sim.setScenario(sc.id)"
              class="w-full bg-stone-800 hover:bg-stone-700 text-stone-200 py-2 rounded-lg text-xs font-mono transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-base">play_circle_outline</mat-icon>
              Inject Scenario
            </button>
          </div>
        }
      </div>

    </div>
  `
})
export class ScenarioTimeMachineComponent {
  readonly sim = inject(KilnSimulationService);
  readonly scenarios = PRESET_SCENARIOS;

  onReplaySliderChange(event: Event): void {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.sim.setReplayIndex(val);
  }
}
