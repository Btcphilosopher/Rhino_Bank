import { Component, ChangeDetectionStrategy, inject, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';

import { Chamber } from '../../models/kiln.types';

@Component({
  selector: 'app-kiln-map',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4">
      
      <!-- Top Bar Header -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-amber-500">map</mat-icon>
            <h2 class="text-base font-bold text-white font-mono">HOFFMANN RING KILN 2D THERMAL MAP</h2>
          </div>
          <p class="text-xs text-stone-400 mt-1 font-mono">
            Top-down continuous ring view. Hot gases circulate from active firing chambers through downstream preheating chambers.
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono">
          <div class="flex items-center gap-1.5 bg-stone-950 px-3 py-1.5 rounded-lg border border-stone-800">
            <span class="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
            <span class="text-stone-300">Firing Front: Chamber {{ sim.firingFront().activeChamberIndex }}</span>
          </div>
          <div class="flex items-center gap-1.5 bg-stone-950 px-3 py-1.5 rounded-lg border border-stone-800">
            <span class="text-stone-400">Peak Temp:</span>
            <span class="text-amber-400 font-bold">{{ sim.peakAtmosphereTemp() }}°C</span>
          </div>
        </div>
      </div>

      <!-- Main Canvas Map Container -->
      <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 relative min-h-[500px] flex items-center justify-center overflow-hidden">
        
        <canvas #mapCanvas class="w-full max-w-[900px] h-[480px] block cursor-pointer"></canvas>

        <!-- Hover Tooltip Overlay -->
        @if (hoveredChamber) {
          <div 
            class="absolute bg-stone-900/95 border border-stone-700 shadow-xl rounded-lg p-3 text-xs font-mono text-stone-200 pointer-events-none z-20 backdrop-blur-sm"
            [style.left.px]="tooltipX"
            [style.top.px]="tooltipY">
            <div class="font-bold text-amber-400 mb-1">CHAMBER {{ hoveredChamber.id < 10 ? '0' + hoveredChamber.id : hoveredChamber.id }} ({{ hoveredChamber.state }})</div>
            <div class="space-y-0.5 text-[11px]">
              <div>Atmosphere: <span class="text-amber-300 font-bold">{{ hoveredChamber.atmosphereTempC }}°C</span></div>
              <div>Brick Surface: <span class="text-orange-300">{{ hoveredChamber.brickSurfaceTempC }}°C</span></div>
              <div>Brick Core: <span class="text-cyan-300">{{ hoveredChamber.brickCoreTempC }}°C</span></div>
              <div>Damper Position: <span class="text-stone-300">{{ hoveredChamber.damperPositionPercent }}%</span></div>
              <div>Flue Pressure: <span class="text-indigo-300">{{ hoveredChamber.fluePressurePa }} Pa</span></div>
            </div>
          </div>
        }

      </div>

      <!-- Map Legend & Control Bar -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-stone-400">
        <div class="flex items-center gap-4">
          <span class="text-stone-300 font-bold">LEGEND:</span>
          <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-rose-600"></span> Firing (1000°C+)</div>
          <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-amber-500"></span> Preheating (400-800°C)</div>
          <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-sky-500"></span> Cooling (100-300°C)</div>
          <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-stone-800 border border-stone-600"></span> Loading / Unloading</div>
        </div>

        <div class="flex items-center gap-2">
          <mat-icon class="!w-4 !h-4 !text-base text-stone-500">sync</mat-icon>
          <span>Gas Flow: Clockwise Air Circulation</span>
        </div>
      </div>

    </div>
  `
})
export class KilnMapComponent implements AfterViewInit, OnDestroy {
  readonly sim = inject(KilnSimulationService);

  @ViewChild('mapCanvas') mapCanvasRef!: ElementRef<HTMLCanvasElement>;

  hoveredChamber: Chamber | null = null;
  tooltipX = 0;
  tooltipY = 0;

  private animFrameId: number | null = null;

  ngAfterViewInit(): void {
    this.initCanvasEvents();
    this.startMapRenderLoop();
  }

  ngOnDestroy(): void {
    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
  }

  private initCanvasEvents(): void {
    const canvas = this.mapCanvasRef.nativeElement;

    canvas.addEventListener('mousemove', (evt) => {
      const rect = canvas.getBoundingClientRect();
      const x = evt.clientX - rect.left;
      const y = evt.clientY - rect.top;

      const found = this.detectChamberAtCoords(x, y, canvas.width, canvas.height);
      this.hoveredChamber = found;
      this.tooltipX = Math.min(rect.width - 180, evt.clientX - rect.left + 15);
      this.tooltipY = Math.min(rect.height - 120, evt.clientY - rect.top + 15);
    });

    canvas.addEventListener('mouseleave', () => {
      this.hoveredChamber = null;
    });

    canvas.addEventListener('click', (evt) => {
      const rect = canvas.getBoundingClientRect();
      const x = evt.clientX - rect.left;
      const y = evt.clientY - rect.top;
      const found = this.detectChamberAtCoords(x, y, canvas.width, canvas.height);
      if (found) {
        this.sim.setActiveChamber(found.id);
      }
    });
  }

  private startMapRenderLoop(): void {
    const render = () => {
      this.drawKilnRingMap();
      this.animFrameId = requestAnimationFrame(render);
    };
    this.animFrameId = requestAnimationFrame(render);
  }

  private drawKilnRingMap(): void {
    const canvas = this.mapCanvasRef.nativeElement;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI display sizing
    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;

    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    // Background Field
    ctx.fillStyle = '#0c0a09';
    ctx.fillRect(0, 0, width, height);

    // Center geometry of Hoffmann Oval Ring
    const centerX = width / 2;
    const centerY = height / 2;
    const rx = width * 0.38;
    const ry = height * 0.35;

    // Outer Kiln Wall Boundary
    ctx.strokeStyle = '#27272a';
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.ellipse(centerX, centerY, rx, ry, 0, 0, Math.PI * 2);
    ctx.stroke();

    // Central Chimney Stack
    ctx.fillStyle = '#1c1917';
    ctx.strokeStyle = '#44403c';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(centerX, centerY, 38, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Chimney Stack Label
    ctx.fillStyle = '#a8a29e';
    ctx.font = '10px JetBrains Mono';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('MAIN STACK', centerX, centerY - 6);
    ctx.fillText(`${this.sim.draught().chimneyStackPressurePa} Pa`, centerX, centerY + 8);

    const chambers = this.sim.chambers();
    const ff = this.sim.firingFront();
    const activeId = this.sim.activeChamberId();

    // Draw 12 Chambers around oval ring
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const x = centerX + Math.cos(angle) * rx;
      const y = centerY + Math.sin(angle) * ry;

      const ch = chambers[i];
      const isSelected = ch.id === activeId;

      // Color from temperature heat map
      const color = this.getHeatMapColor(ch.atmosphereTempC);

      // Draw Chamber Box
      ctx.save();
      ctx.translate(x, y);

      ctx.fillStyle = color;
      ctx.strokeStyle = isSelected ? '#f59e0b' : '#3f3f46';
      ctx.lineWidth = isSelected ? 3 : 1.5;

      ctx.beginPath();
      ctx.roundRect(-28, -22, 56, 44, 6);
      ctx.fill();
      ctx.stroke();

      // Active Firing Front Glow Effect
      if (ch.id === ff.activeChamberIndex) {
        ctx.strokeStyle = '#e11d48';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.roundRect(-31, -25, 62, 50, 8);
        ctx.stroke();
      }

      // Chamber Text Labels
      ctx.fillStyle = ch.atmosphereTempC > 600 ? '#ffffff' : '#e7e5e4';
      ctx.font = 'bold 11px JetBrains Mono';
      ctx.textAlign = 'center';
      ctx.fillText(`CH ${ch.id < 10 ? '0' + ch.id : ch.id}`, 0, -6);

      ctx.font = '10px JetBrains Mono';
      ctx.fillStyle = ch.atmosphereTempC > 600 ? '#fef08a' : '#a8a29e';
      ctx.fillText(`${ch.atmosphereTempC}°C`, 0, 8);

      ctx.restore();

      // Connect Chamber to Central Flue Line
      ctx.strokeStyle = '#27272a';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(centerX + Math.cos(angle) * 38, centerY + Math.sin(angle) * 38);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw Animated Gas Circulation Arrows
    const timeSec = Date.now() / 1000;
    ctx.strokeStyle = '#f59e0b';
    ctx.fillStyle = '#f59e0b';
    ctx.lineWidth = 2;

    for (let i = 0; i < 12; i++) {
      const angle1 = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const angle2 = ((i + 1) / 12) * Math.PI * 2 - Math.PI / 2;

      // Flow particle animation position
      const t = (timeSec * 0.4 + i * 0.08) % 1.0;
      const currentAngle = angle1 + (angle2 - angle1) * t;

      const px = centerX + Math.cos(currentAngle) * (rx * 0.76);
      const py = centerY + Math.sin(currentAngle) * (ry * 0.76);

      ctx.beginPath();
      ctx.arc(px, py, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  private detectChamberAtCoords(x: number, y: number, w: number, h: number): Chamber | null {
    const dpr = window.devicePixelRatio || 1;
    const canvasW = w / dpr;
    const canvasH = h / dpr;

    const centerX = canvasW / 2;
    const centerY = canvasH / 2;
    const rx = canvasW * 0.38;
    const ry = canvasH * 0.35;

    const chambers = this.sim.chambers();

    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const cx = centerX + Math.cos(angle) * rx;
      const cy = centerY + Math.sin(angle) * ry;

      if (Math.abs(x - cx) <= 28 && Math.abs(y - cy) <= 22) {
        return chambers[i];
      }
    }

    return null;
  }

  private getHeatMapColor(temp: number): string {
    if (temp >= 1050) return '#be123c'; // Deep Red Fire
    if (temp >= 900) return '#e11d48';  // Rose Fire
    if (temp >= 700) return '#ea580c';  // Bright Orange
    if (temp >= 500) return '#d97706';  // Amber
    if (temp >= 300) return '#ca8a04';  // Warm Yellow
    if (temp >= 120) return '#0284c7';  // Light Cool
    return '#1c1917';                  // Cold Graphite
  }
}
