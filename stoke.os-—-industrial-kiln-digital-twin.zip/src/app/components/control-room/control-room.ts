import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';

@Component({
  selector: 'app-control-room',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Primary Metric Cards -->
      <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        
        <!-- Firing Front Position -->
        <div class="bg-stone-900/80 border border-stone-800/80 rounded-xl p-3.5 flex flex-col justify-between">
          <div class="flex items-center justify-between text-stone-400 text-xs font-mono">
            <span>FIRING FRONT</span>
            <mat-icon class="!w-4 !h-4 !text-base text-rose-500">local_fire_department</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-2">
            <span class="text-2xl font-bold font-mono text-rose-400">CH {{ sim.firingFront().activeChamberIndex < 10 ? '0' + sim.firingFront().activeChamberIndex : sim.firingFront().activeChamberIndex }}</span>
            <span class="text-xs text-stone-400 font-mono">{{ sim.firingFront().progressPercent | number:'1.0-0' }}%</span>
          </div>
          <div class="mt-2 w-full bg-stone-950 rounded-full h-1.5 overflow-hidden border border-stone-800">
            <div class="bg-rose-500 h-full rounded-full transition-all duration-300" [style.width.%]="sim.firingFront().progressPercent"></div>
          </div>
        </div>

        <!-- Atmosphere Peak Temperature -->
        <div class="bg-stone-900/80 border border-stone-800/80 rounded-xl p-3.5 flex flex-col justify-between">
          <div class="flex items-center justify-between text-stone-400 text-xs font-mono">
            <span>ATMOSPHERE PEAK</span>
            <mat-icon class="!w-4 !h-4 !text-base text-amber-500">thermostat</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-1">
            <span class="text-2xl font-bold font-mono text-amber-400">{{ sim.peakAtmosphereTemp() }}</span>
            <span class="text-xs text-stone-400">°C</span>
          </div>
          <div class="mt-2 text-[11px] text-stone-500 font-mono">
            Target: 1,080 °C
          </div>
        </div>

        <!-- Product Core Temperature -->
        <div class="bg-stone-900/80 border border-stone-800/80 rounded-xl p-3.5 flex flex-col justify-between">
          <div class="flex items-center justify-between text-stone-400 text-xs font-mono">
            <span>BRICK CORE PEAK</span>
            <mat-icon class="!w-4 !h-4 !text-base text-orange-500">grain</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-1">
            <span class="text-2xl font-bold font-mono text-orange-400">{{ sim.peakBrickCoreTemp() }}</span>
            <span class="text-xs text-stone-400">°C</span>
          </div>
          <div class="mt-2 text-[11px] text-stone-500 font-mono">
            Vitrification Active
          </div>
        </div>

        <!-- Core Thermal Lag -->
        <div class="bg-stone-900/80 border border-stone-800/80 rounded-xl p-3.5 flex flex-col justify-between">
          <div class="flex items-center justify-between text-stone-400 text-xs font-mono">
            <span>CORE THERMAL LAG</span>
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">unfold_more</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-1">
            <span class="text-2xl font-bold font-mono text-cyan-300">Δ {{ sim.peakAtmosphereTemp() - sim.peakBrickCoreTemp() }}</span>
            <span class="text-xs text-stone-400">°C</span>
          </div>
          <div class="mt-2 text-[11px] text-stone-500 font-mono">
            Penetration Limit: 120 °C
          </div>
        </div>

        <!-- Thermal MW Input -->
        <div class="bg-stone-900/80 border border-stone-800/80 rounded-xl p-3.5 flex flex-col justify-between">
          <div class="flex items-center justify-between text-stone-400 text-xs font-mono">
            <span>THERMAL INPUT</span>
            <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">power</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-1">
            <span class="text-2xl font-bold font-mono text-emerald-400">{{ sim.combustion().thermalInputMW | number:'1.2-2' }}</span>
            <span class="text-xs text-stone-400">MW</span>
          </div>
          <div class="mt-2 text-[11px] text-stone-500 font-mono truncate">
            {{ sim.combustion().fuelType }}
          </div>
        </div>

        <!-- Draught Network Pressure -->
        <div class="bg-stone-900/80 border border-stone-800/80 rounded-xl p-3.5 flex flex-col justify-between">
          <div class="flex items-center justify-between text-stone-400 text-xs font-mono">
            <span>DRAUGHT PRESSURE</span>
            <mat-icon class="!w-4 !h-4 !text-base text-indigo-400">air</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline gap-1">
            <span class="text-2xl font-bold font-mono text-indigo-300">{{ sim.draught().chimneyStackPressurePa }}</span>
            <span class="text-xs text-stone-400">Pa</span>
          </div>
          <div class="mt-2 text-[11px] text-stone-500 font-mono">
            Exhaust: {{ sim.draught().totalExhaustFlowM3h | number }} m³/h
          </div>
        </div>

      </div>

      <!-- 12-Chamber Ring Overview Strip -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4">
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-amber-500">grid_view</mat-icon>
            <h3 class="text-sm font-bold text-white tracking-wide font-mono">HOFFMANN CHAMBER SEQUENCE STATUS</h3>
          </div>
          <span class="text-xs font-mono text-stone-400">Click chamber to view cross section</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
          @for (ch of sim.chambers(); track ch.id) {
            <button 
              (click)="selectChamber(ch.id)"
              [class]="ch.id === sim.activeChamberId() ? 'ring-2 ring-amber-500 bg-stone-800' : 'bg-stone-950 hover:bg-stone-900'"
              class="p-3 rounded-lg border border-stone-800 text-left transition-all relative overflow-hidden group">
              
              <!-- State Header Badge -->
              <div class="flex items-center justify-between mb-1.5">
                <span class="text-xs font-bold font-mono text-stone-200">CH {{ ch.id < 10 ? '0' + ch.id : ch.id }}</span>
                <span [class]="getStateBadgeClass(ch.state)" class="text-[10px] font-mono px-1.5 py-0.5 rounded uppercase tracking-wider">
                  {{ ch.state }}
                </span>
              </div>

              <!-- Temperature Readings -->
              <div class="space-y-1 font-mono text-xs">
                <div class="flex justify-between text-stone-400">
                  <span>Atm:</span>
                  <span class="text-amber-400 font-semibold">{{ ch.atmosphereTempC }}°C</span>
                </div>
                <div class="flex justify-between text-stone-400">
                  <span>Core:</span>
                  <span class="text-orange-400">{{ ch.brickCoreTempC }}°C</span>
                </div>
              </div>

              <!-- Thermal Heat Bar Indicator -->
              <div class="mt-2.5 w-full bg-stone-900 h-1 rounded-full overflow-hidden">
                <div 
                  class="h-full rounded-full transition-all duration-300"
                  [style.width.%]="(ch.atmosphereTempC / 1080) * 100"
                  [style.background-color]="getTempHeatColor(ch.atmosphereTempC)">
                </div>
              </div>

              <!-- Defect Risk Warning Overlay -->
              @if (ch.defectRisk === 'HIGH' || ch.defectRisk === 'CRITICAL') {
                <div class="absolute top-1 right-1 bg-rose-600 text-white rounded-full p-0.5 animate-bounce">
                  <mat-icon class="!w-3.5 !h-3.5 !text-xs">warning</mat-icon>
                </div>
              }
            </button>
          }
        </div>
      </div>

      <!-- Quick Actions & Diagnostic Panel -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        <!-- Active Chamber Quick Detail Card -->
        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 border-b border-stone-800 pb-2">
              <span class="text-xs font-mono font-bold text-amber-400">ACTIVE INSPECTION: {{ sim.activeChamberDetail().name }}</span>
              <span class="text-xs font-mono text-stone-400">Batch: {{ sim.activeChamberDetail().batchId }}</span>
            </div>

            <div class="grid grid-cols-2 gap-3 text-xs font-mono mb-4">
              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500">Damper Position</div>
                <div class="text-sm font-bold text-stone-200 mt-1">{{ sim.activeChamberDetail().damperPositionPercent }}%</div>
              </div>
              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500">Flue Pressure</div>
                <div class="text-sm font-bold text-indigo-300 mt-1">{{ sim.activeChamberDetail().fluePressurePa }} Pa</div>
              </div>
              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500">Sintering Index</div>
                <div class="text-sm font-bold text-emerald-400 mt-1">{{ sim.activeChamberDetail().sinteringIndex }}</div>
              </div>
              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500">Quartz Transformed</div>
                <div class="text-sm font-bold text-cyan-300 mt-1">{{ sim.activeChamberDetail().quartzTransformedPercent }}%</div>
              </div>
            </div>
          </div>

          <div class="flex gap-2">
            <button 
              (click)="sim.setDamperPosition(sim.activeChamberId(), Math.min(100, sim.activeChamberDetail().damperPositionPercent + 10))"
              class="flex-1 bg-stone-800 hover:bg-stone-700 text-stone-200 py-1.5 px-2 rounded-lg text-xs font-mono transition-colors">
              + Damper 10%
            </button>
            <button 
              (click)="sim.setDamperPosition(sim.activeChamberId(), Math.max(0, sim.activeChamberDetail().damperPositionPercent - 10))"
              class="flex-1 bg-stone-800 hover:bg-stone-700 text-stone-200 py-1.5 px-2 rounded-lg text-xs font-mono transition-colors">
              - Damper 10%
            </button>
          </div>
        </div>

        <!-- Firing Front Kinetics Engine Card -->
        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 border-b border-stone-800 pb-2">
              <span class="text-xs font-mono font-bold text-rose-400">FIRING FRONT PROGRESSION ENGINE</span>
              <mat-icon class="!w-4 !h-4 !text-base text-rose-400">speed</mat-icon>
            </div>

            <div class="space-y-2 text-xs font-mono">
              <div class="flex justify-between py-1 border-b border-stone-800/50">
                <span class="text-stone-400">Progression Rate:</span>
                <span class="text-stone-200 font-bold">{{ sim.firingFront().speedChambersPerDay }} chambers/day</span>
              </div>
              <div class="flex justify-between py-1 border-b border-stone-800/50">
                <span class="text-stone-400">Preheating Zone:</span>
                <span class="text-amber-400">CH {{ sim.firingFront().preheatChambers.join(', ') }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-stone-800/50">
                <span class="text-stone-400">Active Firing Zone:</span>
                <span class="text-rose-400 font-bold">CH {{ sim.firingFront().firingChambers.join(', ') }}</span>
              </div>
              <div class="flex justify-between py-1">
                <span class="text-stone-400">Cooling Zone:</span>
                <span class="text-cyan-400">CH {{ sim.firingFront().coolingChambers.join(', ') }}</span>
              </div>
            </div>
          </div>

          <div class="mt-4 text-[11px] text-stone-400 bg-stone-950 p-2.5 rounded-lg border border-stone-800">
            Hot gases from active firing chambers preheat downstream brick setting; preheated secondary air recovers heat from upstream cooling chambers.
          </div>
        </div>

        <!-- Process Energy Intensity Card -->
        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 border-b border-stone-800 pb-2">
              <span class="text-xs font-mono font-bold text-emerald-400">ENERGY & EMISSIONS SUMMARY</span>
              <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">eco</mat-icon>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs font-mono mb-3">
              <div class="bg-stone-950 p-2 rounded-lg border border-stone-800">
                <div class="text-stone-500 text-[10px]">Specific Energy</div>
                <div class="text-emerald-400 font-bold text-sm mt-0.5">{{ sim.energy().kwhPerTonne }} kWh/t</div>
              </div>
              <div class="bg-stone-950 p-2 rounded-lg border border-stone-800">
                <div class="text-stone-500 text-[10px]">Specific CO2</div>
                <div class="text-stone-200 font-bold text-sm mt-0.5">{{ sim.energy().co2PerTonne }} kg/t</div>
              </div>
            </div>

            <div class="text-xs font-mono space-y-1">
              <div class="flex justify-between text-stone-400">
                <span>Recovered to Dryer:</span>
                <span class="text-amber-400">{{ sim.energy().recoveredToDryerMW }} MW</span>
              </div>
              <div class="flex justify-between text-stone-400">
                <span>Overall Thermal Efficiency:</span>
                <span class="text-emerald-400">{{ sim.energy().efficiencyPercent }}%</span>
              </div>
            </div>
          </div>

          <div class="mt-3 flex items-center justify-between text-[11px] font-mono text-stone-400 bg-stone-950 p-2 rounded-lg border border-stone-800">
            <span>Fuel Flow:</span>
            <span class="text-stone-200 font-bold">{{ sim.combustion().fuelFlowKgH }} kg/h</span>
          </div>
        </div>

      </div>

    </div>
  `
})
export class ControlRoomComponent {
  readonly sim = inject(KilnSimulationService);
  readonly navigateTab = output<string>();

  Math = Math;

  selectChamber(id: number): void {
    this.sim.setActiveChamber(id);
  }

  getStateBadgeClass(state: string): string {
    switch (state) {
      case 'FIRING': return 'bg-rose-950 text-rose-300 border border-rose-800';
      case 'SOAK': return 'bg-amber-950 text-amber-300 border border-amber-800';
      case 'PREHEATING': return 'bg-orange-950 text-orange-300 border border-orange-800';
      case 'COOLING': return 'bg-cyan-950 text-cyan-300 border border-cyan-800';
      case 'LOADED': return 'bg-stone-800 text-stone-300 border border-stone-700';
      default: return 'bg-stone-900 text-stone-400 border border-stone-800';
    }
  }

  getTempHeatColor(temp: number): string {
    if (temp > 1000) return '#E11D48'; // Rose
    if (temp > 800) return '#F97316';  // Orange
    if (temp > 500) return '#F59E0B';  // Amber
    if (temp > 200) return '#0EA5E9';  // Sky
    return '#64748B'; // Slate
  }
}
