import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';

@Component({
  selector: 'app-ai-diagnostics',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Control Header -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-amber-500">psychology</mat-icon>
            <h2 class="text-base font-bold text-white font-mono">GEMINI PROCESS ENGINEERING AI DIAGNOSTICS</h2>
          </div>
          <p class="text-xs text-stone-400 mt-1 font-mono">
            Server-side AI evaluation analyzing live thermal lag, excess air combustion, defect risks, and fuel optimization advice.
          </p>
        </div>

        <button 
          (click)="sim.requestAIEngineeringAnalysis()"
          [disabled]="sim.isAnalyzingAI()"
          class="px-4 py-2 bg-gradient-to-r from-amber-600 to-rose-700 hover:from-amber-500 hover:to-rose-600 text-white font-mono text-xs font-bold rounded-lg shadow-md flex items-center gap-2 disabled:opacity-50">
          <mat-icon class="!w-4 !h-4 !text-base" [class.animate-spin]="sim.isAnalyzingAI()">auto_awesome</mat-icon>
          {{ sim.isAnalyzingAI() ? 'Analyzing Telemetry...' : 'Run Process Diagnostic' }}
        </button>
      </div>

      @if (sim.aiAnalysis(); as analysis) {
        
        <!-- Health Score & Executive Summary Card -->
        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-stone-800 pb-3">
            <div class="flex items-center gap-3">
              <span class="text-xs font-mono font-bold text-stone-400">PROCESS COMPLIANCE HEALTH SCORE</span>
              <span class="text-xl font-bold font-mono text-emerald-400">{{ analysis.overallHealthScore }}/100</span>
            </div>
            <span class="text-xs font-mono px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
              OPTIMAL PROCESS BOUNDS
            </span>
          </div>

          <div>
            <h4 class="text-xs font-bold font-mono text-stone-300 mb-1">Executive Summary</h4>
            <p class="text-xs font-mono text-stone-300 leading-relaxed bg-stone-950 p-3 rounded-lg border border-stone-800">
              {{ analysis.summary }}
            </p>
          </div>
        </div>

        <!-- Thermal Lag & Fuel Optimization Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-5">
            <h4 class="text-xs font-bold font-mono text-amber-400 mb-2 flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-amber-400">thermostat</mat-icon>
              Thermal Lag Assessment
            </h4>
            <p class="text-xs font-mono text-stone-300 leading-relaxed bg-stone-950 p-3 rounded-lg border border-stone-800">
              {{ analysis.thermalLagAssessment }}
            </p>
          </div>

          <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-5">
            <h4 class="text-xs font-bold font-mono text-emerald-400 mb-2 flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">eco</mat-icon>
              Fuel Efficiency & Excess Air Optimization
            </h4>
            <p class="text-xs font-mono text-stone-300 leading-relaxed bg-stone-950 p-3 rounded-lg border border-stone-800">
              {{ analysis.fuelEfficiencyOptimization }}
            </p>
          </div>

        </div>

        <!-- Actionable Recommendations for Operators -->
        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-5">
          <h4 class="text-xs font-bold font-mono text-stone-200 mb-3 flex items-center gap-2">
            <mat-icon class="!w-4 !h-4 !text-base text-amber-500">checklist</mat-icon>
            RECOMMENDED OPERATOR ACTIONS
          </h4>

          <ul class="space-y-2 font-mono text-xs text-stone-300">
            @for (act of analysis.recommendedActions; track act) {
              <li class="flex items-start gap-2 bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <mat-icon class="!w-4 !h-4 !text-base text-emerald-400 shrink-0 mt-0.5">check_circle</mat-icon>
                <span>{{ act }}</span>
              </li>
            }
          </ul>
        </div>

      } @else {
        
        <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-12 text-center space-y-3 font-mono">
          <mat-icon class="!w-12 !h-12 !text-5xl text-stone-600">auto_awesome</mat-icon>
          <div class="text-sm font-bold text-stone-300">No Process Diagnostic Run Yet</div>
          <p class="text-xs text-stone-500 max-w-md mx-auto">
            Click "Run Process Diagnostic" above to initiate Gemini AI analysis of live digital twin firing kinetics.
          </p>
        </div>

      }

    </div>
  `
})
export class AiDiagnosticsComponent {
  readonly sim = inject(KilnSimulationService);
}
