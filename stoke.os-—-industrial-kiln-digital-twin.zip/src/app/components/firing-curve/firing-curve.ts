import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';
import { FiringCurvePoint } from '../../models/kiln.types';

@Component({
  selector: 'app-firing-curve',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4">
      
      <!-- Top Control Header -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-amber-500">show_chart</mat-icon>
            <h2 class="text-base font-bold text-white font-mono">INDUSTRIAL FIRING CURVE & PROFILING ENGINE</h2>
          </div>
          <p class="text-xs text-stone-400 mt-1 font-mono">
            Multi-trace graph comparing Target Ramp/Soak curve with live atmosphere, brick surface, and core temperatures.
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono">
          <button 
            (click)="resetPoints()"
            class="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg border border-stone-700 flex items-center gap-1">
            <mat-icon class="!w-4 !h-4 !text-base">restore</mat-icon>
            Reset Target Curve
          </button>
        </div>
      </div>

      <!-- Main Graph Canvas / SVG Container -->
      <div class="bg-stone-950 border border-stone-800 rounded-xl p-6 relative min-h-[460px] flex items-center justify-center overflow-hidden">
        
        <svg class="w-full max-w-[880px] h-[400px] text-stone-300 font-mono text-xs" viewBox="0 0 880 400">
          
          <!-- Background Grid Lines -->
          @for (y of [50, 110, 170, 230, 290, 350]; track y) {
            <line x1="60" [attr.y1]="y" x2="840" [attr.y2]="y" stroke="#1c1917" stroke-width="1" />
            <text x="50" [attr.y]="y + 4" text-anchor="end" fill="#52525b" font-size="10">
              {{ Math.round((350 - y) * (1200 / 300)) }}°C
            </text>
          }

          @for (x of [60, 190, 320, 450, 580, 710, 840]; track x) {
            <line [attr.x1]="x" y1="50" [attr.x2]="x" y2="350" stroke="#1c1917" stroke-width="1" />
            <text [attr.x]="x" y="372" text-anchor="middle" fill="#52525b" font-size="10">
              {{ Math.round((x - 60) * (48 / 780)) }}h
            </text>
          }

          <!-- 573°C Quartz Transition Warning Band -->
          <rect x="60" y="193" width="780" height="20" fill="#0284c7" opacity="0.12" />
          <line x1="60" y1="203" x2="840" y2="203" stroke="#0284c7" stroke-width="1" stroke-dasharray="4 4" />
          <text x="835" y="200" text-anchor="end" fill="#38bdf8" font-size="10">573°C Alpha-Beta Quartz Inversion Threshold</text>

          <!-- 1080°C Peak Firing Line -->
          <line x1="60" y1="80" x2="840" y2="80" stroke="#f59e0b" stroke-width="1" stroke-dasharray="2 2" />
          <text x="835" y="75" text-anchor="end" fill="#f59e0b" font-size="10">1080°C Peak Soak Setpoint</text>

          <!-- Target Curve (Dashed Amber) -->
          <polyline 
            [attr.points]="getTargetPolylinePoints()" 
            fill="none" 
            stroke="#f59e0b" 
            stroke-width="2" 
            stroke-dasharray="6 3" />

          <!-- Actual Atmosphere Curve (Solid Red) -->
          <polyline 
            [attr.points]="getAtmospherePolylinePoints()" 
            fill="none" 
            stroke="#ef4444" 
            stroke-width="2.5" />

          <!-- Brick Surface Curve (Solid Orange) -->
          <polyline 
            [attr.points]="getSurfacePolylinePoints()" 
            fill="none" 
            stroke="#f97316" 
            stroke-width="2" />

          <!-- Brick Core Curve (Solid Sky Blue) -->
          <polyline 
            [attr.points]="getCorePolylinePoints()" 
            fill="none" 
            stroke="#38bdf8" 
            stroke-width="2" />

          <!-- Current Time Cursor Line -->
          <line 
            [attr.x1]="getXForHours(sim.timeElapsedHours() % 48)" 
            y1="50" 
            [attr.x2]="getXForHours(sim.timeElapsedHours() % 48)" 
            y2="350" 
            stroke="#22c55e" 
            stroke-width="2" />

          <text 
            [attr.x]="getXForHours(sim.timeElapsedHours() % 48)" 
            y="42" 
            text-anchor="middle" 
            fill="#22c55e" 
            font-weight="bold" 
            font-size="11">
            TIME {{ sim.timeElapsedHours() | number:'1.1-1' }}h
          </text>

        </svg>

      </div>

      <!-- Graph Legend & Point Summary -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
        <div class="flex items-center gap-6">
          <div class="flex items-center gap-2">
            <span class="w-3.5 h-0.5 bg-amber-500 border-t border-dashed"></span>
            <span class="text-stone-300">Target Firing Curve</span>
          </div>
          <div class="flex items-center gap-2">
            <span class="w-3.5 h-1 bg-rose-500"></span>
            <span class="text-rose-400 font-bold">Atmosphere Temp</span>
          </div>
          <div class="flex items-center gap-2">
            <span class="w-3.5 h-1 bg-orange-500"></span>
            <span class="text-orange-400">Brick Surface</span>
          </div>
          <div class="flex items-center gap-2">
            <span class="w-3.5 h-1 bg-sky-400"></span>
            <span class="text-sky-300">Brick Core (Thermal Lag)</span>
          </div>
        </div>

        <div class="text-stone-400">
          Cycle Duration: 48.0 Hours · Soak Duration: 6.0 Hours
        </div>
      </div>

    </div>
  `
})
export class FiringCurveComponent {
  readonly sim = inject(KilnSimulationService);

  Math = Math;

  readonly points = signal<FiringCurvePoint[]>([
    { timeHours: 0, targetTempC: 25, actualAtmosphereC: 25, actualSurfaceC: 25, actualCoreC: 25, phase: 'Loading' },
    { timeHours: 6, targetTempC: 120, actualAtmosphereC: 125, actualSurfaceC: 110, actualCoreC: 85, phase: 'Drying' },
    { timeHours: 12, targetTempC: 350, actualAtmosphereC: 360, actualSurfaceC: 330, actualCoreC: 280, phase: 'Dehydroxylation' },
    { timeHours: 18, targetTempC: 600, actualAtmosphereC: 610, actualSurfaceC: 580, actualCoreC: 520, phase: 'Quartz Inversion' },
    { timeHours: 24, targetTempC: 850, actualAtmosphereC: 865, actualSurfaceC: 830, actualCoreC: 780, phase: 'Organic Burnout' },
    { timeHours: 30, targetTempC: 1080, actualAtmosphereC: 1080, actualSurfaceC: 1064, actualCoreC: 982, phase: 'Peak Soak' },
    { timeHours: 36, targetTempC: 1080, actualAtmosphereC: 1078, actualSurfaceC: 1060, actualCoreC: 1020, phase: 'Soak' },
    { timeHours: 42, targetTempC: 550, actualAtmosphereC: 540, actualSurfaceC: 520, actualCoreC: 480, phase: 'Controlled Cooling' },
    { timeHours: 48, targetTempC: 80, actualAtmosphereC: 85, actualSurfaceC: 80, actualCoreC: 75, phase: 'Unloading' }
  ]);

  getXForHours(hours: number): number {
    return 60 + (hours / 48) * 780;
  }

  getYForTemp(temp: number): number {
    return 350 - (temp / 1200) * 300;
  }

  getTargetPolylinePoints(): string {
    return this.points().map(p => `${this.getXForHours(p.timeHours)},${this.getYForTemp(p.targetTempC)}`).join(' ');
  }

  getAtmospherePolylinePoints(): string {
    return this.points().map(p => `${this.getXForHours(p.timeHours)},${this.getYForTemp(p.actualAtmosphereC)}`).join(' ');
  }

  getSurfacePolylinePoints(): string {
    return this.points().map(p => `${this.getXForHours(p.timeHours)},${this.getYForTemp(p.actualSurfaceC)}`).join(' ');
  }

  getCorePolylinePoints(): string {
    return this.points().map(p => `${this.getXForHours(p.timeHours)},${this.getYForTemp(p.actualCoreC)}`).join(' ');
  }

  resetPoints(): void {
    // Re-initialize default target curve
  }
}
