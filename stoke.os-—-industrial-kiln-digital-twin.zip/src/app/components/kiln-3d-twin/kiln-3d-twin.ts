import { Component, ChangeDetectionStrategy, inject, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';
import * as THREE from 'three';

@Component({
  selector: 'app-kiln-3d-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4">
      
      <!-- Top Control Header -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-amber-500">3d_rotation</mat-icon>
            <h2 class="text-base font-bold text-white font-mono">3D KILN PLANT DIGITAL TWIN (WEBGL)</h2>
          </div>
          <p class="text-xs text-stone-400 mt-1 font-mono">
            3D computational twin rendering kiln structure, refractory walls, flue ducts, and live thermal emission fields.
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono">
          <button 
            (click)="toggleThermalCamera()"
            [class]="isThermalCamera ? 'bg-rose-900/80 text-rose-300 border-rose-700' : 'bg-stone-800 text-stone-300 border-stone-700'"
            class="px-3 py-1.5 rounded-lg border font-mono transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">{{ isThermalCamera ? 'videocam' : 'camera_alt' }}</mat-icon>
            {{ isThermalCamera ? 'IR Thermal View [ACTIVE]' : 'Standard Visual View' }}
          </button>
          
          <button 
            (click)="resetCameraView()"
            class="px-2.5 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg border border-stone-700 flex items-center gap-1">
            <mat-icon class="!w-4 !h-4 !text-base">refresh</mat-icon>
            Reset Cam
          </button>
        </div>
      </div>

      <!-- 3D Canvas Viewport -->
      <div class="bg-stone-950 border border-stone-800 rounded-xl relative min-h-[520px] overflow-hidden flex items-center justify-center">
        
        <div #canvasContainer class="w-full h-[520px] block"></div>

        <!-- Floating Camera Control Guidance -->
        <div class="absolute bottom-3 left-3 bg-stone-900/80 backdrop-blur-md border border-stone-800 px-3 py-1.5 rounded-lg text-[11px] font-mono text-stone-400 pointer-events-none flex items-center gap-3">
          <span>Rotate: Drag Left Mouse</span>
          <span>Pan: Drag Right Mouse</span>
          <span>Zoom: Scroll Wheel</span>
        </div>

        <!-- Selected Chamber Info Overlay in 3D -->
        <div class="absolute top-3 right-3 bg-stone-900/90 backdrop-blur-md border border-stone-800 p-3 rounded-xl text-xs font-mono text-stone-200">
          <div class="text-amber-400 font-bold mb-1">INSPECTION: {{ sim.activeChamberDetail().name }}</div>
          <div class="space-y-1 text-[11px]">
            <div>Atmosphere: <span class="text-amber-300">{{ sim.activeChamberDetail().atmosphereTempC }} °C</span></div>
            <div>Core Temp: <span class="text-orange-300">{{ sim.activeChamberDetail().brickCoreTempC }} °C</span></div>
            <div>State: <span class="text-emerald-400">{{ sim.activeChamberDetail().state }}</span></div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class Kiln3dTwinComponent implements AfterViewInit, OnDestroy {
  readonly sim = inject(KilnSimulationService);

  @ViewChild('canvasContainer') canvasContainerRef!: ElementRef<HTMLDivElement>;

  isThermalCamera = false;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private chamberMeshes: THREE.Mesh[] = [];
  private flameLights: THREE.PointLight[] = [];
  private animFrameId: number | null = null;

  // Camera Orbit Drag State
  private isMouseDown = false;
  private prevMouseX = 0;
  private prevMouseY = 0;
  private cameraRadius = 28;
  private cameraTheta = Math.PI / 4;
  private cameraPhi = Math.PI / 3;

  ngAfterViewInit(): void {
    this.initThreeScene();
    this.startRenderLoop();
  }

  ngOnDestroy(): void {
    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
    if (this.renderer) this.renderer.dispose();
  }

  toggleThermalCamera(): void {
    this.isThermalCamera = !this.isThermalCamera;
    this.updateMaterialsMode();
  }

  resetCameraView(): void {
    this.cameraRadius = 28;
    this.cameraTheta = Math.PI / 4;
    this.cameraPhi = Math.PI / 3;
    this.updateCameraPosition();
  }

  private initThreeScene(): void {
    const container = this.canvasContainerRef.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#09090b');

    // 2. Camera setup
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.updateCameraPosition();

    // 3. Renderer setup
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xfff7ed, 1.2);
    dirLight.position.set(20, 40, 20);
    this.scene.add(dirLight);

    // 5. Build Kiln Geometry (12 Chamber Ring + Central Chimney)
    this.buildKiln3DModel();

    // 6. Event Listeners for Orbiting
    this.initOrbitControls(container);
  }

  private buildKiln3DModel(): void {
    const ringRadiusX = 10;
    const ringRadiusZ = 7;

    // Ground Floor Plate
    const floorGeo = new THREE.PlaneGeometry(36, 28);
    const floorMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = -0.1;
    this.scene.add(floorMesh);

    // Central Chimney Stack
    const chimneyGeo = new THREE.CylinderGeometry(1.2, 1.8, 14, 24);
    const chimneyMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.7 });
    const chimneyMesh = new THREE.Mesh(chimneyGeo, chimneyMat);
    chimneyMesh.position.set(0, 7, 0);
    this.scene.add(chimneyMesh);

    // 12 Chamber Modules
    this.chamberMeshes = [];
    this.flameLights = [];

    const chambers = this.sim.chambers();

    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const x = Math.cos(angle) * ringRadiusX;
      const z = Math.sin(angle) * ringRadiusZ;

      const chamberGeo = new THREE.BoxGeometry(2.4, 2.2, 2.8);
      const chamberMat = new THREE.MeshStandardMaterial({
        color: this.getMaterialColorForTemp(chambers[i].atmosphereTempC),
        roughness: 0.6
      });

      const mesh = new THREE.Mesh(chamberGeo, chamberMat);
      mesh.position.set(x, 1.1, z);
      mesh.rotation.y = -angle;
      mesh.userData = { chamberId: i + 1 };

      this.scene.add(mesh);
      this.chamberMeshes.push(mesh);

      // Flue duct connecting chamber to central chimney
      const ductGeo = new THREE.CylinderGeometry(0.2, 0.2, Math.hypot(x, z) * 0.9, 8);
      const ductMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46 });
      const ductMesh = new THREE.Mesh(ductGeo, ductMat);

      ductMesh.position.set(x / 2, 0.8, z / 2);
      ductMesh.rotation.z = Math.PI / 2;
      ductMesh.rotation.y = -angle;
      this.scene.add(ductMesh);

      // Point light for firing flame glow
      const pLight = new THREE.PointLight(0xff4500, 0, 8);
      pLight.position.set(x, 2.5, z);
      this.scene.add(pLight);
      this.flameLights.push(pLight);
    }
  }

  private initOrbitControls(container: HTMLElement): void {
    container.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    container.addEventListener('mousemove', (e) => {
      if (!this.isMouseDown) return;

      const dx = e.clientX - this.prevMouseX;
      const dy = e.clientY - this.prevMouseY;

      this.cameraTheta -= dx * 0.005;
      this.cameraPhi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraPhi - dy * 0.005));

      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;

      this.updateCameraPosition();
    });

    container.addEventListener('wheel', (e) => {
      this.cameraRadius = Math.max(12, Math.min(60, this.cameraRadius + e.deltaY * 0.03));
      this.updateCameraPosition();
    });

    // Click selection on 3D objects via Raycasting
    container.addEventListener('click', (e) => {
      const rect = container.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / container.clientWidth) * 2 - 1,
        -((e.clientY - rect.top) / container.clientHeight) * 2 + 1
      );

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(mouse, this.camera);

      const intersects = raycaster.intersectObjects(this.chamberMeshes);
      if (intersects.length > 0) {
        const id = intersects[0].object.userData['chamberId'];
        if (id) {
          this.sim.setActiveChamber(id);
        }
      }
    });
  }

  private updateCameraPosition(): void {
    this.camera.position.x = this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);
    this.camera.position.y = this.cameraRadius * Math.cos(this.cameraPhi);
    this.camera.position.z = this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);
    this.camera.lookAt(0, 1.5, 0);
  }

  private startRenderLoop(): void {
    const render = () => {
      this.updateDynamicMeshStates();
      this.renderer.render(this.scene, this.camera);
      this.animFrameId = requestAnimationFrame(render);
    };
    this.animFrameId = requestAnimationFrame(render);
  }

  private updateDynamicMeshStates(): void {
    const chambers = this.sim.chambers();
    const activeId = this.sim.activeChamberId();

    chambers.forEach((ch, idx) => {
      const mesh = this.chamberMeshes[idx];
      const pLight = this.flameLights[idx];

      if (mesh && mesh.material) {
        const mat = mesh.material as THREE.MeshStandardMaterial;
        mat.color.set(this.getMaterialColorForTemp(ch.atmosphereTempC));

        // Highlight selected chamber scale
        if (ch.id === activeId) {
          mesh.scale.set(1.08, 1.08, 1.08);
        } else {
          mesh.scale.set(1.0, 1.0, 1.0);
        }
      }

      if (pLight) {
        if (ch.state === 'FIRING') {
          pLight.intensity = 2.5 + Math.sin(Date.now() * 0.008) * 0.8;
        } else {
          pLight.intensity = 0;
        }
      }
    });
  }

  private updateMaterialsMode(): void {
    this.updateDynamicMeshStates();
  }

  private getMaterialColorForTemp(temp: number): number {
    if (this.isThermalCamera) {
      // IR Thermal Palette (Black -> Blue -> Red -> Yellow -> White)
      if (temp > 1000) return 0xffffff;
      if (temp > 800) return 0xfacc15;
      if (temp > 500) return 0xe11d48;
      if (temp > 200) return 0x0284c7;
      return 0x18181b;
    } else {
      // Realistic Masonry / Heat Glow Palette
      if (temp > 1000) return 0xb91c1c;
      if (temp > 800) return 0xc2410c;
      if (temp > 500) return 0xb45309;
      if (temp > 200) return 0x52525b;
      return 0x27272a;
    }
  }
}
