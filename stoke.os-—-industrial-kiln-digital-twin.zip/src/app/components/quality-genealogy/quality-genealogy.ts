import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';

@Component({
  selector: 'app-quality-genealogy',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Control Header -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-amber-500">verified</mat-icon>
            <h2 class="text-base font-bold text-white font-mono">PRODUCT QUALITY & BATCH TRACEABILITY GENEALOGY</h2>
          </div>
          <p class="text-xs text-stone-400 mt-1 font-mono">
            Track batch genealogy from raw clay pit extraction through forming, drying, firing profile, and final quality compliance.
          </p>
        </div>
      </div>

      <!-- Batch Genealogy Cards -->
      <div class="space-y-4">
        @for (b of sim.batchGenealogies(); track b.batchId) {
          <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-5 space-y-4">
            
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-800 pb-3">
              <div class="flex items-center gap-3">
                <span class="text-sm font-bold font-mono text-amber-400">{{ b.batchId }}</span>
                <span class="text-xs font-mono text-stone-300">{{ b.productName }}</span>
              </div>

              <div class="flex items-center gap-2">
                <span 
                  [class]="b.qualityStatus === 'PASS' ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-rose-950 text-rose-300 border-rose-800'"
                  class="text-xs font-mono px-2.5 py-1 rounded-md border font-bold">
                  {{ b.qualityStatus }}
                </span>
              </div>
            </div>

            <!-- Genealogy Trail -->
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500 text-[10px]">Clay Source</div>
                <div class="text-stone-200 mt-0.5 truncate">{{ b.claySource }}</div>
              </div>

              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500 text-[10px]">Forming Line</div>
                <div class="text-stone-200 mt-0.5 truncate">{{ b.formingLine }}</div>
              </div>

              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500 text-[10px]">Dryer Unit</div>
                <div class="text-stone-200 mt-0.5 truncate">{{ b.dryerId }}</div>
              </div>

              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500 text-[10px]">Kiln Chambers</div>
                <div class="text-amber-400 font-bold mt-0.5 truncate">{{ b.chambersUsed }}</div>
              </div>

              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500 text-[10px]">Peak Temp & Soak</div>
                <div class="text-rose-400 font-bold mt-0.5 truncate">{{ b.peakTempC }} °C ({{ b.soakHours }}h)</div>
              </div>

              <div class="bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                <div class="text-stone-500 text-[10px]">Cooling Profile</div>
                <div class="text-cyan-300 mt-0.5 truncate">{{ b.coolingRate }}</div>
              </div>
            </div>

            <!-- Measured Physical Properties & Fired Color Swatch -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-stone-950 p-3.5 rounded-xl border border-stone-800 font-mono text-xs">
              <div class="flex items-center gap-6">
                <div>
                  <span class="text-stone-500">Compressive Strength: </span>
                  <span class="text-emerald-400 font-bold">{{ b.strengthNmm2 }} N/mm²</span>
                </div>
                <div>
                  <span class="text-stone-500">Water Absorption: </span>
                  <span class="text-amber-300 font-bold">{{ b.absorptionPercent }}%</span>
                </div>
              </div>

              <div class="flex items-center gap-2">
                <span class="text-stone-400">Predicted Fired Color:</span>
                <span class="w-5 h-5 rounded-md border border-stone-600 inline-block" [style.background-color]="b.recipeId === 'YORKSHIRE_STOCK' ? '#B93829' : '#3F3F46'"></span>
                <span class="text-stone-200 font-bold">{{ b.estColour }}</span>
              </div>
            </div>

          </div>
        }
      </div>

    </div>
  `
})
export class QualityGenealogyComponent {
  readonly sim = inject(KilnSimulationService);
}
