import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';
import { PRESET_SCENARIOS } from '../../models/kiln.constants';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-stone-900/90 backdrop-blur-md border-b border-stone-800 sticky top-0 z-50 px-4 lg:px-6 py-2.5">
      <div class="flex items-center justify-between gap-4">
        
        <!-- Zone 1: Brand Wordmark -->
        <div class="flex items-center gap-3 shrink-0">
          <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-600 to-rose-700 flex items-center justify-center text-white font-mono font-bold text-sm shadow-md shadow-amber-900/30">
            S
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="text-base font-extrabold tracking-tight text-white font-mono">STOKE.OS</span>
              <span class="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-stone-800 text-stone-400 border border-stone-700/50">v3.6 Twin</span>
            </div>
            <div class="text-[11px] text-stone-400 font-mono hidden sm:block">AIRE VALLEY WORKS · KILN 01 (HOFFMANN RING)</div>
          </div>
        </div>

        <!-- Zone 2: Navigation Views -->
        <nav class="hidden md:flex items-center gap-1 bg-stone-950/80 p-1 rounded-lg border border-stone-800 text-xs font-medium text-stone-400">
          <button 
            (click)="activeTab = 'CONTROL'"
            [class]="activeTab === 'CONTROL' ? 'bg-stone-800 text-amber-400 shadow-xs' : 'hover:text-stone-200'"
            class="px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">dashboard</mat-icon>
            Control Room
          </button>

          <button 
            (click)="activeTab = 'MAP'"
            [class]="activeTab === 'MAP' ? 'bg-stone-800 text-amber-400 shadow-xs' : 'hover:text-stone-200'"
            class="px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">map</mat-icon>
            Kiln Ring Map
          </button>

          <button 
            (click)="activeTab = 'TWIN3D'"
            [class]="activeTab === 'TWIN3D' ? 'bg-stone-800 text-amber-400 shadow-xs' : 'hover:text-stone-200'"
            class="px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">3d_rotation</mat-icon>
            3D Digital Twin
          </button>

          <button 
            (click)="activeTab = 'CROSS_SECTION'"
            [class]="activeTab === 'CROSS_SECTION' ? 'bg-stone-800 text-amber-400 shadow-xs' : 'hover:text-stone-200'"
            class="px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">layers</mat-icon>
            Cross Section
          </button>

          <button 
            (click)="activeTab = 'FIRING_CURVE'"
            [class]="activeTab === 'FIRING_CURVE' ? 'bg-stone-800 text-amber-400 shadow-xs' : 'hover:text-stone-200'"
            class="px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">show_chart</mat-icon>
            Firing Curve
          </button>

          <button 
            (click)="activeTab = 'ELECTRIFICATION'"
            [class]="activeTab === 'ELECTRIFICATION' ? 'bg-stone-800 text-amber-400 shadow-xs' : 'hover:text-stone-200'"
            class="px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">bolt</mat-icon>
            Electrification Lab
          </button>

          <button 
            (click)="activeTab = 'QUALITY'"
            [class]="activeTab === 'QUALITY' ? 'bg-stone-800 text-amber-400 shadow-xs' : 'hover:text-stone-200'"
            class="px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">verified</mat-icon>
            Quality & Batch
          </button>

          <button 
            (click)="activeTab = 'SCENARIOS'"
            [class]="activeTab === 'SCENARIOS' ? 'bg-stone-800 text-amber-400 shadow-xs' : 'hover:text-stone-200'"
            class="px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base">history</mat-icon>
            Time Machine
          </button>
        </nav>

        <!-- Zone 3: Simulation Controls & Status -->
        <div class="flex items-center gap-2">
          
          <!-- Scenario Selector Dropdown -->
          <select 
            [value]="sim.selectedScenarioId()"
            (change)="onScenarioChange($event)"
            class="bg-stone-950 border border-stone-800 rounded-lg px-2.5 py-1.5 text-xs text-stone-300 font-mono focus:outline-none focus:border-amber-600 hidden lg:block">
            @for (sc of scenarios; track sc.id) {
              <option [value]="sc.id">{{ sc.name }}</option>
            }
          </select>

          <!-- Speed Controls -->
          <div class="flex items-center bg-stone-950 rounded-lg p-0.5 border border-stone-800 text-xs font-mono">
            <button 
              (click)="sim.togglePause()" 
              class="px-2 py-1 rounded hover:bg-stone-800 text-stone-300 flex items-center"
              [title]="sim.isPaused() ? 'Resume Simulation' : 'Pause Simulation'">
              <mat-icon class="!w-4 !h-4 !text-base">{{ sim.isPaused() ? 'play_arrow' : 'pause' }}</mat-icon>
            </button>
            <div class="h-3 w-px bg-stone-800 my-auto mx-0.5"></div>
            @for (s of speedSteps; track s) {
              <button 
                (click)="sim.setSpeed(s)" 
                [class]="sim.simSpeedMultiplier() === s && !sim.isPaused() ? 'bg-amber-600/30 text-amber-400 font-bold' : 'text-stone-500 hover:text-stone-300'"
                class="px-1.5 py-0.5 rounded text-[11px]">
                {{ s }}x
              </button>
            }
          </div>

          <!-- Active Firing Front Badge -->
          <div class="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-rose-950/40 border border-rose-800/50 text-rose-300 text-xs font-mono">
            <span class="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
            <span>CH {{ sim.firingFront().activeChamberIndex < 10 ? '0' + sim.firingFront().activeChamberIndex : sim.firingFront().activeChamberIndex }}</span>
            <span class="text-stone-400 font-sans hidden sm:inline">FIRING FRONT</span>
          </div>

        </div>

      </div>

      <!-- Mobile Tab Bar Dropdown -->
      <div class="mt-2 flex md:hidden overflow-x-auto gap-1 pb-1 text-xs">
        <button (click)="activeTab = 'CONTROL'" [class.text-amber-400]="activeTab === 'CONTROL'" class="px-2 py-1 bg-stone-800 rounded shrink-0">Control</button>
        <button (click)="activeTab = 'MAP'" [class.text-amber-400]="activeTab === 'MAP'" class="px-2 py-1 bg-stone-800 rounded shrink-0">Map</button>
        <button (click)="activeTab = 'TWIN3D'" [class.text-amber-400]="activeTab === 'TWIN3D'" class="px-2 py-1 bg-stone-800 rounded shrink-0">3D Twin</button>
        <button (click)="activeTab = 'CROSS_SECTION'" [class.text-amber-400]="activeTab === 'CROSS_SECTION'" class="px-2 py-1 bg-stone-800 rounded shrink-0">Section</button>
        <button (click)="activeTab = 'FIRING_CURVE'" [class.text-amber-400]="activeTab === 'FIRING_CURVE'" class="px-2 py-1 bg-stone-800 rounded shrink-0">Curves</button>
        <button (click)="activeTab = 'ELECTRIFICATION'" [class.text-amber-400]="activeTab === 'ELECTRIFICATION'" class="px-2 py-1 bg-stone-800 rounded shrink-0">Energy</button>
        <button (click)="activeTab = 'QUALITY'" [class.text-amber-400]="activeTab === 'QUALITY'" class="px-2 py-1 bg-stone-800 rounded shrink-0">Quality</button>
        <button (click)="activeTab = 'SCENARIOS'" [class.text-amber-400]="activeTab === 'SCENARIOS'" class="px-2 py-1 bg-stone-800 rounded shrink-0">Time Machine</button>
      </div>
    </header>
  `
})
export class HeaderComponent {
  readonly sim = inject(KilnSimulationService);
  
  activeTab: 'CONTROL' | 'MAP' | 'TWIN3D' | 'CROSS_SECTION' | 'FIRING_CURVE' | 'ELECTRIFICATION' | 'QUALITY' | 'SCENARIOS' = 'CONTROL';
  
  readonly scenarios = PRESET_SCENARIOS;
  readonly speedSteps = [0.1, 1, 10, 100, 1000];

  onScenarioChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.sim.setScenario(val);
  }
}
