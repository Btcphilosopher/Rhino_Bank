import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KilnSimulationService } from '../../services/kiln-simulation.service';
import { FuelType } from '../../models/kiln.types';

@Component({
  selector: 'app-electrification-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Control Header -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!w-5 !h-5 !text-lg text-emerald-400">bolt</mat-icon>
            <h2 class="text-base font-bold text-white font-mono">ELECTRIFICATION & DECARBONISATION LAB</h2>
          </div>
          <p class="text-xs text-stone-400 mt-1 font-mono">
            Sankey thermal balance, fuel switching simulation (Natural Gas vs H2 vs Electric), and CO2 abatement modelling.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-stone-400">Active Fuel:</span>
          <select 
            [value]="sim.combustion().fuelType"
            (change)="onFuelTypeSelect($event)"
            class="bg-stone-950 border border-stone-800 rounded-lg px-3 py-1.5 text-xs text-emerald-400 font-mono focus:outline-none focus:border-emerald-600">
            <option value="NATURAL_GAS">Natural Gas (Methane)</option>
            <option value="HYDROGEN">Green Hydrogen (100% H2)</option>
            <option value="BIOGAS">Upgraded Biogas</option>
            <option value="LPG">LPG (Propane/Butane)</option>
            <option value="ELECTRIC">Direct Electric Resistance</option>
          </select>
        </div>
      </div>

      <!-- Thermal Energy Balance Sankey Representation -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-6">
        <h3 class="text-xs font-bold text-stone-300 font-mono mb-4 flex items-center gap-2">
          <mat-icon class="!w-4 !h-4 !text-base text-amber-500">account_tree</mat-icon>
          SANKEY PROCESS THERMAL ENERGY FLOW (TOTAL INPUT: {{ sim.energy().fuelInputMW }} MW)
        </h3>

        <div class="space-y-3 font-mono text-xs">
          <!-- Useful Process Heat -->
          <div>
            <div class="flex justify-between mb-1 text-stone-300">
              <span>Useful Brick Vitrification Heat (72.5%):</span>
              <span class="text-emerald-400 font-bold">{{ sim.energy().usefulProcessHeatMW }} MW</span>
            </div>
            <div class="w-full bg-stone-950 h-3 rounded-full overflow-hidden border border-stone-800">
              <div class="bg-emerald-500 h-full rounded-full" style="width: 72.5%"></div>
            </div>
          </div>

          <!-- Recovered to Green Brick Dryer -->
          <div>
            <div class="flex justify-between mb-1 text-stone-300">
              <span>Heat Recovered to Green Brick Dryer (20.3%):</span>
              <span class="text-amber-400 font-bold">{{ sim.energy().recoveredToDryerMW }} MW</span>
            </div>
            <div class="w-full bg-stone-950 h-3 rounded-full overflow-hidden border border-stone-800">
              <div class="bg-amber-500 h-full rounded-full" style="width: 20.3%"></div>
            </div>
          </div>

          <!-- Flue Gas Stack Loss -->
          <div>
            <div class="flex justify-between mb-1 text-stone-300">
              <span>Flue Exhaust Gas Stack Loss (14.7%):</span>
              <span class="text-rose-400 font-bold">{{ sim.energy().exhaustLossMW }} MW</span>
            </div>
            <div class="w-full bg-stone-950 h-3 rounded-full overflow-hidden border border-stone-800">
              <div class="bg-rose-500 h-full rounded-full" style="width: 14.7%"></div>
            </div>
          </div>

          <!-- Shell Radiation Loss -->
          <div>
            <div class="flex justify-between mb-1 text-stone-300">
              <span>Kiln Shell Masonry Radiation Loss (6.3%):</span>
              <span class="text-stone-400 font-bold">{{ sim.energy().wallRadiationLossMW }} MW</span>
            </div>
            <div class="w-full bg-stone-950 h-3 rounded-full overflow-hidden border border-stone-800">
              <div class="bg-stone-600 h-full rounded-full" style="width: 6.3%"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Fuel Scenario Comparison Matrix -->
      <div class="bg-stone-900/90 border border-stone-800 rounded-xl p-5 overflow-x-auto">
        <h3 class="text-xs font-bold text-stone-300 font-mono mb-4 flex items-center gap-2">
          <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">compare_arrows</mat-icon>
          FUEL & DECARBONISATION COMPARISON MATRIX
        </h3>

        <table class="w-full text-left font-mono text-xs text-stone-300">
          <thead>
            <tr class="border-b border-stone-800 text-stone-500 text-[11px] uppercase">
              <th class="pb-2">Fuel Energy Carrier</th>
              <th class="pb-2">LHV (MJ/kg)</th>
              <th class="pb-2">Specific Energy</th>
              <th class="pb-2">CO2 Emissions Rate</th>
              <th class="pb-2">Thermal Efficiency</th>
              <th class="pb-2">Est. Fuel Cost / Tonne</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-stone-800/60">
            <tr [class.bg-emerald-950\x2f30]="sim.combustion().fuelType === 'NATURAL_GAS'">
              <td class="py-2.5 font-bold text-white">Natural Gas (Baseline)</td>
              <td>48.0</td>
              <td>168.4 kWh/t</td>
              <td class="text-rose-400">42.8 kg CO2/t</td>
              <td>72.7%</td>
              <td>£ 8.40</td>
            </tr>

            <tr [class.bg-emerald-950\x2f30]="sim.combustion().fuelType === 'HYDROGEN'">
              <td class="py-2.5 font-bold text-emerald-400">Green Hydrogen (100% H2)</td>
              <td>120.0</td>
              <td>164.2 kWh/t</td>
              <td class="text-emerald-400 font-bold">0.0 kg CO2/t (-100%)</td>
              <td>74.2%</td>
              <td>£ 22.10</td>
            </tr>

            <tr [class.bg-emerald-950\x2f30]="sim.combustion().fuelType === 'BIOGAS'">
              <td class="py-2.5 font-bold text-amber-400">Upgraded Biogas</td>
              <td>35.0</td>
              <td>172.1 kWh/t</td>
              <td class="text-emerald-300">8.2 kg CO2/t (-81%)</td>
              <td>71.5%</td>
              <td>£ 12.80</td>
            </tr>

            <tr [class.bg-emerald-950\x2f30]="sim.combustion().fuelType === 'ELECTRIC'">
              <td class="py-2.5 font-bold text-cyan-400">Direct Electric Resistance</td>
              <td>3.6</td>
              <td>142.0 kWh/t</td>
              <td class="text-emerald-400 font-bold">0.0 kg CO2/t (-100%)</td>
              <td>88.5%</td>
              <td>£ 19.50</td>
            </tr>
          </tbody>
        </table>
      </div>

    </div>
  `
})
export class ElectrificationLabComponent {
  readonly sim = inject(KilnSimulationService);

  onFuelTypeSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as FuelType;
    this.sim.setFuelType(val);
  }
}
