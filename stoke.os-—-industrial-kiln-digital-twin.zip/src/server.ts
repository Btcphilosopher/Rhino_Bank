import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '10mb' }));

const angularApp = new AngularNodeAppEngine();

// --- Server-Side Gemini API Client ---
const ai = new GoogleGenAI({
  apiKey: process.env['GEMINI_API_KEY'] || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// ==========================================
// STOKE.OS REST API ENDPOINTS
// ==========================================

app.get('/api/v1/kilns', (_req, res) => {
  res.json({
    id: 'KILN-AIRE-01',
    name: 'Aire Valley Hoffmann Ring Kiln #01',
    architecture: 'HOFFMANN',
    chamberCount: 12,
    nominalCapacityTonneDay: 1020,
    brickTypes: ['Yorkshire Stock Facing', 'Class A Engineering', 'Terracotta Tile'],
    status: 'RUNNING'
  });
});

app.get('/api/v1/chambers', (_req, res) => {
  res.json({
    timestamp: new Date().toISOString(),
    chambersCount: 12,
    activeFiringFront: 8,
    status: 'NORMAL'
  });
});

app.get('/api/v1/firing', (_req, res) => {
  res.json({
    activeChamber: 8,
    progressPercent: 62.4,
    speedChambersPerDay: 1.8,
    peakAtmosphereC: 1080,
    peakCoreC: 982,
    thermalLagC: 98
  });
});

app.get('/api/v1/temperature', (_req, res) => {
  res.json({
    zones: [
      { chamber: 1, atmosphereC: 95, coreC: 70 },
      { chamber: 2, atmosphereC: 25, coreC: 25 },
      { chamber: 3, atmosphereC: 60, coreC: 35 },
      { chamber: 4, atmosphereC: 140, coreC: 80 },
      { chamber: 5, atmosphereC: 420, coreC: 310 },
      { chamber: 6, atmosphereC: 780, coreC: 610 },
      { chamber: 7, atmosphereC: 1020, coreC: 920 },
      { chamber: 8, atmosphereC: 1080, coreC: 982 },
      { chamber: 9, atmosphereC: 920, coreC: 890 },
      { chamber: 10, atmosphereC: 680, coreC: 650 },
      { chamber: 11, atmosphereC: 390, coreC: 360 },
      { chamber: 12, atmosphereC: 180, coreC: 150 }
    ]
  });
});

app.get('/api/v1/airflow', (_req, res) => {
  res.json({
    fanRpm: 1240,
    stackPressurePa: -18,
    totalExhaustFlowM3h: 18400,
    primaryAirM3h: 6200,
    secondaryAirM3h: 12200
  });
});

app.get('/api/v1/fuel', (_req, res) => {
  res.json({
    fuelType: 'NATURAL_GAS',
    flowKgH: 215,
    powerMW: 2.86,
    co2KgH: 578
  });
});

app.get('/api/v1/quality', (_req, res) => {
  res.json({
    activeBatch: 'BATCH BRK-2026-004281',
    estCompressiveStrengthNmm2: 38.2,
    estWaterAbsorptionPercent: 8.8,
    defectRiskCount: 0,
    qualityPassRate: 98.4
  });
});

app.get('/api/v1/scenarios', (_req, res) => {
  res.json([
    { id: 'BASELINE', name: 'Baseline Operational State' },
    { id: 'DAMPER_JAM_CH07', name: 'Damper Failure - Chamber 07' },
    { id: 'HIGH_MOISTURE', name: 'High Moisture Green Brick Batch' },
    { id: 'FAN_TRIP', name: 'Exhaust Fan Speed Drop' },
    { id: 'FAST_COOLING_QUARTZ', name: 'Uncontrolled Rapid Cooling' },
    { id: 'HYDROGEN_CONVERSION', name: 'Electrification & Hydrogen Blend' }
  ]);
});

// --- AI Thermal Diagnostics Endpoint ---
app.post('/api/v1/kiln/analyze', async (req, res) => {
  try {
    const telemetry = req.body;
    const prompt = `You are a senior industrial kiln thermal process engineer analyzing live digital twin telemetry for a Hoffmann-style ceramic brick kiln.
    
Telemetry Payload:
${JSON.stringify(telemetry, null, 2)}

Provide a structured thermal analysis in strict JSON with the following fields:
1. "summary": Concise executive summary of kiln state and thermal front progression.
2. "thermalLagAssessment": Technical assessment of atmosphere vs product core thermal lag and heat penetration.
3. "defectRisks": Array of objects [{ "chamberId": number, "risk": "NONE"|"LOW"|"MEDIUM"|"HIGH"|"CRITICAL", "cause": string, "recommendation": string }].
4. "fuelEfficiencyOptimization": Advice on excess air ratio, fuel stoking balance, and heat recovery.
5. "overallHealthScore": Number 0-100 representing overall process compliance.
6. "recommendedActions": Array of bullet strings for operators.

Return ONLY valid JSON matching this schema.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      }
    });

    const text = response.text || '';
    const parsed = JSON.parse(text);
    res.json(parsed);
  } catch (error: unknown) {
    console.error('Gemini Kiln Analysis API Error:', error);
    // Provide structured fallback response if Gemini key is missing or errored
    res.json({
      summary: 'Kiln firing front is progressing normally at 1.8 chambers/day. Core thermal lag is within nominal 95°C tolerance.',
      thermalLagAssessment: 'Chamber 08 brick core temperature is 982°C vs 1080°C atmosphere, yielding appropriate soaking density.',
      defectRisks: [
        {
          chamberId: 6,
          risk: 'LOW',
          cause: 'Rapid cooling gradient through 573°C quartz inversion zone',
          recommendation: 'Slightly reduce exhaust damper D-06 to lower cold air draft.'
        }
      ],
      fuelEfficiencyOptimization: 'Fuel consumption is 2.86 MW with 72.7% thermal efficiency. Heat recovery to green brick dryers is operating at 0.58 MW.',
      overallHealthScore: 94,
      recommendedActions: [
        'Maintain current natural gas feed rate of 215 kg/h.',
        'Verify pressure differential in flue line #07.',
        'Check green brick moisture content on Extrusion Line 02.'
      ]
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`STOKE.OS Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
