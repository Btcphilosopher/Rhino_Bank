/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Journey, Locomotive, HeritageEvent, MenuItem, MerchItem, MapPoint } from './types';

export const JOURNEYS: Journey[] = [
  {
    id: 'dales-explorer',
    name: 'Dales Explorer',
    tagline: 'Ribblehead & Settle',
    description: 'Traverse the majestic Yorkshire Dales, climbing high above the rugged limestone valleys before crossing the iconic twenty-four arches of the Ribblehead Viaduct.',
    route: 'Harrogate • Settle • Ribblehead • Garsdale • Harrogate',
    duration: '5h 30m',
    price: 65,
    firstClassPrice: 125,
    image: 'https://images.unsplash.com/photo-1541417904950-b855846fe074?auto=format&fit=crop&q=80&w=1200',
    departures: ['09:15', '14:30'],
    availability: 'Good Availability',
    highlights: ['Ribblehead Viaduct Crossings', 'Stunning Yorkshire Dales Vistas', 'Chamber Music on Board', 'Settle Artisan Lunch Stop']
  },
  {
    id: 'york-whitby',
    name: 'York & Whitby Coastline',
    tagline: 'Coastline Steam Special',
    description: 'An extraordinary trans-Yorkshire voyage combining ancient cathedral beauty with dramatic, sea-salted cliffs. Journey through the North York Moors to the historic fishing port of Whitby.',
    route: 'Harrogate • York • Pickering • Whitby • Harrogate',
    duration: '6h 15m',
    price: 75,
    firstClassPrice: 145,
    image: 'https://images.unsplash.com/photo-1610448721566-47369c768e70?auto=format&fit=crop&q=80&w=1200',
    departures: ['08:00', '13:15'],
    availability: 'Selling Fast',
    highlights: ['Whitby Abbey Overlook', 'North York Moors Wilderness', 'Seaside Fish & Chips Feast', 'Historic York Station Departure']
  },
  {
    id: 'bronte-country',
    name: 'Brontë Country Railway',
    tagline: 'Haworth & Keighley',
    description: 'Step into the poetic heart of wild heather and rolling hills. Journey on our historic branch line to Haworth, the home of the legendary Brontë sisters.',
    route: 'Harrogate • Leeds • Keighley • Haworth • Oxenhope • Harrogate',
    duration: '4h 45m',
    price: 76,
    firstClassPrice: 135,
    image: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&q=80&w=1200',
    departures: ['10:00', '15:15'],
    availability: 'Limited Seats',
    highlights: ['Haworth Parsonage Tour', 'Vintage Station Sightseeing', 'Wuthering Heights Moorland Walks', 'Traditional Cream Tea on Board']
  },
  {
    id: 'castles-dales',
    name: 'Castles & Dales Pullman',
    tagline: 'Skipton & Bolton Abbey',
    description: 'A luxurious combination of imposing medieval fortifications and the tranquil, wooded ruins of Bolton Abbey along the banks of the River Wharfe.',
    route: 'Harrogate • Skipton • Bolton Abbey • Ilkley • Harrogate',
    duration: '5h 00m',
    price: 70,
    firstClassPrice: 130,
    image: 'https://images.unsplash.com/photo-1502481851512-e9e2529bbbf9?auto=format&fit=crop&q=80&w=1200',
    departures: ['09:45', '14:00'],
    availability: 'Good Availability',
    highlights: ['Bolton Abbey Woodland Stroll', 'Skipton Castle Premium Admission', 'Gourmet 3-Course Lunch', 'Stately Manor Sightings']
  },
  {
    id: 'christmas-express',
    name: 'Christmas Steam Express',
    tagline: 'Winter Moorland Magic',
    description: 'Experience the pure magic of Christmas with steam drifting through frosty winter landscapes, smelling of spiced wine, toasted chestnuts, and holiday nostalgia.',
    route: 'Harrogate • Ripon • Pickering • North York Moors • Harrogate',
    duration: '3h 30m',
    price: 85,
    firstClassPrice: 160,
    image: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=1200',
    departures: ['11:00', '16:00', '19:00'],
    availability: 'Almost Sold Out',
    highlights: ['Visit from Father Christmas', 'Carols by Candlelight', 'Traditional Mince Pies & Mulled Wine', 'Illuminated Train Forest Ride']
  }
];

export const LOCOMOTIVES: Locomotive[] = [
  {
    id: 'sir-nigel-gresley',
    name: 'No. 60007 "Sir Nigel Gresley"',
    number: '60007',
    classType: 'LNER Class A4',
    designer: 'Sir Nigel Gresley',
    built: '1937',
    status: 'Operational',
    wheelArrangement: '4-6-2 (Pacific)',
    description: 'The sister locomotive to the world-famous "Mallard", this legendary streamlined steam locomotive represents the absolute zenith of British steam engineering, finished in its iconic LNER Brunswick Blue livery.',
    restorationStory: 'Fully overhauled in a meticulous 10-year restoration ending in 2022, costing over £1.2 million. Every single copper pipe, brass fitting, and boiler plate was tested, polished, and restored by hand to meet rigorous modern safety standards.',
    powerOutput: 'approx. 2,200 hp',
    weight: '167 tonnes (engine and tender)',
    topSpeed: '112 mph (holder of postwar steam speed record)',
    image: 'https://images.unsplash.com/photo-1532103054090-334e6e60ab29?auto=format&fit=crop&q=80&w=1200',
    gallery: [
      'https://images.unsplash.com/photo-1532103054090-334e6e60ab29?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1582281227099-7926e13ac99c?auto=format&fit=crop&q=80&w=600'
    ]
  },
  {
    id: 'yorkshire-tyke',
    name: 'No. 45596 "Yorkshire Tyke"',
    number: '45596',
    classType: 'LMS Jubilee Class',
    designer: 'Sir William Stanier',
    built: '1934',
    status: 'Operational',
    wheelArrangement: '4-6-0',
    description: 'An elegant workhorse of the London Midland & Scottish Railway, perfectly suited to heavy passenger express runs over Yorkshire’s formidable gradients.',
    restorationStory: 'Rescued from a scrapyard in Barry, Wales, in 1973. It was rebuilt from a near-skeletal state over thirty years by dedicated Yorkshire railway volunteers and engineers, roaring back to life in 2011.',
    powerOutput: 'approx. 1,650 hp',
    weight: '135 tonnes',
    topSpeed: '90 mph',
    image: 'https://images.unsplash.com/photo-1582281227099-7926e13ac99c?auto=format&fit=crop&q=80&w=1200',
    gallery: [
      'https://images.unsplash.com/photo-1582281227099-7926e13ac99c?auto=format&fit=crop&q=80&w=600'
    ]
  },
  {
    id: 'black-five',
    name: 'No. 44871 "Black Five"',
    number: '44871',
    classType: 'LMS Stanier Class 5',
    designer: 'Sir William Stanier',
    built: '1945',
    status: 'In Workshop',
    wheelArrangement: '4-6-0',
    description: 'Arguably the most successful mixed-traffic steam locomotive design ever built, the Class 5 represents standard mechanical perfection. It can haul anything from heavy coal wagons to premium dining expresses.',
    restorationStory: 'Currently undergoing its ten-year boiler retubing and crown-stay inspections in our central Harrogate Engineering Workshop. Scheduled to return to mainline duties in autumn.',
    powerOutput: 'approx. 1,500 hp',
    weight: '128 tonnes',
    topSpeed: '85 mph',
    image: 'https://images.unsplash.com/photo-1517433456452-f9633a875f6f?auto=format&fit=crop&q=80&w=1200',
    gallery: []
  }
];

export const EVENTS: HeritageEvent[] = [
  {
    id: '1940s-weekend',
    title: '1940s Wartime Weekend',
    subtitle: 'Step Back in Time',
    date: '2026-07-26',
    location: 'Harrogate & Haworth Stations',
    price: 32,
    category: 'Festival',
    description: 'Immerse yourself in Britain’s finest wartime recreation. Complete with Big Band music, vintage military vehicles, tea dances, Churchill impersonators, and magnificent steam locomotives pulling evocative troop trains.',
    image: 'https://images.unsplash.com/photo-1568254183919-78a4f43a2877?auto=format&fit=crop&q=80&w=1200',
    featured: true
  },
  {
    id: 'steam-gala',
    title: 'Grand Autumn Steam Gala',
    subtitle: 'The Ultimate Enthusiasts Meet',
    date: '2026-10-09',
    location: 'Full Railway Network',
    price: 45,
    category: 'Gala',
    description: 'A spectacular intensive weekend timetable featuring all operational home fleet engines and two surprise guest locomotives. Expect double-headers, heavy goods demonstration runs, and late-night steam operations.',
    image: 'https://images.unsplash.com/photo-1541417904950-b855846fe074?auto=format&fit=crop&q=80&w=1200',
    featured: true
  },
  {
    id: 'whisky-express',
    title: 'Steam & Single Malt Evening',
    subtitle: 'Luxury Tasting & Live Jazz',
    date: '2026-08-15',
    location: 'The Yorkshire Pullman carriage',
    price: 85,
    category: 'Dining',
    description: 'A twilight departure smelling of rich oak and coal smoke. Sample five exquisite single malt whiskies from historic Yorkshire and Scottish Highlands distilleries, paired with hand-crafted local cheeses.',
    image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&q=80&w=1200',
    featured: false
  },
  {
    id: 'photo-day',
    title: 'Steam Photography Masterclass',
    subtitle: 'Golden Hour Trackside Access',
    date: '2026-09-04',
    location: 'Ribblehead & Garsdale Banks',
    price: 95,
    category: 'Photography',
    description: 'Gain exclusive, supervised access to premium field locations and lineside vantage points. Guided by an award-winning railway photojournalist, with engine runpasts staged perfectly against the Yorkshire sunset.',
    image: 'https://images.unsplash.com/photo-1610448721566-47369c768e70?auto=format&fit=crop&q=80&w=1200',
    featured: false
  }
];

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'm1',
    name: 'Yorkshire Fillet of Beef',
    category: 'Mains',
    description: 'Dry-aged fillet of premium grass-fed beef from Swaledale farm, served with truffle-infused potato fondant, heritage carrots, roasted bone marrow, and a rich Black Sheep Ale reduction.',
    price: 34,
    localSource: 'Swaledale Farms, North Yorkshire'
  },
  {
    id: 'm2',
    name: 'Whitby Cod & Crab Gateau',
    category: 'Mains',
    description: 'Pan-seared North Sea cod loin resting on a bed of fresh Whitby brown crab and local samphire, accompanied by a velvety, saffron-infused butter sauce.',
    price: 29,
    localSource: 'Lockwood Fishmongers, Whitby'
  },
  {
    id: 'm3',
    name: 'Yorkshire Wensleydale Soufflé',
    category: 'Starters',
    description: 'A twice-baked, exceptionally light cheese soufflé utilizing traditional rich Wensleydale cheese, paired with local candied walnuts and a wild pear salad.',
    price: 12,
    localSource: 'Wensleydale Creamery, Hawes'
  },
  {
    id: 'm4',
    name: 'Warm Ginger & Harrogate Honey Parkin',
    category: 'Desserts',
    description: 'The quintessential Yorkshire oatmeal ginger cake, drenched in local wild honey caramel and served with a generous scoop of artisanal clotted cream ice cream.',
    price: 10,
    localSource: 'Harrogate Town Aviaries & Honey Co.'
  },
  {
    id: 'm5',
    name: 'LNER Centenary Claret (2018)',
    category: 'Wine',
    description: 'A private reserve, full-bodied Bordeaux blend crafted exclusively for our dining carriages, showcasing notes of dark plum, tobacco leaf, and toasted cedar wood.',
    price: 48,
    localSource: 'Private Bottling, Merchant Vintners, York'
  },
  {
    id: 'm6',
    name: 'Brunswick Gold Golden Ale',
    category: 'Yorkshire Ales',
    description: 'A clean, crisp, citrus-forward premium pale golden ale brewed specifically to celebrate our locomotives, offering a beautifully refreshing finish.',
    price: 6.5,
    localSource: 'Cold Bath Brewing Co., Harrogate'
  }
];

export const MERCHANDISE: MerchItem[] = [
  {
    id: 'merch-art-print',
    name: 'LNER Class A4 Centenary Art Print',
    category: 'Prints',
    price: 35,
    description: 'A museum-quality Giclée reproduction of the classic 1930s LNER marketing poster, showing No. 60007 streamlined against the dramatic Yorkshire landscape. Printed on 310gsm archival cotton rag.',
    image: 'https://images.unsplash.com/photo-1610448721566-47369c768e70?auto=format&fit=crop&q=80&w=400',
    rating: 4.9
  },
  {
    id: 'merch-model',
    name: 'Hornby No. 60007 "Sir Nigel Gresley" OO Scale Model',
    category: 'Models',
    price: 245,
    description: 'A breathtakingly detailed, collector-edition OO gauge replica model featuring a heavy-diecast chassis, pre-installed sound decoder, and fully working front and rear lights.',
    image: 'https://images.unsplash.com/photo-1582281227099-7926e13ac99c?auto=format&fit=crop&q=80&w=400',
    rating: 5.0
  },
  {
    id: 'merch-book',
    name: 'Yorkshire Through Steam: The Photographic Odyssey',
    category: 'Books',
    price: 45,
    description: 'A 280-page, hard-bound coffee table book featuring masterfully captured photography of Harrogate Heritage Railway’s iconic routes, historical workshops, and breathtaking landscapes.',
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=400',
    rating: 4.8
  },
  {
    id: 'merch-pocketwatch',
    name: 'The Engineer’s Brass Pocket Watch',
    category: 'Collectibles',
    price: 120,
    description: 'An elegant, mechanical, hand-wound pocket watch with a polished solid brass case, engraved with the Harrogate Heritage Railway coat of arms. Features a visual skeleton window.',
    image: 'https://images.unsplash.com/photo-1509048191080-d2984bad6ae5?auto=format&fit=crop&q=80&w=400',
    rating: 4.9
  }
];

export const MAP_POINTS: MapPoint[] = [
  {
    id: 'map-harrogate',
    name: 'Harrogate Station',
    type: 'station',
    x: 25,
    y: 70,
    description: 'Our luxurious central terminus, featuring the lovingly restored Victorian canopy, the Booking Hall Tea Rooms, and the historic signal box dating back to 1884.',
    tagline: 'Home of the Railway',
    image: 'https://images.unsplash.com/photo-1568254183919-78a4f43a2877?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'map-york',
    name: 'York Station & NRM',
    type: 'station',
    x: 55,
    y: 80,
    description: 'An architectural wonder of the 19th century, connecting Harrogate’s steam heritage directly with the National Railway Museum and ancient medieval city walls.',
    tagline: 'The Gateway to Antiquity',
    image: 'https://images.unsplash.com/photo-1502481851512-e9e2529bbbf9?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'map-haworth',
    name: 'Haworth Station',
    type: 'station',
    x: 15,
    y: 88,
    description: 'A complete time-capsule station frozen in the Edwardian era, resting beneath the cobblestones of Brontë-country hilltops.',
    tagline: 'Poetic Hearth of the Moors',
    image: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'map-whitby',
    name: 'Whitby Seaside Terminus',
    type: 'station',
    x: 90,
    y: 18,
    description: 'Where majestic steel engines meet the salty spray of the North Sea, overlooked by the ominous gothic cliffs of Whitby Abbey.',
    tagline: 'Where Steam Meets Sea',
    image: 'https://images.unsplash.com/photo-1610448721566-47369c768e70?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'map-ribblehead',
    name: 'Ribblehead Viaduct',
    type: 'landmark',
    x: 10,
    y: 30,
    description: 'A monument to Victorian engineering. 24 soaring stone arches scaling the high wilderness of Batty Moss in the Settle-Carlisle line.',
    tagline: 'Colossus of the Dales',
    image: 'https://images.unsplash.com/photo-1541417904950-b855846fe074?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'map-bolton-abbey',
    name: 'Bolton Abbey Estate',
    type: 'landmark',
    x: 35,
    y: 50,
    description: 'Stunning 12th-century Augustinian monastery ruins nestled in deep Yorkshire woodlands along the pristine River Wharfe.',
    tagline: 'Tranquil Monastic Ruins',
    image: 'https://images.unsplash.com/photo-1502481851512-e9e2529bbbf9?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'map-devonshire-arms',
    name: 'The Devonshire Arms Hotel',
    type: 'hotel',
    x: 38,
    y: 45,
    description: 'A multi-award-winning 17th-century country house spa hotel located on the Bolton Abbey Estate. Highly recommended for overnight packages.',
    tagline: 'Luxury Country House Spa',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'map-box signal',
    name: 'The Signalman’s Feast',
    type: 'dining',
    x: 28,
    y: 65,
    description: 'Exquisite, Michelin-star local bistro catering to train travelers and locals alike, crafting the best Sunday lamb in the valley.',
    tagline: 'Fine Yorkshire Gastronomy',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=400'
  }
];
