/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Calendar, MapPin, Tag, ArrowRight, Star, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EVENTS } from '../data';
import { HeritageEvent } from '../types';

interface EventsCalendarProps {
  onSelectEvent: (eventTitle: string, price: number) => void;
}

export default function EventsCalendar({ onSelectEvent }: EventsCalendarProps) {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'Gala' | 'Dining' | 'Festival' | 'Family' | 'Photography'>('all');
  const [featuredEvent, setFeaturedEvent] = useState<HeritageEvent>(EVENTS[0]);

  const categories = [
    { id: 'all', label: 'ALL EVENTS' },
    { id: 'Gala', label: 'STEAM GALAS' },
    { id: 'Dining', label: 'DINING SERVICES' },
    { id: 'Festival', label: 'FESTIVALS' },
    { id: 'Photography', label: 'PHOTOGRAPHY DAYS' }
  ];

  const filteredEvents = EVENTS.filter((e) => {
    if (selectedCategory === 'all') return true;
    return e.category === selectedCategory;
  });

  return (
    <section className="bg-[#EFE9DD] text-[#1E1E1C] py-20 border-t border-[#B58B3A]/30">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Headings */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#A12A2A]">
            YORKSHIRE HERITAGE AGENDA
          </span>
          <h3 className="text-3xl md:text-5xl font-bold tracking-[0.1em] uppercase font-display text-[#1E1E1C] mt-2">
            EVENTS CALENDAR
          </h3>
          <p className="text-xs text-[#8A8D90] font-sans mt-3 max-w-lg mx-auto leading-relaxed">
            Reserve tickets for our legendary wartime weekend, atmospheric steam galas, twilight tastings, and seasonal celebrations.
          </p>
        </div>

        {/* Categories filters bar */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`text-[9px] font-bold tracking-[0.15em] px-4 py-2 border rounded-sm transition-all uppercase cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-[#1E1E1C] border-[#1E1E1C] text-[#EFE9DD]'
                  : 'border-[#B58B3A]/20 text-[#8A8D90] hover:text-[#1E1E1C] hover:border-[#1E1E1C]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Splits Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Featured Gala Panel (Left, W-5/12) */}
          <div className="lg:col-span-5 bg-white border border-[#B58B3A]/30 rounded-sm overflow-hidden shadow-xl flex flex-col justify-between p-6 text-left group">
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center border-b border-[#B58B3A]/10 pb-3">
                <span className="text-[9px] font-bold tracking-[0.25em] text-[#A12A2A] uppercase flex items-center gap-1.5">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  FEATURED EXPERIENCE
                </span>
                <span className="text-[9px] font-bold tracking-wider text-[#8A8D90] font-sans">
                  {featuredEvent.date}
                </span>
              </div>

              <div className="h-48 overflow-hidden rounded-sm relative border border-[#B58B3A]/10">
                <img
                  src={featuredEvent.image}
                  alt={featuredEvent.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              </div>

              <div>
                <h4 className="text-xl font-bold tracking-wide text-[#1E1E1C] uppercase group-hover:text-[#A12A2A] transition-colors">
                  {featuredEvent.title}
                </h4>
                <p className="text-[10px] italic text-[#B58B3A] mt-0.5">{featuredEvent.subtitle}</p>
                <p className="text-xs text-[#353535] font-sans leading-relaxed mt-3">
                  {featuredEvent.description}
                </p>
              </div>

              <div className="flex flex-col gap-2 mt-2 pt-3 border-t border-[#B58B3A]/10 text-[10px] text-[#8A8D90] font-sans font-semibold">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#A12A2A]" />
                  <span>Depot Area: {featuredEvent.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Tag className="w-4 h-4 text-[#B58B3A]" />
                  <span>Fare: from £{featuredEvent.price} standard class entry</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectEvent(featuredEvent.title, featuredEvent.price)}
              className="mt-6 w-full bg-[#1E1E1C] hover:bg-[#A12A2A] text-[#EFE9DD] hover:text-white font-bold text-xs tracking-[0.2em] py-3.5 rounded-sm uppercase transition-all duration-300 transform shadow-md"
            >
              SECURE TICKETS NOW
            </button>
          </div>

          {/* Core Calendar List (Right, W-7/12) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <span className="text-[9px] font-bold tracking-[0.2em] text-[#8A8D90] uppercase text-left">
              UPCOMING DEPARTURES ({filteredEvents.length})
            </span>
            <div className="flex flex-col gap-4 max-h-[580px] overflow-y-auto pr-2">
              <AnimatePresence mode="popLayout">
                {filteredEvents.map((evt) => (
                  <motion.div
                    key={evt.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setFeaturedEvent(evt)}
                    className={`bg-white p-5 rounded-sm border hover:border-[#A12A2A] transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer text-left shadow-sm ${
                      featuredEvent.id === evt.id ? 'border-[#A12A2A] shadow-md ring-1 ring-[#A12A2A]/30' : 'border-[#B58B3A]/15'
                    }`}
                  >
                    <div className="flex gap-4 items-start md:items-center">
                      {/* Left visual date badge */}
                      <div className="bg-[#1E1E1C] text-[#EFE9DD] rounded-sm w-16 h-16 flex flex-col items-center justify-center p-2 border-b-2 border-[#B58B3A]">
                        <span className="text-[8px] font-bold uppercase tracking-widest text-[#B58B3A]">
                          {new Date(evt.date).toLocaleDateString('en-GB', { month: 'short' })}
                        </span>
                        <span className="text-xl font-bold font-sans">
                          {new Date(evt.date).getDate()}
                        </span>
                      </div>

                      <div className="flex flex-col">
                        <span className="text-[8px] font-bold tracking-widest text-[#A12A2A] uppercase">
                          {evt.category}
                        </span>
                        <h5 className="text-sm font-bold tracking-wide uppercase text-[#1E1E1C] mt-0.5">
                          {evt.title}
                        </h5>
                        <p className="text-[10px] text-[#8A8D90] font-sans mt-0.5">
                          {evt.location}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 self-end md:self-auto pt-2 md:pt-0 border-t md:border-t-0 border-[#B58B3A]/10 w-full md:w-auto justify-between md:justify-end">
                      <span className="text-xs font-bold text-[#1E1E1C] font-sans">
                        £{evt.price}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectEvent(evt.title, evt.price);
                        }}
                        className="p-2.5 rounded-full bg-[#EFE9DD] hover:bg-[#A12A2A] text-[#1E1E1C] hover:text-white transition-colors"
                        title="Book tickets for this event"
                        aria-label="Secure Event Tickets"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
