/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, Award, Heart, CheckCircle, Info, Hammer } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LOCOMOTIVES } from '../data';
import { Locomotive } from '../types';

export default function FleetExplorer() {
  const [selectedLoco, setSelectedLoco] = useState<Locomotive>(LOCOMOTIVES[0]);

  return (
    <section className="bg-[#1E1E1C] text-[#EFE9DD] py-20 border-t border-[#B58B3A]/30 relative overflow-hidden">
      {/* Decorative technical line blueprint */}
      <div className="absolute right-10 bottom-10 opacity-5 pointer-events-none w-96 h-96">
        <svg viewBox="0 0 100 100" className="w-full h-full text-[#B58B3A] stroke-current fill-none">
          <rect x="5" y="40" width="90" height="20" rx="2" />
          <circle cx="25" cy="60" r="8" />
          <circle cx="45" cy="60" r="8" />
          <circle cx="65" cy="60" r="8" />
          <circle cx="80" cy="60" r="4" />
          <path d="M5 50 L95 50" />
          <line x1="25" y1="60" x2="65" y2="60" strokeWidth="2" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        {/* Headings */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#B58B3A]">
            LIVING INDUSTRIAL LEGACY
          </span>
          <h3 className="text-3xl md:text-5xl font-bold tracking-[0.1em] uppercase font-display text-[#F8F4EC] mt-2">
            THE STEAM FLEET
          </h3>
          <p className="text-xs text-[#8A8D90] font-sans mt-3 max-w-lg mx-auto leading-relaxed">
            Custodians of speed and mechanical majesty. Browse our active roster of meticulously preserved locomotives and historic coaches.
          </p>
        </div>

        {/* Master Selector Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Engine Menu Wheel (Left, W-4/12) */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            <span className="text-[9px] font-bold tracking-[0.25em] text-[#B58B3A] uppercase mb-2 text-left">
              ACTIVE ROSTER
            </span>
            {LOCOMOTIVES.map((loco) => {
              const isSelected = selectedLoco.id === loco.id;
              return (
                <button
                  key={loco.id}
                  onClick={() => setSelectedLoco(loco)}
                  className={`w-full text-left p-5 border rounded-sm transition-all flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'border-[#B58B3A] bg-[#353535]/40 shadow-lg'
                      : 'border-[#353535] bg-[#1a1a19] hover:border-[#8A8D90]/50'
                  }`}
                >
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] font-semibold text-[#8A8D90] tracking-widest uppercase">
                      {loco.number} • {loco.classType}
                    </span>
                    <h4 className={`text-sm font-bold tracking-wider uppercase transition-colors ${
                      isSelected ? 'text-[#B58B3A]' : 'text-[#EFE9DD]'
                    }`}>
                      {loco.name.split('"')[1] || loco.name}
                    </h4>
                  </div>

                  {/* Status Indicator Badge */}
                  <span className={`text-[8px] font-bold tracking-widest uppercase px-2 py-1 rounded-sm border ${
                    loco.status === 'Operational'
                      ? 'bg-[#204334]/20 border-[#204334] text-[#81C784]'
                      : 'bg-[#B96A3C]/20 border-[#B96A3C] text-[#FFB74D]'
                  }`}>
                    {loco.status}
                  </span>
                </button>
              );
            })}

            {/* Behind the scenes workshop notice */}
            <div className="bg-[#111110] border border-[#353535] p-5 rounded-sm text-left mt-4">
              <h5 className="text-[10px] font-bold tracking-widest text-[#B58B3A] uppercase mb-2 flex items-center gap-1.5">
                <Hammer className="w-3.5 h-3.5" />
                WORKSHOP OBSERVATION DECK
              </h5>
              <p className="text-[10px] text-[#8A8D90] font-sans leading-relaxed">
                Our main locomotive overhaul works in Harrogate are open for public guided viewing every Wednesday. Meet the master boilermakers and apprentice machinists.
              </p>
            </div>
          </div>

          {/* Engine Focus Dashboard (Right, W-8/12) */}
          <div className="lg:col-span-8 bg-[#111110] border border-[#B58B3A]/20 p-6 md:p-8 rounded-sm">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedLoco.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.4 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left"
              >
                {/* Engine Image & Gallery Column */}
                <div className="flex flex-col gap-4">
                  <div className="h-56 md:h-64 rounded-sm overflow-hidden relative border border-[#353535]">
                    <img
                      src={selectedLoco.image}
                      alt={selectedLoco.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  </div>

                  {/* Specifications Card List */}
                  <div className="bg-[#1E1E1C] border border-[#353535] p-4 rounded-sm flex flex-col gap-2">
                    <h5 className="text-[9px] font-bold tracking-widest text-[#B58B3A] uppercase mb-2 border-b border-[#353535] pb-2">
                      TECHNICAL SPECIFICATIONS
                    </h5>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-[10px] font-sans">
                      <div className="flex justify-between border-b border-[#353535] pb-1">
                        <span className="text-[#8A8D90]">Designer:</span>
                        <span className="font-bold">{selectedLoco.designer}</span>
                      </div>
                      <div className="flex justify-between border-b border-[#353535] pb-1">
                        <span className="text-[#8A8D90]">Built:</span>
                        <span className="font-bold">{selectedLoco.built}</span>
                      </div>
                      <div className="flex justify-between border-b border-[#353535] pb-1">
                        <span className="text-[#8A8D90]">Power Output:</span>
                        <span className="font-bold">{selectedLoco.powerOutput}</span>
                      </div>
                      <div className="flex justify-between border-b border-[#353535] pb-1">
                        <span className="text-[#8A8D90]">Top Speed:</span>
                        <span className="font-bold">{selectedLoco.topSpeed}</span>
                      </div>
                      <div className="flex justify-between border-b border-[#353535] pb-1">
                        <span className="text-[#8A8D90]">Total Weight:</span>
                        <span className="font-bold">{selectedLoco.weight}</span>
                      </div>
                      <div className="flex justify-between border-b border-[#353535] pb-1">
                        <span className="text-[#8A8D90]">Wheel Config:</span>
                        <span className="font-bold">{selectedLoco.wheelArrangement}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* History & Overhaul narrative columns */}
                <div className="flex flex-col gap-5 justify-between">
                  <div className="flex flex-col gap-3">
                    <span className="text-[9px] font-bold tracking-[0.2em] text-[#B58B3A] uppercase">
                      HISTORY & CLASS ARCHIVE
                    </span>
                    <h4 className="text-xl font-bold tracking-wide text-[#F8F4EC] uppercase">
                      {selectedLoco.name}
                    </h4>
                    <p className="text-xs text-[#EFE9DD]/80 leading-relaxed font-sans">
                      {selectedLoco.description}
                    </p>
                  </div>

                  <div className="bg-[#1E1E1C] border border-[#B58B3A]/20 p-4 rounded-sm">
                    <h5 className="text-[10px] font-bold tracking-widest text-[#A12A2A] uppercase mb-1.5 flex items-center gap-1.5">
                      <Settings className="w-3.5 h-3.5" />
                      THE OVERHAUL OVERVIEW
                    </h5>
                    <p className="text-[10px] text-[#8A8D90] font-sans leading-relaxed">
                      {selectedLoco.restorationStory}
                    </p>
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>
      </div>
    </section>
  );
}
