/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Anchor, Train, Menu, X, ShoppingCart, Volume2, VolumeX, Moon, Sun } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  openCart: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  cartCount,
  openCart,
  darkMode,
  setDarkMode
}: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [audioEl, setAudioEl] = useState<HTMLAudioElement | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Soft atmospheric ambient train whistle / steam sounds
  useEffect(() => {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2288/2288-84.wav'); // Soft train sound
    audio.loop = true;
    audio.volume = 0.15;
    setAudioEl(audio);

    return () => {
      audio.pause();
    };
  }, []);

  const toggleAmbience = () => {
    if (!audioEl) return;
    if (audioPlaying) {
      audioEl.pause();
    } else {
      audioEl.play().catch(() => {
        // Handle blocked auto-play browser restriction gracefully
      });
    }
    setAudioPlaying(!audioPlaying);
  };

  const navItems = [
    { id: 'home', label: 'JOURNEYS' },
    { id: 'map', label: 'ROUTE MAP' },
    { id: 'dining', label: 'PULLMAN DINING' },
    { id: 'fleet', label: 'THE FLEET' },
    { id: 'engineering', label: 'ENGINEERING & HISTORY' },
    { id: 'events', label: 'EVENTS' },
    { id: 'shop', label: 'MERCHANDISE' }
  ];

  const isLightHeader = scrolled && !darkMode;

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isLightHeader
            ? 'bg-[#EFE9DD]/95 backdrop-blur-md shadow-md border-b border-[#1E1E1C]/10 py-3 text-[#1E1E1C]'
            : scrolled
            ? 'bg-[#1E1E1C]/95 backdrop-blur-md shadow-lg border-b border-[#B58B3A]/20 py-3 text-[#EFE9DD]'
            : 'bg-gradient-to-b from-black/80 to-transparent py-5 text-[#EFE9DD]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between">
          {/* Logo Brand Grouping - Elegant HHR Box */}
          <div
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className={`w-10 h-10 border-2 flex items-center justify-center font-bold text-xs tracking-tighter transition-all ${
              isLightHeader ? 'border-[#1E1E1C] text-[#1E1E1C]' : 'border-[#EFE9DD] text-[#EFE9DD]'
            }`}>
              HHR
            </div>
            <div className="flex flex-col leading-none text-left">
              <span className={`text-sm font-bold uppercase tracking-[0.2em] transition-colors ${
                isLightHeader ? 'text-[#1E1E1C]' : 'text-[#EFE9DD]'
              }`}>
                Harrogate
              </span>
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#B58B3A] font-semibold">
                Heritage Railway
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative text-xs tracking-[0.15em] font-medium uppercase py-2 transition-colors duration-300 ${
                  activeTab === item.id
                    ? 'text-[#B58B3A] font-semibold'
                    : isLightHeader
                    ? 'text-[#1E1E1C]/80 hover:text-[#B58B3A]'
                    : 'text-[#EFE9DD]/80 hover:text-[#B58B3A]'
                }`}
              >
                {item.label}
                {activeTab === item.id && (
                  <motion.div
                    layoutId="underline"
                    className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#B58B3A]"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Right Action Icons & CTA */}
          <div className="flex items-center gap-4">
            {/* Ambient Sound Controller */}
            <button
              onClick={toggleAmbience}
              className={`p-2 rounded-full border transition-all cursor-pointer ${
                isLightHeader
                  ? 'border-[#1E1E1C]/15 text-[#1E1E1C]/80 hover:text-[#B58B3A] hover:border-[#B58B3A]/30'
                  : 'border-[#EFE9DD]/10 text-[#EFE9DD]/80 hover:text-[#B58B3A] hover:border-[#B58B3A]/30'
              }`}
              title="Toggle Steam Atmosphere Ambience"
              aria-label="Toggle Train Ambience Sound"
            >
              {audioPlaying ? (
                <Volume2 className="w-4 h-4 animate-pulse text-[#B58B3A]" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 rounded-full border transition-all cursor-pointer ${
                isLightHeader
                  ? 'border-[#1E1E1C]/15 text-[#1E1E1C]/80 hover:text-[#B58B3A] hover:border-[#B58B3A]/30'
                  : 'border-[#EFE9DD]/10 text-[#EFE9DD]/80 hover:text-[#B58B3A] hover:border-[#B58B3A]/30'
              }`}
              aria-label="Toggle Dark Mode"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Premium Shopping Cart */}
            <button
              onClick={openCart}
              className={`relative p-2 rounded-full border transition-all cursor-pointer ${
                isLightHeader
                  ? 'border-[#1E1E1C]/15 text-[#1E1E1C]/80 hover:text-[#B58B3A] hover:border-[#B58B3A]/30'
                  : 'border-[#EFE9DD]/10 text-[#EFE9DD]/80 hover:text-[#B58B3A] hover:border-[#B58B3A]/30'
              }`}
              aria-label="Shopping Cart"
            >
              <ShoppingCart className="w-4 h-4" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#A12A2A] text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center border border-[#1E1E1C]">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Master Booking Call to Action */}
            <button
              onClick={() => setActiveTab('book')}
              className="hidden sm:flex items-center gap-2 bg-[#B58B3A] hover:bg-[#A12A2A] text-[#1E1E1C] hover:text-white font-medium text-xs tracking-[0.15em] px-5 py-2.5 rounded-sm uppercase transition-all duration-300 transform shadow-md hover:scale-105"
            >
              <Train className="w-4 h-4" />
              BOOK TICKETS
            </button>

            {/* Mobile Hamburger Trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`lg:hidden p-2 transition-all ${
                isLightHeader ? 'text-[#1E1E1C] hover:text-[#B58B3A]' : 'text-[#EFE9DD] hover:text-[#B58B3A]'
              }`}
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-x-0 top-16 z-40 bg-[#1E1E1C] border-b border-[#B58B3A]/30 py-6 px-6 shadow-2xl flex flex-col gap-4 lg:hidden"
          >
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`text-left font-display tracking-[0.2em] text-sm uppercase py-2 border-b border-[#EFE9DD]/5 ${
                  activeTab === item.id ? 'text-[#B58B3A] pl-2 font-bold' : 'text-[#EFE9DD]'
                } transition-all`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => {
                setActiveTab('book');
                setMobileMenuOpen(false);
              }}
              className="w-full text-center bg-[#B58B3A] text-[#1E1E1C] font-semibold text-xs tracking-[0.2em] py-3.5 mt-2 rounded-sm uppercase"
            >
              BOOK JOURNEY TICKETS
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
