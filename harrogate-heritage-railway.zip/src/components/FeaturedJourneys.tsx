/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Clock, Compass, ArrowRight, Star } from 'lucide-react';
import { motion } from 'motion/react';
import { Journey } from '../types';

interface FeaturedJourneysProps {
  journeys: Journey[];
  onSelectJourney: (id: string) => void;
  onNavigateToDining: () => void;
  onNavigateToAbout: () => void;
}

export default function FeaturedJourneys({
  journeys,
  onSelectJourney,
  onNavigateToDining,
  onNavigateToAbout
}: FeaturedJourneysProps) {
  // We grab the first 4 journeys for the grid
  const gridJourneys = journeys.slice(0, 4);

  return (
    <section id="featured-journeys" className="bg-[#EFE9DD] py-16 text-[#1E1E1C]">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="flex justify-between items-end border-b border-[#B58B3A]/30 pb-4 mb-10">
          <div>
            <span className="text-[9px] font-bold tracking-[0.3em] uppercase text-[#A12A2A]">
              PREMIER EXCURSIONS
            </span>
            <h3 className="text-2xl md:text-3xl font-bold tracking-[0.1em] uppercase font-display text-[#1E1E1C] mt-1">
              FEATURED JOURNEYS
            </h3>
          </div>
          <button
            onClick={() => onSelectJourney('')}
            className="text-xs font-bold tracking-[0.15em] text-[#B58B3A] hover:text-[#A12A2A] transition-colors flex items-center gap-1.5 group uppercase"
          >
            VIEW ALL JOURNEYS
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* Triple Column Layout matching mock-up */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* COLUMN 1: Harrogate Our Home (Left, W-3/12 equivalent) */}
          <div className="lg:col-span-3 flex flex-col justify-between bg-[#1E1E1C] text-[#EFE9DD] p-6 rounded-sm border border-[#B58B3A]/20 relative overflow-hidden group">
            {/* Soft decorative engineering watermark */}
            <div className="absolute right-0 bottom-0 opacity-5 pointer-events-none">
              <svg width="200" height="200" viewBox="0 0 100 100" className="text-[#B58B3A] stroke-current fill-none">
                <circle cx="50" cy="50" r="45" strokeWidth="0.5" />
                <path d="M0 50 L100 50" />
              </svg>
            </div>

            <div className="flex flex-col gap-4 z-10">
              <span className="text-[9px] font-bold tracking-[0.25em] text-[#B58B3A] uppercase">
                HARROGATE OUR HOME
              </span>
              
              <div className="overflow-hidden rounded-sm h-48 relative">
                <img
                  src="https://images.unsplash.com/photo-1568254183919-78a4f43a2877?auto=format&fit=crop&q=80&w=600"
                  alt="Elegant Harrogate Town Architecture"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              </div>

              <p className="text-xs tracking-[0.03em] leading-relaxed text-[#EFE9DD]/80 font-sans text-left mt-2">
                Based in the elegant historic spa town of Harrogate, we are incredibly proud to celebrate Yorkshire’s outstanding engineering heritage, connecting extraordinary destinations with unforgettable luxury steam experiences.
              </p>
            </div>

            <button
              onClick={onNavigateToAbout}
              className="mt-6 text-xs font-bold tracking-[0.2em] text-[#B58B3A] hover:text-[#EFE9DD] transition-all flex items-center gap-2 group text-left uppercase border-t border-[#B58B3A]/20 pt-4 cursor-pointer"
            >
              DISCOVER HARROGATE
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* COLUMN 2: Main Featured Grid (Center, W-6/12 equivalent) */}
          <div className="lg:col-span-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            {gridJourneys.map((journey) => (
              <div
                key={journey.id}
                onClick={() => onSelectJourney(journey.id)}
                className="bg-[#F5EFE2] border border-[#B58B3A]/20 p-4 rounded-sm flex flex-col justify-between hover:border-[#A12A2A] hover:shadow-xl transition-all duration-300 group cursor-pointer"
              >
                <div className="flex flex-col gap-3">
                  {/* Journey Photo */}
                  <div className="overflow-hidden rounded-sm h-36 relative">
                    <img
                      src={journey.image}
                      alt={journey.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-2 right-2 bg-[#1E1E1C]/80 backdrop-blur-sm text-[#B58B3A] text-[8px] font-bold tracking-widest px-2 py-1 rounded-sm uppercase">
                      {journey.availability}
                    </div>
                  </div>

                  {/* Card Info */}
                  <div className="text-left">
                    <h4 className="text-sm font-bold tracking-wide uppercase text-[#1E1E1C] group-hover:text-[#A12A2A] transition-colors">
                      {journey.name}
                    </h4>
                    <p className="text-[10px] tracking-[0.05em] text-[#8A8D90] font-sans italic mt-0.5">
                      {journey.tagline}
                    </p>
                    <p className="text-[11px] text-[#353535] font-sans leading-relaxed mt-2 line-clamp-2">
                      {journey.description}
                    </p>
                  </div>
                </div>

                {/* Footer specs of card */}
                <div className="border-t border-[#B58B3A]/10 pt-3 mt-4 flex items-center justify-between text-[10px] font-semibold text-[#8A8D90]">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#B58B3A]" />
                    {journey.duration}
                  </span>
                  <span className="text-[#1E1E1C]">
                    FROM <span className="text-xs font-bold text-[#A12A2A]">£{journey.price}</span>
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* COLUMN 3: The Yorkshire Pullman (Right, W-3/12 equivalent) */}
          <div className="lg:col-span-3 flex flex-col justify-between bg-[#204334] text-[#EFE9DD] p-6 rounded-sm border border-[#B58B3A]/20 relative overflow-hidden group">
            {/* Golden-glowing atmosphere matching luxury dining */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#B58B3A]/10 rounded-full filter blur-2xl pointer-events-none" />

            <div className="flex flex-col gap-4 z-10 text-left">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-[#B58B3A] fill-current" />
                <span className="text-[9px] font-bold tracking-[0.25em] text-[#B58B3A] uppercase">
                  THE YORKSHIRE PULLMAN
                </span>
              </div>

              <div className="overflow-hidden rounded-sm h-48 relative">
                <img
                  src="https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&q=80&w=600"
                  alt="Luxury Pullman Dining Carriage Interior"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>

              <p className="text-xs tracking-[0.03em] leading-relaxed text-[#EFE9DD]/85 font-sans mt-2">
                Travel in pure, timeless luxury. Our multi-course premium dining experience combines award-winning Yorkshire gastronomy with polished wood surrounds, crisp white linens, and original 1920s Pullman elegance.
              </p>
            </div>

            <button
              onClick={onNavigateToDining}
              className="mt-6 text-xs font-bold tracking-[0.2em] text-[#B58B3A] hover:text-[#EFE9DD] transition-all flex items-center gap-2 group text-left uppercase border-t border-[#B58B3A]/20 pt-4 cursor-pointer"
            >
              FIND OUT MORE
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

        </div>
      </div>
    </section>
  );
}
