/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BookOpen, Calendar, Clock, ArrowRight, X, Heart, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Article {
  id: string;
  title: string;
  category: string;
  date: string;
  readTime: string;
  author: string;
  snippet: string;
  content: string[];
  image: string;
}

const ARTICLES: Article[] = [
  {
    id: 'art-whitby',
    title: 'The Sea-Salted Boiler: Where Steam Meets the Whitby Sea',
    category: 'LANDSCAPE',
    date: '14 July 2026',
    readTime: '6 min read',
    author: 'Evelyn Sterling',
    snippet: 'Exploring the breathtaking transition as heavy iron steam engines emerge from the wild North York Moors into the dramatic coastal harbor of Whitby.',
    content: [
      'There is a precise moment on the coastal line when the heavy aroma of high-grade Welsh steam coal blends seamlessly with the salty, iodine-rich air of the North Sea. It happens just as the engine emerges from the deep rock cutting of Newton Dale, descending onto the single-track coastline approach.',
      'To ride the footplate of No. 60007 during this transition is an exercise in optical overload. Behind you lies the vast purple-and-gold heather carpet of the moors, stretching out in silent, rugged majesty. Ahead, the high silhouette of Whitby Abbey stands watch over the waves, gothic and imposing on the East Cliff.',
      'The town of Whitby has been bound to steam travel since George Stephenson himself laid out the initial horse-drawn route in 1836. Today, our heritage trains transport modern voyagers across those same ancient paths, carrying with them the timeless engineering and industrial elegance that built Victorian Britain.'
    ],
    image: 'https://images.unsplash.com/photo-1610448721566-47369c768e70?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'art-viaduct',
    title: 'Colossus of Batty Moss: Engineering the Ribblehead Viaduct',
    category: 'HISTORY & CRAFT',
    date: '28 June 2026',
    readTime: '8 min read',
    author: 'Arthur Pendelton',
    snippet: 'A deep investigation into the legendary stonemasons and navvies who carved twenty-four soaring limestone arches over the high bogs of the Settle-Carlisle line.',
    content: [
      'In the entire landscape of British infrastructure, few monuments command the raw physical and emotional presence of the Ribblehead Viaduct. Comprising twenty-four soaring stone arches scaling Batty Moss, it rises 104 feet above the limestone pavement.',
      'Completed in 1874 under conditions of unimaginable weather extremity, the viaduct was constructed from limestone quarried directly from the surrounding hills. Over one thousand navvies lived in temporary shanty towns around the base, blasting and hauling blocks weighing up to eight tons each.',
      'Today, as a heavy passenger train crosses the viaduct, the stone structure experiences forces of incredible scale. Our engineering department monitors the piers using ultra-precise optical sensors, ensuring that this triumph of Victorian engineering remains fully operational for another century of steam.'
    ],
    image: 'https://images.unsplash.com/photo-1541417904950-b855846fe074?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'art-pullman',
    title: 'The Art of the Table: Gastronomy in Motion',
    category: 'PULLMAN LIFE',
    date: '02 June 2026',
    readTime: '5 min read',
    author: 'Chef Marcus Thorne',
    snippet: 'Behind the scenes inside the rolling galley of the Yorkshire Pullman. How our chefs plate Michelin-caliber Swaledale beef inside a moving 1920s carriage.',
    content: [
      'Cooking at eighty miles per hour is not merely a job; it is a complex choreographic dance with physics. A copper pan of foaming butter does not behave the same way on a curves-heavy mountain branch line as it does in a stable ground kitchen.',
      'Our kitchen staff in the Yorkshire Pullman operates in a galley carriage measuring just eight feet wide. Every motion is deliberate, every counter surface is heavily guarded, and every piece of plating equipment is weighted to prevent the slightest vibration.',
      'Yet, despite these logistical constraints, we refuse to compromise. We serve dry-aged Swaledale beef fillets, pan-seared samphire cod, and twice-baked souffles. It is a testament to the dedication of our culinary crew and the timeless design of our classic dining coaches.'
    ],
    image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&q=80&w=800'
  }
];

export default function JournalEditorial() {
  const [activeArticle, setActiveArticle] = useState<Article | null>(null);

  return (
    <section className="bg-[#EFE9DD] text-[#1E1E1C] py-20 border-t border-[#B58B3A]/30">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Headings */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#A12A2A]">
            YORKSHIRE CHRONICLES
          </span>
          <h3 className="text-3xl md:text-5xl font-bold tracking-[0.1em] uppercase font-display text-[#1E1E1C] mt-2">
            THE RAILWAY JOURNAL
          </h3>
          <p className="text-xs text-[#8A8D90] font-sans mt-3 max-w-lg mx-auto leading-relaxed">
            Beautiful editorial storytelling documenting the history, mechanics, landscapes, and kitchen secrets that define the premier steam experience.
          </p>
        </div>

        {/* Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {ARTICLES.map((art) => (
            <div
              key={art.id}
              className="bg-[#F5EFE2] border border-[#B58B3A]/20 rounded-sm overflow-hidden flex flex-col justify-between group hover:border-[#A12A2A] hover:shadow-2xl transition-all duration-300"
            >
              <div>
                {/* Photo area with floating category */}
                <div className="h-56 overflow-hidden relative">
                  <img
                    src={art.image}
                    alt={art.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-3 left-3 bg-[#1E1E1C] text-[#B58B3A] text-[8px] font-bold tracking-widest px-2.5 py-1 uppercase rounded-sm">
                    {art.category}
                  </div>
                </div>

                <div className="p-6 text-left">
                  <div className="flex items-center gap-3 text-[10px] text-[#8A8D90] font-sans mb-3">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#A12A2A]" />
                      {art.date}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#B58B3A]" />
                      {art.readTime}
                    </span>
                  </div>

                  <h4 className="text-base font-bold tracking-wide uppercase text-[#1E1E1C] group-hover:text-[#A12A2A] transition-colors leading-snug">
                    {art.title}
                  </h4>
                  <p className="text-xs text-[#353535] font-sans leading-relaxed mt-2.5">
                    {art.snippet}
                  </p>
                </div>
              </div>

              <div className="p-6 pt-0 mt-2 border-t border-[#B58B3A]/10 pt-4 flex items-center justify-between text-[10px] font-bold text-[#8A8D90] font-sans">
                <span>By {art.author}</span>
                <button
                  onClick={() => setActiveArticle(art)}
                  className="text-[#B58B3A] hover:text-[#A12A2A] transition-colors flex items-center gap-1 uppercase tracking-widest cursor-pointer"
                >
                  READ ARTICLE
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Full Article Reader Modal overlay */}
        <AnimatePresence>
          {activeArticle && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 30, opacity: 0 }}
                className="bg-[#EFE9DD] text-[#1E1E1C] w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-sm border border-[#B58B3A]/30 p-6 md:p-10 relative shadow-2xl"
              >
                {/* Close Button */}
                <button
                  onClick={() => setActiveArticle(null)}
                  className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
                  title="Close Reader"
                  aria-label="Close Article"
                >
                  <X className="w-5 h-5 text-gray-500 hover:text-black" />
                </button>

                <div className="text-left">
                  {/* Category eye brow */}
                  <span className="text-[9px] font-bold tracking-[0.25em] text-[#A12A2A] uppercase">
                    THE CHRONICLE JOURNAL • {activeArticle.category}
                  </span>

                  <h3 className="text-2xl md:text-3xl font-bold tracking-tight uppercase font-display text-[#1E1E1C] mt-2 leading-tight">
                    {activeArticle.title}
                  </h3>

                  <div className="flex items-center gap-4 text-xs text-[#8A8D90] font-sans mt-3 border-b border-[#B58B3A]/20 pb-4">
                    <span>By <strong className="text-black">{activeArticle.author}</strong></span>
                    <span>•</span>
                    <span>{activeArticle.date}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-[#B58B3A]">
                      <Clock className="w-3.5 h-3.5" />
                      {activeArticle.readTime}
                    </span>
                  </div>

                  {/* Big Hero Banner inside Article */}
                  <div className="h-64 w-full rounded-sm overflow-hidden my-6 border border-[#B58B3A]/25">
                    <img
                      src={activeArticle.image}
                      alt={activeArticle.title}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Article content strictly constrained to ~68ch width for extreme reading elegant comfort */}
                  <div className="flex flex-col gap-5 text-sm md:text-base leading-relaxed text-[#353535] font-sans max-w-[68ch] mx-auto">
                    {activeArticle.content.map((p, pIdx) => (
                      <p key={pIdx} className="first:text-lg first:text-[#1E1E1C] first:font-medium">
                        {p}
                      </p>
                    ))}
                  </div>

                  {/* Elegant signatory footer */}
                  <div className="w-full h-[1px] bg-[#B58B3A]/20 my-8" />
                  <div className="flex justify-between items-center text-xs text-[#8A8D90]">
                    <div className="flex gap-4">
                      <button className="flex items-center gap-1 hover:text-[#A12A2A] transition-colors cursor-pointer">
                        <Heart className="w-4 h-4" /> Save Article
                      </button>
                      <button className="flex items-center gap-1 hover:text-black transition-colors cursor-pointer">
                        <MessageSquare className="w-4 h-4" /> Write Response
                      </button>
                    </div>
                    <span className="italic">Harrogate Heritage Railway Publication Ltd.</span>
                  </div>

                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
