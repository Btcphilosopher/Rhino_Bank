/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Map, MapPin, Eye, Compass, RefreshCw, X, Shield, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MAP_POINTS } from '../data';
import { MapPoint } from '../types';

interface InteractiveMapProps {
  onSelectJourneyByStation: (stationName: string) => void;
}

export default function InteractiveMap({ onSelectJourneyByStation }: InteractiveMapProps) {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'station' | 'landmark' | 'hotel' | 'dining'>('all');
  const [hoveredPoint, setHoveredPoint] = useState<MapPoint | null>(null);
  const [activePoint, setActivePoint] = useState<MapPoint>(MAP_POINTS[0]);
  const [zoomScale, setZoomScale] = useState(1);

  const filteredPoints = MAP_POINTS.filter((p) => {
    if (selectedFilter === 'all') return true;
    return p.type === selectedFilter;
  });

  const filterLabels = [
    { id: 'all', label: 'SHOW ALL' },
    { id: 'station', label: 'HISTORIC STATIONS' },
    { id: 'landmark', label: 'VIADUCTS & LANDMARKS' },
    { id: 'hotel', label: 'PARTNER LUXURY HOTELS' },
    { id: 'dining', label: 'YORKSHIRE DINING' }
  ];

  return (
    <section className="bg-[#1E1E1C] text-[#EFE9DD] py-20 border-t border-[#B58B3A]/30 relative overflow-hidden">
      {/* Blueprint background grid lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#353535_1px,transparent_1px),linear-gradient(to_bottom,#353535_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#B58B3A]">
            ANGLO-FUTURIST CARTOGRAPHY
          </span>
          <h3 className="text-3xl md:text-5xl font-bold tracking-[0.1em] uppercase font-display text-[#F8F4EC] mt-2">
            INTERACTIVE ROUTE MAP
          </h3>
          <p className="text-xs text-[#8A8D90] font-sans mt-3 max-w-lg mx-auto leading-relaxed">
            Explore the historic lines, towering stone viaducts, and romantic destinations linked together by the Harrogate Heritage Railway across the hills of Yorkshire.
          </p>
        </div>

        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-10">
          {filterLabels.map((f) => (
            <button
              key={f.id}
              onClick={() => setSelectedFilter(f.id as any)}
              className={`text-[9px] font-bold tracking-[0.2em] px-4 py-2 border rounded-sm transition-all uppercase cursor-pointer ${
                selectedFilter === f.id
                  ? 'bg-[#B58B3A] border-[#B58B3A] text-[#1E1E1C]'
                  : 'border-[#8A8D90]/30 text-[#8A8D90] hover:text-[#EFE9DD] hover:border-[#EFE9DD]/50'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Map Workspace Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch bg-[#111110] border border-[#B58B3A]/20 rounded-sm p-4 md:p-8 shadow-2xl">
          
          {/* Map Vector Stage (W-7/12) */}
          <div className="lg:col-span-8 bg-[#181817] rounded-sm border border-[#353535] relative h-[400px] md:h-[520px] overflow-hidden flex items-center justify-center group">
            {/* Compass Rose */}
            <div className="absolute top-4 left-4 opacity-25 flex items-center gap-2">
              <Map className="w-5 h-5 text-[#B58B3A]" />
              <span className="text-[9px] font-bold tracking-widest text-[#B58B3A] uppercase">NORTH</span>
            </div>

            {/* Interactive SVG Canvas */}
            <svg
              className="w-full h-full min-w-[500px] max-w-[800px] transition-transform duration-500"
              style={{ transform: `scale(${zoomScale})` }}
              viewBox="0 0 100 100"
            >
              {/* Coastline visual effect */}
              <path
                d="M 85,0 C 90,30 80,50 95,70 C 100,85 92,100 100,100 L 100,0 Z"
                fill="#1E1E1C"
                opacity="0.3"
              />
              <path
                d="M 85,0 C 90,30 80,50 95,70 C 100,85 92,100 100,100"
                stroke="#B58B3A"
                strokeWidth="0.5"
                strokeDasharray="1 3"
                fill="none"
                opacity="0.5"
              />

              {/* Waterway: River Wharfe representation */}
              <path
                d="M 0,60 C 20,55 35,53 45,62 C 55,70 70,68 85,85"
                fill="none"
                stroke="#353535"
                strokeWidth="1.5"
              />

              {/* Main Railway Tracks Vector (Dashed, Animated) */}
              <path
                id="main-rail-track"
                d="M 10,30 Q 20,40 25,70 T 55,80 T 15,88 T 90,18"
                fill="none"
                stroke="#353535"
                strokeWidth="1.5"
              />
              <path
                d="M 10,30 Q 20,40 25,70 T 55,80 T 15,88 T 90,18"
                fill="none"
                stroke="#B58B3A"
                strokeWidth="0.8"
                strokeDasharray="2 2"
                className="animate-[dash_20s_linear_infinite]"
                style={{ strokeDashoffset: 100 }}
              />

              {/* Connection branches to Bolton Abbey and hotels */}
              <path
                d="M 25,70 Q 30,55 35,50 T 38,45"
                fill="none"
                stroke="#353535"
                strokeWidth="1"
                strokeDasharray="1 2"
              />

              {/* Render Map Points */}
              {filteredPoints.map((point) => {
                const isActive = activePoint.id === point.id;
                const isHovered = hoveredPoint?.id === point.id;

                let markerColor = '#B58B3A'; // Gold for standard
                if (point.type === 'station') markerColor = '#A12A2A'; // Red for stations
                if (point.type === 'landmark') markerColor = '#204334'; // Green for viaducts
                if (point.type === 'hotel') markerColor = '#B96A3C'; // Copper for hotels

                return (
                  <g
                    key={point.id}
                    className="cursor-pointer group/node"
                    onClick={() => setActivePoint(point)}
                    onMouseEnter={() => setHoveredPoint(point)}
                    onMouseLeave={() => setHoveredPoint(null)}
                  >
                    {/* Pulsing ring for active/hovered nodes */}
                    {(isActive || isHovered) && (
                      <circle
                        cx={point.x}
                        cy={point.y}
                        r="3.5"
                        fill="none"
                        stroke={markerColor}
                        strokeWidth="0.5"
                        className="animate-ping origin-center"
                        style={{ transformOrigin: `${point.x}px ${point.y}px` }}
                      />
                    )}

                    {/* Outer frame */}
                    <circle
                      cx={point.x}
                      cy={point.y}
                      r={isActive ? '2.5' : '1.8'}
                      fill="#1E1E1C"
                      stroke={markerColor}
                      strokeWidth={isActive ? '1' : '0.6'}
                      transition="all 0.3s"
                    />

                    {/* Core bullet */}
                    <circle
                      cx={point.x}
                      cy={point.y}
                      r="0.8"
                      fill={isActive ? '#FFFFFF' : markerColor}
                    />

                    {/* Text labels floating on map */}
                    <text
                      x={point.x}
                      y={point.y - 3}
                      textAnchor="middle"
                      fill={isActive ? '#F8F4EC' : '#8A8D90'}
                      fontSize="2.2"
                      fontWeight={isActive ? 'bold' : 'normal'}
                      className="font-sans tracking-widest uppercase transition-colors pointer-events-none"
                    >
                      {point.name.split(' ')[0]}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Scale controls */}
            <div className="absolute bottom-4 left-4 flex gap-2">
              <button
                onClick={() => setZoomScale((prev) => Math.min(prev + 0.2, 2))}
                className="w-8 h-8 rounded-full bg-[#1E1E1C]/90 text-white border border-[#353535] flex items-center justify-center font-bold hover:border-[#B58B3A]"
              >
                +
              </button>
              <button
                onClick={() => setZoomScale((prev) => Math.max(prev - 0.2, 0.8))}
                className="w-8 h-8 rounded-full bg-[#1E1E1C]/90 text-white border border-[#353535] flex items-center justify-center font-bold hover:border-[#B58B3A]"
              >
                -
              </button>
              <button
                onClick={() => {
                  setZoomScale(1);
                  setActivePoint(MAP_POINTS[0]);
                }}
                className="p-2 rounded-full bg-[#1E1E1C]/90 text-[#B58B3A] border border-[#353535] hover:border-[#B58B3A] flex items-center justify-center"
                title="Reset Map"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Map Point Info Panel (W-4/12) */}
          <div className="lg:col-span-4 bg-[#1E1E1C] rounded-sm border border-[#B58B3A]/20 p-6 flex flex-col justify-between text-left">
            <AnimatePresence mode="wait">
              <motion.div
                key={activePoint.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4 }}
                className="flex flex-col gap-4"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[9px] font-bold tracking-[0.25em] text-[#B58B3A] uppercase">
                      {activePoint.type} DETAILS
                    </span>
                    <h4 className="text-xl font-bold tracking-wide text-[#F8F4EC] uppercase mt-1">
                      {activePoint.name}
                    </h4>
                    {activePoint.tagline && (
                      <p className="text-[10px] italic text-[#8A8D90] mt-0.5">{activePoint.tagline}</p>
                    )}
                  </div>
                </div>

                <div className="h-44 w-full rounded-sm overflow-hidden relative border border-[#353535] my-2">
                  <img
                    src={activePoint.image}
                    alt={activePoint.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                </div>

                <p className="text-xs text-[#EFE9DD]/80 leading-relaxed font-sans">
                  {activePoint.description}
                </p>

                {activePoint.type === 'station' && (
                  <div className="bg-[#111110] border border-[#353535] p-3 rounded-sm">
                    <h5 className="text-[9px] font-bold tracking-widest text-[#B58B3A] uppercase mb-1">
                      LOCAL STATION RECOMMENDATIONS
                    </h5>
                    <p className="text-[10px] text-[#8A8D90] font-sans">
                      Enjoy hot coffee and Yorkshire parkin in our tearooms, or step into the Victorian platform waiting room to browse historic memorabilia.
                    </p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="mt-6 border-t border-[#B58B3A]/20 pt-4 flex flex-col gap-2">
              <button
                onClick={() => onSelectJourneyByStation(activePoint.name)}
                className="w-full bg-[#B58B3A] hover:bg-[#b96a3c] text-[#1E1E1C] hover:text-white font-bold text-xs tracking-[0.15em] py-3 uppercase rounded-sm transition-all flex items-center justify-center gap-2"
              >
                <Compass className="w-4 h-4" />
                RESERVE TICKETS TO THIS DEPOT
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
