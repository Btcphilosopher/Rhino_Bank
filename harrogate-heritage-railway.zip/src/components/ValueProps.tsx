/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Train, Map, Award, Utensils, Compass } from 'lucide-react';

export default function ValueProps() {
  const props = [
    {
      icon: Train,
      title: 'BEAUTIFULLY RESTORED TRAINS',
      desc: 'Meticulously crafted steam & vintage diesel locomotives.'
    },
    {
      icon: Map,
      title: "YORKSHIRE'S SCENIC ROUTES",
      desc: 'Breathtaking voyages across the North Moors & Dales.'
    },
    {
      icon: Award,
      title: 'FIRST CLASS CARRIAGES',
      desc: 'Original Edwardian and mid-century teak luxury coaches.'
    },
    {
      icon: Utensils,
      title: 'FINE FOOD & HOSPITALITY',
      desc: 'Michelin-worthy menus made with farm-fresh local produce.'
    },
    {
      icon: Compass,
      title: 'MEMORABLE EXPERIENCES',
      desc: 'Curated historic events, photography days, and galas.'
    }
  ];

  return (
    <div className="bg-[#EFE9DD] border-y border-[#B58B3A]/20 py-8 text-[#1E1E1C]">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6 md:gap-4 divide-y md:divide-y-0 md:divide-x divide-[#B58B3A]/20 items-stretch">
          {props.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className={`flex flex-col items-center text-center p-2 group transition-all duration-300 ${
                  idx > 1 ? 'pt-4 md:pt-2' : ''
                }`}
              >
                <div className="mb-3 text-[#B58B3A] group-hover:text-[#A12A2A] transition-colors duration-300">
                  <Icon className="w-6 h-6 stroke-[1.25]" />
                </div>
                <h4 className="text-[10px] font-bold tracking-[0.2em] uppercase text-[#1E1E1C] mb-1 leading-tight">
                  {item.title}
                </h4>
                <p className="text-[9px] tracking-[0.05em] text-[#8A8D90] font-sans leading-relaxed max-w-[150px]">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
