/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShoppingBag, Star, Trash2, Shield, Truck, Calendar, Sparkles } from 'lucide-react';
import { MERCHANDISE } from '../data';
import { MerchItem } from '../types';

interface MerchandiseShopProps {
  onAddToCart: (item: MerchItem) => void;
  cart: { item: MerchItem; quantity: number }[];
  onRemoveFromCart: (id: string) => void;
  onUpdateCartQty: (id: string, qty: number) => void;
  checkoutOpen: boolean;
  setCheckoutOpen: (val: boolean) => void;
  onCompleteCheckout: () => void;
}

export default function MerchandiseShop({
  onAddToCart,
  cart,
  onRemoveFromCart,
  onUpdateCartQty,
  checkoutOpen,
  setCheckoutOpen,
  onCompleteCheckout
}: MerchandiseShopProps) {
  
  const subtotal = cart.reduce((acc, curr) => acc + curr.item.price * curr.quantity, 0);
  const vat = subtotal * 0.2; // 20% UK VAT
  const shipping = subtotal > 150 ? 0 : 8.5; // Free delivery over £150
  const total = subtotal + shipping;

  return (
    <section className="bg-[#EFE9DD] text-[#1E1E1C] py-20 border-t border-[#B58B3A]/20">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Headings */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#A12A2A]">
            THE TERM DECK CATALOGUE
          </span>
          <h3 className="text-3xl md:text-5xl font-bold tracking-[0.1em] uppercase font-display text-[#1E1E1C] mt-2">
            PREMIUM COLLECTIBLES
          </h3>
          <p className="text-xs text-[#8A8D90] font-sans mt-3 max-w-lg mx-auto leading-relaxed">
            Own a beautiful piece of Britain’s glorious industrial heritage. Browse our limited-run brass models, cotton Giclée prints, and custom-bound literary logs.
          </p>
        </div>

        {/* Master Shop Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Products Grid (Left, W-8/12 or full depending on Cart empty state) */}
          <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            {MERCHANDISE.map((item) => (
              <div
                key={item.id}
                className="bg-white border border-[#B58B3A]/20 rounded-sm overflow-hidden flex flex-col justify-between group hover:border-[#A12A2A] hover:shadow-2xl transition-all duration-300"
              >
                <div>
                  {/* Photo area */}
                  <div className="h-56 overflow-hidden relative bg-[#1E1E1C]/5">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-2 left-2 bg-[#B58B3A] text-[#1E1E1C] text-[8px] font-bold px-2 py-1 tracking-widest uppercase rounded-sm">
                      {item.category}
                    </div>
                  </div>

                  <div className="p-6 text-left">
                    <div className="flex items-center gap-1 mb-2">
                      {Array.from({ length: 5 }).map((_, idx) => (
                        <Star
                          key={idx}
                          className={`w-3.5 h-3.5 ${
                            idx < Math.floor(item.rating)
                              ? 'text-[#B58B3A] fill-current'
                              : 'text-gray-200'
                          }`}
                        />
                      ))}
                      <span className="text-[10px] font-semibold text-[#8A8D90] font-sans ml-1.5">
                        {item.rating.toFixed(1)}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold tracking-wide uppercase text-[#1E1E1C] group-hover:text-[#A12A2A] transition-colors">
                      {item.name}
                    </h4>
                    <p className="text-xs text-[#353535] font-sans leading-relaxed mt-2">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="p-6 pt-0 mt-2 flex items-center justify-between border-t border-[#B58B3A]/10 pt-4">
                  <span className="text-sm font-bold text-[#1E1E1C] font-sans">
                    £{item.price.toFixed(2)}
                  </span>
                  <button
                    onClick={() => onAddToCart(item)}
                    className="bg-[#1E1E1C] hover:bg-[#A12A2A] text-[#EFE9DD] hover:text-white text-[10px] font-bold tracking-[0.2em] px-4 py-2.5 rounded-sm uppercase transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    ADD TO CART
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Checkout Cart Drawer Panel (Right, W-4/12) */}
          <div className="lg:col-span-4 bg-white border border-[#B58B3A]/30 p-6 rounded-sm shadow-xl text-left">
            <h4 className="text-sm font-bold tracking-[0.2em] uppercase text-[#1E1E1C] border-b border-[#B58B3A]/20 pb-3 mb-4 flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#B58B3A]" />
              SHOPPING BAG ({cart.reduce((s, c) => s + c.quantity, 0)})
            </h4>

            {cart.length === 0 ? (
              <div className="py-12 text-center flex flex-col items-center gap-3">
                <p className="text-xs text-[#8A8D90] font-sans">Your shopping bag is empty.</p>
                <span className="text-[9px] text-[#B58B3A] font-bold tracking-widest uppercase">
                  PICK UP MEMORABILIA ON THE LEFT
                </span>
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {/* Cart Items Checklist */}
                <div className="flex flex-col gap-3 max-h-[220px] overflow-y-auto pr-2 divide-y divide-[#B58B3A]/10">
                  {cart.map((cartItem, idx) => (
                    <div key={cartItem.item.id} className="pt-3 first:pt-0 flex justify-between gap-3 items-center">
                      <div className="flex-1">
                        <span className="text-[8px] font-bold text-[#B58B3A] uppercase tracking-widest block">
                          {cartItem.item.category}
                        </span>
                        <h5 className="text-[11px] font-bold text-[#1E1E1C] uppercase leading-tight line-clamp-1">
                          {cartItem.item.name}
                        </h5>
                        <span className="text-[10px] font-sans text-[#8A8D90]">
                          £{cartItem.item.price.toFixed(2)} each
                        </span>
                      </div>

                      {/* Quantity counters */}
                      <div className="flex items-center gap-2">
                        <select
                          value={cartItem.quantity}
                          onChange={(e) => onUpdateCartQty(cartItem.item.id, parseInt(e.target.value))}
                          className="bg-[#F5EFE2] border border-[#B58B3A]/20 text-xs p-1 rounded-sm focus:outline-none focus:border-[#B58B3A]"
                        >
                          {[1, 2, 3, 4, 5].map((q) => (
                            <option key={q} value={q}>
                              {q}
                            </option>
                          ))}
                        </select>

                        <button
                          onClick={() => onRemoveFromCart(cartItem.item.id)}
                          className="p-1 text-gray-400 hover:text-[#A12A2A] transition-colors"
                          title="Delete Item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Totals computation card */}
                <div className="bg-[#F5EFE2] border border-[#B58B3A]/25 p-4 rounded-sm flex flex-col gap-2 text-[11px] text-[#353535] font-sans">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span className="font-bold text-[#1E1E1C]">£{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-[#8A8D90] text-[10px]">
                    <span>Includes VAT (20%):</span>
                    <span>£{vat.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Royal Mail Carriage:</span>
                    <span className="font-bold text-[#1E1E1C]">
                      {shipping === 0 ? 'FREE' : `£${shipping.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="border-t border-[#B58B3A]/20 pt-2 mt-1 flex justify-between text-xs text-[#1E1E1C] font-bold">
                    <span>Est. Total:</span>
                    <span className="text-[#A12A2A]">£{total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex flex-col gap-2 mt-2">
                  <div className="flex items-center gap-1.5 text-[9px] font-semibold text-[#8A8D90] font-sans">
                    <Truck className="w-4 h-4 text-[#B58B3A]" />
                    <span>Free UK shipping on orders over £150</span>
                  </div>
                  <button
                    onClick={onCompleteCheckout}
                    className="w-full bg-[#1E1E1C] hover:bg-[#A12A2A] text-white font-bold text-xs tracking-[0.2em] py-3.5 mt-2 rounded-sm uppercase transition-colors"
                  >
                    PROCEED TO CHECKOUT
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}
