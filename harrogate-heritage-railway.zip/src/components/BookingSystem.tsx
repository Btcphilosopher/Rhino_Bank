/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Train, Calendar, Users, Award, Shield, Check, Gift, ArrowRight, ArrowLeft, Eye, Ticket } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { JOURNEYS } from '../data';
import { BookingState, Journey } from '../types';

interface BookingSystemProps {
  initialJourneyId?: string;
  onBookingSuccess: () => void;
}

const COACH_SEATS = [
  { id: '1A', type: 'window', status: 'taken' },
  { id: '1B', type: 'corridor', status: 'available' },
  { id: '1C', type: 'corridor', status: 'available' },
  { id: '1D', type: 'window', status: 'taken' },
  { id: '2A', type: 'window', status: 'available' },
  { id: '2B', type: 'corridor', status: 'available' },
  { id: '2C', type: 'corridor', status: 'taken' },
  { id: '2D', type: 'window', status: 'available' },
  { id: '3A', type: 'window', status: 'available' },
  { id: '3B', type: 'corridor', status: 'taken' },
  { id: '3C', type: 'corridor', status: 'available' },
  { id: '3D', type: 'window', status: 'available' },
  { id: '4A', type: 'window', status: 'available' },
  { id: '4B', type: 'corridor', status: 'available' },
  { id: '4C', type: 'corridor', status: 'available' },
  { id: '4D', type: 'window', status: 'available' }
];

export default function BookingSystem({ initialJourneyId = '', onBookingSuccess }: BookingSystemProps) {
  const [journeyId, setJourneyId] = useState(initialJourneyId || JOURNEYS[0].id);
  const [date, setDate] = useState('2026-07-26');
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);
  const [travelClass, setTravelClass] = useState<'Standard' | 'First' | 'Pullman Dining'>('First');
  const [dietary, setDietary] = useState('');
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [extras, setExtras] = useState({
    champagne: false,
    yorkshireFudge: false,
    photoPass: false
  });
  const [step, setStep] = useState(1);
  const [bookingRef, setBookingRef] = useState('');
  const [billingName, setBillingName] = useState('Thomas Sterling');

  const selectedJourney = JOURNEYS.find((j) => j.id === journeyId) || JOURNEYS[0];

  // Price calculations
  const basePrice = selectedJourney.price;
  const classMultiplier = travelClass === 'Standard' ? 1 : travelClass === 'First' ? 1.8 : 2.5;
  const seatPrice = basePrice * classMultiplier;
  const passengerCount = adults + children;
  
  const extrasCost = 
    (extras.champagne ? 45 : 0) +
    (extras.yorkshireFudge ? 15 : 0) +
    (extras.photoPass ? 25 : 0);

  const subtotal = seatPrice * passengerCount + extrasCost;

  const nextStep = () => {
    if (step < 5) {
      setStep(step + 1);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const toggleSeat = (id: string) => {
    if (selectedSeats.includes(id)) {
      setSelectedSeats(selectedSeats.filter((s) => s !== id));
    } else {
      // Limit to passengers count
      if (selectedSeats.length < passengerCount) {
        setSelectedSeats([...selectedSeats, id]);
      }
    }
  };

  const handleFinalizeBooking = () => {
    // Generate a beautiful historic booking code
    const rand = Math.floor(10000 + Math.random() * 90000);
    setBookingRef(`HHR-${rand}-YORK`);
    setStep(5);
  };

  return (
    <section className="bg-[#1E1E1C] text-[#EFE9DD] py-20 border-t border-[#B58B3A]/30">
      <div className="max-w-4xl mx-auto px-4 md:px-8">
        
        {/* Title and Progress Bar */}
        <div className="text-center mb-12">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#B58B3A]">
            CONCIERGE RESERVATION SERVICE
          </span>
          <h3 className="text-3xl font-display font-bold tracking-wider uppercase text-[#F8F4EC] mt-1">
            VOYAGE BOOKING CONSOLE
          </h3>
          
          {/* Progress Indicators */}
          <div className="flex items-center justify-between max-w-md mx-auto mt-8 relative">
            <div className="absolute top-[11px] left-0 right-0 h-[2px] bg-[#353535] z-0" />
            <div
              className="absolute top-[11px] left-0 h-[2px] bg-[#B58B3A] z-0 transition-all duration-500"
              style={{ width: `${((step - 1) / 4) * 100}%` }}
            />
            {[1, 2, 3, 4, 5].map((s) => (
              <div key={s} className="z-10 flex flex-col items-center gap-1.5">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-all border ${
                    step >= s
                      ? 'bg-[#B58B3A] border-[#B58B3A] text-[#1E1E1C]'
                      : 'bg-[#1E1E1C] border-[#353535] text-[#8A8D90]'
                  }`}
                >
                  {s}
                </div>
                <span className="text-[8px] tracking-widest text-[#8A8D90] uppercase font-semibold hidden md:block">
                  {s === 1 ? 'ROUTE' : s === 2 ? 'CLASS' : s === 3 ? 'SEATING' : s === 4 ? 'UPGRADES' : 'PASS'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Master Widget Frame */}
        <div className="bg-[#111110] border border-[#B58B3A]/30 p-6 md:p-10 rounded-sm shadow-2xl text-left">
          <AnimatePresence mode="wait">
            
            {/* STEP 1: EXCURSION SELECTOR */}
            {step === 1 && (
              <motion.div
                key="step-1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex flex-col gap-6"
              >
                <h4 className="text-sm font-bold tracking-[0.2em] text-[#F8F4EC] uppercase border-b border-[#353535] pb-3">
                  1. CHOOSE VOYAGE ROUTE & DATE
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Radio buttons for Journeys */}
                  {JOURNEYS.map((j) => (
                    <div
                      key={j.id}
                      onClick={() => setJourneyId(j.id)}
                      className={`p-4 border rounded-sm cursor-pointer transition-all flex items-start gap-3 text-left ${
                        journeyId === j.id
                          ? 'border-[#B58B3A] bg-[#1E1E1C]'
                          : 'border-[#353535] bg-[#181817] hover:border-[#8A8D90]'
                      }`}
                    >
                      <input
                        type="radio"
                        checked={journeyId === j.id}
                        onChange={() => setJourneyId(j.id)}
                        className="mt-1 accent-[#B58B3A]"
                      />
                      <div className="flex flex-col">
                        <h5 className="text-xs font-bold uppercase text-[#F8F4EC]">
                          {j.name}
                        </h5>
                        <span className="text-[9px] italic text-[#B58B3A]">{j.tagline}</span>
                        <span className="text-[10px] text-[#8A8D90] font-sans mt-1">
                          Standard Fare: from £{j.price}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Calendar Date & Passengers Panel */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 border-t border-[#353535] pt-6 mt-2">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold tracking-widest text-[#8A8D90] uppercase flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#B58B3A]" />
                      DATE
                    </label>
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-[#181817] border border-[#353535] rounded-sm text-xs p-3 text-white focus:outline-none focus:border-[#B58B3A]"
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold tracking-widest text-[#8A8D90] uppercase flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-[#B58B3A]" />
                      ADULTS
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="8"
                      value={adults}
                      onChange={(e) => setAdults(parseInt(e.target.value) || 1)}
                      className="w-full bg-[#181817] border border-[#353535] rounded-sm text-xs p-3 text-white focus:outline-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold tracking-widest text-[#8A8D90] uppercase flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-[#8A8D90]" />
                      CHILDREN
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="6"
                      value={children}
                      onChange={(e) => setChildren(parseInt(e.target.value) || 0)}
                      className="w-full bg-[#181817] border border-[#353535] rounded-sm text-xs p-3 text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-6 border-t border-[#353535]">
                  <button
                    onClick={nextStep}
                    className="bg-[#B58B3A] hover:bg-[#b96a3c] text-[#1E1E1C] hover:text-white font-bold text-xs tracking-[0.2em] px-8 py-3.5 uppercase rounded-sm flex items-center gap-2 group cursor-pointer"
                  >
                    SELECT CLASS
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 2: CLASS SELECTION */}
            {step === 2 && (
              <motion.div
                key="step-2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex flex-col gap-6"
              >
                <h4 className="text-sm font-bold tracking-[0.2em] text-[#F8F4EC] uppercase border-b border-[#353535] pb-3">
                  2. TRAVEL CARRIAGE CLASS
                </h4>

                <div className="flex flex-col gap-4">
                  {/* Standard Class */}
                  <div
                    onClick={() => setTravelClass('Standard')}
                    className={`p-5 border rounded-sm cursor-pointer transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                      travelClass === 'Standard' ? 'border-[#B58B3A] bg-[#1E1E1C]' : 'border-[#353535] bg-[#181817]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="radio"
                        checked={travelClass === 'Standard'}
                        onChange={() => setTravelClass('Standard')}
                        className="mt-1 accent-[#B58B3A]"
                      />
                      <div className="flex flex-col text-left">
                        <h5 className="text-sm font-bold uppercase text-[#F8F4EC] flex items-center gap-1.5">
                          Standard Class Heritage
                        </h5>
                        <p className="text-xs text-[#8A8D90] font-sans mt-1 max-w-md">
                          Enjoy beautifully varnished 1950s teak wood saloon compartments, comfortable fabric upholstery, and grand panoramic windows.
                        </p>
                      </div>
                    </div>
                    <span className="text-sm font-bold text-[#EFE9DD] font-sans">
                      £{(basePrice * 1).toFixed(2)} / seat
                    </span>
                  </div>

                  {/* First Class */}
                  <div
                    onClick={() => setTravelClass('First')}
                    className={`p-5 border rounded-sm cursor-pointer transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                      travelClass === 'First' ? 'border-[#B58B3A] bg-[#1E1E1C]' : 'border-[#353535] bg-[#181817]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="radio"
                        checked={travelClass === 'First'}
                        onChange={() => setTravelClass('First')}
                        className="mt-1 accent-[#B58B3A]"
                      />
                      <div className="flex flex-col text-left">
                        <h5 className="text-sm font-bold uppercase text-[#B58B3A] flex items-center gap-1.5">
                          <Award className="w-4 h-4" />
                          First Class Heritage Excursion
                        </h5>
                        <p className="text-xs text-[#8A8D90] font-sans mt-1 max-w-md">
                          Plush, wide Edwardian armchairs, extra legroom, traditional wood-panel partitions, and complimentary Yorkshire cream tea served at your table.
                        </p>
                      </div>
                    </div>
                    <span className="text-sm font-bold text-[#B58B3A] font-sans">
                      £{(basePrice * 1.8).toFixed(2)} / seat
                    </span>
                  </div>

                  {/* Pullman Dining */}
                  <div
                    onClick={() => setTravelClass('Pullman Dining')}
                    className={`p-5 border rounded-sm cursor-pointer transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                      travelClass === 'Pullman Dining' ? 'border-[#A12A2A] bg-[#204334]/15' : 'border-[#353535] bg-[#181817]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="radio"
                        checked={travelClass === 'Pullman Dining'}
                        onChange={() => setTravelClass('Pullman Dining')}
                        className="mt-1 accent-[#A12A2A]"
                      />
                      <div className="flex flex-col text-left">
                        <h5 className="text-sm font-bold uppercase text-[#A12A2A] flex items-center gap-1.5">
                          <Award className="w-4 h-4" />
                          Premier Pullman Dining Special
                        </h5>
                        <p className="text-xs text-[#8A8D90] font-sans mt-1 max-w-md">
                          The gold standard of rail travel. Exquisite multi-course Michelin-inspired culinary dining, complimentary champagne flutes, and silver table service.
                        </p>
                      </div>
                    </div>
                    <span className="text-sm font-bold text-[#A12A2A] font-sans">
                      £{(basePrice * 2.5).toFixed(2)} / seat
                    </span>
                  </div>
                </div>

                <div className="flex justify-between pt-6 border-t border-[#353535] mt-4">
                  <button
                    onClick={prevStep}
                    className="border border-[#353535] text-[#8A8D90] hover:text-white font-bold text-xs tracking-[0.2em] px-6 py-3 uppercase rounded-sm flex items-center gap-1.5"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    BACK
                  </button>
                  <button
                    onClick={nextStep}
                    className="bg-[#B58B3A] hover:bg-[#b96a3c] text-[#1E1E1C] hover:text-white font-bold text-xs tracking-[0.2em] px-8 py-3.5 uppercase rounded-sm flex items-center gap-2 group cursor-pointer"
                  >
                    SELECT SEATS
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 3: INTERACTIVE SEATING CHART */}
            {step === 3 && (
              <motion.div
                key="step-3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex flex-col gap-6"
              >
                <h4 className="text-sm font-bold tracking-[0.2em] text-[#F8F4EC] uppercase border-b border-[#353535] pb-3">
                  3. COACH SEAT SELECTION
                </h4>
                <p className="text-xs text-[#8A8D90] font-sans -mt-2">
                  Please pick exactly <strong className="text-white">{passengerCount}</strong> seat(s) from Coach A (LNER Teak Parlour Coach). Chosen seats: {selectedSeats.length} / {passengerCount}
                </p>

                {/* Visual seat blueprint stage */}
                <div className="bg-[#181817] p-6 rounded-sm border border-[#353535] max-w-sm mx-auto w-full flex flex-col gap-4">
                  <div className="text-center font-sans font-bold text-[9px] tracking-widest text-[#B58B3A] border-b border-[#353535] pb-2 uppercase">
                    FRONT OF COACH (ENGINE DIRECTION) ▲
                  </div>

                  <div className="grid grid-cols-4 gap-3 items-center justify-center">
                    {COACH_SEATS.map((seat) => {
                      const isTaken = seat.status === 'taken';
                      const isSelected = selectedSeats.includes(seat.id);

                      return (
                        <button
                          key={seat.id}
                          disabled={isTaken}
                          onClick={() => toggleSeat(seat.id)}
                          className={`h-10 text-[10px] font-bold font-mono rounded-sm flex items-center justify-center border transition-all ${
                            isTaken
                              ? 'bg-red-900/10 border-red-900/30 text-red-950 line-through cursor-not-allowed'
                              : isSelected
                              ? 'bg-[#B58B3A] border-[#B58B3A] text-[#1E1E1C] shadow-[0_0_8px_#B58B3A]'
                              : 'bg-[#1E1E1C] border-[#353535] text-[#8A8D90] hover:border-[#B58B3A]'
                          }`}
                          title={`Seat ${seat.id} (${seat.type}) - ${seat.status}`}
                        >
                          {seat.id}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex justify-between text-[8px] font-bold tracking-widest text-[#8A8D90] border-t border-[#353535] pt-3 uppercase">
                    <span>◄ WINDOW L</span>
                    <span>WINDOW R ►</span>
                  </div>
                </div>

                <div className="flex justify-between pt-6 border-t border-[#353535] mt-4">
                  <button
                    onClick={prevStep}
                    className="border border-[#353535] text-[#8A8D90] hover:text-white font-bold text-xs tracking-[0.2em] px-6 py-3 uppercase rounded-sm flex items-center gap-1.5"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    BACK
                  </button>
                  <button
                    onClick={nextStep}
                    disabled={selectedSeats.length < passengerCount}
                    className="bg-[#B58B3A] hover:bg-[#b96a3c] text-[#1E1E1C] hover:text-white font-bold text-xs tracking-[0.2em] px-8 py-3.5 uppercase rounded-sm flex items-center gap-2 group cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    ADD PREMIUM EXTRAS
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 4: PREMIUM EXTRAS & DIETARIES */}
            {step === 4 && (
              <motion.div
                key="step-4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex flex-col gap-6"
              >
                <h4 className="text-sm font-bold tracking-[0.2em] text-[#F8F4EC] uppercase border-b border-[#353535] pb-3">
                  4. CHOOSE PREMIUM EXTRA UPGRADES
                </h4>

                <div className="flex flex-col gap-4">
                  {/* Champagne */}
                  <div
                    onClick={() => setExtras({ ...extras, champagne: !extras.champagne })}
                    className={`p-4 border rounded-sm cursor-pointer transition-all flex items-center justify-between gap-4 ${
                      extras.champagne ? 'border-[#B58B3A] bg-[#1E1E1C]' : 'border-[#353535] bg-[#181817]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={extras.champagne}
                        onChange={() => {}}
                        className="mt-1 accent-[#B58B3A]"
                      />
                      <div className="flex flex-col text-left">
                        <h5 className="text-xs font-bold uppercase text-[#F8F4EC] flex items-center gap-1">
                          <Gift className="w-4 h-4 text-[#B58B3A]" />
                          Ice-Cold Champagne Bottle & Flutes
                        </h5>
                        <p className="text-[10px] text-[#8A8D90] font-sans">
                          Savor a beautifully chilled bottle of our private Centenary Cuvée, poured at departure.
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-[#EFE9DD] font-sans">
                      + £45.00
                    </span>
                  </div>

                  {/* Fudge */}
                  <div
                    onClick={() => setExtras({ ...extras, yorkshireFudge: !extras.yorkshireFudge })}
                    className={`p-4 border rounded-sm cursor-pointer transition-all flex items-center justify-between gap-4 ${
                      extras.yorkshireFudge ? 'border-[#B58B3A] bg-[#1E1E1C]' : 'border-[#353535] bg-[#181817]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={extras.yorkshireFudge}
                        onChange={() => {}}
                        className="mt-1 accent-[#B58B3A]"
                      />
                      <div className="flex flex-col text-left">
                        <h5 className="text-xs font-bold uppercase text-[#F8F4EC] flex items-center gap-1">
                          <Gift className="w-4 h-4 text-[#B58B3A]" />
                          Yorkshire Clotted Cream Fudge Tin
                        </h5>
                        <p className="text-[10px] text-[#8A8D90] font-sans">
                          Delicious, melt-in-the-mouth fudge handcrafted in Harrogate town. Present box included.
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-[#EFE9DD] font-sans">
                      + £15.00
                    </span>
                  </div>

                  {/* Lineside Photo Pass */}
                  <div
                    onClick={() => setExtras({ ...extras, photoPass: !extras.photoPass })}
                    className={`p-4 border rounded-sm cursor-pointer transition-all flex items-center justify-between gap-4 ${
                      extras.photoPass ? 'border-[#B58B3A] bg-[#1E1E1C]' : 'border-[#353535] bg-[#181817]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={extras.photoPass}
                        onChange={() => {}}
                        className="mt-1 accent-[#B58B3A]"
                      />
                      <div className="flex flex-col text-left">
                        <h5 className="text-xs font-bold uppercase text-[#F8F4EC] flex items-center gap-1">
                          <Gift className="w-4 h-4 text-[#B58B3A]" />
                          Lineside Photographer’s Pass
                        </h5>
                        <p className="text-[10px] text-[#8A8D90] font-sans">
                          Provides exclusive safety trackside viewing access on the day to shoot majestic smoke runpasts.
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-[#EFE9DD] font-sans">
                      + £25.00
                    </span>
                  </div>
                </div>

                {/* Dietary Specs */}
                <div className="flex flex-col gap-2 text-left mt-2">
                  <label className="text-[10px] font-bold tracking-widest text-[#8A8D90] uppercase">
                    DIETARY REQUIREMENTS / ACCESSIBILITY NOTES
                  </label>
                  <textarea
                    value={dietary}
                    onChange={(e) => setDietary(e.target.value)}
                    placeholder="Vegetarian, nut allergies, gluten-free specs, or wheelchair boarding requests..."
                    className="w-full bg-[#181817] border border-[#353535] rounded-sm text-xs p-3 focus:outline-none focus:border-[#B58B3A] font-sans text-white h-20 resize-none"
                  />
                </div>

                <div className="flex justify-between pt-6 border-t border-[#353535] mt-4">
                  <button
                    onClick={prevStep}
                    className="border border-[#353535] text-[#8A8D90] hover:text-white font-bold text-xs tracking-[0.2em] px-6 py-3 uppercase rounded-sm flex items-center gap-1.5"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    BACK
                  </button>
                  <button
                    onClick={handleFinalizeBooking}
                    className="bg-[#B58B3A] hover:bg-[#b96a3c] text-[#1E1E1C] hover:text-white font-bold text-xs tracking-[0.2em] px-8 py-3.5 uppercase rounded-sm flex items-center gap-2 group cursor-pointer"
                  >
                    FINALIZE VOYAGE
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 5: VINTAGE ETCHED BOARDING PASS */}
            {step === 5 && (
              <motion.div
                key="step-5"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center gap-8 text-center"
              >
                <div className="flex flex-col items-center gap-2">
                  <span className="text-[10px] font-bold tracking-[0.4em] text-[#81C784] uppercase">
                    RESERVATION CONFIRMED
                  </span>
                  <h4 className="text-xl font-bold uppercase font-display text-[#F8F4EC] tracking-wider">
                    BON VOYAGE!
                  </h4>
                  <p className="text-xs text-[#8A8D90] font-sans max-w-sm">
                    Your tickets have been registered successfully under our historic ledger. Below is your official Centenary Boarding Pass.
                  </p>
                </div>

                {/* Highly authentic Vintage Boarding Pass Ticket */}
                <div className="w-full max-w-xl bg-[#EFE9DD] text-[#1E1E1C] p-6 rounded-sm border-2 border-[#B58B3A] relative shadow-2xl overflow-hidden font-sans border-dashed">
                  
                  {/* Rounded visual ticket punched holes on edges */}
                  <div className="absolute top-1/2 -left-3 w-6 h-6 rounded-full bg-[#111110] border border-[#B58B3A] z-20" />
                  <div className="absolute top-1/2 -right-3 w-6 h-6 rounded-full bg-[#111110] border border-[#B58B3A] z-20" />

                  {/* Gold-lined frames inside ticket */}
                  <div className="border border-[#B58B3A]/40 p-5 rounded-sm relative">
                    
                    {/* Header bar */}
                    <div className="flex justify-between items-start border-b border-[#B58B3A]/30 pb-3 mb-4 text-left">
                      <div>
                        <h5 className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#1E1E1C]">
                          HARROGATE HERITAGE RAILWAY
                        </h5>
                        <span className="text-[8px] font-bold tracking-widest text-[#B58B3A] uppercase">
                          YORKSHIRE'S FINEST STEAM SERVICES
                        </span>
                      </div>
                      <div className="bg-[#1E1E1C] text-[#EFE9DD] px-3 py-1.5 rounded-sm text-center">
                        <span className="text-[7px] block tracking-widest uppercase font-semibold text-[#B58B3A]">
                          REF NUMBER
                        </span>
                        <strong className="text-[10px] font-mono tracking-wider">{bookingRef}</strong>
                      </div>
                    </div>

                    {/* Ticket body grid */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-y-4 gap-x-2 text-left text-[11px] border-b border-[#B58B3A]/15 pb-4 mb-4">
                      <div>
                        <span className="text-[8px] block tracking-widest text-[#8A8D90] uppercase font-bold">
                          EXCURSION
                        </span>
                        <strong className="uppercase text-xs tracking-wide text-[#1E1E1C]">
                          {selectedJourney.name}
                        </strong>
                      </div>

                      <div>
                        <span className="text-[8px] block tracking-widest text-[#8A8D90] uppercase font-bold">
                          DEPARTURE DATE
                        </span>
                        <strong className="uppercase text-xs tracking-wide text-[#1E1E1C]">
                          {new Date(date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </strong>
                      </div>

                      <div>
                        <span className="text-[8px] block tracking-widest text-[#8A8D90] uppercase font-bold">
                          CARRIAGE CLASS
                        </span>
                        <strong className="uppercase text-xs tracking-wide text-[#A12A2A]">
                          {travelClass}
                        </strong>
                      </div>

                      <div>
                        <span className="text-[8px] block tracking-widest text-[#8A8D90] uppercase font-bold">
                          COACH & SEATS
                        </span>
                        <strong className="uppercase text-xs tracking-wide font-mono text-[#1E1E1C]">
                          COACH A • {selectedSeats.join(', ')}
                        </strong>
                      </div>
                    </div>

                    {/* Bottom strip barcode + stamp */}
                    <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-left pt-1">
                      <div className="flex flex-col text-[10px]">
                        <span className="text-[7px] tracking-widest text-[#8A8D90] uppercase font-bold">
                          PASSENGER MANIFEST
                        </span>
                        <strong className="text-black font-semibold uppercase">{billingName} (+{passengerCount - 1} Guest)</strong>
                        {dietary && (
                          <span className="text-[8px] text-[#A12A2A] mt-1 italic font-sans">
                            * Dietaries: {dietary}
                          </span>
                        )}
                      </div>

                      {/* Mock barcode visual element */}
                      <div className="flex flex-col items-center">
                        <div className="h-8 w-28 bg-[repeating-linear-gradient(90deg,#000,#000_1px,transparent_1.5px,transparent_3px)] opacity-85" />
                        <span className="text-[8px] font-mono mt-1 tracking-[0.25em] text-[#8A8D90]">*{bookingRef}*</span>
                      </div>
                    </div>

                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => {
                      setStep(1);
                      setSelectedSeats([]);
                      setExtras({ champagne: false, yorkshireFudge: false, photoPass: false });
                    }}
                    className="border border-[#353535] text-[#8A8D90] hover:text-white font-bold text-xs tracking-[0.2em] px-8 py-3.5 uppercase rounded-sm cursor-pointer"
                  >
                    BOOK ANOTHER JOURNEY
                  </button>
                  <button
                    onClick={onBookingSuccess}
                    className="bg-[#B58B3A] hover:bg-[#A12A2A] text-[#1E1E1C] hover:text-white font-bold text-xs tracking-[0.2em] px-8 py-3.5 uppercase rounded-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <Ticket className="w-4 h-4" />
                    PRINT BOARDING PASS
                  </button>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
