/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, Award, Layers, Sparkles, Check, Activity, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const TIMELINE_EVENTS = [
  {
    year: '1884',
    title: 'Victorian Inception',
    desc: 'The opening of the original Harrogate central branch depot, transporting high-society tourists from across Europe to Harrogate’s thermal spa pools.'
  },
  {
    year: '1937',
    title: 'Steam Velocity Zenith',
    desc: 'The streamlined LNER Class A4 locomotives reach peak passenger express speeds across Yorkshire, setting worldwide records for coal-fired locomotives.'
  },
  {
    year: '1965',
    title: 'The Great Betrayal',
    desc: 'The controversial Beeching closures shut down the branch line. Volunteers immediately unite to buy back the tracks, stations, and locomotive stock.'
  },
  {
    year: '1973',
    title: 'Heritage Trust Foundation',
    desc: 'A preservation charity is officially formed, commencing four decades of meticulous restoration of Edwardian carriages and iron bridges.'
  },
  {
    year: '2026',
    title: 'Luxury Pullman Resurgence',
    desc: 'Our newly restored Brunswick Blue engines and premium culinary carriages resume service, marking a brand-new golden age of Yorkshire travel.'
  }
];

const MECHANICAL_PARTS = [
  {
    id: 'boiler',
    title: 'Superheated Boiler',
    desc: 'Water is converted into high-pressure steam. Our modern restoration utilizes high-grade steel plates and brass tubes, operating at pressures up to 250 psi.',
    x: 45,
    y: 48
  },
  {
    id: 'firebox',
    title: 'Coal Firebox Furnace',
    desc: 'The heat engine core where volunteer firemen shovel high-grade bituminous coal to heat the surrounding boiler water mantle to 2,000°F.',
    x: 25,
    y: 54
  },
  {
    id: 'pistons',
    title: 'Double-Acting Valves & Pistons',
    desc: 'High-pressure steam is directed into cylinder chambers, driving heavy steel rods back and forth to rotate the giant Brunswick driver wheels.',
    x: 75,
    y: 56
  },
  {
    id: 'smokebox',
    title: 'The Smokebox & Blastpipe',
    desc: 'Exhaust steam is ejected upward into the chimney, creating a strong partial vacuum that pulls hot furnace gases through the boiler tubes for heat exchange.',
    x: 88,
    y: 42
  }
];

export default function HeritageEngineering() {
  const [activePart, setActivePart] = useState(MECHANICAL_PARTS[0]);
  const [engineFired, setEngineFired] = useState(false);
  const [activeTimelineIdx, setActiveTimelineIdx] = useState(0);

  return (
    <section className="bg-[#1E1E1C] text-[#EFE9DD] py-20 border-t border-[#B58B3A]/30 relative overflow-hidden">
      {/* Schematic overlay lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#353535_1px,transparent_1px)] bg-[size:6rem_6rem] opacity-5 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#B58B3A]">
            ANGLO-FUTURIST MECHANICAL HUB
          </span>
          <h3 className="text-3xl md:text-5xl font-bold tracking-[0.1em] uppercase font-display text-[#F8F4EC] mt-2">
            HERITAGE & STEAM ENGINEERING
          </h3>
          <p className="text-xs text-[#8A8D90] font-sans mt-3 max-w-lg mx-auto leading-relaxed">
            Witness the raw power of steam, preserved through generations. Learn about our meticulous volunteer engineering standards and interactive locomotive schematics.
          </p>
        </div>

        {/* SECTION 1: Dynamic Steam Engine Cross-Section Blueprint */}
        <div className="bg-[#111110] border border-[#B58B3A]/30 rounded-sm p-6 md:p-10 mb-16 shadow-2xl">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-[#353535] pb-6 mb-8">
            <div className="text-left">
              <span className="text-[9px] font-bold tracking-[0.2em] text-[#B58B3A] uppercase">
                INTERACTIVE MECHANICAL BLUEPRINT
              </span>
              <h4 className="text-lg font-bold tracking-wide uppercase text-[#F8F4EC] mt-1">
                LNER CLASS A4 SCHEMATIC
              </h4>
            </div>

            {/* Fire Up engine switch */}
            <button
              onClick={() => setEngineFired(!engineFired)}
              className={`text-[9px] font-bold tracking-[0.2em] px-6 py-3 border rounded-sm transition-all flex items-center gap-2 cursor-pointer ${
                engineFired
                  ? 'bg-[#A12A2A] border-[#A12A2A] text-white animate-pulse'
                  : 'border-[#B58B3A] text-[#B58B3A] hover:bg-[#B58B3A] hover:text-[#1E1E1C]'
              }`}
            >
              <Activity className="w-4 h-4" />
              {engineFired ? 'SHUT DOWN ENGINE' : 'FIRE UP BOILER'}
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Giant Blueprint SVG (W-7/12) */}
            <div className="lg:col-span-8 bg-[#181817] rounded-sm p-4 border border-[#353535] relative overflow-hidden flex items-center justify-center">
              
              {/* Technical Grid Blueprint Overlay */}
              <div className="absolute inset-0 bg-[radial-gradient(#353535_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-25" />

              <svg viewBox="0 0 100 100" className="w-full max-w-[650px] relative z-10 text-[#8A8D90] stroke-current fill-none">
                
                {/* Simulated Piston/Steam Steam Flows */}
                {engineFired && (
                  <>
                    {/* Steam rising from chimney */}
                    <motion.ellipse
                      cx="88"
                      cy="22"
                      rx="3"
                      ry="2"
                      fill="#FFFFFF"
                      opacity="0.2"
                      animate={{ y: [-5, -20], x: [88, 92], opacity: [0.3, 0] }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: 'easeOut' }}
                    />
                    <motion.ellipse
                      cx="88"
                      cy="22"
                      rx="5"
                      ry="3.5"
                      fill="#FFFFFF"
                      opacity="0.15"
                      animate={{ y: [-10, -35], x: [88, 94], opacity: [0.2, 0] }}
                      transition={{ repeat: Infinity, duration: 2, ease: 'easeOut', delay: 0.5 }}
                    />

                    {/* Firebox thermal flicker */}
                    <rect x="22" y="50" width="8" height="8" fill="#B96A3C" opacity="0.1" className="animate-pulse" />
                  </>
                )}

                {/* Engine Outer Body Shell */}
                <path d="M 5,60 H 95 V 50 H 85 Q 83,40 78,38 H 25 Z" strokeWidth="0.8" />
                <rect x="15" y="42" width="10" height="18" strokeWidth="0.8" /> {/* Driver Cabin */}
                
                {/* Boiler Tubes & Furnace representation */}
                <line x1="28" y1="46" x2="72" y2="46" strokeWidth="0.4" strokeDasharray="1 1" />
                <line x1="28" y1="50" x2="72" y2="50" strokeWidth="0.4" strokeDasharray="1 1" />
                <line x1="28" y1="54" x2="72" y2="54" strokeWidth="0.4" strokeDasharray="1 1" />
                
                {/* Firebox Coal furnace */}
                <rect x="21" y="52" width="6" height="6" strokeWidth="0.5" strokeDasharray="1 1" />

                {/* Chimney Funnel */}
                <rect x="85" y="32" width="5" height="10" strokeWidth="0.8" />

                {/* Driver Wheels (Rotating dynamically if fired!) */}
                <motion.g
                  animate={engineFired ? { rotate: 360 } : {}}
                  transition={{ repeat: Infinity, duration: 3, ease: 'linear' }}
                  style={{ transformOrigin: '35px 75px' }}
                >
                  <circle cx="35" cy="75" r="10" strokeWidth="0.8" />
                  <line x1="35" y1="65" x2="35" y2="85" strokeWidth="0.4" />
                  <line x1="25" y1="75" x2="45" y2="75" strokeWidth="0.4" />
                </motion.g>

                <motion.g
                  animate={engineFired ? { rotate: 360 } : {}}
                  transition={{ repeat: Infinity, duration: 3, ease: 'linear' }}
                  style={{ transformOrigin: '55px 75px' }}
                >
                  <circle cx="55" cy="75" r="10" strokeWidth="0.8" />
                  <line x1="55" y1="65" x2="55" y2="85" strokeWidth="0.4" />
                  <line x1="45" y1="75" x2="65" y2="75" strokeWidth="0.4" />
                </motion.g>

                {/* Front Bogie helper wheel */}
                <motion.g
                  animate={engineFired ? { rotate: 720 } : {}}
                  transition={{ repeat: Infinity, duration: 3, ease: 'linear' }}
                  style={{ transformOrigin: '78px 80px' }}
                >
                  <circle cx="78" cy="80" r="5" strokeWidth="0.6" />
                  <line x1="78" y1="75" x2="78" y2="85" strokeWidth="0.3" />
                </motion.g>

                {/* Piston Rod connection linking drivers */}
                <motion.line
                  x1={engineFired ? '35' : '35'}
                  y1={engineFired ? '78' : '75'}
                  x2={engineFired ? '55' : '55'}
                  y2={engineFired ? '78' : '75'}
                  strokeWidth="1.2"
                  stroke="#FFFFFF"
                />

                {/* Render Mechanical Interactive Valves Hotspots */}
                {MECHANICAL_PARTS.map((part) => {
                  const isActive = part.id === activePart.id;
                  return (
                    <g
                      key={part.id}
                      className="cursor-pointer"
                      onClick={() => setActivePart(part)}
                    >
                      <circle
                        cx={part.x}
                        cy={part.y}
                        r="3"
                        fill={isActive ? '#A12A2A' : '#B58B3A'}
                        className="animate-pulse"
                      />
                      <circle
                        cx={part.x}
                        cy={part.y}
                        r="1.2"
                        fill="#FFFFFF"
                      />
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Selected Mechanical Spec explanation (W-5/12) */}
            <div className="lg:col-span-4 text-left bg-[#1E1E1C] p-6 rounded-sm border border-[#353535]">
              <span className="text-[9px] font-bold tracking-[0.25em] text-[#B58B3A] uppercase">
                MECHANICAL COMPONENT VIEW
              </span>
              <h4 className="text-xl font-bold tracking-wide text-[#F8F4EC] uppercase mt-1 mb-3">
                {activePart.title}
              </h4>
              <p className="text-xs text-[#8A8D90] font-sans leading-relaxed mb-6">
                {activePart.desc}
              </p>

              <div className="border-t border-[#353535] pt-4 flex flex-col gap-3 text-[10px] text-[#8A8D90] font-sans">
                <div className="flex justify-between">
                  <span>Standard Pressure Level:</span>
                  <span className="text-white font-bold font-mono">250 PSI</span>
                </div>
                <div className="flex justify-between">
                  <span>Thermodynamic Efficiency:</span>
                  <span className="text-[#81C784] font-bold font-mono">Optimized 92%</span>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* SECTION 2: Chronological Timeline Tracks */}
        <div className="border-t border-[#B58B3A]/20 pt-16 text-left">
          <span className="text-[9px] font-bold tracking-[0.25em] text-[#B58B3A] uppercase mb-8 block text-center">
            YORKSHIRE STEAM TIMELINE
          </span>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
            {/* Visual golden rail line traversing events */}
            <div className="hidden md:block absolute top-[44px] left-0 right-0 h-0.5 bg-gradient-to-r from-[#B58B3A]/10 via-[#B58B3A] to-[#B58B3A]/10 z-0" />

            {TIMELINE_EVENTS.map((evt, idx) => {
              const isActive = idx === activeTimelineIdx;
              return (
                <div
                  key={evt.year}
                  onClick={() => setActiveTimelineIdx(idx)}
                  className={`bg-[#111110] border p-5 rounded-sm flex flex-col gap-3 cursor-pointer z-10 transition-all ${
                    isActive ? 'border-[#A12A2A] shadow-xl' : 'border-[#353535] hover:border-[#8A8D90]/50'
                  }`}
                >
                  {/* Timeline Dot Node */}
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full border flex items-center justify-center font-bold text-xs font-sans ${
                      isActive ? 'bg-[#A12A2A] border-[#A12A2A] text-white' : 'bg-[#1E1E1C] border-[#353535] text-[#8A8D90]'
                    }`}>
                      {evt.year}
                    </div>
                    {isActive && (
                      <span className="text-[9px] font-bold text-[#A12A2A] tracking-widest uppercase">
                        ACTIVE ERA
                      </span>
                    )}
                  </div>

                  <h5 className="text-sm font-bold tracking-wide uppercase text-[#F8F4EC]">
                    {evt.title}
                  </h5>
                  <p className="text-[11px] text-[#8A8D90] font-sans leading-relaxed">
                    {evt.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
}
