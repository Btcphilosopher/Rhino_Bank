/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Calendar, Users, MapPin, ArrowRight, Compass } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Journey } from '../types';

interface HeroProps {
  onSearch: (searchParams: { from: string; to: string; date: string; passengers: number }) => void;
  journeys: Journey[];
}

const HERO_IMAGES = [
  'https://images.unsplash.com/photo-1541417904950-b855846fe074?auto=format&fit=crop&q=80&w=1600', // Ribblehead Viaduct crossing
  'https://images.unsplash.com/photo-1610448721566-47369c768e70?auto=format&fit=crop&q=80&w=1600', // Steam train close-up in morning sun
  'https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&q=80&w=1600', // Epic tracks through valley
  'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=1600'  // Atmospheric night steam
];

const STATION_TIMELINE = [
  { name: 'HARROGATE', desc: 'Central Terminus' },
  { name: 'YORK', desc: 'Medieval Hub' },
  { name: 'KEIGHLEY', desc: 'Moorlands Junction' },
  { name: 'HAWORTH', desc: 'Brontë Village' },
  { name: 'WHITBY', desc: 'Coastal Harbor' },
  { name: 'PICKERING', desc: 'Gateway to Moors' },
  { name: 'SELBY', desc: 'Historic Abbey Station' },
  { name: 'SETTLE', desc: 'Ribblehead Pathway' },
  { name: 'LEEDS', desc: 'Metropolitan Junction' }
];

export default function Hero({ onSearch, journeys }: HeroProps) {
  const [currentBg, setCurrentBg] = useState(0);
  const [fromStation, setFromStation] = useState('Harrogate');
  const [toStation, setToStation] = useState('Any Destination');
  const [date, setDate] = useState('2026-07-26');
  const [passengers, setPassengers] = useState('2 Adults');
  const [selectedStation, setSelectedStation] = useState<string | null>(null);

  // Background rotators
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBg((prev) => (prev + 1) % HERO_IMAGES.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const count = parseInt(passengers.split(' ')[0]) || 2;
    onSearch({
      from: fromStation,
      to: toStation,
      date,
      passengers: count
    });
  };

  return (
    <section className="relative min-h-screen flex flex-col justify-center pt-20 overflow-hidden bg-black text-[#EFE9DD]">
      {/* Background Slideshow */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentBg}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5 }}
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${HERO_IMAGES[currentBg]})` }}
          />
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-black/90" />
      </div>

      {/* Main Content Layout */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center py-12 md:py-24">
        {/* Left Side: Cinematic Copy & Branding */}
        <div className="lg:col-span-6 flex flex-col gap-6 text-left">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col gap-2"
          >
            <span className="text-[10px] md:text-xs font-bold tracking-[0.3em] text-[#B58B3A] uppercase font-sans">
              STEAM. HERITAGE. LANDSCAPE.
            </span>
            <h2 className="text-4xl md:text-6xl xl:text-7xl font-bold tracking-tight font-display text-[#F8F4EC] uppercase leading-none">
              YORKSHIRE <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F8F4EC] via-[#EFE9DD] to-[#B58B3A]">
                THROUGH TIME
              </span>
            </h2>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-base md:text-lg text-[#EFE9DD]/85 max-w-lg leading-relaxed font-sans"
          >
            Step aboard our beautifully restored steam trains and experience Yorkshire's majestic landscapes, heritage and history in timeless Pullman-class style.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-wrap gap-4 mt-2"
          >
            <button
              onClick={() => {
                const element = document.getElementById('featured-journeys');
                if (element) element.scrollIntoView({ behavior: 'smooth' });
              }}
              className="flex items-center gap-3 bg-[#B58B3A] hover:bg-[#b96a3c] text-[#1E1E1C] hover:text-white font-medium text-xs tracking-[0.2em] px-8 py-4 uppercase transition-all duration-300 transform rounded-sm group hover:scale-105"
            >
              EXPLORE OUR JOURNEYS
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </motion.div>
        </div>

        {/* Center/Right: Book Your Journey Card Widget */}
        <div className="lg:col-span-4 flex justify-center w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="w-full max-w-sm bg-[#1E1E1C]/95 backdrop-blur-md p-6 rounded-sm border border-[#B58B3A]/30 shadow-2xl"
          >
            <h3 className="text-sm font-bold tracking-[0.2em] uppercase text-[#F8F4EC] border-b border-[#B58B3A]/20 pb-4 mb-5 text-center flex items-center justify-center gap-2">
              <Compass className="w-4 h-4 text-[#B58B3A]" />
              BOOK YOUR JOURNEY
            </h3>

            <form onSubmit={handleSearchSubmit} className="flex flex-col gap-4">
              {/* FROM Dropdown */}
              <div className="flex flex-col gap-1.5 text-left">
                <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-[#8A8D90] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#B58B3A]" />
                  FROM
                </label>
                <select
                  value={fromStation}
                  onChange={(e) => setFromStation(e.target.value)}
                  className="w-full bg-[#353535]/50 border border-[#8A8D90]/30 rounded-sm text-sm p-3 focus:outline-none focus:border-[#B58B3A] transition-colors font-sans"
                >
                  <option value="Harrogate">Harrogate Terminus</option>
                  <option value="York">York Station</option>
                  <option value="Haworth">Haworth Station</option>
                  <option value="Whitby">Whitby Pier</option>
                </select>
              </div>

              {/* TO Dropdown */}
              <div className="flex flex-col gap-1.5 text-left">
                <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-[#8A8D90] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#B58B3A]" />
                  TO
                </label>
                <select
                  value={toStation}
                  onChange={(e) => setToStation(e.target.value)}
                  className="w-full bg-[#353535]/50 border border-[#8A8D90]/30 rounded-sm text-sm p-3 focus:outline-none focus:border-[#B58B3A] transition-colors font-sans"
                >
                  <option value="Any Destination">Any Destination</option>
                  {journeys.map((j) => (
                    <option key={j.id} value={j.id}>
                      {j.name} ({j.tagline})
                    </option>
                  ))}
                </select>
              </div>

              {/* Date Input */}
              <div className="flex flex-col gap-1.5 text-left">
                <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-[#8A8D90] flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#B58B3A]" />
                  DATE OF TRAVEL
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-[#353535]/50 border border-[#8A8D90]/30 rounded-sm text-sm p-2.5 focus:outline-none focus:border-[#B58B3A] transition-colors font-sans text-white"
                />
              </div>

              {/* Passengers Dropdown */}
              <div className="flex flex-col gap-1.5 text-left">
                <label className="text-[10px] font-bold tracking-[0.15em] uppercase text-[#8A8D90] flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-[#B58B3A]" />
                  PASSENGERS
                </label>
                <select
                  value={passengers}
                  onChange={(e) => setPassengers(e.target.value)}
                  className="w-full bg-[#353535]/50 border border-[#8A8D90]/30 rounded-sm text-sm p-3 focus:outline-none focus:border-[#B58B3A] transition-colors font-sans"
                >
                  <option value="1 Adult">1 Adult</option>
                  <option value="2 Adults">2 Adults</option>
                  <option value="3 Adults">3 Adults</option>
                  <option value="4 Adults">4 Adults</option>
                  <option value="2 Adults & 1 Child">2 Adults, 1 Child</option>
                  <option value="2 Adults & 2 Children">2 Adults, 2 Children</option>
                </select>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="w-full bg-[#B58B3A] hover:bg-[#b96a3c] text-[#1E1E1C] hover:text-white font-bold text-xs tracking-[0.2em] py-3.5 mt-2 rounded-sm uppercase transition-all duration-300 transform shadow-md"
              >
                FIND JOURNEYS
              </button>
            </form>

            <button
              onClick={() => {
                const element = document.getElementById('featured-journeys');
                if (element) element.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full text-center text-[#B58B3A] hover:text-[#EFE9DD] text-[10px] tracking-[0.15em] uppercase font-bold mt-4 block transition-colors"
            >
              VIEW TIMETABLES →
            </button>
          </motion.div>
        </div>

        {/* Far Right: Interactive Yorkshire Station Timeline */}
        <div className="lg:col-span-2 hidden lg:flex flex-col border-l border-[#B58B3A]/30 pl-6 h-[500px] justify-between text-left relative">
          <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none">
            {/* Subtle train gear blueprint overlay */}
            <svg width="150" height="150" viewBox="0 0 100 100" className="text-[#B58B3A] stroke-current fill-none">
              <circle cx="50" cy="50" r="40" strokeWidth="1" strokeDasharray="2 2" />
              <circle cx="50" cy="50" r="30" strokeWidth="1" />
              <path d="M50 0 L50 100 M0 50 L100 50 M15 15 L85 85 M15 85 L85 15" strokeWidth="0.5" />
            </svg>
          </div>

          <div className="flex flex-col gap-3">
            {STATION_TIMELINE.map((station, idx) => (
              <div
                key={station.name}
                onMouseEnter={() => setSelectedStation(station.name)}
                onMouseLeave={() => setSelectedStation(null)}
                className="relative cursor-pointer group flex items-start gap-3 py-1"
              >
                {/* Custom timeline bullet node */}
                <div className="relative mt-1">
                  <div
                    className={`w-2.5 h-2.5 rounded-full border-2 transition-all duration-300 ${
                      selectedStation === station.name
                        ? 'bg-[#B58B3A] border-[#B58B3A] scale-125 shadow-[0_0_8px_#B58B3A]'
                        : 'bg-transparent border-[#8A8D90] group-hover:border-[#B58B3A]'
                    }`}
                  />
                  {idx < STATION_TIMELINE.length - 1 && (
                    <div className="absolute top-2.5 left-[4.5px] w-[1px] h-9 bg-gradient-to-b from-[#8A8D90]/50 to-[#8A8D90]/20 group-hover:from-[#B58B3A]" />
                  )}
                </div>

                <div className="flex flex-col">
                  <span
                    className={`text-[10px] font-bold tracking-[0.2em] transition-colors duration-300 ${
                      selectedStation === station.name ? 'text-[#B58B3A]' : 'text-[#8A8D90] group-hover:text-[#EFE9DD]'
                    }`}
                  >
                    {station.name}
                  </span>
                  {selectedStation === station.name && (
                    <motion.span
                      initial={{ opacity: 0, x: -5 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] tracking-[0.1em] text-[#EFE9DD]/70 font-sans"
                    >
                      {station.desc}
                    </motion.span>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="text-[10px] font-bold tracking-[0.3em] text-[#B58B3A] animate-bounce flex items-center gap-1 mt-4">
            <span>↓ AND MORE</span>
          </div>
        </div>
      </div>
    </section>
  );
}
