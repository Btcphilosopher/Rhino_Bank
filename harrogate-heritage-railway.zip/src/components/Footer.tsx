/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Mail, Compass, HelpCircle, FileText, Heart, Shield, ArrowRight } from 'lucide-react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <footer className="bg-[#1E1E1C] text-[#EFE9DD] border-t border-[#B58B3A]/30 pt-16 pb-8 text-left relative overflow-hidden">
      {/* Blueprint lines watermarking */}
      <div className="absolute left-0 bottom-0 opacity-5 pointer-events-none w-64 h-64">
        <svg viewBox="0 0 100 100" className="w-full h-full text-[#B58B3A] stroke-current fill-none">
          <circle cx="50" cy="50" r="45" />
          <line x1="5" y1="50" x2="95" y2="50" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Top subscription bar & logo */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 border-b border-[#353535] pb-12 mb-12">
          
          {/* Logo Brand */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            <div className="flex items-center gap-3">
              <div className="bg-[#B58B3A] p-2 text-[#1E1E1C] rounded-sm">
                <Compass className="w-6 h-6 stroke-[1.5]" />
              </div>
              <div>
                <h4 className="text-sm font-bold tracking-[0.25em] text-[#F8F4EC] uppercase">
                  HARROGATE
                </h4>
                <p className="text-[10px] font-bold tracking-[0.3em] text-[#B58B3A] uppercase">
                  HERITAGE RAILWAY
                </p>
              </div>
            </div>
            <p className="text-xs text-[#8A8D90] font-sans mt-2 max-w-sm leading-relaxed">
              Preserving Britain's golden age of steam transport with premium excursions, Pullman fine dining, and master craftsman workshops across North Yorkshire.
            </p>
          </div>

          {/* Newsletter signup */}
          <div className="lg:col-span-8 flex flex-col gap-3 text-left">
            <span className="text-[9px] font-bold tracking-[0.25em] text-[#B58B3A] uppercase">
              EXCLUSIVE OFFERS & NEWSLETTERS
            </span>
            <h5 className="text-base font-bold uppercase text-[#F8F4EC] tracking-wide">
              BE FIRST IN LINE FOR SPECIAL RELEASES
            </h5>

            {subscribed ? (
              <p className="text-xs text-[#81C784] font-sans mt-2 font-bold uppercase tracking-wider">
                ✓ THANK YOU. YOU HAVE BEEN ADDED TO OUR EXCLUSIVE PRIORITY BOARDING LIST.
              </p>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2 max-w-lg mt-1 w-full">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  className="bg-[#111110] border border-[#353535] rounded-sm text-xs p-3 flex-1 text-white focus:outline-none focus:border-[#B58B3A] font-sans"
                />
                <button
                  type="submit"
                  className="bg-[#B58B3A] hover:bg-[#A12A2A] text-[#1E1E1C] hover:text-white font-bold text-xs tracking-[0.15em] px-6 py-3.5 rounded-sm uppercase transition-all duration-300 transform shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  SUBSCRIBE
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}
            <p className="text-[10px] text-[#8A8D90] font-sans">
              We release tickets in priority tiers. Unsubscribe at any time. Read our privacy charter.
            </p>
          </div>

        </div>

        {/* Links directory columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 border-b border-[#353535] pb-12 mb-8 text-xs font-sans text-[#8A8D90]">
          
          <div className="flex flex-col gap-3">
            <h6 className="text-[10px] font-bold tracking-[0.25em] text-[#F8F4EC] uppercase">
              JOURNEYS & CARS
            </h6>
            <a href="#featured-journeys" className="hover:text-[#B58B3A] transition-colors">Dales Explorer Excursion</a>
            <a href="#featured-journeys" className="hover:text-[#B58B3A] transition-colors">York & Whitby Coastline</a>
            <a href="#featured-journeys" className="hover:text-[#B58B3A] transition-colors">Brontë Country Moors</a>
            <a href="#featured-journeys" className="hover:text-[#B58B3A] transition-colors">Castles & Dales Pullman</a>
          </div>

          <div className="flex flex-col gap-3">
            <h6 className="text-[10px] font-bold tracking-[0.25em] text-[#F8F4EC] uppercase">
              DINING & SIGHTS
            </h6>
            <a href="#dining" className="hover:text-[#B58B3A] transition-colors">Pullman Fine Dining</a>
            <a href="#dining" className="hover:text-[#B58B3A] transition-colors">Edwardian Afternoon Tea</a>
            <a href="#dining" className="hover:text-[#B58B3A] transition-colors">The Sunday Carvery</a>
            <a href="#map" className="hover:text-[#B58B3A] transition-colors">Interactive Route Maps</a>
          </div>

          <div className="flex flex-col gap-3">
            <h6 className="text-[10px] font-bold tracking-[0.25em] text-[#F8F4EC] uppercase">
              HERITAGE HUB
            </h6>
            <a href="#fleet" className="hover:text-[#B58B3A] transition-colors">Steam Fleet Directory</a>
            <a href="#engineering" className="hover:text-[#B58B3A] transition-colors">LNER Boiler Blueprints</a>
            <a href="#engineering" className="hover:text-[#B58B3A] transition-colors">Overhaul Workshop Tours</a>
            <a href="#engineering" className="hover:text-[#B58B3A] transition-colors">History Archives</a>
          </div>

          <div className="flex flex-col gap-3">
            <h6 className="text-[10px] font-bold tracking-[0.25em] text-[#F8F4EC] uppercase">
              CHARITY TRUST
            </h6>
            <a href="#events" className="hover:text-[#B58B3A] transition-colors">Volunteer Opportunities</a>
            <a href="#events" className="hover:text-[#B58B3A] transition-colors">Financial Donation Portals</a>
            <a href="#events" className="hover:text-[#B58B3A] transition-colors">Wills & Legacy Bequests</a>
            <a href="#events" className="hover:text-[#B58B3A] transition-colors">Corporate Hospitality Rates</a>
          </div>

        </div>

        {/* Copyright & Sign-off stamp */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-[#8A8D90] font-sans">
          <div className="flex flex-wrap gap-4 items-center">
            <span>© 2026 Harrogate Heritage Railway Trust. All Rights Reserved.</span>
            <span>•</span>
            <span className="hover:text-white transition-all cursor-pointer flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-[#B58B3A]" /> Privacy Policy
            </span>
            <span>•</span>
            <span className="hover:text-white transition-all cursor-pointer flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5 text-[#B58B3A]" /> Terms of Carriage
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[8px] font-bold tracking-widest text-[#B58B3A] uppercase">
              YORKSHIRE CRAFTED WITH PROUD DEVOTION
            </span>
            <div className="w-4 h-4 rounded-full bg-[#A12A2A] border border-[#B58B3A] flex items-center justify-center text-[7px] text-white font-bold">
              Y
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
}
