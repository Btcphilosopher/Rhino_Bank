/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Utensils, Award, MapPin, Sparkles, BookOpen, Clock, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MENU_ITEMS } from '../data';

export default function ExperiencesDining() {
  const [activeMenuCat, setActiveMenuCat] = useState<'Starters' | 'Mains' | 'Desserts' | 'Wine' | 'Yorkshire Ales'>('Mains');
  const [activeSection, setActiveSection] = useState<'menu' | 'experiences'>('menu');

  const filteredMenuItems = MENU_ITEMS.filter((item) => item.category === activeMenuCat);

  const diningExperiences = [
    {
      title: 'THE SUNDAY ROAST',
      tagline: 'A Yorkshire Tradition Perfected',
      desc: 'Savor aged Swaledale rib of beef carved table-side from a gleaming silver trolley, served with giant, crisp Yorkshire puddings and organic farm vegetables.',
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600',
      duration: '3 hours',
      price: '£65 per guest'
    },
    {
      title: 'EDWARDIAN AFTERNOON TEA',
      tagline: 'Original Heritage Pastry',
      desc: 'Elegant tiered cake stands loaded with freshly-baked warm scones, homemade jams, local clotted cream, delicate finger sandwiches, and exceptional loose-leaf tea infusions.',
      image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=600',
      duration: '2.5 hours',
      price: '£45 per guest'
    },
    {
      title: 'MURDER MYSTERY SOIRÉE',
      tagline: 'An Evening of Suspense',
      desc: 'Crack a classic 1930s Agatha Christie-style riddle as actors weave through our dining coaches. Includes a luxurious 4-course champagne-paired dinner.',
      image: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=600',
      duration: '4 hours',
      price: '£95 per guest'
    }
  ];

  return (
    <section className="bg-[#EFE9DD] text-[#1E1E1C] py-20 border-t border-[#B58B3A]/20">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Headings */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end border-b border-[#B58B3A]/30 pb-6 mb-12 gap-4">
          <div className="text-left">
            <span className="text-[10px] font-bold tracking-[0.35em] text-[#A12A2A] uppercase">
              GASTRONOMIC CRUISE
            </span>
            <h3 className="text-3xl md:text-5xl font-bold tracking-[0.1em] uppercase font-display text-[#1E1E1C] mt-2">
              PULLMAN DINING
            </h3>
            <p className="text-xs text-[#8A8D90] font-sans mt-2 max-w-xl">
              Experience Michelin-inspired culinary craft, showcasing seasonal Yorkshire produce, paired with private reserves, served as rolling green landscapes drift past your window.
            </p>
          </div>

          {/* Core Navigation Selector */}
          <div className="flex bg-[#EFE9DD] p-1 rounded-sm border border-[#B58B3A]/20">
            <button
              onClick={() => setActiveSection('menu')}
              className={`text-[9px] font-bold tracking-[0.2em] px-4 py-2.5 rounded-sm transition-all uppercase cursor-pointer ${
                activeSection === 'menu'
                  ? 'bg-[#1E1E1C] text-[#EFE9DD]'
                  : 'text-[#8A8D90] hover:text-[#1E1E1C]'
              }`}
            >
              SEASONAL MENU
            </button>
            <button
              onClick={() => setActiveSection('experiences')}
              className={`text-[9px] font-bold tracking-[0.2em] px-4 py-2.5 rounded-sm transition-all uppercase cursor-pointer ${
                activeSection === 'experiences'
                  ? 'bg-[#1E1E1C] text-[#EFE9DD]'
                  : 'text-[#8A8D90] hover:text-[#1E1E1C]'
              }`}
            >
              LUXURY PACKAGES
            </button>
          </div>
        </div>

        {/* Content Stages */}
        <AnimatePresence mode="wait">
          {activeSection === 'menu' ? (
            <motion.div
              key="menu-stage"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start"
            >
              {/* Category selector columns (Left, W-3/12) */}
              <div className="lg:col-span-3 flex flex-col gap-2">
                <span className="text-[9px] font-bold tracking-[0.25em] text-[#A12A2A] uppercase mb-4 text-left">
                  SELECT CARD
                </span>
                {(['Starters', 'Mains', 'Desserts', 'Wine', 'Yorkshire Ales'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setActiveMenuCat(cat)}
                    className={`text-left text-xs tracking-[0.2em] font-bold uppercase py-3 px-4 border-l-2 transition-all cursor-pointer ${
                      activeMenuCat === cat
                        ? 'border-[#A12A2A] bg-[#EFE9DD] text-[#1E1E1C] pl-6'
                        : 'border-[#B58B3A]/10 text-[#8A8D90] hover:border-[#B58B3A]/30 hover:text-[#1E1E1C]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}

                <div className="mt-8 bg-[#1E1E1C] text-[#EFE9DD] p-5 rounded-sm border border-[#B58B3A]/30 text-left">
                  <h5 className="text-[10px] font-bold tracking-widest text-[#B58B3A] uppercase mb-2 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-[#B58B3A]" />
                    YORKSHIRE PROUD
                  </h5>
                  <p className="text-[10px] text-[#8A8D90] font-sans leading-relaxed">
                    100% of our meat, fish, flour, honey, and beers are sourced from historic artisan producers located within forty miles of Harrogate station tracks.
                  </p>
                </div>
              </div>

              {/* Menu listings (Right, W-9/12) */}
              <div className="lg:col-span-9 bg-white border border-[#B58B3A]/30 p-8 md:p-12 shadow-xl rounded-sm relative">
                {/* Vintage Corner Decors */}
                <div className="absolute top-4 left-4 w-6 h-6 border-t border-l border-[#B58B3A]/30" />
                <div className="absolute top-4 right-4 w-6 h-6 border-t border-r border-[#B58B3A]/30" />
                <div className="absolute bottom-4 left-4 w-6 h-6 border-b border-l border-[#B58B3A]/30" />
                <div className="absolute bottom-4 right-4 w-6 h-6 border-b border-r border-[#B58B3A]/30" />

                <div className="text-center mb-8">
                  <h4 className="text-xl font-bold tracking-[0.2em] uppercase font-display text-[#1E1E1C]">
                    THE YORKSHIRE PULLMAN
                  </h4>
                  <p className="text-[9px] tracking-widest text-[#8A8D90] uppercase mt-1">
                    First Class Restaurant Carriage Menu
                  </p>
                  <div className="w-24 h-[1px] bg-[#B58B3A]/30 mx-auto mt-3" />
                </div>

                <div className="flex flex-col gap-8 divide-y divide-[#B58B3A]/15">
                  {filteredMenuItems.map((item) => (
                    <div key={item.id} className="pt-6 first:pt-0 text-left">
                      <div className="flex justify-between items-baseline gap-4">
                        <h5 className="text-sm font-bold tracking-wide uppercase text-[#1E1E1C] flex items-center gap-2">
                          <Sparkles className="w-3.5 h-3.5 text-[#B58B3A]" />
                          {item.name}
                        </h5>
                        <div className="flex-1 border-b border-dotted border-[#B58B3A]/30 mx-4" />
                        <span className="text-sm font-bold text-[#A12A2A] font-sans">£{item.price.toFixed(2)}</span>
                      </div>
                      <p className="text-xs text-[#353535] font-sans leading-relaxed mt-2 max-w-2xl">
                        {item.description}
                      </p>
                      <div className="flex items-center gap-4 mt-3 text-[10px] font-semibold text-[#8A8D90]">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-[#A12A2A]" />
                          Provenance: {item.localSource}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="experiences-stage"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6"
            >
              {diningExperiences.map((exp) => (
                <div
                  key={exp.title}
                  className="bg-white border border-[#B58B3A]/20 rounded-sm overflow-hidden shadow-lg hover:border-[#A12A2A] hover:shadow-2xl transition-all duration-300 group flex flex-col justify-between"
                >
                  <div>
                    {/* Img with zoom */}
                    <div className="h-48 overflow-hidden relative">
                      <img
                        src={exp.image}
                        alt={exp.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    </div>

                    <div className="p-6 text-left">
                      <h4 className="text-sm font-bold tracking-widest text-[#1E1E1C] uppercase">
                        {exp.title}
                      </h4>
                      <p className="text-[10px] italic text-[#B58B3A] mt-0.5">{exp.tagline}</p>
                      <p className="text-xs text-[#353535] font-sans leading-relaxed mt-3">
                        {exp.desc}
                      </p>
                    </div>
                  </div>

                  <div className="p-6 pt-0 border-t border-[#B58B3A]/10 mt-4 flex items-center justify-between text-[10px] font-bold text-[#8A8D90]">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-[#B58B3A]" />
                      {exp.duration}
                    </span>
                    <span className="text-[#A12A2A]">{exp.price}</span>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
