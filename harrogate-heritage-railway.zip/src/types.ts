/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Journey {
  id: string;
  name: string;
  tagline: string;
  description: string;
  route: string;
  duration: string;
  price: number;
  firstClassPrice: number;
  image: string;
  departures: string[];
  availability: string;
  highlights: string[];
}

export interface Locomotive {
  id: string;
  name: string;
  number: string;
  classType: string;
  designer: string;
  built: string;
  status: 'Operational' | 'Under Restoration' | 'In Workshop';
  wheelArrangement: string;
  description: string;
  restorationStory: string;
  powerOutput: string;
  weight: string;
  topSpeed: string;
  image: string;
  gallery: string[];
}

export interface HeritageEvent {
  id: string;
  title: string;
  subtitle: string;
  date: string;
  location: string;
  price: number;
  category: 'Gala' | 'Dining' | 'Festival' | 'Family' | 'Photography';
  description: string;
  image: string;
  featured: boolean;
}

export interface MenuItem {
  id: string;
  name: string;
  category: 'Starters' | 'Mains' | 'Desserts' | 'Wine' | 'Yorkshire Ales';
  description: string;
  price: number;
  localSource: string;
}

export interface MerchItem {
  id: string;
  name: string;
  category: 'Prints' | 'Models' | 'Books' | 'Collectibles' | 'Vouchers';
  price: number;
  description: string;
  image: string;
  rating: number;
}

export interface MapPoint {
  id: string;
  name: string;
  type: 'station' | 'viaduct' | 'landmark' | 'hotel' | 'dining';
  x: number; // percentage coordinate on SVG grid
  y: number; // percentage coordinate on SVG grid
  description: string;
  tagline?: string;
  image: string;
}

export interface BookingState {
  journeyId: string;
  date: string;
  passengers: {
    adults: number;
    children: number;
  };
  travelClass: 'Standard' | 'First' | 'Pullman Dining';
  dietaryRequirements: string;
  selectedSeats: string[];
  extras: {
    champagne: boolean;
    yorkshireFudge: boolean;
    photoPass: boolean;
  };
  step: number;
}
