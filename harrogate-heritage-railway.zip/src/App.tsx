/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ValueProps from './components/ValueProps';
import FeaturedJourneys from './components/FeaturedJourneys';
import InteractiveMap from './components/InteractiveMap';
import ExperiencesDining from './components/ExperiencesDining';
import FleetExplorer from './components/FleetExplorer';
import EventsCalendar from './components/EventsCalendar';
import HeritageEngineering from './components/HeritageEngineering';
import JournalEditorial from './components/JournalEditorial';
import BookingSystem from './components/BookingSystem';
import Footer from './components/Footer';

import { JOURNEYS } from './data';
import { MerchItem } from './types';
import MerchandiseShop from './components/MerchandiseShop';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, ShoppingCart, Train, Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [cart, setCart] = useState<{ item: MerchItem; quantity: number }[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [checkoutComplete, setCheckoutComplete] = useState(false);
  const [bookingPrefillId, setBookingPrefillId] = useState('');

  // Apply dark mode styling class to root document html
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Scrolling helpers to navigate gracefully when viewing the unified home page
  useEffect(() => {
    if (activeTab === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.getElementById(activeTab);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [activeTab]);

  const handleAddToCart = (item: MerchItem) => {
    setCart((prevCart) => {
      const existing = prevCart.find((ci) => ci.item.id === item.id);
      if (existing) {
        return prevCart.map((ci) =>
          ci.item.id === item.id ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [...prevCart, { item, quantity: 1 }];
    });
    setCartOpen(true);
  };

  const handleRemoveFromCart = (id: string) => {
    setCart((prev) => prev.filter((ci) => ci.item.id !== id));
  };

  const handleUpdateCartQty = (id: string, qty: number) => {
    setCart((prev) =>
      prev.map((ci) => (ci.item.id === id ? { ...ci, quantity: qty } : ci))
    );
  };

  const handleBookingSearch = (searchParams: { from: string; to: string; date: string; passengers: number }) => {
    if (searchParams.to !== 'Any Destination') {
      setBookingPrefillId(searchParams.to);
    }
    setActiveTab('book');
  };

  const handleSelectJourneyFromGrid = (journeyId: string) => {
    if (journeyId) {
      setBookingPrefillId(journeyId);
      setActiveTab('book');
    } else {
      // If "View All" is selected, take them directly to the booking form
      setActiveTab('book');
    }
  };

  const handleCompleteCartCheckout = () => {
    setCheckoutComplete(true);
    setCart([]);
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-500 ${
      darkMode ? 'bg-[#1E1E1C] text-[#EFE9DD]' : 'bg-[#EFE9DD] text-[#1E1E1C]'
    }`}>
      {/* Premium Header */}
      <Header
        activeTab={activeTab === 'book' ? 'book' : activeTab}
        setActiveTab={setActiveTab}
        cartCount={cart.reduce((s, c) => s + c.quantity, 0)}
        openCart={() => setCartOpen(true)}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Primary Routing/Display logic */}
      <main className="flex-1">
        {activeTab === 'book' ? (
          <div className="pt-24 min-h-[80vh] flex flex-col justify-center bg-[#1E1E1C]">
            <div className="max-w-4xl mx-auto px-4 w-full text-left py-6">
              <button
                onClick={() => setActiveTab('home')}
                className="text-xs font-bold tracking-[0.2em] text-[#B58B3A] hover:text-[#EFE9DD] transition-colors flex items-center gap-1.5 uppercase cursor-pointer"
              >
                ← RETURN TO HOME
              </button>
            </div>
            <BookingSystem
              initialJourneyId={bookingPrefillId}
              onBookingSuccess={() => {
                setActiveTab('home');
                setBookingPrefillId('');
              }}
            />
          </div>
        ) : (
          /* Render Immersive Unified Homepage Scroll-deck */
          <div>
            <Hero onSearch={handleBookingSearch} journeys={JOURNEYS} />
            
            <ValueProps />

            <div id="home">
              <FeaturedJourneys
                journeys={JOURNEYS}
                onSelectJourney={handleSelectJourneyFromGrid}
                onNavigateToDining={() => setActiveTab('dining')}
                onNavigateToAbout={() => setActiveTab('engineering')}
              />
            </div>

            <div id="map">
              <InteractiveMap onSelectJourneyByStation={(station) => {
                setBookingPrefillId('dales-explorer'); // Default to dales explorer on map choice
                setActiveTab('book');
              }} />
            </div>

            <div id="dining">
              <ExperiencesDining />
            </div>

            <div id="fleet">
              <FleetExplorer />
            </div>

            <div id="engineering">
              <HeritageEngineering />
            </div>

            <div id="events">
              <EventsCalendar onSelectEvent={(title, price) => {
                setBookingPrefillId('christmas-express'); // Default fallback prefill
                setActiveTab('book');
              }} />
            </div>

            <div id="shop">
              <MerchandiseShop
                onAddToCart={handleAddToCart}
                cart={cart}
                onRemoveFromCart={handleRemoveFromCart}
                onUpdateCartQty={handleUpdateCartQty}
                checkoutOpen={cartOpen}
                setCheckoutOpen={setCartOpen}
                onCompleteCheckout={handleCompleteCartCheckout}
              />
            </div>

            <JournalEditorial />
          </div>
        )}
      </main>

      {/* Global Footer */}
      <Footer />

      {/* Premium Cart overlay drawers */}
      <AnimatePresence>
        {cartOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex justify-end"
          >
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full max-w-md bg-white text-[#1E1E1C] h-full shadow-2xl p-6 md:p-8 flex flex-col justify-between text-left"
            >
              <div>
                <div className="flex justify-between items-center border-b border-[#B58B3A]/20 pb-4 mb-6">
                  <h4 className="text-sm font-bold tracking-[0.2em] uppercase flex items-center gap-2">
                    <ShoppingCart className="w-4 h-4 text-[#B58B3A]" />
                    YOUR SHOPPING BAG
                  </h4>
                  <button
                    onClick={() => setCartOpen(false)}
                    className="p-1 rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
                    aria-label="Close Cart"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {cart.length === 0 ? (
                  <div className="py-24 text-center">
                    <p className="text-xs text-[#8A8D90] font-sans">Your shopping bag is empty.</p>
                    <button
                      onClick={() => {
                        setCartOpen(false);
                        setActiveTab('shop');
                      }}
                      className="text-[10px] font-bold text-[#B58B3A] tracking-widest uppercase mt-4 cursor-pointer hover:text-[#A12A2A]"
                    >
                      BROWSE EXCLUSIVE ITEMS
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-4 overflow-y-auto max-h-[60vh] pr-1">
                    {cart.map((ci) => (
                      <div key={ci.item.id} className="flex gap-4 border-b border-[#B58B3A]/10 pb-4">
                        <img
                          src={ci.item.image}
                          alt={ci.item.name}
                          className="w-16 h-16 object-cover rounded-sm border border-[#B58B3A]/10"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <span className="text-[8px] font-bold tracking-widest text-[#B58B3A] uppercase">
                              {ci.item.category}
                            </span>
                            <h5 className="text-[11px] font-bold uppercase text-[#1E1E1C] leading-snug line-clamp-1">
                              {ci.item.name}
                            </h5>
                          </div>
                          <div className="flex items-center justify-between text-[10px] font-semibold text-[#8A8D90] font-sans">
                            <span>Qty: {ci.quantity}</span>
                            <span className="text-[#1E1E1C] font-bold">£{(ci.item.price * ci.quantity).toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {cart.length > 0 && (
                <div className="border-t border-[#B58B3A]/20 pt-6 mt-6 flex flex-col gap-4">
                  <div className="flex justify-between items-baseline text-xs">
                    <span className="font-semibold text-[#8A8D90]">Bag Subtotal:</span>
                    <strong className="text-sm font-bold text-[#A12A2A]">
                      £{cart.reduce((s, c) => s + c.item.price * c.quantity, 0).toFixed(2)}
                    </strong>
                  </div>
                  <button
                    onClick={() => {
                      setCartOpen(false);
                      handleCompleteCartCheckout();
                    }}
                    className="w-full bg-[#1E1E1C] hover:bg-[#A12A2A] text-white font-bold text-xs tracking-[0.2em] py-4 rounded-sm uppercase transition-colors"
                  >
                    COMPLETE PURCHASES
                  </button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Notification Modals */}
      <AnimatePresence>
        {checkoutComplete && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/75 backdrop-blur-xs z-55 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-[#EFE9DD] border-2 border-[#B58B3A] p-8 max-w-sm w-full rounded-sm text-center shadow-2xl relative"
            >
              <div className="w-12 h-12 bg-[#204334] text-[#EFE9DD] rounded-full flex items-center justify-center mx-auto mb-4 border border-[#B58B3A]">
                <Check className="w-6 h-6 stroke-[2]" />
              </div>

              <span className="text-[9px] font-bold tracking-[0.25em] text-[#B58B3A] uppercase block mb-1">
                MEMORABILIA DISPATCHED
              </span>
              <h4 className="text-lg font-bold uppercase text-[#1E1E1C] tracking-wide mb-2">
                TRANSACTION COMPLETE
              </h4>
              <p className="text-xs text-[#353535] font-sans leading-relaxed mb-6">
                Your premium collectibles have been securely paid and cataloged. A Royal Mail carriage consignment tracking number has been sent to your email.
              </p>

              <button
                onClick={() => setCheckoutComplete(false)}
                className="w-full bg-[#1E1E1C] hover:bg-[#A12A2A] text-white font-bold text-xs tracking-[0.2em] py-3 uppercase rounded-sm cursor-pointer"
              >
                RETURN TO BOUTIQUE
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
