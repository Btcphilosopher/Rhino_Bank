package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.RhinoViewModel
import com.example.ui.screens.CapitalMarketsScreen
import com.example.ui.screens.ClientsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DealsScreen
import com.example.ui.screens.ProjectScreen
import com.example.ui.screens.CoPilotScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RhinoEmerald
import com.example.ui.theme.RhinoGoldPrimary
import com.example.ui.theme.RhinoNavyDark
import com.example.ui.theme.RhinoNavyLight
import com.example.ui.theme.RhinoNavyMedium
import com.example.ui.theme.RhinoTealPrimary

enum class Screen(val title: String, val icon: ImageVector, val tag: String) {
    Dashboard("Overview", Icons.Default.Dashboard, "nav_overview"),
    Deals("Deals", Icons.Default.BusinessCenter, "nav_deals"),
    Clients("CRM Registry", Icons.Default.Domain, "nav_crm"),
    Projects("Portfolios", Icons.Default.Calculate, "nav_portfolios"),
    Markets("DCM Markets", Icons.Default.ShowChart, "nav_markets"),
    CoPilot("AI Analyst", Icons.Default.Forum, "nav_copilot")
}

class MainActivity : ComponentActivity() {
    private val viewModel: RhinoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf(Screen.Dashboard) }

                BoxWithConstraints(modifier = Modifier.fillMaxSize().background(RhinoNavyDark)) {
                    val isTablet = maxWidth > 720.dp

                    if (isTablet) {
                        // --- CANONICAL ADAPTIVE LAYOUT (TABLET NAVIGATION RAIL) ---
                        Row(modifier = Modifier.fillMaxSize()) {
                            NavigationRail(
                                containerColor = RhinoNavyMedium,
                                header = {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(vertical = 16.dp)
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.img_rhino_logo_1784891380503),
                                            contentDescription = "Rhino Bank Logo",
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .border(1.5.dp, RhinoGoldPrimary, CircleShape),
                                            contentScale = ContentScale.Crop
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "RHINO",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = RhinoGoldPrimary,
                                            letterSpacing = 1.sp
                                        )
                                    }
                                },
                                modifier = Modifier.border(1.dp, RhinoNavyLight)
                            ) {
                                Screen.values().forEach { screen ->
                                    NavigationRailItem(
                                        selected = currentScreen == screen,
                                        onClick = { currentScreen = screen },
                                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                                        label = { Text(screen.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = Color.White,
                                            selectedTextColor = RhinoGoldPrimary,
                                            unselectedIconColor = RhinoGoldPrimary.copy(alpha = 0.6f),
                                            unselectedTextColor = RhinoGoldPrimary.copy(alpha = 0.6f),
                                            indicatorColor = RhinoGoldPrimary
                                        ),
                                        modifier = Modifier.testTag(screen.tag)
                                    )
                                }
                            }

                            // Content area for Tablet
                            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                HeaderBar(currentScreen = currentScreen)
                                Box(modifier = Modifier.weight(1f)) {
                                    ScreenContent(screen = currentScreen, viewModel = viewModel)
                                }
                            }
                        }
                    } else {
                        // --- STANDARD PHONE LAYOUT (BOTTOM NAVIGATION BAR) ---
                        Scaffold(
                            topBar = { HeaderBar(currentScreen = currentScreen) },
                            bottomBar = {
                                NavigationBar(
                                    containerColor = RhinoNavyMedium,
                                    modifier = Modifier.border(1.dp, RhinoNavyLight)
                                ) {
                                    Screen.values().forEach { screen ->
                                        NavigationBarItem(
                                            selected = currentScreen == screen,
                                            onClick = { currentScreen = screen },
                                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                                            label = { Text(screen.title, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = Color.White,
                                                selectedTextColor = RhinoGoldPrimary,
                                                unselectedIconColor = RhinoGoldPrimary.copy(alpha = 0.6f),
                                                unselectedTextColor = RhinoGoldPrimary.copy(alpha = 0.6f),
                                                indicatorColor = RhinoGoldPrimary
                                            ),
                                            modifier = Modifier.testTag(screen.tag)
                                        )
                                    }
                                }
                            },
                            containerColor = RhinoNavyDark
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                ScreenContent(screen = currentScreen, viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeaderBar(currentScreen: Screen) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.img_rhino_logo_1784891380503),
                    contentDescription = "Logo",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .border(1.dp, RhinoGoldPrimary, CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "RHINO BANK",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = RhinoGoldPrimary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "PORTAL: ${currentScreen.title.uppercase()}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = RhinoTealPrimary,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        },
        actions = {
            // High-fidelity terminal-like system indicators
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .padding(end = 12.dp)
                    .background(RhinoNavyDark, RoundedCornerShape(4.dp))
                    .border(1.dp, RhinoNavyLight, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(RhinoEmerald, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "AUM SECURE",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = RhinoEmerald
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = RhinoNavyMedium,
            titleContentColor = RhinoGoldPrimary
        ),
        modifier = Modifier.border(1.dp, RhinoNavyLight)
    )
}

@Composable
fun ScreenContent(screen: Screen, viewModel: RhinoViewModel) {
    when (screen) {
        Screen.Dashboard -> DashboardScreen(viewModel = viewModel)
        Screen.Deals -> DealsScreen(viewModel = viewModel)
        Screen.Clients -> ClientsScreen(viewModel = viewModel)
        Screen.Projects -> ProjectScreen(viewModel = viewModel)
        Screen.Markets -> CapitalMarketsScreen(viewModel = viewModel)
        Screen.CoPilot -> CoPilotScreen(viewModel = viewModel)
    }
}
