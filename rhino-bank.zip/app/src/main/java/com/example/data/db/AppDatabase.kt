package com.example.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// --- Entities ---

@Entity(tableName = "clients")
data class ClientEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val sector: String,
    val country: String,
    val creditRating: String,
    val dueDiligenceChecked: Boolean,
    val notes: String
)

@Entity(tableName = "deals")
data class DealEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val valueMillion: Double,
    val sector: String,
    val feesMillion: Double,
    val stage: String, // Prospect, Proposal, Due Diligence, Legal Review, Completed
    val leadBanker: String,
    val notes: String
)

@Entity(tableName = "bonds")
data class BondEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val issuer: String,
    val couponPercent: Double,
    val maturityYears: Int,
    val currency: String,
    val totalValueMillion: Double,
    val bookbuiltPercent: Double,
    val rating: String,
    val status: String // Origination, Bookbuilding, Pricing, Closed
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val sector: String, // Transport, Energy, Healthcare, Telecom, Housing
    val totalValueMillion: Double,
    val fundingRequirementMillion: Double,
    val debtRatioPercent: Double,
    val currentMilestone: String,
    val projectedIrr: Double,
    val projectedNpv: Double,
    val revenueForecastMillion: Double,
    val location: String
)

@Entity(tableName = "compliance_logs")
data class ComplianceLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val action: String,
    val category: String, // AML, KYC, Sanctions, ConflictCheck
    val status: String, // Approved, Pending, Warning
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String
)

// --- DAOs ---

@Dao
interface ClientDao {
    @Query("SELECT * FROM clients ORDER BY name ASC")
    fun getAllClients(): Flow<List<ClientEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClient(client: ClientEntity)

    @Query("DELETE FROM clients WHERE id = :id")
    suspend fun deleteClientById(id: Int)
}

@Dao
interface DealDao {
    @Query("SELECT * FROM deals ORDER BY valueMillion DESC")
    fun getAllDeals(): Flow<List<DealEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeal(deal: DealEntity)

    @Query("DELETE FROM deals WHERE id = :id")
    suspend fun deleteDealById(id: Int)
}

@Dao
interface BondDao {
    @Query("SELECT * FROM bonds ORDER BY totalValueMillion DESC")
    fun getAllBonds(): Flow<List<BondEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBond(bond: BondEntity)

    @Query("DELETE FROM bonds WHERE id = :id")
    suspend fun deleteBondById(id: Int)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY totalValueMillion DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: Int)
}

@Dao
interface ComplianceLogDao {
    @Query("SELECT * FROM compliance_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<ComplianceLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ComplianceLogEntity)
}

// --- AppDatabase ---

@Database(
    entities = [
        ClientEntity::class,
        DealEntity::class,
        BondEntity::class,
        ProjectEntity::class,
        ComplianceLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun dealDao(): DealDao
    abstract fun bondDao(): BondDao
    abstract fun projectDao(): ProjectDao
    abstract fun complianceLogDao(): ComplianceLogDao
}
