package com.example.data.db

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull

class RhinoRepository(private val database: AppDatabase) {

    val allClients: Flow<List<ClientEntity>> = database.clientDao().getAllClients()
    val allDeals: Flow<List<DealEntity>> = database.dealDao().getAllDeals()
    val allBonds: Flow<List<BondEntity>> = database.bondDao().getAllBonds()
    val allProjects: Flow<List<ProjectEntity>> = database.projectDao().getAllProjects()
    val allLogs: Flow<List<ComplianceLogEntity>> = database.complianceLogDao().getAllLogs()

    suspend fun insertClient(client: ClientEntity) = database.clientDao().insertClient(client)
    suspend fun deleteClientById(id: Int) = database.clientDao().deleteClientById(id)

    suspend fun insertDeal(deal: DealEntity) = database.dealDao().insertDeal(deal)
    suspend fun deleteDealById(id: Int) = database.dealDao().deleteDealById(id)

    suspend fun insertBond(bond: BondEntity) = database.bondDao().insertBond(bond)
    suspend fun deleteBondById(id: Int) = database.bondDao().deleteBondById(id)

    suspend fun insertProject(project: ProjectEntity) = database.projectDao().insertProject(project)
    suspend fun deleteProjectById(id: Int) = database.projectDao().deleteProjectById(id)

    suspend fun insertLog(log: ComplianceLogEntity) = database.complianceLogDao().insertLog(log)

    suspend fun populateInitialDataIfEmpty() {
        // Run check and populate clients
        val clients = database.clientDao().getAllClients().first()
        if (clients.isEmpty()) {
            database.clientDao().insertClient(
                ClientEntity(
                    name = "United Kingdom HM Treasury",
                    sector = "Government",
                    country = "United Kingdom",
                    creditRating = "AAA",
                    dueDiligenceChecked = true,
                    notes = "Sovereign client. Core infrastructure partner. High priority."
                )
            )
            database.clientDao().insertClient(
                ClientEntity(
                    name = "London Infrastructure Fund",
                    sector = "Pension Fund",
                    country = "United Kingdom",
                    creditRating = "AA+",
                    dueDiligenceChecked = true,
                    notes = "Institutional asset manager with £45B under management. Interested in green energy."
                )
            )
            database.clientDao().insertClient(
                ClientEntity(
                    name = "Caledonian Green Energy",
                    sector = "Corporate (Utilities)",
                    country = "United Kingdom",
                    creditRating = "BBB+",
                    dueDiligenceChecked = true,
                    notes = "Developer of offshore wind fields and hydrogen transport lines in North Sea."
                )
            )
            database.clientDao().insertClient(
                ClientEntity(
                    name = "Sino-British Sovereign Fund",
                    sector = "Sovereign Wealth Fund",
                    country = "Singapore / UK",
                    creditRating = "AAA",
                    dueDiligenceChecked = true,
                    notes = "Joint venture fund aiming at logistics, ports and railways development."
                )
            )
            database.clientDao().insertClient(
                ClientEntity(
                    name = "West Midlands Developers Ltd",
                    sector = "Property Developer",
                    country = "United Kingdom",
                    creditRating = "A-",
                    dueDiligenceChecked = false,
                    notes = "SME developer seeking growth capital for mid-rise social housing complexes."
                )
            )
        }

        // Populate deals
        val deals = database.dealDao().getAllDeals().first()
        if (deals.isEmpty()) {
            database.dealDao().insertDeal(
                DealEntity(
                    name = "Thames Tideway Tunnel Advisory",
                    valueMillion = 4200.0,
                    sector = "Infrastructure (Water)",
                    feesMillion = 12.5,
                    stage = "Due Diligence",
                    leadBanker = "Lord Harrington",
                    notes = "Complex structuring advisory for super-sewer finance with sovereign backstop."
                )
            )
            database.dealDao().insertDeal(
                DealEntity(
                    name = "Hinkley Point C Debt Restructuring",
                    valueMillion = 18000.0,
                    sector = "Project Finance (Energy)",
                    feesMillion = 35.0,
                    stage = "Legal Review",
                    leadBanker = "Lady Spencer",
                    notes = "Advising on refinancing construction loans via public-private green bonds."
                )
            )
            database.dealDao().insertDeal(
                DealEntity(
                    name = "Heathrow Rail Link Expansion",
                    valueMillion = 1200.0,
                    sector = "Infrastructure (Transport)",
                    feesMillion = 8.5,
                    stage = "Proposal",
                    leadBanker = "Sir Michael Caine",
                    notes = "Bidding to lead a syndicated loan facility for regional rail link construction."
                )
            )
            database.dealDao().insertDeal(
                DealEntity(
                    name = "ScotWind Joint Venture Acquisition",
                    valueMillion = 3500.0,
                    sector = "Corporate M&A",
                    feesMillion = 15.0,
                    stage = "Completed",
                    leadBanker = "Arthur Pendleton",
                    notes = "Acquisition of offshore wind lease rights by regional energy major."
                )
            )
        }

        // Populate bonds
        val bonds = database.bondDao().getAllBonds().first()
        if (bonds.isEmpty()) {
            database.bondDao().insertBond(
                BondEntity(
                    issuer = "UK Government HM Treasury",
                    couponPercent = 4.25,
                    maturityYears = 30,
                    currency = "GBP",
                    totalValueMillion = 2500.0,
                    bookbuiltPercent = 100.0,
                    rating = "AAA",
                    status = "Closed"
                )
            )
            database.bondDao().insertBond(
                BondEntity(
                    issuer = "London Transit Authority (TfL)",
                    couponPercent = 5.10,
                    maturityYears = 15,
                    currency = "GBP",
                    totalValueMillion = 450.0,
                    bookbuiltPercent = 82.5,
                    rating = "AA",
                    status = "Bookbuilding"
                )
            )
            database.bondDao().insertBond(
                BondEntity(
                    issuer = "Caledonian Renewables Green Bond",
                    couponPercent = 6.25,
                    maturityYears = 10,
                    currency = "GBP",
                    totalValueMillion = 300.0,
                    bookbuiltPercent = 115.0,
                    rating = "BBB+",
                    status = "Pricing"
                )
            )
        }

        // Populate projects
        val projects = database.projectDao().getAllProjects().first()
        if (projects.isEmpty()) {
            database.projectDao().insertProject(
                ProjectEntity(
                    name = "East Coast Mainline Upgrade",
                    sector = "Transport (Rail)",
                    totalValueMillion = 3200.0,
                    fundingRequirementMillion = 2200.0,
                    debtRatioPercent = 70.0,
                    currentMilestone = "Track Laying",
                    projectedIrr = 8.5,
                    projectedNpv = 450.0,
                    revenueForecastMillion = 250.0,
                    location = "London-Edinburgh Corridor"
                )
            )
            database.projectDao().insertProject(
                ProjectEntity(
                    name = "Severn Estuary Tidal Energy",
                    sector = "Renewable Energy",
                    totalValueMillion = 5500.0,
                    fundingRequirementMillion = 4000.0,
                    debtRatioPercent = 80.0,
                    currentMilestone = "Feasibility Phase",
                    projectedIrr = 11.2,
                    projectedNpv = 820.0,
                    revenueForecastMillion = 380.0,
                    location = "Bristol Channel & Wales"
                )
            )
            database.projectDao().insertProject(
                ProjectEntity(
                    name = "Royal Albert Docks Housing",
                    sector = "Real Estate",
                    totalValueMillion = 1100.0,
                    fundingRequirementMillion = 750.0,
                    debtRatioPercent = 65.0,
                    currentMilestone = "Planning Permission",
                    projectedIrr = 14.5,
                    projectedNpv = 180.0,
                    revenueForecastMillion = 110.0,
                    location = "East London Regeneration"
                )
            )
        }

        // Populate logs
        val logs = database.complianceLogDao().getAllLogs().first()
        if (logs.isEmpty()) {
            database.complianceLogDao().insertLog(
                ComplianceLogEntity(
                    action = "KYC Institutional Verification",
                    category = "KYC",
                    status = "Approved",
                    notes = "KYC complete for UK HM Treasury. All authorized signatories verified."
                )
            )
            database.complianceLogDao().insertLog(
                ComplianceLogEntity(
                    action = "Sanctions List Screening",
                    category = "Sanctions",
                    status = "Warning",
                    notes = "Screened Sino-British Sovereign Fund. Warning triggered due to historical shareholder flag, cleared after manual review."
                )
            )
            database.complianceLogDao().insertLog(
                ComplianceLogEntity(
                    action = "Conflict Check",
                    category = "ConflictCheck",
                    status = "Approved",
                    notes = "Conflict check cleared for Caledonian Green Energy Wind Advisory mandate."
                )
            )
        }
    }
}
