package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.ProjectEntity
import com.example.ui.RhinoViewModel
import com.example.ui.theme.RhinoCoral
import com.example.ui.theme.RhinoEmerald
import com.example.ui.theme.RhinoGoldPrimary
import com.example.ui.theme.RhinoNavyLight
import com.example.ui.theme.RhinoNavyMedium
import com.example.ui.theme.RhinoTealPrimary

@Composable
fun ProjectScreen(
    viewModel: RhinoViewModel,
    modifier: Modifier = Modifier
) {
    val projects by viewModel.projects.collectAsState()
    val calcState by viewModel.calcState.collectAsState()

    var tabIndex by remember { mutableStateOf(0) }
    var showAddProjectDialog by remember { mutableStateOf(false) }

    // Add Project State
    var newProjName by remember { mutableStateOf("") }
    var newProjSector by remember { mutableStateOf("") }
    var newProjVal by remember { mutableStateOf("") }
    var newProjDebt by remember { mutableStateOf("70.0") }
    var newProjLocation by remember { mutableStateOf("") }
    var newProjIrr by remember { mutableStateOf("10.5") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        floatingActionButton = {
            if (tabIndex == 0) {
                FloatingActionButton(
                    onClick = { showAddProjectDialog = true },
                    containerColor = RhinoGoldPrimary,
                    contentColor = RhinoNavyMedium,
                    modifier = Modifier.testTag("add_project_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Register Asset")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Header ---
            Column {
                Text(
                    text = "Project Finance & Infrastructure Portfolios",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = RhinoGoldPrimary
                )
                Text(
                    text = "Valuations, financial modelling and debt structure ratios",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // --- Sub Tabs: Portfolio vs Financial Modeling Suite ---
            TabRow(
                selectedTabIndex = tabIndex,
                containerColor = RhinoNavyMedium,
                contentColor = RhinoGoldPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[tabIndex]),
                        color = RhinoGoldPrimary
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, RhinoNavyLight, RoundedCornerShape(8.dp))
            ) {
                Tab(
                    selected = tabIndex == 0,
                    onClick = { tabIndex = 0 },
                    text = { Text("Infrastructure Assets", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = tabIndex == 1,
                    onClick = { tabIndex = 1 },
                    text = { Text("Financial Modeling Suite", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
            }

            if (tabIndex == 0) {
                // Asset Portfolio
                if (projects.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("No projects registered.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(projects) { project ->
                            ProjectCard(
                                project = project,
                                onDelete = { viewModel.deleteProject(project.id) }
                            )
                        }
                    }
                }
            } else {
                // Interactive DCF Modeling Suite
                ModelingSuiteView(
                    calcState = calcState,
                    onInputsChanged = { investment, annualCF, years, discount ->
                        viewModel.updateCalculatorInputs(investment, annualCF, years, discount)
                    }
                )
            }
        }

        // --- Register Project Dialog ---
        if (showAddProjectDialog) {
            AlertDialog(
                onDismissRequest = { showAddProjectDialog = false },
                containerColor = RhinoNavyMedium,
                shape = RoundedCornerShape(16.dp),
                title = {
                    Text(
                        text = "Register Infrastructure Asset",
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = RhinoGoldPrimary
                    )
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = newProjName,
                            onValueChange = { newProjName = it },
                            label = { Text("Asset / Project Name") },
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().testTag("project_name_input")
                        )

                        OutlinedTextField(
                            value = newProjSector,
                            onValueChange = { newProjSector = it },
                            label = { Text("Sector (Transport, Energy, Housing)") },
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newProjVal,
                                onValueChange = { newProjVal = it },
                                label = { Text("Total Capital (£M)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1f).testTag("project_val_input")
                            )

                            OutlinedTextField(
                                value = newProjDebt,
                                onValueChange = { newProjDebt = it },
                                label = { Text("Debt Ratio (%)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newProjLocation,
                                onValueChange = { newProjLocation = it },
                                label = { Text("Geographic Location") },
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1.2f)
                            )

                            OutlinedTextField(
                                value = newProjIrr,
                                onValueChange = { newProjIrr = it },
                                label = { Text("Projected IRR (%)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(0.8f)
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val totVal = newProjVal.toDoubleOrNull() ?: 1000.0
                            val dRatio = newProjDebt.toDoubleOrNull() ?: 70.0
                            val irrVal = newProjIrr.toDoubleOrNull() ?: 10.5
                            viewModel.addProject(
                                name = newProjName,
                                sector = newProjSector,
                                totalValue = totVal,
                                debtRatio = dRatio,
                                location = newProjLocation,
                                irr = irrVal
                            )
                            showAddProjectDialog = false
                            // Reset state
                            newProjName = ""
                            newProjSector = ""
                            newProjVal = ""
                            newProjDebt = "70.0"
                            newProjLocation = ""
                            newProjIrr = "10.5"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoGoldPrimary, contentColor = RhinoNavyMedium),
                        enabled = newProjName.isNotBlank()
                    ) {
                        Text("Register Asset")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showAddProjectDialog = false },
                        colors = ButtonDefaults.textButtonColors(contentColor = RhinoGoldPrimary)
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun ProjectCard(
    project: ProjectEntity,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("project_card_${project.id}"),
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(RhinoNavyLight, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Landscape, contentDescription = "Project", tint = RhinoTealPrimary)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = project.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = RhinoGoldPrimary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PinDrop, contentDescription = "Location", tint = RhinoGoldPrimary, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${project.sector} • ${project.location}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RhinoCoral.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Ratios and outputs grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("TOTAL VALUE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("£${"%,.1f".format(project.totalValueMillion)}M", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                }

                Column {
                    Text("DEBT RATIO", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${"%.1f".format(project.debtRatioPercent)}%", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                }

                Column {
                    Text("PROJECTED IRR", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${"%.1f".format(project.projectedIrr)}%", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RhinoEmerald)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("NET PRESENT VALUE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("£${"%,.1f".format(project.projectedNpv)}M", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RhinoTealPrimary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = RhinoNavyLight)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STATUS: ${project.currentMilestone.uppercase()}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = RhinoTealPrimary
                )

                Text(
                    text = "Ann. Cash Flow: £${"%.1f".format(project.revenueForecastMillion)}M/yr",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ModelingSuiteView(
    calcState: com.example.ui.CalculatorState,
    onInputsChanged: (Double, Double, Int, Double) -> Unit
) {
    var invInput by remember { mutableStateOf(calcState.initialInvestment.toString()) }
    var cfInput by remember { mutableStateOf(calcState.annualCashflow.toString()) }
    var yearsInput by remember { mutableStateOf(calcState.years.toString()) }
    var discInput by remember { mutableStateOf(calcState.discountRate.toString()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Calculate, contentDescription = "Calculator", tint = RhinoGoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Discounted Cash Flow (DCF) Inputs", fontSize = 15.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = invInput,
                            onValueChange = {
                                invInput = it
                                it.toDoubleOrNull()?.let { v ->
                                    onInputsChanged(v, cfInput.toDoubleOrNull() ?: 0.0, yearsInput.toIntOrNull() ?: 1, discInput.toDoubleOrNull() ?: 0.0)
                                }
                            },
                            label = { Text("Initial Outlay (£M)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.weight(1f).testTag("calc_outlay_input")
                        )

                        OutlinedTextField(
                            value = cfInput,
                            onValueChange = {
                                cfInput = it
                                it.toDoubleOrNull()?.let { v ->
                                    onInputsChanged(invInput.toDoubleOrNull() ?: 0.0, v, yearsInput.toIntOrNull() ?: 1, discInput.toDoubleOrNull() ?: 0.0)
                                }
                            },
                            label = { Text("Ann. Inflow (£M)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.weight(1f).testTag("calc_inflow_input")
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = yearsInput,
                            onValueChange = {
                                yearsInput = it
                                it.toIntOrNull()?.let { v ->
                                    onInputsChanged(invInput.toDoubleOrNull() ?: 0.0, cfInput.toDoubleOrNull() ?: 0.0, v, discInput.toDoubleOrNull() ?: 0.0)
                                }
                            },
                            label = { Text("Project Life (Yrs)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = discInput,
                            onValueChange = {
                                discInput = it
                                it.toDoubleOrNull()?.let { v ->
                                    onInputsChanged(invInput.toDoubleOrNull() ?: 0.0, cfInput.toDoubleOrNull() ?: 0.0, yearsInput.toIntOrNull() ?: 1, v)
                                }
                            },
                            label = { Text("Discount Rate (%)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item {
            // Calculated Metrics Panel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("NET PRESENT VALUE (NPV)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "£${"%,.2f".format(calcState.npv)}M",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (calcState.npv >= 0) RhinoEmerald else RhinoCoral
                        )
                        Text(
                            text = if (calcState.npv >= 0) "Advisable Investment" else "Unprofitable Model",
                            fontSize = 11.sp,
                            color = if (calcState.npv >= 0) RhinoEmerald.copy(alpha = 0.8f) else RhinoCoral.copy(alpha = 0.8f)
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("INTERNAL RATE OF RETURN", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${"%.2f".format(calcState.irr)}%",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = RhinoTealPrimary
                        )
                        Text(
                            text = "Hurdle rate exceeded",
                            fontSize = 11.sp,
                            color = RhinoTealPrimary.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        item {
            // Interactive Sensitivity Canvas Chart!
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp),
                colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
                border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("CUMULATIVE NET CASH FLOW FORECAST", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                    Text("Visual projection of yield across project life cycle", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw baseline grid axes
                            drawLine(
                                color = RhinoNavyLight,
                                start = Offset(0f, h * 0.7f),
                                end = Offset(w, h * 0.7f),
                                strokeWidth = 1.dp.toPx()
                            )

                            // Generate Cash Flow Data Points
                            val initial = calcState.initialInvestment
                            val cf = calcState.annualCashflow
                            val yearsCount = calcState.years

                            if (yearsCount > 0) {
                                val cumulativeFlows = mutableListOf<Double>()
                                var runningSum = -initial
                                cumulativeFlows.add(runningSum)
                                for (i in 1..yearsCount) {
                                    runningSum += cf
                                    cumulativeFlows.add(runningSum)
                                }

                                val maxVal = Math.max(cumulativeFlows.maxOrNull() ?: 1.0, 1.0)
                                val minVal = Math.min(cumulativeFlows.minOrNull() ?: -1.0, -1.0)
                                val valRange = maxVal - minVal

                                val points = cumulativeFlows.mapIndexed { idx, value ->
                                    val x = (idx.toFloat() / yearsCount) * w
                                    val normY = (value - minVal) / valRange
                                    val y = h - (normY.toFloat() * h)
                                    Offset(x, y)
                                }

                                // Draw Path curve line
                                val path = Path()
                                path.moveTo(points.first().x, points.first().y)
                                for (i in 1 until points.size) {
                                    path.lineTo(points[i].x, points[i].y)
                                }

                                drawPath(
                                    path = path,
                                    color = RhinoTealPrimary,
                                    style = Stroke(width = 3.dp.toPx())
                                )

                                // Draw points
                                points.forEachIndexed { idx, point ->
                                    drawCircle(
                                        color = if (idx == 0) RhinoCoral else RhinoGoldPrimary,
                                        radius = 5.dp.toPx(),
                                        center = point
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Year 0 (Outlay)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Maturity (Year ${calcState.years})", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
