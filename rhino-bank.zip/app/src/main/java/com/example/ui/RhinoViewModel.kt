package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.api.Content
import com.example.data.api.GenerateContentRequest
import com.example.data.api.Part
import com.example.data.api.RetrofitClient
import com.example.data.db.AppDatabase
import com.example.data.db.BondEntity
import com.example.data.db.ClientEntity
import com.example.data.db.ComplianceLogEntity
import com.example.data.db.DealEntity
import com.example.data.db.ProjectEntity
import com.example.data.db.RhinoRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatMessage(
    val sender: String, // "user" or "copilot"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class CalculatorState(
    val initialInvestment: Double = 1000.0, // in million GBP
    val annualCashflow: Double = 150.0, // in million GBP
    val years: Int = 10,
    val discountRate: Double = 8.0, // in percent
    val npv: Double = 0.0,
    val irr: Double = 0.0,
    val isCalculated: Boolean = false
)

class RhinoViewModel(application: Application) : AndroidViewModel(application) {

    private val db: AppDatabase = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "rhino_bank_database"
    ).build()

    private val repository = RhinoRepository(db)

    // --- State Streams from Database ---
    val clients: StateFlow<List<ClientEntity>> = repository.allClients
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deals: StateFlow<List<DealEntity>> = repository.allDeals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bonds: StateFlow<List<BondEntity>> = repository.allBonds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val projects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<ComplianceLogEntity>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- local UI state ---
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                "copilot",
                "Welcome to Rhino Bank Co-Pilot. I am your specialized institutional financial analyst, risk officer, and regulatory strategist. How can I assist you with your mandates today?"
            )
        )
    )
    val chatHistory = _chatHistory.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading = _isAiLoading.asStateFlow()

    private val _calcState = MutableStateFlow(CalculatorState())
    val calcState = _calcState.asStateFlow()

    init {
        // Pre-populate data in a coroutine
        viewModelScope.launch(Dispatchers.IO) {
            repository.populateInitialDataIfEmpty()
        }
        calculateModel()
    }

    // --- Database CRUD Actions ---
    fun addClient(name: String, sector: String, country: String, creditRating: String, notes: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val client = ClientEntity(
                name = name,
                sector = sector,
                country = country,
                creditRating = creditRating,
                dueDiligenceChecked = true,
                notes = notes
            )
            repository.insertClient(client)
            repository.insertLog(
                ComplianceLogEntity(
                    action = "Institutional Client Added",
                    category = "KYC",
                    status = "Approved",
                    notes = "Added client: $name. System auto-registered regulatory onboarding checks."
                )
            )
        }
    }

    fun deleteClient(id: Int, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteClientById(id)
            repository.insertLog(
                ComplianceLogEntity(
                    action = "Institutional Client Offboarded",
                    category = "KYC",
                    status = "Warning",
                    notes = "Offboarded client: $name. Terminated system clearance status."
                )
            )
        }
    }

    fun addDeal(name: String, value: Double, sector: String, fees: Double, stage: String, lead: String, notes: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val deal = DealEntity(
                name = name,
                valueMillion = value,
                sector = sector,
                feesMillion = fees,
                stage = stage,
                leadBanker = lead,
                notes = notes
            )
            repository.insertDeal(deal)
            repository.insertLog(
                ComplianceLogEntity(
                    action = "Mandate Registered",
                    category = "ConflictCheck",
                    status = "Approved",
                    notes = "Registered deal: $name with value £${value}M. Conflict check cleared automatically."
                )
            )
        }
    }

    fun updateDealStage(deal: DealEntity, newStage: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = deal.copy(stage = newStage)
            repository.insertDeal(updated)
            repository.insertLog(
                ComplianceLogEntity(
                    action = "Mandate Progression",
                    category = "ConflictCheck",
                    status = "Approved",
                    notes = "Deal '${deal.name}' progressed to stage: $newStage. Routing compliance checks."
                )
            )
        }
    }

    fun deleteDeal(id: Int, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteDealById(id)
            repository.insertLog(
                ComplianceLogEntity(
                    action = "Mandate Revoked",
                    category = "ConflictCheck",
                    status = "Warning",
                    notes = "Revoked transaction mandate: $name."
                )
            )
        }
    }

    fun addBond(issuer: String, coupon: Double, maturity: Int, currency: String, totalValue: Double, rating: String, status: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val bond = BondEntity(
                issuer = issuer,
                couponPercent = coupon,
                maturityYears = maturity,
                currency = currency,
                totalValueMillion = totalValue,
                bookbuiltPercent = 0.0,
                rating = rating,
                status = status
            )
            repository.insertBond(bond)
            repository.insertLog(
                ComplianceLogEntity(
                    action = "DCM Bookbuild Initiated",
                    category = "Sanctions",
                    status = "Approved",
                    notes = "Initiated issuance for $issuer. Sized at $currency ${totalValue}M."
                )
            )
        }
    }

    fun updateBondBookbuilt(bond: BondEntity, additionalPercent: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val updatedPercent = (bond.bookbuiltPercent + additionalPercent).coerceIn(0.0, 150.0)
            val updated = bond.copy(
                bookbuiltPercent = updatedPercent,
                status = if (updatedPercent >= 100.0) "Pricing" else bond.status
            )
            repository.insertBond(updated)
        }
    }

    fun deleteBond(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteBondById(id)
        }
    }

    fun addProject(name: String, sector: String, totalValue: Double, debtRatio: Double, location: String, irr: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val reqFunding = totalValue * 0.8 // default 80% funding requirement
            // Calculate NPV based on default metrics
            val npvValue = totalValue * 0.15
            val project = ProjectEntity(
                name = name,
                sector = sector,
                totalValueMillion = totalValue,
                fundingRequirementMillion = reqFunding,
                debtRatioPercent = debtRatio,
                currentMilestone = "Initial Feasibility",
                projectedIrr = irr,
                projectedNpv = npvValue,
                revenueForecastMillion = totalValue * 0.08,
                location = location
            )
            repository.insertProject(project)
            repository.insertLog(
                ComplianceLogEntity(
                    action = "Project Finance Registered",
                    category = "ConflictCheck",
                    status = "Approved",
                    notes = "Registered infrastructure project: $name in $location."
                )
            )
        }
    }

    fun deleteProject(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteProjectById(id)
        }
    }

    // --- Financial Calculator Model (NPV & IRR) ---
    fun updateCalculatorInputs(investment: Double, annualCF: Double, years: Int, rate: Double) {
        _calcState.value = CalculatorState(
            initialInvestment = investment,
            annualCashflow = annualCF,
            years = years,
            discountRate = rate
        )
        calculateModel()
    }

    private fun calculateModel() {
        val state = _calcState.value
        val initial = state.initialInvestment
        val cf = state.annualCashflow
        val years = state.years
        val r = state.discountRate / 100.0

        // Calculate NPV = Sum [ CF / (1+r)^t ] - Initial
        var npvVal = -initial
        for (t in 1..years) {
            npvVal += cf / Math.pow(1.0 + r, t.toDouble())
        }

        // Calculate IRR using Bisection Method (numerical root-finding)
        var lowRate = -0.99
        var highRate = 2.0
        var irrVal = 0.0
        var attempts = 0

        while (attempts < 100) {
            val midRate = (lowRate + highRate) / 2.0
            var tempNpv = -initial
            for (t in 1..years) {
                tempNpv += cf / Math.pow(1.0 + midRate, t.toDouble())
            }

            if (Math.abs(tempNpv) < 1e-4) {
                irrVal = midRate * 100.0
                break
            }

            if (tempNpv > 0) {
                lowRate = midRate
            } else {
                highRate = midRate
            }
            attempts++
            irrVal = midRate * 100.0
        }

        _calcState.value = state.copy(
            npv = npvVal,
            irr = irrVal,
            isCalculated = true
        )
    }

    // --- Gemini Co-Pilot Chat System ---
    fun sendCopilotMessage(userText: String) {
        if (userText.trim().isEmpty()) return

        val userMsg = ChatMessage("user", userText)
        _chatHistory.value = _chatHistory.value + userMsg
        _isAiLoading.value = true

        viewModelScope.launch {
            try {
                // Compile context from local database to feed into system prompt as real data!
                val clientList = clients.value.joinToString { "${it.name} (${it.sector}, Rating: ${it.creditRating})" }
                val activeDeals = deals.value.joinToString { "${it.name} (Value: £${it.valueMillion}M, Fee: £${it.feesMillion}M, Stage: ${it.stage}, Lead: ${it.leadBanker})" }
                val liveBonds = bonds.value.joinToString { "Issuer: ${it.issuer}, Sized: £${it.totalValueMillion}M, Status: ${it.status}, Yield: ${it.couponPercent}%" }
                val activeProjects = projects.value.joinToString { "${it.name} in ${it.location} (NPV: £${it.projectedNpv}M, IRR: ${it.projectedIrr}%)" }

                val systemPrompt = """
                    You are an elite, highly specialized Institutional Investment Banking Analyst, Risk Officer, and Lead Structurer at Rhino Bank, London.
                    Rhino Bank is a premium British merchant bank specializing in large-scale infrastructure finance, corporate advisory, project finance, DCM, and ECM.
                    You represent the ultimate capital markets expert. Avoid simplistic answers. Provide highly professional, structured financial insights.
                    
                    Here is the current real-time portfolio, clients, and pipeline in the Rhino Bank database:
                    - INSTITUTIONAL CLIENTS: $clientList
                    - ACTIVE ADVISORY DEALS: $activeDeals
                    - DEBT CAPITAL MARKETS (Bonds): $liveBonds
                    - INFRASTRUCTURE PROJECTS: $activeProjects
                    
                    When asked, evaluate project risks, structural models, ESG factors, sovereign guarantees, debt sizing, or asset allocations. Speak with British spelling and professional dignity.
                """.trimIndent()

                // Call direct REST API
                val request = GenerateContentRequest(
                    contents = listOf(
                        Content(parts = listOf(Part(text = "User prompt: $userText")))
                    ),
                    systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
                )

                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.service.generateContent(
                        apiKey = com.example.BuildConfig.GEMINI_API_KEY,
                        request = request
                    )
                }

                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "Rhino Bank network response unresolved. Please verify credentials."

                _chatHistory.value = _chatHistory.value + ChatMessage("copilot", replyText)

            } catch (e: Exception) {
                _chatHistory.value = _chatHistory.value + ChatMessage(
                    "copilot",
                    "Advisory note: API call failed. Verify your GEMINI_API_KEY is configured in the AI Studio Secrets panel. (Error detail: ${e.localizedMessage})"
                )
            } finally {
                _isAiLoading.value = false
            }
        }
    }
}
