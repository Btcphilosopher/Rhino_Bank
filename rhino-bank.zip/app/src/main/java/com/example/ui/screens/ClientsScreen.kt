package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalActivity
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.ClientEntity
import com.example.data.db.ComplianceLogEntity
import com.example.ui.RhinoViewModel
import com.example.ui.theme.RhinoAmber
import com.example.ui.theme.RhinoCoral
import com.example.ui.theme.RhinoEmerald
import com.example.ui.theme.RhinoGoldPrimary
import com.example.ui.theme.RhinoNavyLight
import com.example.ui.theme.RhinoNavyMedium
import com.example.ui.theme.RhinoTealPrimary

@Composable
fun ClientsScreen(
    viewModel: RhinoViewModel,
    modifier: Modifier = Modifier
) {
    val clients by viewModel.clients.collectAsState()
    val logs by viewModel.logs.collectAsState()

    var showOnboardDialog by remember { mutableStateOf(false) }
    var tabIndex by remember { mutableStateOf(0) }

    // Onboard Form State
    var newClientName by remember { mutableStateOf("") }
    var newClientSector by remember { mutableStateOf("") }
    var newClientCountry by remember { mutableStateOf("") }
    var newClientRating by remember { mutableStateOf("AAA") }
    var newClientNotes by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        floatingActionButton = {
            if (tabIndex == 0) {
                FloatingActionButton(
                    onClick = { showOnboardDialog = true },
                    containerColor = RhinoGoldPrimary,
                    contentColor = RhinoNavyMedium,
                    modifier = Modifier.testTag("onboard_client_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Onboard Institution")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Screen Header ---
            Column {
                Text(
                    text = "Institutional Registry & CRM",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = RhinoGoldPrimary
                )
                Text(
                    text = "Sovereign wealth, governments, pension funds & corporates",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // --- Custom Dual Tabs: CRM Database vs AML Compliance Trails ---
            TabRow(
                selectedTabIndex = tabIndex,
                containerColor = RhinoNavyMedium,
                contentColor = RhinoGoldPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[tabIndex]),
                        color = RhinoGoldPrimary
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, RhinoNavyLight, RoundedCornerShape(8.dp))
            ) {
                Tab(
                    selected = tabIndex == 0,
                    onClick = { tabIndex = 0 },
                    text = { Text("Institutional CRM", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = tabIndex == 1,
                    onClick = { tabIndex = 1 },
                    text = { Text("Compliance AML/KYC Logs", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
            }

            // --- Content Views ---
            if (tabIndex == 0) {
                // Institutional Database List
                if (clients.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("No clients found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(clients) { client ->
                            ClientCard(
                                client = client,
                                onDelete = { viewModel.deleteClient(client.id, client.name) }
                            )
                        }
                    }
                }
            } else {
                // Regulatory Auditing Logs
                if (logs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("No audits recorded.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(logs) { log ->
                            ComplianceAuditCard(log = log)
                        }
                    }
                }
            }
        }

        // --- Onboarding Dialog Box ---
        if (showOnboardDialog) {
            AlertDialog(
                onDismissRequest = { showOnboardDialog = false },
                containerColor = RhinoNavyMedium,
                shape = RoundedCornerShape(16.dp),
                title = {
                    Text(
                        text = "Register Sovereign/Corporate Institution",
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = RhinoGoldPrimary
                    )
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = newClientName,
                            onValueChange = { newClientName = it },
                            label = { Text("Organization/Authority Name") },
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().testTag("client_name_input")
                        )

                        OutlinedTextField(
                            value = newClientSector,
                            onValueChange = { newClientSector = it },
                            label = { Text("Institution Sector (e.g. Sovereign Wealth)") },
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newClientCountry,
                                onValueChange = { newClientCountry = it },
                                label = { Text("Sovereign Country") },
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1.2f)
                            )

                            OutlinedTextField(
                                value = newClientRating,
                                onValueChange = { newClientRating = it },
                                label = { Text("Credit Rating") },
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(0.8f)
                            )
                        }

                        OutlinedTextField(
                            value = newClientNotes,
                            onValueChange = { newClientNotes = it },
                            label = { Text("Onboarding Notes & Directorship") },
                            maxLines = 3,
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.addClient(
                                name = newClientName,
                                sector = newClientSector,
                                country = newClientCountry,
                                creditRating = newClientRating,
                                notes = newClientNotes
                            )
                            showOnboardDialog = false
                            // Reset state
                            newClientName = ""
                            newClientSector = ""
                            newClientCountry = ""
                            newClientRating = "AAA"
                            newClientNotes = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoGoldPrimary, contentColor = RhinoNavyMedium),
                        enabled = newClientName.isNotBlank()
                    ) {
                        Text("Onboard & Verify")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showOnboardDialog = false },
                        colors = ButtonDefaults.textButtonColors(contentColor = RhinoGoldPrimary)
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun ClientCard(
    client: ClientEntity,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("client_card_${client.id}"),
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(RhinoNavyLight, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Domain, contentDescription = "Institution", tint = RhinoGoldPrimary)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = client.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = RhinoGoldPrimary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Public, contentDescription = "Country", tint = RhinoTealPrimary, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${client.sector} • ${client.country}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Credit rating pill
                Box(
                    modifier = Modifier
                        .background(RhinoGoldPrimary.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "RATING: ${client.creditRating}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = RhinoGoldPrimary
                    )
                }
            }

            if (client.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = client.notes,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = RhinoNavyLight)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Regulatory validation status indicator
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "Cleared",
                        tint = RhinoEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "AML KYC CLEARANCE: APPROVED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = RhinoEmerald
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Client",
                        tint = RhinoCoral.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ComplianceAuditCard(log: ComplianceLogEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        color = when (log.status) {
                            "Approved" -> RhinoEmerald.copy(alpha = 0.15f)
                            "Warning" -> RhinoAmber.copy(alpha = 0.15f)
                            else -> RhinoCoral.copy(alpha = 0.15f)
                        },
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (log.category) {
                        "KYC" -> Icons.Default.VerifiedUser
                        "Sanctions" -> Icons.Default.Flag
                        else -> Icons.Default.Info
                    },
                    contentDescription = log.category,
                    tint = when (log.status) {
                        "Approved" -> RhinoEmerald
                        "Warning" -> RhinoAmber
                        else -> RhinoCoral
                    },
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(log.action, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                    Text(
                        text = log.status.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (log.status) {
                            "Approved" -> RhinoEmerald
                            "Warning" -> RhinoAmber
                            else -> RhinoCoral
                        }
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(log.notes, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 16.sp)
            }
        }
    }
}
