package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val BentoColorScheme =
  lightColorScheme(
    primary = RhinoGoldPrimary,          // slate-900
    secondary = RhinoTealPrimary,        // sky-600
    tertiary = RhinoAmber,
    background = RhinoNavyDark,          // slate-50 (light background)
    surface = RhinoNavyMedium,           // white cards
    onPrimary = Color.White,             // white text on primary button
    onSecondary = Color.White,
    onBackground = TextPrimaryOnDark,    // slate-900 text
    onSurface = TextPrimaryOnDark,       // slate-900 text
    surfaceVariant = RhinoNavyLight,     // slate-100
    onSurfaceVariant = TextSecondaryOnDark,// slate-500
    outline = RhinoNavyLight             // slate-100
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false, // Use the fresh Bento Light layout by default as requested in guidelines
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  // We use our clean, Bento-inspired color scheme as the universal core theme
  MaterialTheme(colorScheme = BentoColorScheme, typography = Typography, content = content)
}
