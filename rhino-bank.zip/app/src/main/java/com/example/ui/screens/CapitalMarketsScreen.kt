package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.BondEntity
import com.example.ui.RhinoViewModel
import com.example.ui.theme.RhinoAmber
import com.example.ui.theme.RhinoCoral
import com.example.ui.theme.RhinoEmerald
import com.example.ui.theme.RhinoGoldPrimary
import com.example.ui.theme.RhinoNavyDark
import com.example.ui.theme.RhinoNavyLight
import com.example.ui.theme.RhinoNavyMedium
import com.example.ui.theme.RhinoTealPrimary

@Composable
fun CapitalMarketsScreen(
    viewModel: RhinoViewModel,
    modifier: Modifier = Modifier
) {
    val bonds by viewModel.bonds.collectAsState()

    var showIssueDialog by remember { mutableStateOf(false) }
    var tabIndex by remember { mutableStateOf(0) }

    // New Issue Form State
    var issuerName by remember { mutableStateOf("") }
    var bondCoupon by remember { mutableStateOf("") }
    var bondMaturity by remember { mutableStateOf("") }
    var bondVal by remember { mutableStateOf("") }
    var bondRating by remember { mutableStateOf("AA") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        floatingActionButton = {
            if (tabIndex == 0) {
                FloatingActionButton(
                    onClick = { showIssueDialog = true },
                    containerColor = RhinoGoldPrimary,
                    contentColor = RhinoNavyMedium,
                    modifier = Modifier.testTag("issue_bond_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Underwrite Issue")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Header ---
            Column {
                Text(
                    text = "Debt & Equity Capital Markets",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = RhinoGoldPrimary
                )
                Text(
                    text = "Syndicated underwriting and sovereign bookbuilding",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // --- Custom Tabs: DCM vs ECM ---
            TabRow(
                selectedTabIndex = tabIndex,
                containerColor = RhinoNavyMedium,
                contentColor = RhinoGoldPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[tabIndex]),
                        color = RhinoGoldPrimary
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, RhinoNavyLight, RoundedCornerShape(8.dp))
            ) {
                Tab(
                    selected = tabIndex == 0,
                    onClick = { tabIndex = 0 },
                    text = { Text("Debt Capital (DCM)", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = tabIndex == 1,
                    onClick = { tabIndex = 1 },
                    text = { Text("Equity Capital (ECM)", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
            }

            if (tabIndex == 0) {
                // Bond Issuances
                if (bonds.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("No underwritten bond issues.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(bonds) { bond ->
                            BondCard(
                                bond = bond,
                                onBidInflow = {
                                    viewModel.updateBondBookbuilt(bond, 15.0)
                                },
                                onDelete = {
                                    viewModel.deleteBond(bond.id)
                                }
                            )
                        }
                    }
                }
            } else {
                // ECM and Cap Tables Panel
                EquityMarketsPlaceholder()
            }
        }

        // --- Underwriting Bond Dialog ---
        if (showIssueDialog) {
            AlertDialog(
                onDismissRequest = { showIssueDialog = false },
                containerColor = RhinoNavyMedium,
                shape = RoundedCornerShape(16.dp),
                title = {
                    Text(
                        text = "Underwrite Sovereign/Corporate Bond",
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = RhinoGoldPrimary
                    )
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = issuerName,
                            onValueChange = { issuerName = it },
                            label = { Text("Sovereign / Corporate Issuer") },
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().testTag("bond_issuer_input")
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = bondCoupon,
                                onValueChange = { bondCoupon = it },
                                label = { Text("Coupon Rate (%)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1f).testTag("bond_coupon_input")
                            )

                            OutlinedTextField(
                                value = bondMaturity,
                                onValueChange = { bondMaturity = it },
                                label = { Text("Maturity (Yrs)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = bondVal,
                                onValueChange = { bondVal = it },
                                label = { Text("Size (Million GBP)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1.2f).testTag("bond_size_input")
                            )

                            OutlinedTextField(
                                value = bondRating,
                                onValueChange = { bondRating = it },
                                label = { Text("Credit Rating") },
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(0.8f)
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val coup = bondCoupon.toDoubleOrNull() ?: 5.0
                            val mat = bondMaturity.toIntOrNull() ?: 10
                            val sizeM = bondVal.toDoubleOrNull() ?: 500.0
                            viewModel.addBond(
                                issuer = issuerName,
                                coupon = coup,
                                maturity = mat,
                                currency = "GBP",
                                totalValue = sizeM,
                                rating = bondRating,
                                status = "Bookbuilding"
                            )
                            showIssueDialog = false
                            // Reset state
                            issuerName = ""
                            bondCoupon = ""
                            bondMaturity = ""
                            bondVal = ""
                            bondRating = "AA"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoGoldPrimary, contentColor = RhinoNavyMedium),
                        enabled = issuerName.isNotBlank()
                    ) {
                        Text("Underwrite Issue")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showIssueDialog = false },
                        colors = ButtonDefaults.textButtonColors(contentColor = RhinoGoldPrimary)
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun BondCard(
    bond: BondEntity,
    onBidInflow: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bond_card_${bond.id}"),
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(RhinoNavyLight, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.LocalOffer, contentDescription = "Bond", tint = RhinoGoldPrimary)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = bond.issuer,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = RhinoGoldPrimary
                        )
                        Text(
                            text = "Rating: ${bond.rating} • ${bond.currency} Sized Debt",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(
                            when (bond.status) {
                                "Closed" -> RhinoEmerald.copy(alpha = 0.15f)
                                "Pricing" -> RhinoAmber.copy(alpha = 0.15f)
                                else -> RhinoTealPrimary.copy(alpha = 0.15f)
                            },
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = bond.status.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (bond.status) {
                            "Closed" -> RhinoEmerald
                            "Pricing" -> RhinoAmber
                            else -> RhinoTealPrimary
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Debt Structure Matrix
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("COUPON RATE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${"%.2f".format(bond.couponPercent)}% YLD", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                }

                Column {
                    Text("MATURITY", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${bond.maturityYears} Years", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                }

                Column {
                    Text("TOTAL PAR VALUE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${bond.currency} ${"%,.1f".format(bond.totalValueMillion)}M", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RhinoTealPrimary)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("BOOKBUILT", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${"%.1f".format(bond.bookbuiltPercent)}%", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (bond.bookbuiltPercent >= 100) RhinoEmerald else RhinoTealPrimary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = RhinoNavyLight)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RhinoCoral.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
                }

                if (bond.bookbuiltPercent < 100.0) {
                    Button(
                        onClick = onBidInflow,
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoTealPrimary, contentColor = RhinoNavyDark),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("increment_bookbuild_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, contentDescription = "Bid", modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Inflow Investor Bid (+15.0%)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Subscribed", tint = RhinoEmerald, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("FULLY SUBSCRIBED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoEmerald)
                    }
                }
            }
        }
    }
}

@Composable
fun EquityMarketsPlaceholder() {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.ShowChart, contentDescription = "Equity", tint = RhinoGoldPrimary, modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text("Equity Capital Markets (ECM)", fontSize = 18.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Initial Public Offerings (IPOs), secondary placements and growth capital cap tables are managed through this portal. Integration channels route directly to regional stock markets.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}
