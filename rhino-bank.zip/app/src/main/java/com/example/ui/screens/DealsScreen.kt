package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoubleArrow
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.DealEntity
import com.example.ui.RhinoViewModel
import com.example.ui.theme.RhinoCoral
import com.example.ui.theme.RhinoEmerald
import com.example.ui.theme.RhinoGoldPrimary
import com.example.ui.theme.RhinoNavyDark
import com.example.ui.theme.RhinoNavyLight
import com.example.ui.theme.RhinoNavyMedium
import com.example.ui.theme.RhinoTealPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DealsScreen(
    viewModel: RhinoViewModel,
    modifier: Modifier = Modifier
) {
    val deals by viewModel.deals.collectAsState()
    var showOriginateDialog by remember { mutableStateOf(false) }

    // State for New Deal form
    var newDealName by remember { mutableStateOf("") }
    var newDealValue by remember { mutableStateOf("") }
    var newDealSector by remember { mutableStateOf("Infrastructure") }
    var newDealFee by remember { mutableStateOf("") }
    var newDealLead by remember { mutableStateOf("") }
    var newDealNotes by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showOriginateDialog = true },
                containerColor = RhinoGoldPrimary,
                contentColor = RhinoNavyMedium,
                modifier = Modifier.testTag("originate_deal_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Originate Mandate")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- 1. Pipeline Summary Funnel Progress Bar ---
            PipelineOverview(deals = deals)

            // --- Header & Stats ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Mandated Deal Pipeline",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = RhinoGoldPrimary
                    )
                    Text(
                        text = "Transaction flows & corporate finance advisory",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "${deals.size} Active Cases",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = RhinoGoldPrimary,
                    modifier = Modifier
                        .background(RhinoNavyLight, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            // --- 2. Scrollable Pipeline List ---
            if (deals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.BusinessCenter,
                            contentDescription = "No deals",
                            tint = RhinoNavyLight,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Active Mandates",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(deals) { deal ->
                        DealCard(
                            deal = deal,
                            onProgress = {
                                val nextStage = when (deal.stage) {
                                    "Prospect" -> "Proposal"
                                    "Proposal" -> "Due Diligence"
                                    "Due Diligence" -> "Legal Review"
                                    "Legal Review" -> "Completed"
                                    else -> "Completed"
                                }
                                viewModel.updateDealStage(deal, nextStage)
                            },
                            onDelete = {
                                viewModel.deleteDeal(deal.id, deal.name)
                            }
                        )
                    }
                }
            }
        }

        // --- Origination Dialog ---
        if (showOriginateDialog) {
            AlertDialog(
                onDismissRequest = { showOriginateDialog = false },
                containerColor = RhinoNavyMedium,
                shape = RoundedCornerShape(16.dp),
                title = {
                    Text(
                        text = "Originate Transaction Mandate",
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = RhinoGoldPrimary
                    )
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = newDealName,
                            onValueChange = { newDealName = it },
                            label = { Text("Client/Deal Name") },
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().testTag("deal_name_input")
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newDealValue,
                                onValueChange = { newDealValue = it },
                                label = { Text("Deal Value (£M)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1f).testTag("deal_value_input")
                            )

                            OutlinedTextField(
                                value = newDealFee,
                                onValueChange = { newDealFee = it },
                                label = { Text("Expected Fee (£M)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = outlineTextFieldColors(),
                                modifier = Modifier.weight(1f).testTag("deal_fee_input")
                            )
                        }

                        OutlinedTextField(
                            value = newDealLead,
                            onValueChange = { newDealLead = it },
                            label = { Text("Lead Investment Banker") },
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )

                        var expandedSector by remember { mutableStateOf(false) }
                        val sectors = listOf("Utilities", "Transport", "Renewable Energy", "Real Estate", "Corporate M&A")
                        ExposedDropdownMenuBox(
                            expanded = expandedSector,
                            onExpandedChange = { expandedSector = !expandedSector }
                        ) {
                            OutlinedTextField(
                                value = newDealSector,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Industry Sector") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedSector) },
                                colors = outlineTextFieldColors(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = expandedSector,
                                onDismissRequest = { expandedSector = false },
                                modifier = Modifier.background(RhinoNavyMedium)
                            ) {
                                sectors.forEach { sector ->
                                    DropdownMenuItem(
                                        text = { Text(sector, color = RhinoGoldPrimary) },
                                        onClick = {
                                            newDealSector = sector
                                            expandedSector = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = newDealNotes,
                            onValueChange = { newDealNotes = it },
                            label = { Text("Strategic Brief & Description") },
                            maxLines = 3,
                            colors = outlineTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val valM = newDealValue.toDoubleOrNull() ?: 100.0
                            val feeM = newDealFee.toDoubleOrNull() ?: 1.5
                            viewModel.addDeal(
                                name = newDealName,
                                value = valM,
                                sector = newDealSector,
                                fees = feeM,
                                stage = "Prospect",
                                lead = newDealLead,
                                notes = newDealNotes
                            )
                            showOriginateDialog = false
                            // Reset state
                            newDealName = ""
                            newDealValue = ""
                            newDealFee = ""
                            newDealLead = ""
                            newDealNotes = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoGoldPrimary, contentColor = RhinoNavyMedium),
                        enabled = newDealName.isNotBlank()
                    ) {
                        Text("Originate Mandate")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showOriginateDialog = false },
                        colors = ButtonDefaults.textButtonColors(contentColor = RhinoGoldPrimary)
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun PipelineOverview(deals: List<DealEntity>) {
    val stages = listOf("Prospect", "Proposal", "Due Diligence", "Legal Review", "Completed")

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "TRANSACTION PIPELINE OVERVIEW",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = RhinoGoldPrimary,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                stages.forEachIndexed { index, stage ->
                    val count = deals.count { it.stage == stage }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(
                                    if (count > 0) RhinoTealPrimary else RhinoNavyLight,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = count.toString(),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (count > 0) RhinoNavyDark else Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stage,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (count > 0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (index < stages.lastIndex) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Next",
                            tint = RhinoNavyLight,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DealCard(
    deal: DealEntity,
    onProgress: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("deal_card_${deal.id}"),
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = deal.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = RhinoGoldPrimary
                    )
                    Text(
                        text = "Sector: ${deal.sector}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Stage pill
                Box(
                    modifier = Modifier
                        .background(
                            when (deal.stage) {
                                "Completed" -> RhinoEmerald.copy(alpha = 0.15f)
                                "Due Diligence" -> RhinoTealPrimary.copy(alpha = 0.15f)
                                "Legal Review" -> RhinoGoldPrimary.copy(alpha = 0.15f)
                                else -> RhinoNavyLight
                            },
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = deal.stage.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (deal.stage) {
                            "Completed" -> RhinoEmerald
                            "Due Diligence" -> RhinoTealPrimary
                            "Legal Review" -> RhinoGoldPrimary
                            else -> RhinoGoldPrimary
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Value & Expected Fee breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("DEAL VALUE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("£${"%,.1f".format(deal.valueMillion)}M", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                }

                Column {
                    Text("EXPECTED FEE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("£${"%,.1f".format(deal.feesMillion)}M", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = RhinoTealPrimary)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, contentDescription = "Banker", tint = RhinoGoldPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(deal.leadBanker, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = RhinoGoldPrimary)
                    }
                    Text("Lead Architect", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            if (deal.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = deal.notes,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = RhinoNavyLight)
            Spacer(modifier = Modifier.height(8.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Deal", tint = RhinoCoral.copy(alpha = 0.8f))
                }

                if (deal.stage != "Completed") {
                    Button(
                        onClick = onProgress,
                        colors = ButtonDefaults.buttonColors(containerColor = RhinoTealPrimary, contentColor = RhinoNavyDark),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("upgrade_stage_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Progress Stage", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.DoubleArrow, contentDescription = "Progress", modifier = Modifier.size(12.dp))
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Settled", tint = RhinoEmerald, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mandate Settled", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RhinoEmerald)
                    }
                }
            }
        }
    }
}

@Composable
fun outlineTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = RhinoGoldPrimary,
    unfocusedTextColor = RhinoGoldPrimary,
    focusedBorderColor = RhinoGoldPrimary,
    unfocusedBorderColor = RhinoNavyLight,
    focusedLabelColor = RhinoGoldPrimary,
    unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
)
