package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Bento Grid Design Theme Color Palette ---
val RhinoNavyDark = Color(0xFFF8FAFC)       // slate-50 background (light theme core)
val RhinoNavyMedium = Color(0xFFFFFFFF)     // pure white cards / bento boxes
val RhinoNavyLight = Color(0xFFF1F5F9)      // slate-100 borders / dividers

val RhinoGoldPrimary = Color(0xFF0F172A)    // slate-900 (primary deep text / solid slate accents)
val RhinoGoldSecondary = Color(0xFF64748B)  // slate-500 (secondary clean text)
val RhinoGoldContainer = Color(0xFFE2E8F0)  // slate-200 background highlights

val RhinoTealPrimary = Color(0xFF0284C7)    // sky-600 active accent blue
val RhinoTealContainer = Color(0xFFE0F2FE)  // sky-100 light highlighting container

val RhinoAmber = Color(0xFFF59E0B)          // amber-500 (Warnings/Pending)
val RhinoEmerald = Color(0xFF10B981)        // emerald-500 (Growth/Success)
val RhinoCoral = Color(0xFFEF4444)          // red-500 (Alerts/High Risk)

// Text Colors (mapped for high-fidelity readability on Light/Bento backgrounds)
val TextPrimaryOnDark = Color(0xFF0F172A)   // slate-900
val TextSecondaryOnDark = Color(0xFF64748B) // slate-500
val TextTertiaryOnDark = Color(0xFF94A3B8)  // slate-400
