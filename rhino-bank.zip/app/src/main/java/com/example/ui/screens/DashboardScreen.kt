package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.db.ComplianceLogEntity
import com.example.ui.RhinoViewModel
import com.example.ui.theme.RhinoAmber
import com.example.ui.theme.RhinoCoral
import com.example.ui.theme.RhinoEmerald
import com.example.ui.theme.RhinoGoldPrimary
import com.example.ui.theme.RhinoNavyLight
import com.example.ui.theme.RhinoNavyMedium
import com.example.ui.theme.RhinoTealContainer
import com.example.ui.theme.RhinoTealPrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: RhinoViewModel,
    modifier: Modifier = Modifier
) {
    val deals by viewModel.deals.collectAsState()
    val bonds by viewModel.bonds.collectAsState()
    val projects by viewModel.projects.collectAsState()
    val logs by viewModel.logs.collectAsState()

    val totalPortfolioValue = projects.sumOf { it.totalValueMillion } + bonds.sumOf { it.totalValueMillion }
    val totalExpectedFees = deals.sumOf { it.feesMillion }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Custom Hero Banner (Canary Wharf at twilight) ---
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, RhinoNavyLight, RoundedCornerShape(16.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_canary_wharf_1784891395820),
                    contentDescription = "Canary Wharf Financial District",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Dark gold gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xE0030D1B)),
                                startY = 50f
                            )
                        )
                )
                // Content in Banner
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "RHINO BANK OPERATIONS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = RhinoGoldPrimary,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Merchant Banking & Infrastructure Finance",
                        fontSize = 20.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        // --- 2. Executive Capital Summary Panels ---
        item {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                maxItemsInEachRow = 3
            ) {
                // AUM Panel
                KPIWidget(
                    title = "Assets Under Advisement",
                    value = "£${"%,.1f".format(totalPortfolioValue / 1000.0)}B",
                    change = "+4.2% YoY",
                    icon = Icons.Default.MonetizationOn,
                    color = RhinoGoldPrimary,
                    modifier = Modifier.weight(1f).widthIn(min = 140.dp)
                )

                // Pipeline Revenue Panel
                KPIWidget(
                    title = "Expected Fee Income",
                    value = "£${"%,.1f".format(totalExpectedFees)}M",
                    change = "+12.8% Q3",
                    icon = Icons.Default.TrendingUp,
                    color = RhinoTealPrimary,
                    modifier = Modifier.weight(1f).widthIn(min = 140.dp)
                )

                // Active Mandates Panel
                KPIWidget(
                    title = "Active Mandates",
                    value = "${deals.size + bonds.size} Deals",
                    change = "100% On-Track",
                    icon = Icons.Default.BusinessCenter,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f).widthIn(min = 140.dp)
                )
            }
        }

        // --- 3. Portfolio Distribution & ESG Split ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1.2f)
                        .height(180.dp),
                    colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
                    shape = RoundedCornerShape(16.dp),
                    border = borderIndicator()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Sovereign & Regional Capital Sizing",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = RhinoGoldPrimary
                            )
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Sovereign exposure",
                                tint = RhinoTealPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Simulated high-fidelity horizontal bar chart
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            HorizontalChartBar(label = "Transport (Rail/Ports)", percentage = 0.55f, color = RhinoGoldPrimary)
                            HorizontalChartBar(label = "Clean Renewable Energy", percentage = 0.35f, color = RhinoTealPrimary)
                            HorizontalChartBar(label = "Social Housing / RE", percentage = 0.15f, color = Color(0xFF6366F1))
                        }
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(0.8f)
                        .height(180.dp),
                    colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
                    shape = RoundedCornerShape(16.dp),
                    border = borderIndicator()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Regulatory & ESG Check",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = RhinoGoldPrimary
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(RhinoTealContainer, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("AA", fontWeight = FontWeight.Bold, color = RhinoTealPrimary, fontSize = 18.sp)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("ESG Rating", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("High Compliance", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = RhinoEmerald)
                            }
                        }
                        Text(
                            text = "Zero thermal coal exposure. Zero sanction breaches in audit period.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // --- 4. Live Compliance and Audit Logs ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = "Logs",
                    tint = RhinoGoldPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Live Audit & Onboarding Logs",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = RhinoGoldPrimary
                )
            }
        }

        items(logs.take(3)) { log ->
            LogItem(log = log)
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun KPIWidget(
    title: String,
    value: String,
    change: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        shape = RoundedCornerShape(16.dp),
        border = borderIndicator()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = RhinoGoldPrimary
            )
            Box(
                modifier = Modifier
                    .background(color.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = change,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            }
        }
    }
}

@Composable
fun HorizontalChartBar(
    label: String,
    percentage: Float,
    color: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${(percentage * 100).toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .background(RhinoNavyLight, RoundedCornerShape(4.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(percentage)
                    .height(8.dp)
                    .background(color, RoundedCornerShape(4.dp))
            )
        }
    }
}

@Composable
fun LogItem(log: ComplianceLogEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RhinoNavyMedium),
        shape = RoundedCornerShape(12.dp),
        border = borderIndicator()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        color = when (log.status) {
                            "Approved" -> RhinoEmerald
                            "Warning" -> RhinoAmber
                            else -> RhinoCoral
                        },
                        shape = CircleShape
                    )
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(log.action, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = RhinoGoldPrimary)
                    Text(
                        text = when (log.category) {
                            "KYC" -> "AML/KYC"
                            "Sanctions" -> "Sanctions"
                            else -> "Conflict Check"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = RhinoGoldPrimary
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(log.notes, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 16.sp)
            }
        }
    }
}

fun borderIndicator() = androidx.compose.foundation.BorderStroke(1.dp, RhinoNavyLight)
