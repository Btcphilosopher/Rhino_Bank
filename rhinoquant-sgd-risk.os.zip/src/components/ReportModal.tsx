/**
 * @file src/components/ReportModal.tsx
 * RHINOQUANT SGD RISK.OS — Institutional Report Generator & Exporter
 */

import React, { useState } from 'react';
import { X, FileSpreadsheet, Download, Printer, CheckCircle2 } from 'lucide-react';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({ isOpen, onClose }) => {
  const [selectedReport, setSelectedReport] = useState<'DAILY' | 'TREASURY' | 'HEDGE' | 'VAR' | 'LIQUIDITY'>('DAILY');
  const [exportFormat, setExportFormat] = useState<'PDF' | 'CSV' | 'JSON'>('PDF');
  const [isExported, setIsExported] = useState(false);

  if (!isOpen) return null;

  const reports = [
    { id: 'DAILY', name: 'Daily SGD FX Risk & S$NEER Report', desc: 'Comprehensive portfolio FX exposure, S$NEER state, daily P&L attribution and top risks.' },
    { id: 'TREASURY', name: 'Corporate Treasury Exposure & Cash Flow Report', desc: 'Bucketed cash flows (0-30D, 31-90D, 3-6M, etc.), natural hedges and unhedged payables/receivables.' },
    { id: 'HEDGE', name: 'Hedge Accounting & Effectiveness Report', desc: 'Pre-vs-post hedge risk comparison, regression R², beta, cash flow certainty and residual delta.' },
    { id: 'VAR', name: 'Portfolio FX VaR & Stress Scenario Report', desc: '1D, 5D, 10D Parametric, Historical and Monte Carlo VaR, Expected Shortfall, and multi-variable stress tests.' },
    { id: 'LIQUIDITY', name: 'SGD Funding & Liquidity Ladder Report', desc: 'Settlement cash flows, forward swap maturities, and collateral requirements under FX shocks.' },
  ];

  const handleGenerate = () => {
    setIsExported(true);
    setTimeout(() => {
      setIsExported(false);
      alert(`Report exported successfully in ${exportFormat} format.`);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl overflow-hidden rounded-xl bg-slate-900 border border-slate-700 shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-500/30 text-emerald-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold tracking-tight text-white">Institutional Report Generator</h3>
              <p className="text-xs text-slate-400 font-mono">
                Audit-Grade PDF / CSV / JSON Export · RhinoQuant SGD Engine
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 text-sm">
          {/* Select Report Type */}
          <div>
            <label className="block text-xs uppercase font-semibold text-slate-400 mb-2 font-mono">Select Report Specification</label>
            <div className="space-y-2">
              {reports.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setSelectedReport(r.id as any)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    selectedReport === r.id
                      ? 'bg-emerald-950/50 border-emerald-500/50 text-white shadow-sm'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="font-semibold">{r.name}</div>
                  <div className="text-xs text-slate-400 mt-0.5">{r.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Format selection */}
          <div className="grid grid-cols-3 gap-3 font-mono text-xs">
            {(['PDF', 'CSV', 'JSON'] as const).map((fmt) => (
              <button
                key={fmt}
                onClick={() => setExportFormat(fmt)}
                className={`py-2 rounded-lg border text-center font-bold transition-all ${
                  exportFormat === fmt
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                EXPORT AS {fmt}
              </button>
            ))}
          </div>

          {/* Audit Metadata preview */}
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs font-mono text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>Report As-Of Timestamp:</span>
              <span className="text-slate-200">{new Date().toISOString()} SGT</span>
            </div>
            <div className="flex justify-between">
              <span>Model & Methodology Version:</span>
              <span className="text-slate-200">RQ-SGD-RISK-v3.4 (Standard MAS Benchmark)</span>
            </div>
            <div className="flex justify-between">
              <span>Market Data State:</span>
              <span className="text-emerald-400 font-bold">SYNTHETIC DETERMINISTIC ENGINE</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-900/90">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition-colors"
          >
            <Printer className="w-4 h-4" /> Print Preview
          </button>

          <button
            onClick={handleGenerate}
            disabled={isExported}
            className="flex items-center gap-2 px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold font-mono transition-all shadow-lg shadow-emerald-950"
          >
            {isExported ? (
              <>
                <CheckCircle2 className="w-4 h-4 animate-spin" /> Compiling Report...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" /> Download {exportFormat} Report
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
