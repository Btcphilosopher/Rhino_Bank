/**
 * @file src/components/CalculationModal.tsx
 * RHINOQUANT SGD RISK.OS — Calculation Explorer Audit Modal
 */

import React from 'react';
import { X, Cpu, CheckCircle2, Copy, FileText } from 'lucide-react';
import { CalculationTrace } from '../types';

interface CalculationModalProps {
  trace: CalculationTrace | null;
  onClose: () => void;
}

export const CalculationModal: React.FC<CalculationModalProps> = ({ trace, onClose }) => {
  if (!trace) return null;

  const handleCopyJSON = () => {
    navigator.clipboard.writeText(JSON.stringify(trace, null, 2));
    alert('Calculation audit JSON copied to clipboard.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-hidden rounded-xl bg-slate-900 border border-slate-700 shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-500/30 text-emerald-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-semibold tracking-tight text-white">{trace.label}</h3>
                <span className="px-2 py-0.5 text-[10px] font-mono uppercase font-medium bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
                  {trace.marketDataProvenance.dataState} DATA
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                ID: {trace.id} · Model: {trace.modelVersion}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm">
          {/* Main Output Box */}
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Calculated Output Result</span>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{trace.outputValue}</div>
              <div className="text-xs text-slate-400 mt-0.5">{trace.methodology}</div>
            </div>
            <div className="text-right text-xs text-slate-500 font-mono">
              <div>Timestamp: {new Date(trace.timestamp).toLocaleTimeString('en-SG')} SGT</div>
              <div>Provenance: {trace.marketDataProvenance.source}</div>
            </div>
          </div>

          {/* Model Inputs */}
          <div>
            <h4 className="text-xs uppercase font-semibold text-slate-400 tracking-wider mb-2 flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-400" /> Model Input Parameters
            </h4>
            <div className="grid grid-cols-2 gap-2 bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs">
              {Object.entries(trace.inputs).map(([key, value]) => (
                <div key={key} className="flex justify-between p-1.5 rounded bg-slate-900/60 border border-slate-800/80">
                  <span className="text-slate-400">{key}:</span>
                  <span className="font-semibold text-slate-200">{value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Intermediate Steps Tree */}
          <div>
            <h4 className="text-xs uppercase font-semibold text-slate-400 tracking-wider mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Intermediate Mathematical Trace Steps
            </h4>
            <div className="space-y-2">
              {trace.intermediateSteps.map((step, idx) => (
                <div key={idx} className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs space-y-1">
                  <div className="flex items-center justify-between text-slate-300 font-semibold">
                    <span>
                      Step {idx + 1}: {step.stepName}
                    </span>
                    <span className="text-emerald-400 font-bold">{step.result}</span>
                  </div>
                  <div className="text-slate-400 bg-slate-900/80 p-2 rounded text-[11px] border border-slate-800/60">
                    Formula: {step.formula}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-900/90 text-xs text-slate-400 font-mono">
          <span>Determinism Verified · Non-Repudiable Quant Trace</span>
          <button
            onClick={handleCopyJSON}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-sans font-medium transition-colors"
          >
            <Copy className="w-3.5 h-3.5" /> Copy Audit JSON
          </button>
        </div>
      </div>
    </div>
  );
};
