/**
 * @file src/components/tabs/PnLAttributionTab.tsx
 * RHINOQUANT SGD RISK.OS — Daily FX P&L Attribution & Waterfall Engine
 */

import React from 'react';
import { quantCore } from '../../engine/quantCore';
import { Activity, TrendingUp, TrendingDown } from 'lucide-react';

interface PnLAttributionTabProps {
  onOpenCalc: (id: string) => void;
}

export const PnLAttributionTab: React.FC<PnLAttributionTabProps> = ({ onOpenCalc }) => {
  const items = quantCore.getDailyPnLAttribution(134250000);
  const totalPnL = items.reduce((acc, i) => acc + i.amountSGD, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">DAILY FX P&L ATTRIBUTION WATERFALL</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              PERFORMANCE EXPLAINER
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Quantitative decomposition explaining why SGD FX P&L moved today across Spot, Forward Roll, Yield Carry, Option Vega, Curve Shift and Basis.
          </p>
        </div>

        <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-right font-mono">
          <div className="text-slate-400 text-xs uppercase font-bold">TOTAL DAILY P&L IMPACT</div>
          <div className={`text-xl font-bold ${totalPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalPnL >= 0
              ? `+SGD ${Math.round(totalPnL).toLocaleString('en-SG')}`
              : `-SGD ${Math.round(Math.abs(totalPnL)).toLocaleString('en-SG')}`}
          </div>
        </div>
      </div>

      {/* Main P&L Waterfall Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 font-mono text-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" /> P&L Factor Decomposition Breakdown
          </h3>
          <button
            onClick={() => onOpenCalc('CALC-FWD-USD/SGD-1')}
            className="text-xs text-emerald-400 font-bold hover:underline"
          >
            [CALC PROVENANCE]
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 text-right">P&L Impact (SGD)</th>
                <th className="py-2.5 px-3">Quantitative Explanation</th>
                <th className="py-2.5 px-3 text-right">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {items.map((item) => (
                <tr key={item.category} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-white">{item.category}</td>
                  <td
                    className={`py-2.5 px-3 text-right font-bold ${
                      item.amountSGD >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {item.amountSGD >= 0
                      ? `+SGD ${Math.round(item.amountSGD).toLocaleString('en-SG')}`
                      : `-SGD ${Math.round(Math.abs(item.amountSGD)).toLocaleString('en-SG')}`}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans text-xs">{item.explanation}</td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => onOpenCalc('CALC-FWD-USD/SGD-1')}
                      className="text-[10px] text-emerald-400 font-bold hover:underline"
                    >
                      [CALC]
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
