/**
 * @file src/components/tabs/HedgeLabTab.tsx
 * RHINOQUANT SGD RISK.OS — SGD Hedge Design & Comparative Structure Engine
 */

import React, { useState } from 'react';
import { HedgeStructure } from '../../types';
import { ShieldCheck, Sliders, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';
import { marketEngine } from '../../engine/marketEngine';

interface HedgeLabTabProps {
  onOpenCalc: (id: string) => void;
}

export const HedgeLabTab: React.FC<HedgeLabTabProps> = ({ onOpenCalc }) => {
  const [exposureForeignNotional, setExposureForeignNotional] = useState<number>(100000000); // USD 100m
  const [currency, setCurrency] = useState<'USD' | 'EUR' | 'CNY' | 'MYR'>('USD');
  const [tenor, setTenor] = useState<'1M' | '3M' | '6M' | '1Y'>('3M');

  const usdSgd = marketEngine.getQuote('USD/SGD')?.spotMid || 1.3425;
  const sgdNotional = exposureForeignNotional * usdSgd;

  // Mathematically defined alternative hedge structures
  const hedgeOptions: HedgeStructure[] = [
    {
      id: 'HDG-OPT-1',
      name: 'Structure A: 100% Deliverable Forward Lock',
      instrumentType: 'FORWARD',
      notionalForeign: exposureForeignNotional,
      notionalSGD: sgdNotional,
      strikeRate: usdSgd - 0.00362, // 1.33888
      tenor,
      hedgeRatioPct: 100.0,
      upfrontCostSGD: 0,
      cashflowCertaintyScore: 100,
      pnlSensitivity: 0,
      carryImpactSGD: +185000,
      residualDeltaSGD: 0,
      estimatedEffectivenessPct: 99.5,
    },
    {
      id: 'HDG-OPT-2',
      name: 'Structure B: 75% Forward + 25% Unhedged Floating',
      instrumentType: 'FORWARD',
      notionalForeign: exposureForeignNotional * 0.75,
      notionalSGD: sgdNotional * 0.75,
      strikeRate: usdSgd - 0.00362,
      tenor,
      hedgeRatioPct: 75.0,
      upfrontCostSGD: 0,
      cashflowCertaintyScore: 75,
      pnlSensitivity: sgdNotional * 0.25 * 0.01,
      carryImpactSGD: +138750,
      residualDeltaSGD: sgdNotional * 0.25,
      estimatedEffectivenessPct: 82.4,
    },
    {
      id: 'HDG-OPT-3',
      name: 'Structure C: 50% Forward + 50% Zero-Cost Option Collar',
      instrumentType: 'COLLAR',
      notionalForeign: exposureForeignNotional,
      notionalSGD: sgdNotional,
      strikeRate: usdSgd,
      tenor,
      hedgeRatioPct: 75.0,
      upfrontCostSGD: 0,
      cashflowCertaintyScore: 88,
      pnlSensitivity: sgdNotional * 0.15 * 0.01,
      carryImpactSGD: +92500,
      residualDeltaSGD: sgdNotional * 0.20,
      estimatedEffectivenessPct: 91.2,
    },
    {
      id: 'HDG-OPT-4',
      name: 'Structure D: Layered Rolling 3M/6M FX Swap Hedge',
      instrumentType: 'FX_SWAP',
      notionalForeign: exposureForeignNotional,
      notionalSGD: sgdNotional,
      strikeRate: usdSgd,
      tenor,
      hedgeRatioPct: 100.0,
      upfrontCostSGD: 0,
      cashflowCertaintyScore: 95,
      pnlSensitivity: 0,
      carryImpactSGD: +210000,
      residualDeltaSGD: 0,
      estimatedEffectivenessPct: 98.2,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">SGD HEDGE DESIGN & COMPARISON LAB</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              MATHEMATICAL HEDGE EVALUATOR
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Quantitatively analyze 100% Forward, Layered FX Swap, Zero-Cost Collar and Partial Hedge Structures against target corporate exposures.
          </p>
        </div>
      </div>

      {/* Target Exposure Input */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-3 font-mono text-xs">
        <h3 className="text-xs uppercase font-bold text-slate-400 tracking-wider">Configure Target Corporate Exposure</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-slate-400 mb-1">Currency</label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-bold"
            >
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
              <option value="CNY">CNY</option>
              <option value="MYR">MYR</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Foreign Exposure Amount</label>
            <input
              type="number"
              value={exposureForeignNotional}
              onChange={(e) => setExposureForeignNotional(parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-bold text-sm"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Tenor Horizon</label>
            <select
              value={tenor}
              onChange={(e) => setTenor(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
            >
              <option value="1M">1 Month</option>
              <option value="3M">3 Months</option>
              <option value="6M">6 Months</option>
              <option value="1Y">1 Year</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Base SGD Equivalent</label>
            <div className="p-2 bg-slate-950 border border-slate-800 rounded text-emerald-400 font-bold text-sm">
              SGD {Math.round(sgdNotional).toLocaleString('en-SG')}
            </div>
          </div>
        </div>
      </div>

      {/* Hedge Structures Comparison Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {hedgeOptions.map((opt) => (
          <div key={opt.id} className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 className="font-bold text-white text-sm">{opt.name}</h4>
              <span className="px-2 py-0.5 text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded font-bold">
                {opt.instrumentType}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-slate-300">
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">HEDGE RATIO</div>
                <div className="text-base font-bold text-emerald-400">{opt.hedgeRatioPct.toFixed(1)}%</div>
              </div>

              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">EST. EFFECTIVENESS R²</div>
                <div className="text-base font-bold text-white">{opt.estimatedEffectivenessPct.toFixed(1)}%</div>
              </div>

              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">CASH FLOW CERTAINTY</div>
                <div className="text-base font-bold text-amber-400">{opt.cashflowCertaintyScore} / 100</div>
              </div>

              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px]">EST. NET CARRY IMPACT</div>
                <div className="text-base font-bold text-emerald-400">
                  +SGD {Math.round(opt.carryImpactSGD).toLocaleString('en-SG')}
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between text-slate-400">
                <span>Residual Unhedged Delta:</span>
                <span className="font-bold text-white">SGD {Math.round(opt.residualDeltaSGD).toLocaleString('en-SG')}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Upfront Premium Cost:</span>
                <span className="font-bold text-emerald-400">SGD {opt.upfrontCostSGD}</span>
              </div>
            </div>

            <div className="text-right">
              <button
                onClick={() => onOpenCalc('CALC-FWD-USD/SGD-1')}
                className="text-[10px] text-emerald-400 font-bold hover:underline"
              >
                [CALC PROVENANCE]
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
