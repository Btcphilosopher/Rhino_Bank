/**
 * @file src/components/tabs/SNEERTab.tsx
 * RHINOQUANT SGD RISK.OS — S$NEER Policy Band Analytics Engine
 */

import React, { useState } from 'react';
import { Activity, ShieldAlert, Cpu, ArrowUpRight, Sliders } from 'lucide-react';
import { marketEngine } from '../../engine/marketEngine';

interface SNEERTabProps {
  onOpenCalc: (id: string) => void;
}

export const SNEERTab: React.FC<SNEERTabProps> = ({ onOpenCalc }) => {
  const sneer = marketEngine.getSNEERState();
  const [usdShockPct, setUsdShockPct] = useState(0);
  const [cnhShockPct, setCnhShockPct] = useState(0);

  // Calculate simulated S$NEER index under user basket shock
  const simIndex = sneer.indexValue + usdShockPct * 0.22 - cnhShockPct * 0.18;
  const simDistance = simIndex - sneer.estimatedCentre;

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">S$NEER ANALYTICS & POLICY BAND ENGINE</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-amber-950 text-amber-400 border border-amber-500/30 rounded">
              {sneer.uncertainty.split(' ')[0]} / MODELLED
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1 max-w-2xl">
            Singapore Nominal Effective Exchange Rate (S$NEER) monetary policy model. Monetary Authority of Singapore (MAS) exchange-rate centered regime.
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-right">
            <div className="text-slate-400">ESTIMATED S$NEER INDEX</div>
            <div className="text-xl font-bold text-emerald-400">{sneer.indexValue.toFixed(2)}</div>
          </div>
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-right">
            <div className="text-slate-400">DISTANCE FROM CENTRE</div>
            <div className="text-xl font-bold text-white">+{sneer.distanceFromCentrePct.toFixed(2)}%</div>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: S$NEER Policy Band Canvas Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" /> S$NEER 60-Day Trajectory & Policy Band
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Centre = 100.0 · Upper Band = 102.0 (+2.0%) · Lower Band = 98.0 (-2.0%)
              </p>
            </div>
            <button
              onClick={() => onOpenCalc('CALC-FWD-USD/SGD-1')}
              className="text-xs font-mono text-emerald-400 font-bold hover:underline"
            >
              [CALC PROVENANCE]
            </button>
          </div>

          {/* SVG Visual Policy Band Chart */}
          <div className="w-full h-64 bg-slate-950 rounded-lg border border-slate-800 p-4 relative flex flex-col justify-between font-mono text-[10px]">
            {/* Top / Bottom Labels */}
            <div className="flex justify-between text-slate-500 border-b border-slate-800/80 pb-1">
              <span>Upper Policy Band Limit (+2.0%): 102.00</span>
              <span className="text-rose-400">MAX DEPRECIATION RISK</span>
            </div>

            {/* SVG Path graphics */}
            <div className="relative flex-1 w-full my-2">
              <svg className="w-full h-full overflow-visible">
                {/* Upper Band Dash */}
                <line x1="0" y1="10%" x2="100%" y2="10%" stroke="#ef4444" strokeDasharray="4 4" strokeWidth="1" opacity="0.6" />
                {/* Centre Band Line */}
                <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#64748b" strokeDasharray="2 2" strokeWidth="1" opacity="0.6" />
                {/* Lower Band Dash */}
                <line x1="0" y1="90%" x2="100%" y2="90%" stroke="#10b981" strokeDasharray="4 4" strokeWidth="1" opacity="0.6" />

                {/* S$NEER Observed Polyline */}
                <polyline
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2.5"
                  points={sneer.historicalObservations
                    .map((obs, idx) => {
                      const x = (idx / (sneer.historicalObservations.length - 1)) * 100;
                      // map 98..102 to 90%..10%
                      const y = 90 - ((obs.observed - 98) / 4) * 80;
                      return `${x}%,${y}%`;
                    })
                    .join(' ')}
                />
              </svg>
            </div>

            <div className="flex justify-between text-slate-500 border-t border-slate-800/80 pt-1">
              <span>Lower Policy Band Limit (-2.0%): 98.00</span>
              <span className="text-emerald-400">MAX APPRECIATION ZONE</span>
            </div>
          </div>

          {/* Policy Parameters Box */}
          <div className="grid grid-cols-3 gap-3 font-mono text-xs">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400">POLICY SLOPE (CRAWL)</div>
              <div className="text-sm font-bold text-white mt-1">+{sneer.slopePctPA.toFixed(1)}% p.a.</div>
              <div className="text-[10px] text-slate-500">Gradual Appreciation</div>
            </div>
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400">BAND WIDTH</div>
              <div className="text-sm font-bold text-white mt-1">±{sneer.bandWidthPct.toFixed(1)}%</div>
              <div className="text-[10px] text-slate-500">Center Buffer</div>
            </div>
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400">30D ROLLING VOLATILITY</div>
              <div className="text-sm font-bold text-emerald-400 mt-1">{sneer.rollingVol30D.toFixed(2)}%</div>
              <div className="text-[10px] text-slate-500">Annualized Vol</div>
            </div>
          </div>
        </div>

        {/* Right Col: Basket Decomposition & Shock Simulator */}
        <div className="space-y-6">
          {/* Basket Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2 font-mono">
              <Cpu className="w-4 h-4 text-emerald-400" /> S$NEER Trade-Weighted Basket
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-left text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                  <tr>
                    <th className="py-2 px-2">Currency</th>
                    <th className="py-2 px-2 text-right">Weight</th>
                    <th className="py-2 px-2 text-right">Contrib %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {sneer.basket.map((b) => (
                    <tr key={b.currency}>
                      <td className="py-1.5 px-2 font-bold text-white">{b.currency}</td>
                      <td className="py-1.5 px-2 text-right text-emerald-400">{b.weightPct.toFixed(1)}%</td>
                      <td className="py-1.5 px-2 text-right text-slate-300">{b.contributionPct.toFixed(1)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Interactive Basket Shock Simulator */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2 font-mono">
              <Sliders className="w-4 h-4 text-emerald-400" /> Hypothetical Basket Shock Simulator
            </h3>
            <div className="space-y-3 font-mono text-xs">
              <div>
                <label className="flex justify-between text-slate-400 mb-1">
                  <span>USD Strength / Shock:</span>
                  <span className="text-emerald-400 font-bold">{usdShockPct > 0 ? `+${usdShockPct}%` : `${usdShockPct}%`}</span>
                </label>
                <input
                  type="range"
                  min="-5"
                  max="5"
                  step="0.5"
                  value={usdShockPct}
                  onChange={(e) => setUsdShockPct(parseFloat(e.target.value))}
                  className="w-full accent-emerald-500 bg-slate-950"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-400 mb-1">
                  <span>CNH Devaluation / Shock:</span>
                  <span className="text-rose-400 font-bold">{cnhShockPct > 0 ? `+${cnhShockPct}%` : `${cnhShockPct}%`}</span>
                </label>
                <input
                  type="range"
                  min="-5"
                  max="5"
                  step="0.5"
                  value={cnhShockPct}
                  onChange={(e) => setCnhShockPct(parseFloat(e.target.value))}
                  className="w-full accent-rose-500 bg-slate-950"
                />
              </div>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1 mt-2">
                <div className="flex justify-between text-slate-300 font-semibold">
                  <span>Simulated S$NEER Index:</span>
                  <span className="text-emerald-400 font-bold">{simIndex.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Dist. from Policy Centre:</span>
                  <span className={simDistance >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                    {simDistance >= 0 ? `+${simDistance.toFixed(2)}%` : `${simDistance.toFixed(2)}%`}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
