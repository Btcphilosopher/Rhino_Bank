/**
 * @file src/components/tabs/ExposureMatrixTab.tsx
 * RHINOQUANT SGD RISK.OS — SGD Currency Exposure Matrix (14 Currencies x Risk Dimensions)
 */

import React from 'react';
import { Currency, CurrencyRiskRow } from '../../types';
import { Table, ShieldCheck, AlertTriangle } from 'lucide-react';

interface ExposureMatrixTabProps {
  onOpenCalc: (id: string) => void;
  onOpenRiskTree: () => void;
}

export const ExposureMatrixTab: React.FC<ExposureMatrixTabProps> = ({ onOpenCalc, onOpenRiskTree }) => {
  // Signature RhinoQuant 14-Currency Risk Matrix Data
  const currencyRows: CurrencyRiskRow[] = [
    { currency: 'USD', grossExposureSGD: 214800000, longExposureSGD: 134250000, shortExposureSGD: 80550000, hedgedAmountSGD: 114112500, netExposureSGD: 20137500, hedgeRatioPct: 85.0, deltaSGD: 20137500, vegaSGD: 90618, var1D99SGD: 320500, es1D99SGD: 378200, todayPnLSGD: -43000, averageMaturityDays: 62 },
    { currency: 'CNY', grossExposureSGD: 7535795, longExposureSGD: 0, shortExposureSGD: 7535795, hedgedAmountSGD: 0, netExposureSGD: -7535795, hedgeRatioPct: 0.0, deltaSGD: -7535795, vegaSGD: 22607, var1D99SGD: 112000, es1D99SGD: 132000, todayPnLSGD: -15000, averageMaturityDays: 45 },
    { currency: 'CNH', grossExposureSGD: 15936000, longExposureSGD: 0, shortExposureSGD: 15936000, hedgedAmountSGD: 12000000, netExposureSGD: -3936000, hedgeRatioPct: 75.3, deltaSGD: -3936000, vegaSGD: 11808, var1D99SGD: 58000, es1D99SGD: 68000, todayPnLSGD: -8000, averageMaturityDays: 80 },
    { currency: 'MYR', grossExposureSGD: 7541478, longExposureSGD: 0, shortExposureSGD: 7541478, hedgedAmountSGD: 1500000, netExposureSGD: -6041478, hedgeRatioPct: 19.9, deltaSGD: -6041478, vegaSGD: 18124, var1D99SGD: 90000, es1D99SGD: 106000, todayPnLSGD: -9000, averageMaturityDays: 115 },
    { currency: 'JPY', grossExposureSGD: 17571604, longExposureSGD: 0, shortExposureSGD: 17571604, hedgedAmountSGD: 0, netExposureSGD: -17571604, hedgeRatioPct: 0.0, deltaSGD: -17571604, vegaSGD: 52714, var1D99SGD: 260000, es1D99SGD: 306000, todayPnLSGD: +79000, averageMaturityDays: 640 },
    { currency: 'EUR', grossExposureSGD: 43956043, longExposureSGD: 0, shortExposureSGD: 43956043, hedgedAmountSGD: 21978021, netExposureSGD: -21978022, hedgeRatioPct: 50.0, deltaSGD: -21978022, vegaSGD: 65934, var1D99SGD: 310000, es1D99SGD: 365000, todayPnLSGD: +35000, averageMaturityDays: 185 },
    { currency: 'GBP', grossExposureSGD: 5200000, longExposureSGD: 5200000, shortExposureSGD: 0, hedgedAmountSGD: 4000000, netExposureSGD: 1200000, hedgeRatioPct: 76.9, deltaSGD: 1200000, vegaSGD: 3600, var1D99SGD: 18000, es1D99SGD: 21000, todayPnLSGD: +2500, averageMaturityDays: 90 },
    { currency: 'AUD', grossExposureSGD: 8400000, longExposureSGD: 8400000, shortExposureSGD: 0, hedgedAmountSGD: 6000000, netExposureSGD: 2400000, hedgeRatioPct: 71.4, deltaSGD: 2400000, vegaSGD: 7200, var1D99SGD: 36000, es1D99SGD: 42000, todayPnLSGD: -7600, averageMaturityDays: 120 },
    { currency: 'IDR', grossExposureSGD: 4200000, longExposureSGD: 0, shortExposureSGD: 4200000, hedgedAmountSGD: 0, netExposureSGD: -4200000, hedgeRatioPct: 0.0, deltaSGD: -4200000, vegaSGD: 12600, var1D99SGD: 63000, es1D99SGD: 74000, todayPnLSGD: +7500, averageMaturityDays: 75 },
    { currency: 'THB', grossExposureSGD: 3100000, longExposureSGD: 3100000, shortExposureSGD: 0, hedgedAmountSGD: 2000000, netExposureSGD: 1100000, hedgeRatioPct: 64.5, deltaSGD: 1100000, vegaSGD: 3300, var1D99SGD: 16500, es1D99SGD: 19400, todayPnLSGD: +3100, averageMaturityDays: 60 },
    { currency: 'KRW', grossExposureSGD: 6500000, longExposureSGD: 0, shortExposureSGD: 6500000, hedgedAmountSGD: 3000000, netExposureSGD: -3500000, hedgeRatioPct: 46.2, deltaSGD: -3500000, vegaSGD: 10500, var1D99SGD: 52500, es1D99SGD: 61800, todayPnLSGD: -16000, averageMaturityDays: 105 },
    { currency: 'TWD', grossExposureSGD: 4800000, longExposureSGD: 4800000, shortExposureSGD: 0, hedgedAmountSGD: 3500000, netExposureSGD: 1300000, hedgeRatioPct: 72.9, deltaSGD: 1300000, vegaSGD: 3900, var1D99SGD: 19500, es1D99SGD: 22900, todayPnLSGD: +1000, averageMaturityDays: 50 },
    { currency: 'INR', grossExposureSGD: 2900000, longExposureSGD: 0, shortExposureSGD: 2900000, hedgedAmountSGD: 0, netExposureSGD: -2900000, hedgeRatioPct: 0.0, deltaSGD: -2900000, vegaSGD: 8700, var1D99SGD: 43500, es1D99SGD: 51100, todayPnLSGD: -2900, averageMaturityDays: 95 },
    { currency: 'HKD', grossExposureSGD: 9100000, longExposureSGD: 9100000, shortExposureSGD: 0, hedgedAmountSGD: 8000000, netExposureSGD: 1100000, hedgeRatioPct: 87.9, deltaSGD: 1100000, vegaSGD: 3300, var1D99SGD: 16500, es1D99SGD: 19400, todayPnLSGD: -1500, averageMaturityDays: 40 },
  ];

  return (
    <div className="space-y-6">
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">SGD CURRENCY EXPOSURE MATRIX</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              14 CURRENCY RISK PANELS
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Institutional consolidated currency risk table across asset, liability, cash flow, forward hedge and option vega vectors.
          </p>
        </div>

        <button
          onClick={onOpenRiskTree}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold transition-all"
        >
          EXPLORE RISK DECOMPOSITION TREE →
        </button>
      </div>

      {/* Main Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 overflow-x-auto">
        <table className="w-full text-xs font-mono text-left text-slate-300">
          <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
            <tr>
              <th className="py-3 px-3">Ccy</th>
              <th className="py-3 px-3 text-right">Gross (SGD)</th>
              <th className="py-3 px-3 text-right">Long (SGD)</th>
              <th className="py-3 px-3 text-right">Short (SGD)</th>
              <th className="py-3 px-3 text-right">Hedged (SGD)</th>
              <th className="py-3 px-3 text-right">Net Delta (SGD)</th>
              <th className="py-3 px-3 text-center">Hedge %</th>
              <th className="py-3 px-3 text-right">Vega (SGD)</th>
              <th className="py-3 px-3 text-right">1D 99% VaR</th>
              <th className="py-3 px-3 text-right">Today P&L</th>
              <th className="py-3 px-3 text-center">Audit</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {currencyRows.map((r) => (
              <tr key={r.currency} className="hover:bg-slate-800/40 transition-colors">
                <td className="py-2.5 px-3 font-bold text-white flex items-center gap-2">
                  <span>{r.currency}</span>
                </td>
                <td className="py-2.5 px-3 text-right text-slate-300">
                  SGD {Math.round(r.grossExposureSGD / 1000).toLocaleString('en-SG')}k
                </td>
                <td className="py-2.5 px-3 text-right text-slate-300">
                  {r.longExposureSGD > 0 ? `SGD ${Math.round(r.longExposureSGD / 1000).toLocaleString('en-SG')}k` : '—'}
                </td>
                <td className="py-2.5 px-3 text-right text-slate-300">
                  {r.shortExposureSGD > 0 ? `SGD ${Math.round(r.shortExposureSGD / 1000).toLocaleString('en-SG')}k` : '—'}
                </td>
                <td className="py-2.5 px-3 text-right text-emerald-400">
                  {r.hedgedAmountSGD > 0 ? `SGD ${Math.round(r.hedgedAmountSGD / 1000).toLocaleString('en-SG')}k` : '0'}
                </td>
                <td
                  className={`py-2.5 px-3 text-right font-bold ${
                    r.netExposureSGD >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  SGD {Math.round(r.netExposureSGD / 1000).toLocaleString('en-SG')}k
                </td>
                <td className="py-2.5 px-3 text-center font-semibold">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] ${
                      r.hedgeRatioPct >= 75
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                        : r.hedgeRatioPct > 0
                        ? 'bg-amber-950 text-amber-400 border border-amber-500/30'
                        : 'bg-rose-950 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    {r.hedgeRatioPct.toFixed(1)}%
                  </span>
                </td>
                <td className="py-2.5 px-3 text-right text-slate-400">
                  SGD {Math.round(r.vegaSGD).toLocaleString('en-SG')}
                </td>
                <td className="py-2.5 px-3 text-right text-amber-400 font-semibold">
                  SGD {Math.round(r.var1D99SGD / 1000).toLocaleString('en-SG')}k
                </td>
                <td
                  className={`py-2.5 px-3 text-right font-semibold ${
                    r.todayPnLSGD >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {r.todayPnLSGD >= 0
                    ? `+SGD ${Math.round(r.todayPnLSGD / 1000).toLocaleString('en-SG')}k`
                    : `-SGD ${Math.round(Math.abs(r.todayPnLSGD) / 1000).toLocaleString('en-SG')}k`}
                </td>
                <td className="py-2.5 px-3 text-center">
                  <button
                    onClick={() => onOpenCalc(`CALC-VAR-1`)}
                    className="text-[10px] text-emerald-400 font-bold hover:underline"
                  >
                    [CALC]
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
