/**
 * @file src/components/tabs/CorporateTreasuryTab.tsx
 * RHINOQUANT SGD RISK.OS — Corporate SGD Cash Flow & Exposure Workspace
 */

import React, { useState } from 'react';
import { CorporateExposure, Currency, ExposureBucket, ExposureDirection, ExposureType } from '../../types';
import { Plus, Briefcase, DollarSign, Calendar, Sliders } from 'lucide-react';
import { marketEngine } from '../../engine/marketEngine';

interface CorporateTreasuryTabProps {
  exposures: CorporateExposure[];
  onAddExposure: (exp: CorporateExposure) => void;
  onOpenCalc: (id: string) => void;
}

export const CorporateTreasuryTab: React.FC<CorporateTreasuryTabProps> = ({
  exposures,
  onAddExposure,
  onOpenCalc,
}) => {
  const [selectedBucket, setSelectedBucket] = useState<string>('ALL');

  // Form states for adding new exposure
  const [entityName, setEntityName] = useState('SingaCorp Logistics Pte Ltd');
  const [businessUnit, setBusinessUnit] = useState('Regional Sourcing');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [amount, setAmount] = useState<number>(25000000);
  const [direction, setDirection] = useState<ExposureDirection>('PAYABLE');
  const [exposureType, setExposureType] = useState<ExposureType>('TRANSACTION');
  const [bucket, setBucket] = useState<ExposureBucket>('31-90D');
  const [maturityDate, setMaturityDate] = useState('2026-11-30');
  const [description, setDescription] = useState('Subsea fiber optic cable procurement contract');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const sgdEquiv = marketEngine.convertToSGD(amount, currency);
    const newExp: CorporateExposure = {
      id: `EXP-${Date.now()}`,
      entityName,
      businessUnit,
      currency,
      foreignAmount: amount,
      sgdEquivalent: sgdEquiv,
      exposureType,
      direction,
      bucket,
      maturityDate,
      naturalHedgeAmount: 0,
      hedgedAmount: 0,
      unhedgedAmount: amount,
      hedgeRatioPct: 0.0,
      fxSensitivitySGD: sgdEquiv * 0.01,
      description,
    };

    onAddExposure(newExp);
    alert('Corporate exposure successfully recorded into SGD Risk Engine.');
  };

  const filteredExposures =
    selectedBucket === 'ALL' ? exposures : exposures.filter((e) => e.bucket === selectedBucket);

  const buckets: ExposureBucket[] = ['0-30D', '31-90D', '3-6M', '6-12M', '1-2Y', '2-5Y', '5Y+'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">CORPORATE SGD CURRENCY EXPOSURE ENGINE</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              TREASURY CASH FLOWS
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Transaction, Translation, Economic and Balance Sheet FX Exposure Management with Maturity Bucketing.
          </p>
        </div>
      </div>

      {/* Main Grid: Create Form + Exposure Buckets List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Form to Record Exposure */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2 font-mono">
            <Plus className="w-4 h-4 text-emerald-400" /> Record Corporate Exposure
          </h3>

          <form onSubmit={handleCreate} className="space-y-3 text-xs font-mono">
            <div>
              <label className="block text-slate-400 mb-1">Legal Entity Name</label>
              <input
                type="text"
                value={entityName}
                onChange={(e) => setEntityName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 mb-1">Business Unit</label>
                <input
                  type="text"
                  value={businessUnit}
                  onChange={(e) => setBusinessUnit(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as Currency)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                >
                  <option value="USD">USD</option>
                  <option value="CNY">CNY</option>
                  <option value="CNH">CNH</option>
                  <option value="MYR">MYR</option>
                  <option value="EUR">EUR</option>
                  <option value="JPY">JPY</option>
                  <option value="GBP">GBP</option>
                  <option value="AUD">AUD</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 mb-1">Foreign Notional Amount</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-bold"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Direction</label>
                <select
                  value={direction}
                  onChange={(e) => setDirection(e.target.value as ExposureDirection)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                >
                  <option value="PAYABLE">PAYABLE</option>
                  <option value="RECEIVABLE">RECEIVABLE</option>
                  <option value="OPEX">OPEX</option>
                  <option value="REVENUE">REVENUE</option>
                  <option value="DEBT">DEBT</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 mb-1">Maturity Bucket</label>
                <select
                  value={bucket}
                  onChange={(e) => setBucket(e.target.value as ExposureBucket)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                >
                  {buckets.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Maturity Date</label>
                <input
                  type="date"
                  value={maturityDate}
                  onChange={(e) => setMaturityDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Description</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded transition-colors"
            >
              RECORD EXPOSURE TO SGD ENGINE
            </button>
          </form>
        </div>

        {/* Right Column: Bucket Filter & Exposures List */}
        <div className="lg:col-span-2 space-y-4">
          {/* Bucket Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-lg border border-slate-800 overflow-x-auto font-mono text-xs">
            <button
              onClick={() => setSelectedBucket('ALL')}
              className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
                selectedBucket === 'ALL' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              ALL BUCKETS ({exposures.length})
            </button>
            {buckets.map((b) => {
              const count = exposures.filter((e) => e.bucket === b).length;
              return (
                <button
                  key={b}
                  onClick={() => setSelectedBucket(b)}
                  className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
                    selectedBucket === b ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {b} ({count})
                </button>
              );
            })}
          </div>

          {/* Exposures Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 overflow-x-auto">
            <table className="w-full text-xs font-mono text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Entity / Unit</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Foreign Amount</th>
                  <th className="py-2.5 px-3">SGD Equiv</th>
                  <th className="py-2.5 px-3">Bucket</th>
                  <th className="py-2.5 px-3">Hedge Ratio</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredExposures.map((exp) => (
                  <tr key={exp.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-white">{exp.entityName}</div>
                      <div className="text-[10px] text-slate-400">{exp.description}</div>
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-300">{exp.direction}</td>
                    <td className="py-2.5 px-3 font-bold text-white">
                      {exp.currency} {exp.foreignAmount.toLocaleString('en-US')}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-emerald-400">
                      SGD {Math.round(exp.sgdEquivalent).toLocaleString('en-SG')}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 bg-slate-950 text-slate-300 rounded border border-slate-800">
                        {exp.bucket}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] ${
                          exp.hedgeRatioPct >= 75
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                            : exp.hedgeRatioPct > 0
                            ? 'bg-amber-950 text-amber-400 border border-amber-500/30'
                            : 'bg-rose-950 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {exp.hedgeRatioPct.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => onOpenCalc('CALC-FWD-USD/SGD-1')}
                        className="text-[10px] text-emerald-400 font-bold hover:underline"
                      >
                        [CALC]
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
