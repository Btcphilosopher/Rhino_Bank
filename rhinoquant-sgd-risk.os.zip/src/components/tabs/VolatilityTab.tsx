/**
 * @file src/components/tabs/VolatilityTab.tsx
 * RHINOQUANT SGD RISK.OS — SGD FX Volatility Surface & Garman-Kohlhagen Option Pricer
 */

import React, { useState } from 'react';
import { Activity, Cpu, Sliders, DollarSign } from 'lucide-react';
import { marketEngine } from '../../engine/marketEngine';
import { quantCore } from '../../engine/quantCore';

interface VolatilityTabProps {
  onOpenCalc: (id: string) => void;
}

export const VolatilityTab: React.FC<VolatilityTabProps> = ({ onOpenCalc }) => {
  const volSurf = marketEngine.getVolSurface();
  const usdSgd = marketEngine.getQuote('USD/SGD')?.spotMid || 1.3425;

  // Pricer Form state
  const [spot, setSpot] = useState<number>(usdSgd);
  const [strike, setStrike] = useState<number>(1.3425);
  const [tenorDays, setTenorDays] = useState<number>(90);
  const [volatilityPct, setVolatilityPct] = useState<number>(5.10);
  const [rDom, setRDom] = useState<number>(2.92);
  const [rFor, setRFor] = useState<number>(4.55);
  const [optionType, setOptionType] = useState<'CALL' | 'PUT'>('CALL');

  const optionResult = quantCore.calculateGarmanKohlhagen(
    spot,
    strike,
    tenorDays / 365,
    volatilityPct / 100,
    rDom / 100,
    rFor / 100,
    optionType
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">USD/SGD VOLATILITY SURFACE & OPTION PRICER</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              GARMAN-KOHLHAGEN
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Implied Volatility Surface, Risk Reversals (-25D RR), Butterflies (+25D BF) and Analytical Greeks.
          </p>
        </div>
      </div>

      {/* Main Grid: Option Pricer Calculator + Volatility Surface Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Garman-Kohlhagen Option Pricer */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-400" /> Garman-Kohlhagen Option Pricer
          </h3>

          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400">Option Type</label>
                <select
                  value={optionType}
                  onChange={(e) => setOptionType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-bold"
                >
                  <option value="CALL">USD CALL / SGD PUT</option>
                  <option value="PUT">USD PUT / SGD CALL</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400">Tenor (Days)</label>
                <input
                  type="number"
                  value={tenorDays}
                  onChange={(e) => setTenorDays(parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400">Spot Price (S)</label>
                <input
                  type="number"
                  step="0.0001"
                  value={spot}
                  onChange={(e) => setSpot(parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>
              <div>
                <label className="text-slate-400">Strike Price (K)</label>
                <input
                  type="number"
                  step="0.0001"
                  value={strike}
                  onChange={(e) => setStrike(parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-slate-400">Vol (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={volatilityPct}
                  onChange={(e) => setVolatilityPct(parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>
              <div>
                <label className="text-slate-400">r_SGD (%)</label>
                <input
                  type="number"
                  step="0.01"
                  value={rDom}
                  onChange={(e) => setRDom(parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>
              <div>
                <label className="text-slate-400">r_USD (%)</label>
                <input
                  type="number"
                  step="0.01"
                  value={rFor}
                  onChange={(e) => setRFor(parseFloat(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
                />
              </div>
            </div>

            {/* Calculated Results & Greeks */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 uppercase font-semibold">Option Premium:</span>
                <span className="text-lg font-bold text-emerald-400">
                  SGD {optionResult.price.toFixed(4)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] border-t border-slate-800 pt-2">
                <div className="flex justify-between text-slate-400">
                  <span>Delta (Δ):</span>
                  <span className="font-bold text-slate-200">{optionResult.delta.toFixed(4)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Gamma (Γ):</span>
                  <span className="font-bold text-slate-200">{optionResult.gamma.toFixed(5)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Vega (ν / 1%):</span>
                  <span className="font-bold text-slate-200">{optionResult.vega.toFixed(4)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Theta (θ / day):</span>
                  <span className="font-bold text-slate-200">{optionResult.theta.toFixed(6)}</span>
                </div>
              </div>

              <div className="text-right border-t border-slate-800 pt-1">
                <button
                  onClick={() => onOpenCalc(optionResult.calcId)}
                  className="text-[10px] text-emerald-400 font-bold hover:underline"
                >
                  [CALC PROVENANCE]
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Implied Volatility Surface Matrix */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2 font-mono">
              <Activity className="w-4 h-4 text-emerald-400" /> Implied Volatility Surface Grid (Tenor x Strike)
            </h3>
            <span className="text-xs font-mono text-slate-400">Pair: {volSurf.pair}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-center text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3 text-left">Tenor</th>
                  {volSurf.strikeGrid.map((k) => (
                    <th key={k} className="py-2.5 px-2">
                      K={k}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {volSurf.points.map((pt, tIdx) => (
                  <tr key={pt.tenor} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 text-left font-bold text-white">{pt.tenor}</td>
                    {volSurf.volGrid[tIdx].map((v, sIdx) => {
                      const isATM = sIdx === 3;
                      return (
                        <td
                          key={sIdx}
                          className={`py-2.5 px-2 ${
                            isATM ? 'font-bold text-emerald-400 bg-emerald-950/30' : 'text-slate-300'
                          }`}
                        >
                          {v.toFixed(2)}%
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Risk Reversals & Butterflies Table */}
          <div className="pt-2 border-t border-slate-800">
            <h4 className="text-xs uppercase font-bold text-slate-400 mb-2 font-mono">
              ATM Volatility, Risk Reversals & Butterflies
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-left text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                  <tr>
                    <th className="py-2 px-3">Tenor</th>
                    <th className="py-2 px-3 text-right">ATM Vol %</th>
                    <th className="py-2 px-3 text-right">25D RR %</th>
                    <th className="py-2 px-3 text-right">25D BF %</th>
                    <th className="py-2 px-3 text-right">10D RR %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {volSurf.points.map((pt) => (
                    <tr key={pt.tenor}>
                      <td className="py-2 px-3 font-bold text-white">{pt.tenor}</td>
                      <td className="py-2 px-3 text-right text-emerald-400 font-semibold">{pt.atmVolPct.toFixed(2)}%</td>
                      <td className="py-2 px-3 text-right text-rose-400 font-semibold">{pt.rr25DeltaPct.toFixed(2)}%</td>
                      <td className="py-2 px-3 text-right text-amber-400">{pt.bf25DeltaPct.toFixed(2)}%</td>
                      <td className="py-2 px-3 text-right text-rose-400">{pt.rr10DeltaPct.toFixed(2)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
