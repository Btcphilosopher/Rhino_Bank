/**
 * @file src/components/tabs/AsiaFXFactorTab.tsx
 * RHINOQUANT SGD RISK.OS — Asia FX Factor Model & Regional Engine (PCA Decomposition)
 */

import React from 'react';
import { quantCore } from '../../engine/quantCore';
import { Network, Activity } from 'lucide-react';

interface AsiaFXFactorTabProps {
  onOpenCalc: (id: string) => void;
}

export const AsiaFXFactorTab: React.FC<AsiaFXFactorTabProps> = ({ onOpenCalc }) => {
  const factors = quantCore.getAsiaFXFactorExposures();

  const regionalPairs = [
    { ccy: 'MYR', spot: '3.3150', betaF1: 0.88, betaF2: 0.65, vol: '6.2%' },
    { ccy: 'IDR', spot: '11780.0', betaF1: 0.92, betaF2: 0.58, vol: '7.8%' },
    { ccy: 'THB', spot: '27.150', betaF1: 0.76, betaF2: 0.42, vol: '5.9%' },
    { ccy: 'CNH', spot: '5.3120', betaF1: 0.62, betaF2: 0.95, vol: '4.8%' },
    { ccy: 'JPY', spot: '113.82', betaF1: 0.85, betaF2: -0.22, vol: '8.4%' },
    { ccy: 'KRW', spot: '1028.5', betaF1: 0.89, betaF2: 0.71, vol: '7.2%' },
    { ccy: 'TWD', spot: '23.850', betaF1: 0.72, betaF2: 0.68, vol: '5.1%' },
    { ccy: 'AUD', spot: '1.1285', betaF1: 0.81, betaF2: 0.45, vol: '8.1%' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">ASIA FX FACTOR MODEL & REGIONAL ENGINE</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              PCA FACTOR DECOMPOSITION
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Principal Component Analysis (PCA) isolating Factor 1 (Global USD), Factor 2 (China/CNY Regional Anchor), and Factor 3 (Commodity/Rates).
          </p>
        </div>
      </div>

      {/* Main Grid: Factors + Regional Beta Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        {/* PCA Factors List */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Network className="w-4 h-4 text-emerald-400" /> PCA Factor Variance Explained
          </h3>

          <div className="space-y-3">
            {factors.map((f, idx) => (
              <div key={idx} className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                <div className="flex justify-between items-center font-bold text-white">
                  <span>{f.factorName}</span>
                  <span className="text-emerald-400">{f.varianceExplainedPct}% Var</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full"
                    style={{ width: `${f.varianceExplainedPct}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-400 font-sans leading-relaxed">{f.driverDescription}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Regional FX Beta Matrix */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400" /> Regional Asian Currency Factor Betas & Volatility
            </h3>
            <button
              onClick={() => onOpenCalc('CALC-FWD-USD/SGD-1')}
              className="text-xs text-emerald-400 font-bold hover:underline"
            >
              [CALC PROVENANCE]
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Currency</th>
                  <th className="py-2.5 px-3">Spot Rate</th>
                  <th className="py-2.5 px-3 text-right">Factor 1 Beta (USD)</th>
                  <th className="py-2.5 px-3 text-right">Factor 2 Beta (CNY)</th>
                  <th className="py-2.5 px-3 text-right">Annual Vol</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {regionalPairs.map((r) => (
                  <tr key={r.ccy} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-bold text-white">SGD/{r.ccy}</td>
                    <td className="py-2.5 px-3 text-slate-300">{r.spot}</td>
                    <td className="py-2.5 px-3 text-right text-emerald-400 font-semibold">{r.betaF1.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-amber-400 font-semibold">{r.betaF2.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-slate-400">{r.vol}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
