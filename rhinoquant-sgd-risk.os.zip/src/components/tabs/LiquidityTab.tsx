/**
 * @file src/components/tabs/LiquidityTab.tsx
 * RHINOQUANT SGD RISK.OS — SGD Liquidity Ladder & FX Funding Risk
 */

import React from 'react';
import { marketEngine } from '../../engine/marketEngine';
import { Layers, Activity } from 'lucide-react';

interface LiquidityTabProps {
  onOpenCalc: (id: string) => void;
}

export const LiquidityTab: React.FC<LiquidityTabProps> = ({ onOpenCalc }) => {
  const ladder = marketEngine.getLiquidityLadder();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">SGD LIQUIDITY & FUNDING RISK LADDER</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              SETTLEMENT & MARGIN BUFFER
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Maturity-bucketed cash flow settlements, FX forward/swap delivery dates, and potential variation margin calls under FX shocks.
          </p>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 overflow-x-auto font-mono text-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" /> Maturity-Bucketed SGD Liquidity Ladder
          </h3>
          <button
            onClick={() => onOpenCalc('CALC-VAR-1')}
            className="text-xs text-emerald-400 font-bold hover:underline"
          >
            [CALC PROVENANCE]
          </button>
        </div>

        <table className="w-full text-left text-slate-300">
          <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
            <tr>
              <th className="py-3 px-3">Tenor Bucket</th>
              <th className="py-3 px-3 text-right">Inflows (SGD)</th>
              <th className="py-3 px-3 text-right">Outflows (SGD)</th>
              <th className="py-3 px-3 text-right">Net Cash Flow</th>
              <th className="py-3 px-3 text-right">FX Settlements</th>
              <th className="py-3 px-3 text-right">Potential Margin Call</th>
              <th className="py-3 px-3 text-right">Cumulative Buffer</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {ladder.map((row) => (
              <tr key={row.bucket} className="hover:bg-slate-800/40 transition-colors">
                <td className="py-2.5 px-3 font-bold text-white">{row.bucket}</td>
                <td className="py-2.5 px-3 text-right text-emerald-400 font-semibold">
                  SGD {Math.round(row.sgdInflows / 1000).toLocaleString('en-SG')}k
                </td>
                <td className="py-2.5 px-3 text-right text-slate-300">
                  SGD {Math.round(row.sgdOutflows / 1000).toLocaleString('en-SG')}k
                </td>
                <td className="py-2.5 px-3 text-right text-emerald-400 font-bold">
                  SGD {Math.round(row.netSgdPosition / 1000).toLocaleString('en-SG')}k
                </td>
                <td className="py-2.5 px-3 text-right text-slate-400">
                  SGD {Math.round(row.foreignSettlementSGD / 1000).toLocaleString('en-SG')}k
                </td>
                <td className="py-2.5 px-3 text-right text-rose-400 font-semibold">
                  SGD {Math.round(row.potentialMarginCallSGD / 1000).toLocaleString('en-SG')}k
                </td>
                <td className="py-2.5 px-3 text-right text-emerald-400 font-bold bg-emerald-950/20">
                  SGD {Math.round(row.cumulativeLiquiditySGD / 1000).toLocaleString('en-SG')}k
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
