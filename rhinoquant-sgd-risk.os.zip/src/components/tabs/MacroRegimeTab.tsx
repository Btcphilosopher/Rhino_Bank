/**
 * @file src/components/tabs/MacroRegimeTab.tsx
 * RHINOQUANT SGD RISK.OS — Macro State Engine & Historical Crisis Replay
 */

import React, { useState } from 'react';
import { PortfolioPosition } from '../../types';
import { Activity, Play, Zap, AlertTriangle } from 'lucide-react';

interface MacroRegimeTabProps {
  positions: PortfolioPosition[];
  onOpenCalc: (id: string) => void;
}

export const MacroRegimeTab: React.FC<MacroRegimeTabProps> = ({ positions, onOpenCalc }) => {
  const [selectedRegime, setSelectedRegime] = useState<string>('USD_STRENGTH');
  const [selectedCrisis, setSelectedCrisis] = useState<string>('2022_FED_HIKE');

  const regimes = [
    { id: 'RISK_ON', name: 'Risk-On / Global Trade Growth', sgdReturn: '+0.45%', usdSgdChange: '-0.35%', vol: '4.2%' },
    { id: 'USD_STRENGTH', name: 'USD Strength / Hawkish Fed Pivot', sgdReturn: '-0.85%', usdSgdChange: '+1.20%', vol: '6.8%' },
    { id: 'ASIA_WEAKNESS', name: 'Asia Weakness / China Growth Slowdown', sgdReturn: '-0.52%', usdSgdChange: '+0.65%', vol: '5.9%' },
    { id: 'INFLATION_MAS', name: 'Inflation Shock / MAS Slope Tightening', sgdReturn: '+0.65%', usdSgdChange: '-0.50%', vol: '4.8%' },
  ];

  const crisisPeriods = [
    { id: '1997_AFC', name: '1997 Asian Financial Crisis', usdSgdImpact: '+18.5%', sgdUnhedgedDrawdown: '-SGD 24.8M', maxVol: '14.2%' },
    { id: '2008_GFC', name: '2008 Global Financial Crisis', usdSgdImpact: '+12.4%', sgdUnhedgedDrawdown: '-SGD 16.5M', maxVol: '12.8%' },
    { id: '2015_CNY', name: '2015 CNY Devaluation Shock', usdSgdImpact: '+5.8%', sgdUnhedgedDrawdown: '-SGD 7.8M', maxVol: '8.5%' },
    { id: '2020_COVID', name: '2020 COVID Liquidity Shock', usdSgdImpact: '+7.2%', sgdUnhedgedDrawdown: '-SGD 9.6M', maxVol: '10.5%' },
    { id: '2022_FED_HIKE', name: '2022 Aggressive Fed Rate Hikes', usdSgdImpact: '+6.4%', sgdUnhedgedDrawdown: '-SGD 8.5M', maxVol: '7.8%' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">MACRO REGIME ENGINE & HISTORICAL CRISIS REPLAY</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              ANALYTICAL STATES
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Conditional return distributions under macro regimes and historical replay of SGD stress periods (1997, 2008, 2015, 2020, 2022).
          </p>
        </div>
      </div>

      {/* Main Grid: Regimes + Crisis Replay */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* Left: Macro Regime Selector */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" /> Analytical Macro States
          </h3>

          <div className="space-y-2">
            {regimes.map((r) => (
              <button
                key={r.id}
                onClick={() => setSelectedRegime(r.id)}
                className={`w-full text-left p-3 rounded-lg border transition-all ${
                  selectedRegime === r.id
                    ? 'bg-emerald-950/60 border-emerald-500/50 text-white font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span>{r.name}</span>
                  <span className="text-emerald-400 font-bold">{r.usdSgdChange}</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                  <span>Cond. SGD Return: {r.sgdReturn}</span>
                  <span>Annual Vol: {r.vol}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right: Historical Crisis Replay */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Zap className="w-4 h-4 text-rose-400" /> Historical Crisis Stress Periods Replay
            </h3>
            <button
              onClick={() => onOpenCalc('CALC-VAR-1')}
              className="text-xs text-emerald-400 font-bold hover:underline"
            >
              [CALC PROVENANCE]
            </button>
          </div>

          <div className="space-y-2">
            {crisisPeriods.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedCrisis(c.id)}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  selectedCrisis === c.id
                    ? 'bg-rose-950/40 border-rose-500/50 text-white font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span>{c.name}</span>
                  <span className="text-rose-400">{c.usdSgdImpact} USD/SGD Shock</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                  <span>Unhedged Drawdown: {c.sgdUnhedgedDrawdown}</span>
                  <span>Max Peak Vol: {c.maxVol}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
