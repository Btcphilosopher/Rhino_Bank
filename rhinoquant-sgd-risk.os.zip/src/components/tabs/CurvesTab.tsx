/**
 * @file src/components/tabs/CurvesTab.tsx
 * RHINOQUANT SGD RISK.OS — SGD Interest Rate & Yield Curve Engine
 */

import React, { useState } from 'react';
import { Activity, Layers, ArrowUpRight, Cpu } from 'lucide-react';
import { marketEngine } from '../../engine/marketEngine';

interface CurvesTabProps {
  onOpenCalc: (id: string) => void;
}

export const CurvesTab: React.FC<CurvesTabProps> = ({ onOpenCalc }) => {
  const sora = marketEngine.getSoraCurve();
  const sofr = marketEngine.getSofrCurve();
  const basis = marketEngine.getBasisCurve();

  const [parallelShiftBp, setParallelShiftBp] = useState<number>(0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">SGD INTEREST-RATE & CURVE ENGINE</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              SORA BENCHMARK
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Singapore Overnight Rate Average (SORA) OIS Curve, USD SOFR Benchmark Curve and USD/SGD Cross-Currency Basis.
          </p>
        </div>

        {/* Shift Controls */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Curve Shift:</span>
          {[-25, 0, 25, 50].map((bp) => (
            <button
              key={bp}
              onClick={() => setParallelShiftBp(bp)}
              className={`px-2.5 py-1 rounded border ${
                parallelShiftBp === bp
                  ? 'bg-emerald-600 border-emerald-500 text-white font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {bp > 0 ? `+${bp}bp` : `${bp}bp`}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: SORA Curve Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2 font-mono">
              <Activity className="w-4 h-4 text-emerald-400" /> SGD SORA OIS Curve Structure
            </h3>
            <button
              onClick={() => onOpenCalc('CALC-FWD-USD/SGD-1')}
              className="text-xs font-mono text-emerald-400 font-bold hover:underline"
            >
              [CALC PROVENANCE]
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Tenor</th>
                  <th className="py-2.5 px-3 text-right">SORA Par %</th>
                  <th className="py-2.5 px-3 text-right">Zero Rate %</th>
                  <th className="py-2.5 px-3 text-right">Discount Factor</th>
                  <th className="py-2.5 px-3 text-right">Forward Rate %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {sora.points.map((pt) => {
                  const shiftedRate = pt.ratePct + parallelShiftBp / 100;
                  const shiftedZero = pt.zeroRatePct + parallelShiftBp / 100;
                  const shiftedDF = Math.exp((-shiftedZero / 100) * (pt.days / 365));

                  return (
                    <tr key={pt.tenor} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 px-3 font-bold text-white">{pt.tenor}</td>
                      <td className="py-2.5 px-3 text-right text-emerald-400 font-semibold">{shiftedRate.toFixed(2)}%</td>
                      <td className="py-2.5 px-3 text-right text-slate-300">{shiftedZero.toFixed(2)}%</td>
                      <td className="py-2.5 px-3 text-right text-slate-400">{shiftedDF.toFixed(5)}</td>
                      <td className="py-2.5 px-3 text-right text-slate-200">{pt.forwardRatePct.toFixed(2)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: USD SOFR & Basis Curve Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2 font-mono">
              <Layers className="w-4 h-4 text-emerald-400" /> USD SOFR & Cross-Currency Basis (bp)
            </h3>
            <span className="text-xs font-mono text-slate-400">Curve Date: {sora.curveDate}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Tenor</th>
                  <th className="py-2.5 px-3 text-right">USD SOFR %</th>
                  <th className="py-2.5 px-3 text-right">SOFR DF</th>
                  <th className="py-2.5 px-3 text-right">USD/SGD Basis (bp)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {sofr.points.map((pt) => {
                  const basisPt = basis.points.find((b) => b.tenor === pt.tenor);
                  const basisBp = basisPt ? Math.round(basisPt.ratePct * 100) : '—';

                  return (
                    <tr key={pt.tenor} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 px-3 font-bold text-white">{pt.tenor}</td>
                      <td className="py-2.5 px-3 text-right text-amber-400 font-semibold">{pt.ratePct.toFixed(2)}%</td>
                      <td className="py-2.5 px-3 text-right text-slate-400">{pt.discountFactor.toFixed(5)}</td>
                      <td className="py-2.5 px-3 text-right text-rose-400 font-bold">{basisBp} bp</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
