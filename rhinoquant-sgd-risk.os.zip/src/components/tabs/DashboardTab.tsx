/**
 * @file src/components/tabs/DashboardTab.tsx
 * RHINOQUANT SGD RISK.OS — Flagship Dashboard & Market Map
 */

import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Activity,
  Layers,
  HelpCircle,
  Network,
} from 'lucide-react';
import { FXQuote, PortfolioPosition } from '../../types';
import { marketEngine } from '../../engine/marketEngine';
import { quantCore } from '../../engine/quantCore';

interface DashboardTabProps {
  quotes: FXQuote[];
  positions: PortfolioPosition[];
  onOpenCalc: (id: string) => void;
  onOpenRiskTree: () => void;
  onSelectTab: (tabId: string) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  quotes,
  positions,
  onOpenCalc,
  onOpenRiskTree,
  onSelectTab,
}) => {
  const sneer = marketEngine.getSNEERState();
  const sora = marketEngine.getSoraCurve();
  const risk = quantCore.calculatePortfolioRisk(positions, 1, 99);
  const usdSgd = marketEngine.getQuote('USD/SGD');

  return (
    <div className="space-y-6">
      {/* Top Banner KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {/* Card 1: SGD SPOT */}
        <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1 relative group">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>USD/SGD SPOT</span>
            <button
              onClick={() => onOpenCalc('CALC-FWD-USD/SGD-1')}
              className="text-[10px] text-emerald-400 font-bold hover:underline"
            >
              [CALC]
            </button>
          </div>
          <div className="text-xl font-bold font-mono text-white">
            {usdSgd?.spotMid.toFixed(4) || '1.3425'}
          </div>
          <div className="flex items-center gap-1 text-xs font-mono text-emerald-400">
            <TrendingDown className="w-3.5 h-3.5" /> -0.15% (-0.0020)
          </div>
        </div>

        {/* Card 2: S$NEER Index */}
        <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>S$NEER STATE</span>
            <button
              onClick={() => onSelectTab('NEER')}
              className="text-[10px] text-emerald-400 font-bold hover:underline"
            >
              [CALC]
            </button>
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400">
            {sneer.indexValue.toFixed(2)}
          </div>
          <div className="text-[11px] font-mono text-slate-400 truncate">
            +{sneer.distanceFromCentrePct.toFixed(2)}% vs Centre (Band ±2.0%)
          </div>
        </div>

        {/* Card 3: SORA Benchmark */}
        <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>SORA OVERNIGHT</span>
            <button
              onClick={() => onSelectTab('CURVES')}
              className="text-[10px] text-emerald-400 font-bold hover:underline"
            >
              [CALC]
            </button>
          </div>
          <div className="text-xl font-bold font-mono text-white">
            {sora.points[0].ratePct.toFixed(2)}%
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            3M SORA: {sora.points[2].ratePct.toFixed(2)}%
          </div>
        </div>

        {/* Card 4: Net FX Delta */}
        <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>NET FX DELTA</span>
            <button
              onClick={() => onOpenCalc('CALC-VAR-1')}
              className="text-[10px] text-emerald-400 font-bold hover:underline"
            >
              [CALC]
            </button>
          </div>
          <div className="text-xl font-bold font-mono text-white">
            SGD {(risk.deltaSGD / 1000000).toFixed(2)}M
          </div>
          <div className="text-[11px] font-mono text-emerald-400">
            85.0% Hedged Ratio
          </div>
        </div>

        {/* Card 5: 1D 99% VaR */}
        <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>1D 99% VaR</span>
            <button
              onClick={() => onOpenCalc('CALC-VAR-1')}
              className="text-[10px] text-emerald-400 font-bold hover:underline"
            >
              [CALC]
            </button>
          </div>
          <div className="text-xl font-bold font-mono text-amber-400">
            SGD {(risk.var1D99 / 1000).toFixed(0)}k
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            10D VaR: SGD {(risk.var10D99 / 1000).toFixed(0)}k
          </div>
        </div>

        {/* Card 6: Expected Shortfall */}
        <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>EXPECTED SHORTFALL</span>
            <button
              onClick={() => onOpenCalc('CALC-VAR-1')}
              className="text-[10px] text-emerald-400 font-bold hover:underline"
            >
              [CALC]
            </button>
          </div>
          <div className="text-xl font-bold font-mono text-rose-400">
            SGD {(risk.expectedShortfall99 / 1000).toFixed(0)}k
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            99% Tail Expectation
          </div>
        </div>
      </div>

      {/* Main Section: SGD Market Map & Quick Action Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SGD Market Map Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" /> SGD Market Map & Cross Rates
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Official MAS Fixing Benchmarks & OTC Deliverable Forward Points
              </p>
            </div>
            <button
              onClick={onOpenRiskTree}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950 border border-emerald-500/40 text-emerald-400 text-xs font-mono font-semibold hover:bg-emerald-900 transition-colors"
            >
              <Network className="w-3.5 h-3.5" /> OPEN RISK TREE
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Pair</th>
                  <th className="py-2.5 px-3">Spot Mid</th>
                  <th className="py-2.5 px-3">Bid / Ask</th>
                  <th className="py-2.5 px-3">1M Fwd Pts</th>
                  <th className="py-2.5 px-3">3M Fwd Pts</th>
                  <th className="py-2.5 px-3">24h Chg</th>
                  <th className="py-2.5 px-3 text-right">Audit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {quotes.map((q) => (
                  <tr key={q.pair} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-bold text-white">{q.pair}</td>
                    <td className="py-2.5 px-3 text-emerald-400 font-semibold">{q.spotMid.toFixed(4)}</td>
                    <td className="py-2.5 px-3 text-slate-400">
                      {q.bid.toFixed(4)} / {q.ask.toFixed(4)}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {q.forwardPoints1M > 0 ? `+${q.forwardPoints1M}` : q.forwardPoints1M}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {q.forwardPoints3M > 0 ? `+${q.forwardPoints3M}` : q.forwardPoints3M}
                    </td>
                    <td
                      className={`py-2.5 px-3 font-semibold ${
                        q.dailyChangePct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {q.dailyChangePct >= 0 ? `+${q.dailyChangePct.toFixed(2)}%` : `${q.dailyChangePct.toFixed(2)}%`}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => onOpenCalc(`CALC-FWD-${q.pair}-1`)}
                        className="text-[10px] text-emerald-400 font-bold hover:underline"
                      >
                        [CALC]
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Panel: Top Portfolio Risks & Quick Actions */}
        <div className="space-y-6">
          {/* Top Risks Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" /> Active Top Portfolio Risks
            </h3>
            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                <div className="flex items-center justify-between font-semibold text-slate-200">
                  <span>USD Depreciation Sensitivity</span>
                  <span className="text-amber-400">HIGH</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                  USD 100m trade receivable unhedged residual exposure (USD 15m) drops SGD 201,375 for every -1.5% USD/SGD decline.
                </p>
              </div>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                <div className="flex items-center justify-between font-semibold text-slate-200">
                  <span>CNY Component Import Inflation</span>
                  <span className="text-rose-400">CRITICAL</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                  CNY 40m supplier payable currently 0% hedged. A 5.0% CNH appreciation increases SGD payables by SGD 376,790.
                </p>
              </div>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                <div className="flex items-center justify-between font-semibold text-slate-200">
                  <span>SORA Rate Hike Basis Risk</span>
                  <span className="text-emerald-400">MODERATE</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                  USD/SGD cross-currency basis widening by 10 bps adds SGD 85,000 to annual SGD funding cost.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Navigation Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
            <h3 className="text-xs uppercase font-bold text-slate-400 tracking-wider font-mono">Quant Subsystems</h3>
            <div className="grid grid-cols-2 gap-2 font-mono text-xs">
              <button
                onClick={() => onSelectTab('EXPOSURE')}
                className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-left text-slate-200 font-semibold transition-colors"
              >
                Exposure Matrix →
              </button>
              <button
                onClick={() => onSelectTab('HEDGE')}
                className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-left text-slate-200 font-semibold transition-colors"
              >
                Hedge Lab →
              </button>
              <button
                onClick={() => onSelectTab('SCENARIO')}
                className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-left text-slate-200 font-semibold transition-colors"
              >
                Scenario Lab →
              </button>
              <button
                onClick={() => onSelectTab('MONTE_CARLO')}
                className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-left text-slate-200 font-semibold transition-colors"
              >
                Monte Carlo →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
