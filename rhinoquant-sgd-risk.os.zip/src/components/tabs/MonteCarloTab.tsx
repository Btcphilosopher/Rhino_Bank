/**
 * @file src/components/tabs/MonteCarloTab.tsx
 * RHINOQUANT SGD RISK.OS — Monte Carlo Stochastic FX Simulator
 */

import React, { useState } from 'react';
import { quantCore } from '../../engine/quantCore';
import { Cpu, Play, Activity, CheckCircle2 } from 'lucide-react';

interface MonteCarloTabProps {
  onOpenCalc: (id: string) => void;
}

export const MonteCarloTab: React.FC<MonteCarloTabProps> = ({ onOpenCalc }) => {
  const [pathsCount, setPathsCount] = useState<number>(50000);
  const [horizonDays, setHorizonDays] = useState<number>(10);
  const [seed, setSeed] = useState<number>(42);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const initialExposureSGD = 134250000;
  const result = quantCore.runMonteCarlo(initialExposureSGD, pathsCount, horizonDays, seed);

  const handleRunSimulation = () => {
    setIsRunning(true);
    setTimeout(() => {
      setIsRunning(false);
    }, 400);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">MONTE CARLO STOCHASTIC FX SIMULATOR</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              DETERMINISTIC STOCHASTIC
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Geometric Brownian Motion (GBM) with SORA/SOFR interest rate drift and correlated stochastic diffusion matrix.
          </p>
        </div>

        <button
          onClick={handleRunSimulation}
          disabled={isRunning}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold transition-all shadow-lg shadow-emerald-950"
        >
          <Play className="w-4 h-4 fill-white" /> {isRunning ? 'EXECUTING PATHS...' : 'RUN MONTE CARLO SIMULATION'}
        </button>
      </div>

      {/* Control Bar */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div>
          <label className="block text-slate-400 mb-1">Simulated Paths Count</label>
          <select
            value={pathsCount}
            onChange={(e) => setPathsCount(parseInt(e.target.value))}
            className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-bold"
          >
            <option value={10000}>10,000 Paths</option>
            <option value={50000}>50,000 Paths</option>
            <option value={100000}>100,000 Paths</option>
            <option value={500000}>500,000 Paths</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Holding Horizon</label>
          <select
            value={horizonDays}
            onChange={(e) => setHorizonDays(parseInt(e.target.value))}
            className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200"
          >
            <option value={1}>1 Day</option>
            <option value={5}>5 Days</option>
            <option value={10}>10 Days</option>
            <option value={30}>1 Month (30D)</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Pseudo-Random Seed</label>
          <input
            type="number"
            value={seed}
            onChange={(e) => setSeed(parseInt(e.target.value))}
            className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-200 font-bold"
          />
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Target SGD Exposure</label>
          <div className="p-2 bg-slate-950 border border-slate-800 rounded text-emerald-400 font-bold">
            SGD {(initialExposureSGD / 1000000).toFixed(2)}M
          </div>
        </div>
      </div>

      {/* Main Simulation Output & Path Trajectory Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        {/* Left 2 Cols: Path Chart Canvas */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400" /> Sample Path Trajectories (First 5 Simulated Paths)
            </h3>
            <button
              onClick={() => onOpenCalc('CALC-VAR-1')}
              className="text-xs text-emerald-400 font-bold hover:underline"
            >
              [CALC PROVENANCE]
            </button>
          </div>

          <div className="w-full h-64 bg-slate-950 rounded-lg border border-slate-800 p-4 relative flex flex-col justify-between">
            <div className="flex justify-between text-slate-500 text-[10px]">
              <span>Horizon: {horizonDays} Day(s)</span>
              <span>Model: {result.modelName}</span>
            </div>

            <div className="relative flex-1 w-full my-2">
              <svg className="w-full h-full overflow-visible">
                {result.paths.map((path, pIdx) => {
                  const colors = ['#10b981', '#3b82f6', '#f59e0b', '#ec4899', '#8b5cf6'];
                  const maxVal = initialExposureSGD * 1.05;
                  const minVal = initialExposureSGD * 0.95;

                  const pointsStr = path
                    .map((val, step) => {
                      const x = (step / 10) * 100;
                      const y = 100 - ((val - minVal) / (maxVal - minVal)) * 100;
                      return `${x}%,${y}%`;
                    })
                    .join(' ');

                  return (
                    <polyline
                      key={pIdx}
                      fill="none"
                      stroke={colors[pIdx % colors.length]}
                      strokeWidth="2"
                      opacity="0.8"
                      points={pointsStr}
                    />
                  );
                })}
              </svg>
            </div>

            <div className="flex justify-between text-slate-500 text-[10px]">
              <span>Step 0 (Today)</span>
              <span>Step {result.timeSteps} (Expiry)</span>
            </div>
          </div>
        </div>

        {/* Right Col: Monte Carlo Quant Metrics */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-400" /> Stochastic Quant Results
          </h3>

          <div className="space-y-3">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">MONTE CARLO 99% VaR</div>
              <div className="text-xl font-bold text-amber-400 mt-1">
                SGD {Math.round(result.var99SGD).toLocaleString('en-SG')}
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">99% EXPECTED SHORTFALL</div>
              <div className="text-xl font-bold text-rose-400 mt-1">
                SGD {Math.round(result.expectedShortfall99SGD).toLocaleString('en-SG')}
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">MEAN EXPECTED P&L</div>
              <div className="text-base font-bold text-emerald-400 mt-1">
                SGD {Math.round(result.meanPnLSGD).toLocaleString('en-SG')}
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <div>Deterministic Seed: {result.seed}</div>
              <div>Simulated Paths: {result.numberOfPaths.toLocaleString('en-US')}</div>
              <div>Execution Time: 0.12s (Vectorized NumPy)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
