/**
 * @file src/components/tabs/ScenarioTab.tsx
 * RHINOQUANT SGD RISK.OS — Scenario Laboratory & Stress Engine
 */

import React, { useState } from 'react';
import { PortfolioPosition, ScenarioDefinition } from '../../types';
import { quantCore } from '../../engine/quantCore';
import { Sliders, Activity, Zap, CheckCircle2 } from 'lucide-react';

interface ScenarioTabProps {
  positions: PortfolioPosition[];
  onOpenCalc: (id: string) => void;
}

export const ScenarioTab: React.FC<ScenarioTabProps> = ({ positions, onOpenCalc }) => {
  const [usdShock, setUsdShock] = useState<number>(5.0); // +5%
  const [cnhShock, setCnhShock] = useState<number>(-4.0); // -4%
  const [myrShock, setMyrShock] = useState<number>(-6.0); // -6%
  const [soraShockBp, setSoraShockBp] = useState<number>(75); // +75bp
  const [volShockPct, setVolShockPct] = useState<number>(50); // +50%

  const activeScenario: ScenarioDefinition = {
    id: 'SCEN-CUSTOM',
    name: 'Multi-Variable Macro Stress Test',
    category: 'CUSTOM',
    shocks: {
      usdSgdPct: usdShock,
      sgdCnhPct: cnhShock,
      sgdMyrPct: myrShock,
      soraBp: soraShockBp,
      volatilityPct: volShockPct,
    },
  };

  const result = quantCore.evaluateScenario(positions, [], activeScenario);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-white tracking-tight">SCENARIO LABORATORY & STRESS ENGINE</h2>
            <span className="px-2.5 py-0.5 text-xs font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 rounded">
              STRESS TESTING
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Evaluate simultaneous multi-asset shocks across FX rates, interest rates, regional Asian currencies and volatility surfaces.
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: Shock Controls */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-400" /> Multi-Variable Shock Sliders
          </h3>

          <div className="space-y-3">
            <div>
              <label className="flex justify-between text-slate-400 mb-1">
                <span>USD/SGD Spot Shock:</span>
                <span className={usdShock >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {usdShock >= 0 ? `+${usdShock}%` : `${usdShock}%`}
                </span>
              </label>
              <input
                type="range"
                min="-10"
                max="10"
                step="0.5"
                value={usdShock}
                onChange={(e) => setUsdShock(parseFloat(e.target.value))}
                className="w-full accent-emerald-500 bg-slate-950"
              />
            </div>

            <div>
              <label className="flex justify-between text-slate-400 mb-1">
                <span>SGD/CNH Regional Shock:</span>
                <span className={cnhShock >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {cnhShock >= 0 ? `+${cnhShock}%` : `${cnhShock}%`}
                </span>
              </label>
              <input
                type="range"
                min="-10"
                max="10"
                step="0.5"
                value={cnhShock}
                onChange={(e) => setCnhShock(parseFloat(e.target.value))}
                className="w-full accent-rose-500 bg-slate-950"
              />
            </div>

            <div>
              <label className="flex justify-between text-slate-400 mb-1">
                <span>SGD/MYR Regional Shock:</span>
                <span className={myrShock >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {myrShock >= 0 ? `+${myrShock}%` : `${myrShock}%`}
                </span>
              </label>
              <input
                type="range"
                min="-10"
                max="10"
                step="0.5"
                value={myrShock}
                onChange={(e) => setMyrShock(parseFloat(e.target.value))}
                className="w-full accent-rose-500 bg-slate-950"
              />
            </div>

            <div>
              <label className="flex justify-between text-slate-400 mb-1">
                <span>SORA Rate Shock (bp):</span>
                <span className="text-amber-400 font-bold">+{soraShockBp} bp</span>
              </label>
              <input
                type="range"
                min="-100"
                max="200"
                step="25"
                value={soraShockBp}
                onChange={(e) => setSoraShockBp(parseFloat(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950"
              />
            </div>

            <div>
              <label className="flex justify-between text-slate-400 mb-1">
                <span>Implied Volatility Shift (%):</span>
                <span className="text-purple-400 font-bold">+{volShockPct}%</span>
              </label>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={volShockPct}
                onChange={(e) => setVolShockPct(parseFloat(e.target.value))}
                className="w-full accent-purple-500 bg-slate-950"
              />
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Stress Results Panel */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-400" /> Scenario P&L & Capital Impact
            </h3>
            <button
              onClick={() => onOpenCalc('CALC-VAR-1')}
              className="text-xs text-emerald-400 font-bold hover:underline"
            >
              [CALC PROVENANCE]
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">UNHEDGED P&L IMPACT</div>
              <div
                className={`text-base font-bold mt-1 ${
                  result.unhedgedPnLSGD >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                SGD {Math.round(result.unhedgedPnLSGD).toLocaleString('en-SG')}
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">HEDGED P&L IMPACT</div>
              <div
                className={`text-base font-bold mt-1 ${
                  result.hedgedPnLSGD >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                SGD {Math.round(result.hedgedPnLSGD).toLocaleString('en-SG')}
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">HEDGE OFFSET RATIO</div>
              <div className="text-base font-bold text-emerald-400 mt-1">
                {result.hedgeEffectivenessOffsetPct.toFixed(1)}%
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">STRESS POST-SHOCK 1D VaR</div>
              <div className="text-base font-bold text-amber-400 mt-1">
                SGD {Math.round(result.varPostShock1D99SGD).toLocaleString('en-SG')}
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">POTENTIAL MARGIN CALL</div>
              <div className="text-base font-bold text-rose-400 mt-1">
                SGD {Math.round(result.liquidityCallSGD).toLocaleString('en-SG')}
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">POST-SHOCK PORTFOLIO VAL</div>
              <div className="text-base font-bold text-white mt-1">
                SGD {Math.round(result.portfolioValueAfterSGD).toLocaleString('en-SG')}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
