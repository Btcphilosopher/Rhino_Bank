/**
 * @file src/components/RiskTreeModal.tsx
 * RHINOQUANT SGD RISK.OS — Interactive SGD Risk Tree Explorer
 */

import React, { useState } from 'react';
import { X, Network, ChevronRight, ChevronDown, ShieldCheck, AlertTriangle } from 'lucide-react';
import { PortfolioPosition } from '../types';

interface RiskTreeModalProps {
  isOpen: boolean;
  onClose: () => void;
  positions: PortfolioPosition[];
  onOpenCalc: (id: string) => void;
}

export const RiskTreeModal: React.FC<RiskTreeModalProps> = ({ isOpen, onClose, positions }) => {
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    USD: true,
    CNY: true,
    MYR: false,
    EUR: false,
    JPY: false,
  });

  if (!isOpen) return null;

  const toggleNode = (nodeKey: string) => {
    setExpandedNodes((prev) => ({ ...prev, [nodeKey]: !prev[nodeKey] }));
  };

  const ccyGroups: Record<string, PortfolioPosition[]> = {};
  positions.forEach((p) => {
    if (!ccyGroups[p.currency]) ccyGroups[p.currency] = [];
    ccyGroups[p.currency].push(p);
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-hidden rounded-xl bg-slate-900 border border-slate-700 shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-500/30 text-emerald-400">
              <Network className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold tracking-tight text-white">SGD Portfolio Risk Tree Decomposition</h3>
              <p className="text-xs text-slate-400 font-mono">
                Hierarchical Risk Breakdown · Currency & Position Delta Tree
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tree Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 font-mono text-xs">
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
            <span className="font-bold text-white text-sm">TOTAL SGD PORTFOLIO FX RISK</span>
            <span className="text-emerald-400 font-bold text-sm">NET DELTA: SGD 13,425,000</span>
          </div>

          <div className="space-y-3 pl-2">
            {Object.entries(ccyGroups).map(([ccy, posList]) => {
              const isExpanded = expandedNodes[ccy] ?? false;
              const ccyNetSGD = posList.reduce((acc, p) => acc + p.marketValueSGD, 0);

              return (
                <div key={ccy} className="border border-slate-800 rounded-lg bg-slate-950/60 overflow-hidden">
                  <button
                    onClick={() => toggleNode(ccy)}
                    className="w-full flex items-center justify-between p-3 bg-slate-900 hover:bg-slate-800/80 transition-colors text-left"
                  >
                    <div className="flex items-center gap-2">
                      {isExpanded ? <ChevronDown className="w-4 h-4 text-emerald-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                      <span className="font-bold text-slate-100 text-sm">{ccy} CURRENCY EXPOSURE BUCKET</span>
                      <span className="px-2 py-0.5 text-[10px] bg-slate-800 text-slate-300 rounded">{posList.length} Position(s)</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-slate-400">
                        Net SGD Equiv:{' '}
                        <span className="font-bold text-emerald-400">
                          SGD {Math.abs(ccyNetSGD).toLocaleString('en-SG')}
                        </span>
                      </span>
                    </div>
                  </button>

                  {isExpanded && (
                    <div className="p-3 space-y-2 border-t border-slate-800/80 bg-slate-950 pl-6">
                      {posList.map((p) => (
                        <div key={p.id} className="p-2.5 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
                          <div className="space-y-0.5">
                            <div className="font-semibold text-slate-200">{p.instrumentName}</div>
                            <div className="text-[11px] text-slate-400">
                              {p.legalEntity} · {p.country} · Maturity: {p.maturityDate}
                            </div>
                          </div>
                          <div className="text-right space-y-1">
                            <div className="font-bold text-slate-100">
                              {p.currency} {Math.abs(p.notionalForeign).toLocaleString('en-US')}
                            </div>
                            <div className="flex items-center gap-2 justify-end">
                              <span className="text-slate-400">
                                SGD {Math.abs(p.marketValueSGD).toLocaleString('en-SG')}
                              </span>
                              {p.hedgeStatus === 'FULLY_HEDGED' ? (
                                <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-500/30">
                                  <ShieldCheck className="w-3 h-3" /> HEDGED
                                </span>
                              ) : p.hedgeStatus === 'PARTIALLY_HEDGED' ? (
                                <span className="flex items-center gap-1 text-[10px] text-amber-400 bg-amber-950 px-1.5 py-0.5 rounded border border-amber-500/30">
                                  PARTIAL
                                </span>
                              ) : (
                                <span className="flex items-center gap-1 text-[10px] text-rose-400 bg-rose-950 px-1.5 py-0.5 rounded border border-rose-500/30">
                                  <AlertTriangle className="w-3 h-3" /> UNHEDGED
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-900/90 text-xs text-slate-400 font-mono">
          <span>Click any branch to expand underlying position risk components</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-sans font-medium transition-colors"
          >
            Close Risk Tree
          </button>
        </div>
      </div>
    </div>
  );
};
