/**
 * @file src/App.tsx
 * RHINOQUANT SGD RISK.OS — Master Application Container
 */

import React, { useState } from 'react';
import {
  Shield,
  FileSpreadsheet,
  Network,
  Download,
  Activity,
  Layers,
  Cpu,
  BarChart3,
  Sliders,
  DollarSign,
  Zap,
  Play,
  Briefcase,
  Database,
  Search,
} from 'lucide-react';

import { marketEngine } from './engine/marketEngine';
import { provenanceRegistry } from './engine/provenance';
import {
  DEMO_INSTITUTIONAL_PORTFOLIO,
  DEMO_CORPORATE_TREASURY,
  DEMO_REGIME_LAB,
  DemoDataset,
} from './engine/presetDemos';
import { CalculationTrace, CorporateExposure, PortfolioPosition } from './types';

// Tab Components
import { DashboardTab } from './components/tabs/DashboardTab';
import { SNEERTab } from './components/tabs/SNEERTab';
import { ExposureMatrixTab } from './components/tabs/ExposureMatrixTab';
import { CorporateTreasuryTab } from './components/tabs/CorporateTreasuryTab';
import { CurvesTab } from './components/tabs/CurvesTab';
import { VolatilityTab } from './components/tabs/VolatilityTab';
import { HedgeLabTab } from './components/tabs/HedgeLabTab';
import { ScenarioTab } from './components/tabs/ScenarioTab';
import { MonteCarloTab } from './components/tabs/MonteCarloTab';
import { AsiaFXFactorTab } from './components/tabs/AsiaFXFactorTab';
import { MacroRegimeTab } from './components/tabs/MacroRegimeTab';
import { LiquidityTab } from './components/tabs/LiquidityTab';
import { PnLAttributionTab } from './components/tabs/PnLAttributionTab';

// Modals
import { CalculationModal } from './components/CalculationModal';
import { RiskTreeModal } from './components/RiskTreeModal';
import { ReportModal } from './components/ReportModal';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('DASHBOARD');
  const [currentDemo, setCurrentDemo] = useState<DemoDataset>(DEMO_INSTITUTIONAL_PORTFOLIO);

  // Active Portfolio Positions & Corporate Exposures state
  const [positions, setPositions] = useState<PortfolioPosition[]>(DEMO_INSTITUTIONAL_PORTFOLIO.positions);
  const [exposures, setExposures] = useState<CorporateExposure[]>(DEMO_INSTITUTIONAL_PORTFOLIO.exposures);

  // Modal States
  const [selectedTrace, setSelectedTrace] = useState<CalculationTrace | null>(null);
  const [isRiskTreeOpen, setIsRiskTreeOpen] = useState<boolean>(false);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);

  // Market Quotes from Engine
  const quotes = marketEngine.getAllQuotes();

  const handleSelectDemo = (demo: DemoDataset) => {
    setCurrentDemo(demo);
    setPositions(demo.positions);
    setExposures(demo.exposures);
  };

  const handleOpenCalc = (traceId: string) => {
    const trace = provenanceRegistry.getTrace(traceId) || provenanceRegistry.getTrace('CALC-FWD-USD/SGD-1') || null;
    setSelectedTrace(trace);
  };

  const handleAddExposure = (newExp: CorporateExposure) => {
    setExposures((prev) => [newExp, ...prev]);
  };

  const navTabs = [
    { id: 'DASHBOARD', name: '01. DASHBOARD', icon: Activity },
    { id: 'NEER', name: '02. S$NEER ANALYTICS', icon: Cpu },
    { id: 'EXPOSURE', name: '03. EXPOSURE MATRIX', icon: BarChart3 },
    { id: 'TREASURY', name: '04. CORPORATE TREASURY', icon: Briefcase },
    { id: 'CURVES', name: '05. SORA & CURVES', icon: Layers },
    { id: 'VOLATILITY', name: '06. VOL SURFACE & PRICER', icon: Sliders },
    { id: 'HEDGE', name: '07. HEDGE LAB', icon: Shield },
    { id: 'SCENARIO', name: '08. SCENARIO LAB', icon: Zap },
    { id: 'MONTE_CARLO', name: '09. MONTE CARLO', icon: Play },
    { id: 'ASIA_FACTORS', name: '10. ASIA FX FACTORS', icon: Network },
    { id: 'REGIMES', name: '11. MACRO REGIMES', icon: Activity },
    { id: 'LIQUIDITY', name: '12. LIQUIDITY LADDER', icon: DollarSign },
    { id: 'ATTRIBUTION', name: '13. P&L ATTRIBUTION', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-emerald-500 selection:text-slate-950 flex flex-col">
      {/* Institutional Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-[1700px] mx-auto px-4 py-3 flex flex-col lg:flex-row items-center justify-between gap-4">
          {/* Logo & Platform Title */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center font-bold text-slate-950 shadow-lg shadow-emerald-950">
                RQ
              </div>
              <div>
                <h1 className="text-base font-bold tracking-tight text-white flex items-center gap-2 font-mono">
                  RHINOQUANT <span className="text-emerald-400">SGD RISK.OS</span>
                </h1>
                <p className="text-[10px] text-slate-400 font-mono tracking-widest uppercase">
                  Singapore Dollar Currency Risk, Hedging & Macro Platform
                </p>
              </div>
            </div>

            <div className="hidden xl:flex items-center gap-2 text-[10px] font-mono">
              <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded border border-slate-700">
                FUNC CCY: <span className="text-emerald-400 font-bold">SGD</span>
              </span>
              <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 rounded border border-emerald-500/30 font-bold">
                PROD INST-ENGINE
              </span>
            </div>
          </div>

          {/* Preset Selector & Action Buttons */}
          <div className="flex items-center gap-3 font-mono text-xs w-full lg:w-auto overflow-x-auto">
            {/* Signature Preset Dropdown */}
            <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800">
              <Database className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-400 text-[11px] uppercase font-bold">Demo:</span>
              <select
                value={currentDemo.id}
                onChange={(e) => {
                  if (e.target.value === DEMO_INSTITUTIONAL_PORTFOLIO.id) handleSelectDemo(DEMO_INSTITUTIONAL_PORTFOLIO);
                  else if (e.target.value === DEMO_CORPORATE_TREASURY.id) handleSelectDemo(DEMO_CORPORATE_TREASURY);
                  else handleSelectDemo(DEMO_REGIME_LAB);
                }}
                className="bg-transparent text-slate-200 font-bold outline-none cursor-pointer text-xs"
              >
                <option value={DEMO_INSTITUTIONAL_PORTFOLIO.id} className="bg-slate-900 text-slate-200">
                  1. Institutional SGD Portfolio
                </option>
                <option value={DEMO_CORPORATE_TREASURY.id} className="bg-slate-900 text-slate-200">
                  2. Singapore Corporate Treasury MNC
                </option>
                <option value={DEMO_REGIME_LAB.id} className="bg-slate-900 text-slate-200">
                  3. SGD Macro Regime & Stress Lab
                </option>
              </select>
            </div>

            {/* Global Actions */}
            <button
              onClick={() => setIsRiskTreeOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold transition-colors whitespace-nowrap"
            >
              <Network className="w-3.5 h-3.5 text-emerald-400" /> RISK TREE
            </button>

            <button
              onClick={() => setIsReportOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-all shadow-md shadow-emerald-950 whitespace-nowrap"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" /> GENERATE REPORT
            </button>
          </div>
        </div>

        {/* Tab Sub-Bar */}
        <div className="max-w-[1700px] mx-auto px-4 border-t border-slate-800/80 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1 py-1 font-mono text-xs whitespace-nowrap">
            {navTabs.map((t) => {
              const Icon = t.icon;
              const isActive = activeTab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md font-semibold transition-all ${
                    isActive
                      ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <span>{t.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto px-4 py-6">
        {activeTab === 'DASHBOARD' && (
          <DashboardTab
            quotes={quotes}
            positions={positions}
            onOpenCalc={handleOpenCalc}
            onOpenRiskTree={() => setIsRiskTreeOpen(true)}
            onSelectTab={setActiveTab}
          />
        )}

        {activeTab === 'NEER' && <SNEERTab onOpenCalc={handleOpenCalc} />}

        {activeTab === 'EXPOSURE' && (
          <ExposureMatrixTab onOpenCalc={handleOpenCalc} onOpenRiskTree={() => setIsRiskTreeOpen(true)} />
        )}

        {activeTab === 'TREASURY' && (
          <CorporateTreasuryTab
            exposures={exposures}
            onAddExposure={handleAddExposure}
            onOpenCalc={handleOpenCalc}
          />
        )}

        {activeTab === 'CURVES' && <CurvesTab onOpenCalc={handleOpenCalc} />}

        {activeTab === 'VOLATILITY' && <VolatilityTab onOpenCalc={handleOpenCalc} />}

        {activeTab === 'HEDGE' && <HedgeLabTab onOpenCalc={handleOpenCalc} />}

        {activeTab === 'SCENARIO' && <ScenarioTab positions={positions} onOpenCalc={handleOpenCalc} />}

        {activeTab === 'MONTE_CARLO' && <MonteCarloTab onOpenCalc={handleOpenCalc} />}

        {activeTab === 'ASIA_FACTORS' && <AsiaFXFactorTab onOpenCalc={handleOpenCalc} />}

        {activeTab === 'REGIMES' && <MacroRegimeTab positions={positions} onOpenCalc={handleOpenCalc} />}

        {activeTab === 'LIQUIDITY' && <LiquidityTab onOpenCalc={handleOpenCalc} />}

        {activeTab === 'ATTRIBUTION' && <PnLAttributionTab onOpenCalc={handleOpenCalc} />}
      </main>

      {/* Institutional Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/80 py-4 text-xs font-mono text-slate-400">
        <div className="max-w-[1700px] mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            <span className="font-bold text-slate-200">RHINOQUANT SGD RISK.OS v3.4</span>
            <span>·</span>
            <span>PROVENANCE REGISTRY: ACTIVE</span>
            <span>·</span>
            <span className="text-emerald-400">DETERMINISTIC SYNTHETIC MARKET ENGINE</span>
          </div>

          <div className="text-slate-500 text-[11px]">
            Institutional FX Quantitative Platform · Singapore Dollar (SGD) Centralized FX Risk Operating System
          </div>
        </div>
      </footer>

      {/* Audit Modals */}
      <CalculationModal trace={selectedTrace} onClose={() => setSelectedTrace(null)} />
      <RiskTreeModal
        isOpen={isRiskTreeOpen}
        onClose={() => setIsRiskTreeOpen(false)}
        positions={positions}
        onOpenCalc={handleOpenCalc}
      />
      <ReportModal isOpen={isReportOpen} onClose={() => setIsReportOpen(false)} />
    </div>
  );
}

export default App;
