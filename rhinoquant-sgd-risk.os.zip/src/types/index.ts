/**
 * @file src/types/index.ts
 * RHINOQUANT SGD RISK.OS — Primary Domain Models & Types
 */

export type Currency =
  | 'SGD'
  | 'USD'
  | 'CNH'
  | 'CNY'
  | 'JPY'
  | 'EUR'
  | 'GBP'
  | 'AUD'
  | 'MYR'
  | 'IDR'
  | 'THB'
  | 'KRW'
  | 'TWD'
  | 'INR'
  | 'HKD';

export type MarketDataState = 'LIVE' | 'HISTORICAL' | 'CACHED' | 'SYNTHETIC' | 'ESTIMATED' | 'MODELLED';

export interface FXQuote {
  pair: string; // e.g. "USD/SGD"
  baseCurrency: Currency;
  quoteCurrency: Currency;
  spotMid: number;
  bid: number;
  ask: number;
  forwardPoints1M: number;
  forwardPoints3M: number;
  forwardPoints6M: number;
  forwardPoints1Y: number;
  dailyChange: number;
  dailyChangePct: number;
  timestamp: string;
  source: string;
  fixing: string;
  marketState: MarketDataState;
}

export interface SNEERBasketComponent {
  currency: Currency;
  weightPct: number;
  fxRateVsSGD: number;
  contributionPct: number;
  sensitivity: number;
}

export interface SNEERState {
  indexValue: number;
  estimatedCentre: number;
  bandWidthPct: number; // e.g. 2.0%
  slopePctPA: number; // e.g. 1.5%
  distanceFromCentrePct: number;
  regime: 'APPRECIATING_CENTER' | 'NEUTRAL' | 'DEPRECIATING_CENTER';
  regimeStatusText: string;
  rollingVol30D: number;
  basket: SNEERBasketComponent[];
  historicalObservations: Array<{ date: string; observed: number; estimatedCentre: number; upperBand: number; lowerBand: number }>;
  uncertainty: string; // "UNOBSERVED / ESTIMATED MODEL"
  timestamp: string;
}

export interface CurvePoint {
  tenor: string; // "ON", "1M", "3M", "6M", "1Y", "2Y", "5Y", "10Y"
  days: number;
  ratePct: number;
  zeroRatePct: number;
  discountFactor: number;
  forwardRatePct: number;
}

export interface RateCurve {
  id: string;
  currency: Currency;
  benchmark: string; // "SORA_OIS", "USD_SOFR", "USD_SGD_BASIS"
  curveDate: string;
  points: CurvePoint[];
  bootstrappingMethod: string;
  interpolationMethod: string;
  discountingMethod: string;
  modelVersion: string;
  marketState: MarketDataState;
}

export type ExposureBucket = '0-30D' | '31-90D' | '3-6M' | '6-12M' | '1-2Y' | '2-5Y' | '5Y+';

export type ExposureDirection = 'RECEIVABLE' | 'PAYABLE' | 'ASSET' | 'LIABILITY' | 'REVENUE' | 'OPEX' | 'DEBT';

export type ExposureType = 'TRANSACTION' | 'TRANSLATION' | 'ECONOMIC' | 'BALANCE_SHEET' | 'FORECAST';

export interface CorporateExposure {
  id: string;
  entityName: string;
  businessUnit: string;
  currency: Currency;
  foreignAmount: number;
  sgdEquivalent: number;
  exposureType: ExposureType;
  direction: ExposureDirection;
  bucket: ExposureBucket;
  maturityDate: string;
  naturalHedgeAmount: number;
  hedgedAmount: number;
  unhedgedAmount: number;
  hedgeRatioPct: number;
  fxSensitivitySGD: number; // Delta per 1% FX change
  description: string;
}

export interface PortfolioPosition {
  id: string;
  instrumentName: string;
  assetClass: 'EQUITY' | 'BOND' | 'LOAN' | 'CASH' | 'DERIVATIVE' | 'TRADE_PAYABLE' | 'TRADE_RECEIVABLE' | 'SUB_EQUITY';
  legalEntity: string;
  country: string;
  currency: Currency;
  notionalForeign: number;
  marketValueSGD: number;
  costSGD: number;
  maturityDate: string;
  fxExposureType: ExposureType;
  hedgeStatus: 'UNHEDGED' | 'PARTIALLY_HEDGED' | 'FULLY_HEDGED';
  hedgeId?: string;
}

export interface CurrencyRiskRow {
  currency: Currency;
  grossExposureSGD: number;
  longExposureSGD: number;
  shortExposureSGD: number;
  hedgedAmountSGD: number;
  netExposureSGD: number;
  hedgeRatioPct: number;
  deltaSGD: number;
  vegaSGD: number;
  var1D99SGD: number;
  es1D99SGD: number;
  todayPnLSGD: number;
  averageMaturityDays: number;
}

export interface RiskMeasure {
  deltaSGD: number;
  gammaSGD: number;
  vegaSGD: number;
  thetaSGD: number;
  carrySGD: number;
  var1D95: number;
  var1D99: number;
  var10D99: number;
  expectedShortfall99: number;
  parametricVaR: number;
  historicalVaR: number;
  monteCarloVaR: number;
  stressVaR: number;
  model: string;
  horizon: string;
  confidence: string;
  dataWindow: string;
  assumptions: string;
  timestamp: string;
}

export interface VolatilityPoint {
  tenor: string;
  days: number;
  atmVolPct: number;
  rr25DeltaPct: number;
  bf25DeltaPct: number;
  rr10DeltaPct: number;
  bf10DeltaPct: number;
}

export interface VolatilitySurface {
  pair: string; // e.g. "USD/SGD"
  asOfDate: string;
  points: VolatilityPoint[];
  strikeGrid: number[]; // e.g. [1.28, 1.30, 1.32, 1.34, 1.36, 1.38, 1.40]
  volGrid: number[][]; // tenor x strike
}

export interface HedgeStructure {
  id: string;
  name: string;
  instrumentType: 'SPOT' | 'FORWARD' | 'FX_SWAP' | 'FUTURES' | 'OPTION_VANILLA' | 'COLLAR' | 'RISK_REVERSAL' | 'CROSS_CURRENCY_SWAP';
  notionalForeign: number;
  notionalSGD: number;
  strikeRate: number;
  tenor: string;
  hedgeRatioPct: number;
  upfrontCostSGD: number;
  cashflowCertaintyScore: number; // 0 to 100
  pnlSensitivity: number;
  carryImpactSGD: number;
  residualDeltaSGD: number;
  estimatedEffectivenessPct: number;
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  category: 'CURRENCY_SHOCK' | 'RATES_SHOCK' | 'MACRO_CRISIS' | 'CUSTOM';
  shocks: {
    usdSgdPct?: number;
    sgdCnhPct?: number;
    sgdMyrPct?: number;
    sgdJpyPct?: number;
    sgdEurPct?: number;
    soraBp?: number;
    sofrBp?: number;
    volatilityPct?: number;
  };
}

export interface ScenarioResult {
  scenarioId: string;
  scenarioName: string;
  portfolioValueBeforeSGD: number;
  portfolioValueAfterSGD: number;
  pnlImpactSGD: number;
  pnlImpactPct: number;
  unhedgedPnLSGD: number;
  hedgedPnLSGD: number;
  hedgeEffectivenessOffsetPct: number;
  varPostShock1D99SGD: number;
  liquidityCallSGD: number;
}

export interface MonteCarloResult {
  seed: number;
  numberOfPaths: number;
  timeSteps: number;
  horizonDays: number;
  modelName: string;
  meanPnLSGD: number;
  stdDevPnLSGD: number;
  var95SGD: number;
  var99SGD: number;
  expectedShortfall99SGD: number;
  paths: number[][]; // sample paths
  timestamp: string;
}

export interface FactorExposure {
  factorName: string;
  varianceExplainedPct: number;
  betaToFactor: number;
  driverDescription: string;
}

export interface LiquidityBucketData {
  bucket: 'TODAY' | '1D' | '1W' | '1M' | '3M' | '6M' | '1Y';
  sgdInflows: number;
  sgdOutflows: number;
  netSgdPosition: number;
  foreignSettlementSGD: number;
  potentialMarginCallSGD: number;
  cumulativeLiquiditySGD: number;
}

export interface PnLAttributionItem {
  category: 'SPOT' | 'FORWARD_POINTS' | 'CARRY' | 'VOLATILITY' | 'OPTION_VEGA' | 'OPTION_GAMMA' | 'RATES' | 'BASIS' | 'NEW_TRADES' | 'FX_TRANSLATION';
  amountSGD: number;
  explanation: string;
}

export interface CalculationTrace {
  id: string;
  label: string;
  outputValue: string | number;
  currency?: string;
  methodology: string;
  modelVersion: string;
  timestamp: string;
  inputs: Record<string, string | number>;
  intermediateSteps: Array<{ stepName: string; formula: string; result: string | number }>;
  marketDataProvenance: {
    source: string;
    asOf: string;
    dataState: MarketDataState;
  };
}
