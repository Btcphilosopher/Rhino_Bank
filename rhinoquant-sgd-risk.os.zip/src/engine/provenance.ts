/**
 * @file src/engine/provenance.ts
 * RHINOQUANT SGD RISK.OS — Calculation Audit Trail & Provenance Registry
 */

import { CalculationTrace, MarketDataState } from '../types';

class ProvenanceRegistry {
  private registry = new Map<string, CalculationTrace>();

  public register(trace: CalculationTrace): string {
    this.registry.set(trace.id, trace);
    return trace.id;
  }

  public getTrace(id: string): CalculationTrace | undefined {
    return this.registry.get(id);
  }

  public get(id: string): CalculationTrace | undefined {
    return this.registry.get(id);
  }

  public createForwardTrace(params: {
    pair: string;
    spot: number;
    rBase: number;
    rQuote: number;
    tenorDays: number;
    forwardPoints: number;
    forwardRate: number;
    dataState?: MarketDataState;
  }): string {
    const id = `CALC-FWD-${params.pair}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const trace: CalculationTrace = {
      id,
      label: `${params.pair} ${params.tenorDays}D Forward Rate & Covered Interest Parity`,
      outputValue: params.forwardRate.toFixed(5),
      currency: 'SGD',
      methodology: 'Covered Interest Rate Parity (Exact Compounding)',
      modelVersion: 'RQ-FX-FWD-v2.4',
      timestamp: new Date().toISOString(),
      inputs: {
        'Spot Rate (S)': params.spot,
        'SGD Base Discount/Yield (r_dom)': `${(params.rQuote * 100).toFixed(3)}%`,
        'USD Foreign Discount/Yield (r_for)': `${(params.rBase * 100).toFixed(3)}%`,
        'Tenor (Days)': params.tenorDays,
        'Day Count Convention': 'ACT/365 vs ACT/360',
      },
      intermediateSteps: [
        {
          stepName: 'Day Fraction Calculation',
          formula: 'T = Tenor / 365',
          result: `${(params.tenorDays / 365).toFixed(6)} years`,
        },
        {
          stepName: 'Domestic Discount Factor (SGD SORA OIS)',
          formula: 'DF_SGD = exp(-r_sgd * T)',
          result: Math.exp(-params.rQuote * (params.tenorDays / 365)).toFixed(6),
        },
        {
          stepName: 'Foreign Discount Factor (USD SOFR)',
          formula: 'DF_USD = exp(-r_usd * T)',
          result: Math.exp(-params.rBase * (params.tenorDays / 365)).toFixed(6),
        },
        {
          stepName: 'Forward Rate Parity Ratio',
          formula: 'F = S * (DF_USD / DF_SGD)',
          result: params.forwardRate.toFixed(5),
        },
        {
          stepName: 'Forward Points (in pips)',
          formula: '(F - S) * 10,000',
          result: params.forwardPoints.toFixed(2),
        },
      ],
      marketDataProvenance: {
        source: 'MAS / Refinitiv SGD SORA & USD SOFR Benchmarks',
        asOf: new Date().toISOString(),
        dataState: params.dataState || 'SYNTHETIC',
      },
    };

    this.register(trace);
    return id;
  }

  public createVaRTrace(params: {
    portfolioValue: number;
    horizonDays: number;
    confidencePct: number;
    portfolioVolPct: number;
    varValueSGD: number;
    esValueSGD: number;
    model: string;
  }): string {
    const id = `CALC-VAR-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const zScore = params.confidencePct === 99 ? 2.326 : params.confidencePct === 97.5 ? 1.96 : 1.645;
    const trace: CalculationTrace = {
      id,
      label: `${params.horizonDays}D ${params.confidencePct}% Value at Risk (${params.model})`,
      outputValue: `SGD ${params.varValueSGD.toLocaleString('en-SG', { maximumFractionDigits: 0 })}`,
      currency: 'SGD',
      methodology: `Parametric Delta-Normal Variance-Covariance Matrix (${params.model})`,
      modelVersion: 'RQ-RISK-VAR-v3.1',
      timestamp: new Date().toISOString(),
      inputs: {
        'Portfolio Value (V)': `SGD ${params.portfolioValue.toLocaleString('en-SG')}`,
        'Holding Horizon (t)': `${params.horizonDays} Day(s)`,
        'Confidence Level (1 - α)': `${params.confidencePct}%`,
        'Gaussian Z-Score (z_α)': zScore,
        'Annualized Portfolio Volatility (σ)': `${(params.portfolioVolPct * 100).toFixed(2)}%`,
        'Daily Portfolio Volatility (σ_daily)': `${((params.portfolioVolPct / Math.sqrt(252)) * 100).toFixed(3)}%`,
      },
      intermediateSteps: [
        {
          stepName: 'Horizon Volatility Scaling',
          formula: 'σ_horizon = σ_daily * sqrt(horizonDays)',
          result: `${((params.portfolioVolPct / Math.sqrt(252)) * Math.sqrt(params.horizonDays) * 100).toFixed(4)}%`,
        },
        {
          stepName: 'Value at Risk Calculation',
          formula: 'VaR = V * z_α * σ_horizon',
          result: `SGD ${params.varValueSGD.toLocaleString('en-SG', { maximumFractionDigits: 0 })}`,
        },
        {
          stepName: 'Expected Shortfall (Tail Conditional VaR)',
          formula: 'ES = V * (exp(-z_α^2 / 2) / (sqrt(2*π) * α)) * σ_horizon',
          result: `SGD ${params.esValueSGD.toLocaleString('en-SG', { maximumFractionDigits: 0 })}`,
        },
      ],
      marketDataProvenance: {
        source: 'Historical Covariance Matrix (252-day window, exponential decay λ=0.94)',
        asOf: new Date().toISOString(),
        dataState: 'SYNTHETIC',
      },
    };

    this.register(trace);
    return id;
  }

  public createBlackScholesTrace(params: {
    pair: string;
    spot: number;
    strike: number;
    tenorYears: number;
    volatilityPct: number;
    rDom: number;
    rFor: number;
    optionType: 'CALL' | 'PUT';
    priceSGD: number;
    delta: number;
    gamma: number;
    vega: number;
    theta: number;
  }): string {
    const id = `CALC-BS-${params.pair}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const trace: CalculationTrace = {
      id,
      label: `Garman-Kohlhagen FX Option ${params.optionType} K=${params.strike} (${params.pair})`,
      outputValue: `SGD ${params.priceSGD.toFixed(4)} per unit`,
      currency: 'SGD',
      methodology: 'Garman-Kohlhagen FX Option Model (Continuous Dividend Yield = Foreign Interest Rate)',
      modelVersion: 'RQ-VOL-BS-v1.9',
      timestamp: new Date().toISOString(),
      inputs: {
        'Spot Price (S)': params.spot,
        'Strike Price (K)': params.strike,
        'Tenor Time to Expiry (T)': `${params.tenorYears.toFixed(3)} Years`,
        'Implied Volatility (σ)': `${(params.volatilityPct * 100).toFixed(2)}%`,
        'Domestic Rate (SGD SORA r_d)': `${(params.rDom * 100).toFixed(3)}%`,
        'Foreign Rate (USD SOFR r_f)': `${(params.rFor * 100).toFixed(3)}%`,
      },
      intermediateSteps: [
        {
          stepName: 'd1 Term',
          formula: 'd1 = [ln(S/K) + (r_d - r_f + 0.5*σ^2)*T] / [σ*sqrt(T)]',
          result: 'Calculated internally',
        },
        {
          stepName: 'd2 Term',
          formula: 'd2 = d1 - σ*sqrt(T)',
          result: 'Calculated internally',
        },
        {
          stepName: 'Option Premium',
          formula: params.optionType === 'CALL' ? 'S*exp(-r_f*T)*N(d1) - K*exp(-r_d*T)*N(d2)' : 'K*exp(-r_d*T)*N(-d2) - S*exp(-r_f*T)*N(-d1)',
          result: params.priceSGD.toFixed(4),
        },
        {
          stepName: 'FX Delta (Spot Sensitivity)',
          formula: '∂V / ∂S',
          result: params.delta.toFixed(4),
        },
        {
          stepName: 'FX Gamma (Curvature Sensitivity)',
          formula: '∂²V / ∂S²',
          result: params.gamma.toFixed(6),
        },
        {
          stepName: 'FX Vega (Volatility Sensitivity per 1% vol)',
          formula: '∂V / ∂σ',
          result: params.vega.toFixed(4),
        },
        {
          stepName: 'FX Theta (Time Decay per day)',
          formula: '∂V / ∂t',
          result: params.theta.toFixed(6),
        },
      ],
      marketDataProvenance: {
        source: 'USD/SGD Volatility Surface & SORA/SOFR Yield Curves',
        asOf: new Date().toISOString(),
        dataState: 'SYNTHETIC',
      },
    };

    this.register(trace);
    return id;
  }
}

export const provenanceRegistry = new ProvenanceRegistry();
