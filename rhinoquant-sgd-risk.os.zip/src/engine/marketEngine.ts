/**
 * @file src/engine/marketEngine.ts
 * RHINOQUANT SGD RISK.OS — Singapore FX, S$NEER, Interest Rate & Market Data Engine
 */

import {
  Currency,
  FXQuote,
  LiquidityBucketData,
  MarketDataState,
  RateCurve,
  SNEERState,
  VolatilitySurface,
} from '../types';

export class MarketEngine {
  private marketStateMode: MarketDataState = 'SYNTHETIC';
  private quotes: Map<string, FXQuote> = new Map();
  private sneerState!: SNEERState;
  private soraCurve!: RateCurve;
  private sofrCurve!: RateCurve;
  private basisCurve!: RateCurve;
  private volSurface!: VolatilitySurface;

  constructor() {
    this.initDefaultMarket();
  }

  public setMarketDataState(mode: MarketDataState) {
    this.marketStateMode = mode;
    this.quotes.forEach((q) => (q.marketState = mode));
    this.soraCurve.marketState = mode;
    this.sofrCurve.marketState = mode;
    this.basisCurve.marketState = mode;
  }

  public getMarketDataState(): MarketDataState {
    return this.marketStateMode;
  }

  private initDefaultMarket() {
    const timestamp = new Date().toISOString();

    // 14 SGD currency pairs with precise quotation conventions
    const rawQuotes: Array<{
      pair: string;
      base: Currency;
      quote: Currency;
      mid: number;
      spread: number;
      fwd1M: number;
      fwd3M: number;
      fwd6M: number;
      fwd1Y: number;
      changePct: number;
    }> = [
      { pair: 'USD/SGD', base: 'USD', quote: 'SGD', mid: 1.3425, spread: 0.0003, fwd1M: -12.5, fwd3M: -36.2, fwd6M: -68.5, fwd1Y: -132.0, changePct: -0.15 },
      { pair: 'SGD/CNH', base: 'SGD', quote: 'CNH', mid: 5.3120, spread: 0.0020, fwd1M: 18.0, fwd3M: 52.0, fwd6M: 104.0, fwd1Y: 210.0, changePct: +0.22 },
      { pair: 'SGD/CNY', base: 'SGD', quote: 'CNY', mid: 5.3080, spread: 0.0025, fwd1M: 17.5, fwd3M: 50.0, fwd6M: 100.0, fwd1Y: 202.0, changePct: +0.20 },
      { pair: 'SGD/JPY', base: 'SGD', quote: 'JPY', mid: 113.82, spread: 0.0800, fwd1M: -28.0, fwd3M: -82.0, fwd6M: -160.0, fwd1Y: -310.0, changePct: +0.45 },
      { pair: 'SGD/EUR', base: 'SGD', quote: 'EUR', mid: 0.6825, spread: 0.0004, fwd1M: 2.1, fwd3M: 6.2, fwd6M: 12.0, fwd1Y: 23.5, changePct: -0.08 },
      { pair: 'SGD/GBP', base: 'SGD', quote: 'GBP', mid: 0.5842, spread: 0.0003, fwd1M: 1.8, fwd3M: 5.1, fwd6M: 9.8, fwd1Y: 19.2, changePct: +0.05 },
      { pair: 'SGD/AUD', base: 'SGD', quote: 'AUD', mid: 1.1285, spread: 0.0008, fwd1M: -4.2, fwd3M: -12.1, fwd6M: -23.5, fwd1Y: -45.0, changePct: -0.32 },
      { pair: 'SGD/MYR', base: 'SGD', quote: 'MYR', mid: 3.3150, spread: 0.0015, fwd1M: 12.0, fwd3M: 35.0, fwd6M: 68.0, fwd1Y: 130.0, changePct: +0.12 },
      { pair: 'SGD/IDR', base: 'SGD', quote: 'IDR', mid: 11780.0, spread: 15.0, fwd1M: 120.0, fwd3M: 350.0, fwd6M: 690.0, fwd1Y: 1350.0, changePct: -0.18 },
      { pair: 'SGD/THB', base: 'SGD', quote: 'THB', mid: 27.150, spread: 0.025, fwd1M: 15.0, fwd3M: 42.0, fwd6M: 80.0, fwd1Y: 155.0, changePct: +0.10 },
      { pair: 'SGD/KRW', base: 'SGD', quote: 'KRW', mid: 1028.5, spread: 1.20, fwd1M: 85.0, fwd3M: 240.0, fwd6M: 460.0, fwd1Y: 890.0, changePct: -0.25 },
      { pair: 'SGD/TWD', base: 'SGD', quote: 'TWD', mid: 23.850, spread: 0.030, fwd1M: 10.0, fwd3M: 28.0, fwd6M: 54.0, fwd1Y: 102.0, changePct: +0.08 },
      { pair: 'SGD/INR', base: 'SGD', quote: 'INR', mid: 62.850, spread: 0.050, fwd1M: 32.0, fwd3M: 92.0, fwd6M: 180.0, fwd1Y: 350.0, changePct: -0.10 },
      { pair: 'SGD/HKD', base: 'SGD', quote: 'HKD', mid: 5.8050, spread: 0.0020, fwd1M: -8.5, fwd3M: -25.0, fwd6M: -48.0, fwd1Y: -92.0, changePct: -0.14 },
    ];

    rawQuotes.forEach((q) => {
      this.quotes.set(q.pair, {
        pair: q.pair,
        baseCurrency: q.base,
        quoteCurrency: q.quote,
        spotMid: q.mid,
        bid: q.mid - q.spread / 2,
        ask: q.mid + q.spread / 2,
        forwardPoints1M: q.fwd1M,
        forwardPoints3M: q.fwd3M,
        forwardPoints6M: q.fwd6M,
        forwardPoints1Y: q.fwd1Y,
        dailyChange: (q.mid * q.changePct) / 100,
        dailyChangePct: q.changePct,
        timestamp,
        source: 'MAS / SGX OTC Benchmark Fixing',
        fixing: '11:00 AM SGT MAS Fixing',
        marketState: this.marketStateMode,
      });
    });

    // S$NEER Policy Band & Basket State
    this.sneerState = {
      indexValue: 101.35,
      estimatedCentre: 100.0,
      bandWidthPct: 2.0, // +/- 2.0%
      slopePctPA: 1.5, // 1.5% annual appreciation
      distanceFromCentrePct: 1.35,
      regime: 'APPRECIATING_CENTER',
      regimeStatusText: 'GRADUAL APPRECIATION PATH (+1.5% p.a., Upper Band at 102.0, Lower Band at 98.0)',
      rollingVol30D: 2.85,
      basket: [
        { currency: 'USD', weightPct: 22.0, fxRateVsSGD: 1.3425, contributionPct: 22.3, sensitivity: -0.22 },
        { currency: 'CNH', weightPct: 18.0, fxRateVsSGD: 5.312, contributionPct: 17.8, sensitivity: +0.18 },
        { currency: 'MYR', weightPct: 14.0, fxRateVsSGD: 3.315, contributionPct: 13.9, sensitivity: +0.14 },
        { currency: 'EUR', weightPct: 11.0, fxRateVsSGD: 0.6825, contributionPct: 11.2, sensitivity: +0.11 },
        { currency: 'JPY', weightPct: 10.0, fxRateVsSGD: 113.82, contributionPct: 9.8, sensitivity: +0.10 },
        { currency: 'AUD', weightPct: 6.0, fxRateVsSGD: 1.1285, contributionPct: 6.1, sensitivity: +0.06 },
        { currency: 'GBP', weightPct: 5.0, fxRateVsSGD: 0.5842, contributionPct: 5.0, sensitivity: +0.05 },
        { currency: 'KRW', weightPct: 4.0, fxRateVsSGD: 1028.5, contributionPct: 4.0, sensitivity: +0.04 },
        { currency: 'TWD', weightPct: 4.0, fxRateVsSGD: 23.85, contributionPct: 3.9, sensitivity: +0.04 },
        { currency: 'THB', weightPct: 3.0, fxRateVsSGD: 27.15, contributionPct: 3.0, sensitivity: +0.03 },
        { currency: 'IDR', weightPct: 3.0, fxRateVsSGD: 11780.0, contributionPct: 3.0, sensitivity: +0.03 },
      ],
      historicalObservations: Array.from({ length: 60 }).map((_, i) => {
        const d = new Date();
        d.setDate(d.getDate() - (59 - i));
        const dateStr = d.toISOString().split('T')[0];
        const trend = 100.0 + (i / 60) * 0.25;
        const noise = Math.sin(i / 4) * 0.35 + (Math.cos(i / 7) * 0.2);
        const obs = trend + 1.1 + noise;
        return {
          date: dateStr,
          observed: Number(obs.toFixed(2)),
          estimatedCentre: Number(trend.toFixed(2)),
          upperBand: Number((trend * 1.02).toFixed(2)),
          lowerBand: Number((trend * 0.98).toFixed(2)),
        };
      }),
      uncertainty: 'UNOBSERVED / ESTIMATED MODEL (MAS Policy Parameters inferred via Econometric Kalman Filtering)',
      timestamp,
    };

    // SGD SORA OIS Curve
    this.soraCurve = {
      id: 'CURVE-SGD-SORA-OIS',
      currency: 'SGD',
      benchmark: 'SORA Overnight Index Swap',
      curveDate: timestamp.split('T')[0],
      bootstrappingMethod: 'Monotone Convex Zero Rate Interpolation',
      interpolationMethod: 'Cubic Spline on Log Discount Factors',
      discountingMethod: 'Continuous Compounding DF = exp(-r*t)',
      modelVersion: 'RQ-RATES-SORA-v2.1',
      marketState: this.marketStateMode,
      points: [
        { tenor: 'ON', days: 1, ratePct: 2.92, zeroRatePct: 2.92, discountFactor: 0.99992, forwardRatePct: 2.92 },
        { tenor: '1M', days: 30, ratePct: 2.98, zeroRatePct: 2.98, discountFactor: 0.99755, forwardRatePct: 2.98 },
        { tenor: '3M', days: 90, ratePct: 3.05, zeroRatePct: 3.04, discountFactor: 0.99250, forwardRatePct: 3.08 },
        { tenor: '6M', days: 180, ratePct: 3.12, zeroRatePct: 3.10, discountFactor: 0.98472, forwardRatePct: 3.16 },
        { tenor: '1Y', days: 365, ratePct: 3.18, zeroRatePct: 3.15, discountFactor: 0.96898, forwardRatePct: 3.20 },
        { tenor: '2Y', days: 730, ratePct: 3.02, zeroRatePct: 3.00, discountFactor: 0.94176, forwardRatePct: 2.85 },
        { tenor: '5Y', days: 1825, ratePct: 2.85, zeroRatePct: 2.82, discountFactor: 0.86849, forwardRatePct: 2.70 },
        { tenor: '10Y', days: 3650, ratePct: 2.78, zeroRatePct: 2.75, discountFactor: 0.75957, forwardRatePct: 2.68 },
      ],
    };

    // USD SOFR Curve
    this.sofrCurve = {
      id: 'CURVE-USD-SOFR',
      currency: 'USD',
      benchmark: 'SOFR OIS',
      curveDate: timestamp.split('T')[0],
      bootstrappingMethod: 'Linear Zero Rate',
      interpolationMethod: 'Log-Linear DF',
      discountingMethod: 'ACT/360 Continuous Compounding',
      modelVersion: 'RQ-RATES-SOFR-v1.8',
      marketState: this.marketStateMode,
      points: [
        { tenor: 'ON', days: 1, ratePct: 4.55, zeroRatePct: 4.55, discountFactor: 0.99987, forwardRatePct: 4.55 },
        { tenor: '1M', days: 30, ratePct: 4.52, zeroRatePct: 4.52, discountFactor: 0.99625, forwardRatePct: 4.52 },
        { tenor: '3M', days: 90, ratePct: 4.48, zeroRatePct: 4.47, discountFactor: 0.98892, forwardRatePct: 4.44 },
        { tenor: '6M', days: 180, ratePct: 4.38, zeroRatePct: 4.36, discountFactor: 0.97843, forwardRatePct: 4.25 },
        { tenor: '1Y', days: 365, ratePct: 4.25, zeroRatePct: 4.22, discountFactor: 0.95868, forwardRatePct: 4.08 },
        { tenor: '2Y', days: 730, ratePct: 4.05, zeroRatePct: 4.02, discountFactor: 0.92228, forwardRatePct: 3.82 },
        { tenor: '5Y', days: 1825, ratePct: 3.95, zeroRatePct: 3.92, discountFactor: 0.82201, forwardRatePct: 3.85 },
        { tenor: '10Y', days: 3650, ratePct: 4.12, zeroRatePct: 4.08, discountFactor: 0.66500, forwardRatePct: 4.24 },
      ],
    };

    // USD/SGD Cross-Currency Basis Curve
    this.basisCurve = {
      id: 'CURVE-USD-SGD-BASIS',
      currency: 'SGD',
      benchmark: 'USD/SGD Cross-Currency Basis Swap (bp)',
      curveDate: timestamp.split('T')[0],
      bootstrappingMethod: 'Direct Par Quote Parity',
      interpolationMethod: 'Linear Par Basis',
      discountingMethod: 'Combined SORA + Basis Spread',
      modelVersion: 'RQ-RATES-BASIS-v1.4',
      marketState: this.marketStateMode,
      points: [
        { tenor: '1M', days: 30, ratePct: -0.12, zeroRatePct: -0.12, discountFactor: 0.9999, forwardRatePct: -0.12 }, // -12 bps
        { tenor: '3M', days: 90, ratePct: -0.18, zeroRatePct: -0.18, discountFactor: 0.9995, forwardRatePct: -0.18 }, // -18 bps
        { tenor: '6M', days: 180, ratePct: -0.22, zeroRatePct: -0.22, discountFactor: 0.9989, forwardRatePct: -0.22 }, // -22 bps
        { tenor: '1Y', days: 365, ratePct: -0.25, zeroRatePct: -0.25, discountFactor: 0.9975, forwardRatePct: -0.25 }, // -25 bps
        { tenor: '2Y', days: 730, ratePct: -0.28, zeroRatePct: -0.28, discountFactor: 0.9944, forwardRatePct: -0.28 }, // -28 bps
        { tenor: '5Y', days: 1825, ratePct: -0.32, zeroRatePct: -0.32, discountFactor: 0.9840, forwardRatePct: -0.32 }, // -32 bps
      ],
    };

    // USD/SGD Volatility Surface
    this.volSurface = {
      pair: 'USD/SGD',
      asOfDate: timestamp.split('T')[0],
      points: [
        { tenor: '1M', days: 30, atmVolPct: 4.85, rr25DeltaPct: -0.45, bf25DeltaPct: 0.22, rr10DeltaPct: -0.82, bf10DeltaPct: 0.54 },
        { tenor: '3M', days: 90, atmVolPct: 5.10, rr25DeltaPct: -0.52, bf25DeltaPct: 0.25, rr10DeltaPct: -0.95, bf10DeltaPct: 0.61 },
        { tenor: '6M', days: 180, atmVolPct: 5.30, rr25DeltaPct: -0.58, bf25DeltaPct: 0.28, rr10DeltaPct: -1.08, bf10DeltaPct: 0.68 },
        { tenor: '1Y', days: 365, atmVolPct: 5.55, rr25DeltaPct: -0.65, bf25DeltaPct: 0.32, rr10DeltaPct: -1.22, bf10DeltaPct: 0.78 },
        { tenor: '2Y', days: 730, atmVolPct: 5.85, rr25DeltaPct: -0.72, bf25DeltaPct: 0.38, rr10DeltaPct: -1.35, bf10DeltaPct: 0.88 },
      ],
      strikeGrid: [1.28, 1.30, 1.32, 1.3425, 1.36, 1.38, 1.40],
      volGrid: [
        [5.35, 5.08, 4.90, 4.85, 4.92, 5.15, 5.48], // 1M
        [5.62, 5.34, 5.16, 5.10, 5.18, 5.42, 5.75], // 3M
        [5.85, 5.56, 5.38, 5.30, 5.39, 5.65, 6.02], // 6M
        [6.15, 5.82, 5.62, 5.55, 5.65, 5.92, 6.35], // 1Y
        [6.50, 6.15, 5.94, 5.85, 5.96, 6.25, 6.70], // 2Y
      ],
    };
  }

  public getQuote(pair: string): FXQuote | undefined {
    return this.quotes.get(pair);
  }

  public getAllQuotes(): FXQuote[] {
    return Array.from(this.quotes.values());
  }

  public getSNEERState(): SNEERState {
    return this.sneerState;
  }

  public getSoraCurve(): RateCurve {
    return this.soraCurve;
  }

  public getSofrCurve(): RateCurve {
    return this.sofrCurve;
  }

  public getBasisCurve(): RateCurve {
    return this.basisCurve;
  }

  public getVolSurface(): VolatilitySurface {
    return this.volSurface;
  }

  public convertToSGD(amount: number, currency: Currency): number {
    if (currency === 'SGD') return amount;
    if (currency === 'USD') {
      const q = this.getQuote('USD/SGD');
      return amount * (q ? q.spotMid : 1.3425);
    }
    // Cross conversion
    const pairKey = `SGD/${currency}`;
    const q = this.getQuote(pairKey);
    if (q) {
      // e.g. SGD/MYR = 3.3150 means 1 SGD = 3.315 MYR -> MYR amount / 3.315 = SGD
      return amount / q.spotMid;
    }
    return amount;
  }

  public getLiquidityLadder(): LiquidityBucketData[] {
    return [
      { bucket: 'TODAY', sgdInflows: 15400000, sgdOutflows: 12100000, netSgdPosition: 3300000, foreignSettlementSGD: 8500000, potentialMarginCallSGD: 450000, cumulativeLiquiditySGD: 3300000 },
      { bucket: '1D', sgdInflows: 28500000, sgdOutflows: 24200000, netSgdPosition: 4300000, foreignSettlementSGD: 19100000, potentialMarginCallSGD: 820000, cumulativeLiquiditySGD: 7600000 },
      { bucket: '1W', sgdInflows: 84000000, sgdOutflows: 68000000, netSgdPosition: 16000000, foreignSettlementSGD: 52000000, potentialMarginCallSGD: 2100000, cumulativeLiquiditySGD: 23600000 },
      { bucket: '1M', sgdInflows: 210000000, sgdOutflows: 175000000, netSgdPosition: 35000000, foreignSettlementSGD: 138000000, potentialMarginCallSGD: 5400000, cumulativeLiquiditySGD: 58600000 },
      { bucket: '3M', sgdInflows: 480000000, sgdOutflows: 410000000, netSgdPosition: 70000000, foreignSettlementSGD: 310000000, potentialMarginCallSGD: 11200000, cumulativeLiquiditySGD: 128600000 },
      { bucket: '6M', sgdInflows: 820000000, sgdOutflows: 710000000, netSgdPosition: 110000000, foreignSettlementSGD: 540000000, potentialMarginCallSGD: 18500000, cumulativeLiquiditySGD: 238600000 },
      { bucket: '1Y', sgdInflows: 1450000000, sgdOutflows: 1240000000, netSgdPosition: 210000000, foreignSettlementSGD: 920000000, potentialMarginCallSGD: 32000000, cumulativeLiquiditySGD: 448600000 },
    ];
  }
}

export const marketEngine = new MarketEngine();
