package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserPass
import com.example.data.Attraction
import com.example.ui.LondonCardViewModel
import com.example.ui.ScannerState
import com.example.ui.theme.*

@Composable
fun CardTab(
    viewModel: LondonCardViewModel,
    modifier: Modifier = Modifier
) {
    val activePass by viewModel.activePass.collectAsState()
    val allPasses by viewModel.allUserPasses.collectAsState()
    val scannerState by viewModel.simulatedScannerState.collectAsState()
    val scannerError by viewModel.scannerErrorMessage.collectAsState()
    val attractions by viewModel.allAttractions.collectAsState()

    var showPurchaseFlow by remember { mutableStateOf(false) }
    var selectedAttractionForScan by remember { mutableStateOf("") }

    if (attractions.isNotEmpty() && selectedAttractionForScan.isEmpty()) {
        selectedAttractionForScan = attractions.first().id
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (!showPurchaseFlow) {
            // MAIN CARD & SCANNER PANEL
            item {
                Text(
                    text = "DIGITAL TOURIST OPERATING CARD",
                    style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, letterSpacing = 1.2.sp)
                )
            }

            if (activePass != null) {
                item {
                    DigitalPassCard(
                        pass = activePass!!,
                        onActivate = { viewModel.activateCard(activePass!!.id) }
                    )
                }

                // SIMULATED GATE SCANNER
                item {
                    Text(
                        text = "SIMULATE GATE ENTRANCE SCAN",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = LondonSlate),
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }

                item {
                    ScannerSimulatorCard(
                        scannerState = scannerState,
                        scannerError = scannerError,
                        attractions = attractions.filter { it.includedInPass },
                        selectedAttractionId = selectedAttractionForScan,
                        onSelectAttraction = { selectedAttractionForScan = it },
                        onScan = { 
                            viewModel.scanAtAttraction(activePass!!.id, selectedAttractionForScan, "")
                        },
                        onReset = { viewModel.resetScanner() }
                    )
                }
                
                // Active / Purchased passes switcher list if multiple exist
                if (allPasses.size > 1) {
                    item {
                        Text(
                            text = "YOUR WALLET PASSES",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = LondonSlate),
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    items(allPasses) { pass ->
                        PassSwitcherItem(
                            pass = pass,
                            isSelected = pass.id == activePass?.id,
                            onSelect = { viewModel.selectPass(pass.id) }
                        )
                    }
                }
            } else {
                // Empty state to purchase a pass
                item {
                    NoPassStateWidget(
                        onPurchaseClick = { showPurchaseFlow = true }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { showPurchaseFlow = true },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("purchase_new_pass_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = LondonSlate)
                ) {
                    Icon(Icons.Default.AddCard, contentDescription = "Add Card")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("CONFIGURE NEW LONDON CARD", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // PASS CONFIGURATOR PURCHASE FLOW
            item {
                Text(
                    text = "LONDON CARD CONFIGURATOR",
                    style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, letterSpacing = 1.2.sp)
                )
            }

            item {
                PassPurchaseFlowCard(
                    viewModel = viewModel,
                    onCancel = { showPurchaseFlow = false },
                    onComplete = { showPurchaseFlow = false }
                )
            }
        }
    }
}

@Composable
fun DigitalPassCard(
    pass: UserPass,
    onActivate: () -> Unit
) {
    val isActivated = pass.activationDate != null

    // Card interactive rotation animation on tap
    var rotated by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(
        targetValue = if (rotated) 360f else 0f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 100f)
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .graphicsLayer {
                rotationY = rotation
                cameraDistance = 12 * density
            }
            .clickable { rotated = !rotated }
            .testTag("digital_london_card_badge"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = LondonCharcoal)
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            // Front side graphics
            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                // Row header
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(
                            text = "LONDON",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp, color = Color.White, fontSize = 20.sp)
                        )
                        Text(
                            text = "CARD",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Light, letterSpacing = 6.sp, color = LondonBrass, fontSize = 14.sp)
                        )
                    }
                    
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isActivated) LondonGreen else LondonRed)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isActivated) "ACTIVE" else "READY TO ACTIVATE",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Middle area - Barcode / QR simulator
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(
                            text = pass.userName.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.5f), letterSpacing = 1.sp)
                        )
                        Text(
                            text = pass.passType,
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "ID: ${pass.id}",
                            style = MaterialTheme.typography.bodySmall.copy(color = LondonBrass, fontWeight = FontWeight.Bold)
                        )
                    }

                    // QR outline simulator
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.White)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "Simulated QR Token",
                            tint = Color.Black,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // Footer validity
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    Column {
                        Text(
                            text = "VALIDITY WINDOW",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.4f), letterSpacing = 1.sp)
                        )
                        Text(
                            text = "${pass.validityDays} DAY TOURIST ACCESS",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                    }

                    if (!isActivated) {
                        Button(
                            onClick = onActivate,
                            colors = ButtonDefaults.buttonColors(containerColor = LondonBrass),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text("ACTIVATE", color = LondonCharcoal, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    } else {
                        Text(
                            text = "SECURE TOKEN",
                            style = MaterialTheme.typography.labelSmall.copy(color = LondonGreen, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ScannerSimulatorCard(
    scannerState: ScannerState,
    scannerError: String,
    attractions: List<Attraction>,
    selectedAttractionId: String,
    onSelectAttraction: (String) -> Unit,
    onScan: () -> Unit,
    onReset: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("scanner_simulator_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (scannerState == ScannerState.IDLE) {
                Text(
                    text = "STEP 1: SELECT GATE ENTRANCE",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = LondonSlate)
                )

                // Simulated gate selection box
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.weight(1f)) {
                        ScrollableDropdownSelector(
                            items = attractions,
                            selectedId = selectedAttractionId,
                            onSelect = onSelectAttraction
                        )
                    }
                }

                Button(
                    onClick = onScan,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("simulate_gate_scan_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = LondonRed)
                ) {
                    Icon(Icons.Outlined.QrCodeScanner, contentDescription = "Scan")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TAP QR AT TURNSTILE GATE", fontWeight = FontWeight.Bold)
                }
            } else {
                // SCANNING ACTIVE FLOW
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (scannerState) {
                        ScannerState.SCANNING -> {
                            CircularProgressIndicator(color = LondonRed)
                            Text("SCANNING SIGNED DIGITAL PASS TOKEN...", fontWeight = FontWeight.Bold, color = LondonSlate)
                        }
                        ScannerState.VERIFIED -> {
                            Icon(Icons.Default.VerifiedUser, contentDescription = "Verified", tint = LondonBrass, modifier = Modifier.size(48.dp))
                            Text("SECURITY TOKEN VERIFIED. AUTHORISING...", fontWeight = FontWeight.Bold, color = LondonBrass)
                        }
                        ScannerState.ENTRY_GRANTED -> {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Granted", tint = LondonGreen, modifier = Modifier.size(60.dp))
                            Text("ENTRY GRANTED • ENJOY TOUR", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LondonGreen))
                            Text("Turnstile open. Simulated redemption logged in persistent database.", style = MaterialTheme.typography.bodySmall)
                        }
                        ScannerState.ERROR -> {
                            Icon(Icons.Default.ErrorOutline, contentDescription = "Error", tint = LondonRed, modifier = Modifier.size(48.dp))
                            Text("GATE ERROR: CANNOT VALIDATE", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LondonRed))
                            Text(scannerError, style = MaterialTheme.typography.bodySmall, color = LondonRed)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = onReset, colors = ButtonDefaults.buttonColors(containerColor = LondonSlate)) {
                                Text("TRY AGAIN")
                            }
                        }
                        else -> {}
                    }
                }
            }
        }
    }
}

@Composable
fun ScrollableDropdownSelector(
    items: List<Attraction>,
    selectedId: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedItem = items.firstOrNull { it.id == selectedId }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(LightSurface)
            .border(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .clickable { expanded = !expanded }
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = selectedItem?.name ?: "Select Attraction Gate...",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Icon(Icons.Default.ArrowDropDown, contentDescription = "dropdown arrow")
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            for (attr in items) {
                DropdownMenuItem(
                    text = { Text(attr.name, fontWeight = FontWeight.Bold) },
                    onClick = {
                        onSelect(attr.id)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun NoPassStateWidget(
    onPurchaseClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Outlined.CreditCard, contentDescription = "No Pass Icon", tint = LondonRed, modifier = Modifier.size(48.dp))
            Text("No London Card Found", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("Create or configure your bespoke private tourist pass. Experience London's landmarks, tours, and architecture seamlessly.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            Button(onClick = onPurchaseClick, colors = ButtonDefaults.buttonColors(containerColor = LondonRed)) {
                Text("GET THE PASS")
            }
        }
    }
}

@Composable
fun PassPurchaseFlowCard(
    viewModel: LondonCardViewModel,
    onCancel: () -> Unit,
    onComplete: () -> Unit
) {
    val purchaseName by viewModel.purchaseName.collectAsState()
    val purchaseType by viewModel.purchaseType.collectAsState()
    val purchaseDays by viewModel.purchaseDays.collectAsState()
    val purchaseCurrency by viewModel.purchaseCurrency.collectAsState()
    val calculatedPrice by viewModel.purchasePrice.collectAsState()

    var checkoutActive by remember { mutableStateOf(false) }
    var cardNum by remember { mutableStateOf("4000 1234 5678 9010") }
    var cardName by remember { mutableStateOf("Tom Walker") }
    var isSuccess by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!checkoutActive) {
                Text("CONFIGURE YOUR PASS", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                // Name Input
                OutlinedTextField(
                    value = purchaseName,
                    onValueChange = { viewModel.purchaseName.value = it },
                    label = { Text("TRAVELLER REGISTER NAME") },
                    modifier = Modifier.fillMaxWidth().testTag("purchase_name_input"),
                    singleLine = true
                )

                // Pass Type
                Text("SELECT CARD SPECIALITY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                val cardTypes = listOf("LONDON CARD DAYS", "LONDON CARD FLEX", "LONDON CARD FAMILY", "LONDON CARD CULTURE", "LONDON CARD DISCOVERY")
                ScrollableTextDropdown(
                    items = cardTypes,
                    selectedItem = purchaseType,
                    onSelect = { viewModel.purchaseType.value = it }
                )

                // Validity Days
                Text("VALIDITY WINDOW (DAYS)", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 2, 3, 4, 5).forEach { dayCount ->
                        val isSel = purchaseDays == dayCount
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) LondonRed else LightSurface)
                                .clickable { viewModel.purchaseDays.value = dayCount }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("$dayCount", fontWeight = FontWeight.Bold, color = if (isSel) Color.White else MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                // Currency switcher
                Text("PREFERED DISPLAY CURRENCY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("GBP", "USD", "EUR", "CHF", "JPY").forEach { curr ->
                        val isSel = purchaseCurrency == curr
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) LondonCharcoal else LightSurface)
                                .clickable { viewModel.purchaseCurrency.value = curr }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(curr, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                        }
                    }
                }

                Divider()

                // Computed Price display
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("TOTAL CALCULATED COST", fontWeight = FontWeight.Bold, color = LondonSlate)
                    val symbol = when (purchaseCurrency) {
                        "USD" -> "$"
                        "EUR" -> "€"
                        "CHF" -> "CHF "
                        "JPY" -> "¥"
                        else -> "£"
                    }
                    Text(
                        text = "$symbol${String.format("%.2f", calculatedPrice)}",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = LondonRed)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onCancel, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f))) {
                        Text("CANCEL", color = MaterialTheme.colorScheme.primary)
                    }
                    Button(onClick = { checkoutActive = true }, modifier = Modifier.weight(1f).testTag("purchase_checkout_button"), colors = ButtonDefaults.buttonColors(containerColor = LondonRed)) {
                        Text("PROCEED")
                    }
                }
            } else {
                // STRIPE STYLE SIMULATION
                if (!isSuccess) {
                    Text("SECURE SIMULATED PAYMENT", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("This is a standard informational checkout simulator. Do not enter real cards.", style = MaterialTheme.typography.bodySmall, color = LondonRed)

                    OutlinedTextField(
                        value = cardNum,
                        onValueChange = { cardNum = it },
                        label = { Text("CARD NUMBER") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = cardName,
                        onValueChange = { cardName = it },
                        label = { Text("NAME ON CARD") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            isSuccess = true
                            viewModel.purchaseCard(purchaseName, purchaseType, purchaseDays, purchaseCurrency, 149.00)
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("confirm_payment_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = LondonGreen)
                    ) {
                        Text("AUTHORISE AND PAY", fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Success receipt
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Approved", tint = LondonGreen, modifier = Modifier.size(60.dp))
                        Text("PAYMENT GRANTED", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LondonGreen))
                        Text("Receipt logged. Your custom London Card pass has been generated and appended into local database wallet.", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = onComplete) {
                            Text("GO TO MY PASS")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScrollableTextDropdown(
    items: List<String>,
    selectedItem: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(LightSurface)
            .border(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .clickable { expanded = !expanded }
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = selectedItem, fontWeight = FontWeight.Bold)
            Icon(Icons.Default.ArrowDropDown, contentDescription = "arrow")
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.fillMaxWidth(0.9f)) {
            for (cat in items) {
                DropdownMenuItem(text = { Text(cat) }, onClick = { onSelect(cat); expanded = false })
            }
        }
    }
}

@Composable
fun PassSwitcherItem(
    pass: UserPass,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect),
        colors = CardDefaults.cardColors(containerColor = if (isSelected) LondonNavy else MaterialTheme.colorScheme.surface)
    ) {
        Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(pass.id, fontWeight = FontWeight.Bold, color = if (isSelected) Color.White else MaterialTheme.colorScheme.primary)
                Text(pass.passType, fontSize = 11.sp, color = if (isSelected) LondonBrass else LondonSlate)
            }
            if (isSelected) {
                Icon(Icons.Default.Check, contentDescription = "selected", tint = LondonBrass)
            }
        }
    }
}
