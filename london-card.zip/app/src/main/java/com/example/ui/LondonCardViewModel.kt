package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val isUser: Boolean, val timestamp: Long = System.currentTimeMillis())

enum class ScannerState { IDLE, SCANNING, VERIFIED, ENTRY_GRANTED, ERROR }

class LondonCardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(database.appDao())
        
        // Seed the database immediately on start
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    // --- DATABASE FLOWS ---
    val allAttractions = repository.allAttractions.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allUserPasses = repository.allUserPasses.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val activePass = repository.activePass.stateIn(viewModelScope, SharingStarted.Lazily, null)
    val allRedemptions = repository.allRedemptions.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allBookings = repository.allBookings.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allNotifications = repository.allNotifications.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allFavorites = repository.allFavorites.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // --- UI NAVIGATION & TRANSIENT STATE ---
    val currentTab = MutableStateFlow("TODAY") // TODAY, EXPLORE, MAP, CARD, TRIP
    val selectedAttraction = MutableStateFlow<Attraction?>(null)
    val searchQuery = MutableStateFlow("")
    val weatherRainy = MutableStateFlow(false) // Toggle Rain Mode
    val offlineMode = MutableStateFlow(false) // Offline cache mode

    // Simulated coordinates (Start at Trafalgar Square: 51.5086, -0.1283)
    val userLatitude = MutableStateFlow(51.5086)
    val userLongitude = MutableStateFlow(-0.1283)
    val currentPositionName = MutableStateFlow("Trafalgar Square")

    // AI Concierge
    val conciergeConversation = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage("Good morning, Tom. I am your London Intelligence concierge. How may I optimize your metropolitan travels today?", isUser = false)
    ))
    val conciergeLoading = MutableStateFlow(false)

    // Scanner
    val simulatedScannerState = MutableStateFlow(ScannerState.IDLE)
    val scannerErrorMessage = MutableStateFlow("")

    // Pass Purchase Configurator State
    val purchaseName = MutableStateFlow("Tom Walker")
    val purchaseType = MutableStateFlow("LONDON CARD DAYS") // FLEX, DAYS, FAMILY, CULTURE, DISCOVERY
    val purchaseDays = MutableStateFlow(4)
    val purchaseCurrency = MutableStateFlow("GBP") // GBP, USD, EUR, CHF, JPY
    val purchasePrice = derivedStateOf {
        val basePrice = when (purchaseType.value) {
            "LONDON CARD FLEX" -> 89.00
            "LONDON CARD DAYS" -> 149.00
            "LONDON CARD FAMILY" -> 299.00
            "LONDON CARD CULTURE" -> 119.00
            "LONDON CARD DISCOVERY" -> 129.00
            else -> 149.00
        }
        val modifier = when (purchaseDays.value) {
            1 -> 0.5
            2 -> 0.75
            3 -> 0.9
            4 -> 1.0
            5 -> 1.15
            else -> 1.0
        }
        val gbpAmount = basePrice * modifier
        
        when (purchaseCurrency.value) {
            "USD" -> gbpAmount * 1.32
            "EUR" -> gbpAmount * 1.19
            "CHF" -> gbpAmount * 1.12
            "JPY" -> gbpAmount * 192.5
            else -> gbpAmount
        }
    }

    // Map filters
    val mapLayerAttractions = MutableStateFlow(true)
    val mapLayerStations = MutableStateFlow(true)
    val mapLayerRestaurants = MutableStateFlow(true)

    // Helper for derived state in Kotlin VM
    private fun <T> derivedStateOf(calculation: () -> T): StateFlow<T> {
        val flow = MutableStateFlow(calculation())
        viewModelScope.launch {
            combine(purchaseType, purchaseDays, purchaseCurrency) { _, _, _ ->
                flow.value = calculation()
            }.collect()
        }
        return flow.asStateFlow()
    }

    // --- OPERATIONS ---

    fun changeTab(tab: String) {
        currentTab.value = tab
    }

    fun selectAttraction(attraction: Attraction?) {
        selectedAttraction.value = attraction
    }

    fun toggleRainMode() {
        weatherRainy.value = !weatherRainy.value
        // Send a notification about the rain response
        viewModelScope.launch {
            if (weatherRainy.value) {
                repository.purchaseCard("", "", 1, 0.0) // trigger a silent notify check
                // Seed a rainy notification
                val message = "London Rain detected. Your Today operating schedule has been automatically re-prioritised with indoor landmarks & galleries."
                Log.d("LondonCardViewModel", "Rain mode enabled: $message")
            }
        }
    }

    fun toggleOfflineMode() {
        offlineMode.value = !offlineMode.value
    }

    // Toggle Favorite
    fun toggleFavorite(attractionId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(attractionId)
        }
    }

    // Buy Card
    fun purchaseCard(userName: String, passType: String, days: Int, currency: String, pricePaidGbp: Double) {
        viewModelScope.launch {
            repository.purchaseCard(
                userName = userName,
                passType = passType,
                days = days,
                pricePaid = pricePaidGbp,
                attractionLimit = if (passType.contains("FLEX")) 5 else -1
            )
            currentTab.value = "CARD"
        }
    }

    // Activate Card
    fun activateCard(passId: String) {
        viewModelScope.launch {
            repository.activatePass(passId)
        }
    }

    fun selectPass(passId: String) {
        viewModelScope.launch {
            repository.selectPass(passId)
        }
    }

    // Simulate entry scan
    fun scanAtAttraction(passId: String, attractionId: String, attractionName: String) {
        viewModelScope.launch {
            simulatedScannerState.value = ScannerState.SCANNING
            kotlinx.coroutines.delay(1000) // Aesthetic delay for scanning tick
            simulatedScannerState.value = ScannerState.VERIFIED
            kotlinx.coroutines.delay(800)  // Aesthetic delay for verification tick
            
            val result = repository.redeemAttraction(passId, attractionId)
            when (result) {
                is RedemptionResult.Success -> {
                    simulatedScannerState.value = ScannerState.ENTRY_GRANTED
                    // Back to idle after some time
                    kotlinx.coroutines.delay(2000)
                    simulatedScannerState.value = ScannerState.IDLE
                }
                is RedemptionResult.Error -> {
                    scannerErrorMessage.value = result.message
                    simulatedScannerState.value = ScannerState.ERROR
                }
            }
        }
    }

    fun resetScanner() {
        simulatedScannerState.value = ScannerState.IDLE
        scannerErrorMessage.value = ""
    }

    // Book/Reserve
    fun makeBooking(type: String, targetName: String, dateTime: String, tickets: Int, priceGbp: Double) {
        viewModelScope.launch {
            repository.reserveBooking(type, targetName, dateTime, tickets, priceGbp)
        }
    }

    // Ask AI Concierge
    fun askAiConcierge(messageText: String) {
        if (messageText.isBlank()) return
        
        val updatedHistory = conciergeConversation.value.toMutableList()
        updatedHistory.add(ChatMessage(messageText, isUser = true))
        conciergeConversation.value = updatedHistory
        
        conciergeLoading.value = true
        
        viewModelScope.launch {
            val pass = activePass.value
            val redemptions = allRedemptions.value
            val attractions = allAttractions.value
            val rainy = weatherRainy.value
            
            val response = GeminiClient.getConciergeResponse(
                userMessage = messageText,
                activePass = pass,
                redemptions = redemptions,
                attractions = attractions,
                isRainy = rainy
            )
            
            val finalHistory = conciergeConversation.value.toMutableList()
            finalHistory.add(ChatMessage(response, isUser = false))
            conciergeConversation.value = finalHistory
            conciergeLoading.value = false
        }
    }

    // Build Custom Intelligent Itinerary
    fun generateSmartItinerary(tripLength: Int, interests: List<String>, pace: String, hasChildren: Boolean) {
        viewModelScope.launch {
            val startCoords = "${userLatitude.value},${userLongitude.value}"
            repository.generateIntelligentItinerary(
                tripLength = tripLength,
                interests = interests,
                pace = pace,
                budget = 100.0,
                isRainy = weatherRainy.value,
                hasChildren = hasChildren,
                hasMobilityNeeds = false,
                startLocation = startCoords
            )
            currentTab.value = "TODAY"
        }
    }

    // Change user location on map
    fun updateUserPosition(lat: Double, lng: Double, name: String) {
        userLatitude.value = lat
        userLongitude.value = lng
        currentPositionName.value = name
    }
}
