package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Attraction
import com.example.data.ItineraryItem
import com.example.ui.LondonCardViewModel
import com.example.ui.theme.*

@Composable
fun TodayTab(
    viewModel: LondonCardViewModel,
    modifier: Modifier = Modifier
) {
    val activePass by viewModel.activePass.collectAsState()
    val isRainy by viewModel.weatherRainy.collectAsState()
    val itineraryItems by viewModel.allAttractions.collectAsState() // Fetch list of attractions
    val userItinerary by viewModel.allUserPasses.collectAsState() // Seeded default itinerary helper
    
    // Fallback static today timeline data representing Day 1 flagship Westminster CUJ
    val day1Timeline = remember {
        listOf(
            TimelineItem("09:30", "Westminster Abbey", "ROYAL", "westminster_abbey", "NOW", "Towering coronation cathedral"),
            TimelineItem("11:45", "Walk through Westminster", "ROYAL", "buckingham_palace", "NEXT", "Wander historical avenues"),
            TimelineItem("13:00", "Lunch at Dishoom", "FOOD", "dishoom_shoreditch", "LATER", "Delicious Bombay cafe dining"),
            TimelineItem("14:30", "Tower of London", "LANDMARKS", "tower_of_london", "LATER", "Beefeaters and crown jewels"),
            TimelineItem("17:00", "Thames Cruise", "EXPERIENCES", "thames_cruise", "LATER", "Dusk views along the river")
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedCorner()
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            TodayHeader(isRainy = isRainy, onToggleRain = { viewModel.toggleRainMode() })
        }

        // Weather Advisory Banner (Dynamic Rain mode adjustment)
        item {
            AnimatedVisibility(
                visible = isRainy,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                RainyAdvisoryBanner()
            }
        }

        // Digital Card Quick Status
        item {
            CardStatusWidget(
                passId = activePass?.id ?: "No Pass",
                passType = activePass?.passType ?: "None Active",
                isActive = activePass != null,
                activationDate = activePass?.activationDate,
                onCardClick = { viewModel.changeTab("CARD") }
            )
        }

        // Timeline Section
        item {
            Text(
                text = "YOUR LONDON TODAY",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                ),
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        itemsIndexed(day1Timeline) { index, item ->
            TimelineCard(
                item = item,
                onClick = {
                    // Open attraction sheet in Explore tab
                    val targetAttr = viewModel.allAttractions.value.find { it.id == item.attractionId }
                    if (targetAttr != null) {
                        viewModel.selectAttraction(targetAttr)
                        viewModel.changeTab("EXPLORE")
                    }
                }
            )
        }

        // Near you quick link
        item {
            Spacer(modifier = Modifier.height(16.dp))
            NearbyShortcutWidget(
                onMapClick = { viewModel.changeTab("MAP") }
            )
            Spacer(modifier = Modifier.height(48.dp)) // Safe scrolling space
        }
    }
}

@Composable
fun TodayHeader(
    isRainy: Boolean,
    onToggleRain: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "GOOD MORNING",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 28.sp,
                    letterSpacing = 1.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "LONDON",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Light,
                        fontSize = 18.sp,
                        letterSpacing = 2.sp,
                        color = LondonRed
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "•  ${if (isRainy) "16°C Light Rain" else "18°C Tuesday"}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                )
            }
        }

        // Sophisticated Sun/Rain control icon
        IconButton(
            onClick = onToggleRain,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface)
                .testTag("toggle_weather_button")
        ) {
            Icon(
                imageVector = if (isRainy) Icons.Filled.WaterDrop else Icons.Filled.WbSunny,
                contentDescription = "Toggle Weather Mode",
                tint = if (isRainy) LondonElectric else LondonBrass
            )
        }
    }
}

@Composable
fun RainyAdvisoryBanner() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(LondonElectric.copy(alpha = 0.15f))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Cloud,
            contentDescription = "Rainy Mode Active",
            tint = LondonElectric,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(
                text = "LONDON RAIN OPERATIONAL MODE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = LondonElectric
                )
            )
            Text(
                text = "Covered landmarks, cozy pubs, and museums have been prioritised automatically for your comfort today.",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                )
            )
        }
    }
}

@Composable
fun CardStatusWidget(
    passId: String,
    passType: String,
    isActive: Boolean,
    activationDate: Long?,
    onCardClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCardClick)
            .testTag("today_card_status_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isActive) LondonGreen.copy(alpha = 0.15f) else LondonRed.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isActive) Icons.Default.QrCodeScanner else Icons.Default.AddCard,
                        contentDescription = "Card Status",
                        tint = if (isActive) LondonGreen else LondonRed
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "YOUR DIGITAL CARD",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    )
                    Text(
                        text = if (isActive) passType else "NO CARD PURCHASED",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Text(
                        text = if (isActive) {
                            if (activationDate != null) "ACTIVE • Day 1 of 4" else "READY • Tap to scan at first attraction"
                        } else {
                            "Setup your digital pass now"
                        },
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (isActive && activationDate != null) LondonGreen else LondonRed
                        )
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Navigate to Card Tab",
                tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
            )
        }
    }
}

data class TimelineItem(
    val time: String,
    val title: String,
    val category: String,
    val attractionId: String,
    val status: String, // NOW, NEXT, LATER, COMPLETED
    val desc: String
)

@Composable
fun TimelineCard(
    item: TimelineItem,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Time column
        Column(
            modifier = Modifier.width(56.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = item.time,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            )
            // Status Tag
            if (item.status == "NOW") {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LondonRed)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "NOW",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            } else if (item.status == "NEXT") {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LondonBrass)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "NEXT",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = LondonCharcoal
                    )
                }
            }
        }

        // Visual divider connector
        Box(
            modifier = Modifier
                .width(16.dp)
                .fillMaxHeight(),
            contentAlignment = Alignment.Center
        ) {
            // Draw a subtle line or circles
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(
                            when (item.status) {
                                "NOW" -> LondonRed
                                "NEXT" -> LondonBrass
                                else -> MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f)
                            }
                        )
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Content details card
        Card(
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = item.desc,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Icon(
                    imageVector = Icons.Default.ArrowForwardIos,
                    contentDescription = "Details",
                    modifier = Modifier.size(12.dp),
                    tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                )
            }
        }
    }
}

@Composable
fun NearbyShortcutWidget(
    onMapClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onMapClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(LondonSlate.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.NearMe,
                    contentDescription = "Near me map",
                    tint = LondonSlate
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = "EXPLORE WHAT IS NEAR YOU",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                    )
                )
                Text(
                    text = "St Paul's, Tube stations & Borough Market are nearby.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                )
            }
        }
    }
}

// Arrangement helper to add small padding between vertical list items
fun Arrangement.spacedCorner() = Arrangement.spacedBy(10.dp)
