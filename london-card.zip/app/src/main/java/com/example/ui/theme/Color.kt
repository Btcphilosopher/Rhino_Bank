package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// London Card Color Palette
val LondonWhite = Color(0xFFFDFBF7)       // Warm White base for light mode
val LondonGraphite = Color(0xFF1B2022)    // Text and accent for light mode
val LondonCharcoal = Color(0xFF0E1112)    // Dark mode primary background
val LondonNavy = Color(0xFF0B1220)        // Deep navy for sophisticated headers
val LondonRed = Color(0xFFD62828)         // Muted red accent (classic London roundel red)
val LondonGreen = Color(0xFF1B4332)       // British Racing Green (included indicator)
val LondonStone = Color(0xFFE5E5E5)       // Stone gray for borders/dividers
val LondonSlate = Color(0xFF334155)       // Muted slate gray
val LondonBrass = Color(0xFFD4AF37)       // Brass/Gold accent for premium cues
val LondonElectric = Color(0xFF0077B6)    // Electric blue for highlights

// Material 3 mappings
val LightPrimary = LondonGraphite
val LightSecondary = LondonSlate
val LightTertiary = LondonRed
val LightBackground = LondonWhite
val LightSurface = Color(0xFFF7F5F0)

val DarkPrimary = Color(0xFFE5E5E5)
val DarkSecondary = LondonSlate
val DarkTertiary = LondonBrass
val DarkBackground = LondonCharcoal
val DarkSurface = Color(0xFF15191B)
