package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Booking
import com.example.data.Redemption
import com.example.ui.ChatMessage
import com.example.ui.LondonCardViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun TripTab(
    viewModel: LondonCardViewModel,
    modifier: Modifier = Modifier
) {
    val activePass by viewModel.activePass.collectAsState()
    val redemptions by viewModel.allRedemptions.collectAsState()
    val bookings by viewModel.allBookings.collectAsState()
    val conversations by viewModel.conciergeConversation.collectAsState()
    val isAiLoading by viewModel.conciergeLoading.collectAsState()
    val isOffline by viewModel.offlineMode.collectAsState()

    var activeSubSection by remember { mutableStateOf("WALLETS") } // WALLETS, CONCIERGE, AIRPORT, EMERGENCY

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Section Selector Row
        Surface(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.background, tonalElevation = 1.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SubSectionTabButton("Wallet & Stats", activeSubSection == "WALLETS", onClick = { activeSubSection = "WALLETS" })
                SubSectionTabButton("London AI", activeSubSection == "CONCIERGE", onClick = { activeSubSection = "CONCIERGE" })
                SubSectionTabButton("Airport Transit", activeSubSection == "AIRPORT", onClick = { activeSubSection = "AIRPORT" })
                SubSectionTabButton("Emergency", activeSubSection == "EMERGENCY", onClick = { activeSubSection = "EMERGENCY" })
            }
        }

        // Subsections views
        when (activeSubSection) {
            "WALLETS" -> WalletSubSection(
                activePassCost = activePass?.pricePaid ?: 0.0,
                redemptions = redemptions,
                bookings = bookings,
                isOffline = isOffline,
                onToggleOffline = { viewModel.toggleOfflineMode() }
            )
            "CONCIERGE" -> ConciergeSubSection(
                conversations = conversations,
                isLoading = isAiLoading,
                onAsk = { viewModel.askAiConcierge(it) }
            )
            "AIRPORT" -> AirportSubSection()
            "EMERGENCY" -> EmergencySubSection()
        }
    }
}

@Composable
fun SubSectionTabButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) LondonCharcoal else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
        )
    }
}

@Composable
fun WalletSubSection(
    activePassCost: Double,
    redemptions: List<Redemption>,
    bookings: List<Booking>,
    isOffline: Boolean,
    onToggleOffline: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // OFFLINE MODE ADVISORY PANEL
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isOffline) LondonGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(1.dp, if (isOffline) LondonGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isOffline) Icons.Default.CloudDone else Icons.Default.CloudQueue,
                            contentDescription = "offline icon",
                            tint = if (isOffline) LondonGreen else LondonSlate
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = if (isOffline) "OFFLINE LONDON ACTIVE" else "ONLINE SYNC CONNECTED",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = if (isOffline) "Downloaded Card, QR, and Maps ready." else "Auto-caching metadata in background.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }
                    }
                    Button(
                        onClick = onToggleOffline,
                        colors = ButtonDefaults.buttonColors(containerColor = if (isOffline) LondonGreen else LondonSlate),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(if (isOffline) "ONLINE" else "CACHE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // SAVINGS CALCULATOR (Flagship Savings CUJ)
        item {
            Text(
                text = "SAVINGS LEDGER",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = LondonSlate)
            )
        }

        item {
            val totalSavedValue = redemptions.sumOf { it.estimatedValueSaved }
            val netSavings = totalSavedValue - activePassCost

            Card(
                modifier = Modifier.fillMaxWidth().testTag("savings_calculator_ledger"),
                colors = CardDefaults.cardColors(containerColor = LondonNavy)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("NET SAVINGS METRIC", style = MaterialTheme.typography.labelSmall.copy(color = LondonBrass, fontWeight = FontWeight.Bold))
                            Text(
                                text = if (netSavings >= 0) "£${String.format("%.2f", netSavings)}" else "-£${String.format("%.2f", -netSavings)}",
                                style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.ExtraBold, color = Color.White, fontSize = 28.sp)
                            )
                        }
                        Icon(Icons.Default.TrendingUp, contentDescription = "trend", tint = LondonBrass, modifier = Modifier.size(36.dp))
                    }

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("PASS VALUE USED", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
                            Text("£${String.format("%.2f", totalSavedValue)}", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("YOUR PASS COST", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
                            Text("£${String.format("%.2f", activePassCost)}", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // REDEMPTIONS RECORDS LIST
        if (redemptions.isNotEmpty()) {
            item {
                Text(
                    text = "RECORDED ENTRY LOGS",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = LondonSlate)
                )
            }

            items(redemptions) { red ->
                Row(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Turnstile", tint = LondonRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(red.attractionName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Scanned successfully", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                        }
                    }
                    Text("+£${String.format("%.2f", red.estimatedValueSaved)}", fontWeight = FontWeight.ExtraBold, color = LondonGreen)
                }
            }
        }

        // MY WALLET RESERVATIONS
        item {
            Text(
                text = "YOUR ACTIVE RESERVATIONS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = LondonSlate)
            )
        }

        if (bookings.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                    Text("No reservations registered in wallet yet.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                }
            }
        } else {
            items(bookings) { b ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when (b.type) {
                                    "THEATRE" -> Icons.Default.TheaterComedy
                                    "RESTAURANT" -> Icons.Default.Restaurant
                                    else -> Icons.Default.Bookmark
                                },
                                contentDescription = "icon",
                                tint = LondonRed
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(b.targetName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("${b.dateTime} • ${b.ticketCount} Tickets", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                            }
                        }
                        Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(LondonGreen.copy(alpha = 0.1f)).padding(6.dp)) {
                            Text(b.confirmationCode, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LondonGreen)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(64.dp))
        }
    }
}

@Composable
fun ConciergeSubSection(
    conversations: List<ChatMessage>,
    isLoading: Boolean,
    onAsk: (String) -> Unit
) {
    var queryText by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // Auto-scroll on conversation changes
    LaunchedEffect(conversations.size) {
        if (conversations.isNotEmpty()) {
            listState.animateScrollToItem(conversations.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Chat list area
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }
            
            items(conversations) { msg ->
                ChatBubble(message = msg)
            }

            if (isLoading) {
                item {
                    Row(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.Start) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = LondonRed)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("LONDON INTELLIGENCE thinking...", style = MaterialTheme.typography.bodySmall, color = LondonSlate)
                    }
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Quick action prompt chips
        val promptChips = listOf(
            "Rainy afternoon plan",
            "4 hours near Westminster",
            "Brutalist architecture tour",
            "Traditional pubs walk"
        )
        LazyRow(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (chip in promptChips) {
                item {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            .clickable { onAsk(chip) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(chip, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LondonRed)
                    }
                }
            }
        }

        // Input bottom bar
        Surface(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = queryText,
                    onValueChange = { queryText = it },
                    modifier = Modifier.weight(1f).testTag("concierge_chat_input"),
                    placeholder = { Text("Ask London Intelligence...", fontSize = 13.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LondonRed,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (queryText.isNotBlank()) {
                            onAsk(queryText)
                            queryText = ""
                        }
                    },
                    modifier = Modifier.size(40.dp).clip(RoundedCornerShape(20.dp)).background(LondonRed).testTag("concierge_send_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val alignEnd = message.isUser
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (alignEnd) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Column(
            horizontalAlignment = if (alignEnd) Alignment.End else Alignment.Start,
            modifier = Modifier.fillMaxWidth(0.85f)
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 12.dp,
                            topEnd = 12.dp,
                            bottomStart = if (alignEnd) 12.dp else 0.dp,
                            bottomEnd = if (alignEnd) 0.dp else 12.dp
                        )
                    )
                    .background(if (alignEnd) LondonRed else MaterialTheme.colorScheme.surface)
                    .padding(12.dp)
            ) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (alignEnd) Color.White else MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )
                )
            }
            Text(
                text = if (alignEnd) "TOM" else "LONDON INTELLIGENCE",
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
            )
        }
    }
}

@Composable
fun AirportSubSection() {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "HEATHROW & OTHER METROPOLITAN GATEWAYS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = LondonSlate)
            )
        }

        item {
            AirportTransportCard("HEATHROW (LHR)", "Elizabeth Line: 35 min direct to Paddington (£12.80 contactless).\nHeathrow Express: 15 min express to Paddington (£25.00).\nPiccadilly Line Tube: 50 min to Central London (£5.60 standard fare).")
        }
        item {
            AirportTransportCard("GATWICK (LGW)", "Gatwick Express: 30 min express to Victoria Station (£22.00).\nThameslink Rail: 35 min direct to London Bridge / St Pancras (£11.50).")
        }
        item {
            AirportTransportCard("STANSTED (STN)", "Stansted Express: 47 min express to Liverpool Street (£21.90).")
        }
        item {
            AirportTransportCard("LUTON (LTN)", "Thameslink Rail: 40 min from Luton Airport Parkway to St Pancras (£13.00).")
        }
    }
}

@Composable
fun AirportTransportCard(airportName: String, description: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(airportName, fontWeight = FontWeight.Bold, color = LondonRed, style = MaterialTheme.typography.titleMedium)
            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f))
        }
    }
}

@Composable
fun EmergencySubSection() {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "LONDON EMERGENCY AND EMBASSY INFRASTRUCTURE",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = LondonSlate)
            )
        }

        item {
            EmergencyContactCard("Emergency Services", "999 (Polite/Fire/Ambulance)", "Dial 999 immediately from any mobile. Completely free of charge.")
        }
        item {
            EmergencyContactCard("Non-Urgent Medical (NHS)", "111", "Dial 111 for standard healthcare, pharmacy advice, and urgent minor medical queries.")
        }
        item {
            EmergencyContactCard("Non-Urgent Police", "101", "Dial 101 to report lost possessions, non-violent crimes, or general inquiry alerts.")
        }
        item {
            EmergencyContactCard("Lost London Card Support", "help@londoncard.co.uk", "Reach our private pass operators directly for digital app issues, lost pass recovery, or refund logs.")
        }
    }
}

@Composable
fun EmergencyContactCard(label: String, valNum: String, desc: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(label, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(valNum, fontWeight = FontWeight.ExtraBold, color = LondonRed, fontSize = 16.sp)
            }
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        }
    }
}
