package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Attraction
import com.example.ui.LondonCardViewModel
import com.example.ui.theme.*
import kotlin.math.roundToInt

data class MapPin(
    val id: String,
    val name: String,
    val category: String,
    val x: Float, // custom canvas coordinates relative mapping
    val y: Float,
    val realLat: Double,
    val realLng: Double,
    val stationName: String
)

@Composable
fun MapTab(
    viewModel: LondonCardViewModel,
    modifier: Modifier = Modifier
) {
    val attractions by viewModel.allAttractions.collectAsState()
    val userLat by viewModel.userLatitude.collectAsState()
    val userLng by viewModel.userLongitude.collectAsState()
    val userLocationName by viewModel.currentPositionName.collectAsState()

    val mapLayerAttractions by viewModel.mapLayerAttractions.collectAsState()
    val mapLayerStations by viewModel.mapLayerStations.collectAsState()
    val mapLayerRestaurants by viewModel.mapLayerRestaurants.collectAsState()

    // Fictional map scale pins centered around Central London
    val pins = remember {
        listOf(
            MapPin("westminster_abbey", "Westminster Abbey", "ROYAL", 0.35f, 0.65f, 51.4994, -0.1273, "Westminster"),
            MapPin("buckingham_palace", "Buckingham Palace", "ROYAL", 0.15f, 0.58f, 51.5014, -0.1419, "Green Park"),
            MapPin("national_gallery", "National Gallery", "GALLERIES", 0.42f, 0.45f, 51.5086, -0.1283, "Charing Cross"),
            MapPin("british_museum", "British Museum", "MUSEUMS", 0.48f, 0.28f, 51.5194, -0.1270, "Holborn"),
            MapPin("st_pauls_cathedral", "St Paul's Cathedral", "LANDMARKS", 0.72f, 0.38f, 51.5138, -0.0984, "St Paul's"),
            MapPin("tower_of_london", "Tower of London", "LANDMARKS", 0.88f, 0.46f, 51.5081, -0.0759, "Tower Hill"),
            MapPin("dishoom_shoreditch", "Dishoom Cafe", "FOOD", 0.92f, 0.22f, 51.5239, -0.0772, "Shoreditch High St"),
            MapPin("market_borough", "Borough Market", "FOOD", 0.76f, 0.52f, 51.5056, -0.0906, "London Bridge")
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Map Controller Header
        Surface(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.background, tonalElevation = 1.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "LONDON CARTOGRAPHY",
                    style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, letterSpacing = 1.2.sp)
                )
                Text(
                    text = "VIRTUAL POSITION: $userLocationName",
                    style = MaterialTheme.typography.labelSmall.copy(color = LondonRed, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Toggle layers Row
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterLayerChip("Places", mapLayerAttractions, onClick = { viewModel.mapLayerAttractions.value = !mapLayerAttractions })
                    FilterLayerChip("Stations", mapLayerStations, onClick = { viewModel.mapLayerStations.value = !mapLayerStations })
                    FilterLayerChip("Dining", mapLayerRestaurants, onClick = { viewModel.mapLayerRestaurants.value = !mapLayerRestaurants })
                }
            }
        }

        // Beautiful Interactive Map Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .background(LightSurface)
                .border(BottomStroke(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)))
                .testTag("london_map_canvas")
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            // Map tap coordinates to set virtual position
                            val clickX = offset.x / size.width
                            val clickY = offset.y / size.height
                            
                            // Find closest predefined pin to click
                            val clickedPin = pins.minByOrNull { 
                                val dx = it.x - clickX
                                val dy = it.y - clickY
                                dx * dx + dy * dy
                            }
                            
                            if (clickedPin != null) {
                                viewModel.updateUserPosition(clickedPin.realLat, clickedPin.realLng, clickedPin.name)
                            }
                        }
                    }
            ) {
                val w = size.width
                val h = size.height

                // 1. Draw River Thames (Curving diagonal stream)
                val thamesPath = Path().apply {
                    moveTo(0f, h * 0.72f)
                    cubicTo(w * 0.3f, h * 0.7f, w * 0.45f, h * 0.52f, w * 0.75f, h * 0.51f)
                    quadraticTo(w * 0.85f, h * 0.5f, w, h * 0.54f)
                }
                drawPath(
                    path = thamesPath,
                    color = LondonElectric.copy(alpha = 0.25f),
                    style = Stroke(width = 28.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                )

                // 2. Draw Road grid lines (Graphite schematic lines)
                // Strand / Fleet St
                drawLine(
                    color = Color.Gray.copy(alpha = 0.3f),
                    start = Offset(w * 0.35f, h * 0.48f),
                    end = Offset(w * 0.85f, h * 0.4f),
                    strokeWidth = 3.dp.toPx()
                )
                // Whitehall / Parliament St
                drawLine(
                    color = Color.Gray.copy(alpha = 0.3f),
                    start = Offset(w * 0.36f, h * 0.48f),
                    end = Offset(w * 0.35f, h * 0.7f),
                    strokeWidth = 3.dp.toPx()
                )

                // 3. Draw Stations pins (Red roundels)
                if (mapLayerStations) {
                    pins.filter { it.category == "ROYAL" || it.id == "st_pauls_cathedral" }.forEach { pin ->
                        drawCircle(
                            color = LondonRed,
                            center = Offset(pin.x * w, pin.y * h + 15f),
                            radius = 6.dp.toPx(),
                            style = Stroke(width = 2.dp.toPx())
                        )
                        drawCircle(
                            color = Color.White,
                            center = Offset(pin.x * w, pin.y * h + 15f),
                            radius = 3.dp.toPx()
                        )
                    }
                }

                // 4. Draw Attraction Pins (Brass / Grey)
                if (mapLayerAttractions) {
                    pins.forEach { pin ->
                        drawCircle(
                            color = if (pin.name == userLocationName) LondonRed else LondonBrass,
                            center = Offset(pin.x * w, pin.y * h),
                            radius = if (pin.name == userLocationName) 9.dp.toPx() else 7.dp.toPx()
                        )
                        drawCircle(
                            color = Color.White,
                            center = Offset(pin.x * w, pin.y * h),
                            radius = 3.dp.toPx()
                        )
                    }
                }
            }

            // Simulated Legend Overlay
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = Color.Black.copy(alpha = 0.7f)
            ) {
                Text(
                    text = "TAP PIN TO SIMULATE WALK",
                    color = Color.White,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(6.dp)
                )
            }
        }

        // NEAR YOU DIRECTORY PANEL
        Text(
            text = "NEAR YOUR VIRTUAL POSITION",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = LondonSlate),
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val nearbySpots = attractions.map { attraction ->
                val distKm = calculateFictionalDistance(userLat, userLng, attraction.coordinates)
                val walkMinutes = (distKm * 12).roundToInt().coerceAtLeast(2)
                NearbySpotItem(attraction, walkMinutes)
            }.sortedBy { it.walkMinutes }

            items(nearbySpots) { spot ->
                NearSpotCard(
                    spot = spot,
                    onClick = {
                        viewModel.selectAttraction(spot.attraction)
                        viewModel.changeTab("EXPLORE")
                    }
                )
            }
        }
    }
}

data class NearbySpotItem(
    val attraction: Attraction,
    val walkMinutes: Int
)

@Composable
fun NearSpotCard(
    spot: NearbySpotItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = Icons.Default.Place,
                    contentDescription = "Place location",
                    tint = LondonRed,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = spot.attraction.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 15.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Nearest Station: ${spot.attraction.location}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                    )
                }
            }
            
            // Walking speed badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(LondonGreen.copy(alpha = 0.12f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${spot.walkMinutes} min walk",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LondonGreen
                )
            }
        }
    }
}

@Composable
fun FilterLayerChip(
    label: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isActive) LondonCharcoal else MaterialTheme.colorScheme.surface)
            .border(1.dp, if (isActive) LondonCharcoal else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isActive) Color.White else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
        )
    }
}

// Simple linear bottom border helper
fun BottomStroke(width: androidx.compose.ui.unit.Dp, color: Color) = BorderStroke(width, color)

// Fictional distance calculation in Central London
private fun calculateFictionalDistance(lat1: Double, lng1: Double, coordinates2: String): Double {
    return try {
        val parts = coordinates2.split(",")
        val lat2 = parts[0].toDouble()
        val lng2 = parts[1].toDouble()
        
        val dLat = Math.abs(lat1 - lat2)
        val dLng = Math.abs(lng1 - lng2)
        (dLat + dLng) * 110.0 // rough scaling km
    } catch (e: Exception) {
        1.5
    }
}
