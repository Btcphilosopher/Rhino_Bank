package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Attraction
import com.example.ui.LondonCardViewModel
import com.example.ui.theme.*

@Composable
fun ExploreTab(
    viewModel: LondonCardViewModel,
    modifier: Modifier = Modifier
) {
    val attractions by viewModel.allAttractions.collectAsState()
    val selectedAttraction by viewModel.selectedAttraction.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isRainy by viewModel.weatherRainy.collectAsState()
    val activePass by viewModel.activePass.collectAsState()

    var selectedCategory by remember { mutableStateFlowOf("ALL") }
    var selectedArchitectureEra by remember { mutableStateFlowOf<String?>(null) }

    // Intercept back button if an attraction details view is active
    if (selectedAttraction != null) {
        BackHandler {
            viewModel.selectAttraction(null)
        }
    }

    Box(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (selectedAttraction == null) {
            // MAIN GRID SEARCH & CATALOG
            Column(modifier = Modifier.fillMaxSize()) {
                // Search Header
                ExploreSearchHeader(
                    searchQuery = searchQuery,
                    onSearchQueryChange = { viewModel.searchQuery.value = it }
                )

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Rain notice banner if active
                    if (isRainy) {
                        item {
                            RainPrioritizationAlert()
                        }
                    }

                    // Onboarding banner featuring our beautiful generated skyline
                    item {
                        ExploreHeroBanner()
                    }

                    // Category scroll row
                    item {
                        Text(
                            text = "DISCOVER BY CATEGORY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                            ),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                        CategoryFilterRow(
                            selectedCategory = selectedCategory,
                            onCategorySelect = { 
                                selectedCategory = it
                                selectedArchitectureEra = null // reset architecture filter
                            }
                        )
                    }

                    // London Architecture Mode Filter Section
                    item {
                        Text(
                            text = "LONDON ARCHITECTURE (ANGLO-FUTURIST)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                            ),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                        ArchitectureFilterRow(
                            selectedEra = selectedArchitectureEra,
                            onEraSelect = {
                                selectedArchitectureEra = if (selectedArchitectureEra == it) null else it
                                selectedCategory = "ALL" // override category filter
                            }
                        )
                    }

                    // Dynamic Title
                    item {
                        val titleText = when {
                            selectedArchitectureEra != null -> "ARCHITECTURAL MASTERS: ${selectedArchitectureEra!!.uppercase()}"
                            selectedCategory != "ALL" -> "RECOMMENDED $selectedCategory"
                            else -> "ALL REQUISITE LONDON PLACES"
                        }
                        Text(
                            text = titleText,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }

                    // Filter list
                    val filteredList = attractions.filter { attraction ->
                        val matchesSearch = attraction.name.contains(searchQuery, ignoreCase = true) || 
                                            attraction.location.contains(searchQuery, ignoreCase = true) ||
                                            attraction.description.contains(searchQuery, ignoreCase = true)
                        
                        val matchesCategory = selectedCategory == "ALL" || attraction.category.equals(selectedCategory, ignoreCase = true)
                        
                        val matchesArchitecture = selectedArchitectureEra == null || when (selectedArchitectureEra) {
                            "Brutalist" -> attraction.id == "barbican_tour"
                            "Art Deco" -> attraction.id == "battersea_lift"
                            "Contemporary" -> attraction.id == "tower_bridge" || attraction.id == "battersea_lift"
                            "Georgian" -> attraction.id == "westminster_abbey" || attraction.id == "pub_cheshire_cheese"
                            "Victorian" -> attraction.id == "st_pauls_cathedral" || attraction.id == "london_zoo"
                            else -> true
                        }

                        val matchesWeather = !isRainy || !attraction.includedInPass || attraction.isRainFriendly

                        matchesSearch && matchesCategory && matchesArchitecture && matchesWeather
                    }

                    if (filteredList.isEmpty()) {
                        item {
                            EmptySearchState()
                        }
                    } else {
                        items(filteredList) { attraction ->
                            AttractionCard(
                                attraction = attraction,
                                onClick = { viewModel.selectAttraction(attraction) }
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(64.dp))
                    }
                }
            }
        } else {
            // DETAILED ATTRACTION OVERLAY
            AttractionDetailScreen(
                attraction = selectedAttraction!!,
                viewModel = viewModel,
                activePassId = activePass?.id,
                onBack = { viewModel.selectAttraction(null) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreSearchHeader(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.background,
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "EXPLORE LONDON",
                style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, letterSpacing = 1.sp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier.fillMaxWidth().testTag("explore_search_input"),
                placeholder = { Text("Search Westminster, Brutalist, cafe...", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search icon") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LondonRed,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f)
                )
            )
        }
    }
}

@Composable
fun RainPrioritizationAlert() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = LondonElectric.copy(alpha = 0.12f)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.WaterDrop, contentDescription = "Rain active", tint = LondonElectric)
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Rain mode is ACTIVE. Outdoor and roof views are filtered out for your comfort. Toggle in the top right to revert.",
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f))
            )
        }
    }
}

@Composable
fun ExploreHeroBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(LondonNavy)
    ) {
        // Draw the beautiful generated hero banner
        AsyncImage(
            model = "/app/src/main/res/drawable/london_hero_banner_1790606974486.jpg",
            contentDescription = "London Skyline Banner",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            error = null // fallbacks to background if not ready yet
        )
        // Elegant overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    androidx.compose.ui.graphics.Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                    )
                )
        )
        Column(
            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)
        ) {
            Text(
                text = "ONE CARD • ONE CITY",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = LondonBrass, letterSpacing = 2.sp)
            )
            Text(
                text = "Discover 24 Masterpiece Attractions",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
            )
        }
    }
}

@Composable
fun CategoryFilterRow(
    selectedCategory: String,
    onCategorySelect: (String) -> Unit
) {
    val categories = listOf("ALL", "LANDMARKS", "MUSEUMS", "GALLERIES", "ROYAL", "ARCHITECTURE", "FOOD", "PUBS", "SHOPPING", "THEATRE")
    
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories) { cat ->
            val isSelected = selectedCategory == cat
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isSelected) LondonRed else MaterialTheme.colorScheme.surface)
                    .border(1.dp, if (isSelected) LondonRed else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                    .clickable { onCategorySelect(cat) }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = cat,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                    )
                )
            }
        }
    }
}

@Composable
fun ArchitectureFilterRow(
    selectedEra: String?,
    onEraSelect: (String) -> Unit
) {
    val eras = listOf("Brutalist", "Art Deco", "Contemporary", "Georgian", "Victorian")
    
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(eras) { era ->
            val isSelected = selectedEra == era
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) LondonBrass else MaterialTheme.colorScheme.surface)
                    .border(1.dp, if (isSelected) LondonBrass else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .clickable { onEraSelect(era) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Architecture,
                        contentDescription = "Architecture icon",
                        tint = if (isSelected) LondonCharcoal else LondonBrass,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = era,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) LondonCharcoal else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun AttractionCard(
    attraction: Attraction,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("attraction_card_${attraction.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category icon
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(LondonNavy),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (attraction.category) {
                        "LANDMARKS" -> Icons.Default.Museum
                        "MUSEUMS" -> Icons.Default.Cabin
                        "GALLERIES" -> Icons.Default.Palette
                        "ROYAL" -> Icons.Default.MilitaryTech
                        "FOOD" -> Icons.Default.Restaurant
                        "PUBS" -> Icons.Default.LocalBar
                        "SHOPPING" -> Icons.Default.LocalMall
                        "THEATRE" -> Icons.Default.TheaterComedy
                        else -> Icons.Default.LocationOn
                    },
                    contentDescription = attraction.category,
                    tint = LondonBrass,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                // Badges
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (attraction.includedInPass) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(LondonGreen.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("INCLUDED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = LondonGreen)
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("SPECIAL EXCLUSION", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                        }
                    }

                    if (attraction.reservationRequired) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(LondonBrass.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("RESERVE REQ", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = LondonBrass)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = attraction.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsTransit, contentDescription = "Station icon", tint = LondonRed, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = attraction.location,
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "Details link",
                tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun EmptySearchState() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Search, contentDescription = "Search", tint = LondonSlate, modifier = Modifier.size(48.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("No Matches Registered", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("Try adjusting your keyword filter or switching weather mode.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
    }
}

@Composable
fun AttractionDetailScreen(
    attraction: Attraction,
    viewModel: LondonCardViewModel,
    activePassId: String?,
    onBack: () -> Unit
) {
    var ticketCount by remember { mutableStateOf(2) }
    var showBookingForm by remember { mutableStateOf(false) }
    var isBookingConfirmed by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Back Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(LondonNavy)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.TopStart)
                    .size(40.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.5f))
                    .testTag("attraction_detail_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Go back", tint = Color.White)
            }

            Column(
                modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)
            ) {
                Text(
                    text = attraction.category.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = LondonBrass, letterSpacing = 2.sp)
                )
                Text(
                    text = attraction.name,
                    style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = Color.White)
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Action Panel Row (Reserve, Add to Day, Favorite)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Favorite Button
                IconButton(
                    onClick = { viewModel.toggleFavorite(attraction.id) },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = "Favorite",
                        tint = LondonRed
                    )
                }

                // Add to Day Plan Button
                Button(
                    onClick = {
                        viewModel.makeBooking("ATTRACTION", attraction.name, "14 Oct 2026, 10:00", 2, 0.0)
                        viewModel.changeTab("TODAY")
                    },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LondonSlate)
                ) {
                    Icon(Icons.Default.CalendarToday, contentDescription = "Add Icon", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ADD TO ITINERARY", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                // Reserve / Directions Button
                Button(
                    onClick = {
                        if (attraction.reservationRequired) {
                            showBookingForm = true
                        } else {
                            viewModel.updateUserPosition(
                                attraction.coordinates.split(",")[0].toDouble(),
                                attraction.coordinates.split(",")[1].toDouble(),
                                attraction.name
                            )
                            viewModel.changeTab("MAP")
                        }
                    },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (attraction.reservationRequired) LondonRed else LondonGreen)
                ) {
                    Icon(
                        imageVector = if (attraction.reservationRequired) Icons.Default.BookmarkAdded else Icons.Default.Map,
                        contentDescription = "Main action icon",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (attraction.reservationRequired) "RESERVE PASS" else "DIRECTIONS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            // Quick metadata grid
            Row(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("PASS PRICE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                    Text(if (attraction.includedInPass) "INCLUDED" else "£${attraction.normalPrice}", fontWeight = FontWeight.Bold, color = if (attraction.includedInPass) LondonGreen else MaterialTheme.colorScheme.primary)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("DURATION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                    Text(attraction.duration, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("NEAREST TUBE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                    Text(attraction.location, fontWeight = FontWeight.Bold, color = LondonRed)
                }
            }

            // Description
            Column {
                Text("THE HISTORICAL RECORD", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = LondonSlate))
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = attraction.description,
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f))
                )
            }

            // Transport details
            Column {
                Text("TRANSPORTATION & INFRASTRUCTURE", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = LondonSlate))
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DirectionsTransit, contentDescription = "Tube", tint = LondonRed, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("Transit Links", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(attraction.transportLinks, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
                        }
                    }
                }
            }

            // Accessibility details
            Column {
                Text("ACCESSIBILITY DIRECTIVE", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = LondonSlate))
                Spacer(modifier = Modifier.height(4.dp))
                Text(attraction.accessibility, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
            }

            // SCAN ATTRACTION TRIGGER IF CARD IS ACTIVE (Flagship Scan entry redemption)
            if (activePassId != null && attraction.includedInPass) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = LondonGreen.copy(alpha = 0.08f)),
                    border = BorderStroke(1.dp, LondonGreen.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "LONDON CARD ENTRY PORTAL",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = LondonGreen, letterSpacing = 1.5.sp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Arrived at the entrance? Scan your digital ticket immediately.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                viewModel.scanAtAttraction(activePassId, attraction.id, attraction.name)
                                viewModel.changeTab("CARD")
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = LondonGreen)
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan icon")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SCAN PASS AT GATE", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // SIMULATED BOOKING FORM MODAL OVERLAY
            if (showBookingForm) {
                Surface(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                    tonalElevation = 4.dp
                ) {
                    if (!isBookingConfirmed) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("RESERVE ENTRY SLOT", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Select ticket count and confirm standard included pass booking.", style = MaterialTheme.typography.bodySmall)
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("TRAVELLERS", fontWeight = FontWeight.Bold)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { if (ticketCount > 1) ticketCount-- }) {
                                        Icon(Icons.Default.RemoveCircleOutline, contentDescription = "remove")
                                    }
                                    Text("$ticketCount", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    IconButton(onClick = { ticketCount++ }) {
                                        Icon(Icons.Default.AddCircleOutline, contentDescription = "add")
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    viewModel.makeBooking("RESERVATIONS", attraction.name, "14 Oct 2026, 14:30", ticketCount, 0.0)
                                    isBookingConfirmed = true
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = LondonRed)
                            ) {
                                Text("CONFIRM BOOKING", fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "success", tint = LondonGreen, modifier = Modifier.size(48.dp))
                            Text("RESERVATION CONFIRMED", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LondonGreen))
                            Text("Your digital pass reservation is registered. Standard QR entry is active inside Wallet.", style = MaterialTheme.typography.bodySmall)
                            Button(onClick = { showBookingForm = false; onBack() }) {
                                Text("RETURN TO CATALOG")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

// Simple dynamic state flow creation
fun <T> mutableStateFlowOf(value: T): MutableState<T> = mutableStateOf(value)
