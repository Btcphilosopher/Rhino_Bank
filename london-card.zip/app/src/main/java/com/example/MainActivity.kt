package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.LondonCardViewModel
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private val viewModel: LondonCardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Full Edge-to-Edge display handling safe drawing insets
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                val currentTab by viewModel.currentTab.collectAsState()

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("app_main_scaffold"),
                    bottomBar = {
                        LondonCardBottomNavigation(
                            selectedTab = currentTab,
                            onTabSelect = { viewModel.changeTab(it) }
                        )
                    },
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            "TODAY" -> TodayTab(viewModel = viewModel)
                            "EXPLORE" -> ExploreTab(viewModel = viewModel)
                            "MAP" -> MapTab(viewModel = viewModel)
                            "CARD" -> CardTab(viewModel = viewModel)
                            "TRIP" -> TripTab(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LondonCardBottomNavigation(
    selectedTab: String,
    onTabSelect: (String) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bottom_nav_bar"),
        containerColor = LondonCharcoal,
        tonalElevation = 8.dp
    ) {
        // Today
        NavigationBarItem(
            selected = selectedTab == "TODAY",
            onClick = { onTabSelect("TODAY") },
            icon = {
                Icon(
                    imageVector = if (selectedTab == "TODAY") Icons.Filled.Today else Icons.Outlined.Today,
                    contentDescription = "Today operating sheet"
                )
            },
            label = { Text("TODAY", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = LondonRed,
                unselectedIconColor = Color.White.copy(alpha = 0.5f),
                selectedTextColor = LondonRed,
                unselectedTextColor = Color.White.copy(alpha = 0.5f),
                indicatorColor = Color.White.copy(alpha = 0.1f)
            )
        )

        // Explore
        NavigationBarItem(
            selected = selectedTab == "EXPLORE",
            onClick = { onTabSelect("EXPLORE") },
            icon = {
                Icon(
                    imageVector = if (selectedTab == "EXPLORE") Icons.Filled.Explore else Icons.Outlined.Explore,
                    contentDescription = "Explore Catalog"
                )
            },
            label = { Text("EXPLORE", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = LondonRed,
                unselectedIconColor = Color.White.copy(alpha = 0.5f),
                selectedTextColor = LondonRed,
                unselectedTextColor = Color.White.copy(alpha = 0.5f),
                indicatorColor = Color.White.copy(alpha = 0.1f)
            )
        )

        // CARD (Central, Prominent Button)
        NavigationBarItem(
            selected = selectedTab == "CARD",
            onClick = { onTabSelect("CARD") },
            icon = {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(if (selectedTab == "CARD") LondonRed else LondonBrass)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = "My QR Card scanner",
                        tint = if (selectedTab == "CARD") Color.White else LondonCharcoal,
                        modifier = Modifier.size(24.dp)
                    )
                }
            },
            label = { Text("LONDON CARD", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = if (selectedTab == "CARD") LondonRed else LondonBrass) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                unselectedIconColor = LondonCharcoal,
                selectedTextColor = LondonRed,
                unselectedTextColor = LondonBrass,
                indicatorColor = Color.Transparent
            )
        )

        // Map
        NavigationBarItem(
            selected = selectedTab == "MAP",
            onClick = { onTabSelect("MAP") },
            icon = {
                Icon(
                    imageVector = if (selectedTab == "MAP") Icons.Filled.Map else Icons.Outlined.Map,
                    contentDescription = "London Map"
                )
            },
            label = { Text("MAP", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = LondonRed,
                unselectedIconColor = Color.White.copy(alpha = 0.5f),
                selectedTextColor = LondonRed,
                unselectedTextColor = Color.White.copy(alpha = 0.5f),
                indicatorColor = Color.White.copy(alpha = 0.1f)
            )
        )

        // Trip Wallet
        NavigationBarItem(
            selected = selectedTab == "TRIP",
            onClick = { onTabSelect("TRIP") },
            icon = {
                Icon(
                    imageVector = if (selectedTab == "TRIP") Icons.Filled.Wallet else Icons.Outlined.Wallet,
                    contentDescription = "Trip wallet stats"
                )
            },
            label = { Text("TRIP", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = LondonRed,
                unselectedIconColor = Color.White.copy(alpha = 0.5f),
                selectedTextColor = LondonRed,
                unselectedTextColor = Color.White.copy(alpha = 0.5f),
                indicatorColor = Color.White.copy(alpha = 0.1f)
            )
        )
    }
}
