package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attractions")
data class Attraction(
    @PrimaryKey val id: String,
    val name: String,
    val category: String, // LANDMARKS, MUSEUMS, GALLERIES, EXPERIENCES, FAMILY, ARCHITECTURE, ROYAL, FOOD, PUBS, SHOPPING, THEATRE
    val location: String, // Neighborhood or station description
    val coordinates: String, // "lat,lng" for distance estimation
    val openingHours: String,
    val duration: String,
    val reservationRequired: Boolean,
    val includedInPass: Boolean,
    val normalPrice: Double, // in GBP
    val cardValue: Double,   // saved value
    val availability: String, // e.g., "Open today", "Available"
    val accessibility: String,
    val ageRequirements: String,
    val description: String,
    val imageUrl: String, // image drawable path or reference
    val transportLinks: String, // Nearest Tube station (e.g. "Tower Hill")
    val isRainFriendly: Boolean = false,
    val isSunFriendly: Boolean = false,
    val isChildFriendly: Boolean = false
)

@Entity(tableName = "user_passes")
data class UserPass(
    @PrimaryKey val id: String, // e.g., "LC-4820-XT"
    val userName: String,
    val passType: String, // FLEX, DAYS, FAMILY, CULTURE, DISCOVERY
    val validityDays: Int,
    val purchaseDate: Long,
    val activationDate: Long?, // Null if not yet activated
    val isActive: Boolean = false,
    val allowedAttractions: Int, // For FLEX (e.g., 5 attractions), or -1 for unlimited
    val remainingAttractions: Int,
    val pricePaid: Double
)

@Entity(tableName = "redemptions")
data class Redemption(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val passId: String,
    val attractionId: String,
    val attractionName: String,
    val timestamp: Long,
    val entryType: String, // "STANDARD" or "FAST_TRACK"
    val estimatedValueSaved: Double
)

@Entity(tableName = "itinerary_items")
data class ItineraryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayNumber: Int, // e.g., 1, 2, 3
    val attractionId: String,
    val attractionName: String,
    val timeSlot: String, // e.g., "09:30", "11:15", "14:30"
    val notes: String = "",
    val category: String = ""
)

@Entity(tableName = "favorites")
data class Favorite(
    @PrimaryKey val attractionId: String,
    val isFavorite: Boolean = true
)

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // "RESTAURANT", "THEATRE", "TOUR", "ATTRACTION"
    val targetName: String, // e.g., "The Ritz Afternoon Tea"
    val dateTime: String, // e.g., "14 Oct 2026, 14:30"
    val ticketCount: Int,
    val status: String, // "CONFIRMED", "PENDING", "CANCELLED"
    val confirmationCode: String,
    val pricePaid: Double = 0.0
)

@Entity(tableName = "notifications")
data class NotificationLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val timestamp: Long,
    val isRead: Boolean = false
)
