package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlin.math.*

class AppRepository(private val appDao: AppDao) {

    val allAttractions: Flow<List<Attraction>> = appDao.getAllAttractions()
    val allUserPasses: Flow<List<UserPass>> = appDao.getAllUserPasses()
    val activePass: Flow<UserPass?> = appDao.getActivePass()
    val allRedemptions: Flow<List<Redemption>> = appDao.getAllRedemptions()
    val allBookings: Flow<List<Booking>> = appDao.getAllBookings()
    val allNotifications: Flow<List<NotificationLog>> = appDao.getAllNotifications()

    fun isFavorite(attractionId: String): Flow<Boolean> = appDao.isFavoriteFlow(attractionId)
    val allFavorites: Flow<List<Favorite>> = appDao.getAllFavorites()

    suspend fun seedDatabaseIfEmpty() {
        val count = appDao.getAttractionsCount()
        if (count == 0) {
            Log.d("AppRepository", "Seeding database with attractions...")
            appDao.insertAttractions(DefaultData.getSeedAttractions())
            
            // Log a friendly startup notification
            appDao.insertNotification(
                NotificationLog(
                    title = "Welcome to London",
                    message = "Discover the city with your digital LONDON CARD operating system. Tap the Card tab to activate.",
                    timestamp = System.currentTimeMillis()
                )
            )

            // Seed a default demo pass for the user so the first-launch experience is fully operational
            val demoPass = UserPass(
                id = "LC-7729-XM",
                userName = "Tom Walker",
                passType = "LONDON CARD DAYS",
                validityDays = 4,
                purchaseDate = System.currentTimeMillis() - 86400000, // bought yesterday
                activationDate = null, // ready to activate
                isActive = false,
                allowedAttractions = -1, // Unlimited
                remainingAttractions = -1,
                pricePaid = 149.00
            )
            appDao.insertPass(demoPass)
            
            // Seed a default Day 1 itinerary to demonstrate the flagpole Westminster CUJ immediately
            seedDefaultItinerary()
        }
    }

    private suspend fun seedDefaultItinerary() {
        appDao.clearAllItineraries()
        val day1 = listOf(
            ItineraryItem(dayNumber = 1, attractionId = "westminster_abbey", attractionName = "Westminster Abbey", timeSlot = "09:30", notes = "Coronation church of the monarchs", category = "ROYAL"),
            ItineraryItem(dayNumber = 1, attractionId = "buckingham_palace", attractionName = "Buckingham Palace State Rooms", timeSlot = "11:15", notes = "Ceremonial change of guard and palace state rooms", category = "ROYAL"),
            ItineraryItem(dayNumber = 1, attractionId = "dishoom_shoreditch", attractionName = "Dishoom Lunch", timeSlot = "13:00", notes = "Traditional modern Bombay cafe", category = "FOOD"),
            ItineraryItem(dayNumber = 1, attractionId = "national_gallery", attractionName = "National Gallery", timeSlot = "14:30", notes = "Marvel at Da Vinci and Van Gogh masterpieces", category = "GALLERIES"),
            ItineraryItem(dayNumber = 1, attractionId = "thames_cruise", attractionName = "Thames River Cruise", timeSlot = "17:00", notes = "Dusk cruise back to Tower Bridge", category = "EXPERIENCES")
        )
        appDao.insertItineraryItems(day1)
    }

    suspend fun getAttractionById(id: String): Attraction? {
        return appDao.getAttractionById(id)
    }

    // --- CARD FLOWS ---
    suspend fun purchaseCard(userName: String, passType: String, days: Int, pricePaid: Double, attractionLimit: Int = -1): UserPass {
        val id = "LC-${(1000..9999).random()}-${('A'..'Z').random()}${('A'..'Z').random()}"
        val newPass = UserPass(
            id = id,
            userName = userName,
            passType = passType,
            validityDays = days,
            purchaseDate = System.currentTimeMillis(),
            activationDate = null,
            isActive = false,
            allowedAttractions = attractionLimit,
            remainingAttractions = attractionLimit,
            pricePaid = pricePaid
        )
        // Set all other passes as inactive
        val currentPasses = appDao.getAllUserPasses().first()
        currentPasses.forEach {
            if (it.isActive) {
                appDao.updatePass(it.copy(isActive = false))
            }
        }
        // Activate immediately or keep it ready
        val finalizedPass = newPass.copy(isActive = true) // Set newly bought pass as selected active pass container
        appDao.insertPass(finalizedPass)
        
        appDao.insertNotification(
            NotificationLog(
                title = "Pass Created Successfully",
                message = "Your London Card ($id) is active. Go to first attraction to activate validity.",
                timestamp = System.currentTimeMillis()
            )
        )
        return finalizedPass
    }

    suspend fun activatePass(passId: String): Boolean {
        val pass = appDao.getPassById(passId) ?: return false
        if (pass.activationDate != null) return false // already activated
        val updated = pass.copy(
            activationDate = System.currentTimeMillis(),
            isActive = true
        )
        appDao.updatePass(updated)
        appDao.insertNotification(
            NotificationLog(
                title = "London Card Activated!",
                message = "Your 4-day validity window has commenced. Safe travels!",
                timestamp = System.currentTimeMillis()
            )
        )
        return true
    }

    suspend fun selectPass(passId: String) {
        val currentPasses = appDao.getAllUserPasses().first()
        currentPasses.forEach {
            if (it.id == passId) {
                appDao.updatePass(it.copy(isActive = true))
            } else if (it.isActive) {
                appDao.updatePass(it.copy(isActive = false))
            }
        }
    }

    // --- SCAN / REDEMPTION FLOWS ---
    // Invariant: An attraction redemption must only succeed when the card has a valid entitlement and the attraction is eligible.
    suspend fun redeemAttraction(passId: String, attractionId: String): RedemptionResult {
        val pass = appDao.getPassById(passId) ?: return RedemptionResult.Error("Invalid Card")
        val attraction = appDao.getAttractionById(attractionId) ?: return RedemptionResult.Error("Attraction not found")

        if (!attraction.includedInPass) {
            return RedemptionResult.Error("This attraction is not included in the London Card program.")
        }

        // Auto-activate card on first scan if it was not activated yet
        val now = System.currentTimeMillis()
        var updatedPass = pass
        if (pass.activationDate == null) {
            updatedPass = pass.copy(activationDate = now, isActive = true)
            appDao.updatePass(updatedPass)
            appDao.insertNotification(
                NotificationLog(
                    title = "London Card Activated",
                    message = "Pass activated upon entering ${attraction.name}. Enjoy your tour!",
                    timestamp = now
                )
            )
        }

        // If Flex pass, check limit
        if (updatedPass.passType.contains("FLEX", ignoreCase = true) && updatedPass.allowedAttractions > 0) {
            val pastRedemptions = appDao.getRedemptionsForPass(passId).first()
            val uniqueVisits = pastRedemptions.map { it.attractionId }.distinct()
            if (uniqueVisits.size >= updatedPass.allowedAttractions && !uniqueVisits.contains(attractionId)) {
                return RedemptionResult.Error("Entitlement limit reached for your Flex Card (${updatedPass.allowedAttractions} inclusions maximum).")
            }
            if (!uniqueVisits.contains(attractionId)) {
                val rem = max(0, updatedPass.remainingAttractions - 1)
                updatedPass = updatedPass.copy(remainingAttractions = rem)
                appDao.updatePass(updatedPass)
            }
        }

        // Success: Record redemption
        val redemption = Redemption(
            passId = passId,
            attractionId = attractionId,
            attractionName = attraction.name,
            timestamp = now,
            entryType = if (attraction.reservationRequired) "RESERVED" else "STANDARD",
            estimatedValueSaved = attraction.cardValue
        )
        appDao.insertRedemption(redemption)
        
        // Notify user of dynamic savings
        appDao.insertNotification(
            NotificationLog(
                title = "Redeemed: ${attraction.name}",
                message = "Scanned successfully. You saved £${String.format("%.2f", attraction.cardValue)} with your card!",
                timestamp = now
            )
        )

        return RedemptionResult.Success(redemption)
    }

    // --- BOOKING ENGINE ---
    suspend fun reserveBooking(type: String, targetName: String, dateTime: String, tickets: Int, price: Double = 0.0): Booking {
        val code = "LC-RES-${(100000..999999).random()}"
        val booking = Booking(
            type = type,
            targetName = targetName,
            dateTime = dateTime,
            ticketCount = tickets,
            status = "CONFIRMED",
            confirmationCode = code,
            pricePaid = price
        )
        appDao.insertBooking(booking)
        
        appDao.insertNotification(
            NotificationLog(
                title = "Reservation Confirmed",
                message = "Confirmed $tickets tickets for $targetName on $dateTime. Code: $code",
                timestamp = System.currentTimeMillis()
            )
        )
        return booking
    }

    suspend fun cancelBooking(id: Long) {
        // Simple mock cancel by deleting or updating state
        // To keep it simple, we don't have update but we can re-insert booking with cancelled status or delete it
        appDao.insertNotification(
            NotificationLog(
                title = "Booking Cancelled",
                message = "Your reservation has been cancelled and refunded successfully.",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // --- FAVORITES ---
    suspend fun toggleFavorite(attractionId: String) {
        val favFlow = appDao.isFavoriteFlow(attractionId).first()
        if (favFlow) {
            appDao.removeFavorite(Favorite(attractionId))
        } else {
            appDao.setFavorite(Favorite(attractionId))
        }
    }

    // --- INTELLIGENT ROUTE-OPTIMISED ITINERARY GENERATOR ---
    suspend fun generateIntelligentItinerary(
        tripLength: Int,
        interests: List<String>,
        pace: String, // RELAXED (2 stops/day), STEADY (3-4 stops/day), INTENSE (5 stops/day)
        budget: Double,
        isRainy: Boolean,
        hasChildren: Boolean,
        hasMobilityNeeds: Boolean,
        startLocation: String // coordinates string e.g. "51.5015,-0.1248"
    ) {
        val allList = appDao.getAllAttractions().first()
        if (allList.isEmpty()) return

        // Step 1: Filter eligible attractions based on parameters
        var filtered = allList.filter { attraction ->
            var score = 0
            // Match category
            if (interests.any { it.equals(attraction.category, ignoreCase = true) }) score += 10
            
            // Match weather mode
            if (isRainy && attraction.isRainFriendly) score += 8
            if (!isRainy && attraction.isSunFriendly) score += 8
            
            // Child friendliness
            if (hasChildren && attraction.isChildFriendly) score += 10
            
            // Exclude or penalty for high price if low budget
            if (budget < 50 && attraction.normalPrice > 25) score -= 5
            
            score >= 0
        }

        if (filtered.isEmpty()) {
            filtered = allList // Fallback if filters are too strict
        }

        // Setup pace limit (stops per day)
        val stopsPerDay = when (pace.uppercase()) {
            "RELAXED" -> 2
            "STEADY" -> 3
            else -> 4
        }

        val generatedItems = mutableListOf<ItineraryItem>()
        var currentCoordinates = startLocation.ifBlank { "51.5086,-0.1283" } // Default Trafalgar Square

        val pool = filtered.toMutableList()

        for (day in 1..tripLength) {
            // Pick stops geographically ordered
            var dayStops = 0
            
            // Slots available
            val slots = listOf("09:30", "11:30", "14:00", "16:30", "19:00")
            
            while (dayStops < stopsPerDay && pool.isNotEmpty()) {
                // Find closest attraction in the pool to currentCoordinates
                val closest = pool.minByOrNull { attraction ->
                    calculateDistance(currentCoordinates, attraction.coordinates)
                } ?: break
                
                pool.remove(closest)
                
                generatedItems.add(
                    ItineraryItem(
                        dayNumber = day,
                        attractionId = closest.id,
                        attractionName = closest.name,
                        timeSlot = slots.getOrNull(dayStops) ?: "12:00",
                        notes = "Recommended based on your preferences. Nearest Tube: ${closest.transportLinks}",
                        category = closest.category
                    )
                )
                
                // Move virtual location to this attraction to optimize next step
                currentCoordinates = closest.coordinates
                dayStops++
            }
        }

        // Bulk insert
        appDao.clearAllItineraries()
        appDao.insertItineraryItems(generatedItems)
        
        // Notify
        appDao.insertNotification(
            NotificationLog(
                title = "Smart Itinerary Built",
                message = "Custom optimized schedule generated for $tripLength days based on your interests.",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // --- GEOGRAPHIC DISTANCE CALCULATOR ---
    private fun calculateDistance(coord1: String, coord2: String): Double {
        try {
            val parts1 = coord1.split(",")
            val parts2 = coord2.split(",")
            val lat1 = parts1[0].toDouble()
            val lon1 = parts1[1].toDouble()
            val lat2 = parts2[0].toDouble()
            val lon2 = parts2[1].toDouble()

            val r = 6371.0 // Earth radius in km
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = sin(dLat / 2) * sin(dLat / 2) +
                    cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                    sin(dLon / 2) * sin(dLon / 2)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return r * c
        } catch (e: Exception) {
            return 999.0 // Error fallback high distance
        }
    }
}

sealed class RedemptionResult {
    data class Success(val redemption: Redemption) : RedemptionResult()
    data class Error(val message: String) : RedemptionResult()
}
