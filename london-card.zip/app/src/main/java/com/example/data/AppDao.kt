package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- ATTRACTIONS ---
    @Query("SELECT * FROM attractions ORDER BY category, name")
    fun getAllAttractions(): Flow<List<Attraction>>

    @Query("SELECT * FROM attractions WHERE id = :id")
    suspend fun getAttractionById(id: String): Attraction?

    @Query("SELECT * FROM attractions WHERE category = :category")
    fun getAttractionsByCategory(category: String): Flow<List<Attraction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttractions(attractions: List<Attraction>)

    @Query("SELECT COUNT(*) FROM attractions")
    suspend fun getAttractionsCount(): Int

    // --- USER PASSES ---
    @Query("SELECT * FROM user_passes ORDER BY purchaseDate DESC")
    fun getAllUserPasses(): Flow<List<UserPass>>

    @Query("SELECT * FROM user_passes WHERE isActive = 1 LIMIT 1")
    fun getActivePass(): Flow<UserPass?>

    @Query("SELECT * FROM user_passes WHERE id = :id")
    suspend fun getPassById(id: String): UserPass?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPass(pass: UserPass)

    @Update
    suspend fun updatePass(pass: UserPass)

    @Query("DELETE FROM user_passes")
    suspend fun clearAllPasses()

    // --- REDEMPTIONS ---
    @Query("SELECT * FROM redemptions ORDER BY timestamp DESC")
    fun getAllRedemptions(): Flow<List<Redemption>>

    @Query("SELECT * FROM redemptions WHERE passId = :passId")
    fun getRedemptionsForPass(passId: String): Flow<List<Redemption>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRedemption(redemption: Redemption)

    @Query("DELETE FROM redemptions")
    suspend fun clearRedemptions()

    // --- ITINERARIES ---
    @Query("SELECT * FROM itinerary_items ORDER BY dayNumber, timeSlot")
    fun getAllItineraryItems(): Flow<List<ItineraryItem>>

    @Query("SELECT * FROM itinerary_items WHERE dayNumber = :dayNumber ORDER BY timeSlot")
    fun getItineraryForDay(dayNumber: Int): Flow<List<ItineraryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItineraryItems(items: List<ItineraryItem>)

    @Query("DELETE FROM itinerary_items WHERE dayNumber = :dayNumber")
    suspend fun deleteItineraryForDay(dayNumber: Int)

    @Query("DELETE FROM itinerary_items")
    suspend fun clearAllItineraries()

    // --- FAVORITES ---
    @Query("SELECT * FROM favorites")
    fun getAllFavorites(): Flow<List<Favorite>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setFavorite(favorite: Favorite)

    @Delete
    suspend fun removeFavorite(favorite: Favorite)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE attractionId = :attractionId)")
    fun isFavoriteFlow(attractionId: String): Flow<Boolean>

    // --- BOOKINGS ---
    @Query("SELECT * FROM bookings ORDER BY id DESC")
    fun getAllBookings(): Flow<List<Booking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: Booking)

    @Update
    suspend fun updateBooking(booking: Booking)

    @Query("DELETE FROM bookings")
    suspend fun clearAllBookings()

    // --- NOTIFICATIONS ---
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationLog)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)
}
