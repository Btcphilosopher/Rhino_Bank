package com.example.data

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini Request and Response Schemas ---

data class GeminiRequest(
    val contents: List<ContentPart>,
    val systemInstruction: ContentPart? = null,
    val generationConfig: GenConfig? = null
)

data class ContentPart(
    val parts: List<TextPart>
)

data class TextPart(
    val text: String
)

data class GenConfig(
    val temperature: Float? = 0.7f,
    val maxOutputTokens: Int? = 1000
)

data class GeminiResponse(
    val candidates: List<Candidate>?
)

data class Candidate(
    val content: ContentPart?
)

// --- Retrofit Api Interface ---

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

// --- Gemini Retrofit Service Client ---

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApi::class.java)
    }

    suspend fun getConciergeResponse(
        userMessage: String,
        activePass: UserPass?,
        redemptions: List<Redemption>,
        attractions: List<Attraction>,
        isRainy: Boolean
    ): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return "LONDON INTELLIGENCE: API Key is unconfigured. Please insert a real GEMINI_API_KEY into the Secrets Panel.\n\nIn the meantime, let me guide you locally: I highly recommend visiting the Westminster area! For rainy afternoons, the British Museum and Tate Modern are excellent covered choices."
        }

        // Build a highly-contextual system instruction
        val attractionsContext = attractions.joinToString("\n") { 
            "- ${it.name} in ${it.location} (Category: ${it.category}, Price: £${it.normalPrice}, Included in Pass: ${it.includedInPass}, Rain-friendly: ${it.isRainFriendly}, Kids-friendly: ${it.isChildFriendly})"
        }
        
        val passStatus = if (activePass != null) {
            "Active London Card ID: ${activePass.id} (${activePass.passType}), bought for ${activePass.validityDays} Days. Scanned in ${redemptions.size} places."
        } else {
            "No active London Card purchased yet."
        }

        val weatherStatus = if (isRainy) "Currently RAINING in London (Indoor attractions and cafes are highly recommended!)." else "Currently SUNNY and dry."

        val systemPrompt = """
            You are the "LONDON INTELLIGENCE" AI Concierge, a highly sophisticated, British travel operating companion built into the LONDON CARD visitor pass application.
            Your tone is professional, sophisticated, architectural, helpful, and distinctly British. Avoid generic tourism clichés or overenthusiastic American marketing phrasing.
            
            USER PASS CONTEXT:
            $passStatus
            
            CURRENT WEATHER CONTEXT:
            $weatherStatus
            
            SYNTHETIC ATTRACTIONS CATALOG:
            $attractionsContext
            
            GUIDELINES:
            1. Recommend actual attractions from the catalog when possible.
            2. Distinguish clearly between included attractions and separate premium integrations (e.g. Dishoom, Les Misérables, Borough Market).
            3. Consider weather! If it is raining, prioritize indoor museums, galleries, covered markets, and cafes.
            4. If the user asks for a itinerary, provide a structured, geographically optimized route (e.g., Westminster then Buckingham Palace, or Tower of London then Tower Bridge to minimize unnecessary tube journeys).
            5. Present yourself with professional metropolitan flair.
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(
                ContentPart(parts = listOf(TextPart(text = userMessage)))
            ),
            systemInstruction = ContentPart(parts = listOf(TextPart(text = systemPrompt))),
            generationConfig = GenConfig(temperature = 0.6f)
        )

        return try {
            val response = api.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "LONDON INTELLIGENCE: No response content received. Please try again."
        } catch (e: Exception) {
            Log.e("GeminiClient", "API error", e)
            "LONDON INTELLIGENCE: Connection timeout or query exception: ${e.localizedMessage}. Please ensure your API key in Secrets panel is active and valid."
        }
    }
}
