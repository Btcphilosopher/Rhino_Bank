package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserRole
import com.example.ui.components.DemoDialog
import com.example.ui.components.TopNavBar
import com.example.ui.screens.DeliveryDetailScreen
import com.example.ui.screens.DriverHomeScreen
import com.example.ui.screens.FarmerHomeScreen
import com.example.ui.screens.HaulierFreightScreen
import com.example.ui.screens.LogisticsCoordinatorScreen
import com.example.ui.screens.MarketFlowScreen
import com.example.ui.screens.QrScannerScreen
import com.example.ui.screens.ReceivingSiteScreen
import com.example.ui.theme.BritAgriTheme
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val darkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

            BritAgriTheme(darkTheme = darkTheme) {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val deliveries by viewModel.deliveries.collectAsStateWithLifecycle()
    val stocks by viewModel.stocks.collectAsStateWithLifecycle()
    val haulageJobs by viewModel.haulageJobs.collectAsStateWithLifecycle()
    val selectedDelivery by viewModel.selectedDelivery.collectAsStateWithLifecycle()
    val eventsForSelected by viewModel.eventsForSelected.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val isOfflineMode by viewModel.isOfflineMode.collectAsStateWithLifecycle()
    val syncMessage by viewModel.syncMessage.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val showDemoDialog by viewModel.showDemoDialog.collectAsStateWithLifecycle()

    LaunchedEffect(syncMessage) {
        syncMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopNavBar(
                currentRole = currentRole,
                onRoleChange = { viewModel.setRole(it) },
                isOfflineMode = isOfflineMode,
                onToggleOffline = { viewModel.toggleOfflineMode() },
                isDarkTheme = isDarkTheme,
                onToggleDarkTheme = { viewModel.toggleDarkTheme() },
                onOpenDemos = { viewModel.setShowDemoDialog(true) }
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == "HOME",
                    onClick = { viewModel.setSelectedTab("HOME") },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_home")
                )
                NavigationBarItem(
                    selected = selectedTab == "DELIVERIES",
                    onClick = { viewModel.setSelectedTab("DELIVERIES") },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Deliveries") },
                    label = { Text("Dispatch", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_dispatch")
                )
                NavigationBarItem(
                    selected = selectedTab == "FLOW",
                    onClick = { viewModel.setSelectedTab("FLOW") },
                    icon = { Icon(Icons.Default.Grain, contentDescription = "Flow") },
                    label = { Text("Flow Map", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_flow_map")
                )
                NavigationBarItem(
                    selected = selectedTab == "FREIGHT",
                    onClick = { viewModel.setSelectedTab("FREIGHT") },
                    icon = { Icon(Icons.Default.Route, contentDescription = "Freight") },
                    label = { Text("Freight", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_freight")
                )
                NavigationBarItem(
                    selected = selectedTab == "DETAIL",
                    onClick = { viewModel.setSelectedTab("DETAIL") },
                    icon = { Icon(Icons.Default.Description, contentDescription = "Detail") },
                    label = { Text("Record 360", fontSize = 10.sp) },
                    modifier = Modifier.testTag("tab_record_360")
                )
                NavigationBarItem(
                    selected = selectedTab == "QR_SCAN",
                    onClick = { viewModel.setSelectedTab("QR_SCAN") },
                    icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "2FA Scan") },
                    label = { Text("2FA Sign", fontSize = 10.sp) },
                    modifier = Modifier.testTag("tab_2fa_sign")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                "HOME" -> {
                    when (currentRole) {
                        UserRole.FARMER -> FarmerHomeScreen(
                            deliveries = deliveries,
                            stocks = stocks,
                            onSelectDelivery = { id ->
                                viewModel.selectDelivery(id)
                                viewModel.setSelectedTab("DETAIL")
                            },
                            onNavigateTab = { tab -> viewModel.setSelectedTab(tab) },
                            onQuickCreateLoad = { viewModel.triggerDemo(4) }
                        )

                        UserRole.DRIVER -> DriverHomeScreen(
                            deliveries = deliveries,
                            onAdvanceState = { id, state, actor, loc ->
                                viewModel.advanceState(id, state, actor, loc)
                            },
                            onSelectDelivery = { id ->
                                viewModel.selectDelivery(id)
                                viewModel.setSelectedTab("DETAIL")
                            }
                        )

                        UserRole.LOGISTICS_COORDINATOR -> LogisticsCoordinatorScreen(
                            deliveries = deliveries,
                            onSelectDelivery = { id ->
                                viewModel.selectDelivery(id)
                                viewModel.setSelectedTab("DETAIL")
                            }
                        )

                        UserRole.RECEIVING_OPERATOR -> ReceivingSiteScreen(
                            delivery = selectedDelivery,
                            onRecordWeights = { id, gross, tare, isOrigin ->
                                viewModel.updateWeights(id, gross, tare, isOrigin)
                            },
                            onRecordQuality = { id, m, p, sp, status, sampleId ->
                                viewModel.updateQuality(id, m, p, sp, status, sampleId)
                            },
                            onSignPod = { id, rec, drv ->
                                viewModel.signPod(id, rec, drv)
                            }
                        )

                        UserRole.HAULIER -> HaulierFreightScreen(
                            haulageJobs = haulageJobs,
                            onAcceptJob = { viewModel.triggerDemo(4) }
                        )

                        UserRole.MARKET_OPERATOR -> MarketFlowScreen(
                            deliveries = deliveries,
                            onSelectDelivery = { id ->
                                viewModel.selectDelivery(id)
                                viewModel.setSelectedTab("DETAIL")
                            }
                        )
                    }
                }

                "DELIVERIES" -> LogisticsCoordinatorScreen(
                    deliveries = deliveries,
                    onSelectDelivery = { id ->
                        viewModel.selectDelivery(id)
                        viewModel.setSelectedTab("DETAIL")
                    }
                )

                "FLOW" -> MarketFlowScreen(
                    deliveries = deliveries,
                    onSelectDelivery = { id ->
                        viewModel.selectDelivery(id)
                        viewModel.setSelectedTab("DETAIL")
                    }
                )

                "FREIGHT" -> HaulierFreightScreen(
                    haulageJobs = haulageJobs,
                    onAcceptJob = { viewModel.triggerDemo(4) }
                )

                "DETAIL" -> DeliveryDetailScreen(
                    delivery = selectedDelivery,
                    events = eventsForSelected,
                    reconciliation = selectedDelivery?.let { viewModel.getReconciliation(it) },
                    onAdvanceState = { id, state, actor, loc ->
                        viewModel.advanceState(id, state, actor, loc)
                    },
                    onReleaseSettlement = { viewModel.triggerDemo(1) }
                )

                "QR_SCAN" -> QrScannerScreen(
                    deliveries = deliveries,
                    selectedDelivery = selectedDelivery,
                    onSelectDelivery = { id -> viewModel.selectDelivery(id) },
                    onSignContractWith2FA = { id, totp, signedBy ->
                        viewModel.signContractWith2FA(id, totp, signedBy)
                    }
                )
            }
        }

        if (showDemoDialog) {
            DemoDialog(
                onDismiss = { viewModel.setShowDemoDialog(false) },
                onTriggerDemo = { demoNum ->
                    viewModel.triggerDemo(demoNum)
                }
            )
        }
    }
}
