package com.example.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.model.DeliveryEntity
import com.example.data.model.DeliveryEventEntity
import com.example.data.model.DeliveryState
import com.example.data.model.FarmStockEntity
import com.example.data.model.HaulageJobEntity
import kotlinx.coroutines.flow.Flow

class Converters {
    @TypeConverter
    fun fromDeliveryState(state: DeliveryState): String = state.name

    @TypeConverter
    fun toDeliveryState(stateString: String): DeliveryState = try {
        DeliveryState.valueOf(stateString)
    } catch (e: Exception) {
        DeliveryState.TRADE_CREATED
    }
}

@Dao
interface DeliveryDao {
    @Query("SELECT * FROM deliveries ORDER BY lastUpdated DESC")
    fun getAllDeliveries(): Flow<List<DeliveryEntity>>

    @Query("SELECT * FROM deliveries WHERE deliveryId = :id")
    fun getDeliveryById(id: String): Flow<DeliveryEntity?>

    @Query("SELECT * FROM deliveries WHERE deliveryId = :id")
    suspend fun getDeliveryByIdSync(id: String): DeliveryEntity?

    @Query("SELECT * FROM deliveries WHERE driver = :driverName ORDER BY lastUpdated DESC")
    fun getDeliveriesForDriver(driverName: String): Flow<List<DeliveryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(delivery: DeliveryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(deliveries: List<DeliveryEntity>)

    @Query("UPDATE deliveries SET status = :status, lastUpdated = :timestamp WHERE deliveryId = :id")
    suspend fun updateStatus(id: String, status: DeliveryState, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM deliveries")
    suspend fun clearAll()
}

@Dao
interface DeliveryEventDao {
    @Query("SELECT * FROM delivery_events WHERE deliveryId = :deliveryId ORDER BY timestamp ASC")
    fun getEventsForDelivery(deliveryId: String): Flow<List<DeliveryEventEntity>>

    @Query("SELECT * FROM delivery_events WHERE syncStatus = 'LOCAL' ORDER BY timestamp ASC")
    suspend fun getUnsyncedEvents(): List<DeliveryEventEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: DeliveryEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<DeliveryEventEntity>)

    @Query("UPDATE delivery_events SET syncStatus = :syncStatus WHERE eventId = :eventId")
    suspend fun updateSyncStatus(eventId: String, syncStatus: String)
}

@Dao
interface FarmStockDao {
    @Query("SELECT * FROM farm_stocks")
    fun getAllStocks(): Flow<List<FarmStockEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStocks(stocks: List<FarmStockEntity>)

    @Query("UPDATE farm_stocks SET totalStockTonnes = :total, reservedStockTonnes = :reserved WHERE commodity = :commodity")
    suspend fun updateStock(commodity: String, total: Double, reserved: Double)
}

@Dao
interface HaulageJobDao {
    @Query("SELECT * FROM haulage_jobs")
    fun getAllJobs(): Flow<List<HaulageJobEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: HaulageJobEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJobs(jobs: List<HaulageJobEntity>)

    @Query("UPDATE haulage_jobs SET status = :status WHERE jobId = :jobId")
    suspend fun updateJobStatus(jobId: String, status: String)
}

@Database(
    entities = [
        DeliveryEntity::class,
        DeliveryEventEntity::class,
        FarmStockEntity::class,
        HaulageJobEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun deliveryDao(): DeliveryDao
    abstract fun deliveryEventDao(): DeliveryEventDao
    abstract fun farmStockDao(): FarmStockDao
    abstract fun haulageJobDao(): HaulageJobDao
}
