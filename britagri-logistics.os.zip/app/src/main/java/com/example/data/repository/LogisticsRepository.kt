package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.db.AppDatabase
import com.example.data.model.DeliveryEntity
import com.example.data.model.DeliveryEventEntity
import com.example.data.model.DeliveryState
import com.example.data.model.FarmStockEntity
import com.example.data.model.HaulageJobEntity
import com.example.data.model.MarketTradeReconciliation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

class LogisticsRepository(context: Context) {

    private val db = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "britagri_logistics.db"
    ).fallbackToDestructiveMigration().build()

    val deliveryDao = db.deliveryDao()
    val deliveryEventDao = db.deliveryEventDao()
    val farmStockDao = db.farmStockDao()
    val haulageJobDao = db.haulageJobDao()

    private val scope = CoroutineScope(Dispatchers.IO)

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    private val _syncMessage = MutableStateFlow<String?>(null)
    val syncMessage: StateFlow<String?> = _syncMessage.asStateFlow()

    init {
        scope.launch {
            seedInitialSyntheticData()
        }
    }

    fun setOfflineMode(offline: Boolean) {
        _isOfflineMode.value = offline
    }

    suspend fun seedInitialSyntheticData() {
        val existing = deliveryDao.getAllDeliveries().first()
        if (existing.isNotEmpty()) return

        val now = System.currentTimeMillis()

        // 1. Deliveries
        val d1 = DeliveryEntity(
            deliveryId = "DEL-48291",
            tradeId = "BRI-2026-004281",
            seller = "Lincolnshire Farms Ltd (Grain Store #2)",
            buyer = "East Midlands Flour Mill, Selby",
            commodity = "Feed Wheat",
            grade = "Group 4 High Yield",
            contractQuantity = 240.0,
            actualQuantity = 238.9,
            unit = "tonnes",
            pricePerTonne = 184.0,
            origin = "Fenland Yard, Boston, Lincs",
            originRegion = "Lincolnshire",
            destination = "Ouse Mill, Selby, N.Yorks",
            destRegion = "Yorkshire",
            collectionWindow = "08:00 - 10:00",
            deliveryWindow = "12:00 - 15:00",
            haulier = "Smith Agricultural Haulage",
            driver = "James Smith",
            vehicle = "AB12 CDE",
            trailer = "XY34 678",
            status = DeliveryState.IN_TRANSIT,
            originGrossWeightKg = 44820.0,
            originTareWeightKg = 16320.0,
            originNetWeightKg = 28500.0,
            destGrossWeightKg = 44620.0,
            destTareWeightKg = 16320.0,
            destNetWeightKg = 28300.0,
            weightSource = "WEIGHBRIDGE",
            moisturePct = 14.1,
            proteinPct = 10.8,
            specificWeightKgHl = 76.4,
            temperatureC = 17.2,
            qualityStatus = "ACCEPTED",
            sampleId = "SAMPLE-A49281",
            sealNumber = "UK-SEAL-88392",
            photoCount = 3,
            lastUpdated = now
        )

        val d2 = DeliveryEntity(
            deliveryId = "DEL-48292",
            tradeId = "BRI-2026-004282",
            seller = "Norfolk Malting Barley Co-op",
            buyer = "East Anglia Brewery, Bury St Edmunds",
            commodity = "Malting Barley",
            grade = "Flagon Premium",
            contractQuantity = 120.0,
            actualQuantity = 119.2,
            unit = "tonnes",
            pricePerTonne = 210.0,
            origin = "Holkham Estate, Norfolk",
            originRegion = "Norfolk",
            destination = "Bury St Edmunds Maltings",
            destRegion = "East Anglia",
            collectionWindow = "09:00 - 11:00",
            deliveryWindow = "13:00 - 16:00",
            haulier = "Anglia Rural Express",
            driver = "David Miller",
            vehicle = "NO55 FLK",
            trailer = "TR77 NFK",
            status = DeliveryState.ARRIVED_AT_FARM,
            originGrossWeightKg = 0.0,
            originTareWeightKg = 0.0,
            originNetWeightKg = 0.0,
            weightSource = "FARM_SCALE",
            moisturePct = 12.8,
            proteinPct = 9.8,
            specificWeightKgHl = 68.2,
            qualityStatus = "PENDING",
            sealNumber = "UK-SEAL-11029",
            photoCount = 1,
            lastUpdated = now - 3600000
        )

        val d3 = DeliveryEntity(
            deliveryId = "DEL-48293",
            tradeId = "BRI-2026-004283",
            seller = "Cambridgeshire Potato Growers",
            buyer = "Midlands Potato Processing Ltd",
            commodity = "Maris Piper Potatoes",
            grade = "Grade A Processing",
            contractQuantity = 220.0,
            actualQuantity = 0.0,
            unit = "tonnes",
            pricePerTonne = 260.0,
            origin = "Ely Fen Store, Cambridgeshire",
            originRegion = "Cambridgeshire",
            destination = "Peterborough Processing Hub",
            destRegion = "Midlands",
            collectionWindow = "10:30 - 12:30",
            deliveryWindow = "14:00 - 17:00",
            haulier = "Fenland Chilled Logistics",
            driver = "Robert Taylor",
            vehicle = "CB22 POT",
            trailer = "RE24 POT",
            status = DeliveryState.DELIVERY_INSTRUCTION,
            lastUpdated = now - 7200000
        )

        val d4 = DeliveryEntity(
            deliveryId = "DEL-48294",
            tradeId = "BRI-2026-004284",
            seller = "Yorkshire Milling Supplies",
            buyer = "Port of Tilbury Grain Terminal",
            commodity = "Milling Wheat",
            grade = "Group 1 Breadmaking",
            contractQuantity = 500.0,
            actualQuantity = 498.5,
            unit = "tonnes",
            pricePerTonne = 225.0,
            origin = "Selby Silos, North Yorkshire",
            originRegion = "Yorkshire",
            destination = "Berth 4, Port of Tilbury, Essex",
            destRegion = "Tilbury Port",
            collectionWindow = "06:00 - 08:00",
            deliveryWindow = "11:00 - 14:00",
            haulier = "Humber Grain Haulage",
            driver = "Mark Briggs",
            vehicle = "YK71 WHT",
            trailer = "TIL-882",
            status = DeliveryState.DELIVERY_ACCEPTED,
            originGrossWeightKg = 44500.0,
            originTareWeightKg = 16100.0,
            originNetWeightKg = 28400.0,
            destGrossWeightKg = 44400.0,
            destTareWeightKg = 16100.0,
            destNetWeightKg = 28300.0,
            moisturePct = 13.2,
            proteinPct = 12.4,
            specificWeightKgHl = 78.9,
            qualityStatus = "ACCEPTED",
            receiverSignature = "J. Robinson (Tilbury Port Op)",
            driverSignature = "M. Briggs",
            podSignedAt = now - 1800000,
            settlementStatus = "SETTLEMENT_READY",
            lastUpdated = now - 1800000
        )

        deliveryDao.insertAll(listOf(d1, d2, d3, d4))

        // 2. Events for d1
        val events = listOf(
            DeliveryEventEntity("EV-01", "DEL-48291", "TRADE_CREATED", now - 14400000, "MARKET.OS System", "Server", "London", "{}"),
            DeliveryEventEntity("EV-02", "DEL-48291", "HAULAGE_ACCEPTED", now - 12600000, "Smith Haulage", "iPad Op", "Lincoln", "{}"),
            DeliveryEventEntity("EV-03", "DEL-48291", "DRIVER_ASSIGNED", now - 10800000, "Dispatcher", "Desktop", "Boston", "{\"driver\":\"James Smith\",\"truck\":\"AB12 CDE\"}"),
            DeliveryEventEntity("EV-04", "DEL-48291", "ARRIVED_AT_FARM", now - 7200000, "James Smith", "Phone Field", "Fenland Yard", "{\"gps\":\"52.978,-0.026\"}"),
            DeliveryEventEntity("EV-05", "DEL-48291", "LOADING", now - 5400000, "James Smith & Farm Op", "Phone Field", "Fenland Yard", "{\"loadedTonnes\":28.5}"),
            DeliveryEventEntity("EV-06", "DEL-48291", "WEIGHED", now - 4500000, "Fenland Weighbridge", "Weighbridge Terminal", "Boston", "{\"gross\":44820,\"tare\":16320,\"net\":28500}"),
            DeliveryEventEntity("EV-07", "DEL-48291", "DEPARTED", now - 3600000, "James Smith", "Phone Field", "A16 Northbound", "{}")
        )
        deliveryEventDao.insertEvents(events)

        // 3. Stocks
        val stocks = listOf(
            FarmStockEntity("Feed Wheat", 420.0, 240.0, 180.0, 184.0),
            FarmStockEntity("Malting Barley", 180.0, 120.0, 60.0, 210.0),
            FarmStockEntity("Oilseed Rape", 75.0, 0.0, 75.0, 390.0),
            FarmStockEntity("Maris Piper Potatoes", 220.0, 220.0, 0.0, 260.0),
            FarmStockEntity("NPK Fertiliser 20-10-10", 38.0, 0.0, 38.0, 340.0)
        )
        farmStockDao.insertStocks(stocks)

        // 4. Haulage Jobs
        val jobs = listOf(
            HaulageJobEntity(
                jobId = "JOB-7701",
                tradeId = "BRI-2026-004285",
                commodity = "Feed Wheat",
                origin = "Lincolnshire (Fenland)",
                destination = "Yorkshire (Selby Mill)",
                tonnes = 240.0,
                dateWindow = "23 SEP 08:00 - 14:00",
                ratePerTonne = 8.40,
                vehicleType = "44t Articulated Tipper",
                status = "AVAILABLE",
                backhaulAvailable = true,
                backhaulDetails = "Yorkshire Mill -> Lincolnshire Fertiliser Depot (132 mi)",
                backhaulSavings = 280.0
            ),
            HaulageJobEntity(
                jobId = "JOB-7702",
                tradeId = "BRI-2026-004286",
                commodity = "Malting Barley",
                origin = "Norfolk (Holkham)",
                destination = "Suffolk (Bury St Edmunds)",
                tonnes = 120.0,
                dateWindow = "24 SEP 09:00 - 15:00",
                ratePerTonne = 9.10,
                vehicleType = "29t Rigid Bulker",
                status = "AVAILABLE",
                backhaulAvailable = false
            ),
            HaulageJobEntity(
                jobId = "JOB-7703",
                tradeId = "BRI-2026-004287",
                commodity = "Potatoes",
                origin = "Cambridgeshire (Ely)",
                destination = "Peterborough Hub",
                tonnes = 220.0,
                dateWindow = "25 SEP 07:00 - 12:00",
                ratePerTonne = 7.80,
                vehicleType = "Temperature Controlled Box",
                status = "AVAILABLE",
                backhaulAvailable = true,
                backhaulDetails = "Peterborough -> Ely Seed Potato Crates",
                backhaulSavings = 195.0
            )
        )
        haulageJobDao.insertJobs(jobs)
    }

    suspend fun transitionState(
        deliveryId: String,
        nextState: DeliveryState,
        actor: String,
        device: String,
        location: String,
        payloadJson: String = "{}"
    ) {
        val current = deliveryDao.getDeliveryByIdSync(deliveryId) ?: return
        val now = System.currentTimeMillis()

        deliveryDao.updateStatus(deliveryId, nextState, now)

        val syncStatus = if (_isOfflineMode.value) "LOCAL" else "SYNCED"
        val event = DeliveryEventEntity(
            eventId = "EV-${UUID.randomUUID().toString().take(8)}",
            deliveryId = deliveryId,
            eventType = nextState.name,
            timestamp = now,
            actor = actor,
            device = device,
            location = location,
            payloadJson = payloadJson,
            syncStatus = syncStatus
        )
        deliveryEventDao.insertEvent(event)

        if (_isOfflineMode.value) {
            _syncMessage.value = "Action saved locally (OFFLINE MODE). Queued for sync."
        }
    }

    suspend fun updateWeights(
        deliveryId: String,
        grossKg: Double,
        tareKg: Double,
        isOrigin: Boolean,
        source: String = "WEIGHBRIDGE"
    ) {
        val current = deliveryDao.getDeliveryByIdSync(deliveryId) ?: return
        val netKg = (grossKg - tareKg).coerceAtLeast(0.0)
        val tonnes = netKg / 1000.0

        val updated = if (isOrigin) {
            current.copy(
                originGrossWeightKg = grossKg,
                originTareWeightKg = tareKg,
                originNetWeightKg = netKg,
                weightSource = source,
                lastUpdated = System.currentTimeMillis()
            )
        } else {
            current.copy(
                destGrossWeightKg = grossKg,
                destTareWeightKg = tareKg,
                destNetWeightKg = netKg,
                actualQuantity = tonnes,
                weightSource = source,
                lastUpdated = System.currentTimeMillis()
            )
        }
        deliveryDao.insertOrUpdate(updated)

        val type = if (isOrigin) "ORIGIN_WEIGHT_RECORDED" else "DESTINATION_WEIGHT_RECORDED"
        transitionState(
            deliveryId = deliveryId,
            nextState = if (isOrigin) DeliveryState.WEIGHED else DeliveryState.FINAL_WEIGHT_CONFIRMED,
            actor = "Weighbridge Operator",
            device = "Terminal Scale",
            location = if (isOrigin) current.origin else current.destination,
            payloadJson = "{\"grossKg\":$grossKg,\"tareKg\":$tareKg,\"netKg\":$netKg,\"tonnes\":$tonnes,\"source\":\"$source\"}"
        )
    }

    suspend fun updateQuality(
        deliveryId: String,
        moisture: Double,
        protein: Double,
        spWeight: Double,
        status: String,
        sampleId: String
    ) {
        val current = deliveryDao.getDeliveryByIdSync(deliveryId) ?: return
        val updated = current.copy(
            moisturePct = moisture,
            proteinPct = protein,
            specificWeightKgHl = spWeight,
            qualityStatus = status,
            sampleId = sampleId,
            lastUpdated = System.currentTimeMillis()
        )
        deliveryDao.insertOrUpdate(updated)

        transitionState(
            deliveryId = deliveryId,
            nextState = DeliveryState.QUALITY_CHECKED,
            actor = "Receiving Lab Operator",
            device = "Grain Analyzer",
            location = current.destination,
            payloadJson = "{\"moisture\":$moisture,\"protein\":$protein,\"spWeight\":$spWeight,\"status\":\"$status\",\"sampleId\":\"$sampleId\"}"
        )
    }

    suspend fun completeProofOfDelivery(
        deliveryId: String,
        receiverSignature: String,
        driverSignature: String
    ) {
        val current = deliveryDao.getDeliveryByIdSync(deliveryId) ?: return
        val now = System.currentTimeMillis()
        val updated = current.copy(
            receiverSignature = receiverSignature,
            driverSignature = driverSignature,
            podSignedAt = now,
            status = DeliveryState.DELIVERY_ACCEPTED,
            settlementStatus = "SETTLEMENT_READY",
            lastUpdated = now
        )
        deliveryDao.insertOrUpdate(updated)

        transitionState(
            deliveryId = deliveryId,
            nextState = DeliveryState.DELIVERY_ACCEPTED,
            actor = receiverSignature,
            device = "iPad Receiving Terminal",
            location = current.destination,
            payloadJson = "{\"receiverSignature\":\"$receiverSignature\",\"driverSignature\":\"$driverSignature\"}"
        )
    }

    suspend fun signContractWith2FA(
        deliveryId: String,
        totpCode: String,
        signedBy: String
    ) {
        val current = deliveryDao.getDeliveryByIdSync(deliveryId) ?: return
        val now = System.currentTimeMillis()
        val updated = current.copy(
            status = DeliveryState.DELIVERY_ACCEPTED,
            settlementStatus = "SETTLEMENT_READY",
            receiverSignature = "2FA Verified: $signedBy [TOTP: $totpCode]",
            podSignedAt = now,
            lastUpdated = now
        )
        deliveryDao.insertOrUpdate(updated)

        transitionState(
            deliveryId = deliveryId,
            nextState = DeliveryState.DELIVERY_ACCEPTED,
            actor = signedBy,
            device = "2FA QR Mobile Key",
            location = "Encrypted 2FA Terminal",
            payloadJson = "{\"totpCode\":\"$totpCode\",\"signedBy\":\"$signedBy\",\"timestamp\":$now,\"signatureType\":\"2FA_QR_SHA256\"}"
        )
        _syncMessage.value = "Contract $deliveryId successfully signed via 2FA QR! Proof sent to MARKET.OS."
    }

    suspend fun syncOfflineEvents(): Int {
        val unsynced = deliveryEventDao.getUnsyncedEvents()
        if (unsynced.isEmpty()) {
            _syncMessage.value = "All events are up to date."
            return 0
        }

        unsynced.forEach { event ->
            deliveryEventDao.updateSyncStatus(event.eventId, "SYNCED")
        }
        val count = unsynced.size
        _syncMessage.value = "Successfully synchronized $count offline events with MARKET.OS!"
        return count
    }

    fun calculateReconciliation(delivery: DeliveryEntity): MarketTradeReconciliation {
        val contract = delivery.contractQuantity
        val collected = if (delivery.originNetWeightKg > 0) delivery.originNetWeightKg / 1000.0 else contract
        val received = if (delivery.destNetWeightKg > 0) delivery.destNetWeightKg / 1000.0 else delivery.actualQuantity.ifZero(collected)

        val colVariance = collected - contract
        val transitVariance = received - collected

        val gross = received * delivery.pricePerTonne
        val qualityAdj = if (delivery.moisturePct > 15.0) -((delivery.moisturePct - 15.0) * 2.5 * received) else 0.0
        val freight = received * 7.40
        val handling = received * 1.20
        val netFarm = gross + qualityAdj - freight - handling

        return MarketTradeReconciliation(
            tradeId = delivery.tradeId,
            contractTonnes = contract,
            collectedTonnes = collected,
            receivedTonnes = received,
            collectionVarianceTonnes = colVariance,
            transitVarianceTonnes = transitVariance,
            contractPricePerTonne = delivery.pricePerTonne,
            grossValue = gross,
            qualityAdjustment = qualityAdj,
            freightCost = freight,
            handlingFee = handling,
            netFarmRealisation = netFarm,
            isSettlementReady = delivery.status == DeliveryState.DELIVERY_ACCEPTED || delivery.settlementStatus == "SETTLEMENT_READY"
        )
    }

    // Signature Demos Implementation
    suspend fun runDemo1FarmerSellsWheat() {
        val d1 = deliveryDao.getDeliveryByIdSync("DEL-48291") ?: return
        val now = System.currentTimeMillis()
        val resetD1 = d1.copy(
            status = DeliveryState.TRADE_CREATED,
            actualQuantity = 0.0,
            destGrossWeightKg = 0.0,
            destTareWeightKg = 0.0,
            destNetWeightKg = 0.0,
            receiverSignature = "",
            driverSignature = "",
            settlementStatus = "PENDING",
            lastUpdated = now
        )
        deliveryDao.insertOrUpdate(resetD1)

        // Step by step state progression simulation
        transitionState("DEL-48291", DeliveryState.HAULAGE_ACCEPTED, "Smith Haulage", "iPad Op", "Lincolnshire")
        transitionState("DEL-48291", DeliveryState.DRIVER_ASSIGNED, "Dispatcher", "Desktop", "Boston", "{\"driver\":\"James Smith\"}")
        transitionState("DEL-48291", DeliveryState.ARRIVED_AT_FARM, "James Smith", "Phone Field", "Fenland Yard")
        transitionState("DEL-48291", DeliveryState.LOADING, "Farm Loader", "Phone Field", "Grain Store #2")
        updateWeights("DEL-48291", grossKg = 44820.0, tareKg = 16320.0, isOrigin = true)
        transitionState("DEL-48291", DeliveryState.DEPARTED, "James Smith", "Phone Field", "A16 Northbound")
        transitionState("DEL-48291", DeliveryState.ARRIVED_AT_DESTINATION, "James Smith", "Phone Field", "Selby Mill")
        updateWeights("DEL-48291", grossKg = 44620.0, tareKg = 16320.0, isOrigin = false)
        updateQuality("DEL-48291", moisture = 14.1, protein = 10.8, spWeight = 76.4, status = "ACCEPTED", sampleId = "SAMPLE-A49281")
        completeProofOfDelivery("DEL-48291", receiverSignature = "Selby Grain Receiver (John Smith)", driverSignature = "James Smith")

        _syncMessage.value = "Demo 1 Complete: Full E2E Loop Executed. Settlement Ready on MARKET.OS!"
    }

    suspend fun runDemo2ShortDelivery() {
        val d1 = deliveryDao.getDeliveryByIdSync("DEL-48291") ?: return
        val now = System.currentTimeMillis()
        val shortD1 = d1.copy(
            contractQuantity = 240.0,
            originNetWeightKg = 239500.0, // 239.5t
            destNetWeightKg = 238900.0,   // 238.9t
            actualQuantity = 238.9,
            status = DeliveryState.WEIGHT_DISPUTED,
            disputeStatus = "OPEN",
            exceptionReason = "Short delivery detected: -1.1t contract variance (-0.6t transit)",
            lastUpdated = now
        )
        deliveryDao.insertOrUpdate(shortD1)
        transitionState(
            "DEL-48291",
            DeliveryState.WEIGHT_DISPUTED,
            "Selby Weighbridge",
            "Terminal",
            "Selby Mill",
            "{\"contract\":240.0,\"collected\":239.5,\"received\":238.9,\"variance\":-1.1}"
        )
        _syncMessage.value = "Demo 2 Triggered: Quantity Variance -1.1t flagged for review."
    }

    suspend fun runDemo3NoSignalOffline() {
        _isOfflineMode.value = true
        transitionState("DEL-48292", DeliveryState.LOADING, "David Miller", "Phone Field", "Holkham Estate")
        transitionState("DEL-48292", DeliveryState.WEIGHED, "Farm Scale", "Phone Field", "Holkham Yard", "{\"net\":29800}")
        transitionState("DEL-48292", DeliveryState.DEPARTED, "David Miller", "Phone Field", "A149")
        transitionState("DEL-48292", DeliveryState.ARRIVED_AT_DESTINATION, "David Miller", "Phone Field", "Bury St Edmunds")
        _syncMessage.value = "Demo 3 Executed: 4 actions recorded offline without mobile signal!"
    }

    suspend fun runDemo4HaulageMarket() {
        val job = HaulageJobEntity(
            jobId = "JOB-${UUID.randomUUID().toString().take(6)}",
            tradeId = "BRI-2026-009988",
            commodity = "Feed Wheat",
            origin = "Fenland Yard, Boston, Lincs",
            destination = "Ouse Mill, Selby, N.Yorks",
            tonnes = 240.0,
            dateWindow = "23 SEP 08:00 - 10:00",
            ratePerTonne = 8.40,
            vehicleType = "44t Articulated Tipper",
            status = "AVAILABLE",
            backhaulAvailable = true,
            backhaulDetails = "Selby -> Boston NPK Fertiliser (132 miles)",
            backhaulSavings = 280.0
        )
        haulageJobDao.insertJob(job)
        _syncMessage.value = "Demo 4 Posted: 240t Wheat Haulage requirement created on Freight Market!"
    }

    suspend fun runDemo5Backhaul() {
        _syncMessage.value = "Demo 5 Backhaul: Empty return 148 mi (£420) converted to Backhaul (£280 revenue). Net empty miles reduced by 90%!"
    }
}

private fun Double.ifZero(defaultVal: Double): Double = if (this == 0.0) defaultVal else this
