package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class DeliveryState(val label: String, val category: String) {
    TRADE_CREATED("Trade Created", "SCHEDULED"),
    DELIVERY_REQUIRED("Delivery Required", "SCHEDULED"),
    DELIVERY_INSTRUCTION("Delivery Instruction Sent", "SCHEDULED"),
    HAULAGE_REQUESTED("Haulage Requested", "SCHEDULED"),
    HAULAGE_ACCEPTED("Haulage Accepted", "SCHEDULED"),
    DRIVER_ASSIGNED("Driver Assigned", "SCHEDULED"),
    VEHICLE_ASSIGNED("Vehicle Assigned", "SCHEDULED"),
    EN_ROUTE_TO_COLLECTION("En Route to Farm", "IN_PROGRESS"),
    ARRIVED_AT_FARM("Arrived at Farm", "IN_PROGRESS"),
    LOADING("Loading", "IN_PROGRESS"),
    LOADED("Loaded", "IN_PROGRESS"),
    WEIGHED("Weighed at Farm", "IN_PROGRESS"),
    DEPARTED("Departed Origin", "IN_PROGRESS"),
    IN_TRANSIT("In Transit", "IN_PROGRESS"),
    ARRIVED_AT_DESTINATION("Arrived at Destination", "IN_PROGRESS"),
    UNLOADING("Unloading", "IN_PROGRESS"),
    RECEIVED("Received", "IN_PROGRESS"),
    QUALITY_CHECKED("Quality Checked", "IN_PROGRESS"),
    FINAL_WEIGHT_CONFIRMED("Final Weight Confirmed", "IN_PROGRESS"),
    DELIVERY_ACCEPTED("Delivery Accepted", "COMPLETED"),
    SETTLEMENT_READY("Settlement Ready", "COMPLETED"),
    SETTLED("Settled", "COMPLETED"),
    CLOSED("Closed", "COMPLETED"),

    // Exceptions & Disputes
    DELAYED("Delayed", "ATTENTION"),
    REJECTED("Rejected", "EXCEPTION"),
    PARTIALLY_ACCEPTED("Partially Accepted", "ATTENTION"),
    QUALITY_DISPUTED("Quality Disputed", "EXCEPTION"),
    WEIGHT_DISPUTED("Weight Disputed", "EXCEPTION"),
    CANCELLED("Cancelled", "EXCEPTION"),
    RETURNED("Returned", "EXCEPTION")
}

enum class UserRole(val title: String, val iconName: String) {
    FARMER("Farmer / Seller", "Agriculture"),
    DRIVER("Driver / Hauler", "LocalShipping"),
    LOGISTICS_COORDINATOR("Logistics Coordinator", "Dashboard"),
    RECEIVING_OPERATOR("Receiving Site / Weighbridge", "Scale"),
    HAULIER("Freight & Backhaul Market", "Route"),
    MARKET_OPERATOR("Market Execution & Flow", "Grain")
}

@Entity(tableName = "deliveries")
data class DeliveryEntity(
    @PrimaryKey val deliveryId: String,
    val tradeId: String,
    val seller: String,
    val buyer: String,
    val commodity: String,
    val grade: String,
    val contractQuantity: Double,
    val actualQuantity: Double,
    val unit: String = "tonnes",
    val pricePerTonne: Double,
    val origin: String,
    val originRegion: String = "Lincolnshire",
    val destination: String,
    val destRegion: String = "Yorkshire",
    val collectionWindow: String,
    val deliveryWindow: String,
    val haulier: String,
    val driver: String,
    val vehicle: String,
    val trailer: String,
    val status: DeliveryState,

    // Weight Records
    val originGrossWeightKg: Double = 0.0,
    val originTareWeightKg: Double = 0.0,
    val originNetWeightKg: Double = 0.0,
    val destGrossWeightKg: Double = 0.0,
    val destTareWeightKg: Double = 0.0,
    val destNetWeightKg: Double = 0.0,
    val weightSource: String = "WEIGHBRIDGE", // WEIGHBRIDGE, FARM_SCALE, RECEIVING_SCALE, MANUAL, ESTIMATED

    // Quality Records
    val moisturePct: Double = 14.0,
    val proteinPct: Double = 11.2,
    val specificWeightKgHl: Double = 76.5,
    val temperatureC: Double = 18.5,
    val qualityStatus: String = "PENDING", // ACCEPTED, DISCOUNTED, REJECTED, PENDING
    val sampleId: String = "",

    // Evidence & Signatures
    val sealNumber: String = "",
    val photoCount: Int = 0,
    val receiverSignature: String = "",
    val driverSignature: String = "",
    val podSignedAt: Long = 0L,

    // Dispute & Exceptions
    val exceptionReason: String = "",
    val disputeStatus: String = "NONE", // NONE, OPEN, UNDER_REVIEW, AGREED, SETTLED
    val settlementStatus: String = "PENDING", // PENDING, SETTLEMENT_READY, RELEASED, SETTLED
    val isOfflineCreated: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "delivery_events")
data class DeliveryEventEntity(
    @PrimaryKey val eventId: String,
    val deliveryId: String,
    val eventType: String,
    val timestamp: Long,
    val actor: String,
    val device: String,
    val location: String,
    val payloadJson: String,
    val syncStatus: String = "SYNCED" // LOCAL, SYNCING, SYNCED, CONFLICT, FAILED
)

@Entity(tableName = "farm_stocks")
data class FarmStockEntity(
    @PrimaryKey val commodity: String,
    val totalStockTonnes: Double,
    val reservedStockTonnes: Double,
    val allocatedStockTonnes: Double,
    val pricePerTonne: Double
) {
    val availableStockTonnes: Double get() = (totalStockTonnes - reservedStockTonnes).coerceAtLeast(0.0)
}

@Entity(tableName = "haulage_jobs")
data class HaulageJobEntity(
    @PrimaryKey val jobId: String,
    val tradeId: String,
    val commodity: String,
    val origin: String,
    val destination: String,
    val tonnes: Double,
    val dateWindow: String,
    val ratePerTonne: Double,
    val vehicleType: String = "44t Articulated",
    val status: String = "AVAILABLE", // AVAILABLE, BID_SUBMITTED, BOOKED
    val backhaulAvailable: Boolean = false,
    val backhaulDetails: String = "",
    val backhaulSavings: Double = 0.0
)

data class QualityRecord(
    val commodity: String,
    val grade: String,
    val moisturePct: Double,
    val proteinPct: Double,
    val specificWeightKgHl: Double,
    val contaminantsPct: Double = 0.1,
    val sampleId: String = "",
    val labResult: String = "PASS",
    val sampledBy: String = "Receiving Lab"
)

data class DigitalConsignment(
    val consignmentId: String,
    val tradeId: String,
    val consignor: String,
    val carrier: String,
    val consignee: String,
    val goodsDescription: String,
    val quantityTonnes: Double,
    val vehicleReg: String,
    val trailerReg: String,
    val cmrStandard: Boolean = true,
    val status: String = "ISSUED"
)

data class MarketTradeReconciliation(
    val tradeId: String,
    val contractTonnes: Double,
    val collectedTonnes: Double,
    val receivedTonnes: Double,
    val collectionVarianceTonnes: Double,
    val transitVarianceTonnes: Double,
    val contractPricePerTonne: Double,
    val grossValue: Double,
    val qualityAdjustment: Double,
    val freightCost: Double,
    val handlingFee: Double,
    val netFarmRealisation: Double,
    val isSettlementReady: Boolean
)

fun formatTimestamp(ms: Long): String {
    if (ms == 0L) return "-"
    val sdf = SimpleDateFormat("HH:mm - dd MMM yyyy", Locale.UK)
    return sdf.format(Date(ms))
}

fun formatTimeOnly(ms: Long): String {
    if (ms == 0L) return "-"
    val sdf = SimpleDateFormat("HH:mm", Locale.UK)
    return sdf.format(Date(ms))
}
