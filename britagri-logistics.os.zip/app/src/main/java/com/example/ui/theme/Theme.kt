package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrightGrainGold,
    onPrimary = DarkControlBackground,
    primaryContainer = LightAgriGreen,
    onPrimaryContainer = Color.White,
    secondary = LightSteelGrey,
    onSecondary = DarkControlBackground,
    tertiary = GrainGold,
    background = DarkControlBackground,
    onBackground = WarmWhiteSurface,
    surface = DarkControlCard,
    onSurface = WarmWhiteSurface,
    surfaceVariant = DarkControlCardHighlight,
    onSurfaceVariant = LightSteelGrey,
    error = AgriRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = DeepAgriGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD3E8DC),
    onPrimaryContainer = DeepAgriGreen,
    secondary = FleetBlue,
    onSecondary = Color.White,
    tertiary = GrainGold,
    background = WarmWhiteSurface,
    onBackground = Color(0xFF1A1C1E),
    surface = WarmCardSurface,
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = OffWhiteBackground,
    onSurfaceVariant = SteelGrey,
    error = AgriRed,
    onError = Color.White
)

@Composable
fun BritAgriTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
