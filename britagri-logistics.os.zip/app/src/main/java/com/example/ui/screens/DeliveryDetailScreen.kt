package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeliveryEntity
import com.example.data.model.DeliveryEventEntity
import com.example.data.model.DeliveryState
import com.example.data.model.MarketTradeReconciliation
import com.example.data.model.formatTimestamp
import com.example.ui.theme.AgriRed
import com.example.ui.theme.GrainGold
import com.example.ui.theme.StatusGreen

@Composable
fun DeliveryDetailScreen(
    delivery: DeliveryEntity?,
    events: List<DeliveryEventEntity>,
    reconciliation: MarketTradeReconciliation?,
    onAdvanceState: (deliveryId: String, nextState: DeliveryState, actor: String, location: String) -> Unit,
    onReleaseSettlement: () -> Unit
) {
    if (delivery == null) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Select a delivery to inspect details.", fontWeight = FontWeight.Bold)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("delivery_detail_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Delivery Primary Hero Block
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DELIVERY ID: ${delivery.deliveryId}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = delivery.status.label.uppercase(),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = delivery.commodity,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Trade: ${delivery.tradeId} • Grade: ${delivery.grade}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(14.dp))

                    DetailRow("SELLER / ORIGIN", "${delivery.seller}\n${delivery.origin}")
                    Spacer(modifier = Modifier.height(8.dp))
                    DetailRow("BUYER / DESTINATION", "${delivery.buyer}\n${delivery.destination}")
                    Spacer(modifier = Modifier.height(8.dp))
                    DetailRow("HAULIER & DRIVER", "${delivery.haulier} • ${delivery.driver} (${delivery.vehicle})")
                }
            }
        }

        // Market Reconciliation & Settlement Bridge
        item {
            if (reconciliation != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "MARKET.OS RECONCILIATION & SETTLEMENT",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        ReconciliationItem("Contract Tonnes", "${reconciliation.contractTonnes} t")
                        ReconciliationItem("Received Tonnes", "${reconciliation.receivedTonnes} t")
                        ReconciliationItem("Contract Price", "£${reconciliation.contractPricePerTonne}/t")
                        ReconciliationItem("Gross Commodity Value", "£${String.format("%.2f", reconciliation.grossValue)}")
                        ReconciliationItem("Freight Deduction (£7.40/t)", "-£${String.format("%.2f", reconciliation.freightCost)}")
                        ReconciliationItem("Handling Fee (£1.20/t)", "-£${String.format("%.2f", reconciliation.handlingFee)}")

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "NET FARM REALISATION",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = "£${String.format("%.2f", reconciliation.netFarmRealisation)}",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Button(
                                onClick = onReleaseSettlement,
                                modifier = Modifier.testTag("release_settlement_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("RELEASE TO MARKET.OS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Weight & Quality Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "WEIGHT & QUALITY RECORDS",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ORIGIN WEIGHBRIDGE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Gross: ${delivery.originGrossWeightKg.toInt()} kg", fontSize = 12.sp)
                            Text("Tare: ${delivery.originTareWeightKg.toInt()} kg", fontSize = 12.sp)
                            Text("Net: ${delivery.originNetWeightKg.toInt()} kg", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("DESTINATION WEIGHBRIDGE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Gross: ${delivery.destGrossWeightKg.toInt()} kg", fontSize = 12.sp)
                            Text("Tare: ${delivery.destTareWeightKg.toInt()} kg", fontSize = 12.sp)
                            Text("Net: ${delivery.destNetWeightKg.toInt()} kg", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Moisture: ${delivery.moisturePct}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Protein: ${delivery.proteinPct}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Sp. Weight: ${delivery.specificWeightKgHl} kg/hl", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Document Wallet Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DELIVERY DOCUMENT WALLET",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    DocumentItem("Trade Confirmation (MARKET.OS)", true)
                    DocumentItem("Delivery Instruction", true)
                    DocumentItem("CMR Consignment Note", true)
                    DocumentItem("Origin Weight Ticket", delivery.originNetWeightKg > 0)
                    DocumentItem("Destination Weight Ticket", delivery.destNetWeightKg > 0)
                    DocumentItem("Quality Certificate (#${delivery.sampleId})", delivery.sampleId.isNotEmpty())
                    DocumentItem("Proof of Delivery (POD Signature)", delivery.receiverSignature.isNotEmpty())
                }
            }
        }

        // Event Stream Audit History
        item {
            Text(
                text = "EVENT-SOURCED EXECUTION AUDIT TRAIL",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            events.forEach { event ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = event.eventType.replace("_", " "),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${formatTimestamp(event.timestamp)} • ${event.actor} (${event.device})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ReconciliationItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
private fun DocumentItem(title: String, isAvailable: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Description,
                contentDescription = null,
                tint = if (isAvailable) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }

        Text(
            text = if (isAvailable) "VERIFIED ✓" else "PENDING",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (isAvailable) StatusGreen else AgriRed
        )
    }
}
