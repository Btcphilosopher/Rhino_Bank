package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepAgriGreen = Color(0xFF1E3A2B)
val LightAgriGreen = Color(0xFF2D5A42)
val GrainGold = Color(0xFFD4A373)
val BrightGrainGold = Color(0xFFE5B880)
val FleetBlue = Color(0xFF1E2B3C)
val SteelGrey = Color(0xFF4A5568)
val LightSteelGrey = Color(0xFF8A9AAB)
val AgriRed = Color(0xFFB3261E)

val WarmWhiteSurface = Color(0xFFF7F6F2)
val WarmCardSurface = Color(0xFFFFFFFF)
val OffWhiteBackground = Color(0xFFEFECE6)

val DarkControlBackground = Color(0xFF14171A)
val DarkControlCard = Color(0xFF1F2428)
val DarkControlCardHighlight = Color(0xFF2C3238)

val StatusGreen = Color(0xFF2E7D32)
val StatusBlue = Color(0xFF1565C0)
val StatusAmber = Color(0xFFEF6C00)
val StatusRed = Color(0xFFC62828)
val StatusGrey = Color(0xFF616161)
