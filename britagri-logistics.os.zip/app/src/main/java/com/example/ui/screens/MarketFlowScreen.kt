package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeliveryEntity
import com.example.ui.theme.DeepAgriGreen
import com.example.ui.theme.FleetBlue
import com.example.ui.theme.GrainGold
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen

@Composable
fun MarketFlowScreen(
    deliveries: List<DeliveryEntity>,
    onSelectDelivery: (String) -> Unit
) {
    val progressAnim = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        progressAnim.animateTo(
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 4000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            )
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("market_flow_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Flagship Header
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BRITAGRI FLOW • LIVE INFRASTRUCTURE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary,
                            letterSpacing = 1.sp
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = StatusGreen
                        ) {
                            Text(
                                text = "1,284 ACTIVE LOADS",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "BRITISH AGRICULTURAL COMMODITY FLOWS",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Live physical movement of Wheat, Barley, Potatoes, Milk, Fertiliser",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Live Logistics Map Simulation Canvas
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = FleetBlue)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    val lineColor = GrainGold.copy(alpha = 0.5f)
                    val nodeColor = Color.White

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Regional Nodes Positions
                        val lincolnshire = Offset(w * 0.55f, h * 0.45f)
                        val yorkshire = Offset(w * 0.50f, h * 0.25f)
                        val norfolk = Offset(w * 0.75f, h * 0.55f)
                        val tilbury = Offset(w * 0.70f, h * 0.75f)
                        val cambridge = Offset(w * 0.60f, h * 0.62f)
                        val midlands = Offset(w * 0.45f, h * 0.55f)

                        // Draw transit corridor lines
                        drawLine(lineColor, lincolnshire, yorkshire, strokeWidth = 4f)
                        drawLine(lineColor, norfolk, tilbury, strokeWidth = 4f)
                        drawLine(lineColor, cambridge, midlands, strokeWidth = 4f)
                        drawLine(lineColor, lincolnshire, tilbury, strokeWidth = 3f)

                        // Moving load animation dots
                        val p = progressAnim.value

                        // Load 1: Lincs -> Yorks
                        val load1 = Offset(
                            lincolnshire.x + (yorkshire.x - lincolnshire.x) * p,
                            lincolnshire.y + (yorkshire.y - lincolnshire.y) * p
                        )
                        drawCircle(GrainGold, radius = 10f, center = load1)

                        // Load 2: Norfolk -> Tilbury
                        val load2 = Offset(
                            norfolk.x + (tilbury.x - norfolk.x) * p,
                            norfolk.y + (tilbury.y - norfolk.y) * p
                        )
                        drawCircle(Color.Cyan, radius = 10f, center = load2)

                        // Nodes
                        drawCircle(nodeColor, radius = 8f, center = lincolnshire)
                        drawCircle(nodeColor, radius = 8f, center = yorkshire)
                        drawCircle(nodeColor, radius = 8f, center = norfolk)
                        drawCircle(nodeColor, radius = 8f, center = tilbury)
                        drawCircle(nodeColor, radius = 8f, center = cambridge)
                        drawCircle(nodeColor, radius = 8f, center = midlands)
                    }

                    // Map Labels Overlay
                    MapNodeTag("Lincolnshire Grain", Alignment.TopStart, Modifier.padding(start = 130.dp, top = 100.dp))
                    MapNodeTag("Selby Mill", Alignment.TopStart, Modifier.padding(start = 100.dp, top = 40.dp))
                    MapNodeTag("Norfolk Malting", Alignment.TopStart, Modifier.padding(start = 200.dp, top = 120.dp))
                    MapNodeTag("Tilbury Port", Alignment.TopStart, Modifier.padding(start = 180.dp, top = 180.dp))

                    // Floating Live Load Banner at Bottom
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp)
                            .fillMaxWidth()
                            .clickable { onSelectDelivery("DEL-48291") },
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.85f)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.LocalShipping,
                                    contentDescription = null,
                                    tint = GrainGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "LOAD #48291 • FEED WHEAT 28.4t",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Lincolnshire → Selby Mill • IN TRANSIT (ETA 13:42)",
                                        fontSize = 10.sp,
                                        color = Color.LightGray
                                    )
                                }
                            }

                            Text(
                                text = "INSPECT ➔",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GrainGold
                            )
                        }
                    }
                }
            }
        }

        // Active Moving Commodities List
        item {
            Text(
                text = "ACTIVE UK AGRICULTURAL FLOWS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            deliveries.forEach { d ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSelectDelivery(d.deliveryId) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${d.commodity} (${d.contractQuantity.toInt()}t)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "${d.originRegion} → ${d.destRegion} • ${d.haulier}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = d.status.label.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MapNodeTag(title: String, alignment: Alignment, modifier: Modifier) {
    Box(modifier = modifier) {
        Surface(
            shape = RoundedCornerShape(4.dp),
            color = Color.Black.copy(alpha = 0.7f)
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
        }
    }
}
