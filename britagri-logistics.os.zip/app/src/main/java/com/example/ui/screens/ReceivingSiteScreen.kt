package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeliveryEntity
import com.example.ui.theme.AgriRed
import com.example.ui.theme.GrainGold

@Composable
fun ReceivingSiteScreen(
    delivery: DeliveryEntity?,
    onRecordWeights: (deliveryId: String, grossKg: Double, tareKg: Double, isOrigin: Boolean) -> Unit,
    onRecordQuality: (deliveryId: String, moisture: Double, protein: Double, spWeight: Double, status: String, sampleId: String) -> Unit,
    onSignPod: (deliveryId: String, receiverName: String, driverName: String) -> Unit
) {
    if (delivery == null) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("No active delivery selected for receiving.", fontWeight = FontWeight.Bold)
        }
        return
    }

    var grossInput by remember(delivery) { mutableStateOf(delivery.destGrossWeightKg.ifZero(44620.0).toString()) }
    var tareInput by remember(delivery) { mutableStateOf(delivery.destTareWeightKg.ifZero(16320.0).toString()) }
    var moistureInput by remember(delivery) { mutableStateOf(delivery.moisturePct.toString()) }
    var proteinInput by remember(delivery) { mutableStateOf(delivery.proteinPct.toString()) }
    var spWeightInput by remember(delivery) { mutableStateOf(delivery.specificWeightKgHl.toString()) }
    var receiverNameInput by remember { mutableStateOf("Selby Mill Receiver (John Smith)") }

    val gross = grossInput.toDoubleOrNull() ?: 44620.0
    val tare = tareInput.toDoubleOrNull() ?: 16320.0
    val netKg = (gross - tare).coerceAtLeast(0.0)
    val netTonnes = netKg / 1000.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("receiving_site_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Truck Arrival Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = "TRUCK ARRIVAL AT WEIGHBRIDGE",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = "SITE: EAST MIDLANDS MILL",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "TRUCK: ${delivery.vehicle} (${delivery.driver})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "DELIVERY ID: ${delivery.deliveryId} • TRADE: ${delivery.tradeId}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "PRODUCT: ${delivery.commodity} (${delivery.grade})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Weighbridge Terminal
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Scale,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "WEIGHBRIDGE DUAL SCALES",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = grossInput,
                            onValueChange = { grossInput = it },
                            label = { Text("GROSS (kg)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = tareInput,
                            onValueChange = { tareInput = it },
                            label = { Text("TARE (kg)") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "NET WEIGHT CALCULATED",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = "${String.format("%.0f", netKg)} kg (${String.format("%.2f", netTonnes)} tonnes)",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }

                            Button(
                                onClick = {
                                    onRecordWeights(delivery.deliveryId, gross, tare, false)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("CONFIRM WEIGHT", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Quality Sampling & Testing
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = null,
                            tint = GrainGold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GRAIN QUALITY & SAMPLE #A49281",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = moistureInput,
                            onValueChange = { moistureInput = it },
                            label = { Text("Moisture %") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = proteinInput,
                            onValueChange = { proteinInput = it },
                            label = { Text("Protein %") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = spWeightInput,
                            onValueChange = { spWeightInput = it },
                            label = { Text("Sp. Wt kg/hl") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val m = moistureInput.toDoubleOrNull() ?: 14.1
                                val p = proteinInput.toDoubleOrNull() ?: 10.8
                                val sp = spWeightInput.toDoubleOrNull() ?: 76.4
                                onRecordQuality(delivery.deliveryId, m, p, sp, "ACCEPTED", "SAMPLE-A49281")
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("ACCEPT LOAD", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                val m = moistureInput.toDoubleOrNull() ?: 14.1
                                val p = proteinInput.toDoubleOrNull() ?: 10.8
                                val sp = spWeightInput.toDoubleOrNull() ?: 76.4
                                onRecordQuality(delivery.deliveryId, m, p, sp, "DISCOUNTED", "SAMPLE-A49281")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("DISCOUNT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                val m = moistureInput.toDoubleOrNull() ?: 14.1
                                val p = proteinInput.toDoubleOrNull() ?: 10.8
                                val sp = spWeightInput.toDoubleOrNull() ?: 76.4
                                onRecordQuality(delivery.deliveryId, m, p, sp, "REJECTED", "SAMPLE-A49281")
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AgriRed)
                        ) {
                            Text("REJECT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Final Receipt & POD Sign
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "CONFIRM FINAL RECEIPT & SIGN POD",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = receiverNameInput,
                        onValueChange = { receiverNameInput = it },
                        label = { Text("Receiver Signatory Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            onSignPod(delivery.deliveryId, receiverNameInput, delivery.driver)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("accept_delivery_pod_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SIGN & ACCEPT DELIVERY", fontSize = 14.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

private fun Double.ifZero(defaultVal: Double): Double = if (this == 0.0) defaultVal else this
