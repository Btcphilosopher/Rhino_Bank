package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DeliveryEntity
import com.example.data.model.DeliveryEventEntity
import com.example.data.model.DeliveryState
import com.example.data.model.FarmStockEntity
import com.example.data.model.HaulageJobEntity
import com.example.data.model.MarketTradeReconciliation
import com.example.data.model.UserRole
import com.example.data.repository.LogisticsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = LogisticsRepository(application)

    val deliveries: StateFlow<List<DeliveryEntity>> = repository.deliveryDao.getAllDeliveries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stocks: StateFlow<List<FarmStockEntity>> = repository.farmStockDao.getAllStocks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val haulageJobs: StateFlow<List<HaulageJobEntity>> = repository.haulageJobDao.getAllJobs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedDeliveryId = MutableStateFlow<String?>("DEL-48291")
    val selectedDeliveryId: StateFlow<String?> = _selectedDeliveryId.asStateFlow()

    val selectedDelivery: StateFlow<DeliveryEntity?> = _selectedDeliveryId
        .flatMapLatest { id ->
            if (id != null) repository.deliveryDao.getDeliveryById(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val eventsForSelected: StateFlow<List<DeliveryEventEntity>> = _selectedDeliveryId
        .flatMapLatest { id ->
            if (id != null) repository.deliveryEventDao.getEventsForDelivery(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentRole = MutableStateFlow(UserRole.FARMER)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    val isOfflineMode: StateFlow<Boolean> = repository.isOfflineMode
    val syncMessage: StateFlow<String?> = repository.syncMessage

    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _selectedTab = MutableStateFlow("HOME")
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    private val _showDemoDialog = MutableStateFlow(false)
    val showDemoDialog: StateFlow<Boolean> = _showDemoDialog.asStateFlow()

    fun selectDelivery(id: String) {
        _selectedDeliveryId.value = id
    }

    fun setRole(role: UserRole) {
        _currentRole.value = role
    }

    fun toggleOfflineMode() {
        repository.setOfflineMode(!repository.isOfflineMode.value)
    }

    fun toggleDarkTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun setSelectedTab(tab: String) {
        _selectedTab.value = tab
    }

    fun setShowDemoDialog(show: Boolean) {
        _showDemoDialog.value = show
    }

    fun syncEvents() {
        viewModelScope.launch {
            repository.syncOfflineEvents()
        }
    }

    fun advanceState(deliveryId: String, nextState: DeliveryState, actor: String, location: String) {
        viewModelScope.launch {
            repository.transitionState(
                deliveryId = deliveryId,
                nextState = nextState,
                actor = actor,
                device = if (_currentRole.value == UserRole.DRIVER) "Phone Field Mode" else "iPad Ops Mode",
                location = location
            )
        }
    }

    fun updateWeights(deliveryId: String, grossKg: Double, tareKg: Double, isOrigin: Boolean) {
        viewModelScope.launch {
            repository.updateWeights(
                deliveryId = deliveryId,
                grossKg = grossKg,
                tareKg = tareKg,
                isOrigin = isOrigin
            )
        }
    }

    fun updateQuality(deliveryId: String, moisture: Double, protein: Double, spWeight: Double, status: String, sampleId: String) {
        viewModelScope.launch {
            repository.updateQuality(
                deliveryId = deliveryId,
                moisture = moisture,
                protein = protein,
                spWeight = spWeight,
                status = status,
                sampleId = sampleId
            )
        }
    }

    fun signPod(deliveryId: String, receiverSignature: String, driverSignature: String) {
        viewModelScope.launch {
            repository.completeProofOfDelivery(
                deliveryId = deliveryId,
                receiverSignature = receiverSignature,
                driverSignature = driverSignature
            )
        }
    }

    fun signContractWith2FA(deliveryId: String, totpCode: String, signedBy: String) {
        viewModelScope.launch {
            repository.signContractWith2FA(deliveryId, totpCode, signedBy)
        }
    }

    fun triggerDemo(demoNumber: Int) {
        viewModelScope.launch {
            when (demoNumber) {
                1 -> repository.runDemo1FarmerSellsWheat()
                2 -> repository.runDemo2ShortDelivery()
                3 -> repository.runDemo3NoSignalOffline()
                4 -> repository.runDemo4HaulageMarket()
                5 -> repository.runDemo5Backhaul()
            }
        }
    }

    fun getReconciliation(delivery: DeliveryEntity): MarketTradeReconciliation {
        return repository.calculateReconciliation(delivery)
    }
}
