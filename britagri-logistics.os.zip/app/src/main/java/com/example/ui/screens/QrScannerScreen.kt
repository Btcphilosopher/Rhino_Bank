package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.DeliveryEntity
import com.example.data.model.formatTimestamp
import kotlinx.coroutines.delay
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrScannerScreen(
    deliveries: List<DeliveryEntity>,
    selectedDelivery: DeliveryEntity?,
    onSelectDelivery: (String) -> Unit,
    onSignContractWith2FA: (deliveryId: String, totpCode: String, signedBy: String) -> Unit
) {
    var activeSubTab by remember { mutableIntStateOf(0) } // 0 = Scan & Verify, 1 = Generate QR, 2 = Audit Log
    var isFlashlightOn by remember { mutableStateOf(false) }
    var scannedPayload by remember { mutableStateOf("") }
    var selectedForScan by remember { mutableStateOf(selectedDelivery ?: deliveries.firstOrNull()) }
    var showSignatureDialog by remember { mutableStateOf(false) }
    var verifiedDelivery by remember { mutableStateOf<DeliveryEntity?>(null) }
    var totpInput by remember { mutableStateOf("") }
    var generatedTotp by remember { mutableStateOf("849 201") }
    var totpSecondsLeft by remember { mutableIntStateOf(28) }
    val clipboardManager = LocalClipboardManager.current

    // TOTP Timer loop
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            if (totpSecondsLeft > 1) {
                totpSecondsLeft--
            } else {
                totpSecondsLeft = 30
                val randomNum = (100000..999999).random()
                generatedTotp = "${randomNum / 1000} ${randomNum % 1000}"
            }
        }
    }

    LaunchedEffect(selectedDelivery) {
        if (selectedDelivery != null) {
            selectedForScan = selectedDelivery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Sub-Tabs Navigation
        Surface(
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            PrimaryTabRow(
                selectedTabIndex = activeSubTab,
                modifier = Modifier.testTag("qr_sub_tabs")
            ) {
                Tab(
                    selected = activeSubTab == 0,
                    onClick = { activeSubTab = 0 },
                    text = { Text("Scan 2FA", fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan") },
                    modifier = Modifier.testTag("tab_sub_scan")
                )
                Tab(
                    selected = activeSubTab == 1,
                    onClick = { activeSubTab = 1 },
                    text = { Text("Generate QR", fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.QrCode, contentDescription = "Generate") },
                    modifier = Modifier.testTag("tab_sub_generate")
                )
                Tab(
                    selected = activeSubTab == 2,
                    onClick = { activeSubTab = 2 },
                    text = { Text("Audit Trail", fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Verified, contentDescription = "Audit") },
                    modifier = Modifier.testTag("tab_sub_audit")
                )
            }
        }

        when (activeSubTab) {
            0 -> ScanAndVerifyTab(
                deliveries = deliveries,
                selectedDelivery = selectedForScan,
                isFlashlightOn = isFlashlightOn,
                onToggleFlashlight = { isFlashlightOn = !isFlashlightOn },
                onSelectDeliveryForScan = { selectedForScan = it },
                onTriggerScan = { delivery ->
                    verifiedDelivery = delivery
                    totpInput = generatedTotp.replace(" ", "")
                    showSignatureDialog = true
                },
                scannedPayload = scannedPayload,
                onPayloadChange = { scannedPayload = it }
            )

            1 -> GenerateQrTab(
                deliveries = deliveries,
                selectedDelivery = selectedForScan,
                totpCode = generatedTotp,
                totpSecondsLeft = totpSecondsLeft,
                onSelectDelivery = { selectedForScan = it },
                onCopyPayload = { payload ->
                    clipboardManager.setText(AnnotatedString(payload))
                }
            )

            2 -> SignedAuditLogTab(
                deliveries = deliveries
            )
        }
    }

    if (showSignatureDialog && verifiedDelivery != null) {
        val target = verifiedDelivery!!
        Dialog(onDismissRequest = { showSignatureDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = "2FA Lock",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "2FA Contract Verification",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "BRITAGRI MARKET.OS SHA-256 Proof",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = target.commodity,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "Contract ID: ${target.tradeId} • Delivery: ${target.deliveryId}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Tonnage: ${target.contractQuantity} tonnes • Value: £${String.format("%,.2f", target.contractQuantity * target.pricePerTonne)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Seller: ${target.seller.take(24)}...",
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Buyer: ${target.buyer.take(24)}...",
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(
                                progress = { totpSecondsLeft / 30f },
                                modifier = Modifier.size(40.dp),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                            Text(
                                text = "$totpSecondsLeft",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "Active 2FA Token",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = generatedTotp,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = totpInput,
                        onValueChange = { totpInput = it },
                        label = { Text("Confirm 2FA Pin / Passcode") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            if (totpInput.isNotEmpty()) {
                                onSignContractWith2FA(target.deliveryId, totpInput, "Farmer / Auth Holder")
                                showSignatureDialog = false
                            }
                        }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_totp_pin")
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = { showSignatureDialog = false },
                            modifier = Modifier.testTag("btn_cancel_2fa")
                        ) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                if (totpInput.isNotEmpty()) {
                                    onSignContractWith2FA(target.deliveryId, totpInput, "Authorized Signatory")
                                    showSignatureDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.testTag("btn_confirm_2fa_sign")
                        ) {
                            Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sign Contract")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScanAndVerifyTab(
    deliveries: List<DeliveryEntity>,
    selectedDelivery: DeliveryEntity?,
    isFlashlightOn: Boolean,
    onToggleFlashlight: () -> Unit,
    onSelectDeliveryForScan: (DeliveryEntity) -> Unit,
    onTriggerScan: (DeliveryEntity) -> Unit,
    scannedPayload: String,
    onPayloadChange: (String) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    val laserTransition = rememberInfiniteTransition(label = "Laser")
    val laserY by laserTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LaserPosition"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Shield,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "2FA Contract Authenticator",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = onToggleFlashlight,
                            modifier = Modifier.testTag("btn_toggle_flashlight")
                        ) {
                            Icon(
                                imageVector = if (isFlashlightOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                contentDescription = "Flashlight",
                                tint = if (isFlashlightOn) Color(0xFFFFD700) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Scanner Viewfinder
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isFlashlightOn) Color(0xFF2B2B11) else Color(0xFF101418))
                            .border(
                                width = 2.dp,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        // Canvas Viewfinder Graphics
                        val primaryColor = MaterialTheme.colorScheme.primary
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val boxSize = w.coerceAtMost(h) * 0.65f
                            val left = (w - boxSize) / 2f
                            val top = (h - boxSize) / 2f
                            val right = left + boxSize
                            val bottom = top + boxSize

                            // Dark overlay outside target
                            drawRect(
                                color = Color.Black.copy(alpha = 0.4f),
                                size = size
                            )

                            // Target Viewfinder Corner Brackets
                            val cornerLen = 28.dp.toPx()
                            val strokeW = 4.dp.toPx()

                            // Top Left
                            drawLine(primaryColor, Offset(left, top), Offset(left + cornerLen, top), strokeW)
                            drawLine(primaryColor, Offset(left, top), Offset(left, top + cornerLen), strokeW)

                            // Top Right
                            drawLine(primaryColor, Offset(right, top), Offset(right - cornerLen, top), strokeW)
                            drawLine(primaryColor, Offset(right, top), Offset(right, top + cornerLen), strokeW)

                            // Bottom Left
                            drawLine(primaryColor, Offset(left, bottom), Offset(left + cornerLen, bottom), strokeW)
                            drawLine(primaryColor, Offset(left, bottom), Offset(left, bottom - cornerLen), strokeW)

                            // Bottom Right
                            drawLine(primaryColor, Offset(right, bottom), Offset(right - cornerLen, bottom), strokeW)
                            drawLine(primaryColor, Offset(right, bottom), Offset(right, bottom - cornerLen), strokeW)

                            // Animated Laser Scanner Line
                            val laserPos = top + (bottom - top) * laserY
                            drawLine(
                                color = Color(0xFFFF3B30),
                                start = Offset(left + 8.dp.toPx(), laserPos),
                                end = Offset(right - 8.dp.toPx(), laserPos),
                                strokeWidth = 3.dp.toPx()
                            )
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
                        ) {
                            Surface(
                                color = Color.Black.copy(alpha = 0.7f),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text(
                                    text = "Align QR Code within target frame",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Quick Demo Selection (Select Contract QR Payload):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    ExposedDropdownMenuBox(
                        expanded = isExpanded,
                        onExpandedChange = { isExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedDelivery?.let { "${it.deliveryId} • ${it.commodity} (${it.contractQuantity}t)" } ?: "Select Delivery...",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("dropdown_scan_delivery_select")
                        )

                        ExposedDropdownMenu(
                            expanded = isExpanded,
                            onDismissRequest = { isExpanded = false }
                        ) {
                            deliveries.forEach { item ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(
                                                text = "${item.deliveryId} - ${item.commodity}",
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${item.seller} -> ${item.buyer}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    },
                                    onClick = {
                                        onSelectDeliveryForScan(item)
                                        isExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            selectedDelivery?.let { onTriggerScan(it) }
                        },
                        enabled = selectedDelivery != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("btn_scan_and_authenticate"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Simulate Scan & Authenticate Contract",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Or Paste Custom Cryptographic QR Payload:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = scannedPayload,
                        onValueChange = onPayloadChange,
                        placeholder = { Text("Paste JSON payload, SHA-256 hash or token string...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("input_custom_qr_payload")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = {
                                onPayloadChange("{\"tradeId\":\"BRI-2026-004281\",\"sha256\":\"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\",\"totpNonce\":\"99281\"}")
                            },
                            modifier = Modifier.testTag("btn_load_sample_payload")
                        ) {
                            Text("Load Sample 2FA JSON")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GenerateQrTab(
    deliveries: List<DeliveryEntity>,
    selectedDelivery: DeliveryEntity?,
    totpCode: String,
    totpSecondsLeft: Int,
    onSelectDelivery: (DeliveryEntity) -> Unit,
    onCopyPayload: (String) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    val current = selectedDelivery ?: deliveries.firstOrNull()

    val payloadJson = remember(current, totpCode) {
        if (current == null) "" else """
        {
          "system": "BRITAGRI_MARKET_OS",
          "version": "2.4.0",
          "tradeId": "${current.tradeId}",
          "deliveryId": "${current.deliveryId}",
          "commodity": "${current.commodity}",
          "contractQuantityTonnes": ${current.contractQuantity},
          "pricePerTonne": ${current.pricePerTonne},
          "grossValueGbp": ${current.contractQuantity * current.pricePerTonne},
          "totp2FA": "${totpCode.replace(" ", "")}",
          "checksumSha256": "${(current.tradeId + totpCode).hashCode().toString(16)}"
        }
        """.trimIndent()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                text = "Generate 2FA Contract QR Code",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "Present this dynamic QR code to drivers, weighbridges, or buyers for 2FA contract execution",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            ExposedDropdownMenuBox(
                expanded = isExpanded,
                onExpandedChange = { isExpanded = it },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = current?.let { "${it.deliveryId} • ${it.commodity} (£${String.format("%,.0f", it.contractQuantity * it.pricePerTonne)})" } ?: "Select Contract",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Selected Trade Contract") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                        .testTag("dropdown_gen_delivery_select")
                )

                ExposedDropdownMenu(
                    expanded = isExpanded,
                    onDismissRequest = { isExpanded = false }
                ) {
                    deliveries.forEach { item ->
                        DropdownMenuItem(
                            text = {
                                Text("${item.deliveryId} - ${item.commodity} (${item.contractQuantity}t)")
                            },
                            onClick = {
                                onSelectDelivery(item)
                                isExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .size(280.dp)
                    .testTag("qr_code_canvas_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Compose Canvas QR Code Generator Matrix
                    val primaryColor = MaterialTheme.colorScheme.primary
                    val darkColor = Color(0xFF1E293B)

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val matrixSize = 21 // 21x21 QR Grid
                        val cellSize = size.width / matrixSize

                        // Draw QR finder patterns (corners)
                        fun drawFinder(startX: Int, startY: Int) {
                            val px = startX * cellSize
                            val py = startY * cellSize
                            drawRect(
                                color = darkColor,
                                topLeft = Offset(px, py),
                                size = Size(cellSize * 7, cellSize * 7)
                            )
                            drawRect(
                                color = Color.White,
                                topLeft = Offset(px + cellSize, py + cellSize),
                                size = Size(cellSize * 5, cellSize * 5)
                            )
                            drawRect(
                                color = darkColor,
                                topLeft = Offset(px + cellSize * 2, py + cellSize * 2),
                                size = Size(cellSize * 3, cellSize * 3)
                            )
                        }

                        drawFinder(0, 0) // Top Left
                        drawFinder(14, 0) // Top Right
                        drawFinder(0, 14) // Bottom Left

                        // Pseudo-deterministic matrix pattern based on payload hash
                        val hash = payloadJson.hashCode()
                        for (r in 0 until matrixSize) {
                            for (c in 0 until matrixSize) {
                                // Skip finder areas
                                if ((r in 0..6 && c in 0..6) ||
                                    (r in 0..6 && c in 14..20) ||
                                    (r in 14..20 && c in 0..6)
                                ) continue

                                val moduleVal = abs((hash xor (r * 31 + c * 17) xor (r * c))) % 3
                                if (moduleVal == 0) {
                                    drawRect(
                                        color = if ((r + c) % 5 == 0) primaryColor else darkColor,
                                        topLeft = Offset(c * cellSize, r * cellSize),
                                        size = Size(cellSize, cellSize)
                                    )
                                }
                            }
                        }
                    }

                    // Centered Logo Badge inside QR Code
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White,
                        border = Stroke(width = 2f).let { null },
                        shadowElevation = 4.dp,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Icon(
                                Icons.Default.Verified,
                                contentDescription = "2FA Badge",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dynamic TOTP Refresh Banner
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(
                    Icons.Default.Key,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "2FA TOTP Token: ",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = totpCode,
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "(${totpSecondsLeft}s)",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = { onCopyPayload(payloadJson) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_copy_qr_payload")
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy JSON")
                }

                Button(
                    onClick = { onCopyPayload(payloadJson) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_share_qr"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share 2FA QR")
                }
            }
        }
    }
}

@Composable
private fun SignedAuditLogTab(
    deliveries: List<DeliveryEntity>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "Cryptographic 2FA Audit Trail",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tamper-evident log of 2FA signed contracts synchronized with BRITAGRI MARKET.OS",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        items(deliveries) { delivery ->
            val isSigned = delivery.receiverSignature.isNotEmpty() || delivery.podSignedAt > 0L

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isSigned) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = if (isSigned) 2.dp else 0.dp),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("audit_card_${delivery.deliveryId}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isSigned) Icons.Default.Verified else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (isSigned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = delivery.deliveryId,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }

                        Surface(
                            color = if (isSigned) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (isSigned) "2FA VERIFIED" else "PENDING 2FA",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSigned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${delivery.commodity} • ${delivery.contractQuantity} tonnes",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "Trade ID: ${delivery.tradeId} • Value: £${String.format("%,.2f", delivery.contractQuantity * delivery.pricePerTonne)}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (isSigned) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = "Signatory: ${delivery.receiverSignature.ifEmpty { "Verified Signatory" }}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Timestamp: ${formatTimestamp(if (delivery.podSignedAt > 0) delivery.podSignedAt else delivery.lastUpdated)}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "SHA-256 Checksum: 0x${(delivery.deliveryId + delivery.tradeId).hashCode().toString(16).uppercase()}",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
