package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeliveryEntity
import com.example.data.model.DeliveryState
import com.example.ui.theme.AgriRed
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusGrey

@Composable
fun LogisticsCoordinatorScreen(
    deliveries: List<DeliveryEntity>,
    onSelectDelivery: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("logistics_coordinator_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active Loads Overview Counters
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BRITAGRI LOGISTICS • DISPATCH CONTROL",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary,
                            letterSpacing = 1.sp
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = AgriRed.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Exceptions",
                                    tint = AgriRed,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "3 EXCEPTIONS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AgriRed
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatPill("84", "ACTIVE LOADS", StatusBlue)
                        StatPill("17", "EN ROUTE", StatusBlue)
                        StatPill("9", "AT FARMS", StatusAmber)
                        StatPill("21", "IN TRANSIT", StatusBlue)
                        StatPill("12", "AT DEST", StatusAmber)
                        StatPill("25", "COMPLETE", StatusGreen)
                    }
                }
            }
        }

        // Delivery Dispatch Table Board
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DELIVERY DISPATCH BOARD",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Click any row to inspect full delivery record & state history",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Scrollable Table
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        // Header Row
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TableCell("DELIVERY", 110.dp, header = true)
                            TableCell("TRADE", 110.dp, header = true)
                            TableCell("COMMODITY", 130.dp, header = true)
                            TableCell("QTY", 70.dp, header = true)
                            TableCell("ORIGIN", 140.dp, header = true)
                            TableCell("DESTINATION", 140.dp, header = true)
                            TableCell("DRIVER", 120.dp, header = true)
                            TableCell("VEHICLE", 100.dp, header = true)
                            TableCell("WINDOW", 110.dp, header = true)
                            TableCell("STATUS", 130.dp, header = true)
                        }

                        deliveries.forEach { d ->
                            val statusColor = when (d.status.category) {
                                "COMPLETED" -> StatusGreen
                                "IN_PROGRESS" -> StatusBlue
                                "ATTENTION" -> StatusAmber
                                "EXCEPTION" -> AgriRed
                                else -> StatusGrey
                            }

                            Row(
                                modifier = Modifier
                                    .clickable { onSelectDelivery(d.deliveryId) }
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                                    .testTag("dispatch_row_${d.deliveryId}"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TableCell(d.deliveryId, 110.dp, bold = true)
                                TableCell(d.tradeId, 110.dp)
                                TableCell(d.commodity, 130.dp, bold = true)
                                TableCell("${d.contractQuantity.toInt()}t", 70.dp, bold = true)
                                TableCell(d.originRegion, 140.dp)
                                TableCell(d.destRegion, 140.dp)
                                TableCell(d.driver, 120.dp)
                                TableCell(d.vehicle, 100.dp)
                                TableCell(d.collectionWindow, 110.dp)

                                Box(
                                    modifier = Modifier
                                        .width(130.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(statusColor)
                                        .padding(horizontal = 6.dp, vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = d.status.label.uppercase(),
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatPill(value: String, label: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                color = color
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

@Composable
private fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    header: Boolean = false,
    bold: Boolean = false
) {
    Text(
        text = text,
        modifier = Modifier.width(width),
        fontSize = if (header) 11.sp else 12.sp,
        fontWeight = if (header || bold) FontWeight.Bold else FontWeight.Normal,
        color = if (header) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
    )
}
