package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
fun DemoDialog(
    onDismiss: () -> Unit,
    onTriggerDemo: (Int) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("signature_demos_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "5 SIGNATURE DEMOS",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.tertiary
                    ) {
                        Text(
                            text = "BRITAGRI",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Select a signature workflow to trigger live execution state transitions",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                DemoCard(
                    title = "1. Farmer Sells Wheat (Full Loop)",
                    desc = "Trade -> Haulage -> Load -> Weigh -> Transport -> Delivery -> Quality -> POD -> Settlement Ready",
                    onClick = {
                        onTriggerDemo(1)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                DemoCard(
                    title = "2. Short Delivery (-1.1t Variance)",
                    desc = "240t Contract -> 239.5t Origin -> 238.9t Received. Triggers Quantity Variance Review & Dispute engine.",
                    onClick = {
                        onTriggerDemo(2)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                DemoCard(
                    title = "3. Farm With No Signal (Offline Engine)",
                    desc = "Records 4 driver/scale actions offline in local database, then syncs 12 events to MARKET.OS upon reconnect.",
                    onClick = {
                        onTriggerDemo(3)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                DemoCard(
                    title = "4. Haulage Market & Bidding",
                    desc = "Posts 240t Lincolnshire -> Yorkshire grain haulage requirement and matches 3 quotes.",
                    onClick = {
                        onTriggerDemo(4)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                DemoCard(
                    title = "5. Backhaul Matching Engine",
                    desc = "Converts 148 mile empty return into Selby Fertiliser backhaul load (+£280 revenue, -90% empty miles).",
                    onClick = {
                        onTriggerDemo(5)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("close_demos_dialog_button")
                ) {
                    Text("CLOSE DEMOS", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DemoCard(title: String, desc: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
