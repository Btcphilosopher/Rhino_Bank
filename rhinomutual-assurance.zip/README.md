# RhinoMutual Assurance
**P2P Risk Pooling and Stake-Backed Double-Blind Claim Validation Platform**  
*Developed by Aureom.AI*

---

## 1. Trust Model & System Architecture

RhinoMutual decouples four critical functions in mutual assurance to counter moral hazard, collusion, and conflicted claim administration:

1. **Policy Administration**: Determines contractual coverage in-force, limits, deductibles, waiting periods, and exclusions. Canonical policy wording versions (e.g. `v1.2-2026.1`) are immutably pinned to every claim.
2. **Evidence Forensics (Track A)**: Examines physical and cryptographic facts (EXIF timestamps, file SHA-256 hashes, CNC/telemetry registers, authorized repairer quotes, and duplicate invoice detection).
3. **Claim Adjudication (Track B & Human Reconciliation)**: Applies policy terms to corroborated facts, calculates straight-line depreciation (15%/yr) and salvage recovery credits, and authorizes settlement disbursements.
4. **Ledger Consensus**: Logs all state transitions on an append-only double-entry ledger with cryptographic hash chains.

```
       [ Member Equipment Registration ]
                      │
                      ▼
        [ Claim Submission & PII Redaction ]
                      │
         ┌────────────┴────────────┐
         ▼                         ▼
   [ Track A: Forensics ]    [ Track B: Coverage ]
   (File Hashes & EXIF)      (Policy & Valuation)
         │                         │
         └────────────┬────────────┘
                      ▼
       [ Commit-Reveal Cryptographic Phase ]
                      │
                      ▼
       [ Adjudication Reconciliation Matrix ]
                      │
                      ▼
       [ Append-Only Double-Entry Settlement ]
```

---

## 2. Key Mechanisms

### A. Double-Blind Commit-Reveal Protocol
- **Blinding**: Claimant names, emails, phone numbers, and tax IDs are scrubbed from reviewer packets.
- **Commit Phase**: Validators submit $H(\text{Assessment JSON} \,\|\, \text{Secret Nonce})$.
- **Reveal Phase**: Secret nonces are revealed after the deadline. Assessments are cryptographically checked against commitments.
- **Escrow Recovery**: If a validator fails to reveal, an encrypted reveal escrow fallback recovers the assessment without penalizing the claimant.

### B. Stake-Backed Validator Registry & Anti-Slashing
- Validators post performance bonds (e.g., €50,000–€100,000) held in segregated escrow accounts.
- **Voting Power Concentration Cap**: Strictly capped at 15% maximum voting share per entity.
- **Fixed Compensation**: Reviewers receive a fixed €180 fee per review regardless of whether the claim is accepted or denied, eliminating denial-bias incentives.
- **Objective Slashing**: Validators are *never* penalized for good-faith dissenting votes or appeal reversals. Bond forfeiture is restricted strictly to objectively proven misconduct (cryptographic equivocation, unauthorized disclosure, undisclosed conflicts, fabricated test records).

### C. Double-Entry Append-Only Ledger
All pool transactions (contributions, reserve locks, settlements, validator fees, salvage recoveries, surplus rebates) are recorded as balanced debits and credits with continuous block hash chains.

---

## 3. Running the Simulation

Run the standalone Python agent-based simulation comparing all 4 governance models:

```bash
python simulation.py --claims 2000 --fraud-rate 0.20 --collusion-rate 0.10
```

CLI Options:
- `--claims <int>`: Total synthetic claims to evaluate (default: 2000)
- `--fraud-rate <float>`: Fraudulent claim fraction (default: 0.20)
- `--collusion-rate <float>`: Reviewer cartel collusion attempts (default: 0.10)
- `--audit-rate <float>`: Post-disbursement random audit frequency (default: 0.10)

---

## 4. Local Development & Deployment

```bash
# Install dependencies
npm install

# Start development server on port 3000
npm run dev

# Production build
npm run build
```

---

## 5. Epistemological Notes
- **Proof-of-Stake vs Reality**: Consensus establishes agreement about records; it does not prove whether physical machinery dropped or short-circuited.
- **Zero-Knowledge Proofs**: A ZK membership proof verifies that a claimant was an active pool member on date $T$ without disclosing identity; it does not verify that physical damage occurred.
- **Moral Hazard**: Treated as an empirical hypothesis to measure and mitigate through structural incentives.
