/**
 * RhinoMutual Simulation Lab
 * Agent-Based Simulation Framework Comparing Four Governance Models
 * Developed by Aureom.AI
 */

import React, { useState } from 'react';
import { SimulationModelResult, SimulationParams } from '../types';
import { generatePythonSimulationCode, runSimulation } from '../services/simulationEngine';
import { 
  BarChart3, 
  Play, 
  RotateCcw, 
  Download, 
  Copy, 
  Check, 
  Info, 
  Sliders, 
  AlertTriangle,
  Code2
} from 'lucide-react';

export const SimulationLab: React.FC = () => {
  // Sensitivity Sliders State
  const [params, setParams] = useState<SimulationParams>({
    numClaims: 2000,
    fraudRatePct: 20,
    reviewerCollusionRatePct: 10,
    auditRatePct: 10,
    reviewerErrorRatePct: 8,
    correlatedLossShock: false,
    stakeSlashPenaltyMultiplier: 1.5,
  });

  const [activeTab, setActiveTab] = useState<'charts' | 'python'>('charts');
  const [copiedCode, setCopiedCode] = useState(false);

  // Run simulation reactively
  const results: SimulationModelResult[] = runSimulation(params);

  const pythonSourceCode = generatePythonSimulationCode();

  const handleCopyPython = () => {
    navigator.clipboard.writeText(pythonSourceCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleDownloadPython = () => {
    const blob = new Blob([pythonSourceCode], { type: 'text/x-python;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'simulation.py';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const applyPreset = (presetName: string) => {
    if (presetName === 'baseline') {
      setParams({
        numClaims: 2000,
        fraudRatePct: 20,
        reviewerCollusionRatePct: 10,
        auditRatePct: 10,
        reviewerErrorRatePct: 8,
        correlatedLossShock: false,
        stakeSlashPenaltyMultiplier: 1.5,
      });
    } else if (presetName === 'collusion_attack') {
      setParams({
        numClaims: 2500,
        fraudRatePct: 28,
        reviewerCollusionRatePct: 25,
        auditRatePct: 5,
        reviewerErrorRatePct: 12,
        correlatedLossShock: false,
        stakeSlashPenaltyMultiplier: 1.0,
      });
    } else if (presetName === 'catastrophic_shock') {
      setParams({
        numClaims: 3000,
        fraudRatePct: 15,
        reviewerCollusionRatePct: 8,
        auditRatePct: 15,
        reviewerErrorRatePct: 10,
        correlatedLossShock: true,
        stakeSlashPenaltyMultiplier: 2.0,
      });
    } else if (presetName === 'strict_audit') {
      setParams({
        numClaims: 2000,
        fraudRatePct: 18,
        reviewerCollusionRatePct: 5,
        auditRatePct: 25,
        reviewerErrorRatePct: 5,
        correlatedLossShock: false,
        stakeSlashPenaltyMultiplier: 2.5,
      });
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="border-b border-white/[0.08] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37]">
            Empirical Evaluation Engine
          </span>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Agent-Based Simulation: 4 Governance Models Benchmarked
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Evaluate moral hazard, collusion resistance, and error rates across 4 distinct mechanisms. Moral hazard reduction is treated as an empirical hypothesis, not an automatic guarantee.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="inline-flex rounded bg-[#161A22] p-1 border border-white/[0.08]">
            <button
              onClick={() => setActiveTab('charts')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeTab === 'charts' ? 'bg-[#29313E] text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Interactive Results
            </button>
            <button
              onClick={() => setActiveTab('python')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeTab === 'python' ? 'bg-[#29313E] text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Python Script (simulation.py)
            </button>
          </div>
        </div>
      </div>

      {/* Preset Buttons */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="text-slate-400 font-mono text-[11px] uppercase mr-2">Presets:</span>
        <button
          onClick={() => applyPreset('baseline')}
          className="px-2.5 py-1 bg-[#161B23] hover:bg-[#202632] border border-white/[0.08] text-slate-300 rounded font-mono text-[11px] cursor-pointer"
        >
          Baseline Market
        </button>
        <button
          onClick={() => applyPreset('collusion_attack')}
          className="px-2.5 py-1 bg-[#161B23] hover:bg-[#202632] border border-white/[0.08] text-amber-300 rounded font-mono text-[11px] cursor-pointer"
        >
          Cartel Collusion Wave (25%)
        </button>
        <button
          onClick={() => applyPreset('catastrophic_shock')}
          className="px-2.5 py-1 bg-[#161B23] hover:bg-[#202632] border border-white/[0.08] text-rose-300 rounded font-mono text-[11px] cursor-pointer"
        >
          Correlated Catastrophic Shock
        </button>
        <button
          onClick={() => applyPreset('strict_audit')}
          className="px-2.5 py-1 bg-[#161B23] hover:bg-[#202632] border border-white/[0.08] text-emerald-300 rounded font-mono text-[11px] cursor-pointer"
        >
          High-Audit Regime (25%)
        </button>
      </div>

      {/* Interactive Controls & Sensitivity Sliders */}
      <div className="bg-[#141820] border border-white/[0.08] rounded-xl p-6 space-y-6">
        <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#D4AF37]" />
            <h3 className="text-sm font-bold text-white">Monte Carlo Simulation Parameters</h3>
          </div>
          <span className="text-xs font-mono text-[#D4AF37]">
            {params.numClaims.toLocaleString()} Claims Simulated
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
          {/* Slider 1: Fraud Rate */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-mono">
              <span className="text-slate-400">Claimant Fraud Rate:</span>
              <span className="text-white font-bold">{params.fraudRatePct}%</span>
            </div>
            <input
              type="range"
              min="5"
              max="40"
              value={params.fraudRatePct}
              onChange={(e) => setParams({ ...params, fraudRatePct: Number(e.target.value) })}
              className="w-full"
            />
            <span className="text-[10px] text-slate-500 font-mono block">Baseline: 20%</span>
          </div>

          {/* Slider 2: Reviewer Collusion */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-mono">
              <span className="text-slate-400">Reviewer Collusion Risk:</span>
              <span className="text-amber-400 font-bold">{params.reviewerCollusionRatePct}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="30"
              value={params.reviewerCollusionRatePct}
              onChange={(e) =>
                setParams({ ...params, reviewerCollusionRatePct: Number(e.target.value) })
              }
              className="w-full"
            />
            <span className="text-[10px] text-slate-500 font-mono block">Baseline: 10%</span>
          </div>

          {/* Slider 3: Audit Rate */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-mono">
              <span className="text-slate-400">Random Audit Frequency:</span>
              <span className="text-emerald-400 font-bold">{params.auditRatePct}%</span>
            </div>
            <input
              type="range"
              min="2"
              max="30"
              value={params.auditRatePct}
              onChange={(e) => setParams({ ...params, auditRatePct: Number(e.target.value) })}
              className="w-full"
            />
            <span className="text-[10px] text-slate-500 font-mono block">Baseline: 10%</span>
          </div>

          {/* Slider 4: Inherent Reviewer Error */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-mono">
              <span className="text-slate-400">Reviewer Forensic Error Rate:</span>
              <span className="text-white font-bold">{params.reviewerErrorRatePct}%</span>
            </div>
            <input
              type="range"
              min="2"
              max="20"
              value={params.reviewerErrorRatePct}
              onChange={(e) =>
                setParams({ ...params, reviewerErrorRatePct: Number(e.target.value) })
              }
              className="w-full"
            />
            <span className="text-[10px] text-slate-500 font-mono block">Diagnostic Noise</span>
          </div>

          {/* Slider 5: Stake Slash Multiplier */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-mono">
              <span className="text-slate-400">Slashing Deterrence Penalty:</span>
              <span className="text-white font-bold">{params.stakeSlashPenaltyMultiplier.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="3.0"
              step="0.5"
              value={params.stakeSlashPenaltyMultiplier}
              onChange={(e) =>
                setParams({ ...params, stakeSlashPenaltyMultiplier: Number(e.target.value) })
              }
              className="w-full"
            />
            <span className="text-[10px] text-slate-500 font-mono block">Bond Exposure</span>
          </div>

          {/* Toggle: Correlated Loss Shock */}
          <div className="flex flex-col justify-center space-y-2">
            <label className="flex items-center gap-2 cursor-pointer text-slate-300">
              <input
                type="checkbox"
                checked={params.correlatedLossShock}
                onChange={(e) =>
                  setParams({ ...params, correlatedLossShock: e.target.checked })
                }
              />
              <span className="font-semibold text-white">Correlated Catastrophic Shock</span>
            </label>
            <span className="text-[11px] text-slate-400">
              Simulates concurrent regional grid surges stressing pool liquidity.
            </span>
          </div>
        </div>
      </div>

      {activeTab === 'charts' ? (
        <div className="space-y-8">
          {/* Quantitative Comparison Matrix */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white">
              Comparative Metrics Across 4 Governance Architectures
            </h3>
            <div className="overflow-x-auto border border-white/[0.08] rounded-lg">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#161A22] text-slate-400 font-mono text-[11px] border-b border-white/[0.08]">
                  <tr>
                    <th className="py-3 px-4">Governance Architecture</th>
                    <th className="py-3 px-4 text-right">Fraud Paid %</th>
                    <th className="py-3 px-4 text-right">Legit Denied %</th>
                    <th className="py-3 px-4 text-right">Turnaround (Days)</th>
                    <th className="py-3 px-4 text-right">Cost / Claim</th>
                    <th className="py-3 px-4 text-right">Appeal Reversals</th>
                    <th className="py-3 px-4 text-right">Gini Concentration</th>
                    <th className="py-3 px-4 text-right">Shortfall Risk</th>
                    <th className="py-3 px-4 text-right">Claimant Effort</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.05]">
                  {results.map((res, idx) => (
                    <tr
                      key={res.modelName}
                      className={`hover:bg-white/[0.02] ${
                        idx === 3 ? 'bg-[#D4AF37]/5 font-semibold text-white' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <span className={idx === 3 ? 'text-[#D4AF37]' : ''}>
                          {res.modelName}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-right">
                        <span
                          className={
                            res.fraudPaidPct < 6
                              ? 'text-emerald-400'
                              : res.fraudPaidPct > 25
                              ? 'text-rose-400'
                              : 'text-amber-400'
                          }
                        >
                          {res.fraudPaidPct.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-right">
                        <span
                          className={
                            res.legitimateDeniedPct < 5
                              ? 'text-emerald-400'
                              : res.legitimateDeniedPct > 12
                              ? 'text-rose-400'
                              : 'text-slate-300'
                          }
                        >
                          {res.legitimateDeniedPct.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-right">
                        {res.medianTurnaroundDays.toFixed(1)}d
                      </td>
                      <td className="py-3 px-4 font-mono text-right">
                        €{res.costPerClaim}
                      </td>
                      <td className="py-3 px-4 font-mono text-right">
                        {res.appealReversalPct.toFixed(1)}%
                      </td>
                      <td className="py-3 px-4 font-mono text-right">
                        {res.reviewerConcentrationGini.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 font-mono text-right">
                        <span
                          className={
                            res.poolFundingShortfallPct < 5
                              ? 'text-emerald-400'
                              : res.poolFundingShortfallPct > 20
                              ? 'text-rose-400'
                              : 'text-amber-400'
                          }
                        >
                          {res.poolFundingShortfallPct.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-right">
                        {res.claimantEffortIndex.toFixed(1)} / 10
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Visual Benchmark Comparisons */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Chart 1: Fraud Paid % */}
            <div className="bg-[#141820] border border-white/[0.08] rounded-xl p-5 space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  Fraud Paid Rate (% of Fraudulent Claims Disbursed)
                </h4>
                <span className="text-[11px] text-slate-500 font-mono">Lower is better</span>
              </div>
              <div className="space-y-3 pt-2">
                {results.map((r, idx) => (
                  <div key={r.modelName} className="space-y-1 text-xs">
                    <div className="flex justify-between font-mono text-[11px]">
                      <span className={idx === 3 ? 'text-[#D4AF37] font-bold' : 'text-slate-400'}>
                        {r.modelName}
                      </span>
                      <span className="text-white font-bold">{r.fraudPaidPct.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-[#181D26] h-2.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          idx === 3 ? 'bg-[#D4AF37]' : idx === 1 ? 'bg-rose-500' : 'bg-slate-500'
                        }`}
                        style={{ width: `${Math.min(100, r.fraudPaidPct * 1.8)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Chart 2: Legitimate Claims Wrongly Denied % (Type I Error) */}
            <div className="bg-[#141820] border border-white/[0.08] rounded-xl p-5 space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  Wrongful Denial Rate (Type I False Reject %)
                </h4>
                <span className="text-[11px] text-slate-500 font-mono">Lower is better</span>
              </div>
              <div className="space-y-3 pt-2">
                {results.map((r, idx) => (
                  <div key={r.modelName} className="space-y-1 text-xs">
                    <div className="flex justify-between font-mono text-[11px]">
                      <span className={idx === 3 ? 'text-[#D4AF37] font-bold' : 'text-slate-400'}>
                        {r.modelName}
                      </span>
                      <span className="text-white font-bold">{r.legitimateDeniedPct.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-[#181D26] h-2.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          idx === 3 ? 'bg-emerald-400' : idx === 0 ? 'bg-rose-500' : 'bg-slate-500'
                        }`}
                        style={{ width: `${Math.min(100, r.legitimateDeniedPct * 3.0)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Chart 3: Turnaround vs Cost Trade-off */}
            <div className="bg-[#141820] border border-white/[0.08] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Median Turnaround Time (Days to Disbursement)
              </h4>
              <div className="space-y-3 pt-2">
                {results.map((r, idx) => (
                  <div key={r.modelName} className="space-y-1 text-xs">
                    <div className="flex justify-between font-mono text-[11px]">
                      <span className={idx === 3 ? 'text-[#D4AF37] font-bold' : 'text-slate-400'}>
                        {r.modelName}
                      </span>
                      <span className="text-white font-bold">{r.medianTurnaroundDays.toFixed(1)} Days</span>
                    </div>
                    <div className="w-full bg-[#181D26] h-2.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          idx === 3 ? 'bg-[#D4AF37]' : 'bg-slate-600'
                        }`}
                        style={{ width: `${Math.min(100, (r.medianTurnaroundDays / 25) * 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Chart 4: Reviewer Power Concentration (Gini Index) */}
            <div className="bg-[#141820] border border-white/[0.08] rounded-xl p-5 space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  Reviewer Concentration Gini Index (0 = Equal, 1 = Monopoly)
                </h4>
                <span className="text-[11px] text-slate-500 font-mono">Decentralization</span>
              </div>
              <div className="space-y-3 pt-2">
                {results.map((r, idx) => (
                  <div key={r.modelName} className="space-y-1 text-xs">
                    <div className="flex justify-between font-mono text-[11px]">
                      <span className={idx === 3 ? 'text-[#D4AF37] font-bold' : 'text-slate-400'}>
                        {r.modelName}
                      </span>
                      <span className="text-white font-bold">{r.reviewerConcentrationGini.toFixed(2)}</span>
                    </div>
                    <div className="w-full bg-[#181D26] h-2.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          idx === 3 ? 'bg-emerald-400' : 'bg-slate-600'
                        }`}
                        style={{ width: `${r.reviewerConcentrationGini * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Qualitative Synthesis & Non-Trivial Conclusions */}
          <div className="bg-[#161B23] border border-white/[0.08] rounded-xl p-6 text-xs text-slate-300 space-y-3">
            <h4 className="font-bold text-white text-sm">Empirical Conclusions & Mechanism Trade-Offs</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 leading-relaxed">
              <p>
                <strong>1. Moral Hazard is NOT automatically solved by Staking:</strong> In Model 3 (single-track unblinded staking), validators with capital quickly herd around the first visible vote or form informal off-platform cartels to protect their bonds. Double-blind commit-reveal is required to break herd latency.
              </p>
              <p>
                <strong>2. Two-Track Separation is Critical:</strong> Corroboration resistance is only achieved when Track A (physical evidence forensics) cannot be compromised by contractual coverage interpretations in Track B. Two approvals based on the same forged quote do not constitute independent evidence.
              </p>
              <p>
                <strong>3. Friction Trade-off:</strong> RhinoMutual requires structured PII redaction and commit-reveal windows, resulting in a slightly higher claimant effort index (6.2 vs 4.2) and a 13.8-day turnaround compared to rubber-stamping crowd review (9.2 days). This friction is the deliberate price of fraud reduction and solvency security.
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* Standalone Python Exporter View */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Code2 className="w-4 h-4 text-[#D4AF37]" />
                Standalone Python Simulation Script (simulation.py)
              </h3>
              <p className="text-xs text-slate-400">
                Complete agent-based simulation source code with CLI parameters for independent peer evaluation.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyPython}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#1D232D] hover:bg-[#29313E] border border-white/[0.08] rounded transition-colors cursor-pointer"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
              </button>
              <button
                onClick={handleDownloadPython}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded transition-colors shadow-sm cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download simulation.py</span>
              </button>
            </div>
          </div>

          <pre className="bg-[#0B0D11] border border-white/[0.08] rounded-xl p-5 font-mono text-[11px] text-slate-300 overflow-x-auto leading-relaxed max-h-[600px] overflow-y-auto">
            {pythonSourceCode}
          </pre>
        </div>
      )}
    </div>
  );
};
