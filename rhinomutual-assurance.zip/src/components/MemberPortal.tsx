/**
 * RhinoMutual Member Portal
 * Equipment Registration, PII Redaction, Claims Filing, and Appeals
 * Developed by Aureom.AI
 */

import React, { useState } from 'react';
import { 
  Claim, 
  Equipment, 
  P2PPool, 
  PolicyVersion,
  EvidenceItem 
} from '../types';
import { scrubPIIFromText, syncSha256 } from '../services/cryptoLedger';
import { 
  Shield, 
  Plus, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  EyeOff, 
  FileCheck, 
  Scale, 
  Upload, 
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';

interface MemberPortalProps {
  claims: Claim[];
  equipmentList: Equipment[];
  pools: P2PPool[];
  activePolicy: PolicyVersion;
  onAddEquipment: (eq: Equipment) => void;
  onSubmitClaim: (claim: Claim) => void;
  onSubmitAppeal: (claimId: string, grounds: string, statement: string) => void;
  onSelectClaim: (claim: Claim) => void;
}

export const MemberPortal: React.FC<MemberPortalProps> = ({
  claims,
  equipmentList,
  pools,
  activePolicy,
  onAddEquipment,
  onSubmitClaim,
  onSubmitAppeal,
  onSelectClaim,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'claims' | 'equipment' | 'policy'>('claims');
  const [isFilingClaim, setIsFilingClaim] = useState(false);
  const [isAddingEquipment, setIsAddingEquipment] = useState(false);
  const [selectedClaimForAppeal, setSelectedClaimForAppeal] = useState<Claim | null>(null);

  // Claim Filing Form State
  const [selectedEqId, setSelectedEqId] = useState(equipmentList[0]?.id || '');
  const [incidentType, setIncidentType] = useState<Claim['incidentType']>('electrical_surge');
  const [claimedAmount, setClaimedAmount] = useState<number>(18500);
  const [incidentDate, setIncidentDate] = useState('2026-11-05');
  const [incidentDesc, setIncidentDesc] = useState(
    'During heavy CNC machining pass, power grid fluctuation caused the digital spindle servo drive to overload and short-circuit. Spindle error code E-901 displayed. Authorised technician Klaus Becker at Munich Precision Lab inspected the motor coil resistance.'
  );
  const [rawClaimantName, setRawClaimantName] = useState('Vanguard Precision Engineering Ltd');
  const [rawContactEmail, setContactEmail] = useState('klaus.becker@vanguard-precision.de');
  const [isRedactionInspected, setIsRedactionInspected] = useState(false);

  // New Equipment Form State
  const [newEqName, setNewEqName] = useState('');
  const [newEqSerial, setNewEqSerial] = useState('');
  const [newEqCategory, setNewEqCategory] = useState<Equipment['category']>('Robotics & CNC');
  const [newEqPurchaseVal, setNewEqPurchaseVal] = useState(65000);

  // Appeal Form State
  const [appealGrounds, setAppealGrounds] = useState<string>('valuation_dispute');
  const [appealStatement, setAppealStatement] = useState('');

  // Handle Redaction computation
  const redactionResult = scrubPIIFromText(
    `${incidentDesc}\nContact: ${rawContactEmail}\nCompany: ${rawClaimantName}`,
    rawClaimantName
  );

  const handleClaimSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetEq = equipmentList.find((e) => e.id === selectedEqId) || equipmentList[0];
    const newClaimId = `CLM-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newEvidence: EvidenceItem[] = [
      {
        id: `EVD-${Date.now()}`,
        title: 'Diagnostic Inverter Telemetry & Photo',
        filename: 'telemetry_log_inverter.pdf',
        fileType: 'application/pdf',
        sha256Hash: syncSha256(`${incidentDesc}:${Date.now()}`),
        uploadTimestamp: new Date().toISOString(),
        classification: 'telemetry_log',
        redactedPreviewUrl: '/redacted_evidence/telemetry.png',
        rawUrl: '/evidence/telemetry.pdf',
        isPIIRedacted: true,
        redactedFields: ['Technician Name', 'Direct Email', 'Tax ID'],
        redactionAuditNote: 'Automated PII scrubbing completed. Diagnostic telemetry preserved.',
      },
    ];

    const newClaim: Claim = {
      id: `CLM-${Date.now()}`,
      claimNumber: newClaimId,
      claimantId: targetEq.ownerId,
      claimantName: targetEq.ownerName,
      equipmentId: targetEq.id,
      equipmentName: targetEq.name,
      equipmentSerial: targetEq.serialNumber,
      poolId: targetEq.activePolicyId || 'POOL-MFG-01',
      poolName: 'Advanced Manufacturing & Precision Robotics Pool',
      policyVersion: activePolicy.version,
      policyWordingHash: activePolicy.wordingHash,
      incidentDate: `${incidentDate}T10:00:00Z`,
      submissionDate: new Date().toISOString(),
      incidentType,
      incidentDescription: redactionResult.redactedText,
      claimedAmount,
      state: 'eligibility_checked',
      timeline: [
        {
          timestamp: new Date().toISOString(),
          state: 'submitted',
          actorRole: 'member',
          actorName: targetEq.ownerName,
          description: 'Claim registered with blinded evidence package.',
          hashProof: syncSha256(newClaimId),
        },
        {
          timestamp: new Date().toISOString(),
          state: 'eligibility_checked',
          actorRole: 'system',
          actorName: 'Policy Administration Engine',
          description: 'Policy in force, notification window satisfied.',
          hashProof: syncSha256(`${newClaimId}:eligibility`),
        },
      ],
      evidence: newEvidence,
      trackACommitments: [],
      trackBCommitments: [],
    };

    onSubmitClaim(newClaim);
    setIsFilingClaim(false);
  };

  const handleEquipmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEqName || !newEqSerial) return;

    const newEq: Equipment = {
      id: `EQ-${Date.now()}`,
      serialNumber: newEqSerial,
      name: newEqName,
      category: newEqCategory,
      manufacturer: newEqName.split(' ')[0] || 'Precision OEM',
      model: newEqName,
      purchaseDate: new Date().toISOString().split('T')[0],
      purchaseValue: newEqPurchaseVal,
      replacementValue: Math.round(newEqPurchaseVal * 1.05),
      depreciationRatePct: 15,
      currentDepreciatedValue: newEqPurchaseVal,
      location: 'Primary Production Facility',
      ownerId: 'MBR-7702',
      ownerName: 'Vanguard Precision Engineering Ltd',
      registrationProofHash: syncSha256(`${newEqSerial}:${newEqName}:${Date.now()}`),
      status: 'coverage_active',
      activePolicyId: 'POOL-MFG-01',
      registeredDate: new Date().toISOString().split('T')[0],
    };

    onAddEquipment(newEq);
    setIsAddingEquipment(false);
    setNewEqName('');
    setNewEqSerial('');
  };

  const handleAppealSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClaimForAppeal) return;
    onSubmitAppeal(selectedClaimForAppeal.id, appealGrounds, appealStatement);
    setSelectedClaimForAppeal(null);
    setAppealStatement('');
  };

  return (
    <div className="space-y-8">
      {/* Header with Sub-tabs */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37]">
            Member Operations
          </span>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Equipment Registry & Active Claims
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <div className="inline-flex rounded bg-[#161A22] p-1 border border-white/[0.08]">
            <button
              onClick={() => setActiveSubTab('claims')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeSubTab === 'claims' ? 'bg-[#29313E] text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              Claims ({claims.length})
            </button>
            <button
              onClick={() => setActiveSubTab('equipment')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeSubTab === 'equipment' ? 'bg-[#29313E] text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              Registered Equipment ({equipmentList.length})
            </button>
            <button
              onClick={() => setActiveSubTab('policy')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeSubTab === 'policy' ? 'bg-[#29313E] text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              Policy Terms ({activePolicy.version})
            </button>
          </div>

          <button
            onClick={() => setIsFilingClaim(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Submit Claim</span>
          </button>
        </div>
      </div>

      {/* Subtab 1: Claims List */}
      {activeSubTab === 'claims' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4">
            {claims.map((claim) => (
              <div
                key={claim.id}
                className="bg-[#141820] border border-white/[0.08] rounded-lg p-5 hover:border-white/[0.18] transition-colors"
              >
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
                      <span className="font-bold text-white text-sm">{claim.claimNumber}</span>
                      <span aria-hidden="true">·</span>
                      <span>{claim.equipmentName}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-[#D4AF37]">€{claim.claimedAmount.toLocaleString()}</span>
                    </div>
                    <p className="text-xs text-slate-300 max-w-3xl line-clamp-2">
                      {claim.incidentDescription}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-mono capitalize px-2.5 py-1 rounded bg-[#202632] text-slate-200 border border-white/[0.06]">
                      {claim.state.replace('_', ' ')}
                    </span>
                    <button
                      onClick={() => onSelectClaim(claim)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#1D232D] hover:bg-[#29313E] border border-white/[0.08] rounded transition-colors cursor-pointer"
                    >
                      View Details
                    </button>
                    {(claim.state === 'authorised' || claim.state === 'assessed') && !claim.appeal && (
                      <button
                        onClick={() => setSelectedClaimForAppeal(claim)}
                        className="px-3 py-1.5 text-xs font-medium text-[#D4AF37] hover:bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded transition-colors cursor-pointer"
                      >
                        File Appeal
                      </button>
                    )}
                  </div>
                </div>

                {/* State Machine Timeline Stepper */}
                <div className="mt-5 pt-4 border-t border-white/[0.05]">
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 overflow-x-auto pb-2 gap-2">
                    {[
                      { key: 'submitted', label: '1. Submitted' },
                      { key: 'eligibility_checked', label: '2. Eligibility' },
                      { key: 'evidence_requested', label: '3. Redacted' },
                      { key: 'review_assigned', label: '4. Assigned' },
                      { key: 'committed', label: '5. Committed' },
                      { key: 'revealed', label: '6. Revealed' },
                      { key: 'assessed', label: '7. Assessed' },
                      { key: 'authorised', label: '8. Authorised' },
                      { key: 'paid', label: '9. Paid' },
                    ].map((step, idx) => {
                      const statesOrder: Claim['state'][] = [
                        'submitted',
                        'eligibility_checked',
                        'evidence_requested',
                        'review_assigned',
                        'committed',
                        'revealed',
                        'assessed',
                        'authorised',
                        'payment_pending',
                        'paid',
                      ];
                      const currentIdx = statesOrder.indexOf(claim.state);
                      const isPast = currentIdx >= idx;
                      const isCurrent = claim.state === step.key;

                      return (
                        <div
                          key={step.key}
                          className={`flex items-center gap-1.5 shrink-0 ${
                            isCurrent
                              ? 'text-[#D4AF37] font-bold'
                              : isPast
                              ? 'text-slate-200'
                              : 'text-slate-600'
                          }`}
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${
                              isCurrent
                                ? 'bg-[#D4AF37]'
                                : isPast
                                ? 'bg-slate-400'
                                : 'bg-slate-700'
                            }`}
                          />
                          <span>{step.label}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subtab 2: Registered Equipment */}
      {activeSubTab === 'equipment' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <p className="text-xs text-slate-400">
              Only equipment registered prior to an incident date with verified serial hashes is eligible for coverage.
            </p>
            <button
              onClick={() => setIsAddingEquipment(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-[#1D232D] hover:bg-[#29313E] border border-white/[0.08] rounded transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Register Equipment</span>
            </button>
          </div>

          <div className="overflow-x-auto border border-white/[0.08] rounded-lg">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-[#161A22] text-slate-400 font-mono text-[11px] border-b border-white/[0.08]">
                <tr>
                  <th className="py-3 px-4">Equipment Unit</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Serial Number</th>
                  <th className="py-3 px-4">Purchase / Replacement</th>
                  <th className="py-3 px-4">Depreciated Book Val</th>
                  <th className="py-3 px-4">Registration Hash</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.05]">
                {equipmentList.map((eq) => (
                  <tr key={eq.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-4 font-semibold text-white">
                      {eq.name}
                      <span className="block text-[11px] text-slate-500 font-normal">{eq.manufacturer}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-400">{eq.category}</td>
                    <td className="py-3 px-4 font-mono text-slate-300">{eq.serialNumber}</td>
                    <td className="py-3 px-4 font-mono">
                      €{eq.purchaseValue.toLocaleString()} / €{eq.replacementValue.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 font-mono text-[#D4AF37]">
                      €{eq.currentDepreciatedValue.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 font-mono text-[10px] text-slate-500">
                      {eq.registrationProofHash.slice(0, 16)}...
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[11px] font-mono capitalize text-emerald-400">
                        {eq.status.replace('_', ' ')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Subtab 3: Policy Version */}
      {activeSubTab === 'policy' && (
        <div className="bg-[#141820] border border-white/[0.08] rounded-lg p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-mono">Applicable Version</span>
                <span className="text-xs font-bold text-white bg-[#222832] px-2 py-0.5 rounded border border-white/[0.08]">
                  {activePolicy.version}
                </span>
              </div>
              <h3 className="text-lg font-bold text-white mt-1">Equipment Direct Mutual Coverage Agreement</h3>
            </div>
            <div className="text-right font-mono text-xs text-slate-400">
              <span>Canonical Wording Hash:</span>
              <span className="block text-[11px] text-[#D4AF37]">{activePolicy.wordingHash}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
            <div className="bg-[#161A22] p-4 rounded border border-white/[0.06]">
              <span className="text-slate-500">Deductible Per Claim</span>
              <span className="block text-base font-bold text-white mt-1">
                €{activePolicy.deductibleAmount.toLocaleString()}
              </span>
            </div>
            <div className="bg-[#161A22] p-4 rounded border border-white/[0.06]">
              <span className="text-slate-500">Max Aggregate Limit</span>
              <span className="block text-base font-bold text-white mt-1">
                €{activePolicy.maxCoverageLimit.toLocaleString()}
              </span>
            </div>
            <div className="bg-[#161A22] p-4 rounded border border-white/[0.06]">
              <span className="text-slate-500">Notice Window</span>
              <span className="block text-base font-bold text-white mt-1">
                {activePolicy.notificationWindowDays} Calendar Days
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-300">
            <div className="space-y-3">
              <h4 className="font-semibold text-white">Covered Perils (§4.0)</h4>
              <ul className="space-y-1.5 list-disc list-inside text-slate-400">
                {activePolicy.coveredPerils.map((p, idx) => (
                  <li key={idx}>{p}</li>
                ))}
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-semibold text-white">Standard Exclusions (§5.0)</h4>
              <ul className="space-y-1.5 list-disc list-inside text-slate-400">
                {activePolicy.exclusions.map((e, idx) => (
                  <li key={idx}>{e}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-[#181C23] p-4 rounded text-xs text-slate-400 border border-white/[0.05]">
            <p className="font-medium text-white mb-1">Immutable Policy Binding Guarantee</p>
            This policy terms version is cryptographically pinned to all existing claims. Subsequent revisions to terms by pool governance will never retroactively adjust or diminish coverage for in-flight claims.
          </div>
        </div>
      )}

      {/* Claim Filing Modal with Interactive PII Redaction Preview */}
      {isFilingClaim && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#11141A] border border-white/[0.12] rounded-xl max-w-3xl w-full p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-4">
              <div>
                <span className="text-xs font-mono text-[#D4AF37] uppercase">Privacy-Preserving Intake</span>
                <h3 className="text-xl font-bold text-white">Submit New Equipment Damage Claim</h3>
              </div>
              <button
                onClick={() => setIsFilingClaim(false)}
                className="text-slate-400 hover:text-white text-xs font-mono"
              >
                [ESC / CLOSE]
              </button>
            </div>

            <form onSubmit={handleClaimSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">Select Registered Equipment</label>
                  <select
                    value={selectedEqId}
                    onChange={(e) => setSelectedEqId(e.target.value)}
                    className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white"
                  >
                    {equipmentList.map((eq) => (
                      <option key={eq.id} value={eq.id}>
                        {eq.name} ({eq.serialNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Incident Category</label>
                  <select
                    value={incidentType}
                    onChange={(e) => setIncidentType(e.target.value as Claim['incidentType'])}
                    className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white"
                  >
                    <option value="electrical_surge">Sudden Electrical Surge / Inverter Failure</option>
                    <option value="mechanical_failure">Catastrophic Mechanical Seizure</option>
                    <option value="transit_drop">Accidental Rigging / Transit Drop</option>
                    <option value="water_damage">Dielectric Coolant / Burst Line Leak</option>
                    <option value="accidental_impact">Accidental Physical Impact</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Date of Incident</label>
                  <input
                    type="date"
                    value={incidentDate}
                    onChange={(e) => setIncidentDate(e.target.value)}
                    className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Estimated Repair / Loss (€)</label>
                  <input
                    type="number"
                    value={claimedAmount}
                    onChange={(e) => setClaimedAmount(Number(e.target.value))}
                    className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div className="text-xs space-y-1">
                <label className="block text-slate-400">Incident Narrative & Diagnostic Telemetry</label>
                <textarea
                  rows={4}
                  value={incidentDesc}
                  onChange={(e) => setIncidentDesc(e.target.value)}
                  className="w-full bg-[#181D26] border border-white/[0.1] rounded p-3 text-white leading-relaxed"
                />
              </div>

              {/* Automatic PII Scrubbing Preview */}
              <div className="bg-[#161B23] border border-white/[0.08] rounded-lg p-4 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-slate-200 font-semibold">
                    <EyeOff className="w-4 h-4 text-[#D4AF37]" />
                    <span>Double-Blind Reviewer Packet Redaction Preview</span>
                  </div>
                  <span className="font-mono text-[11px] text-emerald-400">
                    {redactionResult.detectedPII.length} PII tokens scrubbed
                  </span>
                </div>

                <div className="bg-[#0D1016] border border-white/[0.06] rounded p-3 font-mono text-[11px] text-slate-300 leading-relaxed whitespace-pre-wrap">
                  {redactionResult.redactedText}
                </div>

                {/* Warning callout required by prompt §3 */}
                <div className="flex items-start gap-2 text-[11px] text-amber-300/90 bg-amber-950/20 p-2.5 rounded border border-amber-500/20">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    <strong>Pseudonymity Notice:</strong> Direct claimant identity, emails, and facility identifiers have been redacted from the reviewer dispatch package. Note: document contents may still reveal identity indirectly through proprietary toolpaths or facility layouts.
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsFilingClaim(false)}
                  className="px-4 py-2 text-xs text-slate-300 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded transition-colors shadow-sm cursor-pointer"
                >
                  Confirm & Submit Blinded Claim
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Register Equipment Modal */}
      {isAddingEquipment && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#11141A] border border-white/[0.12] rounded-xl max-w-lg w-full p-6 space-y-5">
            <h3 className="text-lg font-bold text-white">Register Commercial Equipment</h3>
            <form onSubmit={handleEquipmentSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Equipment Name & Model</label>
                <input
                  type="text"
                  placeholder="e.g. TRUMPF TruLaser 3030 Fiber"
                  value={newEqName}
                  onChange={(e) => setNewEqName(e.target.value)}
                  className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">OEM Serial Number</label>
                <input
                  type="text"
                  placeholder="e.g. TRU-3030-2025-998"
                  value={newEqSerial}
                  onChange={(e) => setNewEqSerial(e.target.value)}
                  className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 mb-1">Category</label>
                  <select
                    value={newEqCategory}
                    onChange={(e) => setNewEqCategory(e.target.value as Equipment['category'])}
                    className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white"
                  >
                    <option value="Robotics & CNC">Robotics & CNC</option>
                    <option value="Cinema & Optical">Cinema & Optical</option>
                    <option value="Enterprise Compute">Enterprise Compute</option>
                    <option value="Analytical Instruments">Analytical Instruments</option>
                    <option value="Precision AgTech">Precision AgTech</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Purchase Invoice Value (€)</label>
                  <input
                    type="number"
                    value={newEqPurchaseVal}
                    onChange={(e) => setNewEqPurchaseVal(Number(e.target.value))}
                    className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white font-mono"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddingEquipment(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded cursor-pointer"
                >
                  Save & Mint Registration Hash
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Appeal Submission Modal */}
      {selectedClaimForAppeal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#11141A] border border-white/[0.12] rounded-xl max-w-xl w-full p-6 space-y-5">
            <div>
              <span className="text-xs font-mono text-[#D4AF37] uppercase">Accountable Escalation</span>
              <h3 className="text-lg font-bold text-white">
                Lodge Independent Appeal for {selectedClaimForAppeal.claimNumber}
              </h3>
            </div>

            <form onSubmit={handleAppealSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Grounds for Appeal</label>
                <select
                  value={appealGrounds}
                  onChange={(e) => setAppealGrounds(e.target.value)}
                  className="w-full bg-[#181D26] border border-white/[0.1] rounded px-3 py-2 text-white"
                >
                  <option value="valuation_dispute">Dispute over Depreciation Rate / Valuation Method</option>
                  <option value="factual_misinterpretation">Factual Misinterpretation of Diagnostic Telemetry</option>
                  <option value="new_corroborating_evidence">Submission of New OEM Forensic Evidence</option>
                  <option value="procedural_irregularity">Procedural Conflict of Interest Concern</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Appellant Legal & Factual Grounds Statement</label>
                <textarea
                  rows={4}
                  value={appealStatement}
                  onChange={(e) => setAppealStatement(e.target.value)}
                  placeholder="Detail the factual error or contractual rider in Policy v1.2 that justifies revision..."
                  className="w-full bg-[#181D26] border border-white/[0.1] rounded p-3 text-white leading-relaxed"
                  required
                />
              </div>

              <div className="bg-[#181C23] p-3 rounded text-[11px] text-slate-400 border border-white/[0.05]">
                <strong>Senior Panel Guarantee:</strong> Appeals are escalated to Senior Arbitrators who had zero prior involvement in this claim. Reviewers are screened for conflict of interest.
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedClaimForAppeal(null)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded cursor-pointer"
                >
                  Escalate to Senior Panel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
