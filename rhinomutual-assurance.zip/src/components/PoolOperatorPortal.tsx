/**
 * RhinoMutual Pool Operator Portal
 * Reserves Accounting, Solvency Monitoring, Surplus Allocation, and Stress Testing
 * Developed by Aureom.AI
 */

import React, { useState } from 'react';
import { P2PPool } from '../types';
import { 
  Building2, 
  TrendingUp, 
  ShieldCheck, 
  AlertOctagon, 
  RefreshCw, 
  Percent, 
  Coins, 
  Lock,
  PieChart,
  ArrowUpRight
} from 'lucide-react';

interface PoolOperatorProps {
  pools: P2PPool[];
  onTriggerCapitalCall: (poolId: string) => void;
  onSimulateSurplusRebate: (poolId: string) => void;
}

export const PoolOperatorPortal: React.FC<PoolOperatorProps> = ({
  pools,
  onTriggerCapitalCall,
  onSimulateSurplusRebate,
}) => {
  const [selectedPoolId, setSelectedPoolId] = useState<string>(pools[0].id);
  const selectedPool = pools.find((p) => p.id === selectedPoolId) || pools[0];

  const [stressShockActive, setStressShockActive] = useState(false);

  // Compute hypothetical surplus
  const estimatedAnnualIncurredClaims = selectedPool.claimsReserveBalance * 0.45;
  const grossSurplus = Math.max(0, selectedPool.annualContributions - estimatedAnnualIncurredClaims - selectedPool.operatingReserve);
  const memberRebateAmount = grossSurplus * (selectedPool.surplusAllocation.claimsFreeRebatePct / 100);
  const reserveCushionAmount = grossSurplus * (selectedPool.surplusAllocation.reserveCushionPct / 100);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="border-b border-white/[0.08] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37]">
            Operator Operations
          </span>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            P2P Pool Reserves, Solvency & Surplus Distribution
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Validator bonds are segregated in independent escrow from member claims reserves. Members never vote on individual claims to protect against retaliatory claim denials.
          </p>
        </div>

        {/* Pool Selector Tabs */}
        <div className="inline-flex rounded bg-[#161A22] p-1 border border-white/[0.08]">
          {pools.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelectedPoolId(p.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                selectedPool.id === p.id
                  ? 'bg-[#29313E] text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {p.code}
            </button>
          ))}
        </div>
      </div>

      {/* Solvency Cockpit */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#141820] border border-white/[0.08] rounded-lg p-5 space-y-2">
          <span className="text-xs font-mono text-slate-400 uppercase">Claims Reserve Balance</span>
          <div className="text-2xl font-extrabold text-white font-mono">
            €{selectedPool.claimsReserveBalance.toLocaleString()}
          </div>
          <span className="text-[11px] text-emerald-400 font-mono block">
            Segregated from validator bonds
          </span>
        </div>

        <div className="bg-[#141820] border border-white/[0.08] rounded-lg p-5 space-y-2">
          <span className="text-xs font-mono text-slate-400 uppercase">Solvency Ratio</span>
          <div className="text-2xl font-extrabold text-[#D4AF37] font-mono">
            {selectedPool.liquidityRatioPct.toFixed(1)}%
          </div>
          <span className="text-[11px] text-slate-400 font-mono block">
            Target Solvency: {selectedPool.targetSolvencyPct}%
          </span>
        </div>

        <div className="bg-[#141820] border border-white/[0.08] rounded-lg p-5 space-y-2">
          <span className="text-xs font-mono text-slate-400 uppercase">Active Risk Exposure</span>
          <div className="text-2xl font-extrabold text-slate-200 font-mono">
            €{selectedPool.totalExposure.toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-400 font-mono block">
            {selectedPool.activeEquipmentUnits} Registered Units
          </span>
        </div>

        <div className="bg-[#141820] border border-white/[0.08] rounded-lg p-5 space-y-2">
          <span className="text-xs font-mono text-slate-400 uppercase">Operating Reserve</span>
          <div className="text-2xl font-extrabold text-slate-300 font-mono">
            €{selectedPool.operatingReserve.toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-400 font-mono block">
            For validator fees & audits
          </span>
        </div>
      </div>

      {/* Surplus Allocation Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 bg-[#141820] border border-white/[0.08] rounded-xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-white/[0.08] pb-4">
            <div>
              <span className="text-xs font-mono text-[#D4AF37] uppercase">Contractual Governance</span>
              <h3 className="text-lg font-bold text-white">Year-End Mutual Surplus Allocation</h3>
            </div>
            <button
              onClick={() => onSimulateSurplusRebate(selectedPool.id)}
              className="px-3 py-1.5 text-xs font-semibold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded transition-colors cursor-pointer"
            >
              Simulate Rebate Distribution
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
            <div className="bg-[#161B23] p-4 rounded border border-white/[0.06] space-y-1">
              <span className="text-slate-500">Gross Estimated Surplus</span>
              <span className="block text-base font-bold text-white">
                €{Math.round(grossSurplus).toLocaleString()}
              </span>
            </div>
            <div className="bg-[#161B23] p-4 rounded border border-white/[0.06] space-y-1">
              <span className="text-emerald-400">Claims-Free Rebate (70%)</span>
              <span className="block text-base font-bold text-white">
                €{Math.round(memberRebateAmount).toLocaleString()}
              </span>
            </div>
            <div className="bg-[#161B23] p-4 rounded border border-white/[0.06] space-y-1">
              <span className="text-amber-400">Reserve Cushion (25%)</span>
              <span className="block text-base font-bold text-white">
                €{Math.round(reserveCushionAmount).toLocaleString()}
              </span>
            </div>
          </div>

          <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
            <h4 className="font-semibold text-white">Anti-Moral Hazard Surplus Principles:</h4>
            <p>
              1. <strong>Claims-Free Rebate:</strong> Members who registered zero claims during the underwriting cycle receive up to 70% of residual surplus returned directly as a cash rebate or credited toward subsequent year contributions.
            </p>
            <p>
              2. <strong>Zero Vote Dilution:</strong> Members are strictly prohibited from voting on individual claim approvals or denials. P2P surplus incentives must never motivate malicious denial of legitimate claims.
            </p>
            <p>
              3. <strong>Capital Buffer:</strong> 25% of any annual surplus is automatically transferred to the non-withdrawable reserve buffer to withstand correlated multi-loss catastrophic shocks.
            </p>
          </div>
        </div>

        {/* Stress Testing & Capital Call Engine */}
        <div className="lg:col-span-5 bg-[#141820] border border-white/[0.08] rounded-xl p-6 space-y-6">
          <div className="border-b border-white/[0.08] pb-4">
            <span className="text-xs font-mono text-[#D4AF37] uppercase">Solvency Resilience</span>
            <h3 className="text-lg font-bold text-white">Correlated Loss & Capital Call</h3>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Model extreme scenarios where multiple high-value equipment units fail simultaneously (e.g. regional power grid blackouts or industrial chiller plant trips).
          </p>

          <div className="bg-[#161B23] p-4 rounded border border-white/[0.06] space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-300 font-medium">Catastrophic Surge Shock (5x Claims)</span>
              <button
                onClick={() => setStressShockActive(!stressShockActive)}
                className={`px-2.5 py-1 rounded text-[11px] font-mono cursor-pointer transition-colors ${
                  stressShockActive
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : 'bg-[#29313E] text-slate-300'
                }`}
              >
                {stressShockActive ? 'Shock Active' : 'Simulate Shock'}
              </button>
            </div>

            {stressShockActive && (
              <div className="p-3 bg-rose-950/20 rounded border border-rose-500/20 text-rose-300 space-y-2">
                <div className="flex items-center gap-1.5 font-bold">
                  <AlertOctagon className="w-4 h-4" />
                  <span>Pool Liquidity Deficit Detected</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Projected 5 simultaneous claims total €480,000. Under explicit policy terms (§8.3), a transparent pro-rata capital call of €2,500 per member is triggered. Payouts are never silently haircut!
                </p>
                <button
                  onClick={() => onTriggerCapitalCall(selectedPool.id)}
                  className="w-full py-1.5 text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white rounded transition-colors cursor-pointer"
                >
                  Broadcast Transparent Capital Call Notice
                </button>
              </div>
            )}
          </div>

          <div className="font-mono text-[11px] text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>Pool Code:</span>
              <span className="text-white">{selectedPool.code}</span>
            </div>
            <div className="flex justify-between">
              <span>Total Members:</span>
              <span className="text-white">{selectedPool.totalMembers} Commercial Entities</span>
            </div>
            <div className="flex justify-between">
              <span>External Reinsurance Layer:</span>
              <span className="text-emerald-400">Active (Excess of Loss €500k)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
