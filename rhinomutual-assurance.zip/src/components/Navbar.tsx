/**
 * RhinoMutual Navbar - Top Bar Contract
 * Developed by Aureom.AI
 */

import React from 'react';
import { UserRole } from '../types';
import { 
  Shield, 
  Users, 
  CheckCircle2, 
  Layers, 
  Scale, 
  FileText, 
  Activity, 
  Compass,
  Lock
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  activeRole: UserRole;
  setActiveRole: (role: UserRole) => void;
  onOpenGuidedTour: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  activeRole,
  setActiveRole,
  onOpenGuidedTour,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0E1116]/95 backdrop-blur-md border-b border-white/[0.08] text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-[#D4AF37] to-[#A8811C] flex items-center justify-center text-black font-extrabold shadow-sm">
              <Shield className="w-4 h-4 text-[#0B0D11]" />
            </div>
            <button
              onClick={() => setCurrentTab('overview')}
              className="text-left group transition-colors"
            >
              <span className="text-base font-bold tracking-tight text-white group-hover:text-[#D4AF37] whitespace-nowrap">
                RHINOMUTUAL
              </span>
              <span className="text-[11px] text-slate-400 block -mt-1 font-mono tracking-wider">
                BY AUREOM.AI
              </span>
            </button>
          </div>

          {/* Zone 2: Navigation Links (single-line, clean unboxed) */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-300">
            <button
              onClick={() => setCurrentTab('overview')}
              className={`hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0 py-1 ${
                currentTab === 'overview' ? 'text-[#D4AF37] border-b border-[#D4AF37]' : ''
              }`}
            >
              Trust Model
            </button>
            <button
              onClick={() => setCurrentTab('member')}
              className={`hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0 py-1 ${
                currentTab === 'member' ? 'text-[#D4AF37] border-b border-[#D4AF37]' : ''
              }`}
            >
              Member Portal
            </button>
            <button
              onClick={() => setCurrentTab('validator')}
              className={`hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0 py-1 ${
                currentTab === 'validator' ? 'text-[#D4AF37] border-b border-[#D4AF37]' : ''
              }`}
            >
              Validator Network
            </button>
            <button
              onClick={() => setCurrentTab('pools')}
              className={`hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0 py-1 ${
                currentTab === 'pools' ? 'text-[#D4AF37] border-b border-[#D4AF37]' : ''
              }`}
            >
              Pool Reserves
            </button>
            <button
              onClick={() => setCurrentTab('adjudication')}
              className={`hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0 py-1 ${
                currentTab === 'adjudication' ? 'text-[#D4AF37] border-b border-[#D4AF37]' : ''
              }`}
            >
              2-Track Adjudication
            </button>
            <button
              onClick={() => setCurrentTab('ledger')}
              className={`hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0 py-1 ${
                currentTab === 'ledger' ? 'text-[#D4AF37] border-b border-[#D4AF37]' : ''
              }`}
            >
              Audit Ledger & ZK
            </button>
            <button
              onClick={() => setCurrentTab('simulation')}
              className={`hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0 py-1 ${
                currentTab === 'simulation' ? 'text-[#D4AF37] border-b border-[#D4AF37]' : ''
              }`}
            >
              Simulation Lab
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenGuidedTour}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded transition-colors whitespace-nowrap shadow-sm cursor-pointer"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Guided Demo Tour</span>
            </button>
          </div>
        </div>

        {/* Secondary Role Persona Bar */}
        <div className="border-t border-white/[0.05] py-2 flex flex-wrap items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase tracking-wider text-slate-500 font-mono">
              Active Persona:
            </span>
            <div className="inline-flex rounded bg-[#161A22] p-0.5 border border-white/[0.08]">
              {(['member', 'validator', 'operator', 'adjudicator', 'auditor'] as UserRole[]).map(
                (role) => (
                  <button
                    key={role}
                    onClick={() => {
                      setActiveRole(role);
                      if (role === 'member') setCurrentTab('member');
                      if (role === 'validator') setCurrentTab('validator');
                      if (role === 'operator') setCurrentTab('pools');
                      if (role === 'adjudicator') setCurrentTab('adjudication');
                      if (role === 'auditor') setCurrentTab('ledger');
                    }}
                    className={`px-2.5 py-1 rounded text-[11px] font-medium capitalize transition-colors ${
                      activeRole === role
                        ? 'bg-[#29313E] text-white shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {role}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-4 font-mono text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <Lock className="w-3 h-3 text-[#D4AF37]" />
              Double-Blind Active
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Policy: v1.2-2026.1</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Ledger: Block #1044</span>
          </div>
        </div>
      </div>
    </header>
  );
};
