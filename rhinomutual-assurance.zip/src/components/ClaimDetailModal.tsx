/**
 * RhinoMutual Claim Detail & Timeline Inspector Modal
 * Developed by Aureom.AI
 */

import React from 'react';
import { Claim, TrackAReport, TrackBReport } from '../types';
import { 
  X, 
  ShieldCheck, 
  EyeOff, 
  GitBranch, 
  CheckCircle2, 
  Clock, 
  FileText, 
  Layers, 
  Lock, 
  CreditCard,
  Building2,
  AlertCircle
} from 'lucide-react';

interface ClaimDetailModalProps {
  claim: Claim | null;
  onClose: () => void;
  onNavigateToTab: (tab: string) => void;
}

export const ClaimDetailModal: React.FC<ClaimDetailModalProps> = ({
  claim,
  onClose,
  onNavigateToTab,
}) => {
  if (!claim) return null;

  const revealedTrackA = claim.trackACommitments?.find((c) => c.status === 'revealed')?.revealedReport as TrackAReport | undefined;
  const revealedTrackB = claim.trackBCommitments?.find((c) => c.status === 'revealed')?.revealedReport as TrackBReport | undefined;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#11141A] border border-white/[0.12] rounded-xl max-w-4xl w-full p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="border-b border-white/[0.08] pb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase text-[#D4AF37] font-bold">
              {claim.claimNumber}
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-xs font-mono capitalize px-2 py-0.5 rounded bg-[#1D232D] text-slate-300">
              State: {claim.state.replace('_', ' ')}
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-xs font-mono text-slate-400">Policy: {claim.policyVersion}</span>
          </div>
          <h3 className="text-xl font-bold text-white tracking-tight mt-1">
            {claim.equipmentName} ({claim.equipmentSerial})
          </h3>
        </div>

        {/* Key Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div className="bg-[#161B23] p-3 rounded border border-white/[0.06]">
            <span className="text-slate-500 block">Claimed Loss</span>
            <span className="text-base font-bold text-white mt-0.5 block">
              €{claim.claimedAmount.toLocaleString()}
            </span>
          </div>
          <div className="bg-[#161B23] p-3 rounded border border-white/[0.06]">
            <span className="text-slate-500 block">Incident Date</span>
            <span className="text-slate-200 mt-0.5 block">
              {claim.incidentDate.split('T')[0]}
            </span>
          </div>
          <div className="bg-[#161B23] p-3 rounded border border-white/[0.06]">
            <span className="text-slate-500 block">Incident Category</span>
            <span className="text-slate-200 capitalize mt-0.5 block">
              {claim.incidentType.replace('_', ' ')}
            </span>
          </div>
          <div className="bg-[#161B23] p-3 rounded border border-white/[0.06]">
            <span className="text-slate-500 block">Reconciled Settlement</span>
            <span className="text-base font-bold text-[#D4AF37] mt-0.5 block">
              {claim.adjudication
                ? `€${claim.adjudication.reconciledAmount.toLocaleString()}`
                : claim.appeal?.revisedAmount
                ? `€${claim.appeal.revisedAmount.toLocaleString()}`
                : 'Under Review'}
            </span>
          </div>
        </div>

        {/* Narrative & Redaction */}
        <div className="bg-[#141820] border border-white/[0.06] rounded-lg p-4 space-y-2 text-xs">
          <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
            <span className="font-semibold text-slate-300">Blinded Incident Narrative</span>
            <span className="text-emerald-400">Direct PII Scrubbed</span>
          </div>
          <p className="text-slate-300 leading-relaxed font-sans">
            {claim.incidentDescription}
          </p>
        </div>

        {/* Evidence Items & Hash Verification */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
            Cryptographic Evidence Records ({claim.evidence.length})
          </h4>
          {claim.evidence.length === 0 ? (
            <p className="text-xs text-slate-500 font-mono">No supplementary evidence files attached</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {claim.evidence.map((evd) => (
                <div key={evd.id} className="bg-[#161B23] border border-white/[0.06] rounded p-3 text-xs space-y-1.5 font-mono">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white font-sans">{evd.title}</span>
                    <span className="text-[10px] text-slate-400">{evd.classification}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">File: {evd.filename}</div>
                  <div className="text-[10px] text-slate-500 break-all">SHA-256: {evd.sha256Hash}</div>
                  {evd.isPIIRedacted && (
                    <div className="text-[10px] text-emerald-400 font-sans">
                      ✓ Redacted: {evd.redactedFields.join(', ')}
                    </div>
                  )}
                  {evd.independentAttestation && (
                    <div className="text-[10px] text-[#D4AF37] font-sans">
                      Attestation: {evd.independentAttestation.attestor} ({evd.independentAttestation.status})
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Validation Tracks Corroboration */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Track A */}
          <div className="bg-[#161B23] border border-white/[0.08] rounded-lg p-4 space-y-2">
            <span className="font-bold text-white block">Track A: Evidence Forensics</span>
            {revealedTrackA ? (
              <div className="space-y-1.5 text-[11px] font-mono">
                <div className="text-emerald-400">✓ Hardware telemetry correlated</div>
                <div className="text-emerald-400">✓ Serial plaque matched</div>
                <div className="text-[#D4AF37]">Uncertainty: {revealedTrackA.uncertaintyFactor.toFixed(2)}</div>
                <p className="font-sans text-slate-300 pt-1 text-[11px]">{revealedTrackA.findingsSummary}</p>
              </div>
            ) : (
              <p className="text-slate-500 font-mono text-[11px]">Sealed or in commitment phase</p>
            )}
          </div>

          {/* Track B */}
          <div className="bg-[#161B23] border border-white/[0.08] rounded-lg p-4 space-y-2">
            <span className="font-bold text-white block">Track B: Contractual Coverage</span>
            {revealedTrackB ? (
              <div className="space-y-1.5 text-[11px] font-mono">
                <div className="text-emerald-400">✓ Policy active (§2.1)</div>
                <div className="text-emerald-400">✓ Peril covered (§4.0)</div>
                <div className="text-slate-300">Deductible: -€{revealedTrackB.applicableDeductible}</div>
                <div className="text-slate-300">Depreciation: -€{revealedTrackB.depreciationAdjustment}</div>
                <div className="text-[#D4AF37] font-bold">Proposed: €{revealedTrackB.proposedNetSettlement.toLocaleString()}</div>
              </div>
            ) : (
              <p className="text-slate-500 font-mono text-[11px]">Sealed or in commitment phase</p>
            )}
          </div>
        </div>

        {/* Lifecycle Audit Events Timeline */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
            Lifecycle Audit Log & Hash Transitions
          </h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {claim.timeline.map((evt, idx) => (
              <div key={idx} className="flex items-start gap-3 text-xs bg-[#141820] p-2.5 rounded border border-white/[0.04]">
                <Clock className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div className="space-y-0.5 flex-1 font-mono text-[11px]">
                  <div className="flex items-center justify-between">
                    <span className="text-white font-semibold">{evt.actorName}</span>
                    <span className="text-slate-500">{evt.timestamp.split('T')[0]}</span>
                  </div>
                  <p className="text-slate-300 font-sans text-xs">{evt.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-white/[0.08]">
          <span className="text-xs font-mono text-slate-500">
            Immutable Claim ID: {claim.id}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-200 bg-[#1D232D] hover:bg-[#29313E] rounded cursor-pointer"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
