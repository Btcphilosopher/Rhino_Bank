/**
 * RhinoMutual Trust Model & Architectural Constitution
 * Developed by Aureom.AI
 */

import React from 'react';
import { 
  ShieldCheck, 
  FileCheck2, 
  Scale, 
  Database, 
  ArrowRight, 
  Lock, 
  Layers, 
  AlertTriangle,
  EyeOff,
  GitBranch,
  Coins
} from 'lucide-react';

interface TrustModelProps {
  onNavigate: (tab: string) => void;
  onOpenTour: () => void;
}

export const TrustModelOverview: React.FC<TrustModelProps> = ({ onNavigate, onOpenTour }) => {
  return (
    <div className="space-y-12">
      {/* Hero Visual Section */}
      <div className="relative rounded-xl overflow-hidden border border-white/[0.08] bg-[#11141A]">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[380px]">
          {/* Left Text Zone */}
          <div className="lg:col-span-7 p-8 lg:p-12 flex flex-col justify-between z-10">
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs text-[#D4AF37] font-mono tracking-wider uppercase">
                <span>Institutional P2P Risk Pool Engine</span>
                <span aria-hidden="true">·</span>
                <span>Aureom.AI Architecture</span>
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight text-balance leading-tight">
                Stake-Backed Mutual Assurance with Double-Blind Proof.
              </h1>
              <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
                RhinoMutual replaces adversarial insurance claims handling with two independent validation tracks, blinded commit-reveal reviews, and bonded validator performance guarantees.
              </p>
            </div>

            <div className="pt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenTour}
                className="px-5 py-2.5 text-xs font-bold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded transition-colors shadow-sm cursor-pointer"
              >
                Launch End-to-End Walkthrough
              </button>
              <button
                onClick={() => onNavigate('adjudication')}
                className="px-5 py-2.5 text-xs font-semibold text-slate-200 bg-[#1D232D] hover:bg-[#29313E] border border-white/[0.08] rounded transition-colors cursor-pointer"
              >
                Inspect 2-Track Adjudication
              </button>
            </div>
          </div>

          {/* Right Image Media Zone */}
          <div className="lg:col-span-5 relative bg-[#0B0D11] min-h-[260px] lg:min-h-full">
            <img
              src="/src/assets/images/rhinomutual_hero_banner_1794430753433.jpg"
              alt="RhinoMutual Assurance Institutional Vault Emblem"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center opacity-90 hover:opacity-100 transition-opacity"
            />
            <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-[#11141A] via-transparent to-transparent pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Trust Model Constitution: Separation of Four Functions */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37]">
            01. Foundational Trust Model
          </span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
            Separation of Four Independent Governance Functions
          </h2>
          <p className="text-sm text-slate-400 mt-1 max-w-3xl">
            Proof-of-stake establishes agreement about records; it does not establish whether an industrial accident occurred. RhinoMutual strictly separates physical fact-finding from contractual law and ledger recording.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Function 1 */}
          <div className="bg-[#161A22] border border-white/[0.08] rounded-lg p-6 space-y-4 hover:border-white/[0.16] transition-colors">
            <div className="w-10 h-10 rounded bg-[#222832] border border-white/[0.06] flex items-center justify-center text-[#D4AF37]">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-500 font-mono">Function I</span>
              <h3 className="text-base font-semibold text-white">Policy Administration</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Determines contractual boundaries: active in-force dates, covered perils, waiting periods, deductibles, and depreciation formulas. Attached immutably via canonical policy wording hashes.
            </p>
            <div className="text-[11px] font-mono text-slate-400 pt-2 border-t border-white/[0.05]">
              Output: Immutable Contract Wording Hash
            </div>
          </div>

          {/* Function 2 */}
          <div className="bg-[#161A22] border border-white/[0.08] rounded-lg p-6 space-y-4 hover:border-white/[0.16] transition-colors">
            <div className="w-10 h-10 rounded bg-[#222832] border border-white/[0.06] flex items-center justify-center text-[#D4AF37]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-500 font-mono">Function II</span>
              <h3 className="text-base font-semibold text-white">Evidence Forensics</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Examines what can be empirically established: cryptographic image hashes, EXIF sensors, machine telemetry, serial cross-checks, quote authenticity, and duplicate invoice detection.
            </p>
            <div className="text-[11px] font-mono text-slate-400 pt-2 border-t border-white/[0.05]">
              Output: Track A Integrity Findings & Uncertainty
            </div>
          </div>

          {/* Function 3 */}
          <div className="bg-[#161A22] border border-white/[0.08] rounded-lg p-6 space-y-4 hover:border-white/[0.16] transition-colors">
            <div className="w-10 h-10 rounded bg-[#222832] border border-white/[0.06] flex items-center justify-center text-[#D4AF37]">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-500 font-mono">Function III</span>
              <h3 className="text-base font-semibold text-white">Claim Adjudication</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Applies policy terms to supported facts. Reconciles Track A and Track B, calculates straight-line depreciation and salvage credits, and produces auditable reasoned decisions.
            </p>
            <div className="text-[11px] font-mono text-slate-400 pt-2 border-t border-white/[0.05]">
              Output: Reconciled Net Settlement Authorization
            </div>
          </div>

          {/* Function 4 */}
          <div className="bg-[#161A22] border border-white/[0.08] rounded-lg p-6 space-y-4 hover:border-white/[0.16] transition-colors">
            <div className="w-10 h-10 rounded bg-[#222832] border border-white/[0.06] flex items-center justify-center text-[#D4AF37]">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-500 font-mono">Function IV</span>
              <h3 className="text-base font-semibold text-white">Ledger Consensus</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Records authorised state transitions on an append-only double-entry ledger. Cryptographic hash chains ensure immutability without speculative volatile token economies.
            </p>
            <div className="text-[11px] font-mono text-slate-400 pt-2 border-t border-white/[0.05]">
              Output: Double-Entry Block Commitments
            </div>
          </div>
        </div>
      </section>

      {/* Double Proof & Double-Blind Architecture */}
      <section className="bg-[#141820] border border-white/[0.08] rounded-xl p-8 space-y-6">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37]">
            02. Core Innovations
          </span>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Operational Definitions: Double Proof & Double Blind
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Double Proof */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <GitBranch className="w-4 h-4 text-[#D4AF37]" />
              <h3>Two Independent Validation Tracks ("Double Proof")</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              A single false invoice can trick an adjuster; two approvals based on the same false document do not represent independent corroboration. RhinoMutual splits review into two separately reported tracks assigned to distinct validator entities:
            </p>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-[#D4AF37] font-mono">A.</span>
                <span><strong>Track A (Forensics):</strong> Analyzes file SHA-256 hashes, device EXIF, serial markings, duplicate claims cross-check, and quote tampering.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#D4AF37] font-mono">B.</span>
                <span><strong>Track B (Contractual Coverage):</strong> Analyzes policy wording in force, peril classifications, exclusion triggers, deductible subtractions, and depreciation schedules.</span>
              </li>
            </ul>
          </div>

          {/* Double Blind */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <EyeOff className="w-4 h-4 text-[#D4AF37]" />
              <h3>Double-Blind Commit-Reveal Protocol</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Prevents herd mentality, vote copying, and claimant intimidation:
            </p>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-[#D4AF37] font-mono">1.</span>
                <span><strong>Blinded Evidence Packets:</strong> Names, logos, emails, and tax IDs are masked before reviewer dispatch while preserving diagnostic telemetry.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#D4AF37] font-mono">2.</span>
                <span><strong>Commitment Stage:</strong> Reviewers submit <code className="font-mono text-[#D4AF37]">SHA256(report + nonce)</code> before the deadline.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#D4AF37] font-mono">3.</span>
                <span><strong>Reveal Stage:</strong> Nonces are published after commitments close. An escrow recovery policy prevents non-reveal gridlock.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Moral Hazard Hypothesis Table */}
      <section className="space-y-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37]">
            03. Incentive Engineering
          </span>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Multi-Party Moral Hazard & Adverse Incentives Matrix
          </h2>
          <p className="text-xs text-slate-400">
            Moral hazard is an empirical hypothesis to measure and counter, not a problem automatically solved by staking or blockchain.
          </p>
        </div>

        <div className="overflow-x-auto border border-white/[0.08] rounded-lg">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#161A22] text-slate-400 font-mono text-[11px] border-b border-white/[0.08]">
              <tr>
                <th className="py-3 px-4">Stakeholder</th>
                <th className="py-3 px-4">Adverse Incentive / Moral Hazard</th>
                <th className="py-3 px-4">RhinoMutual Counter-Mechanism</th>
                <th className="py-3 px-4">Observable Metric</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05]">
              <tr className="hover:bg-white/[0.02]">
                <td className="py-3 px-4 font-semibold text-white">Claimant</td>
                <td className="py-3 px-4 text-slate-400">Exaggerating loss, inflating repair invoices, submitting pre-existing damage.</td>
                <td className="py-3 px-4">Pre-coverage registration proof, Track A serial forensic check, direct repairer disbursement.</td>
                <td className="py-3 px-4 font-mono text-emerald-400">Fraud Paid &lt; 2.5%</td>
              </tr>
              <tr className="hover:bg-white/[0.02]">
                <td className="py-3 px-4 font-semibold text-white">Validator</td>
                <td className="py-3 px-4 text-slate-400">Rubber-stamping to harvest fees quickly, colluding with friendly claimants.</td>
                <td className="py-3 px-4">Fixed fee (€180) independent of verdict, bonded stake at risk for demonstrable fraud, random audits.</td>
                <td className="py-3 px-4 font-mono text-emerald-400">Collusion Loss &lt; 1.0%</td>
              </tr>
              <tr className="hover:bg-white/[0.02]">
                <td className="py-3 px-4 font-semibold text-white">Pool Operator</td>
                <td className="py-3 px-4 text-slate-400">Suppressing payouts to artificially preserve reserves or maximize fee take.</td>
                <td className="py-3 px-4">Operator cannot vote on claims; transparent double-entry reserves and independent appeal escalation.</td>
                <td className="py-3 px-4 font-mono text-emerald-400">Legit Denied &lt; 3.0%</td>
              </tr>
              <tr className="hover:bg-white/[0.02]">
                <td className="py-3 px-4 font-semibold text-white">Repair Facility</td>
                <td className="py-3 px-4 text-slate-400">Inflating spare parts pricing or replacing undamaged sub-assemblies.</td>
                <td className="py-3 px-4">Track A quote cross-check against OEM parts catalogs; salvage core return credits.</td>
                <td className="py-3 px-4 font-mono text-emerald-400">Salvage Recovery €4.2k+</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
