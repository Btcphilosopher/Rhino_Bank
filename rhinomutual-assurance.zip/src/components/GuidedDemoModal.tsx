/**
 * RhinoMutual Interactive Guided Walkthrough Modal
 * Demonstrates the 8-Stage Lifecycle from Pool Membership to Cryptographic Audit
 * Developed by Aureom.AI
 */

import React, { useState } from 'react';
import { 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  ShieldCheck, 
  FileText, 
  EyeOff, 
  Users, 
  Lock, 
  Scale, 
  Database, 
  X,
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface GuidedTourProps {
  isOpen: boolean;
  onClose: () => void;
  onJumpToTab: (tab: string) => void;
}

export const GuidedDemoModal: React.FC<GuidedTourProps> = ({
  isOpen,
  onClose,
  onJumpToTab,
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const steps = [
    {
      title: '1. Join Pool & Activate Fictional Coverage',
      tab: 'overview',
      persona: 'member',
      badge: 'Policy Administration',
      summary: 'Member joins the Advanced Manufacturing & Precision Robotics Pool (POOL-MFG-01). Policy Terms v1.2 are locked with an immutable SHA-256 wording hash: 4f882a1762...',
      details: [
        'Contractual terms: €1,500 deductible, €150k maximum coverage, 30-day waiting period.',
        'Policy terms are pinned to claims so future amendments never change existing coverage.',
        'Zero speculative token requirement: pool reserves are held in real EUR/USD bank accounts.',
      ],
      actionLabel: 'Inspect Trust Model',
    },
    {
      title: '2. Register Commercial Business Equipment',
      tab: 'member',
      persona: 'member',
      badge: 'Equipment Registry',
      summary: 'Member registers a DMG MORI 5-Axis CNC Milling Center (€145,000 value, Serial: DMG-2024-X9942B). An immutable registration hash is minted.',
      details: [
        'Straight-line 15% annual depreciation schedule attached.',
        'Pre-coverage inspection and serial hash recorded to prevent retroactive post-accident claims.',
        'Only equipment registered prior to an incident is eligible under pool rules.',
      ],
      actionLabel: 'View Member Equipment',
    },
    {
      title: '3. Submit Claim & Privacy-Preserving Redaction',
      tab: 'member',
      persona: 'member',
      badge: 'Privacy Gateway',
      summary: 'Electrical surge damages spindle drive. Claimant submits incident log and technician repair estimate (€26,400).',
      details: [
        'Automated PII scrubbing redacts company names, emails, and tax IDs before reviewer dispatch.',
        'Diagnostic telemetry, error codes, and serial plaque markings are preserved.',
        'Notice displayed warning that idiosyncratic backgrounds may still reveal identity indirectly.',
      ],
      actionLabel: 'Inspect Claims Intake',
    },
    {
      title: '4. Assign Independent Blinded Validators',
      tab: 'validator',
      persona: 'validator',
      badge: 'Validator Network',
      summary: 'Screening engine checks conflict lists. Assigns Apex Forensic Engineering (Track A) and LexActuarial (Track B).',
      details: [
        'Strict 15% concentration cap prevents any single validator from dominating assignments.',
        'Reviewers receive fixed compensation (€180) regardless of accept/deny verdict.',
        'Bonded stake (€75k) is at risk only for demonstrable bad-faith misconduct, never for honest disagreement.',
      ],
      actionLabel: 'View Staked Validators',
    },
    {
      title: '5. Double-Blind Commit-Reveal Submission',
      tab: 'validator',
      persona: 'validator',
      badge: 'Commit-Reveal Protocol',
      summary: 'Reviewers submit SHA-256 hash commitments H(assessment + secret_nonce) before the deadline to prevent vote copying.',
      details: [
        'After commitment window closes, secret nonces are revealed.',
        'The platform verifies that revealed assessments match initial commitments byte-for-byte.',
        'Encrypted reveal escrow ensures non-reveal timeouts do not penalize the claimant.',
      ],
      actionLabel: 'Test Commit-Reveal',
    },
    {
      title: '6. Two-Track Adjudication & Reconciliation',
      tab: 'adjudication',
      persona: 'adjudicator',
      badge: 'Human Adjudication',
      summary: 'Adjudicator compares Track A (Forensics) with Track B (Contractual Coverage) side-by-side.',
      details: [
        'Track A confirms: telemetry timestamps match spindle surge; quote is authentic.',
        'Track B confirms: covered peril under §4.1; applies €1,500 deductible and €2,400 depreciation.',
        'Adjudicator authorizes €21,300 net settlement direct to certified DMG MORI repair facility.',
      ],
      actionLabel: 'View 2-Track Reconciliation',
    },
    {
      title: '7. Appeals Escalation & Senior Arbitration',
      tab: 'adjudication',
      persona: 'adjudicator',
      badge: 'Independent Appeals',
      summary: 'If a claimant disputes a valuation deduction (e.g. Dell H100 Server claim CLM-2026-6210), they lodge a formal appeal.',
      details: [
        'Escalated to an entirely independent Senior Arbitration Panel with zero prior involvement.',
        'Senior Arbitrator Dame Patricia Moore reviews Section 6.4 AI accelerator rider.',
        'Revised settlement is legally recorded with reasoned deliberation notes.',
      ],
      actionLabel: 'Inspect Appeals Panel',
    },
    {
      title: '8. Double-Entry Ledger Block & ZK Audit',
      tab: 'ledger',
      persona: 'auditor',
      badge: 'Audit & Compliance',
      summary: 'Double-entry settlement block #1043 mined on the append-only ledger with cryptographic SHA-256 hash chains.',
      details: [
        'Auditor verifies hash continuity across all blocks with zero tampering.',
        'Zero-Knowledge adapter verifies member credential possession without revealing private PII.',
        'Year-end surplus allocation calculator returns up to 70% rebate to claims-free pool members.',
      ],
      actionLabel: 'Verify Ledger & ZK Proof',
    },
  ];

  const currentStepData = steps[currentStep];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleJump = () => {
    onJumpToTab(currentStepData.tab);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#11141A] border border-white/[0.14] rounded-xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Step Indicator */}
        <div className="flex items-center justify-between border-b border-white/[0.08] pb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase text-[#D4AF37] font-bold">
              {currentStepData.badge}
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-xs font-mono text-slate-400">
              Step {currentStep + 1} of {steps.length}
            </span>
          </div>
          <span className="text-xs font-mono capitalize px-2 py-0.5 rounded bg-[#1D232D] text-slate-300">
            Persona: {currentStepData.persona}
          </span>
        </div>

        {/* Title & Summary */}
        <div className="space-y-3">
          <h3 className="text-xl font-bold text-white tracking-tight">
            {currentStepData.title}
          </h3>
          <p className="text-sm text-slate-300 leading-relaxed">
            {currentStepData.summary}
          </p>
        </div>

        {/* Detailed Points */}
        <div className="bg-[#161B23] border border-white/[0.06] rounded-lg p-4 space-y-2 text-xs">
          <span className="text-slate-400 font-semibold font-mono text-[11px] uppercase block mb-1">
            Mechanism Invariants:
          </span>
          {currentStepData.details.map((point, idx) => (
            <div key={idx} className="flex items-start gap-2 text-slate-300 leading-relaxed">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
              <span>{point}</span>
            </div>
          ))}
        </div>

        {/* Step Navigation Controls */}
        <div className="flex items-center justify-between pt-2 border-t border-white/[0.08]">
          <button
            onClick={handlePrev}
            disabled={currentStep === 0}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              currentStep === 0
                ? 'text-slate-600 cursor-not-allowed'
                : 'text-slate-300 hover:text-white bg-[#1D232D] cursor-pointer'
            }`}
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Previous</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={handleJump}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-slate-200 bg-[#1F2633] hover:bg-[#29313E] border border-white/[0.08] rounded transition-colors cursor-pointer"
            >
              <span>{currentStepData.actionLabel}</span>
              <ExternalLink className="w-3 h-3 text-[#D4AF37]" />
            </button>

            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-black bg-[#D4AF37] hover:bg-[#E5C058] rounded transition-colors shadow-sm cursor-pointer"
            >
              <span>{currentStep === steps.length - 1 ? 'Finish Tour' : 'Next Step'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
