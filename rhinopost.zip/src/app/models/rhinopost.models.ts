export type VehicleCategory = 'cargo_bike' | 'bicycle' | 'motorcycle' | 'van' | 'ev_van' | 'truck' | 'specialist';
export type VehicleStatus = 'active' | 'depot' | 'charging' | 'maintenance' | 'offline' | 'delayed' | 'critical';
export type ServiceClass = 'SameDay' | 'NextDay' | 'Standard' | 'Economy' | 'Priority' | 'Timed' | 'Business' | 'Returns' | 'Collections';
export type ParcelStatus = 'unassigned' | 'assigned' | 'in_transit' | 'delivered' | 'failed' | 'collected';
export type StopStatus = 'pending' | 'completed' | 'failed' | 'delayed';
export type RouteStatus = 'unassigned' | 'optimised' | 'active' | 'completed' | 'delayed';
export type AlertSeverity = 'critical' | 'warning' | 'info';

export interface Depot {
  id: string;
  code: string;
  name: string;
  city: string;
  region: string;
  postcode: string;
  lat: number;
  lng: number;
  capacityParcels: number;
  currentParcels: number;
  activeVehicles: number;
  totalVehicles: number;
  status: 'optimal' | 'congested' | 'high_load';
  manager: string;
}

export interface VehicleType {
  id: string;
  name: string;
  category: VehicleCategory;
  capacityKg: number;
  volumeM3: number;
  maxRangeKm: number;
  batteryCapacityKwh: number;
  co2PerKmGrams: number;
}

export interface Driver {
  id: string;
  code: string;
  name: string;
  phone: string;
  depotId: string;
  licenseType: string;
  rating: number;
  status: 'active' | 'break' | 'offline' | 'overtime';
  hoursWorkedToday: number;
  assignedVehicleId?: string;
}

export interface Vehicle {
  id: string;
  code: string;
  driverId: string;
  driverName: string;
  vehicleTypeId: string;
  vehicleTypeName: string;
  category: VehicleCategory;
  isEv: boolean;
  batteryPct: number;
  fuelPct: number;
  cargoUtilisationPct: number;
  currentLat: number;
  currentLng: number;
  speedKmH: number;
  status: VehicleStatus;
  depotId: string;
  routeId?: string;
  completedStops: number;
  totalStops: number;
  remainingKm: number;
  etaDepot: string;
  faultAlert?: string;
  onTimeProbability: number;
  heading: number;
}

export interface Parcel {
  trackingId: string;
  serviceClass: ServiceClass;
  senderName: string;
  recipientName: string;
  destinationAddress: string;
  postcode: string;
  lat: number;
  lng: number;
  deliveryWindow: string;
  weightKg: number;
  volumeM3: number;
  priorityLevel: number; // 1 (low) to 5 (urgent)
  signatureRequired: boolean;
  specialInstructions?: string;
  status: ParcelStatus;
  estimatedDurationMins: number;
  assignedRouteId?: string;
  assignedVehicleId?: string;
  depotId: string;
}

export interface Stop {
  id: string;
  stopNumber: number;
  parcelIds: string[];
  type: 'delivery' | 'collection' | 'depot_reload' | 'ev_charge';
  address: string;
  postcode: string;
  lat: number;
  lng: number;
  deliveryWindow: string;
  expectedTime: string;
  actualTime?: string;
  serviceDurationSecs: number;
  status: StopStatus;
  distanceToNextKm: number;
  customerName: string;
  priority: number;
  isLocked?: boolean;
}

export interface Route {
  id: string;
  routeCode: string;
  depotId: string;
  vehicleId: string;
  vehicleCode: string;
  driverId: string;
  driverName: string;
  stops: Stop[];
  totalDistanceKm: number;
  totalDurationMins: number;
  etaCompletion: string;
  status: RouteStatus;
  co2EmissionsKg: number;
  operatingCostGbp: number;
  slaPerformancePct: number;
  isLocked?: boolean;
  colorHex: string;
  currentStopIndex: number;
}

export type OptimisationMode = 
  | 'MINIMUM_COST'
  | 'MINIMUM_DISTANCE'
  | 'FASTEST_DELIVERY'
  | 'MAXIMUM_ON_TIME'
  | 'MINIMUM_CO2'
  | 'BALANCED';

export interface OptimisationWeights {
  distanceWeight: number;
  timeWeight: number;
  driverCostWeight: number;
  energyCostWeight: number;
  vehicleCostWeight: number;
  latePenaltyWeight: number;
  failedPenaltyWeight: number;
  overtimePenaltyWeight: number;
  capacityPenaltyWeight: number;
  priorityPenaltyWeight: number;
}

export interface OptimisationProfile {
  mode: OptimisationMode;
  weights: OptimisationWeights;
  enableCvrp: boolean;
  enableVrptw: boolean;
  enableEvConstraints: boolean;
  enablePickupDelivery: boolean;
  enableMultiTrip: boolean;
}

export interface Scenario {
  id: string;
  title: string;
  description: string;
  vehicleDeltaPct: number;
  parcelVolumeDeltaPct: number;
  closedDepotId?: string;
  evVanAddedCount: number;
  roadClosureLocation?: string;
  trafficMultiplier: number;
  enableSundayDelivery: boolean;
  windowExpansionMinutes: number;
  results?: ScenarioResults;
}

export interface ScenarioResults {
  baselineVehicles: number;
  scenarioVehicles: number;
  baselineDistanceKm: number;
  scenarioDistanceKm: number;
  baselineCostGbp: number;
  scenarioCostGbp: number;
  baselineSlaPct: number;
  scenarioSlaPct: number;
  baselineCo2Tonnes: number;
  scenarioCo2Tonnes: number;
}

export interface Alert {
  id: string;
  timestamp: string;
  severity: AlertSeverity;
  title: string;
  description: string;
  routeId?: string;
  vehicleId?: string;
  depotId?: string;
  acknowledged: boolean;
}

export interface OperationalEvent {
  id: string;
  timestamp: string;
  vehicleCode?: string;
  routeCode?: string;
  type: 'info' | 'reoptimised' | 'congestion' | 'priority' | 'alert' | 'disruption';
  message: string;
}

export interface PostcodeSector {
  sector: string;
  city: string;
  lat: number;
  lng: number;
  parcelCount: number;
  densityPerKm2: number;
  avgStopDurationSec: number;
  failedRatePct: number;
  trafficDelayMins: number;
}

export interface TelemetryData {
  vehicleId: string;
  timestamp: string;
  gpsLat: number;
  gpsLng: number;
  speedKmH: number;
  accelerationMs2: number;
  brakingHardCount: number;
  odometerKm: number;
  batterySocPct: number;
  fuelLevelPct: number;
  engineTempC: number;
  idleTimeMins: number;
  chargingStatus: 'discharging' | 'charging_slow' | 'charging_fast' | 'idle';
  predictedArrivalBatteryPct: number;
}

export interface ReoptimisationNotice {
  id: string;
  vehicleCode: string;
  routeId: string;
  reason: string;
  affectedStopsCount: number;
  previousEta: string;
  newEta: string;
  distanceDeltaKm: number;
  timeDeltaMins: number;
  slaBreached: boolean;
  timestamp: string;
}
