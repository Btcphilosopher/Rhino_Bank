import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header';
import { SidebarComponent, NavTab } from './components/sidebar/sidebar';
import { CommandCenterComponent } from './components/command-center/command-center';
import { DisruptionModalComponent } from './components/disruption-modal/disruption-modal';
import { FleetViewComponent } from './components/fleet-view/fleet-view';
import { RoutesViewComponent } from './components/routes-view/routes-view';
import { DeliverySequenceComponent } from './components/delivery-sequence/delivery-sequence';
import { DeliveriesViewComponent } from './components/deliveries-view/deliveries-view';
import { DepotsViewComponent } from './components/depots-view/depots-view';
import { OptimisationConfigComponent } from './components/optimisation-config/optimisation-config';
import { ScenariosViewComponent } from './components/scenarios-view/scenarios-view';
import { AnalyticsViewComponent } from './components/analytics-view/analytics-view';
import { AlertsViewComponent } from './components/alerts-view/alerts-view';
import { DigitalTwinComponent } from './components/digital-twin/digital-twin';
import { DriverAppComponent } from './components/driver-app/driver-app';
import { PostcodeHeatmapComponent } from './components/postcode-heatmap/postcode-heatmap';
import { ExecutiveRoomComponent } from './components/executive-room/executive-room';
import { AdminViewComponent } from './components/admin-view/admin-view';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    SidebarComponent,
    CommandCenterComponent,
    DisruptionModalComponent,
    FleetViewComponent,
    RoutesViewComponent,
    DeliverySequenceComponent,
    DeliveriesViewComponent,
    DepotsViewComponent,
    OptimisationConfigComponent,
    ScenariosViewComponent,
    AnalyticsViewComponent,
    AlertsViewComponent,
    DigitalTwinComponent,
    DriverAppComponent,
    PostcodeHeatmapComponent,
    ExecutiveRoomComponent,
    AdminViewComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly activeTab = signal<NavTab>('COMMAND');

  onTabChange(tab: NavTab): void {
    this.activeTab.set(tab);
  }
}
