import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-admin-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">security</mat-icon>
            SYSTEM ADMINISTRATION & ROLE ACCESS (RBAC)
          </h1>
          <p class="text-xs text-slate-400">Enterprise permission management, user roles, & security audit trails</p>
        </div>
      </div>

      <!-- Roles Table -->
      <div class="bg-slate-900/80 rounded-lg border border-slate-800 p-4 space-y-3">
        <div class="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2">
          USER ACCESS ROLES
        </div>

        <div class="space-y-2 text-xs">
          <div class="p-3 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
            <div>
              <span class="font-bold text-cyan-400 block">National Dispatcher</span>
              <span class="text-slate-400 text-[11px]">Full access to live map control, manual route re-solves, & disruption triggers</span>
            </div>
            <span class="text-emerald-400 font-bold bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded text-[10px]">ACTIVE</span>
          </div>

          <div class="p-3 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
            <div>
              <span class="font-bold text-slate-200 block">Fleet & Depot Manager</span>
              <span class="text-slate-400 text-[11px]">Manage vehicle assignments, maintenance schedules, & depot wave capacity</span>
            </div>
            <span class="text-emerald-400 font-bold bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded text-[10px]">ACTIVE</span>
          </div>

          <div class="p-3 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
            <div>
              <span class="font-bold text-slate-200 block">Postal Courier / Driver</span>
              <span class="text-slate-400 text-[11px]">Read-only mobile driver companion view, proof-of-delivery capture, & stop navigation</span>
            </div>
            <span class="text-emerald-400 font-bold bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded text-[10px]">ACTIVE</span>
          </div>
        </div>
      </div>

    </div>
  `
})
export class AdminViewComponent {
}
