import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-fleet-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">local_shipping</mat-icon>
            FLEET COMMAND DASHBOARD
          </h1>
          <p class="text-xs text-slate-400">National vehicle telemetry, EV battery distribution, & driver utilization</p>
        </div>
        <div class="text-xs text-slate-400">
          Total Vehicles: <span class="text-cyan-400 font-bold">1,284 National</span>
        </div>
      </div>

      <!-- Fleet Status Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-xs">
        <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
          <span class="text-slate-500 text-[10px] block">TOTAL FLEET</span>
          <span class="text-slate-100 text-lg font-bold">1,284</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-emerald-900/50">
          <span class="text-emerald-400 text-[10px] block">ACTIVE EN ROUTE</span>
          <span class="text-emerald-300 text-lg font-bold">1,067</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
          <span class="text-slate-400 text-[10px] block">AT DEPOT</span>
          <span class="text-slate-200 text-lg font-bold">143</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-cyan-900/50">
          <span class="text-cyan-400 text-[10px] block">EV CHARGING</span>
          <span class="text-cyan-300 text-lg font-bold">31</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
          <span class="text-slate-500 text-[10px] block">MAINTENANCE</span>
          <span class="text-slate-300 text-lg font-bold">27</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
          <span class="text-slate-500 text-[10px] block">OFFLINE</span>
          <span class="text-slate-400 text-lg font-bold">16</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-amber-900/50">
          <span class="text-amber-400 text-[10px] block">DELAYED</span>
          <span class="text-amber-300 text-lg font-bold">73</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-red-900/50">
          <span class="text-red-400 text-[10px] block">CRITICAL FAULT</span>
          <span class="text-red-300 text-lg font-bold">8</span>
        </div>
      </div>

      <!-- Operational KPI Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div class="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-400 text-[10px]">FLEET UTILISATION</span>
          <div class="text-xl font-bold text-cyan-400">87.2%</div>
          <div class="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mt-2">
            <div class="bg-cyan-400 h-full w-[87.2%]"></div>
          </div>
        </div>

        <div class="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-400 text-[10px]">AVG STOPS / HOUR</span>
          <div class="text-xl font-bold text-emerald-400">18.4 stops/hr</div>
          <span class="text-[10px] text-slate-500">+1.2 vs baseline unoptimised</span>
        </div>

        <div class="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-400 text-[10px]">AVG ROUTE KM</span>
          <div class="text-xl font-bold text-slate-200">68.4 km</div>
          <span class="text-[10px] text-slate-500">-14.2% mileage reduction</span>
        </div>

        <div class="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-400 text-[10px]">EV FLEET PENETRATION</span>
          <div class="text-xl font-bold text-emerald-400">65.0% (325 EVs)</div>
          <span class="text-[10px] text-slate-500">Zero direct emissions</span>
        </div>
      </div>

      <!-- Fleet Roster Table -->
      <div class="bg-slate-900/80 rounded-lg border border-slate-800 p-3 flex-1 flex flex-col space-y-2">
        <div class="flex items-center justify-between pb-2 border-b border-slate-800">
          <span class="font-bold text-slate-200 text-xs">ACTIVE VEHICLE ROSTER (SYNTHETIC SAMPLE)</span>
          <input 
            type="text" 
            placeholder="Search vehicle code or driver..." 
            class="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 w-64"
          />
        </div>

        <div class="overflow-x-auto flex-1">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 text-[10px]">
              <tr>
                <th class="p-2">VEHICLE</th>
                <th class="p-2">DRIVER</th>
                <th class="p-2">TYPE</th>
                <th class="p-2">DEPOT</th>
                <th class="p-2">BATTERY/FUEL</th>
                <th class="p-2">CARGO LOAD</th>
                <th class="p-2">STOPS DONE</th>
                <th class="p-2">ETA DEPOT</th>
                <th class="p-2">STATUS</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (vehicle of twinService.vehicles().slice(0, 15); track vehicle.id) {
                <tr class="hover:bg-slate-800/40 cursor-pointer" (click)="twinService.selectVehicle(vehicle.id)">
                  <td class="p-2 font-bold text-cyan-400">{{ vehicle.code }}</td>
                  <td class="p-2 text-slate-200">{{ vehicle.driverName }}</td>
                  <td class="p-2 text-slate-400">{{ vehicle.vehicleTypeName }}</td>
                  <td class="p-2 text-slate-400">{{ vehicle.depotId }}</td>
                  <td class="p-2 font-bold" [class.text-cyan-400]="vehicle.isEv">{{ vehicle.isEv ? vehicle.batteryPct + '%' : vehicle.fuelPct + '%' }}</td>
                  <td class="p-2 text-slate-200">{{ vehicle.cargoUtilisationPct }}%</td>
                  <td class="p-2 text-emerald-400 font-bold">{{ vehicle.completedStops }} / {{ vehicle.totalStops }}</td>
                  <td class="p-2 text-slate-300">{{ vehicle.etaDepot }}</td>
                  <td class="p-2">
                    <span [class]="vehicle.status === 'active' ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-amber-950 text-amber-300 border-amber-800'" class="px-2 py-0.5 rounded border text-[10px] font-bold">
                      {{ vehicle.status | uppercase }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class FleetViewComponent {
  readonly twinService = inject(DigitalTwinService);
}
