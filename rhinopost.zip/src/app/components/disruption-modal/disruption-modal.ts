import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-disruption-modal',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (twinService.activeDisruptionNotice(); as notice) {
      <div class="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[500] flex items-center justify-center p-4 font-mono select-none">
        <div class="bg-slate-900 border-2 border-amber-500/80 rounded-xl p-5 max-w-lg w-full text-slate-100 shadow-2xl space-y-4 animate-pulse-fast">
          
          <!-- Header -->
          <div class="flex items-center justify-between border-b border-amber-500/30 pb-3">
            <div class="flex items-center space-x-2 text-amber-400 font-bold text-sm">
              <mat-icon class="text-base text-amber-400">warning</mat-icon>
              <span>ROUTE CHANGE DETECTED</span>
            </div>
            <span class="text-[10px] text-amber-300 bg-amber-950 border border-amber-800 px-2 py-0.5 rounded font-bold">
              AUTO-REOPTIMISATION
            </span>
          </div>

          <!-- Notice Grid -->
          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-slate-950/80 p-2.5 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">VEHICLE</span>
              <span class="text-cyan-400 font-bold text-sm">{{ notice.vehicleCode }}</span>
            </div>

            <div class="bg-slate-950/80 p-2.5 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">AFFECTED STOPS</span>
              <span class="text-slate-200 font-bold text-sm">{{ notice.affectedStopsCount }} Stops</span>
            </div>

            <div class="bg-slate-950/80 p-2.5 rounded border border-slate-800 col-span-2">
              <span class="text-slate-500 text-[10px] block">REASON / EVENT</span>
              <span class="text-amber-300 font-bold text-xs">{{ notice.reason }}</span>
            </div>

            <div class="bg-slate-950/80 p-2.5 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">PREVIOUS ETA</span>
              <span class="text-slate-400 line-through text-sm font-bold">{{ notice.previousEta }}</span>
            </div>

            <div class="bg-slate-950/80 p-2.5 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">NEW OPTIMISED ETA</span>
              <span class="text-emerald-400 text-sm font-bold">{{ notice.newEta }}</span>
            </div>
          </div>

          <!-- Impact Summary Box -->
          <div class="bg-slate-950 p-3 rounded border border-slate-800 text-xs space-y-1">
            <div class="text-slate-400 font-bold flex items-center justify-between">
              <span>OPTIMISED ALTERNATIVE</span>
              <span class="text-emerald-400 text-[11px]">NO SLA BREACHES EXPECTED</span>
            </div>
            <div class="text-slate-300 text-[11.5px]">
              +{{ notice.distanceDeltaKm }} km detour | +{{ notice.timeDeltaMins }} minutes total impact. VRP solver re-sequenced 17 pending stops around closure point.
            </div>
          </div>

          <!-- Action Buttons -->
          <div class="flex items-center space-x-2 pt-2">
            <button 
              (click)="twinService.dismissNotice()"
              class="flex-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-2 rounded text-xs transition-all flex items-center justify-center gap-1">
              <mat-icon class="text-sm">check_circle</mat-icon>
              ACCEPT RE-OPTIMISATION
            </button>

            <button 
              (click)="twinService.dismissNotice()"
              class="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-3 py-2 rounded text-xs border border-slate-700 transition-all">
              VIEW ALTERNATIVE
            </button>

            <button 
              (click)="twinService.dismissNotice()"
              class="bg-slate-800 hover:bg-slate-700 text-slate-400 font-semibold px-3 py-2 rounded text-xs border border-slate-700 transition-all">
              MANUAL OVERRIDE
            </button>
          </div>

        </div>
      </div>
    }
  `
})
export class DisruptionModalComponent {
  readonly twinService = inject(DigitalTwinService);
}
