import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-analytics-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">insights</mat-icon>
            EXECUTIVE LOGISTICS ANALYTICS
          </h1>
          <p class="text-xs text-slate-400">National last-mile operational efficiency, cost per parcel, & ESG carbon metrics</p>
        </div>

        <div class="flex items-center space-x-1 bg-slate-900 p-1 rounded border border-slate-800 text-xs">
          <button (click)="timeframe.set('HOURLY')" [class.bg-cyan-500]="timeframe() === 'HOURLY'" [class.text-slate-950]="timeframe() === 'HOURLY'" class="px-2 py-0.5 rounded font-bold transition-all">HOURLY</button>
          <button (click)="timeframe.set('DAILY')" [class.bg-cyan-500]="timeframe() === 'DAILY'" [class.text-slate-950]="timeframe() === 'DAILY'" class="px-2 py-0.5 rounded font-bold transition-all">DAILY</button>
          <button (click)="timeframe.set('WEEKLY')" [class.bg-cyan-500]="timeframe() === 'WEEKLY'" [class.text-slate-950]="timeframe() === 'WEEKLY'" class="px-2 py-0.5 rounded font-bold transition-all">WEEKLY</button>
          <button (click)="timeframe.set('MONTHLY')" [class.bg-cyan-500]="timeframe() === 'MONTHLY'" [class.text-slate-950]="timeframe() === 'MONTHLY'" class="px-2 py-0.5 rounded font-bold transition-all">MONTHLY</button>
        </div>
      </div>

      <!-- Core Operational KPI Cards Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3 text-xs">
        <div class="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">DELIVERIES / DAY</span>
          <span class="text-slate-100 text-xl font-bold">248,920</span>
          <span class="text-[10px] text-emerald-400 block">+4.8% vs last week</span>
        </div>

        <div class="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">COST PER PARCEL</span>
          <span class="text-cyan-400 text-xl font-bold">£1.84</span>
          <span class="text-[10px] text-emerald-400 block">-£0.28 post-VRP optimization</span>
        </div>

        <div class="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">DISTANCE / PARCEL</span>
          <span class="text-slate-100 text-xl font-bold">0.14 km</span>
          <span class="text-[10px] text-emerald-400 block">-18.2% mileage efficiency</span>
        </div>

        <div class="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">FIRST-ATTEMPT SUCCESS</span>
          <span class="text-emerald-400 text-xl font-bold">97.8%</span>
          <span class="text-[10px] text-slate-400 block">Customer window precision</span>
        </div>

        <div class="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">CO2 SAVED TODAY</span>
          <span class="text-emerald-300 text-xl font-bold">38.4 Tonnes</span>
          <span class="text-[10px] text-emerald-400 block">EV route prioritization</span>
        </div>
      </div>

      <!-- Performance Breakdown Panels -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
        
        <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
          <div class="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2 flex items-center justify-between">
            <span>COST & MILEAGE EFFICIENCY METRICS</span>
            <span class="text-cyan-400 text-[10px]">VRP IMPACT</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span class="text-slate-300">Total National Distance Traveled</span>
              <span class="text-cyan-400 font-bold">35,740 km</span>
            </div>
            <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span class="text-slate-300">Total Operating Fleet Cost</span>
              <span class="text-slate-100 font-bold">£79,310</span>
            </div>
            <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span class="text-slate-300">Driver Labor Hours</span>
              <span class="text-slate-100 font-bold">3,840 hrs</span>
            </div>
            <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span class="text-slate-300">EV Energy Consumption</span>
              <span class="text-emerald-400 font-bold">22,400 kWh</span>
            </div>
          </div>
        </div>

        <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
          <div class="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2 flex items-center justify-between">
            <span>SUSTAINABILITY & ESG PERFORMANCE</span>
            <span class="text-emerald-400 text-[10px]">NET-ZERO 2030</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span class="text-slate-300">EV Fleet Penetration Rate</span>
              <span class="text-emerald-400 font-bold">65.0% (325 EVs)</span>
            </div>
            <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span class="text-slate-300">Direct Tailpipe Carbon Saved</span>
              <span class="text-emerald-300 font-bold">38.4 Tonnes CO2e</span>
            </div>
            <div class="flex justify-between items-center bg-slate-950 p-2.5 rounded border border-slate-800">
              <span class="text-slate-300">Noise Pollution Reduction in Urban Centers</span>
              <span class="text-cyan-400 font-bold">-4.2 dB</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class AnalyticsViewComponent {
  readonly timeframe = signal<'HOURLY' | 'DAILY' | 'WEEKLY' | 'MONTHLY'>('DAILY');
}
