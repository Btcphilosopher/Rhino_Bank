import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-optimisation-config',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">tune</mat-icon>
            VRP SOLVER OBJECTIVE FUNCTION TUNER
          </h1>
          <p class="text-xs text-slate-400">Customize optimization weights & constraint penalties for OR-Tools solver</p>
        </div>
        <button 
          (click)="runSolverWithWeights()"
          class="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-4 py-2 rounded text-xs transition-all flex items-center gap-1 shadow-md">
          <mat-icon class="text-sm">play_arrow</mat-icon>
          RUN SOLVER WITH WEIGHTS
        </button>
      </div>

      <!-- Strategy Preset Buttons -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
        <button 
          (click)="applyPreset('balanced')"
          [class]="activePreset() === 'balanced' ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-2.5 rounded-lg border text-left transition-all">
          <span class="block text-slate-200 font-bold">BALANCED</span>
          <span class="text-[10px] text-slate-500">Default National</span>
        </button>

        <button 
          (click)="applyPreset('min_cost')"
          [class]="activePreset() === 'min_cost' ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-2.5 rounded-lg border text-left transition-all">
          <span class="block text-slate-200 font-bold">MIN COST</span>
          <span class="text-[10px] text-slate-500">Max Fuel & Labor Efficiency</span>
        </button>

        <button 
          (click)="applyPreset('max_sla')"
          [class]="activePreset() === 'max_sla' ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-2.5 rounded-lg border text-left transition-all">
          <span class="block text-slate-200 font-bold">MAX SLA</span>
          <span class="text-[10px] text-slate-500">Zero Late Deliveries</span>
        </button>

        <button 
          (click)="applyPreset('min_co2')"
          [class]="activePreset() === 'min_co2' ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-2.5 rounded-lg border text-left transition-all">
          <span class="block text-slate-200 font-bold">MIN CO2</span>
          <span class="text-[10px] text-slate-500">Prioritise EVs & Low Mileage</span>
        </button>

        <button 
          (click)="applyPreset('min_distance')"
          [class]="activePreset() === 'min_distance' ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-2.5 rounded-lg border text-left transition-all">
          <span class="block text-slate-200 font-bold">MIN DISTANCE</span>
          <span class="text-[10px] text-slate-500">Shortest Geo Trajectory</span>
        </button>

        <button 
          (click)="applyPreset('fastest')"
          [class]="activePreset() === 'fastest' ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-2.5 rounded-lg border text-left transition-all">
          <span class="block text-slate-200 font-bold">FASTEST</span>
          <span class="text-[10px] text-slate-500">Min Duration On-Road</span>
        </button>
      </div>

      <!-- Sliders Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        <div class="bg-slate-900/80 rounded-lg border border-slate-800 p-4 space-y-4">
          <div class="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2">
            PRIMARY OPERATIONAL WEIGHTS
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300 font-bold">Distance Weight (w_dist)</span>
                <span class="text-cyan-400 font-bold">{{ wDistance() }}</span>
              </div>
              <input type="range" min="0" max="10" step="0.5" [value]="wDistance()" (input)="wDistance.set(+ $any($event.target).value)" class="w-full accent-cyan-500" />
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300 font-bold">Travel Time Weight (w_time)</span>
                <span class="text-cyan-400 font-bold">{{ wTime() }}</span>
              </div>
              <input type="range" min="0" max="10" step="0.5" [value]="wTime()" (input)="wTime.set(+ $any($event.target).value)" class="w-full accent-cyan-500" />
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300 font-bold">Driver Wage Cost Weight (w_driver)</span>
                <span class="text-cyan-400 font-bold">{{ wDriver() }}</span>
              </div>
              <input type="range" min="0" max="10" step="0.5" [value]="wDriver()" (input)="wDriver.set(+ $any($event.target).value)" class="w-full accent-cyan-500" />
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-300 font-bold">Energy / Fuel Cost Weight (w_energy)</span>
                <span class="text-cyan-400 font-bold">{{ wEnergy() }}</span>
              </div>
              <input type="range" min="0" max="10" step="0.5" [value]="wEnergy()" (input)="wEnergy.set(+ $any($event.target).value)" class="w-full accent-cyan-500" />
            </div>
          </div>
        </div>

        <div class="bg-slate-900/80 rounded-lg border border-slate-800 p-4 space-y-4">
          <div class="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2">
            HARD CONSTRAINT PENALTY WEIGHTS
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-amber-400 font-bold">Late Delivery SLA Penalty</span>
                <span class="text-amber-300 font-bold">{{ wLate() }}</span>
              </div>
              <input type="range" min="1" max="20" step="1" [value]="wLate()" (input)="wLate.set(+ $any($event.target).value)" class="w-full accent-amber-500" />
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-amber-400 font-bold">Capacity Overload Penalty</span>
                <span class="text-amber-300 font-bold">{{ wCap() }}</span>
              </div>
              <input type="range" min="1" max="20" step="1" [value]="wCap()" (input)="wCap.set(+ $any($event.target).value)" class="w-full accent-amber-500" />
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-emerald-400 font-bold">Priority Medical / Timed Bonus</span>
                <span class="text-emerald-300 font-bold">{{ wPrio() }}</span>
              </div>
              <input type="range" min="1" max="10" step="1" [value]="wPrio()" (input)="wPrio.set(+ $any($event.target).value)" class="w-full accent-emerald-500" />
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class OptimisationConfigComponent {
  readonly twinService = inject(DigitalTwinService);

  readonly activePreset = signal<string>('balanced');

  readonly wDistance = signal(1.0);
  readonly wTime = signal(1.2);
  readonly wDriver = signal(1.0);
  readonly wEnergy = signal(0.8);
  readonly wLate = signal(8);
  readonly wCap = signal(10);
  readonly wPrio = signal(3);

  applyPreset(preset: string): void {
    this.activePreset.set(preset);
    if (preset === 'min_cost') {
      this.wDistance.set(2.0);
      this.wTime.set(0.8);
      this.wDriver.set(2.0);
      this.wEnergy.set(1.5);
    } else if (preset === 'max_sla') {
      this.wLate.set(20);
      this.wTime.set(2.0);
      this.wPrio.set(8);
    } else if (preset === 'min_co2') {
      this.wEnergy.set(2.5);
      this.wDistance.set(1.8);
    } else {
      this.wDistance.set(1.0);
      this.wTime.set(1.2);
      this.wDriver.set(1.0);
      this.wEnergy.set(0.8);
    }
  }

  runSolverWithWeights(): void {
    this.twinService.triggerDisruption('traffic_surge');
  }
}
