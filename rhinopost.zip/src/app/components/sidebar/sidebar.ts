import { ChangeDetectionStrategy, Component, output, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

export type NavTab = 
  | 'COMMAND'
  | 'FLEET'
  | 'ROUTES'
  | 'DELIVERIES'
  | 'DEPOTS'
  | 'PARCELS'
  | 'MAP'
  | 'OPTIMISATION'
  | 'SCENARIOS'
  | 'ANALYTICS'
  | 'ALERTS'
  | 'DIGITAL TWIN'
  | 'DRIVER APP'
  | 'ADMIN';

interface NavItem {
  id: NavTab;
  label: string;
  icon: string;
  badge?: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="w-56 bg-slate-950 border-r border-slate-800/80 flex flex-col h-[calc(100vh-3.5rem)] text-slate-300 font-mono text-xs select-none z-20 shrink-0">
      <div class="px-3 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-900">
        Navigation
      </div>

      <nav class="flex-1 overflow-y-auto p-1.5 space-y-0.5">
        @for (item of NAV_ITEMS; track item.id) {
          <button
            (click)="activeTabChange.emit(item.id)"
            [class]="activeTab() === item.id 
              ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40 font-bold' 
              : 'hover:bg-slate-900/80 text-slate-400 hover:text-slate-200 border-transparent'"
            class="w-full flex items-center justify-between px-3 py-2 rounded-md border text-left text-[11px] transition-all group">
            
            <div class="flex items-center space-x-2.5">
              <mat-icon [class]="activeTab() === item.id ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-300'" class="text-base transition-colors">
                {{ item.icon }}
              </mat-icon>
              <span class="tracking-wider">{{ item.label }}</span>
            </div>

            @if (item.badge) {
              <span class="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {{ item.badge }}
              </span>
            }
          </button>
        }
      </nav>

      <!-- Bottom System Indicator -->
      <div class="p-3 border-t border-slate-900 bg-slate-950/80 text-[10px] text-slate-500">
        <div class="flex items-center justify-between font-mono mb-1">
          <span>VRP SOLVER</span>
          <span class="text-emerald-400 font-bold">READY</span>
        </div>
        <div class="flex items-center justify-between font-mono">
          <span>LATENCY</span>
          <span class="text-slate-400">14ms</span>
        </div>
      </div>
    </aside>
  `
})
export class SidebarComponent {
  readonly activeTab = input<NavTab>('COMMAND');
  readonly activeTabChange = output<NavTab>();

  readonly NAV_ITEMS: NavItem[] = [
    { id: 'COMMAND', label: 'COMMAND', icon: 'dashboard' },
    { id: 'FLEET', label: 'FLEET', icon: 'local_shipping', badge: '500' },
    { id: 'ROUTES', label: 'ROUTES', icon: 'alt_route', badge: '438' },
    { id: 'DELIVERIES', label: 'DELIVERIES', icon: 'inventory_2' },
    { id: 'DEPOTS', label: 'DEPOTS', icon: 'warehouse', badge: '10' },
    { id: 'PARCELS', label: 'PARCELS', icon: 'local_post_office' },
    { id: 'MAP', label: 'POSTCODE GIS', icon: 'map' },
    { id: 'OPTIMISATION', label: 'OPTIMISATION', icon: 'tune' },
    { id: 'SCENARIOS', label: 'WHAT-IF SIM', icon: 'science' },
    { id: 'ANALYTICS', label: 'ANALYTICS', icon: 'insights' },
    { id: 'ALERTS', label: 'ALERTS', icon: 'notifications_active' },
    { id: 'DIGITAL TWIN', label: 'DIGITAL TWIN', icon: 'hub' },
    { id: 'DRIVER APP', label: 'DRIVER APP', icon: 'smartphone' },
    { id: 'ADMIN', label: 'EXECUTIVE', icon: 'admin_panel_settings' }
  ];
}
