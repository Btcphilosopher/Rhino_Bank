import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-deliveries-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">inventory_2</mat-icon>
            PARCEL & DELIVERY INTELLIGENCE
          </h1>
          <p class="text-xs text-slate-400">Real-time parcel status, service classes, weight/volume constraints, & customer windows</p>
        </div>
        <div class="text-xs text-slate-400">
          Parcels Loaded Today: <span class="text-cyan-400 font-bold">24,820 National</span>
        </div>
      </div>

      <!-- Parcel KPI Cards -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
          <span class="text-slate-500 text-[10px] block">TOTAL PARCELS</span>
          <span class="text-slate-100 text-lg font-bold">24,820</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-emerald-900/50">
          <span class="text-emerald-400 text-[10px] block">DELIVERED</span>
          <span class="text-emerald-300 text-lg font-bold">14,280 (57.5%)</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-cyan-900/50">
          <span class="text-cyan-400 text-[10px] block">IN TRANSIT</span>
          <span class="text-cyan-300 text-lg font-bold">9,840</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-amber-900/50">
          <span class="text-amber-400 text-[10px] block">PENDING / DELAYED</span>
          <span class="text-amber-300 text-lg font-bold">700</span>
        </div>
      </div>

      <!-- Parcel Roster Table -->
      <div class="bg-slate-900/80 rounded-lg border border-slate-800 p-3 flex-1 flex flex-col space-y-2">
        <div class="flex items-center justify-between pb-2 border-b border-slate-800">
          <span class="font-bold text-slate-200 text-xs">NATIONAL PARCEL LOG (SAMPLE)</span>
          <input 
            type="text" 
            placeholder="Filter by Tracking ID, Postcode..." 
            class="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 w-64"
          />
        </div>

        <div class="overflow-x-auto flex-1">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 text-[10px]">
              <tr>
                <th class="p-2">TRACKING ID</th>
                <th class="p-2">SERVICE CLASS</th>
                <th class="p-2">RECIPIENT</th>
                <th class="p-2">POSTCODE</th>
                <th class="p-2">WEIGHT / VOL</th>
                <th class="p-2">WINDOW</th>
                <th class="p-2">ROUTE ID</th>
                <th class="p-2">STATUS</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (route of twinService.routes().slice(0, 10); track route.id) {
                @for (stop of route.stops.slice(1, 4); track stop.id) {
                  <tr class="hover:bg-slate-800/40">
                    <td class="p-2 font-bold text-cyan-400">RP{{ stop.id.replace('stop-v-', '100') }}</td>
                    <td class="p-2">
                      <span class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 text-[10px]">
                        {{ stop.priority >= 4 ? 'NextDay Priority' : 'Standard Delivery' }}
                      </span>
                    </td>
                    <td class="p-2 text-slate-200">{{ stop.customerName }}</td>
                    <td class="p-2 text-slate-300 font-bold">{{ stop.postcode }}</td>
                    <td class="p-2 text-slate-400">2.4 kg | 0.02 m³</td>
                    <td class="p-2 text-slate-300">{{ stop.deliveryWindow }}</td>
                    <td class="p-2 text-cyan-300 font-bold">{{ route.routeCode }}</td>
                    <td class="p-2">
                      <span [class]="stop.status === 'completed' ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-cyan-950 text-cyan-300 border-cyan-800'" class="px-2 py-0.5 rounded border text-[10px] font-bold">
                        {{ stop.status === 'completed' ? 'DELIVERED' : 'IN TRANSIT' }}
                      </span>
                    </td>
                  </tr>
                }
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class DeliveriesViewComponent {
  readonly twinService = inject(DigitalTwinService);
}
