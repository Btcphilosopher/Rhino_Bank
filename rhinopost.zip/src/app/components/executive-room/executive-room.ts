import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-executive-room',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">admin_panel_settings</mat-icon>
            EXECUTIVE NATIONAL CONTROL ROOM
          </h1>
          <p class="text-xs text-slate-400">High-density UK operational control room & multi-tier network drill-down</p>
        </div>
      </div>

      <!-- National Macro KPIs Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">TOTAL NATIONAL DELIVERIES</span>
          <span class="text-slate-100 text-xl font-bold">8,492,221</span>
          <span class="text-[10px] text-emerald-400 block">+6.2% YOY Surge</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">ACTIVE NATIONAL FLEET</span>
          <span class="text-cyan-400 text-xl font-bold">18,421 Vans</span>
          <span class="text-[10px] text-slate-400 block">65% EV Fleet Ratio</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">AVG COST / PARCEL</span>
          <span class="text-emerald-400 text-xl font-bold">£1.84</span>
          <span class="text-[10px] text-emerald-400 block">-£0.28 vs 2025</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">NATIONAL SLA ON-TIME</span>
          <span class="text-emerald-400 text-xl font-bold">96.8%</span>
          <span class="text-[10px] text-slate-400 block">Target: 95.0%</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-500 text-[10px] block">CO2 SAVINGS YTD</span>
          <span class="text-emerald-300 text-xl font-bold">14,280 Tonnes</span>
          <span class="text-[10px] text-emerald-400 block">Net-Zero Pathway</span>
        </div>
      </div>

      <!-- Hierarchical Drill-Down Breadcrumb Explorer -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
        <div class="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2">
          HIERARCHICAL OPERATIONAL DRILL-DOWN BREADCRUMB
        </div>

        <div class="flex items-center space-x-2 text-xs font-bold overflow-x-auto py-1">
          <span class="px-2.5 py-1 rounded bg-cyan-500 text-slate-950">UK NATIONAL</span>
          <mat-icon class="text-slate-600 text-sm">chevron_right</mat-icon>
          <span class="px-2.5 py-1 rounded bg-slate-800 text-cyan-300 border border-slate-700">GREATER LONDON REGION</span>
          <mat-icon class="text-slate-600 text-sm">chevron_right</mat-icon>
          <span class="px-2.5 py-1 rounded bg-slate-800 text-cyan-300 border border-slate-700">LONDON CENTRAL DEPOT</span>
          <mat-icon class="text-slate-600 text-sm">chevron_right</mat-icon>
          <span class="px-2.5 py-1 rounded bg-slate-800 text-cyan-300 border border-slate-700">ROUTE LDN-1042</span>
          <mat-icon class="text-slate-600 text-sm">chevron_right</mat-icon>
          <span class="px-2.5 py-1 rounded bg-slate-800 text-emerald-300 border border-slate-700">VEHICLE RP-1042</span>
        </div>
      </div>

    </div>
  `
})
export class ExecutiveRoomComponent {
}
