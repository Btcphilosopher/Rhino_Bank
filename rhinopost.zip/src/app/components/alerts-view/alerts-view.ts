import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-alerts-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">notifications_active</mat-icon>
            OPERATIONAL ALERTS & INCIDENT CENTRE
          </h1>
          <p class="text-xs text-slate-400">Real-time road closures, vehicle fault telemetry, & SLA risk management</p>
        </div>
      </div>

      <!-- Alerts List -->
      <div class="bg-slate-900/80 rounded-lg border border-slate-800 p-4 flex-1 space-y-3">
        <div class="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2">
          ACTIVE NETWORK ALERTS
        </div>

        <div class="space-y-2">
          @for (alert of twinService.alerts(); track alert.id) {
            <div 
              [class]="alert.severity === 'critical' ? 'bg-red-950/30 border-red-800/80' : alert.severity === 'warning' ? 'bg-amber-950/30 border-amber-800/80' : 'bg-slate-950 border-slate-800'"
              class="p-3.5 rounded-lg border text-xs flex items-start justify-between">
              
              <div class="flex items-start space-x-3">
                <mat-icon [class]="alert.severity === 'critical' ? 'text-red-400' : alert.severity === 'warning' ? 'text-amber-400' : 'text-cyan-400'" class="text-base mt-0.5">
                  {{ alert.severity === 'critical' ? 'error' : 'warning' }}
                </mat-icon>

                <div>
                  <div class="font-bold text-slate-100 flex items-center gap-2">
                    <span>{{ alert.title }}</span>
                    <span [class]="alert.severity === 'critical' ? 'bg-red-950 text-red-300 border-red-800' : 'bg-amber-950 text-amber-300 border-amber-800'" class="text-[9px] px-1.5 py-0.2 rounded border font-bold">
                      {{ alert.severity | uppercase }}
                    </span>
                  </div>
                  <div class="text-slate-300 text-[11.5px] mt-1">{{ alert.description }}</div>
                  <div class="text-[10px] text-slate-500 mt-1">Logged at: {{ alert.timestamp }}</div>
                </div>
              </div>

              <button 
                (click)="twinService.triggerDisruption('road_closure')"
                class="px-3 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all">
                TRIGGER RE-SOLVE
              </button>
            </div>
          }
        </div>
      </div>

    </div>
  `
})
export class AlertsViewComponent {
  readonly twinService = inject(DigitalTwinService);
}
