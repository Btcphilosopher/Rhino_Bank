import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-depots-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">warehouse</mat-icon>
            UK NATIONAL MAIL CENTRES & DEPOTS
          </h1>
          <p class="text-xs text-slate-400">10 Primary sorting hubs & regional delivery depot capacities</p>
        </div>
      </div>

      <!-- Depots Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        @for (depot of twinService.depots(); track depot.id) {
          <div class="bg-slate-900/90 rounded-lg border border-slate-800 p-4 space-y-3 hover:border-slate-700 transition-all">
            <div class="flex items-start justify-between border-b border-slate-800 pb-2">
              <div>
                <span class="text-cyan-400 font-bold text-sm block">{{ depot.name }}</span>
                <span class="text-slate-400 text-[11px]">{{ depot.city }}, {{ depot.region }} ({{ depot.postcode }})</span>
              </div>
              <span [class]="depot.status === 'optimal' ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-amber-950 text-amber-300 border-amber-800'" class="px-2 py-0.5 rounded border text-[10px] font-bold">
                {{ depot.status | uppercase }}
              </span>
            </div>

            <!-- Capacity Progress -->
            <div class="space-y-1">
              <div class="flex justify-between text-[11px]">
                <span class="text-slate-400">Sorting Capacity</span>
                <span class="text-slate-200 font-bold">{{ depot.currentParcels }} / {{ depot.capacityParcels }} Parcels</span>
              </div>
              <div class="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div [class]="(depot.currentParcels / depot.capacityParcels) > 0.85 ? 'bg-amber-400' : 'bg-cyan-400'" class="h-full transition-all" [style.width.%]="(depot.currentParcels / depot.capacityParcels) * 100"></div>
              </div>
            </div>

            <!-- Fleet Info -->
            <div class="grid grid-cols-2 gap-2 text-[11px] pt-1">
              <div class="bg-slate-950 p-2 rounded border border-slate-800">
                <span class="text-slate-500 text-[9px] block">ACTIVE FLEET</span>
                <span class="text-slate-200 font-bold text-xs">{{ depot.activeVehicles }} / {{ depot.totalVehicles }} Vans</span>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-800">
                <span class="text-slate-500 text-[9px] block">DEPOT MANAGER</span>
                <span class="text-slate-300 font-bold text-xs truncate block">{{ depot.manager }}</span>
              </div>
            </div>
          </div>
        }
      </div>

    </div>
  `
})
export class DepotsViewComponent {
  readonly twinService = inject(DigitalTwinService);
}
