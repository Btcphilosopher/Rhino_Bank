import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';
import { NavTab } from '../sidebar/sidebar';

@Component({
  selector: 'app-routes-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">alt_route</mat-icon>
            ACTIVE OPTIMISED ROUTES
          </h1>
          <p class="text-xs text-slate-400">VRP Solved route sequences, SLA predictions & operating costs</p>
        </div>
        <div class="flex items-center space-x-2">
          <button 
            (click)="twinService.triggerDisruption('traffic_surge')"
            class="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-3 py-1.5 rounded text-xs transition-all flex items-center gap-1">
            <mat-icon class="text-sm">sync</mat-icon>
            RE-OPTIMISE ALL ROUTES
          </button>
        </div>
      </div>

      <!-- KPI Summary -->
      <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
        <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
          <span class="text-slate-500 text-[10px] block">TOTAL ROUTES ACTIVE</span>
          <span class="text-slate-100 text-lg font-bold">438 Routes</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
          <span class="text-slate-500 text-[10px] block">TOTAL DISTANCE</span>
          <span class="text-cyan-400 text-lg font-bold">35,740 km</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
          <span class="text-slate-500 text-[10px] block">OPERATING COST</span>
          <span class="text-slate-200 text-lg font-bold">£79,310</span>
        </div>
        <div class="bg-slate-900/90 p-3 rounded-lg border border-emerald-900/50">
          <span class="text-emerald-400 text-[10px] block">AVERAGE SLA ON-TIME</span>
          <span class="text-emerald-300 text-lg font-bold">96.7%</span>
        </div>
      </div>

      <!-- Route Table -->
      <div class="bg-slate-900/80 rounded-lg border border-slate-800 p-3 flex-1 flex flex-col space-y-2">
        <div class="overflow-x-auto flex-1">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 text-[10px]">
              <tr>
                <th class="p-2">ROUTE CODE</th>
                <th class="p-2">VEHICLE</th>
                <th class="p-2">DRIVER</th>
                <th class="p-2">STOPS</th>
                <th class="p-2">DISTANCE</th>
                <th class="p-2">ETA COMPLETION</th>
                <th class="p-2">SLA %</th>
                <th class="p-2">COST</th>
                <th class="p-2">STATUS</th>
                <th class="p-2 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (route of twinService.routes().slice(0, 18); track route.id) {
                <tr class="hover:bg-slate-800/40">
                  <td class="p-2 font-bold text-cyan-400">{{ route.routeCode }}</td>
                  <td class="p-2 text-slate-200">{{ route.vehicleCode }}</td>
                  <td class="p-2 text-slate-300">{{ route.driverName }}</td>
                  <td class="p-2 font-bold text-emerald-400">{{ route.stops.length }} Stops</td>
                  <td class="p-2 text-slate-300">{{ route.totalDistanceKm }} km</td>
                  <td class="p-2 text-slate-200 font-bold">{{ route.etaCompletion }}</td>
                  <td class="p-2 font-bold" [class.text-emerald-400]="route.slaPerformancePct >= 90" [class.text-amber-400]="route.slaPerformancePct < 90">
                    {{ route.slaPerformancePct }}%
                  </td>
                  <td class="p-2 text-slate-300">£{{ route.operatingCostGbp }}</td>
                  <td class="p-2">
                    <span [class]="route.status === 'active' ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-amber-950 text-amber-300 border-amber-800'" class="px-2 py-0.5 rounded border text-[10px] font-bold">
                      {{ route.status | uppercase }}
                    </span>
                  </td>
                  <td class="p-2 text-right space-x-1">
                    <button 
                      (click)="openSequence(route.id)"
                      class="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[10px] font-bold">
                      SEQUENCE
                    </button>
                    <button 
                      (click)="twinService.triggerDisruption('road_closure')"
                      class="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold">
                      RE-SOLVE
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class RoutesViewComponent {
  readonly twinService = inject(DigitalTwinService);
  readonly navTabChange = output<NavTab>();

  openSequence(routeId: string): void {
    this.twinService.selectRoute(routeId);
    this.navTabChange.emit('DELIVERIES');
  }
}
