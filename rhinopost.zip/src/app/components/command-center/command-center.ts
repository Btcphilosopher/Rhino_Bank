import { 
  ChangeDetectionStrategy, Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, inject, signal 
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-command-center',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 overflow-hidden text-slate-100 relative">
      
      <!-- Top Operational Metrics Bar -->
      <div class="h-11 bg-slate-900/90 border-b border-slate-800/80 px-4 flex items-center justify-between text-xs font-mono select-none shrink-0 z-10">
        <div class="flex items-center space-x-6">
          <div class="flex items-center space-x-2">
            <span class="text-slate-400">VEHICLES ACTIVE:</span>
            <span class="text-cyan-400 font-bold text-sm">{{ twinService.activeVehiclesCount() }} / 500</span>
          </div>
          <div class="flex items-center space-x-2">
            <span class="text-slate-400">DELAYED:</span>
            <span class="text-amber-400 font-bold text-sm">{{ twinService.delayedVehiclesCount() }}</span>
          </div>
          <div class="flex items-center space-x-2">
            <span class="text-slate-400">SLA ON-TIME:</span>
            <span class="text-emerald-400 font-bold text-sm">96.8%</span>
          </div>
          <div class="flex items-center space-x-2 hidden xl:flex">
            <span class="text-slate-400">AVG COST/PARCEL:</span>
            <span class="text-slate-200 font-bold text-sm">£1.84</span>
          </div>
        </div>

        <!-- Layer Toggles -->
        <div class="flex items-center space-x-1.5">
          <button 
            (click)="toggleLayer('vehicles')"
            [class]="showVehicles() ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-slate-800 text-slate-400 border-slate-700'"
            class="px-2 py-0.5 rounded border text-[11px] font-semibold flex items-center gap-1">
            <mat-icon class="text-xs">directions_car</mat-icon> Vehicles
          </button>
          <button 
            (click)="toggleLayer('routes')"
            [class]="showRoutes() ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-slate-800 text-slate-400 border-slate-700'"
            class="px-2 py-0.5 rounded border text-[11px] font-semibold flex items-center gap-1">
            <mat-icon class="text-xs">route</mat-icon> Routes
          </button>
          <button 
            (click)="toggleLayer('depots')"
            [class]="showDepots() ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-slate-800 text-slate-400 border-slate-700'"
            class="px-2 py-0.5 rounded border text-[11px] font-semibold flex items-center gap-1">
            <mat-icon class="text-xs">warehouse</mat-icon> Depots
          </button>
          <button 
            (click)="toggleLayer('traffic')"
            [class]="showTraffic() ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-slate-800 text-slate-400 border-slate-700'"
            class="px-2 py-0.5 rounded border text-[11px] font-semibold flex items-center gap-1">
            <mat-icon class="text-xs">traffic</mat-icon> Traffic
          </button>
        </div>
      </div>

      <!-- Main Section: Map + Right Panel -->
      <div class="flex-1 flex overflow-hidden relative">
        
        <!-- Live GIS Map Container -->
        <div class="flex-1 h-full w-full bg-slate-950 relative dark-map-tiles" #mapContainer>
          
          <!-- Floating Map Control Legend Overlay -->
          <div class="absolute top-3 left-3 z-[400] bg-slate-950/90 border border-slate-800 backdrop-blur-md rounded-lg p-2.5 text-[11px] font-mono text-slate-300 space-y-1.5 shadow-xl max-w-xs">
            <div class="font-bold text-slate-200 border-b border-slate-800 pb-1 flex items-center justify-between">
              <span>RHINOPOST GIS MAP</span>
              <span class="text-[9px] text-emerald-400 bg-emerald-950 border border-emerald-800 px-1 rounded">LIVE</span>
            </div>
            <div class="flex items-center space-x-2">
              <div class="w-2.5 h-2.5 rounded-full bg-cyan-400"></div>
              <span>Active Vehicles (438)</span>
            </div>
            <div class="flex items-center space-x-2">
              <div class="w-2.5 h-2.5 rounded-full bg-amber-400"></div>
              <span>Delayed Vehicles (18)</span>
            </div>
            <div class="flex items-center space-x-2">
              <div class="w-2.5 h-2.5 rounded-full bg-purple-400"></div>
              <span>Depots / Mail Hubs (10)</span>
            </div>
            <div class="flex items-center space-x-2">
              <div class="w-3 h-0.5 bg-cyan-500"></div>
              <span>Optimised Route Sequence</span>
            </div>
          </div>
        </div>

        <!-- Right Side: Vehicle & Route Readout Intelligence Panel -->
        <div class="w-80 lg:w-96 bg-slate-950 border-l border-slate-800/80 flex flex-col h-full font-mono text-xs overflow-y-auto shrink-0 z-10 select-none">
          
          @if (twinService.selectedVehicle(); as vehicle) {
            <!-- Vehicle Header -->
            <div class="p-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
              <div>
                <div class="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                  <mat-icon class="text-sm">directions_car</mat-icon>
                  <span>VEHICLE {{ vehicle.code }}</span>
                  <span [class]="vehicle.isEv ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-slate-800 text-slate-300 border-slate-700'" class="text-[9px] px-1.5 py-0.2 rounded border font-bold">
                    {{ vehicle.isEv ? 'EV VAN' : 'DIESEL' }}
                  </span>
                </div>
                <div class="text-[10px] text-slate-400 mt-0.5">Driver: {{ vehicle.driverName }}</div>
              </div>
              <span [class]="vehicle.status === 'active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border-amber-500/40'" class="px-2 py-0.5 rounded border text-[10px] font-bold">
                {{ vehicle.status | uppercase }}
              </span>
            </div>

            <!-- Vehicle Telemetry Readout Grid -->
            <div class="p-3 space-y-3 border-b border-slate-900">
              <div class="grid grid-cols-2 gap-2 text-[11px]">
                <div class="bg-slate-900/70 p-2 rounded border border-slate-800">
                  <span class="text-slate-500 block text-[9px]">SPEED</span>
                  <span class="text-slate-200 font-bold text-sm">{{ vehicle.speedKmH }} km/h</span>
                </div>
                <div class="bg-slate-900/70 p-2 rounded border border-slate-800">
                  <span class="text-slate-500 block text-[9px]">ON-TIME PROB.</span>
                  <span class="text-emerald-400 font-bold text-sm">{{ vehicle.onTimeProbability }}%</span>
                </div>
                <div class="bg-slate-900/70 p-2 rounded border border-slate-800">
                  <span class="text-slate-500 block text-[9px]">BATTERY / FUEL</span>
                  <span class="text-cyan-300 font-bold text-sm">{{ vehicle.isEv ? vehicle.batteryPct + '%' : vehicle.fuelPct + '%' }}</span>
                </div>
                <div class="bg-slate-900/70 p-2 rounded border border-slate-800">
                  <span class="text-slate-500 block text-[9px]">CARGO LOAD</span>
                  <span class="text-slate-200 font-bold text-sm">{{ vehicle.cargoUtilisationPct }}%</span>
                </div>
              </div>

              <!-- Progress Bar: Stops Completed -->
              <div class="bg-slate-900/80 p-2.5 rounded border border-slate-800 space-y-1.5">
                <div class="flex justify-between text-[11px]">
                  <span class="text-slate-400">Route Progress</span>
                  <span class="text-cyan-400 font-bold">{{ vehicle.completedStops }} / {{ vehicle.totalStops }} Stops</span>
                </div>
                <div class="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                  <div class="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full transition-all duration-500" [style.width.%]="(vehicle.completedStops / vehicle.totalStops) * 100"></div>
                </div>
                <div class="flex justify-between text-[10px] text-slate-500">
                  <span>Remaining: {{ vehicle.remainingKm }} km</span>
                  <span>ETA Depot: {{ vehicle.etaDepot }}</span>
                </div>
              </div>
            </div>

            <!-- Active Route Stop Sequence -->
            @if (twinService.selectedRoute(); as route) {
              <div class="flex-1 flex flex-col p-3 overflow-y-auto">
                <div class="font-bold text-slate-300 mb-2 flex items-center justify-between">
                  <span>DELIVERY SEQUENCE ({{ route.stops.length }} STOPS)</span>
                  <span class="text-[10px] text-cyan-400">{{ route.routeCode }}</span>
                </div>

                <div class="space-y-1.5">
                  @for (stop of route.stops; track stop.id) {
                    <div 
                      [class]="stop.status === 'completed' ? 'opacity-60 bg-slate-900/40 border-slate-800/50' : stop.status === 'delayed' ? 'bg-amber-950/30 border-amber-800/60' : 'bg-slate-900/80 border-slate-800'"
                      class="p-2 rounded border text-[11px] flex items-start justify-between">
                      <div class="flex items-start space-x-2">
                        <span class="w-5 h-5 rounded bg-slate-800 text-slate-300 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                          {{ stop.stopNumber }}
                        </span>
                        <div>
                          <div class="font-bold text-slate-200">{{ stop.customerName }}</div>
                          <div class="text-[10px] text-slate-400 truncate max-w-[180px]">{{ stop.address }}</div>
                          <div class="text-[9px] text-slate-500 mt-0.5">Window: {{ stop.deliveryWindow }}</div>
                        </div>
                      </div>

                      <div class="text-right">
                        <span class="text-[10px] font-bold text-slate-300 block">{{ stop.expectedTime }}</span>
                        <span [class]="stop.status === 'completed' ? 'text-emerald-400' : stop.status === 'delayed' ? 'text-amber-400' : 'text-cyan-400'" class="text-[9px] font-semibold">
                          {{ stop.status | uppercase }}
                        </span>
                      </div>
                    </div>
                  }
                </div>
              </div>
            }
          } @else {
            <div class="p-6 text-center text-slate-500 my-auto">
              <mat-icon class="text-3xl mb-2">touch_app</mat-icon>
              <div>Select a vehicle on the map to view live readout & route sequence.</div>
            </div>
          }
        </div>
      </div>

      <!-- Bottom Operational Event Stream Ticker -->
      <div class="h-20 bg-slate-950 border-t border-slate-800/80 px-3 py-1.5 font-mono text-[11px] shrink-0 z-10 flex flex-col justify-between">
        <div class="flex items-center justify-between text-[10px] text-slate-500 font-bold border-b border-slate-900 pb-1">
          <span class="flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            LIVE OPERATIONAL EVENT STREAM
          </span>
          <span>AUTOSCROLL ON</span>
        </div>

        <div class="flex-1 overflow-y-auto space-y-1 mt-1 text-slate-300">
          @for (log of twinService.eventLogs().slice(0, 4); track log.id) {
            <div class="flex items-center space-x-3 text-[10.5px]">
              <span class="text-slate-500 font-mono">{{ log.timestamp }}</span>
              @if (log.vehicleCode) {
                <span class="text-cyan-400 font-bold bg-cyan-950 px-1 rounded border border-cyan-800/60">{{ log.vehicleCode }}</span>
              }
              <span [class]="log.type === 'disruption' ? 'text-red-300 font-bold' : log.type === 'reoptimised' ? 'text-amber-300' : 'text-slate-300'">
                {{ log.message }}
              </span>
            </div>
          }
        </div>
      </div>

    </div>
  `
})
export class CommandCenterComponent implements AfterViewInit, OnDestroy {
  @ViewChild('mapContainer', { static: true }) mapContainer!: ElementRef<HTMLDivElement>;

  readonly twinService = inject(DigitalTwinService);

  readonly showVehicles = signal(true);
  readonly showRoutes = signal(true);
  readonly showDepots = signal(true);
  readonly showTraffic = signal(false);

  private map: unknown = null;
  private markersMap = new Map<string, unknown>();
  private polylineMap = new Map<string, unknown>();

  toggleLayer(layer: 'vehicles' | 'routes' | 'depots' | 'traffic'): void {
    if (layer === 'vehicles') this.showVehicles.update(v => !v);
    if (layer === 'routes') this.showRoutes.update(r => !r);
    if (layer === 'depots') this.showDepots.update(d => !d);
    if (layer === 'traffic') this.showTraffic.update(t => !t);

    this.renderMapItems();
  }

  ngAfterViewInit(): void {
    if (typeof window !== 'undefined' && window.L) {
      this.initLeafletMap();
    }
  }

  ngOnDestroy(): void {
    if (this.map) {
      (this.map as { remove: () => void }).remove();
    }
  }

  private initLeafletMap(): void {
    const L = window.L;
    // Center on UK National Center (Birmingham / Midlands)
    this.map = L.map(this.mapContainer.nativeElement, {
      center: [52.4862, -1.8904],
      zoom: 7,
      zoomControl: false
    });

    L.control.zoom({ position: 'bottomleft' }).addTo(this.map);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      attribution: '&copy; RHINOPOST GIS'
    }).addTo(this.map);

    this.renderMapItems();
  }

  private renderMapItems(): void {
    if (!this.map || typeof window === 'undefined' || !window.L) return;
    const L = window.L;

    // Clear existing
    this.markersMap.forEach(m => (this.map as { removeLayer: (layer: unknown) => void })?.removeLayer(m));
    this.polylineMap.forEach(p => (this.map as { removeLayer: (layer: unknown) => void })?.removeLayer(p));
    this.markersMap.clear();
    this.polylineMap.clear();

    // Render Depots
    if (this.showDepots()) {
      this.twinService.depots().forEach(depot => {
        const depotIcon = L.divIcon({
          className: 'depot-marker',
          html: `<div style="background:#8b5cf6; width:18px; height:18px; border-radius:4px; border:2px solid #fff; box-shadow:0 0 10px rgba(139,92,246,0.8); display:flex; align-items:center; justify-content:center; color:#fff; font-size:10px; font-weight:bold;">D</div>`,
          iconSize: [18, 18]
        });

        const marker = L.marker([depot.lat, depot.lng], { icon: depotIcon })
          .bindPopup(`<b>${depot.name}</b><br/>Capacity: ${depot.currentParcels} / ${depot.capacityParcels}<br/>Active Vehicles: ${depot.activeVehicles}`)
          .addTo(this.map);

        this.markersMap.set(depot.id, marker);
      });
    }

    // Render Vehicles & Routes
    const vehiclesList = this.twinService.vehicles().slice(0, 80); // Scaled map subset for silky performance
    vehiclesList.forEach(vehicle => {
      if (this.showVehicles()) {
        const isDelayed = vehicle.status === 'delayed' || vehicle.status === 'critical';
        const color = isDelayed ? '#f59e0b' : '#06b6d4';

        const vehicleIcon = L.divIcon({
          className: 'vehicle-marker',
          html: `<div style="background:${color}; width:14px; height:14px; border-radius:50%; border:2px solid #fff; box-shadow:0 0 8px ${color};"></div>`,
          iconSize: [14, 14]
        });

        const marker = L.marker([vehicle.currentLat, vehicle.currentLng], { icon: vehicleIcon })
          .addTo(this.map);

        (marker as { on: (event: string, fn: () => void) => void }).on('click', () => {
          this.twinService.selectVehicle(vehicle.id);
        });

        this.markersMap.set(vehicle.id, marker);
      }

      // Render Route Polylines
      if (this.showRoutes() && vehicle.routeId) {
        const route = this.twinService.routes().find(r => r.id === vehicle.routeId);
        if (route && route.stops.length > 1) {
          const latLngs: [number, number][] = route.stops.map(s => [s.lat, s.lng]);
          const polyline = L.polyline(latLngs, {
            color: route.colorHex || '#06b6d4',
            weight: 2.5,
            opacity: 0.7
          }).addTo(this.map);

          this.polylineMap.set(route.id, polyline);
        }
      }
    });
  }
}
