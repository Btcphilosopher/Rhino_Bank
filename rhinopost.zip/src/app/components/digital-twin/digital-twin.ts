import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-digital-twin',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">hub</mat-icon>
            DIGITAL TWIN SIMULATION ENGINE
          </h1>
          <p class="text-xs text-slate-400">Full-network digital twin state manager, telemetry generator, & event stream controller</p>
        </div>
      </div>

      <!-- Simulation Clock Controls -->
      <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
        <div class="flex items-center space-x-4">
          <div class="text-2xl font-bold font-mono text-cyan-400">{{ twinService.currentTime() }}</div>
          <span [class]="twinService.isRunning() ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-amber-950 text-amber-300 border-amber-800'" class="px-2.5 py-1 rounded border text-xs font-bold">
            {{ twinService.isRunning() ? 'SIMULATION RUNNING' : 'PAUSED' }}
          </span>
        </div>

        <div class="flex items-center space-x-2">
          <button 
            (click)="twinService.toggleSimulation()"
            [class]="twinService.isRunning() ? 'bg-amber-500 hover:bg-amber-400 text-slate-950' : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'"
            class="px-4 py-2 rounded text-xs font-bold transition-all flex items-center gap-1">
            <mat-icon class="text-sm">{{ twinService.isRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
            {{ twinService.isRunning() ? 'PAUSE SIMULATION' : 'RESUME SIMULATION' }}
          </button>
        </div>
      </div>

      <!-- Disruption Generator Grid -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
        <div class="font-bold text-slate-200 text-xs border-b border-slate-800 pb-2">
          INJECT OPERATIONAL DISRUPTIONS
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button 
            (click)="twinService.triggerDisruption('road_closure')"
            class="bg-slate-950 hover:bg-red-950/40 border border-slate-800 hover:border-red-800 p-3 rounded-lg text-left transition-all space-y-1">
            <div class="font-bold text-red-400 text-xs flex items-center gap-1">
              <mat-icon class="text-sm">block</mat-icon>
              ROAD CLOSURE DISRUPTION
            </div>
            <div class="text-[10px] text-slate-400">Simulate major A-road closure affecting active routes</div>
          </button>

          <button 
            (click)="twinService.triggerDisruption('breakdown')"
            class="bg-slate-950 hover:bg-amber-950/40 border border-slate-800 hover:border-amber-800 p-3 rounded-lg text-left transition-all space-y-1">
            <div class="font-bold text-amber-400 text-xs flex items-center gap-1">
              <mat-icon class="text-sm">build</mat-icon>
              VEHICLE BREAKDOWN
            </div>
            <div class="text-[10px] text-slate-400">Simulate engine failure requiring parcel re-assignment</div>
          </button>

          <button 
            (click)="twinService.triggerDisruption('traffic_surge')"
            class="bg-slate-950 hover:bg-cyan-950/40 border border-slate-800 hover:border-cyan-800 p-3 rounded-lg text-left transition-all space-y-1">
            <div class="font-bold text-cyan-400 text-xs flex items-center gap-1">
              <mat-icon class="text-sm">traffic</mat-icon>
              URBAN TRAFFIC SURGE
            </div>
            <div class="text-[10px] text-slate-400">Simulate London & Birmingham congestion +25%</div>
          </button>
        </div>
      </div>

    </div>
  `
})
export class DigitalTwinComponent {
  readonly twinService = inject(DigitalTwinService);
}
