import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-postcode-heatmap',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">map</mat-icon>
            UK POSTCODE DENSITY & HEATMAP INTELLIGENCE
          </h1>
          <p class="text-xs text-slate-400">Geographic parcel demand density, stop duration profiling, & failed delivery heatmaps</p>
        </div>
      </div>

      <!-- Sector Density Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        @for (sec of POSTCODE_SECTORS; track sec.sector) {
          <div class="bg-slate-900/90 rounded-lg border border-slate-800 p-4 space-y-3">
            <div class="flex justify-between items-center border-b border-slate-800 pb-2">
              <span class="text-cyan-400 font-bold text-sm">SECTOR {{ sec.sector }}</span>
              <span class="text-xs text-slate-400 font-bold">{{ sec.city }}</span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs">
              <div class="bg-slate-950 p-2 rounded border border-slate-800">
                <span class="text-slate-500 text-[9px] block">PARCEL DEMAND</span>
                <span class="text-slate-100 font-bold text-xs">{{ sec.parcelCount }} Parcels</span>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-800">
                <span class="text-slate-500 text-[9px] block">DENSITY / KM²</span>
                <span class="text-cyan-400 font-bold text-xs">{{ sec.density }} / km²</span>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-800">
                <span class="text-slate-500 text-[9px] block">AVG STOP DURATION</span>
                <span class="text-slate-200 font-bold text-xs">{{ sec.avgSecs }}s</span>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-800">
                <span class="text-slate-500 text-[9px] block">TRAFFIC DELAY</span>
                <span class="text-amber-400 font-bold text-xs">+{{ sec.trafficDelay }} mins</span>
              </div>
            </div>
          </div>
        }
      </div>

    </div>
  `
})
export class PostcodeHeatmapComponent {
  readonly POSTCODE_SECTORS = [
    { sector: 'EC1A 1A', city: 'London Central', parcelCount: 1420, density: 640, avgSecs: 210, trafficDelay: 12 },
    { sector: 'CR0 2E', city: 'Croydon', parcelCount: 980, density: 420, avgSecs: 180, trafficDelay: 6 },
    { sector: 'B1 1A', city: 'Birmingham', parcelCount: 1250, density: 510, avgSecs: 240, trafficDelay: 14 },
    { sector: 'M1 2W', city: 'Manchester', parcelCount: 1180, density: 480, avgSecs: 195, trafficDelay: 8 },
    { sector: 'LS1 4D', city: 'Leeds', parcelCount: 890, density: 390, avgSecs: 175, trafficDelay: 5 },
    { sector: 'BS1 3A', city: 'Bristol', parcelCount: 840, density: 360, avgSecs: 160, trafficDelay: 4 }
  ];
}
