import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';
import { OptimisationSolverService } from '../../services/optimisation-solver.service';

@Component({
  selector: 'app-delivery-sequence',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">format_list_numbered</mat-icon>
            ROUTE STOP SEQUENCE EDITOR
          </h1>
          <p class="text-xs text-slate-400">Detailed delivery sequence inspection, time window validation, & manual override</p>
        </div>
        
        <div class="flex items-center space-x-2">
          <button 
            (click)="reoptimiseCurrentSequence()"
            class="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-3 py-1.5 rounded text-xs transition-all flex items-center gap-1">
            <mat-icon class="text-sm">auto_fix_high</mat-icon>
            RUN 2-OPT SEQUENCE OPTIMISER
          </button>
        </div>
      </div>

      <!-- Route Header Readout -->
      @if (twinService.selectedRoute(); as route) {
        <div class="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 flex items-center justify-between text-xs">
          <div class="flex items-center space-x-6">
            <div>
              <span class="text-slate-500 text-[10px] block">ROUTE CODE</span>
              <span class="text-cyan-400 font-bold text-sm">{{ route.routeCode }}</span>
            </div>
            <div>
              <span class="text-slate-500 text-[10px] block">VEHICLE</span>
              <span class="text-slate-200 font-bold text-sm">{{ route.vehicleCode }}</span>
            </div>
            <div>
              <span class="text-slate-500 text-[10px] block">DRIVER</span>
              <span class="text-slate-200 font-bold text-sm">{{ route.driverName }}</span>
            </div>
            <div>
              <span class="text-slate-500 text-[10px] block">TOTAL STOPS</span>
              <span class="text-emerald-400 font-bold text-sm">{{ route.stops.length }} Stops</span>
            </div>
          </div>

          <div class="flex items-center space-x-4">
            <div>
              <span class="text-slate-500 text-[10px] block">ROUTE DISTANCE</span>
              <span class="text-slate-200 font-bold text-sm">{{ route.totalDistanceKm }} km</span>
            </div>
            <div>
              <span class="text-slate-500 text-[10px] block">ESTIMATED COST</span>
              <span class="text-slate-200 font-bold text-sm">£{{ route.operatingCostGbp }}</span>
            </div>
          </div>
        </div>

        <!-- Stop Timeline Sequence List -->
        <div class="bg-slate-900/80 rounded-lg border border-slate-800 p-3 flex-1 overflow-y-auto space-y-2">
          <div class="font-bold text-slate-300 text-xs pb-2 border-b border-slate-800 flex items-center justify-between">
            <span>STOP SEQUENCE (0 = DEPOT ORIGIN)</span>
            <span class="text-[10px] text-slate-500">Click arrow buttons to manually adjust sequence</span>
          </div>

          <div class="space-y-2">
            @for (stop of route.stops; track stop.id; let idx = $index) {
              <div 
                [class]="stop.type === 'depot_reload' ? 'bg-purple-950/40 border-purple-800/80' : stop.status === 'completed' ? 'bg-slate-900/40 border-slate-800/50 opacity-70' : 'bg-slate-950 border-slate-800'"
                class="p-3 rounded-lg border text-xs flex items-center justify-between">
                
                <div class="flex items-center space-x-3">
                  <div class="w-7 h-7 rounded bg-slate-800 text-slate-200 font-bold text-xs flex items-center justify-center shrink-0 border border-slate-700">
                    {{ stop.stopNumber }}
                  </div>

                  <div>
                    <div class="font-bold text-slate-100 flex items-center gap-2">
                      <span>{{ stop.customerName }}</span>
                      @if (stop.priority >= 4) {
                        <span class="text-[9px] bg-red-950 text-red-300 border border-red-800 px-1.5 py-0.2 rounded font-bold">URGENT</span>
                      }
                    </div>
                    <div class="text-slate-400 text-[11px] mt-0.5">{{ stop.address }} ({{ stop.postcode }})</div>
                    <div class="text-[10px] text-slate-500 mt-0.5">
                      Window: {{ stop.deliveryWindow }} | Service Duration: {{ stop.serviceDurationSecs }}s | Dist to Next: {{ stop.distanceToNextKm }} km
                    </div>
                  </div>
                </div>

                <div class="flex items-center space-x-4">
                  <div class="text-right">
                    <span class="text-slate-200 font-bold block">{{ stop.expectedTime }}</span>
                    <span [class]="stop.status === 'completed' ? 'text-emerald-400' : stop.status === 'delayed' ? 'text-amber-400' : 'text-cyan-400'" class="text-[10px] font-bold">
                      {{ stop.status | uppercase }}
                    </span>
                  </div>

                  @if (stop.type !== 'depot_reload') {
                    <div class="flex flex-col space-y-1">
                      <button 
                        (click)="moveStop(route.id, idx, -1)" 
                        [disabled]="idx <= 1"
                        class="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300">
                        <mat-icon class="text-xs">expand_less</mat-icon>
                      </button>
                      <button 
                        (click)="moveStop(route.id, idx, 1)" 
                        [disabled]="idx >= route.stops.length - 1"
                        class="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300">
                        <mat-icon class="text-xs">expand_more</mat-icon>
                      </button>
                    </div>
                  }
                </div>

              </div>
            }
          </div>
        </div>
      } @else {
        <div class="p-8 text-center text-slate-500 my-auto">
          Select a route from the Routes screen to view stop sequence.
        </div>
      }

    </div>
  `
})
export class DeliverySequenceComponent {
  readonly twinService = inject(DigitalTwinService);
  readonly solver = inject(OptimisationSolverService);

  reoptimiseCurrentSequence(): void {
    const route = this.twinService.selectedRoute();
    if (!route) return;

    const depot = this.twinService.depots().find(d => d.id === route.depotId);
    if (!depot) return;

    const optimisedStops = this.solver.optimiseStopSequence(depot, route.stops);

    const updatedRoute = {
      ...route,
      stops: optimisedStops
    };

    this.twinService.routes.update(list => list.map(r => r.id === route.id ? updatedRoute : r));
  }

  moveStop(routeId: string, idx: number, direction: number): void {
    const route = this.twinService.routes().find(r => r.id === routeId);
    if (!route) return;

    const targetIdx = idx + direction;
    if (targetIdx < 1 || targetIdx >= route.stops.length) return;

    const newStops = [...route.stops];
    const temp = newStops[idx];
    newStops[idx] = newStops[targetIdx];
    newStops[targetIdx] = temp;

    // Re-index
    newStops.forEach((s, i) => s.stopNumber = i);

    const updatedRoute = {
      ...route,
      stops: newStops
    };

    this.twinService.routes.update(list => list.map(r => r.id === routeId ? updatedRoute : r));
  }
}
