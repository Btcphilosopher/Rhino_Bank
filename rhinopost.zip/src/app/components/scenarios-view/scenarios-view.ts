import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-scenarios-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono overflow-y-auto text-slate-100 space-y-4">
      
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <mat-icon class="text-cyan-400">science</mat-icon>
            WHAT-IF SCENARIO SIMULATION STUDIO
          </h1>
          <p class="text-xs text-slate-400">Test network resilience, fleet size changes, & disruption impacts side-by-side</p>
        </div>
      </div>

      <!-- Presets Selector Grid -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
        @for (sc of SCENARIOS; track sc.id) {
          <button 
            (click)="selectScenario(sc)"
            [class]="selectedScenario().id === sc.id ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'"
            class="p-3 rounded-lg border text-left transition-all space-y-1">
            <div class="font-bold text-slate-200 text-xs">{{ sc.title }}</div>
            <div class="text-[10px] text-slate-400 leading-tight">{{ sc.description }}</div>
          </button>
        }
      </div>

      <!-- Comparison Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
        
        <!-- Baseline Current State -->
        <div class="bg-slate-900/90 rounded-xl border border-slate-800 p-4 space-y-4">
          <div class="flex justify-between border-b border-slate-800 pb-2">
            <span class="font-bold text-slate-300">CURRENT BASELINE NETWORK</span>
            <span class="text-xs text-slate-500">LIVE DATA</span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">OPERATING VEHICLES</span>
              <span class="text-slate-200 font-bold text-base">500 Vans</span>
            </div>
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">TOTAL DISTANCE</span>
              <span class="text-slate-200 font-bold text-base">42,810 km</span>
            </div>
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">DAILY FLEET COST</span>
              <span class="text-slate-200 font-bold text-base">£98,420</span>
            </div>
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">SLA ON-TIME</span>
              <span class="text-emerald-400 font-bold text-base">88.2%</span>
            </div>
          </div>
        </div>

        <!-- Simulated Scenario Outcome -->
        <div class="bg-slate-900/90 rounded-xl border-2 border-cyan-500/80 p-4 space-y-4">
          <div class="flex justify-between border-b border-cyan-500/30 pb-2">
            <span class="font-bold text-cyan-400">{{ selectedScenario().title | uppercase }}</span>
            <span class="text-xs text-cyan-300 font-bold bg-cyan-950 border border-cyan-800 px-2 py-0.5 rounded">SIMULATED</span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">OPERATING VEHICLES</span>
              <span class="text-cyan-300 font-bold text-base">{{ selectedScenario().simVehicles }} Vans</span>
            </div>
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">SIMULATED DISTANCE</span>
              <span class="text-cyan-300 font-bold text-base">{{ selectedScenario().simDistance }} km</span>
            </div>
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">ESTIMATED COST</span>
              <span class="text-cyan-300 font-bold text-base">£{{ selectedScenario().simCost }}</span>
            </div>
            <div class="bg-slate-950 p-3 rounded border border-slate-800">
              <span class="text-slate-500 text-[10px] block">PROJECTED SLA %</span>
              <span class="text-emerald-400 font-bold text-base">{{ selectedScenario().simSla }}%</span>
            </div>
          </div>

          <div class="bg-slate-950 p-3 rounded border border-slate-800 text-xs">
            <span class="text-slate-400 font-bold block mb-1">OPTIMISATION SUMMARY:</span>
            <p class="text-slate-300 text-[11.5px] leading-relaxed">
              {{ selectedScenario().impactAnalysis }}
            </p>
          </div>
        </div>

      </div>

    </div>
  `
})
export class ScenariosViewComponent {
  readonly SCENARIOS = [
    {
      id: 'sc-1',
      title: 'Remove 50 Fleet Vans',
      description: 'Simulate operating with 10% fewer vehicles',
      simVehicles: 450,
      simDistance: '44,120',
      simCost: '89,200',
      simSla: '86.4',
      impactAnalysis: 'Capacity utilisation increases to 94.2%. Driver labor cost decreases by £9,220/day with a minor 1.8% SLA performance drop.'
    },
    {
      id: 'sc-2',
      title: 'Parcel Volume +20%',
      description: 'Peak season surge (+5,000 parcels)',
      simVehicles: 500,
      simDistance: '49,850',
      simCost: '112,400',
      simSla: '84.1',
      impactAnalysis: 'Fleet requires 2 extra waves from London & Birmingham hubs. Driver overtime required (+1.4 hrs/driver).'
    },
    {
      id: 'sc-3',
      title: 'Close Croydon Depot',
      description: 'Emergency closure of Croydon facility',
      simVehicles: 442,
      simDistance: '51,200',
      simCost: '108,100',
      simSla: '79.8',
      impactAnalysis: 'London Central takes over 18,900 parcels. Deadhead mileage increases by 8.4 km per vehicle.'
    },
    {
      id: 'sc-4',
      title: 'Add 100 Electric Vans',
      description: 'Electrify 100 additional routes',
      simVehicles: 500,
      simDistance: '41,900',
      simCost: '74,300',
      simSla: '94.2',
      impactAnalysis: 'Daily carbon emissions drop by 18.4 tonnes. Fuel savings £24,120/day with optimal fast-charger waypoint routing.'
    }
  ];

  readonly selectedScenario = signal(this.SCENARIOS[0]);

  selectScenario(sc: typeof this.SCENARIOS[0]): void {
    this.selectedScenario.set(sc);
  }
}
