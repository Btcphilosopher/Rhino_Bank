import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-14 bg-slate-950 border-b border-slate-800/80 px-4 flex items-center justify-between text-slate-200 select-none z-30 relative">
      <!-- Left: Logo & National Ops Switcher -->
      <div class="flex items-center space-x-4">
        <div class="flex items-center space-x-2.5 cursor-pointer">
          <div class="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-black tracking-tighter text-lg shadow-sm">
            RP
          </div>
          <div class="flex flex-col">
            <span class="font-bold tracking-widest text-base text-white font-mono leading-none flex items-center gap-1.5">
              RHINOPOST
              <span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 tracking-normal">
                NATIONAL
              </span>
            </span>
            <span class="text-[10px] text-slate-400 font-medium tracking-tight">
              Intelligent Last-Mile Operations System
            </span>
          </div>
        </div>

        <div class="hidden md:flex items-center space-x-2 bg-slate-900/90 border border-slate-800 rounded-md px-2.5 py-1 text-xs">
          <span class="relative flex h-2 w-2">
            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span class="text-slate-300 font-mono text-[11px]">UK NATIONAL NETWORK</span>
          <span class="text-slate-500">|</span>
          <span class="text-slate-400 text-[11px]">10 Depots Active</span>
        </div>
      </div>

      <!-- Center: Simulation Control Bar -->
      <div class="hidden lg:flex items-center space-x-3 bg-slate-900/90 border border-slate-800/90 rounded-lg px-3 py-1 font-mono text-xs">
        <div class="flex items-center space-x-1.5 text-slate-400">
          <mat-icon class="text-sm text-cyan-400">schedule</mat-icon>
          <span class="text-slate-200 font-bold tracking-wider">{{ twinService.currentTime() }}</span>
        </div>

        <div class="h-3.5 w-px bg-slate-800"></div>

        <div class="flex items-center space-x-1">
          <button 
            (click)="twinService.toggleSimulation()"
            [class]="twinService.isRunning() ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'"
            class="px-2 py-0.5 rounded border text-[11px] font-bold flex items-center gap-1 transition-all">
            <mat-icon class="text-xs">{{ twinService.isRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
            {{ twinService.isRunning() ? 'PAUSE' : 'RUN' }}
          </button>

          <button 
            (click)="twinService.setSpeed(1)" 
            [class.bg-cyan-500]="twinService.simulationSpeed() === 1"
            [class.text-slate-950]="twinService.simulationSpeed() === 1"
            class="px-1.5 py-0.5 rounded hover:bg-slate-800 text-[11px] font-semibold transition-all">
            1x
          </button>
          <button 
            (click)="twinService.setSpeed(10)" 
            [class.bg-cyan-500]="twinService.simulationSpeed() === 10"
            [class.text-slate-950]="twinService.simulationSpeed() === 10"
            class="px-1.5 py-0.5 rounded hover:bg-slate-800 text-[11px] font-semibold transition-all">
            10x
          </button>
          <button 
            (click)="twinService.setSpeed(50)" 
            [class.bg-cyan-500]="twinService.simulationSpeed() === 50"
            [class.text-slate-950]="twinService.simulationSpeed() === 50"
            class="px-1.5 py-0.5 rounded hover:bg-slate-800 text-[11px] font-semibold transition-all">
            50x
          </button>
        </div>
      </div>

      <!-- Right: Search, Disruption Trigger, Alerts & User -->
      <div class="flex items-center space-x-3">
        <!-- Quick Disruption Simulator Button -->
        <button 
          (click)="twinService.triggerDisruption('road_closure')"
          class="hidden sm:flex items-center space-x-1 bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-800/80 px-2.5 py-1 rounded-md text-xs font-mono font-medium transition-all shadow-sm">
          <mat-icon class="text-sm text-red-400">warning</mat-icon>
          <span>SIMULATE ROAD CLOSURE</span>
        </button>

        <!-- Alert Counter -->
        <div class="relative cursor-pointer">
          <div class="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white transition-all">
            <mat-icon class="text-base">notifications</mat-icon>
          </div>
          @if (twinService.criticalAlertsCount() > 0) {
            <span class="absolute -top-1 -right-1 bg-red-500 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center border-2 border-slate-950 animate-pulse">
              {{ twinService.criticalAlertsCount() }}
            </span>
          }
        </div>

        <!-- User Profile -->
        <div class="flex items-center space-x-2 pl-2 border-l border-slate-800">
          <div class="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-300 font-bold text-xs flex items-center justify-center">
            CC
          </div>
          <div class="hidden xl:flex flex-col text-left text-xs">
            <span class="font-bold text-slate-200 leading-tight">Control Center</span>
            <span class="text-[10px] text-slate-400">National Dispatcher</span>
          </div>
        </div>
      </div>
    </header>
  `
})
export class HeaderComponent {
  readonly twinService = inject(DigitalTwinService);
}
