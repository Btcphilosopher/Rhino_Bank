import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../services/digital-twin.service';

@Component({
  selector: 'app-driver-app',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex items-center justify-center h-[calc(100vh-3.5rem)] bg-slate-950 p-4 font-mono select-none overflow-y-auto">
      
      <!-- Smartphone Container Frame -->
      <div class="w-[380px] h-[720px] bg-slate-900 border-4 border-slate-700 rounded-[38px] p-4 flex flex-col shadow-2xl relative overflow-hidden text-slate-100">
        
        <!-- Phone Camera Notch Bar -->
        <div class="w-32 h-5 bg-slate-950 rounded-b-xl mx-auto absolute top-0 left-1/2 -translate-x-1/2 z-30 flex items-center justify-center">
          <div class="w-3 h-3 rounded-full bg-slate-800"></div>
        </div>

        <!-- Driver App Header -->
        <div class="pt-5 pb-3 border-b border-slate-800 flex items-center justify-between text-xs font-bold">
          <div class="flex items-center space-x-2">
            <div class="w-7 h-7 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center font-bold text-xs">
              JW
            </div>
            <div>
              <span class="block text-slate-100">James Wilson</span>
              <span class="text-[9px] text-slate-400">Route LDN-1042 | Vehicle RP-1042</span>
            </div>
          </div>

          <span class="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
            ON ROUTE
          </span>
        </div>

        <!-- Current Stop Banner -->
        <div class="my-3 bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
          <div class="flex justify-between items-center text-[11px]">
            <span class="text-cyan-400 font-bold">STOP 12 OF 82</span>
            <span class="text-slate-400 text-[10px]">ETA: 10:42</span>
          </div>

          <div class="text-sm font-bold text-slate-100">Customer #12</div>
          <div class="text-xs text-slate-300">10 High Street, Sector EC1A 1AA</div>
          <div class="text-[10px] text-slate-400">Window: 10:00 - 12:00 | NextDay Parcel</div>

          <button 
            (click)="completeDelivery()"
            class="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-2 rounded-lg text-xs transition-all mt-2 flex items-center justify-center gap-1 shadow-md">
            <mat-icon class="text-sm">check_circle</mat-icon>
            {{ deliveryStatus() === 'delivered' ? 'DELIVERY CONFIRMED!' : 'MARK AS DELIVERED (POD)' }}
          </button>
        </div>

        <!-- Digital Signature Canvas Simulation -->
        <div class="flex-1 bg-slate-950 rounded-xl border border-slate-800 p-3 flex flex-col justify-between space-y-2">
          <div class="flex justify-between text-[10px] text-slate-400 font-bold border-b border-slate-800 pb-1">
            <span>CUSTOMER SIGNATURE</span>
            <button class="text-cyan-400 font-bold hover:underline" (click)="clearSig()">CLEAR</button>
          </div>

          <div class="flex-1 border border-dashed border-slate-800 rounded-lg flex items-center justify-center relative cursor-crosshair">
            <div class="text-xs text-slate-600 font-serif italic select-none">
              {{ sigText() ? 'J. Wilson Signature Recorded' : 'Sign here on touch screen...' }}
            </div>
          </div>

          <div class="flex space-x-2">
            <button 
              (click)="completeDelivery()"
              class="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded text-xs transition-all">
              CAPTURE POD & NEXT
            </button>
          </div>
        </div>

      </div>

    </div>
  `
})
export class DriverAppComponent {
  readonly twinService = inject(DigitalTwinService);

  readonly deliveryStatus = signal<'pending' | 'delivered'>('pending');
  readonly sigText = signal(false);

  completeDelivery(): void {
    this.deliveryStatus.set('delivered');
    this.sigText.set(true);

    const vehicle = this.twinService.selectedVehicle();
    if (vehicle) {
      this.twinService.vehicles.update(list => list.map(v => v.id === vehicle.id ? { ...v, completedStops: v.completedStops + 1 } : v));
    }
  }

  clearSig(): void {
    this.sigText.set(false);
    this.deliveryStatus.set('pending');
  }
}
