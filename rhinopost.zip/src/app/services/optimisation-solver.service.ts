import { Injectable } from '@angular/core';
import { 
  Route, Stop, Vehicle, Depot, OptimisationProfile, ReoptimisationNotice 
} from '../models/rhinopost.models';

@Injectable({
  providedIn: 'root'
})
export class OptimisationSolverService {

  // Calculate Geodesic Distance in Kilometers between two lat/lng points
  calculateHaversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    
    // Multiply by 1.35 urban road network curvature factor
    return parseFloat((R * c * 1.35).toFixed(2));
  }

  // Calculate Weighted Total Cost Score for a Route
  calculateRouteCost(route: Route, profile: OptimisationProfile): {
    totalCost: number;
    distanceCost: number;
    timeCost: number;
    co2Cost: number;
    slaPenalties: number;
  } {
    const w = profile.weights;

    const distanceCost = route.totalDistanceKm * 0.85 * w.distanceWeight;
    const timeCost = (route.totalDurationMins / 60) * 22.5 * w.timeWeight;
    const co2Cost = route.co2EmissionsKg * 0.15 * w.energyCostWeight;
    
    const lateStops = route.stops.filter(s => s.status === 'delayed').length;
    const slaPenalties = lateStops * 45 * w.latePenaltyWeight;

    const totalCost = parseFloat((distanceCost + timeCost + co2Cost + slaPenalties).toFixed(2));

    return {
      totalCost,
      distanceCost: parseFloat(distanceCost.toFixed(2)),
      timeCost: parseFloat(timeCost.toFixed(2)),
      co2Cost: parseFloat(co2Cost.toFixed(2)),
      slaPenalties: parseFloat(slaPenalties.toFixed(2))
    };
  }

  // Nearest-Neighbor + 2-Opt Metaheuristic Sequence Optimizer
  optimiseStopSequence(depot: Depot, stops: Stop[]): Stop[] {
    if (stops.length <= 2) return stops;

    const pendingStops = [...stops];
    const reordered: Stop[] = [];

    // Keep depot or fixed start as first
    const first = pendingStops.shift()!;
    reordered.push(first);

    let currentLat = first.lat;
    let currentLng = first.lng;

    // Greedy Nearest Neighbor
    while (pendingStops.length > 0) {
      let nearestIdx = 0;
      let minDistance = Infinity;

      for (let i = 0; i < pendingStops.length; i++) {
        const s = pendingStops[i];
        let dist = this.calculateHaversineDistance(currentLat, currentLng, s.lat, s.lng);
        
        // Priority weight discount (higher priority = pull closer)
        if (s.priority >= 4) {
          dist *= 0.7;
        }

        if (dist < minDistance) {
          minDistance = dist;
          nearestIdx = i;
        }
      }

      const nextStop = pendingStops.splice(nearestIdx, 1)[0];
      reordered.push(nextStop);
      currentLat = nextStop.lat;
      currentLng = nextStop.lng;
    }

    // 2-Opt Local Search Swap Improvement
    let improved = true;
    let iterations = 0;
    while (improved && iterations < 50) {
      improved = false;
      iterations++;

      for (let i = 1; i < reordered.length - 2; i++) {
        for (let j = i + 1; j < reordered.length - 1; j++) {
          const d1 = this.calculateHaversineDistance(reordered[i-1].lat, reordered[i-1].lng, reordered[i].lat, reordered[i].lng) +
                     this.calculateHaversineDistance(reordered[j].lat, reordered[j].lng, reordered[j+1].lat, reordered[j+1].lng);
          
          const d2 = this.calculateHaversineDistance(reordered[i-1].lat, reordered[i-1].lng, reordered[j].lat, reordered[j].lng) +
                     this.calculateHaversineDistance(reordered[i].lat, reordered[i].lng, reordered[j+1].lat, reordered[j+1].lng);

          if (d2 < d1) {
            // Reverse sub-path between i and j
            const sub = reordered.slice(i, j + 1).reverse();
            reordered.splice(i, sub.length, ...sub);
            improved = true;
          }
        }
      }
    }

    // Re-index stop numbers & calculate distances
    for (let k = 0; k < reordered.length; k++) {
      reordered[k].stopNumber = k;
      if (k < reordered.length - 1) {
        const dNext = this.calculateHaversineDistance(reordered[k].lat, reordered[k].lng, reordered[k+1].lat, reordered[k+1].lng);
        reordered[k].distanceToNextKm = dNext;
      } else {
        reordered[k].distanceToNextKm = this.calculateHaversineDistance(reordered[k].lat, reordered[k].lng, depot.lat, depot.lng);
      }
    }

    return reordered;
  }

  // Dynamic Re-Optimisation on Disruption (Road Closure, Breakdown, Traffic)
  reoptimiseRouteForDisruption(
    route: Route, 
    vehicle: Vehicle, 
    depot: Depot, 
    disruptionType: 'road_closure' | 'breakdown' | 'traffic_surge'
  ): {
    updatedRoute: Route;
    notice: ReoptimisationNotice;
  } {
    const affectedStops = route.stops.filter(s => s.status === 'pending');
    const completedStops = route.stops.filter(s => s.status === 'completed');

    // Apply sequence optimization to remaining pending stops
    const newlyOrderedPending = this.optimiseStopSequence(depot, affectedStops);
    
    // Combine completed and newly ordered pending
    const allStops = [...completedStops, ...newlyOrderedPending];

    // Calculate distance and time delta
    const previousDist = route.totalDistanceKm;
    let newDist = 0;
    for (let i = 0; i < allStops.length; i++) {
      allStops[i].stopNumber = i;
      if (i < allStops.length - 1) {
        newDist += this.calculateHaversineDistance(allStops[i].lat, allStops[i].lng, allStops[i+1].lat, allStops[i+1].lng);
      }
    }

    const distDelta = parseFloat((newDist - previousDist + (disruptionType === 'road_closure' ? 3.4 : 1.8)).toFixed(1));
    const timeDeltaMins = Math.round(distDelta * 2.2 + (disruptionType === 'traffic_surge' ? 12 : 5));

    const [prevHours, prevMins] = route.etaCompletion.split(':').map(Number);
    const totalEtaMins = prevHours * 60 + prevMins + timeDeltaMins;
    const newEtaHours = Math.floor(totalEtaMins / 60) % 24;
    const newEtaMins = totalEtaMins % 60;
    const newEtaStr = `${newEtaHours < 10 ? '0' : ''}${newEtaHours}:${newEtaMins < 10 ? '0' : ''}${newEtaMins}`;

    const updatedRoute: Route = {
      ...route,
      stops: allStops,
      totalDistanceKm: parseFloat((previousDist + distDelta).toFixed(1)),
      totalDurationMins: route.totalDurationMins + timeDeltaMins,
      etaCompletion: newEtaStr,
      status: 'active'
    };

    const notice: ReoptimisationNotice = {
      id: `notice-${Date.now()}`,
      vehicleCode: vehicle.code,
      routeId: route.id,
      reason: disruptionType === 'road_closure' ? 'A1 Northbound Road Closure Bypass' : disruptionType === 'breakdown' ? 'Vehicle Mechanical Fault Re-assignment' : 'Severe Urban Traffic Surge (+25%)',
      affectedStopsCount: affectedStops.length,
      previousEta: route.etaCompletion,
      newEta: newEtaStr,
      distanceDeltaKm: distDelta,
      timeDeltaMins,
      slaBreached: false,
      timestamp: new Date().toLocaleTimeString('en-GB', { hour12: false })
    };

    return { updatedRoute, notice };
  }
}
