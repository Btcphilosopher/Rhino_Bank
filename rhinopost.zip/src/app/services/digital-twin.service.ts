import { Injectable, signal, computed, inject } from '@angular/core';
import { 
  Vehicle, Route, Alert, OperationalEvent, ReoptimisationNotice, Depot 
} from '../models/rhinopost.models';
import { SyntheticDataService } from './synthetic-data.service';
import { OptimisationSolverService } from './optimisation-solver.service';

@Injectable({
  providedIn: 'root'
})
export class DigitalTwinService {

  private syntheticData = inject(SyntheticDataService);
  private solver = inject(OptimisationSolverService);

  // Reactive State Signals
  readonly simulationSpeed = signal<number>(1); // 1, 10, 50
  readonly isRunning = signal<boolean>(true);
  readonly currentTime = signal<string>('12:42:15');

  readonly depots = signal<Depot[]>([]);
  readonly vehicles = signal<Vehicle[]>([]);
  readonly routes = signal<Route[]>([]);
  readonly alerts = signal<Alert[]>([]);
  readonly eventLogs = signal<OperationalEvent[]>([]);

  // Active Disruption Alert Modal Signal
  readonly activeDisruptionNotice = signal<ReoptimisationNotice | null>(null);

  // Selected Vehicle / Route for detail panels
  readonly selectedVehicleId = signal<string | null>(null);
  readonly selectedRouteId = signal<string | null>(null);

  // Derived Signals
  readonly activeVehiclesCount = computed(() => this.vehicles().filter(v => v.status === 'active' || v.status === 'delayed').length);
  readonly delayedVehiclesCount = computed(() => this.vehicles().filter(v => v.status === 'delayed' || v.status === 'critical').length);
  readonly criticalAlertsCount = computed(() => this.alerts().filter(a => a.severity === 'critical' && !a.acknowledged).length);

  readonly selectedVehicle = computed(() => this.vehicles().find(v => v.id === this.selectedVehicleId()));
  readonly selectedRoute = computed(() => this.routes().find(r => r.id === this.selectedRouteId() || r.id === this.selectedVehicle()?.routeId));

  private timerInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.initializeData();
    this.startSimulationLoop();
  }

  initializeData(): void {
    const data = this.syntheticData.generateNationalDataset();
    this.depots.set(data.depots);
    this.vehicles.set(data.vehicles);
    this.routes.set(data.routes);
    this.eventLogs.set(this.syntheticData.getInitialEvents());
    this.alerts.set(this.syntheticData.getInitialAlerts());

    // Default select first vehicle for readout
    if (data.vehicles.length > 0) {
      this.selectedVehicleId.set(data.vehicles[0].id);
      this.selectedRouteId.set(data.vehicles[0].routeId || null);
    }
  }

  setSpeed(speed: number): void {
    this.simulationSpeed.set(speed);
  }

  toggleSimulation(): void {
    this.isRunning.update(r => !r);
  }

  selectVehicle(vehicleId: string): void {
    this.selectedVehicleId.set(vehicleId);
    const v = this.vehicles().find(x => x.id === vehicleId);
    if (v && v.routeId) {
      this.selectedRouteId.set(v.routeId);
    }
  }

  selectRoute(routeId: string): void {
    this.selectedRouteId.set(routeId);
    const r = this.routes().find(x => x.id === routeId);
    if (r) {
      this.selectedVehicleId.set(r.vehicleId);
    }
  }

  dismissNotice(): void {
    this.activeDisruptionNotice.set(null);
  }

  // Inject Operational Disruption Event
  triggerDisruption(type: 'road_closure' | 'breakdown' | 'traffic_surge'): void {
    const activeVehiclesList = this.vehicles().filter(v => v.status === 'active' || v.status === 'delayed');
    if (activeVehiclesList.length === 0) return;

    // Target a specific vehicle/route
    const targetVehicle = activeVehiclesList[Math.floor(Math.random() * activeVehiclesList.length)];
    const targetRoute = this.routes().find(r => r.id === targetVehicle.routeId);
    const targetDepot = this.depots().find(d => d.id === targetVehicle.depotId);

    if (!targetRoute || !targetDepot) return;

    // Run solver re-optimisation
    const { updatedRoute, notice } = this.solver.reoptimiseRouteForDisruption(targetRoute, targetVehicle, targetDepot, type);

    // Update routes state
    this.routes.update(list => list.map(r => r.id === updatedRoute.id ? updatedRoute : r));

    // Update vehicle status
    this.vehicles.update(list => list.map(v => {
      if (v.id === targetVehicle.id) {
        return {
          ...v,
          status: type === 'breakdown' ? 'critical' : 'delayed',
          faultAlert: type === 'breakdown' ? 'Engine Oil Pressure Warning' : undefined,
          remainingKm: updatedRoute.totalDistanceKm - (v.completedStops * 1.1)
        };
      }
      return v;
    }));

    // Add alert
    const newAlert: Alert = {
      id: `alt-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString('en-GB', { hour12: false }),
      severity: type === 'breakdown' ? 'critical' : 'warning',
      title: type === 'breakdown' ? `Vehicle Breakdown: ${targetVehicle.code}` : type === 'road_closure' ? `Road Closure Impacting ${targetVehicle.code}` : `Congestion Surge: Route ${targetRoute.routeCode}`,
      description: notice.reason,
      vehicleId: targetVehicle.id,
      routeId: targetRoute.id,
      acknowledged: false
    };
    this.alerts.update(a => [newAlert, ...a]);

    // Add operational log
    const newLog: OperationalEvent = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString('en-GB', { hour12: false }),
      vehicleCode: targetVehicle.code,
      routeCode: targetRoute.routeCode,
      type: 'disruption',
      message: `DISRUPTION DETECTED: ${notice.reason}. New ETA: ${notice.newEta} (${notice.distanceDeltaKm > 0 ? '+' : ''}${notice.distanceDeltaKm} km).`
    };
    this.eventLogs.update(logs => [newLog, ...logs.slice(0, 40)]);

    // Trigger Re-optimisation notice modal!
    this.activeDisruptionNotice.set(notice);
    this.selectedVehicleId.set(targetVehicle.id);
    this.selectedRouteId.set(targetRoute.id);
  }

  // Simulation Loop Tick
  private startSimulationLoop(): void {
    if (this.timerInterval) clearInterval(this.timerInterval);

    this.timerInterval = setInterval(() => {
      if (!this.isRunning()) return;

      const spd = this.simulationSpeed();
      
      // Update simulation time
      const date = new Date();
      this.currentTime.set(date.toLocaleTimeString('en-GB', { hour12: false }));

      // Move vehicles slightly along their route trajectories
      this.vehicles.update(vehicleList => {
        return vehicleList.map(v => {
          if (v.status !== 'active' && v.status !== 'delayed') return v;

          const latShift = (Math.sin(Date.now() / 3000 + Number(v.code.replace('RP-', ''))) * 0.0003 * spd);
          const lngShift = (Math.cos(Date.now() / 3000 + Number(v.code.replace('RP-', ''))) * 0.0003 * spd);

          const newLat = v.currentLat + latShift;
          const newLng = v.currentLng + lngShift;

          // Battery or Fuel consumption
          const newBattery = v.isEv ? Math.max(8, v.batteryPct - (0.01 * spd)) : v.batteryPct;
          const newFuel = !v.isEv ? Math.max(12, v.fuelPct - (0.01 * spd)) : v.fuelPct;

          // Complete stop randomly during movement
          let stopsCompleted = v.completedStops;
          if (Math.random() < (0.02 * spd) && stopsCompleted < v.totalStops) {
            stopsCompleted++;
          }

          return {
            ...v,
            currentLat: newLat,
            currentLng: newLng,
            batteryPct: parseFloat(newBattery.toFixed(1)),
            fuelPct: parseFloat(newFuel.toFixed(1)),
            completedStops: stopsCompleted,
            remainingKm: Math.max(0.5, parseFloat((v.remainingKm - (0.01 * spd)).toFixed(1)))
          };
        });
      });

    }, 1000);
  }
}
