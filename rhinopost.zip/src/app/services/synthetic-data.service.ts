import { Injectable } from '@angular/core';
import { 
  Depot, Vehicle, VehicleType, Driver, Parcel, Stop, Route, 
  Alert, OperationalEvent, PostcodeSector 
} from '../models/rhinopost.models';

@Injectable({
  providedIn: 'root'
})
export class SyntheticDataService {

  // 10 National Depots across UK
  readonly DEPOTS: Depot[] = [
    {
      id: 'depot-01',
      code: 'LDN-CENTRAL',
      name: 'London Central Mail Centre',
      city: 'London',
      region: 'Greater London',
      postcode: 'EC1A 1AA',
      lat: 51.5173,
      lng: -0.0978,
      capacityParcels: 35000,
      currentParcels: 28420,
      activeVehicles: 85,
      totalVehicles: 95,
      status: 'optimal',
      manager: 'Alistair Vance'
    },
    {
      id: 'depot-02',
      code: 'LDN-SOUTH',
      name: 'Croydon Delivery Depot',
      city: 'Croydon',
      region: 'Greater London',
      postcode: 'CR0 2EE',
      lat: 51.3762,
      lng: -0.0982,
      capacityParcels: 22000,
      currentParcels: 18900,
      activeVehicles: 58,
      totalVehicles: 65,
      status: 'optimal',
      manager: 'Gemma Davies'
    },
    {
      id: 'depot-03',
      code: 'BHX-MIDLANDS',
      name: 'Birmingham Central Sorting Office',
      city: 'Birmingham',
      region: 'Midlands',
      postcode: 'B1 1AA',
      lat: 52.4862,
      lng: -1.8904,
      capacityParcels: 30000,
      currentParcels: 25100,
      activeVehicles: 72,
      totalVehicles: 80,
      status: 'high_load',
      manager: 'Marcus Sterling'
    },
    {
      id: 'depot-04',
      code: 'MAN-NORTHWEST',
      name: 'Manchester Regional Parcel Hub',
      city: 'Manchester',
      region: 'North West',
      postcode: 'M1 2WD',
      lat: 53.4808,
      lng: -2.2426,
      capacityParcels: 28000,
      currentParcels: 24300,
      activeVehicles: 68,
      totalVehicles: 75,
      status: 'optimal',
      manager: 'Fiona McGregor'
    },
    {
      id: 'depot-05',
      code: 'LDS-YORKSHIRE',
      name: 'Leeds Delivery Office',
      city: 'Leeds',
      region: 'Yorkshire',
      postcode: 'LS1 4DY',
      lat: 53.7997,
      lng: -1.5491,
      capacityParcels: 20000,
      currentParcels: 16500,
      activeVehicles: 45,
      totalVehicles: 50,
      status: 'optimal',
      manager: 'David Thornton'
    },
    {
      id: 'depot-06',
      code: 'GLA-SCOTLAND',
      name: 'Glasgow West Mail Hub',
      city: 'Glasgow',
      region: 'Scotland',
      postcode: 'G1 1XQ',
      lat: 55.8642,
      lng: -4.2518,
      capacityParcels: 18000,
      currentParcels: 14200,
      activeVehicles: 42,
      totalVehicles: 48,
      status: 'optimal',
      manager: 'Callum Reid'
    },
    {
      id: 'depot-07',
      code: 'BRS-SOUTHWEST',
      name: 'Bristol Severn logistics Hub',
      city: 'Bristol',
      region: 'South West',
      postcode: 'BS1 3AG',
      lat: 51.4545,
      lng: -2.5879,
      capacityParcels: 19000,
      currentParcels: 15800,
      activeVehicles: 44,
      totalVehicles: 50,
      status: 'optimal',
      manager: 'Hannah Bennett'
    },
    {
      id: 'depot-08',
      code: 'NCL-NORTHEAST',
      name: 'Newcastle Tyne Depot',
      city: 'Newcastle',
      region: 'North East',
      postcode: 'NE1 1DF',
      lat: 54.9783,
      lng: -1.6178,
      capacityParcels: 15000,
      currentParcels: 12100,
      activeVehicles: 34,
      totalVehicles: 40,
      status: 'optimal',
      manager: 'Robert O\'Connor'
    },
    {
      id: 'depot-09',
      code: 'BFS-ULSTER',
      name: 'Belfast Harbour Logistics',
      city: 'Belfast',
      region: 'Northern Ireland',
      postcode: 'BT1 3AA',
      lat: 54.5973,
      lng: -5.9301,
      capacityParcels: 12000,
      currentParcels: 9400,
      activeVehicles: 28,
      totalVehicles: 32,
      status: 'optimal',
      manager: 'Ciaran O\'Neill'
    },
    {
      id: 'depot-10',
      code: 'CWL-WALES',
      name: 'Cardiff Bay Mail Depot',
      city: 'Cardiff',
      region: 'Wales',
      postcode: 'CF10 1EP',
      lat: 51.4816,
      lng: -3.1791,
      capacityParcels: 14000,
      currentParcels: 11200,
      activeVehicles: 30,
      totalVehicles: 35,
      status: 'optimal',
      manager: 'Sian Hughes'
    }
  ];

  readonly VEHICLE_TYPES: VehicleType[] = [
    {
      id: 'vt-ev-van-m',
      name: 'Electric Van (Medium - E-Transit)',
      category: 'ev_van',
      capacityKg: 1100,
      volumeM3: 9.5,
      maxRangeKm: 260,
      batteryCapacityKwh: 68,
      co2PerKmGrams: 0
    },
    {
      id: 'vt-ev-van-l',
      name: 'Electric Van (Large - Maxus eDeliver 9)',
      category: 'ev_van',
      capacityKg: 1350,
      volumeM3: 11.0,
      maxRangeKm: 296,
      batteryCapacityKwh: 88,
      co2PerKmGrams: 0
    },
    {
      id: 'vt-van-l',
      name: 'Diesel Van (Sprinter L2H2)',
      category: 'van',
      capacityKg: 1400,
      volumeM3: 11.5,
      maxRangeKm: 750,
      batteryCapacityKwh: 0,
      co2PerKmGrams: 185
    },
    {
      id: 'vt-cargo-bike',
      name: 'E-Cargo Trike (Riese & Müller)',
      category: 'cargo_bike',
      capacityKg: 200,
      volumeM3: 1.8,
      maxRangeKm: 80,
      batteryCapacityKwh: 1.2,
      co2PerKmGrams: 0
    },
    {
      id: 'vt-truck-urban',
      name: 'Urban Rigid Truck (DAF LF 7.5t)',
      category: 'truck',
      capacityKg: 3800,
      volumeM3: 32.0,
      maxRangeKm: 600,
      batteryCapacityKwh: 0,
      co2PerKmGrams: 340
    }
  ];

  // Generates complete 500 Vehicles, 500 Drivers, 25,000 Parcels & Routes dataset
  generateNationalDataset(): {
    depots: Depot[];
    vehicles: Vehicle[];
    drivers: Driver[];
    parcels: Parcel[];
    routes: Route[];
    postcodes: PostcodeSector[];
  } {
    const drivers: Driver[] = [];
    const vehicles: Vehicle[] = [];
    const parcels: Parcel[] = [];
    const routes: Route[] = [];
    const postcodes: PostcodeSector[] = [];

    const driverFirstNames = ['James', 'Arthur', 'Oliver', 'Noah', 'George', 'Harry', 'Leo', 'Jack', 'Charlie', 'Freddie', 'Sarah', 'Emily', 'Chloe', 'Jessica', 'Sophie', 'Olivia', 'Amelia', 'Grace', 'Lily', 'Ava'];
    const driverLastNames = ['Wilson', 'Smith', 'Patel', 'Taylor', 'Brown', 'Jones', 'Davies', 'Evans', 'Thomas', 'Roberts', 'Walker', 'Wright', 'Robinson', 'Thompson', 'White', 'Hughes', 'Edwards', 'Green', 'Hall', 'Wood'];

    const routeColors = ['#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#3b82f6', '#14b8a6', '#f97316', '#a855f7', '#6366f1'];

    let globalVehicleIndex = 1001;
    let globalParcelIndex = 100001;

    // Generate Postcode sectors for heatmaps
    this.DEPOTS.forEach(depot => {
      const cityPrefix = depot.postcode.split(' ')[0];
      for (let i = 1; i <= 6; i++) {
        const angle = (i * 60 * Math.PI) / 180;
        const radiusKm = 1.5 + Math.random() * 4.5;
        const lat = depot.lat + (radiusKm / 111.32) * Math.cos(angle);
        const lng = depot.lng + (radiusKm / (111.32 * Math.cos(depot.lat * Math.PI / 180))) * Math.sin(angle);
        
        postcodes.push({
          sector: `${cityPrefix} ${i}A`,
          city: depot.city,
          lat,
          lng,
          parcelCount: Math.floor(400 + Math.random() * 1200),
          densityPerKm2: Math.floor(180 + Math.random() * 650),
          avgStopDurationSec: Math.floor(180 + Math.random() * 180),
          failedRatePct: parseFloat((1.2 + Math.random() * 3.5).toFixed(1)),
          trafficDelayMins: Math.floor(2 + Math.random() * 14)
        });
      }
    });

    // Create 500 vehicles and 500 drivers distributed across 10 depots
    this.DEPOTS.forEach((depot, depotIdx) => {
      const depotVehicleCount = depot.activeVehicles;
      
      for (let i = 0; i < depotVehicleCount; i++) {
        const vId = `v-${globalVehicleIndex}`;
        const dId = `d-${globalVehicleIndex}`;
        const code = `RP-${globalVehicleIndex}`;
        
        const firstName = driverFirstNames[Math.floor(Math.random() * driverFirstNames.length)];
        const lastName = driverLastNames[Math.floor(Math.random() * driverLastNames.length)];
        const driverName = `${firstName} ${lastName}`;

        const isEv = Math.random() < 0.65; // 65% EV Fleet
        const vType = isEv ? this.VEHICLE_TYPES[0] : this.VEHICLE_TYPES[2];

        const driver: Driver = {
          id: dId,
          code: `DRV-${1000 + i}`,
          name: driverName,
          phone: `+44 7700 ${900000 + globalVehicleIndex}`,
          depotId: depot.id,
          licenseType: 'Class C / Van',
          rating: parseFloat((4.5 + Math.random() * 0.5).toFixed(1)),
          status: 'active',
          hoursWorkedToday: parseFloat((2.5 + Math.random() * 4.5).toFixed(1)),
          assignedVehicleId: vId
        };
        drivers.push(driver);

        // Calculate positions around depot
        const offsetAngle = (i * 25 * Math.PI) / 180;
        const offsetDistKm = 0.5 + Math.random() * 8.0;
        const vLat = depot.lat + (offsetDistKm / 111.32) * Math.cos(offsetAngle);
        const vLng = depot.lng + (offsetDistKm / (111.32 * Math.cos(depot.lat * Math.PI / 180))) * Math.sin(offsetAngle);

        const stopsTotal = Math.floor(55 + Math.random() * 45);
        const stopsDone = Math.floor(stopsTotal * (0.35 + Math.random() * 0.4));
        const remKm = parseFloat((18.5 + Math.random() * 35.0).toFixed(1));

        const vehicle: Vehicle = {
          id: vId,
          code,
          driverId: dId,
          driverName,
          vehicleTypeId: vType.id,
          vehicleTypeName: vType.name,
          category: vType.category,
          isEv,
          batteryPct: isEv ? Math.floor(45 + Math.random() * 50) : 0,
          fuelPct: !isEv ? Math.floor(50 + Math.random() * 45) : 0,
          cargoUtilisationPct: Math.floor(65 + Math.random() * 30),
          currentLat: vLat,
          currentLng: vLng,
          speedKmH: Math.floor(25 + Math.random() * 30),
          status: i % 15 === 0 ? 'delayed' : 'active',
          depotId: depot.id,
          routeId: `route-${globalVehicleIndex}`,
          completedStops: stopsDone,
          totalStops: stopsTotal,
          remainingKm: remKm,
          etaDepot: `16:${Math.floor(10 + Math.random() * 45)}`,
          onTimeProbability: Math.floor(88 + Math.random() * 11),
          heading: Math.floor(Math.random() * 360)
        };
        vehicles.push(vehicle);

        // Generate Stops & Route for this vehicle
        const stops: Stop[] = [];
        let currLat = depot.lat;
        let currLng = depot.lng;

        // Depot Start Stop
        stops.push({
          id: `stop-${vId}-000`,
          stopNumber: 0,
          parcelIds: [],
          type: 'depot_reload',
          address: `${depot.name}, ${depot.postcode}`,
          postcode: depot.postcode,
          lat: depot.lat,
          lng: depot.lng,
          deliveryWindow: '08:00 - 08:30',
          expectedTime: '08:00',
          actualTime: '08:02',
          serviceDurationSecs: 900,
          status: 'completed',
          distanceToNextKm: 1.2,
          customerName: 'DEPOT DEPARTURE',
          priority: 1
        });

        const numStopsForRoute = 18; // Detailed stops for route board view
        for (let s = 1; s <= numStopsForRoute; s++) {
          const sAngle = offsetAngle + (s * 0.15);
          const sDist = 0.6 + Math.random() * 0.8;
          currLat += (sDist / 111.32) * Math.cos(sAngle);
          currLng += (sDist / (111.32 * Math.cos(currLat * Math.PI / 180))) * Math.sin(sAngle);

          const trackingId = `RP${globalParcelIndex++}`;
          const isDone = s <= Math.floor(numStopsForRoute * 0.55);

          // Create parcel
          const parcel: Parcel = {
            trackingId,
            serviceClass: s % 5 === 0 ? 'NextDay' : s % 7 === 0 ? 'SameDay' : 'Standard',
            senderName: 'UK E-Commerce Central Hub',
            recipientName: `Customer #${s} at ${depot.city}`,
            destinationAddress: `${10 + s * 3} High Street, Sector ${depot.code}`,
            postcode: `${depot.postcode.split(' ')[0]} ${s}AB`,
            lat: currLat,
            lng: currLng,
            deliveryWindow: s <= 5 ? '09:00 - 12:00' : '12:00 - 17:00',
            weightKg: parseFloat((0.5 + Math.random() * 8.0).toFixed(1)),
            volumeM3: parseFloat((0.01 + Math.random() * 0.08).toFixed(3)),
            priorityLevel: s % 4 === 0 ? 5 : 2,
            signatureRequired: s % 3 === 0,
            status: isDone ? 'delivered' : 'in_transit',
            estimatedDurationMins: 4,
            assignedRouteId: `route-${globalVehicleIndex}`,
            assignedVehicleId: vId,
            depotId: depot.id
          };
          parcels.push(parcel);

          stops.push({
            id: `stop-${vId}-${s}`,
            stopNumber: s,
            parcelIds: [trackingId],
            type: 'delivery',
            address: parcel.destinationAddress,
            postcode: parcel.postcode,
            lat: currLat,
            lng: currLng,
            deliveryWindow: parcel.deliveryWindow,
            expectedTime: `10:${(s * 8) % 60 < 10 ? '0' : ''}${(s * 8) % 60}`,
            actualTime: isDone ? `10:${(s * 8) % 60 < 10 ? '0' : ''}${(s * 8) % 60}` : undefined,
            serviceDurationSecs: 240,
            status: isDone ? 'completed' : (s === 12 && i % 15 === 0 ? 'delayed' : 'pending'),
            distanceToNextKm: parseFloat((0.8 + Math.random() * 1.2).toFixed(1)),
            customerName: parcel.recipientName,
            priority: parcel.priorityLevel
          });
        }

        const route: Route = {
          id: `route-${globalVehicleIndex}`,
          routeCode: `${depot.code.substring(0, 3)}-${globalVehicleIndex}`,
          depotId: depot.id,
          vehicleId: vId,
          vehicleCode: code,
          driverId: dId,
          driverName,
          stops,
          totalDistanceKm: parseFloat((45 + Math.random() * 35).toFixed(1)),
          totalDurationMins: Math.floor(280 + Math.random() * 120),
          etaCompletion: `16:${Math.floor(15 + Math.random() * 35)}`,
          status: i % 15 === 0 ? 'delayed' : 'active',
          co2EmissionsKg: isEv ? 0 : parseFloat((8.5 + Math.random() * 6.0).toFixed(1)),
          operatingCostGbp: parseFloat((65 + Math.random() * 35).toFixed(2)),
          slaPerformancePct: Math.floor(92 + Math.random() * 7),
          colorHex: routeColors[depotIdx % routeColors.length],
          currentStopIndex: Math.floor(numStopsForRoute * 0.55)
        };
        routes.push(route);

        globalVehicleIndex++;
      }
    });

    return { depots: this.DEPOTS, vehicles, drivers, parcels, routes, postcodes };
  }

  // Initial Operational Events for Live Control Ticker
  getInitialEvents(): OperationalEvent[] {
    const timeNow = new Date();
    const formatTime = (minusSecs: number) => {
      const d = new Date(timeNow.getTime() - minusSecs * 1000);
      return d.toTimeString().split(' ')[0];
    };

    return [
      { id: 'ev-1', timestamp: formatTime(4), type: 'reoptimised', vehicleCode: 'RP-1042', routeCode: 'LDN-1042', message: 'Route LDN-1042 re-optimised due to A11 road delay (+3.2 km alternative).' },
      { id: 'ev-2', timestamp: formatTime(18), type: 'congestion', vehicleCode: 'RP-1088', routeCode: 'BHX-1088', message: 'Vehicle RP-1088 entered Birmingham congestion zone. Speed reduced to 18 km/h.' },
      { id: 'ev-3', timestamp: formatTime(32), type: 'priority', vehicleCode: 'RP-1008', routeCode: 'LDN-1008', message: 'Timed Medical Parcel RP100249 priority upgraded to Level 5 Urgent.' },
      { id: 'ev-4', timestamp: formatTime(55), type: 'alert', vehicleCode: 'RP-1145', routeCode: 'MAN-1145', message: 'EV RP-1145 battery level at 28%. Auto-routing waypoint added for Fast Charger #4.' },
      { id: 'ev-5', timestamp: formatTime(85), type: 'info', vehicleCode: 'RP-1204', routeCode: 'LDS-1204', message: 'Depot Leeds Yorkshire loading wave complete. 42 vehicles dispatched on schedule.' }
    ];
  }

  // Initial Critical & Warning Operational Alerts
  getInitialAlerts(): Alert[] {
    return [
      {
        id: 'alt-101',
        timestamp: '11:42:05',
        severity: 'critical',
        title: 'A1 Northbound Road Closure',
        description: 'Major accident on A1 Northbound near Junction 4. 17 active routes affected across London Central & Croydon depots.',
        depotId: 'depot-01',
        acknowledged: false
      },
      {
        id: 'alt-102',
        timestamp: '11:38:12',
        severity: 'warning',
        title: 'EV Battery Range Deficit Risk',
        description: 'Vehicle RP-1145 on route MAN-1145 has predicted arrival battery at 4% (threshold: 10%). Charging stop required.',
        vehicleId: 'v-1145',
        routeId: 'route-1145',
        acknowledged: false
      },
      {
        id: 'alt-103',
        timestamp: '11:24:50',
        severity: 'warning',
        title: 'Depot Sorting Congestion',
        description: 'Birmingham Central Sorting Office operating at 88% capacity. Inbound parcel wave delaying departure by 14 mins.',
        depotId: 'depot-03',
        acknowledged: false
      },
      {
        id: 'alt-104',
        timestamp: '11:10:15',
        severity: 'info',
        title: 'High Priority Parcel Wave Added',
        description: '140 Same-Day Priority parcels added to London Central network for afternoon delivery windows.',
        depotId: 'depot-01',
        acknowledged: true
      }
    ];
  }
}
