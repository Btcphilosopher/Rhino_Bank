import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Initialize Google GenAI Server Client
let genAiClient: GoogleGenAI | null = null;
function getGenAi(): GoogleGenAI {
  if (!genAiClient) {
    genAiClient = new GoogleGenAI({
      apiKey: process.env['GEMINI_API_KEY'] || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return genAiClient;
}

// ==========================================
// RHINOPOST REST API ENDPOINTS
// ==========================================

app.get('/api/vehicles', (_req, res) => {
  res.json({
    status: 'success',
    count: 500,
    active: 438,
    charging: 31,
    maintenance: 27,
    delayed: 18,
    message: 'National Fleet Query (Synthetic Dataset)'
  });
});

app.get('/api/routes', (_req, res) => {
  res.json({
    status: 'success',
    totalRoutes: 438,
    totalDistanceKm: 35740,
    totalOperatingCostGbp: 79310,
    averageSlaPct: 96.7
  });
});

app.get('/api/depots', (_req, res) => {
  res.json({
    status: 'success',
    depotsCount: 10,
    nationalParcelsToday: 248920,
    activeVehicles: 438
  });
});

app.post('/api/scenarios/run', (req, res) => {
  const { scenarioId } = req.body || {};
  res.json({
    status: 'success',
    scenarioId: scenarioId || 'scenario-custom',
    baselineVehicles: 500,
    scenarioVehicles: 438,
    baselineDistanceKm: 42810,
    scenarioDistanceKm: 35740,
    baselineCostGbp: 98420,
    scenarioCostGbp: 79310,
    baselineSlaPct: 88.2,
    scenarioSlaPct: 96.7,
    co2SavedTonnes: 38.4
  });
});

// Gemini AI Prediction API Endpoint for Logistics Intelligence
app.post('/api/gemini/predict', async (req, res) => {
  try {
    const { task, routeCode, currentLat, currentLng, vehicleCode, trafficLevel } = req.body;
    const ai = getGenAi();

    const prompt = `You are the RHINOPOST AI Operations Intelligence Engine.
Analyze the following operational vehicle/route context:
Task: ${task || 'Predict ETA and Failure Risk'}
Vehicle: ${vehicleCode || 'RP-2048'}
Route: ${routeCode || 'LDN-041'}
Current Location: Lat ${currentLat || 51.5173}, Lng ${currentLng || -0.0978}
Traffic Conditions: ${trafficLevel || 'Heavy Urban Congestion'}

Provide a concise, professional, data-dense JSON response with fields:
- predictedEta (e.g. "16:22")
- serviceTimeConfidence (e.g. 94)
- failedDeliveryProbability (e.g. 3.2)
- trafficImpactMinutes (e.g. +8)
- recommendedAction (1 short sentence)
- aiOperationalInsight (2 sentences on VRP optimization advice)`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    res.json({
      status: 'success',
      data: JSON.parse(response.text || '{}')
    });
  } catch {
    res.json({
      status: 'fallback',
      data: {
        predictedEta: '16:18',
        serviceTimeConfidence: 92,
        failedDeliveryProbability: 2.8,
        trafficImpactMinutes: 6,
        recommendedAction: 'Maintain current sequence with A11 bypass.',
        aiOperationalInsight: 'High stop density in sector EC1A indicates 96.4% on-time probability. Minor 6-minute congestion buffer applied.'
      }
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

