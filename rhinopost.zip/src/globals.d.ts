interface Window {
  L: {
    map: (element: HTMLElement | string, options?: unknown) => unknown;
    control: { zoom: (options?: unknown) => { addTo: (map: unknown) => unknown } };
    tileLayer: (url: string, options?: unknown) => { addTo: (map: unknown) => unknown };
    divIcon: (options: unknown) => unknown;
    marker: (latlng: [number, number], options?: unknown) => {
      bindPopup: (content: string) => { addTo: (map: unknown) => unknown };
      addTo: (map: unknown) => unknown;
      on: (event: string, fn: () => void) => void;
    };
    polyline: (latlngs: [number, number][], options?: unknown) => { addTo: (map: unknown) => unknown };
  };
}

declare const L: Window['L'];
