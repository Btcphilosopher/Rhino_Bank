package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.sp
import com.example.nsx.viewmodel.ExchangeViewModel
import com.example.ui.screens.AdminConsoleScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DeveloperApiCliScreen
import com.example.ui.screens.PortfolioLedgerScreen
import com.example.ui.screens.SimulationLabScreen
import com.example.ui.screens.TradingTerminalScreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NorthstarTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

enum class NSXScreen(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    TERMINAL("Terminal", Icons.Default.CandlestickChart),
    PORTFOLIO("Portfolio", Icons.Default.AccountBalanceWallet),
    SIMULATOR("Simulator", Icons.Default.Tune),
    ADMIN("Admin", Icons.Default.AdminPanelSettings),
    CLI_API("CLI & API", Icons.Default.Code)
}

class MainActivity : ComponentActivity() {
    private val viewModel: ExchangeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NorthstarTheme {
                NSXApp(viewModel)
            }
        }
    }
}

@Composable
fun NSXApp(viewModel: ExchangeViewModel) {
    var currentScreen by remember { mutableStateOf(NSXScreen.DASHBOARD) }
    val snackbarHostState = remember { SnackbarHostState() }
    val snackMessage by viewModel.snackMessage.collectAsState()

    LaunchedEffect(snackMessage) {
        snackMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackMessage()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                contentColor = TextPrimary,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NSXScreen.values().forEach { screen ->
                    val selected = currentScreen == screen
                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                screen.icon,
                                contentDescription = screen.title,
                                tint = if (selected) ElectricCyan else TextMuted
                            )
                        },
                        label = {
                            Text(
                                screen.title,
                                fontSize = 10.sp,
                                color = if (selected) ElectricCyan else TextMuted
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = DarkCardSurface
                        ),
                        modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentScreen) {
                NSXScreen.DASHBOARD -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToTerminal = { ticker ->
                        currentScreen = NSXScreen.TERMINAL
                    }
                )
                NSXScreen.TERMINAL -> TradingTerminalScreen(viewModel = viewModel)
                NSXScreen.PORTFOLIO -> PortfolioLedgerScreen(viewModel = viewModel)
                NSXScreen.SIMULATOR -> SimulationLabScreen(viewModel = viewModel)
                NSXScreen.ADMIN -> AdminConsoleScreen(viewModel = viewModel)
                NSXScreen.CLI_API -> DeveloperApiCliScreen(viewModel = viewModel)
            }
        }
    }
}
