package com.example.nsx.engine

import com.example.nsx.model.Order
import com.example.nsx.model.OrderType
import com.example.nsx.model.Security
import com.example.nsx.model.Side
import java.util.concurrent.ConcurrentHashMap

class RiskEngine(
    private val ledgerEngine: LedgerEngine
) {
    var maxOrderNotionalLimit: Double = 10_000_000.0 // £10M max single order
    var maxPositionConcentrationPct: Double = 0.50 // Max 50% single stock concentration
    var volatilityHaltThresholdPct: Double = 10.0 // 10% price movement triggers circuit breaker

    private val priceHistoryWindow = ConcurrentHashMap<String, MutableList<Pair<Long, Double>>>()

    data class RiskValidationResult(
        val isAllowed: Boolean,
        val rejectionReason: String? = null
    )

    fun validateOrder(order: Order, security: Security): RiskValidationResult {
        // 1. Tick size validation
        if (order.limitPrice > 0) {
            val tick = security.tickSize
            val remainder = (order.limitPrice % tick)
            if (remainder > 0.001 && Math.abs(remainder - tick) > 0.001) {
                return RiskValidationResult(false, "Price £${order.limitPrice} does not align with tick size £$tick")
            }
        }

        // 2. Order size / notional limit
        val estimatedNotional = if (order.orderType == OrderType.MARKET) {
            order.quantity * security.lastPrice
        } else {
            order.quantity * order.limitPrice
        }

        if (estimatedNotional > maxOrderNotionalLimit) {
            return RiskValidationResult(false, "Order notional £${String.format("%.2f", estimatedNotional)} exceeds maximum threshold £${String.format("%.2f", maxOrderNotionalLimit)}")
        }

        // 3. Buying Power / Funds Check
        val account = ledgerEngine.getAccount(order.accountId)
            ?: return RiskValidationResult(false, "Account ${order.accountId} not found")

        if (order.side == Side.BUY) {
            if (account.availableCash < estimatedNotional) {
                return RiskValidationResult(false, "Insufficient available cash. Required: £${String.format("%.2f", estimatedNotional)}, Available: £${String.format("%.2f", account.availableCash)}")
            }
        } else {
            val pos = ledgerEngine.getPosition(order.accountId, order.ticker)
            if (pos == null || pos.availableQuantity < order.quantity) {
                val avail = pos?.availableQuantity ?: 0
                return RiskValidationResult(false, "Insufficient position. Required: ${order.quantity}, Available: $avail")
            }
        }

        return RiskValidationResult(true)
    }

    /**
     * Checks if trade price variation exceeds volatility circuit breaker threshold.
     * Returns true if volatility circuit breaker should be triggered.
     */
    fun checkCircuitBreaker(ticker: String, tradePrice: Double, prevClose: Double, timestamp: Long): Boolean {
        if (prevClose <= 0) return false
        val changePct = Math.abs((tradePrice - prevClose) / prevClose) * 100
        if (changePct >= volatilityHaltThresholdPct) {
            return true
        }

        // Window check (last 1 minute)
        val history = priceHistoryWindow.computeIfAbsent(ticker) { mutableListOf() }
        synchronized(history) {
            history.add(Pair(timestamp, tradePrice))
            history.removeIf { timestamp - it.first > 60_000 } // Keep last 1 min
            if (history.size > 2) {
                val minPrice = history.minOf { it.second }
                val maxPrice = history.maxOf { it.second }
                val swingPct = if (minPrice > 0) ((maxPrice - minPrice) / minPrice) * 100 else 0.0
                if (swingPct >= volatilityHaltThresholdPct) {
                    return true
                }
            }
        }
        return false
    }
}
