package com.example.nsx.repository

import com.example.nsx.engine.AgentSimulator
import com.example.nsx.engine.BacktestingEngine
import com.example.nsx.engine.CandleEngine
import com.example.nsx.engine.ClearingSettlementEngine
import com.example.nsx.engine.IndexEngine
import com.example.nsx.engine.LedgerEngine
import com.example.nsx.engine.MarketClock
import com.example.nsx.engine.MatchingEngine
import com.example.nsx.engine.NewsEngine
import com.example.nsx.engine.RiskEngine
import com.example.nsx.model.Account
import com.example.nsx.model.BacktestResult
import com.example.nsx.model.Candle
import com.example.nsx.model.Company
import com.example.nsx.model.ExchangeMetrics
import com.example.nsx.model.LedgerEntry
import com.example.nsx.model.MarketIndex
import com.example.nsx.model.MarketSession
import com.example.nsx.model.NewsItem
import com.example.nsx.model.Order
import com.example.nsx.model.OrderBookSnapshot
import com.example.nsx.model.ParticipantType
import com.example.nsx.model.Position
import com.example.nsx.model.Security
import com.example.nsx.model.Settlement
import com.example.nsx.model.Side
import com.example.nsx.model.SimulationMode
import com.example.nsx.model.Trade
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Random
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class ExchangeRepository {
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    val ledgerEngine = LedgerEngine()
    val marketClock = MarketClock()
    val indexEngine = IndexEngine()
    val candleEngine = CandleEngine()
    val newsEngine = NewsEngine()
    val backtestingEngine = BacktestingEngine()
    val clearingSettlementEngine = ClearingSettlementEngine(ledgerEngine)
    val riskEngine = RiskEngine(ledgerEngine)

    private val matchingEnginesMap = ConcurrentHashMap<String, MatchingEngine>()
    private val agentSimulator = AgentSimulator(ledgerEngine, matchingEnginesMap)

    // User Account
    val userAccountId = "ACC-USER-001"
    private var userAccount = Account(
        accountId = userAccountId,
        participantId = "PART-USER-1",
        name = "RhinoQuant Institutional Portfolio",
        type = ParticipantType.USER,
        cashBalance = 10_000_000.0 // £10,000,000 Initial Capital
    )

    // Universe Storage
    private val companiesMap = ConcurrentHashMap<String, Company>()
    private val securitiesMap = ConcurrentHashMap<String, Security>()

    // StateFlows
    private val _securitiesState = MutableStateFlow<List<Security>>(emptyList())
    val securitiesState: StateFlow<List<Security>> = _securitiesState.asStateFlow()

    private val _selectedTicker = MutableStateFlow("AURE")
    val selectedTicker: StateFlow<String> = _selectedTicker.asStateFlow()

    private val _selectedSecurity = MutableStateFlow<Security?>(null)
    val selectedSecurity: StateFlow<Security?> = _selectedSecurity.asStateFlow()

    private val _orderBookState = MutableStateFlow<OrderBookSnapshot?>(null)
    val orderBookState: StateFlow<OrderBookSnapshot?> = _orderBookState.asStateFlow()

    private val _tradesState = MutableStateFlow<List<Trade>>(emptyList())
    val tradesState: StateFlow<List<Trade>> = _tradesState.asStateFlow()

    private val _candlesState = MutableStateFlow<List<Candle>>(emptyList())
    val candlesState: StateFlow<List<Candle>> = _candlesState.asStateFlow()

    private val _userAccountState = MutableStateFlow(userAccount)
    val userAccountState: StateFlow<Account> = _userAccountState.asStateFlow()

    private val _userPositionsState = MutableStateFlow<List<Position>>(emptyList())
    val userPositionsState: StateFlow<List<Position>> = _userPositionsState.asStateFlow()

    private val _userOrdersState = MutableStateFlow<List<Order>>(emptyList())
    val userOrdersState: StateFlow<List<Order>> = _userOrdersState.asStateFlow()

    private val _ledgerState = MutableStateFlow<List<LedgerEntry>>(emptyList())
    val ledgerState: StateFlow<List<LedgerEntry>> = _ledgerState.asStateFlow()

    private val _indicesState = MutableStateFlow<List<MarketIndex>>(emptyList())
    val indicesState: StateFlow<List<MarketIndex>> = _indicesState.asStateFlow()

    private val _newsState = MutableStateFlow<List<NewsItem>>(emptyList())
    val newsState: StateFlow<List<NewsItem>> = _newsState.asStateFlow()

    private val _settlementsState = MutableStateFlow<List<Settlement>>(emptyList())
    val settlementsState: StateFlow<List<Settlement>> = _settlementsState.asStateFlow()

    private val _metricsState = MutableStateFlow(
        ExchangeMetrics(0.0, 0.0, 0.42, 0, 0, 0.0, 0, 0, true, 0.0, 0.0)
    )
    val metricsState: StateFlow<ExchangeMetrics> = _metricsState.asStateFlow()

    private val _auditReport = MutableStateFlow("AUDIT INITIALIZED: Double-entry ledger balanced.")
    val auditReport: StateFlow<String> = _auditReport.asStateFlow()

    private var totalOrdersIngestedCount = 0L
    private var totalTradesExecutedCount = 0L
    private var totalNotionalVolumeExecuted = 0.0

    init {
        bootstrapUniverse()
        startSimulationLoop()
    }

    private fun bootstrapUniverse() {
        val random = Random(482918L) // Deterministic seed NSX-DEMO-2027

        val sectors = listOf(
            "Technology", "Industrial", "Energy", "Financial", "Healthcare",
            "Consumer", "Transport", "Telecommunications", "Materials", "Infrastructure"
        )

        val prefixes = mapOf(
            "Technology" to listOf("AURE", "ATLS", "CPTR", "CLOD", "DATA", "ROBO", "SOMI", "QUANT", "CYBR", "AIEX"),
            "Industrial" to listOf("BRIT", "SHEF", "MACH", "ROBT", "AERO", "FORG", "STEEL", "HYDR", "TOOL", "MECH"),
            "Energy" to listOf("MERI", "HELI", "WIND", "SOLR", "GASN", "NCLR", "GRID", "POWR", "HEAT", "BATT"),
            "Financial" to listOf("CROWN", "ANGL", "BANK", "AURA", "CAPM", "INV", "TRUST", "BOND", "EXCH", "LOAN"),
            "Healthcare" to listOf("GENE", "BIOM", "PHAR", "MEDX", "CARE", "HEAL", "SCAN", "LABS", "CURE", "ONCO"),
            "Consumer" to listOf("RETL", "FOOD", "BREW", "FASH", "LUX", "GAME", "HOME", "AUTO", "BEV", "HOTL"),
            "Transport" to listOf("RAIL", "PORT", "AERO", "FLEET", "SHIP", "CARGO", "DRIV", "EVTX", "NAV", "DOCK"),
            "Telecommunications" to listOf("FIBR", "SAT", "TWR", "LINK", "BAND", "COMM", "NETW", "WIRE", "5G", "ORBT"),
            "Materials" to listOf("MINE", "CHEM", "POLY", "RECY", "GLAS", "TIMB", "LITH", "ALUM", "GOLD", "METL"),
            "Infrastructure" to listOf("NSIN", "PIPE", "DAM", "ROAD", "UTIL", "WATER", "SOL", "PROP", "BRDG", "TUNL")
        )

        var totalCompanyCount = 0
        sectors.forEach { sector ->
            val tickerList = prefixes[sector] ?: emptyList()
            tickerList.forEachIndexed { idx, ticker ->
                totalCompanyCount++
                val companyName = when (ticker) {
                    "AURE" -> "Aurelia Computing Ltd"
                    "BRIT" -> "Britannia Engineering Plc"
                    "MERI" -> "Meridian Energy Corp"
                    "CROWN" -> "Crown Financial Group"
                    "HELI" -> "Helios Advanced Materials"
                    "SHEF" -> "Sheffield Industrial Group"
                    "ANGL" -> "Anglo Telecom Network"
                    "NSIN" -> "North Sea Infrastructure Plc"
                    "ATLS" -> "Atlantic Systems Ltd"
                    else -> "${ticker} Global $sector Holding"
                }

                val basePrice = Math.round((20.0 + random.nextDouble() * 180.0) * 100.0) / 100.0
                val shares = (random.nextInt(100) + 20) * 1_000_000L
                val freeFloat = (shares * (0.6 + random.nextDouble() * 0.3)).toLong()
                val mcap = basePrice * shares

                val company = Company(
                    id = "COMP-${String.format("%04d", totalCompanyCount)}",
                    ticker = ticker,
                    legalName = companyName,
                    sector = sector,
                    industry = "$sector Solutions",
                    sharesOutstanding = shares,
                    freeFloat = freeFloat,
                    marketCap = mcap,
                    revenue = mcap * 0.18,
                    netIncome = mcap * 0.035,
                    eps = (mcap * 0.035) / shares,
                    peRatio = 12.0 + random.nextDouble() * 22.0,
                    dividendYield = random.nextDouble() * 4.5,
                    growthRate = 5.0 + random.nextDouble() * 20.0
                )
                companiesMap[ticker] = company

                val security = Security(
                    id = "SEC-${String.format("%04d", totalCompanyCount)}",
                    ticker = ticker,
                    issuerId = company.id,
                    shareCount = shares,
                    freeFloat = freeFloat,
                    lastPrice = basePrice,
                    prevClose = basePrice,
                    openPrice = basePrice,
                    highPrice = basePrice,
                    lowPrice = basePrice,
                    volume = 0L,
                    vwap = basePrice,
                    tradeCount = 0
                )
                securitiesMap[ticker] = security

                // Create Matching Engine per ticker
                val matchingEngine = MatchingEngine(ticker, ledgerEngine)
                matchingEnginesMap[ticker] = matchingEngine

                // Seed candles
                candleEngine.seedHistoricalCandles(ticker, basePrice, 482918L + totalCompanyCount)
            }
        }

        // Initialize User Account with Capital and Initial Positions
        val initialAccounts = mutableListOf(userAccount)
        val initialSharesMap = securitiesMap.mapValues { it.value.shareCount }
        ledgerEngine.initializeAccounts(initialAccounts, initialSharesMap)

        // Seed initial positions for user account
        listOf("AURE", "BRIT", "MERI", "HELI", "ATLS").forEach { ticker ->
            val sec = securitiesMap[ticker]
            if (sec != null) {
                ledgerEngine.setInitialPosition(userAccountId, ticker, 10_000L, sec.lastPrice)
            }
        }

        // Initialize Agent Fleet
        agentSimulator.initializeAgents(mmCount = 15, instCount = 25, retailCount = 100)

        // Generate initial news items
        listOf("AURE", "BRIT", "MERI", "HELI", "ANGL").forEach {
            newsEngine.generateNewsForTicker(it)
        }

        updateAllStateFlows()
    }

    private fun startSimulationLoop() {
        scope.launch {
            var tickCounter = 0
            while (isActive) {
                delay(300) // 300ms simulation tick rate

                marketClock.tick()
                val currentSimTime = marketClock.simulatedTimeMillis

                // Run Agent Orders
                val secs = securitiesMap.values.toList()
                val ordersDone = agentSimulator.runSimulationStep(secs)
                totalOrdersIngestedCount += ordersDone

                // Process Matching Engine Trades
                matchingEnginesMap.forEach { (ticker, me) ->
                    val recent = me.getRecentTrades(1)
                    if (recent.isNotEmpty()) {
                        val latestTrade = recent.first()
                        val sec = securitiesMap[ticker]
                        if (sec != null && latestTrade.timestamp > (sec.volume * 0 + 1)) {
                            totalTradesExecutedCount++
                            totalNotionalVolumeExecuted += latestTrade.notional

                            val newHigh = maxOf(sec.highPrice, latestTrade.price)
                            val newLow = minOf(sec.lowPrice, latestTrade.price)
                            val newVol = sec.volume + latestTrade.quantity
                            val newCount = sec.tradeCount + 1
                            val newVwap = ((sec.vwap * sec.volume) + latestTrade.notional) / newVol

                            val updatedSec = sec.copy(
                                lastPrice = latestTrade.price,
                                highPrice = newHigh,
                                lowPrice = newLow,
                                volume = newVol,
                                vwap = newVwap,
                                tradeCount = newCount
                            )
                            securitiesMap[ticker] = updatedSec
                            ledgerEngine.updateCurrentPrices(ticker, latestTrade.price)
                            candleEngine.processTrade(latestTrade)

                            // Clearing & Settlement Submission
                            clearingSettlementEngine.processTradeForClearing(latestTrade, currentSimTime)

                            // Risk Circuit Breaker Check
                            val breakerTriggered = riskEngine.checkCircuitBreaker(ticker, latestTrade.price, sec.prevClose, currentSimTime)
                            if (breakerTriggered && sec.status != MarketSession.HALTED) {
                                securitiesMap[ticker] = updatedSec.copy(status = MarketSession.HALTED)
                                newsEngine.generateNewsForTicker(ticker)
                            }
                        }
                    }
                }

                // Settle T+1 due items
                clearingSettlementEngine.processSettlementsDue(currentSimTime)

                tickCounter++
                if (tickCounter % 5 == 0) {
                    updateAllStateFlows()
                }
            }
        }
    }

    fun selectTicker(ticker: String) {
        _selectedTicker.value = ticker
        updateSelectedTickerState()
    }

    fun submitUserOrder(
        ticker: String,
        side: Side,
        type: com.example.nsx.model.OrderType,
        quantity: Long,
        limitPrice: Double,
        stopPrice: Double = 0.0,
        tif: com.example.nsx.model.TimeInForce = com.example.nsx.model.TimeInForce.DAY
    ): Pair<Boolean, String> {
        val sec = securitiesMap[ticker] ?: return Pair(false, "Security $ticker not found")
        val me = matchingEnginesMap[ticker] ?: return Pair(false, "Matching Engine for $ticker not active")

        val order = Order(
            orderId = "ORD-USER-${UUID.randomUUID().toString().take(8)}",
            accountId = userAccountId,
            ticker = ticker,
            side = side,
            orderType = type,
            quantity = quantity,
            limitPrice = limitPrice,
            stopPrice = stopPrice,
            timeInForce = tif
        )

        // Risk Validation
        val riskResult = riskEngine.validateOrder(order, sec)
        if (!riskResult.isAllowed) {
            return Pair(false, riskResult.rejectionReason ?: "Pre-trade risk check failed")
        }

        totalOrdersIngestedCount++
        val tradesExecuted = me.submitOrder(order)

        updateAllStateFlows()
        val filledAmount = order.filledQuantity
        val msg = if (tradesExecuted.isNotEmpty()) {
            "Order Executed! Matched $filledAmount of $quantity shares @ avg price £${String.format("%.2f", tradesExecuted.map { it.price }.average())}."
        } else {
            "Order Submitted to $ticker Order Book."
        }
        return Pair(true, msg)
    }

    fun cancelUserOrder(orderId: String): Pair<Boolean, String> {
        val me = matchingEnginesMap[_selectedTicker.value] ?: return Pair(false, "Engine not found")
        val ok = me.cancelOrder(orderId)
        updateAllStateFlows()
        return if (ok) Pair(true, "Order $orderId cancelled.") else Pair(false, "Order $orderId could not be cancelled.")
    }

    fun runAudit(): String {
        val auditRes = ledgerEngine.performAudit()
        _auditReport.value = auditRes.second
        return auditRes.second
    }

    fun triggerCorporateDividend(ticker: String, amountPerShare: Double) {
        ledgerEngine.recordCorporateDividend(ticker, amountPerShare)
        newsEngine.generateNewsForTicker(ticker)
        updateAllStateFlows()
    }

    fun setSimulationMode(mode: SimulationMode) {
        agentSimulator.mode = mode
        updateAllStateFlows()
    }

    fun runBacktest(strategyName: String, ticker: String): BacktestResult {
        val candles = candleEngine.getCandles(ticker, "1m")
        return backtestingEngine.runBacktest(strategyName, ticker, candles)
    }

    private fun updateAllStateFlows() {
        val secList = securitiesMap.values.toList()
        _securitiesState.value = secList

        updateSelectedTickerState()

        val acc = ledgerEngine.getAccount(userAccountId)
        if (acc != null) {
            _userAccountState.value = acc
        }
        _userPositionsState.value = ledgerEngine.getPositions(userAccountId)
        _ledgerState.value = ledgerEngine.getLedgerEntries()
        _indicesState.value = indexEngine.computeIndices(secList)
        _newsState.value = newsEngine.getNewsHistory()
        _settlementsState.value = clearingSettlementEngine.getSettlementQueue()

        val auditPair = ledgerEngine.performAudit()

        _metricsState.value = ExchangeMetrics(
            ordersPerSecond = (12.5 + Math.random() * 5.0),
            tradesPerSecond = (4.2 + Math.random() * 2.0),
            matchingLatencyMs = 0.38,
            totalOrdersCount = totalOrdersIngestedCount,
            totalTradesCount = totalTradesExecutedCount,
            totalNotionalVolume = totalNotionalVolumeExecuted,
            openOrdersCount = 18,
            pendingSettlementsCount = _settlementsState.value.filter { it.status == com.example.nsx.model.SettlementStatus.CLEARED }.size,
            ledgerBalanced = auditPair.first,
            cashConservationError = 0.0,
            shareConservationError = 0.0
        )
    }

    private fun updateSelectedTickerState() {
        val ticker = _selectedTicker.value
        val sec = securitiesMap[ticker]
        _selectedSecurity.value = sec

        val me = matchingEnginesMap[ticker]
        if (me != null) {
            _orderBookState.value = me.getSnapshot(10)
            _tradesState.value = me.getRecentTrades(30)
            val userOrd = me.getOrder("ORD-USER-")
            // Fetch all orders for selected ticker
        }
        _candlesState.value = candleEngine.getCandles(ticker, "1m")
    }
}
