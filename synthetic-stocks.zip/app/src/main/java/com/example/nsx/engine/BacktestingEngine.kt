package com.example.nsx.engine

import com.example.nsx.model.BacktestResult
import com.example.nsx.model.Candle
import kotlin.math.sqrt

class BacktestingEngine {

    fun runBacktest(
        strategyName: String,
        ticker: String,
        candles: List<Candle>,
        initialCash: Double = 100_000.0,
        seed: Long = 482918L
    ): BacktestResult {
        if (candles.size < 25) {
            return BacktestResult(
                strategyName = strategyName,
                seed = seed,
                initialCash = initialCash,
                finalEquity = initialCash,
                totalReturnPct = 0.0,
                sharpeRatio = 0.0,
                maxDrawdownPct = 0.0,
                winRatePct = 0.0,
                totalTrades = 0,
                totalFeesPaid = 0.0,
                equityCurve = listOf(Pair(System.currentTimeMillis(), initialCash))
            )
        }

        var cash = initialCash
        var positionShares = 0L
        var totalFees = 0.0
        var totalTradesCount = 0
        var winningTradesCount = 0
        val equityCurve = mutableListOf<Pair<Long, Double>>()

        val prices = candles.map { it.close }
        val timestamps = candles.map { it.timestamp }

        var maxEquitySeen = initialCash
        var maxDrawdown = 0.0
        val returns = mutableListOf<Double>()

        for (i in 20 until candles.size) {
            val price = prices[i]
            val ts = timestamps[i]

            val smaFast = prices.subList(i - 5, i).average()
            val smaSlow = prices.subList(i - 20, i).average()

            val signal = when (strategyName) {
                "SMA_CROSSOVER" -> {
                    if (smaFast > smaSlow) 1 // Buy
                    else if (smaFast < smaSlow) -1 // Sell
                    else 0
                }
                "MEAN_REVERSION" -> {
                    val mean = prices.subList(i - 20, i).average()
                    val variance = prices.subList(i - 20, i).map { Math.pow(it - mean, 2.0) }.average()
                    val stdDev = sqrt(variance)
                    val upper = mean + (1.5 * stdDev)
                    val lower = mean - (1.5 * stdDev)
                    if (price < lower) 1 else if (price > upper) -1 else 0
                }
                else -> { // MARKET_MAKER_ARBITRAGE
                    if (i % 2 == 0) 1 else -1
                }
            }

            // Execute Strategy Signal
            if (signal == 1 && positionShares == 0L) { // Buy Signal
                val sharesToBuy = ((cash * 0.95) / price).toLong()
                if (sharesToBuy > 0) {
                    val notional = sharesToBuy * price
                    val fee = notional * 0.0005
                    cash -= (notional + fee)
                    positionShares = sharesToBuy
                    totalFees += fee
                    totalTradesCount++
                }
            } else if (signal == -1 && positionShares > 0L) { // Sell Signal
                val notional = positionShares * price
                val fee = notional * 0.0005
                cash += (notional - fee)
                val tradePnL = notional - (positionShares * prices[i - 1])
                if (tradePnL > 0) winningTradesCount++
                positionShares = 0L
                totalFees += fee
                totalTradesCount++
            }

            val currentEquity = cash + (positionShares * price)
            equityCurve.add(Pair(ts, currentEquity))

            if (currentEquity > maxEquitySeen) {
                maxEquitySeen = currentEquity
            }
            val dd = if (maxEquitySeen > 0) ((maxEquitySeen - currentEquity) / maxEquitySeen) * 100 else 0.0
            if (dd > maxDrawdown) {
                maxDrawdown = dd
            }

            if (i > 20) {
                val prevEq = equityCurve[equityCurve.size - 2].second
                if (prevEq > 0) {
                    returns.add((currentEquity - prevEq) / prevEq)
                }
            }
        }

        val finalPrice = prices.last()
        val finalEquity = cash + (positionShares * finalPrice)
        val totalReturnPct = ((finalEquity - initialCash) / initialCash) * 100

        val avgReturn = if (returns.isNotEmpty()) returns.average() else 0.0
        val stdReturn = if (returns.size > 1) {
            val varRet = returns.map { Math.pow(it - avgReturn, 2.0) }.average()
            sqrt(varRet)
        } else 0.0

        val sharpeRatio = if (stdReturn > 0) (avgReturn / stdReturn) * sqrt(252.0) else 0.0
        val winRatePct = if (totalTradesCount > 0) (winningTradesCount.toDouble() / (totalTradesCount / 2).coerceAtLeast(1)) * 100 else 0.0

        return BacktestResult(
            strategyName = strategyName,
            seed = seed,
            initialCash = initialCash,
            finalEquity = Math.round(finalEquity * 100.0) / 100.0,
            totalReturnPct = Math.round(totalReturnPct * 100.0) / 100.0,
            sharpeRatio = Math.round(sharpeRatio * 100.0) / 100.0,
            maxDrawdownPct = Math.round(maxDrawdown * 100.0) / 100.0,
            winRatePct = Math.round(winRatePct.coerceAtMost(100.0) * 100.0) / 100.0,
            totalTrades = totalTradesCount,
            totalFeesPaid = Math.round(totalFees * 100.0) / 100.0,
            equityCurve = equityCurve
        )
    }
}
