package com.example.nsx.model

import java.time.Instant

data class Company(
    val id: String,
    val ticker: String,
    val legalName: String,
    val sector: String,
    val industry: String,
    val country: String = "United Kingdom",
    val currency: String = "GBP",
    val sharesOutstanding: Long,
    val freeFloat: Long,
    val marketCap: Double,
    val revenue: Double,
    val netIncome: Double,
    val eps: Double,
    val peRatio: Double,
    val dividendYield: Double,
    val growthRate: Double
)

data class Security(
    val id: String,
    val ticker: String,
    val issuerId: String,
    val currency: String = "GBP",
    val shareCount: Long,
    val freeFloat: Long,
    val tickSize: Double = 0.05,
    val lotSize: Int = 1,
    val status: MarketSession = MarketSession.CONTINUOUS_TRADING,
    val listingDate: String = "2026-01-01",
    val lastPrice: Double,
    val prevClose: Double,
    val openPrice: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val volume: Long,
    val vwap: Double,
    val tradeCount: Int
) {
    val change: Double get() = lastPrice - prevClose
    val changePercent: Double get() = if (prevClose > 0) ((lastPrice - prevClose) / prevClose) * 100 else 0.0
}

data class Account(
    val accountId: String,
    val participantId: String,
    val name: String,
    val type: ParticipantType,
    val cashBalance: Double,
    val reservedCash: Double = 0.0,
    val marginState: String = "HEALTHY"
) {
    val availableCash: Double get() = cashBalance - reservedCash
}

data class Position(
    val accountId: String,
    val ticker: String,
    val quantity: Long,
    val reservedQuantity: Long = 0,
    val avgCost: Double,
    val currentPrice: Double
) {
    val availableQuantity: Long get() = quantity - reservedQuantity
    val marketValue: Double get() = quantity * currentPrice
    val unrealizedPnL: Double get() = quantity * (currentPrice - avgCost)
    val unrealizedPnLPercent: Double get() = if (avgCost > 0) ((currentPrice - avgCost) / avgCost) * 100 else 0.0
}

data class Order(
    val orderId: String,
    val accountId: String,
    val ticker: String,
    val side: Side,
    val orderType: OrderType,
    val quantity: Long,
    val filledQuantity: Long = 0,
    val limitPrice: Double = 0.0,
    val stopPrice: Double = 0.0,
    val timeInForce: TimeInForce = TimeInForce.DAY,
    val status: OrderStatus = OrderStatus.NEW,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val remainingQuantity: Long get() = quantity - filledQuantity
}

data class Trade(
    val tradeId: String,
    val ticker: String,
    val buyerAccountId: String,
    val sellerAccountId: String,
    val price: Double,
    val quantity: Long,
    val notional: Double = price * quantity,
    val fee: Double = notional * 0.0005, // 5 bps exchange fee
    val timestamp: Long = System.currentTimeMillis()
)

data class OrderBookLevel(
    val price: Double,
    var quantity: Long,
    var orderCount: Int
)

data class OrderBookSnapshot(
    val ticker: String,
    val bids: List<OrderBookLevel>,
    val asks: List<OrderBookLevel>,
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val spread: Double get() {
        val topBid = bids.firstOrNull()?.price ?: 0.0
        val topAsk = asks.firstOrNull()?.price ?: 0.0
        return if (topBid > 0 && topAsk > 0) topAsk - topBid else 0.0
    }
}

data class Candle(
    val ticker: String,
    val interval: String, // "1s", "1m", "5m", "1h", "1d"
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long,
    val vwap: Double,
    val tradeCount: Int
)

data class LedgerEntry(
    val entryId: String,
    val transactionId: String,
    val accountId: String,
    val isDebit: Boolean, // Debit increases asset/expense; Credit increases liability/equity
    val type: String, // "CASH" or "SHARE"
    val ticker: String = "GBP",
    val amount: Double,
    val balanceAfter: Double,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class Settlement(
    val settlementId: String,
    val tradeId: String,
    val buyerAccountId: String,
    val sellerAccountId: String,
    val ticker: String,
    val quantity: Long,
    val price: Double,
    val notional: Double,
    val settlementDate: Long,
    val status: SettlementStatus = SettlementStatus.PENDING
)

data class MarketIndex(
    val id: String,
    val name: String,
    val ticker: String,
    val value: Double,
    val change: Double,
    val changePercent: Double,
    val constituents: List<String>
)

data class NewsItem(
    val id: String,
    val ticker: String?,
    val headline: String,
    val summary: String,
    val impact: NewsImpact,
    val affectedSector: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class BacktestResult(
    val strategyName: String,
    val seed: Long,
    val initialCash: Double,
    val finalEquity: Double,
    val totalReturnPct: Double,
    val sharpeRatio: Double,
    val maxDrawdownPct: Double,
    val winRatePct: Double,
    val totalTrades: Int,
    val totalFeesPaid: Double,
    val equityCurve: List<Pair<Long, Double>>
)

data class ExchangeMetrics(
    val ordersPerSecond: Double,
    val tradesPerSecond: Double,
    val matchingLatencyMs: Double,
    val totalOrdersCount: Long,
    val totalTradesCount: Long,
    val totalNotionalVolume: Double,
    val openOrdersCount: Int,
    val pendingSettlementsCount: Int,
    val ledgerBalanced: Boolean,
    val cashConservationError: Double,
    val shareConservationError: Double
)
