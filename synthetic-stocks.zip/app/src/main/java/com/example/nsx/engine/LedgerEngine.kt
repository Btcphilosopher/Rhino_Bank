package com.example.nsx.engine

import com.example.nsx.model.Account
import com.example.nsx.model.LedgerEntry
import com.example.nsx.model.Position
import com.example.nsx.model.Trade
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class LedgerEngine {
    private val ledgerEntries = CopyOnWriteArrayList<LedgerEntry>()
    private val accountsMap = ConcurrentHashMap<String, Account>()
    private val positionsMap = ConcurrentHashMap<String, ConcurrentHashMap<String, Position>>() // AccountId -> Ticker -> Position
    
    private var totalSystemInitialCash: Double = 0.0
    private val totalIssuedSharesMap = ConcurrentHashMap<String, Long>() // Ticker -> Total Issued Shares
    private var totalFeesCollected: Double = 0.0

    fun initializeAccounts(initialAccounts: List<Account>, initialShares: Map<String, Long>) {
        accountsMap.clear()
        positionsMap.clear()
        ledgerEntries.clear()
        totalSystemInitialCash = 0.0
        totalFeesCollected = 0.0
        totalIssuedSharesMap.clear()
        
        initialShares.forEach { (ticker, count) ->
            totalIssuedSharesMap[ticker] = count
        }

        initialAccounts.forEach { acc ->
            accountsMap[acc.accountId] = acc
            totalSystemInitialCash += acc.cashBalance
            // Initial Cash Ledger Entry
            val entry = LedgerEntry(
                entryId = "LEDG-${UUID.randomUUID().toString().take(8)}",
                transactionId = "INIT-${acc.accountId}",
                accountId = acc.accountId,
                isDebit = true,
                type = "CASH",
                ticker = "GBP",
                amount = acc.cashBalance,
                balanceAfter = acc.cashBalance,
                description = "Initial Account Cash Capitalization"
            )
            ledgerEntries.add(entry)
        }
    }

    fun getAccount(accountId: String): Account? = accountsMap[accountId]

    fun getAllAccounts(): List<Account> = accountsMap.values.toList()

    fun getPositions(accountId: String): List<Position> {
        return positionsMap[accountId]?.values?.toList() ?: emptyList()
    }

    fun getPosition(accountId: String, ticker: String): Position? {
        return positionsMap[accountId]?.get(ticker)
    }

    fun setInitialPosition(accountId: String, ticker: String, quantity: Long, avgCost: Double) {
        val accPositions = positionsMap.computeIfAbsent(accountId) { ConcurrentHashMap() }
        val pos = Position(
            accountId = accountId,
            ticker = ticker,
            quantity = quantity,
            avgCost = avgCost,
            currentPrice = avgCost
        )
        accPositions[ticker] = pos

        val entry = LedgerEntry(
            entryId = "LEDG-${UUID.randomUUID().toString().take(8)}",
            transactionId = "INIT-POS-$accountId-$ticker",
            accountId = accountId,
            isDebit = true,
            type = "SHARE",
            ticker = ticker,
            amount = quantity.toDouble(),
            balanceAfter = quantity.toDouble(),
            description = "Initial Share Grant for $ticker"
        )
        ledgerEntries.add(entry)
    }

    fun updateCurrentPrices(ticker: String, price: Double) {
        positionsMap.values.forEach { userPosMap ->
            userPosMap[ticker]?.let { pos ->
                userPosMap[ticker] = pos.copy(currentPrice = price)
            }
        }
    }

    fun reserveCash(accountId: String, amount: Double): Boolean {
        val acc = accountsMap[accountId] ?: return false
        if (acc.availableCash < amount) return false
        accountsMap[accountId] = acc.copy(reservedCash = acc.reservedCash + amount)
        return true
    }

    fun releaseCash(accountId: String, amount: Double) {
        val acc = accountsMap[accountId] ?: return
        val newReserved = (acc.reservedCash - amount).coerceAtLeast(0.0)
        accountsMap[accountId] = acc.copy(reservedCash = newReserved)
    }

    fun reserveShares(accountId: String, ticker: String, quantity: Long): Boolean {
        val accPositions = positionsMap[accountId] ?: return false
        val pos = accPositions[ticker] ?: return false
        if (pos.availableQuantity < quantity) return false
        accPositions[ticker] = pos.copy(reservedQuantity = pos.reservedQuantity + quantity)
        return true
    }

    fun releaseShares(accountId: String, ticker: String, quantity: Long) {
        val accPositions = positionsMap[accountId] ?: return
        val pos = accPositions[ticker] ?: return
        val newReserved = (pos.reservedQuantity - quantity).coerceAtLeast(0)
        accPositions[ticker] = pos.copy(reservedQuantity = newReserved)
    }

    @Synchronized
    fun recordTradeExecution(trade: Trade) {
        val buyer = accountsMap[trade.buyerAccountId] ?: return
        val seller = accountsMap[trade.sellerAccountId] ?: return

        val buyerFee = trade.fee
        val sellerFee = trade.fee
        val totalFee = buyerFee + sellerFee
        totalFeesCollected += totalFee

        val newBuyerReserved = (buyer.reservedCash - trade.notional).coerceAtLeast(0.0)
        val buyerCashCost = trade.notional + buyerFee
        val newBuyerCash = buyer.cashBalance - buyerCashCost
        accountsMap[trade.buyerAccountId] = buyer.copy(
            cashBalance = newBuyerCash,
            reservedCash = newBuyerReserved
        )

        ledgerEntries.add(
            LedgerEntry(
                entryId = "LEDG-${UUID.randomUUID().toString().take(8)}",
                transactionId = trade.tradeId,
                accountId = trade.buyerAccountId,
                isDebit = false,
                type = "CASH",
                ticker = "GBP",
                amount = buyerCashCost,
                balanceAfter = newBuyerCash,
                description = "BUY ${trade.quantity} ${trade.ticker} @ £${trade.price} + Fee £${String.format("%.2f", buyerFee)}"
            )
        )

        val sellerCashProceeds = trade.notional - sellerFee
        val newSellerCash = seller.cashBalance + sellerCashProceeds
        accountsMap[trade.sellerAccountId] = seller.copy(cashBalance = newSellerCash)

        ledgerEntries.add(
            LedgerEntry(
                entryId = "LEDG-${UUID.randomUUID().toString().take(8)}",
                transactionId = trade.tradeId,
                accountId = trade.sellerAccountId,
                isDebit = true,
                type = "CASH",
                ticker = "GBP",
                amount = sellerCashProceeds,
                balanceAfter = newSellerCash,
                description = "SELL ${trade.quantity} ${trade.ticker} @ £${trade.price} - Fee £${String.format("%.2f", sellerFee)}"
            )
        )

        val buyerPositions = positionsMap.computeIfAbsent(trade.buyerAccountId) { ConcurrentHashMap() }
        val oldBuyerPos = buyerPositions[trade.ticker] ?: Position(trade.buyerAccountId, trade.ticker, 0, 0, 0.0, trade.price)
        val newBuyerQty = oldBuyerPos.quantity + trade.quantity
        val totalBuyerCost = (oldBuyerPos.quantity * oldBuyerPos.avgCost) + (trade.quantity * trade.price)
        val newBuyerAvgCost = if (newBuyerQty > 0) totalBuyerCost / newBuyerQty else 0.0
        buyerPositions[trade.ticker] = oldBuyerPos.copy(
            quantity = newBuyerQty,
            avgCost = newBuyerAvgCost,
            currentPrice = trade.price
        )

        ledgerEntries.add(
            LedgerEntry(
                entryId = "LEDG-${UUID.randomUUID().toString().take(8)}",
                transactionId = trade.tradeId,
                accountId = trade.buyerAccountId,
                isDebit = true,
                type = "SHARE",
                ticker = trade.ticker,
                amount = trade.quantity.toDouble(),
                balanceAfter = newBuyerQty.toDouble(),
                description = "Received ${trade.quantity} shares of ${trade.ticker}"
            )
        )

        val sellerPositions = positionsMap.computeIfAbsent(trade.sellerAccountId) { ConcurrentHashMap() }
        val oldSellerPos = sellerPositions[trade.ticker] ?: Position(trade.sellerAccountId, trade.ticker, 0, 0, 0.0, trade.price)
        val newSellerReserved = (oldSellerPos.reservedQuantity - trade.quantity).coerceAtLeast(0)
        val newSellerQty = (oldSellerPos.quantity - trade.quantity).coerceAtLeast(0)
        sellerPositions[trade.ticker] = oldSellerPos.copy(
            quantity = newSellerQty,
            reservedQuantity = newSellerReserved,
            currentPrice = trade.price
        )

        ledgerEntries.add(
            LedgerEntry(
                entryId = "LEDG-${UUID.randomUUID().toString().take(8)}",
                transactionId = trade.tradeId,
                accountId = trade.sellerAccountId,
                isDebit = false,
                type = "SHARE",
                ticker = trade.ticker,
                amount = trade.quantity.toDouble(),
                balanceAfter = newSellerQty.toDouble(),
                description = "Delivered ${trade.quantity} shares of ${trade.ticker}"
            )
        )
    }

    fun recordCorporateDividend(ticker: String, dividendPerShare: Double) {
        positionsMap.forEach { (accId, userPosMap) ->
            userPosMap[ticker]?.let { pos ->
                if (pos.quantity > 0) {
                    val payout = pos.quantity * dividendPerShare
                    val acc = accountsMap[accId]
                    if (acc != null) {
                        val newCash = acc.cashBalance + payout
                        accountsMap[accId] = acc.copy(cashBalance = newCash)
                        ledgerEntries.add(
                            LedgerEntry(
                                entryId = "LEDG-${UUID.randomUUID().toString().take(8)}",
                                transactionId = "DIV-$ticker-${System.currentTimeMillis()}",
                                accountId = accId,
                                isDebit = true,
                                type = "CASH",
                                ticker = "GBP",
                                amount = payout,
                                balanceAfter = newCash,
                                description = "Corporate Dividend Payout for $ticker @ £${String.format("%.2f", dividendPerShare)}/share"
                            )
                        )
                    }
                }
            }
        }
    }

    fun performAudit(): Pair<Boolean, String> {
        var currentSystemCash = 0.0
        accountsMap.values.forEach { currentSystemCash += it.cashBalance }

        val cashDiscrepancy = (currentSystemCash + totalFeesCollected) - totalSystemInitialCash
        val isCashBalanced = Math.abs(cashDiscrepancy) < 0.01

        var shareIssuesBalanced = true
        val shareAuditLog = StringBuilder()

        totalIssuedSharesMap.forEach { (ticker, expectedIssued) ->
            var actualSharesInAccounts = 0L
            positionsMap.values.forEach { userPosMap ->
                userPosMap[ticker]?.let { actualSharesInAccounts += it.quantity }
            }
            if (actualSharesInAccounts != expectedIssued) {
                shareIssuesBalanced = false
                shareAuditLog.append("[$ticker Mismatch: Expected $expectedIssued, Found $actualSharesInAccounts] ")
            }
        }

        val isValid = isCashBalanced && shareIssuesBalanced
        val msg = if (isValid) {
            "AUDIT SUCCESS: Double-entry ledger invariants preserved. System Cash: £${String.format("%.2f", currentSystemCash)}, Exchange Fees: £${String.format("%.2f", totalFeesCollected)}, Cash Balance Error: £${String.format("%.4f", cashDiscrepancy)}."
        } else {
            "AUDIT WARNING: Cash Discrepancy: £${String.format("%.2f", cashDiscrepancy)}. Share Audit: $shareAuditLog"
        }

        return Pair(isValid, msg)
    }

    fun getLedgerEntries(accountId: String? = null): List<LedgerEntry> {
        return if (accountId == null) {
            ledgerEntries.reversed()
        } else {
            ledgerEntries.filter { it.accountId == accountId }.reversed()
        }
    }

    fun getTotalFeesCollected(): Double = totalFeesCollected
}
