package com.example.nsx.engine

import com.example.nsx.model.MarketSession

class MarketClock {
    var simulatedTimeMillis: Long = System.currentTimeMillis()
        private set

    var speedMultiplier: Int = 1 // 0 = Pause, 1 = 1x real time, 5 = 5x, 20 = 20x, 100 = 100x
    var currentSession: MarketSession = MarketSession.CONTINUOUS_TRADING
        private set

    private var lastRealTimeTick: Long = System.currentTimeMillis()

    @Synchronized
    fun tick(): Long {
        val now = System.currentTimeMillis()
        val realElapsed = now - lastRealTimeTick
        lastRealTimeTick = now

        if (speedMultiplier > 0) {
            simulatedTimeMillis += (realElapsed * speedMultiplier)
        }
        return simulatedTimeMillis
    }

    fun setSession(session: MarketSession) {
        this.currentSession = session
    }

    fun stepSingleFrame(durationMs: Long = 1000) {
        simulatedTimeMillis += durationMs
    }
}
