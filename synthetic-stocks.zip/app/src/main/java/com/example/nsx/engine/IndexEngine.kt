package com.example.nsx.engine

import com.example.nsx.model.MarketIndex
import com.example.nsx.model.Security
import java.util.concurrent.ConcurrentHashMap

class IndexEngine {

    fun computeIndices(securities: List<Security>): List<MarketIndex> {
        if (securities.isEmpty()) return emptyList()

        val nsx100 = calculateMarketCapWeightedIndex("NSX-100", "Northstar 100 Index", "NSX100", securities, null, 10000.0)
        
        val techSecurities = securities.filter { getSectorForTicker(it.ticker) == "Technology" }
        val nsxTech = calculateMarketCapWeightedIndex("NSX-TECH", "Northstar Tech 20 Index", "NSXTECH", techSecurities, "Technology", 5000.0)

        val indSecurities = securities.filter { getSectorForTicker(it.ticker) == "Industrial" }
        val nsxInd = calculateMarketCapWeightedIndex("NSX-IND", "Northstar Industrial Index", "NSXIND", indSecurities, "Industrial", 4500.0)

        val energySecurities = securities.filter { getSectorForTicker(it.ticker) == "Energy" }
        val nsxEnergy = calculateMarketCapWeightedIndex("NSX-ENERGY", "Northstar Energy Index", "NSXENG", energySecurities, "Energy", 3800.0)

        val finSecurities = securities.filter { getSectorForTicker(it.ticker) == "Financial" }
        val nsxFin = calculateMarketCapWeightedIndex("NSX-FIN", "Northstar Financial Index", "NSXFIN", finSecurities, "Financial", 4200.0)

        return listOf(nsx100, nsxTech, nsxInd, nsxEnergy, nsxFin)
    }

    private fun calculateMarketCapWeightedIndex(
        id: String,
        name: String,
        ticker: String,
        secs: List<Security>,
        filterSector: String?,
        baseValue: Double
    ): MarketIndex {
        if (secs.isEmpty()) {
            return MarketIndex(id, name, ticker, baseValue, 0.0, 0.0, emptyList())
        }

        var totalCurrentCap = 0.0
        var totalPrevCloseCap = 0.0

        secs.forEach { sec ->
            val shares = sec.shareCount
            totalCurrentCap += sec.lastPrice * shares
            totalPrevCloseCap += sec.prevClose * shares
        }

        val changePct = if (totalPrevCloseCap > 0) ((totalCurrentCap - totalPrevCloseCap) / totalPrevCloseCap) * 100 else 0.0
        val value = baseValue * (1 + (changePct / 100))
        val change = value - baseValue

        return MarketIndex(
            id = id,
            name = name,
            ticker = ticker,
            value = Math.round(value * 100.0) / 100.0,
            change = Math.round(change * 100.0) / 100.0,
            changePercent = Math.round(changePct * 100.0) / 100.0,
            constituents = secs.map { it.ticker }
        )
    }

    private fun getSectorForTicker(ticker: String): String {
        return when (ticker.take(2)) {
            "AU", "AT", "CP" -> "Technology"
            "BR", "SH", "NS" -> "Industrial"
            "ME", "HE" -> "Energy"
            "CR", "AN" -> "Financial"
            else -> "Technology"
        }
    }
}
