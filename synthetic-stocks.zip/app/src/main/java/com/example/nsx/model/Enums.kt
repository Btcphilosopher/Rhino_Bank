package com.example.nsx.model

enum class Side {
    BUY,
    SELL
}

enum class OrderType {
    LIMIT,
    MARKET,
    STOP,
    STOP_LIMIT,
    IOC, // Immediate-or-Cancel
    FOK  // Fill-or-Kill
}

enum class TimeInForce {
    DAY,
    GTC, // Good 'Til Cancelled
    IOC,
    FOK
}

enum class OrderStatus {
    NEW,
    PARTIALLY_FILLED,
    FILLED,
    CANCELLED,
    REJECTED,
    EXPIRED
}

enum class ParticipantType {
    RETAIL,
    INSTITUTIONAL,
    MARKET_MAKER,
    HEDGE_FUND,
    PENSION_FUND,
    CORPORATE,
    USER
}

enum class MarketSession {
    PRE_MARKET,
    OPENING_AUCTION,
    CONTINUOUS_TRADING,
    CLOSING_AUCTION,
    POST_MARKET,
    HALTED
}

enum class SimulationMode {
    NORMAL,
    BULL,
    BEAR,
    CRISIS,
    BUBBLE,
    LIQUIDITY_SHOCK,
    RECOVERY
}

enum class CorporateActionType {
    DIVIDEND,
    STOCK_SPLIT,
    REVERSE_SPLIT,
    BUYBACK,
    NEW_ISSUE
}

enum class SettlementStatus {
    PENDING,
    CLEARED,
    SETTLED,
    FAILED
}

enum class NewsImpact {
    POSITIVE,
    NEGATIVE,
    NEUTRAL
}
