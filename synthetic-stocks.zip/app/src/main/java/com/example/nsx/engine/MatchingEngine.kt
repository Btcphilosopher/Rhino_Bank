package com.example.nsx.engine

import com.example.nsx.model.Order
import com.example.nsx.model.OrderBookLevel
import com.example.nsx.model.OrderBookSnapshot
import com.example.nsx.model.OrderStatus
import com.example.nsx.model.OrderType
import com.example.nsx.model.Side
import com.example.nsx.model.TimeInForce
import com.example.nsx.model.Trade
import java.util.PriorityQueue
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class MatchingEngine(
    val ticker: String,
    private val ledgerEngine: LedgerEngine
) {
    // Buy Order Queue: Highest price first, then earliest time
    private val bidsQueue = PriorityQueue<Order> { o1, o2 ->
        if (o2.limitPrice != o1.limitPrice) {
            o2.limitPrice.compareTo(o1.limitPrice)
        } else {
            o1.createdAt.compareTo(o2.createdAt)
        }
    }

    // Sell Order Queue: Lowest price first, then earliest time
    private val asksQueue = PriorityQueue<Order> { o1, o2 ->
        if (o1.limitPrice != o2.limitPrice) {
            o1.limitPrice.compareTo(o2.limitPrice)
        } else {
            o1.createdAt.compareTo(o2.createdAt)
        }
    }

    private val activeOrdersMap = ConcurrentHashMap<String, Order>()
    private val stopOrdersList = CopyOnWriteArrayList<Order>()
    private val tradeHistory = CopyOnWriteArrayList<Trade>()

    @Synchronized
    fun submitOrder(incomingOrder: Order): List<Trade> {
        val executedTrades = mutableListOf<Trade>()

        // Pre-order check
        if (incomingOrder.quantity <= 0) {
            cancelOrRejectOrder(incomingOrder, OrderStatus.REJECTED, "Invalid quantity")
            return emptyList()
        }

        // FOK Validation: Check if complete fill is possible
        if (incomingOrder.orderType == OrderType.FOK || incomingOrder.timeInForce == TimeInForce.FOK) {
            if (!canFulfillFOK(incomingOrder)) {
                cancelOrRejectOrder(incomingOrder, OrderStatus.CANCELLED, "FOK liquidity insufficient")
                return emptyList()
            }
        }

        // Handle Stop Orders
        if (incomingOrder.orderType == OrderType.STOP || incomingOrder.orderType == OrderType.STOP_LIMIT) {
            stopOrdersList.add(incomingOrder)
            activeOrdersMap[incomingOrder.orderId] = incomingOrder
            return emptyList()
        }

        var order = incomingOrder.copy(status = OrderStatus.NEW)
        activeOrdersMap[order.orderId] = order

        // Reserve Cash/Shares in Ledger
        val reservedOk = reserveOrderCollateral(order)
        if (!reservedOk) {
            cancelOrRejectOrder(order, OrderStatus.REJECTED, "Insufficient funds or positions")
            return emptyList()
        }

        // Matching process
        if (order.side == Side.BUY) {
            while (order.remainingQuantity > 0 && asksQueue.isNotEmpty()) {
                val bestAsk = asksQueue.peek() ?: break

                // Price condition for Limit orders
                if (order.orderType != OrderType.MARKET && order.limitPrice < bestAsk.limitPrice) {
                    break // Price threshold reached
                }

                val matchPrice = bestAsk.limitPrice
                val fillQty = minOf(order.remainingQuantity, bestAsk.remainingQuantity)

                val trade = Trade(
                    tradeId = "TRD-${UUID.randomUUID().toString().take(8)}",
                    ticker = ticker,
                    buyerAccountId = order.accountId,
                    sellerAccountId = bestAsk.accountId,
                    price = matchPrice,
                    quantity = fillQty
                )

                ledgerEngine.recordTradeExecution(trade)
                executedTrades.add(trade)
                tradeHistory.add(trade)

                // Update Buy Order state
                val newBuyFilled = order.filledQuantity + fillQty
                val buyStatus = if (newBuyFilled == order.quantity) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED
                order = order.copy(filledQuantity = newBuyFilled, status = buyStatus, updatedAt = System.currentTimeMillis())
                activeOrdersMap[order.orderId] = order

                // Update Ask Order state
                asksQueue.poll() // Remove best ask
                val newAskFilled = bestAsk.filledQuantity + fillQty
                val askStatus = if (newAskFilled == bestAsk.quantity) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED
                val updatedAsk = bestAsk.copy(filledQuantity = newAskFilled, status = askStatus, updatedAt = System.currentTimeMillis())

                if (updatedAsk.status == OrderStatus.FILLED) {
                    activeOrdersMap[updatedAsk.orderId] = updatedAsk
                } else {
                    activeOrdersMap[updatedAsk.orderId] = updatedAsk
                    asksQueue.add(updatedAsk)
                }

                // Trigger Stop Orders on price movement
                checkStopOrders(matchPrice)
            }

            // Unfilled IOC/Market portion handling
            if (order.remainingQuantity > 0) {
                if (order.orderType == OrderType.IOC || order.timeInForce == TimeInForce.IOC || order.orderType == OrderType.MARKET) {
                    // Unreserve remaining unfilled cash
                    val unreservedNotional = order.remainingQuantity * order.limitPrice
                    if (unreservedNotional > 0) {
                        ledgerEngine.releaseCash(order.accountId, unreservedNotional)
                    }
                    val finalStatus = if (order.filledQuantity > 0) OrderStatus.PARTIALLY_FILLED else OrderStatus.CANCELLED
                    order = order.copy(status = finalStatus, updatedAt = System.currentTimeMillis())
                    activeOrdersMap[order.orderId] = order
                } else {
                    bidsQueue.add(order)
                }
            }
        } else { // SELL Side
            while (order.remainingQuantity > 0 && bidsQueue.isNotEmpty()) {
                val bestBid = bidsQueue.peek() ?: break

                if (order.orderType != OrderType.MARKET && order.limitPrice > bestBid.limitPrice) {
                    break
                }

                val matchPrice = bestBid.limitPrice
                val fillQty = minOf(order.remainingQuantity, bestBid.remainingQuantity)

                val trade = Trade(
                    tradeId = "TRD-${UUID.randomUUID().toString().take(8)}",
                    ticker = ticker,
                    buyerAccountId = bestBid.accountId,
                    sellerAccountId = order.accountId,
                    price = matchPrice,
                    quantity = fillQty
                )

                ledgerEngine.recordTradeExecution(trade)
                executedTrades.add(trade)
                tradeHistory.add(trade)

                // Update Sell Order state
                val newSellFilled = order.filledQuantity + fillQty
                val sellStatus = if (newSellFilled == order.quantity) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED
                order = order.copy(filledQuantity = newSellFilled, status = sellStatus, updatedAt = System.currentTimeMillis())
                activeOrdersMap[order.orderId] = order

                // Update Best Bid state
                bidsQueue.poll()
                val newBidFilled = bestBid.filledQuantity + fillQty
                val bidStatus = if (newBidFilled == bestBid.quantity) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED
                val updatedBid = bestBid.copy(filledQuantity = newBidFilled, status = bidStatus, updatedAt = System.currentTimeMillis())

                if (updatedBid.status == OrderStatus.FILLED) {
                    activeOrdersMap[updatedBid.orderId] = updatedBid
                } else {
                    activeOrdersMap[updatedBid.orderId] = updatedBid
                    bidsQueue.add(updatedBid)
                }

                checkStopOrders(matchPrice)
            }

            if (order.remainingQuantity > 0) {
                if (order.orderType == OrderType.IOC || order.timeInForce == TimeInForce.IOC || order.orderType == OrderType.MARKET) {
                    ledgerEngine.releaseShares(order.accountId, ticker, order.remainingQuantity)
                    val finalStatus = if (order.filledQuantity > 0) OrderStatus.PARTIALLY_FILLED else OrderStatus.CANCELLED
                    order = order.copy(status = finalStatus, updatedAt = System.currentTimeMillis())
                    activeOrdersMap[order.orderId] = order
                } else {
                    asksQueue.add(order)
                }
            }
        }

        return executedTrades
    }

    @Synchronized
    fun cancelOrder(orderId: String): Boolean {
        val order = activeOrdersMap[orderId] ?: return false
        if (order.status == OrderStatus.FILLED || order.status == OrderStatus.CANCELLED) return false

        var removed = bidsQueue.removeIf { it.orderId == orderId }
        if (!removed) {
            removed = asksQueue.removeIf { it.orderId == orderId }
        }
        if (!removed) {
            removed = stopOrdersList.removeIf { it.orderId == orderId }
        }

        if (removed || order.status == OrderStatus.NEW || order.status == OrderStatus.PARTIALLY_FILLED) {
            // Release Collateral
            if (order.side == Side.BUY) {
                val unreservedNotional = order.remainingQuantity * order.limitPrice
                if (unreservedNotional > 0) {
                    ledgerEngine.releaseCash(order.accountId, unreservedNotional)
                }
            } else {
                ledgerEngine.releaseShares(order.accountId, ticker, order.remainingQuantity)
            }

            activeOrdersMap[orderId] = order.copy(status = OrderStatus.CANCELLED, updatedAt = System.currentTimeMillis())
            return true
        }

        return false
    }

    private fun reserveOrderCollateral(order: Order): Boolean {
        return if (order.side == Side.BUY) {
            val estimatedNotional = if (order.orderType == OrderType.MARKET) {
                // Approximate market buy collateral with 10% buffer above best ask or last price
                val bestAsk = asksQueue.peek()?.limitPrice ?: 100.0
                order.quantity * bestAsk * 1.10
            } else {
                order.quantity * order.limitPrice
            }
            ledgerEngine.reserveCash(order.accountId, estimatedNotional)
        } else {
            ledgerEngine.reserveShares(order.accountId, ticker, order.quantity)
        }
    }

    private fun canFulfillFOK(order: Order): Boolean {
        var avail = 0L
        if (order.side == Side.BUY) {
            for (ask in asksQueue) {
                if (order.orderType == OrderType.MARKET || order.limitPrice >= ask.limitPrice) {
                    avail += ask.remainingQuantity
                    if (avail >= order.quantity) return true
                } else break
            }
        } else {
            for (bid in bidsQueue) {
                if (order.orderType == OrderType.MARKET || order.limitPrice <= bid.limitPrice) {
                    avail += bid.remainingQuantity
                    if (avail >= order.quantity) return true
                } else break
            }
        }
        return false
    }

    private fun checkStopOrders(lastTradedPrice: Double) {
        val triggered = mutableListOf<Order>()
        stopOrdersList.forEach { stopOrd ->
            val isTriggered = if (stopOrd.side == Side.BUY) {
                lastTradedPrice >= stopOrd.stopPrice
            } else {
                lastTradedPrice <= stopOrd.stopPrice
            }
            if (isTriggered) {
                triggered.add(stopOrd)
            }
        }

        triggered.forEach { trigOrd ->
            stopOrdersList.remove(trigOrd)
            val convertedType = if (trigOrd.orderType == OrderType.STOP) OrderType.MARKET else OrderType.LIMIT
            submitOrder(trigOrd.copy(orderType = convertedType))
        }
    }

    private fun cancelOrRejectOrder(order: Order, status: OrderStatus, reason: String) {
        activeOrdersMap[order.orderId] = order.copy(status = status, updatedAt = System.currentTimeMillis())
    }

    @Synchronized
    fun getSnapshot(depth: Int = 10): OrderBookSnapshot {
        val bidsList = bidsQueue.groupBy { it.limitPrice }
            .map { (price, orders) -> OrderBookLevel(price, orders.sumOf { it.remainingQuantity }, orders.size) }
            .sortedByDescending { it.price }
            .take(depth)

        val asksList = asksQueue.groupBy { it.limitPrice }
            .map { (price, orders) -> OrderBookLevel(price, orders.sumOf { it.remainingQuantity }, orders.size) }
            .sortedBy { it.price }
            .take(depth)

        return OrderBookSnapshot(
            ticker = ticker,
            bids = bidsList,
            asks = asksList
        )
    }

    fun getOrder(orderId: String): Order? = activeOrdersMap[orderId]

    fun getRecentTrades(limit: Int = 30): List<Trade> = tradeHistory.takeLast(limit).reversed()
}
