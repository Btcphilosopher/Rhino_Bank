package com.example.nsx.engine

import com.example.nsx.model.Settlement
import com.example.nsx.model.SettlementStatus
import com.example.nsx.model.Trade
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class ClearingSettlementEngine(
    private val ledgerEngine: LedgerEngine
) {
    private val settlementsQueue = CopyOnWriteArrayList<Settlement>()
    var settlementCycleDays: Int = 1 // Default T+1

    fun processTradeForClearing(trade: Trade, currentMarketTimeMillis: Long): Settlement {
        val settlementDateMillis = currentMarketTimeMillis + (settlementCycleDays * 24 * 3600 * 1000L)
        val settlement = Settlement(
            settlementId = "SETTL-${UUID.randomUUID().toString().take(8)}",
            tradeId = trade.tradeId,
            buyerAccountId = trade.buyerAccountId,
            sellerAccountId = trade.sellerAccountId,
            ticker = trade.ticker,
            quantity = trade.quantity,
            price = trade.price,
            notional = trade.notional,
            settlementDate = settlementDateMillis,
            status = SettlementStatus.CLEARED
        )
        settlementsQueue.add(settlement)
        return settlement
    }

    fun processSettlementsDue(currentMarketTimeMillis: Long): List<Settlement> {
        val due = settlementsQueue.filter { 
            it.status == SettlementStatus.CLEARED && currentMarketTimeMillis >= it.settlementDate 
        }

        val completed = mutableListOf<Settlement>()
        due.forEach { settl ->
            val updated = settl.copy(status = SettlementStatus.SETTLED)
            val index = settlementsQueue.indexOf(settl)
            if (index >= 0) {
                settlementsQueue[index] = updated
                completed.add(updated)
            }
        }
        return completed
    }

    fun getSettlementQueue(): List<Settlement> = settlementsQueue.toList().reversed()
}
