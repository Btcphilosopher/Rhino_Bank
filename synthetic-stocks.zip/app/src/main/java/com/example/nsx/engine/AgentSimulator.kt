package com.example.nsx.engine

import com.example.nsx.model.Account
import com.example.nsx.model.Order
import com.example.nsx.model.OrderType
import com.example.nsx.model.ParticipantType
import com.example.nsx.model.Security
import com.example.nsx.model.Side
import com.example.nsx.model.SimulationMode
import com.example.nsx.model.TimeInForce
import java.util.Random
import java.util.UUID

class AgentSimulator(
    private val ledgerEngine: LedgerEngine,
    private val matchingEngines: Map<String, MatchingEngine>
) {
    var mode: SimulationMode = SimulationMode.NORMAL
    var tradingIntensity: Double = 1.0 // Multiplier
    private val random = Random()

    private val marketMakerAccounts = mutableListOf<Account>()
    private val institutionalAccounts = mutableListOf<Account>()
    private val retailAccounts = mutableListOf<Account>()

    fun initializeAgents(
        mmCount: Int = 10,
        instCount: Int = 20,
        retailCount: Int = 100
    ) {
        val initialAccounts = mutableListOf<Account>()
        val initialShares = mutableMapOf<String, Long>()

        // Market Makers
        for (i in 1..mmCount) {
            val acc = Account(
                accountId = "MM-${String.format("%03d", i)}",
                participantId = "PART-MM-$i",
                name = "Northstar Market Maker $i",
                type = ParticipantType.MARKET_MAKER,
                cashBalance = 50_000_000.0 // £50M capital
            )
            marketMakerAccounts.add(acc)
            initialAccounts.add(acc)
        }

        // Institutional
        for (i in 1..instCount) {
            val acc = Account(
                accountId = "INST-${String.format("%03d", i)}",
                participantId = "PART-INST-$i",
                name = "Apex Institutional Fund $i",
                type = ParticipantType.INSTITUTIONAL,
                cashBalance = 20_000_000.0 // £20M
            )
            institutionalAccounts.add(acc)
            initialAccounts.add(acc)
        }

        // Retail
        for (i in 1..retailCount) {
            val acc = Account(
                accountId = "RET-${String.format("%04d", i)}",
                participantId = "PART-RET-$i",
                name = "Retail Trader $i",
                type = ParticipantType.RETAIL,
                cashBalance = 100_000.0 // £100k
            )
            retailAccounts.add(acc)
            initialAccounts.add(acc)
        }

        ledgerEngine.initializeAccounts(initialAccounts, initialShares)

        // Grant initial shares to Market Makers & Institutions so they can provide liquidity
        matchingEngines.keys.forEach { ticker ->
            marketMakerAccounts.forEach { mm ->
                ledgerEngine.setInitialPosition(mm.accountId, ticker, 50_000L, 100.0)
            }
            institutionalAccounts.take(5).forEach { inst ->
                ledgerEngine.setInitialPosition(inst.accountId, ticker, 20_000L, 100.0)
            }
        }
    }

    /**
     * Simulation tick cycle called periodically.
     * Generates quotes from Market Makers and orders from agents based on simulation mode.
     */
    fun runSimulationStep(securities: List<Security>): Int {
        if (securities.isEmpty()) return 0
        var ordersGenerated = 0

        val selectedSecurity = securities[random.nextInt(securities.size)]
        val matchingEngine = matchingEngines[selectedSecurity.ticker] ?: return 0

        // 1. Market Maker Quoting Routine
        val mm = marketMakerAccounts[random.nextInt(marketMakerAccounts.size)]
        val basePrice = selectedSecurity.lastPrice
        val spreadPct = when (mode) {
            SimulationMode.CRISIS, SimulationMode.LIQUIDITY_SHOCK -> 0.025 // Wide 2.5% spread
            SimulationMode.NORMAL -> 0.004 // Tight 0.4% spread
            else -> 0.008
        }

        val halfSpread = basePrice * (spreadPct / 2.0)
        val bidPrice = Math.round((basePrice - halfSpread) * 20.0) / 20.0
        val askPrice = Math.round((basePrice + halfSpread) * 20.0) / 20.0

        if (bidPrice > 0 && askPrice > bidPrice) {
            val bidQty = (random.nextInt(20) + 5) * 100L
            val askQty = (random.nextInt(20) + 5) * 100L

            val bidOrder = Order(
                orderId = "ORD-${UUID.randomUUID().toString().take(8)}",
                accountId = mm.accountId,
                ticker = selectedSecurity.ticker,
                side = Side.BUY,
                orderType = OrderType.LIMIT,
                quantity = bidQty,
                limitPrice = bidPrice,
                timeInForce = TimeInForce.DAY
            )

            val askOrder = Order(
                orderId = "ORD-${UUID.randomUUID().toString().take(8)}",
                accountId = mm.accountId,
                ticker = selectedSecurity.ticker,
                side = Side.SELL,
                orderType = OrderType.LIMIT,
                quantity = askQty,
                limitPrice = askPrice,
                timeInForce = TimeInForce.DAY
            )

            matchingEngine.submitOrder(bidOrder)
            matchingEngine.submitOrder(askOrder)
            ordersGenerated += 2
        }

        // 2. Directional Trader Routine
        val side = when (mode) {
            SimulationMode.BULL, SimulationMode.BUBBLE -> if (random.nextDouble() < 0.70) Side.BUY else Side.SELL
            SimulationMode.BEAR, SimulationMode.CRISIS -> if (random.nextDouble() < 0.70) Side.SELL else Side.BUY
            else -> if (random.nextBoolean()) Side.BUY else Side.SELL
        }

        val traderAcc = if (random.nextDouble() < 0.7) {
            retailAccounts[random.nextInt(retailAccounts.size)]
        } else {
            institutionalAccounts[random.nextInt(institutionalAccounts.size)]
        }

        val isMarketOrder = random.nextDouble() < 0.35
        val qty = (random.nextInt(10) + 1) * 100L
        val limitOffset = (random.nextDouble() - 0.5) * 0.02 * basePrice
        val targetPrice = Math.round((basePrice + limitOffset) * 20.0) / 20.0

        if (targetPrice > 0) {
            val traderOrder = Order(
                orderId = "ORD-${UUID.randomUUID().toString().take(8)}",
                accountId = traderAcc.accountId,
                ticker = selectedSecurity.ticker,
                side = side,
                orderType = if (isMarketOrder) OrderType.MARKET else OrderType.LIMIT,
                quantity = qty,
                limitPrice = if (isMarketOrder) 0.0 else targetPrice,
                timeInForce = TimeInForce.DAY
            )

            matchingEngine.submitOrder(traderOrder)
            ordersGenerated++
        }

        return ordersGenerated
    }
}
