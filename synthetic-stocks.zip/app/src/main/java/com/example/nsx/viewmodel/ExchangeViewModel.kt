package com.example.nsx.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.nsx.model.BacktestResult
import com.example.nsx.model.OrderType
import com.example.nsx.model.Side
import com.example.nsx.model.SimulationMode
import com.example.nsx.model.TimeInForce
import com.example.nsx.repository.ExchangeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ExchangeViewModel(
    val repository: ExchangeRepository = ExchangeRepository()
) : ViewModel() {

    val securities = repository.securitiesState
    val selectedTicker = repository.selectedTicker
    val selectedSecurity = repository.selectedSecurity
    val orderBook = repository.orderBookState
    val trades = repository.tradesState
    val candles = repository.candlesState
    val userAccount = repository.userAccountState
    val userPositions = repository.userPositionsState
    val ledgerEntries = repository.ledgerState
    val indices = repository.indicesState
    val news = repository.newsState
    val settlements = repository.settlementsState
    val metrics = repository.metricsState
    val auditReport = repository.auditReport

    // UI Feedback Message
    private val _snackMessage = MutableStateFlow<String?>(null)
    val snackMessage: StateFlow<String?> = _snackMessage.asStateFlow()

    // CLI Command Terminal Output
    private val _cliLogs = MutableStateFlow(
        listOf(
            "NORTHSTAR SECURITIES EXCHANGE (NSX) CLI v1.0.0",
            "Type 'help' or 'nsx market AURE' or 'nsx audit' to execute commands.",
            "Ready."
        )
    )
    val cliLogs: StateFlow<List<String>> = _cliLogs.asStateFlow()

    // Backtest Result
    private val _backtestResult = MutableStateFlow<BacktestResult?>(null)
    val backtestResult: StateFlow<BacktestResult?> = _backtestResult.asStateFlow()

    fun selectSecurity(ticker: String) {
        repository.selectTicker(ticker)
    }

    fun submitOrder(
        ticker: String,
        side: Side,
        orderType: OrderType,
        quantity: Long,
        limitPrice: Double,
        stopPrice: Double = 0.0,
        tif: TimeInForce = TimeInForce.DAY
    ) {
        viewModelScope.launch {
            val result = repository.submitUserOrder(ticker, side, orderType, quantity, limitPrice, stopPrice, tif)
            _snackMessage.value = result.second
        }
    }

    fun cancelOrder(orderId: String) {
        viewModelScope.launch {
            val result = repository.cancelUserOrder(orderId)
            _snackMessage.value = result.second
        }
    }

    fun runAudit() {
        val msg = repository.runAudit()
        _snackMessage.value = msg
    }

    fun setSimulationMode(mode: SimulationMode) {
        repository.setSimulationMode(mode)
        _snackMessage.value = "Market Simulation Mode set to: ${mode.name}"
    }

    fun setSimulationSpeed(speed: Int) {
        repository.marketClock.speedMultiplier = speed
        _snackMessage.value = "Exchange Clock Speed set to ${speed}x"
    }

    fun declareDividend(ticker: String, amountPerShare: Double) {
        repository.triggerCorporateDividend(ticker, amountPerShare)
        _snackMessage.value = "Corporate Dividend declared for $ticker (£${amountPerShare}/share)"
    }

    fun runStrategyBacktest(strategyName: String, ticker: String) {
        val result = repository.runBacktest(strategyName, ticker)
        _backtestResult.value = result
        _snackMessage.value = "Backtest Completed for $strategyName on $ticker. Return: ${result.totalReturnPct}%, Sharpe: ${result.sharpeRatio}"
    }

    fun clearSnackMessage() {
        _snackMessage.value = null
    }

    fun executeCliCommand(cmd: String) {
        val trimmed = cmd.trim()
        val current = _cliLogs.value.toMutableList()
        current.add("> $trimmed")

        val parts = trimmed.split("\\s+".toRegex())
        val head = parts.firstOrNull()?.lowercase() ?: ""

        when {
            head == "help" -> {
                current.add("Available Commands:")
                current.add("  nsx market <ticker>          - View market summary for security")
                current.add("  nsx book <ticker>            - View Level 2 Order Book snapshot")
                current.add("  nsx portfolio                - View cash & positions")
                current.add("  nsx audit                    - Run double-entry ledger audit check")
                current.add("  nsx order <ticker> BUY|SELL LIMIT|MARKET <qty> <price>")
                current.add("  nsx backtest <ticker> SMA_CROSSOVER|MEAN_REVERSION")
                current.add("  clear                        - Clear terminal logs")
            }
            head == "clear" -> {
                current.clear()
                current.add("Terminal cleared.")
            }
            head == "nsx" && parts.size >= 2 -> {
                val sub = parts[1].lowercase()
                when (sub) {
                    "market" -> {
                        val t = parts.getOrNull(2)?.uppercase() ?: selectedTicker.value
                        val sec = securities.value.find { it.ticker == t }
                        if (sec != null) {
                            current.add("MARKET [${sec.ticker}] - ${sec.issuerId}: Last £${sec.lastPrice} (${sec.changePercent}%), Vol: ${sec.volume}, VWAP: £${String.format("%.2f", sec.vwap)}")
                        } else current.add("Security $t not found.")
                    }
                    "book" -> {
                        val t = parts.getOrNull(2)?.uppercase() ?: selectedTicker.value
                        val snap = orderBook.value
                        if (snap != null && snap.ticker == t) {
                            current.add("ORDER BOOK SNAPSHOT FOR $t (Spread: £${String.format("%.2f", snap.spread)})")
                            current.add("ASKS: " + snap.asks.take(3).joinToString(" | ") { "£${it.price}x${it.quantity}" })
                            current.add("BIDS: " + snap.bids.take(3).joinToString(" | ") { "£${it.price}x${it.quantity}" })
                        } else current.add("Order book snapshot unavailable for $t.")
                    }
                    "portfolio" -> {
                        val acc = userAccount.value
                        current.add("ACCOUNT ${acc.accountId} [${acc.name}]")
                        current.add("Cash: £${String.format("%.2f", acc.cashBalance)} (Available: £${String.format("%.2f", acc.availableCash)})")
                        val posList = userPositions.value
                        posList.forEach { pos ->
                            current.add("  ${pos.ticker}: ${pos.quantity} shares @ avg £${String.format("%.2f", pos.avgCost)} (Mkt: £${String.format("%.2f", pos.marketValue)}, P&L: £${String.format("%.2f", pos.unrealizedPnL)})")
                        }
                    }
                    "audit" -> {
                        val res = repository.runAudit()
                        current.add(res)
                    }
                    "order" -> {
                        // nsx order AURE BUY LIMIT 500 84.25
                        if (parts.size >= 7) {
                            val t = parts[2].uppercase()
                            val side = if (parts[3].uppercase() == "BUY") Side.BUY else Side.SELL
                            val type = if (parts[4].uppercase() == "MARKET") OrderType.MARKET else OrderType.LIMIT
                            val qty = parts[5].toLongOrNull() ?: 100L
                            val px = parts[6].toDoubleOrNull() ?: 100.0
                            submitOrder(t, side, type, qty, px)
                            current.add("Order submitted for $t $side $qty shares @ £$px")
                        } else {
                            current.add("Usage: nsx order <ticker> BUY|SELL LIMIT|MARKET <qty> <price>")
                        }
                    }
                    "backtest" -> {
                        val t = parts.getOrNull(2)?.uppercase() ?: selectedTicker.value
                        val strat = parts.getOrNull(3)?.uppercase() ?: "SMA_CROSSOVER"
                        runStrategyBacktest(strat, t)
                        current.add("Backtest launched for $strat on $t. Check Backtest tab.")
                    }
                    else -> current.add("Unknown subcommand '$sub'. Type 'help' for guidance.")
                }
            }
            else -> current.add("Unrecognized command. Type 'help' for available CLI commands.")
        }

        _cliLogs.value = current
    }
}
