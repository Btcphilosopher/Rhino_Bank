package com.example.nsx.engine

import com.example.nsx.model.Candle
import com.example.nsx.model.Trade
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class CandleEngine {
    // Ticker -> Interval -> List<Candle>
    private val candleStore = ConcurrentHashMap<String, ConcurrentHashMap<String, CopyOnWriteArrayList<Candle>>>()

    fun processTrade(trade: Trade) {
        val intervals = listOf(
            "1s" to 1000L,
            "1m" to 60_000L,
            "5m" to 300_000L,
            "1h" to 3600_000L,
            "1d" to 86400_000L
        )

        intervals.forEach { (intervalName, intervalMs) ->
            val bucketTimestamp = (trade.timestamp / intervalMs) * intervalMs
            val tickerCandles = candleStore
                .computeIfAbsent(trade.ticker) { ConcurrentHashMap() }
                .computeIfAbsent(intervalName) { CopyOnWriteArrayList() }

            val existingIndex = tickerCandles.indexOfLast { it.timestamp == bucketTimestamp }

            if (existingIndex >= 0) {
                val current = tickerCandles[existingIndex]
                val newHigh = maxOf(current.high, trade.price)
                val newLow = minOf(current.low, trade.price)
                val newVolume = current.volume + trade.quantity
                val newTradeCount = current.tradeCount + 1
                val totalNotional = (current.vwap * current.volume) + trade.notional
                val newVwap = if (newVolume > 0) totalNotional / newVolume else trade.price

                tickerCandles[existingIndex] = current.copy(
                    high = newHigh,
                    low = newLow,
                    close = trade.price,
                    volume = newVolume,
                    vwap = newVwap,
                    tradeCount = newTradeCount
                )
            } else {
                val newCandle = Candle(
                    ticker = trade.ticker,
                    interval = intervalName,
                    timestamp = bucketTimestamp,
                    open = trade.price,
                    high = trade.price,
                    low = trade.price,
                    close = trade.price,
                    volume = trade.quantity,
                    vwap = trade.price,
                    tradeCount = 1
                )
                tickerCandles.add(newCandle)
                // Keep max 500 candles per interval
                if (tickerCandles.size > 500) {
                    tickerCandles.removeAt(0)
                }
            }
        }
    }

    fun getCandles(ticker: String, interval: String = "1m"): List<Candle> {
        return candleStore[ticker]?.get(interval)?.toList() ?: emptyList()
    }

    fun seedHistoricalCandles(ticker: String, basePrice: Double, seed: Long) {
        val random = java.util.Random(seed + ticker.hashCode())
        val intervalMs = 60_000L
        val now = System.currentTimeMillis()
        val candlesList = candleStore
            .computeIfAbsent(ticker) { ConcurrentHashMap() }
            .computeIfAbsent("1m") { CopyOnWriteArrayList() }

        var lastPrice = basePrice
        // Generate 120 historical 1-min candles
        for (i in 120 downTo 1) {
            val ts = now - (i * intervalMs)
            val pctChange = (random.nextDouble() - 0.49) * 0.015 // +/- 1.5%
            val open = lastPrice
            val close = (open * (1 + pctChange)).coerceAtLeast(0.10)
            val high = maxOf(open, close) * (1 + random.nextDouble() * 0.005)
            val low = minOf(open, close) * (1 - random.nextDouble() * 0.005)
            val vol = (random.nextInt(50) + 10) * 100L
            val vwap = (open + close + high + low) / 4.0

            candlesList.add(
                Candle(
                    ticker = ticker,
                    interval = "1m",
                    timestamp = ts,
                    open = Math.round(open * 100.0) / 100.0,
                    high = Math.round(high * 100.0) / 100.0,
                    low = Math.round(low * 100.0) / 100.0,
                    close = Math.round(close * 100.0) / 100.0,
                    volume = vol,
                    vwap = Math.round(vwap * 100.0) / 100.0,
                    tradeCount = random.nextInt(25) + 5
                )
            )
            lastPrice = close
        }
    }
}
