package com.example.nsx.engine

import com.example.nsx.model.NewsImpact
import com.example.nsx.model.NewsItem
import java.util.Random
import java.util.UUID

class NewsEngine {
    private val newsList = mutableListOf<NewsItem>()
    private val random = Random()

    private val templates = listOf(
        Triple("Aurelia Computing announces record Q3 AI chip sales", "Aurelia Computing reported quarterly net profit surging 38% YoY on strong global semiconductor demand.", NewsImpact.POSITIVE),
        Triple("Meridian Energy secures offshore wind concession in North Sea", "Meridian Energy awarded exclusive 2.4GW wind development rights, expanding renewable capacity.", NewsImpact.POSITIVE),
        Triple("Crown Logistics affected by global freight supply disruption", "Crown Logistics issues temporary guidance revision following regional port bottleneck delays.", NewsImpact.NEGATIVE),
        Triple("Helios Materials expands European battery recycling facility", "Helios Materials doubles high-purity lithium extraction throughput in new Sheffield plant.", NewsImpact.POSITIVE),
        Triple("Central Bank maintains benchmark interest rates at 4.25%", "Monetary policy committee votes 7-2 to hold rates unchanged, citing stabilizing inflation figures.", NewsImpact.NEUTRAL),
        Triple("Britannia Engineering lands £450M defense modernization contract", "Britannia Engineering signs multi-year defense vehicle overhaul agreement with UK Ministry.", NewsImpact.POSITIVE),
        Triple("Atlantic Systems unveils ultra-low latency optical routing platform", "Atlantic Systems claims breakthrough 800Gbps network processor for enterprise data centers.", NewsImpact.POSITIVE),
        Triple("Anglo Telecom reports stable subscriber growth across fiber network", "Anglo Telecom adds 120,000 net new broadband subscriptions with ARPU rising 2.1%.", NewsImpact.POSITIVE),
        Triple("North Sea Infrastructure completes £1.2B green bond issuance", "Over-subscribed bond offering will fund subsea interconnector power projects through 2030.", NewsImpact.POSITIVE),
        Triple("Sheffield Industrial reports temporary raw material cost inflation", "Sheffield Industrial expects Q4 operating margins to compress by 80 bps due to nickel spikes.", NewsImpact.NEGATIVE)
    )

    fun generateNewsForTicker(ticker: String?): NewsItem {
        val tmpl = templates[random.nextInt(templates.size)]
        val item = NewsItem(
            id = "NEWS-${UUID.randomUUID().toString().take(8)}",
            ticker = ticker,
            headline = tmpl.first,
            summary = tmpl.second,
            impact = tmpl.third
        )
        newsList.add(0, item)
        if (newsList.size > 100) newsList.removeAt(newsList.lastIndex)
        return item
    }

    fun getNewsHistory(): List<NewsItem> = newsList.toList()
}
