package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F172A)
val DarkCardSurface = Color(0xFF1E293B)
val BorderSlate = Color(0xFF334155)

val ElectricCyan = Color(0xFF00E5FF)
val PrimaryBlue = Color(0xFF38BDF8)
val BullGreen = Color(0xFF10B981)
val BearRed = Color(0xFFEF4444)
val WarningGold = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val BidGreenAlpha = Color(0x3310B981)
val AskRedAlpha = Color(0x33EF4444)
