package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nsx.model.OrderType
import com.example.nsx.model.Side
import com.example.nsx.viewmodel.ExchangeViewModel
import com.example.ui.components.DepthChart
import com.example.ui.components.OrderBookView
import com.example.ui.components.StockChart
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.BullGreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TradingTerminalScreen(
    viewModel: ExchangeViewModel
) {
    val securities by viewModel.securities.collectAsState()
    val selectedTicker by viewModel.selectedTicker.collectAsState()
    val selectedSecurity by viewModel.selectedSecurity.collectAsState()
    val orderBook by viewModel.orderBook.collectAsState()
    val trades by viewModel.trades.collectAsState()
    val candles by viewModel.candles.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedSectorFilter by remember { mutableStateOf("ALL") }

    var selectedSide by remember { mutableStateOf(Side.BUY) }
    var selectedOrderType by remember { mutableStateOf(OrderType.LIMIT) }
    var quantityText by remember { mutableStateOf("500") }
    var limitPriceText by remember { mutableStateOf(selectedSecurity?.lastPrice?.toString() ?: "84.25") }

    val filteredSecurities = securities.filter { sec ->
        (selectedSectorFilter == "ALL" || getSectorForTicker(sec.ticker) == selectedSectorFilter) &&
                (sec.ticker.contains(searchQuery, ignoreCase = true) || sec.issuerId.contains(searchQuery, ignoreCase = true))
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("trading_terminal_screen")
    ) {
        // Ticker Selector Header & Filter
        item {
            Text("TRADING TERMINAL", style = MaterialTheme.typography.titleMedium, color = ElectricCyan, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search 100 securities by ticker or name...", color = TextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = DarkCardSurface,
                    focusedContainerColor = DarkCardSurface,
                    unfocusedBorderColor = BorderSlate,
                    focusedBorderColor = ElectricCyan
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            val sectors = listOf("ALL", "Technology", "Industrial", "Energy", "Financial", "Materials")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sectors) { sector ->
                    val isSelected = selectedSectorFilter == sector
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) ElectricCyan else DarkCardSurface,
                                shape = MaterialTheme.shapes.small
                            )
                            .clickable { selectedSectorFilter = sector }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = sector,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Ticker Selector List
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filteredSecurities.take(15)) { sec ->
                    val isSel = sec.ticker == selectedTicker
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSel) ElectricCyan.copy(alpha = 0.25f) else DarkCardSurface,
                                shape = MaterialTheme.shapes.small
                            )
                            .clickable {
                                viewModel.selectSecurity(sec.ticker)
                                limitPriceText = sec.lastPrice.toString()
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${sec.ticker} £${String.format("%.2f", sec.lastPrice)}",
                            color = if (isSel) ElectricCyan else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Active Stock Price Banner
        item {
            selectedSecurity?.let { sec ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(sec.ticker, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(sec.issuerId, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("£${String.format("%.2f", sec.lastPrice)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
                            val isUp = sec.change >= 0
                            val col = if (isUp) BullGreen else BearRed
                            val sign = if (isUp) "+" else ""
                            Text("$sign${String.format("%.2f", sec.change)} ($sign${String.format("%.2f", sec.changePercent)}%)", color = col, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Interactive Candlestick Chart
        item {
            StockChart(candles = candles, ticker = selectedTicker)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Order Book & Depth Ladder
        item {
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    OrderBookView(orderBook = orderBook)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    DepthChart(orderBook = orderBook)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Executable Order Entry Form Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth().testTag("order_entry_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ORDER ENTRY FORM", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Side Selector (BUY vs SELL)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { selectedSide = Side.BUY },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedSide == Side.BUY) BullGreen else DarkCardSurface
                            ),
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.weight(1f).testTag("buy_side_button")
                        ) {
                            Text("BUY", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { selectedSide = Side.SELL },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedSide == Side.SELL) BearRed else DarkCardSurface
                            ),
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.weight(1f).testTag("sell_side_button")
                        ) {
                            Text("SELL", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Order Type Selector
                    val types = listOf(OrderType.LIMIT, OrderType.MARKET, OrderType.STOP, OrderType.IOC, OrderType.FOK)
                    TabRow(
                        selectedTabIndex = types.indexOf(selectedOrderType),
                        containerColor = DarkCardSurface,
                        contentColor = ElectricCyan
                    ) {
                        types.forEach { type ->
                            Tab(
                                selected = selectedOrderType == type,
                                onClick = { selectedOrderType = type },
                                text = { Text(type.name, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = quantityText,
                            onValueChange = { quantityText = it },
                            label = { Text("Quantity") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("quantity_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyan)
                        )
                        if (selectedOrderType != OrderType.MARKET) {
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedTextField(
                                value = limitPriceText,
                                onValueChange = { limitPriceText = it },
                                label = { Text("Limit Price (£)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f).testTag("limit_price_input"),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyan)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val qty = quantityText.toLongOrNull() ?: 0L
                    val px = limitPriceText.toDoubleOrNull() ?: 0.0
                    val estNotional = if (selectedOrderType == OrderType.MARKET) (qty * (selectedSecurity?.lastPrice ?: 0.0)) else (qty * px)
                    val estFee = estNotional * 0.0005

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Est. Notional: £${String.format("%.2f", estNotional)}", color = TextSecondary, fontSize = 12.sp)
                        Text("Est. Fee (5bps): £${String.format("%.2f", estFee)}", color = TextMuted, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.submitOrder(
                                ticker = selectedTicker,
                                side = selectedSide,
                                orderType = selectedOrderType,
                                quantity = qty,
                                limitPrice = px
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedSide == Side.BUY) BullGreen else BearRed
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("submit_order_button")
                    ) {
                        Text("SUBMIT ${selectedSide.name} ORDER", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Live Matched Trade Stream
        item {
            Text("LIVE MATCHED TRADES STREAM", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    trades.take(8).forEach { tr ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("£${String.format("%.2f", tr.price)}", color = BullGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("${tr.quantity} shs", color = TextPrimary, fontSize = 12.sp)
                            Text("£${String.format("%.0f", tr.notional)}", color = TextSecondary, fontSize = 12.sp)
                            Text(tr.tradeId, color = TextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun getSectorForTicker(ticker: String): String {
    return when (ticker.take(2)) {
        "AU", "AT", "CP" -> "Technology"
        "BR", "SH", "MA" -> "Industrial"
        "ME", "HE" -> "Energy"
        "CR", "AN" -> "Financial"
        else -> "Technology"
    }
}
