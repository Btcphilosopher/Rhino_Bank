package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nsx.model.Candle
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.BullGreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun StockChart(
    candles: List<Candle>,
    ticker: String,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(260.dp)
                .background(DarkCardSurface, shape = MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center
        ) {
            Text("Awaiting market trade stream for $ticker...", color = TextMuted, fontSize = 14.sp)
        }
        return
    }

    val displayCandles = candles.takeLast(40)
    val minPrice = displayCandles.minOf { it.low }.coerceAtLeast(0.01)
    val maxPrice = displayCandles.maxOf { it.high }.coerceAtLeast(minPrice + 0.05)
    val maxVolume = displayCandles.maxOf { it.volume }.coerceAtLeast(1L)

    val priceRange = (maxPrice - minPrice).coerceAtLeast(0.1)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkCardSurface, shape = MaterialTheme.shapes.medium)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$ticker CANDLESTICK (1M)",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.width(8.dp).height(8.dp).background(BullGreen))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Up", color = TextSecondary, fontSize = 10.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Box(modifier = Modifier.width(8.dp).height(8.dp).background(BearRed))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Down", color = TextSecondary, fontSize = 10.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Box(modifier = Modifier.width(8.dp).height(2.dp).background(ElectricCyan))
                Spacer(modifier = Modifier.width(4.dp))
                Text("VWAP", color = TextSecondary, fontSize = 10.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            val width = size.width
            val height = size.height
            val candleAreaHeight = height * 0.75f
            val volumeAreaHeight = height * 0.20f
            val candleWidth = width / displayCandles.size
            val barWidth = (candleWidth * 0.65f).coerceAtLeast(2f)

            // Horizontal Grid lines
            val gridStep = candleAreaHeight / 4
            for (i in 0..4) {
                val y = i * gridStep
                drawLine(
                    color = BorderSlate.copy(alpha = 0.4f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
            }

            val vwapPath = Path()
            var vwapStarted = false

            displayCandles.forEachIndexed { index, candle ->
                val x = (index * candleWidth) + (candleWidth / 2f)

                // Price mapping to y
                val openY = candleAreaHeight - (((candle.open - minPrice) / priceRange) * candleAreaHeight).toFloat()
                val closeY = candleAreaHeight - (((candle.close - minPrice) / priceRange) * candleAreaHeight).toFloat()
                val highY = candleAreaHeight - (((candle.high - minPrice) / priceRange) * candleAreaHeight).toFloat()
                val lowY = candleAreaHeight - (((candle.low - minPrice) / priceRange) * candleAreaHeight).toFloat()
                val vwapY = candleAreaHeight - (((candle.vwap - minPrice) / priceRange) * candleAreaHeight).toFloat()

                val isGreen = candle.close >= candle.open
                val candleColor = if (isGreen) BullGreen else BearRed

                // High-Low Wick
                drawLine(
                    color = candleColor,
                    start = Offset(x, highY),
                    end = Offset(x, lowY),
                    strokeWidth = 2f
                )

                // Open-Close Candle Body
                val topY = minOf(openY, closeY)
                val bodyHeight = Math.abs(openY - closeY).coerceAtLeast(3f)
                drawRect(
                    color = candleColor,
                    topLeft = Offset(x - (barWidth / 2f), topY),
                    size = Size(barWidth, bodyHeight)
                )

                // Volume Bar
                val volHeight = ((candle.volume.toFloat() / maxVolume) * volumeAreaHeight)
                drawRect(
                    color = candleColor.copy(alpha = 0.4f),
                    topLeft = Offset(x - (barWidth / 2f), height - volHeight),
                    size = Size(barWidth, volHeight)
                )

                // VWAP Path
                if (!vwapStarted) {
                    vwapPath.moveTo(x, vwapY)
                    vwapStarted = true
                } else {
                    vwapPath.lineTo(x, vwapY)
                }
            }

            // Draw VWAP line overlay
            drawPath(
                path = vwapPath,
                color = ElectricCyan,
                style = Stroke(width = 3f)
            )
        }
    }
}
