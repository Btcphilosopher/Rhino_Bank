package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nsx.model.OrderBookSnapshot
import com.example.ui.theme.AskRedAlpha
import com.example.ui.theme.BearRed
import com.example.ui.theme.BidGreenAlpha
import com.example.ui.theme.BullGreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun OrderBookView(
    orderBook: OrderBookSnapshot?,
    modifier: Modifier = Modifier
) {
    if (orderBook == null) return

    val maxBidQty = orderBook.bids.maxOfOrNull { it.quantity }?.toDouble() ?: 1.0
    val maxAskQty = orderBook.asks.maxOfOrNull { it.quantity }?.toDouble() ?: 1.0

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkCardSurface, shape = MaterialTheme.shapes.medium)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("PRICE (GBP)", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("QTY", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("ORDERS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Asks (Sells) in Red - Displayed Highest to Lowest
        orderBook.asks.take(5).reversed().forEach { ask ->
            val fillPct = (ask.quantity / maxAskQty).toFloat()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(22.dp)
            ) {
                // Background depth bar fill
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fillPct)
                        .height(22.dp)
                        .align(Alignment.CenterEnd)
                        .background(AskRedAlpha)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("£${String.format("%.2f", ask.price)}", color = BearRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("${ask.quantity}", color = TextPrimary, fontSize = 12.sp)
                    Text("${ask.orderCount}", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }

        // Spread indicator
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .background(MaterialTheme.colorScheme.surface)
                .padding(vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "SPREAD: £${String.format("%.2f", orderBook.spread)}",
                color = TextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Bids (Buys) in Green - Displayed Highest to Lowest
        orderBook.bids.take(5).forEach { bid ->
            val fillPct = (bid.quantity / maxBidQty).toFloat()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(22.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fillPct)
                        .height(22.dp)
                        .align(Alignment.CenterStart)
                        .background(BidGreenAlpha)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("£${String.format("%.2f", bid.price)}", color = BullGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("${bid.quantity}", color = TextPrimary, fontSize = 12.sp)
                    Text("${bid.orderCount}", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}
