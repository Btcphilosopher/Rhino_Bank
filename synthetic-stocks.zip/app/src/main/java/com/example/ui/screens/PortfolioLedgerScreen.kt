package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nsx.viewmodel.ExchangeViewModel
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PortfolioLedgerScreen(
    viewModel: ExchangeViewModel
) {
    val account by viewModel.userAccount.collectAsState()
    val positions by viewModel.userPositions.collectAsState()
    val ledgerEntries by viewModel.ledgerEntries.collectAsState()
    val settlements by viewModel.settlements.collectAsState()
    val auditReport by viewModel.auditReport.collectAsState()

    val totalPositionsValue = positions.sumOf { it.marketValue }
    val totalUnrealizedPnL = positions.sumOf { it.unrealizedPnL }
    val totalEquity = account.cashBalance + totalPositionsValue

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("portfolio_ledger_screen")
    ) {
        // Portfolio Overview Header Card
        item {
            Text("PORTFOLIO & DOUBLE-ENTRY LEDGER", style = MaterialTheme.typography.titleMedium, color = ElectricCyan, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth().testTag("portfolio_summary_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(account.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("Account ID: ${account.accountId}", style = MaterialTheme.typography.bodySmall, color = TextMuted)

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TOTAL EQUITY", color = TextMuted, fontSize = 11.sp)
                            Text("£${String.format("%.2f", totalEquity)}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("UNREALIZED P&L", color = TextMuted, fontSize = 11.sp)
                            val isUp = totalUnrealizedPnL >= 0
                            val col = if (isUp) BullGreen else BearRed
                            val sign = if (isUp) "+" else ""
                            Text("$sign£${String.format("%.2f", totalUnrealizedPnL)}", color = col, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Cash Balance: £${String.format("%.2f", account.cashBalance)}", color = TextSecondary, fontSize = 12.sp)
                        Text("Available: £${String.format("%.2f", account.availableCash)}", color = ElectricCyan, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Active Share Positions Section
        item {
            Text("ACTIVE SECURITIES POSITIONS", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (positions.isEmpty()) {
            item {
                Text("No active securities positions held.", color = TextMuted, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(16.dp))
            }
        } else {
            items(positions) { pos ->
                val isUp = pos.unrealizedPnL >= 0
                val pnlCol = if (isUp) BullGreen else BearRed
                val sign = if (isUp) "+" else ""

                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(pos.ticker, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                            Text("${pos.quantity} shares @ avg £${String.format("%.2f", pos.avgCost)}", color = TextMuted, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("£${String.format("%.2f", pos.marketValue)}", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                            Text("$sign£${String.format("%.2f", pos.unrealizedPnL)} ($sign${String.format("%.2f", pos.unrealizedPnLPercent)}%)", color = pnlCol, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Double-Entry Ledger Audit Section
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("DOUBLE-ENTRY CASH & SHARE LEDGER", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.weight(1f))
                Button(
                    onClick = { viewModel.runAudit() },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.testTag("run_audit_button")
                ) {
                    Text("AUDIT INVARIANTS", color = MaterialTheme.colorScheme.onPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Audit Report Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth().testTag("audit_report_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("LEDGER INVARIANT AUDIT REPORT", color = ElectricCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(auditReport, color = TextPrimary, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        // Ledger Postings List
        items(ledgerEntries.take(15)) { entry ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.extraSmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(entry.description, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Text("Txn: ${entry.transactionId} • ${entry.type}", color = TextMuted, fontSize = 10.sp)
                    }
                    val amtCol = if (entry.isDebit) BullGreen else BearRed
                    val sign = if (entry.isDebit) "+" else "-"
                    Text(
                        "$sign${if (entry.type == "CASH") "£" else ""}${String.format("%.2f", entry.amount)}",
                        color = amtCol,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Settlement Queue
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text("CLEARING & T+1 SETTLEMENT QUEUE", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(settlements.take(5)) { settl ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.extraSmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("${settl.ticker} • ${settl.quantity} shs @ £${settl.price}", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Buyer: ${settl.buyerAccountId} | Seller: ${settl.sellerAccountId}", color = TextMuted, fontSize = 10.sp)
                    }
                    Box(
                        modifier = Modifier
                            .background(ElectricCyan.copy(alpha = 0.2f), shape = MaterialTheme.shapes.extraSmall)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(settl.status.name, color = ElectricCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
