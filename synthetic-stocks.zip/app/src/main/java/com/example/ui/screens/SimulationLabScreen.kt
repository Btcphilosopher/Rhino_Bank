package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nsx.model.SimulationMode
import com.example.nsx.viewmodel.ExchangeViewModel
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SimulationLabScreen(
    viewModel: ExchangeViewModel
) {
    val selectedTicker by viewModel.selectedTicker.collectAsState()
    val backtestResult by viewModel.backtestResult.collectAsState()

    var selectedMode by remember { mutableStateOf(SimulationMode.NORMAL) }
    var selectedSpeed by remember { mutableStateOf(1) }
    var selectedStrategy by remember { mutableStateOf("SMA_CROSSOVER") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("simulation_lab_screen")
    ) {
        item {
            Text("MARKET SIMULATOR & BACKTESTING LAB", style = MaterialTheme.typography.titleMedium, color = ElectricCyan, fontWeight = FontWeight.Bold)
            Text("DETERMINISTIC MARKET REPLAY • SEED: NSX-DEMO-2027", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Clock Speed Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth().testTag("simulation_clock_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("EXCHANGE CLOCK SPEED", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val speeds = listOf(0 to "PAUSE", 1 to "1x", 5 to "5x", 20 to "20x", 100 to "100x")
                        speeds.forEach { (sp, label) ->
                            val isSel = selectedSpeed == sp
                            Button(
                                onClick = {
                                    selectedSpeed = sp
                                    viewModel.setSimulationSpeed(sp)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) ElectricCyan else DarkCardSurface
                                ),
                                shape = MaterialTheme.shapes.small,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) MaterialTheme.colorScheme.onPrimary else TextPrimary)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Market Regime Preset Selector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth().testTag("simulation_regime_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("SIMULATION MARKET REGIME", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    val modes = listOf(
                        SimulationMode.NORMAL,
                        SimulationMode.BULL,
                        SimulationMode.BEAR,
                        SimulationMode.CRISIS,
                        SimulationMode.BUBBLE,
                        SimulationMode.LIQUIDITY_SHOCK
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(modes) { m ->
                            val isSel = selectedMode == m
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isSel) ElectricCyan else DarkCardSurface,
                                        shape = MaterialTheme.shapes.small
                                    )
                                    .clickable {
                                        selectedMode = m
                                        viewModel.setSimulationMode(m)
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    m.name,
                                    color = if (isSel) MaterialTheme.colorScheme.onPrimary else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Quantitative Strategy Backtesting Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth().testTag("backtesting_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("QUANTITATIVE STRATEGY BACKTESTER", color = ElectricCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Target Security: $selectedTicker", color = TextSecondary, fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    val strats = listOf("SMA_CROSSOVER", "MEAN_REVERSION", "MARKET_MAKER_ARBITRAGE")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(strats) { st ->
                            val isSel = selectedStrategy == st
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isSel) ElectricCyan else DarkCardSurface,
                                        shape = MaterialTheme.shapes.small
                                    )
                                    .clickable { selectedStrategy = st }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(st, color = if (isSel) MaterialTheme.colorScheme.onPrimary else TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.runStrategyBacktest(selectedStrategy, selectedTicker) },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        modifier = Modifier.fillMaxWidth().testTag("run_backtest_button")
                    ) {
                        Text("LAUNCH STRATEGY BACKTEST", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Backtest Results Display
        item {
            backtestResult?.let { res ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth().testTag("backtest_results_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("BACKTEST PERFORMANCE REPORT [${res.strategyName}]", color = ElectricCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Seed: ${res.seed} • Total Trades: ${res.totalTrades}", color = TextMuted, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("TOTAL RETURN", color = TextMuted, fontSize = 11.sp)
                                val isUp = res.totalReturnPct >= 0
                                val col = if (isUp) BullGreen else BearRed
                                val sign = if (isUp) "+" else ""
                                Text("$sign${res.totalReturnPct}%", color = col, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SHARPE RATIO", color = TextMuted, fontSize = 11.sp)
                                Text("${res.sharpeRatio}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("MAX DRAWDOWN", color = TextMuted, fontSize = 11.sp)
                                Text("${res.maxDrawdownPct}%", color = BearRed, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Win Rate: ${res.winRatePct}%", color = TextSecondary, fontSize = 12.sp)
                            Text("Exchange Fees Paid: £${res.totalFeesPaid}", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
