package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nsx.model.NewsImpact
import com.example.nsx.viewmodel.ExchangeViewModel
import com.example.ui.components.TickerCard
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningGold

@Composable
fun DashboardScreen(
    viewModel: ExchangeViewModel,
    onNavigateToTerminal: (String) -> Unit
) {
    val indices by viewModel.indices.collectAsState()
    val securities by viewModel.securities.collectAsState()
    val newsList by viewModel.news.collectAsState()
    val metrics by viewModel.metrics.collectAsState()

    val topMovers = securities.sortedByDescending { Math.abs(it.changePercent) }.take(6)
    val advancers = securities.count { it.change > 0 }
    val decliners = securities.count { it.change < 0 }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("dashboard_screen")
    ) {
        // Exchange Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NORTHSTAR SECURITIES EXCHANGE",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ElectricCyan
                    )
                    Text(
                        text = "A COMPLETE SYNTHETIC MARKET • NSX EXECUTABLE",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .background(BullGreen.copy(alpha = 0.2f), shape = MaterialTheme.shapes.small)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("CONTINUOUS", color = BullGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Indices Horizontal Slider
        item {
            Text(
                text = "SYNTHETIC INDICES",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(indices) { idx ->
                    val isUp = idx.change >= 0
                    val col = if (isUp) BullGreen else BearRed
                    val sign = if (isUp) "+" else ""

                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.width(160.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(idx.ticker, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(idx.name, color = TextMuted, fontSize = 10.sp, maxLines = 1)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("£${String.format("%.2f", idx.value)}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("$sign${String.format("%.2f", idx.changePercent)}%", color = col, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Market Breadth Stats
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ADVANCERS", color = TextMuted, fontSize = 11.sp)
                        Text("$advancers", color = BullGreen, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DECLINERS", color = TextMuted, fontSize = 11.sp)
                        Text("$decliners", color = BearRed, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("MATCHED ORDERS", color = TextMuted, fontSize = 11.sp)
                        Text("${metrics.totalOrdersCount}", color = ElectricCyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TOTAL TRADES", color = TextMuted, fontSize = 11.sp)
                        Text("${metrics.totalTradesCount}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Top Movers Section
        item {
            Text(
                text = "TOP MOVERS & ACTIVE SECURITIES",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(topMovers) { sec ->
            TickerCard(
                security = sec,
                isSelected = false,
                onSelect = {
                    viewModel.selectSecurity(sec.ticker)
                    onNavigateToTerminal(sec.ticker)
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "SYNTHETIC MARKET NEWS STREAM",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // News Stream
        items(newsList.take(6)) { news ->
            val impactCol = when (news.impact) {
                NewsImpact.POSITIVE -> BullGreen
                NewsImpact.NEGATIVE -> BearRed
                NewsImpact.NEUTRAL -> WarningGold
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.small,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        news.ticker?.let {
                            Box(
                                modifier = Modifier
                                    .background(ElectricCyan.copy(alpha = 0.2f), shape = MaterialTheme.shapes.extraSmall)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(it, color = ElectricCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Box(
                            modifier = Modifier
                                .background(impactCol.copy(alpha = 0.2f), shape = MaterialTheme.shapes.extraSmall)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(news.impact.name, color = impactCol, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(news.headline, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(news.summary, color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}
