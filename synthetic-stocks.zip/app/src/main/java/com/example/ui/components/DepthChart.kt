package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nsx.model.OrderBookSnapshot
import com.example.ui.theme.AskRedAlpha
import com.example.ui.theme.BearRed
import com.example.ui.theme.BidGreenAlpha
import com.example.ui.theme.BullGreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DepthChart(
    orderBook: OrderBookSnapshot?,
    modifier: Modifier = Modifier
) {
    if (orderBook == null || (orderBook.bids.isEmpty() && orderBook.asks.isEmpty())) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(DarkCardSurface, shape = MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center
        ) {
            Text("Order book depth calculating...", color = TextMuted, fontSize = 12.sp)
        }
        return
    }

    val bids = orderBook.bids.sortedBy { it.price } // Lowest to highest
    val asks = orderBook.asks.sortedBy { it.price } // Lowest to highest

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkCardSurface, shape = MaterialTheme.shapes.medium)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("LEVEL 2 DEPTH LADDER", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.weight(1f))
            Text("Spread: £${String.format("%.2f", orderBook.spread)}", color = TextSecondary, fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
        ) {
            val width = size.width
            val height = size.height
            val midX = width / 2f

            // Calculate Cumulative Volumes
            var cumBid = 0L
            val cumBids = bids.map {
                cumBid += it.quantity
                Pair(it.price, cumBid)
            }

            var cumAsk = 0L
            val cumAsks = asks.map {
                cumAsk += it.quantity
                Pair(it.price, cumAsk)
            }

            val maxCumVol = maxOf(cumBid, cumAsk).coerceAtLeast(1L)

            // Draw Bids Path (Left side)
            if (cumBids.isNotEmpty()) {
                val bidPath = Path()
                val bidFill = Path()

                bidPath.moveTo(0f, height)
                bidFill.moveTo(0f, height)

                cumBids.forEachIndexed { i, pair ->
                    val x = (i.toFloat() / (cumBids.size.coerceAtLeast(1))) * midX
                    val y = height - ((pair.second.toFloat() / maxCumVol) * height)
                    bidPath.lineTo(x, y)
                    bidFill.lineTo(x, y)
                }

                bidPath.lineTo(midX, height)
                bidFill.lineTo(midX, height)
                bidFill.close()

                drawPath(path = bidFill, color = BidGreenAlpha)
                drawPath(path = bidPath, color = BullGreen, style = Stroke(width = 3f))
            }

            // Draw Asks Path (Right side)
            if (cumAsks.isNotEmpty()) {
                val askPath = Path()
                val askFill = Path()

                askPath.moveTo(midX, height)
                askFill.moveTo(midX, height)

                cumAsks.forEachIndexed { i, pair ->
                    val x = midX + ((i.toFloat() / (cumAsks.size.coerceAtLeast(1))) * (width - midX))
                    val y = height - ((pair.second.toFloat() / maxCumVol) * height)
                    askPath.lineTo(x, y)
                    askFill.lineTo(x, y)
                }

                askPath.lineTo(width, height)
                askFill.lineTo(width, height)
                askFill.close()

                drawPath(path = askFill, color = AskRedAlpha)
                drawPath(path = askPath, color = BearRed, style = Stroke(width = 3f))
            }

            // Mid Line
            drawLine(
                color = TextMuted,
                start = Offset(midX, 0f),
                end = Offset(midX, height),
                strokeWidth = 2f
            )
        }
    }
}
