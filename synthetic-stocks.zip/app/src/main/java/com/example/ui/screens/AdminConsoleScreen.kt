package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nsx.viewmodel.ExchangeViewModel
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningGold

@Composable
fun AdminConsoleScreen(
    viewModel: ExchangeViewModel
) {
    val selectedTicker by viewModel.selectedTicker.collectAsState()
    val metrics by viewModel.metrics.collectAsState()
    val auditReport by viewModel.auditReport.collectAsState()

    var dividendAmountText by remember { mutableStateOf("1.25") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("admin_console_screen")
    ) {
        item {
            Text("EXCHANGE ADMINISTRATOR CONSOLE", style = MaterialTheme.typography.titleMedium, color = ElectricCyan, fontWeight = FontWeight.Bold)
            Text("NORTHSTAR EXCHANGE CONTROL & TELEMETRY", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Exchange Metrics & Observability Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth().testTag("telemetry_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("EXCHANGE TELEMETRY & OBSERVABILITY", color = ElectricCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ORDERS / SEC", color = TextMuted, fontSize = 11.sp)
                            Text("${String.format("%.1f", metrics.ordersPerSecond)}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("TRADES / SEC", color = TextMuted, fontSize = 11.sp)
                            Text("${String.format("%.1f", metrics.tradesPerSecond)}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("MATCH LATENCY", color = TextMuted, fontSize = 11.sp)
                            Text("${metrics.matchingLatencyMs} ms", color = BullGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Notional Traded: £${String.format("%.0f", metrics.totalNotionalVolume)}", color = TextSecondary, fontSize = 12.sp)
                        Text("Pending Settlements: ${metrics.pendingSettlementsCount}", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Corporate Actions Trigger Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth().testTag("corporate_actions_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("CORPORATE ACTIONS ENGINE", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Selected Security: $selectedTicker", color = TextMuted, fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = dividendAmountText,
                            onValueChange = { dividendAmountText = it },
                            label = { Text("Dividend (£/share)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val amt = dividendAmountText.toDoubleOrNull() ?: 1.0
                                viewModel.declareDividend(selectedTicker, amt)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BullGreen),
                            shape = MaterialTheme.shapes.small
                        ) {
                            Text("PAY DIVIDEND", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Double-Entry Ledger Audit Check
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("DOUBLE-ENTRY LEDGER INVARIANT CHECK", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(auditReport, color = TextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.runAudit() },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("RUN FULL LEDGER INVARIANT AUDIT", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
        }
    }
}
