package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NSXDarkColorScheme = darkColorScheme(
    primary = PrimaryBlue,
    onPrimary = DarkBackground,
    primaryContainer = DarkCardSurface,
    onPrimaryContainer = TextPrimary,
    secondary = ElectricCyan,
    onSecondary = DarkBackground,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkCardSurface,
    onSurfaceVariant = TextSecondary,
    outline = BorderSlate,
    error = BearRed
)

@Composable
fun NorthstarTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NSXDarkColorScheme,
        typography = Typography,
        content = content
    )
}
