package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.nsx.engine.LedgerEngine
import com.example.nsx.engine.MatchingEngine
import com.example.nsx.model.Account
import com.example.nsx.model.Order
import com.example.nsx.model.OrderType
import com.example.nsx.model.ParticipantType
import com.example.nsx.model.Side
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Northstar Exchange", appName)
  }

  @Test
  fun `verify price time priority matching and double entry ledger invariant`() {
    val ledgerEngine = LedgerEngine()
    val buyerAccount = Account("ACC-BUYER-1", "PART-1", "Buyer Fund", ParticipantType.INSTITUTIONAL, 1_000_000.0)
    val sellerAccount = Account("ACC-SELLER-1", "PART-2", "Seller Fund", ParticipantType.INSTITUTIONAL, 1_000_000.0)

    ledgerEngine.initializeAccounts(listOf(buyerAccount, sellerAccount), mapOf("AURE" to 100_000L))
    ledgerEngine.setInitialPosition("ACC-SELLER-1", "AURE", 100_000L, 80.0)

    val matchingEngine = MatchingEngine("AURE", ledgerEngine)

    // Seller submits Limit Sell 500 @ 84.00
    val sellOrder = Order("ORD-SELL-1", "ACC-SELLER-1", "AURE", Side.SELL, OrderType.LIMIT, 500, 0, 84.00)
    matchingEngine.submitOrder(sellOrder)

    // Buyer submits Limit Buy 500 @ 84.25 (Crosses book)
    val buyOrder = Order("ORD-BUY-1", "ACC-BUYER-1", "AURE", Side.BUY, OrderType.LIMIT, 500, 0, 84.25)
    val trades = matchingEngine.submitOrder(buyOrder)

    assertEquals(1, trades.size)
    assertEquals(84.00, trades[0].price, 0.01)
    assertEquals(500L, trades[0].quantity)

    // Verify double-entry ledger audit passes
    val auditResult = ledgerEngine.performAudit()
    assertTrue(auditResult.first)
  }
}
