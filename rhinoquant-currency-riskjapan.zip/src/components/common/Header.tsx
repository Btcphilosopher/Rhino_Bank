// RHINOQUANT JAPAN - Header Component

import React, { useState, useEffect } from 'react';
import { Locale, SimulationRegime } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { ShieldCheck, Activity, Globe, Clock, Zap, Sliders, Database } from 'lucide-react';

interface HeaderProps {
  locale: Locale;
  regime: SimulationRegime;
  onSelectLocale: (newLocale: Locale) => void;
  onSelectRegime: (regime: SimulationRegime) => void;
  onOpenSettings: () => void;
  onOpenTrace: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  locale,
  regime,
  onSelectLocale,
  onSelectRegime,
  onOpenSettings,
  onOpenTrace
}) => {
  const [timeStr, setTimeStr] = useState<string>('');

  // Derive display values from regime
  const getRegimeDisplay = () => {
    switch (regime) {
      case 'JPY_APPRECIATION_SHOCK':
        return { marketRegime: 'STRESSED', jpyRegime: 'APPRECIATION' };
      case 'BASIS_SPIKE':
        return { marketRegime: 'VOLATILE', jpyRegime: 'DEPRECIATION' };
      case 'VOLATILITY_SPIKE':
        return { marketRegime: 'VOLATILE', jpyRegime: 'RANGE_BOUND' };
      case 'NORMAL':
      default:
        return { marketRegime: 'CALM', jpyRegime: 'RANGE_BOUND' };
    }
  };
  const { marketRegime, jpyRegime } = getRegimeDisplay();

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Format time in Asia/Tokyo
      const formatted = new Intl.DateTimeFormat(locale === 'ja-JP' ? 'ja-JP' : 'en-GB', {
        timeZone: 'Asia/Tokyo',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).format(now);
      setTimeStr(`${formatted} JST`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [locale]);

  return (
    <header className="bg-[#121721] border-b border-[#2a3447] text-[#e2e8f0] px-4 py-2.5 select-none">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Brand & Codename */}
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 text-[#38bdf8] p-2 rounded font-mono font-bold tracking-wider flex items-center justify-center shadow-inner">
            <span className="text-xl leading-none">RQ</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight text-white font-mono leading-none">
                {getTranslation(locale, 'appTitle')}
              </h1>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#1e293b] text-[#38bdf8] border border-[#3b82f6]/30 font-semibold tracking-wider">
                JAPAN JPY
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-600/40 font-medium">
                {getTranslation(locale, 'syntheticDataNotice')}
              </span>
            </div>
            <p className="text-xs text-[#94a3b8] mt-0.5">
              {getTranslation(locale, 'appSubtitle')}
            </p>
          </div>
        </div>

        {/* Global Controls & Status Bar */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Simulation Regime */}
          <div className="hidden lg:flex items-center gap-1.5 bg-[#172030] border border-[#2a374e] px-2.5 py-1 rounded text-xs">
            <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="text-[#94a3b8] font-mono">REGIME:</span>
            <span className="font-mono font-semibold text-emerald-300">{marketRegime}</span>
            <span className="text-[#475569] px-1">|</span>
            <span className="text-[#94a3b8] font-mono">JPY:</span>
            <span className="font-mono font-semibold text-sky-300">{jpyRegime}</span>
          </div>

          {/* Timezone Clock */}
          <div className="flex items-center gap-1.5 bg-[#172030] border border-[#2a374e] px-2.5 py-1 rounded text-xs font-mono text-[#cbd5e1]">
            <Clock className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span>{timeStr || 'Asia/Tokyo'}</span>
          </div>

          {/* 20-Step Lineage Trace Shortcut Button */}
          <button
            onClick={onOpenTrace}
            className="flex items-center gap-1.5 bg-[#1d283a] hover:bg-[#283850] border border-[#3b82f6]/40 text-[#38bdf8] hover:text-white px-2.5 py-1 rounded text-xs font-mono font-medium transition cursor-pointer"
            title="Full 20-step quantitative calculation trace"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>{getTranslation(locale, 'navTrace')}</span>
          </button>

          {/* Locale Switcher */}
          <div className="flex items-center bg-[#172030] border border-[#2a374e] rounded p-0.5 text-xs font-mono">
            <button
              onClick={() => onSelectLocale('ja-JP')}
              className={`px-2 py-0.5 rounded transition ${
                locale === 'ja-JP'
                  ? 'bg-[#2563eb] text-white font-semibold shadow-sm'
                  : 'text-[#94a3b8] hover:text-white'
              }`}
            >
              日本語
            </button>
            <button
              onClick={() => onSelectLocale('en-GB')}
              className={`px-2 py-0.5 rounded transition ${
                locale === 'en-GB'
                  ? 'bg-[#2563eb] text-white font-semibold shadow-sm'
                  : 'text-[#94a3b8] hover:text-white'
              }`}
            >
              EN
            </button>
          </div>

          {/* Simulation Settings Button */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 bg-[#172030] hover:bg-[#253248] border border-[#2a374e] text-[#94a3b8] hover:text-white rounded transition cursor-pointer"
            title="Simulation Controls & Settings"
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
