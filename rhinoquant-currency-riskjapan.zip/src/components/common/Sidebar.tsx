// RHINOQUANT JAPAN - Sidebar Component

import React from 'react';
import { Locale } from '../../types';
import { getTranslation } from '../../i18n/translations';
import {
  LayoutDashboard,
  Briefcase,
  TrendingUp,
  LineChart,
  GitCommit,
  Activity,
  Shield,
  Gauge,
  SlidersHorizontal,
  PieChart,
  Calculator,
  CheckCircle2,
  FileText,
  Database,
  ShieldCheck,
  Zap,
  Settings
} from 'lucide-react';

export type NavModuleId =
  | 'market'
  | 'exposure'
  | 'futures'
  | 'forwards'
  | 'curves'
  | 'volatility'
  | 'hedging'
  | 'risk'
  | 'scenarios'
  | 'portfolio'
  | 'valuation'
  | 'reconciliation'
  | 'reports'
  | 'dataQuality'
  | 'governance'
  | 'trace'
  | 'settings';

interface SidebarProps {
  locale: Locale;
  activeModule: NavModuleId;
  onSelectModule: (module: NavModuleId) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ locale, activeModule, onSelectModule }) => {
  const menuItems: { id: NavModuleId; key: any; icon: React.ReactNode; isPrimary?: boolean }[] = [
    { id: 'market', key: 'navMarket', icon: <LayoutDashboard className="w-4 h-4" />, isPrimary: true },
    { id: 'exposure', key: 'navExposure', icon: <Briefcase className="w-4 h-4" /> },
    { id: 'futures', key: 'navFutures', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'forwards', key: 'navForwards', icon: <LineChart className="w-4 h-4" /> },
    { id: 'curves', key: 'navCurves', icon: <GitCommit className="w-4 h-4" />, isPrimary: true },
    { id: 'volatility', key: 'navVolatility', icon: <Activity className="w-4 h-4" /> },
    { id: 'hedging', key: 'navHedging', icon: <Shield className="w-4 h-4" /> },
    { id: 'risk', key: 'navRisk', icon: <Gauge className="w-4 h-4" />, isPrimary: true },
    { id: 'scenarios', key: 'navScenarios', icon: <SlidersHorizontal className="w-4 h-4" /> },
    { id: 'portfolio', key: 'navPortfolio', icon: <PieChart className="w-4 h-4" /> },
    { id: 'valuation', key: 'navValuation', icon: <Calculator className="w-4 h-4" /> },
    { id: 'reconciliation', key: 'navReconciliation', icon: <CheckCircle2 className="w-4 h-4" /> },
    { id: 'reports', key: 'navReports', icon: <FileText className="w-4 h-4" /> },
    { id: 'dataQuality', key: 'navDataQuality', icon: <Database className="w-4 h-4" /> },
    { id: 'governance', key: 'navGovernance', icon: <ShieldCheck className="w-4 h-4" /> },
    { id: 'trace', key: 'navTrace', icon: <Zap className="w-4 h-4 text-amber-400" /> },
    { id: 'settings', key: 'navSettings', icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <aside className="w-60 bg-[#0e131f] border-r border-[#263147] flex flex-col shrink-0 select-none">
      <div className="px-3 py-2 border-b border-[#263147] bg-[#121929]">
        <span className="text-[11px] font-mono font-semibold tracking-wider text-[#64748b] uppercase">
          {locale === 'ja-JP' ? '主要分析モジュール' : 'Primary Modules'}
        </span>
      </div>

      <nav className="flex-1 overflow-y-auto p-1.5 space-y-0.5 custom-scrollbar">
        {menuItems.map(item => {
          const isActive = activeModule === item.id;
          const labelJa = getTranslation('ja-JP', item.key);
          const labelEn = getTranslation('en-GB', item.key);

          return (
            <button
              key={item.id}
              onClick={() => onSelectModule(item.id)}
              className={`w-full flex items-center justify-between px-2.5 py-2 rounded text-left transition cursor-pointer group ${
                isActive
                  ? 'bg-[#1e293b] text-white border-l-2 border-[#3b82f6] shadow-sm font-medium'
                  : 'text-[#94a3b8] hover:bg-[#151c2c] hover:text-[#e2e8f0]'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span className={`${isActive ? 'text-[#38bdf8]' : 'text-[#64748b] group-hover:text-[#94a3b8]'}`}>
                  {item.icon}
                </span>
                <div className="truncate">
                  <div className="text-xs font-medium leading-tight truncate">
                    {locale === 'ja-JP' ? labelJa : labelEn}
                  </div>
                  <div className="text-[10px] font-mono text-[#64748b] truncate leading-none mt-0.5">
                    {locale === 'ja-JP' ? labelEn : labelJa}
                  </div>
                </div>
              </div>

              {item.isPrimary && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#38bdf8] shrink-0" title="Core Module" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer System Info */}
      <div className="p-3 border-t border-[#263147] bg-[#0b0f19] text-[10px] text-[#64748b] font-mono space-y-1">
        <div className="flex justify-between items-center">
          <span>RHINOQUANT ENGINE</span>
          <span className="text-emerald-400 font-semibold">v2.4.0-JP</span>
        </div>
        <div className="flex justify-between items-center text-[9px]">
          <span>DATA PROVENANCE:</span>
          <span className="text-[#94a3b8]">SYNTHETIC_CIP</span>
        </div>
      </div>
    </aside>
  );
};
