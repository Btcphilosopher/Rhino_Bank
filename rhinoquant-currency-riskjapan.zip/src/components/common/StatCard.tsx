// RHINOQUANT JAPAN - Institutional Stat Card Component

import React from 'react';
import { Locale, DataStatus } from '../../types';
import { ChevronRight } from 'lucide-react';

interface StatCardProps {
  titleJa: string;
  titleEn: string;
  value: string;
  unit?: string;
  currency?: string;
  changeStr?: string;
  isPositive?: boolean;
  timestamp?: string;
  source?: string;
  qualityStatus?: DataStatus;
  onClickDrilldown?: () => void;
  locale: Locale;
  accentColor?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  titleJa,
  titleEn,
  value,
  unit,
  currency,
  changeStr,
  isPositive,
  timestamp = '2026-09-21 05:25 JST',
  source = 'TOKYO_DESK [SYNTHETIC]',
  qualityStatus = 'SYNTHETIC',
  onClickDrilldown,
  locale,
  accentColor = 'border-l-blue-500'
}) => {
  return (
    <div
      onClick={onClickDrilldown}
      className={`bg-[#131926] border border-[#232e42] ${accentColor} border-l-4 rounded p-3 flex flex-col justify-between hover:bg-[#182132] transition cursor-pointer group shadow-sm`}
    >
      <div>
        {/* Header Title */}
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="text-xs font-semibold text-[#cbd5e1] tracking-tight">
              {locale === 'ja-JP' ? titleJa : titleEn}
            </div>
            <div className="text-[10px] font-mono text-[#64748b]">
              {locale === 'ja-JP' ? titleEn : titleJa}
            </div>
          </div>
          {onClickDrilldown && (
            <ChevronRight className="w-4 h-4 text-[#475569] group-hover:text-[#38bdf8] transition" />
          )}
        </div>

        {/* Value Display */}
        <div className="mt-2 flex items-baseline gap-1.5 flex-wrap">
          <span className="text-xl md:text-2xl font-mono font-bold text-white tracking-tight">
            {value}
          </span>
          {unit && <span className="text-xs font-mono text-[#94a3b8]">{unit}</span>}
          {currency && <span className="text-xs font-mono text-[#38bdf8] font-semibold">{currency}</span>}
        </div>

        {/* Change or Subtext */}
        {changeStr && (
          <div className="mt-1 flex items-center gap-1 text-xs font-mono">
            <span className={isPositive ? 'text-emerald-400' : 'text-rose-400'}>
              {isPositive ? '▲' : '▼'} {changeStr}
            </span>
          </div>
        )}
      </div>

      {/* Footer Provenance Meta */}
      <div className="mt-3 pt-2 border-t border-[#1f293d] flex items-center justify-between text-[9px] font-mono text-[#64748b]">
        <span className="truncate max-w-[130px]">{source}</span>
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="px-1 py-0.2 rounded bg-[#1e293b] text-amber-300 border border-amber-600/30">
            {qualityStatus}
          </span>
        </div>
      </div>
    </div>
  );
};
