// RHINOQUANT JAPAN - Settings & Simulation Control Module

import React from 'react';
import { Locale, SimulationRegime } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { Settings, RefreshCw, Sliders, ShieldAlert, Cpu } from 'lucide-react';

interface SettingsModuleProps {
  locale: Locale;
  regime: SimulationRegime;
  onSelectRegime: (regime: SimulationRegime) => void;
  onSelectLocale: (locale: Locale) => void;
}

export const SettingsModule: React.FC<SettingsModuleProps> = ({
  locale,
  regime,
  onSelectRegime,
  onSelectLocale
}) => {
  const isJa = locale === 'ja-JP';

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? 'シミュレーション環境 & パラメーター設定' : 'SIMULATION ENGINE & REGIME CONFIGURATION'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              市場ストレス・レジーム切り替え | テキスト言語 | データシード再生成
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Regime Settings Card */}
        <div className="bg-[#121722] border border-[#232e42] rounded p-4 space-y-3">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
            <span>{isJa ? '市場シミュレーション・レジーム' : 'Simulation Market Regime'}</span>
            <span className="text-[10px] text-amber-300">ACTIVE: {regime}</span>
          </h3>

          <div className="space-y-2">
            {[
              { id: 'NORMAL', labelJa: '通常市場 (Normal Market)', desc: '標準的な金利差と CIP 均衡状態' },
              { id: 'JPY_APPRECIATION_SHOCK', labelJa: '急激な円高ショック (-5% JPY)', desc: 'USD/JPY 急落 & スワップベース拡大' },
              { id: 'BASIS_SPIKE', labelJa: 'ドル調達ベース急拡大 (Basis Spike)', desc: 'ドルキャッシュ調達逼迫 (+25 bps)' },
              { id: 'VOLATILITY_SPIKE', labelJa: 'ボラティリティ急急上昇 (Vol Spike)', desc: 'インプライド・ボラティリティ急拡大 (+30%)' },
            ].map(r => (
              <button
                key={r.id}
                onClick={() => onSelectRegime(r.id as any)}
                className={`w-full text-left p-2.5 rounded border transition cursor-pointer ${
                  regime === r.id
                    ? 'bg-[#1e293b] border-[#38bdf8] text-white'
                    : 'bg-[#172030] border-[#253248] text-[#94a3b8] hover:bg-[#1f2c42]'
                }`}
              >
                <div className="font-bold text-xs">{r.labelJa}</div>
                <div className="text-[10px] text-[#64748b] mt-0.5">{r.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Locale & System Controls */}
        <div className="bg-[#121722] border border-[#232e42] rounded p-4 space-y-3">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2">
            {isJa ? '言語 & システム表示設定' : 'Language & System Display'}
          </h3>

          <div className="space-y-3">
            <div>
              <label className="text-[#94a3b8] text-[11px] block mb-1">表示言語 (Display Locale)</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => onSelectLocale('ja-JP')}
                  className={`p-2 rounded font-bold transition cursor-pointer border ${
                    locale === 'ja-JP' ? 'bg-[#2563eb] text-white border-[#38bdf8]' : 'bg-[#172030] text-[#94a3b8] border-[#253248]'
                  }`}
                >
                  日本語 (ja-JP)
                </button>
                <button
                  onClick={() => onSelectLocale('en-GB')}
                  className={`p-2 rounded font-bold transition cursor-pointer border ${
                    locale === 'en-GB' ? 'bg-[#2563eb] text-white border-[#38bdf8]' : 'bg-[#172030] text-[#94a3b8] border-[#253248]'
                  }`}
                >
                  English (en-GB)
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
