// RHINOQUANT JAPAN - Market Overview Module

import React from 'react';
import { Locale, CurrencyPair, RiskMetrics, DataStatus } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { StatCard } from '../common/StatCard';
import ReactECharts from 'echarts-for-react';
import { Activity, ShieldCheck, CheckCircle2, AlertTriangle, ArrowUpRight, ArrowDownRight, RefreshCw } from 'lucide-react';

interface MarketOverviewModuleProps {
  locale: Locale;
  currencyPairs: CurrencyPair[];
  riskMetrics: RiskMetrics;
  onNavigate: (module: any) => void;
}

export const MarketOverviewModule: React.FC<MarketOverviewModuleProps> = ({
  locale,
  currencyPairs,
  riskMetrics,
  onNavigate
}) => {
  const isJa = locale === 'ja-JP';

  // Chart 1: Futures & Forward Curve Overview
  const curveOption = {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis', backgroundColor: '#1e293b', borderColor: '#334155', textStyle: { color: '#f8fafc', fontSize: 12 } },
    legend: { data: [isJa ? '先物カーブ (Futures)' : 'Futures Curve', isJa ? 'フォワードカーブ (Forward)' : 'Forward Curve'], textStyle: { color: '#94a3b8', fontSize: 11 }, top: 0 },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '15%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['1W', '1M', '3M', '6M', '9M', '1Y', '2Y'],
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 }
    },
    yAxis: {
      type: 'value',
      scale: true,
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', fontSize: 11, formatter: '{value} JPY' }
    },
    series: [
      {
        name: isJa ? '先物カーブ (Futures)' : 'Futures Curve',
        type: 'line',
        data: [154.28, 153.95, 152.86, 151.20, 149.65, 148.25, 145.40],
        smooth: true,
        lineStyle: { width: 2, color: '#38bdf8' },
        itemStyle: { color: '#38bdf8' }
      },
      {
        name: isJa ? 'フォワードカーブ (Forward)' : 'Forward Curve',
        type: 'line',
        data: [154.23, 153.82, 152.77, 151.05, 149.48, 148.10, 145.10],
        smooth: true,
        lineStyle: { width: 2, type: 'dashed', color: '#818cf8' },
        itemStyle: { color: '#818cf8' }
      }
    ]
  };

  // Chart 2: Exposure by Currency Stack
  const exposureOption = {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: '#1e293b', borderColor: '#334155', textStyle: { color: '#f8fafc', fontSize: 12 } },
    legend: { data: [isJa ? 'ヘッジ済み (Hedged)' : 'Hedged', isJa ? '未ヘッジ (Unhedged)' : 'Unhedged'], textStyle: { color: '#94a3b8', fontSize: 11 }, top: 0 },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '15%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['USD', 'EUR', 'GBP', 'AUD', 'CAD'],
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 }
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', fontSize: 11, formatter: '{value} M$' }
    },
    series: [
      {
        name: isJa ? 'ヘッジ済み (Hedged)' : 'Hedged',
        type: 'bar',
        stack: 'total',
        data: [280, 85, 42, 25, 18],
        itemStyle: { color: '#3b82f6' }
      },
      {
        name: isJa ? '未ヘッジ (Unhedged)' : 'Unhedged',
        type: 'bar',
        stack: 'total',
        data: [140, 35, 18, 15, 12],
        itemStyle: { color: '#f43f5e' }
      }
    ]
  };

  return (
    <div className="space-y-4 p-4">
      {/* Top Stat Cards Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2.5">
        <StatCard
          locale={locale}
          titleJa="総純為替エクスポージャー"
          titleEn="Total Net FX Exposure"
          value="420"
          unit="百万"
          currency="USD"
          changeStr="647.8 億円"
          isPositive={true}
          accentColor="border-l-blue-500"
          onClickDrilldown={() => onNavigate('exposure')}
        />
        <StatCard
          locale={locale}
          titleJa="円換算報告エクスポージャー"
          titleEn="JPY Reporting Exposure"
          value="64,785"
          unit="百万円"
          currency="JPY"
          accentColor="border-l-indigo-500"
          onClickDrilldown={() => onNavigate('exposure')}
        />
        <StatCard
          locale={locale}
          titleJa="ヘッジ比率"
          titleEn="Hedge Ratio"
          value="66.7"
          unit="%"
          changeStr="目標: 65~80%"
          isPositive={true}
          accentColor="border-l-emerald-500"
          onClickDrilldown={() => onNavigate('hedging')}
        />
        <StatCard
          locale={locale}
          titleJa="ポートフォリオ MTM"
          titleEn="Portfolio MTM"
          value="+113"
          unit="百万円"
          currency="JPY"
          changeStr="含み益"
          isPositive={true}
          accentColor="border-l-teal-500"
          onClickDrilldown={() => onNavigate('portfolio')}
        />
        <StatCard
          locale={locale}
          titleJa="日次損益"
          titleEn="Daily P&L"
          value="+18.5"
          unit="百万円"
          currency="JPY"
          changeStr="本日の評価変調"
          isPositive={true}
          accentColor="border-l-cyan-500"
          onClickDrilldown={() => onNavigate('portfolio')}
        />
        <StatCard
          locale={locale}
          titleJa="証拠金使用率"
          titleEn="Margin Utilization"
          value="38.2"
          unit="%"
          changeStr="維持証拠金余裕"
          isPositive={true}
          accentColor="border-l-amber-500"
          onClickDrilldown={() => onNavigate('futures')}
        />
        <StatCard
          locale={locale}
          titleJa="カーブ品質"
          titleEn="Curve Quality"
          value="100"
          unit="分/100"
          changeStr="CIP 整合性維持"
          isPositive={true}
          accentColor="border-l-[#38bdf8]"
          onClickDrilldown={() => onNavigate('curves')}
        />
        <StatCard
          locale={locale}
          titleJa="リスク限度使用率"
          titleEn="Risk Limit Util."
          value="42.5"
          unit="%"
          changeStr="VaR 99%: 3.85億円"
          isPositive={true}
          accentColor="border-l-purple-500"
          onClickDrilldown={() => onNavigate('risk')}
        />
      </div>

      {/* Main Grid Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Market Snapshot Grid (5 cols) */}
        <div className="lg:col-span-5 bg-[#121722] border border-[#232e42] rounded p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#38bdf8]" />
              <h3 className="text-sm font-semibold font-mono text-white">
                {isJa ? '為替スポット & フォワード気配 (Market Snapshot)' : 'FX Spot & Forward Snapshot'}
              </h3>
            </div>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-700/40">
              SYNTHETIC
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left text-[#cbd5e1]">
              <thead className="bg-[#182030] text-[#64748b] border-b border-[#232e42]">
                <tr>
                  <th className="py-1.5 px-2">{isJa ? '通貨ペア' : 'Pair'}</th>
                  <th className="py-1.5 px-2 text-right">{isJa ? 'ビッド' : 'Bid'}</th>
                  <th className="py-1.5 px-2 text-right">{isJa ? 'アスク' : 'Ask'}</th>
                  <th className="py-1.5 px-2 text-right">{isJa ? '前日比' : '24h Chg'}</th>
                  <th className="py-1.5 px-2 text-right">{isJa ? '表示形式' : 'Quote'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                {currencyPairs.map(pair => (
                  <tr key={pair.id} className="hover:bg-[#182234] transition">
                    <td className="py-2 px-2 font-bold text-white flex items-center gap-1.5">
                      <span>{pair.symbol}</span>
                      <span className="text-[9px] text-[#64748b] font-normal hidden sm:inline">
                        ({isJa ? pair.descriptionJa : pair.descriptionEn})
                      </span>
                    </td>
                    <td className="py-2 px-2 text-right text-emerald-400 font-semibold">{pair.bid.toFixed(2)}</td>
                    <td className="py-2 px-2 text-right text-rose-400 font-semibold">{pair.ask.toFixed(2)}</td>
                    <td className="py-2 px-2 text-right">
                      <span className={pair.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                        {pair.change24h >= 0 ? '+' : ''}{pair.change24hPct.toFixed(2)}%
                      </span>
                    </td>
                    <td className="py-2 px-2 text-right text-[10px] text-[#94a3b8]">
                      {pair.quotationConvention === 'JPY_PER_FCU' ? 'JPY/FCU' : 'FCU/JPY'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Charts & Curves (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#121722] border border-[#232e42] rounded p-3">
            <div className="flex items-center justify-between border-b border-[#1e293b] pb-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#38bdf8]" />
                <h3 className="text-sm font-semibold font-mono text-white">
                  {isJa ? 'USD/JPY イールドカーブ・タームストラクチャー' : 'USD/JPY Term Structure & Futures Curve'}
                </h3>
              </div>
              <button
                onClick={() => onNavigate('curves')}
                className="text-xs font-mono text-[#38bdf8] hover:underline flex items-center gap-1 cursor-pointer"
              >
                {isJa ? 'カーブターミナルを開く →' : 'Open Curve Terminal →'}
              </button>
            </div>
            <ReactECharts option={curveOption} style={{ height: '220px' }} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#121722] border border-[#232e42] rounded p-3">
              <h3 className="text-xs font-semibold font-mono text-[#cbd5e1] mb-2">
                {isJa ? '通貨別エクスポージャー構成 (USD $420M)' : 'Currency Exposure Breakdown'}
              </h3>
              <ReactECharts option={exposureOption} style={{ height: '180px' }} />
            </div>

            {/* Service & System Status Panel */}
            <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-2.5">
              <h3 className="text-xs font-semibold font-mono text-[#cbd5e1] border-b border-[#1e293b] pb-1.5 flex items-center justify-between">
                <span>{isJa ? 'システムサービス & 整合性ステータス' : 'System Service Integrity'}</span>
                <span className="text-[10px] text-emerald-400 font-normal">ALL SYSTEMS NORMAL</span>
              </h3>

              <div className="space-y-1.5 text-xs font-mono">
                <div className="flex justify-between items-center bg-[#172030] p-1.5 rounded">
                  <span className="text-[#94a3b8]">{isJa ? '市場データ配信 (Market Data)' : 'Market Data Feed'}</span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1 text-[11px]">
                    <CheckCircle2 className="w-3 h-3" /> SYNTHETIC_OK
                  </span>
                </div>
                <div className="flex justify-between items-center bg-[#172030] p-1.5 rounded">
                  <span className="text-[#94a3b8]">{isJa ? 'CIP カーブ構築 (Curve Build)' : 'Curve Construction'}</span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1 text-[11px]">
                    <CheckCircle2 className="w-3 h-3" /> BOOTSTRAP_OK
                  </span>
                </div>
                <div className="flex justify-between items-center bg-[#172030] p-1.5 rounded">
                  <span className="text-[#94a3b8]">{isJa ? '評価エンジン (Valuation Engine)' : 'Valuation Engine'}</span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1 text-[11px]">
                    <CheckCircle2 className="w-3 h-3" /> DECIMAL_PRECISION
                  </span>
                </div>
                <div className="flex justify-between items-center bg-[#172030] p-1.5 rounded">
                  <span className="text-[#94a3b8]">{isJa ? '照合監査 (Reconciliation)' : 'Reconciliation'}</span>
                  <span className="text-amber-300 font-semibold flex items-center gap-1 text-[11px]">
                    <AlertTriangle className="w-3 h-3" /> 1 WARNING
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
