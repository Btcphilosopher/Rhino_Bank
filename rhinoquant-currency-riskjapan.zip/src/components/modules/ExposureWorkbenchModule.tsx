// RHINOQUANT JAPAN - Corporate Treasury FX Exposure Workbench

import React, { useState } from 'react';
import { Locale, ExposureItem, HedgePosition } from '../../types';
import { getTranslation } from '../../i18n/translations';
import ReactECharts from 'echarts-for-react';
import { Briefcase, ShieldCheck, Building2, Calendar, FileSpreadsheet, Plus, ArrowUpRight } from 'lucide-react';

interface ExposureWorkbenchModuleProps {
  locale: Locale;
  exposures: ExposureItem[];
  hedges: HedgePosition[];
}

export const ExposureWorkbenchModule: React.FC<ExposureWorkbenchModuleProps> = ({ locale, exposures, hedges }) => {
  const isJa = locale === 'ja-JP';

  const totalExposureUsd = exposures.reduce((acc, e) => acc + e.amountForeign, 0);
  const totalHedgedUsd = exposures.reduce((acc, e) => acc + e.hedgedAmountForeign, 0);
  const totalUnhedgedUsd = totalExposureUsd - totalHedgedUsd;
  const overallHedgeRatioPct = (totalHedgedUsd / totalExposureUsd) * 100;

  // Maturity Ladder Chart
  const ladderOption = {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: '#1e293b', borderColor: '#334155', textStyle: { color: '#f8fafc', fontSize: 12 } },
    legend: { data: [isJa ? 'ヘッジ済み (Hedged)' : 'Hedged', isJa ? '未ヘッジ (Unhedged)' : 'Unhedged'], textStyle: { color: '#94a3b8', fontSize: 11 }, top: 0 },
    grid: { left: '3%', right: '4%', bottom: '5%', top: '15%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['2026 Q4 (12月)', '2027 Q1 (3月)', '2027 Q2 (6月)'],
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 }
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', fontSize: 11, formatter: '${value}M' }
    },
    series: [
      {
        name: isJa ? 'ヘッジ済み (Hedged)' : 'Hedged',
        type: 'bar',
        stack: 'total',
        data: [120, 110, 50],
        itemStyle: { color: '#2563eb' }
      },
      {
        name: isJa ? '未ヘッジ (Unhedged)' : 'Unhedged',
        type: 'bar',
        stack: 'total',
        data: [0, 50, 90],
        itemStyle: { color: '#e11d48' }
      }
    ]
  };

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      {/* Corporate Header Card */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1e293b] pb-3">
          <div className="flex items-center gap-3">
            <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2.5 rounded text-[#38bdf8]">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-wide">
                企業名: 東京インダストリアル・ホールディングス (TOKYO INDUSTRIAL HOLDINGS) — SYNTHETIC
              </div>
              <div className="text-xs text-[#94a3b8] mt-0.5">
                報告通貨 (Reporting Currency): <strong className="text-sky-300">JPY (日本円)</strong> | 主たる外貨: <strong className="text-emerald-300">USD (米ドル)</strong>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-[#182030] border border-[#2e3e5b] text-[#38bdf8] rounded font-semibold text-xs">
              SAP S/4HANA SYNCED
            </span>
          </div>
        </div>

        {/* Corporate Summary KPI Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
          <div className="bg-[#172030] p-2.5 rounded border border-[#253248]">
            <div className="text-[11px] text-[#94a3b8]">{isJa ? '総外貨エクスポージャー' : 'Total Foreign Exposure'}</div>
            <div className="text-lg font-bold text-white mt-0.5">${(totalExposureUsd / 1e6).toFixed(1)}M USD</div>
            <div className="text-[10px] text-[#64748b]">約 647.8 億円 MTM</div>
          </div>

          <div className="bg-[#172030] p-2.5 rounded border border-[#253248]">
            <div className="text-[11px] text-[#94a3b8]">{isJa ? 'ヘッジ済み額' : 'Hedged Amount'}</div>
            <div className="text-lg font-bold text-emerald-400 mt-0.5">${(totalHedgedUsd / 1e6).toFixed(1)}M USD</div>
            <div className="text-[10px] text-emerald-500 font-semibold">為替予約 & CME先物</div>
          </div>

          <div className="bg-[#172030] p-2.5 rounded border border-[#253248]">
            <div className="text-[11px] text-[#94a3b8]">{isJa ? '未ヘッジ外貨残高' : 'Unhedged Balance'}</div>
            <div className="text-lg font-bold text-rose-400 mt-0.5">${(totalUnhedgedUsd / 1e6).toFixed(1)}M USD</div>
            <div className="text-[10px] text-rose-300">円高感応度: 1円=1.4億円</div>
          </div>

          <div className="bg-[#172030] p-2.5 rounded border border-[#253248]">
            <div className="text-[11px] text-[#94a3b8]">{isJa ? '全社ヘッジ比率' : 'Overall Hedge Ratio'}</div>
            <div className="text-lg font-bold text-[#38bdf8] mt-0.5">{overallHedgeRatioPct.toFixed(1)}%</div>
            <div className="text-[10px] text-sky-400 font-semibold">社内規定 (60~80%) 適合</div>
          </div>
        </div>
      </div>

      {/* Main Grid: Exposure Schedule Table (7 cols) + Maturity Ladder Chart (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Table (7 cols) */}
        <div className="lg:col-span-7 bg-[#121722] border border-[#232e42] rounded p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <h3 className="font-semibold text-white">
              {isJa ? '四半期別為替エクスポージャー明細 (Receivables Schedule)' : 'Quarterly FX Exposure Schedule'}
            </h3>
            <span className="text-[10px] text-[#38bdf8]">3 CONTRACT BUCKETS</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[#cbd5e1]">
              <thead className="bg-[#182030] text-[#64748b]">
                <tr>
                  <th className="py-1.5 px-2">ID / 事業部</th>
                  <th className="py-1.5 px-2 text-right">金額 (USD)</th>
                  <th className="py-1.5 px-2 text-right">ヘッジ済</th>
                  <th className="py-1.5 px-2 text-right">比率</th>
                  <th className="py-1.5 px-2 text-center">予定日</th>
                  <th className="py-1.5 px-2 text-center">ステータス</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                {exposures.map(exp => (
                  <tr key={exp.exposureId} className="hover:bg-[#182234] transition">
                    <td className="py-2.5 px-2">
                      <div className="font-bold text-white">{exp.exposureId}</div>
                      <div className="text-[10px] text-[#64748b] truncate max-w-[180px]">{exp.businessUnit}</div>
                    </td>
                    <td className="py-2.5 px-2 text-right font-bold text-white">${(exp.amountForeign / 1e6).toFixed(0)}M</td>
                    <td className="py-2.5 px-2 text-right text-emerald-400 font-semibold">${(exp.hedgedAmountForeign / 1e6).toFixed(0)}M</td>
                    <td className="py-2.5 px-2 text-right font-bold text-[#38bdf8]">{exp.hedgeRatioPct.toFixed(1)}%</td>
                    <td className="py-2.5 px-2 text-center text-[#94a3b8]">{exp.expectedDate}</td>
                    <td className="py-2.5 px-2 text-center">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                        exp.hedgeStatus === 'FULLY_HEDGED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/40' : 'bg-amber-950 text-amber-300 border border-amber-700/40'
                      }`}>
                        {exp.hedgeStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Maturity Ladder Chart (5 cols) */}
        <div className="lg:col-span-5 bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2">
            {isJa ? '満期別ヘッジ構造 (Maturity Ladder)' : 'Maturity Ladder Structure'}
          </h3>
          <ReactECharts option={ladderOption} style={{ height: '260px' }} />
        </div>
      </div>
    </div>
  );
};
