// RHINOQUANT JAPAN - Professional JPY Curve Terminal

import React, { useState } from 'react';
import { Locale, CurveData } from '../../types';
import { getTranslation } from '../../i18n/translations';
import ReactECharts from 'echarts-for-react';
import { calculateCipForwardRate } from '../../quant/engine';
import { Download, Sliders, CheckCircle2, History, GitCommit, Calculator, RefreshCw } from 'lucide-react';

interface CurveTerminalModuleProps {
  locale: Locale;
  curveData: CurveData;
}

export const CurveTerminalModule: React.FC<CurveTerminalModuleProps> = ({ locale, curveData }) => {
  const isJa = locale === 'ja-JP';

  const [selectedPair, setSelectedPair] = useState<string>('USD/JPY');
  const [activeCurveType, setActiveCurveType] = useState<'OUTRIGHT' | 'BASIS' | 'FORWARD_POINTS' | 'RATE_DIFF' | 'ROLL'>('OUTRIGHT');
  const [showHistorical, setShowHistorical] = useState<boolean>(true);
  const [interpMethod, setInterpMethod] = useState<'LOG_LINEAR_DF' | 'LINEAR'>('LOG_LINEAR_DF');
  const [selectedTenorAudit, setSelectedTenorAudit] = useState<string>('3M');

  // Compute CIP audit trail for selected tenor
  const spotRate = 154.25;
  const auditTenorDays = selectedTenorAudit === '1M' ? 30 : selectedTenorAudit === '3M' ? 90 : selectedTenorAudit === '6M' ? 180 : 365;
  const cipAudit = calculateCipForwardRate(spotRate, auditTenorDays, 0.35, 4.35, -18.5);

  // Chart rendering options based on curve type
  const chartOption = {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis', backgroundColor: '#1e293b', borderColor: '#334155', textStyle: { color: '#f8fafc', fontSize: 12 } },
    legend: { textStyle: { color: '#94a3b8', fontSize: 11 }, top: 0 },
    grid: { left: '3%', right: '4%', bottom: '8%', top: '15%', containLabel: true },
    xAxis: {
      type: 'category',
      data: curveData.points.map(p => p.tenor),
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 }
    },
    yAxis: {
      type: 'value',
      scale: true,
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 }
    },
    series: [
      {
        name: isJa ? '本日 (Today)' : 'Today',
        type: 'line',
        data: activeCurveType === 'OUTRIGHT'
          ? curveData.points.map(p => p.forwardRate)
          : activeCurveType === 'BASIS'
          ? curveData.points.map(p => p.basisPips)
          : activeCurveType === 'FORWARD_POINTS'
          ? curveData.points.map(p => p.forwardPointsPips)
          : curveData.points.map(p => p.impliedRateDiffPct),
        smooth: true,
        lineStyle: { width: 3, color: '#38bdf8' },
        itemStyle: { color: '#38bdf8' }
      },
      ...(showHistorical && curveData.historicalCurves ? curveData.historicalCurves.map((hist, idx) => ({
        name: hist.dateLabel,
        type: 'line',
        data: hist.points.map(p => p.rate),
        smooth: true,
        lineStyle: { width: 1.5, type: 'dashed', opacity: 0.6 },
        itemStyle: { opacity: 0.6 }
      })) : [])
    ]
  };

  const handleExportCsv = () => {
    const headers = ['Tenor', 'Days', 'MaturityDate', 'ForwardRate', 'FuturesRate', 'BasisPips', 'ForwardPointsPips', 'RateDiffPct'];
    const rows = curveData.points.map(p => [
      p.tenor,
      p.daysToMaturity,
      p.maturityDate,
      p.forwardRate.toFixed(4),
      p.futuresRate.toFixed(4),
      p.basisPips.toFixed(2),
      p.forwardPointsPips.toFixed(2),
      p.impliedRateDiffPct.toFixed(4)
    ].join(','));

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RHINOQUANT_JPY_CURVE_${selectedPair.replace('/', '')}_20260921.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 p-4">
      {/* Terminal Header Bar */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 font-mono">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1e293b] pb-2.5">
          <div className="flex items-center gap-3">
            <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
              <GitCommit className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wider flex items-center gap-2">
                <span>{isJa ? 'JPY イールド＆カーブ・ターミナル' : 'JPY CURVE TERMINAL'}</span>
                <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-700/40 px-1.5 py-0.5 rounded">
                  SYNTHETIC
                </span>
              </h2>
              <div className="text-xs text-[#94a3b8] flex items-center gap-3 mt-0.5">
                <span>PAIR: <strong className="text-white">{selectedPair}</strong></span>
                <span>VALUATION: <strong className="text-sky-300">2026-09-21 05:28 JST</strong></span>
                <span>METHOD: <strong className="text-emerald-300">{curveData.constructionMethod}</strong></span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 bg-[#172030] hover:bg-[#202d44] border border-[#2e3e5b] text-[#cbd5e1] hover:text-white px-3 py-1.5 rounded text-xs transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{getTranslation(locale, 'exportCsv')}</span>
            </button>
          </div>
        </div>

        {/* Curve Type Selector Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-1">
          <div className="flex items-center gap-1 bg-[#182030] p-1 rounded border border-[#26334a] text-xs">
            <button
              onClick={() => setActiveCurveType('OUTRIGHT')}
              className={`px-3 py-1 rounded transition cursor-pointer ${activeCurveType === 'OUTRIGHT' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'}`}
            >
              {isJa ? 'アウトライト先物カーブ (Outright)' : 'Outright Curve'}
            </button>
            <button
              onClick={() => setActiveCurveType('BASIS')}
              className={`px-3 py-1 rounded transition cursor-pointer ${activeCurveType === 'BASIS' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'}`}
            >
              {isJa ? 'ベース・カーブ (Futures Basis)' : 'Basis Curve'}
            </button>
            <button
              onClick={() => setActiveCurveType('FORWARD_POINTS')}
              className={`px-3 py-1 rounded transition cursor-pointer ${activeCurveType === 'FORWARD_POINTS' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'}`}
            >
              {isJa ? 'フォワード・ポイント (Forward Points)' : 'Forward Points'}
            </button>
            <button
              onClick={() => setActiveCurveType('RATE_DIFF')}
              className={`px-3 py-1 rounded transition cursor-pointer ${activeCurveType === 'RATE_DIFF' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'}`}
            >
              {isJa ? '金利差カーブ (Rate Differential)' : 'Rate Differential'}
            </button>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <label className="flex items-center gap-1.5 text-[#94a3b8] cursor-pointer">
              <input
                type="checkbox"
                checked={showHistorical}
                onChange={e => setShowHistorical(e.target.checked)}
                className="rounded border-[#334155] bg-[#1e293b] text-[#2563eb]"
              />
              <span>{isJa ? '過去カーブ比較 (History Overlay)' : 'Historical Overlays'}</span>
            </label>

            <select
              value={interpMethod}
              onChange={e => setInterpMethod(e.target.value as any)}
              className="bg-[#182030] border border-[#26334a] text-white px-2 py-1 rounded text-xs focus:outline-none"
            >
              <option value="LOG_LINEAR_DF">Log-Linear DF (CIP Standard)</option>
              <option value="LINEAR">Linear Interpolation</option>
            </select>
          </div>
        </div>
      </div>

      {/* Interactive Main Curve Chart Container */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-mono font-semibold text-[#38bdf8]">
            {activeCurveType === 'OUTRIGHT' ? 'USD/JPY OUTRIGHT FUTURES vs FORWARD CURVE' : activeCurveType === 'BASIS' ? 'FUTURES BASIS (FUTURES - FORWARD)' : 'FORWARD POINTS (SEN / PIPS)'}
          </span>
          <span className="text-[10px] font-mono text-[#64748b]">
            DAY COUNT: {curveData.dayCountConvention} | CALENDAR: {curveData.calendar}
          </span>
        </div>
        <ReactECharts option={chartOption} style={{ height: '320px' }} />
      </div>

      {/* Data Table & Calculation Audit Panel Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono text-xs">
        {/* Tenor Table (7 cols) */}
        <div className="lg:col-span-7 bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
            <span>{isJa ? '限月・テナー別詳細データ' : 'Tenor Curve Point Specifications'}</span>
            <span className="text-[10px] text-[#38bdf8]">9 TENOR POINTS LOADED</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[#cbd5e1]">
              <thead className="bg-[#182030] text-[#64748b]">
                <tr>
                  <th className="py-1.5 px-2">TENOR</th>
                  <th className="py-1.5 px-2 text-right">DAYS</th>
                  <th className="py-1.5 px-2 text-right">FORWARD</th>
                  <th className="py-1.5 px-2 text-right">FUTURES</th>
                  <th className="py-1.5 px-2 text-right">BASIS</th>
                  <th className="py-1.5 px-2 text-right">POINTS</th>
                  <th className="py-1.5 px-2 text-right">DF (DOM)</th>
                  <th className="py-1.5 px-2 text-center">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                {curveData.points.map(p => (
                  <tr
                    key={p.tenor}
                    className={`hover:bg-[#182234] transition ${selectedTenorAudit === p.tenor ? 'bg-[#1b263b] text-white' : ''}`}
                  >
                    <td className="py-2 px-2 font-bold text-[#38bdf8]">{p.tenor}</td>
                    <td className="py-2 px-2 text-right text-[#94a3b8]">{p.daysToMaturity}d</td>
                    <td className="py-2 px-2 text-right font-semibold text-white">{p.forwardRate.toFixed(3)}</td>
                    <td className="py-2 px-2 text-right text-emerald-400 font-semibold">{p.futuresRate.toFixed(3)}</td>
                    <td className="py-2 px-2 text-right text-amber-300">+{p.basisPips.toFixed(1)}p</td>
                    <td className="py-2 px-2 text-right text-rose-300">{p.forwardPointsPips.toFixed(1)}</td>
                    <td className="py-2 px-2 text-right text-[#94a3b8]">{p.discountFactor.toFixed(5)}</td>
                    <td className="py-2 px-2 text-center">
                      <button
                        onClick={() => setSelectedTenorAudit(p.tenor)}
                        className="px-2 py-0.5 rounded bg-[#1e293b] hover:bg-[#2d3d59] text-[10px] text-[#38bdf8] border border-[#3b82f6]/30 cursor-pointer"
                      >
                        {isJa ? '監査' : 'Audit'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Calculation Audit Panel (5 cols) */}
        <div className="lg:col-span-5 bg-[#121722] border border-[#232e42] rounded p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-emerald-400" />
              <h3 className="font-semibold text-white">
                {isJa ? `計算監査トレール (${selectedTenorAudit})` : `Calculation Lineage (${selectedTenorAudit})`}
              </h3>
            </div>
            <span className="text-[10px] text-[#94a3b8]">MODEL: MOD-CIP-001</span>
          </div>

          <div className="space-y-2 text-xs">
            {cipAudit.calculationSteps.map(st => (
              <div key={st.step} className="bg-[#172030] border border-[#253248] rounded p-2 space-y-1">
                <div className="flex items-center justify-between text-[11px] font-semibold text-[#38bdf8]">
                  <span>STEP {st.step}: {isJa ? st.descriptionJa : st.descriptionEn}</span>
                </div>
                <div className="text-[11px] text-[#94a3b8] font-mono">{st.formula}</div>
                <div className="text-xs font-bold text-emerald-300 font-mono mt-0.5">➔ {st.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
