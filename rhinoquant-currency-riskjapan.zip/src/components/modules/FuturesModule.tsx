// RHINOQUANT JAPAN - Futures Analytics & Variation Margin Engine

import React, { useState } from 'react';
import { Locale, FuturesContract } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { simulateFuturesPosition } from '../../quant/engine';
import { TrendingUp, ShieldAlert, DollarSign, RefreshCw, Calculator, Layers } from 'lucide-react';

interface FuturesModuleProps {
  locale: Locale;
  contracts: FuturesContract[];
}

export const FuturesModule: React.FC<FuturesModuleProps> = ({ locale, contracts }) => {
  const isJa = locale === 'ja-JP';

  // State for interactive variation margin simulator
  const [selectedContractId, setSelectedContractId] = useState<string>('CME-JYZ26');
  const [positionContracts, setPositionContracts] = useState<number>(2200);
  const [direction, setDirection] = useState<'LONG' | 'SHORT'>('LONG');
  const [entryPrice, setEntryPrice] = useState<number>(0.006500); // ~ 153.85 JPY
  const [currentPrice, setCurrentPrice] = useState<number>(0.006540); // ~ 152.90 JPY

  const contract = contracts.find(c => c.contractId === selectedContractId) || contracts[0];
  const simResult = simulateFuturesPosition(
    positionContracts,
    direction,
    entryPrice,
    currentPrice,
    contract.contractMultiplier
  );

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      {/* Module Banner */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? '通貨先物アナリティクス & 証拠金シミュレーター' : 'FX FUTURES ANALYTICS & MARGIN SIMULATION'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              CME Group / TFX 規格 | 取引単位 (Multiplier): <strong className="text-sky-300">12,500,000 JPY</strong> | 変動証拠金現金決済
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-amber-950 text-amber-300 border border-amber-700/40 rounded text-[10px] font-semibold">
          SYNTHETIC VENUE
        </span>
      </div>

      {/* Contract Specification Table */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
        <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
          <span>{isJa ? 'CME / TFX 通貨先物 限月別約定スペック' : 'Futures Contract Specification & Roll Rates'}</span>
          <span className="text-[10px] text-[#38bdf8]">4 LIQUID CONTRACT MONTHS</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[#cbd5e1]">
            <thead className="bg-[#182030] text-[#64748b]">
              <tr>
                <th className="py-1.5 px-2">CONTRACT ID</th>
                <th className="py-1.5 px-2">LIMITED MONTH</th>
                <th className="py-1.5 px-2 text-right">LAST PRICE</th>
                <th className="py-1.5 px-2 text-right">MULTIPLIER</th>
                <th className="py-1.5 px-2 text-right">OPEN INTEREST</th>
                <th className="py-1.5 px-2 text-right">BASIS</th>
                <th className="py-1.5 px-2 text-right">ROLL YIELD</th>
                <th className="py-1.5 px-2 text-right">INITIAL MARGIN</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {contracts.map(c => (
                <tr key={c.contractId} className="hover:bg-[#182234] transition">
                  <td className="py-2.5 px-2 font-bold text-[#38bdf8]">{c.contractId}</td>
                  <td className="py-2.5 px-2 text-white font-semibold">{c.contractMonth}</td>
                  <td className="py-2.5 px-2 text-right text-emerald-400 font-mono font-bold">{c.lastPrice.toFixed(6)}</td>
                  <td className="py-2.5 px-2 text-right text-[#94a3b8]">{(c.contractMultiplier / 1e6).toFixed(1)}M JPY</td>
                  <td className="py-2.5 px-2 text-right text-[#cbd5e1]">{c.openInterest.toLocaleString()}</td>
                  <td className="py-2.5 px-2 text-right text-amber-300">{c.basis.toFixed(2)}p</td>
                  <td className="py-2.5 px-2 text-right text-rose-300">{c.rollYield.toFixed(2)}% p.a.</td>
                  <td className="py-2.5 px-2 text-right text-sky-300">¥{(c.initialMarginReq / 1000).toFixed(0)}k</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Variation Margin Simulator Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Controls (5 cols) */}
        <div className="lg:col-span-5 bg-[#121722] border border-[#232e42] rounded p-3 space-y-3">
          <div className="flex items-center gap-2 border-b border-[#1e293b] pb-2">
            <Calculator className="w-4 h-4 text-[#38bdf8]" />
            <h3 className="font-semibold text-white">
              {isJa ? '変動証拠金 (Variation Margin) シミュレーター' : 'Variation Margin Calculator'}
            </h3>
          </div>

          <div className="space-y-2.5">
            <div>
              <label className="text-[#94a3b8] text-[11px] block mb-1">対象限月 (Contract)</label>
              <select
                value={selectedContractId}
                onChange={e => setSelectedContractId(e.target.value)}
                className="w-full bg-[#182030] border border-[#26334a] text-white p-2 rounded focus:outline-none"
              >
                {contracts.map(c => (
                  <option key={c.contractId} value={c.contractId}>
                    {c.contractId} ({c.contractMonth}) - Last: {c.lastPrice.toFixed(6)}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[#94a3b8] text-[11px] block mb-1">ポジション方向</label>
                <select
                  value={direction}
                  onChange={e => setDirection(e.target.value as any)}
                  className="w-full bg-[#182030] border border-[#26334a] text-white p-2 rounded focus:outline-none font-semibold"
                >
                  <option value="LONG">LONG (買いヘッジ)</option>
                  <option value="SHORT">SHORT (売りヘッジ)</option>
                </select>
              </div>

              <div>
                <label className="text-[#94a3b8] text-[11px] block mb-1">建玉枚数 (Contracts)</label>
                <input
                  type="number"
                  value={positionContracts}
                  onChange={e => setPositionContracts(Number(e.target.value))}
                  className="w-full bg-[#182030] border border-[#26334a] text-white p-2 rounded focus:outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[#94a3b8] text-[11px] block mb-1">約定単価 (Entry Price)</label>
                <input
                  type="number"
                  step="0.00001"
                  value={entryPrice}
                  onChange={e => setEntryPrice(Number(e.target.value))}
                  className="w-full bg-[#182030] border border-[#26334a] text-white p-2 rounded focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="text-[#94a3b8] text-[11px] block mb-1">現在清算値 (Current Price)</label>
                <input
                  type="number"
                  step="0.00001"
                  value={currentPrice}
                  onChange={e => setCurrentPrice(Number(e.target.value))}
                  className="w-full bg-[#182030] border border-[#26334a] text-white p-2 rounded focus:outline-none font-mono text-emerald-400 font-semibold"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Results Panel (7 cols) */}
        <div className="lg:col-span-7 bg-[#121722] border border-[#232e42] rounded p-3 space-y-3">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2">
            {isJa ? '試算結果 & 証拠金フロー' : 'Position P&L & Margin Cashflow Output'}
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#172030] border border-[#253248] p-3 rounded">
              <span className="text-[#94a3b8] text-[11px] block">{isJa ? '想定元本 (Notional JPY)' : 'Notional JPY'}</span>
              <span className="text-xl font-bold text-white mt-1 block">
                ¥{(simResult.notionalJpy / 1e8).toFixed(2)} 億円
              </span>
              <span className="text-[10px] text-[#64748b]">
                (${(simResult.notionalJpy / 154.25 / 1e6).toFixed(1)}M USD)
              </span>
            </div>

            <div className="bg-[#172030] border border-[#253248] p-3 rounded">
              <span className="text-[#94a3b8] text-[11px] block">{isJa ? '日次評価損益 (Daily P&L)' : 'Daily P&L'}</span>
              <span className={`text-xl font-bold mt-1 block ${simResult.dailyPnlJpy >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {simResult.dailyPnlJpy >= 0 ? '+' : ''}¥{(simResult.dailyPnlJpy / 1e6).toFixed(2)} 百万円
              </span>
              <span className="text-[10px] text-[#64748b]">現金清算対象</span>
            </div>

            <div className="bg-[#172030] border border-[#253248] p-3 rounded">
              <span className="text-[#94a3b8] text-[11px] block">{isJa ? '必要当初証拠金 (Initial Margin)' : 'Initial Margin'}</span>
              <span className="text-lg font-bold text-sky-300 mt-1 block">
                ¥{(simResult.initialMarginReqJpy / 1e6).toFixed(1)} 百万円
              </span>
              <span className="text-[10px] text-[#64748b]">CME Clearing 預託済</span>
            </div>

            <div className="bg-[#172030] border border-[#253248] p-3 rounded">
              <span className="text-[#94a3b8] text-[11px] block">{isJa ? '証拠金使用率 (Margin Utilization)' : 'Margin Utilization'}</span>
              <span className="text-lg font-bold text-amber-300 mt-1 block">
                {simResult.marginUtilizationPct.toFixed(1)}%
              </span>
              <span className="text-[10px] text-emerald-400">マージンコール発生リスク: 低</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
