// RHINOQUANT JAPAN - Hedging Engine & Strategies

import React from 'react';
import { Locale, HedgePosition } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { Shield, CheckCircle2, DollarSign, Layers, ArrowRight } from 'lucide-react';

interface HedgingModuleProps {
  locale: Locale;
  hedges: HedgePosition[];
}

export const HedgingModule: React.FC<HedgingModuleProps> = ({ locale, hedges }) => {
  const isJa = locale === 'ja-JP';

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? '機関投資家向け為替ヘッジ・エンジン (Hedging Engine)' : 'INSTITUTIONAL HEDGING ENGINE'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              為替予約 (FX Forward) / 通貨先物 (Futures) / ローリングヘッジ (Rolling) 統合台帳
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-emerald-950 text-emerald-300 border border-emerald-700/40 rounded text-[10px] font-semibold">
          ACTIVE REGISTER
        </span>
      </div>

      {/* Hedge Positions Table */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
        <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
          <span>{isJa ? '実行済みヘッジポジション・契約台帳' : 'Active Hedge Contract Register'}</span>
          <span className="text-[10px] text-[#38bdf8]">3 REGISTERED POSITIONS</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[#cbd5e1]">
            <thead className="bg-[#182030] text-[#64748b]">
              <tr>
                <th className="py-1.5 px-2">HEDGE ID</th>
                <th className="py-1.5 px-2">STRATEGY TYPE</th>
                <th className="py-1.5 px-2">INSTRUMENT REF</th>
                <th className="py-1.5 px-2 text-right">NOTIONAL (USD)</th>
                <th className="py-1.5 px-2 text-right">EXEC RATE</th>
                <th className="py-1.5 px-2 text-right">UNREALIZED MTM</th>
                <th className="py-1.5 px-2 text-center">MATURITY</th>
                <th className="py-1.5 px-2 text-right">BASIS RISK</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {hedges.map(h => (
                <tr key={h.hedgeId} className="hover:bg-[#182234] transition">
                  <td className="py-2.5 px-2 font-bold text-[#38bdf8]">{h.hedgeId}</td>
                  <td className="py-2.5 px-2">
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#1d283a] text-sky-300 border border-[#3b82f6]/30 font-semibold">
                      {h.strategyType}
                    </span>
                  </td>
                  <td className="py-2.5 px-2 text-white font-semibold">{h.contractIdOrRef}</td>
                  <td className="py-2.5 px-2 text-right font-bold text-white">${(h.notionalForeign / 1e6).toFixed(0)}M</td>
                  <td className="py-2.5 px-2 text-right text-emerald-400 font-bold">{h.executedRate.toFixed(2)} JPY</td>
                  <td className={`py-2.5 px-2 text-right font-bold ${h.unrealizedPnlJpy >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {h.unrealizedPnlJpy >= 0 ? '+' : ''}¥{(h.unrealizedPnlJpy / 1e6).toFixed(1)}M
                  </td>
                  <td className="py-2.5 px-2 text-center text-[#94a3b8]">{h.maturityDate}</td>
                  <td className="py-2.5 px-2 text-right text-amber-300 font-semibold">{h.basisRiskScore.toFixed(1)} / 10</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
