// RHINOQUANT JAPAN - Model Governance Module

import React from 'react';
import { Locale, ModelCard } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { MODEL_GOVERNANCE_CARDS } from '../../quant/engine';
import { ShieldCheck, FileCode2, CheckCircle2, AlertOctagon, BookOpen } from 'lucide-react';

interface ModelGovernanceModuleProps {
  locale: Locale;
}

export const ModelGovernanceModule: React.FC<ModelGovernanceModuleProps> = ({ locale }) => {
  const isJa = locale === 'ja-JP';

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? '定量モデルガバナンス & モデルカード (Model Governance)' : 'MODEL GOVERNANCE & MODEL CARDS'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              数理モデル前提条件 | 制限事項 | 承認ステータス | 検証結果カタルグ
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-emerald-950 text-emerald-300 border border-emerald-700/40 rounded text-[10px] font-semibold">
          3 APPROVED MODELS
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {MODEL_GOVERNANCE_CARDS.map(m => (
          <div key={m.modelId} className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-2.5">
            <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
              <span className="font-bold text-[#38bdf8]">{m.modelId}</span>
              <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-950 text-emerald-300 border border-emerald-700/40 font-bold">
                {m.approvalStatus}
              </span>
            </div>

            <div className="text-sm font-bold text-white">{m.modelName}</div>
            <div className="text-[10px] text-[#94a3b8]">バージョン: {m.version} | 責任部署: {m.owner}</div>

            <div className="bg-[#172030] p-2 rounded border border-[#253248] text-[11px] font-mono text-emerald-300">
              数理方程式: {m.mathematicalFormula}
            </div>

            <div>
              <span className="text-[#94a3b8] font-semibold block mb-1">主要な数理前提条件 (Assumptions):</span>
              <ul className="list-disc list-inside space-y-0.5 text-[#cbd5e1] text-[11px]">
                {m.assumptions.map((a, i) => (
                  <li key={i}>{a}</li>
                ))}
              </ul>
            </div>

            <div>
              <span className="text-[#94a3b8] font-semibold block mb-1">モデル制限事項 (Limitations):</span>
              <ul className="list-disc list-inside space-y-0.5 text-rose-300 text-[11px]">
                {m.limitations.map((l, i) => (
                  <li key={i}>{l}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
