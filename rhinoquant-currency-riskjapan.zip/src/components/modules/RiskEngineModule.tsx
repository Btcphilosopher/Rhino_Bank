// RHINOQUANT JAPAN - Institutional Risk Engine (VaR, ES & Sensitivities)

import React from 'react';
import { Locale, RiskMetrics } from '../../types';
import { getTranslation } from '../../i18n/translations';
import ReactECharts from 'echarts-for-react';
import { Gauge, ShieldAlert, Activity, TrendingDown, Layers, BarChart3 } from 'lucide-react';

interface RiskEngineModuleProps {
  locale: Locale;
  riskMetrics: RiskMetrics;
}

export const RiskEngineModule: React.FC<RiskEngineModuleProps> = ({ locale, riskMetrics }) => {
  const isJa = locale === 'ja-JP';

  // VaR Distribution Chart (Normal vs Fat Tail)
  const varChartOption = {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis', backgroundColor: '#1e293b', borderColor: '#334155', textStyle: { color: '#f8fafc', fontSize: 12 } },
    legend: { textStyle: { color: '#94a3b8', fontSize: 11 }, top: 0 },
    grid: { left: '3%', right: '4%', bottom: '5%', top: '15%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['-3% (Stress)', '-2% (ES 99%)', '-1.5% (VaR 99%)', '-1.0% (VaR 95%)', '0%', '+1%', '+2%', '+3%'],
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 }
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 }
    },
    series: [
      {
        name: isJa ? 'リターン確率密度 (Return Density)' : 'Return Density',
        type: 'line',
        smooth: true,
        data: [0.05, 0.25, 0.85, 2.40, 4.80, 2.40, 0.85, 0.05],
        areaStyle: { color: 'rgba(56, 189, 248, 0.2)' },
        lineStyle: { color: '#38bdf8', width: 2 }
      }
    ]
  };

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <Gauge className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? '機関投資家向け為替リスク・アナリティクス・エンジン' : 'INSTITUTIONAL CURRENCY RISK ENGINE'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              モデル: <strong className="text-sky-300">MOD-VAR-002</strong> (Parametric & Historical VaR) | 1日保有期間 | 95% & 99% 信頼区間
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-amber-950 text-amber-300 border border-amber-700/40 rounded text-[10px] font-semibold">
          MODEL OUTPUT
        </span>
      </div>

      {/* Main Risk Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-1">
          <span className="text-[#94a3b8] text-[11px] block">{isJa ? '95% 日次 VaR (1D Parametric)' : '95% 1-Day VaR'}</span>
          <span className="text-xl font-bold text-amber-300 block">¥2.72 億円</span>
          <span className="text-[10px] text-[#64748b]">1日の最大予想損失 (95% 確率はこれ以下)</span>
        </div>

        <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-1">
          <span className="text-[#94a3b8] text-[11px] block">{isJa ? '99% 日次 VaR (1D Parametric)' : '99% 1-Day VaR'}</span>
          <span className="text-xl font-bold text-rose-400 block">¥3.85 億円</span>
          <span className="text-[10px] text-[#64748b]">極端な相場下での最大予想損失</span>
        </div>

        <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-1">
          <span className="text-[#94a3b8] text-[11px] block">{isJa ? '99% Expected Shortfall (ES)' : '99% Expected Shortfall'}</span>
          <span className="text-xl font-bold text-rose-500 block">¥4.41 億円</span>
          <span className="text-[10px] text-[#64748b]">99% VaR 超過時の平均期待テール損失</span>
        </div>

        <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-1">
          <span className="text-[#94a3b8] text-[11px] block">{isJa ? 'リスク限度枠使用率 (Limit Util.)' : 'Risk Limit Utilization'}</span>
          <span className="text-xl font-bold text-emerald-400 block">42.5%</span>
          <span className="text-[10px] text-emerald-500">限度枠 (10.0 億円) 内に収容</span>
        </div>
      </div>

      {/* Sensitivities Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Table Sensitivities (6 cols) */}
        <div className="lg:col-span-6 bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
            <span>{isJa ? 'ポートフォリオ為替感応度 (Sensitivities / Greeks)' : 'Portfolio Sensitivity Matrix'}</span>
            <span className="text-[10px] text-[#38bdf8]">FIRST ORDER DELTAS</span>
          </h3>

          <table className="w-full text-left text-[#cbd5e1]">
            <thead className="bg-[#182030] text-[#64748b]">
              <tr>
                <th className="py-1.5 px-2">RISK FACTOR</th>
                <th className="py-1.5 px-2">SHOCK UNIT</th>
                <th className="py-1.5 px-2 text-right">IMPACT (JPY)</th>
                <th className="py-1.5 px-2 text-right">EXPOSURE IMPACT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              <tr className="hover:bg-[#182234] transition">
                <td className="py-2.5 px-2 font-bold text-white">ΔP / ΔFX Spot</td>
                <td className="py-2.5 px-2 text-[#94a3b8]">USD/JPY 1% (1.54 JPY) Move</td>
                <td className="py-2.5 px-2 text-right text-rose-400 font-bold">¥2.15 億円</td>
                <td className="py-2.5 px-2 text-right text-[#38bdf8]">未ヘッジ $140M に直結</td>
              </tr>
              <tr className="hover:bg-[#182234] transition">
                <td className="py-2.5 px-2 font-bold text-white">ΔP / ΔForward Points</td>
                <td className="py-2.5 px-2 text-[#94a3b8]">10 Pips (10 銭) Shift</td>
                <td className="py-2.5 px-2 text-right text-amber-300 font-bold">¥2,800 万円</td>
                <td className="py-2.5 px-2 text-right text-[#94a3b8]">為替予約 $280M MTM 影響</td>
              </tr>
              <tr className="hover:bg-[#182234] transition">
                <td className="py-2.5 px-2 font-bold text-white">ΔP / ΔVolatility</td>
                <td className="py-2.5 px-2 text-[#94a3b8]">1.0% Vol Expansion</td>
                <td className="py-2.5 px-2 text-right text-sky-300 font-bold">¥1,200 万円</td>
                <td className="py-2.5 px-2 text-right text-[#94a3b8]">オプション抽象 Vega 影響</td>
              </tr>
              <tr className="hover:bg-[#182234] transition">
                <td className="py-2.5 px-2 font-bold text-white">ΔP / ΔCross Basis</td>
                <td className="py-2.5 px-2 text-[#94a3b8]">10 bps Basis Widening</td>
                <td className="py-2.5 px-2 text-right text-purple-300 font-bold">¥1,850 万円</td>
                <td className="py-2.5 px-2 text-right text-[#94a3b8]">通貨スワップ調達コスト</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* VaR Distribution Chart (6 cols) */}
        <div className="lg:col-span-6 bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2">
            {isJa ? 'VaR & Expected Shortfall 確率分布' : 'VaR & Expected Shortfall Distribution'}
          </h3>
          <ReactECharts option={varChartOption} style={{ height: '220px' }} />
        </div>
      </div>
    </div>
  );
};
