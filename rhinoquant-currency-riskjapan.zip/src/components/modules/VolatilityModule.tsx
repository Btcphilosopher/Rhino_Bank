// RHINOQUANT JAPAN - FX Volatility Surface Module

import React from 'react';
import { Locale, VolatilityPoint } from '../../types';
import { getTranslation } from '../../i18n/translations';
import ReactECharts from 'echarts-for-react';
import { Activity, Sliders } from 'lucide-react';

interface VolatilityModuleProps {
  locale: Locale;
  volData: VolatilityPoint[];
}

export const VolatilityModule: React.FC<VolatilityModuleProps> = ({ locale, volData }) => {
  const isJa = locale === 'ja-JP';

  // Volatility Smile Chart for 3M Tenor
  const smileOption = {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis', backgroundColor: '#1e293b', borderColor: '#334155', textStyle: { color: '#f8fafc', fontSize: 12 } },
    legend: { textStyle: { color: '#94a3b8', fontSize: 11 }, top: 0 },
    grid: { left: '3%', right: '4%', bottom: '5%', top: '15%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['25D Put', '10D Put', 'ATM (At-The-Money)', '10D Call', '25D Call'],
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 }
    },
    yAxis: {
      type: 'value',
      scale: true,
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#94a3b8', fontSize: 11, formatter: '{value}%' }
    },
    series: [
      {
        name: '3M Volatility Smile',
        type: 'line',
        smooth: true,
        data: [10.80, 10.35, 10.15, 9.95, 9.92],
        lineStyle: { color: '#38bdf8', width: 2.5 },
        itemStyle: { color: '#38bdf8' }
      }
    ]
  };

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? 'USD/JPY インプライド・ボラティリティ・サーフェス' : 'USD/JPY IMPLIED VOLATILITY SURFACE'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              ATM Volatility | Risk Reversal (RR) | Butterfly (BF) デルタ・スマイル構造
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-amber-950 text-amber-300 border border-amber-700/40 rounded text-[10px] font-semibold">
          SYNTHETIC SURFACE
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7 bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2">
            {isJa ? 'テナー別 ATM & デルタ・ボラティリティ構造' : 'Tenor Volatility Term Structure'}
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[#cbd5e1]">
              <thead className="bg-[#182030] text-[#64748b]">
                <tr>
                  <th className="py-1.5 px-2">TENOR</th>
                  <th className="py-1.5 px-2 text-right">DAYS</th>
                  <th className="py-1.5 px-2 text-right">ATM VOL (%)</th>
                  <th className="py-1.5 px-2 text-right">25D RR (%)</th>
                  <th className="py-1.5 px-2 text-right">25D BF (%)</th>
                  <th className="py-1.5 px-2 text-right">25D PUT</th>
                  <th className="py-1.5 px-2 text-right">25D CALL</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                {volData.map(v => (
                  <tr key={v.tenor} className="hover:bg-[#182234] transition">
                    <td className="py-2.5 px-2 font-bold text-[#38bdf8]">{v.tenor}</td>
                    <td className="py-2.5 px-2 text-right text-[#94a3b8]">{v.days}d</td>
                    <td className="py-2.5 px-2 text-right text-emerald-400 font-bold">{v.atmVol.toFixed(2)}%</td>
                    <td className="py-2.5 px-2 text-right text-rose-300">{v.rr25.toFixed(2)}%</td>
                    <td className="py-2.5 px-2 text-right text-amber-300">{v.bf25.toFixed(2)}%</td>
                    <td className="py-2.5 px-2 text-right text-[#cbd5e1]">{v.vol25Put.toFixed(2)}%</td>
                    <td className="py-2.5 px-2 text-right text-[#cbd5e1]">{v.vol25Call.toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-5 bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2">
            {isJa ? '3M ボラティリティ・スマイル (Smile Curve)' : '3M Volatility Smile Curve'}
          </h3>
          <ReactECharts option={smileOption} style={{ height: '220px' }} />
        </div>
      </div>
    </div>
  );
};
