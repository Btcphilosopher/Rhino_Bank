// RHINOQUANT JAPAN - Data Quality & Provenance Module

import React from 'react';
import { Locale } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { Database, ShieldCheck, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';

interface DataQualityModuleProps {
  locale: Locale;
}

export const DataQualityModule: React.FC<DataQualityModuleProps> = ({ locale }) => {
  const isJa = locale === 'ja-JP';

  const provenanceFeeds = [
    { id: 'FEED-USDJPY-01', venue: 'TOKYO_DESK', metric: 'USD/JPY Spot', quality: 'SYNTHETIC_CIP', latency: '2ms', status: 'SYNTHETIC' },
    { id: 'FEED-CME-01', venue: 'CME_GLOBEX', metric: 'CME JPY Futures (JYZ26)', quality: 'SYNTHETIC_CIP', latency: '4ms', status: 'SYNTHETIC' },
    { id: 'FEED-TFX-01', venue: 'TFX_TOKYO', metric: 'Click365 USD/JPY', quality: 'SYNTHETIC_CIP', latency: '3ms', status: 'SYNTHETIC' },
    { id: 'FEED-LIBOR-01', venue: 'BOJ_TONA_SOFR', metric: 'Interest Rate Curve', quality: 'SYNTHETIC_CIP', latency: '1ms', status: 'SYNTHETIC' },
  ];

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? 'データ品質・由来 (Data Provenance & Lineage) マトリクス' : 'DATA QUALITY & PROVENANCE MATRIX'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              市場データフィード | 信頼性スコア | 合成データ区分明示
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-amber-950 text-amber-300 border border-amber-700/40 rounded text-[10px] font-semibold">
          SYNTHETIC REGIME
        </span>
      </div>

      <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
        <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
          <span>{isJa ? 'データソース品質監査ログ' : 'Market Data Feed Provenance Audit'}</span>
          <span className="text-[10px] text-emerald-400">100% AUDIT VERIFIED</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[#cbd5e1]">
            <thead className="bg-[#182030] text-[#64748b]">
              <tr>
                <th className="py-1.5 px-2">FEED ID</th>
                <th className="py-1.5 px-2">VENUE / SOURCE</th>
                <th className="py-1.5 px-2">INSTRUMENT / METRIC</th>
                <th className="py-1.5 px-2">QUALITY FLAG</th>
                <th className="py-1.5 px-2 text-right">LATENCY</th>
                <th className="py-1.5 px-2 text-center">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {provenanceFeeds.map(f => (
                <tr key={f.id} className="hover:bg-[#182234] transition">
                  <td className="py-2.5 px-2 font-bold text-[#38bdf8]">{f.id}</td>
                  <td className="py-2.5 px-2 text-white font-semibold">{f.venue}</td>
                  <td className="py-2.5 px-2 text-[#cbd5e1]">{f.metric}</td>
                  <td className="py-2.5 px-2 text-emerald-300">{f.quality}</td>
                  <td className="py-2.5 px-2 text-right font-mono text-[#94a3b8]">{f.latency}</td>
                  <td className="py-2.5 px-2 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-amber-950 text-amber-300 border border-amber-700/40 font-bold">
                      {f.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
