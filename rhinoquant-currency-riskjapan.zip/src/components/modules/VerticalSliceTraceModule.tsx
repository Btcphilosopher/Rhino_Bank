// RHINOQUANT JAPAN - 20-Step Vertical Slice Lineage Trace Wizard

import React, { useState } from 'react';
import { Locale } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { VERTICAL_SLICE_STEPS } from '../../data/syntheticData';
import { Zap, ChevronRight, CheckCircle2, Play, RefreshCw, Calculator } from 'lucide-react';

interface VerticalSliceTraceModuleProps {
  locale: Locale;
}

interface ExpandedStepDetails {
  module: string;
  inputs: string;
  formulaOrModel: string;
  outputs: string;
}

const getStepDetails = (stepNum: number, dataSnippet: string): ExpandedStepDetails => {
  switch (stepNum) {
    case 1:
      return {
        module: 'MARKET_DATA',
        inputs: 'USD/JPY Spot Reference Rate (Broker Feeds)',
        formulaOrModel: 'S_mid = (S_bid + S_ask) / 2',
        outputs: dataSnippet
      };
    case 2:
      return {
        module: 'YIELD_CURVES',
        inputs: 'TONA Overnight Rate, SOFR Overnight Rate, Basis Swaps',
        formulaOrModel: 'DF(T) = exp(-r * T)',
        outputs: dataSnippet
      };
    case 3:
      return {
        module: 'FUTURES',
        inputs: 'CME JPY Currency Futures Specifications',
        formulaOrModel: 'Notional = Multiplier * Contracts',
        outputs: dataSnippet
      };
    case 4:
      return {
        module: 'FORWARD_CURVE',
        inputs: 'Spot Rate, JPY Curve, USD Curve, Cross-Currency Basis',
        formulaOrModel: 'F = S * (1 + r_dom * T) / (1 + r_for * T)',
        outputs: dataSnippet
      };
    case 5:
      return {
        module: 'FUTURES',
        inputs: 'Exchange Quarterly Futures Contract Prices',
        formulaOrModel: 'Interpolate(Futures_Curve)',
        outputs: dataSnippet
      };
    case 6:
      return {
        module: 'FORWARD_POINTS',
        inputs: 'Outright Forward Rates, Spot Rate',
        formulaOrModel: 'Points = (Forward - Spot) * 100 (pips/sen)',
        outputs: dataSnippet
      };
    case 7:
      return {
        module: 'BASIS_RISK',
        inputs: 'Futures Contract Price, CIP Forward Rate',
        formulaOrModel: 'Basis = Futures_Price - Forward_Rate',
        outputs: dataSnippet
      };
    case 8:
      return {
        module: 'EXPOSURES',
        inputs: 'ERP Order Ledgers & Invoiced Transactions',
        formulaOrModel: 'MTM_JPY = Amount_USD * Spot_USD/JPY',
        outputs: dataSnippet
      };
    case 9:
      return {
        module: 'EXPOSURES',
        inputs: 'Cash Flow Schedule, Settlement Calendars',
        formulaOrModel: 'Bucket(T_maturity) ➔ [Q4, Q1, Q2]',
        outputs: dataSnippet
      };
    case 10:
      return {
        module: 'HEDGING',
        inputs: 'Corporate Receivables, Active Hedges',
        formulaOrModel: 'Hedge_Ratio = Hedged_Amount / Total_Exposure',
        outputs: dataSnippet
      };
    case 11:
      return {
        module: 'HEDGING',
        inputs: 'CME Contract Count, Forward Notionals',
        formulaOrModel: 'Notional_JPY = Contracts * Multiplier + Fwd_USD * Fwd_Rate',
        outputs: dataSnippet
      };
    case 12:
      return {
        module: 'RISK_ENGINE',
        inputs: 'Exchange Price Deltas, Margin Accounts',
        formulaOrModel: 'Daily_VM = contracts * (P_t - P_t-1) * Multiplier',
        outputs: dataSnippet
      };
    case 13:
      return {
        module: 'VALUATION',
        inputs: 'Forward Curves, Active Hedges, Discount Factors',
        formulaOrModel: 'Net_MTM = Sum(Hedge_i * DF_dom(T_i))',
        outputs: dataSnippet
      };
    case 14:
      return {
        module: 'STRESS_LAB',
        inputs: 'Shock Vector: Spot -5%, Basis +15 bps',
        formulaOrModel: 'P&L_Shock = unhedged * dSpot + hedged * dHedge',
        outputs: dataSnippet
      };
    case 15:
      return {
        module: 'STRESS_LAB',
        inputs: 'Shock Vector: Spot +5%, Basis -10 bps',
        formulaOrModel: 'P&L_Shock = unhedged * dSpot + hedged * dHedge',
        outputs: dataSnippet
      };
    case 16:
      return {
        module: 'RISK_ENGINE',
        inputs: 'Unhedged Exposures, Historic JPY Daily Volatility',
        formulaOrModel: 'VaR_99 = Exposure_JPY * Vol_1D * 2.326',
        outputs: dataSnippet
      };
    case 17:
      return {
        module: 'FUTURES',
        inputs: 'Quarterly Contract Basis Curve',
        formulaOrModel: 'Roll_Yield = (Futures_Z - Futures_H) / Price_Z * (365 / days)',
        outputs: dataSnippet
      };
    case 18:
      return {
        module: 'RECONCILIATION',
        inputs: 'Market Data Ingestion vs. Forward Curve vs. SAP S/4HANA',
        formulaOrModel: 'Abs(Val_Source - Val_Target) < Tolerance_Threshold',
        outputs: dataSnippet
      };
    case 19:
      return {
        module: 'REPORTING',
        inputs: 'All Valuations, Risk Metrics, Reconciliation Audits',
        formulaOrModel: 'TreasuryReportSchema.validate(Data)',
        outputs: dataSnippet
      };
    case 20:
    default:
      return {
        module: 'AUDIT_TRAIL',
        inputs: 'Hash Chain, Database Lineage Keys',
        formulaOrModel: 'VerifyProvenanceChain(Step_1 ➔ Step_20)',
        outputs: dataSnippet
      };
  }
};

export const VerticalSliceTraceModule: React.FC<VerticalSliceTraceModuleProps> = ({ locale }) => {
  const isJa = locale === 'ja-JP';

  const [activeStepId, setActiveStepId] = useState<number>(1);

  const activeStep = VERTICAL_SLICE_STEPS.find(s => s.stepNumber === activeStepId) || VERTICAL_SLICE_STEPS[0];
  const activeDetails = getStepDetails(activeStep.stepNumber, activeStep.dataSnippet);

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <Zap className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide flex items-center gap-2">
              <span>{isJa ? '第1垂直スライス 20段階全血統トレースウィザード' : 'FIRST VERTICAL SLICE 20-STEP LINEAGE TRACE'}</span>
              <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-700/40 px-1.5 py-0.5 rounded">
                AUDIT TRACEABLE
              </span>
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              市場データ受領 ➔ CIPカーブ ➔ 先物清算 ➔ エクスポージャー ➔ ヘッジ配分 ➔ MTM ➔ VaR/ES ➔ 照合 ➔ レポート
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid: Steps List (5 cols) + Step Details (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Step List (5 cols) */}
        <div className="lg:col-span-5 bg-[#121722] border border-[#232e42] rounded p-3 space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
            <span>{isJa ? '計算実行ステップ (全20工程)' : '20-Step Lineage Pipeline'}</span>
            <span className="text-[10px] text-emerald-400">20 / 20 EXECUTED</span>
          </h3>

          <div className="space-y-1">
            {VERTICAL_SLICE_STEPS.map(st => {
              const isSelected = activeStepId === st.stepNumber;
              const details = getStepDetails(st.stepNumber, st.dataSnippet);
              return (
                <button
                  key={st.stepNumber}
                  onClick={() => setActiveStepId(st.stepNumber)}
                  className={`w-full flex items-center justify-between p-2 rounded border text-left transition cursor-pointer ${
                    isSelected
                      ? 'bg-[#1e293b] border-[#38bdf8] text-white shadow-sm'
                      : 'bg-[#161f2e] border-[#222f44] text-[#94a3b8] hover:bg-[#1c283c] hover:text-[#e2e8f0]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                      isSelected ? 'bg-[#38bdf8] text-black' : 'bg-[#26334a] text-[#cbd5e1]'
                    }`}>
                      {st.stepNumber}
                    </span>
                    <div className="truncate">
                      <div className="font-semibold text-[11px] truncate">
                        {isJa ? st.titleJa : st.titleEn}
                      </div>
                      <div className="text-[9px] text-[#64748b] truncate">{details.module}</div>
                    </div>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-[#38bdf8]' : 'text-[#475569]'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Step Detail Card (7 cols) */}
        <div className="lg:col-span-7 bg-[#121722] border border-[#232e42] rounded p-4 space-y-4">
          <div className="border-b border-[#1e293b] pb-3 flex items-start justify-between">
            <div>
              <div className="text-xs text-[#38bdf8] font-bold">
                STEP {activeStep.stepNumber} OF 20 — {activeDetails.module}
              </div>
              <h3 className="text-base font-bold text-white mt-0.5">
                {isJa ? activeStep.titleJa : activeStep.titleEn}
              </h3>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-700/40 font-bold">
              EXECUTED_OK
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <span className="text-[#94a3b8] font-semibold block mb-1">工程概要 (Description):</span>
              <p className="text-[#cbd5e1] leading-relaxed bg-[#172030] p-2.5 rounded border border-[#253248]">
                {isJa ? activeStep.descriptionJa : activeStep.descriptionEn}
              </p>
            </div>

            <div>
              <span className="text-[#94a3b8] font-semibold block mb-1">入力データ (Inputs):</span>
              <div className="bg-[#172030] p-2.5 rounded border border-[#253248] text-amber-300 font-mono">
                {activeDetails.inputs}
              </div>
            </div>

            <div>
              <span className="text-[#94a3b8] font-semibold block mb-1">数理式・計算モデル (Formula / Model):</span>
              <div className="bg-[#172030] p-2.5 rounded border border-[#253248] text-sky-300 font-mono font-bold">
                {activeDetails.formulaOrModel}
              </div>
            </div>

            <div>
              <span className="text-[#94a3b8] font-semibold block mb-1">算出出力 (Outputs):</span>
              <div className="bg-[#172030] p-2.5 rounded border border-[#253248] text-emerald-300 font-mono font-bold">
                {activeDetails.outputs}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
