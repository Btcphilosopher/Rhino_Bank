// RHINOQUANT JAPAN - Risk Scenario Laboratory

import React, { useState } from 'react';
import { Locale } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { runStressScenario } from '../../quant/engine';
import { SlidersHorizontal, AlertOctagon, TrendingDown, RefreshCw, BarChart2 } from 'lucide-react';

interface ScenarioLaboratoryModuleProps {
  locale: Locale;
}

export const ScenarioLaboratoryModule: React.FC<ScenarioLaboratoryModuleProps> = ({ locale }) => {
  const isJa = locale === 'ja-JP';

  // Interactive controls
  const [spotUsdJpy, setSpotUsdJpy] = useState<number>(154.25);
  const [fxShockPct, setFxShockPct] = useState<number>(-5.0); // -5% JPY appreciation
  const [volShockPct, setVolShockPct] = useState<number>(25.0); // +25% Volatility spike
  const [basisShockBps, setBasisShockBps] = useState<number>(15.0); // +15 bps basis widening

  const baseNetExposureUsd = 420000000; // $420M
  const hedgedUsd = 280000000; // $280M

  const apprecScenario = runStressScenario('急速な円高ショック (-5% JPY Appreciation)', baseNetExposureUsd, hedgedUsd, spotUsdJpy, fxShockPct, volShockPct);
  const depprecScenario = runStressScenario('大幅な円安進行 (+5% JPY Depreciation)', baseNetExposureUsd, hedgedUsd, spotUsdJpy, 5.0, volShockPct);
  const severeScenario = runStressScenario('超過激円高ショック (-10% Severe JPY Shock)', baseNetExposureUsd, hedgedUsd, spotUsdJpy, -10.0, volShockPct);

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? '多角化リスク・シナリオ・ラボラトリー' : 'RISK SCENARIO LABORATORY'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              単一・複数要因ショックの定量試算 | 未ヘッジ損益 vs ヘッジオフセット比較
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-amber-950 text-amber-300 border border-amber-700/40 rounded text-[10px] font-semibold">
          STRESS TESTING
        </span>
      </div>

      {/* Interactive Controls & Live Output Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Controls (4 cols) */}
        <div className="lg:col-span-4 bg-[#121722] border border-[#232e42] rounded p-3 space-y-3">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2">
            {isJa ? 'ショックパラメーター調整' : 'Shock Parameter Adjustments'}
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-[#94a3b8]">USD/JPY スポット変動ショック (%)</span>
                <span className="font-bold text-[#38bdf8]">{fxShockPct >= 0 ? '+' : ''}{fxShockPct}%</span>
              </div>
              <input
                type="range"
                min="-15"
                max="15"
                step="0.5"
                value={fxShockPct}
                onChange={e => setFxShockPct(Number(e.target.value))}
                className="w-full accent-[#38bdf8]"
              />
              <div className="flex justify-between text-[9px] text-[#64748b]">
                <span>-15% (円高)</span>
                <span>0%</span>
                <span>+15% (円安)</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-[#94a3b8]">ボラティリティ急拡大ショック (%)</span>
                <span className="font-bold text-amber-300">+{volShockPct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={volShockPct}
                onChange={e => setVolShockPct(Number(e.target.value))}
                className="w-full accent-amber-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-[#94a3b8]">通貨スワップ・ベース拡大 (bps)</span>
                <span className="font-bold text-purple-300">+{basisShockBps} bps</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                step="5"
                value={basisShockBps}
                onChange={e => setBasisShockBps(Number(e.target.value))}
                className="w-full accent-purple-400"
              />
            </div>
          </div>
        </div>

        {/* Live Scenario Comparison Table (8 cols) */}
        <div className="lg:col-span-8 bg-[#121722] border border-[#232e42] rounded p-3 space-y-3">
          <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
            <span>{isJa ? 'シナリオ試算結果比較 (Base Case vs Shocked Case)' : 'Scenario Stress Results'}</span>
            <span className="text-[10px] text-emerald-400">DECIMAL PRECISION</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[#cbd5e1]">
              <thead className="bg-[#182030] text-[#64748b]">
                <tr>
                  <th className="py-1.5 px-2">シナリオ名</th>
                  <th className="py-1.5 px-2 text-right">ショック後レート</th>
                  <th className="py-1.5 px-2 text-right">未ヘッジ損失</th>
                  <th className="py-1.5 px-2 text-right">ヘッジ損益</th>
                  <th className="py-1.5 px-2 text-right">全社純損益</th>
                  <th className="py-1.5 px-2 text-right">ヘッジ効果</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]">
                <tr className="hover:bg-[#182234] transition">
                  <td className="py-2.5 px-2 font-bold text-white">ベースケース (現在値)</td>
                  <td className="py-2.5 px-2 text-right font-bold text-sky-300">154.25 JPY</td>
                  <td className="py-2.5 px-2 text-right text-[#94a3b8]">¥0</td>
                  <td className="py-2.5 px-2 text-right text-[#94a3b8]">¥0</td>
                  <td className="py-2.5 px-2 text-right font-bold text-white">¥0</td>
                  <td className="py-2.5 px-2 text-right text-emerald-400">100.0%</td>
                </tr>

                <tr className="hover:bg-[#182234] transition bg-[#1a2336]">
                  <td className="py-2.5 px-2 font-bold text-[#38bdf8]">{apprecScenario.scenarioName}</td>
                  <td className="py-2.5 px-2 text-right font-bold text-white">{apprecScenario.shockedSpot.toFixed(2)} JPY</td>
                  <td className="py-2.5 px-2 text-right text-rose-400 font-semibold">
                    ¥{(apprecScenario.unhedgedLossJpy / 1e6).toFixed(0)}M
                  </td>
                  <td className="py-2.5 px-2 text-right text-emerald-400 font-semibold">
                    +¥{(apprecScenario.hedgeGainJpy / 1e6).toFixed(0)}M
                  </td>
                  <td className={`py-2.5 px-2 text-right font-bold ${apprecScenario.shockedPnlJpy >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {apprecScenario.shockedPnlJpy >= 0 ? '+' : ''}¥{(apprecScenario.shockedPnlJpy / 1e6).toFixed(0)}M
                  </td>
                  <td className="py-2.5 px-2 text-right font-bold text-emerald-300">
                    {apprecScenario.hedgeEffectivenessPct.toFixed(1)}%
                  </td>
                </tr>

                <tr className="hover:bg-[#182234] transition">
                  <td className="py-2.5 px-2 font-bold text-white">{depprecScenario.scenarioName}</td>
                  <td className="py-2.5 px-2 text-right font-bold text-white">{depprecScenario.shockedSpot.toFixed(2)} JPY</td>
                  <td className="py-2.5 px-2 text-right text-emerald-400 font-semibold">
                    +¥{(depprecScenario.unhedgedLossJpy / 1e6).toFixed(0)}M
                  </td>
                  <td className="py-2.5 px-2 text-right text-rose-400 font-semibold">
                    -¥{(Math.abs(depprecScenario.hedgeGainJpy) / 1e6).toFixed(0)}M
                  </td>
                  <td className="py-2.5 px-2 text-right font-bold text-emerald-400">
                    +¥{(depprecScenario.shockedPnlJpy / 1e6).toFixed(0)}M
                  </td>
                  <td className="py-2.5 px-2 text-right font-bold text-emerald-300">
                    {depprecScenario.hedgeEffectivenessPct.toFixed(1)}%
                  </td>
                </tr>

                <tr className="hover:bg-[#182234] transition">
                  <td className="py-2.5 px-2 font-bold text-rose-300">{severeScenario.scenarioName}</td>
                  <td className="py-2.5 px-2 text-right font-bold text-white">{severeScenario.shockedSpot.toFixed(2)} JPY</td>
                  <td className="py-2.5 px-2 text-right text-rose-400 font-semibold">
                    ¥{(severeScenario.unhedgedLossJpy / 1e6).toFixed(0)}M
                  </td>
                  <td className="py-2.5 px-2 text-right text-emerald-400 font-semibold">
                    +¥{(severeScenario.hedgeGainJpy / 1e6).toFixed(0)}M
                  </td>
                  <td className="py-2.5 px-2 text-right font-bold text-emerald-400">
                    +¥{(severeScenario.shockedPnlJpy / 1e6).toFixed(0)}M
                  </td>
                  <td className="py-2.5 px-2 text-right font-bold text-emerald-300">
                    {severeScenario.hedgeEffectivenessPct.toFixed(1)}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
