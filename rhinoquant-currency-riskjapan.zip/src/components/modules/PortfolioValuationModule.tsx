// RHINOQUANT JAPAN - Portfolio Valuation Module

import React from 'react';
import { Locale, HedgePosition } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { PieChart, Calculator, CheckCircle2, TrendingUp } from 'lucide-react';

interface PortfolioValuationModuleProps {
  locale: Locale;
  hedges: HedgePosition[];
}

export const PortfolioValuationModule: React.FC<PortfolioValuationModuleProps> = ({ locale, hedges }) => {
  const isJa = locale === 'ja-JP';

  const totalUnrealizedPnl = hedges.reduce((sum, h) => sum + h.unrealizedPnlJpy, 0);

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <PieChart className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? 'ポートフォリオ時価評価 & P&L 計上エンジン' : 'PORTFOLIO VALUATION & P&L ENGINE'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              Decimal 精密評価 | 連続複利割引キャッシュフロー | 評価損益 (MTM P&L)
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-emerald-950 text-emerald-300 border border-emerald-700/40 rounded text-[10px] font-semibold">
          MTM AUDITED
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-1">
          <span className="text-[#94a3b8] text-[11px] block">{isJa ? 'ポートフォリオ総評価額 (Total MTM)' : 'Total Portfolio MTM'}</span>
          <span className="text-2xl font-bold text-emerald-400 block">+¥113,000,000 JPY</span>
          <span className="text-[10px] text-emerald-500 font-semibold">含み益 (+1.13 億円)</span>
        </div>

        <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-1">
          <span className="text-[#94a3b8] text-[11px] block">{isJa ? '実現損益 (Realized P&L)' : 'Realized P&L'}</span>
          <span className="text-2xl font-bold text-sky-300 block">+¥18,500,000 JPY</span>
          <span className="text-[10px] text-[#64748b]">先物変動証拠金受領済</span>
        </div>

        <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-1">
          <span className="text-[#94a3b8] text-[11px] block">{isJa ? '未実現評価損益 (Unrealized P&L)' : 'Unrealized P&L'}</span>
          <span className="text-2xl font-bold text-emerald-400 block">+¥113,000,000 JPY</span>
          <span className="text-[10px] text-[#64748b]">時価評価計上額</span>
        </div>
      </div>
    </div>
  );
};
