// RHINOQUANT JAPAN - Bilingual Risk Reports Module

import React, { useState } from 'react';
import { Locale } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { FileText, Download, Printer, CheckCircle2, Building2, ShieldCheck } from 'lucide-react';

interface ReportsModuleProps {
  locale: Locale;
}

export const ReportsModule: React.FC<ReportsModuleProps> = ({ locale }) => {
  const isJa = locale === 'ja-JP';

  const [selectedReportType, setSelectedReportType] = useState<string>('DAILY_FX_RISK');

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      {/* Banner */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between print:hidden">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? '日英バイリンガル為替リスク＆ガバナンス・レポート発行' : 'BILINGUAL TREASURY & RISK REPORT GENERATOR'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              取締役会・財務委員会・監査部提出用 | 日本語 (ja-JP) & 英語 (en-GB) 完全出力
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 bg-[#172030] hover:bg-[#202d44] border border-[#2e3e5b] text-[#cbd5e1] hover:text-white px-3 py-1.5 rounded text-xs transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span>{isJa ? '印刷 / PDF発行' : 'Print / Save PDF'}</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Container */}
      <div className="bg-[#121722] border border-[#232e42] rounded p-6 space-y-6 text-[#cbd5e1] print:bg-white print:text-black print:p-0">
        {/* Document Header */}
        <div className="border-b-2 border-[#38bdf8] pb-4 flex justify-between items-start">
          <div>
            <div className="text-xl font-bold text-white print:text-black tracking-tight">
              RHINOQUANT JAPAN — DAILY FX CURRENCY RISK REPORT
            </div>
            <div className="text-xs text-[#38bdf8] print:text-blue-800 font-semibold mt-1">
              日次全社為替リスク & 先物イールドカーブ監査報告書
            </div>
          </div>

          <div className="text-right text-[10px] text-[#94a3b8] print:text-gray-600 space-y-0.5">
            <div>REPORT ID: <strong>RPT-JPY-20260921-001</strong></div>
            <div>VALUATION TIME: <strong>2026-09-21 05:28:30 JST</strong></div>
            <div>STATUS: <strong className="text-emerald-400 print:text-green-700">AUDITED [SYNTHETIC]</strong></div>
          </div>
        </div>

        {/* Company & Entity Summary */}
        <div className="bg-[#172030] print:bg-gray-100 p-3 rounded border border-[#26334a] print:border-gray-300 grid grid-cols-2 md:grid-cols-4 gap-3">
          <div>
            <div className="text-[10px] text-[#94a3b8] print:text-gray-500">対象法人 (Legal Entity)</div>
            <div className="font-bold text-white print:text-black">東京インダストリアル・ホールディングス</div>
          </div>
          <div>
            <div className="text-[10px] text-[#94a3b8] print:text-gray-500">報告通貨 (Reporting Currency)</div>
            <div className="font-bold text-sky-300 print:text-blue-900">JPY (日本円)</div>
          </div>
          <div>
            <div className="text-[10px] text-[#94a3b8] print:text-gray-500">総外貨エクスポージャー</div>
            <div className="font-bold text-white print:text-black">$420,000,000 USD (647.8 億円)</div>
          </div>
          <div>
            <div className="text-[10px] text-[#94a3b8] print:text-gray-500">全社ヘッジ比率 (Hedge Ratio)</div>
            <div className="font-bold text-emerald-400 print:text-green-800">66.7% (ヘッジ済 $280M)</div>
          </div>
        </div>

        {/* Executive Summary Section */}
        <div className="space-y-2">
          <h3 className="text-sm font-bold text-white print:text-black border-b border-[#232e42] print:border-gray-300 pb-1">
            1. エグゼクティブ・サマリー (Executive Summary)
          </h3>
          <p className="text-xs leading-relaxed text-[#94a3b8] print:text-gray-800">
            本日時点における当社の総外貨エクスポージャー 4.2 億 USD に対し、為替予約（1.2 億 USD）および CME JPY 通貨先物（1.6 億 USD 相当、3,200 枚）によるヘッジを実施しており、全社ヘッジ比率は 66.7%（目標レンジ 60〜80% に適合）となっております。未ヘッジ残高 1.4 億 USD に対する 1 日 99% VaR は 3.85 億円と算定され、社内規定限度枠（10 億円）を大幅に下回る安全圏で推移しております。
          </p>
        </div>

        {/* Quantitative Metrics Table */}
        <div className="space-y-2">
          <h3 className="text-sm font-bold text-white print:text-black border-b border-[#232e42] print:border-gray-300 pb-1">
            2. 主要リスク指標 & 評価損益 (Quantitative Metrics & MTM)
          </h3>

          <table className="w-full text-left border border-[#232e42] print:border-gray-300">
            <thead className="bg-[#182030] print:bg-gray-200 text-[#64748b] print:text-gray-700">
              <tr>
                <th className="p-2">RISK METRIC</th>
                <th className="p-2 text-right">VALUE</th>
                <th className="p-2 text-right">LIMIT / TARGET</th>
                <th className="p-2 text-center">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b] print:divide-gray-300 text-xs">
              <tr>
                <td className="p-2 font-bold text-white print:text-black">ポートフォリオ評価額 (Portfolio MTM)</td>
                <td className="p-2 text-right text-emerald-400 print:text-green-700 font-bold">+1.13 億円 JPY</td>
                <td className="p-2 text-right text-[#94a3b8] print:text-gray-600">N/A</td>
                <td className="p-2 text-center text-emerald-400 font-bold">PROFIT</td>
              </tr>
              <tr>
                <td className="p-2 font-bold text-white print:text-black">99% 日次 VaR (1D Parametric)</td>
                <td className="p-2 text-right text-rose-400 print:text-red-700 font-bold">3.85 億円 JPY</td>
                <td className="p-2 text-right text-[#94a3b8] print:text-gray-600">10.00 億円 JPY</td>
                <td className="p-2 text-center text-emerald-400 font-bold">PASS (42.5%)</td>
              </tr>
              <tr>
                <td className="p-2 font-bold text-white print:text-black">99% Expected Shortfall (ES)</td>
                <td className="p-2 text-right text-rose-400 print:text-red-700 font-bold">4.41 億円 JPY</td>
                <td className="p-2 text-right text-[#94a3b8] print:text-gray-600">15.00 億円 JPY</td>
                <td className="p-2 text-center text-emerald-400 font-bold">PASS</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
