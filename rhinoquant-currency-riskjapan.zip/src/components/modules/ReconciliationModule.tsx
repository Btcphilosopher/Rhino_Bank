// RHINOQUANT JAPAN - Reconciliation Module

import React from 'react';
import { Locale, ReconciliationItem } from '../../types';
import { getTranslation } from '../../i18n/translations';
import { CheckCircle2, AlertTriangle, RefreshCw, ShieldCheck } from 'lucide-react';

interface ReconciliationModuleProps {
  locale: Locale;
  items: ReconciliationItem[];
}

export const ReconciliationModule: React.FC<ReconciliationModuleProps> = ({ locale, items }) => {
  const isJa = locale === 'ja-JP';

  return (
    <div className="space-y-4 p-4 font-mono text-xs">
      <div className="bg-[#121722] border border-[#232e42] rounded p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[#1e293b] border border-[#3b82f6]/40 p-2 rounded text-[#38bdf8]">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">
              {isJa ? '市場データ・評価・帳簿 自動照合エンジン (Reconciliation)' : 'MARKET DATA & VALUATION RECONCILIATION'}
            </h2>
            <p className="text-[#94a3b8] text-[11px]">
              市場データ ↔ イールドカーブ ↔ 評価エンジン ↔ ERP 帳簿 ↔ ヘッジ台帳
            </p>
          </div>
        </div>
        <span className="px-2 py-1 bg-emerald-950 text-emerald-300 border border-emerald-700/40 rounded text-[10px] font-semibold">
          3 MATCHED / 1 WARNING
        </span>
      </div>

      <div className="bg-[#121722] border border-[#232e42] rounded p-3 space-y-2">
        <h3 className="font-semibold text-white border-b border-[#1e293b] pb-2 flex items-center justify-between">
          <span>{isJa ? '照合結果 & 例外監査ログ' : 'Reconciliation Audit Matrix'}</span>
          <span className="text-[10px] text-[#38bdf8]">AUTOMATED PASS: 100%</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[#cbd5e1]">
            <thead className="bg-[#182030] text-[#64748b]">
              <tr>
                <th className="py-1.5 px-2">ID</th>
                <th className="py-1.5 px-2">SOURCE MODULE</th>
                <th className="py-1.5 px-2">TARGET MODULE</th>
                <th className="py-1.5 px-2">FIELD / CHECK</th>
                <th className="py-1.5 px-2 text-right">SOURCE VALUE</th>
                <th className="py-1.5 px-2 text-right">TARGET VALUE</th>
                <th className="py-1.5 px-2 text-center">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]">
              {items.map(item => (
                <tr key={item.id} className="hover:bg-[#182234] transition">
                  <td className="py-2.5 px-2 font-bold text-[#38bdf8]">{item.id}</td>
                  <td className="py-2.5 px-2 text-white font-semibold">{item.sourceModule}</td>
                  <td className="py-2.5 px-2 text-[#94a3b8]">{item.targetModule}</td>
                  <td className="py-2.5 px-2 text-white">{item.field}</td>
                  <td className="py-2.5 px-2 text-right font-bold text-white">{item.sourceValue}</td>
                  <td className="py-2.5 px-2 text-right text-emerald-400 font-bold">{item.targetValue}</td>
                  <td className="py-2.5 px-2 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      item.status === 'MATCHED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/40' : 'bg-amber-950 text-amber-300 border border-amber-700/40'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
