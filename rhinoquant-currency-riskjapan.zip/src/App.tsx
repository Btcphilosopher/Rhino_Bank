// RHINOQUANT JAPAN - Main Application Container

import React, { useState } from 'react';
import { Locale, SimulationRegime } from './types';
import { Header } from './components/common/Header';
import { Sidebar, NavModuleId } from './components/common/Sidebar';

// Import All Analytics & Risk Modules
import { MarketOverviewModule } from './components/modules/MarketOverviewModule';
import { ExposureWorkbenchModule } from './components/modules/ExposureWorkbenchModule';
import { FuturesModule } from './components/modules/FuturesModule';
import { CurveTerminalModule } from './components/modules/CurveTerminalModule';
import { VolatilityModule } from './components/modules/VolatilityModule';
import { HedgingModule } from './components/modules/HedgingModule';
import { RiskEngineModule } from './components/modules/RiskEngineModule';
import { ScenarioLaboratoryModule } from './components/modules/ScenarioLaboratoryModule';
import { PortfolioValuationModule } from './components/modules/PortfolioValuationModule';
import { ReconciliationModule } from './components/modules/ReconciliationModule';
import { ModelGovernanceModule } from './components/modules/ModelGovernanceModule';
import { ReportsModule } from './components/modules/ReportsModule';
import { DataQualityModule } from './components/modules/DataQualityModule';
import { VerticalSliceTraceModule } from './components/modules/VerticalSliceTraceModule';
import { SettingsModule } from './components/modules/SettingsModule';

// Synthetic Data Stores
import {
  SYNTHETIC_CURRENCY_PAIRS,
  SYNTHETIC_CURVE_DATA,
  SYNTHETIC_FUTURES,
  SYNTHETIC_EXPOSURES,
  SYNTHETIC_HEDGES,
  SYNTHETIC_RISK_METRICS,
  SYNTHETIC_RECONCILIATION,
  SYNTHETIC_VOLATILITY
} from './data/syntheticData';

export function App() {
  const [locale, setLocale] = useState<Locale>('ja-JP');
  const [regime, setRegime] = useState<SimulationRegime>('NORMAL');
  const [activeModule, setActiveModule] = useState<NavModuleId>('market');

  // Handle active module renderer
  const renderActiveModule = () => {
    switch (activeModule) {
      case 'market':
        return (
          <MarketOverviewModule
            locale={locale}
            currencyPairs={SYNTHETIC_CURRENCY_PAIRS}
            riskMetrics={SYNTHETIC_RISK_METRICS}
            onNavigate={setActiveModule}
          />
        );

      case 'exposure':
        return (
          <ExposureWorkbenchModule
            locale={locale}
            exposures={SYNTHETIC_EXPOSURES}
            hedges={SYNTHETIC_HEDGES}
          />
        );

      case 'futures':
      case 'forwards':
        return (
          <FuturesModule
            locale={locale}
            contracts={SYNTHETIC_FUTURES}
          />
        );

      case 'curves':
        return (
          <CurveTerminalModule
            locale={locale}
            curveData={SYNTHETIC_CURVE_DATA}
          />
        );

      case 'volatility':
        return (
          <VolatilityModule
            locale={locale}
            volData={SYNTHETIC_VOLATILITY}
          />
        );

      case 'hedging':
        return (
          <HedgingModule
            locale={locale}
            hedges={SYNTHETIC_HEDGES}
          />
        );

      case 'risk':
        return (
          <RiskEngineModule
            locale={locale}
            riskMetrics={SYNTHETIC_RISK_METRICS}
          />
        );

      case 'scenarios':
        return <ScenarioLaboratoryModule locale={locale} />;

      case 'portfolio':
      case 'valuation':
        return (
          <PortfolioValuationModule
            locale={locale}
            hedges={SYNTHETIC_HEDGES}
          />
        );

      case 'reconciliation':
        return (
          <ReconciliationModule
            locale={locale}
            items={SYNTHETIC_RECONCILIATION}
          />
        );

      case 'reports':
        return <ReportsModule locale={locale} />;

      case 'dataQuality':
        return <DataQualityModule locale={locale} />;

      case 'governance':
        return <ModelGovernanceModule locale={locale} />;

      case 'trace':
        return <VerticalSliceTraceModule locale={locale} />;

      case 'settings':
        return (
          <SettingsModule
            locale={locale}
            regime={regime}
            onSelectRegime={setRegime}
            onSelectLocale={setLocale}
          />
        );

      default:
        return (
          <MarketOverviewModule
            locale={locale}
            currencyPairs={SYNTHETIC_CURRENCY_PAIRS}
            riskMetrics={SYNTHETIC_RISK_METRICS}
            onNavigate={setActiveModule}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0d14] text-[#e2e8f0] flex flex-col font-sans antialiased selection:bg-[#38bdf8] selection:text-black">
      {/* Top Navigation Bar */}
      <Header
        locale={locale}
        regime={regime}
        onSelectLocale={setLocale}
        onSelectRegime={setRegime}
        onOpenSettings={() => setActiveModule('settings')}
        onOpenTrace={() => setActiveModule('trace')}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Primary Navigation Sidebar */}
        <Sidebar
          locale={locale}
          activeModule={activeModule}
          onSelectModule={setActiveModule}
        />

        {/* Right Main Content Area */}
        <main className="flex-1 overflow-y-auto custom-scrollbar bg-[#0a0d14]">
          {renderActiveModule()}
        </main>
      </div>
    </div>
  );
}

export default App;
