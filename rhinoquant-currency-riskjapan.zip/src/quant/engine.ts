// RHINOQUANT JAPAN - Institutional Quantitative Analytics & Pricing Engine

import { CurrencyPair, ForwardTenorPoint, FuturesContract, CurveData, ExposureItem, HedgePosition, RiskMetrics, StressScenario, ReconciliationItem, ModelCard } from '../types';

/**
 * FX Forward Pricing via Covered Interest Parity (CIP)
 * Quote convention: JPY per Foreign Currency Unit (e.g., 154.25 JPY = 1 USD)
 * F = S * (1 + r_dom * T) / (1 + r_for * T)
 */
export interface CipPricingResult {
  spotRate: number;
  tenor: string;
  days: number;
  yearFraction: number; // Day count convention ACT/365F
  domRatePct: number; // JPY interest rate %
  forRatePct: number; // Foreign currency interest rate %
  rateDiffPct: number; // (r_dom - r_for)
  basisBps: number; // Cross-currency basis adjustment
  forwardRate: number; // Outright forward rate
  forwardPointsPips: number; // (F - S) in pips (1 pip = 0.01 JPY for JPY pairs)
  premiumDiscountPct: number; // Annualized (F - S)/S * 365/days * 100
  discountFactorDom: number;
  discountFactorFor: number;
  calculationSteps: { step: number; descriptionJa: string; descriptionEn: string; formula: string; value: string }[];
}

export function calculateCipForwardRate(
  spotRate: number,
  days: number,
  domRatePct: number,
  forRatePct: number,
  basisBps: number = 0,
  dayCount: 'ACT/365F' | 'ACT/360' = 'ACT/365F',
  pipMultiplier: number = 100 // 100 for JPY pairs (0.01 = 1 pip)
): CipPricingResult {
  const dayBase = dayCount === 'ACT/365F' ? 365.0 : 360.0;
  const T = days / dayBase;

  const r_dom = domRatePct / 100.0;
  // Foreign rate includes cross-currency basis adjustment if applicable
  const r_for_adj = (forRatePct + basisBps / 100.0) / 100.0;

  // Discrete compounding (CIP)
  const forwardRate = spotRate * ((1 + r_dom * T) / (1 + r_for_adj * T));

  // Forward points in pips (1 pip = 0.01 for JPY pairs)
  const forwardPointsPips = (forwardRate - spotRate) * pipMultiplier;

  // Annualized Premium / Discount
  const premiumDiscountPct = ((forwardRate - spotRate) / spotRate) * (365.0 / days) * 100.0;

  // Discount factors
  const dfDom = Math.exp(-r_dom * T);
  const dfFor = Math.exp(-r_for_adj * T);

  const steps = [
    {
      step: 1,
      descriptionJa: '年換算日数の算出 (ACT/365F)',
      descriptionEn: 'Calculate Year Fraction T (ACT/365F)',
      formula: `T = ${days} / ${dayBase}`,
      value: T.toFixed(6)
    },
    {
      step: 2,
      descriptionJa: '自国金利 (JPY) および外貨金利 (ベース調整済) の適用',
      descriptionEn: 'Apply Domestic (JPY) & Foreign Adjusted Rates',
      formula: `r_dom = ${domRatePct}%, r_for_adj = ${forRatePct}% + (${basisBps} bps) = ${(forRatePct + basisBps/100).toFixed(4)}%`,
      value: `r_dom: ${r_dom.toFixed(6)}, r_for: ${r_for_adj.toFixed(6)}`
    },
    {
      step: 3,
      descriptionJa: 'カバー付き金利平価 (CIP) 方程式によるフォワードレート算出',
      descriptionEn: 'Covered Interest Parity Forward Equation',
      formula: `F = S * (1 + r_dom * T) / (1 + r_for * T)`,
      value: `F = ${spotRate.toFixed(3)} * (1 + ${ (r_dom*T).toFixed(6) }) / (1 + ${ (r_for_adj*T).toFixed(6) }) = ${forwardRate.toFixed(3)}`
    },
    {
      step: 4,
      descriptionJa: 'フォワード・ポイント (銭 / セン) への変換',
      descriptionEn: 'Convert to Forward Points (Pips / Sen)',
      formula: `Points = (F - S) * ${pipMultiplier}`,
      value: `${forwardPointsPips.toFixed(2)} pips`
    },
    {
      step: 5,
      descriptionJa: '連続複利割引係数 (Discount Factors) の導出',
      descriptionEn: 'Derive Continuous Discount Factors',
      formula: `DF = exp(-r * T)`,
      value: `DF_dom: ${dfDom.toFixed(6)}, DF_for: ${dfFor.toFixed(6)}`
    }
  ];

  return {
    spotRate,
    tenor: `${days}D`,
    days,
    yearFraction: T,
    domRatePct,
    forRatePct,
    rateDiffPct: domRatePct - forRatePct,
    basisBps,
    forwardRate,
    forwardPointsPips,
    premiumDiscountPct,
    discountFactorDom: dfDom,
    discountFactorFor: dfFor,
    calculationSteps: steps
  };
}

/**
 * Interpolate curve linearly or log-linearly
 */
export function interpolateRate(
  targetDays: number,
  knownPoints: { days: number; rate: number }[],
  method: 'LINEAR' | 'LOG_LINEAR_DF' = 'LINEAR'
): number {
  if (knownPoints.length === 0) return 0;
  const sorted = [...knownPoints].sort((a, b) => a.days - b.days);

  if (targetDays <= sorted[0].days) return sorted[0].rate;
  if (targetDays >= sorted[sorted.length - 1].days) return sorted[sorted.length - 1].rate;

  for (let i = 0; i < sorted.length - 1; i++) {
    const p1 = sorted[i];
    const p2 = sorted[i + 1];
    if (targetDays >= p1.days && targetDays <= p2.days) {
      const weight = (targetDays - p1.days) / (p2.days - p1.days);
      if (method === 'LINEAR') {
        return p1.rate + weight * (p2.rate - p1.rate);
      } else {
        // Log-linear interpolation on discount factors
        const df1 = Math.exp(-p1.rate * (p1.days / 365.0));
        const df2 = Math.exp(-p2.rate * (p2.days / 365.0));
        const logDf = Math.log(df1) + weight * (Math.log(df2) - Math.log(df1));
        const interpDf = Math.exp(logDf);
        return -Math.log(interpDf) / (targetDays / 365.0);
      }
    }
  }

  return sorted[0].rate;
}

/**
 * Value at Risk (VaR) & Expected Shortfall (ES) Calculations
 */
export function calculateRiskMetrics(
  notionalJpy: number,
  dailyVolPct: number = 0.75, // 0.75% daily volatility ~ 12% annualized
  holdingDays: number = 1
): { var95: number; var99: number; es99: number } {
  // Z-scores: 95% = 1.64485, 99% = 2.32635
  const z95 = 1.64485;
  const z99 = 2.32635;
  const sqrtT = Math.sqrt(holdingDays);

  const sigmaDecimal = dailyVolPct / 100.0;
  const var95 = notionalJpy * sigmaDecimal * z95 * sqrtT;
  const var99 = notionalJpy * sigmaDecimal * z99 * sqrtT;

  // Expected Shortfall 99% for Normal Distribution: phi(z)/(1 - alpha) ~ 2.665 * sigma
  const esFactor = 2.665;
  const es99 = notionalJpy * sigmaDecimal * esFactor * sqrtT;

  return { var95, var99, es99 };
}

/**
 * Futures Variation Margin & P&L Simulator
 */
export function simulateFuturesPosition(
  contracts: number,
  direction: 'LONG' | 'SHORT',
  entryPrice: number,
  currentPrice: number,
  multiplier: number, // e.g. $125,000 or 12,500,000 JPY
  initialMarginRate: number = 0.05 // 5%
): {
  notionalJpy: number;
  dailyPnlJpy: number;
  totalPnlJpy: number;
  initialMarginReqJpy: number;
  variationMarginJpy: number;
  marginUtilizationPct: number;
} {
  const priceDiff = currentPrice - entryPrice;
  const sign = direction === 'LONG' ? 1 : -1;

  // For USD/JPY CME futures: price is in USD per JPY (e.g. 0.006485) or JPY per USD
  // Multiplier: 12,500,000 JPY per contract
  const totalPnlJpy = sign * priceDiff * multiplier * contracts;
  const notionalJpy = currentPrice * multiplier * contracts;

  const initialMarginReqJpy = notionalJpy * initialMarginRate;
  // Variation margin is daily settlement gain/loss
  const variationMarginJpy = totalPnlJpy;

  const marginUtilizationPct = Math.min(100, Math.max(0, (initialMarginReqJpy - Math.min(0, totalPnlJpy)) / initialMarginReqJpy * 100));

  return {
    notionalJpy,
    dailyPnlJpy: totalPnlJpy,
    totalPnlJpy,
    initialMarginReqJpy,
    variationMarginJpy,
    marginUtilizationPct
  };
}

/**
 * Stress Scenario Analyzer
 */
export function runStressScenario(
  scenarioName: string,
  baseNetExposureUsd: number,
  hedgedUsd: number,
  spotUsdJpy: number,
  fxShockPct: number, // e.g. -5% (JPY appreciation)
  volShockPct: number = 0
): {
  scenarioName: string;
  shockedSpot: number;
  basePnlJpy: number;
  shockedPnlJpy: number;
  netPnlChangeJpy: number;
  unhedgedLossJpy: number;
  hedgeGainJpy: number;
  residualRiskUsd: number;
  hedgeEffectivenessPct: number;
} {
  const shockedSpot = spotUsdJpy * (1 + fxShockPct / 100.0);
  const unhedgedUsd = baseNetExposureUsd - hedgedUsd;

  // Loss on unhedged exposure under spot move
  const unhedgedLossJpy = unhedgedUsd * (shockedSpot - spotUsdJpy);
  // Gain/Loss on hedge instrument (e.g. short USD forward or futures)
  const hedgeGainJpy = -hedgedUsd * (shockedSpot - spotUsdJpy);

  const totalNetPnlJpy = unhedgedLossJpy + hedgeGainJpy;
  
  // Hedge effectiveness = (1 - residual loss / gross loss)
  const grossLossJpy = Math.abs(baseNetExposureUsd * (shockedSpot - spotUsdJpy));
  const netLossJpy = Math.abs(totalNetPnlJpy);
  const hedgeEffectivenessPct = grossLossJpy > 0 ? Math.max(0, (1 - netLossJpy / grossLossJpy) * 100) : 100;

  return {
    scenarioName,
    shockedSpot,
    basePnlJpy: 0,
    shockedPnlJpy: totalNetPnlJpy,
    netPnlChangeJpy: totalNetPnlJpy,
    unhedgedLossJpy,
    hedgeGainJpy,
    residualRiskUsd: unhedgedUsd,
    hedgeEffectivenessPct
  };
}

/**
 * Model Governance Directory
 */
export const MODEL_GOVERNANCE_CARDS: ModelCard[] = [
  {
    modelId: 'MOD-CIP-001',
    modelName: 'Covered Interest Parity Forward Pricing Engine',
    version: '2.4.0',
    owner: 'Quant Engineering / Tokyo Treasury Desk',
    approvalStatus: 'APPROVED',
    validationStatus: 'VALIDATED',
    calibrationDate: '2026-09-15',
    assumptions: [
      'Zero arbitrage friction across spot and forward FX venues',
      'ACT/365F day count convention for JPY domestic interest rates',
      'Log-linear discount factor interpolation across liquid tenors'
    ],
    limitations: [
      'Does not account for extreme market illiquidity or capital controls',
      'Assumes linear cross-currency basis scaling for broken dates'
    ],
    intendedUse: 'Indicative forward pricing, forward points curve building, and corporate treasury hedging valuation.',
    prohibitedUse: 'Automated high-frequency order placement or guaranteed execution.',
    mathematicalFormula: 'F = S * (1 + r_dom * T) / (1 + r_for * T)',
    knownFailureModes: ['Negative interest rate regime edge cases', 'Tenor gaps > 2 years without OIS curve calibration']
  },
  {
    modelId: 'MOD-VAR-002',
    modelName: 'Parametric & Historical JPY Risk Engine',
    version: '1.8.2',
    owner: 'Risk Analytics / Financial Engineering',
    approvalStatus: 'APPROVED',
    validationStatus: 'VALIDATED',
    calibrationDate: '2026-09-10',
    assumptions: [
      'Log-normal FX rate return distribution for parametric 95%/99% VaR',
      'Daily 1-day holding horizon with square-root of time scaling'
    ],
    limitations: [
      'Underestimates fat-tail downside risk during abrupt central bank interventions',
      'Does not model non-linear option gamma without full Monte Carlo expansion'
    ],
    intendedUse: 'Institutional portfolio currency risk measurement and treasury limit monitoring.',
    prohibitedUse: 'Regulatory capital requirement calculations without supervisory review.',
    mathematicalFormula: 'VaR_alpha = Notional_JPY * sigma_daily * Z_alpha * sqrt(T)',
    knownFailureModes: ['Vol-regime shifts during BoJ monetary policy releases']
  },
  {
    modelId: 'MOD-FUT-003',
    modelName: 'JPY Futures Basis & Roll Engine',
    version: '3.1.0',
    owner: 'Derivatives & Futures Structuring',
    approvalStatus: 'APPROVED',
    validationStatus: 'VALIDATED',
    calibrationDate: '2026-09-18',
    assumptions: [
      'CME & TFX currency futures contract specifications and delivery calendar',
      'Daily variation margin cash settlement at official exchange settlement prices'
    ],
    limitations: [
      'Physical delivery friction not modeled for non-standard delivery windows'
    ],
    intendedUse: 'Futures curve analysis, basis trading analytics, and contract roll optimization.',
    prohibitedUse: 'Automated order execution on derivative exchanges.',
    mathematicalFormula: 'Basis = Futures_Price - Forward_Rate',
    knownFailureModes: ['Expiration day liquidity drop-off']
  }
];
