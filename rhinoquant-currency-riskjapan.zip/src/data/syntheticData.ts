// RHINOQUANT JAPAN - Synthetic Market Data & Simulation Data Generator

import { CurrencyPair, MarketDataPoint, FuturesContract, CurveData, ExposureItem, HedgePosition, VolatilityPoint, ReconciliationItem, SimulationConfig, RiskMetrics } from '../types';
import { calculateCipForwardRate, calculateRiskMetrics } from '../quant/engine';

export const INITIAL_CURRENCY_PAIRS: CurrencyPair[] = [
  {
    id: 'USDJPY',
    symbol: 'USD/JPY',
    baseCurrency: 'USD',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: '米ドル / 日本円',
    descriptionEn: 'US Dollar / Japanese Yen',
    spotPrice: 154.25,
    bid: 154.24,
    ask: 154.26,
    change24h: 0.45,
    change24hPct: 0.29
  },
  {
    id: 'EURJPY',
    symbol: 'EUR/JPY',
    baseCurrency: 'EUR',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: 'ユーロ / 日本円',
    descriptionEn: 'Euro / Japanese Yen',
    spotPrice: 165.80,
    bid: 165.78,
    ask: 165.82,
    change24h: -0.32,
    change24hPct: -0.19
  },
  {
    id: 'GBPJPY',
    symbol: 'GBP/JPY',
    baseCurrency: 'GBP',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: '英ポンド / 日本円',
    descriptionEn: 'British Pound / Japanese Yen',
    spotPrice: 198.40,
    bid: 198.37,
    ask: 198.43,
    change24h: 0.82,
    change24hPct: 0.41
  },
  {
    id: 'AUDJPY',
    symbol: 'AUD/JPY',
    baseCurrency: 'AUD',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: '豪ドル / 日本円',
    descriptionEn: 'Australian Dollar / Japanese Yen',
    spotPrice: 102.15,
    bid: 102.13,
    ask: 102.17,
    change24h: 0.18,
    change24hPct: 0.18
  },
  {
    id: 'CHFJPY',
    symbol: 'CHF/JPY',
    baseCurrency: 'CHF',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: 'スイスフラン / 日本円',
    descriptionEn: 'Swiss Franc / Japanese Yen',
    spotPrice: 176.30,
    bid: 176.27,
    ask: 176.33,
    change24h: 0.05,
    change24hPct: 0.03
  },
  {
    id: 'CADJPY',
    symbol: 'CAD/JPY',
    baseCurrency: 'CAD',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: 'カナダドル / 日本円',
    descriptionEn: 'Canadian Dollar / Japanese Yen',
    spotPrice: 113.60,
    bid: 113.57,
    ask: 113.63,
    change24h: -0.12,
    change24hPct: -0.11
  },
  {
    id: 'CNYJPY',
    symbol: 'CNY/JPY',
    baseCurrency: 'CNY',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: '人民元 / 日本円',
    descriptionEn: 'Chinese Yuan / Japanese Yen',
    spotPrice: 21.65,
    bid: 21.64,
    ask: 21.66,
    change24h: 0.04,
    change24hPct: 0.19
  },
  {
    id: 'KRWJPY',
    symbol: 'KRW/JPY',
    baseCurrency: 'KRW',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: '韓国ウォン (100ウォン) / 日本円',
    descriptionEn: '100 South Korean Won / Japanese Yen',
    spotPrice: 11.42,
    bid: 11.41,
    ask: 11.43,
    change24h: -0.02,
    change24hPct: -0.17
  },
  {
    id: 'SGDJPY',
    symbol: 'SGD/JPY',
    baseCurrency: 'SGD',
    quoteCurrency: 'JPY',
    quotationConvention: 'JPY_PER_FCU',
    descriptionJa: 'シンガポールドル / 日本円',
    descriptionEn: 'Singapore Dollar / Japanese Yen',
    spotPrice: 118.20,
    bid: 118.18,
    ask: 118.22,
    change24h: 0.15,
    change24hPct: 0.13
  }
];

export const TENOR_SPECS = [
  { tenor: 'ON', days: 1 },
  { tenor: '1W', days: 7 },
  { tenor: '1M', days: 30 },
  { tenor: '2M', days: 60 },
  { tenor: '3M', days: 90 },
  { tenor: '6M', days: 180 },
  { tenor: '9M', days: 270 },
  { tenor: '1Y', days: 365 },
  { tenor: '2Y', days: 730 }
];

export function generateCurveData(spotRate: number = 154.25, timestamp: string = '2026-09-21T05:28:30Z'): CurveData {
  const points = TENOR_SPECS.map(spec => {
    // JPY rate: 0.25% to 0.85%, USD rate: 4.50% to 3.80%
    const domRate = 0.25 + (spec.days / 365) * 0.35;
    const forRate = 4.75 - (spec.days / 365) * 0.45;
    const basisBps = -18.5 - (spec.days / 365) * 5.0; // Cross-currency basis

    const cip = calculateCipForwardRate(spotRate, spec.days, domRate, forRate, basisBps);
    // Futures rate is forward rate + basis
    const futuresBasisPips = 8.5 + (spec.days / 365) * 4.0;
    const futuresRate = cip.forwardRate + futuresBasisPips / 100.0;

    const maturityDate = new Date(Date.now() + spec.days * 86400000).toISOString().split('T')[0];

    return {
      tenor: spec.tenor,
      daysToMaturity: spec.days,
      maturityDate,
      forwardRate: cip.forwardRate,
      futuresRate,
      basisPips: futuresBasisPips,
      forwardPointsPips: cip.forwardPointsPips,
      impliedRateDiffPct: cip.rateDiffPct,
      discountFactor: cip.discountFactorDom,
      qualityStatus: 'SYNTHETIC' as const
    };
  });

  return {
    curveId: 'CURVE-USDJPY-20260921',
    currencyPair: 'USD/JPY',
    valuationTime: timestamp,
    constructionMethod: 'CIP Log-Linear DF Bootstrapping',
    interpolationMethod: 'Log-Linear DF',
    dayCountConvention: 'ACT/365F',
    calendar: 'Tokyo / New York (Bank of Japan & Fed)',
    version: 'v2.4.1',
    qualityStatus: 'SYNTHETIC',
    points,
    historicalCurves: [
      {
        dateLabel: '今日 (Today)',
        points: points.map(p => ({ tenor: p.tenor, rate: p.forwardRate }))
      },
      {
        dateLabel: '1日前 (-1D)',
        points: points.map(p => ({ tenor: p.tenor, rate: p.forwardRate - 0.12 }))
      },
      {
        dateLabel: '1週間前 (-1W)',
        points: points.map(p => ({ tenor: p.tenor, rate: p.forwardRate - 0.45 }))
      },
      {
        dateLabel: '1ヶ月前 (-1M)',
        points: points.map(p => ({ tenor: p.tenor, rate: p.forwardRate - 1.20 }))
      },
      {
        dateLabel: '3ヶ月前 (-3M)',
        points: points.map(p => ({ tenor: p.tenor, rate: p.forwardRate - 2.80 }))
      }
    ]
  };
}

export const FUTURES_CONTRACTS: FuturesContract[] = [
  {
    contractId: 'CME-JYU26',
    underlyingPair: 'USD/JPY',
    exchangeCode: 'CME Group / TFX',
    contractMonth: '2026-09 (U26)',
    expiryDate: '2026-09-14',
    contractMultiplier: 12500000, // 12.5M JPY
    tickSize: 0.000001,
    tickValue: 12.50,
    settlementType: 'PHYSICAL',
    quoteConvention: 'USD per JPY',
    currency: 'USD',
    lastPrice: 0.006482, // 1 / 154.27
    openInterest: 184200,
    volume: 45200,
    basis: -0.15,
    rollYield: -2.85,
    initialMarginReq: 420000, // JPY per contract
    maintMarginReq: 350000
  },
  {
    contractId: 'CME-JYZ26',
    underlyingPair: 'USD/JPY',
    exchangeCode: 'CME Group / TFX',
    contractMonth: '2026-12 (Z26)',
    expiryDate: '2026-12-14',
    contractMultiplier: 12500000,
    tickSize: 0.000001,
    tickValue: 12.50,
    settlementType: 'PHYSICAL',
    quoteConvention: 'USD per JPY',
    currency: 'USD',
    lastPrice: 0.006540, // ~ 152.90
    openInterest: 212500,
    volume: 58900,
    basis: -0.28,
    rollYield: -3.10,
    initialMarginReq: 420000,
    maintMarginReq: 350000
  },
  {
    contractId: 'CME-JYH27',
    underlyingPair: 'USD/JPY',
    exchangeCode: 'CME Group / TFX',
    contractMonth: '2027-03 (H27)',
    expiryDate: '2027-03-15',
    contractMultiplier: 12500000,
    tickSize: 0.000001,
    tickValue: 12.50,
    settlementType: 'PHYSICAL',
    quoteConvention: 'USD per JPY',
    currency: 'USD',
    lastPrice: 0.006605, // ~ 151.40
    openInterest: 98400,
    volume: 18200,
    basis: -0.42,
    rollYield: -3.35,
    initialMarginReq: 450000,
    maintMarginReq: 380000
  },
  {
    contractId: 'CME-JYM27',
    underlyingPair: 'USD/JPY',
    exchangeCode: 'CME Group / TFX',
    contractMonth: '2027-06 (M27)',
    expiryDate: '2027-06-14',
    contractMultiplier: 12500000,
    tickSize: 0.000001,
    tickValue: 12.50,
    settlementType: 'PHYSICAL',
    quoteConvention: 'USD per JPY',
    currency: 'USD',
    lastPrice: 0.006675, // ~ 149.80
    openInterest: 41000,
    volume: 7400,
    basis: -0.58,
    rollYield: -3.60,
    initialMarginReq: 450000,
    maintMarginReq: 380000
  }
];

export const SYNTHETIC_CORPORATE_EXPOSURES: ExposureItem[] = [
  {
    exposureId: 'EXP-US-REC-2026Q4',
    legalEntity: '東京インダストリアル・ホールディングス (TOKYO INDUSTRIAL HOLDINGS)',
    businessUnit: 'グローバル北米事業部 (North America Machinery Div)',
    category: 'TRANSACTION',
    currency: 'USD',
    amountForeign: 120000000, // 120M USD
    amountJpy: 18510000000, // 18.51 Billion JPY
    direction: 'RECEIVABLE',
    expectedDate: '2026-12-15',
    confidencePct: 98,
    source: 'SAP S/4HANA ERP Feed - Confirmed Order #TIH-8821',
    hedgeStatus: 'FULLY_HEDGED',
    hedgedAmountForeign: 120000000,
    hedgeRatioPct: 100
  },
  {
    exposureId: 'EXP-US-REC-2027Q1',
    legalEntity: '東京インダストリアル・ホールディングス (TOKYO INDUSTRIAL HOLDINGS)',
    businessUnit: 'グローバル北米事業部 (North America Machinery Div)',
    category: 'FORECAST',
    currency: 'USD',
    amountForeign: 160000000, // 160M USD
    amountJpy: 24680000000,
    direction: 'RECEIVABLE',
    expectedDate: '2027-03-20',
    confidencePct: 85,
    source: 'Corporate Budget Forecast FY2026',
    hedgeStatus: 'PARTIALLY_HEDGED',
    hedgedAmountForeign: 110000000,
    hedgeRatioPct: 68.75
  },
  {
    exposureId: 'EXP-US-REC-2027Q2',
    legalEntity: '東京インダストリアル・ホールディングス (TOKYO INDUSTRIAL HOLDINGS)',
    businessUnit: '先端電子デバイス事業部 (Advanced Electronics Div)',
    category: 'FORECAST',
    currency: 'USD',
    amountForeign: 140000000, // 140M USD
    amountJpy: 21595000000,
    direction: 'RECEIVABLE',
    expectedDate: '2027-06-25',
    confidencePct: 75,
    source: 'Rolling Treasury Plan Q2-2027',
    hedgeStatus: 'PARTIALLY_HEDGED',
    hedgedAmountForeign: 50000000,
    hedgeRatioPct: 35.71
  }
];

export const SYNTHETIC_HEDGE_POSITIONS: HedgePosition[] = [
  {
    hedgeId: 'HDG-FWD-USDJPY-001',
    exposureId: 'EXP-US-REC-2026Q4',
    strategyType: 'FX_FORWARD',
    instrumentType: 'FORWARD',
    contractIdOrRef: 'FWD-20261215-MUFG',
    notionalForeign: 120000000,
    executedRate: 153.80,
    currentMtmJpy: -54000000, // -54M JPY
    unrealizedPnlJpy: -54000000,
    realizedPnlJpy: 0,
    maturityDate: '2026-12-15',
    hedgeRatioPct: 100,
    basisRiskScore: 1.2,
    rolloverCostJpy: 0,
    effectiveCoveragePct: 100
  },
  {
    hedgeId: 'HDG-FUT-USDJPY-002',
    exposureId: 'EXP-US-REC-2027Q1',
    strategyType: 'FX_FUTURES',
    instrumentType: 'FUTURES',
    contractIdOrRef: 'CME-JYH27 (2,200 Contracts)',
    notionalForeign: 110000000,
    executedRate: 151.90,
    currentMtmJpy: 125000000, // +125M JPY
    unrealizedPnlJpy: 125000000,
    realizedPnlJpy: 18500000,
    maturityDate: '2027-03-15',
    hedgeRatioPct: 68.75,
    basisRiskScore: 2.8,
    rolloverCostJpy: 4500000,
    effectiveCoveragePct: 98.2
  },
  {
    hedgeId: 'HDG-FUT-USDJPY-003',
    exposureId: 'EXP-US-REC-2027Q2',
    strategyType: 'ROLLING_FUTURES',
    instrumentType: 'FUTURES',
    contractIdOrRef: 'CME-JYM27 (1,000 Contracts)',
    notionalForeign: 50000000,
    executedRate: 150.20,
    currentMtmJpy: 42000000,
    unrealizedPnlJpy: 42000000,
    realizedPnlJpy: 0,
    maturityDate: '2027-06-14',
    hedgeRatioPct: 35.71,
    basisRiskScore: 3.5,
    rolloverCostJpy: 3200000,
    effectiveCoveragePct: 95.4
  }
];

export const VOLATILITY_SURFACE_DATA: VolatilityPoint[] = [
  { tenor: '1W', days: 7, atmVol: 8.85, rr25: -0.42, bf25: 0.28, vol25Call: 8.78, vol25Put: 9.20 },
  { tenor: '1M', days: 30, atmVol: 9.40, rr25: -0.65, bf25: 0.35, vol25Call: 9.22, vol25Put: 9.87 },
  { tenor: '3M', days: 90, atmVol: 10.15, rr25: -0.88, bf25: 0.42, vol25Call: 9.92, vol25Put: 10.80 },
  { tenor: '6M', days: 180, atmVol: 10.80, rr25: -1.15, bf25: 0.48, vol25Call: 10.46, vol25Put: 11.61 },
  { tenor: '1Y', days: 365, atmVol: 11.25, rr25: -1.35, bf25: 0.55, vol25Call: 10.85, vol25Put: 12.20 },
  { tenor: '2Y', days: 730, atmVol: 11.60, rr25: -1.50, bf25: 0.62, vol25Call: 11.16, vol25Put: 12.66 }
];

export const RECONCILIATION_ITEMS: ReconciliationItem[] = [
  {
    id: 'REC-001',
    sourceModule: 'Market Data Ingestion',
    targetModule: 'Forward Curve Builder',
    field: 'USD/JPY Spot Mid Price',
    sourceValue: '154.250 JPY',
    targetValue: '154.250 JPY',
    difference: '0.000',
    status: 'MATCHED',
    detectedTime: '2026-09-21 05:25:12 Asia/Tokyo',
    auditTrail: 'Automated 1-second price reconciliation pass.'
  },
  {
    id: 'REC-002',
    sourceModule: 'CME Exchange Adapter',
    targetModule: 'Futures Basis Engine',
    field: 'CME-JYZ26 Settlement Price',
    sourceValue: '0.006540 USD',
    targetValue: '0.006540 USD',
    difference: '0.000000',
    status: 'MATCHED',
    detectedTime: '2026-09-21 05:25:12 Asia/Tokyo',
    auditTrail: 'Direct contract multiplier check verified (12.5M JPY).'
  },
  {
    id: 'REC-003',
    sourceModule: 'Forward Curve Builder',
    targetModule: 'Valuation Engine',
    field: '3M Forward Points (USD/JPY)',
    sourceValue: '-148.5 銭',
    targetValue: '-148.2 銭',
    difference: '0.3 銭 (Warning)',
    status: 'WARNING',
    detectedTime: '2026-09-21 05:20:00 Asia/Tokyo',
    auditTrail: 'Minor rounding delta detected between discrete CIP and log-linear discount factor interpolation.'
  },
  {
    id: 'REC-004',
    sourceModule: 'SAP S/4HANA ERP',
    targetModule: 'Hedge Register',
    field: 'EXP-US-REC-2027Q2 Exposure Notional',
    sourceValue: '$140,000,000',
    targetValue: '$140,000,000',
    difference: '$0',
    status: 'MATCHED',
    detectedTime: '2026-09-21 05:00:00 Asia/Tokyo',
    auditTrail: 'Intercompany receivable reconciliation confirmed.'
  }
];

export const VERTICAL_SLICE_STEPS = [
  {
    stepNumber: 1,
    titleJa: '合成市場データの読み込み',
    titleEn: 'Load Synthetic Market Data',
    descriptionJa: 'USD/JPY スポット 154.25 JPY、気配値スプレッド 2銭の市場データをロード。',
    descriptionEn: 'Loaded USD/JPY spot at 154.25 JPY with a 2-pip bid-ask spread.',
    status: 'COMPLETED',
    dataSnippet: 'USD/JPY Spot = 154.25 | Source = TOKYO_DESK [SYNTHETIC]'
  },
  {
    stepNumber: 2,
    titleJa: 'JPY & USD 割引カーブの構成',
    titleEn: 'Construct JPY & USD Discount Curves',
    descriptionJa: 'TONA 0.25% (JPY) および SOFR 4.75% (USD) 連続複利割引カーブの構築。',
    descriptionEn: 'Constructed JPY TONA (0.25%) and USD SOFR (4.75%) discount curves.',
    status: 'COMPLETED',
    dataSnippet: 'DF_JPY(1Y) = 0.9975 | DF_USD(1Y) = 0.9536'
  },
  {
    stepNumber: 3,
    titleJa: '先物名目仕様のロード',
    titleEn: 'Load Synthetic Futures Specifications',
    descriptionJa: 'CME JYU26, JYZ26, JYH27 (取引単位: 1,250万円) の約定・限月情報の取得。',
    descriptionEn: 'Loaded CME JYU26, JYZ26, JYH27 specs with 12.5M JPY contract multiplier.',
    status: 'COMPLETED',
    dataSnippet: 'Multiplier = 12,500,000 JPY | Settlement = PHYSICAL'
  },
  {
    stepNumber: 4,
    titleJa: 'USD/JPY フォワード・カーブの構築',
    titleEn: 'Build USD/JPY Forward Curve',
    descriptionJa: 'カバー付き金利平価 (CIP) 方程式を用いて全限月のフォワードレートを導出。',
    descriptionEn: 'Derived outright forward rates across tenors using CIP formulation.',
    status: 'COMPLETED',
    dataSnippet: '1M Fwd = 153.82 | 3M Fwd = 152.77 | 1Y Fwd = 148.10'
  },
  {
    stepNumber: 5,
    titleJa: '合成先物カーブの構築',
    titleEn: 'Construct Synthetic Futures Curve',
    descriptionJa: '限月（3月・6月・9月・12月）別先物価格からイールドカーブを算出。',
    descriptionEn: 'Mapped quarterly futures contract prices to standard time horizons.',
    status: 'COMPLETED',
    dataSnippet: 'JYZ26 Price = 0.006540 USD/JPY (~152.90 JPY)'
  },
  {
    stepNumber: 6,
    titleJa: 'フォワード・ポイント (銭) の計算',
    titleEn: 'Calculate Forward Points (Sen/Pips)',
    descriptionJa: 'スポットとフォワードの差分から銭単位のプレミアム・ディスカウントを計上。',
    descriptionEn: 'Calculated forward discount in JPY sen (1 pip = 0.01 JPY).',
    status: 'COMPLETED',
    dataSnippet: '3M Forward Points = -148.0 銭 (-1.48 JPY)'
  },
  {
    stepNumber: 7,
    titleJa: '先物ベース (Futures Basis) の分析',
    titleEn: 'Calculate Futures Basis',
    descriptionJa: '先物価格と基準フォワードレートの乖離 (Basis) を算出。',
    descriptionEn: 'Evaluated difference between futures price and fair-value forward rate.',
    status: 'COMPLETED',
    dataSnippet: '3M Basis = +8.5 pips (0.085 JPY)'
  },
  {
    stepNumber: 8,
    titleJa: '企業エクスポージャー・スケジュールのインポート',
    titleEn: 'Import Corporate Exposure Schedule',
    descriptionJa: '東京インダストリアル・ホールディングスの年間4億2000万USDの売掛金を取込。',
    descriptionEn: 'Imported Tokyo Industrial Holdings USD $420M receivables schedule.',
    status: 'COMPLETED',
    dataSnippet: 'Total USD Receivables = $420,000,000 (64.78 Billion JPY)'
  },
  {
    stepNumber: 9,
    titleJa: '満期別エクスポージャーの表示',
    titleEn: 'Display Exposure by Maturity Ladder',
    descriptionJa: '2026Q4, 2027Q1, 2027Q2 の四半期別キャッシュフローに分解。',
    descriptionEn: 'Bucket exposure into 2026Q4 ($120M), 2027Q1 ($160M), 2027Q2 ($140M).',
    status: 'COMPLETED',
    dataSnippet: 'Bucket 1 = $120M | Bucket 2 = $160M | Bucket 3 = $140M'
  },
  {
    stepNumber: 10,
    titleJa: '先物・為替予約ヘッジのシミュレーション',
    titleEn: 'Simulate Futures & Forward Hedges',
    descriptionJa: '売掛金に対し2.8億USD (ヘッジ比率 66.7%) の先物・為替予約を実行。',
    descriptionEn: 'Executed $280M hedge (66.7% hedge ratio) across forwards and futures.',
    status: 'COMPLETED',
    dataSnippet: 'Hedged USD = $280,000,000 | Unhedged = $140,000,000'
  },
  {
    stepNumber: 11,
    titleJa: 'ヘッジ想定元本の算出',
    titleEn: 'Calculate Hedge Notional',
    descriptionJa: 'CME先物 3,200枚 (想定元本 1.6億USD相当) + 為替予約 1.2億USD。',
    descriptionEn: 'Allocated 3,200 CME contracts ($160M) + $120M FX forwards.',
    status: 'COMPLETED',
    dataSnippet: '3,200 Contracts x 12.5M JPY = 40 Billion JPY Notional'
  },
  {
    stepNumber: 12,
    titleJa: '日次変動証拠金 (Variation Margin) の試算',
    titleEn: 'Calculate Daily Variation Margin',
    descriptionJa: '1日の価格変動に伴う証拠金現金決済額を算出。',
    descriptionEn: 'Simulated daily cash clearing variation margin flows.',
    status: 'COMPLETED',
    dataSnippet: 'Daily Variation Margin = +18.5 Million JPY'
  },
  {
    stepNumber: 13,
    titleJa: 'ポートフォリオ MTM 評価の実行',
    titleEn: 'Calculate Portfolio Mark-to-Market',
    descriptionJa: '全ポジション・ヘッジの割引時価評価額 (MTM) を統一算出。',
    descriptionEn: 'Valued all positions, hedges, and cashflows in net JPY MTM.',
    status: 'COMPLETED',
    dataSnippet: 'Portfolio Net MTM = +113,000,000 JPY'
  },
  {
    stepNumber: 14,
    titleJa: '円高シナリオ (-5% JPY Appreciation) の実行',
    titleEn: 'Run JPY Appreciation Shock Scenario',
    descriptionJa: '154.25 → 146.54 JPY への急激な円高時の企業損益・ヘッジ効果の分析。',
    descriptionEn: 'Simulated USD/JPY drop to 146.54 JPY. Hedged P&L offset calculated.',
    status: 'COMPLETED',
    dataSnippet: 'Unhedged Loss = -1,079M JPY | Hedge Gain = +2,159M JPY | Net Offset OK'
  },
  {
    stepNumber: 15,
    titleJa: '円安シナリオ (+5% JPY Depreciation) の実行',
    titleEn: 'Run JPY Depreciation Shock Scenario',
    descriptionJa: '154.25 → 161.96 JPY への円安進行時の未ヘッジ益とヘッジ評価損の分析。',
    descriptionEn: 'Simulated USD/JPY rally to 161.96 JPY. Excess profit analyzed.',
    status: 'COMPLETED',
    dataSnippet: 'Unhedged Gain = +1,079M JPY | Net Position Protected'
  },
  {
    stepNumber: 16,
    titleJa: '残存未ヘッジリスク (Residual Exposure) の特定',
    titleEn: 'Calculate Residual Risk Exposure',
    descriptionJa: '未ヘッジの 1.4億USD に対する VaR (99% 1D) 3.85億円を提示。',
    descriptionEn: 'Quantified 1-day 99% VaR at 385M JPY for remaining $140M exposure.',
    status: 'COMPLETED',
    dataSnippet: 'Residual Exposure = $140M | 99% 1D VaR = 385 Million JPY'
  },
  {
    stepNumber: 17,
    titleJa: '先物ロール・カーブ (Roll Yield) の表示',
    titleEn: 'Display Futures Roll Curve',
    descriptionJa: '限月乗り換え (JYZ26 → JYH27) 時のロールコスト (年率 -3.10%) を試算。',
    descriptionEn: 'Analyzed roll yields and cost of rolling contract months (-3.10% p.a.).',
    status: 'COMPLETED',
    dataSnippet: 'Estimated Roll Cost = 4.5 Million JPY per Quarter'
  },
  {
    stepNumber: 18,
    titleJa: '市場データ・ポジション・評価の自動照合 (Reconciliation)',
    titleEn: 'Reconcile Data, Positions & Valuation',
    descriptionJa: 'マーケットデータ、イールドカーブ、ERP帳簿、ヘッジ台帳間の整合性をチェック。',
    descriptionEn: 'Verified integrity between market inputs, curves, positions, and risk metrics.',
    status: 'COMPLETED',
    dataSnippet: 'Reconciliation Status = 3 MATCHED, 1 WARNING (0 Exceptions)'
  },
  {
    stepNumber: 19,
    titleJa: '日次日英バイリンガル・リスクレポート生成',
    titleEn: 'Generate Bilingual Risk Report',
    descriptionJa: '取締役会・財務部提出用の全社為替リスク監査レポートを出力。',
    descriptionEn: 'Generated complete audit-ready bilingual treasury risk report.',
    status: 'COMPLETED',
    dataSnippet: 'Report ID = RPT-JPY-20260921-001 [PDF/CSV Ready]'
  },
  {
    stepNumber: 20,
    titleJa: '完全な計算リネージ (Calculation Lineage) の可視化',
    titleEn: 'Display Complete Calculation Lineage',
    descriptionJa: '市場データ → イールドカーブ → 先物評価 → エクスポージャー → リスク報告の全監査追跡完了。',
    descriptionEn: 'Full calculation lineage and model provenance audit trail displayed.',
    status: 'COMPLETED',
    dataSnippet: 'Data Provenance: Clean | Model: MOD-CIP-001 & MOD-VAR-002'
  }
];

export const SYNTHETIC_CURRENCY_PAIRS = INITIAL_CURRENCY_PAIRS;
export const SYNTHETIC_CURVE_DATA: CurveData = generateCurveData(154.25);
export const SYNTHETIC_FUTURES = FUTURES_CONTRACTS;
export const SYNTHETIC_EXPOSURES = SYNTHETIC_CORPORATE_EXPOSURES;
export const SYNTHETIC_HEDGES = SYNTHETIC_HEDGE_POSITIONS;
export const SYNTHETIC_RECONCILIATION = RECONCILIATION_ITEMS;
export const SYNTHETIC_VOLATILITY = VOLATILITY_SURFACE_DATA;

export const SYNTHETIC_RISK_METRICS: RiskMetrics = {
  valuationTimestamp: '2026-09-21T05:28:30Z',
  totalNetExposureJpy: 64780000000,
  reportingExposureJpy: 21590000000,
  weightedHedgeRatioPct: 66.7,
  portfolioMtmJpy: 113000000,
  dailyPnlJpy: 18500000,
  var95_1D_Jpy: 245000000,
  var99_1D_Jpy: 385000000,
  expectedShortfall99_Jpy: 485000000,
  deltaFxJpyPer1Pct: 647800000,
  deltaFwdPointsJpyPer10Pips: 12000000,
  deltaVolJpyPer1Pct: 4500000,
  deltaBasisJpyPer10Bps: 8500000,
  marginUtilizationPct: 44.5,
  limitUtilizationPct: 62.1
};
