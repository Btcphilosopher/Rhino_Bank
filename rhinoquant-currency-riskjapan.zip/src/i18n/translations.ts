// RHINOQUANT JAPAN - Terminology Dictionary & Translations

import { Locale } from '../types';

export const translations = {
  'ja-JP': {
    // App Header & Branding
    appTitle: 'RHINOQUANT JAPAN',
    appSubtitle: '日本円為替リスク・先物・イールドカーブ統合分析プラットフォーム',
    institutionalDisclaimer: '【シミュレーション環境】本システムは合成データを使用しており、実取引・保証された価格ではありません。',
    syntheticDataNotice: '合成データ (SYNTHETIC)',
    
    // Navigation Modules
    navMarket: 'マーケット',
    navExposure: '為替エクスポージャー',
    navFutures: '先物',
    navForwards: 'フォワード',
    navCurves: 'カーブ',
    navVolatility: 'ボラティリティ',
    navHedging: 'ヘッジ',
    navRisk: 'リスク',
    navScenarios: 'シナリオ',
    navPortfolio: 'ポートフォリオ',
    navValuation: '評価',
    navReconciliation: '照合',
    navReports: 'レポート',
    navDataQuality: 'データ品質',
    navGovernance: 'モデル管理',
    navTrace: '20段階計算追跡',
    navSettings: '設定',

    // Financial Terminology Dictionary
    fxRisk: '為替リスク',
    futures: '先物',
    forwardContract: '先渡取引',
    fxForward: '為替予約',
    currencySwap: '通貨スワップ',
    interestRateDiff: '金利差',
    forwardPoints: 'フォワード・ポイント',
    hedgeRatio: 'ヘッジ比率',
    markToMarketPnl: '評価損益 (MTM P&L)',
    notionalAmount: '想定元本',
    settlementDate: '決済日',
    maturityDate: '満期日',
    crossCurrencyBasis: '通貨スワップ・ベース (XCCY Basis)',
    valueAtRisk: 'Value at Risk (VaR)',
    expectedShortfall: 'Expected Shortfall (ES)',
    initialMargin: '当初証拠金 (Initial Margin)',
    variationMargin: '変動証拠金 (Variation Margin)',
    marginUtilization: '証拠金使用率',
    rollYield: 'ロール・イールド',
    discountFactor: '割引係数 (Discount Factor)',
    coveredInterestParity: 'カバー付き金利平価 (CIP)',

    // Quotation Conventions
    quotationJpyPerFcu: '円建て表示 (JPY per FCU)',
    quotationFcuPerJpy: '外貨建て表示 (FCU per JPY)',
    domesticCurrency: '自国通貨 (JPY)',
    foreignCurrency: '外国通貨',

    // Key Stats Cards
    totalNetFxExposure: '総純為替エクスポージャー',
    jpyReportingExposure: '円換算報告エクスポージャー',
    portfolioMtm: 'ポートフォリオ評価額',
    dailyPnl: '日次損益',
    curveQuality: 'カーブ品質ステータス',
    riskLimitUtil: 'リスク限度使用率',

    // Actions & Status
    exportCsv: 'CSV出力',
    exportJson: 'JSON出力',
    exportPdf: 'PDFレポート発行',
    runScenario: 'シナリオ実行',
    recalculate: '再計算',
    dataStatusLive: 'ライブ (LIVE)',
    dataStatusSynthetic: '合成 (SYNTHETIC)',
    dataStatusDelayed: '遅延 (DELAYED)',
    dataStatusIndicative: '気配値 (INDICATIVE)',
    dataStatusStale: '更新停止 (STALE)',

    // Common Labels
    tenor: '期間 (Tenor)',
    spotRate: 'スポットレート',
    forwardRate: 'フォワードレート',
    futuresPrice: '先物価格',
    basis: 'ベース (Basis)',
    multiplier: '取引単位 (Multiplier)',
    legalEntity: '対象法人',
    businessUnit: '事業部門',
    currencyPair: '通貨ペア',
    timestamp: '評価タイムスタンプ',
    source: 'データソース',
  },

  'en-GB': {
    // App Header & Branding
    appTitle: 'RHINOQUANT JAPAN',
    appSubtitle: 'Institutional JPY Currency-Risk, Futures and Curve Analytics Platform',
    institutionalDisclaimer: '[SIMULATION] System relies on synthetic market data. Indicative pricing, non-executable.',
    syntheticDataNotice: 'SYNTHETIC DATA',
    
    // Navigation Modules
    navMarket: 'Market Overview',
    navExposure: 'FX Exposure',
    navFutures: 'Futures',
    navForwards: 'Forwards',
    navCurves: 'Curves Terminal',
    navVolatility: 'Volatility Surface',
    navHedging: 'Hedging Engine',
    navRisk: 'Risk Engine',
    navScenarios: 'Risk Scenarios',
    navPortfolio: 'Portfolio',
    navValuation: 'Valuation',
    navReconciliation: 'Reconciliation',
    navReports: 'Reports',
    navDataQuality: 'Data Quality',
    navGovernance: 'Model Governance',
    navTrace: '20-Step Trace',
    navSettings: 'Settings',

    // Financial Terminology Dictionary
    fxRisk: 'Currency Risk',
    futures: 'Futures',
    forwardContract: 'Forward Contract',
    fxForward: 'FX Forward',
    currencySwap: 'Currency Swap',
    interestRateDiff: 'Interest-Rate Differential',
    forwardPoints: 'Forward Points',
    hedgeRatio: 'Hedge Ratio',
    markToMarketPnl: 'Mark-to-Market P&L',
    notionalAmount: 'Notional Amount',
    settlementDate: 'Settlement Date',
    maturityDate: 'Maturity Date',
    crossCurrencyBasis: 'Cross-Currency Basis',
    valueAtRisk: 'Value at Risk (VaR)',
    expectedShortfall: 'Expected Shortfall (ES)',
    initialMargin: 'Initial Margin',
    variationMargin: 'Variation Margin',
    marginUtilization: 'Margin Utilization',
    rollYield: 'Roll Yield',
    discountFactor: 'Discount Factor',
    coveredInterestParity: 'Covered Interest Parity (CIP)',

    // Quotation Conventions
    quotationJpyPerFcu: 'JPY per Foreign Unit (Direct)',
    quotationFcuPerJpy: 'Foreign Currency per JPY (Inverted)',
    domesticCurrency: 'Domestic Currency (JPY)',
    foreignCurrency: 'Foreign Currency',

    // Key Stats Cards
    totalNetFxExposure: 'Total Net FX Exposure',
    jpyReportingExposure: 'JPY Reporting Exposure',
    portfolioMtm: 'Portfolio MTM',
    dailyPnl: 'Daily P&L',
    curveQuality: 'Curve Quality Status',
    riskLimitUtil: 'Risk Limit Utilization',

    // Actions & Status
    exportCsv: 'Export CSV',
    exportJson: 'Export JSON',
    exportPdf: 'Generate PDF Report',
    runScenario: 'Run Scenario',
    recalculate: 'Recalculate',
    dataStatusLive: 'LIVE',
    dataStatusSynthetic: 'SYNTHETIC',
    dataStatusDelayed: 'DELAYED',
    dataStatusIndicative: 'INDICATIVE',
    dataStatusStale: 'STALE',

    // Common Labels
    tenor: 'Tenor',
    spotRate: 'Spot Rate',
    forwardRate: 'Forward Rate',
    futuresPrice: 'Futures Price',
    basis: 'Basis',
    multiplier: 'Contract Multiplier',
    legalEntity: 'Legal Entity',
    businessUnit: 'Business Unit',
    currencyPair: 'Currency Pair',
    timestamp: 'Valuation Timestamp',
    source: 'Data Source',
  }
};

export function getTranslation(locale: Locale, key: keyof typeof translations['ja-JP']): string {
  return translations[locale]?.[key] || translations['ja-JP'][key] || key;
}

// Financial Terminology Dictionary table for explicit Reference panel
export const termDictionary = [
  { ja: '為替リスク', en: 'Currency Risk', category: 'Risk Management' },
  { ja: '先物', en: 'Futures', category: 'Derivatives' },
  { ja: '先渡取引', en: 'Forward Contract', category: 'Derivatives' },
  { ja: '為替予約', en: 'FX Forward', category: 'Corporate Treasury' },
  { ja: '通貨スワップ', en: 'Currency Swap', category: 'Derivatives' },
  { ja: '金利差', en: 'Interest-Rate Differential', category: 'Quantitative Finance' },
  { ja: 'フォワード・ポイント', en: 'Forward Points', category: 'FX Analytics' },
  { ja: 'ヘッジ比率', en: 'Hedge Ratio', category: 'Risk Management' },
  { ja: '評価損益', en: 'Mark-to-Market P&L', category: 'Accounting' },
  { ja: '想定元本', en: 'Notional Amount', category: 'Trading' },
  { ja: '決済日', en: 'Settlement Date', category: 'Operations' },
  { ja: '満期日', en: 'Maturity Date', category: 'Operations' },
  { ja: '通貨スワップ・ベース', en: 'Cross-Currency Basis', category: 'Curve Engineering' },
  { ja: '当初証拠金', en: 'Initial Margin', category: 'Futures Clearing' },
  { ja: '変動証拠金', en: 'Variation Margin', category: 'Futures Clearing' },
  { ja: 'カバー付き金利平価', en: 'Covered Interest Parity', category: 'Quantitative Finance' }
];
