// RHINOQUANT JAPAN - Institutional Types & Data Models

export type Locale = 'ja-JP' | 'en-GB';

export type CurrencyCode = 'JPY' | 'USD' | 'EUR' | 'GBP' | 'AUD' | 'CHF' | 'CAD' | 'CNY' | 'KRW' | 'SGD';

export type SimulationRegime = 'NORMAL' | 'JPY_APPRECIATION_SHOCK' | 'BASIS_SPIKE' | 'VOLATILITY_SPIKE';

export interface CurrencyPair {
  id: string;
  symbol: string; // e.g., "USD/JPY"
  baseCurrency: CurrencyCode;
  quoteCurrency: CurrencyCode;
  quotationConvention: 'JPY_PER_FCU' | 'FCU_PER_JPY'; // JPY per foreign currency or FCU per JPY
  descriptionJa: string;
  descriptionEn: string;
  spotPrice: number;
  bid: number;
  ask: number;
  change24h: number;
  change24hPct: number;
}

export type DataStatus = 'LIVE' | 'DELAYED' | 'INDICATIVE' | 'SYNTHETIC' | 'STALE' | 'MISSING' | 'REJECTED';

export interface MarketDataPoint {
  instrumentId: string;
  observationTime: string; // ISO String
  value: number;
  currency: CurrencyCode;
  source: string;
  sourceTimestamp: string;
  dataStatus: DataStatus;
  qualityScore: number; // 0 to 100
  bid?: number;
  ask?: number;
  mid?: number;
  unit: string;
  convention: string;
}

export interface ForwardTenorPoint {
  tenor: string; // "1W", "1M", "3M", "6M", "9M", "1Y", "2Y"
  days: number;
  forwardPoints: number; // e.g., -142.5 pips
  forwardRate: number; // e.g., 152.775
  domRatePct: number; // JPY rate %
  forRatePct: number; // Foreign rate %
  impliedDiffPct: number; // Rate differential
  discountFactorDom: number;
  discountFactorFor: number;
}

export interface FuturesContract {
  contractId: string;
  underlyingPair: string;
  exchangeCode: string; // "CME", "TFX"
  contractMonth: string; // "2026H", "2026M", "2026U", "2026Z"
  expiryDate: string;
  contractMultiplier: number; // e.g. 12,500,000 JPY or $125,000
  tickSize: number; // e.g. 0.005 or 0.01
  tickValue: number; // e.g. $6.25 or 625 JPY
  settlementType: 'CASH' | 'PHYSICAL';
  quoteConvention: string;
  currency: CurrencyCode;
  lastPrice: number;
  openInterest: number;
  volume: number;
  basis: number; // Futures - Forward
  rollYield: number; // Annualized
  initialMarginReq: number; // JPY or USD
  maintMarginReq: number;
}

export interface CurvePoint {
  tenor: string;
  daysToMaturity: number;
  maturityDate: string;
  forwardRate: number;
  futuresRate: number;
  basisPips: number;
  forwardPointsPips: number;
  impliedRateDiffPct: number;
  discountFactor: number;
  qualityStatus: DataStatus;
}

export interface CurveData {
  curveId: string;
  currencyPair: string;
  valuationTime: string;
  constructionMethod: string; // e.g., "CIP Log-Linear DF Bootstrapping"
  interpolationMethod: string; // "Linear", "Log-Linear", "Monotonic Cubic"
  dayCountConvention: string; // "ACT/365F", "ACT/360"
  calendar: string; // "Tokyo/NewYork"
  version: string;
  qualityStatus: DataStatus;
  points: CurvePoint[];
  historicalCurves?: {
    dateLabel: string;
    points: { tenor: string; rate: number }[];
  }[];
}

export interface VolatilityPoint {
  tenor: string;
  days: number;
  atmVol: number; // %
  rr25: number; // Risk Reversal 25 Delta
  bf25: number; // Butterfly 25 Delta
  vol25Call: number;
  vol25Put: number;
}

export type ExposureCategory = 
  | 'TRANSACTION' 
  | 'TRANSLATION' 
  | 'ECONOMIC' 
  | 'FORECAST' 
  | 'FIRM_COMMITMENT' 
  | 'INTERCOMPANY';

export interface ExposureItem {
  exposureId: string;
  legalEntity: string;
  businessUnit: string;
  category: ExposureCategory;
  currency: CurrencyCode;
  amountForeign: number; // e.g., 420,000,000 USD
  amountJpy: number; // MTM in JPY
  direction: 'RECEIVABLE' | 'PAYABLE';
  expectedDate: string;
  confidencePct: number;
  source: string;
  hedgeStatus: 'UNHEDGED' | 'PARTIALLY_HEDGED' | 'FULLY_HEDGED';
  hedgedAmountForeign: number;
  hedgeRatioPct: number;
}

export type HedgeStrategyType = 
  | 'FX_FORWARD' 
  | 'FX_FUTURES' 
  | 'FX_SWAP' 
  | 'PARTIAL_LAYERED' 
  | 'ROLLING_FUTURES' 
  | 'NATURAL_HEDGE';

export interface HedgePosition {
  hedgeId: string;
  exposureId: string;
  strategyType: HedgeStrategyType;
  instrumentType: 'FORWARD' | 'FUTURES' | 'SWAP';
  contractIdOrRef: string;
  notionalForeign: number;
  executedRate: number;
  currentMtmJpy: number;
  unrealizedPnlJpy: number;
  realizedPnlJpy: number;
  maturityDate: string;
  hedgeRatioPct: number;
  basisRiskScore: number; // 0 to 10
  rolloverCostJpy: number;
  effectiveCoveragePct: number;
}

export interface RiskMetrics {
  valuationTimestamp: string;
  totalNetExposureJpy: number;
  reportingExposureJpy: number;
  weightedHedgeRatioPct: number;
  portfolioMtmJpy: number;
  dailyPnlJpy: number;
  var95_1D_Jpy: number;
  var99_1D_Jpy: number;
  expectedShortfall99_Jpy: number;
  deltaFxJpyPer1Pct: number; // Sensitivity to 1% FX move
  deltaFwdPointsJpyPer10Pips: number;
  deltaVolJpyPer1Pct: number;
  deltaBasisJpyPer10Bps: number;
  marginUtilizationPct: number;
  limitUtilizationPct: number;
}

export interface StressScenario {
  id: string;
  nameJa: string;
  nameEn: string;
  descriptionJa: string;
  descriptionEn: string;
  fxSpotShockPct: number; // e.g. -5.0% (JPY appreciation)
  rateDiffShockBps: number;
  volShockPct: number;
  basisShockBps: number;
  resultPnlJpy: number;
  resultExposureJpy: number;
  marginImpactJpy: number;
  hedgeEffectivenessPct: number;
}

export interface ModelCard {
  modelId: string;
  modelName: string;
  version: string;
  owner: string;
  approvalStatus: 'APPROVED' | 'PENDING_REVIEW' | 'CONDITIONALLY_APPROVED';
  validationStatus: 'VALIDATED' | 'REQUIRES_RECALIBRATION';
  calibrationDate: string;
  assumptions: string[];
  limitations: string[];
  intendedUse: string;
  prohibitedUse: string;
  mathematicalFormula: string;
  knownFailureModes: string[];
}

export interface ReconciliationItem {
  id: string;
  sourceModule: string; // e.g., "Market Data"
  targetModule: string; // e.g., "Valuation Engine"
  field: string;
  sourceValue: string;
  targetValue: string;
  difference: string;
  status: 'MATCHED' | 'WARNING' | 'EXCEPTION' | 'PENDING';
  detectedTime: string;
  auditTrail: string;
}

export interface SimulationConfig {
  timeScale: '1X' | '10X' | '100X';
  marketRegime: 'CALM' | 'TRENDING' | 'VOLATILE' | 'STRESSED';
  jpyRegime: 'APPRECIATION' | 'DEPRECIATION' | 'RANGE_BOUND';
  curveState: 'NORMAL' | 'STEEPENING' | 'FLATTENING' | 'INVERTED';
  basisState: 'STABLE' | 'WIDENING' | 'TIGHTENING';
  seed: number;
}
