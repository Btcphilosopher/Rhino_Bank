import React, { useState } from 'react';
import { 
  CheckCircle, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  Activity,
  Sparkles
} from 'lucide-react';
import { SyntheticProduct, EconomicExposure } from '../types';
import { optimizePortfolioWeights } from '../utils/engine';

interface StructuringOptimiserProps {
  currentProduct: SyntheticProduct;
  onApplyOptimizedWeights: (newExposures: EconomicExposure[]) => void;
}

export const StructuringOptimiser: React.FC<StructuringOptimiserProps> = ({
  currentProduct,
  onApplyOptimizedWeights,
}) => {
  const [selectedObjective, setSelectedObjective] = useState<
    'MAX_DIVERSIFICATION' | 'MIN_CORRELATION' | 'MIN_EXPECTED_LOSS' | 'MIN_CONCENTRATION' | 'MAX_YIELD'
  >('MIN_CONCENTRATION');

  const [activeResult, setActiveResult] = useState<{
    updatedExposures: EconomicExposure[];
    metricValue: string;
    explanation: string;
  }>(() => optimizePortfolioWeights(currentProduct.exposures, 'MIN_CONCENTRATION'));

  const handleSelectObjective = (obj: any) => {
    setSelectedObjective(obj);
    const res = optimizePortfolioWeights(currentProduct.exposures, obj);
    setActiveResult(res);
  };

  const handleApply = () => {
    onApplyOptimizedWeights(activeResult.updatedExposures);
  };

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              STRUCTURING OPTIMISER // PARETO FRONTIER SOLVER (SECTION 33)
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800">
              CONVEX PROGRAMMING SOLVER
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Optimise reference portfolio weights across multi-dimensional criteria: minimum tail correlation, maximum diversification, and minimum single-supplier concentration.
          </p>
        </div>

        <button
          onClick={handleApply}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-xs flex items-center space-x-1.5 shadow-md transition-colors cursor-pointer"
        >
          <CheckCircle className="w-4 h-4 mr-1" />
          APPLY OPTIMAL WEIGHTS TO REFERENCE POOL
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
        {[
          { id: 'MIN_CONCENTRATION', label: 'MIN CONCENTRATION', icon: ShieldCheck, desc: 'Equalize weights & eliminate single-tier exposure' },
          { id: 'MIN_CORRELATION', label: 'MIN CORRELATION', icon: Activity, desc: 'Dampen joint co-movement between metals' },
          { id: 'MAX_DIVERSIFICATION', label: 'MAX DIVERSIFICATION', icon: Sparkles, desc: 'Inverse volatility risk-parity allocation' },
          { id: 'MIN_EXPECTED_LOSS', label: 'MIN EXPECTED LOSS', icon: Zap, desc: 'Prune volatile battery chemicals & shipping' },
          { id: 'MAX_YIELD', label: 'MAX YIELD / CARRY', icon: TrendingUp, desc: 'Maximize spread carry on subassembly debt' },
        ].map((obj) => {
          const Icon = obj.icon;
          const isSelected = selectedObjective === obj.id;
          return (
            <div
              key={obj.id}
              onClick={() => handleSelectObjective(obj.id)}
              className={`p-3 rounded-lg border cursor-pointer transition-all ${
                isSelected
                  ? 'border-amber-500 bg-amber-950/40 text-amber-200 ring-1 ring-amber-500/50'
                  : 'border-slate-800 bg-[#080d16] text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center space-x-2 mb-1">
                <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                <span className="text-xs font-bold text-slate-100">{obj.label}</span>
              </div>
              <p className="text-[10px] text-slate-400 font-sans leading-tight">{obj.desc}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-[#090e18] border border-slate-800 p-4 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div>
          <span className="text-[10px] text-slate-500 block">SOLVER OUTCOME</span>
          <span className="text-base font-bold text-emerald-400">{activeResult.metricValue}</span>
          <p className="text-xs text-slate-300 font-sans mt-0.5">{activeResult.explanation}</p>
        </div>

        <div className="text-right text-[11px] text-slate-400 bg-slate-900 px-3 py-2 rounded border border-slate-800">
          Convergence: <span className="text-emerald-400 font-bold">OPTIMAL</span> | Iterations: <span className="text-slate-200">14</span> | Solver: <span className="text-slate-200">SLSQP</span>
        </div>
      </div>

      <div className="bg-[#080d16] border border-slate-800 rounded-lg p-5 space-y-3">
        <span className="text-xs font-bold text-slate-200">
          RE-WEIGHTING ALLOCATION PREVIEW (ACTIVE VS OPTIMAL)
        </span>

        <div className="space-y-2">
          {activeResult.updatedExposures.map((opt) => {
            const original = currentProduct.exposures.find((e) => e.id === opt.id);
            const origWeight = original ? original.weight : opt.weight;
            const delta = Number((opt.weight - origWeight).toFixed(1));

            return (
              <div key={opt.id} className="p-2.5 rounded bg-slate-900/60 border border-slate-800/80 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2 w-1/3">
                  <span className="font-bold text-slate-200 truncate">{opt.name}</span>
                </div>

                <div className="flex items-center space-x-6 text-right">
                  <div>
                    <span className="text-[10px] text-slate-500 block">ORIGINAL</span>
                    <span className="text-slate-400">{origWeight}%</span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-500 block">OPTIMAL</span>
                    <span className="text-amber-400 font-bold">{opt.weight}%</span>
                  </div>

                  <div className="w-16">
                    <span className="text-[10px] text-slate-500 block">DELTA</span>
                    <span className={delta > 0 ? 'text-emerald-400 font-bold' : delta < 0 ? 'text-rose-400 font-bold' : 'text-slate-400'}>
                      {delta > 0 ? `+${delta}%` : `${delta}%`}
                    </span>
                  </div>

                  <div className="w-24 text-right">
                    <span className="text-[10px] text-slate-500 block">NOTIONAL</span>
                    <span className="text-slate-200">£{(opt.notionalValue / 1e6).toFixed(0)}m</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
