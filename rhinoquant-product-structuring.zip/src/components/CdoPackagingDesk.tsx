import React, { useState } from 'react';
import { 
  RotateCcw,
  Zap 
} from 'lucide-react';
import { SyntheticProduct, Tranche } from '../types';
import { calculateWaterfall } from '../utils/engine';

interface CdoPackagingDeskProps {
  currentProduct: SyntheticProduct;
  onUpdateTranches: (newTranches: Tranche[]) => void;
}

export const CdoPackagingDesk: React.FC<CdoPackagingDeskProps> = ({
  currentProduct,
  onUpdateTranches,
}) => {
  const [tranches, setTranches] = useState<Tranche[]>(currentProduct.tranches);
  const [simulatedLossPercent, setSimulatedLossPercent] = useState<number>(7.5);

  const liveTranches = calculateWaterfall(tranches, currentProduct.totalNotionalGbp, simulatedLossPercent);
  const totalDollarLoss = (simulatedLossPercent / 100) * currentProduct.totalNotionalGbp;

  const handleResetTranches = () => {
    setTranches(currentProduct.tranches);
    onUpdateTranches(currentProduct.tranches);
    setSimulatedLossPercent(0);
  };

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              CDO TRANCHING & LOSS WATERFALL TERMINAL // CANARY WHARF DESK
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800">
              SC-CDO ENGINE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Senior-subordinated capital tranching for Industrial Reference Portfolio <span className="text-amber-400 font-bold">{currentProduct.code}</span>. Losses absorb sequentially from first-loss equity.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <button
            onClick={handleResetTranches}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 flex items-center space-x-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 mr-1" />
            RESET WATERFALL
          </button>
        </div>
      </div>

      <div className="bg-[#090e18] border border-slate-800 p-4 rounded-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-slate-200 uppercase">
              PORTFOLIO ECONOMIC LOSS WATERFALL SIMULATOR
            </span>
          </div>
          <div className="flex items-center space-x-3 text-xs">
            <span className="text-slate-400">
              Active Pool Shock: <span className="text-rose-400 font-bold">{simulatedLossPercent}%</span>
            </span>
            <span className="text-slate-400">
              Aggregate Loss: <span className="text-rose-400 font-bold">£{(totalDollarLoss / 1e6).toFixed(1)}m</span>
            </span>
          </div>
        </div>

        <div className="space-y-1">
          <input
            type="range"
            min="0"
            max="40"
            step="0.5"
            value={simulatedLossPercent}
            onChange={(e) => setSimulatedLossPercent(Number(e.target.value))}
            className="w-full accent-rose-500 cursor-pointer h-2 bg-slate-800 rounded"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>0% (Benign)</span>
            <span>5% (Equity Wiped)</span>
            <span>10% (Junior Wiped)</span>
            <span>18% (Mezz Wiped)</span>
            <span>35% (Senior Penetrated)</span>
            <span>40% (Extreme Stress)</span>
          </div>
        </div>
      </div>

      <div className="bg-[#080d16] border border-slate-800 p-4 rounded-lg space-y-2">
        <div className="flex justify-between items-center text-xs">
          <span className="font-bold text-slate-300">CAPITAL STACK SENIORITY & WRITE-DOWN ALLOCATION</span>
          <span className="text-[11px] text-slate-400">Total Capital Notional: £{(currentProduct.totalNotionalGbp / 1e9).toFixed(2)}B</span>
        </div>

        <div className="h-10 w-full rounded-md overflow-hidden flex border border-slate-700 bg-slate-900">
          {liveTranches.map((t) => {
            const isImpaired = t.allocatedLossPercent > 0;
            const isWiped = t.allocatedLossPercent >= 99.9;
            return (
              <div
                key={t.id}
                style={{ width: `${t.width}%` }}
                className="relative h-full border-r border-slate-950 flex flex-col justify-center items-center px-1 text-center transition-all overflow-hidden"
                title={`${t.name}: ${t.width}% width, Attachment: ${t.attachmentPoint}% - ${t.detachmentPoint}%, Loss: ${t.allocatedLossPercent}%`}
              >
                <div
                  className={`absolute inset-0 ${
                    t.seniority === 'EQUITY'
                      ? 'bg-rose-900/40'
                      : t.seniority === 'JUNIOR'
                      ? 'bg-orange-900/40'
                      : t.seniority === 'MEZZANINE'
                      ? 'bg-amber-900/40'
                      : t.seniority === 'SENIOR'
                      ? 'bg-blue-900/40'
                      : 'bg-emerald-900/40'
                  }`}
                />

                <div
                  style={{ width: `${t.allocatedLossPercent}%` }}
                  className="absolute left-0 top-0 bottom-0 bg-red-600/75 transition-all duration-200"
                />

                <span className="relative z-10 text-[10px] font-bold text-white truncate max-w-full">
                  {t.seniority.replace('_', ' ')} ({t.width}%)
                </span>
                <span className="relative z-10 text-[9px] font-mono text-slate-200 truncate">
                  {isWiped ? 'EXHAUSTED' : isImpaired ? `-${t.allocatedLossPercent}%` : `${t.couponSpreadBps}bps`}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-[#080d16] border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#050911] text-slate-400 border-b border-slate-800 text-[10px] uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Tranche Name</th>
                <th className="py-2.5 px-3 text-center">Seniority</th>
                <th className="py-2.5 px-3 text-center">Rating</th>
                <th className="py-2.5 px-3 text-right">Attach (Sub)</th>
                <th className="py-2.5 px-3 text-right">Detach</th>
                <th className="py-2.5 px-3 text-right">Width</th>
                <th className="py-2.5 px-3 text-right">Tranche Notional</th>
                <th className="py-2.5 px-3 text-right">Spread (SONIA+)</th>
                <th className="py-2.5 px-3 text-right">Expected Loss</th>
                <th className="py-2.5 px-3 text-right">Stress Loss</th>
                <th className="py-2.5 px-3 text-right">Loss Allocated</th>
                <th className="py-2.5 px-3 text-center">Tranche Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {liveTranches.map((t) => {
                return (
                  <tr key={t.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-slate-100">
                      {t.name}
                      <span className="block text-[10px] text-slate-500 font-mono">
                        WAL Duration: {t.durationYears}y | Sensitivity: {t.deltaSensitivity}x
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] font-bold">
                        {t.seniority}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        t.simulatedRating === 'AAA' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                        t.simulatedRating.startsWith('A') ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                        t.simulatedRating.startsWith('BBB') ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}>
                        {t.simulatedRating}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      {t.attachmentPoint}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200">
                      {t.detachmentPoint}%
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-amber-400">
                      {t.width}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-100 font-mono">
                      £{(t.notional / 1e6).toFixed(1)}m
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-400 font-mono">
                      +{t.couponSpreadBps} bps
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300 font-mono">
                      {t.expectedLoss}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-rose-400 font-mono">
                      {t.stressLoss}%
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono">
                      {t.allocatedLoss > 0 ? (
                        <span className="text-rose-400 font-bold">
                          -£{(t.allocatedLoss / 1e6).toFixed(1)}m ({t.allocatedLossPercent}%)
                        </span>
                      ) : (
                        <span className="text-slate-500">£0.0m (0.0%)</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        t.status === 'PERFORMING' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                        t.status === 'IMPAIRED' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        t.status === 'TRIGGERED' ? 'bg-orange-950 text-orange-300 border border-orange-800' :
                        'bg-red-950 text-red-300 border border-red-800 animate-pulse'
                      }`}>
                        {t.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="bg-[#050911] border-t border-slate-700 font-bold text-slate-100">
              <tr>
                <td colSpan={6} className="py-2.5 px-3">
                  TOTAL CAPITAL STRUCTURE WATERFALL ({liveTranches.length} TRANCHES)
                </td>
                <td className="py-2.5 px-3 text-right text-emerald-400">
                  £{(currentProduct.totalNotionalGbp / 1e9).toFixed(2)}B
                </td>
                <td colSpan={3} className="py-2.5 px-3 text-right text-slate-400 text-[11px]">
                  Total Absorption Capacity: 100% Notional
                </td>
                <td className="py-2.5 px-3 text-right text-rose-400">
                  -£{(totalDollarLoss / 1e6).toFixed(1)}m
                </td>
                <td className="py-2.5 px-3 text-center text-slate-400 text-[10px]">
                  {simulatedLossPercent > 0 ? 'ACTIVE SHOCK' : 'BASELINE'}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
