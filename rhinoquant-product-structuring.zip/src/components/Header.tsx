import React from 'react';
import { 
  Layers, 
  ArrowLeftRight, 
  ShieldCheck, 
  Terminal, 
  TrendingUp, 
  Clock, 
  FileText,
  Activity
} from 'lucide-react';
import { SyntheticProduct } from '../types';

interface HeaderProps {
  currentProduct: SyntheticProduct;
  onSelectProduct: (product: SyntheticProduct) => void;
  allProducts: SyntheticProduct[];
  activeMode: 'FORWARD' | 'REVERSE';
  onToggleMode: (mode: 'FORWARD' | 'REVERSE') => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenDocModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentProduct,
  onSelectProduct,
  allProducts,
  activeMode,
  onToggleMode,
  activeTab,
  onSelectTab,
  onOpenDocModal,
}) => {
  return (
    <header className="border-b border-slate-800 bg-[#090d14] text-slate-100 sticky top-0 z-40">
      <div className="flex flex-wrap items-center justify-between px-4 py-1.5 bg-[#05080e] border-b border-slate-900 text-xs text-slate-400 font-mono">
        <div className="flex items-center space-x-4">
          <span className="flex items-center text-amber-500 font-semibold tracking-wider">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse"></span>
            RHINOQUANT TERMINAL // PROD-ENGINE
          </span>
          <span className="hidden sm:inline text-slate-500">|</span>
          <span className="hidden sm:inline text-slate-400">MODEL: {currentProduct.modelVersion}</span>
          <span className="hidden md:inline text-slate-500">|</span>
          <span className="hidden md:inline text-slate-400">ENGINE: RUST/C++/PYTHON KERNEL v8.4</span>
        </div>

        <div className="flex items-center space-x-4">
          <span className="text-slate-400 flex items-center">
            <Clock className="w-3.5 h-3.5 mr-1 text-slate-500" />
            LONDON UTC 08:26:00
          </span>
          <span className="text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-2 py-0.5 rounded text-[11px] font-mono">
            BIDIRECTIONAL COMPILER: ACTIVE
          </span>
        </div>
      </div>

      <div className="px-4 py-2.5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 bg-slate-800 border border-slate-700 flex items-center justify-center rounded">
            <Layers className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base font-bold tracking-tight text-white font-mono uppercase">
                RHINOQUANT PRODUCT STRUCTURING
              </h1>
              <span className="px-1.5 py-0.5 text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded font-mono">
                INSTITUTIONAL
              </span>
            </div>
            <p className="text-[11px] text-slate-400 tracking-wider font-mono">
              SYNTHETIC PRODUCTS <span className="text-amber-400">↔</span> STRUCTURED SUPPLY CHAINS
            </p>
          </div>
        </div>

        <div className="flex items-center bg-slate-900 border border-slate-800 p-1 rounded-md self-start lg:self-center">
          <button
            onClick={() => onToggleMode('FORWARD')}
            className={`flex items-center px-3 py-1.5 rounded text-xs font-mono font-medium transition-all ${
              activeMode === 'FORWARD'
                ? 'bg-emerald-900/80 text-emerald-200 border border-emerald-700/80 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
            FORWARD STRUCTURING
            <span className="ml-1.5 text-[10px] opacity-75 hidden sm:inline">(SUPPLY CHAIN → SYNTHETIC PRODUCT)</span>
          </button>

          <button
            onClick={() => onToggleMode('REVERSE')}
            className={`flex items-center px-3 py-1.5 rounded text-xs font-mono font-medium transition-all ${
              activeMode === 'REVERSE'
                ? 'bg-amber-900/80 text-amber-200 border border-amber-700/80 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ArrowLeftRight className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
            REVERSE STRUCTURING
            <span className="ml-1.5 text-[10px] opacity-75 hidden sm:inline">(SYNTHETIC PRODUCT → SUPPLY CHAIN)</span>
          </button>
        </div>

        <div className="flex items-center space-x-2">
          <div className="relative">
            <select
              value={currentProduct.id}
              onChange={(e) => {
                const found = allProducts.find((p) => p.id === e.target.value);
                if (found) onSelectProduct(found);
              }}
              className="bg-slate-900 text-slate-200 text-xs font-mono border border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              {allProducts.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.code} — {p.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onOpenDocModal}
            className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded text-xs font-mono text-slate-200 transition-colors"
            title="Generate Institutional Term Sheet & Documents"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">TERM SHEET</span>
          </button>
        </div>
      </div>

      <nav className="flex items-center overflow-x-auto px-4 bg-[#0a0f18] border-t border-slate-800/80 scrollbar-none text-xs font-mono">
        {[
          { id: 'flagship_loop', label: 'THE RHINO LOOP', icon: Activity },
          { id: 'forward_desk', label: 'FORWARD STRUCTURING', icon: TrendingUp },
          { id: 'reverse_desk', label: 'REVERSE STRUCTURING & BEM', icon: ArrowLeftRight },
          { id: 'cdo_packaging', label: 'CDO TRANCHING & WATERFALL', icon: Layers },
          { id: 'industrial_graph', label: 'INDUSTRIAL FINANCIAL GRAPH', icon: ShieldCheck },
          { id: 'shock_lab', label: 'SHOCK LAB & CASCADING', icon: Activity },
          { id: 'risk_greeks', label: 'GREEKS, VAR & REVERSE P&L', icon: TrendingUp },
          { id: 'copula_governance', label: 'COPULA & GOVERNANCE', icon: ShieldCheck },
          { id: 'optimiser', label: 'STRUCTURING OPTIMISER', icon: TrendingUp },
          { id: 'secondary_market', label: 'SECONDARY MARKET', icon: Layers },
          { id: 'ai_assistant', label: 'RHINO STRUCTURER (AI)', icon: Terminal },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex items-center space-x-1.5 py-2.5 px-3 whitespace-nowrap border-b-2 transition-colors ${
                isActive
                  ? 'border-amber-400 text-amber-300 font-semibold bg-amber-950/20'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
