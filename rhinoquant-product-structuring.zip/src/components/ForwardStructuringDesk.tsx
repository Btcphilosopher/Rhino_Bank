import React, { useState } from 'react';
import { 
  CheckCircle, 
  RotateCw, 
  ArrowRight, 
  Boxes, 
  Cpu, 
  Factory, 
  FileCheck 
} from 'lucide-react';
import { SyntheticProduct, EconomicExposure } from '../types';

interface ForwardStructuringDeskProps {
  currentProduct: SyntheticProduct;
  onUpdateExposures: (newExposures: EconomicExposure[]) => void;
  onNavigateToTranches: () => void;
}

export const ForwardStructuringDesk: React.FC<ForwardStructuringDeskProps> = ({
  currentProduct,
  onUpdateExposures,
  onNavigateToTranches,
}) => {
  const [exposures, setExposures] = useState<EconomicExposure[]>(currentProduct.exposures);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('ALL');
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [compiledSuccess, setCompiledSuccess] = useState<boolean>(false);

  const totalWeight = Number(exposures.reduce((sum, e) => sum + e.weight, 0).toFixed(1));
  const totalNotional = exposures.reduce((sum, e) => sum + e.notionalValue, 0);

  const handleWeightChange = (id: string, newWeight: number) => {
    const updated = exposures.map((exp) => {
      if (exp.id === id) {
        const notional = Math.round((newWeight / 100) * currentProduct.totalNotionalGbp);
        return { ...exp, weight: newWeight, notionalValue: notional };
      }
      return exp;
    });
    setExposures(updated);
  };

  const handleNormalizeWeights = () => {
    const currentSum = exposures.reduce((s, e) => s + e.weight, 0);
    if (currentSum === 0) return;
    const normalized = exposures.map((exp) => {
      const normWeight = Number(((exp.weight / currentSum) * 100).toFixed(1));
      const notional = Math.round((normWeight / 100) * currentProduct.totalNotionalGbp);
      return { ...exp, weight: normWeight, notionalValue: notional };
    });
    setExposures(normalized);
    onUpdateExposures(normalized);
  };

  const handleCompileToCDO = () => {
    setIsCompiling(true);
    setTimeout(() => {
      onUpdateExposures(exposures);
      setIsCompiling(false);
      setCompiledSuccess(true);
      setTimeout(() => setCompiledSuccess(false), 3000);
    }, 600);
  };

  const filteredExposures = selectedCategoryFilter === 'ALL'
    ? exposures
    : exposures.filter((e) => e.category === selectedCategoryFilter);

  return (
    <div className="space-y-5">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100 font-mono">
                FORWARD STRUCTURING DESK // SUPPLY CHAIN → SYNTHETIC PRODUCT
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1 font-mono">
              Aggregate physical materials, factory capacity, logistics routes, and subassembly commitments into the Industrial Reference Portfolio: <span className="text-amber-400 font-bold">{currentProduct.code}</span>.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleNormalizeWeights}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs rounded border border-slate-700 transition-colors cursor-pointer"
            >
              NORMALIZE TO 100%
            </button>
            <button
              onClick={handleCompileToCDO}
              disabled={isCompiling}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold rounded flex items-center space-x-1.5 transition-colors shadow-md cursor-pointer"
            >
              {isCompiling ? (
                <>
                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  <span>COMPILING...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>COMPILE REFERENCE POOL</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-2 text-xs font-mono pt-2 border-t border-slate-800/80">
          <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
            <span className="text-slate-500 block text-[10px]">LAYER 1</span>
            <span className="text-slate-200 font-semibold">PHYSICAL POOL</span>
            <p className="text-[10px] text-slate-400 mt-0.5">PO contracts, inventory, warehouse stock</p>
          </div>
          <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
            <span className="text-slate-500 block text-[10px]">LAYER 2</span>
            <span className="text-slate-200 font-semibold">ECONOMIC EXPOSURE</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Price beta, capacity delta, supplier credit</p>
          </div>
          <div className="p-2 bg-amber-950/40 border border-amber-800/60 rounded">
            <span className="text-amber-400 block text-[10px] font-bold">LAYER 3 (ACTIVE)</span>
            <span className="text-amber-200 font-semibold">SYNTHETIC PORTFOLIO</span>
            <p className="text-[10px] text-amber-300/80 mt-0.5">Collateral basket with arbitrary weights</p>
          </div>
          <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
            <span className="text-slate-500 block text-[10px]">LAYER 4</span>
            <span className="text-slate-200 font-semibold">TRANCHING</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Equity, Junior, Mezz, Senior, Super-Senior</p>
          </div>
          <div className="p-2 bg-slate-900/80 border border-slate-800 rounded">
            <span className="text-slate-500 block text-[10px]">LAYER 5</span>
            <span className="text-slate-200 font-semibold">SYNTHETIC PRODUCT</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Tradable SC-CDO & Industrial Notes</p>
          </div>
        </div>
      </div>

      {compiledSuccess && (
        <div className="bg-emerald-950/80 border border-emerald-700 p-3 rounded text-emerald-200 text-xs font-mono flex items-center justify-between">
          <span className="flex items-center">
            <CheckCircle className="w-4 h-4 mr-2 text-emerald-400" />
            Reference Portfolio successfully compiled and loaded into CDO Tranching Engine!
          </span>
          <button
            onClick={onNavigateToTranches}
            className="px-2.5 py-1 bg-emerald-800 hover:bg-emerald-700 text-white rounded font-bold flex items-center text-[11px] cursor-pointer"
          >
            PROCEED TO TRANCHING <ArrowRight className="w-3 h-3 ml-1" />
          </button>
        </div>
      )}

      <div className="bg-[#090e18] border border-slate-800 p-4 rounded-lg font-mono text-xs space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
          <span className="text-amber-400 font-bold tracking-wider uppercase flex items-center">
            <FileCheck className="w-3.5 h-3.5 mr-1.5" />
            REFERENCE POOL METADATA SPECIFICATION // {currentProduct.code}
          </span>
          <span className="text-slate-400 text-[11px]">
            TOTAL WEIGHT: <span className={totalWeight === 100 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>{totalWeight}%</span>
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 text-[11px]">
          <div className="bg-slate-900/70 p-2 rounded border border-slate-800">
            <span className="text-slate-500 block">PRODUCT_ID</span>
            <span className="text-slate-200 font-semibold">{currentProduct.id}</span>
          </div>
          <div className="bg-slate-900/70 p-2 rounded border border-slate-800">
            <span className="text-slate-500 block">PORTFOLIO_ID</span>
            <span className="text-slate-200 font-semibold">{currentProduct.code}</span>
          </div>
          <div className="bg-slate-900/70 p-2 rounded border border-slate-800">
            <span className="text-slate-500 block">NOTIONAL</span>
            <span className="text-emerald-400 font-semibold">£{(currentProduct.totalNotionalGbp / 1e9).toFixed(2)}B {currentProduct.currency}</span>
          </div>
          <div className="bg-slate-900/70 p-2 rounded border border-slate-800">
            <span className="text-slate-500 block">MATURITY</span>
            <span className="text-slate-200 font-semibold">{currentProduct.maturityDate}</span>
          </div>
          <div className="bg-slate-900/70 p-2 rounded border border-slate-800">
            <span className="text-slate-500 block">MODEL_VERSION</span>
            <span className="text-slate-200 font-semibold">{currentProduct.modelVersion}</span>
          </div>
          <div className="bg-slate-900/70 p-2 rounded border border-slate-800">
            <span className="text-slate-500 block">REBALANCING_RULES</span>
            <span className="text-slate-200 font-semibold">Quarterly / Band 2%</span>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-1.5 font-mono text-xs">
          {['ALL', 'COMMODITY', 'COMPONENT', 'PRODUCTION', 'LOGISTICS', 'COMMERCIAL'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategoryFilter(cat)}
              className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                selectedCategoryFilter === cat
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="text-xs font-mono text-slate-400">
          Showing {filteredExposures.length} of {exposures.length} constituent exposures
        </div>
      </div>

      <div className="bg-[#080d16] border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#050911] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Exposure Name</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 text-right">Target Weight</th>
                <th className="py-2.5 px-3">Weight Adjuster</th>
                <th className="py-2.5 px-3 text-right">Notional Value</th>
                <th className="py-2.5 px-3">Physical Reference / Quantity</th>
                <th className="py-2.5 px-3">Supplier & Location</th>
                <th className="py-2.5 px-3 text-center">Rating</th>
                <th className="py-2.5 px-3 text-right">Vol (p.a.)</th>
                <th className="py-2.5 px-3">Primary Risk Factor</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-300">
              {filteredExposures.map((exp) => (
                <tr key={exp.id} className="hover:bg-slate-900/60 transition-colors">
                  <td className="py-2.5 px-3 font-semibold text-slate-100 flex items-center space-x-1.5">
                    {exp.category === 'COMMODITY' && <Boxes className="w-3.5 h-3.5 text-cyan-400 mr-1" />}
                    {exp.category === 'COMPONENT' && <Cpu className="w-3.5 h-3.5 text-blue-400 mr-1" />}
                    {exp.category === 'PRODUCTION' && <Factory className="w-3.5 h-3.5 text-emerald-400 mr-1" />}
                    {exp.category === 'LOGISTICS' && <RotateCw className="w-3.5 h-3.5 text-indigo-400 mr-1" />}
                    <span>{exp.name}</span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-400">
                    <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px]">
                      {exp.category}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-amber-400">
                    {exp.weight}%
                  </td>
                  <td className="py-2.5 px-3 w-40">
                    <input
                      type="range"
                      min="1"
                      max="35"
                      step="1"
                      value={exp.weight}
                      onChange={(e) => handleWeightChange(exp.id, Number(e.target.value))}
                      className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-200">
                    £{(exp.notionalValue / 1e6).toFixed(1)}m
                  </td>
                  <td className="py-2.5 px-3 text-slate-400">
                    {exp.quantityRequired.toLocaleString()} {exp.baseUnit}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 truncate max-w-[180px]">
                    {exp.supplierName} ({exp.factoryLocation})
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                      exp.supplierRating.startsWith('AA') ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                      exp.supplierRating.startsWith('A') ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                      'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {exp.supplierRating}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 font-mono">
                    {exp.priceVolatility}%
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                    {exp.primaryRiskFactor}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-[#050911] border-t border-slate-700 font-bold text-slate-200">
              <tr>
                <td className="py-2.5 px-3">AGGREGATE REFERENCE POOL</td>
                <td className="py-2.5 px-3 text-slate-400">{exposures.length} CONSTITUENTS</td>
                <td className={`py-2.5 px-3 text-right ${totalWeight === 100 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {totalWeight}%
                </td>
                <td className="py-2.5 px-3">
                  <span className="text-[10px] text-slate-400">
                    {totalWeight === 100 ? 'BALANCED' : `IMBALANCE: ${(100 - totalWeight).toFixed(1)}%`}
                  </span>
                </td>
                <td className="py-2.5 px-3 text-right text-emerald-400">
                  £{(totalNotional / 1e9).toFixed(2)}B
                </td>
                <td colSpan={5} className="py-2.5 px-3 text-right text-slate-400 text-[11px]">
                  All exposures denominated in GBP benchmarked against LME / ICIS / Fastmarkets
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
