import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Copy, 
  Check, 
  FileText, 
  ShieldAlert
} from 'lucide-react';
import { SyntheticProduct } from '../types';

interface DocumentTermSheetModalProps {
  product: SyntheticProduct;
  isOpen: boolean;
  onClose: () => void;
}

export const DocumentTermSheetModal: React.FC<DocumentTermSheetModalProps> = ({
  product,
  isOpen,
  onClose,
}) => {
  const [activeDoc, setActiveDoc] = useState<'FINANCIAL_TERM_SHEET' | 'INDUSTRIAL_PORTFOLIO'>('FINANCIAL_TERM_SHEET');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 font-mono">
      <div className="bg-[#090e18] border border-slate-700 w-full max-w-4xl max-h-[90vh] rounded-lg shadow-2xl flex flex-col overflow-hidden text-slate-200">
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-[#060a12]">
          <div className="flex items-center space-x-3">
            <FileText className="w-5 h-5 text-amber-400" />
            <div>
              <span className="text-xs font-bold text-slate-100 tracking-wider">
                INSTITUTIONAL DOCUMENT REPOSITORY // {product.code}
              </span>
              <p className="text-[10px] text-slate-400">
                Simulated Securities Disclosures & Industrial Reference Specification
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveDoc('FINANCIAL_TERM_SHEET')}
              className={`px-3 py-1 rounded text-xs transition-colors cursor-pointer ${
                activeDoc === 'FINANCIAL_TERM_SHEET'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              FINANCIAL TERM SHEET (SC-CDO)
            </button>
            <button
              onClick={() => setActiveDoc('INDUSTRIAL_PORTFOLIO')}
              className={`px-3 py-1 rounded text-xs transition-colors cursor-pointer ${
                activeDoc === 'INDUSTRIAL_PORTFOLIO'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              INDUSTRIAL REFERENCE PORTFOLIO
            </button>

            <button
              onClick={onClose}
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto space-y-6 text-xs leading-relaxed">
          <div className="p-3 bg-red-950/40 border border-red-800 text-red-200 rounded flex items-center justify-between">
            <span className="flex items-center font-bold">
              <ShieldAlert className="w-4 h-4 mr-2 text-red-400" />
              CONFIDENTIAL & PROPRIETARY — FOR SIMULATION AND DEMONSTRATION PURPOSES ONLY. NOT A REAL SECURITIES ISSUANCE.
            </span>
            <span className="text-[10px] text-red-300">RHINOQUANT PROTOCOL</span>
          </div>

          {activeDoc === 'FINANCIAL_TERM_SHEET' ? (
            <div className="space-y-5 bg-[#070b13] p-6 rounded border border-slate-800">
              <div className="border-b border-slate-800 pb-3">
                <span className="text-[10px] text-amber-400 font-bold uppercase">TERM SHEET SPECIFICATION</span>
                <h2 className="text-base font-bold text-white mt-1">
                  SUPPLY-CHAIN COLLATERALISED DEBT OBLIGATION // {product.code}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Synthetic reference indexation of {product.targetQuantity.toLocaleString()} units ({product.name}).
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-900/60 p-3 rounded border border-slate-800 text-[11px]">
                <div>
                  <span className="text-slate-500 block">ISSUER / STRUCTURER</span>
                  <span className="text-slate-200 font-bold">RHINOQUANT PRODUCT STRUCTURING</span>
                </div>
                <div>
                  <span className="text-slate-500 block">TOTAL NOTIONAL</span>
                  <span className="text-emerald-400 font-bold">£{(product.totalNotionalGbp / 1e9).toFixed(2)}B {product.currency}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">MATURITY DATE</span>
                  <span className="text-slate-200 font-bold">{product.maturityDate}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">PAYMENT FREQUENCY</span>
                  <span className="text-slate-200 font-bold">Quarterly (ACT/365)</span>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-bold text-amber-400 uppercase">TRANCHE CAPITAL STACK & WATERFALL ALLOCATION</h4>
                <table className="w-full text-left text-xs border border-slate-800">
                  <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase">
                    <tr>
                      <th className="py-2 px-3">Class</th>
                      <th className="py-2 px-3 text-right">Notional</th>
                      <th className="py-2 px-3 text-right">Attach</th>
                      <th className="py-2 px-3 text-right">Detach</th>
                      <th className="py-2 px-3 text-right">Coupon Spread</th>
                      <th className="py-2 px-3 text-center">Rating</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300">
                    {product.tranches.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-900/40">
                        <td className="py-2 px-3 font-bold text-slate-200">{t.name}</td>
                        <td className="py-2 px-3 text-right font-mono text-emerald-400">£{(t.notional / 1e6).toFixed(1)}m</td>
                        <td className="py-2 px-3 text-right">{t.attachmentPoint}%</td>
                        <td className="py-2 px-3 text-right">{t.detachmentPoint}%</td>
                        <td className="py-2 px-3 text-right font-bold text-amber-400">+{t.couponSpreadBps} bps</td>
                        <td className="py-2 px-3 text-center font-bold">{t.simulatedRating}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="space-y-1.5 text-xs text-slate-300 font-sans">
                <h4 className="text-xs font-bold text-amber-400 uppercase font-mono">PRIORITY OF PAYMENTS (WATERFALL)</h4>
                <p>
                  1. Senior Trustee & Custody Administrative fees.
                  <br />
                  2. Class Super-Senior interest and principal repayments until complete retirement.
                  <br />
                  3. Class Senior interest and principal amortization sequentially down to Mezzanine and Junior.
                  <br />
                  4. Equity tranche absorbs all initial portfolio impairment losses (0-5%) before mezzanine impairment.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-5 bg-[#070b13] p-6 rounded border border-slate-800">
              <div className="border-b border-slate-800 pb-3">
                <span className="text-[10px] text-emerald-400 font-bold uppercase">INDUSTRIAL REFERENCE SPECIFICATION</span>
                <h2 className="text-base font-bold text-white mt-1">
                  INDUSTRIAL BILL OF ECONOMIC MATERIALS & CAPACITY // {product.code}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Direct industrial bridge between Rhino Products engineering plants and quant trading desk.
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-bold text-emerald-400 uppercase">TIER-1 / TIER-2 COLLATERAL REFERENCES</h4>
                <table className="w-full text-left text-xs border border-slate-800">
                  <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase">
                    <tr>
                      <th className="py-2 px-3">Industrial Exposure</th>
                      <th className="py-2 px-3">Supplier & Facility</th>
                      <th className="py-2 px-3 text-right">Physical Volume</th>
                      <th className="py-2 px-3 text-right">Weight</th>
                      <th className="py-2 px-3 text-right">Notional</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300">
                    {product.exposures.map((exp) => (
                      <tr key={exp.id} className="hover:bg-slate-900/40">
                        <td className="py-2 px-3 font-bold text-slate-200">{exp.name}</td>
                        <td className="py-2 px-3 text-slate-400">{exp.supplierName} ({exp.factoryLocation})</td>
                        <td className="py-2 px-3 text-right">{exp.quantityRequired.toLocaleString()} {exp.baseUnit}</td>
                        <td className="py-2 px-3 text-right font-bold text-amber-400">{exp.weight}%</td>
                        <td className="py-2 px-3 text-right font-mono text-emerald-400">£{(exp.notionalValue / 1e6).toFixed(1)}m</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between px-5 py-3 border-t border-slate-800 bg-[#060a12] text-xs">
          <span className="text-slate-500">Hash: 0x8f4d92a1b7e30c4519f6a73d82e1c94b7a2d3c5e</span>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center space-x-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED TO CLIPBOARD' : 'COPY DOCUMENT'}</span>
            </button>
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center space-x-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>PRINT / EXPORT PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
