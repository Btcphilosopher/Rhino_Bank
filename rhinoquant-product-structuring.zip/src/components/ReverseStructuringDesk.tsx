import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  AlertTriangle, 
  RotateCw, 
  Boxes 
} from 'lucide-react';
import { SyntheticProduct } from '../types';
import { 
  solveMaterialToProductEngine, 
  compileProductToMaterial, 
  SupplyChainInputPool,
  FeasibleProductOutput
} from '../utils/engine';

interface ReverseStructuringDeskProps {
  currentProduct: SyntheticProduct;
}

export const ReverseStructuringDesk: React.FC<ReverseStructuringDeskProps> = ({
  currentProduct,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'BEM' | 'VECTOR' | 'MATERIAL_TO_PRODUCT' | 'PRODUCT_TO_MATERIAL' | 'BOTTLENECK'>('BEM');

  const [inputPool, setInputPool] = useState<SupplyChainInputPool>({
    aluminiumTonnes: 18000,
    copperTonnes: 4500,
    batteryCells: 100000,
    motors: 150000,
    semiconductorLots: 14000,
    factoryHours: 350000,
    shippingTeu: 24000,
  });

  const [targetVehicles, setTargetVehicles] = useState<number>(10000);

  const feasibleProducts: FeasibleProductOutput[] = solveMaterialToProductEngine(inputPool);
  const compiledMaterials = compileProductToMaterial(targetVehicles);
  const vector = currentProduct.vectorDecomposition;

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              REVERSE STRUCTURING DESK // SYNTHETIC PRODUCT → SUPPLY CHAIN
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30">
              BIDIRECTIONAL COMPILER
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Deconstruct synthetic instruments into physical bills of materials, solve multi-product capacity feasibility, and isolate tier-1/tier-2 manufacturing bottlenecks.
          </p>
        </div>

        <div className="flex flex-wrap items-center bg-slate-900 border border-slate-800 p-1 rounded-md text-xs">
          {[
            { id: 'BEM', label: 'BILL OF ECONOMIC MATERIALS (BEM)' },
            { id: 'VECTOR', label: '8-FACTOR VECTOR DECOMPOSITION' },
            { id: 'BOTTLENECK', label: 'BOTTLENECK ENGINE' },
            { id: 'MATERIAL_TO_PRODUCT', label: 'MATERIAL → PRODUCT' },
            { id: 'PRODUCT_TO_MATERIAL', label: 'PRODUCT → MATERIAL' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-2.5 py-1.5 rounded transition-all cursor-pointer ${
                activeSubTab === tab.id
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeSubTab === 'BEM' && (
        <div className="space-y-4">
          <div className="bg-[#080d16] border border-slate-800 rounded-lg p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3 mb-3">
              <div>
                <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center">
                  <FileSpreadsheet className="w-4 h-4 mr-1.5" />
                  BILL OF ECONOMIC MATERIALS (BEM) // {currentProduct.name}
                </h3>
                <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                  Not merely a mechanical BOM. Quantifies physical volume, economic value share, price indexing, supplier credit, and marginal risk contribution.
                </p>
              </div>
              <div className="text-right text-xs">
                <span className="text-slate-400">Total BEM Value: </span>
                <span className="text-emerald-400 font-bold">
                  £{currentProduct.bem.reduce((s, b) => s + b.economicValueGbp, 0).toLocaleString()} / unit
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#050911] text-slate-400 border-b border-slate-800 text-[10px] uppercase tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3">Component / Subassembly</th>
                    <th className="py-2.5 px-3">Physical Qty</th>
                    <th className="py-2.5 px-3 text-right">Economic Value</th>
                    <th className="py-2.5 px-3 text-right">Value Share</th>
                    <th className="py-2.5 px-3">Price Exposure Index</th>
                    <th className="py-2.5 px-3">Supplier & Facility</th>
                    <th className="py-2.5 px-3">Capacity Exposure</th>
                    <th className="py-2.5 px-3">Credit Exposure</th>
                    <th className="py-2.5 px-3">Delivery SLA</th>
                    <th className="py-2.5 px-3 text-right">Corr (ρ)</th>
                    <th className="py-2.5 px-3 text-right">Risk (bps)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {currentProduct.bem.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-900/60 transition-colors">
                      <td className="py-2.5 px-3 font-semibold text-slate-100">
                        {item.componentName}
                        <span className="block text-[10px] text-slate-500">{item.category}</span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-300">
                        {item.physicalQty} {item.unit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-100">
                        £{item.economicValueGbp.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-amber-400 font-bold">
                        {item.economicSharePercent}%
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 truncate max-w-[140px]" title={item.priceExposure}>
                        {item.priceExposure}
                      </td>
                      <td className="py-2.5 px-3 text-slate-300 truncate max-w-[150px]" title={item.supplierExposure}>
                        {item.supplierExposure}
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 truncate max-w-[140px]" title={item.capacityExposure}>
                        {item.capacityExposure}
                      </td>
                      <td className="py-2.5 px-3 text-slate-400">
                        {item.creditExposure}
                      </td>
                      <td className="py-2.5 px-3 text-slate-400">
                        {item.deliveryExposure}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-300 font-bold">
                        {item.correlationToEV}
                      </td>
                      <td className="py-2.5 px-3 text-right text-rose-400 font-bold">
                        +{item.riskContributionBps}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'VECTOR' && (
        <div className="space-y-4">
          <div className="bg-[#080d16] border border-slate-800 rounded-lg p-5">
            <div className="border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                PRODUCT VECTOR DECOMPOSITION FORMULATION (SECTION 14)
              </h3>
              <div className="mt-2 p-2.5 bg-slate-900 border border-slate-800 rounded text-slate-200 text-xs font-mono">
                <code>
                  Product = Material({vector.material}%) + Components({vector.components}%) + Manufacturing({vector.manufacturing}%) + Logistics({vector.logistics}%) + Energy({vector.energy}%) + Labour({vector.labour}%) + Capital({vector.capital}%) + Financing({vector.financing}%)
                </code>
              </div>
            </div>

            <div className="h-6 w-full rounded overflow-hidden flex border border-slate-700 mb-6">
              <div style={{ width: `${vector.material}%` }} className="bg-cyan-600 flex items-center justify-center text-[10px] font-bold text-white" title={`Material: ${vector.material}%`}>{vector.material}%</div>
              <div style={{ width: `${vector.components}%` }} className="bg-blue-600 flex items-center justify-center text-[10px] font-bold text-white" title={`Components: ${vector.components}%`}>{vector.components}%</div>
              <div style={{ width: `${vector.manufacturing}%` }} className="bg-emerald-600 flex items-center justify-center text-[10px] font-bold text-white" title={`Manufacturing: ${vector.manufacturing}%`}>{vector.manufacturing}%</div>
              <div style={{ width: `${vector.logistics}%` }} className="bg-indigo-600 flex items-center justify-center text-[10px] font-bold text-white" title={`Logistics: ${vector.logistics}%`}>{vector.logistics}%</div>
              <div style={{ width: `${vector.energy}%` }} className="bg-amber-600 flex items-center justify-center text-[10px] font-bold text-white" title={`Energy: ${vector.energy}%`}>{vector.energy}%</div>
              <div style={{ width: `${vector.labour}%` }} className="bg-purple-600 flex items-center justify-center text-[10px] font-bold text-white" title={`Labour: ${vector.labour}%`}>{vector.labour}%</div>
              <div style={{ width: `${vector.capital}%` }} className="bg-rose-600 flex items-center justify-center text-[10px] font-bold text-white" title={`Capital: ${vector.capital}%`}>{vector.capital}%</div>
              <div style={{ width: `${vector.financing}%` }} className="bg-slate-600 flex items-center justify-center text-[10px] font-bold text-white" title={`Financing: ${vector.financing}%`}>{vector.financing}%</div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              {[
                { name: 'MATERIAL CONTENT', percent: vector.material, color: 'text-cyan-400 border-cyan-800 bg-cyan-950/20', desc: 'Raw ores, ingots, sheet metal, chemical precursors' },
                { name: 'COMPONENT CONTENT', percent: vector.components, color: 'text-blue-400 border-blue-800 bg-blue-950/20', desc: 'Tier-1 modules, battery cells, motors, MCUs' },
                { name: 'MANUFACTURING CONTENT', percent: vector.manufacturing, color: 'text-emerald-400 border-emerald-800 bg-emerald-950/20', desc: 'Cleanrooms, robotic assembly, stamping presses' },
                { name: 'LOGISTICS CONTENT', percent: vector.logistics, color: 'text-indigo-400 border-indigo-800 bg-indigo-950/20', desc: 'Container freight, RoRo shipping, rail shuttles' },
                { name: 'ENERGY CONTENT', percent: vector.energy, color: 'text-amber-400 border-amber-800 bg-amber-950/20', desc: 'Smelter baseload power, formation kWh, gas heat' },
                { name: 'LABOUR CONTENT', percent: vector.labour, color: 'text-purple-400 border-purple-800 bg-purple-950/20', desc: 'Tooling engineers, QC specialists, logistics crews' },
                { name: 'CAPITAL ASSETS', percent: vector.capital, color: 'text-rose-400 border-rose-800 bg-rose-950/20', desc: 'Die amortization, factory leasehold depreciation' },
                { name: 'FINANCING & CARRY', percent: vector.financing, color: 'text-slate-400 border-slate-800 bg-slate-900/60', desc: 'Working capital PO financing, letter of credit rates' },
              ].map((item) => (
                <div key={item.name} className={`p-3 rounded border ${item.color}`}>
                  <div className="flex justify-between items-baseline">
                    <span className="text-[10px] font-bold">{item.name}</span>
                    <span className="text-base font-bold font-mono">{item.percent}%</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 font-sans leading-tight">
                    {item.desc}
                  </p>
                  <div className="mt-2 text-[10px] text-slate-400">
                    Notional: <span className="text-slate-200">£{((item.percent / 100) * currentProduct.totalNotionalGbp / 1e6).toFixed(0)}m</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'BOTTLENECK' && (
        <div className="space-y-4">
          <div className="bg-[#080d16] border border-slate-800 rounded-lg p-5">
            <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center">
                  <AlertTriangle className="w-4 h-4 mr-1.5 text-amber-400" />
                  SUPPLY-CHAIN BOTTLENECK ENGINE (SECTION 26)
                </h3>
                <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                  Identifies the binding component or factory constraint limiting aggregate programme throughput.
                </p>
              </div>
              <div className="px-3 py-1 bg-rose-950/80 border border-rose-800 rounded text-rose-300 text-xs">
                CRITICAL LIMITER: <span className="font-bold">TSMC 28nm MCUs (87%)</span>
              </div>
            </div>

            <div className="space-y-3">
              {currentProduct.bottlenecks.map((b) => {
                const isCritical = b.capacityPercent < 90;
                return (
                  <div
                    key={b.resource}
                    className={`p-3 rounded border ${
                      isCritical
                        ? 'border-rose-800 bg-rose-950/20'
                        : b.capacityPercent <= 100
                        ? 'border-amber-800 bg-amber-950/20'
                        : 'border-emerald-800 bg-emerald-950/20'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                      <span className="font-bold text-slate-200 text-xs">{b.resource}</span>
                      <div className="flex items-center space-x-3 text-xs">
                        <span className="text-slate-400">
                          Capacity: <span className={isCritical ? 'text-rose-400 font-bold' : 'text-slate-200 font-bold'}>{b.capacityPercent}%</span>
                        </span>
                        <span className="text-slate-400">
                          Max Output: <span className="text-slate-200 font-bold">{b.constrainedOutput.toLocaleString()} units</span>
                        </span>
                      </div>
                    </div>

                    <div className="w-full bg-slate-800 h-2 rounded overflow-hidden mb-1.5">
                      <div
                        style={{ width: `${Math.min(100, (b.capacityPercent / 140) * 100)}%` }}
                        className={`h-full ${
                          isCritical ? 'bg-rose-500' : b.capacityPercent <= 100 ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                      />
                    </div>
                    <p className="text-[11px] text-slate-400 font-sans">{b.impactDescription}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'MATERIAL_TO_PRODUCT' && (
        <div className="space-y-4">
          <div className="bg-[#080d16] border border-slate-800 rounded-lg p-5">
            <div className="border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center">
                <RotateCw className="w-4 h-4 mr-1.5" />
                MATERIAL → PRODUCT COMPILER (SECTION 24)
              </h3>
              <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                Query: <span className="text-slate-200 font-bold">"Given this pool of raw commodities, factory shifts, and shipping slots, what products can be synthesized and where are the bottlenecks?"</span>
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-900/90 p-4 rounded border border-slate-800 mb-5">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">ALUMINIUM (TONNES)</label>
                <input
                  type="number"
                  value={inputPool.aluminiumTonnes}
                  onChange={(e) => setInputPool({ ...inputPool, aluminiumTonnes: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">COPPER (TONNES)</label>
                <input
                  type="number"
                  value={inputPool.copperTonnes}
                  onChange={(e) => setInputPool({ ...inputPool, copperTonnes: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">BATTERY CELLS</label>
                <input
                  type="number"
                  value={inputPool.batteryCells}
                  onChange={(e) => setInputPool({ ...inputPool, batteryCells: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">MOTORS</label>
                <input
                  type="number"
                  value={inputPool.motors}
                  onChange={(e) => setInputPool({ ...inputPool, motors: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">SEMICONDUCTOR LOTS (K)</label>
                <input
                  type="number"
                  value={inputPool.semiconductorLots}
                  onChange={(e) => setInputPool({ ...inputPool, semiconductorLots: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">FACTORY HOURS</label>
                <input
                  type="number"
                  value={inputPool.factoryHours}
                  onChange={(e) => setInputPool({ ...inputPool, factoryHours: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">SHIPPING CAPACITY (TEU)</label>
                <input
                  type="number"
                  value={inputPool.shippingTeu}
                  onChange={(e) => setInputPool({ ...inputPool, shippingTeu: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
                />
              </div>

              <div className="flex items-end">
                <button
                  onClick={() => setInputPool({ aluminiumTonnes: 25000, copperTonnes: 6000, batteryCells: 130000, motors: 180000, semiconductorLots: 18000, factoryHours: 420000, shippingTeu: 30000 })}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 py-1.5 rounded text-xs border border-slate-700 cursor-pointer"
                >
                  EXPAND QUOTAS (+30%)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {feasibleProducts.map((p) => (
                <div key={p.productName} className="p-4 rounded border border-slate-800 bg-slate-950/60 space-y-3">
                  <div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                      {p.category}
                    </span>
                    <h4 className="text-xs font-bold text-slate-100 mt-1">{p.productName}</h4>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Feasible Output:</span>
                      <span className="text-emerald-400 font-bold">{p.maxUnitsPossible.toLocaleString()} units</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Limiting Constraint:</span>
                      <span className="text-rose-400 font-bold">{p.bottleneckResource}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Unit Gross Margin:</span>
                      <span className="text-amber-400 font-bold">{p.marginPercent}% (£{(p.unitGrossRevenueGbp - p.unitProductionCostGbp).toLocaleString()})</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Total Gross Profit:</span>
                      <span className="text-emerald-300 font-bold">£{(p.totalGrossMarginGbp / 1e6).toFixed(1)}m</span>
                    </div>
                  </div>

                  <div className="text-[10px] text-slate-400 space-y-1">
                    <span className="font-semibold text-slate-300 block">Required Input Breakdown:</span>
                    {p.resourceRequirementsPerUnit.slice(0, 4).map((r) => (
                      <div key={r.resource} className="flex justify-between">
                        <span>{r.resource}:</span>
                        <span>{r.maxUnitsSupported.toLocaleString()} units cap</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'PRODUCT_TO_MATERIAL' && (
        <div className="space-y-4">
          <div className="bg-[#080d16] border border-slate-800 rounded-lg p-5">
            <div className="border-b border-slate-800 pb-3 mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center">
                  <Boxes className="w-4 h-4 mr-1.5" />
                  PRODUCT → MATERIAL COMPILER (SECTION 25)
                </h3>
                <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                  Input target vehicle run → Instantly compiles required tonnes of copper, lithium, nickel, semiconductor lots, and assembly hours.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-400">TARGET FLEET:</span>
                <input
                  type="number"
                  step="1000"
                  value={targetVehicles}
                  onChange={(e) => setTargetVehicles(Math.max(100, Number(e.target.value)))}
                  className="w-28 bg-slate-900 border border-slate-700 text-emerald-400 font-bold px-2 py-1 rounded text-xs"
                />
                <span className="text-xs text-slate-400">UNITS</span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#050911] text-slate-400 border-b border-slate-800 text-[10px] uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Physical Raw Resource</th>
                    <th className="py-2.5 px-3 text-right">Per Vehicle</th>
                    <th className="py-2.5 px-3 text-right">Total Quantity Required</th>
                    <th className="py-2.5 px-3 text-right">Total Economic Notional</th>
                    <th className="py-2.5 px-3">Spot Benchmark Index</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {compiledMaterials.map((m) => (
                    <tr key={m.material} className="hover:bg-slate-900/60">
                      <td className="py-2 px-3 font-semibold text-slate-100">{m.material}</td>
                      <td className="py-2 px-3 text-right text-slate-400">{m.perUnit} {m.unit}</td>
                      <td className="py-2 px-3 text-right font-bold text-amber-400">
                        {m.totalRequired.toLocaleString()} {m.unit}
                      </td>
                      <td className="py-2 px-3 text-right font-bold text-emerald-400">
                        £{(m.totalCostGbp / 1e6).toFixed(2)}m
                      </td>
                      <td className="py-2 px-3 text-slate-400 text-[11px]">{m.priceIndex}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-[#050911] border-t border-slate-700 font-bold text-slate-100">
                  <tr>
                    <td colSpan={3} className="py-2.5 px-3">
                      TOTAL EMBEDDED INDUSTRIAL COMMITMENT ({targetVehicles.toLocaleString()} VEHICLES)
                    </td>
                    <td className="py-2.5 px-3 text-right text-emerald-400 font-mono">
                      £{(compiledMaterials.reduce((s, m) => s + m.totalCostGbp, 0) / 1e6).toFixed(2)}m
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                      100% look-through reference backing
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
