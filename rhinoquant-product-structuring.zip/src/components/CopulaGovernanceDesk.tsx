import React, { useState } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  GitCompare,
  Scale
} from 'lucide-react';
import { SyntheticProduct, ModelGovernanceRecord } from '../types';
import { DEFAULT_GOVERNANCE } from '../data/defaultProducts';
import { compareCopulaModels } from '../utils/engine';

interface CopulaGovernanceDeskProps {
  currentProduct: SyntheticProduct;
}

export const CopulaGovernanceDesk: React.FC<CopulaGovernanceDeskProps> = ({
  currentProduct,
}) => {
  const [govRecord] = useState<ModelGovernanceRecord>(DEFAULT_GOVERNANCE);
  const comparison = compareCopulaModels(currentProduct.tranches);

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              COPULA ENGINE & MODEL GOVERNANCE // BASE VS CHALLENGER (SECTIONS 20, 47 & 48)
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-blue-950/80 text-blue-300 border border-blue-800">
              VALIDATION SUITE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Rigorous quantitative governance comparing fat-tailed Student-t Copula with Gaussian Copula to prevent underestimation of joint catastrophic supply-chain defaults.
          </p>
        </div>

        <div className="text-xs text-slate-400 bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
          SEED: <span className="text-amber-400 font-bold">{govRecord.randomSeed}</span> | AUDIT: <span className="text-slate-300 font-mono text-[10px]">{govRecord.auditHash.substring(0, 10)}...</span>
        </div>
      </div>

      <div className="bg-[#080d16] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <span className="text-xs font-bold text-amber-400 flex items-center">
            <GitCompare className="w-3.5 h-3.5 mr-1.5" />
            CHALLENGER STRESS COMPARISON: STUDENT-T (BASE) VS GAUSSIAN (CHALLENGER)
          </span>
          <span className="text-[10px] text-slate-400">
            Base: Student-t (df=4.8, λ_L=0.28) | Challenger: Gaussian (λ_L=0.00)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#050911] text-slate-400 border-b border-slate-800 text-[10px] uppercase">
              <tr>
                <th className="py-2.5 px-3">Tranche Seniority</th>
                <th className="py-2.5 px-3 text-right">Student-t Fair Spread</th>
                <th className="py-2.5 px-3 text-right">Gaussian Fair Spread</th>
                <th className="py-2.5 px-3 text-right">Spread Variance</th>
                <th className="py-2.5 px-3 text-right">Student-t Stress Loss</th>
                <th className="py-2.5 px-3 text-right">Gaussian Stress Loss</th>
                <th className="py-2.5 px-3 text-right">Tail Underestimation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {comparison.map((c) => (
                <tr key={c.trancheName} className="hover:bg-slate-900/60">
                  <td className="py-2.5 px-3 font-semibold text-slate-100">
                    {c.trancheName} ({c.seniority})
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-amber-400">
                    +{c.baseModel.fairSpreadBps} bps
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400">
                    +{c.challengerModel.fairSpreadBps} bps
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-rose-400">
                    +{c.spreadVarianceBps} bps
                  </td>
                  <td className="py-2.5 px-3 text-right text-rose-400 font-bold">
                    {c.baseModel.stressLoss}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400">
                    {c.challengerModel.stressLoss}%
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold">
                    <span className="text-red-400">
                      -{c.tailRiskUnderestimationPercent}% under-hedged
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-3 rounded bg-amber-950/20 border border-amber-800/60 text-xs text-amber-200/90 font-sans">
          <span className="font-bold font-mono text-amber-400">KEY QUANTITATIVE TAKEAWAY: </span>
          The Gaussian Copula significantly underestimates tail joint correlation among automotive tier-1 suppliers during systemic industrial shocks (e.g. semiconductor allocation freezes or port closures). Senior tranches priced with Gaussian models would be under-spread by up to 45 bps.
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#080d16] border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-xs font-bold text-slate-200 flex items-center border-b border-slate-800 pb-1">
            <Scale className="w-3.5 h-3.5 mr-1 text-blue-400" />
            CORE STRUCTURING ASSUMPTIONS
          </span>
          <ul className="space-y-1.5 text-[11px] text-slate-400 font-sans list-disc list-inside">
            {govRecord.assumptions.map((a, idx) => (
              <li key={idx} className="leading-tight">{a}</li>
            ))}
          </ul>
        </div>

        <div className="bg-[#080d16] border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-xs font-bold text-slate-200 flex items-center border-b border-slate-800 pb-1">
            <AlertTriangle className="w-3.5 h-3.5 mr-1 text-amber-400" />
            STRESS CALIBRATION PARAMETERS
          </span>
          <ul className="space-y-1.5 text-[11px] text-slate-400 font-sans list-disc list-inside">
            {govRecord.stressParameters.map((s, idx) => (
              <li key={idx} className="leading-tight">{s}</li>
            ))}
          </ul>
        </div>

        <div className="bg-[#080d16] border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-xs font-bold text-slate-200 flex items-center border-b border-slate-800 pb-1">
            <ShieldCheck className="w-3.5 h-3.5 mr-1 text-emerald-400" />
            MODEL BOUNDARIES & LIMITATIONS
          </span>
          <ul className="space-y-1.5 text-[11px] text-slate-400 font-sans list-disc list-inside">
            {govRecord.knownLimitations.map((l, idx) => (
              <li key={idx} className="leading-tight">{l}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
