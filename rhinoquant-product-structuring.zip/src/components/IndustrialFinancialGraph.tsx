import React, { useState } from 'react';
import { 
  Network, 
  ShieldAlert, 
  Info
} from 'lucide-react';
import { SyntheticProduct } from '../types';

interface IndustrialFinancialGraphProps {
  currentProduct: SyntheticProduct;
  allProducts: SyntheticProduct[];
}

interface GraphNode {
  id: string;
  name: string;
  category: 'MATERIAL' | 'COMPONENT' | 'FACTORY' | 'LOGISTICS' | 'PRODUCT' | 'EXPOSURE' | 'TRANCHE' | 'PORTFOLIO';
  x: number;
  y: number;
  economicWeight: string;
  tier: string;
  concentrationRisk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  exposedProducts: string[];
  description: string;
}

export const IndustrialFinancialGraph: React.FC<IndustrialFinancialGraphProps> = ({
  currentProduct,
  allProducts,
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-semi');
  const [traversalMode, setTraversalMode] = useState<'UPSTREAM' | 'DOWNSTREAM' | 'ALL'>('ALL');

  const nodes: GraphNode[] = [
    {
      id: 'node-cu',
      name: 'Refined Copper Cathodes (Grade A)',
      category: 'MATERIAL',
      x: 8,
      y: 20,
      economicWeight: '8% (£360m)',
      tier: 'Tier 3 Raw Ore & Smelting',
      concentrationRisk: 'HIGH',
      exposedProducts: ['RQP-EV-2026-001', 'RQP-H2-2026-003'],
      description: 'Aurubis & KME extraction forward contracts. Primary feedstock for motor stators and high-voltage busbars.',
    },
    {
      id: 'node-al',
      name: 'Extruded Aluminium 6000-Series',
      category: 'MATERIAL',
      x: 8,
      y: 50,
      economicWeight: '12% (£540m)',
      tier: 'Tier 3 Bauxite & Smelting',
      concentrationRisk: 'MEDIUM',
      exposedProducts: ['RQP-EV-2026-001', 'RQP-AERION-2026-002'],
      description: 'Hydro & Rio Tinto smelters in Sunndal & Gloucestershire. Lightweight monocoque structure.',
    },
    {
      id: 'node-li',
      name: 'Battery Lithium Hydroxide (LiOH)',
      category: 'MATERIAL',
      x: 8,
      y: 80,
      economicWeight: '7% (£315m)',
      tier: 'Tier 3 Chemical Refining',
      concentrationRisk: 'HIGH',
      exposedProducts: ['RQP-EV-2026-001'],
      description: 'Albemarle & SQM brine extraction. Key chemical precursor for high-nickel cathode active materials.',
    },
    {
      id: 'node-motor',
      name: 'Hairpin Traction Dual Motors',
      category: 'COMPONENT',
      x: 28,
      y: 20,
      economicWeight: '7% (£315m)',
      tier: 'Tier 1 Powertrain Assembly',
      concentrationRisk: 'LOW',
      exposedProducts: ['RQP-EV-2026-001'],
      description: 'Rhino Powertrain Sheffield. High-torque 800V permanent magnet synchronous dual-drive.',
    },
    {
      id: 'node-semi',
      name: '28nm MCUs & SiC Inverter Chips',
      category: 'COMPONENT',
      x: 28,
      y: 50,
      economicWeight: '9% (£405m)',
      tier: 'Tier 2 Semiconductor Foundry',
      concentrationRisk: 'CRITICAL',
      exposedProducts: ['RQP-EV-2026-001', 'RQP-AERION-2026-002', 'RQP-H2-2026-003'],
      description: 'TSMC Fab 14 & Infineon Dresden. Critical systemic bottleneck constraining all 3 Rhino flagship platforms.',
    },
    {
      id: 'node-cells',
      name: '80kWh Prismatic Battery Modules',
      category: 'COMPONENT',
      x: 28,
      y: 80,
      economicWeight: '18% (£810m)',
      tier: 'Tier 1 Electrochemical Pack',
      concentrationRisk: 'HIGH',
      exposedProducts: ['RQP-EV-2026-001'],
      description: 'AESC Envision Gigafactory Sunderland. Largest single component weighting in reference pool.',
    },
    {
      id: 'node-solihull',
      name: 'Solihull Flex-Factory Plant 4',
      category: 'FACTORY',
      x: 48,
      y: 35,
      economicWeight: '10% (£450m)',
      tier: 'Final Vehicle Assembly',
      concentrationRisk: 'HIGH',
      exposedProducts: ['RQP-EV-2026-001'],
      description: '350,000 robotic operating hours. Takt time 68 seconds with automated guided vehicle (AGV) shuttles.',
    },
    {
      id: 'node-ports',
      name: 'Felixstowe / Southampton Port Hub',
      category: 'LOGISTICS',
      x: 48,
      y: 70,
      economicWeight: '5% (£225m)',
      tier: 'Maritime Freight & RoRo',
      concentrationRisk: 'HIGH',
      exposedProducts: ['RQP-EV-2026-001', 'RQP-AERION-2026-002'],
      description: 'DP World & Maersk container logistics. Inbound wafer freight and export finished vehicle RoRo slips.',
    },
    {
      id: 'node-product',
      name: 'RHINO EV PLATFORM 01',
      category: 'PRODUCT',
      x: 68,
      y: 50,
      economicWeight: '100% (£4.5B)',
      tier: 'Industrial Digital Twin Asset',
      concentrationRisk: 'MEDIUM',
      exposedProducts: ['RQP-EV-2026-001'],
      description: 'Core synthetic product representing 100,000 electric vehicles over 5-year manufacturing run.',
    },
    {
      id: 'node-tranches',
      name: 'SC-CDO Capital Tranches (Eq to AAA)',
      category: 'TRANCHE',
      x: 86,
      y: 35,
      economicWeight: '5 Tranches',
      tier: 'Credit Risk Seniority Stack',
      concentrationRisk: 'LOW',
      exposedProducts: ['RQP-EV-2026-001'],
      description: 'Equity (0-5%), Junior (5-10%), Mezzanine (10-18%), Senior (18-35%), Super-Senior (35-100%).',
    },
    {
      id: 'node-portfolio',
      name: 'RHINO GLOBAL QUANT FUND',
      category: 'PORTFOLIO',
      x: 86,
      y: 70,
      economicWeight: '£12.4B NAV',
      tier: 'Institutional Balance Sheet',
      concentrationRisk: 'LOW',
      exposedProducts: ['RQP-EV-2026-001', 'RQP-AERION-2026-002', 'RQP-H2-2026-003'],
      description: 'Multi-strategy portfolio holding mezzanine and senior structured exposures alongside physical hedge overlays.',
    },
  ];

  const edges = [
    { from: 'node-cu', to: 'node-motor' },
    { from: 'node-al', to: 'node-solihull' },
    { from: 'node-li', to: 'node-cells' },
    { from: 'node-semi', to: 'node-motor' },
    { from: 'node-semi', to: 'node-solihull' },
    { from: 'node-cells', to: 'node-solihull' },
    { from: 'node-motor', to: 'node-solihull' },
    { from: 'node-solihull', to: 'node-product' },
    { from: 'node-ports', to: 'node-product' },
    { from: 'node-product', to: 'node-tranches' },
    { from: 'node-tranches', to: 'node-portfolio' },
  ];

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[4];

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              GLOBAL INDUSTRIAL FINANCIAL GRAPH (SECTIONS 43, 44 & 67)
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800">
              NETWORK GRAPH ENGINE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Full topological traversal linking Raw Materials ↔ Components ↔ Factories ↔ Logistics ↔ Synthetic Products ↔ Tranches ↔ Rhino Portfolio.
          </p>
        </div>

        <div className="flex items-center bg-slate-900 border border-slate-800 p-1 rounded text-xs">
          <button
            onClick={() => setTraversalMode('ALL')}
            className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
              traversalMode === 'ALL' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            BIDIRECTIONAL
          </button>
          <button
            onClick={() => setTraversalMode('UPSTREAM')}
            className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
              traversalMode === 'UPSTREAM' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            UPSTREAM (REVERSE)
          </button>
          <button
            onClick={() => setTraversalMode('DOWNSTREAM')}
            className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
              traversalMode === 'DOWNSTREAM' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            DOWNSTREAM (FORWARD)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-8 bg-[#070b12] border border-slate-800 rounded-lg p-3 relative overflow-hidden flex flex-col justify-between min-h-[480px]">
          <div className="flex justify-between items-center text-xs text-slate-400 border-b border-slate-900 pb-2 mb-2">
            <span className="flex items-center">
              <Network className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
              INTERACTIVE CAUSAL TOPOLOGY
            </span>
            <span className="text-[11px] text-slate-500">
              Click any node to evaluate systemic cross-product concentration
            </span>
          </div>

          <div className="relative w-full h-[400px]">
            <svg className="w-full h-full" viewBox="0 0 1000 500">
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>

              {edges.map((e) => {
                const src = nodes.find((n) => n.id === e.from);
                const dst = nodes.find((n) => n.id === e.to);
                if (!src || !dst) return null;

                const x1 = (src.x / 100) * 1000;
                const y1 = (src.y / 100) * 500;
                const x2 = (dst.x / 100) * 1000;
                const y2 = (dst.y / 100) * 500;

                const isConnected = selectedNode.id === src.id || selectedNode.id === dst.id;

                return (
                  <g key={`${e.from}-${e.to}`}>
                    <line
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke={isConnected ? '#f59e0b' : '#1e293b'}
                      strokeWidth={isConnected ? 2.5 : 1.2}
                      strokeDasharray={isConnected ? 'none' : '4 2'}
                      filter={isConnected ? 'url(#glow)' : undefined}
                      className="transition-all duration-300"
                    />
                    {isConnected && (
                      <circle
                        r="3.5"
                        fill="#38bdf8"
                        className="animate-ping"
                        cx={(x1 + x2) / 2}
                        cy={(y1 + y2) / 2}
                      />
                    )}
                  </g>
                );
              })}

              {nodes.map((node) => {
                const cx = (node.x / 100) * 1000;
                const cy = (node.y / 100) * 500;
                const isSelected = selectedNode.id === node.id;

                let nodeColor = '#3b82f6';
                if (node.category === 'MATERIAL') nodeColor = '#06b6d4';
                if (node.category === 'COMPONENT') nodeColor = '#3b82f6';
                if (node.category === 'FACTORY') nodeColor = '#10b981';
                if (node.category === 'LOGISTICS') nodeColor = '#8b5cf6';
                if (node.category === 'PRODUCT') nodeColor = '#f59e0b';
                if (node.category === 'TRANCHE') nodeColor = '#f43f5e';
                if (node.category === 'PORTFOLIO') nodeColor = '#10b981';

                return (
                  <g
                    key={node.id}
                    onClick={() => setSelectedNodeId(node.id)}
                    className="cursor-pointer group"
                  >
                    {node.concentrationRisk === 'CRITICAL' && (
                      <circle
                        cx={cx}
                        cy={cy}
                        r="20"
                        fill="none"
                        stroke="#ef4444"
                        strokeWidth="1.5"
                        opacity="0.6"
                        className="animate-pulse"
                      />
                    )}

                    <circle
                      cx={cx}
                      cy={cy}
                      r={isSelected ? 16 : 12}
                      fill="#0b111e"
                      stroke={isSelected ? '#f59e0b' : nodeColor}
                      strokeWidth={isSelected ? 3 : 2}
                      className="transition-all duration-150 group-hover:scale-110"
                    />

                    <circle
                      cx={cx}
                      cy={cy}
                      r={isSelected ? 6 : 4}
                      fill={isSelected ? '#f59e0b' : nodeColor}
                    />

                    <text
                      x={cx}
                      y={cy + 24}
                      textAnchor="middle"
                      fill={isSelected ? '#fef08a' : '#94a3b8'}
                      fontSize="10"
                      fontFamily="monospace"
                      fontWeight={isSelected ? 'bold' : 'normal'}
                      className="select-none pointer-events-none"
                    >
                      {node.name.length > 22 ? `${node.name.substring(0, 20)}...` : node.name}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="flex flex-wrap items-center justify-between text-[10px] text-slate-400 border-t border-slate-900 pt-2">
            <div className="flex items-center space-x-3">
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-cyan-400 mr-1"></span>Material</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-blue-400 mr-1"></span>Component</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-emerald-400 mr-1"></span>Factory</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-purple-400 mr-1"></span>Logistics</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-amber-400 mr-1"></span>Product</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-rose-400 mr-1"></span>Tranche</span>
            </div>
            <span>Status: Topological Matrix Synchronized</span>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-3">
          <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-amber-400 flex items-center">
                <Info className="w-3.5 h-3.5 mr-1" />
                NODE RISK INSPECTOR
              </span>
              <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                selectedNode.concentrationRisk === 'CRITICAL' ? 'bg-red-950 text-red-300 border border-red-800' :
                selectedNode.concentrationRisk === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                'bg-emerald-950 text-emerald-300 border border-emerald-800'
              }`}>
                RISK: {selectedNode.concentrationRisk}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 uppercase">{selectedNode.tier}</span>
              <h3 className="text-sm font-bold text-slate-100 mt-0.5">{selectedNode.name}</h3>
              <p className="text-xs text-slate-300 mt-1 font-sans leading-relaxed">
                {selectedNode.description}
              </p>
            </div>

            <div className="bg-slate-900/90 p-3 rounded border border-slate-800 text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Node Category:</span>
                <span className="text-slate-200 font-semibold">{selectedNode.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Economic Value:</span>
                <span className="text-amber-400 font-bold">{selectedNode.economicWeight}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Systemic Beta:</span>
                <span className="text-emerald-400 font-bold">1.28x to Global Industrial</span>
              </div>
            </div>

            <div className="p-3 rounded bg-amber-950/20 border border-amber-800/60 space-y-1.5">
              <div className="flex items-center text-amber-300 text-xs font-bold">
                <ShieldAlert className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
                CROSS-PRODUCT CONCENTRATION
              </div>
              <p className="text-[11px] text-slate-300 font-sans">
                This node is a single-point-of-failure across <span className="text-amber-400 font-bold">{selectedNode.exposedProducts.length}</span> active Rhino platforms:
              </p>
              <div className="flex flex-wrap gap-1 mt-1">
                {selectedNode.exposedProducts.map((p) => (
                  <span key={p} className="text-[10px] px-1.5 py-0.5 bg-slate-900 border border-slate-700 text-slate-200 rounded">
                    {p}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
