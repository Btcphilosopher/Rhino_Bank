import React, { useState } from 'react';
import { 
  CheckCircle, 
  Activity, 
  Send, 
  Zap 
} from 'lucide-react';
import { SecondaryInstrument } from '../types';
import { SECONDARY_MARKET_INSTRUMENTS } from '../data/defaultProducts';

export const SecondaryMarketDesk: React.FC = () => {
  const [instruments] = useState<SecondaryInstrument[]>(SECONDARY_MARKET_INSTRUMENTS);
  const [selectedInst, setSelectedInst] = useState<SecondaryInstrument>(instruments[0]);
  const [rfqSide, setRfqSide] = useState<'BUY' | 'SELL'>('BUY');
  const [rfqQuantity, setRfqQuantity] = useState<number>(10000000);
  const [tradeMessage, setTradeMessage] = useState<string | null>(null);

  const handleExecuteRFQ = (e: React.FormEvent) => {
    e.preventDefault();
    const price = rfqSide === 'BUY' ? selectedInst.askPrice : selectedInst.bidPrice;
    setTradeMessage(
      `ORDER EXECUTED: ${rfqSide} £${(rfqQuantity / 1e6).toFixed(1)}m of ${selectedInst.symbol} at ${price.toFixed(2)} (Yield: ${selectedInst.yieldToMaturity}% | Spread: +${selectedInst.spreadBps}bps)`
    );
    setTimeout(() => setTradeMessage(null), 5000);
  };

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              RHINO PRODUCT SECONDARY MARKET & RFQ (SECTIONS 39 & 40)
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800">
              INSTITUTIONAL ORDER BOOK
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Liquid secondary exchange for Supply-Chain Collateralised Debt Obligations (SC-CDO), Synthetic Commodity Notes, and Manufacturing Exposure Notes.
          </p>
        </div>

        <div className="text-xs text-slate-400">
          DAILY TURNOVER: <span className="text-emerald-400 font-bold">£384.2m</span>
        </div>
      </div>

      {tradeMessage && (
        <div className="p-3 rounded bg-emerald-950/80 border border-emerald-700 text-emerald-200 text-xs flex items-center justify-between">
          <span className="flex items-center">
            <CheckCircle className="w-4 h-4 mr-2 text-emerald-400" />
            {tradeMessage}
          </span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-8 bg-[#080d16] border border-slate-800 rounded-lg overflow-hidden">
          <div className="p-3 border-b border-slate-800 flex justify-between items-center text-xs">
            <span className="font-bold text-slate-200 flex items-center">
              <Activity className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
              LIVE SYNTHETIC INSTRUMENTS
            </span>
            <span className="text-[11px] text-slate-400">All prices in % of par</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#050911] text-slate-400 border-b border-slate-800 text-[10px] uppercase">
                <tr>
                  <th className="py-2.5 px-3">Symbol</th>
                  <th className="py-2.5 px-3">Structure Type</th>
                  <th className="py-2.5 px-3 text-right">Bid</th>
                  <th className="py-2.5 px-3 text-right">Ask</th>
                  <th className="py-2.5 px-3 text-right">Spread</th>
                  <th className="py-2.5 px-3 text-right">YTM</th>
                  <th className="py-2.5 px-3 text-center">Liquidity Score</th>
                  <th className="py-2.5 px-3 text-right">24h Vol</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {instruments.map((inst) => {
                  const isSelected = selectedInst.id === inst.id;
                  return (
                    <tr
                      key={inst.id}
                      onClick={() => setSelectedInst(inst)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-amber-950/30' : 'hover:bg-slate-900/60'
                      }`}
                    >
                      <td className="py-2.5 px-3 font-bold text-slate-100 flex items-center space-x-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-amber-400' : 'bg-transparent'}`} />
                        <span>{inst.symbol}</span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400">
                        <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px]">
                          {inst.type} {inst.trancheSeniority ? `(${inst.trancheSeniority})` : ''}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-emerald-400">
                        {inst.bidPrice.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-rose-400">
                        {inst.askPrice.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-amber-400">
                        +{inst.spreadBps} bps
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-200">
                        {inst.yieldToMaturity}%
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          inst.liquidityScore >= 90 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                          inst.liquidityScore >= 75 ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                          'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {inst.liquidityScore}/100
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-400">
                        £{(inst.dailyVolumeGbp / 1e6).toFixed(1)}m
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-4 bg-[#080d16] border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <span className="text-xs font-bold text-amber-400 flex items-center">
              <Zap className="w-3.5 h-3.5 mr-1" />
              INSTITUTIONAL RFQ ENGINE
            </span>
            <h3 className="text-sm font-bold text-slate-100 mt-1">{selectedInst.symbol}</h3>
            <span className="text-[10px] text-slate-400 font-sans block">{selectedInst.underlyingProduct}</span>
          </div>

          <div className="bg-slate-900/90 p-3 rounded border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Indicative Bid:</span>
              <span className="text-emerald-400 font-bold">{selectedInst.bidPrice.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Indicative Ask:</span>
              <span className="text-rose-400 font-bold">{selectedInst.askPrice.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Model Liquidity Score:</span>
              <span className="text-amber-400 font-bold">{selectedInst.liquidityScore} / 100</span>
            </div>
          </div>

          <form onSubmit={handleExecuteRFQ} className="space-y-3 text-xs">
            <div className="flex space-x-2">
              <button
                type="button"
                onClick={() => setRfqSide('BUY')}
                className={`flex-1 py-1.5 rounded font-bold transition-colors cursor-pointer ${
                  rfqSide === 'BUY'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-900 text-slate-400 border border-slate-800'
                }`}
              >
                BUY / LONG
              </button>
              <button
                type="button"
                onClick={() => setRfqSide('SELL')}
                className={`flex-1 py-1.5 rounded font-bold transition-colors cursor-pointer ${
                  rfqSide === 'SELL'
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-900 text-slate-400 border border-slate-800'
                }`}
              >
                SELL / SHORT
              </button>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 block mb-1">NOTIONAL ORDER SIZE (GBP)</label>
              <input
                type="number"
                step="1000000"
                value={rfqQuantity}
                onChange={(e) => setRfqQuantity(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-bold"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                £{(rfqQuantity / 1e6).toFixed(1)} Million Notional
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center justify-center space-x-1.5 shadow-md transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>SUBMIT INSTITUTIONAL ORDER</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
