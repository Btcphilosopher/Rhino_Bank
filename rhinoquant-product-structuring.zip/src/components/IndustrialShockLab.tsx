import React, { useState } from 'react';
import { 
  Play, 
  RotateCcw, 
  Activity,
  Zap,
  ShieldAlert
} from 'lucide-react';
import { SyntheticProduct } from '../types';
import { SHOCK_SCENARIOS } from '../data/defaultProducts';
import { applyShockScenario } from '../utils/engine';

interface IndustrialShockLabProps {
  currentProduct: SyntheticProduct;
  onApplyShockResult: (updatedProduct: SyntheticProduct) => void;
}

export const IndustrialShockLab: React.FC<IndustrialShockLabProps> = ({
  currentProduct,
  onApplyShockResult,
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(SHOCK_SCENARIOS[0].id);
  const [activeStepIndex, setActiveStepIndex] = useState<number>(3);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [appliedState, setAppliedState] = useState<{
    scenarioName: string;
    totalLossGbp: number;
    portfolioLossPercent: number;
    exposureLosses: { name: string; lossGbp: number; priceChangePercent: number }[];
  } | null>(null);

  const selectedScenario = SHOCK_SCENARIOS.find((s) => s.id === selectedScenarioId) || SHOCK_SCENARIOS[0];

  const handleRunShockSimulation = () => {
    setIsSimulating(true);
    setActiveStepIndex(0);

    let step = 0;
    const interval = setInterval(() => {
      step += 1;
      setActiveStepIndex(step);
      if (step >= selectedScenario.causalChain.length - 1) {
        clearInterval(interval);
        setIsSimulating(false);

        const result = applyShockScenario(currentProduct, selectedScenario);
        setAppliedState({
          scenarioName: selectedScenario.name,
          totalLossGbp: result.totalLossGbp,
          portfolioLossPercent: result.portfolioLossPercent,
          exposureLosses: result.exposureLosses,
        });
        onApplyShockResult(result.updatedProduct);
      }
    }, 450);
  };

  const handleReset = () => {
    setAppliedState(null);
    setActiveStepIndex(selectedScenario.causalChain.length - 1);
  };

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              INDUSTRIAL SHOCK LAB // CASCADING PROPAGATION ENGINE (SECTIONS 22 & 23)
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800">
              NON-LINEAR CAUSAL MATRIX
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Shocks are not independent spreadsheet cells. Causal disruptions propagate through physical mine output, tier-1 subassemblies, factory takt times, and sequential credit waterfalls.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {appliedState && (
            <button
              onClick={handleReset}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-xs flex items-center space-x-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1" />
              CLEAR SHOCK
            </button>
          )}

          <button
            onClick={handleRunShockSimulation}
            disabled={isSimulating}
            className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 disabled:bg-rose-900/50 text-white font-bold rounded flex items-center space-x-1.5 text-xs transition-colors shadow-lg shadow-rose-950/40 cursor-pointer"
          >
            {isSimulating ? (
              <>
                <Activity className="w-3.5 h-3.5 animate-spin" />
                <span>PROPAGATING CHAIN...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>EXECUTE CASCADING SHOCK</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {SHOCK_SCENARIOS.map((scenario) => {
          const isSelected = scenario.id === selectedScenarioId;
          return (
            <div
              key={scenario.id}
              onClick={() => {
                if (!isSimulating) {
                  setSelectedScenarioId(scenario.id);
                  setActiveStepIndex(scenario.causalChain.length - 1);
                }
              }}
              className={`p-2.5 rounded border cursor-pointer transition-all ${
                isSelected
                  ? 'border-amber-500 bg-amber-950/30 text-amber-200 ring-1 ring-amber-500/60'
                  : 'border-slate-800 bg-[#080d16] text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="flex justify-between items-center text-[10px] mb-1">
                <span className="font-bold text-slate-400">{scenario.category}</span>
                <span className={`px-1 rounded text-[9px] font-bold ${
                  scenario.severity === 'EXTREME' ? 'text-red-400 bg-red-950/60' : 'text-amber-400 bg-amber-950/60'
                }`}>
                  {scenario.severity}
                </span>
              </div>
              <h4 className="text-[11px] font-bold text-slate-200 line-clamp-1">{scenario.name}</h4>
            </div>
          );
        })}
      </div>

      <div className="bg-[#080d16] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] text-rose-400 font-bold uppercase tracking-wider">
              ACTIVE STRESS VECTOR // {selectedScenario.category}
            </span>
            <h3 className="text-sm font-bold text-slate-100">{selectedScenario.name}</h3>
            <p className="text-xs text-slate-400 font-sans mt-0.5 max-w-3xl">
              {selectedScenario.description}
            </p>
          </div>

          <div className="flex items-center space-x-3 text-xs">
            <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800 text-right">
              <span className="text-slate-500 text-[10px] block">COMMODITY DELTA</span>
              <span className="text-rose-400 font-bold">
                {Object.values(selectedScenario.commodityPriceShock)[0] || 0}% Spike
              </span>
            </div>
            <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800 text-right">
              <span className="text-slate-500 text-[10px] block">CAPACITY LOSS</span>
              <span className="text-rose-400 font-bold">-{selectedScenario.factoryCapacityLoss}%</span>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <span className="text-xs font-bold text-slate-300 flex items-center">
            <Zap className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
            STEP-BY-STEP CAUSAL PROPAGATION CHAIN (SECTION 23)
          </span>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 relative">
            {selectedScenario.causalChain.map((step, idx) => {
              const isPast = idx <= activeStepIndex;
              const isCurrent = idx === activeStepIndex && isSimulating;

              return (
                <div
                  key={step.stepNumber}
                  className={`p-3 rounded border transition-all duration-300 relative ${
                    isCurrent
                      ? 'border-amber-400 bg-amber-950/40 shadow-lg shadow-amber-950/50 scale-[1.03]'
                      : isPast
                      ? 'border-rose-800/80 bg-rose-950/20 text-slate-200'
                      : 'border-slate-800 bg-slate-950/40 opacity-40'
                  }`}
                >
                  <div className="flex justify-between items-center text-[10px] mb-1.5">
                    <span className="font-bold text-amber-400">STEP {step.stepNumber}</span>
                    <span className="px-1.5 py-0.2 rounded bg-slate-900 text-slate-400 text-[9px]">
                      {step.impactType}
                    </span>
                  </div>

                  <h5 className="text-xs font-bold text-slate-100 mb-1">{step.nodeName}</h5>
                  <p className="text-[11px] text-slate-400 font-sans leading-tight mb-2">
                    {step.description}
                  </p>

                  <div className="pt-2 border-t border-slate-800/80 flex justify-between items-baseline text-[11px]">
                    <span className="text-rose-400 font-bold">
                      {step.deltaPercent > 0 ? `+${step.deltaPercent}%` : `${step.deltaPercent}%`}
                    </span>
                    <span className="text-slate-300 font-mono text-[10px]">
                      Cum: -£{(step.cumulativeLossGbp / 1e6).toFixed(0)}m
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {appliedState && (
          <div className="p-4 rounded-lg bg-red-950/40 border border-red-800 text-xs space-y-3 mt-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-red-900/60 pb-2">
              <span className="font-bold text-red-200 flex items-center">
                <ShieldAlert className="w-4 h-4 mr-1.5 text-red-400" />
                QUANTITATIVE CAPITAL WRITE-DOWN REPORT // {appliedState.scenarioName}
              </span>
              <div className="flex items-center space-x-4">
                <span className="text-red-300">
                  Portfolio Loss: <span className="text-white font-bold">{appliedState.portfolioLossPercent}%</span>
                </span>
                <span className="text-red-300">
                  Total Write-Down: <span className="text-white font-bold">-£{(appliedState.totalLossGbp / 1e6).toFixed(1)}m</span>
                </span>
              </div>
            </div>

            <div className="text-[11px] text-slate-300 font-sans">
              Sequential waterfall execution has allocated losses into the structured capital stack. Check the{' '}
              <span className="text-amber-400 font-mono font-bold">CDO TRANCHING</span> desk to view the exact tranche impairment status.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
