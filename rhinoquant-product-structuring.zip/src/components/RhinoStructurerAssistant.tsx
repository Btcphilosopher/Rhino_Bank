import React, { useState } from 'react';
import { 
  Send
} from 'lucide-react';
import { SyntheticProduct } from '../types';

interface RhinoStructurerAssistantProps {
  currentProduct: SyntheticProduct;
  onNavigateTab: (tabId: string) => void;
}

interface Message {
  id: string;
  sender: 'USER' | 'ASSISTANT';
  text: string;
  structuredData?: {
    title: string;
    breakdown?: { label: string; value: string; percent?: number }[];
    actions?: { label: string; targetTab: string }[];
  };
  timestamp: string;
}

export const RhinoStructurerAssistant: React.FC<RhinoStructurerAssistantProps> = ({
  currentProduct,
  onNavigateTab,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-init',
      sender: 'ASSISTANT',
      text: `RHINO STRUCTURER ONLINE. Connected to Industrial-Financial Compilation Kernel v8.4. Ready to structure new synthetic products, execute reverse look-through decompositions, or audit supply-chain concentrations across the Rhino portfolio.`,
      timestamp: '08:26:00',
    },
  ]);
  const [inputText, setInputText] = useState<string>('');

  const quickPrompts = [
    'What is this product actually exposed to?',
    'Structure this product down into its supply-chain exposures.',
    'What happens to our product economics if copper rises 30%?',
    'Which supplier represents the largest hidden concentration across the portfolio?',
    'Build a synthetic product representing 100,000 electric vehicles manufactured over five years.',
  ];

  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'USER',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');

    setTimeout(() => {
      let assistantMsg: Message;
      const lower = textToSend.toLowerCase();

      if (lower.includes('actually exposed to') || lower.includes('exposure')) {
        assistantMsg = {
          id: `asst-${Date.now()}`,
          sender: 'ASSISTANT',
          text: `Reverse engineering synthesis for ${currentProduct.code} (${currentProduct.name}). The product is represented as an 8-factor vector:`,
          timestamp: new Date().toLocaleTimeString(),
          structuredData: {
            title: 'ECONOMIC EXPOSURE DECOMPOSITION VECTOR',
            breakdown: [
              { label: 'Raw Materials (Base & Battery Metals)', value: '£1.71B', percent: 38 },
              { label: 'Components & Tier-1 Subassemblies', value: '£1.08B', percent: 24 },
              { label: 'Manufacturing Assembly Hours', value: '£630M', percent: 14 },
              { label: 'Multimodal Shipping & Freight', value: '£315M', percent: 7 },
              { label: 'Labour & Engineering Tooling', value: '£270M', percent: 6 },
              { label: 'Grid Power & Smelter Energy', value: '£225M', percent: 5 },
              { label: 'Capital Assets & Tooling Depreciation', value: '£180M', percent: 4 },
              { label: 'Working Capital Carry & Financing', value: '£90M', percent: 2 },
            ],
            actions: [
              { label: 'VIEW BILL OF ECONOMIC MATERIALS (BEM)', targetTab: 'reverse_desk' },
              { label: 'INSPECT TOPOLOGICAL GRAPH', targetTab: 'industrial_graph' },
            ],
          },
        };
      } else if (lower.includes('structure this product down') || lower.includes('structure down')) {
        assistantMsg = {
          id: `asst-${Date.now()}`,
          sender: 'ASSISTANT',
          text: `Executing forward-to-reverse compilation: Decomposing ${currentProduct.name} down into its reference pool, correlation matrix, and capital stack:`,
          timestamp: new Date().toLocaleTimeString(),
          structuredData: {
            title: 'STRUCTURE DOWN: SYNTHETIC PRODUCT → SC-CDO',
            breakdown: [
              { label: 'Physical Pool', value: '18,000t Al, 4,500t Cu, 100k Cells, 14k Chip Lots' },
              { label: 'Reference Pool', value: '11 Arbitrarily Weighted Industrial References' },
              { label: 'Loss Distribution', value: 'Student-t Copula (df=4.8, Fat-tail dependence 0.28)' },
              { label: 'Equity Tranche (0-5%)', value: '£225M Notional | Spread +1,350 bps | NR' },
              { label: 'Mezzanine Tranche (10-18%)', value: '£360M Notional | Spread +420 bps | BBB' },
              { label: 'Senior Tranche (18-35%)', value: '£765M Notional | Spread +185 bps | AA-' },
              { label: 'Super-Senior (35-100%)', value: '£2.925B Notional | Spread +65 bps | AAA' },
            ],
            actions: [
              { label: 'OPEN CDO TRANCHING ENGINE', targetTab: 'cdo_packaging' },
              { label: 'RUN LOSS WATERFALL SIMULATION', targetTab: 'shock_lab' },
            ],
          },
        };
      } else if (lower.includes('copper rises 30%') || lower.includes('copper')) {
        assistantMsg = {
          id: `asst-${Date.now()}`,
          sender: 'ASSISTANT',
          text: `Simulating +30% Copper shock on ${currentProduct.code}. A +30% surge in LME Grade A Copper elevates raw wire drawing and busbar procurement cost by +£108,000,000 across the 100,000 vehicle programme. This reduces vehicle gross margin by 2.4% and exhausts 48% of the Equity first-loss tranche subordination buffer.`,
          timestamp: new Date().toLocaleTimeString(),
          structuredData: {
            title: 'COPPER SHOCK IMPACT ASSESSMENT',
            breakdown: [
              { label: 'Unit Production Cost Increase', value: '+£1,080 / vehicle' },
              { label: 'Gross Dollar Loss to Portfolio', value: '-£108.0m GBP' },
              { label: 'Mark-to-Market Portfolio Delta', value: '-2.40%' },
              { label: 'Equity Tranche Impairment', value: '48.0% of Notional Written Down' },
              { label: 'Mezzanine Tranche Status', value: 'UNTOUCHED (Attachment 10% protected)' },
            ],
            actions: [
              { label: 'EXECUTE IN SHOCK LAB', targetTab: 'shock_lab' },
              { label: 'INSPECT DELTA SENSITIVITY (ΔCopper)', targetTab: 'risk_greeks' },
            ],
          },
        };
      } else if (lower.includes('hidden concentration') || lower.includes('largest hidden')) {
        assistantMsg = {
          id: `asst-${Date.now()}`,
          sender: 'ASSISTANT',
          text: `Cross-portfolio graph traversal complete. The largest hidden systemic concentration across the Rhino balance sheet is: TSMC Fab 14 (Hsinchu) / 28nm Microcontroller Foundry Allocation.`,
          timestamp: new Date().toLocaleTimeString(),
          structuredData: {
            title: 'SYSTEMIC BOTTLENECK AUDIT',
            breakdown: [
              { label: 'Constrained Resource', value: 'Automotive 28nm MCUs & SiC Wafers' },
              { label: 'Single Point of Failure', value: 'TSMC Fab 14 & Infineon Cleanrooms' },
              { label: 'Exposed Platforms', value: 'EV-01 (87% cap), AERION-02 (78% cap), H2-03 (82% cap)' },
              { label: 'Total Value at Risk (VaR)', value: '£405M direct, £1.2B downstream delays' },
            ],
            actions: [
              { label: 'INSPECT BOTTLENECK ENGINE', targetTab: 'reverse_desk' },
              { label: 'VIEW SYSTEMIC CONCENTRATION GRAPH', targetTab: 'industrial_graph' },
            ],
          },
        };
      } else {
        assistantMsg = {
          id: `asst-${Date.now()}`,
          sender: 'ASSISTANT',
          text: `Programme synthesis compiled. Assembled Bill of Materials (BOM), 11-node industrial reference portfolio, and 5-tier senior-subordinated tranche structure for 100,000 modular vehicles over 5 years. Total issuance notional: £4.50 Billion.`,
          timestamp: new Date().toLocaleTimeString(),
          structuredData: {
            title: 'SYNTHETIC VEHICLE PROGRAMME SPECIFICATION',
            breakdown: [
              { label: 'Programme Output', value: '100,000 units over 60 months' },
              { label: 'Total Collateral Pool', value: '£4,500,000,000 GBP' },
              { label: 'Key Bottleneck', value: '28nm Semiconductors (TSMC 87% quota)' },
              { label: 'Benchmark Spread', value: 'SONIA + 285 bps blended' },
            ],
            actions: [
              { label: 'FORWARD STRUCTURING DESK', targetTab: 'forward_desk' },
              { label: 'GENERATE INSTITUTIONAL TERM SHEET', targetTab: 'cdo_packaging' },
            ],
          },
        };
      }

      setMessages((prev) => [...prev, assistantMsg]);
    }, 400);
  };

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              RHINO STRUCTURER // AI INSTITUTIONAL ASSISTANT (SECTIONS 50 & 51)
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800">
              NATURAL LANGUAGE COMPILER
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Natural language structuring terminal capable of forward synthesis, reverse engineering, and systemic network risk diagnosis.
          </p>
        </div>
      </div>

      <div className="space-y-1.5">
        <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
          INSTITUTIONAL QUERY TEMPLATES:
        </span>
        <div className="flex flex-wrap gap-2">
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p)}
              className="px-2.5 py-1.5 bg-[#080d16] hover:bg-slate-800 text-slate-300 hover:text-amber-300 border border-slate-800 rounded text-xs transition-colors text-left cursor-pointer"
            >
              "{p}"
            </button>
          ))}
        </div>
      </div>

      <div className="bg-[#070b12] border border-slate-800 rounded-lg p-4 space-y-4 min-h-[380px] max-h-[500px] overflow-y-auto">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.sender === 'USER' ? 'items-end' : 'items-start'
            }`}
          >
            <div className="flex items-center space-x-2 text-[10px] text-slate-500 mb-1">
              <span className="font-bold text-slate-400">
                {msg.sender === 'USER' ? 'QUANT STRUCTURER' : 'RHINO STRUCTURER // KERNEL'}
              </span>
              <span>{msg.timestamp}</span>
            </div>

            <div
              className={`max-w-2xl p-3.5 rounded-lg text-xs font-sans leading-relaxed ${
                msg.sender === 'USER'
                  ? 'bg-amber-950/40 text-amber-100 border border-amber-800/80 font-mono'
                  : 'bg-slate-900/90 text-slate-200 border border-slate-800'
              }`}
            >
              <p>{msg.text}</p>

              {msg.structuredData && (
                <div className="mt-3 pt-3 border-t border-slate-800 font-mono text-xs space-y-2.5">
                  <span className="font-bold text-amber-400 block text-[11px] uppercase">
                    {msg.structuredData.title}
                  </span>

                  {msg.structuredData.breakdown && (
                    <div className="space-y-1.5 bg-slate-950/70 p-2.5 rounded border border-slate-800/80 text-[11px]">
                      {msg.structuredData.breakdown.map((item, idx) => (
                        <div key={idx} className="flex justify-between items-center">
                          <span className="text-slate-400">{item.label}:</span>
                          <span className="text-slate-100 font-bold">
                            {item.value} {item.percent !== undefined ? `(${item.percent}%)` : ''}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {msg.structuredData.actions && (
                    <div className="flex flex-wrap gap-2 pt-1">
                      {msg.structuredData.actions.map((act, idx) => (
                        <button
                          key={idx}
                          onClick={() => onNavigateTab(act.targetTab)}
                          className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-[10px] flex items-center space-x-1 cursor-pointer"
                        >
                          <span>{act.label}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(inputText);
        }}
        className="flex space-x-2"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Ask Rhino Structurer (e.g. 'What is this product actually exposed to?')"
          className="flex-1 bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs flex items-center space-x-1.5 shadow-md cursor-pointer"
        >
          <Send className="w-3.5 h-3.5" />
          <span>QUERY KERNEL</span>
        </button>
      </form>
    </div>
  );
};
