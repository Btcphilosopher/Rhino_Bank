import React, { useState } from 'react';
import { 
  ArrowDown, 
  ArrowUp, 
  Layers, 
  ShieldCheck, 
  Cpu, 
  Factory, 
  Boxes, 
  RotateCw, 
  Sparkles,
  Maximize2,
  ExternalLink,
  Info
} from 'lucide-react';
import { SyntheticProduct } from '../types';

interface FlagshipVisualLoopProps {
  currentProduct: SyntheticProduct;
  onNavigateTab: (tabId: string) => void;
  onTriggerStructureDown: () => void;
  onTriggerStructureUp: () => void;
}

export const FlagshipVisualLoop: React.FC<FlagshipVisualLoopProps> = ({
  currentProduct,
  onNavigateTab,
  onTriggerStructureDown,
  onTriggerStructureUp,
}) => {
  const [selectedNodeIndex, setSelectedNodeIndex] = useState<number>(4);
  const [flowDirection, setFlowDirection] = useState<'FORWARD' | 'REVERSE'>('FORWARD');

  const loopNodes = [
    {
      id: 'materials',
      name: 'RAW MATERIALS',
      subtitle: 'Al, Cu, Li, Ni, Steel, PGM, Polymers',
      role: 'Layer 1 Physical Commodity Pool',
      icon: Boxes,
      metric: `£${(currentProduct.exposures.filter(e => e.category === 'COMMODITY').reduce((a, b) => a + b.notionalValue, 0) / 1e6).toFixed(0)}m Commodity Notional`,
      targetTab: 'forward_desk',
      color: 'border-cyan-700/80 text-cyan-300 bg-cyan-950/30',
      description: 'Physical or synthetic raw commodities extracted and processed as foundational baseline for component fabrication.',
    },
    {
      id: 'components',
      name: 'COMPONENTS',
      subtitle: 'Motors, Batteries, MCUs, Inverters, Skirts',
      role: 'Layer 1 Subassemblies & Bill of Materials',
      icon: Cpu,
      metric: `£${(currentProduct.exposures.filter(e => e.category === 'COMPONENT').reduce((a, b) => a + b.notionalValue, 0) / 1e6).toFixed(0)}m Subassemblies`,
      targetTab: 'reverse_desk',
      color: 'border-blue-700/80 text-blue-300 bg-blue-950/30',
      description: 'Manufactured tier-1 modules and assemblies subject to supplier qualification, lead times, and capacity constraints.',
    },
    {
      id: 'manufacturing',
      name: 'MANUFACTURING',
      subtitle: 'Solihull Assembly, Drydocks, Cleanrooms',
      role: 'Industrial Digital Twin & Factory Capacity',
      icon: Factory,
      metric: `£${(currentProduct.exposures.filter(e => e.category === 'PRODUCTION').reduce((a, b) => a + b.notionalValue, 0) / 1e6).toFixed(0)}m Production Hours`,
      targetTab: 'forward_desk',
      color: 'border-emerald-700/80 text-emerald-300 bg-emerald-950/30',
      description: 'Factory floor throughput, tooling amortization, labour shifts, and takt time economics.',
    },
    {
      id: 'supply_chain',
      name: 'SUPPLY CHAIN & LOGISTICS',
      subtitle: 'Multimodal TEU, Railheads, Warehousing',
      role: 'Logistics Contracts & Shipping Routes',
      icon: RotateCw,
      metric: `£${(currentProduct.exposures.filter(e => e.category === 'LOGISTICS').reduce((a, b) => a + b.notionalValue, 0) / 1e6).toFixed(0)}m Freight Notional`,
      targetTab: 'industrial_graph',
      color: 'border-indigo-700/80 text-indigo-300 bg-indigo-950/30',
      description: 'Maritime shipping corridors, port container dwell times, rail freight connections, and buffer inventory.',
    },
    {
      id: 'synthetic_product',
      name: 'SYNTHETIC PRODUCT',
      subtitle: currentProduct.name,
      role: 'Rhino Product Industrial Digital Twin',
      icon: Sparkles,
      metric: `£${(currentProduct.totalNotionalGbp / 1e9).toFixed(2)}B Programme Notional`,
      targetTab: 'reverse_desk',
      color: 'border-amber-500 text-amber-300 bg-amber-950/40 ring-1 ring-amber-500/50',
      description: 'The aggregated synthetic asset representing finished units as a structured economic commitment.',
    },
    {
      id: 'structured_exposure',
      name: 'STRUCTURED EXPOSURE',
      subtitle: `Reference Code: ${currentProduct.code}`,
      role: 'Layer 2 & 3 Economic Exposure Matrix',
      icon: Layers,
      metric: `${currentProduct.exposures.length} Industrial References`,
      targetTab: 'forward_desk',
      color: 'border-purple-700/80 text-purple-300 bg-purple-950/30',
      description: 'Transformation of physical purchase orders and commodity curves into quantified financial risk vectors.',
    },
    {
      id: 'tranche',
      name: 'CDO TRANCHING ENGINE',
      subtitle: 'Equity 0-5% → Super-Senior 35-100%',
      role: 'Layer 4 Loss Waterfall & Seniority',
      icon: ShieldCheck,
      metric: `${currentProduct.tranches.length} Tranche Layers (AAA to NR)`,
      targetTab: 'cdo_packaging',
      color: 'border-rose-700/80 text-rose-300 bg-rose-950/30',
      description: 'Subordination stack allocating industrial supply-chain losses sequentially from first-loss equity to rated debt.',
    },
    {
      id: 'rhino_product',
      name: 'RHINO PRODUCT (FINANCIAL ASSET)',
      subtitle: 'Tradable SC-CDO & Synthetic Notes',
      role: 'Layer 5 Tradable Institutional Securities',
      icon: Maximize2,
      metric: 'Secondary Market Active',
      targetTab: 'secondary_market',
      color: 'border-emerald-500 text-emerald-300 bg-emerald-950/40',
      description: 'Liquid market execution layer allowing quants and institutions to trade credit protection on industrial production.',
    },
    {
      id: 'reverse_lookthrough',
      name: 'REVERSE LOOK-THROUGH',
      subtitle: 'Decomposition into 8-Vector & BEM',
      role: 'Bidirectional Compiler Look-Through',
      icon: RotateCw,
      metric: `${currentProduct.bem.length} BEM Line Items`,
      targetTab: 'reverse_desk',
      color: 'border-amber-600 text-amber-300 bg-amber-950/30',
      description: 'Instant look-through traversal unpacking the financial product back into its tier-1/tier-2 suppliers and mine sites.',
    },
  ];

  const activeNode = loopNodes[selectedNodeIndex];

  return (
    <div className="space-y-4">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100 font-mono">
              THE RHINO PRODUCT STRUCTURING LOOP
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono">
              SECTION 3 & 58 ARCHITECTURE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            Bidirectional financial-industrial translation: Drag or click any node to traverse between physical extraction and synthetic CDO tranches.
          </p>
        </div>

        <div className="flex items-center space-x-2 font-mono text-xs">
          <button
            onClick={() => {
              setFlowDirection('FORWARD');
              onTriggerStructureDown();
            }}
            className={`px-3 py-2 rounded flex items-center space-x-1.5 transition-colors border ${
              flowDirection === 'FORWARD'
                ? 'bg-emerald-900/80 text-emerald-200 border-emerald-600'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
            <span>FORWARD (STRUCTURE DOWN)</span>
          </button>

          <button
            onClick={() => {
              setFlowDirection('REVERSE');
              onTriggerStructureUp();
            }}
            className={`px-3 py-2 rounded flex items-center space-x-1.5 transition-colors border ${
              flowDirection === 'REVERSE'
                ? 'bg-amber-900/80 text-amber-200 border-amber-600'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <ArrowUp className="w-3.5 h-3.5 text-amber-400" />
            <span>REVERSE (STRUCTURE UP)</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-8 bg-[#080d16] border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800/80 pb-2">
            <span className="text-xs font-mono font-semibold text-slate-300 flex items-center">
              <RotateCw className="w-3.5 h-3.5 text-amber-400 mr-2" />
              SYNTHETIC INDUSTRIAL GRAPH TRAVERSAL
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              Active Direction: <span className={flowDirection === 'FORWARD' ? 'text-emerald-400' : 'text-amber-400'}>{flowDirection}</span>
            </span>
          </div>

          <div className="flex flex-col items-center space-y-2 relative">
            {loopNodes.map((node, idx) => {
              const Icon = node.icon;
              const isSelected = selectedNodeIndex === idx;

              return (
                <React.Fragment key={node.id}>
                  <div
                    onClick={() => setSelectedNodeIndex(idx)}
                    className={`w-full max-w-xl p-3 rounded-md border cursor-pointer transition-all duration-150 flex items-center justify-between group ${
                      isSelected
                        ? `${node.color} shadow-lg shadow-black/60 scale-[1.02]`
                        : 'border-slate-800/90 bg-[#0d131f] hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-8 h-8 rounded flex items-center justify-center border ${
                          isSelected ? 'bg-slate-900/90 border-current' : 'bg-slate-800 border-slate-700 text-slate-400'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-bold font-mono tracking-wide">{node.name}</span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-900/80 border border-slate-800 text-slate-400 font-mono">
                            STEP {idx + 1}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono">{node.subtitle}</p>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xs font-mono font-semibold text-slate-200">{node.metric}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{node.role}</div>
                    </div>
                  </div>

                  {idx < loopNodes.length - 1 && (
                    <div className="flex items-center justify-center my-0.5">
                      {flowDirection === 'FORWARD' ? (
                        <ArrowDown className="w-4 h-4 text-emerald-500/70 animate-bounce" />
                      ) : (
                        <ArrowUp className="w-4 h-4 text-amber-500/70 animate-bounce" />
                      )}
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-4 space-y-4">
          <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-mono font-bold text-amber-400 flex items-center">
                <Info className="w-3.5 h-3.5 mr-1.5" />
                LAYER INSPECTOR // NODE {selectedNodeIndex + 1}
              </span>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                {activeNode.id.toUpperCase()}
              </span>
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-100 font-mono">{activeNode.name}</h3>
              <p className="text-xs text-amber-300/90 font-mono mt-0.5">{activeNode.role}</p>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed font-sans">
                {activeNode.description}
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-3 rounded text-xs font-mono space-y-2">
              <div className="flex justify-between text-slate-400">
                <span>Active Metric:</span>
                <span className="text-emerald-400 font-bold">{activeNode.metric}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Target Product:</span>
                <span className="text-slate-200">{currentProduct.code}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Compiler Status:</span>
                <span className="text-amber-400">SYNCHRONIZED (0.0ms LAG)</span>
              </div>
            </div>

            <button
              onClick={() => onNavigateTab(activeNode.targetTab)}
              className="w-full py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-mono text-xs font-bold rounded flex items-center justify-center space-x-1.5 transition-colors shadow-md cursor-pointer"
            >
              <span>OPEN DEDICATED DESK: {activeNode.name}</span>
              <ExternalLink className="w-3.5 h-3.5 ml-1" />
            </button>
          </div>

          <div className="bg-[#090e18] border border-slate-800/90 rounded-lg p-4 text-xs font-mono space-y-3">
            <h4 className="text-slate-200 font-bold flex items-center text-[11px] uppercase tracking-wider">
              <RotateCw className="w-3.5 h-3.5 mr-1.5 text-cyan-400" />
              BIDIRECTIONAL COMPILER PARADIGM
            </h4>
            <div className="space-y-2 text-[11px] text-slate-400">
              <div className="p-2 bg-slate-900/60 rounded border border-slate-800">
                <span className="text-emerald-400 font-semibold">FORWARD (STRUCTURE DOWN):</span>
                <p className="mt-0.5 text-slate-300">
                  Takes physical supply contracts, mines, and factories, projects them into a reference portfolio, and tranches them into an SC-CDO.
                </p>
              </div>

              <div className="p-2 bg-slate-900/60 rounded border border-slate-800">
                <span className="text-amber-400 font-semibold">REVERSE (STRUCTURE UP):</span>
                <p className="mt-0.5 text-slate-300">
                  Takes synthetic product or tranche exposure and reverse-compiles down to required tonnes of copper, semiconductor lots, and assembly hours.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
