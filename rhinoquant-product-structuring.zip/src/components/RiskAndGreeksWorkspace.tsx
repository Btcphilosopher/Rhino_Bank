import React, { useState } from 'react';
import { 
  Activity, 
  ArrowDownRight,
  ArrowUpRight,
  HelpCircle,
  ShieldAlert
} from 'lucide-react';
import { SyntheticProduct, Greeks, ReversePnLBreakdown } from '../types';
import { 
  calculateIndustrialGreeks, 
  calculateReversePnL, 
  calculateSupplyChainVaR 
} from '../utils/engine';

interface RiskAndGreeksWorkspaceProps {
  currentProduct: SyntheticProduct;
}

export const RiskAndGreeksWorkspace: React.FC<RiskAndGreeksWorkspaceProps> = ({
  currentProduct,
}) => {
  const [customPnLMove, setCustomPnLMove] = useState<number>(8200000);

  const greeks: Greeks = calculateIndustrialGreeks(currentProduct);
  const reversePnL: ReversePnLBreakdown = calculateReversePnL(currentProduct, customPnLMove);
  const varMetrics = calculateSupplyChainVaR(currentProduct);

  return (
    <div className="space-y-4 font-mono">
      <div className="bg-[#0b101b] border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              INDUSTRIAL GREEKS, SUPPLY-CHAIN VAR & REVERSE P&L (SECTIONS 35, 36, 37 & 38)
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800">
              RISK DESK
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Delta sensitivities to physical commodity spot prices, factory uptime, and freight, paired with reverse causal P&L decomposition.
          </p>
        </div>

        <div className="text-right text-xs">
          <span className="text-slate-400">10-Day 99% VaR: </span>
          <span className="text-rose-400 font-bold">£{(varMetrics.var99_10Day / 1e6).toFixed(1)}m</span>
        </div>
      </div>

      <div className="bg-[#080d16] border border-slate-800 rounded-lg p-5 space-y-3">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <span className="text-xs font-bold text-amber-400 flex items-center">
            <Activity className="w-3.5 h-3.5 mr-1.5" />
            INDUSTRIAL DELTA SENSITIVITIES (SECTION 35)
          </span>
          <span className="text-[10px] text-slate-400">
            Impact on Portfolio Notional per +1% Underlying Movement
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          {[
            { greek: 'ΔCopper', val: greeks.deltaCopper, factor: '+1% LME Copper move', color: 'text-amber-400' },
            { greek: 'ΔAluminium', val: greeks.deltaAluminium, factor: '+1% LME Aluminium move', color: 'text-cyan-400' },
            { greek: 'ΔLithium', val: greeks.deltaLithium, factor: '+1% Fastmarkets LiOH', color: 'text-blue-400' },
            { greek: 'ΔSteel', val: greeks.deltaSteel, factor: '+1% European HRC index', color: 'text-slate-300' },
            { greek: 'ΔEnergy', val: greeks.deltaEnergy, factor: '+1% UK Power N2EX', color: 'text-emerald-400' },
            { greek: 'ΔShipping', val: greeks.deltaShipping, factor: '+1% Container freight TEU', color: 'text-indigo-400' },
            { greek: 'ΔSupplier Cap', val: greeks.deltaSupplierCapacity, factor: '+1% Tier-1 allocation', color: 'text-rose-400' },
            { greek: 'ΔFactory Hours', val: greeks.deltaFactoryHours, factor: '+1% Solihull shift hour', color: 'text-emerald-300' },
            { greek: 'ΔDemand', val: greeks.deltaDemand, factor: '+1% OEM off-take order', color: 'text-amber-300' },
            { greek: 'ΔFX (GBP/USD)', val: greeks.deltaFxGbpUsd, factor: '+1% Sterling appreciation', color: 'text-cyan-300' },
            { greek: 'ΔRates (SONIA)', val: greeks.deltaRatesBps, factor: '+1 bp discount rate move', color: 'text-purple-400' },
          ].map((item) => (
            <div key={item.greek} className="p-3 rounded bg-slate-900/80 border border-slate-800 space-y-1">
              <span className={`text-xs font-bold ${item.color}`}>{item.greek}</span>
              <div className="text-sm font-bold text-slate-100">
                £{(item.val / 1e3).toFixed(0)}k
              </div>
              <p className="text-[10px] text-slate-400 font-sans">{item.factor}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7 bg-[#080d16] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
            <div>
              <span className="text-xs font-bold text-amber-400 flex items-center">
                <HelpCircle className="w-3.5 h-3.5 mr-1.5" />
                REVERSE P&L ATTRIBUTION ENGINE (SECTION 37)
              </span>
              <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                "Product value changed — <span className="text-amber-400 font-bold">WHY?</span>" Root-cause traversal into the physical network.
              </p>
            </div>

            <div className="flex items-center space-x-1.5 text-xs">
              <button
                onClick={() => setCustomPnLMove(8200000)}
                className="px-2 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[10px] cursor-pointer"
              >
                +£8.2m GAIN
              </button>
              <button
                onClick={() => setCustomPnLMove(-14500000)}
                className="px-2 py-1 bg-rose-950 text-rose-300 border border-rose-800 rounded text-[10px] cursor-pointer"
              >
                -£14.5m LOSS
              </button>
            </div>
          </div>

          <div className="bg-slate-900/90 p-3 rounded border border-slate-800 flex justify-between items-center">
            <div>
              <span className="text-[10px] text-slate-400 block">TOTAL PERIODIC PRODUCT VALUE MOVEMENT</span>
              <span className={`text-base font-bold ${reversePnL.totalPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {reversePnL.totalPnL >= 0 ? `+£${(reversePnL.totalPnL / 1e6).toFixed(1)}m` : `-£${(Math.abs(reversePnL.totalPnL) / 1e6).toFixed(1)}m`}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono">100% EXPLAINED BY FACTOR CASCADE</span>
          </div>

          <div className="space-y-2">
            {reversePnL.drivers.map((driver) => {
              const isPositive = driver.amountGbp >= 0;
              return (
                <div
                  key={driver.name}
                  className="p-2.5 rounded bg-slate-950/80 border border-slate-800/90 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-2.5">
                    {isPositive ? (
                      <ArrowUpRight className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4 text-rose-400" />
                    )}
                    <div>
                      <span className="text-xs font-bold text-slate-200">{driver.name}</span>
                      <span className="block text-[10px] text-slate-500">{driver.category} FACTOR</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className={`text-xs font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {isPositive ? `+£${(driver.amountGbp / 1e6).toFixed(2)}m` : `-£${(Math.abs(driver.amountGbp) / 1e6).toFixed(2)}m`}
                    </span>
                    <span className="block text-[10px] text-slate-400 font-mono">{driver.percentage}% share</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-5 bg-[#080d16] border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <span className="text-xs font-bold text-amber-400 flex items-center">
              <ShieldAlert className="w-3.5 h-3.5 mr-1.5" />
              SUPPLY-CHAIN VaR & EXPECTED SHORTFALL (SECTION 38)
            </span>
            <p className="text-[11px] text-slate-400 font-sans mt-0.5">
              Fat-tailed loss distributions calibrated to multi-year industrial commodity volatility.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">10-DAY 95% VaR</span>
              <span className="text-sm font-bold text-amber-400">
                £{(varMetrics.var95_10Day / 1e6).toFixed(1)}m
              </span>
            </div>

            <div className="p-3 rounded bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">10-DAY 99% VaR</span>
              <span className="text-sm font-bold text-rose-400">
                £{(varMetrics.var99_10Day / 1e6).toFixed(1)}m
              </span>
            </div>

            <div className="p-3 rounded bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">EXPECTED SHORTFALL (CVaR)</span>
              <span className="text-sm font-bold text-rose-300">
                £{(varMetrics.expectedShortfall99 / 1e6).toFixed(1)}m
              </span>
            </div>

            <div className="p-3 rounded bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">HISTORICAL STRESS VaR</span>
              <span className="text-sm font-bold text-red-400">
                £{(varMetrics.stressVaR / 1e6).toFixed(1)}m
              </span>
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-800">
            <span className="text-[11px] font-bold text-slate-300 block">
              Risk Contribution by Industrial Tier:
            </span>
            {varMetrics.breakdownByCategory.map((cat) => (
              <div key={cat.category} className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">{cat.category}</span>
                  <span className="text-slate-200 font-bold">£{(cat.riskGbp / 1e6).toFixed(1)}m ({cat.percent}%)</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded overflow-hidden">
                  <div style={{ width: `${cat.percent}%` }} className="bg-amber-500 h-full" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
