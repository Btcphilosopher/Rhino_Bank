import React, { useState } from 'react';
import { Header } from './components/Header';
import { FlagshipVisualLoop } from './components/FlagshipVisualLoop';
import { ForwardStructuringDesk } from './components/ForwardStructuringDesk';
import { ReverseStructuringDesk } from './components/ReverseStructuringDesk';
import { CdoPackagingDesk } from './components/CdoPackagingDesk';
import { IndustrialFinancialGraph } from './components/IndustrialFinancialGraph';
import { IndustrialShockLab } from './components/IndustrialShockLab';
import { RiskAndGreeksWorkspace } from './components/RiskAndGreeksWorkspace';
import { CopulaGovernanceDesk } from './components/CopulaGovernanceDesk';
import { StructuringOptimiser } from './components/StructuringOptimiser';
import { SecondaryMarketDesk } from './components/SecondaryMarketDesk';
import { RhinoStructurerAssistant } from './components/RhinoStructurerAssistant';
import { DocumentTermSheetModal } from './components/DocumentTermSheetModal';
import { DEFAULT_PRODUCTS } from './data/defaultProducts';
import { SyntheticProduct, EconomicExposure, Tranche } from './types';

export default function App() {
  const [allProducts, setAllProducts] = useState<SyntheticProduct[]>(DEFAULT_PRODUCTS);
  const [currentProduct, setCurrentProduct] = useState<SyntheticProduct>(DEFAULT_PRODUCTS[0]);
  const [activeMode, setActiveMode] = useState<'FORWARD' | 'REVERSE'>('FORWARD');
  const [activeTab, setActiveTab] = useState<string>('flagship_loop');
  const [isDocModalOpen, setIsDocModalOpen] = useState<boolean>(false);

  // Handlers for state updates
  const handleUpdateExposures = (newExposures: EconomicExposure[]) => {
    const updated: SyntheticProduct = {
      ...currentProduct,
      exposures: newExposures,
    };
    setCurrentProduct(updated);
    setAllProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const handleUpdateTranches = (newTranches: Tranche[]) => {
    const updated: SyntheticProduct = {
      ...currentProduct,
      tranches: newTranches,
    };
    setCurrentProduct(updated);
    setAllProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const handleApplyShockResult = (updatedProduct: SyntheticProduct) => {
    setCurrentProduct(updatedProduct);
    setAllProducts((prev) => prev.map((p) => (p.id === updatedProduct.id ? updatedProduct : p)));
  };

  const handleSelectProduct = (product: SyntheticProduct) => {
    setCurrentProduct(product);
  };

  const handleToggleMode = (mode: 'FORWARD' | 'REVERSE') => {
    setActiveMode(mode);
    if (mode === 'FORWARD') {
      setActiveTab('forward_desk');
    } else {
      setActiveTab('reverse_desk');
    }
  };

  const handleStructureDown = () => {
    setActiveMode('FORWARD');
    setActiveTab('cdo_packaging');
  };

  const handleStructureUp = () => {
    setActiveMode('REVERSE');
    setActiveTab('reverse_desk');
  };

  return (
    <div className="min-h-screen bg-[#070b13] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">
      {/* Institutional Terminal Header */}
      <Header
        currentProduct={currentProduct}
        onSelectProduct={handleSelectProduct}
        allProducts={allProducts}
        activeMode={activeMode}
        onToggleMode={handleToggleMode}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenDocModal={() => setIsDocModalOpen(true)}
      />

      {/* Main Workspace Area */}
      <main className="flex-1 p-4 max-w-[1700px] w-full mx-auto space-y-4">
        {activeTab === 'flagship_loop' && (
          <FlagshipVisualLoop
            currentProduct={currentProduct}
            onNavigateTab={setActiveTab}
            onTriggerStructureDown={handleStructureDown}
            onTriggerStructureUp={handleStructureUp}
          />
        )}

        {activeTab === 'forward_desk' && (
          <ForwardStructuringDesk
            currentProduct={currentProduct}
            onUpdateExposures={handleUpdateExposures}
            onNavigateToTranches={() => setActiveTab('cdo_packaging')}
          />
        )}

        {activeTab === 'reverse_desk' && (
          <ReverseStructuringDesk
            currentProduct={currentProduct}
          />
        )}

        {activeTab === 'cdo_packaging' && (
          <CdoPackagingDesk
            currentProduct={currentProduct}
            onUpdateTranches={handleUpdateTranches}
          />
        )}

        {activeTab === 'industrial_graph' && (
          <IndustrialFinancialGraph
            currentProduct={currentProduct}
            allProducts={allProducts}
          />
        )}

        {activeTab === 'shock_lab' && (
          <IndustrialShockLab
            currentProduct={currentProduct}
            onApplyShockResult={handleApplyShockResult}
          />
        )}

        {activeTab === 'risk_greeks' && (
          <RiskAndGreeksWorkspace
            currentProduct={currentProduct}
          />
        )}

        {activeTab === 'copula_governance' && (
          <CopulaGovernanceDesk
            currentProduct={currentProduct}
          />
        )}

        {activeTab === 'optimiser' && (
          <StructuringOptimiser
            currentProduct={currentProduct}
            onApplyOptimizedWeights={handleUpdateExposures}
          />
        )}

        {activeTab === 'secondary_market' && (
          <SecondaryMarketDesk />
        )}

        {activeTab === 'ai_assistant' && (
          <RhinoStructurerAssistant
            currentProduct={currentProduct}
            onNavigateTab={setActiveTab}
          />
        )}
      </main>

      {/* Institutional Document Modal */}
      <DocumentTermSheetModal
        product={currentProduct}
        isOpen={isDocModalOpen}
        onClose={() => setIsDocModalOpen(false)}
      />

      {/* Footer System Status */}
      <footer className="border-t border-slate-900 bg-[#05080e] px-4 py-2 text-xs font-mono text-slate-500 flex flex-wrap justify-between items-center gap-2">
        <div className="flex items-center space-x-3">
          <span className="text-amber-500 font-bold">RHINOQUANT PRODUCT STRUCTURING</span>
          <span>•</span>
          <span>A PRODUCT CAN BE REPRESENTED AS A STRUCTURED ECONOMIC EXPOSURE TO ITS SUPPLY CHAIN</span>
        </div>
        <div className="flex items-center space-x-3 text-slate-400">
          <span>PORT 3000 DEV ACTIVE</span>
          <span>•</span>
          <span className="text-emerald-400">RUST/R/PYTHON KERNEL SYNCHRONIZED</span>
        </div>
      </footer>
    </div>
  );
}
