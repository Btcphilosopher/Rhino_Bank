export type ExposureCategory = 
  | 'COMMODITY' 
  | 'COMPONENT' 
  | 'PRODUCTION' 
  | 'LOGISTICS' 
  | 'COMMERCIAL';

export interface EconomicExposure {
  id: string;
  name: string;
  category: ExposureCategory;
  subcategory: string;
  weight: number; // percentage
  notionalValue: number; // GBP
  baseUnit: string;
  quantityRequired: number;
  currentPrice: number;
  currency: string;
  priceVolatility: number;
  betaToGlobalIndustrial: number;
  supplierName: string;
  supplierRating: string;
  factoryLocation: string;
  leadTimeDays: number;
  primaryRiskFactor: string;
  correlationGroup: string;
  currentMtmDelta: number;
}

export type TrancheSeniority = 
  | 'EQUITY' 
  | 'JUNIOR' 
  | 'MEZZANINE' 
  | 'SENIOR' 
  | 'SUPER_SENIOR';

export interface Tranche {
  id: string;
  name: string;
  seniority: TrancheSeniority;
  attachmentPoint: number;
  detachmentPoint: number;
  width: number;
  notional: number;
  couponSpreadBps: number;
  simulatedRating: string;
  expectedLoss: number;
  stressLoss: number;
  subordination: number;
  durationYears: number;
  deltaSensitivity: number;
  allocatedLoss: number;
  allocatedLossPercent: number;
  status: 'PERFORMING' | 'IMPAIRED' | 'TRIGGERED' | 'EXHAUSTED';
}

export interface BEMItem {
  id: string;
  componentName: string;
  category: string;
  physicalQty: number;
  unit: string;
  economicValueGbp: number;
  economicSharePercent: number;
  priceExposure: string;
  supplierExposure: string;
  capacityExposure: string;
  creditExposure: string;
  deliveryExposure: string;
  correlationToEV: number;
  riskContributionBps: number;
  bottleneckCapacityPercent: number;
}

export interface VectorDecomposition {
  material: number;
  components: number;
  manufacturing: number;
  logistics: number;
  energy: number;
  labour: number;
  capital: number;
  financing: number;
}

export interface SyntheticProduct {
  id: string;
  code: string;
  name: string;
  subtitle: string;
  category: 'AUTOMOTIVE' | 'MARINE_AEROSPACE' | 'CLEAN_ENERGY' | 'CUSTOM';
  targetQuantity: number;
  productionHorizonYears: number;
  totalNotionalGbp: number;
  currency: string;
  maturityDate: string;
  creationTimestamp: string;
  modelVersion: string;
  description: string;
  vectorDecomposition: VectorDecomposition;
  exposures: EconomicExposure[];
  tranches: Tranche[];
  bem: BEMItem[];
  bottlenecks: {
    resource: string;
    capacityPercent: number;
    constrainedOutput: number;
    impactDescription: string;
  }[];
  possibleAlternativeProducts?: {
    name: string;
    maxOutput: number;
    criticalLimiter: string;
    estimatedMargin: number;
  }[];
}

export interface CausalShockStep {
  stepNumber: number;
  nodeName: string;
  impactType: 'PRICE' | 'DELAY' | 'CAPACITY' | 'OUTPUT' | 'REVENUE' | 'LOSS';
  description: string;
  deltaPercent: number;
  cumulativeLossGbp: number;
}

export interface ShockScenario {
  id: string;
  name: string;
  category: 'MACRO' | 'COMMODITY' | 'LOGISTICS' | 'SUPPLY_CHAIN' | 'OPERATIONAL';
  description: string;
  severity: 'MILD' | 'SEVERE' | 'EXTREME';
  commodityPriceShock: { [commodityName: string]: number };
  supplierFailureRate: number;
  shippingCostSurge: number;
  factoryCapacityLoss: number;
  energyPriceSurge: number;
  demandShift: number;
  causalChain: CausalShockStep[];
}

export interface IndustrialFactor {
  id: string;
  name: string;
  code: string;
  description: string;
  currentValue: number;
  historicalVol: number;
  loadingByExposure: { [exposureName: string]: number };
}

export interface Greeks {
  deltaCopper: number;
  deltaAluminium: number;
  deltaLithium: number;
  deltaSteel: number;
  deltaEnergy: number;
  deltaShipping: number;
  deltaSupplierCapacity: number;
  deltaFactoryHours: number;
  deltaDemand: number;
  deltaFxGbpUsd: number;
  deltaRatesBps: number;
}

export interface ReversePnLBreakdown {
  totalPnL: number;
  drivers: {
    name: string;
    amountGbp: number;
    percentage: number;
    trend: 'UP' | 'DOWN';
    category: 'COMMODITY' | 'BATTERY' | 'FX' | 'LOGISTICS' | 'ENERGY' | 'CAPACITY' | 'SPREAD';
  }[];
}

export interface SecondaryInstrument {
  id: string;
  symbol: string;
  type: 'SC-CDO' | 'SYNTHETIC_COMMODITY' | 'MANUFACTURING_EXPOSURE' | 'PRODUCT_NOTE';
  underlyingProduct: string;
  trancheSeniority?: TrancheSeniority;
  bidPrice: number;
  askPrice: number;
  lastPrice: number;
  spreadBps: number;
  sizeNotional: number;
  liquidityScore: number;
  dailyVolumeGbp: number;
  yieldToMaturity: number;
}

export interface ModelGovernanceRecord {
  modelVersion: string;
  calibrationDate: string;
  lossModelType: 'GAUSSIAN_COPULA' | 'STUDENT_T_COPULA' | 'FACTOR_MODEL' | 'EMPIRICAL';
  copulaDegreesOfFreedom?: number;
  randomSeed: number;
  correlationEngine: string;
  assumptions: string[];
  stressParameters: string[];
  knownLimitations: string[];
  auditHash: string;
}
