import React, { useState, useEffect } from "react";
import { Currency, TimePeriod, ViewTab, OverviewMetrics, WaterfallItem, CommercialAlert } from "./types";
import { Header } from "./components/Header";
import { OverviewView } from "./components/OverviewView";
import { SalesView } from "./components/SalesView";
import { ProductsView } from "./components/ProductsView";
import { InventoryView } from "./components/InventoryView";
import { CustomersView } from "./components/CustomersView";
import { MarketingView } from "./components/MarketingView";
import { ProfitabilityView } from "./components/ProfitabilityView";
import { ForecastingView } from "./components/ForecastingView";
import { OptimisationView } from "./components/OptimisationView";
import { SettingsView } from "./components/SettingsView";
import { RConsoleModal } from "./components/RConsoleModal";

export default function App() {
  const [tab, setTab] = useState<ViewTab>("overview");
  const [currency, setCurrency] = useState<Currency>("GBP");
  const [period, setPeriod] = useState<TimePeriod>("30d");
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [rConsoleOpen, setRConsoleOpen] = useState<boolean>(false);

  // Overview Data
  const [overviewMetrics, setOverviewMetrics] = useState<OverviewMetrics | null>(null);
  const [waterfall, setWaterfall] = useState<WaterfallItem[]>([]);
  const [bulletins, setBulletins] = useState<string[]>([]);
  const [alerts, setAlerts] = useState<CommercialAlert[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Currency Symbols
  const currencySymbols: Record<Currency, string> = {
    GBP: "£",
    USD: "$",
    EUR: "€",
    CAD: "CA$",
    AUD: "A$"
  };

  const currentSymbol = currencySymbols[currency];

  useEffect(() => {
    // Apply theme class
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      fetch(`/api/overview?period=${period}`).then(res => res.json()),
      fetch("/api/alerts").then(res => res.json())
    ])
      .then(([overviewData, alertsData]) => {
        setOverviewMetrics(overviewData.metrics);
        setWaterfall(overviewData.waterfall);
        setBulletins(overviewData.executiveSummary);
        setAlerts(alertsData);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error loading overview data:", err);
        setLoading(false);
      });
  }, [period]);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F9FA] dark:bg-slate-950 text-[#1A1C1E] dark:text-slate-100 font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {/* Navigation Header */}
      <Header
        currentTab={tab}
        setTab={setTab}
        currency={currency}
        setCurrency={setCurrency}
        period={period}
        setPeriod={setPeriod}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        openRConsole={() => setRConsoleOpen(true)}
      />

      {/* Main View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {tab === "overview" && (
          <OverviewView
            metrics={overviewMetrics}
            waterfall={waterfall}
            alerts={alerts}
            bulletins={bulletins}
            currencySymbol={currentSymbol}
          />
        )}
        {tab === "sales" && <SalesView period={period} currencySymbol={currentSymbol} />}
        {tab === "products" && <ProductsView currencySymbol={currentSymbol} />}
        {tab === "inventory" && <InventoryView currencySymbol={currentSymbol} />}
        {tab === "customers" && <CustomersView currencySymbol={currentSymbol} />}
        {tab === "marketing" && <MarketingView currencySymbol={currentSymbol} />}
        {tab === "profitability" && <ProfitabilityView currencySymbol={currentSymbol} />}
        {tab === "forecasting" && <ForecastingView currencySymbol={currentSymbol} />}
        {tab === "optimisation" && <OptimisationView currencySymbol={currentSymbol} />}
        {tab === "settings" && <SettingsView />}
      </main>

      {/* System Status Footer */}
      <footer className="px-6 py-2 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap justify-between items-center text-[10px] font-medium text-slate-500 dark:text-slate-400 font-mono gap-2">
        <div className="flex items-center space-x-6">
          <span>ENVIRONMENT: PRODUCTION</span>
          <span>DATA SOURCE: R-ANALYTICS-ENGINE & DUCKDB</span>
          <span>CACHE LATENCY: 4.2ms</span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-slate-600 dark:text-slate-400">v4.2.2-STABLE</span>
          <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            SYSTEMS NOMINAL
          </span>
        </div>
      </footer>

      {/* Live R Console Modal */}
      <RConsoleModal isOpen={rConsoleOpen} onClose={() => setRConsoleOpen(false)} />
    </div>
  );
}
