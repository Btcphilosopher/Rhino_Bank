import React, { useState, useEffect } from "react";
import { ProductItem } from "../types";
import { ProductMatrixGrid } from "./ProductMatrixGrid";
import { Search, Filter, Package, ArrowUpDown, Award, Star, TrendingUp, AlertOctagon } from "lucide-react";

interface ProductsViewProps {
  currencySymbol: string;
}

export const ProductsView: React.FC<ProductsViewProps> = ({ currencySymbol }) => {
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedQuadrant, setSelectedQuadrant] = useState<string>("All");

  useEffect(() => {
    fetch("/api/products")
      .then(res => res.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="p-8 text-center text-slate-400 font-mono">Loading products database...</div>;

  const categories = ["All", ...Array.from(new Set(products.map(p => p.category)))];

  const filtered = products.filter(p => {
    const matchesSearch = p.sku.toLowerCase().includes(search.toLowerCase()) || p.product_name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    const matchesQuadrant = selectedQuadrant === "All" || p.quadrant === selectedQuadrant;
    return matchesSearch && matchesCategory && matchesQuadrant;
  });

  return (
    <div className="space-y-6">
      {/* Product Matrix 2x2 Classifier */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight">
              2x2 Commercial Product Performance Matrix
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Categorizes SKUs based on volume demand vs net contribution profit (Stars, Winners, Volume, Weak).
            </p>
          </div>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 uppercase tracking-wider">
            R-ENGINE: CLASSIFY_MATRIX()
          </span>
        </div>
        <ProductMatrixGrid products={products} currencySymbol={currencySymbol} />
      </div>

      {/* SKU Table & Search Filters */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search SKU or product name..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 text-xs rounded-lg pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {/* Category Filter */}
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg px-3 py-2 border border-slate-200 dark:border-slate-800 font-mono"
            >
              {categories.map(c => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            {/* Quadrant Filter */}
            <select
              value={selectedQuadrant}
              onChange={e => setSelectedQuadrant(e.target.value)}
              className="bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg px-3 py-2 border border-slate-200 dark:border-slate-800 font-mono"
            >
              <option value="All">All Quadrants</option>
              <option value="STARS">STARS</option>
              <option value="WINNERS">WINNERS</option>
              <option value="VOLUME">VOLUME</option>
              <option value="WEAK">WEAK</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-mono uppercase bg-slate-50 dark:bg-slate-950">
                <th className="p-3">SKU</th>
                <th className="p-3">Product Name</th>
                <th className="p-3">Category</th>
                <th className="p-3 text-right">Units Sold</th>
                <th className="p-3 text-right">Revenue</th>
                <th className="p-3 text-right">Gross Margin</th>
                <th className="p-3 text-right">Contribution Profit</th>
                <th className="p-3 text-right">Return Rate</th>
                <th className="p-3 text-center">Matrix Category</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
              {filtered.slice(0, 50).map(p => {
                let badgeClass = "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700";
                if (p.quadrant === "STARS") badgeClass = "bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800";
                if (p.quadrant === "WINNERS") badgeClass = "bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800";
                if (p.quadrant === "VOLUME") badgeClass = "bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800";
                if (p.quadrant === "WEAK") badgeClass = "bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800";

                return (
                  <tr key={p.sku} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400">{p.sku}</td>
                    <td className="p-3 text-slate-800 dark:text-slate-200 font-sans font-medium">{p.product_name}</td>
                    <td className="p-3 text-slate-500 dark:text-slate-400 font-sans">{p.category}</td>
                    <td className="p-3 text-right font-bold text-slate-800 dark:text-slate-100">{p.units_sold.toLocaleString()}</td>
                    <td className="p-3 text-right font-bold text-slate-800 dark:text-slate-100">{currencySymbol}{p.revenue.toLocaleString()}</td>
                    <td className="p-3 text-right text-emerald-600 dark:text-emerald-400 font-bold">{p.gross_margin}%</td>
                    <td className="p-3 text-right font-bold text-emerald-600 dark:text-emerald-400">{currencySymbol}{p.contribution_profit.toLocaleString()}</td>
                    <td className={`p-3 text-right ${p.return_rate > 8 ? "text-rose-600 dark:text-rose-400 font-bold" : "text-slate-500 dark:text-slate-400"}`}>{p.return_rate}%</td>
                    <td className="p-3 text-center">
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded border ${badgeClass}`}>
                        {p.quadrant}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
