import React from "react";
import { Sparkles, ArrowRight, ShieldAlert, CheckCircle2 } from "lucide-react";

interface ExecutiveSummaryProps {
  bulletins: string[];
}

export const ExecutiveSummaryTicker: React.FC<ExecutiveSummaryProps> = ({ bulletins }) => {
  if (!bulletins || bulletins.length === 0) return null;

  return (
    <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-xl p-5 shadow-sm my-4">
      <div className="flex items-center justify-between border-b border-slate-700/80 pb-3 mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
          <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-400 font-mono">
            Automated Executive Bulletin (R Analytics Engine)
          </h2>
        </div>
        <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
          REAL-TIME AUDIT
        </span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        {bulletins.map((item, idx) => {
          const isWarning = item.toLowerCase().includes("risk") || item.toLowerCase().includes("decline") || item.toLowerCase().includes("drop");
          return (
            <div
              key={idx}
              className="flex items-start gap-2 bg-slate-800/90 rounded-lg p-3 border border-slate-700/80 leading-relaxed text-slate-200 shadow-xs"
            >
              {isWarning ? (
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              )}
              <span>{item}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
