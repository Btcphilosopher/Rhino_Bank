import React, { useState, useEffect } from "react";
import { ResponsiveContainer, ComposedChart, Line, Area, XAxis, YAxis, Tooltip, Legend } from "recharts";
import { Sparkles, TrendingUp, Calendar, ShieldCheck } from "lucide-react";

interface ForecastingViewProps {
  currencySymbol: string;
}

export const ForecastingView: React.FC<ForecastingViewProps> = ({ currencySymbol }) => {
  const [forecast, setForecast] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetch("/api/forecasting")
      .then(res => res.json())
      .then(data => {
        setForecast(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="p-8 text-center text-slate-400 font-mono">Running time-series forecasting models...</div>;

  return (
    <div className="space-y-6">
      {/* Forecast Chart */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight">
              30-Day Commercial Revenue Forecast with 80% & 95% Confidence Intervals
            </h3>
          </div>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 uppercase tracking-wider">
            R-ENGINE: FORECAST_REVENUE()
          </span>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={forecast} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
              <XAxis dataKey="date" tick={{ fill: "#64748b", fontSize: 11 }} />
              <YAxis tickFormatter={v => `${currencySymbol}${(v / 1000).toFixed(0)}k`} tick={{ fill: "#64748b", fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", color: "#f8fafc", borderRadius: "8px" }} />
              <Legend wrapperStyle={{ fontSize: "12px", paddingTop: "10px" }} />
              <Area type="monotone" dataKey="upper95" name="95% CI Upper" stroke="none" fill="#10b981" fillOpacity={0.12} />
              <Area type="monotone" dataKey="upper80" name="80% CI Upper" stroke="none" fill="#10b981" fillOpacity={0.25} />
              <Line type="monotone" dataKey="point" name="Point Forecast" stroke="#10b981" strokeWidth={3} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
