import React from "react";
import { ProductItem, Currency } from "../types";
import { Star, Award, TrendingUp, AlertOctagon } from "lucide-react";

interface ProductMatrixGridProps {
  products: ProductItem[];
  currencySymbol: string;
}

export const ProductMatrixGrid: React.FC<ProductMatrixGridProps> = ({ products, currencySymbol }) => {
  const stars = products.filter(p => p.quadrant === "STARS");
  const winners = products.filter(p => p.quadrant === "WINNERS");
  const volume = products.filter(p => p.quadrant === "VOLUME");
  const weak = products.filter(p => p.quadrant === "WEAK");

  const QuadrantBox = ({
    title,
    subtitle,
    icon: Icon,
    color,
    items
  }: {
    title: string;
    subtitle: string;
    icon: any;
    color: string;
    items: ProductItem[];
  }) => (
    <div className={`p-4 rounded-xl border bg-white dark:bg-slate-900 ${color} flex flex-col shadow-sm`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4" />
          <h4 className="text-xs font-bold uppercase tracking-wider font-mono">{title}</h4>
        </div>
        <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-mono">
          {items.length} SKUs
        </span>
      </div>
      <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">{subtitle}</p>

      <div className="flex-1 overflow-y-auto max-h-48 space-y-2 pr-1">
        {items.slice(0, 8).map(item => (
          <div
            key={item.sku}
            className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
          >
            <div>
              <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">{item.sku}</span>
              <p className="text-slate-500 dark:text-slate-400 truncate max-w-[130px]">{item.product_name}</p>
            </div>
            <div className="text-right">
              <span className="font-bold text-slate-900 dark:text-slate-100 font-mono">
                {currencySymbol}
                {item.contribution_profit.toLocaleString()}
              </span>
              <p className="text-slate-400 text-[10px]">{item.units_sold} units</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
      <QuadrantBox
        title="WINNERS (High Profit / Low Sales)"
        subtitle="Niche high-margin items. Boost marketing to drive volume."
        icon={Award}
        color="border-purple-500/40 text-purple-400"
        items={winners}
      />
      <QuadrantBox
        title="STARS (High Profit / High Sales)"
        subtitle="Core profit engines. Maintain stock level & protect margin."
        icon={Star}
        color="border-emerald-500/40 text-emerald-400"
        items={stars}
      />
      <QuadrantBox
        title="WEAK (Low Profit / Low Sales)"
        subtitle="Underperforming SKUs. Consider clearance or price optimization."
        icon={AlertOctagon}
        color="border-rose-500/40 text-rose-400"
        items={weak}
      />
      <QuadrantBox
        title="VOLUME (Low Profit / High Sales)"
        subtitle="High-volume drivers with compressed margin. Re-negotiate COGS."
        icon={TrendingUp}
        color="border-amber-500/40 text-amber-400"
        items={volume}
      />
    </div>
  );
};
