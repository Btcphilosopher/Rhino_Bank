import React from "react";
import { OverviewMetrics, WaterfallItem, CommercialAlert, Currency } from "../types";
import { RevenueWaterfallChart } from "./RevenueWaterfallChart";
import { AlertsFeed } from "./AlertsFeed";
import { WhatIfSimulator } from "./WhatIfSimulator";
import { ExecutiveSummaryTicker } from "./ExecutiveSummaryTicker";
import { TrendingUp, TrendingDown, DollarSign, ShoppingCart, Percent, Coins, ArrowUpRight, ArrowDownRight } from "lucide-react";

interface OverviewViewProps {
  metrics: OverviewMetrics | null;
  waterfall: WaterfallItem[];
  alerts: CommercialAlert[];
  bulletins: string[];
  currencySymbol: string;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  metrics,
  waterfall,
  alerts,
  bulletins,
  currencySymbol
}) => {
  if (!metrics) return <div className="p-8 text-center text-slate-400">Loading commercial metrics...</div>;

  const KPICard = ({
    title,
    value,
    symbol,
    pct,
    pp,
    icon: Icon,
    isCurrency = true,
    isPercent = false
  }: {
    title: string;
    value: number;
    symbol: string;
    pct?: number;
    pp?: number;
    icon: any;
    isCurrency?: boolean;
    isPercent?: boolean;
  }) => {
    const isPos = (pct !== undefined && pct >= 0) || (pp !== undefined && pp >= 0);
    const DeltaIcon = isPos ? ArrowUpRight : ArrowDownRight;

    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded p-4 shadow-sm">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-[10px] font-bold uppercase tracking-wider font-mono">{title}</span>
          <div className="p-1.5 rounded bg-slate-100 dark:bg-slate-800 text-emerald-600 dark:text-emerald-400">
            <Icon className="w-4 h-4" />
          </div>
        </div>
        <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mb-1">
          {isCurrency && symbol}
          {value.toLocaleString(undefined, { maximumFractionDigits: isPercent ? 1 : 0 })}
          {isPercent && "%"}
        </div>
        <div className="flex items-center gap-1 text-xs">
          <span className={`inline-flex items-center font-bold font-mono ${isPos ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400"}`}>
            <DeltaIcon className="w-3.5 h-3.5" />
            {pct !== undefined && `${pct >= 0 ? "+" : ""}${pct.toFixed(1)}%`}
            {pp !== undefined && `${pp >= 0 ? "+" : ""}${pp.toFixed(1)}pp`}
          </span>
          <span className="text-slate-400 font-normal">vs prev period</span>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Executive Summary Bulletins */}
      <ExecutiveSummaryTicker bulletins={bulletins} />

      {/* Top 8 KPI Matrix */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="Net Revenue"
          value={metrics.revenue.value}
          symbol={currencySymbol}
          pct={metrics.revenue.pct}
          icon={DollarSign}
        />
        <KPICard
          title="Gross Margin"
          value={metrics.grossMargin.value}
          symbol={currencySymbol}
          pp={metrics.grossMargin.pp}
          isCurrency={false}
          isPercent={true}
          icon={Percent}
        />
        <KPICard
          title="Orders"
          value={metrics.orders.value}
          symbol={currencySymbol}
          pct={metrics.orders.pct}
          isCurrency={false}
          icon={ShoppingCart}
        />
        <KPICard
          title="AOV"
          value={metrics.aov.value}
          symbol={currencySymbol}
          pct={metrics.aov.pct}
          icon={TrendingUp}
        />
        <KPICard
          title="Gross Profit"
          value={metrics.grossProfit.value}
          symbol={currencySymbol}
          pct={metrics.grossProfit.pct}
          icon={Coins}
        />
        <KPICard
          title="Net Profit"
          value={metrics.netProfit.value}
          symbol={currencySymbol}
          pct={metrics.netProfit.pct}
          icon={DollarSign}
        />
        <KPICard
          title="Units Sold"
          value={metrics.units.value}
          symbol={currencySymbol}
          pct={metrics.units.pct}
          isCurrency={false}
          icon={ShoppingCart}
        />
        <KPICard
          title="Conversion Rate"
          value={metrics.conversionRate.value}
          symbol={currencySymbol}
          pp={metrics.conversionRate.pp}
          isCurrency={false}
          isPercent={true}
          icon={Percent}
        />
      </div>

      {/* Revenue Waterfall Chart Section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-tight">
              Revenue Waterfall Analysis (Gross Sales to Net Operating Revenue)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Accounting reconciliation of discounts, returns, refunds, shipping, and tax liabilities.
            </p>
          </div>
          <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 uppercase tracking-wider">
            ACCOUNTING BASIS: NET REVENUE
          </span>
        </div>
        <RevenueWaterfallChart data={waterfall} currencySymbol={currencySymbol} />
      </div>

      {/* Commercial Alerts Feed */}
      <AlertsFeed alerts={alerts} />

      {/* What-If Simulation Engine */}
      <WhatIfSimulator currencySymbol={currencySymbol} />
    </div>
  );
};
