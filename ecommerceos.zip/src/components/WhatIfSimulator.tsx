import React, { useState, useEffect } from "react";
import { Sliders, TrendingUp, Sparkles, AlertCircle, RefreshCcw } from "lucide-react";

interface WhatIfSimulatorProps {
  currencySymbol: string;
}

export const WhatIfSimulator: React.FC<WhatIfSimulatorProps> = ({ currencySymbol }) => {
  const [currentPrice, setCurrentPrice] = useState<number>(49.99);
  const [cogs, setCogs] = useState<number>(18.0);
  const [priceChange, setPriceChange] = useState<number>(5);
  const [elasticity, setElasticity] = useState<number>(-1.6);
  const [volume, setVolume] = useState<number>(1200);

  const [simulationResult, setSimulationResult] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const runSimulation = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/optimisation/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          priceChangePct: priceChange,
          currentPrice,
          cogs,
          elasticity,
          currentVolume: volume
        })
      });
      const data = await res.json();
      setSimulationResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runSimulation();
  }, [priceChange, currentPrice, cogs, elasticity, volume]);

  const baseRevenue = currentPrice * volume;
  const baseGrossProfit = (currentPrice - cogs) * volume;
  const baseContribution = baseGrossProfit - (baseRevenue * 0.12) - (volume * 3.50);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm my-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div className="flex items-center gap-2">
          <Sliders className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-tight font-mono">
            Commercial What-If & Price Elasticity Simulator
          </h3>
        </div>
        <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-mono bg-emerald-50 dark:bg-emerald-950/80 px-2.5 py-1 rounded border border-emerald-200 dark:border-emerald-800 uppercase tracking-wider font-semibold">
          R-ENGINE: OPTIMIZE_PRICE()
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Price Adjustment Slider */}
        <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800">
          <div className="flex justify-between items-center mb-1 text-xs">
            <span className="text-slate-600 dark:text-slate-400 font-semibold">Price Adjustment</span>
            <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">{priceChange > 0 ? `+${priceChange}%` : `${priceChange}%`}</span>
          </div>
          <input
            type="range"
            min="-20"
            max="30"
            step="1"
            value={priceChange}
            onChange={e => setPriceChange(parseFloat(e.target.value))}
            className="w-full accent-emerald-500 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
            <span>-20%</span>
            <span>Current</span>
            <span>+30%</span>
          </div>
        </div>

        {/* Current Price */}
        <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800">
          <label className="text-xs text-slate-600 dark:text-slate-400 font-semibold block mb-1">
            Current Price ({currencySymbol})
          </label>
          <input
            type="number"
            step="0.01"
            value={currentPrice}
            onChange={e => setCurrentPrice(parseFloat(e.target.value) || 0)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs rounded p-1.5 focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* COGS */}
        <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800">
          <label className="text-xs text-slate-600 dark:text-slate-400 font-semibold block mb-1">
            Unit COGS ({currencySymbol})
          </label>
          <input
            type="number"
            step="0.1"
            value={cogs}
            onChange={e => setCogs(parseFloat(e.target.value) || 0)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs rounded p-1.5 focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Price Elasticity */}
        <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800">
          <label className="text-xs text-slate-600 dark:text-slate-400 font-semibold block mb-1">
            Assumed Elasticity (Ed)
          </label>
          <input
            type="number"
            step="0.1"
            value={elasticity}
            onChange={e => setElasticity(parseFloat(e.target.value) || -1.0)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs rounded p-1.5 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Results Comparison Grid */}
      {simulationResult && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
          {/* Output 1: Expected Revenue */}
          <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold block mb-1 font-mono uppercase">Expected Revenue</span>
            <div className="text-lg font-bold font-mono text-slate-900 dark:text-white">
              {currencySymbol}{simulationResult.revenue.toLocaleString()}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono">
              Delta: {simulationResult.revenue >= baseRevenue ? "+" : ""}
              {currencySymbol}{(simulationResult.revenue - baseRevenue).toLocaleString()}
            </p>
          </div>

          {/* Output 2: Expected Units */}
          <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold block mb-1 font-mono uppercase">Expected Units Demand</span>
            <div className="text-lg font-bold font-mono text-slate-900 dark:text-white">
              {simulationResult.expectedUnits.toLocaleString()} units
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono">
              Volume Delta: {simulationResult.expectedUnits - volume} units
            </p>
          </div>

          {/* Output 3: Contribution Profit */}
          <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold block mb-1 font-mono uppercase">Contribution Profit Lift</span>
            <div className={`text-lg font-bold font-mono ${simulationResult.contributionProfit >= baseContribution ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400"}`}>
              {currencySymbol}{simulationResult.contributionProfit.toLocaleString()}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono">
              Profit Impact: {simulationResult.contributionProfit >= baseContribution ? "+" : ""}
              {currencySymbol}{(simulationResult.contributionProfit - baseContribution).toLocaleString()}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
