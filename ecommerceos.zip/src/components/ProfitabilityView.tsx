import React, { useState, useEffect } from "react";
import { PnLRow } from "../types";
import { DollarSign, FileText, PieChart, ShieldCheck } from "lucide-react";

interface ProfitabilityViewProps {
  currencySymbol: string;
}

export const ProfitabilityView: React.FC<ProfitabilityViewProps> = ({ currencySymbol }) => {
  const [pnl, setPnl] = useState<PnLRow[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetch("/api/profitability")
      .then(res => res.json())
      .then(data => {
        setPnl(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="p-8 text-center text-slate-400 font-mono">Loading Profitability P&L...</div>;

  return (
    <div className="space-y-6">
      {/* Financial Statement Container */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              Commercial Income Statement (P&L Accounting)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Full breakdown of Gross Revenue, COGS, Shipping, Payment Fees, Advertising, Contribution & Net Profit.
            </p>
          </div>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 uppercase tracking-wider">
            R-ENGINE: CALCULATE_PNL()
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 uppercase bg-slate-50 dark:bg-slate-950">
                <th className="p-3">P&L Line Item</th>
                <th className="p-3 text-right">Amount ({currencySymbol})</th>
                <th className="p-3 text-right">% Net Revenue</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {pnl.map((row, idx) => {
                const isTotal = row.type === "total" || row.type === "subtotal";
                const isDeduction = row.type === "deduction" || row.type === "cost";

                return (
                  <tr
                    key={idx}
                    className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${
                      isTotal ? "bg-slate-50 dark:bg-slate-950/80 font-bold text-slate-900 dark:text-white" : "text-slate-700 dark:text-slate-300"
                    }`}
                  >
                    <td className={`p-3 ${isTotal ? "text-emerald-600 dark:text-emerald-400 font-semibold" : "pl-6 text-slate-700 dark:text-slate-300"}`}>
                      {row.category}
                    </td>
                    <td className={`p-3 text-right font-bold ${isDeduction ? "text-rose-600 dark:text-rose-400" : isTotal ? "text-emerald-600 dark:text-emerald-400" : "text-slate-900 dark:text-slate-100"}`}>
                      {row.amount < 0 ? `- ${currencySymbol}${Math.abs(row.amount).toLocaleString()}` : `${currencySymbol}${row.amount.toLocaleString()}`}
                    </td>
                    <td className="p-3 text-right text-slate-500 dark:text-slate-400 font-bold">{row.pct}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
