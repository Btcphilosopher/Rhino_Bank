import React from "react";
import { WhatIfSimulator } from "./WhatIfSimulator";
import { Sliders, TrendingUp, Sparkles, Target } from "lucide-react";

interface OptimisationViewProps {
  currencySymbol: string;
}

export const OptimisationView: React.FC<OptimisationViewProps> = ({ currencySymbol }) => {
  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center gap-2 mb-2">
          <Target className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight">
            R-Engine Profit Optimisation & Elasticity Lab
          </h3>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Simulate commercial price changes, marketing ad spend shifts, and fulfillment cost variations to determine optimal price points for maximum contribution profit.
        </p>
      </div>

      <WhatIfSimulator currencySymbol={currencySymbol} />
    </div>
  );
};
