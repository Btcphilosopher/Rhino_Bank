import React, { useState } from "react";
import { X, Play, Terminal, Code2, Copy, Check, RefreshCw } from "lucide-react";

interface RConsoleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RConsoleModal: React.FC<RConsoleModalProps> = ({ isOpen, onClose }) => {
  const [code, setCode] = useState<string>(
    `# EcommerceOS Interactive R Console
# Run custom R models, forecasts and profit optimization

# 1. Run Profit Optimizer
opt <- profit_optimizer(current_price=49.99, cogs=18.0, shipping_cost=3.5, ad_spend_per_unit=5.0, current_volume=1200, price_elasticity=-1.6)
cat("Suggested Price:", opt$optimal_price, "\\n")
cat("Expected Profit Lift:", sprintf("£%.2f (+%.1f%%)", opt$expected_profit_lift, opt$expected_profit_lift_pct), "\\n\\n")

# 2. View Simulation Grid
print(opt$simulations)`
  );

  const [output, setOutput] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleRun = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/r-console", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code })
      });
      const data = await res.json();
      setOutput(data.output || data.error || "Execution completed.");
    } catch (err: any) {
      setOutput(`Error executing R code: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const copyOutput = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="text-xs font-bold text-slate-800 dark:text-white font-mono uppercase tracking-wider">
              Live R Execution Terminal (R v4.2.2 Engine)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0 divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-slate-800 flex-1 overflow-hidden">
          {/* Editor */}
          <div className="p-4 flex flex-col bg-white dark:bg-slate-900">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 font-mono uppercase tracking-wider">
                R Script Input
              </span>
              <button
                onClick={handleRun}
                disabled={loading}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-800 text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-xs transition-all font-mono uppercase tracking-wider"
              >
                {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                <span>{loading ? "Running R..." : "Execute R"}</span>
              </button>
            </div>
            <textarea
              value={code}
              onChange={e => setCode(e.target.value)}
              className="flex-1 w-full bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 font-mono text-xs p-3 rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500 resize-none h-64 md:h-auto"
              spellCheck={false}
            />
          </div>

          {/* Console Output */}
          <div className="p-4 flex flex-col bg-slate-50 dark:bg-slate-950">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 font-mono uppercase tracking-wider">
                R Terminal Stdout Output
              </span>
              {output && (
                <button
                  onClick={copyOutput}
                  className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? "Copied" : "Copy"}</span>
                </button>
              )}
            </div>
            <pre className="flex-1 w-full bg-slate-900 text-emerald-400 font-mono text-xs p-3 rounded-lg border border-slate-800 overflow-auto h-64 md:h-auto whitespace-pre-wrap">
              {output || "# R stdout stream will appear here after clicking Execute R."}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-[10px] font-mono text-slate-500 flex justify-between items-center">
          <span>Engine: /usr/bin/R | Process environment: Linux x86_64</span>
          <span>ecommerce_os/R/*.R libraries pre-loaded</span>
        </div>
      </div>
    </div>
  );
};
