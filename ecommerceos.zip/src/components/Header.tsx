import React from "react";
import { Currency, TimePeriod, ViewTab } from "../types";
import {
  Terminal,
  TrendingUp,
  Package,
  Users,
  Boxes,
  PieChart,
  DollarSign,
  LineChart,
  Sliders,
  Settings,
  Download,
  Moon,
  Sun,
  Layers,
  Sparkles
} from "lucide-react";

interface HeaderProps {
  currentTab: ViewTab;
  setTab: (tab: ViewTab) => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  period: TimePeriod;
  setPeriod: (p: TimePeriod) => void;
  darkMode: boolean;
  setDarkMode: (d: boolean) => void;
  openRConsole: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setTab,
  currency,
  setCurrency,
  period,
  setPeriod,
  darkMode,
  setDarkMode,
  openRConsole
}) => {
  const tabs: { id: ViewTab; label: string; icon: React.ReactNode }[] = [
    { id: "overview", label: "Overview", icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: "sales", label: "Sales Analytics", icon: <LineChart className="w-3.5 h-3.5" /> },
    { id: "products", label: "Product Matrix", icon: <Package className="w-3.5 h-3.5" /> },
    { id: "inventory", label: "Inventory & Reorder", icon: <Boxes className="w-3.5 h-3.5" /> },
    { id: "customers", label: "RFM & Customers", icon: <Users className="w-3.5 h-3.5" /> },
    { id: "marketing", label: "Marketing ROAS", icon: <PieChart className="w-3.5 h-3.5" /> },
    { id: "profitability", label: "Profitability P&L", icon: <DollarSign className="w-3.5 h-3.5" /> },
    { id: "forecasting", label: "Forecasting", icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: "optimisation", label: "What-If Optimizer", icon: <Sliders className="w-3.5 h-3.5" /> },
    { id: "settings", label: "Data & Settings", icon: <Settings className="w-3.5 h-3.5" /> }
  ];

  return (
    <header className="bg-[#0F172A] text-white border-b border-slate-800 sticky top-0 z-40 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Control Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between py-3 gap-3">
          <div className="flex items-center gap-3">
            <span className="text-xl font-bold tracking-tight text-emerald-400 font-mono">
              ECOMMERCE<span className="text-white font-light">.OS</span>
            </span>
            <div className="flex items-center space-x-2 bg-slate-800/90 px-2.5 py-1 rounded border border-slate-700/80 text-xs font-mono">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-slate-300 font-medium">DUCKDB CONNECTED</span>
              <span className="text-slate-500 hidden sm:inline">| R v4.2.2</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Currency Selector */}
            <div className="flex items-center bg-slate-800/90 rounded p-1 border border-slate-700">
              {(["GBP", "USD", "EUR", "CAD", "AUD"] as Currency[]).map(c => (
                <button
                  key={c}
                  onClick={() => setCurrency(c)}
                  className={`px-2.5 py-0.5 text-xs font-semibold rounded transition-all ${
                    currency === c
                      ? "bg-emerald-500 text-slate-950 font-bold shadow-xs"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            {/* Time Range Selector */}
            <select
              value={period}
              onChange={e => setPeriod(e.target.value as TimePeriod)}
              className="bg-slate-800 text-slate-200 text-xs font-semibold rounded px-3 py-1.5 border border-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="today">Today</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days (Rolling)</option>
              <option value="90d">Last 90 Days</option>
              <option value="ytd">Year to Date (YTD)</option>
            </select>

            {/* R Terminal Button */}
            <button
              onClick={openRConsole}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-xs transition-all"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>R Console</span>
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-1.5 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 transition-colors"
              title="Toggle Theme"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 overflow-x-auto py-1.5 scrollbar-none border-t border-slate-800/80">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider rounded transition-all whitespace-nowrap ${
                currentTab === t.id
                  ? "text-emerald-400 border-b-2 border-emerald-400 bg-slate-800/80"
                  : "text-slate-400 hover:text-white hover:bg-slate-800/40"
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};
