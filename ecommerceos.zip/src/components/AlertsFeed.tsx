import React from "react";
import { CommercialAlert } from "../types";
import { AlertOctagon, AlertTriangle, CheckCircle2, Info } from "lucide-react";

interface AlertsFeedProps {
  alerts: CommercialAlert[];
}

export const AlertsFeed: React.FC<AlertsFeedProps> = ({ alerts }) => {
  if (!alerts || alerts.length === 0) return null;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm my-4">
      <h3 className="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider mb-3 font-mono">
        Commercial Exception & Risk Engine
      </h3>
      <div className="space-y-2">
        {alerts.map(a => {
          let Icon = AlertTriangle;
          let badgeColor = "bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800";
          if (a.type === "danger") {
            Icon = AlertOctagon;
            badgeColor = "bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800";
          } else if (a.type === "success") {
            Icon = CheckCircle2;
            badgeColor = "bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800";
          } else if (a.type === "info") {
            Icon = Info;
            badgeColor = "bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800";
          }

          return (
            <div
              key={a.id}
              className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 shrink-0 ${a.type === "danger" ? "text-rose-500" : a.type === "warning" ? "text-amber-500" : "text-emerald-500"}`} />
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">{a.title}</span>
                  <p className="text-slate-500 dark:text-slate-400">{a.message}</p>
                </div>
              </div>
              <span className={`px-2.5 py-1 text-[10px] font-bold font-mono rounded border ${badgeColor}`}>
                {a.impact}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
