import React, { useState, useEffect } from "react";
import { RFMSegment } from "../types";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";
import { Users, DollarSign, Award, Target, UserCheck } from "lucide-react";

interface CustomersViewProps {
  currencySymbol: string;
}

export const CustomersView: React.FC<CustomersViewProps> = ({ currencySymbol }) => {
  const [data, setData] = useState<{ segments: RFMSegment[]; ltvCac: any[] } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetch("/api/customers")
      .then(res => res.json())
      .then(d => {
        setData(d);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading || !data) return <div className="p-8 text-center text-slate-400 font-mono">Loading customer analytics engine...</div>;

  return (
    <div className="space-y-6">
      {/* LTV vs CAC Economics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase font-mono tracking-wider">Blended CAC</span>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {currencySymbol}32.50
          </div>
          <p className="text-xs text-slate-400 mt-1">Customer Acquisition Cost</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase font-mono tracking-wider">1-Year LTV Forecast</span>
          <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
            {currencySymbol}165.00
          </div>
          <p className="text-xs text-slate-400 mt-1">Observed 90D: {currencySymbol}89.40</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase font-mono tracking-wider">LTV / CAC Ratio</span>
          <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
            5.08x
          </div>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold mt-1">Healthy Economics (&gt; 3.0x)</p>
        </div>
      </div>

      {/* RFM Customer Segmentation Bar Chart */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight">
              RFM Customer Segmentation (Recency, Frequency, Monetary)
            </h3>
          </div>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 uppercase tracking-wider">
            R-ENGINE: CALCULATE_RFM()
          </span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.segments} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
              <XAxis dataKey="name" tick={{ fill: "#64748b", fontSize: 11 }} />
              <YAxis tick={{ fill: "#64748b", fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", color: "#f8fafc", borderRadius: "8px" }} />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {data.segments.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* RFM Segment Breakdown Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-xs font-bold text-slate-800 dark:text-white font-mono uppercase tracking-wider mb-3">
          Customer Cohort & Segment Metrics
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-950">
                <th className="p-3">Segment</th>
                <th className="p-3 text-right">Customer Count</th>
                <th className="p-3 text-right">Avg Order Value</th>
                <th className="p-3 text-right">Repeat Purchase Rate</th>
                <th className="p-3 text-right">Recommended Campaign</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {data.segments.map(seg => (
                <tr key={seg.name} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-slate-800 dark:text-white flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: seg.color }} />
                    {seg.name}
                  </td>
                  <td className="p-3 text-right font-bold text-slate-700 dark:text-slate-200">{seg.count.toLocaleString()}</td>
                  <td className="p-3 text-right text-emerald-600 dark:text-emerald-400 font-bold">{currencySymbol}{seg.avgSpend}</td>
                  <td className="p-3 text-right text-slate-600 dark:text-slate-300">
                    {seg.name === "Champions" || seg.name === "Loyal" ? "78.4%" : "12.1%"}
                  </td>
                  <td className="p-3 text-right text-slate-500 dark:text-slate-400 font-sans">
                    {seg.name === "Champions" ? "VIP Early Access & Rewards" : seg.name === "At Risk" ? "Win-Back Discount Code" : "Nurture Email Flow"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
