import React, { useState, useEffect } from "react";
import { InventoryItem } from "../types";
import { Boxes, AlertTriangle, CheckCircle, Clock, ShoppingCart, RefreshCcw } from "lucide-react";

interface InventoryViewProps {
  currencySymbol: string;
}

export const InventoryView: React.FC<InventoryViewProps> = ({ currencySymbol }) => {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [statusFilter, setStatusFilter] = useState<string>("All");

  useEffect(() => {
    fetch("/api/inventory")
      .then(res => res.json())
      .then(data => {
        setInventory(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="p-8 text-center text-slate-400 font-mono">Loading inventory engine...</div>;

  const outOfStockCount = inventory.filter(i => i.status === "OUT OF STOCK").length;
  const lowStockCount = inventory.filter(i => i.status === "LOW STOCK").length;
  const overstockedCount = inventory.filter(i => i.status === "OVERSTOCKED").length;

  const filtered = inventory.filter(i => statusFilter === "All" || i.status === statusFilter);

  return (
    <div className="space-y-6">
      {/* Top Status Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase font-mono tracking-wider">Out Of Stock</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400">{outOfStockCount} SKUs</div>
          <p className="text-[11px] text-slate-400 mt-1">Requires immediate PO</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase font-mono tracking-wider">Low Stock Warning</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400">{lowStockCount} SKUs</div>
          <p className="text-[11px] text-slate-400 mt-1">Below Reorder Point (ROP)</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase font-mono tracking-wider">Overstocked</span>
            <Boxes className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-blue-600 dark:text-blue-400">{overstockedCount} SKUs</div>
          <p className="text-[11px] text-slate-400 mt-1">&gt; 120 Days of Inventory</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase font-mono tracking-wider">Total Monitored</span>
            <CheckCircle className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">{inventory.length} SKUs</div>
          <p className="text-[11px] text-slate-400 mt-1">Automated Stockout Forecast</p>
        </div>
      </div>

      {/* Inventory Operations Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight">
            Inventory Health & Reorder Demand Table
          </h3>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg px-3 py-1.5 border border-slate-200 dark:border-slate-800 font-mono"
          >
            <option value="All">All Statuses</option>
            <option value="OUT OF STOCK">OUT OF STOCK</option>
            <option value="LOW STOCK">LOW STOCK</option>
            <option value="HEALTHY">HEALTHY</option>
            <option value="OVERSTOCKED">OVERSTOCKED</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-mono uppercase bg-slate-50 dark:bg-slate-950">
                <th className="p-3">SKU</th>
                <th className="p-3">Product</th>
                <th className="p-3 text-right">Stock On Hand</th>
                <th className="p-3 text-right">Daily Demand</th>
                <th className="p-3 text-right">Days of Stock</th>
                <th className="p-3 text-right">Reorder Point (ROP)</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-right">Recommended PO Qty</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
              {filtered.slice(0, 50).map(item => {
                let statusBadge = "bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800";
                if (item.status === "OUT OF STOCK") statusBadge = "bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800";
                if (item.status === "LOW STOCK") statusBadge = "bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800";
                if (item.status === "OVERSTOCKED") statusBadge = "bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800";

                return (
                  <tr key={item.sku} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400">{item.sku}</td>
                    <td className="p-3 text-slate-800 dark:text-slate-200 font-sans font-medium">{item.product_name}</td>
                    <td className="p-3 text-right font-bold text-slate-800 dark:text-white">{item.stock_on_hand}</td>
                    <td className="p-3 text-right text-slate-600 dark:text-slate-300">{item.daily_demand}</td>
                    <td className="p-3 text-right text-slate-600 dark:text-slate-300">{item.days_of_inventory}d</td>
                    <td className="p-3 text-right text-slate-500 dark:text-slate-400">{item.reorder_point}</td>
                    <td className="p-3 text-center">
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded border ${statusBadge}`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="p-3 text-right font-bold text-emerald-600 dark:text-emerald-400">
                      {item.recommended_reorder > 0 ? `+${item.recommended_reorder} units` : "-"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
