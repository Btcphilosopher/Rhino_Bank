import React, { useState, useEffect } from "react";
import { ChannelPerformance } from "../types";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from "recharts";
import { PieChart, Target, DollarSign, TrendingUp, Zap } from "lucide-react";

interface MarketingViewProps {
  currencySymbol: string;
}

export const MarketingView: React.FC<MarketingViewProps> = ({ currencySymbol }) => {
  const [channels, setChannels] = useState<ChannelPerformance[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetch("/api/marketing")
      .then(res => res.json())
      .then(data => {
        setChannels(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="p-8 text-center text-slate-400 font-mono">Loading marketing analytics...</div>;

  return (
    <div className="space-y-6">
      {/* ROAS vs Contribution ROAS Chart */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight">
              Channel ROAS vs Contribution ROAS (Net Incremental Profit)
            </h3>
          </div>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 uppercase tracking-wider">
            R-ENGINE: MARKETING_ROAS()
          </span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={channels} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
              <XAxis dataKey="channel" tick={{ fill: "#64748b", fontSize: 11 }} />
              <YAxis tick={{ fill: "#64748b", fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", color: "#f8fafc", borderRadius: "8px" }} />
              <Legend wrapperStyle={{ fontSize: "12px", paddingTop: "10px" }} />
              <Bar dataKey="roas" name="Top-Line ROAS (Revenue/Spend)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="croas" name="Contribution ROAS (Profit/Spend)" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Marketing Economics Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-xs font-bold text-slate-800 dark:text-white font-mono uppercase tracking-wider mb-3">
          Channel Attributed Spend & Profitability Economics
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-950">
                <th className="p-3">Marketing Channel</th>
                <th className="p-3 text-right">Ad Spend</th>
                <th className="p-3 text-right">Attributed Revenue</th>
                <th className="p-3 text-right">Top-Line ROAS</th>
                <th className="p-3 text-right">Contribution ROAS</th>
                <th className="p-3 text-right">Net Profit After Ads</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {channels.map(ch => (
                <tr key={ch.channel} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400">{ch.channel}</td>
                  <td className="p-3 text-right text-slate-700 dark:text-slate-200">{currencySymbol}{ch.spend.toLocaleString()}</td>
                  <td className="p-3 text-right font-bold text-slate-900 dark:text-white">{currencySymbol}{ch.revenue.toLocaleString()}</td>
                  <td className="p-3 text-right font-bold text-blue-600 dark:text-blue-400">{ch.roas.toFixed(2)}x</td>
                  <td className={`p-3 text-right font-bold ${ch.croas >= 1.5 ? "text-emerald-600 dark:text-emerald-400" : ch.croas >= 1.0 ? "text-amber-600 dark:text-amber-400" : "text-rose-600 dark:text-rose-400"}`}>
                    {ch.croas.toFixed(2)}x
                  </td>
                  <td className="p-3 text-right font-bold text-emerald-600 dark:text-emerald-400">
                    {currencySymbol}{(ch.revenue * 0.438 - ch.spend).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
