import React from "react";
import { WaterfallItem, Currency } from "../types";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, ReferenceLine } from "recharts";

interface WaterfallProps {
  data: WaterfallItem[];
  currencySymbol: string;
}

export const RevenueWaterfallChart: React.FC<WaterfallProps> = ({ data, currencySymbol }) => {
  if (!data || data.length === 0) return null;

  // Transform data for Recharts Waterfall
  let cumulative = 0;
  const plotData = data.map(item => {
    const isTotal = item.category === "Gross" || item.category === "Net Operating Revenue";
    let start = cumulative;
    if (isTotal) {
      start = 0;
      cumulative = item.amount;
    } else {
      cumulative += item.impact;
    }

    return {
      stage: item.stage,
      amount: Math.abs(item.impact),
      base: item.impact < 0 ? cumulative : start,
      isNegative: item.impact < 0,
      category: item.category,
      rawAmount: item.amount
    };
  });

  return (
    <div className="w-full h-72">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={plotData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
          <XAxis dataKey="stage" tick={{ fill: "#64748b", fontSize: 11 }} />
          <YAxis
            tickFormatter={val => `${currencySymbol}${(val / 1000).toFixed(0)}k`}
            tick={{ fill: "#64748b", fontSize: 11 }}
          />
          <Tooltip
            formatter={(value: any, name: any, props: any) => [
              `${currencySymbol}${props.payload.rawAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}`,
              props.payload.category
            ]}
            contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", color: "#f8fafc", borderRadius: "8px" }}
          />
          <Bar dataKey="base" stackId="a" fill="transparent" />
          <Bar dataKey="amount" stackId="a">
            {plotData.map((entry, index) => {
              let color = "#3b82f6"; // default blue
              if (entry.isNegative) color = "#ef4444"; // red deduction
              else if (entry.category === "Addition") color = "#10b981"; // green addition
              else if (entry.category === "Net Operating Revenue") color = "#6366f1"; // indigo total
              return <Cell key={`cell-${index}`} fill={color} />;
            })}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
