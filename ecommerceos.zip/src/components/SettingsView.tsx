import React, { useState } from "react";
import { Upload, Database, CheckCircle2, ShieldCheck, RefreshCw, FileCode, AlertCircle } from "lucide-react";

export const SettingsView: React.FC = () => {
  const [report, setReport] = useState<string>(
    `[Data Quality & Database Validation Audit Report]
✔ Database Connected: DuckDB (database/ecommerce.duckdb)
✔ Orders Dataset: 50,000 valid orders parsed
✔ Products Database: 500 active SKUs mapped
✔ Customers Database: 20,000 unique customer IDs
✔ Duplicate Check: 0 duplicate order IDs
✔ Missing Values: 0 missing revenue fields
✔ Currency Standardisation: Base currency GBP (£)`
  );

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Database Connection Status */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Database className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight">
            Analytical Database & Storage Pipeline
          </h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
          <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-slate-500 dark:text-slate-400">Database Engine</span>
            <p className="font-bold text-emerald-600 dark:text-emerald-400 mt-1">DuckDB v0.9+</p>
          </div>
          <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-slate-500 dark:text-slate-400">R Runtime Engine</span>
            <p className="font-bold text-blue-600 dark:text-blue-400 mt-1">R v4.2.2 Linux</p>
          </div>
          <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-slate-500 dark:text-slate-400">Record Count</span>
            <p className="font-bold text-slate-800 dark:text-white mt-1">50,000 Orders</p>
          </div>
        </div>
      </div>

      {/* CSV File Upload & Validation */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Upload className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-white font-mono uppercase tracking-tight">
            Data Import & Validation Pipeline
          </h3>
        </div>
        <div className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-6 text-center bg-slate-50 dark:bg-slate-950/60 mb-4">
          <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            Drag & drop custom orders.csv, products.csv or marketing.csv here
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Supports CSV, Parquet, JSON formats up to 100MB</p>
          <input type="file" className="hidden" id="fileInput" />
          <label
            htmlFor="fileInput"
            className="inline-block mt-3 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer shadow-xs font-mono uppercase tracking-wider"
          >
            Select File
          </label>
        </div>

        {/* Audit Log */}
        <pre className="bg-slate-900 dark:bg-slate-950 text-emerald-400 p-4 rounded-xl border border-slate-800 text-xs font-mono leading-relaxed overflow-x-auto">
          {report}
        </pre>
      </div>
    </div>
  );
};
