export type Currency = "GBP" | "USD" | "EUR" | "CAD" | "AUD";
export type TimePeriod = "today" | "7d" | "30d" | "90d" | "ytd" | "custom";
export type ViewTab =
  | "overview"
  | "sales"
  | "products"
  | "customers"
  | "inventory"
  | "marketing"
  | "profitability"
  | "forecasting"
  | "optimisation"
  | "settings";

export interface KPIMetric {
  value: number;
  prev: number;
  pct?: number;
  pp?: number;
}

export interface OverviewMetrics {
  revenue: KPIMetric;
  orders: KPIMetric;
  units: KPIMetric;
  aov: KPIMetric;
  grossProfit: KPIMetric;
  grossMargin: KPIMetric;
  netProfit: KPIMetric;
  conversionRate: KPIMetric;
}

export interface WaterfallItem {
  stage: string;
  amount: number;
  impact: number;
  category: string;
}

export interface ProductItem {
  sku: string;
  product_name: string;
  category: string;
  units_sold: number;
  revenue: number;
  cogs: number;
  sale_price: number;
  gross_profit: number;
  gross_margin: number;
  contribution_profit: number;
  return_rate: number;
  quadrant: "STARS" | "WINNERS" | "VOLUME" | "WEAK";
}

export interface InventoryItem {
  sku: string;
  product_name: string;
  category: string;
  stock_on_hand: number;
  stock_reserved: number;
  daily_demand: number;
  days_of_inventory: number;
  reorder_point: number;
  lead_time_days: number;
  status: "HEALTHY" | "LOW STOCK" | "OUT OF STOCK" | "OVERSTOCKED" | "DEAD STOCK";
  recommended_reorder: number;
  expected_stockout_date: string;
}

export interface RFMSegment {
  name: string;
  count: number;
  avgSpend: number;
  color: string;
}

export interface ChannelPerformance {
  channel: string;
  spend: number;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
  roas: number;
  croas: number;
}

export interface PnLRow {
  category: string;
  amount: number;
  pct: string;
  type: "revenue" | "deduction" | "addition" | "subtotal" | "cost" | "total";
}

export interface CommercialAlert {
  id: number;
  type: "danger" | "warning" | "success" | "info";
  title: string;
  message: string;
  impact: string;
}
