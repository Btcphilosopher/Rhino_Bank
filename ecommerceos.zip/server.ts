import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import { exec } from "child_process";
import { createServer as createViteServer } from "vite";

interface Product {
  sku: string;
  product_name: string;
  category: string;
  cogs: number;
  sale_price: number;
  min_reorder_point: number;
  lead_time_days: number;
}

interface Order {
  order_id: string;
  order_date: string;
  customer_id: string;
  currency: string;
  total_units: number;
  acquisition_channel: string;
  country: string;
  gross_subtotal: number;
  discount_amount: number;
  is_returned: boolean;
  return_amount: number;
  refund_amount: number;
  return_processing_cost: number;
  shipping_charged: number;
  actual_shipping_cost: number;
  tax_amount: number;
  total_cogs: number;
  payment_processing_fee: number;
  marketing_attribution_cost: number;
}

interface Customer {
  customer_id: string;
  customer_name: string;
  email: string;
  country: string;
  acquisition_channel: string;
  created_at: string;
}

interface InventoryRecord {
  sku: string;
  stock_on_hand: number;
  stock_reserved: number;
  reorder_point: number;
  lead_time_days: number;
  last_restock_date: string;
}

interface MarketingRecord {
  date: string;
  channel: string;
  spend: number;
  impressions: number;
  clicks: number;
  conversions: number;
}

// In-Memory Cached Data Store
let products: Product[] = [];
let orders: Order[] = [];
let customers: Customer[] = [];
let inventory: InventoryRecord[] = [];
let marketing: MarketingRecord[] = [];

// Helper to parse simple CSV
function parseCSV<T>(filePath: string, mapper: (row: Record<string, string>) => T): T[] {
  if (!fs.existsSync(filePath)) return [];
  const content = fs.readFileSync(filePath, "utf-8");
  const lines = content.split("\n").filter(l => l.trim().length > 0);
  if (lines.length < 2) return [];
  
  const headers = lines[0].split(",").map(h => h.replace(/^"|"$/g, "").trim());
  const results: T[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(",").map(v => v.replace(/^"|"$/g, "").trim());
    if (values.length < headers.length) continue;
    const obj: Record<string, string> = {};
    headers.forEach((h, idx) => {
      obj[h] = values[idx];
    });
    results.push(mapper(obj));
  }
  return results;
}

function loadData() {
  const dataDir = path.join(process.cwd(), "ecommerce_os", "data");
  
  products = parseCSV(path.join(dataDir, "products.csv"), r => ({
    sku: r.sku,
    product_name: r.product_name,
    category: r.category,
    cogs: parseFloat(r.cogs || "0"),
    sale_price: parseFloat(r.sale_price || "0"),
    min_reorder_point: parseInt(r.min_reorder_point || "10", 10),
    lead_time_days: parseInt(r.lead_time_days || "7", 10)
  }));

  customers = parseCSV(path.join(dataDir, "customers.csv"), r => ({
    customer_id: r.customer_id,
    customer_name: r.customer_name,
    email: r.email,
    country: r.country,
    acquisition_channel: r.acquisition_channel,
    created_at: r.created_at
  }));

  inventory = parseCSV(path.join(dataDir, "inventory.csv"), r => ({
    sku: r.sku,
    stock_on_hand: parseInt(r.stock_on_hand || "0", 10),
    stock_reserved: parseInt(r.stock_reserved || "0", 10),
    reorder_point: parseInt(r.reorder_point || "10", 10),
    lead_time_days: parseInt(r.lead_time_days || "7", 10),
    last_restock_date: r.last_restock_date
  }));

  marketing = parseCSV(path.join(dataDir, "marketing.csv"), r => ({
    date: r.date,
    channel: r.channel,
    spend: parseFloat(r.spend || "0"),
    impressions: parseInt(r.impressions || "0", 10),
    clicks: parseInt(r.clicks || "0", 10),
    conversions: parseInt(r.conversions || "0", 10)
  }));

  orders = parseCSV(path.join(dataDir, "orders.csv"), r => ({
    order_id: r.order_id,
    order_date: r.order_date,
    customer_id: r.customer_id,
    currency: r.currency || "GBP",
    total_units: parseInt(r.total_units || "1", 10),
    acquisition_channel: r.acquisition_channel || "Direct",
    country: r.country || "United Kingdom",
    gross_subtotal: parseFloat(r.gross_subtotal || "0"),
    discount_amount: parseFloat(r.discount_amount || "0"),
    is_returned: r.is_returned === "TRUE" || r.is_returned === "true",
    return_amount: parseFloat(r.return_amount || "0"),
    refund_amount: parseFloat(r.refund_amount || "0"),
    return_processing_cost: parseFloat(r.return_processing_cost || "0"),
    shipping_charged: parseFloat(r.shipping_charged || "0"),
    actual_shipping_cost: parseFloat(r.actual_shipping_cost || "0"),
    tax_amount: parseFloat(r.tax_amount || "0"),
    total_cogs: parseFloat(r.total_cogs || "0"),
    payment_processing_fee: parseFloat(r.payment_processing_fee || "0"),
    marketing_attribution_cost: parseFloat(r.marketing_attribution_cost || "0")
  }));

  console.log(`[EcommerceOS Data Engine] Loaded ${products.length} products, ${customers.length} customers, ${orders.length} orders.`);
}

loadData();

function filterOrdersByPeriod(period: string, customStart?: string, customEnd?: string) {
  if (orders.length === 0) return [];
  
  // Find max date in dataset
  const dates = orders.map(o => new Date(o.order_date).getTime()).filter(t => !isNaN(t));
  const maxTime = Math.max(...dates);
  const maxDate = new Date(maxTime);
  
  let daysToSubtract = 30;
  if (period === "today") daysToSubtract = 0;
  if (period === "7d") daysToSubtract = 6;
  if (period === "30d") daysToSubtract = 29;
  if (period === "90d") daysToSubtract = 89;
  if (period === "ytd") {
    const yearStart = new Date(maxDate.getFullYear(), 0, 1);
    daysToSubtract = Math.floor((maxDate.getTime() - yearStart.getTime()) / (1000 * 60 * 60 * 24));
  }
  
  let startTime = maxTime - daysToSubtract * 24 * 60 * 60 * 1000;
  let endTime = maxTime;

  if (period === "custom" && customStart && customEnd) {
    startTime = new Date(customStart).getTime();
    endTime = new Date(customEnd).getTime();
  }

  return orders.filter(o => {
    const t = new Date(o.order_date).getTime();
    return t >= startTime && t <= endTime;
  });
}

function getPreviousPeriodOrders(filtered: Order[], period: string) {
  if (filtered.length === 0) return [];
  const times = filtered.map(o => new Date(o.order_date).getTime());
  const minTime = Math.min(...times);
  const maxTime = Math.max(...times);
  const duration = maxTime - minTime + (24 * 60 * 60 * 1000);

  const prevStart = minTime - duration;
  const prevEnd = minTime - 1;

  return orders.filter(o => {
    const t = new Date(o.order_date).getTime();
    return t >= prevStart && t <= prevEnd;
  });
}

async function startServer() {
  const app = express();
  app.use(express.json());
  const PORT = 3000;

  // --- API ROUTES ---

  // 1. Overview API
  app.get("/api/overview", (req: Request, res: Response) => {
    const period = (req.query.period as string) || "30d";
    const currentOrders = filterOrdersByPeriod(period);
    const prevOrders = getPreviousPeriodOrders(currentOrders, period);

    const calcMetrics = (ords: Order[]) => {
      const grossSales = ords.reduce((sum, o) => sum + o.gross_subtotal, 0);
      const discounts = ords.reduce((sum, o) => sum + o.discount_amount, 0);
      const returns = ords.reduce((sum, o) => sum + o.return_amount, 0);
      const refunds = ords.reduce((sum, o) => sum + o.refund_amount, 0);
      const shippingRev = ords.reduce((sum, o) => sum + o.shipping_charged, 0);
      const netRevenue = grossSales - discounts - returns - refunds + shippingRev;
      
      const cogs = ords.reduce((sum, o) => sum + o.total_cogs, 0);
      const grossProfit = netRevenue - cogs;
      const grossMargin = netRevenue > 0 ? grossProfit / netRevenue : 0;
      
      const shippingCost = ords.reduce((sum, o) => sum + o.actual_shipping_cost, 0);
      const paymentFees = ords.reduce((sum, o) => sum + o.payment_processing_fee, 0);
      const mktgCost = ords.reduce((sum, o) => sum + o.marketing_attribution_cost, 0);
      const returnCosts = ords.reduce((sum, o) => sum + o.return_processing_cost, 0);
      const opex = (ords.length > 0 ? 350 * 30 : 0);

      const contributionProfit = grossProfit - shippingCost - paymentFees - mktgCost - returnCosts;
      const netProfit = contributionProfit - opex;

      const orderCount = ords.length;
      const unitsSold = ords.reduce((sum, o) => sum + o.total_units, 0);
      const aov = orderCount > 0 ? netRevenue / orderCount : 0;
      const conversionRate = 0.0285 + (Math.random() * 0.004 - 0.002);

      return {
        grossSales, discounts, returns, refunds, shippingRev, netRevenue,
        cogs, grossProfit, grossMargin, shippingCost, paymentFees, mktgCost,
        contributionProfit, netProfit, orderCount, unitsSold, aov, conversionRate
      };
    };

    const curr = calcMetrics(currentOrders);
    const prev = calcMetrics(prevOrders);

    const calcPct = (c: number, p: number) => p > 0 ? ((c - p) / p) * 100 : 0;

    res.json({
      metrics: {
        revenue: { value: curr.netRevenue, prev: prev.netRevenue, pct: calcPct(curr.netRevenue, prev.netRevenue) },
        orders: { value: curr.orderCount, prev: prev.orderCount, pct: calcPct(curr.orderCount, prev.orderCount) },
        units: { value: curr.unitsSold, prev: prev.unitsSold, pct: calcPct(curr.unitsSold, prev.unitsSold) },
        aov: { value: curr.aov, prev: prev.aov, pct: calcPct(curr.aov, prev.aov) },
        grossProfit: { value: curr.grossProfit, prev: prev.grossProfit, pct: calcPct(curr.grossProfit, prev.grossProfit) },
        grossMargin: { value: curr.grossMargin * 100, prev: prev.grossMargin * 100, pp: (curr.grossMargin - prev.grossMargin) * 100 },
        netProfit: { value: curr.netProfit, prev: prev.netProfit, pct: calcPct(curr.netProfit, prev.netProfit) },
        conversionRate: { value: curr.conversionRate * 100, prev: prev.conversionRate * 100, pp: (curr.conversionRate - prev.conversionRate) * 100 }
      },
      waterfall: [
        { stage: "Gross Sales", amount: curr.grossSales, impact: curr.grossSales, category: "Gross" },
        { stage: "Discounts", amount: curr.discounts, impact: -curr.discounts, category: "Deduction" },
        { stage: "Returns", amount: curr.returns, impact: -curr.returns, category: "Deduction" },
        { stage: "Refunds", amount: curr.refunds, impact: -curr.refunds, category: "Deduction" },
        { stage: "Shipping Rev", amount: curr.shippingRev, impact: curr.shippingRev, category: "Addition" },
        { stage: "Net Revenue", amount: curr.netRevenue, impact: curr.netRevenue, category: "Net Operating Revenue" }
      ],
      executiveSummary: [
        `Net Revenue reached £${curr.netRevenue.toLocaleString(undefined, {maximumFractionDigits: 0})}, representing a ${calcPct(curr.netRevenue, prev.netRevenue).toFixed(1)}% change versus previous period.`,
        `Gross margin stands at ${(curr.grossMargin * 100).toFixed(1)}% with an average order value of £${curr.aov.toFixed(2)}.`,
        `Contribution profit after marketing and fulfillment is £${curr.contributionProfit.toLocaleString(undefined, {maximumFractionDigits: 0})}.`,
        `Commercial Priority: Reallocate marketing spend from underperforming channels to boost high-margin categories.`
      ]
    });
  });

  // 2. Sales API
  app.get("/api/sales", (req: Request, res: Response) => {
    const period = (req.query.period as string) || "30d";
    const ords = filterOrdersByPeriod(period);

    // Group by Date
    const dailyMap: Record<string, { revenue: number; orders: number; units: number }> = {};
    ords.forEach(o => {
      const d = o.order_date;
      if (!dailyMap[d]) dailyMap[d] = { revenue: 0, orders: 0, units: 0 };
      const net = o.gross_subtotal - o.discount_amount - o.return_amount + o.shipping_charged;
      dailyMap[d].revenue += net;
      dailyMap[d].orders += 1;
      dailyMap[d].units += o.total_units;
    });

    const timeSeries = Object.keys(dailyMap).sort().map(d => ({
      date: d,
      revenue: Math.round(dailyMap[d].revenue),
      orders: dailyMap[d].orders,
      units: dailyMap[d].units,
      aov: dailyMap[d].orders > 0 ? Math.round(dailyMap[d].revenue / dailyMap[d].orders) : 0
    }));

    // Category breakdown
    const categoryMap: Record<string, number> = {};
    ords.forEach(o => {
      const cat = o.acquisition_channel === "Google Ads" ? "Apparel" :
                  o.acquisition_channel === "Meta Ads" ? "Footwear" :
                  o.acquisition_channel === "TikTok" ? "Beauty" : "Electronics";
      const net = o.gross_subtotal - o.discount_amount;
      categoryMap[cat] = (categoryMap[cat] || 0) + net;
    });

    // Country breakdown
    const countryMap: Record<string, number> = {};
    ords.forEach(o => {
      const c = o.country || "United Kingdom";
      const net = o.gross_subtotal - o.discount_amount;
      countryMap[c] = (countryMap[c] || 0) + net;
    });

    res.json({
      timeSeries,
      categories: Object.keys(categoryMap).map(k => ({ name: k, value: Math.round(categoryMap[k]) })),
      countries: Object.keys(countryMap).map(k => ({ country: k, revenue: Math.round(countryMap[k]) }))
    });
  });

  // 3. Products API
  app.get("/api/products", (req: Request, res: Response) => {
    const period = (req.query.period as string) || "30d";
    const ords = filterOrdersByPeriod(period);

    // Aggregate sales per product
    const productStats: Record<string, { units: number; revenue: number; cogs: number; returns: number }> = {};
    ords.forEach(o => {
      // Assign pseudo SKU for simulation
      const skuIndex = (parseInt(o.order_id.replace(/\D/g, ""), 10) % products.length);
      const prod = products[skuIndex] || products[0];
      if (!prod) return;

      if (!productStats[prod.sku]) productStats[prod.sku] = { units: 0, revenue: 0, cogs: 0, returns: 0 };
      const net = o.gross_subtotal - o.discount_amount;
      productStats[prod.sku].units += o.total_units;
      productStats[prod.sku].revenue += net;
      productStats[prod.sku].cogs += o.total_cogs;
      if (o.is_returned) productStats[prod.sku].returns += o.total_units;
    });

    const enriched = products.map(p => {
      const st = productStats[p.sku] || { units: Math.floor(Math.random() * 200), revenue: 0, cogs: 0, returns: 0 };
      if (st.revenue === 0) st.revenue = st.units * p.sale_price;
      if (st.cogs === 0) st.cogs = st.units * p.cogs;

      const grossProfit = st.revenue - st.cogs;
      const grossMargin = st.revenue > 0 ? (grossProfit / st.revenue) * 100 : 0;
      const contributionProfit = grossProfit - (st.revenue * 0.12) - (st.units * 3.10);
      const returnRate = st.units > 0 ? (st.returns / st.units) * 100 : Math.random() * 8;

      let quadrant = "WEAK";
      if (st.units >= 100 && contributionProfit >= 1500) quadrant = "STARS";
      else if (st.units < 100 && contributionProfit >= 1500) quadrant = "WINNERS";
      else if (st.units >= 100 && contributionProfit < 1500) quadrant = "VOLUME";

      return {
        sku: p.sku,
        product_name: p.product_name,
        category: p.category,
        units_sold: st.units,
        revenue: Math.round(st.revenue),
        cogs: p.cogs,
        sale_price: p.sale_price,
        gross_profit: Math.round(grossProfit),
        gross_margin: parseFloat(grossMargin.toFixed(1)),
        contribution_profit: Math.round(contributionProfit),
        return_rate: parseFloat(returnRate.toFixed(1)),
        quadrant
      };
    });

    res.json(enriched);
  });

  // 4. Inventory API
  app.get("/api/inventory", (req: Request, res: Response) => {
    const list = inventory.map(inv => {
      const prod = products.find(p => p.sku === inv.sku) || { product_name: "Product", category: "General", sale_price: 50 };
      const dailyDemand = (inv.stock_on_hand / 30) * (0.8 + Math.random() * 0.4);
      const daysOfInventory = dailyDemand > 0 ? Math.floor(inv.stock_on_hand / dailyDemand) : 999;

      let status = "HEALTHY";
      if (inv.stock_on_hand === 0) status = "OUT OF STOCK";
      else if (inv.stock_on_hand <= inv.reorder_point) status = "LOW STOCK";
      else if (daysOfInventory > 120) status = "OVERSTOCKED";
      else if (dailyDemand < 0.2) status = "DEAD STOCK";

      const recommendedReorder = status === "LOW STOCK" || status === "OUT OF STOCK" ? Math.max(100, Math.ceil(dailyDemand * 60) - inv.stock_on_hand) : 0;

      return {
        sku: inv.sku,
        product_name: prod.product_name,
        category: prod.category,
        stock_on_hand: inv.stock_on_hand,
        stock_reserved: inv.stock_reserved,
        daily_demand: parseFloat(dailyDemand.toFixed(1)),
        days_of_inventory: daysOfInventory,
        reorder_point: inv.reorder_point,
        lead_time_days: inv.lead_time_days,
        status,
        recommended_reorder: recommendedReorder,
        expected_stockout_date: new Date(Date.now() + daysOfInventory * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
      };
    });

    res.json(list);
  });

  // 5. Customers & RFM API
  app.get("/api/customers", (req: Request, res: Response) => {
    const segments = [
      { name: "Champions", count: 2450, avgSpend: 420, color: "#10b981" },
      { name: "Loyal", count: 4800, avgSpend: 280, color: "#3b82f6" },
      { name: "Potential Loyalists", count: 3200, avgSpend: 190, color: "#6366f1" },
      { name: "New Customers", count: 5100, avgSpend: 85, color: "#f59e0b" },
      { name: "At Risk", count: 2900, avgSpend: 210, color: "#ef4444" },
      { name: "Lost", count: 1550, avgSpend: 65, color: "#64748b" }
    ];

    const ltvCac = [
      { metric: "CAC", value: 32.5 },
      { metric: "Observed 30D LTV", value: 48.2 },
      { metric: "Observed 90D LTV", value: 89.4 },
      { metric: "Forecast 1-Year LTV", value: 165.0 },
      { metric: "LTV / CAC Ratio", value: 5.08 }
    ];

    res.json({ segments, ltvCac });
  });

  // 6. Marketing API
  app.get("/api/marketing", (req: Request, res: Response) => {
    const channelStats = [
      { channel: "Google Ads", spend: 18500, impressions: 420000, clicks: 18500, conversions: 920, revenue: 82500, roas: 4.46, croas: 2.15 },
      { channel: "Meta Ads", spend: 14200, impressions: 680000, clicks: 22400, conversions: 610, revenue: 48200, roas: 3.39, croas: 1.58 },
      { channel: "TikTok Ads", spend: 6800, impressions: 390000, clicks: 14200, conversions: 240, revenue: 16800, roas: 2.47, croas: 0.95 },
      { channel: "Email", spend: 1200, impressions: 95000, clicks: 12400, conversions: 580, revenue: 38400, roas: 32.0, croas: 16.2 },
      { channel: "Affiliate", spend: 4200, impressions: 110000, clicks: 4800, conversions: 210, revenue: 19500, roas: 4.64, croas: 2.10 }
    ];

    res.json(channelStats);
  });

  // 7. Profitability P&L API
  app.get("/api/profitability", (req: Request, res: Response) => {
    const pnl = [
      { category: "Gross Sales", amount: 320000, pct: "112.6%", type: "revenue" },
      { category: "Discounts & Promo", amount: -21200, pct: "-7.5%", type: "deduction" },
      { category: "Returns & Refunds", amount: -23800, pct: "-8.4%", type: "deduction" },
      { category: "Shipping Charged", amount: 9210, pct: "3.2%", type: "addition" },
      { category: "Net Operating Revenue", amount: 284210, pct: "100.0%", type: "subtotal" },
      { category: "Cost of Goods Sold (COGS)", amount: -159720, pct: "-56.2%", type: "cost" },
      { category: "Gross Profit", amount: 124490, pct: "43.8%", type: "subtotal" },
      { category: "Shipping & Fulfillment Expense", amount: -23500, pct: "-8.3%", type: "cost" },
      { category: "Payment Processing Fees", amount: -7105, pct: "-2.5%", type: "cost" },
      { category: "Marketing & Advertising Spend", amount: -44965, pct: "-15.8%", type: "cost" },
      { category: "Returns Processing & Stock Loss", amount: -3850, pct: "-1.4%", type: "cost" },
      { category: "Contribution Profit", amount: 45070, pct: "15.9%", type: "subtotal" },
      { category: "Fixed Operating Expenses (OpEx)", amount: -10500, pct: "-3.7%", type: "cost" },
      { category: "Net Operating Profit", amount: 34570, pct: "12.2%", type: "total" }
    ];

    res.json(pnl);
  });

  // 8. Forecasting API
  app.get("/api/forecasting", (req: Request, res: Response) => {
    const forecast = [];
    const baseRev = 9200;
    for (let i = 1; i <= 30; i++) {
      const point = baseRev + i * 45 + Math.sin(i / 2) * 400;
      forecast.push({
        day: i,
        date: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        point: Math.round(point),
        lower80: Math.round(point * 0.88),
        upper80: Math.round(point * 1.12),
        lower95: Math.round(point * 0.81),
        upper95: Math.round(point * 1.19)
      });
    }
    res.json(forecast);
  });

  // 9. Profit Optimisation & What-If Simulation API
  app.post("/api/optimisation/simulate", (req: Request, res: Response) => {
    const { priceChangePct = 0, currentPrice = 49.99, cogs = 18.0, elasticity = -1.6, currentVolume = 1000 } = req.body;

    const pct_p = priceChangePct / 100;
    const newPrice = currentPrice * (1 + pct_p);
    const pct_q = elasticity * pct_p;
    const newVolume = Math.max(0, currentVolume * (1 + pct_q));

    const revenue = newPrice * newVolume;
    const totalCogs = cogs * newVolume;
    const grossProfit = (newPrice - cogs) * newVolume;
    const contributionProfit = grossProfit - (revenue * 0.12) - (newVolume * 3.50);

    res.json({
      priceChangePct,
      newPrice: parseFloat(newPrice.toFixed(2)),
      expectedUnits: Math.round(newVolume),
      revenue: Math.round(revenue),
      grossProfit: Math.round(grossProfit),
      contributionProfit: Math.round(contributionProfit),
      grossMarginPct: parseFloat(((grossProfit / revenue) * 100).toFixed(1))
    });
  });

  // 10. Commercial Alerts API
  app.get("/api/alerts", (req: Request, res: Response) => {
    res.json([
      { id: 1, type: "danger", title: "Stockout Warning", message: "Product SKU-0012 projected to stock out in 4 days. 180 units recommended for reorder.", impact: "High Impact" },
      { id: 2, type: "warning", title: "Margin Compression", message: "Gross margin decreased 2.1pp due to rising fulfillment & shipping surcharges.", impact: "Medium Impact" },
      { id: 3, type: "warning", title: "TikTok ROAS Decline", message: "TikTok CPA rose 18% with Contribution ROAS dropping below 1.0 (0.95).", impact: "High Impact" },
      { id: 4, type: "success", title: "Email Revenue Surge", message: "Repeat purchase flow revenue increased +28% following VIP discount campaign.", impact: "Positive" }
    ]);
  });

  // 11. Interactive R Console API
  app.post("/api/r-console", (req: Request, res: Response) => {
    const { code } = req.body;
    if (!code || typeof code !== "string") {
      res.status(400).json({ error: "No R code provided" });
      return;
    }

    // Escape R code safely
    const escapedCode = code.replace(/"/g, '\\"');
    const command = `R_HOME=/usr/lib/R R --vanilla --slave -e "options(editor='cat'); source('ecommerce_os/R/utilities.R'); source('ecommerce_os/R/metrics.R'); source('ecommerce_os/R/revenue_engine.R'); source('ecommerce_os/R/profit_engine.R'); source('ecommerce_os/R/optimisation_engine.R'); ${escapedCode}"`;

    exec(command, { cwd: process.cwd(), timeout: 10000 }, (error, stdout, stderr) => {
      res.json({
        code,
        output: stdout || (error ? error.message : "Executed successfully with no output"),
        error: stderr || null
      });
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[EcommerceOS] Full-stack application running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
