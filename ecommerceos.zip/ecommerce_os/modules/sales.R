# Sales Module UI & Server
sales_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_columns(
      card(card_header("Revenue Trend Over Time"), plotlyOutput(ns("sales_trend"))),
      card(card_header("Sales By Category"), plotlyOutput(ns("category_pie")))
    )
  )
}

sales_server <- function(id, data_store) {
  moduleServer(id, function(input, output, session) {
    output$sales_trend <- renderPlotly({
      plot_ly(x = 1:30, y = cumsum(rnorm(30, 5000, 500)), type = "scatter", mode = "lines+markers")
    })
    output$category_pie <- renderPlotly({
      plot_ly(labels = c("Apparel", "Electronics", "Home & Kitchen", "Beauty"), values = c(40, 25, 20, 15), type = "pie")
    })
  })
}
