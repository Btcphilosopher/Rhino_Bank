# Profitability Module UI & Server
profitability_ui <- function(id) {
  ns <- NS(id)
  tagList(
    card(card_header("Full Commercial P&L Breakdown"), DTOutput(ns("pnl_table")))
  )
}

profitability_server <- function(id, data_store) {
  moduleServer(id, function(input, output, session) {
    output$pnl_table <- renderDT({
      datatable(data.frame(
        LineItem = c("Gross Revenue", "Discounts & Returns", "Net Revenue", "COGS", "Gross Profit", "Shipping & Fulfillment", "Payment Processing", "Marketing Spend", "Contribution Profit", "Operating Expenses", "Net Profit"),
        Amount = c("£320,000", "-£35,790", "£284,210", "-£159,720", "£124,490", "-£23,500", "-£7,105", "-£44,965", "£48,920", "-£10,500", "£38,420"),
        PctRevenue = c("112.6%", "-12.6%", "100.0%", "56.2%", "43.8%", "8.3%", "2.5%", "15.8%", "17.2%", "3.7%", "13.5%")
      ))
    })
  })
}
