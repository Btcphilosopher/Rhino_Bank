# Inventory Module UI & Server
inventory_ui <- function(id) {
  ns <- NS(id)
  tagList(
    card(card_header("Inventory Stockout Risk & Reorder Timeline"), DTOutput(ns("inventory_table")))
  )
}

inventory_server <- function(id, data_store) {
  moduleServer(id, function(input, output, session) {
    output$inventory_table <- renderDT({
      datatable(data.frame(
        SKU = c("SKU-101", "SKU-205", "SKU-309"),
        StockOnHand = c(120, 15, 850),
        DailyDemand = c(12.5, 4.2, 1.1),
        StockoutDate = c("10 Days", "3 Days", "750 Days"),
        Status = c("Healthy", "LOW STOCK", "OVERSTOCKED"),
        ReorderQty = c(300, 200, 0)
      ))
    })
  })
}
