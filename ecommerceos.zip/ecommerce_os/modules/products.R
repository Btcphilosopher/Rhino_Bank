# Products Module UI & Server
products_ui <- function(id) {
  ns <- NS(id)
  tagList(
    card(card_header("Product Performance Matrix (2x2)"), plotlyOutput(ns("matrix_plot"))),
    card(card_header("SKU Performance Table"), DTOutput(ns("products_table")))
  )
}

products_server <- function(id, data_store) {
  moduleServer(id, function(input, output, session) {
    output$matrix_plot <- renderPlotly({
      plot_ly(x = c(10, 50, 80, 20), y = c(80, 70, 20, 10), text = c("SKU-1", "SKU-2", "SKU-3", "SKU-4"),
              type = "scatter", mode = "markers+text")
    })
    output$products_table <- renderDT({
      datatable(data.frame(
        SKU = c("SKU-101", "SKU-102", "SKU-103"),
        Product = c("Wireless Earbuds", "Leather Wallet", "Ergonomic Chair"),
        Units = c(1200, 850, 420),
        Revenue = c(59990, 34000, 105000),
        Margin = c("54.2%", "62.1%", "38.5%"),
        Status = c("Stars", "Winners", "Volume")
      ))
    })
  })
}
