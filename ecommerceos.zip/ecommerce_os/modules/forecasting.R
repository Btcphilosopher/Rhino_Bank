# Forecasting Module UI & Server
forecasting_ui <- function(id) {
  ns <- NS(id)
  tagList(
    card(card_header("30-Day Revenue & Demand Forecast with 80% & 95% CIs"), plotlyOutput(ns("forecast_plot")))
  )
}

forecasting_server <- function(id, data_store) {
  moduleServer(id, function(input, output, session) {
    output$forecast_plot <- renderPlotly({
      days <- 1:30
      pred <- 9000 + days * 50
      plot_ly() %>%
        add_lines(x = days, y = pred, name = "Forecast") %>%
        add_ribbons(x = days, ymin = pred * 0.85, ymax = pred * 1.15, name = "80% CI", opacity = 0.3)
    })
  })
}
