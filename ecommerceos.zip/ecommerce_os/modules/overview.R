# Overview Module UI & Server
overview_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_columns(
      value_box("Net Revenue", "$284,210", showcase = icon("dollar-sign")),
      value_box("Orders", "8,421", showcase = icon("shopping-cart")),
      value_box("Gross Margin", "43.8%", showcase = icon("percent")),
      value_box("Net Profit", "$48,920", showcase = icon("coins"))
    ),
    card(card_header("Commercial Performance & Revenue Waterfall"), plotlyOutput(ns("waterfall_plot")))
  )
}

overview_server <- function(id, data_store) {
  moduleServer(id, function(input, output, session) {
    output$waterfall_plot <- renderPlotly({
      plot_ly(x = c("Gross Sales", "Discounts", "Returns", "Shipping", "Net Revenue"),
              y = c(320000, -20000, -25000, 9210, 284210),
              type = "bar",
              marker = list(color = c("#3b82f6", "#ef4444", "#ef4444", "#10b981", "#6366f1")))
    })
  })
}
