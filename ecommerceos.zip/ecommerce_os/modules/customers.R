# Customers Module UI & Server
customers_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_columns(
      card(card_header("RFM Customer Segmentation"), plotlyOutput(ns("rfm_bar"))),
      card(card_header("LTV / CAC Economics"), plotlyOutput(ns("ltv_cac_chart")))
    )
  )
}

customers_server <- function(id, data_store) {
  moduleServer(id, function(input, output, session) {
    output$rfm_bar <- renderPlotly({
      plot_ly(x = c("Champions", "Loyal", "Potential", "At Risk", "Lost"), y = c(1200, 3400, 2100, 850, 420), type = "bar")
    })
    output$ltv_cac_chart <- renderPlotly({
      plot_ly(x = c("CAC", "30D LTV", "90D LTV", "1Y LTV"), y = c(32, 48, 85, 142), type = "bar")
    })
  })
}
