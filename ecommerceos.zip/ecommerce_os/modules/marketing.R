# Marketing Module UI & Server
marketing_ui <- function(id) {
  ns <- NS(id)
  tagList(
    card(card_header("Channel Spend vs Attributed Revenue & ROAS"), plotlyOutput(ns("roas_chart")))
  )
}

marketing_server <- function(id, data_store) {
  moduleServer(id, function(input, output, session) {
    output$roas_chart <- renderPlotly({
      plot_ly(x = c("Google Ads", "Meta Ads", "TikTok", "Email", "Affiliate"),
              y = c(4.2, 3.1, 2.4, 8.5, 5.2),
              name = "ROAS", type = "bar")
    })
  })
}
