# EcommerceOS - Automated R Test Suite

source("ecommerce_os/R/utilities.R")
source("ecommerce_os/R/metrics.R")
source("ecommerce_os/R/revenue_engine.R")
source("ecommerce_os/R/profit_engine.R")
source("ecommerce_os/R/optimisation_engine.R")

cat("Running EcommerceOS R Calculations Tests...\n")

# Test 1: AOV & Margins
stopifnot(calculate_aov(1000, 10) == 100)
stopifnot(calculate_gross_margin(40, 100) == 0.40)
cat("✔ Test 1 Passed: Core metrics formulas verified\n")

# Test 2: Waterfall Calculation
sample_orders <- data.frame(
  gross_subtotal = c(100, 200),
  discount_amount = c(10, 20),
  return_amount = c(0, 30),
  refund_amount = c(0, 0),
  shipping_charged = c(5, 5),
  tax_amount = c(18, 32)
)
wf <- calculate_revenue_waterfall(sample_orders)
net_rev <- wf[wf$stage == "Net Revenue", "amount"]
stopifnot(net_rev == (300 - 30 - 30 + 10))
cat("✔ Test 2 Passed: Revenue Waterfall Accounting verified\n")

# Test 3: Profit Optimizer
opt <- profit_optimizer(current_price = 50, cogs = 15, shipping_cost = 3, ad_spend_per_unit = 5, current_volume = 1000, price_elasticity = -1.5)
stopifnot(!is.null(opt$optimal_price))
cat("✔ Test 3 Passed: Profit Optimisation Engine verified\n")

cat("ALL R TESTS PASSED SUCCESSFULLY!\n")
