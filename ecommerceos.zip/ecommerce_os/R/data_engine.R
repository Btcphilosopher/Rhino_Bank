# EcommerceOS - Data Generation, Loading & DuckDB Integration Engine

suppressPackageStartupMessages({
  if (requireNamespace("stats", quietly = TRUE)) library(stats)
  if (requireNamespace("utils", quietly = TRUE)) library(utils)
})

generate_synthetic_dataset <- function(output_dir = "ecommerce_os/data") {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  set.seed(42)
  
  cat("Generating realistic synthetic e-commerce dataset...\n")
  
  # 1. Products (500 SKUs)
  categories <- c("Apparel", "Footwear", "Electronics", "Home & Living", "Beauty & Care", "Accessories", "Sports & Fitness")
  num_products <- 500
  
  products <- data.frame(
    sku = sprintf("SKU-%04d", 1:num_products),
    product_name = sprintf("Product %d", 1:num_products),
    category = sample(categories, num_products, replace = TRUE, prob = c(0.25, 0.15, 0.20, 0.15, 0.10, 0.10, 0.05)),
    cogs = round(runif(num_products, 5, 120), 2),
    markup = runif(num_products, 1.4, 3.2)
  )
  products$sale_price <- round(products$cogs * products$markup, 2)
  products$markup <- NULL
  products$min_reorder_point <- sample(10:100, num_products, replace = TRUE)
  products$lead_time_days <- sample(3:21, num_products, replace = TRUE)
  
  write.csv(products, file.path(output_dir, "products.csv"), row.names = FALSE)
  
  # 2. Customers (20,000)
  num_customers <- 20000
  countries <- c("United Kingdom", "United States", "Germany", "France", "Canada", "Australia")
  channels  <- c("Google Ads", "Meta Ads", "TikTok", "Email", "Organic Search", "Affiliate", "Direct")
  
  customers <- data.frame(
    customer_id = sprintf("CUST-%05d", 1:num_customers),
    customer_name = sprintf("User %d", 1:num_customers),
    email = sprintf("user%d@example.com", 1:num_customers),
    country = sample(countries, num_customers, replace = TRUE, prob = c(0.55, 0.20, 0.10, 0.05, 0.05, 0.05)),
    acquisition_channel = sample(channels, num_customers, replace = TRUE, prob = c(0.30, 0.25, 0.15, 0.10, 0.10, 0.05, 0.05)),
    created_at = Sys.Date() - sample(0:365, num_customers, replace = TRUE)
  )
  
  write.csv(customers, file.path(output_dir, "customers.csv"), row.names = FALSE)
  
  # 3. Inventory
  inventory <- data.frame(
    sku = products$sku,
    stock_on_hand = sample(0:800, num_products, replace = TRUE),
    stock_reserved = sample(0:50, num_products, replace = TRUE),
    reorder_point = products$min_reorder_point,
    lead_time_days = products$lead_time_days,
    last_restock_date = Sys.Date() - sample(1:60, num_products, replace = TRUE)
  )
  
  write.csv(inventory, file.path(output_dir, "inventory.csv"), row.names = FALSE)
  
  # 4. Orders (50,000+)
  num_orders <- 50000
  dates <- Sys.Date() - sample(0:365, num_orders, replace = TRUE)
  cust_sample <- sample(customers$customer_id, num_orders, replace = TRUE)
  
  orders <- data.frame(
    order_id = sprintf("ORD-%06d", 1:num_orders),
    order_date = dates,
    customer_id = cust_sample,
    currency = "GBP",
    total_units = sample(1:6, num_orders, replace = TRUE, prob = c(0.5, 0.3, 0.1, 0.05, 0.03, 0.02))
  )
  
  # Merge customer acquisition channel
  orders <- merge(orders, customers[, c("customer_id", "acquisition_channel", "country")], by = "customer_id", all.x = TRUE)
  
  # Generate order financial amounts
  base_price <- round(runif(num_orders, 25, 180), 2)
  orders$gross_subtotal   <- round(base_price * orders$total_units, 2)
  orders$discount_amount  <- round(orders$gross_subtotal * sample(c(0, 0.10, 0.15, 0.20), num_orders, replace = TRUE, prob = c(0.7, 0.15, 0.10, 0.05)), 2)
  
  # Return logic (10% return rate)
  orders$is_returned <- sample(c(FALSE, TRUE), num_orders, replace = TRUE, prob = c(0.91, 0.09))
  orders$return_amount <- ifelse(orders$is_returned, orders$gross_subtotal - orders$discount_amount, 0)
  orders$refund_amount <- orders$return_amount
  orders$return_processing_cost <- ifelse(orders$is_returned, 4.50 + (orders$total_units * 0.50), 0)
  
  orders$shipping_charged <- ifelse(orders$gross_subtotal - orders$discount_amount >= 75, 0, 4.99)
  orders$actual_shipping_cost <- round(3.20 + (orders$total_units * 0.60), 2)
  orders$tax_amount <- round((orders$gross_subtotal - orders$discount_amount + orders$shipping_charged) * 0.20, 2)
  
  orders$total_cogs <- round(orders$gross_subtotal * runif(num_orders, 0.35, 0.48), 2)
  orders$payment_processing_fee <- round(orders$gross_subtotal * 0.024 + 0.20, 2)
  orders$marketing_attribution_cost <- round(orders$gross_subtotal * 0.12, 2)
  
  write.csv(orders, file.path(output_dir, "orders.csv"), row.names = FALSE)
  
  # 5. Marketing Campaigns
  marketing <- data.frame(
    date = rep(Sys.Date() - 0:89, each = 5),
    channel = rep(c("Google Ads", "Meta Ads", "TikTok", "Email", "Affiliate"), times = 90),
    spend = round(runif(450, 100, 1500), 2),
    impressions = sample(5000:50000, 450, replace = TRUE),
    clicks = sample(200:2500, 450, replace = TRUE),
    conversions = sample(10:150, 450, replace = TRUE)
  )
  
  write.csv(marketing, file.path(output_dir, "marketing.csv"), row.names = FALSE)
  
  cat("Successfully generated 50,000 orders dataset!\n")
}

# Run generation if data files do not exist
if (!file.exists("ecommerce_os/data/orders.csv")) {
  generate_synthetic_dataset("ecommerce_os/data")
}
