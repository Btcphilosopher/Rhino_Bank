# EcommerceOS - Utilities Engine
# R Helper functions for formatting, currency, and date ranges

convert_currency <- function(amount, from_curr = "GBP", to_curr = "GBP", rates = c(GBP=1.0, USD=1.28, EUR=1.17, CAD=1.75, AUD=1.92)) {
  if (from_curr == to_curr) return(amount)
  # Convert to base GBP first then to target currency
  amount_in_gbp <- amount / rates[from_curr]
  amount_in_target <- amount_in_gbp * rates[to_curr]
  return(amount_in_target)
}

format_currency <- function(amount, currency = "GBP") {
  symbol <- switch(currency,
    "GBP" = "£",
    "USD" = "$",
    "EUR" = "€",
    "CAD" = "CA$",
    "AUD" = "A$",
    "£"
  )
  sprintf("%s%s", symbol, formatC(amount, format = "f", digits = 2, big.mark = ","))
}

format_percent <- function(val, digits = 1) {
  sprintf("%.*f%%", digits, val * 100)
}

safe_divide <- function(num, den, default = 0) {
  ifelse(den == 0 | is.na(den), default, num / den)
}

filter_date_range <- function(df, date_col = "date", period = "30d", custom_start = NULL, custom_end = NULL, ref_date = Sys.Date()) {
  if (is.null(df) || nrow(df) == 0) return(df)
  
  max_date <- as.Date(ref_date)
  
  start_date <- switch(period,
    "today" = max_date,
    "7d" = max_date - 6,
    "30d" = max_date - 29,
    "90d" = max_date - 89,
    "ytd" = as.Date(sprintf("%s-01-01", format(max_date, "%Y"))),
    "custom" = if(!is.null(custom_start)) as.Date(custom_start) else max_date - 29,
    max_date - 29
  )
  
  end_date <- if(period == "custom" && !is.null(custom_end)) as.Date(custom_end) else max_date
  
  df_date <- as.Date(df[[date_col]])
  return(df[df_date >= start_date & df_date <= end_date, ])
}
