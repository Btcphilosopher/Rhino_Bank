# EcommerceOS - Forecasting Engine (Time Series Forecasting with Confidence Intervals)

forecast_metric <- function(time_series, horizon_days = 30, confidence_level = 0.95) {
  if (is.null(time_series) || length(time_series) < 7) {
    # Fallback dummy forecast
    return(data.frame(
      day = 1:horizon_days,
      date = Sys.Date() + (1:horizon_days),
      point_forecast = rep(100, horizon_days),
      lower_80 = rep(85, horizon_days),
      upper_80 = rep(115, horizon_days),
      lower_95 = rep(75, horizon_days),
      upper_95 = rep(125, horizon_days)
    ))
  }
  
  n <- length(time_series)
  mean_val <- mean(time_series, na.rm = TRUE)
  sd_val   <- sd(time_series, na.rm = TRUE)
  if (is.na(sd_val) || sd_val == 0) sd_val <- mean_val * 0.1
  
  # Calculate 7-day seasonality index
  seasonality <- rep(1, 7)
  if (n >= 14) {
    weekly_matrix <- matrix(time_series[1:(floor(n/7)*7)], ncol = 7, byrow = TRUE)
    day_means <- colMeans(weekly_matrix, na.rm = TRUE)
    seasonality <- day_means / mean(day_means)
  }
  
  # Holt-Winters style trend estimation
  recent_trend <- (mean(tail(time_series, 7)) - mean(head(time_series, 7))) / (n - 7)
  
  z_80 <- 1.282
  z_95 <- 1.960
  
  dates <- Sys.Date() + (1:horizon_days)
  forecasts <- numeric(horizon_days)
  l80 <- numeric(horizon_days)
  u80 <- numeric(horizon_days)
  l95 <- numeric(horizon_days)
  u95 <- numeric(horizon_days)
  
  for (i in 1:horizon_days) {
    day_of_week <- ((n + i - 1) %% 7) + 1
    s_factor <- seasonality[day_of_week]
    
    base_pred <- pmax(0, (mean_val + recent_trend * i) * s_factor)
    
    # Uncertainty expands with horizon
    horizon_sd <- sd_val * sqrt(1 + (i / 10))
    
    forecasts[i] <- round(base_pred, 2)
    l80[i] <- pmax(0, round(base_pred - z_80 * horizon_sd, 2))
    u80[i] <- round(base_pred + z_80 * horizon_sd, 2)
    l95[i] <- pmax(0, round(base_pred - z_95 * horizon_sd, 2))
    u95[i] <- round(base_pred + z_95 * horizon_sd, 2)
  }
  
  return(data.frame(
    day = 1:horizon_days,
    date = dates,
    point_forecast = forecasts,
    lower_80 = l80,
    upper_80 = u80,
    lower_95 = l95,
    upper_95 = u95
  ))
}

forecast_revenue_and_demand <- function(daily_df, horizon = 30) {
  if (is.null(daily_df) || nrow(daily_df) == 0) return(list())
  
  rev_ts   <- daily_df$net_revenue
  order_ts <- daily_df$orders
  unit_ts  <- daily_df$units
  
  return(list(
    revenue_forecast = forecast_metric(rev_ts, horizon_days = horizon),
    orders_forecast  = forecast_metric(order_ts, horizon_days = horizon),
    units_forecast   = forecast_metric(unit_ts, horizon_days = horizon)
  ))
}
