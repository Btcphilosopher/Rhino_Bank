# EcommerceOS - Inventory & Stock Operations Engine

calculate_inventory_status <- function(inventory_df, sales_30d_df) {
  if (is.null(inventory_df) || nrow(inventory_df) == 0) return(data.frame())
  
  merged <- merge(inventory_df, sales_30d_df, by = "sku", all.x = TRUE)
  merged$units_sold_30d[is.na(merged$units_sold_30d)] <- 0
  
  merged$daily_demand <- merged$units_sold_30d / 30
  merged$safety_stock <- ceiling(merged$daily_demand * merged$lead_time_days * 0.5)
  merged$calculated_rop <- ceiling((merged$daily_demand * merged$lead_time_days) + merged$safety_stock)
  
  merged$days_of_inventory <- ifelse(merged$daily_demand > 0, merged$stock_on_hand / merged$daily_demand, 999)
  
  merged$status <- apply(merged, 1, function(row) {
    soh <- as.numeric(row["stock_on_hand"])
    rop <- as.numeric(row["calculated_rop"])
    doi <- as.numeric(row["days_of_inventory"])
    dd  <- as.numeric(row["daily_demand"])
    
    if (soh == 0) {
      return("OUT OF STOCK")
    } else if (soh <= rop) {
      return("LOW STOCK")
    } else if (doi > 120 && dd > 0) {
      return("OVERSTOCKED")
    } else if (dd == 0 && soh > 0) {
      return("DEAD STOCK")
    } else if (doi < 15) {
      return("FAST MOVING")
    } else {
      return("HEALTHY")
    }
  })
  
  # Target stock level = 60 days of demand + safety stock
  merged$target_stock <- ceiling((merged$daily_demand * 60) + merged$safety_stock)
  merged$recommended_order_qty <- pmax(0, merged$target_stock - (merged$stock_on_hand + merged$stock_reserved))
  
  return(merged)
}

forecast_sku_stockout <- function(inventory_status_df) {
  if (is.null(inventory_status_df) || nrow(inventory_status_df) == 0) return(data.frame())
  
  inventory_status_df$expected_stockout_days <- ifelse(
    inventory_status_df$daily_demand > 0,
    floor(inventory_status_df$stock_on_hand / inventory_status_df$daily_demand),
    999
  )
  
  inventory_status_df$expected_stockout_date <- Sys.Date() + inventory_status_df$expected_stockout_days
  inventory_status_df$reorder_trigger_date   <- inventory_status_df$expected_stockout_date - inventory_status_df$lead_time_days
  
  return(inventory_status_df[order(inventory_status_df$expected_stockout_days), ])
}
