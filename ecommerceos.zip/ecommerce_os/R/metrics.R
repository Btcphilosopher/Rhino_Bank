# EcommerceOS - Core Commercial Metrics Engine

calculate_aov <- function(revenue, orders) {
  safe_divide(revenue, orders, 0)
}

calculate_gross_profit <- function(revenue, cogs) {
  revenue - cogs
}

calculate_gross_margin <- function(gross_profit, revenue) {
  safe_divide(gross_profit, revenue, 0)
}

calculate_contribution_profit <- function(revenue, cogs, shipping, payment_fees, marketing, returns) {
  revenue - cogs - shipping - payment_fees - marketing - returns
}

calculate_contribution_margin <- function(contribution_profit, revenue) {
  safe_divide(contribution_profit, revenue, 0)
}

calculate_net_profit <- function(contribution_profit, opex) {
  contribution_profit - opex
}

calculate_roas <- function(revenue, ad_spend) {
  safe_divide(revenue, ad_spend, 0)
}

calculate_contribution_roas <- function(contribution_profit_before_marketing, ad_spend) {
  safe_divide(contribution_profit_before_marketing, ad_spend, 0)
}

calculate_cac <- function(total_marketing_spend, new_customers) {
  safe_divide(total_marketing_spend, new_customers, 0)
}

calculate_ltv <- function(avg_order_value, purchase_frequency, avg_customer_lifespan_years, gross_margin_pct) {
  avg_order_value * purchase_frequency * avg_customer_lifespan_years * gross_margin_pct
}

calculate_repeat_rate <- function(repeat_customers, total_customers) {
  safe_divide(repeat_customers, total_customers, 0)
}

calculate_turnover_rate <- function(cogs, avg_inventory_value) {
  safe_divide(cogs, avg_inventory_value, 0)
}

calculate_days_of_inventory <- function(avg_inventory_value, daily_cogs) {
  safe_divide(avg_inventory_value, daily_cogs, 0)
}
