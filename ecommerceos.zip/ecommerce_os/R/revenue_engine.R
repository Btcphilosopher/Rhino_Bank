# EcommerceOS - Revenue Engine & Accounting Waterfall

calculate_revenue_waterfall <- function(orders_df) {
  if (is.null(orders_df) || nrow(orders_df) == 0) {
    return(data.frame(
      stage = c("Gross Sales", "Discounts", "Returns", "Refunds", "Shipping Revenue", "Tax Collected", "Net Revenue"),
      amount = rep(0, 7),
      type = c("total", "subtraction", "subtraction", "subtraction", "addition", "tax", "total")
    ))
  }
  
  gross_sales <- sum(orders_df$gross_subtotal, na.rm = TRUE)
  discounts   <- sum(orders_df$discount_amount, na.rm = TRUE)
  returns     <- sum(orders_df$return_amount, na.rm = TRUE)
  refunds     <- sum(orders_df$refund_amount, na.rm = TRUE)
  shipping_rev <- sum(orders_df$shipping_charged, na.rm = TRUE)
  tax_collected <- sum(orders_df$tax_amount, na.rm = TRUE)
  
  # Accounting Net Revenue = Gross Sales - Discounts - Returns - Refunds + Shipping Revenue
  # Note: Tax is held in trust (liability), not recognized as operating revenue
  net_revenue <- gross_sales - discounts - returns - refunds + shipping_rev
  
  waterfall <- data.frame(
    stage = c("Gross Sales", "Discounts", "Returns", "Refunds", "Shipping Revenue", "Tax Collected", "Net Revenue"),
    amount = c(gross_sales, discounts, returns, refunds, shipping_rev, tax_collected, net_revenue),
    impact = c(gross_sales, -discounts, -returns, -refunds, shipping_rev, tax_collected, net_revenue),
    category = c("Gross", "Deduction", "Deduction", "Deduction", "Addition", "Tax (Liability)", "Net Operating Revenue")
  )
  
  return(waterfall)
}

calculate_daily_revenue_trend <- function(orders_df) {
  if (is.null(orders_df) || nrow(orders_df) == 0) return(data.frame())
  
  orders_df$date <- as.Date(orders_df$order_date)
  
  daily <- aggregate(
    cbind(net_revenue = gross_subtotal - discount_amount - return_amount + shipping_charged,
          orders = order_id,
          units = total_units) ~ date,
    data = orders_df,
    FUN = function(x) if (is.numeric(x)) sum(x, na.rm = TRUE) else length(x)
  )
  
  daily$aov <- ifelse(daily$orders > 0, daily$net_revenue / daily$orders, 0)
  return(daily)
}
