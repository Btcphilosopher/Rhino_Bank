# EcommerceOS - Marketing & Attribution Engine

calculate_marketing_performance <- function(marketing_df, orders_df) {
  if (is.null(marketing_df) || nrow(marketing_df) == 0) return(data.frame())
  
  # Channel summary from marketing table
  m_summary <- aggregate(
    cbind(spend, impressions, clicks, conversions) ~ channel,
    data = marketing_df,
    FUN = sum
  )
  
  m_summary$ctr <- ifelse(m_summary$impressions > 0, m_summary$clicks / m_summary$impressions, 0)
  m_summary$cpc <- ifelse(m_summary$clicks > 0, m_summary$spend / m_summary$clicks, 0)
  m_summary$cpa <- ifelse(m_summary$conversions > 0, m_summary$spend / m_summary$conversions, 0)
  
  if (!is.null(orders_df) && "acquisition_channel" %in% names(orders_df)) {
    orders_df$net_revenue <- orders_df$gross_subtotal - orders_df$discount_amount - orders_df$return_amount + orders_df$shipping_charged
    orders_df$gross_profit <- orders_df$net_revenue - orders_df$total_cogs
    
    rev_by_channel <- aggregate(
      cbind(attributed_revenue = net_revenue,
            attributed_gross_profit = gross_profit) ~ acquisition_channel,
      data = orders_df,
      FUN = sum
    )
    names(rev_by_channel)[1] <- "channel"
    
    m_summary <- merge(m_summary, rev_by_channel, by = "channel", all.x = TRUE)
    m_summary$attributed_revenue[is.na(m_summary$attributed_revenue)] <- 0
    m_summary$attributed_gross_profit[is.na(m_summary$attributed_gross_profit)] <- 0
    
    m_summary$roas <- ifelse(m_summary$spend > 0, m_summary$attributed_revenue / m_summary$spend, 0)
    m_summary$contribution_roas <- ifelse(m_summary$spend > 0, (m_summary$attributed_gross_profit - (m_summary$spend * 0.15)) / m_summary$spend, 0)
    m_summary$profit_after_ads <- m_summary$attributed_gross_profit - m_summary$spend
  }
  
  return(m_summary[order(-m_summary$attributed_revenue), ])
}
