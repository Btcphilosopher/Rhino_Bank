# EcommerceOS - Profitability Engine

calculate_p_and_l <- function(orders_df, marketing_df, opex_daily = 350) {
  if (is.null(orders_df) || nrow(orders_df) == 0) {
    return(list(
      revenue = 0, cogs = 0, gross_profit = 0, gross_margin = 0,
      shipping_cost = 0, payment_fees = 0, marketing_cost = 0, returns_cost = 0,
      contribution_profit = 0, contribution_margin = 0, opex = 0, net_profit = 0, net_margin = 0
    ))
  }
  
  revenue <- sum(orders_df$gross_subtotal - orders_df$discount_amount - orders_df$return_amount + orders_df$shipping_charged, na.rm = TRUE)
  cogs    <- sum(orders_df$total_cogs, na.rm = TRUE)
  gross_profit <- revenue - cogs
  gross_margin <- ifelse(revenue > 0, gross_profit / revenue, 0)
  
  shipping_cost  <- sum(orders_df$actual_shipping_cost, na.rm = TRUE)
  payment_fees   <- sum(orders_df$payment_processing_fee, na.rm = TRUE)
  marketing_cost <- if (!is.null(marketing_df)) sum(marketing_df$spend, na.rm = TRUE) else sum(orders_df$marketing_attribution_cost, na.rm = TRUE)
  returns_cost   <- sum(orders_df$return_processing_cost, na.rm = TRUE)
  
  num_days <- length(unique(as.Date(orders_df$order_date)))
  opex <- num_days * opex_daily
  
  contribution_profit <- gross_profit - shipping_cost - payment_fees - marketing_cost - returns_cost
  contribution_margin <- ifelse(revenue > 0, contribution_profit / revenue, 0)
  
  net_profit <- contribution_profit - opex
  net_margin <- ifelse(revenue > 0, net_profit / revenue, 0)
  
  return(list(
    revenue = revenue,
    cogs = cogs,
    gross_profit = gross_profit,
    gross_margin = gross_margin,
    shipping_cost = shipping_cost,
    payment_fees = payment_fees,
    marketing_cost = marketing_cost,
    returns_cost = returns_cost,
    contribution_profit = contribution_profit,
    contribution_margin = contribution_margin,
    opex = opex,
    net_profit = net_profit,
    net_margin = net_margin
  ))
}

calculate_product_contribution <- function(items_df, products_df) {
  if (is.null(items_df) || nrow(items_df) == 0) return(data.frame())
  
  merged <- merge(items_df, products_df, by = "sku", all.x = TRUE)
  merged$item_net_revenue <- merged$item_price * merged$quantity - merged$item_discount
  merged$item_total_cogs  <- merged$cogs * merged$quantity
  merged$item_gross_profit <- merged$item_net_revenue - merged$item_total_cogs
  
  # Allocate marketing & shipping proportionally
  merged$item_shipping_est <- merged$quantity * 2.80
  merged$item_marketing_est <- merged$item_net_revenue * 0.12
  merged$item_return_cost_est <- ifelse(merged$is_returned, merged$cogs * 0.5 + 4.50, 0)
  
  merged$item_contribution <- merged$item_gross_profit - merged$item_shipping_est - merged$item_marketing_est - merged$item_return_cost_est
  
  by_product <- aggregate(
    cbind(units_sold = quantity,
          revenue = item_net_revenue,
          cogs = item_total_cogs,
          gross_profit = item_gross_profit,
          contribution_profit = item_contribution) ~ sku + product_name + category,
    data = merged,
    FUN = sum
  )
  
  by_product$gross_margin <- ifelse(by_product$revenue > 0, by_product$gross_profit / by_product$revenue, 0)
  by_product$contribution_margin <- ifelse(by_product$revenue > 0, by_product$contribution_profit / by_product$revenue, 0)
  
  return(by_product[order(-by_product$contribution_profit), ])
}
