# EcommerceOS - Profit Optimisation Engine & Price Elasticity

profit_optimizer <- function(current_price, cogs, shipping_cost, ad_spend_per_unit, current_volume, price_elasticity = -1.6) {
  # Price elasticity of demand = (% change in Q) / (% change in P)
  # Ed = (dQ / Q) / (dP / P)  => dQ = Q * Ed * (dP / P)
  
  simulations <- data.frame()
  pct_changes <- c(-0.15, -0.10, -0.05, 0.0, 0.05, 0.10, 0.15, 0.20)
  
  for (pct_p in pct_changes) {
    new_price  <- current_price * (1 + pct_p)
    pct_q      <- price_elasticity * pct_p
    new_volume <- pmax(0, current_volume * (1 + pct_q))
    
    unit_revenue <- new_price
    unit_cogs    <- cogs
    unit_margin  <- unit_revenue - unit_cogs - shipping_cost - ad_spend_per_unit
    
    total_revenue <- new_price * new_volume
    total_cogs    <- cogs * new_volume
    total_gross   <- (new_price - cogs) * new_volume
    total_profit  <- unit_margin * new_volume
    margin_pct    <- ifelse(total_revenue > 0, total_profit / total_revenue, 0)
    
    simulations <- rbind(simulations, data.frame(
      price_change_pct = pct_p * 100,
      price = round(new_price, 2),
      expected_units = round(new_volume),
      revenue = round(total_revenue, 2),
      gross_profit = round(total_gross, 2),
      contribution_profit = round(total_profit, 2),
      margin_pct = round(margin_pct * 100, 2)
    ))
  }
  
  # Find price that maximizes total contribution profit
  best_idx <- which.max(simulations$contribution_profit)
  optimal_scenario <- simulations[best_idx, ]
  current_scenario <- simulations[simulations$price_change_pct == 0, ]
  
  profit_lift <- optimal_scenario$contribution_profit - current_scenario$contribution_profit
  pct_lift    <- ifelse(current_scenario$contribution_profit > 0, (profit_lift / current_scenario$contribution_profit) * 100, 0)
  
  recommendation <- list(
    current_price = current_price,
    optimal_price = optimal_scenario$price,
    suggested_change = sprintf("%+.1f%%", optimal_scenario$price_change_pct),
    expected_revenue_change = sprintf("%+.1f%%", ((optimal_scenario$revenue - current_scenario$revenue) / current_scenario$revenue) * 100),
    expected_units_change = sprintf("%+.1f%%", ((optimal_scenario$expected_units - current_scenario$expected_units) / current_scenario$expected_units) * 100),
    expected_profit_lift = profit_lift,
    expected_profit_lift_pct = pct_lift,
    elasticity_assumed = price_elasticity,
    simulations = simulations
  )
  
  return(recommendation)
}
