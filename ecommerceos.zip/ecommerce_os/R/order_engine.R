# EcommerceOS - Order Processing & Cart Engine

calculate_order_totals <- function(cart_items, discount_code = NULL, shipping_rate = 4.99, tax_rate = 0.20) {
  if (is.null(cart_items) || nrow(cart_items) == 0) {
    return(list(
      subtotal = 0, discount = 0, shipping = 0, tax = 0, grand_total = 0, cogs = 0
    ))
  }
  
  gross_subtotal <- sum(cart_items$price * cart_items$quantity, na.rm = TRUE)
  total_cogs     <- sum(cart_items$cogs * cart_items$quantity, na.rm = TRUE)
  
  discount_amount <- 0
  if (!is.null(discount_code)) {
    discount_amount <- switch(toupper(discount_code),
      "VIP10" = gross_subtotal * 0.10,
      "SAVE20" = gross_subtotal * 0.20,
      "SUMMER15" = gross_subtotal * 0.15,
      0
    )
  }
  
  net_subtotal <- gross_subtotal - discount_amount
  shipping <- if (net_subtotal >= 75) 0 else shipping_rate
  taxable_base <- net_subtotal + shipping
  tax_amount <- taxable_base * tax_rate
  grand_total <- taxable_base + tax_amount
  
  return(list(
    gross_subtotal = gross_subtotal,
    discount_amount = discount_amount,
    net_subtotal = net_subtotal,
    shipping_charged = shipping,
    tax_amount = tax_amount,
    grand_total = grand_total,
    total_cogs = total_cogs,
    gross_margin_est = ifelse(net_subtotal > 0, (net_subtotal - total_cogs) / net_subtotal, 0)
  ))
}
