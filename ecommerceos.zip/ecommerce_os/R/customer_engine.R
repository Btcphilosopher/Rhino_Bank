# EcommerceOS - Customer Intelligence & RFM Segmentation Engine

calculate_rfm_segments <- function(orders_df, customers_df, ref_date = Sys.Date()) {
  if (is.null(orders_df) || nrow(orders_df) == 0) return(data.frame())
  
  orders_df$order_date <- as.Date(orders_df$order_date)
  ref_date <- as.Date(ref_date)
  
  # Aggregate metrics per customer
  cust_agg <- aggregate(
    cbind(recency_days = as.numeric(ref_date - order_date),
          frequency = order_id,
          monetary = gross_subtotal - discount_amount) ~ customer_id,
    data = orders_df,
    FUN = function(x) {
      if (is.numeric(x) && length(x) > 1) {
        if ("order_date" %in% names(x)) min(x) else sum(x)
      } else {
        length(x)
      }
    }
  )
  
  # Clean up aggregations
  rfm <- aggregate(order_date ~ customer_id, data = orders_df, FUN = function(d) as.numeric(ref_date - max(d)))
  names(rfm)[2] <- "recency_days"
  
  freq <- aggregate(order_id ~ customer_id, data = orders_df, FUN = length)
  names(freq)[2] <- "frequency"
  
  mon <- aggregate(gross_subtotal - discount_amount ~ customer_id, data = orders_df, FUN = sum)
  names(mon)[2] <- "monetary"
  
  rfm <- merge(rfm, freq, by = "customer_id")
  rfm <- merge(rfm, mon, by = "customer_id")
  
  # Assign Scores 1-5
  rfm$r_score <- 6 - as.numeric(cut(rfm$recency_days, breaks = quantile(rfm$recency_days, probs = seq(0, 1, 0.2), na.rm=TRUE), include.lowest=TRUE, labels=FALSE))
  rfm$f_score <- as.numeric(cut(rfm$frequency, breaks = unique(quantile(rfm$frequency, probs = seq(0, 1, 0.2), na.rm=TRUE)), include.lowest=TRUE, labels=FALSE))
  rfm$m_score <- as.numeric(cut(rfm$monetary, breaks = quantile(rfm$monetary, probs = seq(0, 1, 0.2), na.rm=TRUE), include.lowest=TRUE, labels=FALSE))
  
  rfm$r_score[is.na(rfm$r_score)] <- 3
  rfm$f_score[is.na(rfm$f_score)] <- 3
  rfm$m_score[is.na(rfm$m_score)] <- 3
  
  # Segment mapping
  rfm$segment <- apply(rfm, 1, function(row) {
    r <- as.numeric(row["r_score"])
    f <- as.numeric(row["f_score"])
    m <- as.numeric(row["m_score"])
    
    if (r >= 4 && f >= 4 && m >= 4) return("Champions")
    if (r >= 3 && f >= 3) return("Loyal")
    if (r >= 4 && f <= 2) return("New Customers")
    if (r >= 3 && f <= 2 && m >= 3) return("Potential Loyalists")
    if (r <= 2 && f >= 3) return("At Risk")
    if (r <= 2 && f <= 2) return("Lost")
    return("General")
  })
  
  if (!is.null(customers_df)) {
    rfm <- merge(rfm, customers_df[, c("customer_id", "customer_name", "email", "country", "acquisition_channel")], by = "customer_id", all.x = TRUE)
  }
  
  return(rfm)
}

calculate_customer_cohorts <- function(orders_df) {
  if (is.null(orders_df) || nrow(orders_df) == 0) return(data.frame())
  
  orders_df$order_month <- format(as.Date(orders_df$order_date), "%Y-%m")
  
  first_orders <- aggregate(order_month ~ customer_id, data = orders_df, FUN = min)
  names(first_orders)[2] <- "cohort_month"
  
  merged <- merge(orders_df, first_orders, by = "customer_id")
  
  cohort_matrix <- aggregate(
    customer_id ~ cohort_month + order_month,
    data = merged,
    FUN = function(x) length(unique(x))
  )
  
  return(cohort_matrix)
}
