# EcommerceOS - Product Analytics Engine & Matrix Classifier

classify_product_matrix <- function(product_perf_df) {
  if (is.null(product_perf_df) || nrow(product_perf_df) == 0) return(data.frame())
  
  median_sales  <- median(product_perf_df$units_sold, na.rm = TRUE)
  median_profit <- median(product_perf_df$contribution_profit, na.rm = TRUE)
  
  product_perf_df$quadrant <- apply(product_perf_df, 1, function(row) {
    sales  <- as.numeric(row["units_sold"])
    profit <- as.numeric(row["contribution_profit"])
    
    if (sales >= median_sales && profit >= median_profit) {
      return("STARS") # High Sales, High Profit
    } else if (sales < median_sales && profit >= median_profit) {
      return("WINNERS") # Low Sales, High Profit (Niche High-Margin)
    } else if (sales >= median_sales && profit < median_profit) {
      return("VOLUME") # High Sales, Low Profit (High Volume Low Margin)
    } else {
      return("WEAK") # Low Sales, Low Profit
    }
  })
  
  return(product_perf_df)
}

calculate_product_kpis <- function(items_df, products_df, inventory_df) {
  if (is.null(products_df) || nrow(products_df) == 0) return(data.frame())
  
  # Aggregate sales per product
  sales_agg <- aggregate(
    cbind(units_sold = quantity,
          revenue = item_price * quantity - item_discount,
          returns = ifelse(is_returned, quantity, 0)) ~ sku,
    data = items_df,
    FUN = sum
  )
  
  m1 <- merge(products_df, sales_agg, by = "sku", all.x = TRUE)
  m1$units_sold[is.na(m1$units_sold)] <- 0
  m1$revenue[is.na(m1$revenue)] <- 0
  m1$returns[is.na(m1$returns)] <- 0
  
  m1$total_cogs <- m1$units_sold * m1$cogs
  m1$gross_profit <- m1$revenue - m1$total_cogs
  m1$gross_margin <- ifelse(m1$revenue > 0, m1$gross_profit / m1$revenue, 0)
  m1$return_rate  <- ifelse(m1$units_sold > 0, m1$returns / m1$units_sold, 0)
  
  # Estimate 30-day contribution profit
  m1$contribution_profit <- m1$gross_profit - (m1$revenue * 0.12) - (m1$units_sold * 3.10)
  
  if (!is.null(inventory_df)) {
    m1 <- merge(m1, inventory_df[, c("sku", "stock_on_hand", "reorder_point")], by = "sku", all.x = TRUE)
    m1$stock_on_hand[is.na(m1$stock_on_hand)] <- 0
    m1$days_of_stock <- ifelse(m1$units_sold > 0, (m1$stock_on_hand / m1$units_sold) * 30, 999)
  }
  
  m1 <- classify_product_matrix(m1)
  return(m1[order(-m1$revenue), ])
}
