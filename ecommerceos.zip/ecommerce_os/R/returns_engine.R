# EcommerceOS - Returns & Refund Risk Engine

analyze_returns <- function(orders_df, items_df, products_df) {
  if (is.null(orders_df) || nrow(orders_df) == 0) return(list())
  
  total_orders <- nrow(orders_df)
  returned_orders <- sum(orders_df$is_returned, na.rm = TRUE)
  return_rate <- ifelse(total_orders > 0, returned_orders / total_orders, 0)
  
  total_refund_value <- sum(orders_df$refund_amount, na.rm = TRUE)
  total_return_cost  <- sum(orders_df$return_processing_cost, na.rm = TRUE)
  
  # Product return rates
  product_returns <- data.frame()
  if (!is.null(items_df) && nrow(items_df) > 0) {
    prod_agg <- aggregate(
      cbind(total_units = quantity,
            returned_units = ifelse(is_returned, quantity, 0),
            refund_amount = item_refund) ~ sku,
      data = items_df,
      FUN = sum
    )
    
    prod_agg$sku_return_rate <- ifelse(prod_agg$total_units > 0, prod_agg$returned_units / prod_agg$total_units, 0)
    
    if (!is.null(products_df)) {
      prod_agg <- merge(products_df[, c("sku", "product_name", "category", "cogs", "sale_price")], prod_agg, by = "sku", all.x = TRUE)
    }
    
    prod_agg$margin_drag_pct <- prod_agg$sku_return_rate * (prod_agg$cogs / prod_agg$sale_price)
    product_returns <- prod_agg[order(-prod_agg$sku_return_rate), ]
  }
  
  # Common Return Reasons
  reasons <- data.frame(
    reason = c("Wrong Size / Fit", "Item Defective / Damaged", "Not as Pictured", "Changed Mind", "Late Delivery"),
    pct = c(0.42, 0.21, 0.18, 0.12, 0.07),
    units = round(returned_orders * c(0.42, 0.21, 0.18, 0.12, 0.07))
  )
  
  return(list(
    return_rate = return_rate,
    returned_orders = returned_orders,
    refund_value = total_refund_value,
    return_cost = total_return_cost,
    product_returns = product_returns,
    return_reasons = reasons
  ))
}
