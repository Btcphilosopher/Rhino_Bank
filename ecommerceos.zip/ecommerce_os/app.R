# EcommerceOS - R Shiny Application
# Production E-Commerce Operating & Analytics System

library(shiny)
library(bslib)
library(plotly)
library(DT)

# Source Engine Modules
source("R/utilities.R")
source("R/metrics.R")
source("R/data_engine.R")
source("R/revenue_engine.R")
source("R/profit_engine.R")
source("R/product_engine.R")
source("R/inventory_engine.R")
source("R/customer_engine.R")
source("R/marketing_engine.R")
source("R/returns_engine.R")
source("R/forecasting_engine.R")
source("R/optimisation_engine.R")

# Source UI Modules
source("modules/overview.R")
source("modules/sales.R")
source("modules/products.R")
source("modules/customers.R")
source("modules/inventory.R")
source("modules/marketing.R")
source("modules/profitability.R")
source("modules/forecasting.R")
source("modules/settings.R")

theme <- bs_theme(
  version = 5,
  bootswatch = "darkly",
  primary = "#3b82f6",
  bg = "#0f172a",
  fg = "#f8fafc"
)

ui <- page_navbar(
  theme = theme,
  title = span(icon("chart-line"), "EcommerceOS"),
  id = "main_nav",
  
  nav_panel("Overview", overview_ui("overview")),
  nav_panel("Sales", sales_ui("sales")),
  nav_panel("Products", products_ui("products")),
  nav_panel("Customers", customers_ui("customers")),
  nav_panel("Inventory", inventory_ui("inventory")),
  nav_panel("Marketing", marketing_ui("marketing")),
  nav_panel("Profitability", profitability_ui("profitability")),
  nav_panel("Forecasting", forecasting_ui("forecasting")),
  nav_panel("Settings & Data", settings_ui("settings"))
)

server <- function(input, output, session) {
  # Reactive Data Store
  data_store <- reactiveValues(
    currency = "GBP",
    period = "30d"
  )
  
  overview_server("overview", data_store)
  sales_server("sales", data_store)
  products_server("products", data_store)
  customers_server("customers", data_store)
  inventory_server("inventory", data_store)
  marketing_server("marketing", data_store)
  profitability_server("profitability", data_store)
  forecasting_server("forecasting", data_store)
  settings_server("settings", data_store)
}

shinyApp(ui = ui, server = server)
