package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.screens.*
import com.example.ui.theme.MbCharcoal
import com.example.ui.theme.MbHouseTheme
import com.example.ui.theme.WarmGold
import com.example.ui.theme.WarmWhite
import com.example.ui.viewmodel.HospitalityViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: HospitalityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val screenState by viewModel.currentScreen.collectAsState()
            val venueState by viewModel.selectedVenue.collectAsState()
            
            // Dynamic Brand Identity Engine - adopts brand visual system if viewing venue details or custom booking screens
            val activeBrandId = if (screenState in listOf(Screen.VENUE_DETAILS, Screen.BOOKING)) {
                venueState?.brandId
            } else {
                null
            }

            MbHouseTheme(brandId = activeBrandId) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        // Header only on general tabs, not details screens
                        if (screenState in listOf(Screen.HOME, Screen.DISCOVER, Screen.SEARCH, Screen.ACCOUNT)) {
                            AppHeader(
                                title = "M&B House",
                                subtitle = when (screenState) {
                                    Screen.HOME -> "Good Evening"
                                    Screen.DISCOVER -> "Brand Explorer"
                                    Screen.SEARCH -> "Find Your Place"
                                    else -> "My House"
                                },
                                onAssistantClick = { viewModel.navigateTo(Screen.ASSISTANT) },
                                onEstateTwinClick = { viewModel.navigateTo(Screen.ESTATE_TWIN) }
                            )
                        } else {
                            // Simple header with back button for detail screens
                            Surface(
                                color = MbCharcoal,
                                contentColor = WarmWhite,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .statusBarsPadding()
                                        .padding(horizontal = 12.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { viewModel.navigateBack() },
                                        modifier = Modifier.testTag("back_navigation_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowBack,
                                            contentDescription = "Go back",
                                            tint = WarmGold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = when (screenState) {
                                            Screen.VENUE_DETAILS -> venueState?.name?.uppercase() ?: "VENUE DETAILS"
                                            Screen.BOOKING -> "RESERVE A TABLE"
                                            Screen.ORDER -> "ORDER AT TABLE"
                                            Screen.ESTATE_TWIN -> "ESTATE TWIN RADAR"
                                            Screen.ASSISTANT -> "AI ASSISTANT CHAT"
                                            else -> "M&B HOUSE"
                                        },
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = WarmWhite,
                                        fontSize = 16.sp
                                    )
                                }
                            }
                        }
                    },
                    bottomBar = {
                        // Core platform bottom navigation
                        NavigationBar(
                            containerColor = MbCharcoal,
                            contentColor = WarmWhite,
                            modifier = Modifier.testTag("app_bottom_nav_bar")
                        ) {
                            NavigationBarItem(
                                selected = screenState == Screen.HOME,
                                onClick = { viewModel.navigateTo(Screen.HOME) },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home tab") },
                                label = { Text("HOME", style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MbCharcoal,
                                    selectedTextColor = WarmGold,
                                    unselectedIconColor = WarmWhite.copy(alpha = 0.6f),
                                    unselectedTextColor = WarmWhite.copy(alpha = 0.6f),
                                    indicatorColor = WarmGold
                                ),
                                modifier = Modifier.testTag("nav_item_home")
                            )
                            NavigationBarItem(
                                selected = screenState == Screen.DISCOVER,
                                onClick = { viewModel.navigateTo(Screen.DISCOVER) },
                                icon = { Icon(Icons.Default.Explore, contentDescription = "Discover tab") },
                                label = { Text("DISCOVER", style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MbCharcoal,
                                    selectedTextColor = WarmGold,
                                    unselectedIconColor = WarmWhite.copy(alpha = 0.6f),
                                    unselectedTextColor = WarmWhite.copy(alpha = 0.6f),
                                    indicatorColor = WarmGold
                                ),
                                modifier = Modifier.testTag("nav_item_discover")
                            )
                            NavigationBarItem(
                                selected = screenState == Screen.SEARCH,
                                onClick = { viewModel.navigateTo(Screen.SEARCH) },
                                icon = { Icon(Icons.Default.Search, contentDescription = "Search tab") },
                                label = { Text("FIND", style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MbCharcoal,
                                    selectedTextColor = WarmGold,
                                    unselectedIconColor = WarmWhite.copy(alpha = 0.6f),
                                    unselectedTextColor = WarmWhite.copy(alpha = 0.6f),
                                    indicatorColor = WarmGold
                                ),
                                modifier = Modifier.testTag("nav_item_find")
                            )
                            NavigationBarItem(
                                selected = screenState == Screen.ORDER,
                                onClick = { viewModel.navigateTo(Screen.ORDER) },
                                icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "Order tab") },
                                label = { Text("ORDER", style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MbCharcoal,
                                    selectedTextColor = WarmGold,
                                    unselectedIconColor = WarmWhite.copy(alpha = 0.6f),
                                    unselectedTextColor = WarmWhite.copy(alpha = 0.6f),
                                    indicatorColor = WarmGold
                                ),
                                modifier = Modifier.testTag("nav_item_order")
                            )
                            NavigationBarItem(
                                selected = screenState == Screen.ACCOUNT,
                                onClick = { viewModel.navigateTo(Screen.ACCOUNT) },
                                icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Account tab") },
                                label = { Text("MY HOUSE", style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MbCharcoal,
                                    selectedTextColor = WarmGold,
                                    unselectedIconColor = WarmWhite.copy(alpha = 0.6f),
                                    unselectedTextColor = WarmWhite.copy(alpha = 0.6f),
                                    indicatorColor = WarmGold
                                ),
                                modifier = Modifier.testTag("nav_item_account")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (screenState) {
                            Screen.HOME -> HomeScreen(viewModel = viewModel)
                            Screen.DISCOVER -> BrandExplorerScreen(viewModel = viewModel)
                            Screen.SEARCH -> VenueSearchScreen(viewModel = viewModel)
                            Screen.VENUE_DETAILS -> VenueDetailsScreen(viewModel = viewModel)
                            Screen.BOOKING -> BookingScreen(viewModel = viewModel)
                            Screen.ORDER -> OrderScreen(viewModel = viewModel)
                            Screen.ACCOUNT -> AccountScreen(viewModel = viewModel)
                            Screen.ESTATE_TWIN -> EstateTwinScreen(viewModel = viewModel)
                            Screen.ASSISTANT -> AssistantScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
