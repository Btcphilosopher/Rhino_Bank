package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.entities.*
import com.example.data.repository.HospitalityRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class Screen {
    HOME, DISCOVER, SEARCH, VENUE_DETAILS, BOOKING, ORDER, ACCOUNT, ESTATE_TWIN, ASSISTANT
}

data class BookingFormState(
    val selectedDate: String = "Today, 27 September",
    val selectedTime: String = "19:30",
    val partySize: Int = 4,
    val occasion: String = "Birthday Celebration",
    val seatingType: String = "Standard Table",
    val specialRequests: String = "",
    val accessibilityRequests: String = "",
    val step: Int = 1
)

data class ActiveOrderSession(
    val venueId: String = "",
    val tableNumber: Int = 0,
    val statusText: String = "AVAILABLE", // AVAILABLE, RESERVED, SEATED, ORDERING, PREPARING, READY, SERVING, BILL_REQUESTED, PAYING, CLEARED
    val cartItems: List<MenuItem> = emptyList(),
    val billSplittingType: String = "EQUAL", // EQUAL, BY_ITEM, BY_PERSON
    val selectedItemIndexToPay: Int = -1,
    val splitMembersCount: Int = 4,
    val pinlessPaymentProcessing: Boolean = false,
    val pinlessPaymentSuccess: Boolean = false
)

data class AssistantChatMessage(
    val sender: String, // "USER" or "ASSISTANT"
    val text: String,
    val actionCta: String? = null, // Custom CTA trigger e.g. "NAV_BOOK", "NAV_STEAK", "NAV_OFFERS"
    val actionData: String? = null
)

class HospitalityViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: HospitalityRepository = HospitalityRepository(AppDatabase.getDatabase(application).hospitalityDao())
    private var simulatorJob: Job? = null

    // --- DYNAMIC BRAND & VENUE VIEWING ---
    val selectedBrandId = MutableStateFlow<String?>(null)
    val selectedVenueId = MutableStateFlow<String?>(null)

    val staticMenuCatalog = repository.staticMenuCatalog

    fun getTablesForVenue(venueId: String): Flow<List<TableStateEntity>> = repository.getTablesForVenue(venueId)

    @kotlin.OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val venueTables: StateFlow<List<TableStateEntity>> = selectedVenueId
        .flatMapLatest { id ->
            if (id != null) repository.getTablesForVenue(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- NAVIGATION BACKSTACK ---
    private val _navigationStack = MutableStateFlow<List<Screen>>(listOf(Screen.HOME))
    val currentScreen: StateFlow<Screen> = _navigationStack
        .map { it.lastOrNull() ?: Screen.HOME }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Screen.HOME)

    fun navigateTo(screen: Screen) {
        val currentList = _navigationStack.value.toMutableList()
        currentList.add(screen)
        _navigationStack.value = currentList
    }

    fun navigateBack(): Boolean {
        val currentList = _navigationStack.value.toMutableList()
        return if (currentList.size > 1) {
            currentList.removeAt(currentList.size - 1)
            _navigationStack.value = currentList
            true
        } else {
            false
        }
    }

    // --- STATE FLOWS FROM REPOSITORY ---
    val brands: StateFlow<List<BrandEntity>> = repository.allBrands
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val venues: StateFlow<List<VenueEntity>> = repository.allVenues
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookings: StateFlow<List<BookingEntity>> = repository.allBookings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loyaltyAccount: StateFlow<LoyaltyAccountEntity?> = repository.loyaltyAccount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val offers: StateFlow<List<OfferEntity>> = repository.allOffers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val giftCards: StateFlow<List<GiftCardEntity>> = repository.allGiftCards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val feedbacks: StateFlow<List<FeedbackEntity>> = repository.allFeedback
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    val selectedVenue: StateFlow<VenueEntity?> = selectedVenueId
        .map { id -> id?.let { repository.getVenueById(it) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- SEARCH & FILTER ENGINE ---
    val searchQuery = MutableStateFlow("")
    val filterCity = MutableStateFlow("All")
    val filterCategory = MutableStateFlow("All") // PUB, RESTAURANT, BAR, STEAK, CARVERY, FAMILY, BRUNCH, DRINKS
    val filterMood = MutableStateFlow("All") // Relaxed, Social, Luxury, Traditional, Family

    val filteredVenues: StateFlow<List<VenueEntity>> = combine(
        venues, searchQuery, filterCity, filterCategory, filterMood
    ) { list, query, city, category, mood ->
        list.filter { venue ->
            val matchesQuery = query.isEmpty() || 
                venue.name.contains(query, ignoreCase = true) || 
                venue.postcode.contains(query, ignoreCase = true) ||
                venue.features.contains(query, ignoreCase = true)
            
            val matchesCity = city == "All" || venue.city.equals(city, ignoreCase = true)
            
            val matchesCategory = category == "All" || when (category) {
                "STEAK" -> venue.brandId == "miller_carter" || venue.signatureDishName.contains("steak", ignoreCase = true)
                "CARVERY" -> venue.brandId == "toby_carvery"
                "BRUNCH" -> venue.features.contains("BRUNCH", ignoreCase = true)
                "BAR" -> venue.features.contains("COCKTAIL_BAR", ignoreCase = true) || venue.brandId == "all_bar_one"
                "FAMILY" -> venue.features.contains("FAMILY", ignoreCase = true) || venue.brandId == "harvester"
                "DRINKS" -> venue.features.contains("CASK_ALE") || venue.features.contains("GIN_TRAIL")
                else -> true
            }

            val matchesMood = mood == "All" || when (mood) {
                "Relaxed" -> venue.brandId in listOf("harvester", "vintage_inns", "premium_country")
                "Social" -> venue.brandId in listOf("all_bar_one")
                "Luxury" -> venue.brandId in listOf("miller_carter", "browns")
                "Traditional" -> venue.brandId in listOf("nicholsons")
                else -> true
            }

            matchesQuery && matchesCity && matchesCategory && matchesMood
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- TABLE BOOKING FORM STATE ---
    val bookingForm = MutableStateFlow(BookingFormState())

    fun updateBookingForm(transform: (BookingFormState) -> BookingFormState) {
        bookingForm.value = transform(bookingForm.value)
    }

    fun submitBooking() {
        val form = bookingForm.value
        val venue = selectedVenue.value ?: return
        viewModelScope.launch {
            val booking = BookingEntity(
                venueId = venue.id,
                venueName = venue.name,
                brandId = venue.brandId,
                dateTimeText = "${form.selectedDate} at ${form.selectedTime}",
                partySize = form.partySize,
                status = "CONFIRMED",
                occasion = form.occasion,
                seatingType = form.seatingType,
                specialRequests = form.specialRequests,
                accessibilityRequests = form.accessibilityRequests,
                tableNumber = Random.nextInt(1, 13) // Assign random table twin
            )
            val bookingId = repository.insertBooking(booking)
            
            // Seat the digital table automatically in our simulation database
            val tableId = "${venue.id}_${booking.tableNumber}"
            repository.updateTableState(tableId, "RESERVED", 0.0, bookingId.toInt())

            // Increment points in loyalty account
            val account = repository.loyaltyAccount.first()
            if (account != null) {
                repository.updateLoyaltyAccount(
                    account.copy(
                        points = account.points + 25, // Earn 25 points per booking
                        visitsCount = account.visitsCount + 1
                    )
                )
            }

            // Reset Form and Navigate
            bookingForm.value = BookingFormState()
            navigateTo(Screen.ACCOUNT)
        }
    }


    // --- ACTIVE ORDERING & CART SESSION ---
    val activeOrder = MutableStateFlow(ActiveOrderSession())
    
    // Tracks currently ordered items in the kitchen/bar twin for active table
    val activeTableOrderLines = activeOrder.flatMapLatest { session ->
        if (session.venueId.isNotEmpty() && session.tableNumber > 0) {
            repository.getOrderLinesForTable(session.venueId, session.tableNumber)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun scanTable(venueId: String, tableNumber: Int) {
        viewModelScope.launch {
            val tableId = "${venueId}_$tableNumber"
            val table = repository.getTableById(tableId)
            activeOrder.value = ActiveOrderSession(
                venueId = venueId,
                tableNumber = tableNumber,
                statusText = table?.statusText ?: "SEATED"
            )
            // Seated inside room
            repository.updateTableStatusOnly(tableId, "SEATED")
        }
    }

    fun addToCart(menuItem: MenuItem) {
        val currentCart = activeOrder.value.cartItems.toMutableList()
        currentCart.add(menuItem)
        activeOrder.value = activeOrder.value.copy(cartItems = currentCart)
    }

    fun removeFromCart(menuItem: MenuItem) {
        val currentCart = activeOrder.value.cartItems.toMutableList()
        currentCart.remove(menuItem)
        activeOrder.value = activeOrder.value.copy(cartItems = currentCart)
    }

    fun submitOrder() {
        val session = activeOrder.value
        if (session.cartItems.isEmpty()) return
        
        viewModelScope.launch {
            // Write items to active order table
            val lines = session.cartItems.map { item ->
                OrderLineEntity(
                    venueId = session.venueId,
                    tableNumber = session.tableNumber,
                    dishName = item.name,
                    price = item.price,
                    quantity = 1,
                    category = item.category,
                    statusText = "PREPARING" // Immediate kitchen dispatch
                )
            }
            repository.insertOrderLines(lines)

            // Update table twin state to preparing
            val tableId = "${session.venueId}_${session.tableNumber}"
            val totalBill = lines.sumOf { it.price }
            repository.updateTableState(tableId, "PREPARING", totalBill, 0)

            // Clear Cart but keep session active
            activeOrder.value = session.copy(
                cartItems = emptyList(),
                statusText = "PREPARING"
            )
        }
    }

    fun setBillSplitting(type: String) {
        activeOrder.value = activeOrder.value.copy(billSplittingType = type)
    }

    fun updateSplitMembers(count: Int) {
        activeOrder.value = activeOrder.value.copy(splitMembersCount = count)
    }

    fun processSimulatedPayment() {
        viewModelScope.launch {
            activeOrder.value = activeOrder.value.copy(pinlessPaymentProcessing = true)
            delay(1800) // Beautiful transaction simulation
            activeOrder.value = activeOrder.value.copy(
                pinlessPaymentProcessing = false,
                pinlessPaymentSuccess = true,
                statusText = "CLEARED"
            )
            
            // Update table state to cleared
            val session = activeOrder.value
            val tableId = "${session.venueId}_${session.tableNumber}"
            repository.updateTableState(tableId, "AVAILABLE", 0.0, 0)
            repository.clearOrderLinesForTable(session.venueId, session.tableNumber)

            // Add points for dining
            val account = repository.loyaltyAccount.first()
            if (account != null) {
                repository.updateLoyaltyAccount(
                    account.copy(points = account.points + 80)
                )
            }
        }
    }

    fun exitOrderSession() {
        activeOrder.value = ActiveOrderSession()
    }


    // --- AI ASSISTANT CHAT ENGINE ---
    val assistantMessages = MutableStateFlow<List<AssistantChatMessage>>(
        listOf(
            AssistantChatMessage(
                sender = "ASSISTANT",
                text = "Hello! I am your Mitchells & Butlers House Assistant. I can help you find country pubs, check upcoming bookings, retrieve your rewards, or locate a Miller & Carter nearby. What are you in the mood for tonight?"
            )
        )
    )

    fun sendAssistantQuery(query: String) {
        if (query.isBlank()) return
        
        // Add User Message
        val messages = assistantMessages.value.toMutableList()
        messages.add(AssistantChatMessage("USER", query))
        assistantMessages.value = messages

        viewModelScope.launch {
            delay(1000) // Realistic typing delay

            val reply = parseAssistantQuery(query)
            val updatedMessages = assistantMessages.value.toMutableList()
            updatedMessages.add(reply)
            assistantMessages.value = updatedMessages
        }
    }

    private fun parseAssistantQuery(query: String): AssistantChatMessage {
        val q = query.lowercase()
        return when {
            q.contains("booking") || q.contains("reserv") || q.contains("table") -> {
                AssistantChatMessage(
                    sender = "ASSISTANT",
                    text = "You have an upcoming reservation at Browns Bristol on Saturday, 21 September at 19:30 for 4 guests! Would you like to schedule another booking right now?",
                    actionCta = "NAV_BOOK",
                    actionData = "browns_bristol"
                )
            }
            q.contains("steak") || q.contains("miller") || q.contains("carter") -> {
                AssistantChatMessage(
                    sender = "ASSISTANT",
                    text = "Miller & Carter is our award-winning steakhouse brand. Certified Steak Masters cut 30-day aged Ribeyes, Sirloins, and gorgeous Chateaubriand tenderloins. I've found Miller & Carter Bristol City (1.2 miles away) and Birmingham Mailbox (1.1 miles away) for you!",
                    actionCta = "NAV_STEAK",
                    actionData = "miller_carter"
                )
            }
            q.contains("country") || q.contains("pub") || q.contains("vintage") -> {
                AssistantChatMessage(
                    sender = "ASSISTANT",
                    text = "If you're looking for rural warmth, Premium Country Pubs and Vintage Inns provide rustic Georgian beams, crackling fireplaces, and scenic gardens. I highly recommend 'The George Premium Country Pub' located in Leigh Woods (3.1 miles away).",
                    actionCta = "NAV_SEARCH",
                    actionData = "premium_country"
                )
            }
            q.contains("offer") || q.contains("deal") || q.contains("discount") || q.contains("voucher") -> {
                AssistantChatMessage(
                    sender = "ASSISTANT",
                    text = "You have 3 active house offers: 20% off dinner at Browns, a free shaken cocktail at All Bar One, and kids eat for £1 at Toby Carvery! Tap below to open your loyalty wallet.",
                    actionCta = "NAV_OFFERS",
                    actionData = "offers"
                )
            }
            q.contains("brunch") || q.contains("cocktail") || q.contains("all bar one") -> {
                AssistantChatMessage(
                    sender = "ASSISTANT",
                    text = "For stylish cocktails, tapas, and bottomless brunch, All Bar One is the ultimate social hub! We have All Bar One Waterside in Bristol (0.5 miles away) which has bi-fold dockside glass walls and gorgeous sunset viewings.",
                    actionCta = "NAV_SEARCH",
                    actionData = "all_bar_one"
                )
            }
            q.contains("roast") || q.contains("carvery") || q.contains("toby") || q.contains("sunday") -> {
                AssistantChatMessage(
                    sender = "ASSISTANT",
                    text = "Sunday is a destination at Toby Carvery! Our Master Carvers slice slow-roasted beef, turkey, pork, and gammon with ruffled crisp roasties and giant golden Yorkshires. I've found Toby Carvery Maesknoll (4.2 miles away) for your next family roast feast.",
                    actionCta = "NAV_SEARCH",
                    actionData = "toby_carvery"
                )
            }
            q.contains("birmingham") -> {
                AssistantChatMessage(
                    sender = "ASSISTANT",
                    text = "In Birmingham, you have 3 fantastic venues: Browns Birmingham overlooking St Martin's Square, Miller & Carter Mailbox by the canals, and Toby Carvery Edgbaston in a beautiful Victorian redbrick manor.",
                    actionCta = "NAV_SEARCH",
                    actionData = "Birmingham"
                )
            }
            else -> {
                AssistantChatMessage(
                    sender = "ASSISTANT",
                    text = "I've searched your M&B House registry and found matching options in our multi-brand portfolio. Would you like to explore our full estate map or open our Brand Explorer?",
                    actionCta = "NAV_DISCOVER"
                )
            }
        }
    }


    // --- FEEDBACK & REVIEWS SYSTEM ---
    fun submitGuestFeedback(ratingFood: Int, ratingService: Int, ratingAtmosphere: Int, ratingValue: Int, comment: String) {
        val venueId = activeOrder.value.venueId.ifEmpty { "browns_bristol" }
        viewModelScope.launch {
            repository.insertFeedback(
                FeedbackEntity(
                    venueId = venueId,
                    ratingFood = ratingFood,
                    ratingService = ratingService,
                    ratingAtmosphere = ratingAtmosphere,
                    ratingValue = ratingValue,
                    comment = comment
                )
            )
            // Show successful message and return to account
            navigateTo(Screen.ACCOUNT)
        }
    }


    // --- ESTATE-WIDE SIMULATION ENGINE (BACKGROUND ROUTINES) ---
    // Simulates table transactions, cooking progressions, and booking arrivals globally
    private fun startGlobalSimulator() {
        simulatorJob = viewModelScope.launch {
            while (true) {
                delay(4000) // Run every 4 seconds
                
                // 1. Progress active order lines for active table session
                val session = activeOrder.value
                if (session.venueId.isNotEmpty() && session.tableNumber > 0) {
                    val orderLines = repository.getOrderLinesForTable(session.venueId, session.tableNumber).first()
                    var allDelivered = true
                    
                    orderLines.forEach { line ->
                        if (line.statusText == "PREPARING") {
                            repository.updateOrderLineStatus(line.id, "READY")
                            allDelivered = false
                        } else if (line.statusText == "READY") {
                            repository.updateOrderLineStatus(line.id, "DELIVERED")
                        } else if (line.statusText != "DELIVERED") {
                            allDelivered = false
                        }
                    }

                    // Automatically update table status
                    val tableId = "${session.venueId}_${session.tableNumber}"
                    if (orderLines.isNotEmpty()) {
                        val hasPreparing = orderLines.any { it.statusText == "PREPARING" }
                        val hasReady = orderLines.any { it.statusText == "READY" }
                        val nextStatus = when {
                            hasPreparing -> "PREPARING"
                            hasReady -> "READY"
                            else -> "SERVING"
                        }
                        if (session.statusText != "BILL_REQUESTED" && session.statusText != "CLEARED") {
                            repository.updateTableStatusOnly(tableId, nextStatus)
                            activeOrder.value = session.copy(statusText = nextStatus)
                        }
                    }
                }

                // 2. Global Estate Random Simulation (Flickering Digital Twin stats)
                val allVenuesList = repository.allVenues.first()
                if (allVenuesList.isNotEmpty()) {
                    val randomVenue = allVenuesList[Random.nextInt(allVenuesList.size)]
                    val tables = repository.getTablesForVenue(randomVenue.id).first()
                    if (tables.isNotEmpty()) {
                        val randomTable = tables[Random.nextInt(tables.size)]
                        val statuses = listOf("AVAILABLE", "RESERVED", "SEATED", "ORDERING", "BILL_REQUESTED")
                        val currentStatusIdx = statuses.indexOf(randomTable.statusText)
                        val nextStatus = if (currentStatusIdx != -1) {
                            statuses[(currentStatusIdx + 1) % statuses.size]
                        } else {
                            "AVAILABLE"
                        }
                        
                        val nextBill = if (nextStatus in listOf("SEATED", "ORDERING")) {
                            Random.nextDouble(18.0, 110.0)
                        } else 0.0

                        repository.updateTableState(
                            tableId = randomTable.tableId,
                            status = nextStatus,
                            bill = nextBill,
                            bookingId = randomTable.bookingId
                        )
                    }
                }
            }
        }
    }

    init {
        viewModelScope.launch {
            // Seed database
            repository.checkAndSeedData()
            // Start background twin updates
            startGlobalSimulator()
        }
    }

    override fun onCleared() {
        super.onCleared()
        simulatorJob?.cancel()
    }
}
