package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// M&B House Brand Palette
val MbCharcoal = Color(0xFF20201E)
val DeepInk = Color(0xFF181817)
val WarmWhite = Color(0xFFF5F1E8)
val Paper = Color(0xFFECE5D8)
val Stone = Color(0xFFD2C8B8)
val PubGreen = Color(0xFF334A3B)
val DeepForest = Color(0xFF23362C)
val Burgundy = Color(0xFF6B302E)
val Oxblood = Color(0xFF542622)
val Brass = Color(0xFFA77A3C)
val WarmGold = Color(0xFFC49A4A)
val Navy = Color(0xFF293B48)
val Slate = Color(0xFF626765)
val Cream = Color(0xFFF1E9D9)

// Android theme defaults mapping
val PrimaryDark = WarmGold
val OnPrimaryDark = DeepInk
val SecondaryDark = Brass
val BackgroundDark = MbCharcoal
val SurfaceDark = DeepInk

val PrimaryLight = MbCharcoal
val OnPrimaryLight = WarmWhite
val SecondaryLight = PubGreen
val BackgroundLight = WarmWhite
val SurfaceLight = Paper
