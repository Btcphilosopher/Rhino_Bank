package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entities.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.HospitalityViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue
import kotlin.random.Random
import androidx.compose.ui.geometry.Size

// ==========================================
// 1. HOME SCREEN
// ==========================================
@Composable
fun HomeScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val venues by viewModel.filteredVenues.collectAsState()
    val bookings by viewModel.bookings.collectAsState()
    val loyalty by viewModel.loyaltyAccount.collectAsState()
    
    val selectedMood by viewModel.filterCategory.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(WarmWhite)
    ) {
        // Hero Section with editorial style
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(MbCharcoal)
                .padding(20.dp),
            contentAlignment = Alignment.BottomStart
        ) {
            Column {
                Text(
                    text = "ONE HOUSE. MANY WAYS TO GO OUT.",
                    style = MaterialTheme.typography.displayMedium,
                    color = WarmWhite,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "FIND YOUR PLACE",
                    style = MaterialTheme.typography.labelLarge,
                    color = WarmGold,
                    letterSpacing = 2.sp
                )
            }
        }

        // What are you in the mood for?
        MoodNavigator(
            selectedMood = selectedMood,
            onMoodSelected = { category ->
                viewModel.filterCategory.value = category
                viewModel.navigateTo(Screen.SEARCH)
            }
        )

        // Upcoming reservation callout if any exists
        val activeBooking = bookings.firstOrNull { it.status == "CONFIRMED" }
        if (activeBooking != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
                    .clickable { viewModel.navigateTo(Screen.ACCOUNT) }
                    .testTag("home_active_booking_card"),
                colors = CardDefaults.cardColors(containerColor = Burgundy),
                border = BorderStroke(1.dp, WarmGold)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = "Reservation icon",
                        tint = WarmGold,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "TONIGHT'S PLANS",
                            style = MaterialTheme.typography.labelSmall,
                            color = WarmGold
                        )
                        Text(
                            text = activeBooking.venueName.uppercase(),
                            style = MaterialTheme.typography.titleLarge,
                            color = WarmWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${activeBooking.dateTimeText} • ${activeBooking.partySize} Guests",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Paper
                        )
                    }
                }
            }
        }

        // Near You horizontal reel
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "NEAR YOU",
                style = MaterialTheme.typography.labelLarge,
                color = MbCharcoal
            )
            Text(
                text = "VIEW ALL",
                style = MaterialTheme.typography.labelSmall,
                color = Brass,
                modifier = Modifier.clickable { viewModel.navigateTo(Screen.SEARCH) }
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.height(180.dp)
        ) {
            items(venues.take(5)) { venue ->
                Card(
                    modifier = Modifier
                        .width(260.dp)
                        .fillMaxHeight()
                        .clickable {
                            viewModel.selectedVenueId.value = venue.id
                            viewModel.navigateTo(Screen.VENUE_DETAILS)
                        }
                        .testTag("near_you_card_${venue.id}"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = venue.brandId.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = WarmGold
                            )
                            Text(
                                text = "${venue.distanceMiles} MILES",
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = venue.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MbCharcoal
                        )
                        Text(
                            text = "${venue.city} • Open until ${venue.openingHours.split("-").last().trim()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "BOOK TABLE →",
                                style = MaterialTheme.typography.labelMedium,
                                color = Brass,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Favourites / Discover Promo
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .clickable { viewModel.navigateTo(Screen.DISCOVER) }
                .testTag("home_discover_promo_card"),
            colors = CardDefaults.cardColors(containerColor = Cream)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "YOUR M&B JOURNEY",
                    style = MaterialTheme.typography.labelMedium,
                    color = Brass
                )
                Text(
                    text = "Explore 15+ Unique Brands Under One Account",
                    style = MaterialTheme.typography.displayMedium,
                    color = MbCharcoal,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Text(
                    text = "Your House registry connects grills, carveries, premium steakhouses, and local country pubs. Switch between brand personalities seamlessly.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate
                )
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = { viewModel.navigateTo(Screen.DISCOVER) },
                    colors = ButtonDefaults.buttonColors(containerColor = MbCharcoal),
                    modifier = Modifier.testTag("home_explore_brands_btn")
                ) {
                    Text("OPEN BRAND EXPLORER", color = WarmWhite)
                }
            }
        }
    }
}


// ==========================================
// 2. BRAND EXPLORER SCREEN (DISCOVER)
// ==========================================
@Composable
fun BrandExplorerScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val brands by viewModel.brands.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        Surface(
            color = MbCharcoal,
            contentColor = WarmWhite,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "DISCOVER M&B",
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold
                )
                Text(
                    text = "EDITORIAL COLLECTION",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    color = WarmWhite
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(brands) { brand ->
                val brandColor = Color(android.graphics.Color.parseColor(brand.accentColorHex))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.filterCategory.value = "All"
                            viewModel.searchQuery.value = brand.name
                            viewModel.navigateTo(Screen.SEARCH)
                        }
                        .testTag("brand_explorer_card_${brand.id}")
                ) {
                    Column {
                        // Brand Ribbon Header
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .background(brandColor)
                        )
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = brand.name.uppercase(),
                                    style = MaterialTheme.typography.displayMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MbCharcoal
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = "Go to brand venues",
                                    tint = brandColor
                                )
                            }
                            Text(
                                text = brand.headline,
                                style = MaterialTheme.typography.titleMedium,
                                color = brandColor,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                            Text(
                                text = brand.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Slate
                            )
                            
                            Spacer(modifier = Modifier.height(12.dp))
                            // Styled tags/keywords
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                brand.keywords.split(",").take(4).forEach { tag ->
                                    Box(
                                        modifier = Modifier
                                            .background(Paper, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = tag.uppercase(),
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                                            color = MbCharcoal,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 3. VENUE SEARCH & MAP SCREEN (SEARCH)
// ==========================================
@Composable
fun VenueSearchScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val searchResults by viewModel.filteredVenues.collectAsState()
    val rawQuery by viewModel.searchQuery.collectAsState()
    val cityFilter by viewModel.filterCity.collectAsState()
    
    var isMapView by remember { mutableStateOf(false) }

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        // Search Header
        Surface(
            color = MbCharcoal,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = rawQuery,
                    onValueChange = { viewModel.searchQuery.value = it },
                    placeholder = { Text("Search postcode, city, venue or brand...", color = Stone) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = WarmGold) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_text_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = WarmWhite,
                        unfocusedTextColor = WarmWhite,
                        focusedBorderColor = WarmGold,
                        unfocusedBorderColor = Stone,
                        focusedContainerColor = DeepInk,
                        unfocusedContainerColor = DeepInk
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))
                
                // City Filters row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val cities = listOf("All", "Bristol", "Birmingham", "London", "Cardiff")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(cities) { city ->
                            val isSelected = cityFilter == city
                            Box(
                                modifier = Modifier
                                    .background(
                                        color = if (isSelected) WarmGold else DeepInk,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .clickable { viewModel.filterCity.value = city }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("search_city_$city")
                            ) {
                                Text(
                                    text = city.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) DeepInk else WarmWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Map Toggle
                    IconButton(
                        onClick = { isMapView = !isMapView },
                        modifier = Modifier
                            .background(DeepInk, CircleShape)
                            .testTag("map_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (isMapView) Icons.Default.List else Icons.Default.Map,
                            contentDescription = "Toggle list map",
                            tint = WarmGold
                        )
                    }
                }
            }
        }

        // View display switcher
        if (isMapView) {
            Column(modifier = Modifier.fillMaxSize()) {
                MapClusterView(
                    selectedCity = cityFilter,
                    onCitySelected = { viewModel.filterCity.value = it },
                    onVenueClicked = { 
                        viewModel.selectedVenueId.value = it.id
                        viewModel.navigateTo(Screen.VENUE_DETAILS)
                    },
                    venues = searchResults
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "CHOOSE FROM ACTIVE MARKERS OR TAP A CITY BUBBLE",
                    style = MaterialTheme.typography.labelSmall,
                    color = Slate,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(searchResults) { venue ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectedVenueId.value = venue.id
                                viewModel.navigateTo(Screen.VENUE_DETAILS)
                            }
                            .testTag("search_venue_item_${venue.id}"),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = venue.brandId.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WarmGold,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Rating",
                                        tint = WarmGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${venue.ratingStars}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MbCharcoal
                                    )
                                }
                            }
                            Text(
                                text = venue.name,
                                style = MaterialTheme.typography.headlineMedium,
                                color = MbCharcoal,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${venue.city} • ${venue.postcode} • ${venue.distanceMiles} Miles Away",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Slate
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            // Actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.selectedVenueId.value = venue.id
                                        viewModel.navigateTo(Screen.BOOKING)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MbCharcoal),
                                    modifier = Modifier.weight(1f).testTag("venue_book_btn_${venue.id}")
                                ) {
                                    Text("BOOK A TABLE", color = WarmWhite)
                                }
                                OutlinedButton(
                                    onClick = {
                                        viewModel.selectedVenueId.value = venue.id
                                        viewModel.navigateTo(Screen.VENUE_DETAILS)
                                    },
                                    border = BorderStroke(1.dp, MbCharcoal),
                                    modifier = Modifier.weight(1f).testTag("venue_menu_btn_${venue.id}")
                                ) {
                                    Text("VIEW MENU", color = MbCharcoal)
                                }
                            }
                        }
                    }
                }

                if (searchResults.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "No results",
                                    tint = Slate,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "NO MATCHING HOUSE FOUND",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Slate
                                )
                                Text(
                                    text = "Try searching for alternative towns like Bristol or London, or clear filters.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Slate,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 4. VENUE DETAILS & INDIVIDUAL BRAND MODES
// ==========================================
@Composable
fun VenueDetailsScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val venue by viewModel.selectedVenue.collectAsState()
    val tableStates by remember(venue?.id) {
        val id = venue?.id
        if (id != null) viewModel.getTablesForVenue(id) else kotlinx.coroutines.flow.flowOf(emptyList())
    }.collectAsState(emptyList())
    
    var activeTab by remember { mutableStateOf("OVERVIEW") }

    BackHandler {
        viewModel.navigateBack()
    }

    if (venue == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val currentVenue = venue!!

    // Dynamic brand-styled container
    MbHouseTheme(brandId = currentVenue.brandId) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Brand-dynamic Cover Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(20.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                Column {
                    Text(
                        text = currentVenue.brandId.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary,
                        letterSpacing = 3.sp
                    )
                    Text(
                        text = currentVenue.name,
                        style = MaterialTheme.typography.displayLarge,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${currentVenue.city} • ${currentVenue.postcode}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                    )
                }
            }

            // Tabs Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                val tabs = listOf("OVERVIEW", "MENU", "DIGITAL TWIN")
                tabs.forEach { tab ->
                    val isSelected = activeTab == tab
                    val primaryColor = MaterialTheme.colorScheme.primary
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { activeTab = tab }
                            .drawBehind {
                                if (isSelected) {
                                    val strokeWidth = 3.dp.toPx()
                                    drawLine(
                                        color = primaryColor,
                                        start = Offset(0f, size.height - strokeWidth / 2),
                                        end = Offset(size.width, size.height - strokeWidth / 2),
                                        strokeWidth = strokeWidth
                                    )
                                }
                            }
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Slate
                        )
                    }
                }
            }

            // Tabs contents
            when (activeTab) {
                "OVERVIEW" -> {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "ARCHITECTURE & HISTORY",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Founded in ${currentVenue.foundedYear}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = currentVenue.historyText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Signature highlights
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "HOUSE SPECIALTIES",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row {
                                    Icon(Icons.Default.LocalBar, "Drink", tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(currentVenue.signatureDrinkName, fontWeight = FontWeight.Bold)
                                        Text(currentVenue.signatureDrinkDesc, style = MaterialTheme.typography.bodySmall, color = Slate)
                                    }
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Row {
                                    Icon(Icons.Default.Restaurant, "Dish", tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(currentVenue.signatureDishName, fontWeight = FontWeight.Bold)
                                        Text(currentVenue.signatureDishDesc, style = MaterialTheme.typography.bodySmall, color = Slate)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { viewModel.navigateTo(Screen.BOOKING) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("details_booking_cta")
                        ) {
                            Text("SCHEDULE RESERVATION", color = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }

                "MENU" -> {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "BRAND MENU & DISH INTELLIGENCE",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // Filter static menu catalogs for this brand
                        val brandMenu = viewModel.staticMenuCatalog.filter { it.brandId == currentVenue.brandId }
                        brandMenu.forEach { item ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = item.name,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = item.category,
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.sp),
                                                    color = MaterialTheme.colorScheme.secondary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                        Text(
                                            text = item.description,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Slate
                                        )
                                        Text(
                                            text = "Allergens: ${item.allergens} • ${item.flavorProfile}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Slate
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "£${"%.2f".format(item.price)}",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        IconButton(
                                            onClick = { 
                                                viewModel.addToCart(item)
                                                // Scan and seat table automatically if not already active to showcase table ordering
                                                if (viewModel.activeOrder.value.venueId.isEmpty()) {
                                                    viewModel.scanTable(currentVenue.id, 4)
                                                }
                                            },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                                                .testTag("menu_add_btn_${item.name.replace(" ", "_")}")
                                        ) {
                                            Icon(Icons.Default.Add, "Add to cart", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }

                        // Order Shortcut banner
                        val cartSession by viewModel.activeOrder.collectAsState()
                        if (cartSession.cartItems.isNotEmpty()) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                                    .clickable { viewModel.navigateTo(Screen.ORDER) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${cartSession.cartItems.size} items in order cart",
                                        color = MaterialTheme.colorScheme.onSecondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "VIEW TABLE ORDER →",
                                        color = MaterialTheme.colorScheme.onSecondary,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                "DIGITAL TWIN" -> {
                    Column(modifier = Modifier.padding(12.dp)) {
                        TableDigitalTwinLayout(
                            venueId = currentVenue.id,
                            tables = tableStates,
                            onTableClick = { tableNum ->
                                viewModel.scanTable(currentVenue.id, tableNum)
                                viewModel.navigateTo(Screen.ORDER)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun currentColorScheme() = MaterialTheme.colorScheme


// ==========================================
// 5. STEP-BY-STEP TABLE BOOKING ENGINE
// ==========================================
@Composable
fun BookingScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val venue by viewModel.selectedVenue.collectAsState()
    val formState by viewModel.bookingForm.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    if (venue == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a venue to book from the search page", color = MbCharcoal)
        }
        return
    }

    val currentVenue = venue!!

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(WarmWhite)
    ) {
        Surface(color = MbCharcoal, contentColor = WarmWhite, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "RESERVATION ENGINE",
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold
                )
                Text(
                    text = currentVenue.name.uppercase(),
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Step ${formState.step} of 3",
                    style = MaterialTheme.typography.labelLarge,
                    color = Stone
                )
            }
        }

        Column(modifier = Modifier.padding(20.dp)) {
            when (formState.step) {
                1 -> {
                    Text("WHEN ARE YOU VISITING?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    // Simple select list representing dates
                    val dates = listOf("Today, 27 September", "Tomorrow, 28 September", "Tuesday, 29 September", "Wednesday, 30 September")
                    dates.forEach { date ->
                        val isSelected = formState.selectedDate == date
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(1.dp, if (isSelected) WarmGold else Stone, RoundedCornerShape(8.dp))
                                .background(if (isSelected) MbCharcoal else Color.White, RoundedCornerShape(8.dp))
                                .clickable { viewModel.updateBookingForm { it.copy(selectedDate = date) } }
                                .padding(16.dp)
                                .testTag("date_option_$date"),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(date, fontWeight = FontWeight.Bold, color = if (isSelected) WarmWhite else MbCharcoal)
                            if (isSelected) Icon(Icons.Default.CheckCircle, "Selected", tint = WarmGold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("SELECT TIME", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    val times = listOf("12:00", "17:30", "19:30", "21:00")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        times.forEach { time ->
                            val isSelected = formState.selectedTime == time
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, if (isSelected) WarmGold else Stone, RoundedCornerShape(6.dp))
                                    .background(if (isSelected) MbCharcoal else Color.White, RoundedCornerShape(6.dp))
                                    .clickable { viewModel.updateBookingForm { it.copy(selectedTime = time) } }
                                    .padding(vertical = 12.dp)
                                    .testTag("time_option_$time"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(time, fontWeight = FontWeight.Bold, color = if (isSelected) WarmWhite else MbCharcoal)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { viewModel.updateBookingForm { it.copy(step = 2) } },
                        colors = ButtonDefaults.buttonColors(containerColor = MbCharcoal),
                        modifier = Modifier.fillMaxWidth().testTag("booking_next_1_btn")
                    ) {
                        Text("NEXT STEP", color = WarmWhite)
                    }
                }

                2 -> {
                    Text("GUESTS & OCCASION", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Number of Guests: ${formState.partySize}", fontWeight = FontWeight.Bold)
                    Slider(
                        value = formState.partySize.toFloat(),
                        onValueChange = { viewModel.updateBookingForm { f -> f.copy(partySize = it.toInt()) } },
                        valueRange = 1f..12f,
                        steps = 10,
                        colors = SliderDefaults.colors(thumbColor = WarmGold, activeTrackColor = MbCharcoal),
                        modifier = Modifier.testTag("party_size_slider")
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("WHAT ARE YOU CELEBRATING?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    val occasions = listOf("Birthday Celebration", "Date Night", "Sunday Roast Feast", "Christmas Event")
                    occasions.forEach { occ ->
                        val isSelected = formState.occasion == occ
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(1.dp, if (isSelected) WarmGold else Stone, RoundedCornerShape(8.dp))
                                .background(if (isSelected) MbCharcoal else Color.White, RoundedCornerShape(8.dp))
                                .clickable { viewModel.updateBookingForm { it.copy(occasion = occ) } }
                                .padding(14.dp)
                                .testTag("occasion_option_$occ")
                        ) {
                            Text(occ, color = if (isSelected) WarmWhite else MbCharcoal, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.updateBookingForm { it.copy(step = 1) } },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("BACK", color = MbCharcoal)
                        }
                        Button(
                            onClick = { viewModel.updateBookingForm { it.copy(step = 3) } },
                            colors = ButtonDefaults.buttonColors(containerColor = MbCharcoal),
                            modifier = Modifier.weight(1f).testTag("booking_next_2_btn")
                        ) {
                            Text("NEXT STEP", color = WarmWhite)
                        }
                    }
                }

                3 -> {
                    Text("SEATING & SELECTION", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    val seats = listOf("Standard Table", "Window View Table", "Cosy Dining Booth", "Outdoor Garden Space")
                    seats.forEach { seat ->
                        val isSelected = formState.seatingType == seat
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(1.dp, if (isSelected) WarmGold else Stone, RoundedCornerShape(8.dp))
                                .background(if (isSelected) MbCharcoal else Color.White, RoundedCornerShape(8.dp))
                                .clickable { viewModel.updateBookingForm { it.copy(seatingType = seat) } }
                                .padding(12.dp)
                                .testTag("seating_option_$seat")
                        ) {
                            Text(seat, color = if (isSelected) WarmWhite else MbCharcoal, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Special dietary or notes:", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = formState.specialRequests,
                        onValueChange = { notes -> viewModel.updateBookingForm { it.copy(specialRequests = notes) } },
                        modifier = Modifier.fillMaxWidth().testTag("booking_special_requests")
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Accessibility or wheelchair requests:", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = formState.accessibilityRequests,
                        onValueChange = { notes -> viewModel.updateBookingForm { it.copy(accessibilityRequests = notes) } },
                        modifier = Modifier.fillMaxWidth().testTag("booking_accessibility_requests")
                    )

                    Spacer(modifier = Modifier.height(24.dp))
                    // Summary receipt box
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Cream),
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, WarmGold)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("CONFIRMED PARAMETERS", style = MaterialTheme.typography.labelSmall, color = Brass)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("VENUE: ${currentVenue.name}", fontWeight = FontWeight.Bold)
                            Text("ARRIVING: ${formState.selectedDate} at ${formState.selectedTime}")
                            Text("SIZE: ${formState.partySize} Guests")
                            Text("CELEBRATING: ${formState.occasion}")
                            Text("SEATING: ${formState.seatingType}")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.updateBookingForm { it.copy(step = 2) } },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("BACK", color = MbCharcoal)
                        }
                        Button(
                            onClick = { viewModel.submitBooking() },
                            colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                            modifier = Modifier.weight(1f).testTag("booking_confirm_btn")
                        ) {
                            Text("CONFIRM TABLE", color = WarmWhite)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 6. ORDER AT TABLE & SPLIT BILL
// ==========================================
@Composable
fun OrderScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val session by viewModel.activeOrder.collectAsState()
    val orderLines by viewModel.activeTableOrderLines.collectAsState()
    val venues by viewModel.venues.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(WarmWhite)
    ) {
        Surface(color = MbCharcoal, contentColor = WarmWhite, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "ORDER AT TABLE",
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold
                )
                Text(
                    text = "DIGITAL SEAT GATEWAY",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (session.venueId.isEmpty()) {
            // Scanner simulator screen
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "SCAN QR CODE OR SELECT TABLE",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "To simulate ordering inside the pub, select a synthetic table twin below:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))
                venues.forEach { venue ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clickable { viewModel.scanTable(venue.id, 4) }
                            .testTag("scan_venue_option_${venue.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(venue.name, fontWeight = FontWeight.Bold)
                                Text("Assign to Table 4 (Tap to pair)", style = MaterialTheme.typography.bodySmall, color = Slate)
                            }
                            Icon(Icons.Default.QrCodeScanner, "Scan", tint = WarmGold)
                        }
                    }
                }
            }
        } else {
            // Active seat session
            val currentVenue = venues.find { it.id == session.venueId }
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(currentVenue?.name ?: "M&B House", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("TABLE ${session.tableNumber}", style = MaterialTheme.typography.labelLarge, color = WarmGold)
                    }
                    Box(
                        modifier = Modifier
                            .background(Burgundy, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = session.statusText,
                            color = WarmWhite,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("DIGITAL TABLE RECEIPT", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
                
                // Show currently ordered items
                if (orderLines.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.RestaurantMenu, "No orders", tint = Slate, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("NO DISHES DISPATCHED YET", style = MaterialTheme.typography.labelSmall, color = Slate)
                            Text("Navigate to Menu tab to order grills, steaks, or craft pints.", style = MaterialTheme.typography.bodySmall, color = Slate)
                        }
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            orderLines.forEach { line ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(line.dishName, fontWeight = FontWeight.Bold)
                                        Text("Price: £${"%.2f".format(line.price)}", style = MaterialTheme.typography.bodySmall, color = Slate)
                                    }
                                    
                                    // Live cooking pipelines indicator
                                    val statusColor = when (line.statusText) {
                                        "PREPARING" -> Color(0xFFC49A4A) // Gold
                                        "READY" -> Color(0xFF2E5A44) // Green
                                        else -> Slate // Delivered
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = line.statusText,
                                            color = statusColor,
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.sp),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            Divider(modifier = Modifier.padding(vertical = 10.dp))
                            val totalBill = orderLines.sumOf { it.price }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("TOTAL DUE", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                                Text("£${"%.2f".format(totalBill)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = Burgundy)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("BILL SPLITTING PROTOCOL", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    val splitTypes = listOf("EQUAL", "BY_PERSON")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        splitTypes.forEach { type ->
                            val isSelected = session.billSplittingType == type
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, if (isSelected) WarmGold else Stone, RoundedCornerShape(6.dp))
                                    .background(if (isSelected) MbCharcoal else Color.White, RoundedCornerShape(6.dp))
                                    .clickable { viewModel.setBillSplitting(type) }
                                    .padding(vertical = 12.dp)
                                    .testTag("split_type_$type"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(type.replace("_", " "), fontWeight = FontWeight.Bold, color = if (isSelected) WarmWhite else MbCharcoal)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    val totalBill = orderLines.sumOf { it.price }
                    when (session.billSplittingType) {
                        "EQUAL" -> {
                            Text("Divide Equally (Members: ${session.splitMembersCount})", fontWeight = FontWeight.Bold)
                            Slider(
                                value = session.splitMembersCount.toFloat(),
                                onValueChange = { viewModel.updateSplitMembers(it.toInt()) },
                                valueRange = 2f..8f,
                                steps = 5,
                                colors = SliderDefaults.colors(thumbColor = WarmGold, activeTrackColor = MbCharcoal),
                                modifier = Modifier.testTag("split_slider")
                            )
                            val perPerson = totalBill / session.splitMembersCount
                            Text(
                                text = "EACH MEMBER PAYS: £${"%.2f".format(perPerson)}",
                                style = MaterialTheme.typography.titleLarge,
                                color = Burgundy,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }

                        "BY_PERSON" -> {
                            // Render custom split shares
                            Column(modifier = Modifier.background(Color.White).padding(10.dp)) {
                                val members = listOf("Alice (You)", "James", "Sarah", "Tom")
                                val rates = listOf(0.25, 0.35, 0.20, 0.20)
                                members.forEachIndexed { idx, name ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(name, fontWeight = FontWeight.Bold)
                                        Text("£${"%.2f".format(totalBill * rates[idx])} (${(rates[idx] * 100).toInt()}%)", color = Slate)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    if (session.pinlessPaymentProcessing) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = WarmGold)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("CONTACTLESS TAP CHIP & PIN TERMINAL PROCESSING...", fontWeight = FontWeight.Bold)
                        }
                    } else if (session.pinlessPaymentSuccess) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = PubGreen),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.CheckCircle, "Approved", tint = WarmWhite, modifier = Modifier.size(36.dp))
                                    Text("TRANSACTION APPROVED SECURELY", color = WarmWhite, fontWeight = FontWeight.Bold)
                                    Text("You earned +80 Loyalty points! Receipt printed.", color = Paper, style = MaterialTheme.typography.bodySmall)
                                }
                            }

                            // Interactive Guest Review Form
                            var rFood by remember { mutableStateOf(5) }
                            var rService by remember { mutableStateOf(5) }
                            var rAtmosphere by remember { mutableStateOf(5) }
                            var rValue by remember { mutableStateOf(5) }
                            var commentText by remember { mutableStateOf("") }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Stone),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "RATE YOUR HOUSE VISIT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Brass,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    RatingStarsBlock(label = "Food Quality", rating = rFood, onRatingChange = { rFood = it })
                                    RatingStarsBlock(label = "Service", rating = rService, onRatingChange = { rService = it })
                                    RatingStarsBlock(label = "Atmosphere", rating = rAtmosphere, onRatingChange = { rAtmosphere = it })
                                    RatingStarsBlock(label = "Value for Money", rating = rValue, onRatingChange = { rValue = it })

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("Any additional comments?", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                    OutlinedTextField(
                                        value = commentText,
                                        onValueChange = { commentText = it },
                                        placeholder = { Text("How can we make your next visit even better?", color = Slate) },
                                        modifier = Modifier.fillMaxWidth().testTag("feedback_comment_input"),
                                        maxLines = 3
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))
                                    Button(
                                        onClick = {
                                            viewModel.submitGuestFeedback(rFood, rService, rAtmosphere, rValue, commentText)
                                            viewModel.exitOrderSession()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                                        modifier = Modifier.fillMaxWidth().testTag("submit_feedback_btn")
                                    ) {
                                        Text("SUBMIT GUEST REVIEW", color = WarmWhite)
                                    }
                                }
                            }
                        }
                    } else {
                        Button(
                            onClick = { viewModel.processSimulatedPayment() },
                            colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("payment_process_btn")
                        ) {
                            Text("SECURE CONTACTLESS PAYMENT", color = WarmWhite)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                OutlinedButton(
                    onClick = { viewModel.exitOrderSession() },
                    modifier = Modifier.fillMaxWidth().testTag("exit_session_btn")
                ) {
                    Text("EXIT DIGITAL TABLE SESSION", color = MbCharcoal)
                }
            }
        }
    }
}


// ==========================================
// 7. UNIFIED ACCOUNT, LOYALTY & PLANNERS
// ==========================================
@Composable
fun AccountScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val loyalty by viewModel.loyaltyAccount.collectAsState()
    val bookings by viewModel.bookings.collectAsState()
    val offers by viewModel.offers.collectAsState()
    val giftCards by viewModel.giftCards.collectAsState()

    var plannerPeople by remember { mutableStateOf("4") }
    var plannerBudget by remember { mutableStateOf("Budget (£50)") }
    var plannerGenerated by remember { mutableStateOf<List<String>?>(null) }

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(WarmWhite)
    ) {
        Surface(color = MbCharcoal, contentColor = WarmWhite, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "YOUR METRIC PROFILE",
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold
                )
                Text(
                    text = "MY HOUSE",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Loyalty Segment
        Column(modifier = Modifier.padding(20.dp)) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MbCharcoal),
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, WarmGold)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("M&B UNIFIED REWARDS", color = WarmGold, style = MaterialTheme.typography.labelMedium)
                        Box(
                            modifier = Modifier.background(WarmGold, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("${loyalty?.points ?: 0} PTS", color = DeepInk, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "ONE ACCOUNT. ANY BRAND.",
                        style = MaterialTheme.typography.headlineMedium,
                        color = WarmWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "You've completed ${loyalty?.visitsCount ?: 0} total house visits across Harvester, Toby Carvery, and Miller & Carter. Keep exploring to unlock Premium Country Pubs milestones!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Paper
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text("ACTIVE HOUSE OFFERS", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
            Spacer(modifier = Modifier.height(8.dp))
            
            offers.forEach { offer ->
                val brandColor = when (offer.brandId) {
                    "browns" -> Color(0xFF2E5A44)
                    "all_bar_one" -> Color(0xFFA77A3C)
                    "toby_carvery" -> Color(0xFF542622)
                    else -> MbCharcoal
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    border = BorderStroke(0.5.dp, Stone)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(brandColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = offer.discountPercent.toString() + "%",
                                color = WarmWhite,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(offer.title, fontWeight = FontWeight.Bold)
                            Text(offer.description, style = MaterialTheme.typography.bodySmall, color = Slate)
                            Text("Expires: ${offer.validUntil}", style = MaterialTheme.typography.labelSmall, color = Slate)
                        }
                        Box(
                            modifier = Modifier
                                .background(Paper, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .clickable { viewModel.navigateTo(Screen.SEARCH) }
                        ) {
                            Text("REDEEM", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            // Dining Out Gift Card Balance segment
            Spacer(modifier = Modifier.height(20.dp))
            Text("YOUR DINING OUT GIFT CARDS", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
            Spacer(modifier = Modifier.height(6.dp))
            giftCards.forEach { gc ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Cream),
                    border = BorderStroke(1.dp, WarmGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("GIFT CARD WALLET", style = MaterialTheme.typography.labelSmall, color = Brass)
                            Text("CARD ID: ${gc.id}", style = MaterialTheme.typography.labelSmall, color = Slate)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "BALANCE: £${"%.2f".format(gc.currentBalance)}",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = MbCharcoal
                        )
                        Text("For: ${gc.recipientName} • \"${gc.message}\"", style = MaterialTheme.typography.bodyMedium, color = Slate)
                        
                        // Fake barcode lines using canvas drawing
                        Spacer(modifier = Modifier.height(10.dp))
                        Canvas(modifier = Modifier.fillMaxWidth().height(30.dp)) {
                            val barWidth = 4f
                            var currentX = 0f
                            while (currentX < size.width) {
                                val spacing = Random.nextInt(2, 10)
                                drawRect(
                                    color = MbCharcoal,
                                    topLeft = Offset(currentX, 0f),
                                    size = Size(barWidth, size.height)
                                )
                                currentX += barWidth + spacing
                            }
                        }
                    }
                }
            }

            // NIGHT OUT EVENT PLANNER (Itinerary generator)
            Spacer(modifier = Modifier.height(20.dp))
            Text("PLAN YOUR NIGHT OUT ITINERARY", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Stone),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Select Party Size", fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = plannerPeople,
                        onValueChange = { plannerPeople = it },
                        modifier = Modifier.fillMaxWidth().testTag("planner_party_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Select Budget Tier", fontWeight = FontWeight.Bold)
                    val budgetOptions = listOf("Budget (£50)", "Premium (£150)", "Luxury Ultra (£400)")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        budgetOptions.forEach { opt ->
                            val isSelected = plannerBudget == opt
                            Box(
                                modifier = Modifier
                                    .background(if (isSelected) MbCharcoal else Paper, RoundedCornerShape(4.dp))
                                    .clickable { plannerBudget = opt }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = opt,
                                    color = if (isSelected) WarmWhite else MbCharcoal,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            plannerGenerated = if (plannerBudget.contains("Budget")) {
                                listOf(
                                    "17:30 • HARVESTER • Standard Family Grill & rotisserie platter",
                                    "19:30 • TOBY CARVERY • Four-Roast Feast with unlimited yorkshires",
                                    "21:30 • VINTAGE INNS • Two traditional pies and warm cask craft lager"
                                )
                            } else {
                                listOf(
                                    "18:30 • BROWNS BRASSERIE • Lobster, champagne starter and Devon crab pasta",
                                    "20:30 • MILLER & CARTER • Premium Certified dry-aged 12oz Ribeye steaks",
                                    "22:30 • ALL BAR ONE • Hand-shaken Espresso Martinis on waterside terrace"
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MbCharcoal),
                        modifier = Modifier.fillMaxWidth().testTag("planner_generate_btn")
                    ) {
                        Text("GENERATE MULTI-BRAND ITINERARY", color = WarmWhite)
                    }

                    if (plannerGenerated != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text("GENERATED EVENT PLAN", color = WarmGold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        plannerGenerated!!.forEach { stop ->
                            Text(
                                text = stop,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Favourites section
            Spacer(modifier = Modifier.height(20.dp))
            Text("YOUR HOUSE HISTORY & FAVORITES", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
            Spacer(modifier = Modifier.height(6.dp))
            bookings.forEach { past ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(past.venueName, fontWeight = FontWeight.Bold)
                            Text("Visited: ${past.dateTimeText}", style = MaterialTheme.typography.bodySmall, color = Slate)
                        }
                        Button(
                            onClick = {
                                viewModel.selectedVenueId.value = past.venueId
                                viewModel.navigateTo(Screen.BOOKING)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MbCharcoal)
                        ) {
                            Text("BOOK AGAIN", color = WarmWhite, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 8. AI HOSPITALITY ASSISTANT SCREEN (CHAT)
// ==========================================
@Composable
fun AssistantScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.assistantMessages.collectAsState()
    var currentQuery by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
    ) {
        Surface(color = MbCharcoal, contentColor = WarmWhite, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "AI STEWARD ASSISTANT",
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold
                )
                Text(
                    text = "M&B ASSISTANT",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Suggested prompts bubble desk
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("Suggested Queries:", style = MaterialTheme.typography.labelSmall, color = Slate)
            Spacer(modifier = Modifier.height(4.dp))
            val suggestions = listOf(
                "Find a country pub",
                "Show my upcoming bookings",
                "Where are late night bars?",
                "Find Miller & Carter nearby"
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(suggestions) { sugg ->
                    Box(
                        modifier = Modifier
                            .background(Paper, RoundedCornerShape(20.dp))
                            .clickable { viewModel.sendAssistantQuery(sugg) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("suggested_query_$sugg")
                    ) {
                        Text(sugg, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Messages list
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(messages) { msg ->
                val isUser = msg.sender == "USER"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) MbCharcoal else Color.White
                        ),
                        border = if (isUser) null else BorderStroke(1.dp, Stone),
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = msg.text,
                                color = if (isUser) WarmWhite else MbCharcoal,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            if (msg.actionCta != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        when (msg.actionCta) {
                                            "NAV_BOOK" -> {
                                                viewModel.selectedVenueId.value = msg.actionData
                                                viewModel.navigateTo(Screen.BOOKING)
                                            }
                                            "NAV_STEAK" -> {
                                                viewModel.searchQuery.value = "miller"
                                                viewModel.navigateTo(Screen.SEARCH)
                                            }
                                            "NAV_OFFERS" -> {
                                                viewModel.navigateTo(Screen.ACCOUNT)
                                            }
                                            "NAV_SEARCH" -> {
                                                viewModel.searchQuery.value = msg.actionData ?: ""
                                                viewModel.navigateTo(Screen.SEARCH)
                                            }
                                            else -> viewModel.navigateTo(Screen.DISCOVER)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = WarmGold),
                                    modifier = Modifier.testTag("assistant_cta_btn")
                                ) {
                                    Text("VIEW RECOMMENDED NOW", color = DeepInk, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Chat input bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = currentQuery,
                onValueChange = { currentQuery = it },
                placeholder = { Text("Ask anything about Mitchells & Butlers portfolio...", color = Slate) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("assistant_chat_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = WarmGold,
                    unfocusedBorderColor = Stone
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (currentQuery.isNotBlank()) {
                        viewModel.sendAssistantQuery(currentQuery)
                        currentQuery = ""
                        scope.launch {
                            listState.animateScrollToItem(messages.size)
                        }
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(MbCharcoal, CircleShape)
                    .testTag("assistant_send_btn")
            ) {
                Icon(Icons.Default.Send, "Send text", tint = WarmGold)
            }
        }
    }
}


// ==========================================
// 9. ESTATE-WIDE COMMAND MAP & OPERATION TWINS
// ==========================================
@Composable
fun EstateTwinScreen(
    viewModel: HospitalityViewModel,
    modifier: Modifier = Modifier
) {
    val venues by viewModel.venues.collectAsState()
    val feedbacks by viewModel.feedbacks.collectAsState()

    var selectedOperationalVenueId by remember { mutableStateOf("browns_bristol") }
    val selectedOpVenue = venues.find { it.id == selectedOperationalVenueId }
    
    val tablesList by remember(selectedOperationalVenueId) {
        viewModel.getTablesForVenue(selectedOperationalVenueId)
    }.collectAsState(emptyList())

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(WarmWhite)
    ) {
        Surface(color = MbCharcoal, contentColor = WarmWhite, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "EXECUTIVE PORTFOLIO TWIN CONTROL DESK",
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold
                )
                Text(
                    text = "M&B ESTATE SIMULATOR",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(modifier = Modifier.padding(20.dp)) {
            // General metrics cards
            Text("GROUP-WIDE ESTATE METRICS (1,700+ VENUES LIVE)", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
            Spacer(modifier = Modifier.height(10.dp))
            
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("TABLE UTILISATION", style = MaterialTheme.typography.labelSmall, color = Slate)
                        Text("78%", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = PubGreen)
                    }
                }
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("AVERAGE SERVICE WAIT", style = MaterialTheme.typography.labelSmall, color = Slate)
                        Text("11 MIN", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = Brass)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("KITCHEN LOAD", style = MaterialTheme.typography.labelSmall, color = Slate)
                        Text("HIGH", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = Burgundy)
                    }
                }
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("BAR DRINKS LOAD", style = MaterialTheme.typography.labelSmall, color = Slate)
                        Text("MEDIUM", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = WarmGold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            PerformanceChart()

            // Select a live venue digital twin to inspect
            Spacer(modifier = Modifier.height(20.dp))
            Text("DRILL DOWN TO VENUE DIGITAL TWIN", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
            Spacer(modifier = Modifier.height(8.dp))
            
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(venues) { venue ->
                    val isSelected = selectedOperationalVenueId == venue.id
                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isSelected) MbCharcoal else Color.White,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, if (isSelected) WarmGold else Stone, RoundedCornerShape(4.dp))
                            .clickable { selectedOperationalVenueId = venue.id }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("op_venue_select_${venue.id}")
                    ) {
                        Text(
                            text = venue.name,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) WarmWhite else MbCharcoal,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            if (selectedOpVenue != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "ROOM & DINING TWIN • " + selectedOpVenue.name.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = WarmGold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        TableDigitalTwinLayout(
                            venueId = selectedOpVenue.id,
                            tables = tablesList,
                            onTableClick = { }
                        )
                        
                        Divider(modifier = Modifier.padding(vertical = 12.dp))
                        Text("KITCHEN STATION LIVE COOKING QUEUES", fontWeight = FontWeight.Bold)
                        
                        val stations = listOf("GRILL STATION", "FRY STATION", "ROAST CARVING PASS", "BAR DISPATCH")
                        val queueCounts = listOf("3 ORDERS", "2 ORDERS", "5 ORDERS", "1 ORDER")
                        stations.forEachIndexed { index, station ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(station, style = MaterialTheme.typography.bodyMedium)
                                Box(
                                    modifier = Modifier.background(Cream, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(queueCounts[index], color = Burgundy, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Customer feedback analytic loops
            Spacer(modifier = Modifier.height(20.dp))
            Text("GUEST FEEDBACK LOOPS", style = MaterialTheme.typography.labelLarge, color = MbCharcoal)
            Spacer(modifier = Modifier.height(8.dp))
            feedbacks.forEach { feedback ->
                val currentVenue = venues.find { it.id == feedback.venueId }
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(currentVenue?.name ?: "M&B House", fontWeight = FontWeight.Bold)
                            Row {
                                repeat(feedback.ratingFood) {
                                    Icon(Icons.Default.Star, "Star", tint = WarmGold, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                        Text(
                            text = "\"${feedback.comment}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Slate
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RatingStarsBlock(
    label: String,
    rating: Int,
    onRatingChange: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (i in 1..5) {
                val isSelected = i <= rating
                Icon(
                    imageVector = if (isSelected) Icons.Default.Star else Icons.Default.StarOutline,
                    contentDescription = "$i stars selection",
                    tint = if (isSelected) WarmGold else Slate,
                    modifier = Modifier
                        .size(28.dp)
                        .clickable { onRatingChange(i) }
                )
            }
        }
    }
}

