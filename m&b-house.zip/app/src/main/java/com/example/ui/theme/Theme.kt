package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Platform color schemes
private val PlatformDarkColorScheme = darkColorScheme(
    primary = WarmGold,
    onPrimary = DeepInk,
    secondary = Brass,
    onSecondary = WarmWhite,
    background = MbCharcoal,
    onBackground = WarmWhite,
    surface = DeepInk,
    onSurface = WarmWhite,
    surfaceVariant = MbCharcoal,
    onSurfaceVariant = Stone
)

private val PlatformLightColorScheme = lightColorScheme(
    primary = MbCharcoal,
    onPrimary = WarmWhite,
    secondary = PubGreen,
    onSecondary = Cream,
    background = WarmWhite,
    onBackground = MbCharcoal,
    surface = Paper,
    onSurface = MbCharcoal,
    surfaceVariant = Stone,
    onSurfaceVariant = MbCharcoal
)

// Brand Color Schemes for the Brand Identity Engine
val HarvesterColorScheme = lightColorScheme(
    primary = Color(0xFF1F6F8B), // Teal
    onPrimary = Color.White,
    secondary = Color(0xFF154C60),
    onSecondary = Color.White,
    background = Color(0xFFF0F7F7),
    onBackground = Color(0xFF11333E),
    surface = Color.White,
    onSurface = Color(0xFF11333E),
    surfaceVariant = Color(0xFFD4ECEE),
    onSurfaceVariant = Color(0xFF1F6F8B)
)

val TobyCarveryColorScheme = lightColorScheme(
    primary = Color(0xFF542622), // Oxblood
    onPrimary = Color.White,
    secondary = Color(0xFF334A3B), // Green
    onSecondary = Color.White,
    background = Color(0xFFFAF7F2), // Warm Cream
    onBackground = Color(0xFF331714),
    surface = Color.White,
    onSurface = Color(0xFF331714),
    surfaceVariant = Color(0xFFECE5D8),
    onSurfaceVariant = Color(0xFF542622)
)

val MillerCarterColorScheme = darkColorScheme(
    primary = Color(0xFFC49A4A), // Premium Gold
    onPrimary = Color(0xFF181817),
    secondary = Color(0xFF20201E),
    onSecondary = Color(0xFFC49A4A),
    background = Color(0xFF121211), // Charcoal/Black
    onBackground = Color(0xFFFAF6F0),
    surface = Color(0xFF1C1C1A),
    onSurface = Color(0xFFFAF6F0),
    surfaceVariant = Color(0xFF2E2E2A),
    onSurfaceVariant = Color(0xFFC49A4A)
)

val AllBarOneColorScheme = lightColorScheme(
    primary = Color(0xFFA77A3C), // Brass
    onPrimary = Color.White,
    secondary = Color(0xFF7D5260),
    onSecondary = Color.White,
    background = Color(0xFFFDFBF7),
    onBackground = Color(0xFF2D2010),
    surface = Color.White,
    onSurface = Color(0xFF2D2010),
    surfaceVariant = Color(0xFFF1E9D9),
    onSurfaceVariant = Color(0xFFA77A3C)
)

val BrownsColorScheme = lightColorScheme(
    primary = Color(0xFF2E5A44), // Emerald
    onPrimary = Color.White,
    secondary = Color(0xFF6B302E), // Burgundy
    onSecondary = Color.White,
    background = Color(0xFFF5F1E8), // Ivory
    onBackground = Color(0xFF162B20),
    surface = Color.White,
    onSurface = Color(0xFF162B20),
    surfaceVariant = Color(0xFFE5DCD0),
    onSurfaceVariant = Color(0xFF2E5A44)
)

val PremiumCountryColorScheme = lightColorScheme(
    primary = Color(0xFF23362C), // Deep Forest
    onPrimary = Color.White,
    secondary = Color(0xFFD2C8B8), // Stone
    onSecondary = Color(0xFF23362C),
    background = Color(0xFFECE5D8), // Light Paper
    onBackground = Color(0xFF18261F),
    surface = Color.White,
    onSurface = Color(0xFF18261F),
    surfaceVariant = Color(0xFFDCD5C6),
    onSurfaceVariant = Color(0xFF23362C)
)

val NicholsonsColorScheme = lightColorScheme(
    primary = Color(0xFF293B48), // Slate Navy
    onPrimary = Color.White,
    secondary = Color(0xFFA77A3C), // Brass
    onSecondary = Color.White,
    background = Color(0xFFF1E9D9),
    onBackground = Color(0xFF162128),
    surface = Color.White,
    onSurface = Color(0xFF162128),
    surfaceVariant = Color(0xFFE2D6BE),
    onSurfaceVariant = Color(0xFF293B48)
)

val VintageInnsColorScheme = lightColorScheme(
    primary = Color(0xFF6B302E), // Burgundy
    onPrimary = Color.White,
    secondary = Color(0xFF334A3B), // Pub Green
    onSecondary = Color.White,
    background = Color(0xFFF5F1E8),
    onBackground = Color(0xFF3D1615),
    surface = Color.White,
    onSurface = Color(0xFF3D1615),
    surfaceVariant = Color(0xFFECE5D8),
    onSurfaceVariant = Color(0xFF6B302E)
)

@Composable
fun MbHouseTheme(
    brandId: String? = null,
    darkTheme: Boolean = false, // We prioritize beautiful light/editorial themes or specific brand themes
    content: @Composable () -> Unit
) {
    val colorScheme = when (brandId) {
        "harvester" -> HarvesterColorScheme
        "toby_carvery" -> TobyCarveryColorScheme
        "miller_carter" -> MillerCarterColorScheme
        "all_bar_one" -> AllBarOneColorScheme
        "browns" -> BrownsColorScheme
        "premium_country" -> PremiumCountryColorScheme
        "nicholsons" -> NicholsonsColorScheme
        "vintage_inns" -> VintageInnsColorScheme
        else -> {
            if (darkTheme) PlatformDarkColorScheme else PlatformLightColorScheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
