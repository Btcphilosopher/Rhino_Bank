package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entities.BrandEntity
import com.example.data.entities.VenueEntity
import com.example.ui.theme.*

@Composable
fun AppHeader(
    title: String,
    subtitle: String,
    onAssistantClick: () -> Unit,
    onEstateTwinClick: () -> Unit
) {
    Surface(
        color = MbCharcoal,
        contentColor = WarmWhite,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.displayMedium,
                    color = WarmWhite
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = onAssistantClick,
                    modifier = Modifier
                        .size(44.dp)
                        .background(DeepInk, CircleShape)
                        .testTag("header_assistant_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.SmartToy,
                        contentDescription = "AI Assistant",
                        tint = WarmGold
                    )
                }
                IconButton(
                    onClick = onEstateTwinClick,
                    modifier = Modifier
                        .size(44.dp)
                        .background(DeepInk, CircleShape)
                        .testTag("header_estate_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Analytics,
                        contentDescription = "Estate twin simulation",
                        tint = WarmGold
                    )
                }
            }
        }
    }
}

@Composable
fun MoodNavigator(
    selectedMood: String,
    onMoodSelected: (String) -> Unit
) {
    val moods = listOf("All", "STEAK", "CARVERY", "BRUNCH", "BAR", "FAMILY")
    val icons = listOf(
        Icons.Default.Restaurant,
        Icons.Default.BreakfastDining,
        Icons.Default.LunchDining,
        Icons.Default.LocalBar,
        Icons.Default.People
    )

    Column(modifier = Modifier.padding(vertical = 12.dp)) {
        Text(
            text = "WHAT ARE YOU IN THE MOOD FOR?",
            style = MaterialTheme.typography.labelSmall,
            color = Slate,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(moods) { mood ->
                val isSelected = selectedMood == mood
                InputChip(
                    selected = isSelected,
                    onClick = { onMoodSelected(mood) },
                    label = { 
                        Text(
                            text = mood, 
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        ) 
                    },
                    colors = InputChipDefaults.inputChipColors(
                        selectedContainerColor = MbCharcoal,
                        selectedLabelColor = WarmWhite,
                        containerColor = Paper,
                        labelColor = MbCharcoal
                    ),
                    border = null,
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("mood_chip_$mood")
                )
            }
        }
    }
}

@Composable
fun MapClusterView(
    selectedCity: String,
    onCitySelected: (String) -> Unit,
    onVenueClicked: (VenueEntity) -> Unit,
    venues: List<VenueEntity>
) {
    // Simplified custom-drawn Vector map of Great Britain (UK geography layout)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(380.dp)
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = Paper),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Draw highly abstract simplified UK coastal outlines
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(width * 0.45f, height * 0.05f) // Scotland north
                    quadraticTo(width * 0.35f, height * 0.15f, width * 0.40f, height * 0.25f)
                    quadraticTo(width * 0.30f, height * 0.35f, width * 0.42f, height * 0.45f) // Scotland boundary
                    quadraticTo(width * 0.46f, height * 0.55f, width * 0.50f, height * 0.65f) // North England
                    quadraticTo(width * 0.55f, height * 0.70f, width * 0.60f, height * 0.78f) // East England
                    quadraticTo(width * 0.55f, height * 0.85f, width * 0.52f, height * 0.95f) // South East/London
                    lineTo(width * 0.35f, height * 0.95f) // South Coast
                    quadraticTo(width * 0.25f, height * 0.90f, width * 0.30f, height * 0.82f) // Land's End / Bristol
                    quadraticTo(width * 0.22f, height * 0.75f, width * 0.28f, height * 0.68f) // Wales
                    quadraticTo(width * 0.38f, height * 0.60f, width * 0.45f, height * 0.50f) // West Coast
                    close()
                }

                // Fill UK Landmass with smooth natural stone pub color
                drawPath(path, color = Color(0xFFDFD7C7))
                drawPath(path, color = Color(0x33626765), style = Stroke(width = 3.dp.toPx()))

                // Draw major cities clusters
                // Bristol
                drawCircle(
                    color = Color(0x3323362C),
                    radius = 28.dp.toPx(),
                    center = Offset(width * 0.34f, height * 0.84f)
                )
                drawCircle(
                    color = Color(0xFF23362C),
                    radius = 8.dp.toPx(),
                    center = Offset(width * 0.34f, height * 0.84f)
                )

                // Birmingham
                drawCircle(
                    color = Color(0x33542622),
                    radius = 24.dp.toPx(),
                    center = Offset(width * 0.43f, height * 0.74f)
                )
                drawCircle(
                    color = Color(0xFF542622),
                    radius = 8.dp.toPx(),
                    center = Offset(width * 0.43f, height * 0.74f)
                )

                // London
                drawCircle(
                    color = Color(0x33A77A3C),
                    radius = 32.dp.toPx(),
                    center = Offset(width * 0.48f, height * 0.86f)
                )
                drawCircle(
                    color = Color(0xFFA77A3C),
                    radius = 8.dp.toPx(),
                    center = Offset(width * 0.48f, height * 0.86f)
                )

                // Cardiff
                drawCircle(
                    color = Color(0x331F6F8B),
                    radius = 20.dp.toPx(),
                    center = Offset(width * 0.29f, height * 0.82f)
                )
                drawCircle(
                    color = Color(0xFF1F6F8B),
                    radius = 8.dp.toPx(),
                    center = Offset(width * 0.29f, height * 0.82f)
                )
            }

            // Click overlays for city circles
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind { }
            ) {
                // Interactive labels
                CityMarkerLabel(
                    name = "BRISTOL",
                    count = venues.count { it.city == "Bristol" },
                    offsetFractionX = 0.34f,
                    offsetFractionY = 0.81f,
                    isSelected = selectedCity == "Bristol",
                    onClick = { onCitySelected("Bristol") }
                )

                CityMarkerLabel(
                    name = "BIRMINGHAM",
                    count = venues.count { it.city == "Birmingham" },
                    offsetFractionX = 0.43f,
                    offsetFractionY = 0.70f,
                    isSelected = selectedCity == "Birmingham",
                    onClick = { onCitySelected("Birmingham") }
                )

                CityMarkerLabel(
                    name = "LONDON",
                    count = venues.count { it.city == "London" },
                    offsetFractionX = 0.48f,
                    offsetFractionY = 0.88f,
                    isSelected = selectedCity == "London",
                    onClick = { onCitySelected("London") }
                )

                CityMarkerLabel(
                    name = "CARDIFF",
                    count = venues.count { it.city == "Cardiff" },
                    offsetFractionX = 0.26f,
                    offsetFractionY = 0.78f,
                    isSelected = selectedCity == "Cardiff",
                    onClick = { onCitySelected("Cardiff") }
                )
            }

            // Small watermark
            Text(
                text = "M&B SYNTHETIC ESTATE MAP",
                style = MaterialTheme.typography.labelSmall,
                color = Slate,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
            )
        }
    }
}

@Composable
fun BoxScope.CityMarkerLabel(
    name: String,
    count: Int,
    offsetFractionX: Float,
    offsetFractionY: Float,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val backgroundColor = if (isSelected) MbCharcoal else Color.White.copy(alpha = 0.85f)
    val textColor = if (isSelected) WarmWhite else MbCharcoal
    
    Card(
        shape = RoundedCornerShape(4.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .align(Alignment.TopStart)
            .offset(
                x = (offsetFractionX * 300).dp, // approximate canvas scaling
                y = (offsetFractionY * 340).dp
            )
            .clickable { onClick() }
            .testTag("city_marker_$name")
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = name,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                fontWeight = FontWeight.Bold,
                color = textColor
            )
            Text(
                text = "$count VENUES",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.sp),
                color = if (isSelected) WarmGold else Slate
            )
        }
    }
}

@Composable
fun TableDigitalTwinLayout(
    venueId: String,
    tables: List<com.example.data.entities.TableStateEntity>,
    onTableClick: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "RESTAURANT TABLE TWIN MONITOR",
            style = MaterialTheme.typography.labelLarge,
            color = MbCharcoal,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = "Click table to simulate digital seat pairing or trigger orders",
            style = MaterialTheme.typography.bodySmall,
            color = Slate,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Render standard grid representing dining layout
        val gridRows = 3
        val gridCols = 4
        
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (row in 0 until gridRows) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (col in 0 until gridCols) {
                        val index = row * gridCols + col
                        if (index < tables.size) {
                            val table = tables[index]
                            
                            val statusColor = when (table.statusText) {
                                "AVAILABLE" -> Color(0xFF334A3B) // Pub Green
                                "RESERVED" -> Color(0xFFC49A4A) // Warm Gold
                                "SEATED", "ORDERING" -> Color(0xFF626765) // Slate
                                "PREPARING", "READY" -> Color(0xFF6B302E) // Burgundy/Preparing
                                "BILL_REQUESTED" -> Color(0xFF542622) // Oxblood
                                else -> Color(0xFF20201E)
                            }

                            Box(
                                modifier = Modifier
                                    .size(width = 75.dp, height = 65.dp)
                                    .background(statusColor, RoundedCornerShape(8.dp))
                                    .clickable { onTableClick(table.tableNumber) }
                                    .testTag("table_twin_box_${table.tableNumber}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "T${table.tableNumber}",
                                        color = WarmWhite,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = table.statusText.take(10),
                                        color = Stone,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.sp)
                                    )
                                    if (table.currentBillAmount > 0) {
                                        Text(
                                            text = "£${"%.2f".format(table.currentBillAmount)}",
                                            color = WarmWhite,
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PerformanceChart() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MbCharcoal)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "DEMAND & TABLE UTILISATION HOURLY PROFILE",
                style = MaterialTheme.typography.labelSmall,
                color = WarmGold
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            // Draw synthetic utilization bar graph using Compose Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height
                val barWidth = width / 12f
                val ratings = listOf(15f, 22f, 45f, 50f, 32f, 25f, 60f, 85f, 95f, 75f, 40f, 15f)
                
                ratings.forEachIndexed { idx, value ->
                    val barHeight = height * (value / 100f)
                    drawRoundRect(
                        color = if (idx in 7..9) Color(0xFFC49A4A) else Color(0x99A77A3C),
                        topLeft = Offset(idx * barWidth + 4.dp.toPx(), height - barHeight),
                        size = Size(barWidth - 8.dp.toPx(), barHeight),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                }
            }
        }
    }
}
