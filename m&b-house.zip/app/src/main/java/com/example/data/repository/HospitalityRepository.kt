package com.example.data.repository

import com.example.data.dao.HospitalityDao
import com.example.data.entities.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class HospitalityRepository(private val dao: HospitalityDao) {

    // --- BRANDS ---
    val allBrands: Flow<List<BrandEntity>> = dao.getAllBrands()
    suspend fun getBrandById(id: String): BrandEntity? = dao.getBrandById(id)

    // --- VENUES ---
    val allVenues: Flow<List<VenueEntity>> = dao.getAllVenues()
    fun getVenuesByBrand(brandId: String): Flow<List<VenueEntity>> = dao.getVenuesByBrand(brandId)
    suspend fun getVenueById(id: String): VenueEntity? = dao.getVenueById(id)
    val favoriteVenues: Flow<List<VenueEntity>> = dao.getFavoriteVenues()
    suspend fun updateFavoriteStatus(id: String, isFav: Boolean) = dao.updateFavoriteStatus(id, isFav)

    // --- BOOKINGS ---
    val allBookings: Flow<List<BookingEntity>> = dao.getAllBookings()
    suspend fun getBookingById(id: Int): BookingEntity? = dao.getBookingById(id)
    suspend fun insertBooking(booking: BookingEntity): Long = dao.insertBooking(booking)
    suspend fun deleteBooking(id: Int) = dao.deleteBooking(id)

    // --- TABLES (DIGITAL TWIN) ---
    fun getTablesForVenue(venueId: String): Flow<List<TableStateEntity>> = dao.getTablesForVenue(venueId)
    suspend fun getTableById(tableId: String): TableStateEntity? = dao.getTableById(tableId)
    suspend fun updateTableState(tableId: String, status: String, bill: Double, bookingId: Int) = 
        dao.updateTableState(tableId, status, bill, bookingId)
    suspend fun updateTableStatusOnly(tableId: String, status: String) = dao.updateTableStatusOnly(tableId, status)

    // --- ORDER LINES ---
    fun getOrderLinesForTable(venueId: String, tableNumber: Int): Flow<List<OrderLineEntity>> = 
        dao.getOrderLinesForTable(venueId, tableNumber)
    suspend fun insertOrderLines(orderLines: List<OrderLineEntity>) = dao.insertOrderLines(orderLines)
    suspend fun updateOrderLineStatus(lineId: Int, status: String) = dao.updateOrderLineStatus(lineId, status)
    suspend fun clearOrderLinesForTable(venueId: String, tableNumber: Int) = dao.clearOrderLinesForTable(venueId, tableNumber)

    // --- LOYALTY ---
    val loyaltyAccount: Flow<LoyaltyAccountEntity?> = dao.getLoyaltyAccountFlow()
    suspend fun updateLoyaltyAccount(account: LoyaltyAccountEntity) = dao.insertLoyaltyAccount(account)

    // --- OFFERS ---
    val allOffers: Flow<List<OfferEntity>> = dao.getAllOffers()
    suspend fun redeemOffer(id: String) = dao.redeemOffer(id)

    // --- GIFT CARDS ---
    val allGiftCards: Flow<List<GiftCardEntity>> = dao.getAllGiftCards()
    suspend fun updateGiftCardBalance(id: String, balance: Double) = dao.updateGiftCardBalance(id, balance)
    suspend fun insertGiftCards(cards: List<GiftCardEntity>) = dao.insertGiftCards(cards)

    // --- FEEDBACKS ---
    val allFeedback: Flow<List<FeedbackEntity>> = dao.getAllFeedback()
    suspend fun insertFeedback(feedback: FeedbackEntity) = dao.insertFeedback(feedback)


    // --- SYNTHETIC DATABASE PREPOPULATION ENGINE ---
    suspend fun checkAndSeedData() {
        val brandsCount = dao.getAllBrands().first().size
        if (brandsCount > 0) return // Already seeded

        // 1. Seed Brands
        val brands = listOf(
            BrandEntity(
                id = "harvester",
                name = "Harvester",
                headline = "Warmed grills, fresh rotisserie & the legendary unlimited salad bar",
                description = "Harvester has been the favorite family restaurant brand across Britain for decades. Known for charred grills, rotisserie chicken, premium family value, and of course, our iconic unlimited salad bar where everything is crisp and freshly sliced.",
                accentColorHex = "#1F6F8B", // Teal/Cyan Accents
                secondaryColorHex = "#EBF6F5",
                styleVibe = "family_grill",
                keywords = "family,salad,rotisserie,grill,kid,unlimited,burger,chicken"
            ),
            BrandEntity(
                id = "toby_carvery",
                name = "Toby Carvery",
                headline = "Sunday is a destination. Home of the legendary roast",
                description = "The undisputed Home of the Roast. Every single day, our Master Carvers prepare succulent joints of beef, pork, turkey, and glazed gammon, accompanied by giant Yorkshires, ruffled roasties, and fresh seasonal veg.",
                accentColorHex = "#542622", // Roast Oxblood
                secondaryColorHex = "#F9F6F0",
                styleVibe = "sunday_roast",
                keywords = "roast,beef,pork,yorkshire,gravy,sunday,carvery,family,meat,seasonal"
            ),
            BrandEntity(
                id = "miller_carter",
                name = "Miller & Carter",
                headline = "The elite steakhouse experience. Masters of steak",
                description = "For the love of steak. We are proud of our farm-to-fork practices, offering 30-day aged cuts expertly grilled to your precision by certified Steak Masters. Uncompromising steaks, luxury wines, and refined service.",
                accentColorHex = "#C49A4A", // Premium Gold
                secondaryColorHex = "#181817", // Black Carbon
                styleVibe = "steakhouse",
                keywords = "steak,ribeye,sirloin,filet,beef,luxury,wine,fine,romantic,celebrate"
            ),
            BrandEntity(
                id = "all_bar_one",
                name = "All Bar One",
                headline = "Vibrant high-street cocktail bars, tapas & social dining",
                description = "Your modern high-street social hub. From bottomless brunch to curated tapas boards and an incredible selection of hand-shaken cocktails. This is the ultimate place for team catch-ups, date nights, and evening drinks.",
                accentColorHex = "#A77A3C", // Brass/Bronze
                secondaryColorHex = "#20201E",
                styleVibe = "cocktail_social",
                keywords = "cocktail,brunch,tapas,bar,social,drink,girl,night,highstreet"
            ),
            BrandEntity(
                id = "browns",
                name = "Browns Brasserie",
                headline = "Refined brasseries, classic dining, & afternoon tea",
                description = "Bustling, beautiful, and sophisticated. Set in iconic historic buildings, Browns has been delivering classical French-influenced British brasserie dishes, afternoon teas, and exquisite champagnes since 1973.",
                accentColorHex = "#2E5A44", // Deep Emerald
                secondaryColorHex = "#F5F1E8",
                styleVibe = "brasserie",
                keywords = "brasserie,afternoon,tea,champagne,lobster,fish,classy,romantic,bristol"
            ),
            BrandEntity(
                id = "premium_country",
                name = "Premium Country Pubs",
                headline = "Welcoming, stylish & relaxing country destinations",
                description = "Nestled in spectacular British countryside, our locations combine beautifully restored historic architecture with roaring open fires, idyllic beer gardens, and seasonal gastronomy made for long lunches.",
                accentColorHex = "#23362C", // Forest Green
                secondaryColorHex = "#ECE5D8",
                styleVibe = "country",
                keywords = "country,garden,rustic,fireplace,wood,scenic,roam,village,sunday"
            ),
            BrandEntity(
                id = "nicholsons",
                name = "Nicholson's Pubs",
                headline = "Classic historic British pubs, real ale & gin trails",
                description = "Founded in 1873, Nicholson's preserves the unique architectural heritage of classic British victorian public houses. Famous for real cask ales, artisanal gin, and classic pub fare like hand-battered fish & chips.",
                accentColorHex = "#293B48", // Slate Navy
                secondaryColorHex = "#EBEBEB",
                styleVibe = "historic",
                keywords = "historic,pub,ale,gin,fish,cask,traditional,victorian,london"
            ),
            BrandEntity(
                id = "vintage_inns",
                name = "Vintage Inns",
                headline = "Cosy village pubs with classic character & heart",
                description = "Discover a warm village welcome, crackling log fires, and a menu filled with comforting traditional pub classics. The quintessential English country pub experience built for walkers and families.",
                accentColorHex = "#6B302E", // Warm Burgundy
                secondaryColorHex = "#F5F1E8",
                styleVibe = "village_cosy",
                keywords = "cosy,log,fire,village,traditional,pie,dog,walker,nature"
            )
        )
        dao.insertBrands(brands)

        // 2. Seed Venues (15+ venues across cities like Bristol, Birmingham, London, Cardiff)
        val venues = listOf(
            // Browns
            VenueEntity(
                id = "browns_bristol",
                brandId = "browns",
                name = "Browns Bristol",
                city = "Bristol",
                postcode = "BS8 1RE",
                distanceMiles = 0.8,
                lat = 51.4582,
                lng = -2.6025,
                openingHours = "09:00 - 23:00",
                foundedYear = 1973,
                architecture = "Venetian Gothic masterpiece building with towering high arches",
                historyText = "Formerly the Bristol Museum & Library, this iconic building has high gothic arches and elegant dining tiers that make it a local architectural jewel.",
                signatureDrinkName = "Elderflower French 75",
                signatureDrinkDesc = "Browns Prosecco, Hendrick's Gin, elderflower and fresh lemon juice",
                signatureDishName = "Lobster & Devon Crab Tagliolini",
                signatureDishDesc = "Hand-picked crab, half lobster tail, cherry tomatoes, white wine, garlic and red chilli",
                ratingStars = 4.7,
                features = "WIFI,ACCESSIBLE,PRIVATE_DINING,AFTERNOON_TEA,BRUNCH"
            ),
            VenueEntity(
                id = "browns_birmingham",
                brandId = "browns",
                name = "Browns Birmingham",
                city = "Birmingham",
                postcode = "B5 4BU",
                distanceMiles = 2.4,
                lat = 52.4781,
                lng = -1.8931,
                openingHours = "10:00 - 23:00",
                foundedYear = 1994,
                architecture = "Contemporary glass brasserie overlooking St Martin's Square",
                historyText = "Situated in the heart of the Bullring, offering spectacular views of historic St Martin's Church from its gorgeous, light-filled glass terrace.",
                signatureDrinkName = "Rhubarb & Cucumber Collins",
                signatureDrinkDesc = "Slingsby Rhubarb Gin, fresh cucumber, lemon juice, topped with club soda",
                signatureDishName = "Pan-Seared Cod Gremolata",
                signatureDishDesc = "With chorizo, squid, butterbeans, slow-roasted tomatoes, salsa verde and sea-vegetables",
                ratingStars = 4.6,
                features = "WIFI,ACCESSIBLE,TERRACE,COCKTAIL_BAR"
            ),
            // Miller & Carter
            VenueEntity(
                id = "miller_bristol",
                brandId = "miller_carter",
                name = "Miller & Carter Bristol City",
                city = "Bristol",
                postcode = "BS1 5DB",
                distanceMiles = 1.2,
                lat = 51.4533,
                lng = -2.5971,
                openingHours = "12:00 - 22:30",
                foundedYear = 2012,
                architecture = "Restored heritage banking hall with grand mahogany paneling",
                historyText = "Inhabiting an elegant 19th-century bank. The high ceilings and dark mahogany create a grand, intimate steakhouse dining vault.",
                signatureDrinkName = "Rich Espresso Martini",
                signatureDrinkDesc = "Ketel One Vodka, Kahlúa, fresh espresso, shaken with toasted hazelnut syrup",
                signatureDishName = "30-Day Aged Ribeye (12oz)",
                signatureDishDesc = "Served with our signature onion loaf, balsamic glazed beef tomato, and our lettuce wedge with bacon & blue cheese",
                ratingStars = 4.8,
                features = "WIFI,ACCESSIBLE,STEAK_MASTER,WINE_CELLAR"
            ),
            VenueEntity(
                id = "miller_birmingham",
                brandId = "miller_carter",
                name = "Miller & Carter Birmingham Mailbox",
                city = "Birmingham",
                postcode = "B1 1XL",
                distanceMiles = 1.1,
                lat = 52.4760,
                lng = -1.9056,
                openingHours = "12:00 - 23:00",
                foundedYear = 2008,
                architecture = "Ultra-modern waterside dining terrace with plush leather booths",
                historyText = "Overlooking the vibrant canals of the Mailbox. Featuring open theatre kitchens and glass dry-aging chambers for sensory steak exploration.",
                signatureDrinkName = "The Smoky Old Fashioned",
                signatureDrinkDesc = "Woodford Reserve Bourbon, brown sugar, Angostura, applewood smoke infusion",
                signatureDishName = "Chateaubriand (16oz for two)",
                signatureDishDesc = "The ultimate cut from the tenderloin, sliced at table. Exquisitely tender and juicy",
                ratingStars = 4.9,
                features = "WIFI,WATERSIDE,ACCESSIBLE,STEAK_MASTER"
            ),
            // Toby Carvery
            VenueEntity(
                id = "toby_bristol",
                brandId = "toby_carvery",
                name = "Toby Carvery Maesknoll",
                city = "Bristol",
                postcode = "BS14 0RE",
                distanceMiles = 4.2,
                lat = 51.4095,
                lng = -2.5645,
                openingHours = "08:00 - 22:00",
                foundedYear = 1985,
                architecture = "Traditional farmhouse style build with heavy oak beams",
                historyText = "Seeded on the historical main southern toll-road out of Bristol. A comforting haven of home cooking since the mid-1980s.",
                signatureDrinkName = "British Orchard Cider",
                signatureDrinkDesc = "Crisp, cold-pressed Somerset apples, served over ice with fresh mint",
                signatureDishName = "Four-Roast Carver's Feast",
                signatureDishDesc = "A choice of beef, turkey, pork, or gammon, freshly carved onto your plate with giant Yorkshires and unlimited roasties",
                ratingStars = 4.4,
                features = "WIFI,FAMILY,GARDEN,ACCESSIBLE,BREAKFAST_BUFFET"
            ),
            VenueEntity(
                id = "toby_birmingham",
                brandId = "toby_carvery",
                name = "Toby Carvery Edgbaston",
                city = "Birmingham",
                postcode = "B17 8HJ",
                distanceMiles = 3.1,
                lat = 52.4644,
                lng = -1.9425,
                openingHours = "08:00 - 22:00",
                foundedYear = 1979,
                architecture = "Victorian redbrick manor convert with cosy stone fireplaces",
                historyText = "A beautiful historic red-brick building converted to host Edgbaston's favorite carvery, complete with original wooden beams and roaring hearths.",
                signatureDrinkName = "Bloody Mary Roast Companion",
                signatureDrinkDesc = "Smirnoff Vodka, rich tomato juice, Tabasco, Worcestershire sauce, and a celery stalk",
                signatureDishName = "King Size Roast Carver",
                signatureDishDesc = "Extra meat portion, an extra Yorkshire pudding, and two chipolata sausages alongside your standard heap of carvery trimmings",
                ratingStars = 4.5,
                features = "WIFI,FAMILY,ACCESSIBLE,GARDEN,PLAY_AREA"
            ),
            // Harvester
            VenueEntity(
                id = "harvester_bristol",
                brandId = "harvester",
                name = "Harvester Snuff Mills",
                city = "Bristol",
                postcode = "BS16 1DL",
                distanceMiles = 3.6,
                lat = 51.4812,
                lng = -2.5412,
                openingHours = "09:00 - 22:00",
                foundedYear = 1991,
                architecture = "Spacious modern timber-framed family lodge",
                historyText = "Perfectly situated near the scenic Snuff Mills woodlands. Designed for muddy-boots walkers and families needing a fresh grill recharge.",
                signatureDrinkName = "Berry Lemon Punch",
                signatureDrinkDesc = "Muddled raspberries, fresh cloudy lemonade, sweet cranberry extract and fresh mint",
                signatureDishName = "The BBQ Pitmaster Platter",
                signatureDishDesc = "Half rotisserie chicken, a full rack of slow-cooked baby back ribs, grilled corn, and ultimate fries with BBQ dipping sauce",
                ratingStars = 4.3,
                features = "WIFI,FAMILY,UNLIMITED_SALAD,GARDEN,PLAY_AREA"
            ),
            VenueEntity(
                id = "harvester_cardiff",
                brandId = "harvester",
                name = "Harvester Cardiff Bay",
                city = "Cardiff",
                postcode = "CF11 0SY",
                distanceMiles = 24.8,
                lat = 51.4611,
                lng = -3.1645,
                openingHours = "09:00 - 22:30",
                foundedYear = 1999,
                architecture = "Circular maritime pavilion with panoramic bay windows",
                historyText = "A stunning custom-built pavilion on the waterfront, making it the perfect hub for rotisserie grills and views across the active yacht bay.",
                signatureDrinkName = "Tropical Twist Shaker",
                signatureDrinkDesc = "Mango purée, pineapple juice, lime, soda, and a splash of passionfruit syrup",
                signatureDishName = "Charred Rotisserie Chicken",
                signatureDishDesc = "Our famous half chicken, slow-roasted in our rotisserie ovens and basted in hot Cajun spices, with fries and salad bar",
                ratingStars = 4.4,
                features = "WIFI,WATERSIDE,FAMILY,UNLIMITED_SALAD,ACCESSIBLE"
            ),
            // All Bar One
            VenueEntity(
                id = "abo_bristol",
                brandId = "all_bar_one",
                name = "All Bar One Bristol Waterside",
                city = "Bristol",
                postcode = "BS1 4GH",
                distanceMiles = 0.5,
                lat = 51.4518,
                lng = -2.5982,
                openingHours = "10:00 - 24:00",
                foundedYear = 2003,
                architecture = "Industrial chic dockside bar with bi-fold glass walls",
                historyText = "Housed in a converted historic shipping warehouse. Modern, high-ceiling design with glass walls that open out to the active harbour.",
                signatureDrinkName = "Salted Caramel Espresso Martini",
                signatureDrinkDesc = "Absolut Vodka, Kahúla, espresso, salted caramel syrup, garnished with fudge",
                signatureDishName = "Vibrant Mezze Board",
                signatureDishDesc = "Falafels, flatbread, hummus, olives, roasted sweet potato, grilled halloumi, and sweet pepper drops",
                ratingStars = 4.5,
                features = "WIFI,COCKTAIL_BAR,BRUNCH,TERRACE,WATERSIDE"
            ),
            // Nicholson's
            VenueEntity(
                id = "nicholsons_london",
                brandId = "nicholsons",
                name = "The Salisbury Nicholson's",
                city = "London",
                postcode = "WC2H 0BH",
                distanceMiles = 118.0,
                lat = 51.5111,
                lng = -0.1260,
                openingHours = "11:00 - 23:30",
                foundedYear = 1892,
                architecture = "Glorious Victorian gin palace with original etched glass",
                historyText = "A legendary historic London public house featuring spectacular victorian red velvet banquettes, polished brass, and hand-etched mirrors.",
                signatureDrinkName = "Nicholson's Pale Ale",
                signatureDrinkDesc = "Our signature amber ale, brewed exclusively for our pubs with British hops",
                signatureDishName = "Nicholson's Fish & Chips",
                signatureDishDesc = "Hand-battered cod loin in our pale ale batter, double-cooked chips, mushy peas, and homemade tartare sauce",
                ratingStars = 4.7,
                features = "WIFI,HISTORIC,CASK_ALE,GIN_TRAIL"
            ),
            // Premium Country Pubs
            VenueEntity(
                id = "pcp_leigh",
                brandId = "premium_country",
                name = "The George Premium Country Pub",
                city = "Bristol",
                postcode = "BS8 3RA",
                distanceMiles = 3.1,
                lat = 51.4615,
                lng = -2.6455,
                openingHours = "11:00 - 23:00",
                foundedYear = 1845,
                architecture = "Georgian stone coaching inn with sprawling gardens",
                historyText = "A beautifully preserved Georgian country inn, providing an escape from Bristol city into the lush woods of Leigh Woods.",
                signatureDrinkName = "Blackberry Bramble",
                signatureDrinkDesc = "Tanqueray Gin, lemon juice, blackberries, and sweet crème de mûre over crushed ice",
                signatureDishName = "Slow-Braised Pork Belly",
                signatureDishDesc = "With rich black pudding, sweet mustard mash, crisp crackling, roasted apple, and cider jus",
                ratingStars = 4.8,
                features = "WIFI,GARDEN,DOG_FRIENDLY,FIREPLACE,SUNDAY_ROAST"
            )
        )
        dao.insertVenues(venues)

        // 3. Seed Tables (Digital Twin states for our venues)
        val tablesList = mutableListOf<TableStateEntity>()
        venues.forEach { venue ->
            // Seed 12 tables per venue
            val seats = listOf(2, 4, 4, 6, 2, 4, 8, 4, 2, 4, 6, 4)
            val statuses = listOf(
                "AVAILABLE", "RESERVED", "SEATED", "ORDERING",
                "PREPARING", "READY", "SERVING", "BILL_REQUESTED",
                "PAYING", "CLEARED", "AVAILABLE", "AVAILABLE"
            )
            for (i in 1..12) {
                tablesList.add(
                    TableStateEntity(
                        tableId = "${venue.id}_$i",
                        venueId = venue.id,
                        tableNumber = i,
                        seatsCount = seats[i - 1],
                        statusText = statuses[(i - 1) % statuses.size],
                        currentBillAmount = if (statuses[(i - 1) % statuses.size] in listOf("PREPARING", "READY", "SERVING", "BILL_REQUESTED")) {
                            (25.0 + (i * 4.5))
                        } else 0.0
                    )
                )
            }
        }
        dao.insertTables(tablesList)

        // 4. Seed primary Loyalty Account
        dao.insertLoyaltyAccount(
            LoyaltyAccountEntity(
                id = "primary_account",
                points = 240,
                visitsCount = 7,
                brandVisitsRaw = "harvester:2,toby_carvery:2,all_bar_one:1,miller_carter:2",
                stampCardsRaw = "harvester:3,toby_carvery:1,all_bar_one:0,miller_carter:1"
            )
        )

        // 5. Seed Offers
        val offers = listOf(
            OfferEntity(
                id = "off_browns_20",
                title = "20% Off Dinner",
                brandId = "browns",
                description = "Enjoy 20% off your total food bill when dining on main menu dishes after 18:00, Monday through Thursday.",
                validUntil = "30 Sep 2026",
                promoCode = "BRWN20DIN",
                discountPercent = 20
            ),
            OfferEntity(
                id = "off_abo_drink",
                title = "Free Shaken Cocktail",
                brandId = "all_bar_one",
                description = "Get one complimentary signature cocktail when you order any 2 tapas sharing plates this weekend.",
                validUntil = "04 Oct 2026",
                promoCode = "ABOWKNDDRK",
                discountPercent = 100 // represents a free drink voucher
            ),
            OfferEntity(
                id = "off_toby_kids",
                title = "Kids Eat For £1",
                brandId = "toby_carvery",
                description = "Treat the little ones to our famous carvery for just £1 when you purchase a full-sized adult carvery meal.",
                validUntil = "15 Oct 2026",
                promoCode = "TOBYKIDS1",
                discountPercent = 15
            )
        )
        dao.insertOffers(offers)

        // 6. Seed starting Gift Card
        dao.insertGiftCards(
            listOf(
                GiftCardEntity(
                    id = "GC-75-MBH",
                    initialBalance = 75.0,
                    currentBalance = 75.0,
                    recipientName = "Alice",
                    message = "Have a wonderful dinner on us!",
                    barcodeRaw = "98231084204812"
                )
            )
        )
    }

    // Static food menu list based on M&B official brand categories
    val staticMenuCatalog = listOf(
        // Harvester
        MenuItem("Rotisserie Chicken (Half)", 14.99, "Our famous half chicken, flame-roasted in our ovens, basted in your choice of spicy Cajun or smoky BBQ sauce.", "GRILLS", "harvester", "Gluten Free", "Spicy & Smoky"),
        MenuItem("BBQ Baby Back Ribs", 18.49, "Full rack of tender pork ribs, glazed in sweet smoky BBQ sauce, served with chips and buttered corn.", "GRILLS", "harvester", "None", "Sweet & Charred"),
        MenuItem("Unlimited Salad Bar", 6.99, "Our legendary salad bar. Free with any main, or available as a standalone course. Choose fresh potatoes, crisp lettuce, croutons, and dressings.", "SALAD", "harvester", "Dairy (if using ranch)", "Fresh & Crisp"),
        MenuItem("Harvester Triple Combo", 19.99, "Rotisserie quarter chicken, a half rack of ribs, and grilled chicken breast skewers with waffle fries.", "GRILLS", "harvester", "Gluten", "Meaty & Hearty"),
        MenuItem("Ultimate Sundae", 5.99, "Rich vanilla ice cream layered with chocolate brownie pieces, whipped cream, and Belgian chocolate fudge.", "DESSERTS", "harvester", "Dairy, Gluten", "Indulgent & Sweet"),
        MenuItem("Berry Cooler Mocktail", 3.49, "Refreshing cloudy lemonade shaken with real muddled raspberries and fresh mint.", "DRINKS", "harvester", "None", "Fruity & Zesty"),

        // Toby Carvery
        MenuItem("The Carver's Four-Roast Feast", 13.49, "Choose from beef, pork with crackling, turkey crown, or glazed gammon. Help yourself to Yorkshires and unlimited roasties & veg.", "ROASTS", "toby_carvery", "Gluten (Yorkshire), Dairy (Mash)", "Rich & Comforting"),
        MenuItem("King Size Carvery Upgrade", 15.99, "Our classic carvery but with extra carved meat, two chipolata sausages, and an extra giant Yorkshire pudding.", "ROASTS", "toby_carvery", "Gluten, Sulphites", "Gigantic & Meaty"),
        MenuItem("Melt-in-mouth Beef Roast", 14.49, "Slow-roasted British beef joint, carved to your thickness, with rich pan-gravy.", "ROASTS", "toby_carvery", "Gluten (Gravy)", "Rich & Savory"),
        MenuItem("Ruffled Roast Potatoes", 4.49, "Side of our signature roast potatoes, crispy on the outside, fluffy and ruffled on the inside.", "ROASTS", "toby_carvery", "None", "Salty & Crispy"),
        MenuItem("Giant Bramley Apple Pie", 5.49, "Traditional sweet apples baked in crisp pastry, served warm with double custard.", "DESSERTS", "toby_carvery", "Gluten, Dairy", "Sweet & Tart"),

        // Miller & Carter
        MenuItem("Fillet Steak (8oz)", 31.95, "The ultimate tender cut, grilled exactly to your preference. Served with onion loaf and lettuce wedge.", "STEAKS", "miller_carter", "Dairy (Butter)", "Incredibly Tender"),
        MenuItem("Ribeye Steak (12oz)", 28.50, "Richly marbled cut offering maximum succulence and deep beef flavor. Certified Black Angus.", "STEAKS", "miller_carter", "Dairy", "Rich & Juicy"),
        MenuItem("Chateaubriand (16oz)", 64.00, "The luxury tenderloin cut designed for two. Exceptionally juicy, sliced at table with truffle fries.", "STEAKS", "miller_carter", "Dairy, Gluten (Loaf)", "Luxurious & Delicate"),
        MenuItem("Lobster Mac & Cheese", 6.95, "Gourmet side of rich mature cheddar pasta topped with sweet butter-poached lobster claw.", "STEAKS", "miller_carter", "Gluten, Dairy, Shellfish", "Cheesy & Decadent"),
        MenuItem("Smoked Old Fashioned", 9.95, "Woodford Reserve bourbon, aromatic bitters, brown sugar, applewood smoke chamber infusion.", "DRINKS", "miller_carter", "None", "Smoky & Bold"),

        // All Bar One
        MenuItem("Vibrant Tapas Trio", 16.50, "Choose three tapas plates. Recommended: Crispy calamari, spicy patatas bravas, and grilled halloumi skewers.", "TAPAS", "all_bar_one", "Gluten, Dairy, Molluscs", "Zesty & Sharing"),
        MenuItem("Bottomless Prosecco Brunch", 32.00, "Order any brunch dish (like Smashed Avocado & Poached Eggs) with 90 minutes of free-flowing Prosecco.", "BRUNCH", "all_bar_one", "Gluten, Eggs", "Bubbly & Fresh"),
        MenuItem("Espresso Martini", 9.45, "Absolut vodka, Kahlúa coffee liqueur, double shot of fresh espresso, sweet vanilla syrup.", "DRINKS", "all_bar_one", "None", "Bitter & Sweet"),
        MenuItem("Pornstar Martini", 9.95, "Vanilla vodka, Passoa, passionfruit purée, served with a side shot of crisp Prosecco.", "DRINKS", "all_bar_one", "Sulphites", "Sweet & Tropical"),

        // Browns
        MenuItem("Traditional Afternoon Tea", 22.00, "Savoury finger sandwiches, freshly baked warm scones with clotted cream, and mini patisseries with loose tea.", "TEA", "browns", "Gluten, Dairy, Eggs", "Delicate & Classic"),
        MenuItem("Lobster & Devon Crab Tagliolini", 21.50, "Hand-picked local crab, half lobster tail, cherry tomatoes, garlic, white wine, and fresh chilli.", "BRUNCH", "browns", "Gluten, Shellfish", "Seafood & Garlic"),
        MenuItem("Browns Champagne Bottomless", 45.00, "Any main course paired with unlimited Moët & Chandon Imperial Champagne for two hours.", "BRUNCH", "browns", "Sulphites", "Elegant & Effervescent"),
        MenuItem("Elderflower French 75", 10.45, "Browns Prosecco, Hendrick's Gin, elderflower cordial, shaken with lemon juice.", "DRINKS", "browns", "Sulphites", "Crisp & Floral")
    )
}
