package com.example.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@Entity(tableName = "brands")
data class BrandEntity(
    @PrimaryKey val id: String, // e.g. "harvester", "toby_carvery"
    val name: String,
    val headline: String,
    val description: String,
    val accentColorHex: String,
    val secondaryColorHex: String,
    val styleVibe: String, // "family_grill", "sunday_roast", "steakhouse", "cocktail_social", "brasserie", "country", "historic"
    val keywords: String // Comma-separated search words
)

@Entity(tableName = "venues")
data class VenueEntity(
    @PrimaryKey val id: String, // e.g. "browns_bristol", "miller_birmingham"
    val brandId: String,
    val name: String,
    val city: String,
    val postcode: String,
    val distanceMiles: Double,
    val lat: Double,
    val lng: Double,
    val openingHours: String, // "11:00 - 23:00"
    val foundedYear: Int,
    val architecture: String,
    val historyText: String,
    val signatureDrinkName: String,
    val signatureDrinkDesc: String,
    val signatureDishName: String,
    val signatureDishDesc: String,
    val ratingStars: Double,
    val isFavorite: Boolean = false,
    // Features comma separated e.g. "GARDEN,FAMILY,SPORT,WIFI"
    val features: String
)

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val venueId: String,
    val venueName: String,
    val brandId: String,
    val dateTimeText: String, // "Saturday, 21 September 19:30"
    val partySize: Int,
    val status: String, // "CONFIRMED", "ARRIVED", "SEATED", "CANCELLED"
    val occasion: String, // "Birthday", "Date Night", "Sunday Lunch", "Christmas"
    val seatingType: String, // "Standard", "Window", "Booth", "Outdoor"
    val specialRequests: String = "",
    val accessibilityRequests: String = "",
    val tableNumber: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "tables")
data class TableStateEntity(
    @PrimaryKey val tableId: String, // venueId_tableNumber
    val venueId: String,
    val tableNumber: Int,
    val seatsCount: Int,
    val statusText: String, // "AVAILABLE", "RESERVED", "SEATED", "ORDERING", "PREPARING", "READY", "SERVING", "BILL_REQUESTED", "PAYING", "CLEARED"
    val currentBillAmount: Double,
    val bookingId: Int = 0
)

@Entity(tableName = "order_lines")
data class OrderLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val venueId: String,
    val tableNumber: Int,
    val dishName: String,
    val price: Double,
    val quantity: Int,
    val category: String, // "GRILLS", "SALAD", "STEAKS", "DRINKS", "DESSERTS", "ROASTS"
    val statusText: String, // "PENDING", "PREPARING", "READY", "DELIVERED"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "loyalty")
data class LoyaltyAccountEntity(
    @PrimaryKey val id: String = "primary_account",
    val points: Int,
    val visitsCount: Int,
    val brandVisitsRaw: String, // brandId:visitsCount comma separated
    val stampCardsRaw: String // brandId:stampsCount comma separated e.g. "harvester:3,toby:1"
)

@Entity(tableName = "offers")
data class OfferEntity(
    @PrimaryKey val id: String,
    val title: String,
    val brandId: String,
    val description: String,
    val validUntil: String,
    val promoCode: String,
    val discountPercent: Int,
    val isRedeemed: Boolean = false
)

@Entity(tableName = "gift_cards")
data class GiftCardEntity(
    @PrimaryKey val id: String, // e.g. "GC-75-XYZ"
    val initialBalance: Double,
    val currentBalance: Double,
    val recipientName: String,
    val message: String,
    val barcodeRaw: String
)

@Entity(tableName = "feedbacks")
data class FeedbackEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val venueId: String,
    val ratingFood: Int,
    val ratingService: Int,
    val ratingAtmosphere: Int,
    val ratingValue: Int,
    val comment: String,
    val timestamp: Long = System.currentTimeMillis()
)

// Helper objects for non-entity data models
data class MenuItem(
    val name: String,
    val price: Double,
    val description: String,
    val category: String, // "GRILLS", "SALAD", "STEAKS", "DRINKS", "DESSERTS", "ROASTS", "TAPAS", "BRUNCH", "TEA"
    val brandId: String,
    val allergens: String,
    val flavorProfile: String = ""
)

class Converters {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val menuItemListAdapter = moshi.adapter<List<MenuItem>>(
        Types.newParameterizedType(List::class.java, MenuItem::class.java)
    )

    @TypeConverter
    fun fromMenuItemList(value: List<MenuItem>?): String? {
        return menuItemListAdapter.toJson(value)
    }

    @TypeConverter
    fun toMenuItemList(value: String?): List<MenuItem>? {
        return value?.let { menuItemListAdapter.fromJson(it) }
    }
}
