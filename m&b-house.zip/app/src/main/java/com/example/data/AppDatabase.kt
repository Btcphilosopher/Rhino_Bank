package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.dao.HospitalityDao
import com.example.data.entities.*

@Database(
    entities = [
        BrandEntity::class,
        VenueEntity::class,
        BookingEntity::class,
        TableStateEntity::class,
        OrderLineEntity::class,
        LoyaltyAccountEntity::class,
        OfferEntity::class,
        GiftCardEntity::class,
        FeedbackEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun hospitalityDao(): HospitalityDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mb_house_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
