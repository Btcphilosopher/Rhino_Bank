package com.example.data.dao

import androidx.room.*
import com.example.data.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface HospitalityDao {

    // --- BRANDS ---
    @Query("SELECT * FROM brands")
    fun getAllBrands(): Flow<List<BrandEntity>>

    @Query("SELECT * FROM brands WHERE id = :id")
    suspend fun getBrandById(id: String): BrandEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBrands(brands: List<BrandEntity>)


    // --- VENUES ---
    @Query("SELECT * FROM venues")
    fun getAllVenues(): Flow<List<VenueEntity>>

    @Query("SELECT * FROM venues WHERE brandId = :brandId")
    fun getVenuesByBrand(brandId: String): Flow<List<VenueEntity>>

    @Query("SELECT * FROM venues WHERE id = :id")
    suspend fun getVenueById(id: String): VenueEntity?

    @Query("SELECT * FROM venues WHERE isFavorite = 1")
    fun getFavoriteVenues(): Flow<List<VenueEntity>>

    @Query("UPDATE venues SET isFavorite = :isFav WHERE id = :id")
    suspend fun updateFavoriteStatus(id: String, isFav: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVenues(venues: List<VenueEntity>)


    // --- BOOKINGS ---
    @Query("SELECT * FROM bookings ORDER BY timestamp DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE id = :id")
    suspend fun getBookingById(id: Int): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity): Long

    @Query("DELETE FROM bookings WHERE id = :id")
    suspend fun deleteBooking(id: Int)


    // --- TABLE STATE (DIGITAL TWIN) ---
    @Query("SELECT * FROM tables WHERE venueId = :venueId ORDER BY tableNumber ASC")
    fun getTablesForVenue(venueId: String): Flow<List<TableStateEntity>>

    @Query("SELECT * FROM tables WHERE tableId = :tableId")
    suspend fun getTableById(tableId: String): TableStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTables(tables: List<TableStateEntity>)

    @Query("UPDATE tables SET statusText = :status, currentBillAmount = :bill, bookingId = :bookingId WHERE tableId = :tableId")
    suspend fun updateTableState(tableId: String, status: String, bill: Double, bookingId: Int)

    @Query("UPDATE tables SET statusText = :status WHERE tableId = :tableId")
    suspend fun updateTableStatusOnly(tableId: String, status: String)


    // --- ORDER LINES ---
    @Query("SELECT * FROM order_lines WHERE venueId = :venueId AND tableNumber = :tableNumber ORDER BY timestamp ASC")
    fun getOrderLinesForTable(venueId: String, tableNumber: Int): Flow<List<OrderLineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderLines(orderLines: List<OrderLineEntity>)

    @Query("UPDATE order_lines SET statusText = :status WHERE id = :lineId")
    suspend fun updateOrderLineStatus(lineId: Int, status: String)

    @Query("DELETE FROM order_lines WHERE venueId = :venueId AND tableNumber = :tableNumber")
    suspend fun clearOrderLinesForTable(venueId: String, tableNumber: Int)


    // --- LOYALTY ---
    @Query("SELECT * FROM loyalty WHERE id = :id")
    suspend fun getLoyaltyAccount(id: String = "primary_account"): LoyaltyAccountEntity?

    @Query("SELECT * FROM loyalty WHERE id = :id")
    fun getLoyaltyAccountFlow(id: String = "primary_account"): Flow<LoyaltyAccountEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoyaltyAccount(account: LoyaltyAccountEntity)


    // --- OFFERS ---
    @Query("SELECT * FROM offers")
    fun getAllOffers(): Flow<List<OfferEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffers(offers: List<OfferEntity>)

    @Query("UPDATE offers SET isRedeemed = 1 WHERE id = :id")
    suspend fun redeemOffer(id: String)


    // --- GIFT CARDS ---
    @Query("SELECT * FROM gift_cards")
    fun getAllGiftCards(): Flow<List<GiftCardEntity>>

    @Query("SELECT * FROM gift_cards WHERE id = :id")
    suspend fun getGiftCardById(id: String): GiftCardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGiftCards(giftCards: List<GiftCardEntity>)

    @Query("UPDATE gift_cards SET currentBalance = :balance WHERE id = :id")
    suspend fun updateGiftCardBalance(id: String, balance: Double)


    // --- FEEDBACKS ---
    @Query("SELECT * FROM feedbacks ORDER BY timestamp DESC")
    fun getAllFeedback(): Flow<List<FeedbackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedback(feedback: FeedbackEntity)
}
