package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketDataRepository
import com.example.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun FundamentalsValuationScreen(
  security: Security?
) {
  if (security == null) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(TerminalBg),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = "SELECT A SECURITY TO VIEW FUNDAMENTALS & VALUATION MODEL.",
        fontFamily = FontFamily.Monospace,
        color = TextMuted
      )
    }
    return
  }

  val ticker = security.ticker
  val periods = remember(ticker) { MarketDataRepository.getFinancialPeriods(ticker) }
  val consensus = remember(ticker) { MarketDataRepository.getConsensus(ticker) }

  // Point-in-time toggle
  var isAsReported by remember { mutableStateOf(true) }

  // Interactive DCF Model state
  var wacc by remember { mutableStateOf(8.5) }
  var terminalGrowth by remember { mutableStateOf(3.0) }
  var fcfGrowth by remember { mutableStateOf(12.0) }

  val dcfModel = remember(ticker, wacc, terminalGrowth, fcfGrowth) {
    MarketDataRepository.calculateDcf(ticker, wacc, terminalGrowth, fcfGrowth)
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Header with PIT vintage toggle
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "${security.ticker} // FINANCIAL STATEMENTS (PIT)",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = TerminalAmber
              )
              Text(
                text = "${security.displayName} | Currency: ${security.currency} in Billions",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary
              )
            }

            // PIT Mode Toggle
            Row(
              modifier = Modifier
                .background(TerminalSurfaceElevated, RoundedCornerShape(2.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(2.dp))
                .padding(2.dp)
            ) {
              Box(
                modifier = Modifier
                  .background(
                    if (isAsReported) TerminalAmber else Color.Transparent,
                    RoundedCornerShape(2.dp)
                  )
                  .clickable { isAsReported = true }
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "AS-REPORTED",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isAsReported) TerminalBg else TextSecondary
                )
              }
              Box(
                modifier = Modifier
                  .background(
                    if (!isAsReported) TerminalAmber else Color.Transparent,
                    RoundedCornerShape(2.dp)
                  )
                  .clickable { isAsReported = false }
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "LATEST-REVISED",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (!isAsReported) TerminalBg else TextSecondary
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Point-in-time prevents look-ahead bias. Vintage date: ${if (isAsReported) periods.firstOrNull()?.asReportedDate else "T-0 Restated"}",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = TextMuted
          )
        }
      }
    }

    // 2. Multi-Period Financial Statement Table
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(8.dp)) {
          // Table Columns Header
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(TerminalSurfaceElevated)
              .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "METRIC ($)", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.8f))
            periods.forEach { p ->
              Text(
                text = p.period,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = TerminalCyan,
                modifier = Modifier.weight(1f)
              )
            }
          }

          StatementRow("Revenue", periods.map { String.format(Locale.US, "%.1fB", it.revenue) })
          StatementRow("Gross Profit", periods.map { String.format(Locale.US, "%.1fB", it.grossProfit) })
          StatementRow("EBITDA", periods.map { String.format(Locale.US, "%.1fB", it.ebitda) })
          StatementRow("Operating Income", periods.map { String.format(Locale.US, "%.1fB", it.operatingIncome) })
          StatementRow("Net Income", periods.map { String.format(Locale.US, "%.1fB", it.netIncome) })
          StatementRow("Diluted EPS", periods.map { String.format(Locale.US, "$%.2f", it.eps) })
          StatementRow("Free Cash Flow", periods.map { String.format(Locale.US, "%.1fB", it.fcf) })
          StatementRow("CapEx", periods.map { String.format(Locale.US, "%.1fB", it.capex) })
          StatementRow("Cash & Equivalents", periods.map { String.format(Locale.US, "%.1fB", it.cash) })
          StatementRow("Net Debt", periods.map { String.format(Locale.US, "%.1fB", it.netDebt) })
          StatementRow("Total Equity", periods.map { String.format(Locale.US, "%.1fB", it.totalEquity) })
        }
      }
    }

    // 3. Valuation Multiples & Capital Return Ratios Grid
    item {
      Text(
        text = "VALUATION RATIOS & PROFITABILITY BENCHMARKS",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = TerminalCyan
      )
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            RatioItem("P/E (TTM)", "${security.pe}x")
            RatioItem("FORWARD P/E", "${security.forwardPe}x")
            RatioItem("P/B", "${security.pb}x")
            RatioItem("EV/EBITDA", "${security.evEbitda}x")
          }
          HorizontalDivider(color = TerminalBorderSubtle, thickness = 0.5.dp)
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            RatioItem("FCF YIELD", "${security.fcfYieldPct}%")
            RatioItem("DIV YIELD", "${security.dividendYieldPct}%")
            RatioItem("ROE", "${security.roePct}%")
            RatioItem("ROIC", "${security.roicPct}%")
          }
          HorizontalDivider(color = TerminalBorderSubtle, thickness = 0.5.dp)
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            RatioItem("GROSS MARGIN", "${security.grossMarginPct}%")
            RatioItem("OP MARGIN", "${security.operatingMarginPct}%")
            RatioItem("NET MARGIN", "${security.netMarginPct}%")
            RatioItem("BETA", "${security.beta}")
          }
        }
      }
    }

    // 4. Interactive DCF Valuation Model (VALUATION-CORE)
    item {
      Text(
        text = "DISCOUNTED CASH FLOW (DCF) // VALUATION LAB",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = TerminalAmber
      )
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          // Result Summary
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "INTRINSIC VALUE PER SHARE",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextMuted
              )
              Text(
                text = String.format(Locale.US, "$%.2f", dcfModel.intrinsicValue),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = TerminalAmber
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              val isUndervalued = dcfModel.marginOfSafetyPct >= 0
              Text(
                text = "MARGIN OF SAFETY",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextMuted
              )
              Text(
                text = String.format(Locale.US, "%+.1f%%", dcfModel.marginOfSafetyPct),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = if (isUndervalued) TerminalGreen else TerminalRed
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider(color = TerminalBorderSubtle)
          Spacer(modifier = Modifier.height(10.dp))

          // Interactive Model Sliders
          Text(
            text = "ADJUST DCF ASSUMPTIONS IN REAL-TIME:",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = TextSecondary
          )

          Spacer(modifier = Modifier.height(6.dp))
          DcfSlider(
            label = "WACC (Cost of Capital)",
            valueText = String.format(Locale.US, "%.1f%%", wacc),
            value = wacc.toFloat(),
            range = 6.0f..12.0f,
            onValueChange = { wacc = ((it * 10).toInt() / 10.0) }
          )

          DcfSlider(
            label = "Terminal Growth Rate",
            valueText = String.format(Locale.US, "%.1f%%", terminalGrowth),
            value = terminalGrowth.toFloat(),
            range = 1.5f..4.5f,
            onValueChange = { terminalGrowth = ((it * 10).toInt() / 10.0) }
          )

          DcfSlider(
            label = "5-Year FCF CAGR",
            valueText = String.format(Locale.US, "%.1f%%", fcfGrowth),
            value = fcfGrowth.toFloat(),
            range = 4.0f..25.0f,
            onValueChange = { fcfGrowth = ((it * 10).toInt() / 10.0) }
          )

          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Implied Forward EV/EBITDA Multiple: ${dcfModel.impliedMultipleEvEbitda}x",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = TerminalCyan
          )
        }
      }
    }

    // 5. Analyst Consensus & Revisions
    item {
      Text(
        text = "ANALYST CONSENSUS & REVISION MOMENTUM // ESTIMATES-CORE",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = TerminalCyan
      )
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(text = "CONSENSUS TARGET", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
              Text(
                text = String.format(Locale.US, "$%.2f", consensus.targetPriceMean),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = TerminalGreen
              )
            }
            Column {
              Text(text = "STREET RANGE", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
              Text(
                text = "$${consensus.targetPriceLow} - $${consensus.targetPriceHigh}",
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = TextPrimary
              )
            }
            Column {
              Text(text = "RATINGS", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
              Text(
                text = "${consensus.buyCount} BUY / ${consensus.holdCount} HOLD / ${consensus.sellCount} SELL",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = TextSecondary
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "30-Day Revision Momentum: +${consensus.revisionMomentum30dPct}% | Next FY EPS Consensus: $${consensus.epsConsensusNextFy}",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = TerminalAmber
          )
        }
      }
    }
  }
}

@Composable
private fun StatementRow(metric: String, values: List<String>) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 6.dp, vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = metric,
      fontFamily = FontFamily.Monospace,
      fontSize = 11.sp,
      color = TextSecondary,
      modifier = Modifier.weight(1.8f)
    )
    values.forEach { v ->
      Text(
        text = v,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.sp,
        color = TextPrimary,
        modifier = Modifier.weight(1f)
      )
    }
  }
  HorizontalDivider(color = TerminalBorderSubtle, thickness = 0.5.dp)
}

@Composable
private fun RatioItem(label: String, value: String) {
  Column {
    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
    Text(text = value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
  }
}

@Composable
private fun DcfSlider(
  label: String,
  valueText: String,
  value: Float,
  range: ClosedFloatingPointRange<Float>,
  onValueChange: (Float) -> Unit
) {
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary)
      Text(text = valueText, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TerminalAmber)
    }
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = range,
      colors = SliderDefaults.colors(
        thumbColor = TerminalAmber,
        activeTrackColor = TerminalAmber,
        inactiveTrackColor = TerminalSurfaceHighlight
      ),
      modifier = Modifier.height(28.dp)
    )
  }
}
