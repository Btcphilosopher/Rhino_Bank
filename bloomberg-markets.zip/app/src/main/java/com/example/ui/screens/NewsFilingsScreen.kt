package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NewsItem
import com.example.model.RegulatoryFiling
import com.example.ui.theme.*

@Composable
fun NewsFilingsScreen(
  newsList: List<NewsItem>,
  filingsList: List<RegulatoryFiling>,
  onSelectSecurity: (String) -> Unit
) {
  var selectedTab by remember { mutableStateOf("NEWS") } // NEWS, FILINGS

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Tab Switcher
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurfaceElevated)
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        listOf(
          "NEWS" to "REAL-TIME INSTITUTIONAL NEWS WIRE & NLP SENTIMENT",
          "FILINGS" to "REGULATORY FILINGS // STRUCTURED EXTRACTION"
        ).forEach { (key, title) ->
          val isSelected = selectedTab == key
          Box(
            modifier = Modifier
              .background(
                if (isSelected) TerminalAmber else Color.Transparent,
                RoundedCornerShape(2.dp)
              )
              .clickable { selectedTab = key }
              .padding(horizontal = 8.dp, vertical = 6.dp)
          ) {
            Text(
              text = title,
              fontFamily = FontFamily.Monospace,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp,
              color = if (isSelected) TerminalBg else TextSecondary
            )
          }
        }
      }
    }

    if (selectedTab == "NEWS") {
      item {
        Text(
          text = "LIVE WIRE // EVENT INTELLIGENCE // MODELLED SENTIMENT",
          fontFamily = FontFamily.Monospace,
          fontSize = 10.sp,
          color = TextMuted,
          modifier = Modifier.padding(horizontal = 2.dp)
        )
      }

      items(newsList) { item ->
        val isBullish = item.sentimentScore > 0.3
        val isBearish = item.sentimentScore < -0.3
        val sentimentColor = if (isBullish) TerminalGreen else if (isBearish) TerminalRed else TerminalCyan

        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = item.timestamp,
                  fontFamily = FontFamily.Monospace,
                  fontSize = 10.sp,
                  color = TerminalAmber
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "[${item.source}]",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 9.sp,
                  color = TextMuted
                )
              }

              Box(
                modifier = Modifier
                  .background(TerminalSurfaceHighlight, RoundedCornerShape(2.dp))
                  .border(1.dp, sentimentColor, RoundedCornerShape(2.dp))
                  .padding(horizontal = 4.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "${item.sentimentLabel} (${item.sentimentScore})",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 9.sp,
                  color = sentimentColor
                )
              }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = item.headline,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = TextPrimary
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
              text = item.summary,
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              color = TextSecondary
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Category: ${item.category} | Relevance: ${item.relevance}",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = TextMuted
              )

              Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                item.tickers.forEach { ticker ->
                  Box(
                    modifier = Modifier
                      .background(TerminalSurfaceHighlight, RoundedCornerShape(2.dp))
                      .clickable { onSelectSecurity(ticker) }
                      .padding(horizontal = 4.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = ticker,
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold,
                      fontSize = 9.sp,
                      color = TerminalCyan
                    )
                  }
                }
              }
            }
          }
        }
      }
    } else {
      // Filings
      item {
        Text(
          text = "STRUCTURED FILINGS EXTRACTION // EDGAR & GLOBAL REGULATORY",
          fontFamily = FontFamily.Monospace,
          fontSize = 10.sp,
          color = TextMuted,
          modifier = Modifier.padding(horizontal = 2.dp)
        )
      }

      items(filingsList) { f ->
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .background(TerminalAmber, RoundedCornerShape(2.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = f.formType,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = TerminalBg
                  )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "${f.company} (${f.ticker})",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = TextPrimary
                )
              }

              Text(
                text = f.filingDate,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextMuted
              )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = f.title,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.sp,
              color = TerminalCyan
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
              text = "Structured Extraction: ${f.extractedHighlights}",
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              color = TextSecondary
            )
          }
        }
      }
    }
  }
}
