package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MarketTwinScreen() {
  var selectedMode by remember { mutableStateOf("SCENARIO") } // SCENARIO, REPLAY

  // Interactive Scenario Twin parameters
  var equityShock by remember { mutableStateOf(-10.0) }
  var ratesShockBp by remember { mutableStateOf(50) }
  var usdShock by remember { mutableStateOf(5.0) }
  var oilShock by remember { mutableStateOf(15.0) }

  // Replay Simulator State
  var isPlaying by remember { mutableStateOf(false) }
  var replaySpeed by remember { mutableStateOf("5x") }
  var currentReplayTimestamp by remember { mutableStateOf("09:34:12.820") }
  var selectedReplaySession by remember { mutableStateOf("August 2024 Global Carry Trade Unwind") }

  // Computed Scenario Results
  val estPortfolioImpactPct = (equityShock * 0.85) - (ratesShockBp * 0.035) - (usdShock * 0.15) - (oilShock * 0.08)
  val estLossAmount = (100_000_000.0 * (estPortfolioImpactPct / 100.0))

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Header & Mode Switcher
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "EQUITY MARKET DIGITAL TWIN // MARKET-TWIN",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = TerminalAmber
              )
              Text(
                text = "High-Fidelity Agent-Based Simulation & Historical Replay Engine",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary
              )
            }

            Row(
              modifier = Modifier
                .background(TerminalSurfaceElevated, RoundedCornerShape(2.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(2.dp))
                .padding(2.dp)
            ) {
              listOf("SCENARIO" to "WHAT-IF TWIN", "REPLAY" to "REPLAY ENGINE").forEach { (mode, label) ->
                val isSelected = selectedMode == mode
                Box(
                  modifier = Modifier
                    .background(if (isSelected) TerminalAmber else Color.Transparent, RoundedCornerShape(2.dp))
                    .clickable { selectedMode = mode }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                  Text(
                    text = label,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) TerminalBg else TextSecondary
                  )
                }
              }
            }
          }
        }
      }
    }

    if (selectedMode == "SCENARIO") {
      // 2. Scenario Shocks Input Card
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = "CROSS-ASSET SHOCK PARAMETERS",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              color = TerminalCyan
            )
            HorizontalDivider(color = TerminalBorderSubtle)

            TwinSlider(
              label = "Global Equity Shock (Nasdaq/MSCI)",
              valueText = String.format(Locale.US, "%+.1f%%", equityShock),
              value = equityShock.toFloat(),
              range = -30f..15f,
              onValueChange = { equityShock = ((it * 10).toInt() / 10.0) }
            )

            TwinSlider(
              label = "Benchmark Rates Parallel Shift",
              valueText = String.format(Locale.US, "%+d bps", ratesShockBp),
              value = ratesShockBp.toFloat(),
              range = -100f..200f,
              onValueChange = { ratesShockBp = it.toInt() }
            )

            TwinSlider(
              label = "US Dollar Index (DXY) Shock",
              valueText = String.format(Locale.US, "%+.1f%%", usdShock),
              value = usdShock.toFloat(),
              range = -10f..15f,
              onValueChange = { usdShock = ((it * 10).toInt() / 10.0) }
            )

            TwinSlider(
              label = "Brent Crude Oil Shock",
              valueText = String.format(Locale.US, "%+.1f%%", oilShock),
              value = oilShock.toFloat(),
              range = -25f..50f,
              onValueChange = { oilShock = ((it * 10).toInt() / 10.0) }
            )
          }
        }
      }

      // 3. Computed Digital Twin Impact Card
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurfaceElevated),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = "COMPUTED MANDATE & MARKET EQUILIBRIUM IMPACT",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              color = TerminalAmber
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = "ESTIMATED NAV DRAWDOWN", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
                Text(
                  text = String.format(Locale.US, "%+.2f%%", estPortfolioImpactPct),
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 18.sp,
                  color = if (estPortfolioImpactPct >= 0) TerminalGreen else TerminalRed
                )
              }

              Column(horizontalAlignment = Alignment.End) {
                Text(text = "ESTIMATED P&L IMPACT ($100M BOOK)", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
                Text(
                  text = String.format(Locale.US, "%+,.0f USD", estLossAmount),
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp,
                  color = if (estLossAmount >= 0) TerminalGreen else TerminalRed
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = TerminalBorderSubtle)
            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = "• Technology & Growth: -14.2% multiple contraction on WACC expansion\n• Financials & Banks: +1.8% NIM expansion buffer\n• Systematic Volatility: VIX expected jump to 28.5 (liquidity spreads widen +4.2 bps)\n• Recommended Mitigation: Deploy index put collars or long USD/JPY hedges",
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
              color = TextSecondary,
              lineHeight = 15.sp
            )
          }
        }
      }
    } else {
      // REPLAY ENGINE
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
              text = "HISTORICAL SESSION PLAYBACK CONTROLS",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              color = TerminalCyan
            )

            // Replay Session Selectors
            Text(text = "SELECT EVENT ARCHIVE:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
            listOf(
              "August 2024 Global Carry Trade Unwind",
              "March 2020 Liquidity & Vol Shock",
              "2024 Tech Earnings CapEx Rebalancing",
              "May 2010 Flash Crash Microstructure"
            ).forEach { session ->
              val isSel = selectedReplaySession == session
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(if (isSel) TerminalSurfaceHighlight else Color.Transparent)
                  .clickable { selectedReplaySession = session }
                  .padding(vertical = 4.dp, horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(6.dp)
                    .background(if (isSel) TerminalAmber else TextMuted, RoundedCornerShape(3.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = session,
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp,
                  color = if (isSel) TerminalAmber else TextPrimary
                )
              }
            }

            HorizontalDivider(color = TerminalBorderSubtle)

            // Playback controls row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                  onClick = { isPlaying = !isPlaying },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPlaying) TerminalRed else TerminalGreen,
                    contentColor = TerminalBg
                  ),
                  shape = RoundedCornerShape(2.dp),
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = if (isPlaying) "PAUSE" else "PLAY REPLAY",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                  )
                }

                Button(
                  onClick = { currentReplayTimestamp = "09:35:00.000" },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = TerminalSurfaceHighlight,
                    contentColor = TextPrimary
                  ),
                  shape = RoundedCornerShape(2.dp),
                  contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                  Text(text = "STEP +1s", fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                }
              }

              // Speed selector
              Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("1x", "5x", "20x").forEach { spd ->
                  val isSpd = replaySpeed == spd
                  Box(
                    modifier = Modifier
                      .background(if (isSpd) TerminalAmber else TerminalSurfaceHighlight, RoundedCornerShape(2.dp))
                      .clickable { replaySpeed = spd }
                      .padding(horizontal = 6.dp, vertical = 4.dp)
                  ) {
                    Text(
                      text = spd,
                      fontFamily = FontFamily.Monospace,
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (isSpd) TerminalBg else TextPrimary
                    )
                  }
                }
              }
            }

            Text(
              text = "REPLAY CLOCK: $currentReplayTimestamp | STATE: ${if (isPlaying) "STREAMING @ $replaySpeed" else "PAUSED"}",
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
              color = TerminalAmber
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TwinSlider(
  label: String,
  valueText: String,
  value: Float,
  range: ClosedFloatingPointRange<Float>,
  onValueChange: (Float) -> Unit
) {
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary)
      Text(text = valueText, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TerminalAmber)
    }
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = range,
      colors = SliderDefaults.colors(
        thumbColor = TerminalAmber,
        activeTrackColor = TerminalAmber,
        inactiveTrackColor = TerminalSurfaceHighlight
      ),
      modifier = Modifier.height(26.dp)
    )
  }
}
