package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MarketOverviewScreen(
  indices: List<GlobalIndex>,
  exchanges: List<ExchangeVenue>,
  marketRegime: MarketRegimeInfo,
  onSelectSecurity: (String) -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Market Regime & Systematic Breadth Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "MARKET REGIME // SYSTEMATIC ENGINE",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TerminalAmber
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "[${marketRegime.modelVersion}]",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextMuted
              )
            }

            Box(
              modifier = Modifier
                .background(TerminalGreenBg, RoundedCornerShape(2.dp))
                .border(1.dp, TerminalGreen, RoundedCornerShape(2.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = "${marketRegime.regime} (${marketRegime.probabilityPct}%)",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = TerminalGreen
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Primary Signal: ${marketRegime.primarySignal}",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = TextSecondary
          )

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider(color = TerminalBorderSubtle, thickness = 1.dp)
          Spacer(modifier = Modifier.height(8.dp))

          // 4 Breadth Metrics
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            BreadthMetricItem(label = "ADV / DEC RATIO", value = String.format(Locale.US, "%.2fx", marketRegime.advanceDeclineRatio), isBullish = true)
            BreadthMetricItem(label = "% ABOVE 50 DMA", value = "${marketRegime.pctAbove50Dma}%", isBullish = true)
            BreadthMetricItem(label = "McCLELLAN OSC", value = "+${marketRegime.mcclellanOscillator}", isBullish = true)
            BreadthMetricItem(label = "CROSS-ASSET RISK", value = "RISK-ON", isBullish = true)
          }
        }
      }
    }

    // 2. Global Trading Sessions & Venues
    item {
      Text(
        text = "GLOBAL EXCHANGE VENUES & TRADING CALENDARS",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        color = TerminalCyan,
        modifier = Modifier.padding(vertical = 2.dp)
      )
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(8.dp)) {
          // Table Header
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(TerminalSurfaceElevated)
              .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "VENUE", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.2f))
            Text(text = "CITY / REGION", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.3f))
            Text(text = "HOURS (LOCAL)", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.4f))
            Text(text = "STATUS", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.0f))
          }

          exchanges.forEach { venue ->
            val isOpen = venue.status == MarketSessionStatus.OPEN
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 5.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${venue.code} (${venue.mic})",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                color = TextPrimary,
                modifier = Modifier.weight(1.2f)
              )
              Text(
                text = "${venue.city}, ${venue.country}",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary,
                modifier = Modifier.weight(1.3f)
              )
              Text(
                text = venue.localTradingHours,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary,
                modifier = Modifier.weight(1.4f)
              )
              Box(
                modifier = Modifier
                  .weight(1.0f)
                  .background(
                    if (isOpen) TerminalGreenBg else TerminalSurfaceHighlight,
                    RoundedCornerShape(2.dp)
                  )
                  .border(
                    1.dp,
                    if (isOpen) TerminalGreen else TerminalBorder,
                    RoundedCornerShape(2.dp)
                  )
                  .padding(horizontal = 4.dp, vertical = 2.dp)
              ) {
                Text(
                  text = venue.status.name,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 9.sp,
                  color = if (isOpen) TerminalGreen else TextMuted
                )
              }
            }
            HorizontalDivider(color = TerminalBorderSubtle, thickness = 0.5.dp)
          }
        }
      }
    }

    // 3. Global Benchmark Equity Indices
    item {
      Text(
        text = "GLOBAL BENCHMARK INDICES // INDEX-CORE",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        color = TerminalAmber,
        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
      )
    }

    items(indices) { idx ->
      val isUp = idx.change >= 0
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = idx.ticker,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = TerminalAmber
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = idx.name,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = TextSecondary
              )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "Region: ${idx.region} | CCY: ${idx.currency} | Constituents: ${idx.constituentsCount} | Divisor: ${idx.divisor}",
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
              color = TextMuted
            )
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = String.format(Locale.US, "%,.2f", idx.level),
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = TextPrimary
            )
            Text(
              text = String.format(Locale.US, "%+,.2f (%+.2f%%)", idx.change, idx.changePct),
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.SemiBold,
              fontSize = 11.sp,
              color = if (isUp) TerminalGreen else TerminalRed
            )
          }
        }
      }
    }
  }
}

@Composable
private fun BreadthMetricItem(label: String, value: String, isBullish: Boolean) {
  Column {
    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = value,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 12.sp,
      color = if (isBullish) TerminalGreen else TerminalAmber
    )
  }
}
