package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GlobalIndex
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TerminalHeader(
  indices: List<GlobalIndex>,
  isLiveStreaming: Boolean,
  onToggleStreaming: () -> Unit,
  onExecuteCommand: (String) -> Unit,
  activeTab: String,
  onSelectTab: (String) -> Unit
) {
  var commandText by remember { mutableStateOf("") }
  var currentTimeUtc by remember { mutableStateOf("") }
  var currentTimeEst by remember { mutableStateOf("") }

  LaunchedEffect(Unit) {
    while (true) {
      val now = Date()
      val utcFormat = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
      }
      val estFormat = SimpleDateFormat("HH:mm:ss 'EST'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("America/New_York")
      }
      currentTimeUtc = utcFormat.format(now)
      currentTimeEst = estFormat.format(now)
      kotlinx.coroutines.delay(1000)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(TerminalSurface)
      .border(1.dp, TerminalBorderSubtle)
  ) {
    // Top Bar: System ID, Clocks, Status Badges
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        // Institutional Title
        Text(
          text = "BLOOMBERG // MARKETS",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          color = TerminalAmber,
          letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.width(8.dp))
        Box(
          modifier = Modifier
            .background(TerminalSurfaceHighlight, RoundedCornerShape(2.dp))
            .border(1.dp, TerminalBorder, RoundedCornerShape(2.dp))
            .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
          Text(
            text = "INSTITUTIONAL v3.8",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = TerminalCyan
          )
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "$currentTimeUtc | $currentTimeEst",
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          color = TextSecondary
        )
        Spacer(modifier = Modifier.width(8.dp))

        // Streaming Toggle Badge
        Row(
          modifier = Modifier
            .background(
              if (isLiveStreaming) TerminalGreenBg else TerminalRedBg,
              RoundedCornerShape(3.dp)
            )
            .border(
              1.dp,
              if (isLiveStreaming) TerminalGreen else TerminalRed,
              RoundedCornerShape(3.dp)
            )
            .clickable { onToggleStreaming() }
            .padding(horizontal = 6.dp, vertical = 2.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(6.dp)
              .background(
                if (isLiveStreaming) TerminalGreen else TerminalRed,
                RoundedCornerShape(3.dp)
              )
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isLiveStreaming) "LIVE" else "PAUSED",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            color = if (isLiveStreaming) TerminalGreen else TerminalRed
          )
        }

        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "0.45ms",
          fontFamily = FontFamily.Monospace,
          fontSize = 9.sp,
          color = TextMuted
        )
      }
    }

    // Command Bar with <GO> Action
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(TerminalBg)
        .padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = ">",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        color = TerminalAmber,
        modifier = Modifier.padding(end = 6.dp)
      )

      OutlinedTextField(
        value = commandText,
        onValueChange = { commandText = it },
        placeholder = {
          Text(
            text = "ENTER TICKER OR COMMAND (e.g. AAPL <GO>, NVDA, RISK, PORT, TWIN, DCF MSFT)...",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = TextDim
          )
        },
        singleLine = true,
        textStyle = LocalTextStyle.current.copy(
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          color = TextPrimary
        ),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = TerminalSurface,
          unfocusedContainerColor = TerminalSurface,
          focusedBorderColor = TerminalAmber,
          unfocusedBorderColor = TerminalBorder
        ),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
        keyboardActions = KeyboardActions(onGo = {
          if (commandText.isNotBlank()) {
            onExecuteCommand(commandText.trim())
            commandText = ""
          }
        }),
        modifier = Modifier
          .weight(1f)
          .height(44.dp)
          .testTag("terminal_command_input")
      )

      Spacer(modifier = Modifier.width(6.dp))

      // The iconic Bloomberg <GO> Button
      Button(
        onClick = {
          if (commandText.isNotBlank()) {
            onExecuteCommand(commandText.trim())
            commandText = ""
          } else {
            onExecuteCommand("HELP")
          }
        },
        colors = ButtonDefaults.buttonColors(
          containerColor = TerminalAmber,
          contentColor = TerminalBg
        ),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
        modifier = Modifier
          .height(44.dp)
          .testTag("execute_go_button")
      ) {
        Text(
          text = "<GO>",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp
        )
      }
    }

    // Function Key Toolbar (F1-F10 shortcuts)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(TerminalSurfaceElevated)
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 6.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      val functionKeys = listOf(
        "MKT" to "F2 MKT",
        "SEC" to "F3 SEC",
        "FUN" to "F4 FUN",
        "QNT" to "F5 QNT",
        "PORT" to "F6 PORT",
        "WIRE" to "F7 WIRE",
        "TWIN" to "F8 TWIN",
        "API" to "F9 API",
        "AI" to "F10 AI"
      )

      functionKeys.forEach { (key, label) ->
        val isSelected = activeTab == key
        Box(
          modifier = Modifier
            .background(
              if (isSelected) TerminalAmber else TerminalSurfaceHighlight,
              RoundedCornerShape(2.dp)
            )
            .border(
              1.dp,
              if (isSelected) TerminalAmberLight else TerminalBorder,
              RoundedCornerShape(2.dp)
            )
            .clickable { onSelectTab(key) }
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = label,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 11.sp,
            color = if (isSelected) TerminalBg else TextPrimary
          )
        }
      }
    }

    // Running Global Indices Ticker Ribbon
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(TerminalBg)
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 8.dp, vertical = 3.dp),
      horizontalArrangement = Arrangement.spacedBy(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      indices.forEach { idx ->
        val isUp = idx.change >= 0
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = idx.ticker,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = TextSecondary
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = String.format(Locale.US, "%.1f", idx.level),
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = TextPrimary
          )
          Spacer(modifier = Modifier.width(3.dp))
          Text(
            text = String.format(Locale.US, "%+.2f%%", idx.changePct),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp,
            color = if (isUp) TerminalGreen else TerminalRed
          )
        }
      }
    }
  }
}
