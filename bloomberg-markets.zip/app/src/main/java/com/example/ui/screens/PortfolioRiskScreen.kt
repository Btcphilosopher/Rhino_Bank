package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PortfolioHolding
import com.example.model.StressScenario
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun PortfolioRiskScreen(
  holdings: List<PortfolioHolding>,
  stressScenarios: List<StressScenario>,
  onSelectSecurity: (String) -> Unit
) {
  var selectedTab by remember { mutableStateOf("HOLDINGS") } // HOLDINGS, RISK_METRICS, STRESS_TEST

  val totalMarketValue = remember(holdings) { holdings.sumOf { it.marketValue } }
  val totalUnrealizedPnl = remember(holdings) { holdings.sumOf { it.unrealizedPnl } }
  val totalPnlPct = if (totalMarketValue > 0) (totalUnrealizedPnl / (totalMarketValue - totalUnrealizedPnl)) * 100.0 else 0.0

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Institutional Portfolio Mandate Summary Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "GLOBAL EQUITY MANDATE // BOOK-01",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = TerminalAmber
              )
              Text(
                text = "Institutional Long-Only Alpha Strategy | Base CCY: USD",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.US, "$%,.2f", totalMarketValue),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = TextPrimary
              )
              val isUp = totalUnrealizedPnl >= 0
              Text(
                text = String.format(Locale.US, "%+,.2f (%+.2f%%)", totalUnrealizedPnl, totalPnlPct),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (isUp) TerminalGreen else TerminalRed
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider(color = TerminalBorderSubtle)
          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            SummaryItem("DAILY P&L", "+$482,100 (+0.48%)", isPositive = true)
            SummaryItem("MTD RETURN", "+2.85%", isPositive = true)
            SummaryItem("YTD RETURN", "+18.42%", isPositive = true)
            SummaryItem("POSITIONS", "${holdings.size} HELD", isPositive = true)
          }
        }
      }
    }

    // 2. Sub-Tab Switcher
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurfaceElevated)
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        listOf(
          "HOLDINGS" to "PORTFOLIO HOLDINGS",
          "RISK_METRICS" to "RISK-CORE ANALYTICS",
          "STRESS_TEST" to "MACRO STRESS TESTING"
        ).forEach { (key, title) ->
          val isSelected = selectedTab == key
          Box(
            modifier = Modifier
              .background(
                if (isSelected) TerminalAmber else Color.Transparent,
                RoundedCornerShape(2.dp)
              )
              .clickable { selectedTab = key }
              .padding(horizontal = 8.dp, vertical = 6.dp)
          ) {
            Text(
              text = title,
              fontFamily = FontFamily.Monospace,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp,
              color = if (isSelected) TerminalBg else TextSecondary
            )
          }
        }
      }
    }

    when (selectedTab) {
      "HOLDINGS" -> {
        // Table Header
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(TerminalSurfaceElevated)
              .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("TICKER / NAME", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted, modifier = Modifier.weight(1.8f))
            Text("WT %", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted, modifier = Modifier.weight(0.8f))
            Text("MV ($)", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted, modifier = Modifier.weight(1.2f))
            Text("PNL ($ / %)", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted, modifier = Modifier.weight(1.3f))
          }
        }

        // Holdings List
        items(holdings) { pos ->
          val isUp = pos.unrealizedPnl >= 0
          Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, TerminalBorder)
              .clickable { onSelectSecurity(pos.ticker) }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 6.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1.8f)) {
                Text(
                  text = pos.ticker,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = TerminalAmber
                )
                Text(
                  text = "${pos.shares.toInt()} shs @ $${pos.avgCostPrice}",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 9.sp,
                  color = TextMuted
                )
              }

              Text(
                text = "${pos.weightPct}%",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                color = TextPrimary,
                modifier = Modifier.weight(0.8f)
              )

              Text(
                text = String.format(Locale.US, "$%,.1fM", pos.marketValue / 1_000_000.0),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                color = TextPrimary,
                modifier = Modifier.weight(1.2f)
              )

              Column(modifier = Modifier.weight(1.3f), horizontalAlignment = Alignment.End) {
                Text(
                  text = String.format(Locale.US, "%+,.0f", pos.unrealizedPnl),
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = if (isUp) TerminalGreen else TerminalRed
                )
                Text(
                  text = String.format(Locale.US, "(%+.1f%%)", pos.unrealizedPnlPct),
                  fontFamily = FontFamily.Monospace,
                  fontSize = 9.sp,
                  color = if (isUp) TerminalGreen else TerminalRed
                )
              }
            }
          }
        }
      }

      "RISK_METRICS" -> {
        // Quantitative Risk Engine Metrics
        item {
          Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, TerminalBorder)
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                text = "PORTFOLIO RISK PROFILE // RISK-CORE",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TerminalCyan
              )
              HorizontalDivider(color = TerminalBorderSubtle)

              RiskRow("Parametric Daily VaR (95%)", "$1,850,000 (1.85% NAV)")
              RiskRow("Historical Daily VaR (99%)", "$2,620,000 (2.62% NAV)")
              RiskRow("Expected Shortfall (CVaR 97.5%)", "$2,340,000 (2.34% NAV)")
              RiskRow("Portfolio Beta to Benchmark", "1.18x")
              RiskRow("Ex-Ante Tracking Error", "2.45% annualized")
              RiskRow("Annualized Sharpe Ratio", "1.68")
              RiskRow("Sortino Downside Ratio", "2.14")
              RiskRow("Maximum Historical Drawdown", "-12.4% (Aug 2024)")
              RiskRow("Gross Exposure", "100.0% (Long-Only)")
              RiskRow("Factor Risk Breakdown", "72% Systematic / 28% Idiosyncratic")
            }
          }
        }
      }

      "STRESS_TEST" -> {
        item {
          Text(
            text = "MACRO SCENARIO DECOMPOSITION & WHAT-IF STRESS",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = TerminalAmber
          )
        }

        items(stressScenarios) { scen ->
          Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, TerminalBorder)
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = scen.name,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = TerminalAmber
                )
                Text(
                  text = "${scen.portfolioImpactPct}% NAV",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = TerminalRed
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = scen.description,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "Shocks: Equities ${scen.equityShockPct}% | Rates +${scen.ratesShockBp}bp | Vol +${scen.volShockPct.toInt()}%",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 9.sp,
                  color = TextMuted
                )
                Text(
                  text = "Est. Loss: $${String.format(Locale.US, "%,.1fM", scen.estimatedPnlLoss / 1_000_000.0)}",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp,
                  color = TerminalRed
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SummaryItem(label: String, value: String, isPositive: Boolean) {
  Column {
    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
    Text(
      text = value,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp,
      color = if (isPositive) TerminalGreen else TerminalRed
    )
  }
}

@Composable
private fun RiskRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextSecondary)
    Text(text = value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
  }
}
