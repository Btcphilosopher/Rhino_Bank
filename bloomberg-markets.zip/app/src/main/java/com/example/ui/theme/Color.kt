package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Terminal Palette (Bloomberg // Markets)
val TerminalBg = Color(0xFF070A0E)
val TerminalSurface = Color(0xFF0E131A)
val TerminalSurfaceElevated = Color(0xFF141B24)
val TerminalSurfaceHighlight = Color(0xFF1C2533)
val TerminalBorder = Color(0xFF253142)
val TerminalBorderSubtle = Color(0xFF19222E)

// Semantic Accents
val TerminalAmber = Color(0xFFFF9900)
val TerminalAmberLight = Color(0xFFFFB84D)
val TerminalAmberDark = Color(0xFFB36B00)

val TerminalCyan = Color(0xFF00E5FF)
val TerminalCyanMuted = Color(0xFF0097A7)

val TerminalGreen = Color(0xFF00E676)
val TerminalGreenBg = Color(0xFF0A2E1C)
val TerminalGreenMuted = Color(0xFF00B0FF)

val TerminalRed = Color(0xFFFF3D57)
val TerminalRedBg = Color(0xFF330D15)

val TerminalYellow = Color(0xFFFFD600)
val TerminalBlue = Color(0xFF2979FF)
val TerminalPurple = Color(0xFFB388FF)

// Text Colors
val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF8FA3B8)
val TextMuted = Color(0xFF5A6C80)
val TextDim = Color(0xFF3B4856)

// Functional
val BidColor = Color(0xFF00E676)
val AskColor = Color(0xFFFF3D57)
val MidColor = Color(0xFFFFB84D)
