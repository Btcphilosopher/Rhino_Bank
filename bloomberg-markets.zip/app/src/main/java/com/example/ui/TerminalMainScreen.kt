package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.MarketDataRepository
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun TerminalMainScreen() {
  val securities by MarketDataRepository.securities.collectAsStateWithLifecycle()
  val selectedSecurity by MarketDataRepository.selectedSecurity.collectAsStateWithLifecycle()
  val orderBook by MarketDataRepository.orderBook.collectAsStateWithLifecycle()
  val tradesTape by MarketDataRepository.tradesTape.collectAsStateWithLifecycle()
  val indices by MarketDataRepository.indices.collectAsStateWithLifecycle()
  val news by MarketDataRepository.news.collectAsStateWithLifecycle()
  val portfolioHoldings by MarketDataRepository.portfolioHoldings.collectAsStateWithLifecycle()
  val stressScenarios by MarketDataRepository.stressScenarios.collectAsStateWithLifecycle()
  val marketRegime by MarketDataRepository.marketRegime.collectAsStateWithLifecycle()
  val isLiveStreaming by MarketDataRepository.isLiveStreaming.collectAsStateWithLifecycle()

  var activeTab by remember { mutableStateOf("MKT") } // MKT, SEC, FUN, QNT, PORT, WIRE, TWIN, API, AI
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  // Command parser
  fun executeCommand(rawCommand: String) {
    val clean = rawCommand.trim().uppercase()
      .replace("<GO>", "")
      .replace("GO", "")
      .trim()

    when {
      clean.startsWith("ORDERBOOK ") || clean.startsWith("L2 ") -> {
        val ticker = clean.substringAfter(" ").trim()
        MarketDataRepository.selectSecurity(ticker)
        activeTab = "SEC"
      }
      clean.startsWith("FUNDAMENTALS ") || clean.startsWith("FUN ") -> {
        val ticker = clean.substringAfter(" ").trim()
        MarketDataRepository.selectSecurity(ticker)
        activeTab = "FUN"
      }
      clean.startsWith("DCF ") || clean.startsWith("VALUATION ") -> {
        val ticker = clean.substringAfter(" ").trim()
        MarketDataRepository.selectSecurity(ticker)
        activeTab = "FUN"
      }
      clean == "MKT" || clean == "MARKET" || clean == "OVERVIEW" -> {
        activeTab = "MKT"
      }
      clean == "SEC" || clean == "SECURITY" || clean == "ORDERBOOK" -> {
        activeTab = "SEC"
      }
      clean == "FUN" || clean == "FUNDAMENTALS" -> {
        activeTab = "FUN"
      }
      clean == "QNT" || clean == "QUANT" || clean == "SCREENER" || clean == "SCREEN" -> {
        activeTab = "QNT"
      }
      clean == "PORT" || clean == "PORTFOLIO" || clean == "RISK" -> {
        activeTab = "PORT"
      }
      clean == "WIRE" || clean == "NEWS" || clean == "FILINGS" -> {
        activeTab = "WIRE"
      }
      clean == "TWIN" || clean == "REPLAY" || clean == "SCENARIO" -> {
        activeTab = "TWIN"
      }
      clean == "API" || clean == "DEVELOPER" || clean == "SDK" -> {
        activeTab = "API"
      }
      clean == "AI" || clean == "RESEARCH" || clean == "COPILOT" -> {
        activeTab = "AI"
      }
      clean == "HELP" || clean == "?" -> {
        scope.launch {
          snackbarHostState.showSnackbar(
            message = "COMMANDS: <TICKER> (e.g. AAPL, NVDA), ORDERBOOK <TICKER>, DCF <TICKER>, RISK, PORT, TWIN, SCREEN, WIRE, API, AI",
            duration = SnackbarDuration.Short
          )
        }
      }
      else -> {
        // Assume ticker lookup
        val foundSec = securities.find { it.ticker.equals(clean, ignoreCase = true) }
        if (foundSec != null) {
          MarketDataRepository.selectSecurity(clean)
          activeTab = "SEC"
        } else {
          // If not exact ticker, try AI search or switch tab
          MarketDataRepository.selectSecurity(clean)
          activeTab = "SEC"
        }
      }
    }
  }

  Scaffold(
    snackbarHost = {
      SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier.padding(bottom = 54.dp)
      ) { data ->
        Snackbar(
          containerColor = TerminalSurfaceHighlight,
          contentColor = TerminalAmber,
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier.border(1.dp, TerminalAmber, RoundedCornerShape(2.dp))
        ) {
          Text(text = data.visuals.message, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
      }
    },
    topBar = {
      TerminalHeader(
        indices = indices,
        isLiveStreaming = isLiveStreaming,
        onToggleStreaming = { MarketDataRepository.toggleLiveStreaming() },
        onExecuteCommand = { executeCommand(it) },
        activeTab = activeTab,
        onSelectTab = { activeTab = it }
      )
    },
    bottomBar = {
      TerminalBottomBar(
        activeTab = activeTab,
        onSelectTab = { activeTab = it }
      )
    },
    containerColor = TerminalBg,
    contentWindowInsets = WindowInsets.safeDrawing
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      when (activeTab) {
        "MKT" -> MarketOverviewScreen(
          indices = indices,
          exchanges = MarketDataRepository.exchanges,
          marketRegime = marketRegime,
          onSelectSecurity = {
            MarketDataRepository.selectSecurity(it)
            activeTab = "SEC"
          }
        )
        "SEC" -> SecurityWorkspaceScreen(
          security = selectedSecurity,
          allSecurities = securities,
          orderBook = orderBook,
          tradesTape = tradesTape,
          corporateActions = MarketDataRepository.corporateActions,
          onSelectSecurity = { MarketDataRepository.selectSecurity(it) }
        )
        "FUN" -> FundamentalsValuationScreen(
          security = selectedSecurity
        )
        "QNT" -> QuantScreenerScreen(
          securities = securities,
          selectedSecurity = selectedSecurity,
          onSelectSecurity = {
            MarketDataRepository.selectSecurity(it)
            activeTab = "SEC"
          }
        )
        "PORT" -> PortfolioRiskScreen(
          holdings = portfolioHoldings,
          stressScenarios = stressScenarios,
          onSelectSecurity = {
            MarketDataRepository.selectSecurity(it)
            activeTab = "SEC"
          }
        )
        "WIRE" -> NewsFilingsScreen(
          newsList = news,
          filingsList = MarketDataRepository.filings,
          onSelectSecurity = {
            MarketDataRepository.selectSecurity(it)
            activeTab = "SEC"
          }
        )
        "TWIN" -> MarketTwinScreen()
        "API" -> DeveloperApiScreen()
        "AI" -> MarketsAiScreen()
      }
    }
  }
}

@Composable
private fun TerminalBottomBar(
  activeTab: String,
  onSelectTab: (String) -> Unit
) {
  val tabs = listOf(
    TabDef("MKT", "MKT", Icons.Default.Public),
    TabDef("SEC", "SEC", Icons.Default.ShowChart),
    TabDef("FUN", "FUN", Icons.Default.AccountBalance),
    TabDef("QNT", "QNT", Icons.Default.FilterAlt),
    TabDef("PORT", "PORT", Icons.Default.PieChart),
    TabDef("WIRE", "WIRE", Icons.Default.Feed),
    TabDef("TWIN", "TWIN", Icons.Default.Memory),
    TabDef("API", "API", Icons.Default.Terminal),
    TabDef("AI", "AI", Icons.Default.Psychology)
  )

  Surface(
    color = TerminalSurface,
    tonalElevation = 0.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorderSubtle),
    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp)
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceAround
    ) {
      tabs.forEach { tab ->
        val isSelected = activeTab == tab.key
        Column(
          modifier = Modifier
            .clickable { onSelectTab(tab.key) }
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .testTag("nav_tab_${tab.key}"),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = tab.icon,
            contentDescription = tab.label,
            tint = if (isSelected) TerminalAmber else TextSecondary,
            modifier = Modifier.size(18.dp)
          )
          Text(
            text = tab.label,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 9.sp,
            color = if (isSelected) TerminalAmber else TextMuted
          )
        }
      }
    }
  }
}

private data class TabDef(
  val key: String,
  val label: String,
  val icon: ImageVector
)
