package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketDataRepository
import com.example.model.ApiEndpoint
import com.example.ui.theme.*

@Composable
fun DeveloperApiScreen() {
  val endpoints = MarketDataRepository.apiEndpoints
  var selectedEndpoint by remember { mutableStateOf(endpoints.first()) }
  var selectedSdkLang by remember { mutableStateOf("PYTHON") } // PYTHON, RUST, R, CURL, GRAPHQL

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. API Architecture Overview Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Text(
            text = "MARKETS API // INSTITUTIONAL DEVELOPER SUITE",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = TerminalAmber
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Ultra-Low Latency REST, WebSockets & GraphQL Engine | mTLS & Entitlements Gate",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = TextSecondary
          )
          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            SdkBadge("Python: markets-python (3.12+)")
            SdkBadge("Rust: markets-engine (crates.io)")
            SdkBadge("R: marketsR (CRAN)")
            SdkBadge("TS: markets-js")
          }
        }
      }
    }

    // 2. Endpoint Selector Chips
    item {
      Text(
        text = "STANDARDIZED REST & WEBSOCKET ENDPOINTS",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = TerminalCyan
      )
    }

    items(endpoints) { ep ->
      val isSelected = ep.path == selectedEndpoint.path
      Card(
        colors = CardDefaults.cardColors(
          containerColor = if (isSelected) TerminalSurfaceHighlight else TerminalSurface
        ),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, if (isSelected) TerminalAmber else TerminalBorder)
          .clickable { selectedEndpoint = ep }
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .background(
                if (ep.method == "GET") TerminalGreenBg else TerminalAmberDark,
                RoundedCornerShape(2.dp)
              )
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = ep.method,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 9.sp,
              color = if (ep.method == "GET") TerminalGreen else TerminalAmber
            )
          }

          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = ep.path,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              color = TextPrimary
            )
            Text(
              text = ep.summary,
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
              color = TextSecondary
            )
          }
        }
      }
    }

    // 3. Interactive Code Generator Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Text(
            text = "CLIENT SDK CODE IMPLEMENTATION",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = TerminalAmber
          )
          Spacer(modifier = Modifier.height(6.dp))

          // Language Switcher Tabs
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(TerminalSurfaceElevated)
              .padding(2.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            listOf("PYTHON", "RUST", "R", "CURL", "GRAPHQL").forEach { lang ->
              val isSel = selectedSdkLang == lang
              Box(
                modifier = Modifier
                  .background(if (isSel) TerminalAmber else Color.Transparent, RoundedCornerShape(2.dp))
                  .clickable { selectedSdkLang = lang }
                  .padding(horizontal = 6.dp, vertical = 3.dp)
              ) {
                Text(
                  text = lang,
                  fontFamily = FontFamily.Monospace,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSel) TerminalBg else TextSecondary
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Code Snippet Box
          val codeText = when (selectedSdkLang) {
            "PYTHON" -> selectedEndpoint.samplePython
            "RUST" -> selectedEndpoint.sampleRust
            "R" -> "library(marketsR)\nclient <- markets_client(api_key = Sys.getenv(\"MARKETS_API_KEY\"))\nquote <- client\$market_quote(\"AAPL\")\nprint(quote\$last)"
            "CURL" -> selectedEndpoint.sampleCurl
            "GRAPHQL" -> "query GetSecurityOverview {\n  security(ticker: \"AAPL\") {\n    ticker\n    isin\n    lastPrice\n    orderBook(depth: 5) {\n      spreadBps\n      bids { price quantity }\n    }\n  }\n}"
            else -> selectedEndpoint.samplePython
          }

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(TerminalBg, RoundedCornerShape(2.dp))
              .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(2.dp))
              .padding(8.dp)
          ) {
            Text(
              text = codeText,
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
              color = TerminalCyan,
              lineHeight = 14.sp
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "STANDARDIZED JSON RESPONSE PAYLOAD",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = TextSecondary
          )
          Spacer(modifier = Modifier.height(4.dp))

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(TerminalBg, RoundedCornerShape(2.dp))
              .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(2.dp))
              .padding(8.dp)
          ) {
            Text(
              text = selectedEndpoint.sampleResponse,
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
              color = TerminalGreen,
              lineHeight = 14.sp
            )
          }
        }
      }
    }
  }
}

@Composable
private fun SdkBadge(text: String) {
  Box(
    modifier = Modifier
      .background(TerminalSurfaceHighlight, RoundedCornerShape(2.dp))
      .padding(horizontal = 4.dp, vertical = 2.dp)
  ) {
    Text(
      text = text,
      fontFamily = FontFamily.Monospace,
      fontSize = 8.sp,
      color = TextSecondary
    )
  }
}
