package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketDataRepository
import com.example.model.AiResearchAudit
import com.example.ui.theme.*

@Composable
fun MarketsAiScreen() {
  var userQuery by remember { mutableStateOf("Why is NVDA moving today?") }
  var activeAudit by remember { mutableStateOf<AiResearchAudit?>(null) }

  LaunchedEffect(Unit) {
    activeAudit = MarketDataRepository.executeAiQuery("Why is NVDA moving today?")
  }

  val promptChips = listOf(
    "Why is NVDA moving today?",
    "AAPL fundamentals & DCF valuation",
    "What happens if US rates rise 100bp?",
    "Global equity breadth & regime scan"
  )

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Header Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Text(
            text = "MARKETS AI // COMPUTATIONAL MARKET RESEARCH GRAPH",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = TerminalAmber
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Structured Graph Traversal: COMPANY → SECURITY → FUNDAMENTALS → ESTIMATES → NEWS → RISK",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = TextSecondary
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Rule: Never fabricates market facts. Every assertion exposes underlying datasets, provenance, and calculation model.",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = TextMuted
          )
        }
      }
    }

    // 2. Query Input & Quick Prompt Chips
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = userQuery,
            onValueChange = { userQuery = it },
            placeholder = {
              Text(
                text = "ENTER MARKET RESEARCH QUERY...",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = TextDim
              )
            },
            singleLine = true,
            textStyle = LocalTextStyle.current.copy(
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              color = TextPrimary
            ),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = TerminalSurface,
              unfocusedContainerColor = TerminalSurface,
              focusedBorderColor = TerminalAmber,
              unfocusedBorderColor = TerminalBorder
            ),
            modifier = Modifier
              .weight(1f)
              .height(44.dp)
          )

          Spacer(modifier = Modifier.width(6.dp))

          Button(
            onClick = {
              if (userQuery.isNotBlank()) {
                activeAudit = MarketDataRepository.executeAiQuery(userQuery.trim())
              }
            },
            colors = ButtonDefaults.buttonColors(
              containerColor = TerminalAmber,
              contentColor = TerminalBg
            ),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.height(44.dp)
          ) {
            Text(
              text = "QUERY",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp
            )
          }
        }

        // Prompt Chips
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          promptChips.forEach { chip ->
            Box(
              modifier = Modifier
                .background(TerminalSurfaceElevated, RoundedCornerShape(2.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(2.dp))
                .clickable {
                  userQuery = chip
                  activeAudit = MarketDataRepository.executeAiQuery(chip)
                }
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = chip,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TerminalCyan
              )
            }
          }
        }
      }
    }

    // 3. AI Computational Response & Structured Provenance Card
    item {
      val audit = activeAudit
      if (audit != null) {
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "STRUCTURED MARKET INTELLIGENCE",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TerminalAmber
              )

              Box(
                modifier = Modifier
                  .background(TerminalGreenBg, RoundedCornerShape(2.dp))
                  .border(1.dp, TerminalGreen, RoundedCornerShape(2.dp))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "CONFIDENCE: ${(audit.confidenceScore * 100).toInt()}%",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 9.sp,
                  color = TerminalGreen
                )
              }
            }

            // Analytical Synthesis
            Text(
              text = audit.structuredAnswer,
              fontFamily = FontFamily.Monospace,
              fontSize = 12.sp,
              color = TextPrimary,
              lineHeight = 17.sp
            )

            HorizontalDivider(color = TerminalBorderSubtle)

            // Key Inferences
            Text(
              text = "KEY QUANTITATIVE INFERENCES:",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              color = TerminalCyan
            )
            audit.keyInferences.forEach { inf ->
              Text(
                text = "• $inf",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary,
                lineHeight = 14.sp
              )
            }

            HorizontalDivider(color = TerminalBorderSubtle)

            // Provenance & Audit Metadata Grid
            Text(
              text = "AUDIT TRAIL & DATA PROVENANCE (STRICT VERIFICATION):",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              color = TerminalAmber
            )

            AuditRow("DATA SOURCES USED", audit.dataPointsUsed.joinToString(", "))
            AuditRow("TIME HORIZON", audit.timeHorizon)
            AuditRow("PROVENANCE TIER", audit.dataProvenance)
            AuditRow("CALCULATION MODEL", audit.calculationMethod)
          }
        }
      }
    }
  }
}

@Composable
private fun AuditRow(label: String, value: String) {
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
    Text(text = value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, fontSize = 10.sp, color = TextPrimary)
  }
}
