package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketDataRepository
import com.example.model.QuantFactorBacktest
import com.example.model.Security
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun QuantScreenerScreen(
  securities: List<Security>,
  selectedSecurity: Security?,
  onSelectSecurity: (String) -> Unit
) {
  var selectedTab by remember { mutableStateOf("SCREENER") } // SCREENER, QUANT_LAB

  // Screener Filters
  var maxPeFilter by remember { mutableStateOf(45.0) }
  var minRoicFilter by remember { mutableStateOf(10.0) }
  var minFcfYieldFilter by remember { mutableStateOf(1.5) }
  var selectedSector by remember { mutableStateOf("ALL") }

  val filteredSecurities = remember(securities, maxPeFilter, minRoicFilter, minFcfYieldFilter, selectedSector) {
    securities.filter { sec ->
      sec.pe <= maxPeFilter &&
      sec.roicPct >= minRoicFilter &&
      sec.fcfYieldPct >= minFcfYieldFilter &&
      (selectedSector == "ALL" || sec.sector.equals(selectedSector, ignoreCase = true))
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Tab Switcher
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurfaceElevated)
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        listOf(
          "SCREENER" to "INSTITUTIONAL EQUITY SCREENER",
          "QUANT_LAB" to "QUANT LAB // FACTOR BACKTEST ENGINE"
        ).forEach { (key, title) ->
          val isSelected = selectedTab == key
          Box(
            modifier = Modifier
              .background(
                if (isSelected) TerminalAmber else Color.Transparent,
                RoundedCornerShape(2.dp)
              )
              .clickable { selectedTab = key }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
              text = title,
              fontFamily = FontFamily.Monospace,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp,
              color = if (isSelected) TerminalBg else TextSecondary
            )
          }
        }
      }
    }

    if (selectedTab == "SCREENER") {
      // 2. Screener Controls Card
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = "BOOLEAN CRITERIA FILTER // SCREENING-CORE",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = TerminalAmber
            )

            // Current Query string
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceHighlight, RoundedCornerShape(2.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(2.dp))
                .padding(6.dp)
            ) {
              Text(
                text = "QUERY: PE <= ${maxPeFilter.toInt()} AND ROIC >= ${minRoicFilter.toInt()}% AND FCF_YIELD >= ${String.format(Locale.US, "%.1f", minFcfYieldFilter)}% AND SECTOR == '$selectedSector'",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TerminalCyan
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Sliders
            FilterSlider(
              label = "Max P/E Multiple",
              valueText = "<= ${maxPeFilter.toInt()}x",
              value = maxPeFilter.toFloat(),
              range = 10f..60f,
              onValueChange = { maxPeFilter = it.toDouble() }
            )

            FilterSlider(
              label = "Min ROIC (%)",
              valueText = ">= ${minRoicFilter.toInt()}%",
              value = minRoicFilter.toFloat(),
              range = 0f..50f,
              onValueChange = { minRoicFilter = it.toDouble() }
            )

            FilterSlider(
              label = "Min FCF Yield (%)",
              valueText = ">= ${String.format(Locale.US, "%.1f", minFcfYieldFilter)}%",
              value = minFcfYieldFilter.toFloat(),
              range = 0f..10f,
              onValueChange = { minFcfYieldFilter = it.toDouble() }
            )

            // Sector Filters
            Text(text = "SECTOR UNIVERSE:", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary)
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              listOf("ALL", "Technology", "Financials", "Healthcare", "Consumer Cyclical").forEach { sec ->
                val isSelected = selectedSector == sec
                Box(
                  modifier = Modifier
                    .background(if (isSelected) TerminalCyan else TerminalSurfaceHighlight, RoundedCornerShape(2.dp))
                    .clickable { selectedSector = sec }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                  Text(
                    text = sec,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = if (isSelected) TerminalBg else TextPrimary
                  )
                }
              }
            }
          }
        }
      }

      // 3. Screened Results Header
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "MATCHING SECURITIES: ${filteredSecurities.size} / ${securities.size}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = TerminalGreen
          )
          Text(
            text = "TAP TO OPEN IN WORKSPACE",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = TextMuted
          )
        }
      }

      // 4. Filtered Securities List
      items(filteredSecurities) { sec ->
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
            .clickable { onSelectSecurity(sec.ticker) }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = sec.ticker,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = TerminalAmber
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = sec.displayName,
                  fontFamily = FontFamily.Monospace,
                  fontSize = 12.sp,
                  color = TextPrimary
                )
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "${sec.sector} | ${sec.country} | P/E: ${sec.pe}x | ROIC: ${sec.roicPct}% | FCF Yield: ${sec.fcfYieldPct}%",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = String.format(Locale.US, "$%.2f", sec.price),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = TextPrimary
              )
              val isUp = sec.change >= 0
              Text(
                text = String.format(Locale.US, "%+.2f%%", sec.changePct),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = if (isUp) TerminalGreen else TerminalRed
              )
            }
          }
        }
      }
    } else {
      // QUANT LAB: Factor scores & Factor backtest table
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = "FACTOR SCORES // ${selectedSecurity?.ticker ?: "AAPL"} Z-SCORE EXPOSURES",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = TerminalAmber
            )
            HorizontalDivider(color = TerminalBorderSubtle)

            if (selectedSecurity != null) {
              FactorZScoreRow("Value (EBITDA/EV + FCF Yield)", selectedSecurity.factorValue)
              FactorZScoreRow("Momentum (12M - 1M Residual)", selectedSecurity.factorMomentum)
              FactorZScoreRow("Quality (ROIC + Margins + Leverage)", selectedSecurity.factorQuality)
              FactorZScoreRow("Low Volatility (Inverse Realized Var)", selectedSecurity.factorLowVol)
            }
          }
        }
      }

      item {
        Text(
          text = "HISTORICAL FACTOR STRATEGY BACKTEST RESULTS (10Y)",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          color = TerminalCyan
        )
      }

      items(MarketDataRepository.factorBacktests) { bt ->
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalSurface),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder)
        ) {
          Column(modifier = Modifier.padding(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = bt.factorName,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TerminalAmber
              )
              Text(
                text = "Ann. Return: +${bt.annualizedReturnPct}%",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TerminalGreen
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Sharpe: ${bt.sharpe}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary)
              Text(text = "Max DD: -${bt.maxDrawdownPct}%", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary)
              Text(text = "Turnover: ${bt.turnoverAnnualPct}%", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary)
              Text(text = "L/S Spread: +${bt.longShortSpreadPct}%", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TerminalCyan)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun FilterSlider(
  label: String,
  valueText: String,
  value: Float,
  range: ClosedFloatingPointRange<Float>,
  onValueChange: (Float) -> Unit
) {
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary)
      Text(text = valueText, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TerminalAmber)
    }
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = range,
      colors = SliderDefaults.colors(
        thumbColor = TerminalAmber,
        activeTrackColor = TerminalAmber,
        inactiveTrackColor = TerminalSurfaceHighlight
      ),
      modifier = Modifier.height(26.dp)
    )
  }
}

@Composable
private fun FactorZScoreRow(factor: String, zScore: Double) {
  val isPositive = zScore >= 0
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(text = factor, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary)
    Text(
      text = String.format(Locale.US, "%+.2f σ", zScore),
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp,
      color = if (isPositive) TerminalGreen else TerminalRed
    )
  }
}
