package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val BloombergTerminalColorScheme = darkColorScheme(
  primary = TerminalAmber,
  onPrimary = TerminalBg,
  primaryContainer = TerminalSurfaceElevated,
  onPrimaryContainer = TerminalAmberLight,
  secondary = TerminalCyan,
  onSecondary = TerminalBg,
  secondaryContainer = TerminalSurfaceElevated,
  onSecondaryContainer = TerminalCyan,
  tertiary = TerminalGreen,
  onTertiary = TerminalBg,
  background = TerminalBg,
  onBackground = TextPrimary,
  surface = TerminalSurface,
  onSurface = TextPrimary,
  surfaceVariant = TerminalSurfaceElevated,
  onSurfaceVariant = TextSecondary,
  outline = TerminalBorder,
  outlineVariant = TerminalBorderSubtle,
  error = TerminalRed,
  onError = TextPrimary
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = BloombergTerminalColorScheme,
    typography = TerminalTypography,
    content = content
  )
}
