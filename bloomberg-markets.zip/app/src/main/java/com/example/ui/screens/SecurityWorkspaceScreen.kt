package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun SecurityWorkspaceScreen(
  security: Security?,
  allSecurities: List<Security>,
  orderBook: OrderBook?,
  tradesTape: List<TradeTapeItem>,
  corporateActions: List<CorporateAction>,
  onSelectSecurity: (String) -> Unit
) {
  if (security == null) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(TerminalBg),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = "NO SECURITY SELECTED. ENTER TICKER IN COMMAND BAR (e.g. AAPL <GO>).",
        fontFamily = FontFamily.Monospace,
        color = TextMuted
      )
    }
    return
  }

  var selectedSubTab by remember { mutableStateOf("ORDERBOOK") } // ORDERBOOK, METRICS, CA

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(TerminalBg)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Ticker Quick Selector Pills
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        allSecurities.forEach { sec ->
          val isSelected = sec.ticker == security.ticker
          Box(
            modifier = Modifier
              .background(
                if (isSelected) TerminalAmber else TerminalSurface,
                RoundedCornerShape(2.dp)
              )
              .border(
                1.dp,
                if (isSelected) TerminalAmberLight else TerminalBorder,
                RoundedCornerShape(2.dp)
              )
              .clickable { onSelectSecurity(sec.ticker) }
              .padding(horizontal = 8.dp, vertical = 4.dp)
              .testTag("select_ticker_${sec.ticker}")
          ) {
            Text(
              text = sec.ticker,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              color = if (isSelected) TerminalBg else TextPrimary
            )
          }
        }
      }
    }

    // 2. Security Master Descriptive Header (SECURITY-MASTER)
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, TerminalBorder)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          // Top Line: Ticker, Name, Status, Exchange
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = security.ticker,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 18.sp,
                  color = TerminalAmber
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = security.displayName,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 14.sp,
                  color = TextPrimary
                )
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "${security.exchange} (${security.mic}) | ${security.country} | Sector: ${security.sector}",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              val isUp = security.change >= 0
              Text(
                text = String.format(Locale.US, "%.2f %s", security.price, security.currency),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = TextPrimary
              )
              Text(
                text = String.format(Locale.US, "%+.2f (%+.2f%%)", security.change, security.changePct),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (isUp) TerminalGreen else TerminalRed
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          HorizontalDivider(color = TerminalBorderSubtle, thickness = 1.dp)
          Spacer(modifier = Modifier.height(6.dp))

          // Instrument Reference Master Identifiers
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            RefCodeItem(label = "ISIN", value = security.isin)
            RefCodeItem(label = "FIGI", value = security.figi)
            RefCodeItem(label = "SEDOL", value = security.sedol)
            RefCodeItem(label = "STATUS", value = security.status)
          }

          Spacer(modifier = Modifier.height(6.dp))
          HorizontalDivider(color = TerminalBorderSubtle, thickness = 1.dp)
          Spacer(modifier = Modifier.height(6.dp))

          // L1 Quote Bar
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            QuoteStatItem("OPEN", String.format(Locale.US, "%.2f", security.open))
            QuoteStatItem("HIGH", String.format(Locale.US, "%.2f", security.high))
            QuoteStatItem("LOW", String.format(Locale.US, "%.2f", security.low))
            QuoteStatItem("VWAP", String.format(Locale.US, "%.2f", security.vwap))
            QuoteStatItem("VOLUME", String.format(Locale.US, "%,d", security.volume))
            QuoteStatItem("52W H/L", String.format(Locale.US, "%.1f/%.1f", security.high52w, security.low52w))
          }
        }
      }
    }

    // 3. Sub-View Tabs Switcher
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(TerminalSurfaceElevated)
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        listOf(
          "ORDERBOOK" to "LEVEL 2 ORDER BOOK & TAPE",
          "METRICS" to "MICROSTRUCTURE & L1 DESK",
          "CA" to "CORPORATE ACTIONS"
        ).forEach { (tabKey, title) ->
          val isSelected = selectedSubTab == tabKey
          Box(
            modifier = Modifier
              .background(
                if (isSelected) TerminalSurfaceHighlight else Color.Transparent,
                RoundedCornerShape(2.dp)
              )
              .border(
                1.dp,
                if (isSelected) TerminalCyan else TerminalBorderSubtle,
                RoundedCornerShape(2.dp)
              )
              .clickable { selectedSubTab = tabKey }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
              text = title,
              fontFamily = FontFamily.Monospace,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp,
              color = if (isSelected) TerminalCyan else TextSecondary
            )
          }
        }
      }
    }

    // Content based on sub-tab
    when (selectedSubTab) {
      "ORDERBOOK" -> {
        // Level 2 Order Book & Auction Imbalance
        item {
          if (orderBook != null) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              // Auction & Spread Indicator Banner
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(TerminalSurfaceElevated, RoundedCornerShape(2.dp))
                  .border(1.dp, TerminalBorder, RoundedCornerShape(2.dp))
                  .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "SPREAD: ${String.format(Locale.US, "%.2f", orderBook.spread)} (${orderBook.spreadBps} bps)",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TerminalAmber
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(
                    text = "AUCTION: ${orderBook.auctionStatus}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = TextSecondary
                  )
                }

                Text(
                  text = "IMBALANCE: ${orderBook.imbalanceSide} ${String.format(Locale.US, "%,d", orderBook.indicativeImbalanceQty)} shs @ ${String.format(Locale.US, "%.2f", orderBook.indicativeAuctionPrice)}",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 10.sp,
                  color = if (orderBook.imbalanceSide == OrderSide.BUY) TerminalGreen else TerminalRed
                )
              }

              // Dual-Column Order Book Ladder: Bids (left) and Asks (right)
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(TerminalSurface)
                  .border(1.dp, TerminalBorder)
                  .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                // Bids Column
                Column(modifier = Modifier.weight(1f)) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .background(TerminalGreenBg)
                      .padding(horizontal = 4.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text("BIDS (BUY)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TerminalGreen)
                    Text("SIZE / CUM", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextSecondary)
                  }
                  orderBook.bids.take(8).forEach { bid ->
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 3.dp),
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Text(
                        text = String.format(Locale.US, "%.2f", bid.price),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = TerminalGreen
                      )
                      Text(
                        text = "${String.format(Locale.US, "%,d", bid.quantity)} (${String.format(Locale.US, "%,d", bid.cumulativeQty)})",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TextPrimary
                      )
                    }
                    HorizontalDivider(color = TerminalBorderSubtle, thickness = 0.5.dp)
                  }
                }

                // Asks Column
                Column(modifier = Modifier.weight(1f)) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .background(TerminalRedBg)
                      .padding(horizontal = 4.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text("ASKS (SELL)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TerminalRed)
                    Text("SIZE / CUM", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextSecondary)
                  }
                  orderBook.asks.take(8).forEach { ask ->
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 3.dp),
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Text(
                        text = String.format(Locale.US, "%.2f", ask.price),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = TerminalRed
                      )
                      Text(
                        text = "${String.format(Locale.US, "%,d", ask.quantity)} (${String.format(Locale.US, "%,d", ask.cumulativeQty)})",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TextPrimary
                      )
                    }
                    HorizontalDivider(color = TerminalBorderSubtle, thickness = 0.5.dp)
                  }
                }
              }

              // Live Trades Tape
              Text(
                text = "REAL-TIME EXECUTED TRADES TAPE",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TerminalAmber,
                modifier = Modifier.padding(top = 4.dp)
              )

              Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .border(1.dp, TerminalBorder)
              ) {
                Column(modifier = Modifier.padding(6.dp)) {
                  tradesTape.take(6).forEach { trade ->
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 3.dp),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        text = trade.time,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TextMuted
                      )
                      Text(
                        text = String.format(Locale.US, "%.2f", trade.price),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (trade.side == OrderSide.BUY) TerminalGreen else TerminalRed
                      )
                      Text(
                        text = "${trade.quantity} shs",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TextPrimary
                      )
                      Text(
                        text = "${trade.side} [${trade.venue}]",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = if (trade.side == OrderSide.BUY) TerminalGreen else TerminalRed
                      )
                    }
                    HorizontalDivider(color = TerminalBorderSubtle, thickness = 0.5.dp)
                  }
                }
              }
            }
          }
        }
      }

      "METRICS" -> {
        // Detailed Microstructure & L1 Desk
        item {
          Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, TerminalBorder)
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                text = "SECURITY MICROSTRUCTURE SPECIFICATIONS",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TerminalCyan
              )
              HorizontalDivider(color = TerminalBorderSubtle)

              MetricRow("Exchange MIC", security.mic)
              MetricRow("Security Type", security.securityType.name)
              MetricRow("Shares Outstanding", String.format(Locale.US, "%,.1f M", security.sharesOutstanding))
              MetricRow("Free Float", "${security.freeFloatPct}%")
              MetricRow("Daily Turnover", String.format(Locale.US, "$%,.1f M", security.turnover))
              MetricRow("Trade Count Today", String.format(Locale.US, "%,d", security.tradeCount))
              MetricRow("Daily VaR (95%)", "${security.var95DailyPct}%")
              MetricRow("Beta to Market", "${security.beta}")
              MetricRow("Sharpe Ratio (1Y)", "${security.sharpe}")
              MetricRow("Max Drawdown (3Y)", "${security.maxDrawdownPct}%")
              MetricRow("Feed Latency", "${security.latencyMs} ms")
              MetricRow("Data Provenance", security.dataStatus.name)
            }
          }
        }
      }

      "CA" -> {
        // Corporate Actions
        val caList = corporateActions.filter { it.ticker == security.ticker }
        if (caList.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "NO PENDING CORPORATE ACTIONS FOR ${security.ticker}",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = TextMuted
              )
            }
          }
        } else {
          items(caList) { ca ->
            Card(
              colors = CardDefaults.cardColors(containerColor = TerminalSurface),
              shape = RoundedCornerShape(2.dp),
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, TerminalBorder)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "${ca.type.name} // ${ca.actionId}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = TerminalAmber
                  )
                  Text(
                    text = ca.status,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = TerminalGreen
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "Ex-Date: ${ca.exDate} | Record: ${ca.recordDate} | Effective: ${ca.effectiveDate}",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 10.sp,
                  color = TextSecondary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "Terms: ${ca.ratio} | Cash: ${ca.cashAmount?.let { "$$it" } ?: "N/A"} | Adjustment Factor: ${ca.adjustmentFactor}",
                  fontFamily = FontFamily.Monospace,
                  fontSize = 10.sp,
                  color = TextPrimary
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun RefCodeItem(label: String, value: String) {
  Column {
    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
    Text(text = value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, color = TextPrimary)
  }
}

@Composable
private fun QuoteStatItem(label: String, value: String) {
  Column {
    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
    Text(text = value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
  }
}

@Composable
private fun MetricRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextSecondary)
    Text(text = value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
  }
}
