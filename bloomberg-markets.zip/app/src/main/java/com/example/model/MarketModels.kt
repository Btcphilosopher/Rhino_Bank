package com.example.model

/**
 * Data status and audit provenance indicators as specified in the
 * institutional market architecture.
 */
enum class DataStatus {
  OFFICIAL,
  EXCHANGE,
  LICENSED,
  OBSERVED,
  ESTIMATED,
  MODELLED,
  FORECAST,
  SCENARIO,
  SYNTHETIC
}

enum class SecurityType {
  COMMON_STOCK,
  PREFERRED_STOCK,
  ADR,
  GDR,
  REIT,
  ETF,
  CLOSED_END_FUND,
  INVESTMENT_TRUST
}

enum class MarketSessionStatus {
  OPEN,
  PRE_OPEN,
  AUCTION,
  HALTED,
  CLOSED
}

enum class OrderSide {
  BUY,
  SELL
}

enum class CorporateActionType {
  DIVIDEND,
  SPECIAL_DIVIDEND,
  STOCK_SPLIT,
  REVERSE_SPLIT,
  RIGHTS_ISSUE,
  BUYBACK,
  SPIN_OFF,
  M_AND_A
}

data class Security(
  val securityId: String,
  val issuerId: String,
  val exchange: String,
  val mic: String,
  val ticker: String,
  val isin: String,
  val cusip: String,
  val sedol: String,
  val figi: String,
  val localCode: String,
  val currency: String,
  val country: String,
  val sector: String,
  val industry: String,
  val securityType: SecurityType,
  val sharesOutstanding: Double, // in millions
  val freeFloatPct: Double,
  val status: String,
  val displayName: String,
  // Real-Time Pricing
  val price: Double,
  val change: Double,
  val changePct: Double,
  val bid: Double,
  val bidSize: Int,
  val ask: Double,
  val askSize: Int,
  val open: Double,
  val high: Double,
  val low: Double,
  val prevClose: Double,
  val volume: Long,
  val turnover: Double, // in millions
  val vwap: Double,
  val tradeCount: Int,
  val high52w: Double,
  val low52w: Double,
  // Valuation & Fundamentals
  val pe: Double,
  val forwardPe: Double,
  val pb: Double,
  val evEbitda: Double,
  val evSales: Double,
  val fcfYieldPct: Double,
  val dividendYieldPct: Double,
  val roePct: Double,
  val roicPct: Double,
  val grossMarginPct: Double,
  val operatingMarginPct: Double,
  val netMarginPct: Double,
  // Risk & Quantitative
  val beta: Double,
  val var95DailyPct: Double,
  val sharpe: Double,
  val maxDrawdownPct: Double,
  val factorValue: Double, // z-score
  val factorMomentum: Double,
  val factorQuality: Double,
  val factorLowVol: Double,
  val dataStatus: DataStatus = DataStatus.SYNTHETIC,
  val latencyMs: Double = 0.45
)

data class Company(
  val companyId: String,
  val legalName: String,
  val displayName: String,
  val country: String,
  val headquarters: String,
  val sector: String,
  val industry: String,
  val employees: Int,
  val website: String,
  val lei: String,
  val parentCompany: String? = null,
  val subsidiaries: List<String> = emptyList(),
  val ultimateParent: String? = null,
  val description: String = ""
)

data class ExchangeVenue(
  val code: String,
  val name: String,
  val mic: String,
  val country: String,
  val city: String,
  val timezone: String,
  val status: MarketSessionStatus,
  val localTradingHours: String,
  val currency: String,
  val tickRule: String,
  val auctionTimes: String,
  val listedSecuritiesCount: Int
)

data class OrderBookLevel(
  val price: Double,
  val quantity: Int,
  val orderCount: Int,
  val cumulativeQty: Int,
  val side: OrderSide
)

data class OrderBook(
  val securityId: String,
  val ticker: String,
  val bids: List<OrderBookLevel>,
  val asks: List<OrderBookLevel>,
  val lastPrice: Double,
  val spread: Double,
  val spreadBps: Double,
  val indicativeAuctionPrice: Double,
  val indicativeImbalanceQty: Int,
  val imbalanceSide: OrderSide,
  val auctionStatus: String = "CONTINUOUS_TRADING"
)

data class TradeTapeItem(
  val tradeId: String,
  val time: String,
  val price: Double,
  val quantity: Int,
  val side: OrderSide,
  val venue: String,
  val condition: String = "@"
)

data class GlobalIndex(
  val id: String,
  val ticker: String,
  val name: String,
  val region: String,
  val currency: String,
  val level: Double,
  val change: Double,
  val changePct: Double,
  val constituentsCount: Int,
  val divisor: Double,
  val topConstituents: List<IndexConstituent> = emptyList()
)

data class IndexConstituent(
  val ticker: String,
  val name: String,
  val weightPct: Double,
  val shares: Double,
  val freeFloat: Double
)

data class CorporateAction(
  val actionId: String,
  val ticker: String,
  val type: CorporateActionType,
  val announcementDate: String,
  val exDate: String,
  val recordDate: String,
  val effectiveDate: String,
  val ratio: String,
  val cashAmount: Double?,
  val currency: String,
  val adjustmentFactor: Double,
  val status: String = "CONFIRMED"
)

data class FinancialStatementPeriod(
  val period: String, // e.g. "2024-Q4" or "2024-FY"
  val asReportedDate: String,
  val vintageDate: String,
  val revenue: Double, // Billions
  val grossProfit: Double,
  val ebitda: Double,
  val ebit: Double = 0.0,
  val operatingIncome: Double,
  val netIncome: Double,
  val eps: Double,
  val dps: Double,
  val fcf: Double,
  val capex: Double,
  val cash: Double,
  val totalDebt: Double,
  val netDebt: Double,
  val totalAssets: Double,
  val totalLiabilities: Double,
  val totalEquity: Double
)

data class EarningsSurprise(
  val period: String,
  val reportedEps: Double,
  val consensusEps: Double,
  val surprisePct: Double,
  val reportedRev: Double,
  val consensusRev: Double,
  val revSurprisePct: Double,
  val priceReactionPct: Double
)

data class AnalystConsensus(
  val ticker: String,
  val targetPriceMean: Double,
  val targetPriceHigh: Double,
  val targetPriceLow: Double,
  val currentPrice: Double,
  val buyCount: Int,
  val holdCount: Int,
  val sellCount: Int,
  val epsConsensusNextFy: Double,
  val revConsensusNextFy: Double,
  val revisionMomentum30dPct: Double,
  val surprises: List<EarningsSurprise> = emptyList()
)

data class ValuationDCF(
  val ticker: String,
  val currentPrice: Double,
  val waccPct: Double,
  val terminalGrowthPct: Double,
  val fcfBase: Double,
  val growthRateYear1_5: Double,
  val intrinsicValue: Double,
  val marginOfSafetyPct: Double,
  val impliedMultipleEvEbitda: Double
)

data class PortfolioHolding(
  val ticker: String,
  val name: String,
  val shares: Double,
  val avgCostPrice: Double,
  val currentPrice: Double,
  val marketValue: Double,
  val weightPct: Double,
  val unrealizedPnl: Double,
  val unrealizedPnlPct: Double,
  val sector: String,
  val beta: Double,
  val varContribPct: Double
)

data class StressScenario(
  val id: String,
  val name: String,
  val description: String,
  val equityShockPct: Double,
  val ratesShockBp: Int,
  val usdShockPct: Double,
  val oilShockPct: Double,
  val volShockPct: Double,
  val portfolioImpactPct: Double,
  val estimatedPnlLoss: Double
)

data class NewsItem(
  val id: String,
  val timestamp: String,
  val headline: String,
  val summary: String,
  val source: String,
  val category: String,
  val sentimentScore: Double, // -1.0 to 1.0
  val sentimentLabel: String,
  val relevance: Double,
  val novelty: Double,
  val tickers: List<String>
)

data class RegulatoryFiling(
  val id: String,
  val ticker: String,
  val company: String,
  val formType: String, // 10-K, 10-Q, 8-K, 6-K
  val filingDate: String,
  val title: String,
  val extractedHighlights: String
)

data class QuantFactorBacktest(
  val factorName: String,
  val annualizedReturnPct: Double,
  val sharpe: Double,
  val maxDrawdownPct: Double,
  val turnoverAnnualPct: Double,
  val hitRatePct: Double,
  val longShortSpreadPct: Double
)

data class MarketRegimeInfo(
  val regime: String, // BULL_MOMENTUM, BEAR_VOLATILE, RANGEBOUND_LOW_VOL, RISK_OFF
  val probabilityPct: Int,
  val primarySignal: String,
  val modelVersion: String = "REGIME-LSTM-v4.2",
  val advanceDeclineRatio: Double,
  val pctAbove50Dma: Double,
  val mcclellanOscillator: Double
)

data class AiResearchAudit(
  val query: String,
  val structuredAnswer: String,
  val dataPointsUsed: List<String>,
  val timeHorizon: String,
  val dataProvenance: String,
  val calculationMethod: String,
  val confidenceScore: Double,
  val keyInferences: List<String>
)

data class ApiEndpoint(
  val method: String,
  val path: String,
  val summary: String,
  val description: String,
  val sampleCurl: String,
  val samplePython: String,
  val sampleRust: String,
  val sampleResponse: String
)
