package com.example.engine

import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.random.Random

object MarketDataRepository {

  private val coroutineScope = CoroutineScope(Dispatchers.Default)

  // Global Securities
  private val _securities = MutableStateFlow<List<Security>>(emptyList())
  val securities: StateFlow<List<Security>> = _securities.asStateFlow()

  // Selected Security
  private val _selectedSecurity = MutableStateFlow<Security?>(null)
  val selectedSecurity: StateFlow<Security?> = _selectedSecurity.asStateFlow()

  // Live Order Book for Selected Security
  private val _orderBook = MutableStateFlow<OrderBook?>(null)
  val orderBook: StateFlow<OrderBook?> = _orderBook.asStateFlow()

  // Live Trades Tape
  private val _tradesTape = MutableStateFlow<List<TradeTapeItem>>(emptyList())
  val tradesTape: StateFlow<List<TradeTapeItem>> = _tradesTape.asStateFlow()

  // Global Indices
  private val _indices = MutableStateFlow<List<GlobalIndex>>(emptyList())
  val indices: StateFlow<List<GlobalIndex>> = _indices.asStateFlow()

  // Global Exchanges
  val exchanges: List<ExchangeVenue> = createInitialExchanges()

  // Corporate Actions
  val corporateActions: List<CorporateAction> = createInitialCorporateActions()

  // News Wire
  private val _news = MutableStateFlow<List<NewsItem>>(emptyList())
  val news: StateFlow<List<NewsItem>> = _news.asStateFlow()

  // Regulatory Filings
  val filings: List<RegulatoryFiling> = createInitialFilings()

  // Portfolio Holdings
  private val _portfolioHoldings = MutableStateFlow<List<PortfolioHolding>>(emptyList())
  val portfolioHoldings: StateFlow<List<PortfolioHolding>> = _portfolioHoldings.asStateFlow()

  // Stress Scenarios
  private val _stressScenarios = MutableStateFlow<List<StressScenario>>(emptyList())
  val stressScenarios: StateFlow<List<StressScenario>> = _stressScenarios.asStateFlow()

  // Market Regime
  private val _marketRegime = MutableStateFlow(
    MarketRegimeInfo(
      regime = "BULL_MOMENTUM",
      probabilityPct = 78,
      primarySignal = "Breadth expansion & Credit spreads tight",
      modelVersion = "REGIME-LSTM-v4.2.1",
      advanceDeclineRatio = 2.34,
      pctAbove50Dma = 71.8,
      mcclellanOscillator = 42.6
    )
  )
  val marketRegime: StateFlow<MarketRegimeInfo> = _marketRegime.asStateFlow()

  // Quant Factor Backtests
  val factorBacktests: List<QuantFactorBacktest> = listOf(
    QuantFactorBacktest("Quality (High ROIC/Low Leverage)", 14.8, 1.34, 18.2, 38.0, 64.2, 7.8),
    QuantFactorBacktest("Momentum (12M - 1M Residual)", 16.2, 1.21, 24.5, 92.0, 58.6, 9.4),
    QuantFactorBacktest("Value (EBITDA/EV + FCF Yield)", 13.5, 1.08, 22.0, 44.0, 56.4, 6.2),
    QuantFactorBacktest("Low Volatility (Min Variance)", 11.9, 1.42, 13.4, 28.0, 68.1, 4.5),
    QuantFactorBacktest("Multi-Factor Core Composite", 17.4, 1.58, 15.6, 52.0, 66.8, 11.2)
  )

  // Live Engine State
  private val _isLiveStreaming = MutableStateFlow(true)
  val isLiveStreaming: StateFlow<Boolean> = _isLiveStreaming.asStateFlow()

  init {
    initializeData()
    startMarketSimulation()
  }

  fun toggleLiveStreaming() {
    _isLiveStreaming.value = !_isLiveStreaming.value
  }

  fun selectSecurity(ticker: String) {
    val sec = _securities.value.find { it.ticker.equals(ticker, ignoreCase = true) }
      ?: _securities.value.firstOrNull()
    _selectedSecurity.value = sec
    if (sec != null) {
      regenerateOrderBook(sec)
    }
  }

  private fun initializeData() {
    val initialSecurities = createInitialSecurities()
    _securities.value = initialSecurities
    _selectedSecurity.value = initialSecurities.firstOrNull()

    _indices.value = createInitialIndices()
    _news.value = createInitialNews()
    _portfolioHoldings.value = createInitialPortfolio(initialSecurities)
    _stressScenarios.value = createInitialStressScenarios()

    _selectedSecurity.value?.let { regenerateOrderBook(it) }
  }

  private fun startMarketSimulation() {
    coroutineScope.launch {
      while (isActive) {
        delay(900)
        if (!_isLiveStreaming.value) continue

        // Update random securities with realistic micro-ticks
        val currentList = _securities.value
        if (currentList.isEmpty()) continue

        val updatedList = currentList.map { sec ->
          if (Random.nextDouble() < 0.45) {
            val deltaPct = (Random.nextDouble() - 0.48) * 0.0035 // ~0.05% to 0.15%
            val newPrice = (sec.price * (1.0 + deltaPct)).coerceAtLeast(1.0)
            val roundedPrice = (newPrice * 100.0).roundToInt() / 100.0
            val priceDiff = roundedPrice - sec.prevClose
            val changePct = (priceDiff / sec.prevClose) * 100.0
            val newVolume = sec.volume + Random.nextLong(100, 3500)
            val newHigh = maxOf(sec.high, roundedPrice)
            val newLow = minOf(sec.low, roundedPrice)

            // Adjust bid / ask around new price
            val spread = (roundedPrice * 0.0003).coerceAtLeast(0.01)
            val newBid = (roundedPrice - spread / 2.0 * 100.0).roundToInt() / 100.0
            val newAsk = (roundedPrice + spread / 2.0 * 100.0).roundToInt() / 100.0

            sec.copy(
              price = roundedPrice,
              change = (priceDiff * 100.0).roundToInt() / 100.0,
              changePct = (changePct * 100.0).roundToInt() / 100.0,
              bid = newBid,
              ask = newAsk,
              high = newHigh,
              low = newLow,
              volume = newVolume,
              vwap = ((sec.vwap * 0.95) + (roundedPrice * 0.05) * 100.0).roundToInt() / 100.0
            )
          } else {
            sec
          }
        }

        _securities.value = updatedList

        // If selected security was updated, update it and orderbook
        val sel = _selectedSecurity.value
        if (sel != null) {
          val updatedSel = updatedList.find { it.securityId == sel.securityId } ?: sel
          _selectedSecurity.value = updatedSel

          // Generate realistic level-2 order book updates
          regenerateOrderBook(updatedSel)

          // Add a trade to the tape
          val side = if (Random.nextBoolean()) OrderSide.BUY else OrderSide.SELL
          val tradeQty = Random.nextInt(10, 400) * 10
          val tradeTime = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US).format(java.util.Date())
          val newTrade = TradeTapeItem(
            tradeId = "TRD-${System.currentTimeMillis() % 100000}",
            time = tradeTime,
            price = updatedSel.price,
            quantity = tradeQty,
            side = side,
            venue = updatedSel.mic
          )
          val existingTape = _tradesTape.value.take(19)
          _tradesTape.value = listOf(newTrade) + existingTape
        }

        // Ticker updates for indices
        _indices.value = _indices.value.map { idx ->
          if (Random.nextDouble() < 0.3) {
            val idxDelta = (Random.nextDouble() - 0.49) * 0.001
            val newLevel = idx.level * (1.0 + idxDelta)
            val rounded = (newLevel * 100.0).roundToInt() / 100.0
            val chg = (rounded - (idx.level - idx.change) * 100.0).roundToInt() / 100.0
            val pct = (chg / (rounded - chg)) * 100.0
            idx.copy(level = rounded, change = chg, changePct = (pct * 100.0).roundToInt() / 100.0)
          } else {
            idx
          }
        }
      }
    }
  }

  private fun regenerateOrderBook(sec: Security) {
    val mid = sec.price
    val spreadCents = (mid * 0.0003).coerceAtLeast(0.02)
    val tick = 0.01

    val bids = mutableListOf<OrderBookLevel>()
    var cumBidQty = 0
    for (i in 1..10) {
      val price = ((mid - (spreadCents / 2.0) - (i - 1) * tick * (1 + i * 0.15)) * 100.0).roundToInt() / 100.0
      val qty = Random.nextInt(20, 150) * 100
      cumBidQty += qty
      bids.add(OrderBookLevel(price, qty, Random.nextInt(3, 24), cumBidQty, OrderSide.BUY))
    }

    val asks = mutableListOf<OrderBookLevel>()
    var cumAskQty = 0
    for (i in 1..10) {
      val price = ((mid + (spreadCents / 2.0) + (i - 1) * tick * (1 + i * 0.15)) * 100.0).roundToInt() / 100.0
      val qty = Random.nextInt(20, 150) * 100
      cumAskQty += qty
      asks.add(OrderBookLevel(price, qty, Random.nextInt(3, 24), cumAskQty, OrderSide.SELL))
    }

    val bestBid = bids.first().price
    val bestAsk = asks.first().price
    val spread = ((bestAsk - bestBid) * 100.0).roundToInt() / 100.0
    val spreadBps = ((spread / mid) * 10000.0 * 10.0).roundToInt() / 10.0

    // Auction Imbalance calculations
    val indicativeAuctionPrice = ((mid + (Random.nextDouble() - 0.5) * 0.1) * 100.0).roundToInt() / 100.0
    val imbalanceSide = if (cumBidQty > cumAskQty) OrderSide.BUY else OrderSide.SELL
    val indicativeImbalanceQty = abs(cumBidQty - cumAskQty) / 4

    _orderBook.value = OrderBook(
      securityId = sec.securityId,
      ticker = sec.ticker,
      bids = bids,
      asks = asks,
      lastPrice = mid,
      spread = spread,
      spreadBps = spreadBps,
      indicativeAuctionPrice = indicativeAuctionPrice,
      indicativeImbalanceQty = indicativeImbalanceQty,
      imbalanceSide = imbalanceSide,
      auctionStatus = if (sec.status == "OPEN") "CONTINUOUS_TRADING" else "CROSSING_AUCTION"
    )
  }

  // Calculate DCF dynamically
  fun calculateDcf(
    ticker: String,
    waccPct: Double,
    terminalGrowthPct: Double,
    fcfGrowth1_5Pct: Double
  ): ValuationDCF {
    val sec = _securities.value.find { it.ticker.equals(ticker, ignoreCase = true) }
      ?: _securities.value.first()
    val shares = sec.sharesOutstanding // in millions
    // Baseline FCF in millions
    val baseFcf = (sec.turnover * 0.28).coerceAtLeast(1800.0)

    val r = waccPct / 100.0
    val gTerminal = terminalGrowthPct / 100.0
    val g1 = fcfGrowth1_5Pct / 100.0

    var pvFcfSum = 0.0
    var projectedFcf = baseFcf
    for (year in 1..5) {
      projectedFcf *= (1.0 + g1)
      val discountFactor = (1.0 + r).pow(year)
      pvFcfSum += (projectedFcf / discountFactor)
    }

    // Terminal value at year 5
    val fcfYear6 = projectedFcf * (1.0 + gTerminal)
    val terminalValue = if (r > gTerminal) fcfYear6 / (r - gTerminal) else fcfYear6 / 0.05
    val pvTerminalValue = terminalValue / (1.0 + r).pow(5)

    val enterpriseValue = pvFcfSum + pvTerminalValue
    // Equity Value ~ Enterprise Value (assuming modest net debt adjustment)
    val equityValue = enterpriseValue * 1.05
    val intrinsicPerShare = (equityValue / shares * 100.0).roundToInt() / 100.0
    val marginOfSafety = (((intrinsicPerShare - sec.price) / intrinsicPerShare) * 100.0 * 10.0).roundToInt() / 10.0

    return ValuationDCF(
      ticker = sec.ticker,
      currentPrice = sec.price,
      waccPct = waccPct,
      terminalGrowthPct = terminalGrowthPct,
      fcfBase = baseFcf,
      growthRateYear1_5 = fcfGrowth1_5Pct,
      intrinsicValue = intrinsicPerShare,
      marginOfSafetyPct = marginOfSafety,
      impliedMultipleEvEbitda = ((enterpriseValue / (baseFcf * 1.4)) * 10.0).roundToInt() / 10.0
    )
  }

  fun getFinancialPeriods(ticker: String): List<FinancialStatementPeriod> {
    return listOf(
      FinancialStatementPeriod(
        period = "2024-FY",
        asReportedDate = "2024-11-01",
        vintageDate = "2024-11-01",
        revenue = 391.0,
        grossProfit = 180.7,
        ebitda = 134.2,
        ebit = 123.2,
        operatingIncome = 123.2,
        netIncome = 93.7,
        eps = 6.08,
        dps = 0.98,
        fcf = 108.8,
        capex = 9.4,
        cash = 65.2,
        totalDebt = 106.6,
        netDebt = 41.4,
        totalAssets = 364.9,
        totalLiabilities = 308.0,
        totalEquity = 56.9
      ),
      FinancialStatementPeriod(
        period = "2023-FY",
        asReportedDate = "2023-11-03",
        vintageDate = "2023-11-03",
        revenue = 383.3,
        grossProfit = 169.1,
        ebitda = 125.8,
        ebit = 114.3,
        operatingIncome = 114.3,
        netIncome = 97.0,
        eps = 6.13,
        dps = 0.95,
        fcf = 99.6,
        capex = 10.9,
        cash = 61.5,
        totalDebt = 111.1,
        netDebt = 49.6,
        totalAssets = 352.6,
        totalLiabilities = 290.4,
        totalEquity = 62.1
      ),
      FinancialStatementPeriod(
        period = "2022-FY",
        asReportedDate = "2022-10-28",
        vintageDate = "2022-10-28",
        revenue = 394.3,
        grossProfit = 170.8,
        ebitda = 130.5,
        ebit = 119.4,
        operatingIncome = 119.4,
        netIncome = 99.8,
        eps = 6.11,
        dps = 0.91,
        fcf = 111.4,
        capex = 10.7,
        cash = 48.3,
        totalDebt = 120.1,
        netDebt = 71.8,
        totalAssets = 352.8,
        totalLiabilities = 302.1,
        totalEquity = 50.7
      )
    )
  }

  fun getConsensus(ticker: String): AnalystConsensus {
    val sec = _securities.value.find { it.ticker.equals(ticker, ignoreCase = true) }
      ?: _securities.value.first()
    val targetMean = (sec.price * 1.15 * 100.0).roundToInt() / 100.0
    val targetHigh = (sec.price * 1.35 * 100.0).roundToInt() / 100.0
    val targetLow = (sec.price * 0.92 * 100.0).roundToInt() / 100.0
    return AnalystConsensus(
      ticker = sec.ticker,
      targetPriceMean = targetMean,
      targetPriceHigh = targetHigh,
      targetPriceLow = targetLow,
      currentPrice = sec.price,
      buyCount = 38,
      holdCount = 9,
      sellCount = 2,
      epsConsensusNextFy = 7.15,
      revConsensusNextFy = 412.5,
      revisionMomentum30dPct = 4.8,
      surprises = listOf(
        EarningsSurprise("Q4 2024", 1.64, 1.60, 2.5, 94.9, 94.5, 0.4, 1.8),
        EarningsSurprise("Q3 2024", 1.40, 1.35, 3.7, 85.8, 84.4, 1.6, 2.4),
        EarningsSurprise("Q2 2024", 1.53, 1.50, 2.0, 90.7, 90.0, 0.8, -0.9),
        EarningsSurprise("Q1 2024", 2.18, 2.10, 3.8, 119.6, 117.9, 1.4, 3.1)
      )
    )
  }

  // Markets AI Query Processor with full structured audit trail
  fun executeAiQuery(query: String): AiResearchAudit {
    val upper = query.uppercase()
    return when {
      upper.contains("NVDA") || upper.contains("NVIDIA") || upper.contains("SEMICONDUCTOR") -> {
        AiResearchAudit(
          query = query,
          structuredAnswer = "NVDA outperformance (+3.2% session, +148% YTD) is driven by hyperscaler CapEx revisions (MSFT, AMZN, GOOGL guided FY25 AI infrastructure aggregate $215B, +24% YoY). Order book shows institutional bid depth ratio 1.82x vs ask depth, with short interest near 1.2% float.",
          dataPointsUsed = listOf("NVDA Level 2 Order Book", "Hyperscaler Q3 10-Q Filings", "GICS 4520 Semiconductor Breadth", "CFTC Institutional Flow Tape"),
          timeHorizon = "T-0 Continuous Trading + FY25 Consensus",
          dataProvenance = "EXCHANGE_OBSERVED + SEC_FILINGS + MODELLED_CONSENSUS",
          calculationMethod = "Order Flow Microstructure Imbalance & CapEx Regression",
          confidenceScore = 0.94,
          keyInferences = listOf(
            "Order book uncrossing showed 1.4M buy imbalance into European close",
            "Consensus forward EPS revision momentum is +8.6% over past 30 days",
            "Beta to Nasdaq-100 stands at 1.72 with daily VaR95 at 3.18%"
          )
        )
      }
      upper.contains("AAPL") || upper.contains("APPLE") -> {
        AiResearchAudit(
          query = query,
          structuredAnswer = "AAPL trading rangebound ($232.40, +0.65%). Gross margin expanded to 46.2% on Services revenue mix (now 24.8% of total). Free Cash Flow Yield is 3.78% with annual share repurchase run-rate of $100B providing baseline liquidity absorption.",
          dataPointsUsed = listOf("AAPL As-Reported 10-K Cash Flow", "Services Segment Restatement", "L2 Order Book Spread (0.4 bps)", "Consensus EPS Revision Index"),
          timeHorizon = "LTM + FY25/26 Street Estimates",
          dataProvenance = "OFFICIAL_COMPANY_REPORTS + REGULATORY_EDGAR",
          calculationMethod = "Point-in-Time Statement Ratio & Buyback Absorption Model",
          confidenceScore = 0.96,
          keyInferences = listOf(
            "Intrinsic DCF fair value calculated at $245.80 (WACC 8.5%, Terminal Growth 3.0%)",
            "Dividend payout ratio remains low at 16.1% due to buyback prioritisation",
            "Short % of Float at 0.78% (institutional borrow utilization < 5%)"
          )
        )
      }
      upper.contains("RATES") || upper.contains("100BP") || upper.contains("STRESS") -> {
        AiResearchAudit(
          query = query,
          structuredAnswer = "A +100bp parallel upward shift in global yield curves would depress equity multiples via WACC expansion. Estimated mandate portfolio impact: -5.4% NAV ($5.4M drawdown). High-duration tech assets (NVDA, TSLA) absorb highest hit (-7.2%), partially hedged by Financials (JPM +2.8%).",
          dataPointsUsed = listOf("US 10Y Benchmark Curve", "Constituent Cash Flow Durations", "Barra GEM3 Factor Betas", "Sector Rate Sensitivity Matrix"),
          timeHorizon = "Instantaneous Shock Analysis (T+0)",
          dataProvenance = "MODELLED_STRESS_TWIN (Risk-Core Engine)",
          calculationMethod = "Multi-Factor Covariance Factor Shock Decomposition",
          confidenceScore = 0.91,
          keyInferences = listOf(
            "Portfolio effective duration is 5.4 years",
            "Value factor exposure expands while Growth/Quality absorbs valuation compression",
            "Recommended hedge: Short E-mini Nasdaq futures or expand Energy/Financials weighting by 4.5%"
          )
        )
      }
      else -> {
        AiResearchAudit(
          query = query,
          structuredAnswer = "Cross-asset multi-venue scan across 15 global exchanges confirms global equity breadth positive (Advance/Decline 2.34x). Market Regime classified as BULL_MOMENTUM with 78% probability. Volatility compression across VIX (14.2) and Nikkei Volatility Index (18.6).",
          dataPointsUsed = listOf("Global 20 Exchange Ticker Feeds", "McClellan Oscillator", "Cross-Asset FX & Commodity Vectors", "Consensus Revision Breadth"),
          timeHorizon = "Global Multi-Timeframe T-0 to 1Y",
          dataProvenance = "FEDERATED_GLOBAL_MARKET_STREAM + SYNTHETIC_TWIN",
          calculationMethod = "Markov Regime Switching + Institutional Breadth Vector",
          confidenceScore = 0.89,
          keyInferences = listOf(
            "71.8% of global large-cap universe trading above 50-day moving average",
            "Highest factor dispersion observed in Momentum vs Low-Vol (+9.4% L/S spread)",
            "Institutional liquidity conditions: Bid-ask spreads normal across NY and European venues"
          )
        )
      }
    }
  }

  // --- Initial Data Seeds ---

  private fun createInitialSecurities(): List<Security> = listOf(
    Security(
      securityId = "SEC-US-AAPL",
      issuerId = "COMP-AAPL",
      exchange = "NASDAQ",
      mic = "XNAS",
      ticker = "AAPL",
      isin = "US0378331005",
      cusip = "037833100",
      sedol = "2046251",
      figi = "BBG000B9XRY4",
      localCode = "AAPL",
      currency = "USD",
      country = "United States",
      sector = "Technology",
      industry = "Consumer Electronics",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 15204.0,
      freeFloatPct = 99.2,
      status = "OPEN",
      displayName = "Apple Inc.",
      price = 232.40,
      change = 1.50,
      changePct = 0.65,
      bid = 232.38,
      bidSize = 1200,
      ask = 232.42,
      askSize = 800,
      open = 231.10,
      high = 233.15,
      low = 230.85,
      prevClose = 230.90,
      volume = 48512300,
      turnover = 11270.0,
      vwap = 232.18,
      tradeCount = 421000,
      high52w = 237.23,
      low52w = 164.08,
      pe = 34.2,
      forwardPe = 29.8,
      pb = 45.1,
      evEbitda = 24.6,
      evSales = 8.1,
      fcfYieldPct = 3.78,
      dividendYieldPct = 0.43,
      roePct = 148.2,
      roicPct = 56.4,
      grossMarginPct = 46.2,
      operatingMarginPct = 31.5,
      netMarginPct = 24.0,
      beta = 1.05,
      var95DailyPct = 1.85,
      sharpe = 1.62,
      maxDrawdownPct = 15.2,
      factorValue = -0.85,
      factorMomentum = 1.12,
      factorQuality = 2.45,
      factorLowVol = 0.65
    ),
    Security(
      securityId = "SEC-US-MSFT",
      issuerId = "COMP-MSFT",
      exchange = "NASDAQ",
      mic = "XNAS",
      ticker = "MSFT",
      isin = "US5949181045",
      cusip = "594918104",
      sedol = "2588173",
      figi = "BBG000BPH459",
      localCode = "MSFT",
      currency = "USD",
      country = "United States",
      sector = "Technology",
      industry = "Software - Infrastructure",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 7430.0,
      freeFloatPct = 98.8,
      status = "OPEN",
      displayName = "Microsoft Corporation",
      price = 428.15,
      change = 3.85,
      changePct = 0.91,
      bid = 428.10,
      bidSize = 900,
      ask = 428.20,
      askSize = 1100,
      open = 425.00,
      high = 429.80,
      low = 424.60,
      prevClose = 424.30,
      volume = 19480100,
      turnover = 8330.0,
      vwap = 427.65,
      tradeCount = 312000,
      high52w = 468.35,
      low52w = 366.50,
      pe = 35.8,
      forwardPe = 31.2,
      pb = 11.2,
      evEbitda = 23.4,
      evSales = 12.8,
      fcfYieldPct = 2.95,
      dividendYieldPct = 0.75,
      roePct = 38.6,
      roicPct = 28.4,
      grossMarginPct = 69.8,
      operatingMarginPct = 44.6,
      netMarginPct = 35.8,
      beta = 1.12,
      var95DailyPct = 1.92,
      sharpe = 1.48,
      maxDrawdownPct = 14.8,
      factorValue = -0.92,
      factorMomentum = 0.95,
      factorQuality = 2.68,
      factorLowVol = 0.58
    ),
    Security(
      securityId = "SEC-US-NVDA",
      issuerId = "COMP-NVDA",
      exchange = "NASDAQ",
      mic = "XNAS",
      ticker = "NVDA",
      isin = "US67066G1040",
      cusip = "67066G104",
      sedol = "2379504",
      figi = "BBG000BBJQV0",
      localCode = "NVDA",
      currency = "USD",
      country = "United States",
      sector = "Technology",
      industry = "Semiconductors",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 24500.0,
      freeFloatPct = 95.8,
      status = "OPEN",
      displayName = "NVIDIA Corporation",
      price = 138.25,
      change = 4.30,
      changePct = 3.21,
      bid = 138.22,
      bidSize = 4200,
      ask = 138.28,
      askSize = 3800,
      open = 135.10,
      high = 139.00,
      low = 134.80,
      prevClose = 133.95,
      volume = 72140500,
      turnover = 9920.0,
      vwap = 137.40,
      tradeCount = 980000,
      high52w = 140.76,
      low52w = 45.10,
      pe = 52.4,
      forwardPe = 38.2,
      pb = 41.5,
      evEbitda = 44.8,
      evSales = 28.4,
      fcfYieldPct = 2.45,
      dividendYieldPct = 0.03,
      roePct = 115.0,
      roicPct = 88.5,
      grossMarginPct = 75.3,
      operatingMarginPct = 62.1,
      netMarginPct = 55.6,
      beta = 1.72,
      var95DailyPct = 3.18,
      sharpe = 2.85,
      maxDrawdownPct = 26.5,
      factorValue = -1.65,
      factorMomentum = 2.84,
      factorQuality = 2.92,
      factorLowVol = -1.45
    ),
    Security(
      securityId = "SEC-US-AMZN",
      issuerId = "COMP-AMZN",
      exchange = "NASDAQ",
      mic = "XNAS",
      ticker = "AMZN",
      isin = "US0231351067",
      cusip = "023135106",
      sedol = "2000019",
      figi = "BBG000BVPV84",
      localCode = "AMZN",
      currency = "USD",
      country = "United States",
      sector = "Consumer Cyclical",
      industry = "Internet Retail",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 10450.0,
      freeFloatPct = 88.5,
      status = "OPEN",
      displayName = "Amazon.com Inc.",
      price = 189.70,
      change = 2.10,
      changePct = 1.12,
      bid = 189.65,
      bidSize = 1500,
      ask = 189.75,
      askSize = 1200,
      open = 188.00,
      high = 190.50,
      low = 187.60,
      prevClose = 187.60,
      volume = 34500000,
      turnover = 6540.0,
      vwap = 189.20,
      tradeCount = 280000,
      high52w = 201.20,
      low52w = 118.35,
      pe = 44.2,
      forwardPe = 34.0,
      pb = 8.4,
      evEbitda = 19.8,
      evSales = 3.2,
      fcfYieldPct = 3.25,
      dividendYieldPct = 0.0,
      roePct = 21.4,
      roicPct = 15.8,
      grossMarginPct = 48.2,
      operatingMarginPct = 9.8,
      netMarginPct = 7.4,
      beta = 1.25,
      var95DailyPct = 2.15,
      sharpe = 1.55,
      maxDrawdownPct = 18.4,
      factorValue = -0.45,
      factorMomentum = 1.35,
      factorQuality = 1.72,
      factorLowVol = 0.12
    ),
    Security(
      securityId = "SEC-US-JPM",
      issuerId = "COMP-JPM",
      exchange = "NYSE",
      mic = "XNYS",
      ticker = "JPM",
      isin = "US46625H1005",
      cusip = "46625H100",
      sedol = "2190385",
      figi = "BBG000GZQ834",
      localCode = "JPM",
      currency = "USD",
      country = "United States",
      sector = "Financials",
      industry = "Diversified Banking",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 2860.0,
      freeFloatPct = 99.1,
      status = "OPEN",
      displayName = "JPMorgan Chase & Co.",
      price = 224.80,
      change = 1.20,
      changePct = 0.54,
      bid = 224.75,
      bidSize = 800,
      ask = 224.85,
      askSize = 900,
      open = 223.50,
      high = 225.40,
      low = 223.10,
      prevClose = 223.60,
      volume = 8240000,
      turnover = 1850.0,
      vwap = 224.30,
      tradeCount = 145000,
      high52w = 228.10,
      low52w = 142.20,
      pe = 12.8,
      forwardPe = 12.1,
      pb = 1.85,
      evEbitda = 8.4,
      evSales = 3.6,
      fcfYieldPct = 6.40,
      dividendYieldPct = 2.15,
      roePct = 17.5,
      roicPct = 14.2,
      grossMarginPct = 62.0,
      operatingMarginPct = 42.1,
      netMarginPct = 34.2,
      beta = 1.02,
      var95DailyPct = 1.55,
      sharpe = 1.84,
      maxDrawdownPct = 12.1,
      factorValue = 1.45,
      factorMomentum = 1.62,
      factorQuality = 1.88,
      factorLowVol = 0.94
    ),
    Security(
      securityId = "SEC-EU-ASML",
      issuerId = "COMP-ASML",
      exchange = "Euronext Amsterdam",
      mic = "XAMS",
      ticker = "ASML",
      isin = "NL0010273215",
      cusip = "N07059210",
      sedol = "B929F49",
      figi = "BBG000D9DW43",
      localCode = "ASML",
      currency = "EUR",
      country = "Netherlands",
      sector = "Technology",
      industry = "Semiconductor Equipment",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 392.0,
      freeFloatPct = 97.4,
      status = "OPEN",
      displayName = "ASML Holding N.V.",
      price = 788.50,
      change = -8.20,
      changePct = -1.03,
      bid = 788.20,
      bidSize = 350,
      ask = 788.80,
      askSize = 420,
      open = 794.00,
      high = 797.50,
      low = 785.00,
      prevClose = 796.70,
      volume = 920000,
      turnover = 725.0,
      vwap = 790.20,
      tradeCount = 42000,
      high52w = 1021.80,
      low52w = 540.00,
      pe = 41.2,
      forwardPe = 32.5,
      pb = 18.2,
      evEbitda = 31.0,
      evSales = 11.4,
      fcfYieldPct = 2.80,
      dividendYieldPct = 0.82,
      roePct = 52.4,
      roicPct = 44.1,
      grossMarginPct = 51.3,
      operatingMarginPct = 32.8,
      netMarginPct = 27.2,
      beta = 1.45,
      var95DailyPct = 2.65,
      sharpe = 1.35,
      maxDrawdownPct = 28.2,
      factorValue = -1.15,
      factorMomentum = 0.45,
      factorQuality = 2.82,
      factorLowVol = -0.85
    ),
    Security(
      securityId = "SEC-UK-AZN",
      issuerId = "COMP-AZN",
      exchange = "LSE",
      mic = "XLON",
      ticker = "AZN",
      isin = "GB0009895292",
      cusip = "046353108",
      sedol = "0989529",
      figi = "BBG000BNTGQ7",
      localCode = "AZN",
      currency = "GBP",
      country = "United Kingdom",
      sector = "Healthcare",
      industry = "Pharmaceuticals",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 1550.0,
      freeFloatPct = 98.2,
      status = "OPEN",
      displayName = "AstraZeneca PLC",
      price = 118.40,
      change = 0.90,
      changePct = 0.77,
      bid = 118.35,
      bidSize = 500,
      ask = 118.45,
      askSize = 650,
      open = 117.80,
      high = 119.10,
      low = 117.50,
      prevClose = 117.50,
      volume = 2410000,
      turnover = 285.0,
      vwap = 118.25,
      tradeCount = 38000,
      high52w = 134.20,
      low52w = 97.40,
      pe = 31.4,
      forwardPe = 17.8,
      pb = 4.6,
      evEbitda = 16.5,
      evSales = 4.2,
      fcfYieldPct = 4.20,
      dividendYieldPct = 2.25,
      roePct = 16.8,
      roicPct = 12.4,
      grossMarginPct = 81.2,
      operatingMarginPct = 26.5,
      netMarginPct = 14.8,
      beta = 0.62,
      var95DailyPct = 1.25,
      sharpe = 1.42,
      maxDrawdownPct = 14.2,
      factorValue = 0.25,
      factorMomentum = 0.88,
      factorQuality = 1.95,
      factorLowVol = 1.72
    ),
    Security(
      securityId = "SEC-JP-7203",
      issuerId = "COMP-7203",
      exchange = "JPX / Tokyo Stock Exchange",
      mic = "XTKS",
      ticker = "7203",
      isin = "JP3633400001",
      cusip = "892331100",
      sedol = "6900643",
      figi = "BBG000BMHYD2",
      localCode = "7203",
      currency = "JPY",
      country = "Japan",
      sector = "Consumer Cyclical",
      industry = "Automobiles",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 13580.0,
      freeFloatPct = 82.4,
      status = "CLOSED",
      displayName = "Toyota Motor Corp.",
      price = 2845.0,
      change = 32.0,
      changePct = 1.14,
      bid = 2844.0,
      bidSize = 18000,
      ask = 2846.0,
      askSize = 14000,
      open = 2820.0,
      high = 2858.0,
      low = 2815.0,
      prevClose = 2813.0,
      volume = 24800000,
      turnover = 70500.0,
      vwap = 2838.0,
      tradeCount = 94000,
      high52w = 3870.0,
      low52w = 2320.0,
      pe = 7.9,
      forwardPe = 8.4,
      pb = 0.98,
      evEbitda = 6.2,
      evSales = 0.85,
      fcfYieldPct = 8.15,
      dividendYieldPct = 3.12,
      roePct = 15.2,
      roicPct = 9.8,
      grossMarginPct = 21.4,
      operatingMarginPct = 11.8,
      netMarginPct = 10.2,
      beta = 0.88,
      var95DailyPct = 1.74,
      sharpe = 1.12,
      maxDrawdownPct = 22.0,
      factorValue = 2.45,
      factorMomentum = 0.65,
      factorQuality = 1.25,
      factorLowVol = 0.82
    ),
    Security(
      securityId = "SEC-HK-9988",
      issuerId = "COMP-9988",
      exchange = "HKEX",
      mic = "XHKG",
      ticker = "9988",
      isin = "KYG017191142",
      cusip = "G01719114",
      sedol = "BK63NG9",
      figi = "BBG00Q8GZ1R9",
      localCode = "9988",
      currency = "HKD",
      country = "China / Hong Kong",
      sector = "Technology",
      industry = "Internet & E-Commerce",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 19740.0,
      freeFloatPct = 86.5,
      status = "CLOSED",
      displayName = "Alibaba Group Holding",
      price = 98.40,
      change = 3.80,
      changePct = 4.02,
      bid = 98.35,
      bidSize = 48000,
      ask = 98.45,
      askSize = 35000,
      open = 95.80,
      high = 99.20,
      low = 95.20,
      prevClose = 94.60,
      volume = 88400000,
      turnover = 8620.0,
      vwap = 97.60,
      tradeCount = 186000,
      high52w = 117.50,
      low52w = 64.60,
      pe = 14.2,
      forwardPe = 10.8,
      pb = 1.42,
      evEbitda = 7.8,
      evSales = 1.8,
      fcfYieldPct = 9.80,
      dividendYieldPct = 2.10,
      roePct = 9.8,
      roicPct = 8.4,
      grossMarginPct = 37.8,
      operatingMarginPct = 15.2,
      netMarginPct = 7.6,
      beta = 1.35,
      var95DailyPct = 2.85,
      sharpe = 0.88,
      maxDrawdownPct = 38.5,
      factorValue = 2.10,
      factorMomentum = 1.82,
      factorQuality = 1.15,
      factorLowVol = -1.10
    ),
    Security(
      securityId = "SEC-IN-RELIANCE",
      issuerId = "COMP-RELIANCE",
      exchange = "NSE India",
      mic = "XNSE",
      ticker = "RELIANCE",
      isin = "INE002A01018",
      cusip = "759470107",
      sedol = "6724647",
      figi = "BBG000BWT1W7",
      localCode = "RELIANCE",
      currency = "INR",
      country = "India",
      sector = "Energy & Conglomerate",
      industry = "Integrated Oil & Telecom",
      securityType = SecurityType.COMMON_STOCK,
      sharesOutstanding = 6760.0,
      freeFloatPct = 49.8,
      status = "CLOSED",
      displayName = "Reliance Industries Ltd",
      price = 2748.5,
      change = 18.0,
      changePct = 0.66,
      bid = 2748.0,
      bidSize = 12000,
      ask = 2749.0,
      askSize = 10500,
      open = 2735.0,
      high = 2760.0,
      low = 2730.0,
      prevClose = 2730.5,
      volume = 5420000,
      turnover = 14850.0,
      vwap = 2744.0,
      tradeCount = 210000,
      high52w = 3217.9,
      low52w = 2220.0,
      pe = 24.8,
      forwardPe = 21.2,
      pb = 2.35,
      evEbitda = 12.8,
      evSales = 2.4,
      fcfYieldPct = 3.90,
      dividendYieldPct = 0.40,
      roePct = 9.8,
      roicPct = 8.5,
      grossMarginPct = 31.4,
      operatingMarginPct = 16.5,
      netMarginPct = 7.8,
      beta = 0.95,
      var95DailyPct = 1.62,
      sharpe = 1.45,
      maxDrawdownPct = 18.2,
      factorValue = 0.85,
      factorMomentum = 0.72,
      factorQuality = 1.45,
      factorLowVol = 0.62
    )
  )

  private fun createInitialExchanges(): List<ExchangeVenue> = listOf(
    ExchangeVenue("XNAS", "NASDAQ Stock Market", "XNAS", "United States", "New York", "America/New_York", MarketSessionStatus.OPEN, "09:30-16:00 EST", "USD", "Sub-penny rule Reg NMS", "09:30 / 16:00 Cross", 3800),
    ExchangeVenue("XNYS", "New York Stock Exchange", "XNYS", "United States", "New York", "America/New_York", MarketSessionStatus.OPEN, "09:30-16:00 EST", "USD", "Reg NMS Tiered tick", "DMM Closing Auction 16:00", 2400),
    ExchangeVenue("XLON", "London Stock Exchange", "XLON", "United Kingdom", "London", "Europe/London", MarketSessionStatus.OPEN, "08:00-16:30 GMT", "GBP", "SETS dynamic tick schedule", "SETS Opening 07:50 / Closing 16:30", 1950),
    ExchangeVenue("XAMS", "Euronext Amsterdam", "XAMS", "Netherlands", "Amsterdam", "Europe/Amsterdam", MarketSessionStatus.OPEN, "09:00-17:30 CET", "EUR", "Euronext harmonised tick size", "Closing TAL 17:35", 1400),
    ExchangeVenue("XETR", "Deutsche Börse XETRA", "XETR", "Germany", "Frankfurt", "Europe/Berlin", MarketSessionStatus.OPEN, "09:00-17:30 CET", "EUR", "MiFID II Liquidity Bands", "Intraday Auction 13:00 / Closing 17:30", 1600),
    ExchangeVenue("XTKS", "Tokyo Stock Exchange", "XTKS", "Japan", "Tokyo", "Asia/Tokyo", MarketSessionStatus.CLOSED, "09:00-15:30 JST", "JPY", "Arrowhead Tick Band 0.1-50 JPY", "Itayose Opening & Closing", 3900),
    ExchangeVenue("XHKG", "Hong Kong Exchanges & Clearing", "XHKG", "Hong Kong", "Hong Kong", "Asia/Hong_Kong", MarketSessionStatus.CLOSED, "09:30-16:00 HKT", "HKD", "HKEX Static Spread Table", "CAS Closing Auction 16:08", 2600),
    ExchangeVenue("XSHG", "Shanghai Stock Exchange", "XSHG", "China", "Shanghai", "Asia/Shanghai", MarketSessionStatus.CLOSED, "09:30-15:00 CST", "CNY", "0.01 CNY Uniform Tick / 10% Limit", "Call Auction 09:25 & 14:57", 2200),
    ExchangeVenue("XNSE", "National Stock Exchange of India", "XNSE", "India", "Mumbai", "Asia/Kolkata", MarketSessionStatus.CLOSED, "09:15-15:30 IST", "INR", "0.05 INR Base Tick", "Pre-Open Auction 09:00-09:15", 2100),
    ExchangeVenue("XASX", "Australian Securities Exchange", "XASX", "Australia", "Sydney", "Australia/Sydney", MarketSessionStatus.CLOSED, "10:00-16:00 AEST", "AUD", "ASX Trade Tick Matrix", "Batch Single Price Auction", 2200),
    ExchangeVenue("BVMF", "B3 - Brasil Bolsa Balcão", "BVMF", "Brazil", "São Paulo", "America/Sao_Paulo", MarketSessionStatus.CLOSED, "10:00-17:00 BRT", "BRL", "0.01 BRL Tick", "Pre-market Call & Closing Call", 450)
  )

  private fun createInitialIndices(): List<GlobalIndex> = listOf(
    GlobalIndex("IDX-SPX", "S&P 500", "S&P 500 Index", "North America", "USD", 5815.26, 42.10, 0.73, 503, 8912.4),
    GlobalIndex("IDX-NDX", "NASDAQ 100", "Nasdaq 100", "North America", "USD", 20285.40, 195.80, 0.98, 101, 4120.1),
    GlobalIndex("IDX-UKX", "FTSE 100", "FTSE 100 Index", "United Kingdom", "GBP", 8243.60, 28.40, 0.35, 100, 1140.2),
    GlobalIndex("IDX-DAX", "DAX 40", "Deutscher Aktienindex", "Europe", "EUR", 19412.50, 84.10, 0.44, 40, 680.5),
    GlobalIndex("IDX-N225", "NIKKEI 225", "Nikkei 225 Average", "Japan", "JPY", 39605.80, 218.40, 0.55, 225, 28.4),
    GlobalIndex("IDX-HSI", "HANG SENG", "Hang Seng Index", "Hong Kong", "HKD", 20638.70, 614.20, 3.07, 82, 342.1),
    GlobalIndex("IDX-CSI300", "CSI 300", "China CSI 300", "China", "CNY", 3985.40, 82.50, 2.11, 300, 780.2),
    GlobalIndex("IDX-NIFTY", "NIFTY 50", "NSE Nifty 50", "India", "INR", 24964.20, 122.80, 0.50, 50, 215.0),
    GlobalIndex("IDX-AS51", "ASX 200", "S&P/ASX 200", "Australia", "AUD", 8284.10, 15.60, 0.19, 200, 480.9),
    GlobalIndex("IDX-IBOV", "IBOVESPA", "B3 Ibovespa Index", "Latin America", "BRL", 130352.0, -420.0, -0.32, 86, 1940.0)
  )

  private fun createInitialCorporateActions(): List<CorporateAction> = listOf(
    CorporateAction("CA-2024-001", "AAPL", CorporateActionType.DIVIDEND, "2024-10-31", "2024-11-08", "2024-11-11", "2024-11-14", "1:1", 0.25, "USD", 0.9989),
    CorporateAction("CA-2024-002", "NVDA", CorporateActionType.STOCK_SPLIT, "2024-05-22", "2024-06-07", "2024-06-07", "2024-06-10", "10:1", null, "USD", 0.1000),
    CorporateAction("CA-2024-003", "MSFT", CorporateActionType.DIVIDEND, "2024-09-16", "2024-11-20", "2024-11-21", "2024-12-12", "1:1", 0.83, "USD", 0.9980),
    CorporateAction("CA-2024-004", "AAPL", CorporateActionType.BUYBACK, "2024-05-02", "2024-05-03", "2024-05-03", "2025-05-01", "$110B Authorization", 110000.0, "USD", 1.0000),
    CorporateAction("CA-2024-005", "JPM", CorporateActionType.DIVIDEND, "2024-09-17", "2024-10-04", "2024-10-04", "2024-10-31", "1:1", 1.25, "USD", 0.9944)
  )

  private fun createInitialNews(): List<NewsItem> = listOf(
    NewsItem(
      id = "NW-10492",
      timestamp = "14:48:12",
      headline = "Hyperscalers Boost 2025 AI CapEx Guidance to $215B Aggregate",
      summary = "Quarterly regulatory filings from MSFT, AMZN, and GOOGL confirm accelerated data center deployment and custom silicon procurement.",
      source = "MARKETS WIRE",
      category = "EARNINGS / CAPEX",
      sentimentScore = 0.82,
      sentimentLabel = "BULLISH",
      relevance = 0.98,
      novelty = 0.89,
      tickers = listOf("NVDA", "MSFT", "AMZN", "GOOGL")
    ),
    NewsItem(
      id = "NW-10491",
      timestamp = "14:32:05",
      headline = "ECB Signals Faster Pace of Policy Normalization as Services Inflation Cools",
      summary = "Governing Council commentary points to 25bp deposit facility cut at upcoming Frankfurt meeting. European banking spread compression observed.",
      source = "GLOBAL MACRO DESK",
      category = "MONETARY POLICY",
      sentimentScore = 0.45,
      sentimentLabel = "MODERATE",
      relevance = 0.91,
      novelty = 0.76,
      tickers = listOf("ASML", "MC", "SAP")
    ),
    NewsItem(
      id = "NW-10490",
      timestamp = "13:58:44",
      headline = "Apple Services Margin Expands to Record 46.2% on Cloud & App Store Scale",
      summary = "Granular segment disclosures reveal software and subscription gross profit margins accelerating while hardware mix stabilizes.",
      source = "INSTITUTIONAL EQUITY RESEARCH",
      category = "FUNDAMENTALS",
      sentimentScore = 0.74,
      sentimentLabel = "BULLISH",
      relevance = 0.95,
      novelty = 0.82,
      tickers = listOf("AAPL")
    ),
    NewsItem(
      id = "NW-10489",
      timestamp = "13:15:20",
      headline = "TSE Implements Enhanced Pre-Close Auction Crossing Microstructure Rule",
      summary = "Tokyo Stock Exchange expands 5-minute pre-close order entry window and publishes real-time indicative uncrossing price to curb closing volatility.",
      source = "VENUE MICROSTRUCTURE",
      category = "REGULATION / EXCHANGE",
      sentimentScore = 0.20,
      sentimentLabel = "NEUTRAL",
      relevance = 0.84,
      novelty = 0.94,
      tickers = listOf("7203", "6758")
    ),
    NewsItem(
      id = "NW-10488",
      timestamp = "12:40:11",
      headline = "Hong Kong Equities Volume Surges 42% on Mainland Southbound Stock Connect Inflows",
      summary = "Institutional buying concentrated in technology platforms with net southbound purchases topping HKD 12.4 billion for second consecutive session.",
      source = "FLOW INTELLIGENCE",
      category = "CAPITAL FLOWS",
      sentimentScore = 0.88,
      sentimentLabel = "BULLISH",
      relevance = 0.93,
      novelty = 0.87,
      tickers = listOf("9988", "0700")
    )
  )

  private fun createInitialFilings(): List<RegulatoryFiling> = listOf(
    RegulatoryFiling("FIL-01", "AAPL", "Apple Inc.", "10-K", "2024-11-01", "Annual Report FY2024", "Revenue $391.0B, Services margin 46.2%, FCF $108.8B, Authorized $110B buyback execution."),
    RegulatoryFiling("FIL-02", "MSFT", "Microsoft Corp.", "10-Q", "2024-10-30", "Quarterly Report Q1 FY25", "Cloud revenue $38.9B (+22% YoY), Intelligent Cloud operating income $10.5B, Azure growth 33%."),
    RegulatoryFiling("FIL-03", "NVDA", "NVIDIA Corp.", "10-Q", "2024-08-28", "Quarterly Report Q2 FY25", "Data Center revenue $26.3B (+154% YoY), Gross margin 75.1%, Blackwell architecture initial delivery scheduled."),
    RegulatoryFiling("FIL-04", "AMZN", "Amazon.com Inc.", "10-Q", "2024-10-31", "Quarterly Report Q3 FY24", "AWS revenue $27.5B (+19% YoY), Operating income $17.4B (+55% YoY), Trailing 12-month FCF $47.7B.")
  )

  private fun createInitialPortfolio(secs: List<Security>): List<PortfolioHolding> {
    // $100M notional book
    val holdings = mutableListOf<PortfolioHolding>()
    val allocations = listOf(
      "AAPL" to (75000.0 to 220.0), // ~17.4M
      "MSFT" to (35000.0 to 410.0), // ~15.0M
      "NVDA" to (130000.0 to 115.0), // ~18.0M
      "AMZN" to (65000.0 to 175.0), // ~12.3M
      "JPM"  to (50000.0 to 205.0), // ~11.2M
      "ASML" to (12000.0 to 740.0), // ~9.5M
      "AZN"  to (70000.0 to 110.0), // ~8.3M
      "7203" to (28000.0 to 2600.0) // ~8.0M
    )

    var totalMv = 0.0
    for ((ticker, pair) in allocations) {
      val sec = secs.find { it.ticker == ticker } ?: secs.first()
      val shares = pair.first
      val cost = pair.second
      val mv = shares * sec.price
      totalMv += mv
    }

    for ((ticker, pair) in allocations) {
      val sec = secs.find { it.ticker == ticker } ?: secs.first()
      val shares = pair.first
      val cost = pair.second
      val mv = shares * sec.price
      val pnl = (sec.price - cost) * shares
      val pnlPct = ((sec.price - cost) / cost) * 100.0
      val weight = (mv / totalMv) * 100.0

      holdings.add(
        PortfolioHolding(
          ticker = sec.ticker,
          name = sec.displayName,
          shares = shares,
          avgCostPrice = cost,
          currentPrice = sec.price,
          marketValue = (mv * 100.0).roundToInt() / 100.0,
          weightPct = (weight * 10.0).roundToInt() / 10.0,
          unrealizedPnl = (pnl * 100.0).roundToInt() / 100.0,
          unrealizedPnlPct = (pnlPct * 10.0).roundToInt() / 10.0,
          sector = sec.sector,
          beta = sec.beta,
          varContribPct = ((sec.var95DailyPct * (weight / 100.0)) * 10.0).roundToInt() / 10.0
        )
      )
    }

    return holdings
  }

  private fun createInitialStressScenarios(): List<StressScenario> = listOf(
    StressScenario(
      id = "SCEN-01",
      name = "Global Rates Shock (+100bp)",
      description = "Parallel upward shift in benchmark sovereign yield curves across G10 economies.",
      equityShockPct = -6.2,
      ratesShockBp = 100,
      usdShockPct = 3.5,
      oilShockPct = -4.0,
      volShockPct = 25.0,
      portfolioImpactPct = -5.4,
      estimatedPnlLoss = 5400000.0
    ),
    StressScenario(
      id = "SCEN-02",
      name = "Tech Multiple Compression (Nasdaq -15%)",
      description = "Hyperscaler CapEx fatigue triggering 2.5x multiple de-rating across AI semiconductors and infrastructure.",
      equityShockPct = -15.0,
      ratesShockBp = -25,
      usdShockPct = -1.2,
      oilShockPct = -2.5,
      volShockPct = 65.0,
      portfolioImpactPct = -11.8,
      estimatedPnlLoss = 11800000.0
    ),
    StressScenario(
      id = "SCEN-03",
      name = "US Dollar Surge (USD +10%)",
      description = "Safe-haven dollar appreciation penalizing multinational foreign revenues and emerging market liquidity.",
      equityShockPct = -4.8,
      ratesShockBp = 45,
      usdShockPct = 10.0,
      oilShockPct = -8.0,
      volShockPct = 30.0,
      portfolioImpactPct = -3.9,
      estimatedPnlLoss = 3900000.0
    ),
    StressScenario(
      id = "SCEN-04",
      name = "Energy Supply Shock (Brent +30%)",
      description = "Strait of Hormuz geopolitical disruption inducing crude spike and sticky headline CPI.",
      equityShockPct = -8.5,
      ratesShockBp = 75,
      usdShockPct = 4.2,
      oilShockPct = 30.0,
      volShockPct = 48.0,
      portfolioImpactPct = -7.2,
      estimatedPnlLoss = 7200000.0
    ),
    StressScenario(
      id = "SCEN-05",
      name = "Global Volatility Spike (VIX +50%)",
      description = "Exogenous systematic deleveraging event inducing risk parity and CTA unwind.",
      equityShockPct = -9.4,
      ratesShockBp = -40,
      usdShockPct = 2.0,
      oilShockPct = -6.0,
      volShockPct = 50.0,
      portfolioImpactPct = -8.6,
      estimatedPnlLoss = 8600000.0
    )
  )

  // API Explorer specifications
  val apiEndpoints: List<ApiEndpoint> = listOf(
    ApiEndpoint(
      method = "GET",
      path = "/api/v1/securities/{ticker}",
      summary = "Normalized security master instrument definition & market quote",
      description = "Returns complete cross-venue identifiers (ISIN, CUSIP, SEDOL, FIGI, MIC), real-time Level 1 pricing, and valuation metrics with full provenance.",
      sampleCurl = "curl -X GET 'https://api.markets.terminal/v1/securities/AAPL' \\\n  -H 'Authorization: Bearer mk_live_9f82...'",
      samplePython = "from markets import Client\nclient = Client(api_key='mk_live_...')\naapl = client.securities.get('AAPL')\nprint(aapl.quote.last, aapl.isin)",
      sampleRust = "use markets_engine::Client;\nlet client = Client::new(\"mk_live_...\");\nlet sec = client.securities().get(\"AAPL\").await?;\nprintln!(\"Price: {}\", sec.quote.last);",
      sampleResponse = "{\n  \"security_id\": \"SEC-US-AAPL\",\n  \"ticker\": \"AAPL\",\n  \"mic\": \"XNAS\",\n  \"isin\": \"US0378331005\",\n  \"quote\": {\n    \"bid\": 232.38,\n    \"ask\": 232.42,\n    \"last\": 232.40,\n    \"volume\": 48512300,\n    \"vwap\": 232.18,\n    \"data_status\": \"EXCHANGE\"\n  }\n}"
    ),
    ApiEndpoint(
      method = "GET",
      path = "/api/v1/orderbook/{ticker}/depth",
      summary = "Deterministic Level 2 market-by-price order book ladder",
      description = "Retrieves aggregated bids and asks up to 20 price tiers with uncrossing auction imbalance analytics.",
      sampleCurl = "curl -X GET 'https://api.markets.terminal/v1/orderbook/NVDA/depth?levels=10' \\\n  -H 'Authorization: Bearer mk_live_...'",
      samplePython = "depth = client.orderbook.get_depth('NVDA', levels=10)\nfor bid in depth.bids:\n    print(f'{bid.price} x {bid.quantity}')",
      sampleRust = "let book = client.orderbook().fetch_depth(\"NVDA\").await?;\nprintln!(\"Spread BPS: {}\", book.spread_bps);",
      sampleResponse = "{\n  \"security_id\": \"SEC-US-NVDA\",\n  \"bids\": [{\"price\": 138.22, \"qty\": 4200, \"cum\": 4200}],\n  \"asks\": [{\"price\": 138.28, \"qty\": 3800, \"cum\": 3800}],\n  \"spread\": 0.06,\n  \"spread_bps\": 4.3,\n  \"imbalance\": {\"side\": \"BUY\", \"qty\": 1050}\n}"
    ),
    ApiEndpoint(
      method = "POST",
      path = "/api/v1/risk/stress-test",
      summary = "Multi-factor portfolio stress testing & covariance shock decomposition",
      description = "Computes instantaneous P&L impact across interest rates, equity factors, foreign exchange, and volatility shocks.",
      sampleCurl = "curl -X POST 'https://api.markets.terminal/v1/risk/stress-test' \\\n  -H 'Content-Type: application/json' \\\n  -d '{\"portfolio_id\": \"BOOK-01\", \"scenario\": \"RATES_100BP\"}'",
      samplePython = "result = client.risk.stress_test(\n    portfolio='BOOK-01',\n    equity_shock=-0.10,\n    rates_bp=100\n)\nprint(f'Est Drawdown: {result.pnl_impact}')",
      sampleRust = "let stress = RiskEngine::simulate_stress(&portfolio, Scenario::RatesShock(100))?;\nprintln!(\"Estimated Loss: {}\", stress.estimated_loss);",
      sampleResponse = "{\n  \"portfolio_id\": \"BOOK-01\",\n  \"nav\": 100000000.0,\n  \"scenario\": \"RATES_100BP\",\n  \"estimated_pnl_loss\": -5400000.0,\n  \"portfolio_impact_pct\": -5.4\n}"
    )
  )
}
