package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.MarketDataRepository
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Markets", appName)
  }

  @Test
  fun `verify market repository securities loaded`() {
    val secs = MarketDataRepository.securities.value
    assertTrue("Securities should not be empty", secs.isNotEmpty())
    val aapl = secs.find { it.ticker == "AAPL" }
    assertNotNull("AAPL should be present in security master", aapl)
    assertEquals("US0378331005", aapl?.isin)
  }

  @Test
  fun `verify dcf intrinsic value computation`() {
    val dcf = MarketDataRepository.calculateDcf("AAPL", 8.5, 3.0, 12.0)
    assertTrue("Intrinsic value should be greater than zero", dcf.intrinsicValue > 0)
    assertTrue("Implied multiple should be positive", dcf.impliedMultipleEvEbitda > 0)
  }

  @Test
  fun `verify markets ai query provenance`() {
    val result = MarketDataRepository.executeAiQuery("Why is NVDA moving today?")
    assertNotNull(result)
    assertTrue(result.confidenceScore > 0.8)
    assertTrue(result.dataPointsUsed.isNotEmpty())
    assertTrue(result.keyInferences.isNotEmpty())
  }
}
