import { Station, TrackSection, TrainFormation, CandidateRoute, CoachComposition, Scenario } from '../types/railway';

export const EUROPEAN_STATIONS: Station[] = [
  { id: 'STPX', code: 'STPX', name: 'London St Pancras', city: 'London', country: 'United Kingdom', lat: 51.5314, lng: -0.1261, type: 'HUB', platformCapacity: 12, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'PAR_N', code: 'PAR_N', name: 'Paris Gare du Nord', city: 'Paris', country: 'France', lat: 48.8809, lng: 2.3553, type: 'HUB', platformCapacity: 28, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'PAR_E', code: 'PAR_E', name: 'Paris Gare de l\'Est', city: 'Paris', country: 'France', lat: 48.8768, lng: 2.3592, type: 'HUB', platformCapacity: 30, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'BRU_M', code: 'BRU_M', name: 'Brussels Midi', city: 'Brussels', country: 'Belgium', lat: 50.8357, lng: 4.3365, type: 'HUB', platformCapacity: 22, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'AMS_C', code: 'AMS_C', name: 'Amsterdam Centraal', city: 'Amsterdam', country: 'Netherlands', lat: 52.3791, lng: 4.9003, type: 'HUB', platformCapacity: 15, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'COL_H', code: 'COL_H', name: 'Cologne Hbf', city: 'Cologne', country: 'Germany', lat: 50.9432, lng: 6.9586, type: 'HUB', platformCapacity: 11, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'FRA_H', code: 'FRA_H', name: 'Frankfurt Hbf', city: 'Frankfurt', country: 'Germany', lat: 50.1071, lng: 8.6637, type: 'HUB', platformCapacity: 24, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'BER_H', code: 'BER_H', name: 'Berlin Hbf', city: 'Berlin', country: 'Germany', lat: 52.5251, lng: 13.3694, type: 'HUB', platformCapacity: 14, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'HAM_H', code: 'HAM_H', name: 'Hamburg Hbf', city: 'Hamburg', country: 'Germany', lat: 53.5528, lng: 10.0067, type: 'HUB', platformCapacity: 12, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'COP_H', code: 'COP_H', name: 'Copenhagen Hbf', city: 'Copenhagen', country: 'Denmark', lat: 55.6726, lng: 12.5646, type: 'MAJOR', platformCapacity: 12, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'MUN_H', code: 'MUN_H', name: 'Munich Hbf', city: 'Munich', country: 'Germany', lat: 48.1402, lng: 11.5583, type: 'HUB', platformCapacity: 32, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'VIE_H', code: 'VIE_H', name: 'Vienna Hbf', city: 'Vienna', country: 'Austria', lat: 48.1851, lng: 16.3764, type: 'HUB', platformCapacity: 12, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'PRA_H', code: 'PRA_H', name: 'Prague hl.n.', city: 'Prague', country: 'Czech Republic', lat: 50.0831, lng: 14.4353, type: 'HUB', platformCapacity: 8, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'BUD_K', code: 'BUD_K', name: 'Budapest Keleti', city: 'Budapest', country: 'Hungary', lat: 47.5003, lng: 19.0839, type: 'HUB', platformCapacity: 18, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'ZUR_H', code: 'ZUR_H', name: 'Zurich HB', city: 'Zurich', country: 'Switzerland', lat: 47.3779, lng: 8.5403, type: 'HUB', platformCapacity: 26, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'MI_C', code: 'MI_C', name: 'Milan Centrale', city: 'Milan', country: 'Italy', lat: 45.4859, lng: 9.2038, type: 'HUB', platformCapacity: 24, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'VE_SL', code: 'VE_SL', name: 'Venice Santa Lucia', city: 'Venice', country: 'Italy', lat: 45.4411, lng: 12.3211, type: 'MAJOR', platformCapacity: 14, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'ROM_T', code: 'ROM_T', name: 'Rome Termini', city: 'Rome', country: 'Italy', lat: 41.9010, lng: 12.5018, type: 'HUB', platformCapacity: 32, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'FLO_SMN', code: 'FLO_SMN', name: 'Florence SMN', city: 'Florence', country: 'Italy', lat: 43.7766, lng: 11.2478, type: 'MAJOR', platformCapacity: 19, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'BOL_C', code: 'BOL_C', name: 'Bologna Centrale', city: 'Bologna', country: 'Italy', lat: 44.5058, lng: 11.3417, type: 'MAJOR', platformCapacity: 16, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'TUR_PN', code: 'TUR_PN', name: 'Turin Porta Nuova', city: 'Turin', country: 'Italy', lat: 45.0622, lng: 7.6784, type: 'MAJOR', platformCapacity: 20, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'INN_H', code: 'INN_H', name: 'Innsbruck Hbf', city: 'Innsbruck', country: 'Austria', lat: 47.2638, lng: 11.4010, type: 'MAJOR', platformCapacity: 11, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'SAL_H', code: 'SAL_H', name: 'Salzburg Hbf', city: 'Salzburg', country: 'Austria', lat: 47.8129, lng: 13.0456, type: 'MAJOR', platformCapacity: 9, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'LJU_G', code: 'LJU_G', name: 'Ljubljana', city: 'Ljubljana', country: 'Slovenia', lat: 46.0577, lng: 14.5098, type: 'MAJOR', platformCapacity: 7, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'ZAG_G', code: 'ZAG_G', name: 'Zagreb Glavni', city: 'Zagreb', country: 'Croatia', lat: 45.8051, lng: 15.9788, type: 'MAJOR', platformCapacity: 8, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'MAR_SC', code: 'MAR_SC', name: 'Marseille St-Charles', city: 'Marseille', country: 'France', lat: 43.3028, lng: 5.3806, type: 'MAJOR', platformCapacity: 16, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'NIC_V', code: 'NIC_V', name: 'Nice-Ville', city: 'Nice', country: 'France', lat: 43.7046, lng: 7.2618, type: 'MINOR', platformCapacity: 7, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'LYO_P', code: 'LYO_P', name: 'Lyon Part-Dieu', city: 'Lyon', country: 'France', lat: 45.7606, lng: 4.8599, type: 'MAJOR', platformCapacity: 11, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'BAR_S', code: 'BAR_S', name: 'Barcelona Sants', city: 'Barcelona', country: 'Spain', lat: 41.3791, lng: 2.1401, type: 'HUB', platformCapacity: 14, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'MAD_A', code: 'MAD_A', name: 'Madrid Atocha', city: 'Madrid', country: 'Spain', lat: 40.4068, lng: -3.6892, type: 'HUB', platformCapacity: 15, openingWindow: { startHour: 5, endHour: 24 } },
  { id: 'CAL_F', code: 'CAL_F', name: 'Calais Frethun (Tunnel)', city: 'Calais', country: 'France', lat: 50.8997, lng: 1.8122, type: 'BORDER', platformCapacity: 4, openingWindow: { startHour: 0, endHour: 24 } },
  { id: 'BAS_S', code: 'BAS_S', name: 'Basel SBB', city: 'Basel', country: 'Switzerland', lat: 47.5476, lng: 7.5896, type: 'BORDER', platformCapacity: 17, openingWindow: { startHour: 0, endHour: 24 } }
];

export const EUROPEAN_TRACK_SECTIONS: TrackSection[] = [
  // Channel Tunnel & High Speed 1
  { id: 'E_STPX_CAL', sourceId: 'STPX', targetId: 'CAL_F', distanceKm: 172, minRunningTimeMin: 65, maxSpeedKmh: 300, capacityTrainsPerHour: 12, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 20, gradientPct: 1.1, typicalDelayMin: 4, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_CAL_PAR', sourceId: 'CAL_F', targetId: 'PAR_N', distanceKm: 295, minRunningTimeMin: 80, maxSpeedKmh: 300, capacityTrainsPerHour: 18, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'TVM', hasBorderCrossing: false, gradientPct: 0.8, typicalDelayMin: 2, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_CAL_BRU', sourceId: 'CAL_F', targetId: 'BRU_M', distanceKm: 210, minRunningTimeMin: 60, maxSpeedKmh: 300, capacityTrainsPerHour: 16, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: false, gradientPct: 0.5, typicalDelayMin: 3, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  
  // North-West Corridors
  { id: 'E_BRU_AMS', sourceId: 'BRU_M', targetId: 'AMS_C', distanceKm: 211, minRunningTimeMin: 110, maxSpeedKmh: 250, capacityTrainsPerHour: 12, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 0.2, typicalDelayMin: 5, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_BRU_COL', sourceId: 'BRU_M', targetId: 'COL_H', distanceKm: 226, minRunningTimeMin: 110, maxSpeedKmh: 250, capacityTrainsPerHour: 10, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 1.4, typicalDelayMin: 6, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_AMS_COL', sourceId: 'AMS_C', targetId: 'COL_H', distanceKm: 260, minRunningTimeMin: 160, maxSpeedKmh: 200, capacityTrainsPerHour: 10, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 0.3, typicalDelayMin: 4, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_COL_FRA', sourceId: 'COL_H', targetId: 'FRA_H', distanceKm: 180, minRunningTimeMin: 60, maxSpeedKmh: 300, capacityTrainsPerHour: 16, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: false, gradientPct: 4.0, typicalDelayMin: 5, permittedTrainTypes: ['SLEEPER_HS', 'SLEEPER_CLASSIC'] },
  { id: 'E_FRA_BER', sourceId: 'FRA_H', targetId: 'BER_H', distanceKm: 540, minRunningTimeMin: 230, maxSpeedKmh: 250, capacityTrainsPerHour: 14, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: false, gradientPct: 0.5, typicalDelayMin: 7, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_COL_BER', sourceId: 'COL_H', targetId: 'BER_H', distanceKm: 570, minRunningTimeMin: 250, maxSpeedKmh: 250, capacityTrainsPerHour: 12, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: false, gradientPct: 0.4, typicalDelayMin: 6, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_BER_HAM', sourceId: 'BER_H', targetId: 'HAM_H', distanceKm: 286, minRunningTimeMin: 100, maxSpeedKmh: 230, capacityTrainsPerHour: 14, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: false, gradientPct: 0.2, typicalDelayMin: 3, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_HAM_COP', sourceId: 'HAM_H', targetId: 'COP_H', distanceKm: 340, minRunningTimeMin: 220, maxSpeedKmh: 200, capacityTrainsPerHour: 8, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 15, gradientPct: 0.5, typicalDelayMin: 8, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },

  // Rhine Alpine Corridor & Switzerland
  { id: 'E_PAR_E_BAS', sourceId: 'PAR_E', targetId: 'BAS_S', distanceKm: 500, minRunningTimeMin: 180, maxSpeedKmh: 320, capacityTrainsPerHour: 16, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 0.8, typicalDelayMin: 3, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_FRA_BAS', sourceId: 'FRA_H', targetId: 'BAS_S', distanceKm: 330, minRunningTimeMin: 170, maxSpeedKmh: 250, capacityTrainsPerHour: 14, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 0.6, typicalDelayMin: 6, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_BAS_ZUR', sourceId: 'BAS_S', targetId: 'ZUR_H', distanceKm: 88, minRunningTimeMin: 53, maxSpeedKmh: 160, capacityTrainsPerHour: 16, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: false, gradientPct: 1.0, typicalDelayMin: 1, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_ZUR_MI', sourceId: 'ZUR_H', targetId: 'MI_C', distanceKm: 250, minRunningTimeMin: 190, maxSpeedKmh: 200, capacityTrainsPerHour: 10, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 10, gradientPct: 2.5, typicalDelayMin: 5, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },

  // Trans-Alpine & Austrian Network
  { id: 'E_FRA_MUN', sourceId: 'FRA_H', targetId: 'MUN_H', distanceKm: 400, minRunningTimeMin: 190, maxSpeedKmh: 300, capacityTrainsPerHour: 16, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: false, gradientPct: 1.2, typicalDelayMin: 5, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_MUN_VIE', sourceId: 'MUN_H', targetId: 'VIE_H', distanceKm: 435, minRunningTimeMin: 240, maxSpeedKmh: 230, capacityTrainsPerHour: 12, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 0.8, typicalDelayMin: 4, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_MUN_INN', sourceId: 'MUN_H', targetId: 'INN_H', distanceKm: 170, minRunningTimeMin: 100, maxSpeedKmh: 160, capacityTrainsPerHour: 8, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 1.8, typicalDelayMin: 3, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_INN_MI', sourceId: 'INN_H', targetId: 'MI_C', distanceKm: 380, minRunningTimeMin: 280, maxSpeedKmh: 160, capacityTrainsPerHour: 6, trackType: 'SINGLE', electrification: 'DC_3KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 2.8, typicalDelayMin: 9, permittedTrainTypes: ['SLEEPER_CLASSIC'] },
  { id: 'E_VIE_PRA', sourceId: 'VIE_H', targetId: 'PRA_H', distanceKm: 310, minRunningTimeMin: 240, maxSpeedKmh: 160, capacityTrainsPerHour: 8, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 0.9, typicalDelayMin: 5, permittedTrainTypes: ['SLEEPER_CLASSIC'] },
  { id: 'E_PRA_BER', sourceId: 'PRA_H', targetId: 'BER_H', distanceKm: 350, minRunningTimeMin: 250, maxSpeedKmh: 160, capacityTrainsPerHour: 8, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 0.7, typicalDelayMin: 6, permittedTrainTypes: ['SLEEPER_CLASSIC'] },
  { id: 'E_VIE_BUD', sourceId: 'VIE_H', targetId: 'BUD_K', distanceKm: 250, minRunningTimeMin: 140, maxSpeedKmh: 160, capacityTrainsPerHour: 10, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 0.4, typicalDelayMin: 4, permittedTrainTypes: ['SLEEPER_CLASSIC'] },
  { id: 'E_VIE_LJU', sourceId: 'VIE_H', targetId: 'LJU_G', distanceKm: 380, minRunningTimeMin: 360, maxSpeedKmh: 140, capacityTrainsPerHour: 5, trackType: 'SINGLE', electrification: 'DC_3KV', signalling: 'PZB', hasBorderCrossing: true, borderInspectionMin: 10, gradientPct: 1.9, typicalDelayMin: 8, permittedTrainTypes: ['SLEEPER_CLASSIC'] },
  { id: 'E_LJU_ZAG', sourceId: 'LJU_G', targetId: 'ZAG_G', distanceKm: 140, minRunningTimeMin: 130, maxSpeedKmh: 120, capacityTrainsPerHour: 4, trackType: 'SINGLE', electrification: 'AC_25KV', signalling: 'PZB', hasBorderCrossing: true, borderInspectionMin: 15, gradientPct: 1.1, typicalDelayMin: 10, permittedTrainTypes: ['SLEEPER_CLASSIC'] },

  // Italian Backbone
  { id: 'E_MI_VE', sourceId: 'MI_C', targetId: 'VE_SL', distanceKm: 267, minRunningTimeMin: 135, maxSpeedKmh: 250, capacityTrainsPerHour: 14, trackType: 'DOUBLE', electrification: 'DC_3KV', signalling: 'ETCS_L2', hasBorderCrossing: false, gradientPct: 0.3, typicalDelayMin: 3, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_MI_BOL', sourceId: 'MI_C', targetId: 'BOL_C', distanceKm: 215, minRunningTimeMin: 65, maxSpeedKmh: 300, capacityTrainsPerHour: 18, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: false, gradientPct: 0.2, typicalDelayMin: 2, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_BOL_FLO', sourceId: 'BOL_C', targetId: 'FLO_SMN', distanceKm: 98, minRunningTimeMin: 37, maxSpeedKmh: 300, capacityTrainsPerHour: 18, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: false, gradientPct: 1.5, typicalDelayMin: 2, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_FLO_ROM', sourceId: 'FLO_SMN', targetId: 'ROM_T', distanceKm: 260, minRunningTimeMin: 90, maxSpeedKmh: 250, capacityTrainsPerHour: 16, trackType: 'DOUBLE', electrification: 'DC_3KV', signalling: 'ETCS_L2', hasBorderCrossing: false, gradientPct: 0.6, typicalDelayMin: 3, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },

  // French & Iberian Corridors
  { id: 'E_PAR_E_LYO', sourceId: 'PAR_E', targetId: 'LYO_P', distanceKm: 425, minRunningTimeMin: 120, maxSpeedKmh: 300, capacityTrainsPerHour: 20, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'TVM', hasBorderCrossing: false, gradientPct: 1.5, typicalDelayMin: 2, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_LYO_MAR', sourceId: 'LYO_P', targetId: 'MAR_SC', distanceKm: 310, minRunningTimeMin: 100, maxSpeedKmh: 300, capacityTrainsPerHour: 16, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'TVM', hasBorderCrossing: false, gradientPct: 1.0, typicalDelayMin: 3, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_MAR_NIC', sourceId: 'MAR_SC', targetId: 'NIC_V', distanceKm: 220, minRunningTimeMin: 150, maxSpeedKmh: 160, capacityTrainsPerHour: 8, trackType: 'DOUBLE', electrification: 'DC_1_5KV', signalling: 'KVB', hasBorderCrossing: false, gradientPct: 1.8, typicalDelayMin: 6, permittedTrainTypes: ['SLEEPER_CLASSIC'] },
  { id: 'E_LYO_BAR', sourceId: 'LYO_P', targetId: 'BAR_S', distanceKm: 640, minRunningTimeMin: 300, maxSpeedKmh: 300, capacityTrainsPerHour: 10, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: true, borderInspectionMin: 0, gradientPct: 1.2, typicalDelayMin: 5, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] },
  { id: 'E_BAR_MAD', sourceId: 'BAR_S', targetId: 'MAD_A', distanceKm: 620, minRunningTimeMin: 150, maxSpeedKmh: 310, capacityTrainsPerHour: 16, trackType: 'DOUBLE', electrification: 'AC_25KV', signalling: 'ETCS_L2', hasBorderCrossing: false, gradientPct: 1.0, typicalDelayMin: 2, permittedTrainTypes: ['SLEEPER_CLASSIC', 'SLEEPER_HS'] }
];

export const STANDARD_COACHES: CoachComposition[] = [
  { id: 'SLP_DELUXE', type: 'SINGLE_SLEEPER', name: 'Deluxe Single Sleeper (Ensuite)', beds: 12, seats: 0, weightTons: 48, costEuro: 850000 },
  { id: 'SLP_DOUBLE', type: 'DOUBLE_SLEEPER', name: 'Standard Double Sleeper', beds: 24, seats: 0, weightTons: 46, costEuro: 750000 },
  { id: 'CSH_4B', type: 'COUSETTE_4', name: '4-Berth Comfort Couchette', beds: 36, seats: 0, weightTons: 44, costEuro: 620000 },
  { id: 'CSH_6B', type: 'COUSETTE_6', name: '6-Berth Family Couchette', beds: 54, seats: 0, weightTons: 45, costEuro: 580000 },
  { id: 'STD_1ST', type: 'SEATED_1ST', name: '1st Class Reclining Seats', beds: 0, seats: 42, weightTons: 42, costEuro: 500000 },
  { id: 'STD_2ND', type: 'SEATED_2ND', name: '2nd Class Reclining Seats', beds: 0, seats: 72, weightTons: 41, costEuro: 450000 },
  { id: 'REST_BAR', type: 'RESTAURANT', name: 'Dining Car & Lounge Bar', beds: 0, seats: 30, weightTons: 52, costEuro: 900000 },
];

export const DEFAULT_FORMATIONS: TrainFormation[] = [
  {
    id: 'FORM_NIGHTJET_STD',
    name: 'Nightjet Standard Express (12 Coaches)',
    locoType: 'Vectron Multi-System AC/DC (6.4MW)',
    coaches: [
      STANDARD_COACHES[0], // Deluxe
      STANDARD_COACHES[1], STANDARD_COACHES[1], // 2x Double
      STANDARD_COACHES[2], STANDARD_COACHES[2], STANDARD_COACHES[2], // 3x Couchette 4
      STANDARD_COACHES[3], STANDARD_COACHES[3], // 2x Couchette 6
      STANDARD_COACHES[6], // Dining Car
      STANDARD_COACHES[4], // 1st Class
      STANDARD_COACHES[5], STANDARD_COACHES[5], // 2x 2nd Class
    ],
    totalBeds: 276,
    totalSeats: 174,
    totalCapacity: 450,
    totalLengthMeters: 310,
    totalWeightTons: 610,
    locoPowerKw: 6400,
    maxSpeedKmh: 200,
  },
  {
    id: 'FORM_PREMIUM_SLEEPER',
    name: 'Luxury Executive Night Express (10 Coaches)',
    locoType: 'EuroDual Hybrid Multi-System',
    coaches: [
      STANDARD_COACHES[0], STANDARD_COACHES[0], STANDARD_COACHES[0], // 3x Deluxe
      STANDARD_COACHES[1], STANDARD_COACHES[1], STANDARD_COACHES[1], // 3x Double
      STANDARD_COACHES[2], STANDARD_COACHES[2], // 2x Couchette 4
      STANDARD_COACHES[6], // Dining Lounge
      STANDARD_COACHES[4], // 1st Class
    ],
    totalBeds: 180,
    totalSeats: 72,
    totalCapacity: 252,
    totalLengthMeters: 260,
    totalWeightTons: 520,
    locoPowerKw: 7000,
    maxSpeedKmh: 230,
  }
];

export const INITIAL_CANDIDATE_ROUTES: CandidateRoute[] = [
  {
    id: 'R_LON_PAR_MIL',
    name: 'Trans-Alpine Night Express (London → Milan)',
    originId: 'STPX',
    originName: 'London St Pancras',
    destinationId: 'MI_C',
    destinationName: 'Milan Centrale',
    pathStationIds: ['STPX', 'CAL_F', 'PAR_E', 'BAS_S', 'ZUR_H', 'MI_C'],
    pathEdgeIds: ['E_STPX_CAL', 'E_CAL_PAR', 'E_PAR_E_BAS', 'E_BAS_ZUR', 'E_ZUR_MI'],
    totalDistanceKm: 1210,
    pureRunningTimeMin: 528,
    scheduledDepartureTime: '19:45',
    scheduledArrivalTime: '07:30',
    totalJourneyTimeMin: 705,
    sleepDurationHours: 7.5,
    stops: [
      { stationId: 'STPX', stationName: 'London St Pancras', arrivalTime: '19:15', departureTime: '19:45', dwellMin: 30, stopType: 'major_boarding', distanceFromOriginKm: 0, isSleepingHours: false, nightDisruptionPenalty: 0 },
      { stationId: 'CAL_F', stationName: 'Calais Frethun', arrivalTime: '21:10', departureTime: '21:30', dwellMin: 20, stopType: 'border', distanceFromOriginKm: 172, isSleepingHours: false, nightDisruptionPenalty: 1 },
      { stationId: 'PAR_E', stationName: 'Paris Gare de l\'Est', arrivalTime: '22:50', departureTime: '23:15', dwellMin: 25, stopType: 'major_boarding', distanceFromOriginKm: 467, isSleepingHours: false, nightDisruptionPenalty: 2 },
      { stationId: 'BAS_S', stationName: 'Basel SBB', arrivalTime: '02:15', departureTime: '02:25', dwellMin: 10, stopType: 'technical', distanceFromOriginKm: 967, isSleepingHours: true, nightDisruptionPenalty: 3 },
      { stationId: 'ZUR_H', stationName: 'Zurich HB', arrivalTime: '03:18', departureTime: '03:40', dwellMin: 22, stopType: 'loco_change', distanceFromOriginKm: 1055, isSleepingHours: true, nightDisruptionPenalty: 4 },
      { stationId: 'MI_C', stationName: 'Milan Centrale', arrivalTime: '07:30', departureTime: '08:00', dwellMin: 30, stopType: 'major_boarding', distanceFromOriginKm: 1210, isSleepingHours: false, nightDisruptionPenalty: 0 },
    ],
    sleepQualityScore: 88,
    nightDisruptionScore: 18,
    robustnessRating: 'ROBUST',
    robustnessScore: 91,
    estimatedPaxDemand: 385,
    avgFareEuro: 165,
    totalRevenueEuro: 63525,
    operatingCostEuro: 31200,
    netMarginEuro: 32325,
    breakEvenOccupancyPct: 49,
    co2SavedVsFlightKg: 142000,
    formation: DEFAULT_FORMATIONS[0],
    requiredTrainsets: 2,
    hasCouplingPortion: false,
  },
  {
    id: 'R_AMS_COL_VIE',
    name: 'Central European Nightjet (Amsterdam → Vienna)',
    originId: 'AMS_C',
    originName: 'Amsterdam Centraal',
    destinationId: 'VIE_H',
    destinationName: 'Vienna Hbf',
    pathStationIds: ['AMS_C', 'COL_H', 'FRA_H', 'MUN_H', 'SAL_H', 'VIE_H'],
    pathEdgeIds: ['E_AMS_COL', 'E_COL_FRA', 'E_FRA_MUN', 'E_MUN_VIE'],
    totalDistanceKm: 1275,
    pureRunningTimeMin: 650,
    scheduledDepartureTime: '19:30',
    scheduledArrivalTime: '08:15',
    totalJourneyTimeMin: 765,
    sleepDurationHours: 7.8,
    stops: [
      { stationId: 'AMS_C', stationName: 'Amsterdam Centraal', arrivalTime: '19:00', departureTime: '19:30', dwellMin: 30, stopType: 'major_boarding', distanceFromOriginKm: 0, isSleepingHours: false, nightDisruptionPenalty: 0 },
      { stationId: 'COL_H', stationName: 'Cologne Hbf', arrivalTime: '22:10', departureTime: '22:30', dwellMin: 20, stopType: 'coupling_splitting', distanceFromOriginKm: 260, isSleepingHours: false, nightDisruptionPenalty: 1 },
      { stationId: 'FRA_H', stationName: 'Frankfurt Hbf', arrivalTime: '23:30', departureTime: '23:45', dwellMin: 15, stopType: 'minor_boarding', distanceFromOriginKm: 440, isSleepingHours: true, nightDisruptionPenalty: 3 },
      { stationId: 'MUN_H', stationName: 'Munich Hbf', arrivalTime: '03:55', departureTime: '04:15', dwellMin: 20, stopType: 'technical', distanceFromOriginKm: 840, isSleepingHours: true, nightDisruptionPenalty: 5 },
      { stationId: 'SAL_H', stationName: 'Salzburg Hbf', arrivalTime: '05:50', departureTime: '06:05', dwellMin: 15, stopType: 'minor_boarding', distanceFromOriginKm: 1010, isSleepingHours: false, nightDisruptionPenalty: 2 },
      { stationId: 'VIE_H', stationName: 'Vienna Hbf', arrivalTime: '08:15', departureTime: '08:45', dwellMin: 30, stopType: 'major_boarding', distanceFromOriginKm: 1275, isSleepingHours: false, nightDisruptionPenalty: 0 },
    ],
    sleepQualityScore: 82,
    nightDisruptionScore: 24,
    robustnessRating: 'ROBUST',
    robustnessScore: 86,
    estimatedPaxDemand: 410,
    avgFareEuro: 145,
    totalRevenueEuro: 59450,
    operatingCostEuro: 29800,
    netMarginEuro: 29650,
    breakEvenOccupancyPct: 50,
    co2SavedVsFlightKg: 138000,
    formation: DEFAULT_FORMATIONS[0],
    requiredTrainsets: 3,
    hasCouplingPortion: true,
    couplingHubId: 'COL_H',
  },
  {
    id: 'R_LON_BRU_BER',
    name: 'Capital Sleeper (London → Berlin via Brussels)',
    originId: 'STPX',
    originName: 'London St Pancras',
    destinationId: 'BER_H',
    destinationName: 'Berlin Hbf',
    pathStationIds: ['STPX', 'CAL_F', 'BRU_M', 'COL_H', 'BER_H'],
    pathEdgeIds: ['E_STPX_CAL', 'E_CAL_BRU', 'E_BRU_COL', 'E_COL_BER'],
    totalDistanceKm: 1178,
    pureRunningTimeMin: 485,
    scheduledDepartureTime: '20:15',
    scheduledArrivalTime: '07:45',
    totalJourneyTimeMin: 690,
    sleepDurationHours: 7.2,
    stops: [
      { stationId: 'STPX', stationName: 'London St Pancras', arrivalTime: '19:45', departureTime: '20:15', dwellMin: 30, stopType: 'major_boarding', distanceFromOriginKm: 0, isSleepingHours: false, nightDisruptionPenalty: 0 },
      { stationId: 'CAL_F', stationName: 'Calais Frethun', arrivalTime: '21:30', departureTime: '21:50', dwellMin: 20, stopType: 'border', distanceFromOriginKm: 172, isSleepingHours: false, nightDisruptionPenalty: 1 },
      { stationId: 'BRU_M', stationName: 'Brussels Midi', arrivalTime: '22:50', departureTime: '23:15', dwellMin: 25, stopType: 'major_boarding', distanceFromOriginKm: 382, isSleepingHours: false, nightDisruptionPenalty: 2 },
      { stationId: 'COL_H', stationName: 'Cologne Hbf', arrivalTime: '01:05', departureTime: '01:25', dwellMin: 20, stopType: 'technical', distanceFromOriginKm: 608, isSleepingHours: true, nightDisruptionPenalty: 6 },
      { stationId: 'BER_H', stationName: 'Berlin Hbf', arrivalTime: '07:45', departureTime: '08:15', dwellMin: 30, stopType: 'major_boarding', distanceFromOriginKm: 1178, isSleepingHours: false, nightDisruptionPenalty: 0 },
    ],
    sleepQualityScore: 79,
    nightDisruptionScore: 28,
    robustnessRating: 'FRAGILE',
    robustnessScore: 68,
    estimatedPaxDemand: 390,
    avgFareEuro: 155,
    totalRevenueEuro: 60450,
    operatingCostEuro: 32500,
    netMarginEuro: 27950,
    breakEvenOccupancyPct: 53,
    co2SavedVsFlightKg: 129000,
    formation: DEFAULT_FORMATIONS[0],
    requiredTrainsets: 2,
    hasCouplingPortion: true,
    couplingHubId: 'BRU_M',
  }
];

export const INITIAL_SCENARIOS: Scenario[] = [
  {
    id: 'SC_BASE_2035',
    name: 'Base European Network 2035',
    description: 'Default operational network state with ETCS L2 rollouts and open high-speed corridors.',
    demandMultiplier: 1.0,
    energyCostMultiplier: 1.0,
    trackAccessMultiplier: 1.0,
    closedStations: [],
    restrictedEdges: [],
    speedReductionPct: 0,
    active: true,
  },
  {
    id: 'SC_HIGH_DEMAND',
    name: 'Aviation Carbon Tax Shift (+35% Night Demand)',
    description: 'EU-wide aviation short-haul ban and kerosene tax driving passenger surge to overnight sleeper rail.',
    demandMultiplier: 1.35,
    energyCostMultiplier: 1.0,
    trackAccessMultiplier: 0.95,
    closedStations: [],
    restrictedEdges: [],
    speedReductionPct: 0,
    active: false,
  },
  {
    id: 'SC_ENGINEERING_RHINE',
    name: 'Rhine Valley Night Possessions (Single Track Clearance)',
    description: 'Overnight maintenance between Cologne & Frankfurt restricting capacity to 2 trains/hr and +15 min delay.',
    demandMultiplier: 0.95,
    energyCostMultiplier: 1.05,
    trackAccessMultiplier: 1.1,
    closedStations: [],
    restrictedEdges: ['E_COL_FRA'],
    speedReductionPct: 25,
    active: false,
  },
  {
    id: 'SC_HIGH_ENERGY',
    name: 'Energy Crisis Surge (+40% Traction Power)',
    description: 'Electricity spot price spike increasing traction power cost per train-km.',
    demandMultiplier: 1.0,
    energyCostMultiplier: 1.4,
    trackAccessMultiplier: 1.05,
    closedStations: [],
    restrictedEdges: [],
    speedReductionPct: 0,
    active: false,
  }
];
