import { StopDetail } from '../types/railway';

export interface SleepUtilityBreakdown {
  totalJourneyMinutes: number;
  sleepDurationMinutes: number; // Duration of main sleep window
  departureInconveniencePenalty: number;
  arrivalInconveniencePenalty: number;
  nightStopsDisruptionPenalty: number;
  borderDisruptionPenalty: number;
  couplingDisruptionPenalty: number;
  passengerSleepQualityScore: number; // 0 - 100
  nightDisruptionScore: number; // 0 - 100
  comparison: {
    railwayOptimalHours: number;
    passengerOptimalHours: number;
    recommendedSpeedHoldMin: number; // Additional holding min to allow full 8h sleep
  };
}

export function parseTimeToMinutes(timeStr: string): number {
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

export function formatMinutesToTime(mins: number): string {
  const normMins = (mins + 1440 * 2) % 1440;
  const h = Math.floor(normMins / 60);
  const m = normMins % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

export function evaluateSleepQuality(
  departureTimeStr: string,
  arrivalTimeStr: string,
  stops: StopDetail[]
): SleepUtilityBreakdown {
  const depMin = parseTimeToMinutes(departureTimeStr);
  let arrMin = parseTimeToMinutes(arrivalTimeStr);
  if (arrMin <= depMin) arrMin += 1440; // Next day arrival

  const totalJourneyMinutes = arrMin - depMin;

  // 1. Departure Inconvenience Penalty
  // Ideal departure window: 19:30 - 22:30 (1170 - 1350 mins)
  let departureInconveniencePenalty = 0;
  if (depMin < 1110) { // Before 18:30
    departureInconveniencePenalty = (1110 - depMin) * 0.15;
  } else if (depMin > 1410) { // After 23:30
    departureInconveniencePenalty = (depMin - 1410) * 0.25;
  }

  // 2. Arrival Inconvenience Penalty
  // Ideal arrival window: 07:00 - 09:15 (420 - 555 mins + 1440)
  let arrivalInconveniencePenalty = 0;
  if (arrMin < 1800) { // Before 06:00
    arrivalInconveniencePenalty = (1800 - arrMin) * 0.4; // Very bad: waking passengers at 5 AM
  } else if (arrMin > 2100) { // After 11:00
    arrivalInconveniencePenalty = (arrMin - 2100) * 0.2;
  }

  // 3. Sleep Window Calculation (23:00 to 06:30 = 1380 to 1830 mins)
  const sleepStart = 1380;
  const sleepEnd = 1830;
  
  const journeyStart = depMin;
  const journeyEnd = arrMin;

  const actualSleepStart = Math.max(journeyStart + 45, sleepStart); // 45 min dinner/bed preparation
  const actualSleepEnd = Math.min(journeyEnd - 45, sleepEnd); // 45 min wake up/breakfast prep
  
  const sleepDurationMinutes = Math.max(0, actualSleepEnd - actualSleepStart);

  // 4. Intermediate Night Disruption Penalty (Stops during 23:00 - 06:30)
  let nightStopsDisruptionPenalty = 0;
  let borderDisruptionPenalty = 0;
  let couplingDisruptionPenalty = 0;

  for (const stop of stops) {
    let stopArrMin = parseTimeToMinutes(stop.arrivalTime);
    if (stopArrMin < depMin) stopArrMin += 1440;

    // Check if stop occurs during sleeping hours (1380 to 1830)
    if (stopArrMin >= 1380 && stopArrMin <= 1830) {
      if (stop.stopType === 'major_boarding' || stop.stopType === 'minor_boarding') {
        nightStopsDisruptionPenalty += 18; // Boarding/alighting announcement noise
      } else if (stop.stopType === 'border') {
        borderDisruptionPenalty += 25; // Passport check waking passengers
      } else if (stop.stopType === 'coupling_splitting') {
        couplingDisruptionPenalty += 20; // Shunting impact noise
      } else if (stop.stopType === 'technical' || stop.stopType === 'loco_change') {
        nightStopsDisruptionPenalty += 8; // Motion stop
      }
    }
  }

  // Base sleep utility calculation
  // Max score 100: 8 hours uninterrupted sleep (480 mins) = 60 pts
  // Timings = 20 pts, Low disruption = 20 pts
  const sleepDurationScore = Math.min(60, (sleepDurationMinutes / 450) * 60);
  const timingScore = Math.max(0, 20 - departureInconveniencePenalty - arrivalInconveniencePenalty);
  const disruptionPenaltySum = nightStopsDisruptionPenalty + borderDisruptionPenalty + couplingDisruptionPenalty;
  const disruptionScore = Math.max(0, 20 - disruptionPenaltySum * 0.4);

  const passengerSleepQualityScore = Math.min(100, Math.round(sleepDurationScore + timingScore + disruptionScore));
  const nightDisruptionScore = Math.min(100, Math.round(disruptionPenaltySum + (departureInconveniencePenalty + arrivalInconveniencePenalty) * 0.5));

  // Comparison between Railway-Optimal vs Passenger-Optimal
  // Railway optimal pushes train at max 200-300km/h and arrives early (e.g. 5:30 AM).
  // Passenger optimal holds the train at a quiet loop station for 45-60 min to let passengers sleep until 07:45 AM.
  const railwayOptimalHours = Math.round((totalJourneyMinutes / 60) * 10) / 10;
  const recommendedSpeedHoldMin = Math.max(0, 480 - sleepDurationMinutes);
  const passengerOptimalHours = Math.round(((totalJourneyMinutes + recommendedSpeedHoldMin) / 60) * 10) / 10;

  return {
    totalJourneyMinutes,
    sleepDurationMinutes,
    departureInconveniencePenalty: Math.round(departureInconveniencePenalty),
    arrivalInconveniencePenalty: Math.round(arrivalInconveniencePenalty),
    nightStopsDisruptionPenalty,
    borderDisruptionPenalty,
    couplingDisruptionPenalty,
    passengerSleepQualityScore,
    nightDisruptionScore,
    comparison: {
      railwayOptimalHours,
      passengerOptimalHours,
      recommendedSpeedHoldMin,
    },
  };
}
