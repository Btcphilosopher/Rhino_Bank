import { CandidateRoute, Scenario, Station } from '../types/railway';

export interface EconomicBreakdown {
  routeId: string;
  routeName: string;
  distanceKm: number;
  passengersPerNight: number;
  averageFareEuro: number;
  occupancyRatePct: number;
  grossRevenuePerNightEuro: number;
  operatingCostsPerNight: {
    trackAccessCharges: number;
    locoAndEnergyCost: number;
    staffAndCrew: number;
    stationAndTerminalFees: number;
    cateringAndBedding: number;
    rollingStockMaintenance: number;
    totalOperatingCostEuro: number;
  };
  netContributionMarginEuro: number;
  netMarginPct: number;
  breakEvenPax: number;
  costPerTrainKmEuro: number;
  costPerPassengerKmEuro: number;
  costPerBedEuro: number;
  co2ComparisonKg: {
    sleeperRailKg: number;
    aviationKg: number;
    privateCarKg: number;
    savingsVsAviationKg: number;
  };
}

export function calculateDemandAndEconomics(
  route: CandidateRoute,
  scenario: Scenario,
  priceMultiplier: number = 1.0,
  speedMultiplier: number = 1.0
): EconomicBreakdown {
  const baseDemand = route.estimatedPaxDemand;
  
  // Demand elasticity model:
  // Price elasticity = -1.2
  // Journey time elasticity = -0.7
  const priceFactor = Math.pow(priceMultiplier, -1.2);
  const timeFactor = Math.pow(speedMultiplier, 0.7);

  const effectivePaxDemand = Math.round(
    baseDemand * scenario.demandMultiplier * priceFactor * timeFactor
  );

  const capacity = route.formation.totalCapacity || 450;
  const actualPax = Math.min(capacity, effectivePaxDemand);
  const occupancyRatePct = Math.min(100, Math.round((actualPax / capacity) * 100));

  const averageFareEuro = Math.round(route.avgFareEuro * priceMultiplier);
  const grossRevenuePerNightEuro = actualPax * averageFareEuro;

  // Operating Cost Breakdown per Night Journey
  const dist = route.totalDistanceKm;
  const energyMult = scenario.energyCostMultiplier;
  const accessMult = scenario.trackAccessMultiplier;

  const trackAccessCharges = Math.round(dist * 6.8 * accessMult); // ~€6.80/train-km track fee
  const locoAndEnergyCost = Math.round(dist * 7.5 * energyMult); // ~€7.50/train-km traction energy
  const staffAndCrew = 3200; // 2 drivers, 4 train managers/conductors overnight
  const stationAndTerminalFees = 2400; // Origin/destination terminal dwell fees
  const cateringAndBedding = Math.round(actualPax * 14.5); // Breakfast & laundry per pax
  const rollingStockMaintenance = Math.round(dist * 4.2); // ~€4.20/train-km overhaul amortization

  const totalOperatingCostEuro = Math.round(
    trackAccessCharges + locoAndEnergyCost + staffAndCrew + stationAndTerminalFees + cateringAndBedding + rollingStockMaintenance
  );

  const netContributionMarginEuro = grossRevenuePerNightEuro - totalOperatingCostEuro;
  const netMarginPct = Math.round((netContributionMarginEuro / Math.max(1, grossRevenuePerNightEuro)) * 100);

  const breakEvenPax = Math.ceil(totalOperatingCostEuro / Math.max(1, averageFareEuro));
  const costPerTrainKmEuro = Math.round((totalOperatingCostEuro / dist) * 100) / 100;
  const costPerPassengerKmEuro = Math.round((totalOperatingCostEuro / (dist * Math.max(1, actualPax))) * 1000) / 1000;
  const costPerBedEuro = Math.round(totalOperatingCostEuro / route.formation.totalBeds);

  // Environmental CO2 Comparison Model
  // Sleeper Rail: ~12g CO2/pax-km (European grid mix)
  // Aviation: ~165g CO2/pax-km (including radiative forcing at high altitude)
  // Car: ~110g CO2/pax-km
  const sleeperRailKg = Math.round((actualPax * dist * 0.012));
  const aviationKg = Math.round((actualPax * dist * 0.165));
  const privateCarKg = Math.round((actualPax * dist * 0.110));
  const savingsVsAviationKg = Math.max(0, aviationKg - sleeperRailKg);

  return {
    routeId: route.id,
    routeName: route.name,
    distanceKm: dist,
    passengersPerNight: actualPax,
    averageFareEuro,
    occupancyRatePct,
    grossRevenuePerNightEuro,
    operatingCostsPerNight: {
      trackAccessCharges,
      locoAndEnergyCost,
      staffAndCrew,
      stationAndTerminalFees,
      cateringAndBedding,
      rollingStockMaintenance,
      totalOperatingCostEuro,
    },
    netContributionMarginEuro,
    netMarginPct,
    breakEvenPax,
    costPerTrainKmEuro,
    costPerPassengerKmEuro,
    costPerBedEuro,
    co2ComparisonKg: {
      sleeperRailKg,
      aviationKg,
      privateCarKg,
      savingsVsAviationKg,
    },
  };
}
