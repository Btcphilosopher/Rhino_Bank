import { Station, TrackSection } from '../types/railway';

export type WeightStrategy = 'DISTANCE' | 'TRAVEL_TIME' | 'COST' | 'BORDER_COMPLEXITY' | 'ROBUSTNESS' | 'PASSENGER_COMFORT';

export interface PathResult {
  stationIds: string[];
  edgeIds: string[];
  totalDistanceKm: number;
  totalPureRunningTimeMin: number;
  borderCrossingsCount: number;
  weightedScore: number;
}

export function calculateEdgeWeight(edge: TrackSection, strategy: WeightStrategy, speedReductionPct: number = 0): number {
  const effectiveMaxSpeed = edge.maxSpeedKmh * (1 - speedReductionPct / 100);
  const effectiveRunningTime = (edge.distanceKm / effectiveMaxSpeed) * 60 + (edge.borderInspectionMin || 0);

  switch (strategy) {
    case 'DISTANCE':
      return edge.distanceKm;
    case 'TRAVEL_TIME':
      return effectiveRunningTime + edge.typicalDelayMin;
    case 'BORDER_COMPLEXITY':
      return effectiveRunningTime + (edge.hasBorderCrossing ? 60 : 0);
    case 'COST':
      return edge.distanceKm * 12 + (edge.hasBorderCrossing ? 500 : 0);
    case 'ROBUSTNESS':
      return effectiveRunningTime + edge.typicalDelayMin * 3 + (edge.trackType === 'SINGLE' ? 30 : 0);
    case 'PASSENGER_COMFORT':
      // Smoother running, avoiding sharp gradients or frequent border halts
      return effectiveRunningTime + edge.gradientPct * 10 + (edge.hasBorderCrossing ? 40 : 0);
    default:
      return effectiveRunningTime;
  }
}

export function findShortestPath(
  stations: Station[],
  edges: TrackSection[],
  originId: string,
  destinationId: string,
  strategy: WeightStrategy = 'TRAVEL_TIME',
  speedReductionPct: number = 0
): PathResult | null {
  const stationMap = new Map(stations.map(s => [s.id, s]));
  const adjacency = new Map<string, { targetId: string; edge: TrackSection }[]>();

  for (const s of stations) {
    adjacency.set(s.id, []);
  }

  for (const edge of edges) {
    adjacency.get(edge.sourceId)?.push({ targetId: edge.targetId, edge });
    adjacency.get(edge.targetId)?.push({ targetId: edge.sourceId, edge }); // Bi-directional rail lines
  }

  const distances = new Map<string, number>();
  const previous = new Map<string, { stationId: string; edgeId: string } | null>();
  const unvisited = new Set<string>();

  for (const s of stations) {
    distances.set(s.id, Infinity);
    previous.set(s.id, null);
    unvisited.add(s.id);
  }

  distances.set(originId, 0);

  while (unvisited.size > 0) {
    // Pick unvisited node with min distance
    let currentId: string | null = null;
    let minDist = Infinity;

    for (const id of unvisited) {
      const d = distances.get(id)!;
      if (d < minDist) {
        minDist = d;
        currentId = id;
      }
    }

    if (!currentId || minDist === Infinity) break;
    if (currentId === destinationId) break;

    unvisited.delete(currentId);

    const neighbors = adjacency.get(currentId) || [];
    for (const { targetId, edge } of neighbors) {
      if (!unvisited.has(targetId)) continue;

      const weight = calculateEdgeWeight(edge, strategy, speedReductionPct);
      const alt = distances.get(currentId)! + weight;

      if (alt < distances.get(targetId)!) {
        distances.set(targetId, alt);
        previous.set(targetId, { stationId: currentId, edgeId: edge.id });
      }
    }
  }

  if (distances.get(destinationId) === Infinity) return null;

  // Reconstruct path
  const pathStationIds: string[] = [];
  const pathEdgeIds: string[] = [];
  let curr: string | null = destinationId;

  while (curr) {
    pathStationIds.unshift(curr);
    const prev = previous.get(curr);
    if (prev) {
      pathEdgeIds.unshift(prev.edgeId);
      curr = prev.stationId;
    } else {
      curr = null;
    }
  }

  // Calculate totals
  let totalDistanceKm = 0;
  let totalPureRunningTimeMin = 0;
  let borderCrossingsCount = 0;

  for (const edgeId of pathEdgeIds) {
    const edge = edges.find(e => e.id === edgeId);
    if (edge) {
      totalDistanceKm += edge.distanceKm;
      const speed = edge.maxSpeedKmh * (1 - speedReductionPct / 100);
      totalPureRunningTimeMin += Math.round((edge.distanceKm / speed) * 60) + (edge.borderInspectionMin || 0);
      if (edge.hasBorderCrossing) borderCrossingsCount++;
    }
  }

  return {
    stationIds: pathStationIds,
    edgeIds: pathEdgeIds,
    totalDistanceKm,
    totalPureRunningTimeMin,
    borderCrossingsCount,
    weightedScore: distances.get(destinationId)!,
  };
}

export function findKShortestPaths(
  stations: Station[],
  edges: TrackSection[],
  originId: string,
  destinationId: string,
  k: number = 3,
  speedReductionPct: number = 0
): PathResult[] {
  const results: PathResult[] = [];
  const primary = findShortestPath(stations, edges, originId, destinationId, 'TRAVEL_TIME', speedReductionPct);
  if (primary) results.push(primary);

  // Alternative strategy paths
  const strategies: WeightStrategy[] = ['DISTANCE', 'BORDER_COMPLEXITY', 'PASSENGER_COMFORT'];
  for (const strat of strategies) {
    if (results.length >= k) break;
    const path = findShortestPath(stations, edges, originId, destinationId, strat, speedReductionPct);
    if (path) {
      // Ensure unique station path
      const pathKey = path.stationIds.join('->');
      if (!results.some(r => r.stationIds.join('->') === pathKey)) {
        results.push(path);
      }
    }
  }

  return results;
}
