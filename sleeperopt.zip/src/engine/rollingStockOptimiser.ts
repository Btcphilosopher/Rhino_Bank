import { CandidateRoute, CoachComposition, TrainFormation } from '../types/railway';
import { STANDARD_COACHES } from '../data/europeanNetwork';

export interface FleetRequirements {
  activeServicesCount: number;
  totalTrainsetsRequired: number;
  maintenanceBufferTrainsets: number;
  totalFleetSize: number;
  fleetUtilizationPct: number;
  avgTurnaroundMinutes: number;
  emptyStockMovementsPerDay: number;
  capitalCostEuro: number;
}

export function calculateFleetSizing(routes: CandidateRoute[]): FleetRequirements {
  const activeServicesCount = routes.length;
  let rawTrainsets = 0;

  for (const r of routes) {
    // A single overnight daily service requires 2 trainsets for bidirectional rotation (A->B night 1, B->A night 2)
    // Long routes (>1200km) or 36h cycle require 3 trainsets with maintenance padding
    if (r.totalDistanceKm > 1200 || r.totalJourneyTimeMin > 720) {
      rawTrainsets += 3;
    } else {
      rawTrainsets += 2;
    }
  }

  const maintenanceBufferTrainsets = Math.ceil(rawTrainsets * 0.15); // 15% spare fleet for overhaul
  const totalFleetSize = rawTrainsets + maintenanceBufferTrainsets;
  const fleetUtilizationPct = Math.round((rawTrainsets / totalFleetSize) * 100);
  const avgTurnaroundMinutes = 390; // ~6.5 hours station servicing & catering reload
  const emptyStockMovementsPerDay = Math.ceil(activeServicesCount * 0.5);

  // Trainset cost ~ €28,500,000 per 12-car formation
  const capitalCostEuro = totalFleetSize * 28500000;

  return {
    activeServicesCount,
    totalTrainsetsRequired: rawTrainsets,
    maintenanceBufferTrainsets,
    totalFleetSize,
    fleetUtilizationPct,
    avgTurnaroundMinutes,
    emptyStockMovementsPerDay,
    capitalCostEuro,
  };
}

export function evaluateTrainFormation(coaches: CoachComposition[], locoPowerKw: number = 6400): TrainFormation {
  let totalBeds = 0;
  let totalSeats = 0;
  let totalWeightTons = 120; // Locomotive tare weight
  let totalLengthMeters = 22; // Loco length

  for (const c of coaches) {
    totalBeds += c.beds;
    totalSeats += c.seats;
    totalWeightTons += c.weightTons;
    totalLengthMeters += 26.4; // UIC standard car length 26.4m
  }

  return {
    id: `FORM_CUSTOM_${Date.now().toString().slice(-4)}`,
    name: `Custom Formation (${coaches.length} Coaches)`,
    locoType: 'Vectron Multi-System Electric',
    coaches,
    totalBeds,
    totalSeats,
    totalCapacity: totalBeds + totalSeats,
    totalLengthMeters: Math.round(totalLengthMeters),
    totalWeightTons: Math.round(totalWeightTons),
    locoPowerKw,
    maxSpeedKmh: totalWeightTons > 650 ? 160 : 200,
  };
}

export function getPresetCoachList(): CoachComposition[] {
  return STANDARD_COACHES;
}
