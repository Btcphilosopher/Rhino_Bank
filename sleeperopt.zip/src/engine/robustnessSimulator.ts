import { CandidateRoute, SimulationResult, TrackSection } from '../types/railway';

export function runMonteCarloDelaySimulation(
  route: CandidateRoute,
  sections: TrackSection[],
  numIterations: number = 500,
  speedReductionPct: number = 0
): SimulationResult {
  const delays: number[] = [];
  const missedConnectionsCount = 0;
  const sectionDelaySum: Record<string, number> = {};

  // Find relevant track sections
  const routeSections = sections.filter(s => route.pathEdgeIds.includes(s.id));
  routeSections.forEach(s => { sectionDelaySum[s.id] = 0; });

  for (let i = 0; i < numIterations; i++) {
    let totalDelayThisRun = 0;

    for (const section of routeSections) {
      // Stochastic delay generator using exponential / log-normal distribution model
      const baseDelay = section.typicalDelayMin;
      const randVal = Math.random();

      let sectionDelay = 0;
      if (randVal > 0.85) {
        // Severe delay event (15% probability)
        sectionDelay = baseDelay + Math.floor(Math.random() * 18 + 5);
      } else if (randVal > 0.50) {
        // Minor delay event (35% probability)
        sectionDelay = baseDelay + Math.floor(Math.random() * 5 + 1);
      } else {
        // On time or negative delay (recovering buffer)
        sectionDelay = Math.max(0, baseDelay - 1);
      }

      if (speedReductionPct > 0) {
        sectionDelay += Math.floor(speedReductionPct * 0.2);
      }

      sectionDelaySum[section.id] += sectionDelay;
      totalDelayThisRun += sectionDelay;
    }

    // Buffer absorption along the journey
    const totalBufferRecoveryMin = 15; // 15 min total timetable recovery slack
    const netDelayAtArrival = Math.max(0, totalDelayThisRun - totalBufferRecoveryMin);

    delays.push(netDelayAtArrival);
  }

  // Sort delays for percentile calculation
  delays.sort((a, b) => a - b);

  const p50Idx = Math.floor(numIterations * 0.50);
  const p80Idx = Math.floor(numIterations * 0.80);
  const p95Idx = Math.floor(numIterations * 0.95);

  const p50DelayMin = delays[p50Idx] || 0;
  const p80DelayMin = delays[p80Idx] || 0;
  const p95DelayMin = delays[p95Idx] || 0;

  const onTimeCount = delays.filter(d => d <= 5).length;
  const onTimeArrivalPct = Math.round((onTimeCount / numIterations) * 100);

  // Distribution histogram buckets (0-5m, 6-10m, 11-15m, 16-20m, 21-30m, 30m+)
  const distributionMap = new Map<number, number>([
    [0, 0], [5, 0], [10, 0], [15, 0], [20, 0], [30, 0]
  ]);

  for (const d of delays) {
    if (d <= 2) distributionMap.set(0, (distributionMap.get(0) || 0) + 1);
    else if (d <= 5) distributionMap.set(5, (distributionMap.get(5) || 0) + 1);
    else if (d <= 10) distributionMap.set(10, (distributionMap.get(10) || 0) + 1);
    else if (d <= 15) distributionMap.set(15, (distributionMap.get(15) || 0) + 1);
    else if (d <= 20) distributionMap.set(20, (distributionMap.get(20) || 0) + 1);
    else distributionMap.set(30, (distributionMap.get(30) || 0) + 1);
  }

  const delayDistribution = Array.from(distributionMap.entries()).map(([delayMin, frequency]) => ({
    delayMin,
    frequency,
  }));

  const sectionDelayHotspots = routeSections.map(s => ({
    edgeId: s.id,
    edgeName: `${s.sourceId} ↔ ${s.targetId}`,
    avgDelayMin: Math.round((sectionDelaySum[s.id] / numIterations) * 10) / 10,
  })).sort((a, b) => b.avgDelayMin - a.avgDelayMin);

  return {
    runId: `SIM_${Date.now().toString().slice(-6)}`,
    timestamp: new Date().toLocaleTimeString(),
    numIterations,
    p50DelayMin,
    p80DelayMin,
    p95DelayMin,
    onTimeArrivalPct,
    missedConnectionsCount,
    delayDistribution,
    sectionDelayHotspots,
  };
}
