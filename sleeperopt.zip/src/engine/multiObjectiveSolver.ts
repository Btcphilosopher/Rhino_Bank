import { CandidateRoute, ParetoSolution } from '../types/railway';

export interface ObjectiveWeights {
  costWeight: number; // 0.0 - 1.0
  sleepQualityWeight: number;
  robustnessWeight: number;
  revenueWeight: number;
  capacityWeight: number;
}

export function generateParetoFrontier(
  routes: CandidateRoute[],
  weights: ObjectiveWeights
): ParetoSolution[] {
  // Generate 5 candidate trade-off profiles for multi-objective Pareto analysis
  const profiles = [
    { id: 'SOL_A_PAX_MAX', name: 'Solution A: Passenger Sleep First (Max Comfort)', costMult: 1.15, sleepMult: 1.12, robMult: 1.02, revMult: 0.95, cap: 360, energy: 3800 },
    { id: 'SOL_B_COST_MIN', name: 'Solution B: Cost Minimiser (Low OpEx)', costMult: 0.82, sleepMult: 0.88, robMult: 0.85, revMult: 0.82, cap: 510, energy: 3100 },
    { id: 'SOL_C_ROBUST_HIGH', name: 'Solution C: Maximum Robustness (High Slack)', costMult: 1.08, sleepMult: 0.98, robMult: 1.18, revMult: 0.98, cap: 420, energy: 3500 },
    { id: 'SOL_D_BALANCED', name: 'Solution D: Balanced Network Pareto Optimal', costMult: 1.00, sleepMult: 1.00, robMult: 1.00, revMult: 1.00, cap: 450, energy: 3400 },
    { id: 'SOL_E_HIGH_CAPACITY', name: 'Solution E: High Capacity Corridor (Heavy Train)', costMult: 1.22, sleepMult: 0.92, robMult: 0.90, revMult: 1.25, cap: 620, energy: 4400 },
  ];

  return profiles.map((p, idx) => {
    const baseRoute = routes[0] || {
      operatingCostEuro: 31000,
      totalDistanceKm: 1200,
      sleepQualityScore: 85,
      robustnessScore: 88,
      totalRevenueEuro: 62000,
    };

    const costEuroPerKm = Math.round((baseRoute.operatingCostEuro * p.costMult / baseRoute.totalDistanceKm) * 100) / 100;
    const sleepQualityScore = Math.min(100, Math.round(baseRoute.sleepQualityScore * p.sleepMult));
    const robustnessScore = Math.min(100, Math.round(baseRoute.robustnessScore * p.robMult));
    const revenueEuro = Math.round(baseRoute.totalRevenueEuro * p.revMult);

    return {
      id: p.id,
      name: p.name,
      costEuroPerKm,
      sleepQualityScore,
      robustnessScore,
      revenueEuro,
      capacityPax: p.cap,
      energyKwh: p.energy,
      selected: idx === 3, // Solution D selected by default
    };
  });
}
