/**
 * SLEEPEROPT — Railway Engineering & Quantitative Network Optimisation Data Types
 */

export type ElectrificationType = 'AC_25KV' | 'DC_3KV' | 'DC_1_5KV' | 'DIESEL';
export type SignallingType = 'ETCS_L2' | 'PZB' | 'TVM' | 'KVB';
export type TrackType = 'SINGLE' | 'DOUBLE' | 'QUAD';
export type StationType = 'HUB' | 'MAJOR' | 'MINOR' | 'BORDER' | 'JUNCTION';

export interface Station {
  id: string;
  code: string;
  name: string;
  city: string;
  country: string;
  lat: number;
  lng: number;
  type: StationType;
  platformCapacity: number;
  openingWindow: { startHour: number; endHour: number }; // e.g. { startHour: 5, endHour: 24 }
  nightEngineeringPossession?: { startHour: number; endHour: number }; // e.g. { startHour: 1, endHour: 4 }
}

export interface TrackSection {
  id: string;
  sourceId: string;
  targetId: string;
  distanceKm: number;
  minRunningTimeMin: number;
  maxSpeedKmh: number;
  capacityTrainsPerHour: number;
  trackType: TrackType;
  electrification: ElectrificationType;
  signalling: SignallingType;
  hasBorderCrossing: boolean;
  borderInspectionMin?: number;
  gradientPct: number; // e.g. 1.2%
  typicalDelayMin: number;
  permittedTrainTypes: string[];
}

export type StopType =
  | 'major_boarding'
  | 'minor_boarding'
  | 'technical'
  | 'loco_change'
  | 'coupling_splitting'
  | 'border'
  | 'overnight_hold'
  | 'pass_through';

export interface StopDetail {
  stationId: string;
  stationName: string;
  arrivalTime: string; // HH:MM
  departureTime: string; // HH:MM
  dwellMin: number;
  stopType: StopType;
  distanceFromOriginKm: number;
  isSleepingHours: boolean; // Between 23:00 and 06:30
  nightDisruptionPenalty: number; // 0 to 10
}

export interface CoachComposition {
  id: string;
  type: 'SINGLE_SLEEPER' | 'DOUBLE_SLEEPER' | 'COUSETTE_4' | 'COUSETTE_6' | 'SEATED_1ST' | 'SEATED_2ND' | 'RESTAURANT' | 'SERVICE';
  name: string;
  beds: number;
  seats: number;
  weightTons: number;
  costEuro: number;
}

export interface TrainFormation {
  id: string;
  name: string;
  locoType: string;
  coaches: CoachComposition[];
  totalBeds: number;
  totalSeats: number;
  totalCapacity: number;
  totalLengthMeters: number;
  totalWeightTons: number;
  locoPowerKw: number;
  maxSpeedKmh: number;
}

export type RobustnessRating = 'ROBUST' | 'FRAGILE' | 'INFEASIBLE';

export interface CandidateRoute {
  id: string;
  name: string;
  originId: string;
  originName: string;
  destinationId: string;
  destinationName: string;
  pathStationIds: string[];
  pathEdgeIds: string[];
  totalDistanceKm: number;
  pureRunningTimeMin: number;
  scheduledDepartureTime: string; // e.g. "20:30"
  scheduledArrivalTime: string; // e.g. "08:15"
  totalJourneyTimeMin: number;
  sleepDurationHours: number; // e.g. 7.5
  stops: StopDetail[];
  
  // Quantitative Evaluation Metrics
  sleepQualityScore: number; // 0 - 100
  nightDisruptionScore: number; // 0 - 100 (lower is better)
  robustnessRating: RobustnessRating;
  robustnessScore: number; // 0 - 100
  
  // Economics & Demand
  estimatedPaxDemand: number;
  avgFareEuro: number;
  totalRevenueEuro: number;
  operatingCostEuro: number;
  netMarginEuro: number;
  breakEvenOccupancyPct: number;
  co2SavedVsFlightKg: number;
  
  // Operational Parameters
  formation: TrainFormation;
  requiredTrainsets: number;
  hasCouplingPortion: boolean;
  couplingHubId?: string;
}

export type ConflictType =
  | 'headway_violation'
  | 'platform_overflow'
  | 'single_track_crossing'
  | 'engineering_possession'
  | 'border_delay';

export interface TimeSpaceConflict {
  id: string;
  trainAId: string;
  trainAName: string;
  trainBId: string;
  trainBName: string;
  locationId: string;
  locationName: string;
  timeSlot: string; // e.g. "02:15 - 02:22"
  conflictType: ConflictType;
  requiredBufferMin: number;
  actualBufferMin: number;
  proposedResolution: string;
  severity: 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface SimulationResult {
  runId: string;
  timestamp: string;
  numIterations: number;
  p50DelayMin: number;
  p80DelayMin: number;
  p95DelayMin: number;
  onTimeArrivalPct: number;
  missedConnectionsCount: number;
  delayDistribution: { delayMin: number; frequency: number }[];
  sectionDelayHotspots: { edgeId: string; edgeName: string; avgDelayMin: number }[];
}

export interface ParetoSolution {
  id: string;
  name: string;
  costEuroPerKm: number;
  sleepQualityScore: number;
  robustnessScore: number;
  revenueEuro: number;
  capacityPax: number;
  energyKwh: number;
  selected: boolean;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  demandMultiplier: number;
  energyCostMultiplier: number;
  trackAccessMultiplier: number;
  closedStations: string[];
  restrictedEdges: string[];
  speedReductionPct: number;
  active: boolean;
}

export interface ResearchEntry {
  id: string;
  title: string;
  date: string;
  hypothesis: string;
  scenarioName: string;
  routeId: string;
  solverVersion: string;
  metrics: {
    paxDemand: number;
    costEuro: number;
    sleepQuality: number;
    robustnessScore: number;
  };
  conclusion: string;
}
