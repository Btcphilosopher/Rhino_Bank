import React, { useState, useMemo } from 'react';
import { TopBar, ActiveTab } from './components/TopBar';
import { NetworkMap } from './components/NetworkMap';
import { RouteDesigner } from './components/RouteDesigner';
import { TimetableEditor } from './components/TimetableEditor';
import { TimeSpaceGraph } from './components/TimeSpaceGraph';
import { RollingStockView } from './components/RollingStockView';
import { DemandEconomicsView } from './components/DemandEconomicsView';
import { DelaySimulatorView } from './components/DelaySimulatorView';
import { ParetoFrontierView } from './components/ParetoFrontierView';
import { ScenarioLab } from './components/ScenarioLab';
import { ResearchNotebookView } from './components/ResearchNotebookView';
import { ApiCliConsole } from './components/ApiCliConsole';
import { RouteInspectorModal } from './components/RouteInspectorModal';

import { EUROPEAN_STATIONS, EUROPEAN_TRACK_SECTIONS, INITIAL_CANDIDATE_ROUTES, INITIAL_SCENARIOS } from './data/europeanNetwork';
import { CandidateRoute, Scenario, TimeSpaceConflict } from './types/railway';
import { detectTimetableConflicts } from './engine/timetableOptimiser';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('NETWORK');
  const [scenarios, setScenarios] = useState<Scenario[]>(INITIAL_SCENARIOS);
  const [activeScenario, setActiveScenario] = useState<Scenario>(INITIAL_SCENARIOS[0]);

  const [candidateRoutes, setCandidateRoutes] = useState<CandidateRoute[]>(INITIAL_CANDIDATE_ROUTES);
  const [selectedRouteId, setSelectedRouteId] = useState<string>(INITIAL_CANDIDATE_ROUTES[0].id);
  const [inspectedRoute, setInspectedRoute] = useState<CandidateRoute | null>(null);

  const [isOptimising, setIsOptimising] = useState(false);

  // Active Selected Route
  const activeRoute = useMemo(() => {
    return candidateRoutes.find(r => r.id === selectedRouteId) || candidateRoutes[0];
  }, [candidateRoutes, selectedRouteId]);

  // Recalculate Time-Space Conflicts across all active candidate routes
  const conflicts: TimeSpaceConflict[] = useMemo(() => {
    return detectTimetableConflicts(candidateRoutes, EUROPEAN_STATIONS, EUROPEAN_TRACK_SECTIONS);
  }, [candidateRoutes]);

  // Global Solver Trigger
  const handleRunGlobalOptimiser = () => {
    setIsOptimising(true);
    setTimeout(() => {
      // Re-evaluate routes with slight optimization adjustments
      const optimized = candidateRoutes.map(route => ({
        ...route,
        sleepQualityScore: Math.min(100, route.sleepQualityScore + 2),
        robustnessScore: Math.min(100, route.robustnessScore + 3),
        robustnessRating: 'ROBUST' as const,
      }));
      setCandidateRoutes(optimized);
      setIsOptimising(false);
    }, 600);
  };

  // Add Route from Generator
  const handleAddGeneratedRoute = (route: CandidateRoute) => {
    setCandidateRoutes([...candidateRoutes, route]);
    setSelectedRouteId(route.id);
    setActiveTab('NETWORK');
  };

  // Update Timetable from Editor
  const handleUpdateRouteTimetable = (updatedRoute: CandidateRoute) => {
    setCandidateRoutes(candidateRoutes.map(r => r.id === updatedRoute.id ? updatedRoute : r));
  };

  // Scenario Selection
  const handleSelectScenario = (scenario: Scenario) => {
    setActiveScenario(scenario);
    setScenarios(scenarios.map(s => ({ ...s, active: s.id === scenario.id })));
  };

  // Scenario Duplication
  const handleDuplicateScenario = (scenario: Scenario) => {
    const dup: Scenario = {
      ...scenario,
      id: `SC_CUSTOM_${Date.now().toString().slice(-4)}`,
      name: `${scenario.name} (Copy)`,
      active: false,
    };
    setScenarios([...scenarios, dup]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Primary Top Bar */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeScenario={activeScenario}
        onRunGlobalOptimiser={handleRunGlobalOptimiser}
        isOptimising={isOptimising}
      />

      {/* Primary Screen Router */}
      <main className="flex-1">
        {activeTab === 'NETWORK' && (
          <NetworkMap
            stations={EUROPEAN_STATIONS}
            trackSections={EUROPEAN_TRACK_SECTIONS}
            candidateRoutes={candidateRoutes}
            conflicts={conflicts}
            selectedRouteId={selectedRouteId}
            onSelectRoute={setSelectedRouteId}
            onInspectRoute={setInspectedRoute}
          />
        )}

        {activeTab === 'ROUTE_DESIGNER' && (
          <RouteDesigner
            stations={EUROPEAN_STATIONS}
            trackSections={EUROPEAN_TRACK_SECTIONS}
            onAddGeneratedRoute={handleAddGeneratedRoute}
          />
        )}

        {activeTab === 'TIMETABLE' && (
          <TimetableEditor
            activeRoute={activeRoute}
            stations={EUROPEAN_STATIONS}
            conflicts={conflicts}
            onUpdateRouteTimetable={handleUpdateRouteTimetable}
          />
        )}

        {activeTab === 'TIME_SPACE' && (
          <TimeSpaceGraph
            candidateRoutes={candidateRoutes}
            stations={EUROPEAN_STATIONS}
            conflicts={conflicts}
            onSelectConflict={(conf) => {
              const r = candidateRoutes.find(cr => cr.id === conf.trainAId || cr.id === conf.trainBId);
              if (r) setInspectedRoute(r);
            }}
          />
        )}

        {activeTab === 'ROLLING_STOCK' && (
          <RollingStockView
            candidateRoutes={candidateRoutes}
          />
        )}

        {activeTab === 'DEMAND_ECONOMICS' && (
          <DemandEconomicsView
            activeRoute={activeRoute}
            activeScenario={activeScenario}
          />
        )}

        {activeTab === 'ROBUSTNESS_SIM' && (
          <DelaySimulatorView
            activeRoute={activeRoute}
            trackSections={EUROPEAN_TRACK_SECTIONS}
          />
        )}

        {activeTab === 'PARETO_OPTIMISER' && (
          <ParetoFrontierView
            candidateRoutes={candidateRoutes}
          />
        )}

        {activeTab === 'SCENARIOS' && (
          <ScenarioLab
            scenarios={scenarios}
            activeScenario={activeScenario}
            onSelectScenario={handleSelectScenario}
            onDuplicateScenario={handleDuplicateScenario}
          />
        )}

        {activeTab === 'RESEARCH_NOTEBOOK' && (
          <ResearchNotebookView />
        )}

        {activeTab === 'API_CLI' && (
          <ApiCliConsole />
        )}
      </main>

      {/* Deep-Dive Route Inspector Modal */}
      <RouteInspectorModal
        route={inspectedRoute}
        stations={EUROPEAN_STATIONS}
        onClose={() => setInspectedRoute(null)}
      />
    </div>
  );
}
