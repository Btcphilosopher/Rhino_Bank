import React, { useState } from 'react';
import { Station, TrackSection, CandidateRoute, TimeSpaceConflict } from '../types/railway';
import { TrainTrack, MapPin, AlertTriangle, ShieldCheck, Zap, ArrowRight, Layers } from 'lucide-react';

interface NetworkMapProps {
  stations: Station[];
  trackSections: TrackSection[];
  candidateRoutes: CandidateRoute[];
  conflicts: TimeSpaceConflict[];
  selectedRouteId: string | null;
  onSelectRoute: (routeId: string) => void;
  onInspectRoute: (route: CandidateRoute) => void;
}

export const NetworkMap: React.FC<NetworkMapProps> = ({
  stations,
  trackSections,
  candidateRoutes,
  conflicts,
  selectedRouteId,
  onSelectRoute,
  onInspectRoute,
}) => {
  const [hoveredStation, setHoveredStation] = useState<Station | null>(null);
  const [hoveredRoute, setHoveredRoute] = useState<CandidateRoute | null>(null);

  // SVG Geographic projection bounds for Western & Central Europe
  // Lat: 40 (Madrid) to 56 (Copenhagen)
  // Lng: -4 (Madrid) to 20 (Budapest)
  const mapWidth = 900;
  const mapHeight = 650;

  const projectCoords = (lat: number, lng: number) => {
    const minLat = 40.0;
    const maxLat = 56.5;
    const minLng = -4.5;
    const maxLng = 20.5;

    const x = ((lng - minLng) / (maxLng - minLng)) * mapWidth;
    // Invert Y for latitude
    const y = mapHeight - ((lat - minLat) / (maxLat - minLat)) * mapHeight;

    return { x, y };
  };

  const stationMap = new Map(stations.map(s => [s.id, s]));

  // Selected Route Details
  const activeRoute = candidateRoutes.find(r => r.id === selectedRouteId) || candidateRoutes[0];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-6 min-h-[calc(100vh-100px)] bg-slate-950">
      {/* Map Visualiser Area */}
      <div className="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-lg p-5 flex flex-col relative overflow-hidden rail-grid-bg">
        {/* Header Overlay */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4 z-10">
          <div>
            <h2 className="text-sm font-bold tracking-tight text-slate-100 uppercase font-display flex items-center gap-2">
              <TrainTrack className="w-4 h-4 text-blue-500" />
              European Railway Network Model (2035 Infrastructure Graph)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              32 Major European Hubs · {trackSections.length} Track Corridors · ETCS L2 & TVM Signalling
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> Active Sleeper Route</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-slate-600"></span> Track Section</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Border Control</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-red-500"></span> Conflict Hotspot</span>
          </div>
        </div>

        {/* SVG Interactive Canvas */}
        <div className="relative flex-1 flex items-center justify-center min-h-[500px]">
          <svg viewBox={`0 0 ${mapWidth} ${mapHeight}`} className="w-full h-full max-h-[600px] select-none">
            {/* Draw Base Track Sections */}
            {trackSections.map((section) => {
              const src = stationMap.get(section.sourceId);
              const tgt = stationMap.get(section.targetId);
              if (!src || !tgt) return null;

              const p1 = projectCoords(src.lat, src.lng);
              const p2 = projectCoords(tgt.lat, tgt.lng);

              const isHighlighted = activeRoute?.pathEdgeIds.includes(section.id);

              return (
                <g key={section.id}>
                  <line
                    x1={p1.x}
                    y1={p1.y}
                    x2={p2.x}
                    y2={p2.y}
                    stroke={isHighlighted ? '#3b82f6' : '#334155'}
                    strokeWidth={isHighlighted ? 3.5 : 1.5}
                    strokeDasharray={section.trackType === 'SINGLE' ? '4,4' : undefined}
                    opacity={isHighlighted ? 1 : 0.6}
                    className="transition-all duration-300"
                  />
                  {section.hasBorderCrossing && (
                    <circle
                      cx={(p1.x + p2.x) / 2}
                      cy={(p1.y + p2.y) / 2}
                      r={3.5}
                      fill="#f59e0b"
                      className="animate-pulse"
                    />
                  )}
                </g>
              );
            })}

            {/* Draw Station Nodes */}
            {stations.map((station) => {
              const { x, y } = projectCoords(station.lat, station.lng);
              const isSelectedRouteStop = activeRoute?.pathStationIds.includes(station.id);
              const isOriginOrDest = activeRoute?.originId === station.id || activeRoute?.destinationId === station.id;

              let nodeColor = '#64748b'; // default slate
              if (isOriginOrDest) nodeColor = '#3b82f6';
              else if (isSelectedRouteStop) nodeColor = '#60a5fa';
              else if (station.type === 'HUB') nodeColor = '#e2e8f0';

              return (
                <g
                  key={station.id}
                  className="cursor-pointer group"
                  onMouseEnter={() => setHoveredStation(station)}
                  onMouseLeave={() => setHoveredStation(null)}
                >
                  <circle
                    cx={x}
                    cy={y}
                    r={isOriginOrDest ? 7 : station.type === 'HUB' ? 5 : 3.5}
                    fill={nodeColor}
                    stroke="#0f172a"
                    strokeWidth={2}
                    className="transition-all duration-200 group-hover:scale-125"
                  />
                  {/* Station Label */}
                  <text
                    x={x + 8}
                    y={y + 4}
                    fill={isSelectedRouteStop ? '#f8fafc' : '#94a3b8'}
                    fontSize={station.type === 'HUB' ? 11 : 9}
                    fontWeight={isOriginOrDest ? 'bold' : 'medium'}
                    className="font-sans pointer-events-none drop-shadow"
                  >
                    {station.city}
                  </text>
                </g>
              );
            })}

            {/* Conflict Hotspots Overlays */}
            {conflicts.map((conf) => {
              const stn = stationMap.get(conf.locationId);
              if (!stn) return null;
              const { x, y } = projectCoords(stn.lat, stn.lng);

              return (
                <g key={conf.id} className="animate-bounce">
                  <circle cx={x} cy={y} r={10} fill="#ef4444" opacity={0.3} />
                  <circle cx={x} cy={y} r={5} fill="#ef4444" />
                </g>
              );
            })}
          </svg>

          {/* Hover Tooltip Overlay */}
          {hoveredStation && (
            <div className="absolute top-4 left-4 bg-slate-900/95 border border-slate-700 text-slate-100 p-3 rounded-md shadow-xl text-xs backdrop-blur z-20 max-w-xs">
              <div className="font-bold text-sm text-blue-400 font-display">{hoveredStation.name}</div>
              <div className="text-slate-400 mt-1">{hoveredStation.city}, {hoveredStation.country}</div>
              <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800 text-[11px] font-mono">
                <div>Type: <span className="text-slate-200">{hoveredStation.type}</span></div>
                <div>Platforms: <span className="text-slate-200">{hoveredStation.platformCapacity}</span></div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Side Panel: Active Sleeper Route Inspector & Candidate Route Selector */}
      <div className="lg:col-span-4 flex flex-col gap-5">
        {/* Route Selector List */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <h3 className="text-xs font-bold uppercase text-slate-400 tracking-wider mb-3 font-display">
            Candidate Overnight Services ({candidateRoutes.length})
          </h3>

          <div className="space-y-2.5">
            {candidateRoutes.map((route) => {
              const isSelected = route.id === activeRoute?.id;
              return (
                <div
                  key={route.id}
                  onClick={() => onSelectRoute(route.id)}
                  className={`p-3 rounded-md border text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-950/40 border-blue-500/60 shadow-md shadow-blue-950/30'
                      : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/50 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
                    <span className="truncate pr-2">{route.name}</span>
                    <span className="font-mono text-blue-400 shrink-0">€{route.avgFareEuro}</span>
                  </div>

                  <div className="flex items-center justify-between mt-2 text-[11px] text-slate-400 font-mono">
                    <span>{route.scheduledDepartureTime} → {route.scheduledArrivalTime}</span>
                    <span>{route.sleepDurationHours}h Sleep</span>
                  </div>

                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/60 text-[10px]">
                    <span className="text-slate-400">{route.totalDistanceKm} km</span>
                    <span className={`font-semibold ${route.robustnessRating === 'ROBUST' ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {route.robustnessRating} ({route.robustnessScore}/100)
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Route Detailed Briefing Card */}
        {activeRoute && (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <span className="text-[10px] font-bold tracking-widest text-blue-400 uppercase">Selected Service</span>
                  <h3 className="text-base font-bold text-slate-100 font-display mt-0.5">{activeRoute.name}</h3>
                </div>
                <button
                  onClick={() => onInspectRoute(activeRoute)}
                  className="px-3 py-1.5 text-xs font-semibold text-blue-400 bg-blue-950/60 hover:bg-blue-900/60 border border-blue-800/60 rounded transition cursor-pointer flex items-center gap-1"
                >
                  <span>Inspect</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              {/* Key Quantitative Metrics Grid */}
              <div className="grid grid-cols-2 gap-3 my-4 text-xs font-mono">
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase">Sleep Quality</div>
                  <div className="text-lg font-bold text-emerald-400 mt-0.5">{activeRoute.sleepQualityScore} / 100</div>
                </div>
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase">Night Disruption</div>
                  <div className="text-lg font-bold text-amber-400 mt-0.5">{activeRoute.nightDisruptionScore} / 100</div>
                </div>
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase">Daily Pax Demand</div>
                  <div className="text-lg font-bold text-blue-400 mt-0.5">{activeRoute.estimatedPaxDemand} pax</div>
                </div>
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase">Net Revenue / Night</div>
                  <div className="text-lg font-bold text-slate-100 mt-0.5">€{activeRoute.netMarginEuro.toLocaleString()}</div>
                </div>
              </div>

              {/* Stop Detail Sequence */}
              <div className="space-y-1.5 mt-3">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">Stop Pattern ({activeRoute.stops.length} stations)</div>
                {activeRoute.stops.map((stop, i) => (
                  <div key={i} className="flex items-center justify-between text-xs py-1.5 px-2 bg-slate-950/50 rounded border border-slate-800/60">
                    <div className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      <span className="font-semibold text-slate-200">{stop.stationName}</span>
                    </div>
                    <div className="font-mono text-slate-400 text-[11px]">
                      {stop.arrivalTime} - {stop.departureTime}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-500 font-mono flex items-center justify-between">
              <span>Formation: {activeRoute.formation.name}</span>
              <span>Fleet: {activeRoute.requiredTrainsets} sets</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
