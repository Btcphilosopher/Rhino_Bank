import React from 'react';
import { CandidateRoute, Station } from '../types/railway';
import { X, Moon, Clock, DollarSign, TrainTrack, ShieldCheck, Download } from 'lucide-react';

interface RouteInspectorModalProps {
  route: CandidateRoute | null;
  stations: Station[];
  onClose: () => void;
}

export const RouteInspectorModal: React.FC<RouteInspectorModalProps> = ({
  route,
  stations,
  onClose,
}) => {
  if (!route) return null;

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(route, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `sleeperopt_${route.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 flex flex-col justify-between shadow-2xl">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest font-mono">Service Inspector</span>
              <h2 className="text-lg font-bold text-slate-100 font-display mt-0.5">{route.name}</h2>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleExportJSON}
                className="px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded transition cursor-pointer flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export JSON Report</span>
              </button>

              <button
                onClick={onClose}
                className="p-1 text-slate-400 hover:text-slate-100 bg-slate-800 rounded border border-slate-700 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Key Metrics Overview */}
          <div className="grid grid-cols-4 gap-3 my-5 text-xs font-mono text-center">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Sleep Quality</div>
              <div className="text-lg font-bold text-emerald-400 mt-0.5">{route.sleepQualityScore} / 100</div>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Sleep Window</div>
              <div className="text-lg font-bold text-indigo-400 mt-0.5">{route.sleepDurationHours} hours</div>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Daily Pax Demand</div>
              <div className="text-lg font-bold text-blue-400 mt-0.5">{route.estimatedPaxDemand} pax</div>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Net Margin / Night</div>
              <div className="text-lg font-bold text-slate-100 mt-0.5">€{route.netMarginEuro.toLocaleString()}</div>
            </div>
          </div>

          {/* Stop Pattern Timeline */}
          <div className="space-y-2 mt-4">
            <h3 className="text-xs font-bold uppercase text-slate-300 font-display tracking-wider mb-2">Detailed Stop & Station Sequence</h3>
            {route.stops.map((stop, i) => (
              <div key={i} className="flex items-center justify-between p-2.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono">
                <div className="flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  <span className="font-bold text-slate-200">{stop.stationName}</span>
                  <span className="text-slate-500 text-[10px] uppercase">({stop.stopType})</span>
                </div>

                <div className="flex items-center gap-4 text-[11px]">
                  <span className="text-slate-400">{stop.arrivalTime} - {stop.departureTime} ({stop.dwellMin}m dwell)</span>
                  <span className="text-slate-500">{stop.distanceFromOriginKm} km</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-3 border-t border-slate-800 text-[11px] font-mono text-slate-500 flex justify-between">
          <span>Formation: {route.formation.name}</span>
          <span>Required Trainsets: {route.requiredTrainsets}</span>
        </div>
      </div>
    </div>
  );
};
