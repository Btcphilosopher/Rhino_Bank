import React, { useState } from 'react';
import { ResearchEntry } from '../types/railway';
import { BookOpen, Plus, Save, Trash2, CheckCircle2 } from 'lucide-react';

export const ResearchNotebookView: React.FC = () => {
  const [entries, setEntries] = useState<ResearchEntry[]>([
    {
      id: 'EXP_001',
      title: 'Trans-Alpine Sleeper Window Optimization (London to Milan)',
      date: '2026-10-04',
      hypothesis: 'Holding the train for 35 minutes at Zurich HB during 03:00 AM will increase passenger sleep quality score from 74 to 88 with minimal impact on 07:30 AM arrival.',
      scenarioName: 'Base European Network 2035',
      routeId: 'R_LON_PAR_MIL',
      solverVersion: 'SLEEPEROPT v3.4 CP-SAT',
      metrics: {
        paxDemand: 385,
        costEuro: 31200,
        sleepQuality: 88,
        robustnessScore: 91,
      },
      conclusion: 'Hypothesis confirmed. Passenger Sleep Quality score rose by +14 pts. Delay buffer at Zurich absorbed minor tunnel speed restrictions.',
    },
    {
      id: 'EXP_002',
      title: 'Rhine Corridor Capacity Stress Test under Single-Track Possessions',
      date: '2026-10-03',
      hypothesis: 'Overnight maintenance on Cologne-Frankfurt track section will cause 2 headway conflicts between Nightjet and freight paths.',
      scenarioName: 'Rhine Valley Night Possessions',
      routeId: 'R_AMS_COL_VIE',
      solverVersion: 'SLEEPEROPT v3.4 CP-SAT',
      metrics: {
        paxDemand: 410,
        costEuro: 29800,
        sleepQuality: 82,
        robustnessScore: 68,
      },
      conclusion: 'Conflicts resolved by retarding Nightjet departure at Cologne by +12 minutes. Schedule robustness dropped to FRAGILE (68 pts).',
    }
  ]);

  const [newTitle, setNewTitle] = useState('');
  const [newHypothesis, setNewHypothesis] = useState('');
  const [newConclusion, setNewConclusion] = useState('');

  const handleAddEntry = () => {
    if (!newTitle) return;

    const entry: ResearchEntry = {
      id: `EXP_00${entries.length + 1}`,
      title: newTitle,
      date: new Date().toISOString().split('T')[0],
      hypothesis: newHypothesis || 'Testing network response under modified operational parameters.',
      scenarioName: 'Active Research Trial',
      routeId: 'R_LON_PAR_MIL',
      solverVersion: 'SLEEPEROPT v3.4',
      metrics: {
        paxDemand: 400,
        costEuro: 30000,
        sleepQuality: 85,
        robustnessScore: 88,
      },
      conclusion: newConclusion || 'Experiment logged successfully.',
    };

    setEntries([entry, ...entries]);
    setNewTitle('');
    setNewHypothesis('');
    setNewConclusion('');
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] flex flex-col gap-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Quantitative Research Log</span>
          <h2 className="text-base font-bold text-slate-100 font-display mt-0.5">Railway Network Research Notebook</h2>
          <p className="text-xs text-slate-400 mt-1">
            Record hypotheses, scenario configurations, solver outcomes, and quantitative conclusions for peer review.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* New Experiment Entry Form */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold uppercase text-slate-300 font-display tracking-wider mb-4 flex items-center gap-2">
              <Plus className="w-4 h-4 text-blue-400" />
              Log New Research Experiment
            </h3>

            <div className="space-y-3 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-1 text-[10px] uppercase">Experiment Title</label>
                <input
                  type="text"
                  placeholder="e.g. Couchette Capacity Expansion on Paris-Vienna..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 text-[10px] uppercase">Hypothesis</label>
                <textarea
                  rows={3}
                  placeholder="Formulate expected impact on sleep quality or cost..."
                  value={newHypothesis}
                  onChange={(e) => setNewHypothesis(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 text-[10px] uppercase">Conclusion & Findings</label>
                <textarea
                  rows={3}
                  placeholder="Quantitative outcome summary..."
                  value={newConclusion}
                  onChange={(e) => setNewConclusion(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          <button
            onClick={handleAddEntry}
            className="mt-4 w-full py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded transition cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Commit Experiment Entry</span>
          </button>
        </div>

        {/* Experiment Log List */}
        <div className="lg:col-span-7 space-y-4">
          {entries.map((entry) => (
            <div key={entry.id} className="bg-slate-900 border border-slate-800 rounded-lg p-5">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold font-mono text-blue-400 bg-blue-950 border border-blue-800 px-2 py-0.5 rounded">
                    {entry.id}
                  </span>
                  <h3 className="text-xs font-bold text-slate-100 font-display">{entry.title}</h3>
                </div>
                <span className="text-[11px] font-mono text-slate-500">{entry.date}</span>
              </div>

              <div className="my-3 space-y-2 text-xs font-mono text-slate-300">
                <div><span className="text-slate-500 uppercase font-bold text-[10px]">Hypothesis:</span> {entry.hypothesis}</div>
                <div><span className="text-slate-500 uppercase font-bold text-[10px]">Findings:</span> {entry.conclusion}</div>
              </div>

              <div className="grid grid-cols-4 gap-2 pt-3 border-t border-slate-800 text-center font-mono text-xs">
                <div className="bg-slate-950 p-1.5 rounded">
                  <span className="text-[9px] text-slate-500 block">Sleep Q</span>
                  <span className="font-bold text-emerald-400">{entry.metrics.sleepQuality}/100</span>
                </div>
                <div className="bg-slate-950 p-1.5 rounded">
                  <span className="text-[9px] text-slate-500 block">Robustness</span>
                  <span className="font-bold text-amber-400">{entry.metrics.robustnessScore}/100</span>
                </div>
                <div className="bg-slate-950 p-1.5 rounded">
                  <span className="text-[9px] text-slate-500 block">Pax Demand</span>
                  <span className="font-bold text-blue-400">{entry.metrics.paxDemand}</span>
                </div>
                <div className="bg-slate-950 p-1.5 rounded">
                  <span className="text-[9px] text-slate-500 block">Cost</span>
                  <span className="font-bold text-slate-200">€{(entry.metrics.costEuro/1000).toFixed(1)}k</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
