import React, { useState } from 'react';
import { CandidateRoute, Station, TimeSpaceConflict } from '../types/railway';
import { Clock, AlertTriangle, CheckCircle, RefreshCw, Save } from 'lucide-react';

interface TimetableEditorProps {
  activeRoute: CandidateRoute;
  stations: Station[];
  conflicts: TimeSpaceConflict[];
  onUpdateRouteTimetable: (updatedRoute: CandidateRoute) => void;
}

export const TimetableEditor: React.FC<TimetableEditorProps> = ({
  activeRoute,
  stations,
  conflicts,
  onUpdateRouteTimetable,
}) => {
  const [editedStops, setEditedStops] = useState(activeRoute.stops);

  const handleTimeChange = (index: number, field: 'arrivalTime' | 'departureTime', value: string) => {
    const updated = [...editedStops];
    updated[index] = { ...updated[index], [field]: value };
    setEditedStops(updated);
  };

  const handleSaveAndRecalculate = () => {
    const updatedRoute = { ...activeRoute, stops: editedStops };
    onUpdateRouteTimetable(updatedRoute);
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] flex flex-col gap-5">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Interactive Timetable Editor</span>
          <h2 className="text-base font-bold text-slate-100 font-display mt-0.5">{activeRoute.name}</h2>
          <p className="text-xs text-slate-400 mt-1">
            Edit arrival/departure slots below. Timetable engine immediately recalculates platform capacity, headways, and sleep window validity.
          </p>
        </div>

        <button
          onClick={handleSaveAndRecalculate}
          className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded transition cursor-pointer flex items-center gap-2 shadow-sm shadow-blue-900/50"
        >
          <Save className="w-4 h-4" />
          <span>Recalculate Timetable Feasibility</span>
        </button>
      </div>

      {/* Timetable Grid Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800 text-[11px]">
            <tr>
              <th className="py-3 px-4">Seq</th>
              <th className="py-3 px-4">Station</th>
              <th className="py-3 px-4">Arrival</th>
              <th className="py-3 px-4">Departure</th>
              <th className="py-3 px-4">Dwell</th>
              <th className="py-3 px-4">Stop Type</th>
              <th className="py-3 px-4">Distance</th>
              <th className="py-3 px-4">Sleep Window</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {editedStops.map((stop, idx) => {
              const isOrigin = idx === 0;
              const isDest = idx === editedStops.length - 1;

              return (
                <tr key={idx} className="hover:bg-slate-850/50 transition">
                  <td className="py-3 px-4 text-slate-500">#{idx + 1}</td>
                  <td className="py-3 px-4 font-bold text-slate-100">{stop.stationName}</td>

                  {/* Arrival Input */}
                  <td className="py-2 px-4">
                    {isOrigin ? (
                      <span className="text-slate-500">—</span>
                    ) : (
                      <input
                        type="text"
                        value={stop.arrivalTime}
                        onChange={(e) => handleTimeChange(idx, 'arrivalTime', e.target.value)}
                        className="bg-slate-950 border border-slate-800 focus:border-blue-500 rounded px-2 py-1 text-xs text-blue-400 font-bold w-20 text-center"
                      />
                    )}
                  </td>

                  {/* Departure Input */}
                  <td className="py-2 px-4">
                    {isDest ? (
                      <span className="text-slate-500">—</span>
                    ) : (
                      <input
                        type="text"
                        value={stop.departureTime}
                        onChange={(e) => handleTimeChange(idx, 'departureTime', e.target.value)}
                        className="bg-slate-950 border border-slate-800 focus:border-blue-500 rounded px-2 py-1 text-xs text-emerald-400 font-bold w-20 text-center"
                      />
                    )}
                  </td>

                  <td className="py-3 px-4 text-slate-400">{stop.dwellMin} min</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      stop.stopType === 'major_boarding' ? 'bg-blue-950 text-blue-400 border border-blue-800' :
                      stop.stopType === 'border' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {stop.stopType.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">{stop.distanceFromOriginKm} km</td>
                  <td className="py-3 px-4">
                    {stop.isSleepingHours ? (
                      <span className="text-indigo-400 font-bold text-[11px]">Night Window</span>
                    ) : (
                      <span className="text-slate-500 text-[11px]">Daylight</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
