import React, { useState } from 'react';
import { CandidateRoute, CoachComposition, TrainFormation } from '../types/railway';
import { calculateFleetSizing, evaluateTrainFormation, getPresetCoachList } from '../engine/rollingStockOptimiser';
import { TrainFront, Plus, Trash2, Layers, GitFork, ArrowRight } from 'lucide-react';

interface RollingStockViewProps {
  candidateRoutes: CandidateRoute[];
}

export const RollingStockView: React.FC<RollingStockViewProps> = ({
  candidateRoutes,
}) => {
  const fleetInfo = calculateFleetSizing(candidateRoutes);
  const availableCoaches = getPresetCoachList();

  const [selectedCoaches, setSelectedCoaches] = useState<CoachComposition[]>([
    availableCoaches[0], // Deluxe
    availableCoaches[1], availableCoaches[1], // 2x Double
    availableCoaches[2], availableCoaches[2], // 2x Couchette 4
    availableCoaches[6], // Restaurant
    availableCoaches[4], // Seated
  ]);

  const customFormation = evaluateTrainFormation(selectedCoaches);

  const handleAddCoach = (coach: CoachComposition) => {
    setSelectedCoaches([...selectedCoaches, coach]);
  };

  const handleRemoveCoach = (index: number) => {
    const updated = [...selectedCoaches];
    updated.splice(index, 1);
    setSelectedCoaches(updated);
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] flex flex-col gap-6">
      {/* Fleet Overview Header Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Active Trainsets Needed</div>
          <div className="text-2xl font-bold text-blue-400 font-display mt-1">{fleetInfo.totalTrainsetsRequired} Sets</div>
          <div className="text-xs text-slate-400 mt-1 font-mono">For {fleetInfo.activeServicesCount} overnight routes</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Maintenance Buffer</div>
          <div className="text-2xl font-bold text-amber-400 font-display mt-1">+{fleetInfo.maintenanceBufferTrainsets} Sets</div>
          <div className="text-xs text-slate-400 mt-1 font-mono">15% overhaul reserve</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Total Fleet Size</div>
          <div className="text-2xl font-bold text-emerald-400 font-display mt-1">{fleetInfo.totalFleetSize} Trainsets</div>
          <div className="text-xs text-slate-400 mt-1 font-mono">{fleetInfo.fleetUtilizationPct}% utilisation rate</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Fleet Capital Expense</div>
          <div className="text-2xl font-bold text-slate-100 font-display mt-1">€{(fleetInfo.capitalCostEuro / 1000000).toFixed(1)}M</div>
          <div className="text-xs text-slate-400 mt-1 font-mono">2035 rolling stock asset base</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Interactive Train Formation Builder */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h2 className="text-sm font-bold text-slate-100 uppercase font-display tracking-tight flex items-center gap-2">
                <TrainFront className="w-4 h-4 text-blue-500" />
                Train Formation & Composition Optimiser
              </h2>
              <span className="text-xs font-mono text-slate-400">Total Cars: {selectedCoaches.length} + 1 Locomotive</span>
            </div>

            {/* Visual Trainset Schematic Bar */}
            <div className="bg-slate-950 p-4 rounded-md border border-slate-800 overflow-x-auto mb-6">
              <div className="flex items-center gap-1.5 min-w-[650px] py-2">
                {/* Locomotive */}
                <div className="bg-blue-600 text-white p-2.5 rounded text-[10px] font-bold font-mono text-center shrink-0 w-24 shadow">
                  LOCO (6.4MW)
                </div>

                {/* Coaches */}
                {selectedCoaches.map((c, i) => (
                  <div
                    key={i}
                    className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 p-2 rounded text-[10px] font-mono text-center shrink-0 w-28 relative group transition"
                  >
                    <button
                      onClick={() => handleRemoveCoach(i)}
                      className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                    <div className="font-bold truncate">{c.name.split(' ')[0]}</div>
                    <div className="text-slate-400 text-[9px] mt-0.5">{c.beds > 0 ? `${c.beds} beds` : `${c.seats} seats`}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Available Coach Presets to Add */}
            <div className="text-xs font-mono mb-2 text-slate-400 uppercase font-bold">Add Coach Type to Formation</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {availableCoaches.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleAddCoach(c)}
                  className="p-2.5 bg-slate-950 border border-slate-800 hover:border-blue-500/60 rounded text-left transition cursor-pointer"
                >
                  <div className="font-bold text-slate-200 text-xs truncate">{c.name}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{c.beds > 0 ? `${c.beds} Beds` : `${c.seats} Seats`} · {c.weightTons}t</div>
                </button>
              ))}
            </div>
          </div>

          {/* Computed Formation Metrics Bar */}
          <div className="grid grid-cols-4 gap-3 mt-6 pt-4 border-t border-slate-800 text-xs font-mono text-center">
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Total Beds</div>
              <div className="text-emerald-400 font-bold text-sm">{customFormation.totalBeds}</div>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Total Length</div>
              <div className="text-slate-200 font-bold text-sm">{customFormation.totalLengthMeters}m</div>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Tare Mass</div>
              <div className="text-slate-200 font-bold text-sm">{customFormation.totalWeightTons}t</div>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500 uppercase">Max Speed</div>
              <div className="text-blue-400 font-bold text-sm">{customFormation.maxSpeedKmh} km/h</div>
            </div>
          </div>
        </div>

        {/* Coupling & Splitting Hub Model */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold uppercase text-slate-300 font-display tracking-wider mb-3 flex items-center gap-2">
              <GitFork className="w-4 h-4 text-indigo-400" />
              Coupling & Portion Splitting Hubs
            </h3>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded text-xs font-mono space-y-3">
              <div className="font-bold text-blue-400">Joint Haulage Example: Cologne Hbf Hub</div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Amsterdam & Brussels portions couple together at Cologne Hbf (01:15 AM) and run as a 12-car joint train to Vienna, saving 45% in track access fees.
              </p>

              <div className="p-2 bg-slate-900 rounded border border-slate-800/80 text-[11px]">
                <div className="flex justify-between text-slate-300">
                  <span>Portion A: AMS → VIE</span>
                  <span className="text-emerald-400 font-bold">6 Coaches</span>
                </div>
                <div className="flex justify-between text-slate-300 mt-1">
                  <span>Portion B: BRU → VIE</span>
                  <span className="text-emerald-400 font-bold">6 Coaches</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-[11px] font-mono text-slate-500 pt-3 border-t border-slate-800">
            Shunting dwell time: 22 min · Locomotive change: Electrified AC 25kV
          </div>
        </div>
      </div>
    </div>
  );
};
