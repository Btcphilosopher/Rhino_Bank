import React from 'react';
import { Scenario } from '../types/railway';
import { Layers, CheckCircle2, Copy, AlertTriangle } from 'lucide-react';

interface ScenarioLabProps {
  scenarios: Scenario[];
  activeScenario: Scenario;
  onSelectScenario: (scenario: Scenario) => void;
  onDuplicateScenario: (scenario: Scenario) => void;
}

export const ScenarioLab: React.FC<ScenarioLabProps> = ({
  scenarios,
  activeScenario,
  onSelectScenario,
  onDuplicateScenario,
}) => {
  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] flex flex-col gap-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Macro Network Sensitivity</span>
          <h2 className="text-base font-bold text-slate-100 font-display mt-0.5">Scenario Analysis & Stress Testing</h2>
          <p className="text-xs text-slate-400 mt-1">
            Evaluate how sleeper network viability changes under demand surges, energy price spikes, or overnight engineering possessions.
          </p>
        </div>
      </div>

      {/* Scenario Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {scenarios.map((scen) => {
          const isActive = scen.id === activeScenario.id;

          return (
            <div
              key={scen.id}
              className={`p-5 rounded-lg border flex flex-col justify-between transition-all ${
                isActive
                  ? 'bg-blue-950/40 border-blue-500 shadow-lg shadow-blue-950/40 ring-1 ring-blue-500/50'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className={`text-[10px] font-bold uppercase tracking-wider ${isActive ? 'text-blue-400' : 'text-slate-500'}`}>
                    {isActive ? 'Active Scenario' : 'Scenario'}
                  </span>
                  {isActive && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
                </div>

                <h3 className="text-sm font-bold text-slate-100 font-display mt-3">{scen.name}</h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">{scen.description}</p>

                {/* Multipliers Grid */}
                <div className="grid grid-cols-2 gap-2 mt-4 text-xs font-mono">
                  <div className="p-2 bg-slate-950 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block">Demand</span>
                    <span className="font-bold text-emerald-400">{scen.demandMultiplier}x</span>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block">Energy Cost</span>
                    <span className="font-bold text-amber-400">{scen.energyCostMultiplier}x</span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  onClick={() => onSelectScenario(scen)}
                  disabled={isActive}
                  className={`flex-1 py-1.5 px-3 text-xs font-bold rounded transition cursor-pointer ${
                    isActive
                      ? 'bg-blue-600/20 text-blue-300 border border-blue-500/30'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                  }`}
                >
                  {isActive ? 'Active' : 'Apply Scenario'}
                </button>

                <button
                  onClick={() => onDuplicateScenario(scen)}
                  className="p-1.5 text-slate-400 hover:text-slate-100 bg-slate-800 rounded border border-slate-700 transition cursor-pointer"
                  title="Duplicate Scenario"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
