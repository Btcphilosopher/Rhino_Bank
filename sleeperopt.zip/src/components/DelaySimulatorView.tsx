import React, { useState } from 'react';
import { CandidateRoute, SimulationResult, TrackSection } from '../types/railway';
import { runMonteCarloDelaySimulation } from '../engine/robustnessSimulator';
import { ShieldAlert, Play, BarChart2, AlertCircle, CheckCircle2 } from 'lucide-react';

interface DelaySimulatorViewProps {
  activeRoute: CandidateRoute;
  trackSections: TrackSection[];
}

export const DelaySimulatorView: React.FC<DelaySimulatorViewProps> = ({
  activeRoute,
  trackSections,
}) => {
  const [numIterations, setNumIterations] = useState(500);
  const [simResult, setSimResult] = useState<SimulationResult | null>(() => 
    runMonteCarloDelaySimulation(activeRoute, trackSections, 500)
  );
  const [isRunning, setIsRunning] = useState(false);

  const handleRunSimulation = () => {
    setIsRunning(true);
    setTimeout(() => {
      const res = runMonteCarloDelaySimulation(activeRoute, trackSections, numIterations);
      setSimResult(res);
      setIsRunning(false);
    }, 300);
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] flex flex-col gap-6">
      {/* Simulation Controller Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">Stochastic Monte Carlo Engine</span>
          <h2 className="text-base font-bold text-slate-100 font-display mt-0.5">Delay Propagation & Schedule Robustness</h2>
          <p className="text-xs text-slate-400 mt-1">
            Simulate 100s of stochastic operational runs introducing random track section delays (+2m to +30m). Evaluates P50, P80, P95 arrival distributions.
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <select
            value={numIterations}
            onChange={(e) => setNumIterations(Number(e.target.value))}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-slate-200 focus:outline-none"
          >
            <option value={200}>200 Runs</option>
            <option value={500}>500 Runs</option>
            <option value={1000}>1,000 Runs</option>
            <option value={2000}>2,000 Runs</option>
          </select>

          <button
            onClick={handleRunSimulation}
            disabled={isRunning}
            className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded transition cursor-pointer flex items-center gap-2 shadow-sm shadow-blue-900/50"
          >
            <Play className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
            <span>{isRunning ? 'Running Monte Carlo...' : 'Run Simulation'}</span>
          </button>
        </div>
      </div>

      {/* Simulation Output Overview */}
      {simResult && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Key Percentile Metrics Cards */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-4 font-display">Arrival Delay Percentiles</h3>

              <div className="space-y-3 font-mono">
                <div className="p-3 bg-slate-950 border border-slate-800 rounded flex justify-between items-center">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase">P50 (Median Delay)</span>
                    <div className="text-base font-bold text-emerald-400">+{simResult.p50DelayMin} min</div>
                  </div>
                  <CheckCircle2 className="w-5 h-5 text-emerald-500/80" />
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded flex justify-between items-center">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase">P80 (Upper Quartile)</span>
                    <div className="text-base font-bold text-amber-400">+{simResult.p80DelayMin} min</div>
                  </div>
                  <AlertCircle className="w-5 h-5 text-amber-500/80" />
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded flex justify-between items-center">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase">P95 (95th Percentile Severe)</span>
                    <div className="text-base font-bold text-red-400">+{simResult.p95DelayMin} min</div>
                  </div>
                  <ShieldAlert className="w-5 h-5 text-red-500/80" />
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-xs font-mono flex justify-between text-slate-400">
                <span>On-Time Arrival Rate:</span>
                <span className="font-bold text-emerald-400">{simResult.onTimeArrivalPct}%</span>
              </div>
            </div>

            {/* Delay Hotspots */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 font-display">Critical Section Hotspots</h3>
              <div className="space-y-2 text-xs font-mono">
                {simResult.sectionDelayHotspots.map((spot, i) => (
                  <div key={i} className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
                    <span className="text-slate-300">{spot.edgeName}</span>
                    <span className="text-amber-400 font-bold">+{spot.avgDelayMin}m avg</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Histogram Visualization */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-lg p-6 flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-4 font-display flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-blue-500" />
                Arrival Delay Frequency Histogram ({simResult.numIterations} Runs)
              </h3>

              {/* Bar Chart Visualization */}
              <div className="h-64 flex items-end gap-4 pt-8 px-4 border-b border-slate-800">
                {simResult.delayDistribution.map((bucket, i) => {
                  const maxFreq = Math.max(...simResult.delayDistribution.map(d => d.frequency));
                  const heightPct = (bucket.frequency / maxFreq) * 100;

                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                      <div className="text-[10px] font-mono text-slate-400 opacity-0 group-hover:opacity-100 transition">
                        {bucket.frequency}
                      </div>
                      <div
                        style={{ height: `${heightPct}%` }}
                        className={`w-full rounded-t transition-all ${
                          bucket.delayMin <= 5 ? 'bg-emerald-500' : bucket.delayMin <= 15 ? 'bg-amber-500' : 'bg-red-500'
                        }`}
                      ></div>
                      <span className="text-[11px] font-mono text-slate-400 mt-1">
                        +{bucket.delayMin}m
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="text-xs text-slate-400 font-mono mt-4 pt-2 border-t border-slate-800/80">
              Simulation completed in 12ms. Stochastic seed: 0x8F4A.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
