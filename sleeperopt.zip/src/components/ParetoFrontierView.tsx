import React, { useState } from 'react';
import { CandidateRoute, ParetoSolution } from '../types/railway';
import { generateParetoFrontier } from '../engine/multiObjectiveSolver';
import { SlidersHorizontal, Check, ShieldCheck, Sparkles } from 'lucide-react';

interface ParetoFrontierViewProps {
  candidateRoutes: CandidateRoute[];
}

export const ParetoFrontierView: React.FC<ParetoFrontierViewProps> = ({
  candidateRoutes,
}) => {
  const [weights, setWeights] = useState({
    costWeight: 0.25,
    sleepQualityWeight: 0.35,
    robustnessWeight: 0.25,
    revenueWeight: 0.15,
    capacityWeight: 0.0,
  });

  const [solutions, setSolutions] = useState<ParetoSolution[]>(() =>
    generateParetoFrontier(candidateRoutes, weights)
  );

  const [selectedSolutionId, setSelectedSolutionId] = useState<string>('SOL_D_BALANCED');

  const handleSelectSolution = (id: string) => {
    setSelectedSolutionId(id);
    setSolutions(solutions.map(s => ({ ...s, selected: s.id === id })));
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] flex flex-col gap-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Multi-Objective Optimiser</span>
          <h2 className="text-base font-bold text-slate-100 font-display mt-0.5">Pareto Frontier Trade-Off Analysis</h2>
          <p className="text-xs text-slate-400 mt-1">
            Exposes fundamental trade-offs between Operating Cost, Passenger Sleep Quality, Schedule Robustness, and Revenue.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Pareto Chart Canvas */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-lg p-6 flex flex-col justify-between rail-grid-bg">
          <div>
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-4 font-display">
              Pareto Frontier: Sleep Quality Score (Y) vs Operating Cost per Km (X)
            </h3>

            <div className="relative h-72 border-b border-l border-slate-700 p-4">
              {/* Scatter Plot Points */}
              {solutions.map((sol) => {
                // X: Cost €20 to €35 / km -> norm
                const normX = Math.min(1, Math.max(0, (sol.costEuroPerKm - 20) / 15));
                // Y: Sleep Quality 70 to 100 -> norm
                const normY = Math.min(1, Math.max(0, (sol.sleepQualityScore - 70) / 30));

                const leftPct = normX * 85 + 5;
                const bottomPct = normY * 85 + 5;

                const isSelected = sol.id === selectedSolutionId;

                return (
                  <div
                    key={sol.id}
                    onClick={() => handleSelectSolution(sol.id)}
                    style={{ left: `${leftPct}%`, bottom: `${bottomPct}%` }}
                    className={`absolute transform -translate-x-1/2 translate-y-1/2 p-2 rounded-full cursor-pointer transition-all duration-300 flex items-center gap-2 group ${
                      isSelected ? 'bg-blue-600 ring-4 ring-blue-500/30 scale-125 z-20' : 'bg-slate-800 hover:bg-slate-700 border border-slate-600'
                    }`}
                  >
                    <div className={`w-3 h-3 rounded-full ${isSelected ? 'bg-white' : 'bg-blue-400'}`}></div>
                    <span className="text-[10px] font-mono font-bold text-slate-200 group-hover:block whitespace-nowrap bg-slate-950 px-2 py-0.5 rounded border border-slate-800 shadow">
                      {sol.name.split(':')[0]} ({sol.sleepQualityScore} pts / €{sol.costEuroPerKm}/km)
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between text-xs font-mono text-slate-500 mt-3">
              <span>← Lower Operating Cost (€20/km)</span>
              <span>Higher Operating Cost (€35/km) →</span>
            </div>
          </div>

          <div className="text-xs font-mono text-slate-400 mt-4 pt-3 border-t border-slate-800">
            Click any Pareto-optimal point to inspect detailed trade-off metrics.
          </div>
        </div>

        {/* Selected Solution Trade-off Cards */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold uppercase text-slate-400 font-display tracking-wider mb-3">
              Candidate Solutions ({solutions.length})
            </h3>

            <div className="space-y-3 font-mono text-xs">
              {solutions.map((sol) => {
                const isSelected = sol.id === selectedSolutionId;

                return (
                  <div
                    key={sol.id}
                    onClick={() => handleSelectSolution(sol.id)}
                    className={`p-3 rounded border transition cursor-pointer ${
                      isSelected ? 'bg-blue-950/40 border-blue-500 text-slate-100 shadow-md' : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex justify-between items-center font-bold">
                      <span className="truncate pr-2">{sol.name}</span>
                      {isSelected && <Check className="w-4 h-4 text-blue-400 shrink-0" />}
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800/80 text-[11px]">
                      <div>Cost/km: <span className="text-slate-200 font-bold">€{sol.costEuroPerKm}</span></div>
                      <div>Sleep Q: <span className="text-emerald-400 font-bold">{sol.sleepQualityScore}</span></div>
                      <div>Robustness: <span className="text-amber-400 font-bold">{sol.robustnessScore}</span></div>
                      <div>Net Rev: <span className="text-blue-400 font-bold">€{(sol.revenueEuro/1000).toFixed(0)}k</span></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
