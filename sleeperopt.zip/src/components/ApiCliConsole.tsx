import React, { useState } from 'react';
import { Terminal, Code, Play, Send, CheckCircle2 } from 'lucide-react';

export const ApiCliConsole: React.FC = () => {
  const [cliInput, setCliInput] = useState('sleeperopt route generate --origin STPX --dest MI_C');
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    'SLEEPEROPT Quantitative CLI Engine v3.4.0 (x86_64-pc-linux-gnu)',
    'Type "sleeperopt --help" or run pre-configured commands below.',
    '$ sleeperopt network build --preset EUROPE_2035',
    '[INFO] Loaded 32 European stations and 48 track section graph edges.',
    '[INFO] Graph topology initialized. ETCS L2 signal density: 84%.',
  ]);

  const apiEndpoints = [
    { method: 'POST', path: '/api/v1/routes/generate', desc: 'Generates candidate overnight paths using K-shortest path Dijkstra' },
    { method: 'POST', path: '/api/v1/timetable/optimise', desc: 'Solves headway and platform occupancy constraint matrices' },
    { method: 'POST', path: '/api/v1/rolling-stock/optimise', desc: 'Computes fleet sizing, coach compositions and turnarounds' },
    { method: 'POST', path: '/api/v1/simulation/run', desc: 'Executes stochastic Monte Carlo delay propagation analysis' },
    { method: 'GET', path: '/api/v1/reports/export', desc: 'Generates downloadable engineering report (JSON/PDF)' },
  ];

  const handleRunCommand = (cmdStr?: string) => {
    const cmd = cmdStr || cliInput;
    if (!cmd) return;

    const newLogs = [...terminalLogs, `$ ${cmd}`];

    if (cmd.includes('route generate')) {
      newLogs.push('[PATHFINDER] Executing Dijkstra K-Shortest Paths (Origin: STPX, Dest: MI_C)...');
      newLogs.push('[PATHFINDER] Path 1: London → Calais → Paris → Basel → Zurich → Milan (1,210 km, 8.8h sleep)');
      newLogs.push('[PATHFINDER] Path 2: London → Brussels → Cologne → Frankfurt → Zurich → Milan (1,340 km, 7.5h sleep)');
      newLogs.push('[SUCCESS] 2 candidate sleeper routes generated in 14ms.');
    } else if (cmd.includes('timetable optimise')) {
      newLogs.push('[SOLVER] Initializing CP-SAT Timetable Constraint Matrix...');
      newLogs.push('[SOLVER] Enforcing 4-min headway buffers & platform capacity...');
      newLogs.push('[SUCCESS] Timetable feasibility: FEASIBLE. 0 hard conflicts detected.');
    } else if (cmd.includes('simulate')) {
      newLogs.push('[SIMULATOR] Running 500 Monte Carlo stochastic iterations...');
      newLogs.push('[RESULT] P50 Delay: +4m | P80 Delay: +12m | P95 Delay: +24m | On-Time Rate: 89%');
    } else if (cmd.includes('report')) {
      newLogs.push('[REPORT] Generating 2035 European Sleeper Network Engineering Assessment...');
      newLogs.push('[SUCCESS] Export complete: /exports/sleeperopt_report_2035.json (242 KB)');
    } else {
      newLogs.push(`[CMD] Command executed: ${cmd}`);
    }

    setTerminalLogs(newLogs);
    setCliInput('');
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
      {/* CLI Terminal View */}
      <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <h2 className="text-xs font-bold text-slate-100 uppercase tracking-tight flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              CLI Terminal (`sleeperopt`)
            </h2>
            <span className="text-[10px] text-slate-500">Python 3.12 / C++ Core Solver</span>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-slate-800 text-xs font-mono space-y-1.5 h-80 overflow-y-auto">
            {terminalLogs.map((log, i) => (
              <div key={i} className={log.startsWith('$') ? 'text-blue-400 font-bold' : log.includes('SUCCESS') ? 'text-emerald-400' : 'text-slate-300'}>
                {log}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <input
            type="text"
            value={cliInput}
            onChange={(e) => setCliInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleRunCommand()}
            placeholder="Type sleeperopt command..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={() => handleRunCommand()}
            className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded transition cursor-pointer flex items-center gap-1"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Exec</span>
          </button>
        </div>
      </div>

      {/* REST API Endpoints Specification */}
      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-bold text-slate-100 uppercase tracking-tight flex items-center gap-2 pb-3 border-b border-slate-800 mb-4">
          <Code className="w-4 h-4 text-blue-400" />
          FastAPI OpenAPI Endpoints
        </h3>

        <div className="space-y-3 text-xs">
          {apiEndpoints.map((ep, i) => (
            <div key={i} className="p-3 bg-slate-950 border border-slate-800 rounded hover:border-slate-700 transition">
              <div className="flex items-center gap-2 font-bold">
                <span className={`px-2 py-0.5 rounded text-[10px] ${ep.method === 'POST' ? 'bg-blue-950 text-blue-400 border border-blue-800' : 'bg-emerald-950 text-emerald-400 border border-emerald-800'}`}>
                  {ep.method}
                </span>
                <span className="text-slate-200">{ep.path}</span>
              </div>
              <p className="text-slate-400 text-[11px] mt-1.5">{ep.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
