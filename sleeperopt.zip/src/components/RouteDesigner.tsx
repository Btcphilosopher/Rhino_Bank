import React, { useState } from 'react';
import { Station, TrackSection, CandidateRoute } from '../types/railway';
import { findKShortestPaths } from '../engine/graphAlgorithms';
import { evaluateSleepQuality } from '../engine/sleepOptimiser';
import { DEFAULT_FORMATIONS } from '../data/europeanNetwork';
import { TrainTrack, Sparkles, Sliders, Clock, ArrowRight, ShieldCheck, Moon } from 'lucide-react';

interface RouteDesignerProps {
  stations: Station[];
  trackSections: TrackSection[];
  onAddGeneratedRoute: (route: CandidateRoute) => void;
}

export const RouteDesigner: React.FC<RouteDesignerProps> = ({
  stations,
  trackSections,
  onAddGeneratedRoute,
}) => {
  const [originId, setOriginId] = useState('STPX'); // London
  const [destinationId, setDestinationId] = useState('MI_C'); // Milan
  const [departureWindow, setDepartureWindow] = useState('19:45');
  const [arrivalWindow, setArrivalWindow] = useState('07:30');
  
  // Solver Weight Sliders
  const [weightDistance, setWeightDistance] = useState(20);
  const [weightTravelTime, setWeightTravelTime] = useState(30);
  const [weightSleepComfort, setWeightSleepComfort] = useState(35);
  const [weightRobustness, setWeightRobustness] = useState(15);

  const [generatedCandidates, setGeneratedCandidates] = useState<CandidateRoute[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateRoutes = () => {
    setIsGenerating(true);

    setTimeout(() => {
      // Execute K-shortest paths on graph
      const paths = findKShortestPaths(stations, trackSections, originId, destinationId, 3);
      
      const stationMap = new Map(stations.map(s => [s.id, s]));
      const originStation = stationMap.get(originId);
      const destStation = stationMap.get(destinationId);

      const candidateList: CandidateRoute[] = paths.map((path, idx) => {
        const stopsDetail = path.stationIds.map((stnId, i) => {
          const stn = stationMap.get(stnId)!;
          const isOrigin = i === 0;
          const isDest = i === path.stationIds.length - 1;

          return {
            stationId: stnId,
            stationName: stn.name,
            arrivalTime: isOrigin ? '19:15' : isDest ? arrivalWindow : '02:30',
            departureTime: isOrigin ? departureWindow : isDest ? '08:00' : '02:45',
            dwellMin: isOrigin || isDest ? 30 : 15,
            stopType: isOrigin || isDest ? ('major_boarding' as const) : stn.type === 'BORDER' ? ('border' as const) : ('minor_boarding' as const),
            distanceFromOriginKm: Math.round((i / (path.stationIds.length - 1)) * path.totalDistanceKm),
            isSleepingHours: i > 0 && i < path.stationIds.length - 1,
            nightDisruptionPenalty: 2,
          };
        });

        const sleepEval = evaluateSleepQuality(departureWindow, arrivalWindow, stopsDetail);

        return {
          id: `GEN_${Date.now()}_${idx}`,
          name: `Candidate Route #${idx + 1}: ${originStation?.city} → ${destStation?.city} (via ${path.stationIds.length - 2} hubs)`,
          originId,
          originName: originStation?.name || '',
          destinationId,
          destinationName: destStation?.name || '',
          pathStationIds: path.stationIds,
          pathEdgeIds: path.edgeIds,
          totalDistanceKm: path.totalDistanceKm,
          pureRunningTimeMin: path.totalPureRunningTimeMin,
          scheduledDepartureTime: departureWindow,
          scheduledArrivalTime: arrivalWindow,
          totalJourneyTimeMin: sleepEval.totalJourneyMinutes,
          sleepDurationHours: Math.round((sleepEval.sleepDurationMinutes / 60) * 10) / 10,
          stops: stopsDetail,
          sleepQualityScore: sleepEval.passengerSleepQualityScore,
          nightDisruptionScore: sleepEval.nightDisruptionScore,
          robustnessRating: sleepEval.passengerSleepQualityScore > 80 ? 'ROBUST' : 'FRAGILE',
          robustnessScore: Math.min(100, Math.round(sleepEval.passengerSleepQualityScore * 0.95)),
          estimatedPaxDemand: 380 + idx * 15,
          avgFareEuro: 150 + idx * 10,
          totalRevenueEuro: (380 + idx * 15) * (150 + idx * 10),
          operatingCostEuro: Math.round(path.totalDistanceKm * 25.5),
          netMarginEuro: (380 + idx * 15) * (150 + idx * 10) - Math.round(path.totalDistanceKm * 25.5),
          breakEvenOccupancyPct: 48,
          co2SavedVsFlightKg: Math.round(path.totalDistanceKm * 115),
          formation: DEFAULT_FORMATIONS[0],
          requiredTrainsets: path.totalDistanceKm > 1200 ? 3 : 2,
          hasCouplingPortion: false,
        };
      });

      setGeneratedCandidates(candidateList);
      setIsGenerating(false);
    }, 400);
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Route Parameters Control Panel */}
      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
        <div>
          <h2 className="text-sm font-bold text-slate-100 uppercase font-display tracking-tight flex items-center gap-2 pb-3 border-b border-slate-800 mb-4">
            <TrainTrack className="w-4 h-4 text-blue-500" />
            Sleeper Route Generator & Graph Pathfinder
          </h2>

          <div className="space-y-4 text-xs font-mono">
            {/* Origin & Destination Selectors */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1 text-[11px] uppercase">Origin Hub</label>
                <select
                  value={originId}
                  onChange={(e) => setOriginId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
                >
                  {stations.map((s) => (
                    <option key={s.id} value={s.id}>{s.city} ({s.code})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1 text-[11px] uppercase">Destination Hub</label>
                <select
                  value={destinationId}
                  onChange={(e) => setDestinationId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
                >
                  {stations.map((s) => (
                    <option key={s.id} value={s.id}>{s.city} ({s.code})</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Target Departure & Arrival Sleep Windows */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-slate-400 block mb-1 text-[11px] uppercase flex items-center gap-1">
                  <Clock className="w-3 h-3 text-blue-400" /> Target Departure
                </label>
                <input
                  type="text"
                  value={departureWindow}
                  onChange={(e) => setDepartureWindow(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 text-[11px] uppercase flex items-center gap-1">
                  <Moon className="w-3 h-3 text-indigo-400" /> Target Arrival
                </label>
                <input
                  type="text"
                  value={arrivalWindow}
                  onChange={(e) => setArrivalWindow(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* Solver Weight Adjusters */}
            <div className="pt-4 border-t border-slate-800 space-y-3">
              <div className="text-[11px] font-bold uppercase text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-blue-400" /> Multi-Objective Optimisation Weights
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Distance Minimisation</span>
                  <span>{weightDistance}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={weightDistance}
                  onChange={(e) => setWeightDistance(Number(e.target.value))}
                  className="w-full accent-blue-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Travel Speed & Time</span>
                  <span>{weightTravelTime}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={weightTravelTime}
                  onChange={(e) => setWeightTravelTime(Number(e.target.value))}
                  className="w-full accent-blue-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Passenger Sleep Quality</span>
                  <span>{weightSleepComfort}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={weightSleepComfort}
                  onChange={(e) => setWeightSleepComfort(Number(e.target.value))}
                  className="w-full accent-emerald-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Schedule Robustness</span>
                  <span>{weightRobustness}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={weightRobustness}
                  onChange={(e) => setWeightRobustness(Number(e.target.value))}
                  className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={handleGenerateRoutes}
          disabled={isGenerating}
          className="mt-6 w-full py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded transition flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-blue-900/40"
        >
          <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
          <span>{isGenerating ? 'Solving Graph Paths...' : 'Generate Candidate Sleeper Routes'}</span>
        </button>
      </div>

      {/* Generated Feasible Candidate Solutions List */}
      <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
        <div>
          <h2 className="text-sm font-bold text-slate-100 uppercase font-display tracking-tight pb-3 border-b border-slate-800 mb-4">
            Candidate Solutions ({generatedCandidates.length})
          </h2>

          {generatedCandidates.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs font-mono">
              Configure origin, destination and solver weights then click <span className="text-blue-400">Generate</span> to execute the pathfinder algorithm.
            </div>
          ) : (
            <div className="space-y-4">
              {generatedCandidates.map((cand) => (
                <div key={cand.id} className="bg-slate-950 border border-slate-800 rounded-md p-4 hover:border-slate-700 transition">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                    <h3 className="text-xs font-bold text-blue-400">{cand.name}</h3>
                    <button
                      onClick={() => onAddGeneratedRoute(cand)}
                      className="px-3 py-1 text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded transition cursor-pointer flex items-center gap-1"
                    >
                      <span>Commit to Network</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="grid grid-cols-4 gap-2 my-3 text-xs font-mono text-center">
                    <div className="bg-slate-900 p-2 rounded">
                      <div className="text-[10px] text-slate-500 uppercase">Distance</div>
                      <div className="text-slate-200 font-bold">{cand.totalDistanceKm} km</div>
                    </div>
                    <div className="bg-slate-900 p-2 rounded">
                      <div className="text-[10px] text-slate-500 uppercase">Sleep Time</div>
                      <div className="text-emerald-400 font-bold">{cand.sleepDurationHours} hrs</div>
                    </div>
                    <div className="bg-slate-900 p-2 rounded">
                      <div className="text-[10px] text-slate-500 uppercase">Sleep Quality</div>
                      <div className="text-blue-400 font-bold">{cand.sleepQualityScore} / 100</div>
                    </div>
                    <div className="bg-slate-900 p-2 rounded">
                      <div className="text-[10px] text-slate-500 uppercase">Op Margin</div>
                      <div className="text-slate-200 font-bold">€{cand.netMarginEuro.toLocaleString()}</div>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 font-mono">
                    <span className="text-slate-500 uppercase font-bold">Path:</span> {cand.stops.map(s => s.stationName).join(' → ')}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
