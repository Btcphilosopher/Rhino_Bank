import React, { useState } from 'react';
import { CandidateRoute, Scenario } from '../types/railway';
import { calculateDemandAndEconomics } from '../engine/demandAndEconomics';
import { TrendingUp, Sliders, DollarSign, Leaf, PieChart } from 'lucide-react';

interface DemandEconomicsViewProps {
  activeRoute: CandidateRoute;
  activeScenario: Scenario;
}

export const DemandEconomicsView: React.FC<DemandEconomicsViewProps> = ({
  activeRoute,
  activeScenario,
}) => {
  const [priceMultiplier, setPriceMultiplier] = useState(1.0);
  const [speedMultiplier, setSpeedMultiplier] = useState(1.0);

  const econ = calculateDemandAndEconomics(activeRoute, activeScenario, priceMultiplier, speedMultiplier);

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] flex flex-col gap-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Transport Economics & Passenger Demand</span>
          <h2 className="text-base font-bold text-slate-100 font-display mt-0.5">{econ.routeName}</h2>
          <p className="text-xs text-slate-400 mt-1">
            Synthetic OD passenger demand matrix, price/time elasticity lab, cost per train-km, and CO2 emissions vs aviation.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
            <span className="text-slate-400">Net Margin: </span>
            <span className={`font-bold ${econ.netContributionMarginEuro >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              €{econ.netContributionMarginEuro.toLocaleString()} ({econ.netMarginPct}%)
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Elasticity Sensitivity Lab */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold uppercase text-slate-300 font-display tracking-wider mb-4 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-400" />
              Demand Elasticity Sensitivity Lab
            </h3>

            <div className="space-y-4 text-xs font-mono">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Ticket Price Adjustment</span>
                  <span className="text-blue-400 font-bold">€{econ.averageFareEuro} ({(priceMultiplier * 100).toFixed(0)}%)</span>
                </div>
                <input
                  type="range"
                  min={0.6}
                  max={1.8}
                  step={0.05}
                  value={priceMultiplier}
                  onChange={(e) => setPriceMultiplier(Number(e.target.value))}
                  className="w-full accent-blue-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Journey Speed Adjustment</span>
                  <span className="text-emerald-400 font-bold">{(speedMultiplier * 100).toFixed(0)}% Speed</span>
                </div>
                <input
                  type="range"
                  min={0.8}
                  max={1.3}
                  step={0.05}
                  value={speedMultiplier}
                  onChange={(e) => setSpeedMultiplier(Number(e.target.value))}
                  className="w-full accent-emerald-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 space-y-2">
                <div className="flex justify-between text-slate-300">
                  <span>Passenger Load Factor:</span>
                  <span className="font-bold text-blue-400">{econ.occupancyRatePct}% ({econ.passengersPerNight} pax)</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Break-Even Load Factor:</span>
                  <span className="font-bold text-amber-400">{econ.breakEvenPax} pax</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Gross Revenue / Night:</span>
                  <span className="font-bold text-slate-100">€{econ.grossRevenuePerNightEuro.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-3 border-t border-slate-800 text-[11px] font-mono text-slate-500">
            Price Elasticity = -1.2 · Time Elasticity = -0.7
          </div>
        </div>

        {/* Operating Cost Breakdown & Environmental Model */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold uppercase text-slate-300 font-display tracking-wider mb-4 flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              Operating Cost Breakdown & Environmental CO2 Model
            </h3>

            {/* Cost Breakdown Grid */}
            <div className="grid grid-cols-2 gap-3 text-xs font-mono mb-6">
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px] uppercase">Track Access Fees</div>
                <div className="text-slate-200 font-bold mt-0.5">€{econ.operatingCostsPerNight.trackAccessCharges.toLocaleString()}</div>
              </div>

              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px] uppercase">Loco & Traction Power</div>
                <div className="text-slate-200 font-bold mt-0.5">€{econ.operatingCostsPerNight.locoAndEnergyCost.toLocaleString()}</div>
              </div>

              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px] uppercase">Staff & On-Board Crew</div>
                <div className="text-slate-200 font-bold mt-0.5">€{econ.operatingCostsPerNight.staffAndCrew.toLocaleString()}</div>
              </div>

              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px] uppercase">Total Cost / Night</div>
                <div className="text-emerald-400 font-bold mt-0.5">€{econ.operatingCostsPerNight.totalOperatingCostEuro.toLocaleString()}</div>
              </div>
            </div>

            {/* Environmental CO2 Model */}
            <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2">
              <div className="text-xs font-bold text-emerald-400 uppercase font-mono flex items-center gap-1.5">
                <Leaf className="w-3.5 h-3.5" /> CO2 Emissions Comparison per Journey
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs font-mono text-center pt-2">
                <div className="p-2 bg-slate-900 rounded">
                  <div className="text-slate-500 text-[10px]">Sleeper Rail</div>
                  <div className="text-emerald-400 font-bold mt-0.5">{econ.co2ComparisonKg.sleeperRailKg.toLocaleString()} kg</div>
                </div>
                <div className="p-2 bg-slate-900 rounded">
                  <div className="text-slate-500 text-[10px]">Aviation</div>
                  <div className="text-red-400 font-bold mt-0.5">{econ.co2ComparisonKg.aviationKg.toLocaleString()} kg</div>
                </div>
                <div className="p-2 bg-slate-900 rounded">
                  <div className="text-slate-500 text-[10px]">Net Saved</div>
                  <div className="text-blue-400 font-bold mt-0.5">{(econ.co2ComparisonKg.savingsVsAviationKg / 1000).toFixed(1)} tons</div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] font-mono text-slate-400 flex justify-between">
            <span>Cost / Train-km: €{econ.costPerTrainKmEuro}</span>
            <span>Cost / Bed: €{econ.costPerBedEuro}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
