import React, { useState } from 'react';
import { CandidateRoute, Station, TimeSpaceConflict } from '../types/railway';
import { parseTimeToMinutes } from '../engine/sleepOptimiser';
import { Layers, AlertTriangle, ShieldCheck, Info } from 'lucide-react';

interface TimeSpaceGraphProps {
  candidateRoutes: CandidateRoute[];
  stations: Station[];
  conflicts: TimeSpaceConflict[];
  onSelectConflict: (conflict: TimeSpaceConflict) => void;
}

export const TimeSpaceGraph: React.FC<TimeSpaceGraphProps> = ({
  candidateRoutes,
  stations,
  conflicts,
  onSelectConflict,
}) => {
  const [hoveredTrain, setHoveredTrain] = useState<string | null>(null);

  // Time-Space Canvas dimensions
  // X-axis: Time from 18:00 (1080 min) to 12:00 next day (2160 min) -> 1080 minutes total span
  // Y-axis: Corridor Distance from 0km (London) to 1300km (Milan/Vienna)
  const chartWidth = 960;
  const chartHeight = 520;
  const paddingLeft = 140;
  const paddingBottom = 45;
  const paddingTop = 25;
  const paddingRight = 30;

  const innerWidth = chartWidth - paddingLeft - paddingRight;
  const innerHeight = chartHeight - paddingTop - paddingBottom;

  const minTimeMin = 1080; // 18:00
  const maxTimeMin = 2160; // 12:00 next day
  const maxDistanceKm = 1300;

  const timeToX = (timeStr: string) => {
    let mins = parseTimeToMinutes(timeStr);
    if (mins < 720) mins += 1440; // Next day morning hours (e.g. 05:30 -> 1770 min)
    const norm = (mins - minTimeMin) / (maxTimeMin - minTimeMin);
    return paddingLeft + norm * innerWidth;
  };

  const distToY = (distKm: number) => {
    const norm = distKm / maxDistanceKm;
    return paddingTop + (1 - norm) * innerHeight;
  };

  // Time Ticks (every 2 hours: 18:00, 20:00, 22:00, 00:00, 02:00, 04:00, 06:00, 08:00, 10:00, 12:00)
  const timeTicks = [
    { label: '18:00', min: 1080 },
    { label: '20:00', min: 1200 },
    { label: '22:00', min: 1320 },
    { label: '00:00', min: 1440 },
    { label: '02:00', min: 1560 },
    { label: '04:00', min: 1680 },
    { label: '06:00', min: 1800 },
    { label: '08:00', min: 1920 },
    { label: '10:00', min: 2040 },
    { label: '12:00', min: 2160 },
  ];

  // Route Colors
  const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-100px)] flex flex-col gap-5">
      {/* Time-Space Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-100 font-display uppercase tracking-tight flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-500" />
            Time-Space String Diagram (Railway Capacity & Conflicts)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            X-axis represents 18:00 to 12:00 time progression; Y-axis represents corridor distance. Slopes indicate train speed profiles.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
            <span className="text-slate-400">Total Conflicts Detected:</span>
            <span className={`font-bold ${conflicts.length > 0 ? 'text-red-400 animate-pulse' : 'text-emerald-400'}`}>
              {conflicts.length}
            </span>
          </div>
        </div>
      </div>

      {/* Main Diagram Area */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 rail-grid-bg relative overflow-x-auto">
        <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto min-w-[800px] select-none">
          {/* Sleep Window Highlight Zone (23:00 to 06:30 -> 1380 to 1830 mins) */}
          <rect
            x={paddingLeft + ((1380 - minTimeMin) / (maxTimeMin - minTimeMin)) * innerWidth}
            y={paddingTop}
            width={((1830 - 1380) / (maxTimeMin - minTimeMin)) * innerWidth}
            height={innerHeight}
            fill="#1e1b4b"
            opacity={0.35}
          />
          <text
            x={paddingLeft + ((1380 - minTimeMin) / (maxTimeMin - minTimeMin)) * innerWidth + 10}
            y={paddingTop + 20}
            fill="#a5b4fc"
            fontSize={10}
            fontWeight="bold"
            fontFamily="JetBrains Mono"
            className="uppercase tracking-widest"
          >
            Passenger Sleep Window (23:00 - 06:30)
          </text>

          {/* Time Ticks (X Grid Lines) */}
          {timeTicks.map((tick) => {
            const x = paddingLeft + ((tick.min - minTimeMin) / (maxTimeMin - minTimeMin)) * innerWidth;
            return (
              <g key={tick.label}>
                <line
                  x1={x}
                  y1={paddingTop}
                  x2={x}
                  y2={chartHeight - paddingBottom}
                  stroke="#334155"
                  strokeDasharray="2,2"
                  opacity={0.5}
                />
                <text
                  x={x}
                  y={chartHeight - paddingBottom + 20}
                  fill="#94a3b8"
                  fontSize={11}
                  fontFamily="JetBrains Mono"
                  textAnchor="middle"
                >
                  {tick.label}
                </text>
              </g>
            );
          })}

          {/* Distance Ticks (Y Grid Lines & Station Reference Lines) */}
          {[0, 200, 400, 600, 800, 1000, 1200].map((distKm) => {
            const y = distToY(distKm);
            return (
              <g key={distKm}>
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={chartWidth - paddingRight}
                  y2={y}
                  stroke="#334155"
                  strokeDasharray="2,2"
                  opacity={0.4}
                />
                <text
                  x={paddingLeft - 12}
                  y={y + 4}
                  fill="#64748b"
                  fontSize={10}
                  fontFamily="JetBrains Mono"
                  textAnchor="end"
                >
                  {distKm} km
                </text>
              </g>
            );
          })}

          {/* Draw Train String Lines */}
          {candidateRoutes.map((route, routeIdx) => {
            const color = colors[routeIdx % colors.length];
            const isHovered = hoveredTrain === route.id;

            // Build path points from stops sequence
            const points: { x: number; y: number; name: string }[] = [];

            route.stops.forEach((stop) => {
              const arrX = timeToX(stop.arrivalTime);
              const depX = timeToX(stop.departureTime);
              const y = distToY(stop.distanceFromOriginKm);

              // Arrival point
              points.push({ x: arrX, y, name: stop.stationName });
              // Departure point (dwell line)
              points.push({ x: depX, y, name: stop.stationName });
            });

            // Construct SVG path string
            const pathD = points.reduce((acc, pt, idx) => {
              return idx === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`;
            }, '');

            return (
              <g
                key={route.id}
                onMouseEnter={() => setHoveredTrain(route.id)}
                onMouseLeave={() => setHoveredTrain(null)}
                className="cursor-pointer transition-all"
              >
                {/* Train Line */}
                <path
                  d={pathD}
                  fill="none"
                  stroke={color}
                  strokeWidth={isHovered ? 4 : 2.5}
                  opacity={hoveredTrain && !isHovered ? 0.3 : 1}
                />

                {/* Draw Stop Dwell Circles */}
                {points.map((pt, i) => (
                  <circle
                    key={i}
                    cx={pt.x}
                    cy={pt.y}
                    r={isHovered ? 4 : 2.5}
                    fill={color}
                    stroke="#0f172a"
                    strokeWidth={1.5}
                  />
                ))}
              </g>
            );
          })}

          {/* Draw Conflict Hotspots */}
          {conflicts.map((conf) => {
            // Place conflict icon at estimated time and distance
            const [arrStr] = conf.timeSlot.split(' / ');
            const x = timeToX(arrStr || '02:00');
            const y = distToY(600); // Mid corridor estimate

            return (
              <g
                key={conf.id}
                onClick={() => onSelectConflict(conf)}
                className="cursor-pointer animate-pulse"
              >
                <circle cx={x} cy={y} r={12} fill="#ef4444" opacity={0.3} />
                <circle cx={x} cy={y} r={6} fill="#ef4444" stroke="#ffffff" strokeWidth={1.5} />
              </g>
            );
          })}
        </svg>
      </div>

      {/* Conflict Log Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 font-display flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-500" />
          Detected Infrastructure & Headway Conflicts ({conflicts.length})
        </h3>

        <div className="space-y-2">
          {conflicts.length === 0 ? (
            <div className="text-xs text-slate-400 py-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>No headway or platform conflicts detected in current schedule. Timetable is operationally feasible.</span>
            </div>
          ) : (
            conflicts.map((conf) => (
              <div
                key={conf.id}
                onClick={() => onSelectConflict(conf)}
                className="p-3 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-md flex items-center justify-between text-xs cursor-pointer transition-all"
              >
                <div className="flex items-center gap-3">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${conf.severity === 'HIGH' ? 'bg-red-950 text-red-400 border border-red-800' : 'bg-amber-950 text-amber-400 border border-amber-800'}`}>
                    {conf.severity}
                  </span>
                  <div>
                    <span className="font-bold text-slate-200">{conf.trainAName} vs {conf.trainBName}</span>
                    <div className="text-slate-400 text-[11px] mt-0.5">Location: {conf.locationName} · Slot: {conf.timeSlot}</div>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className="text-slate-300">Buffer: <span className="text-red-400">{conf.actualBufferMin}m</span> / {conf.requiredBufferMin}m</div>
                  <div className="text-blue-400 text-[11px] mt-0.5">{conf.proposedResolution}</div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
