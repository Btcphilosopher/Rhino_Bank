import React from 'react';
import { 
  Network, 
  Clock, 
  TrainTrack, 
  TrainFront, 
  TrendingUp, 
  SlidersHorizontal, 
  ShieldAlert, 
  BookOpen, 
  Terminal, 
  Layers, 
  Sparkles,
  Search
} from 'lucide-react';
import { Scenario } from '../types/railway';

export type ActiveTab = 
  | 'NETWORK'
  | 'ROUTE_DESIGNER'
  | 'TIMETABLE'
  | 'TIME_SPACE'
  | 'ROLLING_STOCK'
  | 'DEMAND_ECONOMICS'
  | 'PARETO_OPTIMISER'
  | 'SCENARIOS'
  | 'ROBUSTNESS_SIM'
  | 'RESEARCH_NOTEBOOK'
  | 'API_CLI';

interface TopBarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  activeScenario: Scenario;
  onRunGlobalOptimiser: () => void;
  isOptimising: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  activeScenario,
  onRunGlobalOptimiser,
  isOptimising,
}) => {
  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'NETWORK', label: 'Network', icon: <Network className="w-4 h-4" /> },
    { id: 'ROUTE_DESIGNER', label: 'Route Generator', icon: <TrainTrack className="w-4 h-4" /> },
    { id: 'TIMETABLE', label: 'Timetable', icon: <Clock className="w-4 h-4" /> },
    { id: 'TIME_SPACE', label: 'Time-Space Graph', icon: <Layers className="w-4 h-4" /> },
    { id: 'ROLLING_STOCK', label: 'Rolling Stock', icon: <TrainFront className="w-4 h-4" /> },
    { id: 'DEMAND_ECONOMICS', label: 'Demand & Economics', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'ROBUSTNESS_SIM', label: 'Delay Simulator', icon: <ShieldAlert className="w-4 h-4" /> },
    { id: 'PARETO_OPTIMISER', label: 'Pareto Solver', icon: <SlidersHorizontal className="w-4 h-4" /> },
    { id: 'SCENARIOS', label: 'Scenario Lab', icon: <Layers className="w-4 h-4" /> },
    { id: 'RESEARCH_NOTEBOOK', label: 'Research Log', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'API_CLI', label: 'API / CLI', icon: <Terminal className="w-4 h-4" /> },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 shrink-0 sticky top-0 z-50">
      {/* Upper Bar: Brand & System Status */}
      <div className="flex items-center justify-between px-6 py-2.5 border-b border-slate-800/80">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded bg-blue-600 flex items-center justify-center text-white font-black tracking-tighter shadow-md shadow-blue-900/40">
              S
            </div>
            <div>
              <span className="text-base font-extrabold tracking-wider text-slate-100 font-display">
                SLEEPER<span className="text-blue-500">OPT</span>
              </span>
              <span className="hidden sm:inline-block ml-3 text-[11px] font-medium tracking-widest text-slate-400 uppercase border-l border-slate-700 pl-3">
                Overnight Rail Network Optimisation
              </span>
            </div>
          </div>
        </div>

        {/* Center: Scenario Badge */}
        <div className="hidden lg:flex items-center gap-2 bg-slate-950/80 border border-slate-800 rounded-md px-3 py-1 text-xs">
          <span className="text-slate-400">Active Scenario:</span>
          <span className="text-blue-400 font-semibold">{activeScenario.name}</span>
          <span className="text-slate-500 text-[10px]">({activeScenario.demandMultiplier}x Demand)</span>
        </div>

        {/* Right: Global Optimise Action */}
        <div className="flex items-center gap-3">
          <button
            onClick={onRunGlobalOptimiser}
            disabled={isOptimising}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded transition-all shadow-sm shadow-blue-900/50 disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isOptimising ? 'animate-spin' : ''}`} />
            <span>{isOptimising ? 'Solving Engine...' : 'Run Network Solver'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Links Bar */}
      <div className="flex items-center justify-between px-6 overflow-x-auto no-scrollbar">
        <nav className="flex items-center gap-1 py-1.5">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-blue-600/15 text-blue-400 font-semibold border border-blue-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
