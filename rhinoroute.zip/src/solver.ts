import { 
  CollectionRoute, 
  StreetSegment, 
  Vehicle, 
  Driver, 
  SolverConfig, 
  SolverLog, 
  YorkshireRegion,
  CollectionType,
  PropulsionType,
  VehicleStatus
} from "./types";
import { STREET_SEGMENTS, DEPOTS, FACILITIES } from "./data";

/**
 * Calculates straight line distance between two visual coordinates (pixels)
 */
export function getDistance(p1: [number, number], p2: [number, number]): number {
  const dx = p1[0] - p2[0];
  const dy = p1[1] - p2[1];
  // Map pixel distance to approximate real-world kilometers (1 pixel approx 0.35 km in this map projection)
  return Math.sqrt(dx * dx + dy * dy) * 0.35;
}

/**
 * Runs a simulated multi-threaded Rust CVRP VRP Solver with Time Windows.
 * Returns a generator or stream of logs, and a final list of optimized routes.
 */
export function solveRoutes(
  region: YorkshireRegion,
  collectionType: CollectionType,
  vehicles: Vehicle[],
  drivers: Driver[],
  config: SolverConfig,
  onProgress: (logs: SolverLog[], convergence: number[], progress: number) => void
): Promise<CollectionRoute[]> {
  return new Promise((resolve) => {
    const logs: SolverLog[] = [];
    const convergence: number[] = [];
    let progress = 0;
    
    const addLog = (message: string, level: "INFO" | "WARN" | "ERROR" | "SUCCESS" = "INFO", thread = "main") => {
      const timestamp = new Date().toISOString().split("T")[1].slice(0, 8);
      logs.push({ timestamp, level, thread, message });
    };

    addLog(`Initializing Rust optimization engine (VRP-CVRPTW-Solver v2.4.1)`, "INFO", "main");
    addLog(`Loading spatial index from PostgreSQL/PostGIS for region: ${region}`, "INFO", "postgis");
    
    // Filter streets for current region & collection type
    const regionStreets = STREET_SEGMENTS.filter(
      (st) => st.region === region && st.collectionType === collectionType
    );

    if (regionStreets.length === 0) {
      addLog(`No street segments matching collection type '${collectionType}' in ${region}. Falling back to general waste streets.`, "WARN", "solver");
    }

    const streetsToRoute = regionStreets.length > 0 
      ? regionStreets 
      : STREET_SEGMENTS.filter(st => st.region === region);

    const activeVehicles = vehicles.filter(v => v.status === VehicleStatus.ACTIVE && v.currentPayloadTons === 0);
    const activeDrivers = drivers.filter(d => d.status === "On Shift");

    addLog(`Found ${streetsToRoute.length} collection segments. Allocating from ${activeVehicles.length} available trucks.`, "INFO", "solver");

    let step = 0;
    const maxSteps = 10;
    const interval = setInterval(() => {
      step++;
      progress = (step / maxSteps) * 100;

      // Simulate logarithmic convergence values (objective function = cost/distance)
      const baseCost = streetsToRoute.reduce((sum, s) => sum + s.households, 0) * 1.5;
      const optimizedValue = baseCost * (1 - 0.45 * Math.log10(1 + (step * (config.iterations / 100)) / 10));
      convergence.push(Math.round(optimizedValue));

      if (step === 1) {
        addLog(`Constructing initial heuristic solution using parallel Clark-Wright savings...`, "INFO", "thread-0");
        addLog(`Thread-1 spawned: solving Time-Window constraints. Strictness: ${config.timeWindowStrictness}`, "INFO", "thread-1");
        addLog(`Thread-2 spawned: calculating driver shift limit: max ${activeDrivers[0]?.maxShiftMinutes || 480} mins`, "INFO", "thread-2");
      } else if (step === 3) {
        addLog(`Executing local search (2-opt swap & Or-opt relocates) on ${streetsToRoute.length} points`, "INFO", "thread-0");
        if (config.weatherFactor !== "Fine") {
          addLog(`Applied weather correction multiplier (${config.weatherFactor}): speeds adjusted by -20%`, "WARN", "solver");
        }
      } else if (step === 6) {
        addLog(`Metaheuristics active: running Tabu Search to escape local minima`, "INFO", "thread-1");
        addLog(`Vehicle capacity constraint: applying scaling factor of ${config.maxCapacityMultiplier}x`, "INFO", "solver");
      } else if (step === 8) {
        addLog(`Route balancing triggered. Inter-route variance reduced to under 4.5%`, "INFO", "thread-2");
        if (config.trafficWeight > 50) {
          addLog(`High traffic congestion weight (${config.trafficWeight}%) applied. Re-routing secondary pathways.`, "WARN", "solver");
        }
      } else if (step === 10) {
        addLog(`VRP Solver converged in ${config.iterations} iterations. Parallel threads joined successfully.`, "SUCCESS", "main");
        addLog(`Saving optimized plans back to PostgreSQL tables with transaction ID: tx_vrp_${Math.floor(Math.random() * 90000) + 10000}`, "SUCCESS", "postgis");
        
        clearInterval(interval);

        // Generate final optimized routes based on actual available resources
        const allocatedVehicles = activeVehicles.slice(0, Math.max(1, Math.floor(streetsToRoute.length / 3)));
        const finalRoutes: CollectionRoute[] = [];

        // Distribute segments into routes
        const segmentsPerRoute = Math.ceil(streetsToRoute.length / Math.max(1, allocatedVehicles.length));
        
        const depot = DEPOTS.find(d => d.region === region) || DEPOTS[0];
        const facility = FACILITIES.find(f => f.region === region) || FACILITIES[0];

        allocatedVehicles.forEach((veh, idx) => {
          const driver = activeDrivers[idx % activeDrivers.length] || drivers[0];
          const routeStreets = streetsToRoute.slice(idx * segmentsPerRoute, (idx + 1) * segmentsPerRoute);
          
          if (routeStreets.length === 0) return;

          const totalHouseholds = routeStreets.reduce((sum, s) => sum + s.households, 0);
          const plannedTonnage = Number(routeStreets.reduce((sum, s) => sum + s.wasteTonnageEstimate, 0).toFixed(2));
          
          // Re-generate visual path coordinates starting from depot, hitting streets, ending at facility
          const pathPoints: [number, number][] = [[depot.lat, depot.lng]];
          routeStreets.forEach(st => {
            st.coordinates.forEach(pt => pathPoints.push(pt));
          });
          pathPoints.push([facility.lat, facility.lng]);

          // Calculate visual distance
          let distanceKm = 0;
          for (let i = 0; i < pathPoints.length - 1; i++) {
            distanceKm += getDistance(pathPoints[i], pathPoints[i+1]);
          }
          distanceKm = Number(distanceKm.toFixed(1));

          // Base duration is km * 2.5 mins/km + 1 min per household stop
          const durationMinutes = Math.round(distanceKm * 2.5 + totalHouseholds * 0.4);

          finalRoutes.push({
            id: `route-${region.substring(0, 3).toLowerCase()}-${collectionType.substring(0, 3).toLowerCase()}-${idx + 1}`,
            name: `${region} ${collectionType} Round ${idx + 1}`,
            region,
            collectionType,
            depotId: depot.id,
            facilityId: facility.id,
            vehicleId: veh.id,
            driverName: driver?.name || "Substitute Driver",
            streets: routeStreets.map(s => s.id),
            totalHouseholds,
            plannedTonnage,
            completedTonnage: 0,
            distanceKm,
            durationMinutes,
            missedCollections: 0,
            status: "Planned",
            points: pathPoints
          });
        });

        onProgress(logs, convergence, progress);
        resolve(finalRoutes);
      }

      onProgress(logs, convergence, progress);
    }, 200);
  });
}

/**
 * Approximates environmental and financial performance metrics of a fleet
 */
export function calculateFleetImpact(vehicles: Vehicle[], routes: CollectionRoute[]) {
  let dieselCo2Kg = 0;
  let electricEnergyKwh = 0;
  let hydrogenKg = 0;
  let totalDistanceKm = 0;
  let operationalCostGBP = 0;

  routes.forEach(r => {
    const veh = vehicles.find(v => v.id === r.vehicleId);
    if (!veh) return;

    totalDistanceKm += r.distanceKm;
    
    // Emissions calculations based on truck propulsion
    if (veh.propulsion === PropulsionType.DIESEL) {
      // 1.01 to 1.15 kg CO2 per km for heavy refuse trucks
      const rate = veh.co2EmissionsKgPerKm || 1.1;
      dieselCo2Kg += r.distanceKm * rate;
      // Fuel cost: £1.45/L, consuming 38-44L/100km -> ~£0.60/km
      operationalCostGBP += r.distanceKm * 0.62 + (r.durationMinutes * 0.45); // fuel + driver wage
    } else if (veh.propulsion === PropulsionType.ELECTRIC) {
      // Clean tailpipe, grid electric cost: 1.4 kWh/km, charging at 25p/kWh -> ~35p/km
      electricEnergyKwh += r.distanceKm * 1.4;
      operationalCostGBP += r.distanceKm * 0.35 + (r.durationMinutes * 0.45);
    } else if (veh.propulsion === PropulsionType.HYDROGEN) {
      // Clean tailpipe, green hydrogen cost: 0.08 kgH2/km, £10/kg -> ~80p/km
      hydrogenKg += r.distanceKm * 0.08;
      operationalCostGBP += r.distanceKm * 0.80 + (r.durationMinutes * 0.45);
    }
  });

  // Calculate CO2 avoided (compared to 100% diesel fleet at 1.1 kg CO2/km)
  const theoreticalDieselCo2 = totalDistanceKm * 1.1;
  const co2AvoidedKg = Math.max(0, theoreticalDieselCo2 - dieselCo2Kg);

  return {
    dieselCo2Kg: Math.round(dieselCo2Kg),
    electricEnergyKwh: Math.round(electricEnergyKwh),
    hydrogenKg: Math.round(hydrogenKg),
    totalDistanceKm: Math.round(totalDistanceKm),
    co2AvoidedKg: Math.round(co2AvoidedKg),
    operationalCostGBP: Math.round(operationalCostGBP)
  };
}
