import { ForecastPoint, YorkshireRegion, CollectionType } from "./types";
import { REGIONAL_HISTORICAL_TONNAGE, WASTE_TYPE_SEASONALITY, ARIMA_COEFFICIENTS } from "./data";

/**
 * Simulates R-driven ARIMA / ETS statistical forecasting suite.
 * Generates predictions for the next 12 months with confidence intervals.
 */
export function generateVolumeForecast(
  region: YorkshireRegion,
  collectionType: CollectionType,
  annualGrowthRate = 0.025, // 2.5% default annual population/waste growth
  recyclingRateShift = 0, // -10% to +10% target shifting General to Recycling
  monthsAhead = 12
): ForecastPoint[] {
  // 1. Retrieve baseline regional monthly historical tonnage (24 months)
  const baseTonnageArray = REGIONAL_HISTORICAL_TONNAGE[region];
  const seasonalityList = WASTE_TYPE_SEASONALITY[collectionType];
  
  // Base split of waste type (approximate share of total council tonnage)
  let wasteShare = 0.50; // General waste is 50% of municipal tonnage
  if (collectionType === CollectionType.RECYCLING) wasteShare = 0.28;
  else if (collectionType === CollectionType.GARDEN_WASTE) wasteShare = 0.12;
  else if (collectionType === CollectionType.FOOD_WASTE) wasteShare = 0.06;
  else if (collectionType === CollectionType.COMMERCIAL_WASTE) wasteShare = 0.08;
  else if (collectionType === CollectionType.GLASS) wasteShare = 0.04;
  else if (collectionType === CollectionType.CLINICAL_WASTE) wasteShare = 0.01;
  else if (collectionType === CollectionType.BULKY_WASTE) wasteShare = 0.01;

  // Apply recycling target shift
  if (collectionType === CollectionType.GENERAL_WASTE) {
    wasteShare = Math.max(0.10, wasteShare - (recyclingRateShift / 100));
  } else if (collectionType === CollectionType.RECYCLING) {
    wasteShare = Math.min(0.60, wasteShare + (recyclingRateShift / 100));
  }

  // Construct historical sequence (last 12 months for visual baseline)
  const historyPoints: ForecastPoint[] = [];
  const startYear = 2025;
  const monthNames = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];

  // We map the second half of baseTonnage (months 12-23) as "Actuals"
  for (let i = 12; i < 24; i++) {
    const monthIdx = i % 12;
    const rawTotal = baseTonnageArray[i];
    
    // Scale by waste type share and standard seasonality multiplier
    const actualTonnage = rawTotal * wasteShare * seasonalityList[monthIdx];
    
    historyPoints.push({
      date: `${monthNames[monthIdx]} ${startYear + 1}`,
      actualTonnage: Math.round(actualTonnage),
      forecastTonnage: Math.round(actualTonnage),
      confidenceLower: Math.round(actualTonnage * 0.96),
      confidenceUpper: Math.round(actualTonnage * 1.04)
    });
  }

  // 2. Generate future projections using simulated R forecasting math:
  // f(t) = (f(t-1) * (1 + growth)) * seasonality_multiplier + ARIMA_noise
  const forecastPoints: ForecastPoint[] = [];
  let lastActualValue = historyPoints[historyPoints.length - 1].actualTonnage || 1000;
  
  const ar1 = ARIMA_COEFFICIENTS.ar1;
  const drift = ARIMA_COEFFICIENTS.drift;
  let prevError = 0;
  let prevARDiff = 0;

  for (let step = 1; step <= monthsAhead; step++) {
    const monthIdx = (24 + step - 1) % 12;
    const yearOffset = Math.floor((24 + step - 1) / 12);
    const forecastYear = startYear + yearOffset + 1;
    
    // Compute compound monthly growth
    const monthlyGrowth = annualGrowthRate / 12;
    const growthScale = Math.pow(1 + monthlyGrowth, step);
    
    // R Auto-Arima (1,1,1) auto-correlative simulation
    const whiteNoise = (Math.sin(step * 0.8) * 12) + (Math.cos(step * 1.5) * 6); // Simulated residual error
    const arDiff = prevARDiff * ar1 + drift + whiteNoise;
    const movingAverageTerm = prevError * ARIMA_COEFFICIENTS.ma1;
    
    // Baseline model computation
    const baseTotal = baseTonnageArray[23] * growthScale;
    let predictedTonnage = baseTotal * wasteShare * seasonalityList[monthIdx] + arDiff + movingAverageTerm;
    predictedTonnage = Math.max(5, predictedTonnage); // floor at 5 tons

    // Save states for next steps
    prevARDiff = arDiff - drift;
    prevError = whiteNoise;

    // Confidence intervals widen over time, typical of ARIMA models (R `forecast` package)
    const variancePercent = 0.04 + (step * 0.015); // widens by 1.5% each month
    const confidenceLower = Math.max(0, predictedTonnage * (1 - variancePercent));
    const confidenceUpper = predictedTonnage * (1 + variancePercent);

    forecastPoints.push({
      date: `${monthNames[monthIdx]} ${forecastYear}`,
      forecastTonnage: Math.round(predictedTonnage),
      confidenceLower: Math.round(confidenceLower),
      confidenceUpper: Math.round(confidenceUpper)
    });
  }

  return [...historyPoints, ...forecastPoints];
}

/**
 * Simulates financial cost forecasts and carbon offset analysis across Yorkshire
 */
export interface ScenarioMetrics {
  totalTonnage: number;
  collectionCosts: number;
  landfillTaxCosts: number; // Yorkshire council penalties
  carbonFootprintTons: number;
  recyclingRate: number;
}

export function evaluateScenario(
  region: YorkshireRegion,
  annualGrowth: number,
  recyclingShift: number,
  electricHydrogenSharePercent: number // 0 to 100% green fleet
): ScenarioMetrics {
  const baseTonnageArray = REGIONAL_HISTORICAL_TONNAGE[region];
  const lastYearTotal = baseTonnageArray.slice(12, 24).reduce((s, x) => s + x, 0);
  
  // Future volume with compound growth
  const projectedTonnage = lastYearTotal * (1 + annualGrowth / 100);
  
  // Base recycling rate for Yorkshire: Hull/East Riding around 48%, Leeds around 38%
  let baseRecycling = 40;
  if (region === YorkshireRegion.EAST_RIDING) baseRecycling = 52;
  else if (region === YorkshireRegion.HULL) baseRecycling = 48;
  else if (region === YorkshireRegion.NORTH_YORKSHIRE) baseRecycling = 44;

  const currentRecyclingRate = Math.min(85, Math.max(10, baseRecycling + recyclingShift));
  const generalWasteShare = 1 - (currentRecyclingRate / 100);

  // Financial Modelling
  // General waste to Landfill incurs Landfill Tax (UK £102.10/tonne for 2026/27) plus handling gates (£80) = £182/tonne
  // Recycling is cheaper to process (average gate fee of £45/tonne)
  // Food/Garden waste averages £35/tonne for Anaerobic Digestion
  const generalWasteTons = projectedTonnage * generalWasteShare;
  const recyclingTons = projectedTonnage * (currentRecyclingRate / 100);
  
  const landfillTaxCosts = generalWasteTons * 102.10; // strictly standard UK landfill tax
  const sortingGateFees = recyclingTons * 45.00 + generalWasteTons * 80.00;
  const fleetOperationalCosts = projectedTonnage * 32.50; // standard collection logistics factor

  // Cost adjustments based on Green Fleet share
  // Electric/Hydrogen have higher acquisition but 45% lower maintenance & energy costs
  const logisticsDiscount = (electricHydrogenSharePercent / 100) * 0.15; // up to 15% logistic saving
  const finalCollectionCosts = fleetOperationalCosts * (1 - logisticsDiscount) + sortingGateFees;

  // Carbon Emissions:
  // Base diesel fleet emissions: ~0.11 kg CO2 per household collection, or approx 12 kg CO2 per tonne collected.
  // Landfill waste generates methane (1 tonne general waste = ~250 kg CO2e indirect footprint)
  const fleetCarbonTons = (projectedTonnage * 12 / 1000) * (1 - (electricHydrogenSharePercent / 100));
  const indirectDecompositionCarbonTons = (generalWasteTons * 250 / 1000);
  const totalCarbonFootprint = fleetCarbonTons + indirectDecompositionCarbonTons;

  return {
    totalTonnage: Math.round(projectedTonnage),
    collectionCosts: Math.round(finalCollectionCosts),
    landfillTaxCosts: Math.round(landfillTaxCosts),
    carbonFootprintTons: Math.round(totalCarbonFootprint),
    recyclingRate: currentRecyclingRate
  };
}
