import React, { useState } from "react";
import { 
  YorkshireRegion, 
  CollectionType, 
  Vehicle, 
  Driver, 
  CollectionRoute, 
  LedgerBlock,
  VehicleStatus
} from "./types";
import { 
  DEPOTS, 
  INITIAL_VEHICLES, 
  INITIAL_DRIVERS, 
  INITIAL_LEDGER 
} from "./data";
import GisMap from "./components/GisMap";
import RustEngine from "./components/RustEngine";
import RForecastSuite from "./components/RForecastSuite";
import FleetController from "./components/FleetController";
import AuditLedger from "./components/AuditLedger";
import ExecutiveReport from "./components/ExecutiveReport";
import { 
  LayoutDashboard, 
  Compass, 
  Cpu, 
  TrendingUp, 
  Truck, 
  ShieldCheck, 
  FileText, 
  Menu, 
  X,
  PlusCircle,
  Clock,
  Sparkles
} from "lucide-react";

export default function App() {
  // Navigation & View Shell States
  const [activeTab, setActiveTab] = useState<"gis" | "rust" | "r-forecast" | "fleet" | "ledger" | "reports">("gis");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Global Operations States
  const [selectedRegion, setSelectedRegion] = useState<YorkshireRegion>(YorkshireRegion.WEST_YORKSHIRE);
  const [selectedCollectionType, setSelectedCollectionType] = useState<CollectionType>(CollectionType.GENERAL_WASTE);
  
  // Real-time Database arrays
  const [vehicles, setVehicles] = useState<Vehicle[]>(INITIAL_VEHICLES);
  const [drivers, setDrivers] = useState<Driver[]>(INITIAL_DRIVERS);
  const [routes, setRoutes] = useState<CollectionRoute[]>([]);
  const [ledger, setLedger] = useState<LedgerBlock[]>(INITIAL_LEDGER);
  
  const [activeRouteId, setActiveRouteId] = useState<string | null>(null);

  // Helper to append transactional actions to the immutable audit ledger
  const handleAddLedgerEntry = (event: string, payload: string) => {
    setLedger((prev) => {
      const lastBlock = prev[prev.length - 1];
      const nextIdx = lastBlock.index + 1;
      
      // Simple hash generator mock (mimicking SHA-256)
      const mockHash = Math.sin(nextIdx * 123.4).toString(16).substring(2, 66);

      const newBlock: LedgerBlock = {
        index: nextIdx,
        timestamp: new Date().toISOString(),
        event,
        operator: "COUNCIL_LOGISTICS_COORD_04",
        payload,
        previousHash: lastBlock.hash,
        hash: mockHash
      };
      return [...prev, newBlock];
    });
  };

  // Fleet Actions
  const handleUpdateVehicleStatus = (id: string, status: VehicleStatus) => {
    setVehicles((prev) => 
      prev.map(v => v.id === id ? { ...v, status } : v)
    );
  };

  const handleAssignDriver = (vehicleId: string, driverId: string) => {
    // Roster updates: free previous vehicle of this driver, assign new one
    setVehicles((prevVeh) => 
      prevVeh.map(v => {
        if (v.id === vehicleId) return { ...v, driverId };
        if (v.driverId === driverId) return { ...v, driverId: undefined };
        return v;
      })
    );

    setDrivers((prevDrivers) => 
      prevDrivers.map(d => {
        if (d.id === driverId) return { ...d, assignedVehicleId: vehicleId, status: "On Shift" };
        if (d.assignedVehicleId === vehicleId && d.id !== driverId) return { ...d, assignedVehicleId: undefined, status: "Resting" };
        return d;
      })
    );
  };

  // Automatically seed some initial logical routes if routes are empty on load
  React.useEffect(() => {
    // We create simple default routes for the selected region to prevent a blank starting experience
    const depot = DEPOTS.find(d => d.region === selectedRegion) || DEPOTS[0];
    const initialRoute: CollectionRoute = {
      id: `route-${selectedRegion.substring(0,3).toLowerCase()}-gen-1`,
      name: `${selectedRegion} General Waste Round 1`,
      region: selectedRegion,
      collectionType: selectedCollectionType,
      depotId: depot.id,
      facilityId: "fac-leeds-efw",
      vehicleId: "v-01",
      driverName: "Alastair Hirst",
      streets: ["st-leeds-1", "st-leeds-2"],
      totalHouseholds: 320,
      plannedTonnage: 3.6,
      completedTonnage: 0,
      distanceKm: 24.5,
      durationMinutes: 145,
      missedCollections: 0,
      status: "Planned",
      points: [[280, 550], [250, 510], [230, 480], [240, 540], [310, 560]]
    };
    setRoutes([initialRoute]);
  }, [selectedRegion]);

  return (
    <div id="rhinoroute-app" className="min-h-screen bg-[#1A1C1E] text-[#D6D2C4] flex flex-col antialiased selection:bg-[#B87333] selection:text-white">
      
      {/* Top Banner & Corporate Header */}
      <header className="bg-[#0D1B2A] border-b border-[#4E545C] px-6 py-4 flex items-center justify-between z-10 shadow-md">
        <div className="flex items-center gap-3">
          {/* Logo element with Yorkshire Futurist copper aesthetic */}
          <div className="h-9 w-9 rounded bg-[#B87333] flex items-center justify-center font-bold text-[#1A1C1E] tracking-widest text-lg shadow-lg shadow-[#B87333]/20 select-none">
            R
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-white text-base font-extrabold tracking-wider uppercase font-mono">
                Rhino<span className="font-light opacity-80">Route</span>
              </h1>
              <span className="text-[10px] bg-[#1A1C1E] text-[#B87333] border border-[#4E545C] px-1.5 py-0.5 rounded font-mono font-bold tracking-widest">
                MUNICIPAL LOGISTICS
              </span>
            </div>
            <p className="text-[10px] text-gray-400 font-mono mt-0.5">
              Refuse collection routing and statistical analytics for Rhino Bank
            </p>
          </div>
        </div>

        {/* Global Stats bar */}
        <div className="hidden md:flex items-center gap-6 font-mono text-xs">
          <div className="text-right">
            <span className="text-gray-500 block text-[9px] uppercase tracking-wider">Total Councils</span>
            <span className="text-[#D6D2C4] font-bold">5 Yorkshire Authorities</span>
          </div>
          <div className="h-8 w-[1px] bg-[#4E545C]"></div>
          <div className="text-right">
            <span className="text-gray-500 block text-[9px] uppercase tracking-wider">Fleet Status</span>
            <span className="text-green-400 font-bold">62% Green (BEV/FCEV)</span>
          </div>
          <div className="h-8 w-[1px] bg-[#4E545C]"></div>
          <div className="text-right">
            <span className="text-gray-500 block text-[9px] uppercase tracking-wider">Database Link</span>
            <span className="text-[#10b981] font-bold flex items-center gap-1 justify-end">
              <span className="w-1.5 h-1.5 bg-[#10b981] rounded-full"></span> PostgreSQL
            </span>
          </div>
        </div>
      </header>

      {/* Main Core Layout: Sidebar + Viewport */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Sidebar Navigation */}
        <aside className={`${isSidebarOpen ? "w-64" : "w-16"} bg-[#0D1B2A] border-r border-[#4E545C] transition-all duration-300 flex flex-col justify-between z-10 font-mono text-xs`}>
          <div className="py-4 px-2 space-y-1">
            {/* Nav Title */}
            {isSidebarOpen && (
              <div className="px-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-4">
                Operations Panel
              </div>
            )}

            {/* Nav items */}
            {[
              { id: "gis", label: "GIS Control Room", icon: Compass },
              { id: "rust", label: "Heuristic Solver", icon: Cpu },
              { id: "r-forecast", label: "R Forecast Engine", icon: TrendingUp },
              { id: "fleet", label: "Fleet & Crews", icon: Truck },
              { id: "ledger", label: "Audit Ledger", icon: ShieldCheck },
              { id: "reports", label: "Executive Reports", icon: FileText }
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-all ${
                    isActive
                      ? "bg-[#1A1C1E] text-[#B87333] border-l-2 border-[#B87333]"
                      : "text-gray-400 hover:text-white hover:bg-[#15181c]"
                  }`}
                  title={item.label}
                >
                  <Icon size={18} />
                  {isSidebarOpen && <span className="font-medium">{item.label}</span>}
                </button>
              );
            })}
          </div>

          {/* Sidebar Toggle at bottom */}
          <div className="p-3 border-t border-[#4E545C]">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="w-full flex items-center justify-center p-2 rounded bg-[#1A1C1E] hover:bg-[#15181c] border border-[#4E545C] text-gray-400 cursor-pointer"
            >
              {isSidebarOpen ? "Collapse Navigation" : "»"}
            </button>
          </div>
        </aside>

        {/* Viewport content area */}
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Top Quick Telemetry KPIs */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            
            {/* KPI 1 */}
            <div className="bg-[#0D1B2A] border border-[#4E545C] p-4 rounded-xl shadow-md font-mono">
              <div className="flex items-center justify-between text-gray-500 mb-1">
                <span className="text-[10px] uppercase tracking-wider font-bold">Active Region</span>
                <Compass size={14} className="text-[#B87333]" />
              </div>
              <div className="text-sm font-extrabold text-white truncate">{selectedRegion}</div>
              <span className="text-[9px] text-gray-400 mt-0.5 block">Target Yorkshire Authority</span>
            </div>

            {/* KPI 2 */}
            <div className="bg-[#0D1B2A] border border-[#4E545C] p-4 rounded-xl shadow-md font-mono">
              <div className="flex items-center justify-between text-gray-500 mb-1">
                <span className="text-[10px] uppercase tracking-wider font-bold">Optimised Rounds</span>
                <Cpu size={14} className="text-[#B87333]" />
              </div>
              <div className="text-sm font-extrabold text-white truncate">{routes.length} Active VRP Runs</div>
              <span className="text-[9px] text-[#10b981] mt-0.5 block font-bold">✓ Converged successfully</span>
            </div>

            {/* KPI 3 */}
            <div className="bg-[#0D1B2A] border border-[#4E545C] p-4 rounded-xl shadow-md font-mono">
              <div className="flex items-center justify-between text-gray-500 mb-1">
                <span className="text-[10px] uppercase tracking-wider font-bold">Fleet Dispatch Ratio</span>
                <Truck size={14} className="text-[#10b981]" />
              </div>
              <div className="text-sm font-extrabold text-white truncate">
                {vehicles.filter(v => v.status === VehicleStatus.ACTIVE).length} Active Crew Units
              </div>
              <span className="text-[9px] text-gray-400 mt-0.5 block">0 units grounded for check</span>
            </div>

            {/* KPI 4 */}
            <div className="bg-[#0D1B2A] border border-[#4E545C] p-4 rounded-xl shadow-md font-mono">
              <div className="flex items-center justify-between text-gray-500 mb-1">
                <span className="text-[10px] uppercase tracking-wider font-bold">Ledger Integrity</span>
                <ShieldCheck size={14} className="text-green-500" />
              </div>
              <div className="text-sm font-extrabold text-[#10b981] truncate">SHA-256 Verified</div>
              <span className="text-[9px] text-gray-400 mt-0.5 block">{ledger.length} immutable hashes recorded</span>
            </div>

          </div>

          {/* Dynamic Tab Panel viewport switcher */}
          <div className="transition-all duration-300">
            {activeTab === "gis" && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <GisMap
                    selectedRegion={selectedRegion}
                    selectedCollectionType={selectedCollectionType}
                    routes={routes}
                    activeRouteId={activeRouteId}
                    onSelectRoute={setActiveRouteId}
                  />
                </div>
                
                {/* Route selection side information card */}
                <div className="bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg flex flex-col justify-between font-mono text-xs">
                  <div>
                    <div className="flex items-center gap-2 mb-4 border-b border-[#4E545C] pb-2">
                      <Compass className="text-[#B87333] h-5 w-5" />
                      <h3 className="text-white text-xs font-semibold tracking-wider uppercase">
                        Active Route Logbook
                      </h3>
                    </div>

                    {/* Left Council Selectors inside HUD panel */}
                    <div className="space-y-4">
                      <div>
                        <label className="block text-gray-500 text-[10px] uppercase mb-1">Active Council Focus:</label>
                        <select
                          value={selectedRegion}
                          onChange={(e) => setSelectedRegion(e.target.value as YorkshireRegion)}
                          className="w-full bg-[#1A1C1E] border border-[#4E545C] text-[#D6D2C4] py-1.5 px-2 rounded focus:outline-none focus:border-[#B87333]"
                        >
                          {Object.values(YorkshireRegion).map(r => (
                            <option key={r} value={r}>{r}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-gray-500 text-[10px] uppercase mb-1">Logistics Round Type:</label>
                        <select
                          value={selectedCollectionType}
                          onChange={(e) => setSelectedCollectionType(e.target.value as CollectionType)}
                          className="w-full bg-[#1A1C1E] border border-[#4E545C] text-[#D6D2C4] py-1.5 px-2 rounded focus:outline-none focus:border-[#B87333]"
                        >
                          {Object.values(CollectionType).map(t => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Selected route details */}
                    <div className="mt-6 space-y-3 bg-[#1A1C1E] p-4 rounded-lg border border-[#4E545C]">
                      <div className="font-bold text-white uppercase text-[10px] tracking-wider border-b border-[#4E545C] pb-1 flex items-center justify-between">
                        <span>PLANNER SUMMARY</span>
                        <span className="text-[#B87333]">VRP Active</span>
                      </div>
                      
                      {routes.filter(r => r.region === selectedRegion && r.collectionType === selectedCollectionType).length > 0 ? (
                        routes.filter(r => r.region === selectedRegion && r.collectionType === selectedCollectionType).map(r => (
                          <div key={r.id} className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-gray-500">Route ID:</span>
                              <span className="text-[#B87333] font-bold">{r.id.toUpperCase()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Assigned Driver:</span>
                              <span className="text-[#D6D2C4] font-bold">{r.driverName}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Planned Tonnage:</span>
                              <span className="text-[#D6D2C4]">{r.plannedTonnage} tonnes</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Distance Travelled:</span>
                              <span className="text-[#D6D2C4]">{r.distanceKm} km</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Round Duration:</span>
                              <span className="text-[#D6D2C4]">{r.durationMinutes} mins</span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-gray-500 italic text-[11px] py-4">
                          No solver route generated for this type. Please navigate to the 'Heuristic Solver' tab in the left sidebar to compile optimized VRP routes.
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-[#4E545C] text-[10px] text-gray-500 space-y-2">
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-[#B87333] rounded-full"></span>
                      <span>Coordinates computed via PostGIS functions</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "rust" && (
              <RustEngine
                selectedRegion={selectedRegion}
                selectedCollectionType={selectedCollectionType}
                vehicles={vehicles}
                drivers={drivers}
                onRoutesOptimized={setRoutes}
                onAddLedgerEntry={handleAddLedgerEntry}
              />
            )}

            {activeTab === "r-forecast" && (
              <RForecastSuite
                selectedRegion={selectedRegion}
                onChangeRegion={setSelectedRegion}
                selectedCollectionType={selectedCollectionType}
                onChangeCollectionType={setSelectedCollectionType}
              />
            )}

            {activeTab === "fleet" && (
              <FleetController
                vehicles={vehicles}
                drivers={drivers}
                onUpdateVehicleStatus={handleUpdateVehicleStatus}
                onAssignDriver={handleAssignDriver}
                onAddLedgerEntry={handleAddLedgerEntry}
              />
            )}

            {activeTab === "ledger" && (
              <AuditLedger
                ledger={ledger}
              />
            )}

            {activeTab === "reports" && (
              <ExecutiveReport
                selectedRegion={selectedRegion}
                routes={routes}
                vehicles={vehicles}
              />
            )}
          </div>
          
          {/* AI Logistics Copilot Interactive Widget at bottom */}
          <div className="bg-[#0D1B2A]/90 backdrop-blur border border-[#4E545C] rounded-xl p-4 font-mono text-xs text-[#D6D2C4]">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="text-[#B87333] h-4 w-4" />
              <span className="font-bold uppercase tracking-wider text-[10px] text-[#B87333]">AI ROUTING COPILOT (MUNICIPAL ASSISTANT)</span>
            </div>
            <div className="bg-[#1A1C1E] border border-[#4E545C] rounded p-3 text-gray-300 leading-relaxed max-h-[140px] overflow-y-auto">
              <p>
                <strong>Welcome, Operations Planner.</strong> I am synchronised with RhinoRoute's forecasting metrics for <strong>{selectedRegion}</strong>. I can assist you with scenario optimization.
              </p>
              <p className="mt-1.5">
                • <strong>Insight:</strong> Garden Waste volumes are entering their summer surge (+190% vs base). The optimal move is to redeploy Diesel Truck YG22 KLS to compost streams and assign extra shifts to Alastair Hirst. This reduces missed bins by 1.8% and decreases local tipping tax expenses by 12.5%.
              </p>
            </div>
          </div>

        </main>
      </div>

      {/* Footer System Details */}
      <footer className="bg-[#0D1B2A] border-t border-[#4E545C] px-6 py-3 flex flex-wrap items-center justify-between text-[10px] text-gray-500 font-mono">
        <div>
          <span>RHINOROUTE SYSTEM LOG • PORT 3000 CONSOLE</span>
        </div>
        <div className="flex items-center gap-4">
          <span>PostgreSQL 16.3 + PostGIS 3.4.2</span>
          <span>R 4.4.1 (forecast, tidyverse, spatial)</span>
          <span>Rust toolchain v1.79.0</span>
        </div>
      </footer>

    </div>
  );
}
