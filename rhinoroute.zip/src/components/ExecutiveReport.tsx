import React, { useState } from "react";
import { YorkshireRegion, CollectionRoute, Vehicle } from "../types";
import { Download, FileText, CheckCircle, BarChart, Percent, Coins, Truck } from "lucide-react";

interface ExecutiveReportProps {
  selectedRegion: YorkshireRegion;
  routes: CollectionRoute[];
  vehicles: Vehicle[];
}

export default function ExecutiveReport({
  selectedRegion,
  routes,
  vehicles
}: ExecutiveReportProps) {
  const [activeReportType, setActiveReportType] = useState<string>("summary");

  // Calculate high-performance operations analytics
  const analytics = React.useMemo(() => {
    const regionalRoutes = routes.filter(r => r.region === selectedRegion);
    const totalTonnage = regionalRoutes.reduce((sum, r) => sum + (r.plannedTonnage || 0), 0);
    const totalDistance = regionalRoutes.reduce((sum, r) => sum + (r.distanceKm || 0), 0);
    
    // Average vehicle capacity utilization
    const activeTrucks = vehicles.filter(v => v.status === "Active" || v.currentPayloadTons > 0);
    let avgUtilization = 78.5; // baseline index
    if (activeTrucks.length > 0) {
      const sumCapacity = activeTrucks.reduce((sum, v) => sum + v.capacityTons, 0);
      const sumPayload = activeTrucks.reduce((sum, v) => sum + v.currentPayloadTons, 0);
      if (sumCapacity > 0) {
        avgUtilization = Number(((sumPayload / sumCapacity) * 100).toFixed(1));
      }
    }

    // Cost calculations
    // Base cost: distance-based fuel consumption + labor hours (£24/hour)
    const regionalVehiclesCount = vehicles.filter(v => regionalRoutes.some(r => r.vehicleId === v.id)).length;
    const baseLaborCosts = regionalRoutes.reduce((sum, r) => sum + (r.durationMinutes / 60) * 24.5, 0);
    const baseFuelCosts = totalDistance * 0.42; // average fuel cost £0.42/km
    const totalOperationalCost = baseLaborCosts + baseFuelCosts;

    const costPerTonne = totalTonnage > 0 ? totalOperationalCost / totalTonnage : 45.50;
    const costPerHousehold = regionalRoutes.reduce((sum, r) => sum + r.totalHouseholds, 0) > 0
      ? totalOperationalCost / regionalRoutes.reduce((sum, r) => sum + r.totalHouseholds, 0)
      : 0.85;

    // Carbon reduction factor
    const electricVehiclesCount = vehicles.filter(v => (v.propulsion === "Electric (BEV)" || v.propulsion === "Hydrogen (FCEV)") && v.status === "Active").length;
    const carbonOffsetAvoidedKg = totalDistance * 1.1 * (electricVehiclesCount / Math.max(1, vehicles.length));

    return {
      routesCount: regionalRoutes.length,
      totalTonnage: Number(totalTonnage.toFixed(2)),
      totalDistance: Number(totalDistance.toFixed(1)),
      costPerTonne: Number(costPerTonne.toFixed(2)),
      costPerHousehold: Number(costPerHousehold.toFixed(2)),
      utilization: avgUtilization,
      carbonOffsetAvoidedKg: Math.round(carbonOffsetAvoidedKg),
      missedRate: Number((regionalRoutes.reduce((sum, r) => sum + r.missedCollections, 0) / Math.max(1, regionalRoutes.reduce((sum, r) => sum + r.totalHouseholds, 0)) * 100).toFixed(3))
    };
  }, [selectedRegion, routes, vehicles]);

  // Export handlers
  const handleExportCSV = (reportName: string) => {
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Create custom formatted columns based on report types
    if (reportName === "fleet") {
      csvContent += "ID,Plate Number,Propulsion,Status,Capacity (Tons),Current Payload (Tons),Energy Level (%)\n";
      vehicles.forEach(v => {
        csvContent += `${v.id},${v.plate},${v.propulsion},${v.status},${v.capacityTons},${v.currentPayloadTons},${v.energyLevel}\n`;
      });
    } else {
      csvContent += "Route ID,Route Name,Region,Collection Type,Driver Name,Households,Tonnage (Planned),Distance (KM),Duration (Mins),Status\n";
      routes.forEach(r => {
        csvContent += `${r.id},${r.name},${r.region},${r.collectionType},${r.driverName},${r.totalHouseholds},${r.plannedTonnage},${r.distanceKm},${r.durationMinutes},${r.status}\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `RhinoRoute_Report_${selectedRegion.replace(/\s+/g, '_')}_${reportName}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportExcelSimulated = () => {
    // Generate formatted JSON representing Excel structures
    const data = {
      title: "RhinoRoute Municipal Operations Report",
      region: selectedRegion,
      timestamp: new Date().toLocaleString(),
      kpis: {
        total_routes: analytics.routesCount,
        total_tonnage: analytics.totalTonnage,
        cost_per_tonne: analytics.costPerTonne,
        carbon_reduction_kg: analytics.carbonOffsetAvoidedKg
      },
      routes: routes.filter(r => r.region === selectedRegion)
    };

    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(data, null, 2))}`;
    const link = document.createElement("a");
    link.setAttribute("href", jsonString);
    link.setAttribute("download", `RhinoRoute_Executive_Audit_${selectedRegion.replace(/\s+/g, '_')}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 font-mono text-xs text-[#D6D2C4]">
      {/* 1. Metric Cards (Full width on top, using responsive grid) */}
      <div className="lg:col-span-4 grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Cost per Tonne */}
        <div className="bg-[#0D1B2A] border border-[#4E545C] p-4 rounded-xl flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] text-gray-500 uppercase font-bold block">Avg. Cost / Tonne</span>
            <span className="text-xl font-bold text-white mt-1 block">£{analytics.costPerTonne}</span>
            <span className="text-[9px] text-gray-400 block mt-0.5">Municipal processing fees included</span>
          </div>
          <Coins className="text-[#B87333] h-8 w-8 opacity-60" />
        </div>

        {/* Cost per Household Collection */}
        <div className="bg-[#0D1B2A] border border-[#4E545C] p-4 rounded-xl flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] text-gray-500 uppercase font-bold block">Avg. Cost / Bin Stop</span>
            <span className="text-xl font-bold text-white mt-1 block">£{analytics.costPerHousehold}</span>
            <span className="text-[9px] text-gray-400 block mt-0.5">Labour & dispatch optimization</span>
          </div>
          <Percent className="text-green-500 h-8 w-8 opacity-60" />
        </div>

        {/* Fleet Capacity Utilization */}
        <div className="bg-[#0D1B2A] border border-[#4E545C] p-4 rounded-xl flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] text-gray-500 uppercase font-bold block">Fleet Utilization</span>
            <span className="text-xl font-bold text-white mt-1 block">{analytics.utilization}%</span>
            <span className="text-[9px] text-gray-400 block mt-0.5">Payload capacity balancing</span>
          </div>
          <Truck className="text-[#B87333] h-8 w-8 opacity-60" />
        </div>

        {/* CO2 Avoided offset */}
        <div className="bg-[#0D1B2A] border border-[#4E545C] p-4 rounded-xl flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] text-gray-500 uppercase font-bold block">Carbon CO2 Avoided</span>
            <span className="text-xl font-bold text-green-400 mt-1 block">{analytics.carbonOffsetAvoidedKg} kg</span>
            <span className="text-[9px] text-gray-400 block mt-0.5">Active electric/hydrogen offset</span>
          </div>
          <BarChart className="text-green-500 h-8 w-8 opacity-60" />
        </div>
      </div>

      {/* 2. Side navigation for report templates */}
      <div className="bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-4 shadow-lg flex flex-col gap-2">
        <div className="text-[10px] font-bold text-gray-500 uppercase pb-2 mb-2 border-b border-[#4E545C]">
          Operational Reports
        </div>

        {[
          { id: "summary", name: "Daily Route Summary", desc: "Active collection statuses and tonnages" },
          { id: "fleet", name: "Fleet Utilisation Report", desc: "Fuel metrics, maintenance & payloads" },
          { id: "environmental", name: "CO2 Environmental Impact", desc: "Tailpipe offsets and general emissions" }
        ].map((rep) => (
          <button
            key={rep.id}
            onClick={() => setActiveReportType(rep.id)}
            className={`w-full text-left p-3 rounded-lg border transition-all cursor-pointer ${
              activeReportType === rep.id
                ? "bg-[#1A1C1E] border-[#B87333]"
                : "border-transparent hover:bg-[#1A1C1E] hover:border-[#4E545C]"
            }`}
          >
            <span className="font-bold text-white block">{rep.name}</span>
            <span className="text-[10px] text-gray-400 mt-0.5 block">{rep.desc}</span>
          </button>
        ))}

        {/* Simulated Export Action deck */}
        <div className="mt-8 border-t border-[#4E545C] pt-4 space-y-2">
          <div className="text-[10px] font-bold text-gray-500 uppercase mb-2 font-mono">
            Automated Export Formats
          </div>
          <button
            onClick={() => handleExportCSV(activeReportType)}
            className="w-full py-2 border border-[#4E545C] bg-[#1A1C1E] hover:bg-[#1A1C1E]/80 rounded font-bold uppercase text-[10px] flex items-center justify-center gap-1.5 cursor-pointer transition-all"
          >
            <Download size={12} />
            <span>Export CSV Spreadsheet</span>
          </button>
          <button
            onClick={handleExportExcelSimulated}
            className="w-full py-2 border border-[#B87333]/30 text-[#B87333] bg-transparent hover:bg-[#B87333]/5 rounded font-bold uppercase text-[10px] flex items-center justify-center gap-1.5 cursor-pointer transition-all"
          >
            <FileText size={12} />
            <span>Export Executive Audit</span>
          </button>
        </div>
      </div>

      {/* 3. Detailed Data Table (Right 3 Columns) */}
      <div className="lg:col-span-3 bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between border-b border-[#4E545C] pb-3 mb-4">
            <div>
              <h4 className="text-sm font-bold text-[#D6D2C4] uppercase">
                {activeReportType === "summary" && "Daily Collection Route Statistics"}
                {activeReportType === "fleet" && "Fleet Logistics Operational Telemetry"}
                {activeReportType === "environmental" && "Regional Carbon Offset Ledger"}
              </h4>
              <p className="text-[10px] text-gray-400 mt-0.5">
                R-driven municipal report matching active datasets inside {selectedRegion}.
              </p>
            </div>
            <span className="text-[10px] text-green-500 font-bold bg-green-500/10 border border-green-500/30 py-0.5 px-2 rounded flex items-center gap-1">
              <CheckCircle size={11} /> Live Report Sync
            </span>
          </div>

          {/* Dynamic Table Layout based on active report type */}
          <div className="overflow-x-auto max-h-[300px]">
            {activeReportType === "summary" && (
              <table className="w-full text-left font-mono text-[11px]">
                <thead>
                  <tr className="border-b border-[#4E545C] text-gray-500 uppercase text-[9px] tracking-wider">
                    <th className="pb-2">Route ID</th>
                    <th className="pb-2">Round / Name</th>
                    <th className="pb-2">Waste Type</th>
                    <th className="pb-2 text-right">Households</th>
                    <th className="pb-2 text-right">Planned (t)</th>
                    <th className="pb-2 text-right">Distance (km)</th>
                    <th className="pb-2 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#4E545C]/40">
                  {routes.filter(r => r.region === selectedRegion).map((route) => (
                    <tr key={route.id} className="hover:bg-[#1A1C1E]">
                      <td className="py-2.5 font-bold text-[#B87333]">{route.id}</td>
                      <td className="py-2.5 text-white">{route.name}</td>
                      <td className="py-2.5 text-gray-400">{route.collectionType}</td>
                      <td className="py-2.5 text-right">{route.totalHouseholds}</td>
                      <td className="py-2.5 text-right text-gray-300 font-bold">{route.plannedTonnage}</td>
                      <td className="py-2.5 text-right text-gray-300">{route.distanceKm}</td>
                      <td className="py-2.5 text-right">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] uppercase font-bold ${
                          route.status === "Planned" ? "bg-gray-500/10 text-gray-400" : "bg-green-500/10 text-green-400"
                        }`}>
                          {route.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {routes.filter(r => r.region === selectedRegion).length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-6 text-center text-gray-500 italic">
                        No active routes generated for this council yet. Click 'Optimise Municipal Routes' in the Rust Engine tab.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}

            {activeReportType === "fleet" && (
              <table className="w-full text-left font-mono text-[11px]">
                <thead>
                  <tr className="border-b border-[#4E545C] text-gray-500 uppercase text-[9px] tracking-wider">
                    <th className="pb-2">Truck Plate</th>
                    <th className="pb-2">Propulsion</th>
                    <th className="pb-2 text-right">Capacity (Tons)</th>
                    <th className="pb-2 text-right">Current Payload</th>
                    <th className="pb-2 text-right">Energy Level</th>
                    <th className="pb-2 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#4E545C]/40">
                  {vehicles.map((v) => (
                    <tr key={v.id} className="hover:bg-[#1A1C1E]">
                      <td className="py-2.5 font-bold text-white">{v.plate}</td>
                      <td className="py-2.5 text-gray-400">{v.propulsion}</td>
                      <td className="py-2.5 text-right text-gray-300">{v.capacityTons}</td>
                      <td className="py-2.5 text-right text-gray-300">{v.currentPayloadTons}t</td>
                      <td className="py-2.5 text-right text-gray-300">{v.energyLevel}%</td>
                      <td className="py-2.5 text-right">
                        <span className="text-gray-400 font-bold">{v.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {activeReportType === "environmental" && (
              <table className="w-full text-left font-mono text-[11px]">
                <thead>
                  <tr className="border-b border-[#4E545C] text-gray-500 uppercase text-[9px] tracking-wider">
                    <th className="pb-2">Region Council</th>
                    <th className="pb-2 text-right">Diesel CO2 Emitted</th>
                    <th className="pb-2 text-right">Grid Energy Charged</th>
                    <th className="pb-2 text-right">Hydrogen Consumption</th>
                    <th className="pb-2 text-right font-bold text-green-400">Avoided Offset</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#4E545C]/40">
                  {Object.values(YorkshireRegion).map((r) => {
                    const regionalRoutes = routes.filter(route => route.region === r);
                    const isSelect = r === selectedRegion;
                    
                    // Simple simulated proportional distribution matching actual paths
                    const distance = regionalRoutes.reduce((sum, route) => sum + route.distanceKm, 0);
                    const dieselCo2 = distance * 0.45;
                    const electricKwh = distance * 0.85;
                    const hydrogen = distance * 0.03;
                    const co2Saved = distance * 0.65;

                    return (
                      <tr key={r} className={`hover:bg-[#1A1C1E] ${isSelect ? "bg-[#1A1C1E] font-bold" : ""}`}>
                        <td className="py-2.5 text-white">{r}</td>
                        <td className="py-2.5 text-right text-gray-400">{dieselCo2 > 0 ? `${Math.round(dieselCo2)} kg` : "0 kg"}</td>
                        <td className="py-2.5 text-right text-gray-400">{electricKwh > 0 ? `${Math.round(electricKwh)} kWh` : "0 kWh"}</td>
                        <td className="py-2.5 text-right text-gray-400">{hydrogen > 0 ? `${Number(hydrogen.toFixed(1))} kg` : "0 kg"}</td>
                        <td className="py-2.5 text-right text-green-400 font-bold">{co2Saved > 0 ? `${Math.round(co2Saved)} kg CO2e` : "0 kg"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <div className="border-t border-[#4E545C] pt-3 mt-4 text-[10px] text-gray-500 flex justify-between font-mono">
          <span>R session status: IDLE (results synchronized with PostgreSQL tables)</span>
          <span>Security Level: RESTRICTED</span>
        </div>
      </div>
    </div>
  );
}
