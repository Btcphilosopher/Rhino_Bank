import React, { useState } from "react";
import { 
  YorkshireRegion, 
  CollectionType, 
  SolverConfig, 
  SolverLog, 
  CollectionRoute,
  Vehicle,
  Driver
} from "../types";
import { solveRoutes } from "../solver";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { Cpu, Play, Terminal, Sliders, CheckCircle2, AlertTriangle } from "lucide-react";

interface RustEngineProps {
  selectedRegion: YorkshireRegion;
  selectedCollectionType: CollectionType;
  vehicles: Vehicle[];
  drivers: Driver[];
  onRoutesOptimized: (routes: CollectionRoute[]) => void;
  onAddLedgerEntry: (event: string, payload: string) => void;
}

export default function RustEngine({
  selectedRegion,
  selectedCollectionType,
  vehicles,
  drivers,
  onRoutesOptimized,
  onAddLedgerEntry
}: RustEngineProps) {
  const [config, setConfig] = useState<SolverConfig>({
    iterations: 1500,
    maxCapacityMultiplier: 1.0,
    weatherFactor: "Fine",
    trafficWeight: 35,
    speedLimitMultiplier: 1.0,
    timeWindowStrictness: "Standard",
    multiDepotBalancing: true
  });

  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [terminalLogs, setTerminalLogs] = useState<SolverLog[]>([]);
  const [convergenceData, setConvergenceData] = useState<{ iter: number; cost: number }[]>([]);

  const handleRunSolver = async () => {
    setIsRunning(true);
    setProgress(0);
    setTerminalLogs([]);
    setConvergenceData([]);

    // Call the VRP solver with live feedback callback
    const optimized = await solveRoutes(
      selectedRegion,
      selectedCollectionType,
      vehicles,
      drivers,
      config,
      (logs, convergence, prog) => {
        setTerminalLogs(logs);
        setConvergenceData(
          convergence.map((cost, idx) => ({
            iter: Math.round(((idx + 1) / convergence.length) * config.iterations),
            cost
          }))
        );
        setProgress(prog);
      }
    );

    setIsRunning(false);
    onRoutesOptimized(optimized);
    
    // Add transaction to the audit ledger
    onAddLedgerEntry(
      "VRP_OPTIMIZATION_RUN",
      `Optimized ${optimized.length} collection routes for ${selectedRegion} (${selectedCollectionType}) using CVRP. Iterations: ${config.iterations}`
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* 1. Hyper-parameter Sliders Panel */}
      <div className="bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Sliders className="text-[#B87333] h-5 w-5" />
            <h3 className="text-[#D6D2C4] text-xs font-semibold tracking-wider uppercase font-mono">
              Heuristic Solver Parameters (Rust)
            </h3>
          </div>

          <p className="text-xs text-gray-400 mb-5 leading-relaxed font-mono">
            Configure the underlying Rust spatial constraints engine before generating Capacitated Vehicle Routing (CVRPTW) paths.
          </p>

          <div className="space-y-4 font-mono text-xs">
            {/* Iterations */}
            <div>
              <div className="flex justify-between mb-1 text-gray-300">
                <span>Solver Iterations:</span>
                <span className="text-[#B87333] font-bold">{config.iterations}</span>
              </div>
              <input
                type="range"
                min="500"
                max="5000"
                step="250"
                value={config.iterations}
                onChange={(e) => setConfig({ ...config, iterations: parseInt(e.target.value) })}
                className="w-full accent-[#B87333] h-1 bg-[#1A1C1E] rounded-lg cursor-pointer"
                disabled={isRunning}
              />
            </div>

            {/* Truck Capacity Multiplier */}
            <div>
              <div className="flex justify-between mb-1 text-gray-300">
                <span>Capacity Safety Margins:</span>
                <span className="text-[#B87333] font-bold">{config.maxCapacityMultiplier}x</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.2"
                step="0.05"
                value={config.maxCapacityMultiplier}
                onChange={(e) => setConfig({ ...config, maxCapacityMultiplier: parseFloat(e.target.value) })}
                className="w-full accent-[#B87333] h-1 bg-[#1A1C1E] rounded-lg cursor-pointer"
                disabled={isRunning}
              />
            </div>

            {/* Weather Factors */}
            <div>
              <label className="block text-gray-300 mb-1">Weather Context:</label>
              <select
                value={config.weatherFactor}
                onChange={(e) => setConfig({ ...config, weatherFactor: e.target.value as any })}
                className="w-full bg-[#1A1C1E] border border-[#4E545C] text-[#D6D2C4] py-1.5 px-2 rounded focus:outline-none focus:border-[#B87333]"
                disabled={isRunning}
              >
                <option value="Fine">Fine (Dry Roads • Standard Speed)</option>
                <option value="Rain">Rain (Wet • Transit Speeds -15%)</option>
                <option value="Snow">Snow (Snow clearing • Speeds -40%)</option>
                <option value="Ice">Ice (High hazard • Extreme constraints)</option>
              </select>
            </div>

            {/* Traffic Congestion weight */}
            <div>
              <div className="flex justify-between mb-1 text-gray-300">
                <span>Traffic Penalty Weight:</span>
                <span className="text-[#B87333] font-bold">{config.trafficWeight}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={config.trafficWeight}
                onChange={(e) => setConfig({ ...config, trafficWeight: parseInt(e.target.value) })}
                className="w-full accent-[#B87333] h-1 bg-[#1A1C1E] rounded-lg cursor-pointer"
                disabled={isRunning}
              />
            </div>

            {/* Time Window Strictness */}
            <div>
              <label className="block text-gray-300 mb-1">Time Window Bounds:</label>
              <div className="flex gap-2">
                {["Flexible", "Standard", "Strict"].map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setConfig({ ...config, timeWindowStrictness: level as any })}
                    className={`flex-1 py-1 px-2 border text-center rounded text-[10px] uppercase font-bold transition-all cursor-pointer ${
                      config.timeWindowStrictness === level
                        ? "bg-[#B87333]/10 border-[#B87333] text-[#B87333]"
                        : "border-[#4E545C] text-gray-400 hover:border-gray-500"
                    }`}
                    disabled={isRunning}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* Multi Depot balance check */}
            <div className="flex items-center gap-2 pt-2">
              <input
                type="checkbox"
                id="depot-balance"
                checked={config.multiDepotBalancing}
                onChange={(e) => setConfig({ ...config, multiDepotBalancing: e.target.checked })}
                className="accent-[#B87333]"
                disabled={isRunning}
              />
              <label htmlFor="depot-balance" className="text-gray-300 select-none cursor-pointer">
                Enable Inter-depot Balancing
              </label>
            </div>
          </div>
        </div>

        {/* Action Trigger Button */}
        <button
          onClick={handleRunSolver}
          disabled={isRunning}
          className={`w-full mt-6 py-3 px-4 font-mono font-bold tracking-wider text-xs rounded-lg uppercase flex items-center justify-center gap-2 transition-all cursor-pointer ${
            isRunning 
              ? "bg-[#1A1C1E] text-gray-500 border border-[#4E545C] cursor-not-allowed"
              : "bg-[#B87333] text-[#1A1C1E] hover:bg-[#965a25] shadow-md hover:shadow-[#B87333]/20"
          }`}
        >
          {isRunning ? (
            <>
              <Cpu className="h-4 w-4 animate-spin text-[#B87333]" />
              <span>Running VRP Heuristics ({Math.round(progress)}%)</span>
            </>
          ) : (
            <>
              <Cpu className="h-4 w-4" />
              <span>Optimise Municipal Routes</span>
            </>
          )}
        </button>
      </div>

      {/* 2. Live Solver Terminal Console Log */}
      <div className="bg-[#1A1C1E] border border-[#4E545C] rounded-xl p-4 shadow-lg flex flex-col h-[400px]">
        <div className="flex items-center gap-2 mb-3 border-b border-[#4E545C] pb-2">
          <Terminal className="text-green-500 h-4 w-4" />
          <h3 className="text-[#D6D2C4] text-xs font-semibold tracking-wider uppercase font-mono">
            Rust Compiler & Solver Logs
          </h3>
          {isRunning && <span className="text-[10px] bg-green-500/10 text-green-500 border border-green-500/30 px-1.5 py-0.5 rounded animate-pulse">SOLVER ACTIVE</span>}
        </div>

        {/* Scrollable logs box */}
        <div className="flex-1 overflow-y-auto font-mono text-[10px] space-y-1.5 pr-2 custom-scrollbar">
          {terminalLogs.length === 0 ? (
            <div className="h-full flex items-center justify-center text-gray-500 italic">
              Terminal idle. Click 'Optimise Municipal Routes' to launch Solver threads.
            </div>
          ) : (
            terminalLogs.map((log, i) => {
              let levelColor = "text-gray-400";
              let levelBadge = "[INFO]";
              if (log.level === "SUCCESS") {
                levelColor = "text-green-400 font-semibold";
                levelBadge = "[SUCCESS]";
              } else if (log.level === "WARN") {
                levelColor = "text-[#B87333]";
                levelBadge = "[WARN]";
              } else if (log.level === "ERROR") {
                levelColor = "text-red-500 font-bold";
                levelBadge = "[FATAL]";
              }

              return (
                <div key={i} className="leading-relaxed border-b border-[#4E545C]/10 pb-0.5">
                  <span className="text-gray-600 mr-1.5">[{log.timestamp}]</span>
                  <span className="text-[#888] mr-1.5">[{log.thread}]</span>
                  <span className={`${levelColor} mr-1.5`}>{levelBadge}</span>
                  <span className="text-[#D6D2C4]">{log.message}</span>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 3. Objective Convergence Chart */}
      <div className="bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg flex flex-col h-[400px]">
        <div className="flex items-center gap-2 mb-2">
          <Cpu className="text-[#B87333] h-5 w-5" />
          <h3 className="text-[#D6D2C4] text-xs font-semibold tracking-wider uppercase font-mono">
            VRP Convergence Curve ($f(x)$)
          </h3>
        </div>
        <p className="text-[11px] text-gray-400 mb-4 font-mono leading-tight">
          Visualizes simulated logarithmic cost reduction (objective penalty score minimization) computed in millisecond intervals.
        </p>

        {/* Recharts Box */}
        <div className="flex-1 w-full min-h-0">
          {convergenceData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-gray-500 font-mono text-xs italic">
              No convergence telemetry recorded yet.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={convergenceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#4E545C" />
                <XAxis 
                  dataKey="iter" 
                  stroke="#888888" 
                  fontSize={10} 
                  fontFamily="monospace"
                  tickLine={false}
                  label={{ value: "Solver Iterations", position: "insideBottom", offset: -2, fill: "#888", fontSize: 9 }}
                />
                <YAxis 
                  stroke="#888888" 
                  fontSize={10} 
                  fontFamily="monospace"
                  tickLine={false}
                  label={{ value: "Penalty Metric", angle: -90, position: "insideLeft", offset: 10, fill: "#888", fontSize: 9 }}
                />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0D1B2A", border: "1px solid #4E545C", borderRadius: "6px" }}
                  labelStyle={{ color: "#888", fontSize: "10px", fontFamily: "monospace" }}
                  itemStyle={{ color: "#B87333", fontSize: "11px", fontFamily: "monospace" }}
                />
                <Line 
                  type="monotone" 
                  dataKey="cost" 
                  stroke="#B87333" 
                  strokeWidth={2} 
                  dot={false}
                  activeDot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}
