import React, { useState } from "react";
import { 
  YorkshireRegion, 
  CollectionRoute, 
  CollectionType 
} from "../types";
import { MAP_DIMENSIONS, DEPOTS, FACILITIES, STREET_SEGMENTS } from "../data";
import { Play, Pause, RotateCcw, MapPin, ZoomIn, ZoomOut, Compass, Layers } from "lucide-react";

interface GisMapProps {
  selectedRegion: YorkshireRegion;
  selectedCollectionType: CollectionType;
  routes: CollectionRoute[];
  activeRouteId: string | null;
  onSelectRoute: (id: string | null) => void;
}

export default function GisMap({
  selectedRegion,
  selectedCollectionType,
  routes,
  activeRouteId,
  onSelectRoute
}: GisMapProps) {
  const [zoom, setZoom] = useState<number>(1.0);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(0); // 0 to 100 percent
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // Playback effect
  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setPlaybackTime((prev) => {
          if (prev >= 100) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handleZoom = (factor: number) => {
    setZoom((z) => Math.min(3.0, Math.max(0.6, z * factor)));
  };

  const handleReset = () => {
    setZoom(1.0);
    setPan({ x: 0, y: 0 });
    setPlaybackTime(0);
    setIsPlaying(false);
  };

  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // SVG Coordinates for drawing stylized county zones representing Yorkshire
  // Map dimensions are 1000 x 800
  // Yorkshire counties polygons
  const zonesGeo = [
    {
      name: YorkshireRegion.WEST_YORKSHIRE,
      color: "rgba(12, 30, 54, 0.45)",
      border: "#1e3a60",
      points: "120,450 180,410 320,440 360,500 340,640 220,620 110,540"
    },
    {
      name: YorkshireRegion.SOUTH_YORKSHIRE,
      color: "rgba(217, 119, 54, 0.08)",
      border: "#c56324",
      points: "220,620 340,640 460,690 510,780 320,790 200,710"
    },
    {
      name: YorkshireRegion.NORTH_YORKSHIRE,
      color: "rgba(138, 154, 134, 0.15)",
      border: "#566854",
      points: "120,450 180,410 240,220 400,100 580,120 720,240 640,380 460,390 320,440"
    },
    {
      name: YorkshireRegion.EAST_RIDING,
      color: "rgba(12, 30, 54, 0.15)",
      border: "#1e3a60",
      points: "460,390 640,380 780,310 880,400 790,520 620,530"
    },
    {
      name: YorkshireRegion.HULL,
      color: "rgba(217, 119, 54, 0.25)",
      border: "#d97736",
      points: "720,510 800,510 820,550 740,550"
    }
  ];

  // Helper to interpolate truck coordinates along route line based on playbackTime
  const getTruckPosition = (route: CollectionRoute): { x: number; y: number } | null => {
    if (route.points.length === 0) return null;
    const segmentsCount = route.points.length - 1;
    const exactIndex = (playbackTime / 100) * segmentsCount;
    const segmentIdx = Math.min(segmentsCount - 1, Math.floor(exactIndex));
    const segmentProgress = exactIndex - segmentIdx;

    const p1 = route.points[segmentIdx];
    const p2 = route.points[segmentIdx + 1];

    if (!p1 || !p2) return null;

    return {
      x: p1[0] + (p2[0] - p1[0]) * segmentProgress,
      y: p1[1] + (p2[1] - p1[1]) * segmentProgress
    };
  };

  return (
    <div id="gis-platform" className="bg-[#1A1C1E] border border-[#4E545C] rounded-xl overflow-hidden shadow-2xl flex flex-col h-full min-h-[600px]">
      {/* Top Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#0D1B2A] border-b border-[#4E545C]">
        <div className="flex items-center gap-3">
          <Layers className="text-[#B87333] h-5 w-5" />
          <div>
            <h3 className="text-white text-sm font-semibold tracking-wider uppercase font-mono">
              Live Yorkshire GIS Control Room
            </h3>
            <p className="text-xs text-gray-400 font-mono">
              Region: <span className="text-[#B87333] font-bold">{selectedRegion}</span> • Fleet operations simulator
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Heatmap Toggle */}
          <button
            onClick={() => setShowHeatmap(!showHeatmap)}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-colors cursor-pointer ${
              showHeatmap 
                ? "bg-[#B87333] text-[#1A1C1E] font-bold" 
                : "bg-[#1A1C1E] text-[#D6D2C4] hover:bg-[#23272d] border border-[#4E545C]"
            }`}
          >
            {showHeatmap ? "Hide Waste Heatmap" : "Show Waste Heatmap"}
          </button>

          {/* Divider */}
          <div className="h-6 w-[1px] bg-[#4E545C] mx-1"></div>

          {/* Zoom and Panning Controls */}
          <button onClick={() => handleZoom(1.2)} className="p-2 bg-[#1A1C1E] hover:bg-[#23272d] border border-[#4E545C] rounded text-[#D6D2C4] cursor-pointer" title="Zoom In">
            <ZoomIn size={14} />
          </button>
          <button onClick={() => handleZoom(0.8)} className="p-2 bg-[#1A1C1E] hover:bg-[#23272d] border border-[#4E545C] rounded text-[#D6D2C4] cursor-pointer" title="Zoom Out">
            <ZoomOut size={14} />
          </button>
          <button onClick={handleReset} className="p-2 bg-[#1A1C1E] hover:bg-[#23272d] border border-[#4E545C] rounded text-[#D6D2C4] cursor-pointer" title="Recenter View">
            <RotateCcw size={14} />
          </button>
        </div>
      </div>

      {/* Main Map Canvas Area */}
      <div className="relative flex-1 bg-[#0A0C10] overflow-hidden cursor-grab active:cursor-grabbing">
        {/* Styled dot grid background pattern */}
        <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: "radial-gradient(#4E545C 1px, transparent 1px)", backgroundSize: "32px 32px" }}></div>

        {/* Playback HUD Overlay */}
        <div className="absolute top-4 left-4 z-10 bg-[#0D1B2A]/90 backdrop-blur-md border border-[#4E545C] p-3 rounded-lg shadow-lg font-mono text-xs text-[#D6D2C4] flex items-center gap-4">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2 rounded bg-[#B87333] text-[#1A1C1E] hover:bg-[#965a25] transition-colors cursor-pointer"
          >
            {isPlaying ? <Pause size={14} /> : <Play size={14} />}
          </button>
          <div>
            <div className="font-semibold text-white">ROUTE SIMULATION STATUS</div>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse"></span>
              <span className="text-gray-400">Time-lapse Index: {playbackTime}%</span>
            </div>
          </div>
          <div className="w-28 bg-[#1A1C1E] h-1.5 rounded-full overflow-hidden border border-[#4E545C]/50">
            <div className="bg-[#B87333] h-full" style={{ width: `${playbackTime}%` }}></div>
          </div>
        </div>

        {/* Map Legend Overlay */}
        <div className="absolute bottom-4 right-4 z-10 bg-[#0D1B2A]/90 backdrop-blur-md border border-[#4E545C] p-3 rounded-lg shadow-lg font-mono text-[10px] text-gray-400 space-y-2">
          <div className="font-bold text-white border-b border-[#4E545C] pb-1 mb-1">GIS KEY</div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-md bg-[#B87333]/20 border border-[#B87333]"></span>
            <span>Target Region Zone ({selectedRegion})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 inline-block rounded-full bg-[#B87333]"></span>
            <span>Depot / Logistics Hub</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 inline-block bg-[#10b981] rotate-45"></span>
            <span>Disposal / Treatment Facility</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-4 h-[2px] inline-block bg-[#B87333] border-t border-dashed"></span>
            <span>Optimized VRP Route (Capacitated)</span>
          </div>
        </div>

        {/* SVG GIS Layer */}
        <svg
          id="yorkshire-gis-canvas"
          width="100%"
          height="100%"
          viewBox={`0 0 ${MAP_DIMENSIONS.width} ${MAP_DIMENSIONS.height}`}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className="user-select-none"
        >
          {/* Inner transformation group for Panning & Zooming */}
          <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
            
            {/* 1. Base Yorkshire Geography Borders / Polygonal Regions */}
            {zonesGeo.map((zone) => {
              const isSelected = zone.name === selectedRegion;
              return (
                <polygon
                  key={zone.name}
                  points={zone.points}
                  fill={isSelected ? "rgba(184, 115, 51, 0.12)" : zone.color}
                  stroke={isSelected ? "#B87333" : zone.border}
                  strokeWidth={isSelected ? 2.5 : 1}
                  className="transition-all duration-300"
                />
              );
            })}

            {/* 2. Heatmap Circle Overlays (Waste generation density) */}
            {showHeatmap && STREET_SEGMENTS.map((seg, i) => (
              <circle
                key={`heat-${i}`}
                cx={seg.coordinates[0][0]}
                cy={seg.coordinates[0][1]}
                r={seg.households * 0.18}
                fill="rgba(184, 115, 51, 0.15)"
                filter="blur(4px)"
              />
            ))}

            {/* 3. Major Yorkshire Highways / Roadways */}
            {/* M62 Highway */}
            <path
              d="M 120,540 Q 300,560 620,530 T 880,480"
              fill="none"
              stroke="#2e3a4e"
              strokeWidth={3}
              strokeDasharray="5, 3"
            />
            {/* A1(M) Highway */}
            <path
              d="M 430,100 L 460,390 L 450,550 Q 460,690 320,790"
              fill="none"
              stroke="#222f3e"
              strokeWidth={2}
            />

            {/* Text Labels for Highway Roads */}
            <text x="320" y="545" fill="#4a5d78" fontSize="10" fontFamily="monospace">M62 Corridor</text>
            <text x="470" y="250" fill="#4a5d78" fontSize="10" fontFamily="monospace" transform="rotate(78, 470, 250)">A1(M)</text>

            {/* 4. Active Collection Street segments */}
            {STREET_SEGMENTS.map((seg) => {
              const isRegion = seg.region === selectedRegion;
              const isType = seg.collectionType === selectedCollectionType;
              const highlight = isRegion && isType;
              
              return (
                <g key={seg.id} className="opacity-80">
                  <path
                    d={`M ${seg.coordinates.map(pt => pt.join(",")).join(" L ")}`}
                    fill="none"
                    stroke={highlight ? "#B87333" : "#2b303b"}
                    strokeWidth={highlight ? 4.5 : 2}
                    className="transition-colors duration-300"
                  />
                  {highlight && (
                    <circle
                      cx={seg.coordinates[0][0]}
                      cy={seg.coordinates[0][1]}
                      r={3}
                      fill="#fff"
                    />
                  )}
                </g>
              );
            })}

            {/* 5. VRP Optimized Route Overlays (Pulsing dashed path lines) */}
            {routes.map((route) => {
              const isActive = activeRouteId === route.id;
              if (route.points.length === 0) return null;
              
              return (
                <path
                  key={`route-line-${route.id}`}
                  d={`M ${route.points.map(pt => pt.join(",")).join(" L ")}`}
                  fill="none"
                  stroke={isActive ? "#fff" : "#B87333"}
                  strokeWidth={isActive ? 3.5 : 1.8}
                  strokeDasharray={isActive ? "6, 4" : "4, 6"}
                  className="cursor-pointer hover:stroke-white transition-all duration-200"
                  onClick={() => onSelectRoute(isActive ? null : route.id)}
                />
              );
            })}

            {/* 6. Facilities Markers (Recycling Plants, Landfills, EfWs) */}
            {FACILITIES.map((fac) => {
              const isRegion = fac.region === selectedRegion;
              return (
                <g
                  key={fac.id}
                  transform={`translate(${fac.lat}, ${fac.lng})`}
                  className="cursor-pointer group"
                >
                  <polygon
                    points="0,-8 7,5 -7,5"
                    fill={isRegion ? "#10b981" : "#4b5563"}
                    stroke="#fff"
                    strokeWidth={1}
                  />
                  <text
                    y="-12"
                    textAnchor="middle"
                    fill="#D6D2C4"
                    fontSize="9"
                    fontFamily="monospace"
                    className="opacity-0 group-hover:opacity-100 bg-[#111] pointer-events-none transition-opacity"
                  >
                    {fac.name}
                  </text>
                </g>
              );
            })}

            {/* 7. Depots Markers (Logistics Hubs) */}
            {DEPOTS.map((dep) => {
              const isSelected = dep.region === selectedRegion;
              return (
                <g
                  key={dep.id}
                  transform={`translate(${dep.lat}, ${dep.lng})`}
                  className="cursor-pointer"
                >
                  <circle
                    r={isSelected ? 8 : 5}
                    fill={isSelected ? "#B87333" : "#4b5563"}
                    stroke="#fff"
                    strokeWidth={1.5}
                  />
                  <circle
                    r={isSelected ? 16 : 0}
                    fill="none"
                    stroke="#B87333"
                    strokeWidth={1}
                    className="animate-ping"
                    style={{ animationDuration: "3s" }}
                  />
                  <text
                    y="18"
                    textAnchor="middle"
                    fill={isSelected ? "#B87333" : "#9ca3af"}
                    fontSize="10"
                    fontWeight={isSelected ? "bold" : "normal"}
                    fontFamily="monospace"
                  >
                    {dep.name.split(" ")[0]} Hub
                  </text>
                </g>
              );
            })}

            {/* 8. Active Simulation Trucks moving along paths */}
            {routes.map((route) => {
              const pos = getTruckPosition(route);
              if (!pos) return null;
              
              // Color-code based on truck propulsion type
              const isElectric = route.id.includes("elec") || route.vehicleId.includes("v-01") || route.vehicleId.includes("v-05") || route.vehicleId.includes("v-07");
              const isHydrogen = route.vehicleId.includes("v-02") || route.vehicleId.includes("v-06");
              
              let truckColor = "#eab308"; // Diesel = Amber
              if (isElectric) truckColor = "#10b981"; // Electric = Green
              if (isHydrogen) truckColor = "#3b82f6"; // Hydrogen = Blue

              return (
                <g key={`truck-marker-${route.id}`}>
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r={6}
                    fill={truckColor}
                    stroke="#fff"
                    strokeWidth={1}
                  />
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r={12}
                    fill="none"
                    stroke={truckColor}
                    strokeWidth={1}
                    className="animate-pulse"
                  />
                </g>
              );
            })}

          </g>
        </svg>
      </div>

      {/* Bottom GIS Dashboard HUD */}
      <div className="bg-[#0D1B2A] border-t border-[#4E545C] p-4 flex flex-wrap gap-6 text-xs text-gray-400 font-mono">
        <div>
          <span className="text-gray-500 uppercase tracking-wider block text-[10px]">ACTIVE ROUTES</span>
          <span className="text-white font-semibold text-sm">{routes.length}</span>
        </div>
        <div className="h-8 w-[1px] bg-[#4E545C]"></div>
        <div>
          <span className="text-gray-500 uppercase tracking-wider block text-[10px]">DEPOTS COVERED</span>
          <span className="text-white font-semibold text-sm">5 / 5 Hubs</span>
        </div>
        <div className="h-8 w-[1px] bg-[#4E545C]"></div>
        <div>
          <span className="text-gray-500 uppercase tracking-wider block text-[10px]">TOTAL DISPOSAL PLANTS</span>
          <span className="text-white font-semibold text-sm">5 Regional Facilities</span>
        </div>
        <div className="h-8 w-[1px] bg-[#4E545C]"></div>
        <div className="flex-1 min-w-[200px]">
          <span className="text-gray-500 uppercase tracking-wider block text-[10px]">COUNCIL COVERAGE</span>
          <div className="flex gap-1.5 mt-1 flex-wrap">
            <span className="px-1.5 py-0.5 rounded bg-[#1A1C1E] border border-[#4E545C] text-gray-300">Leeds CC</span>
            <span className="px-1.5 py-0.5 rounded bg-[#1A1C1E] border border-[#4E545C] text-gray-300">Sheffield CC</span>
            <span className="px-1.5 py-0.5 rounded bg-[#1A1C1E] border border-[#4E545C] text-gray-300">York CC</span>
            <span className="px-1.5 py-0.5 rounded bg-[#1A1C1E] border border-[#4E545C] text-gray-300">Hull CC</span>
          </div>
        </div>
      </div>
    </div>
  );
}
