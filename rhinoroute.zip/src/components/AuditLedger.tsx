import React, { useState } from "react";
import { LedgerBlock } from "../types";
import { ShieldCheck, Database, RefreshCw, Key, Layers, AlertCircle } from "lucide-react";

interface AuditLedgerProps {
  ledger: LedgerBlock[];
  onClearLedger?: () => void;
}

export default function AuditLedger({ ledger }: AuditLedgerProps) {
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<"IDLE" | "SUCCESS" | "FAILED">("IDLE");
  const [activeVerificationStep, setActiveVerificationStep] = useState<number>(-1);

  const handleVerifyChain = () => {
    setIsVerifying(true);
    setVerificationResult("IDLE");
    setActiveVerificationStep(0);

    // Run step-by-step verification animation of previous hashes matching current block hashes
    let currentBlock = 0;
    const interval = setInterval(() => {
      currentBlock++;
      if (currentBlock < ledger.length) {
        setActiveVerificationStep(currentBlock);
      } else {
        clearInterval(interval);
        setIsVerifying(false);
        setActiveVerificationStep(-1);
        
        // Final evaluation (confirming hashes are connected)
        let isValid = true;
        for (let i = 1; i < ledger.length; i++) {
          if (ledger[i].previousHash !== ledger[i - 1].hash) {
            isValid = false;
            break;
          }
        }
        setVerificationResult(isValid ? "SUCCESS" : "FAILED");
      }
    }, 250);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Immutability HUD Bar */}
      <div className="bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Database className="text-[#B87333] h-6 w-6" />
          <div>
            <h4 className="text-[#D6D2C4] text-xs font-semibold tracking-wider uppercase">
              Operational Ledger Cryptographic Auditing
            </h4>
            <p className="text-xs text-gray-400 mt-0.5">
              Immutable chain records audit trails of route publication, dispatch confirmations and technician handovers.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {verificationResult === "SUCCESS" && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#10b981]/10 border border-[#10b981]/30 text-[#10b981] font-bold text-[10px] uppercase">
              <ShieldCheck size={14} />
              <span>Chain Integrity Verified</span>
            </div>
          )}
          {verificationResult === "FAILED" && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-red-500/10 border border-red-500/30 text-red-400 font-bold text-[10px] uppercase animate-pulse">
              <AlertCircle size={14} />
              <span>Breach Detected in Chain</span>
            </div>
          )}

          <button
            onClick={handleVerifyChain}
            disabled={isVerifying}
            className={`py-2 px-4 rounded font-bold uppercase transition-all cursor-pointer flex items-center gap-2 border text-[10px] ${
              isVerifying
                ? "bg-[#1A1C1E] text-gray-500 border-[#4E545C] cursor-not-allowed"
                : "bg-[#B87333] text-white border-[#B87333] hover:bg-[#a05d25]"
            }`}
          >
            <RefreshCw size={12} className={isVerifying ? "animate-spin" : ""} />
            <span>Verify Ledger Security</span>
          </button>
        </div>
      </div>

      {/* Chain Blocks visualizer */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {ledger.map((block, idx) => {
          const isVerifyingBlock = activeVerificationStep === idx;
          const hasPassedVerification = verificationResult === "SUCCESS" || (activeVerificationStep > idx);
          
          let blockBorder = "border-[#4E545C]";
          let bgState = "bg-[#1A1C1E]";
          if (isVerifyingBlock) {
            blockBorder = "border-yellow-600/60 shadow-md shadow-yellow-500/10";
            bgState = "bg-yellow-500/5";
          } else if (hasPassedVerification) {
            blockBorder = "border-[#10b981]/50";
            bgState = "bg-green-500/[0.01]";
          }

          return (
            <div 
              key={block.index}
              className={`border rounded-xl p-4 transition-all flex flex-col justify-between h-[230px] ${bgState} ${blockBorder}`}
            >
              <div>
                <div className="flex justify-between items-center border-b border-[#4E545C] pb-2 mb-2">
                  <div className="flex items-center gap-1.5">
                    <Layers size={13} className="text-gray-500" />
                    <span className="font-bold text-white">BLOCK #{block.index}</span>
                  </div>
                  <span className="text-[9px] text-gray-500">{block.timestamp.split("T")[1].slice(0, 8)}</span>
                </div>

                <div className="space-y-1.5 text-[10px] text-gray-400">
                  <div className="flex justify-between font-semibold text-[#B87333]">
                    <span>EVENT:</span>
                    <span>{block.event}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 font-bold">OPERATOR:</span> {block.operator}
                  </div>
                  <div className="text-gray-300 mt-1.5 leading-relaxed overflow-hidden h-[45px] text-ellipsis">
                    {block.payload}
                  </div>
                </div>
              </div>

              {/* Cryptographic Hashes */}
              <div className="pt-2 border-t border-[#4E545C]/40 text-[9px] space-y-1 text-gray-500 font-mono">
                <div className="flex items-center justify-between gap-1 overflow-hidden">
                  <span className="flex items-center gap-0.5"><Key size={8} /> PREV:</span>
                  <span className="truncate text-gray-600" title={block.previousHash}>{block.previousHash.substring(0, 16)}...</span>
                </div>
                <div className="flex items-center justify-between gap-1 overflow-hidden">
                  <span className="flex items-center gap-0.5"><Key size={8} /> HASH:</span>
                  <span className="truncate text-[#D6D2C4]" title={block.hash}>{block.hash.substring(0, 16)}...</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
