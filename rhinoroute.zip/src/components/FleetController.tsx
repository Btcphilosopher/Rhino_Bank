import React, { useState } from "react";
import { Vehicle, Driver, PropulsionType, VehicleStatus } from "../types";
import { Truck, User, Battery, Wrench, Shield, CheckCircle } from "lucide-react";

interface FleetControllerProps {
  vehicles: Vehicle[];
  drivers: Driver[];
  onUpdateVehicleStatus: (id: string, status: VehicleStatus) => void;
  onAssignDriver: (vehicleId: string, driverId: string) => void;
  onAddLedgerEntry: (event: string, payload: string) => void;
}

export default function FleetController({
  vehicles,
  drivers,
  onUpdateVehicleStatus,
  onAssignDriver,
  onAddLedgerEntry
}: FleetControllerProps) {
  const [selectedVehicleId, setSelectedVehicleId] = useState<string | null>(null);

  const selectedVehicle = vehicles.find(v => v.id === selectedVehicleId);

  const handleMaintenanceToggle = (veh: Vehicle) => {
    const nextStatus = veh.status === VehicleStatus.MAINTENANCE 
      ? VehicleStatus.STANDBY 
      : VehicleStatus.MAINTENANCE;
    
    onUpdateVehicleStatus(veh.id, nextStatus);
    onAddLedgerEntry(
      "FLEET_MAINTENANCE_UPDATE",
      `Vehicle ${veh.plate} status changed to ${nextStatus} by regional maintenance coordinator.`
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
      {/* 1. Fleet Grid List (Left 2 Columns) */}
      <div className="lg:col-span-2 bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Truck className="text-[#B87333] h-5 w-5" />
            <h3 className="text-[#D6D2C4] text-xs font-semibold tracking-wider uppercase">
              Yorkshire Fleet Inventory ({vehicles.length} Trucks)
            </h3>
          </div>
          <span className="text-[10px] text-gray-400 bg-[#1A1C1E] border border-[#4E545C] py-1 px-2 rounded">
            EV & FCEV Zero Emission Transition: 62%
          </span>
        </div>

        {/* Vehicles Grid list */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[460px] overflow-y-auto pr-1">
          {vehicles.map((veh) => {
            const driver = drivers.find(d => d.id === veh.driverId);
            
            // Fuel indicator styling
            let fuelColor = "bg-yellow-500";
            if (veh.propulsion === PropulsionType.ELECTRIC) fuelColor = "bg-green-500";
            if (veh.propulsion === PropulsionType.HYDROGEN) fuelColor = "bg-blue-500";

            return (
              <div 
                key={veh.id}
                onClick={() => setSelectedVehicleId(veh.id)}
                className={`border rounded-lg p-4 cursor-pointer transition-all ${
                  selectedVehicleId === veh.id
                    ? "border-[#B87333] bg-[#1A1C1E]/60 shadow-md"
                    : "border-[#4E545C] bg-[#1A1C1E] hover:border-gray-500"
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <span className="text-[10px] font-bold text-gray-500 tracking-wider uppercase block">
                      {veh.propulsion}
                    </span>
                    <span className="text-sm font-bold text-white">{veh.plate}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded-[4px] text-[9px] font-bold uppercase tracking-wider ${
                    veh.status === VehicleStatus.ACTIVE
                      ? "bg-[#10b981]/10 border border-[#10b981]/30 text-[#10b981]"
                      : veh.status === VehicleStatus.MAINTENANCE
                      ? "bg-red-500/10 border border-red-500/30 text-red-400"
                      : veh.status === VehicleStatus.STANDBY
                      ? "bg-gray-500/10 border border-gray-500/30 text-gray-300"
                      : "bg-blue-500/10 border border-blue-500/30 text-blue-400"
                  }`}>
                    {veh.status}
                  </span>
                </div>

                <div className="space-y-2 mt-3">
                  {/* Driver Assignment row */}
                  <div className="flex items-center gap-1.5 text-gray-400">
                    <User size={13} className="text-gray-500" />
                    <span>Crew: {driver ? driver.name : <span className="text-red-400 italic">Unassigned</span>}</span>
                  </div>

                  {/* Energy bar row */}
                  <div>
                    <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                      <span>Energy Level / Range:</span>
                      <span>{veh.energyLevel}%</span>
                    </div>
                    <div className="w-full bg-[#1A1C1E] h-1.5 rounded-full overflow-hidden border border-[#4E545C]/20">
                      <div className={`h-full ${fuelColor}`} style={{ width: `${veh.energyLevel}%` }}></div>
                    </div>
                  </div>

                  {/* Operational Payload capacity */}
                  <div className="flex justify-between text-[10px] text-gray-500 pt-1">
                    <span>Payload: {veh.currentPayloadTons}t / {veh.capacityTons}t</span>
                    <span>CO2: {veh.co2EmissionsKgPerKm} kg/km</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Selected Vehicle Controls / Driver Allocation (Right Column) */}
      <div className="bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg flex flex-col justify-between">
        {selectedVehicle ? (
          <div className="space-y-5">
            <div className="border-b border-[#4E545C] pb-3">
              <div className="text-[10px] font-bold text-gray-500 tracking-wider uppercase">UNIT CONTROLLER</div>
              <h4 className="text-lg font-bold text-white mt-0.5">{selectedVehicle.plate}</h4>
              <p className="text-[10px] text-gray-400 mt-1">Status: <span className="text-[#B87333] font-bold">{selectedVehicle.status}</span></p>
            </div>

            {/* Quick telemetry indicators */}
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="bg-[#1A1C1E] border border-[#4E545C] p-2.5 rounded">
                <span className="text-gray-500 block text-[9px] uppercase">Consumption</span>
                <span className="text-white font-bold text-xs mt-0.5 block">{selectedVehicle.consumptionRate}</span>
              </div>
              <div className="bg-[#1A1C1E] border border-[#4E545C] p-2.5 rounded">
                <span className="text-gray-500 block text-[9px] uppercase">CO2 Tailpipe</span>
                <span className="text-white font-bold text-xs mt-0.5 block">{selectedVehicle.co2EmissionsKgPerKm === 0 ? "0.0 kg/km" : `${selectedVehicle.co2EmissionsKgPerKm} kg/km`}</span>
              </div>
            </div>

            {/* Shift/Driver Allocation tool */}
            <div className="space-y-2">
              <label className="block text-gray-400 text-[10px] uppercase">Assign Driver to Truck:</label>
              <select
                value={selectedVehicle.driverId || ""}
                onChange={(e) => {
                  onAssignDriver(selectedVehicle.id, e.target.value);
                  const dName = drivers.find(d => d.id === e.target.value)?.name || "Unassigned";
                  onAddLedgerEntry(
                    "FLEET_DRIVER_ASSIGNED",
                    `Driver ${dName} assigned to vehicle ${selectedVehicle.plate} for next regional operations shift.`
                  );
                }}
                className="w-full bg-[#1A1C1E] border border-[#4E545C] text-[#D6D2C4] py-1.5 px-2 rounded focus:outline-none focus:border-[#B87333]"
              >
                <option value="">-- No Driver --</option>
                {drivers.map(d => (
                  <option key={d.id} value={d.id}>{d.name} ({d.status})</option>
                ))}
              </select>
            </div>

            {/* Fleet actions */}
            <div className="space-y-2 pt-3">
              <button
                onClick={() => handleMaintenanceToggle(selectedVehicle)}
                className="w-full py-2 border border-yellow-600/30 text-yellow-500 bg-yellow-500/5 hover:bg-yellow-500/10 font-bold rounded flex items-center justify-center gap-2 transition-all cursor-pointer uppercase text-[10px]"
              >
                <Wrench size={13} />
                <span>
                  {selectedVehicle.status === VehicleStatus.MAINTENANCE 
                    ? "Release from Maintenance" 
                    : "Send to Maintenance Garage"}
                </span>
              </button>
            </div>

            {/* Maintenance History */}
            <div className="bg-[#1A1C1E] p-3 rounded-lg border border-[#4E545C] space-y-1.5 text-[10px] text-gray-400">
              <div className="font-bold text-white mb-1 border-b border-[#4E545C] pb-0.5 uppercase flex items-center gap-1">
                <Shield size={11} className="text-[#B87333]" />
                <span>Logistical Safety Audit</span>
              </div>
              <div className="flex justify-between">
                <span>Last Garage Service:</span>
                <span className="text-white">{selectedVehicle.lastMaintenanceDate}</span>
              </div>
              <div className="flex justify-between">
                <span>Next Scheduled Check:</span>
                <span className="text-white">{selectedVehicle.nextMaintenanceDate}</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-gray-500 italic text-center p-6">
            Select an individual vehicle from the inventory array to load real-time control options and assignment rosters.
          </div>
        )}

        <div className="border-t border-[#4E545C] pt-4 mt-6 text-[10px] text-gray-500 flex items-center gap-1.5">
          <CheckCircle size={12} className="text-green-500" />
          <span>Vehicle profiles locked via regional council database</span>
        </div>
      </div>
    </div>
  );
}
