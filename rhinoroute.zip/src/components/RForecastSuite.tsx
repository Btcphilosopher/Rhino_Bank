import React, { useState, useMemo } from "react";
import { YorkshireRegion, CollectionType } from "../types";
import { generateVolumeForecast, evaluateScenario } from "../forecaster";
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  AreaChart,
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from "recharts";
import { TrendingUp, BarChart3, Settings2, ShieldCheck, DollarSign, Leaf, RefreshCw } from "lucide-react";

interface RForecastSuiteProps {
  selectedRegion: YorkshireRegion;
  onChangeRegion: (r: YorkshireRegion) => void;
  selectedCollectionType: CollectionType;
  onChangeCollectionType: (t: CollectionType) => void;
}

export default function RForecastSuite({
  selectedRegion,
  onChangeRegion,
  selectedCollectionType,
  onChangeCollectionType
}: RForecastSuiteProps) {
  const [modelType, setModelType] = useState<"ARIMA" | "ETS">("ARIMA");
  
  // Forecast parameters
  const [annualGrowth, setAnnualGrowth] = useState<number>(2.2); // Annual % waste volume growth
  const [recyclingShift, setRecyclingShift] = useState<number>(5); // Shift General -> Recycling %
  const [greenFleetShare, setGreenFleetShare] = useState<number>(30); // 0-100% EV/Hydrogen trucks

  // Generate volume forecast points using R forecaster math
  const forecastData = useMemo(() => {
    return generateVolumeForecast(
      selectedRegion,
      selectedCollectionType,
      annualGrowth / 100,
      recyclingShift,
      12 // forecast 12 months ahead
    );
  }, [selectedRegion, selectedCollectionType, annualGrowth, recyclingShift]);

  // Compute what-if financial & environmental scenarios
  const scenarioResults = useMemo(() => {
    return evaluateScenario(
      selectedRegion,
      annualGrowth,
      recyclingShift,
      greenFleetShare
    );
  }, [selectedRegion, annualGrowth, recyclingShift, greenFleetShare]);

  // Formatter for Currency
  const formatGBP = (val: number) => {
    return new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP", maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="space-y-6">
      {/* Top Selectors and KPI Info banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-4 shadow-md font-mono text-xs">
        <div>
          <label className="block text-gray-400 mb-1">Local Council:</label>
          <select
            value={selectedRegion}
            onChange={(e) => onChangeRegion(e.target.value as YorkshireRegion)}
            className="w-full bg-[#1A1C1E] border border-[#4E545C] text-[#D6D2C4] py-1.5 px-2 rounded focus:outline-none focus:border-[#B87333]"
          >
            {Object.values(YorkshireRegion).map((r) => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-gray-400 mb-1">Waste Classification:</label>
          <select
            value={selectedCollectionType}
            onChange={(e) => onChangeCollectionType(e.target.value as CollectionType)}
            className="w-full bg-[#1A1C1E] border border-[#4E545C] text-[#D6D2C4] py-1.5 px-2 rounded focus:outline-none focus:border-[#B87333]"
          >
            {Object.values(CollectionType).map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-gray-400 mb-1">R Core Package Engine:</label>
          <div className="flex gap-1.5">
            <button
              onClick={() => setModelType("ARIMA")}
              className={`flex-1 py-1 px-2 border text-center rounded text-[10px] font-bold uppercase transition-all cursor-pointer ${
                modelType === "ARIMA"
                  ? "bg-[#B87333]/10 border-[#B87333] text-[#B87333]"
                  : "border-[#4E545C] text-gray-400 hover:border-[#666]"
              }`}
            >
              fable::ARIMA(1,1,1)
            </button>
            <button
              onClick={() => setModelType("ETS")}
              className={`flex-1 py-1 px-2 border text-center rounded text-[10px] font-bold uppercase transition-all cursor-pointer ${
                modelType === "ETS"
                  ? "bg-[#10b981]/10 border-[#10b981] text-[#10b981]"
                  : "border-[#4E545C] text-gray-400 hover:border-[#666]"
              }`}
            >
              forecast::ETS(M,A,M)
            </button>
          </div>
        </div>

        <div className="flex items-center justify-end">
          <div className="text-right">
            <span className="text-gray-500 uppercase tracking-wider block text-[10px]">Statistical Baseline</span>
            <span className="text-white font-semibold text-xs block mt-0.5">24 Months Historical Log</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Forecasting Plot (Left 2 Columns) */}
        <div className="lg:col-span-2 bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg flex flex-col h-[420px]">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="text-[#B87333] h-5 w-5" />
              <h3 className="text-[#D6D2C4] text-xs font-semibold tracking-wider uppercase font-mono">
                ARIMA / ETS Waste Tonnage Projections
              </h3>
            </div>
            <span className="text-[10px] font-mono text-gray-400 bg-[#1A1C1E] border border-[#4E545C] py-1 px-2 rounded">
              Confidence intervals (80% / 95% threshold shading)
            </span>
          </div>

          {/* Recharts Container */}
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={forecastData}>
                <defs>
                  <linearGradient id="colorForecast" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#B87333" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#B87333" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#4E545C" />
                <XAxis 
                  dataKey="date" 
                  stroke="#888888" 
                  fontSize={10} 
                  fontFamily="monospace"
                  tickLine={false}
                />
                <YAxis 
                  stroke="#888888" 
                  fontSize={10} 
                  fontFamily="monospace"
                  tickLine={false}
                  label={{ value: "Volume (Metric Tonnes)", angle: -90, position: "insideLeft", offset: 12, fill: "#888", fontSize: 10 }}
                />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0D1B2A", border: "1px solid #4E545C", borderRadius: "6px" }}
                  labelStyle={{ color: "#888", fontSize: "10px", fontFamily: "monospace" }}
                  itemStyle={{ fontSize: "11px", fontFamily: "monospace" }}
                />
                <Legend 
                  verticalAlign="top" 
                  height={32} 
                  wrapperStyle={{ fontSize: "10px", fontFamily: "monospace" }}
                />
                
                {/* Confidence upper/lower bounds area */}
                <Area 
                  name="Confidence Range (ARIMA)"
                  type="monotone" 
                  dataKey="confidenceUpper" 
                  stroke="none"
                  fill="#B87333" 
                  fillOpacity={0.06} 
                  legendType="none"
                />
                <Area 
                  type="monotone" 
                  dataKey="confidenceLower" 
                  stroke="none"
                  fill="#B87333" 
                  fillOpacity={0.06} 
                  legendType="none"
                />

                {/* Actuals Line (first 12 months) */}
                <Line 
                  name="Observed Actual Tonnage" 
                  type="monotone" 
                  dataKey="actualTonnage" 
                  stroke="#10b981" 
                  strokeWidth={2.5}
                  dot={{ r: 2 }}
                />

                {/* Forecast Line */}
                <Line 
                  name="Projected Trend (R Model)" 
                  type="monotone" 
                  dataKey="forecastTonnage" 
                  stroke="#B87333" 
                  strokeWidth={2} 
                  strokeDasharray="5 5"
                  dot={{ r: 3 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* What-If Scenario Inputs Panel */}
        <div className="bg-[#0D1B2A] border border-[#4E545C] rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Settings2 className="text-[#B87333] h-5 w-5" />
              <h3 className="text-[#D6D2C4] text-xs font-semibold tracking-wider uppercase font-mono">
                Scenario Modeling Controls
              </h3>
            </div>

            <p className="text-xs text-gray-400 mb-5 leading-relaxed font-mono">
              Model macro policy adjustments in R. Instantly calculate municipal costs, carbon outputs, and landfill tax exposures.
            </p>

            <div className="space-y-4 font-mono text-xs">
              {/* Annual Growth */}
              <div>
                <div className="flex justify-between mb-1 text-gray-300">
                  <span>Demographic Waste Growth:</span>
                  <span className="text-[#B87333] font-bold">{annualGrowth > 0 ? `+${annualGrowth}` : annualGrowth}%</span>
                </div>
                <input
                  type="range"
                  min="-3.0"
                  max="10.0"
                  step="0.2"
                  value={annualGrowth}
                  onChange={(e) => setAnnualGrowth(parseFloat(e.target.value))}
                  className="w-full accent-[#B87333] h-1 bg-[#1A1C1E] rounded-lg cursor-pointer"
                />
              </div>

              {/* Recycling Shift */}
              <div>
                <div className="flex justify-between mb-1 text-gray-300">
                  <span>Recycling Conversion Target:</span>
                  <span className="text-[#B87333] font-bold">+{recyclingShift}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  step="1"
                  value={recyclingShift}
                  onChange={(e) => setRecyclingShift(parseInt(e.target.value))}
                  className="w-full accent-[#B87333] h-1 bg-[#1A1C1E] rounded-lg cursor-pointer"
                />
              </div>

              {/* Green Fleet Share */}
              <div>
                <div className="flex justify-between mb-1 text-gray-300">
                  <span>Green Propulsion Ratio:</span>
                  <span className="text-[#B87333] font-bold">{greenFleetShare}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={greenFleetShare}
                  onChange={(e) => setGreenFleetShare(parseInt(e.target.value))}
                  className="w-full accent-[#B87333] h-1 bg-[#1A1C1E] rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-[#4E545C] mt-4 text-[10px] text-gray-500 font-mono flex items-center gap-2">
            <RefreshCw className="h-3 w-3 animate-spin text-gray-600" />
            <span>ARIMA coefficients re-fit dynamically in R environment</span>
          </div>
        </div>
      </div>

      {/* Side-by-Side What-If Scenario Comparative Outputs Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Total Projected Tonnage */}
        <div className="bg-[#1A1C1E] border border-[#4E545C] rounded-xl p-4 shadow-md font-mono">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] text-gray-500 uppercase tracking-wider font-bold">Projected Total Vol</span>
            <BarChart3 size={16} className="text-[#B87333]" />
          </div>
          <div className="text-xl font-bold text-white">{scenarioResults.totalTonnage.toLocaleString()} tons</div>
          <div className="text-[10px] text-gray-400 mt-1">12M compound tonnage curve</div>
        </div>

        {/* Collection & Sorting Costs */}
        <div className="bg-[#1A1C1E] border border-[#4E545C] rounded-xl p-4 shadow-md font-mono">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] text-gray-500 uppercase tracking-wider font-bold">Est. Logistical Cost</span>
            <DollarSign size={16} className="text-[#10b981]" />
          </div>
          <div className="text-xl font-bold text-[#10b981]">{formatGBP(scenarioResults.collectionCosts)}</div>
          <div className="text-[10px] text-gray-400 mt-1">Includes route savings margins</div>
        </div>

        {/* UK Landfill Tax Exposure */}
        <div className="bg-[#1A1C1E] border border-[#4E545C] rounded-xl p-4 shadow-md font-mono">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] text-gray-500 uppercase tracking-wider font-bold">Landfill Tax Penalty</span>
            <DollarSign size={16} className="text-red-500" />
          </div>
          <div className="text-xl font-bold text-red-400">{formatGBP(scenarioResults.landfillTaxCosts)}</div>
          <div className="text-[10px] text-gray-400 mt-1">Charged at £102.10/t on general waste</div>
        </div>

        {/* Estimated Carbon footprint */}
        <div className="bg-[#1A1C1E] border border-[#4E545C] rounded-xl p-4 shadow-md font-mono">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] text-gray-500 uppercase tracking-wider font-bold">CO2e Emissions</span>
            <Leaf size={16} className="text-green-500" />
          </div>
          <div className="text-xl font-bold text-green-400">{scenarioResults.carbonFootprintTons.toLocaleString()} tCO2e</div>
          <div className="text-[10px] text-gray-400 mt-1">Direct fleet + decomposition offset</div>
        </div>
      </div>
    </div>
  );
}
