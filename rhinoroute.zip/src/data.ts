import { 
  YorkshireRegion, 
  CollectionType, 
  PropulsionType, 
  VehicleStatus, 
  Depot, 
  Facility, 
  StreetSegment, 
  Vehicle, 
  Driver,
  LedgerBlock
} from "./types";

// Geographic bounds for SVG map (0 to 1000 pixels)
export const MAP_DIMENSIONS = { width: 1000, height: 800 };

// Real-world representation of depots in Yorkshire
export const DEPOTS: Depot[] = [
  { id: "depot-leeds", name: "Leeds Kirkstall Road Depot", region: YorkshireRegion.WEST_YORKSHIRE, lat: 280, lng: 550, capacity: 45, activeVehicles: 32 },
  { id: "depot-sheffield", name: "Sheffield Lumley Street Depot", region: YorkshireRegion.SOUTH_YORKSHIRE, lat: 330, lng: 720, capacity: 40, activeVehicles: 28 },
  { id: "depot-york", name: "York Hazel Court Depot", region: YorkshireRegion.NORTH_YORKSHIRE, lat: 460, lng: 390, capacity: 25, activeVehicles: 18 },
  { id: "depot-beverley", name: "Beverley Carnaby Depot", region: YorkshireRegion.EAST_RIDING, lat: 680, lng: 450, capacity: 20, activeVehicles: 12 },
  { id: "depot-hull", name: "Hull Sutton Fields Depot", region: YorkshireRegion.HULL, lat: 740, lng: 520, capacity: 30, activeVehicles: 22 }
];

// Disposal & Transfer facilities across Yorkshire
export const FACILITIES: Facility[] = [
  { id: "fac-leeds-efw", name: "Leeds Recycling & Energy Facility", type: "Energy-from-Waste", region: YorkshireRegion.WEST_YORKSHIRE, lat: 310, lng: 560, fillRate: 68, dailyCapacityTons: 400 },
  { id: "fac-sheff-efw", name: "Sheffield Bernard Road EfW", type: "Energy-from-Waste", region: YorkshireRegion.SOUTH_YORKSHIRE, lat: 345, lng: 735, fillRate: 74, dailyCapacityTons: 350 },
  { id: "fac-york-hw", name: "Harewood Whin Recycling Facility", type: "Recycling Centre", region: YorkshireRegion.NORTH_YORKSHIRE, lat: 430, lng: 380, fillRate: 45, dailyCapacityTons: 200 },
  { id: "fac-er-landfill", name: "East Riding Allerthorpe Landfill", type: "Landfill", region: YorkshireRegion.EAST_RIDING, lat: 600, lng: 430, fillRate: 82, dailyCapacityTons: 150 },
  { id: "fac-hull-transfer", name: "Hull Wilmington Transfer Station", type: "Transfer Station", region: YorkshireRegion.HULL, lat: 760, lng: 535, fillRate: 59, dailyCapacityTons: 300 }
];

// Street segments for VRP solver paths and collection simulation
export const STREET_SEGMENTS: StreetSegment[] = [
  // West Yorkshire (Leeds)
  { id: "st-leeds-1", name: "Otley Road", town: "Headingley", region: YorkshireRegion.WEST_YORKSHIRE, households: 180, wasteTonnageEstimate: 2.1, collectionType: CollectionType.GENERAL_WASTE, oneWay: false, schoolZone: true, coordinates: [[280, 550], [250, 510], [230, 480]] },
  { id: "st-leeds-2", name: "Kirkstall Lane", town: "Kirkstall", region: YorkshireRegion.WEST_YORKSHIRE, households: 140, wasteTonnageEstimate: 1.5, collectionType: CollectionType.RECYCLING, oneWay: false, schoolZone: false, coordinates: [[280, 550], [240, 540], [210, 530]] },
  { id: "st-leeds-3", name: "Briggate", town: "Leeds Centre", region: YorkshireRegion.WEST_YORKSHIRE, households: 90, wasteTonnageEstimate: 2.8, collectionType: CollectionType.COMMERCIAL_WASTE, oneWay: true, schoolZone: false, coordinates: [[280, 550], [290, 560], [305, 570]] },
  { id: "st-leeds-4", name: "Cardigan Road", town: "Burley", region: YorkshireRegion.WEST_YORKSHIRE, households: 210, wasteTonnageEstimate: 1.8, collectionType: CollectionType.GARDEN_WASTE, oneWay: false, schoolZone: false, coordinates: [[280, 550], [260, 535], [245, 550]] },
  
  // South Yorkshire (Sheffield)
  { id: "st-sheff-1", name: "Ecclesall Road", town: "Sheffield South", region: YorkshireRegion.SOUTH_YORKSHIRE, households: 250, wasteTonnageEstimate: 3.2, collectionType: CollectionType.GENERAL_WASTE, oneWay: false, schoolZone: false, coordinates: [[330, 720], [310, 740], [280, 765]] },
  { id: "st-sheff-2", name: "Fargate", town: "Sheffield Centre", region: YorkshireRegion.SOUTH_YORKSHIRE, households: 50, wasteTonnageEstimate: 3.5, collectionType: CollectionType.COMMERCIAL_WASTE, oneWay: true, schoolZone: false, coordinates: [[330, 720], [340, 710], [350, 700]] },
  { id: "st-sheff-3", name: "Abbeydale Road", town: "Millhouses", region: YorkshireRegion.SOUTH_YORKSHIRE, households: 190, wasteTonnageEstimate: 2.0, collectionType: CollectionType.RECYCLING, oneWay: false, schoolZone: true, coordinates: [[330, 720], [315, 750], [300, 780]] },
  { id: "st-sheff-4", name: "Attercliffe Road", town: "Attercliffe", region: YorkshireRegion.SOUTH_YORKSHIRE, households: 120, wasteTonnageEstimate: 1.4, collectionType: CollectionType.GLASS, oneWay: false, schoolZone: false, coordinates: [[330, 720], [355, 715], [380, 710]] },

  // North Yorkshire (York / Harrogate)
  { id: "st-york-1", name: "Gillygate", town: "York Centre", region: YorkshireRegion.NORTH_YORKSHIRE, households: 110, wasteTonnageEstimate: 1.2, collectionType: CollectionType.GENERAL_WASTE, oneWay: true, schoolZone: false, coordinates: [[460, 390], [455, 370], [450, 350]] },
  { id: "st-york-2", name: "Bishopthorpe Road", town: "York South", region: YorkshireRegion.NORTH_YORKSHIRE, households: 160, wasteTonnageEstimate: 1.7, collectionType: CollectionType.RECYCLING, oneWay: false, schoolZone: true, coordinates: [[460, 390], [465, 410], [470, 430]] },
  { id: "st-york-3", name: "The Shambles", town: "York Centre", region: YorkshireRegion.NORTH_YORKSHIRE, households: 40, wasteTonnageEstimate: 2.5, collectionType: CollectionType.COMMERCIAL_WASTE, oneWay: true, schoolZone: false, coordinates: [[460, 390], [465, 385], [470, 380]] },
  { id: "st-york-4", name: "Harrogate Road", town: "Ripon", region: YorkshireRegion.NORTH_YORKSHIRE, households: 130, wasteTonnageEstimate: 1.1, collectionType: CollectionType.FOOD_WASTE, oneWay: false, schoolZone: false, coordinates: [[460, 390], [410, 340], [370, 310]] },

  // East Riding & Hull
  { id: "st-hull-1", name: "Beverley Road", town: "Hull North", region: YorkshireRegion.HULL, households: 280, wasteTonnageEstimate: 3.4, collectionType: CollectionType.GENERAL_WASTE, oneWay: false, schoolZone: false, coordinates: [[740, 520], [720, 490], [700, 470]] },
  { id: "st-hull-2", name: "Hessle Road", town: "Hull West", region: YorkshireRegion.HULL, households: 220, wasteTonnageEstimate: 2.3, collectionType: CollectionType.RECYCLING, oneWay: false, schoolZone: false, coordinates: [[740, 520], [700, 530], [670, 540]] },
  { id: "st-hull-3", name: "Princes Avenue", town: "Hull West", region: YorkshireRegion.HULL, households: 150, wasteTonnageEstimate: 1.6, collectionType: CollectionType.FOOD_WASTE, oneWay: false, schoolZone: true, coordinates: [[740, 520], [715, 510], [695, 500]] },
  { id: "st-er-1", name: "New Walk", town: "Beverley Town", region: YorkshireRegion.EAST_RIDING, households: 170, wasteTonnageEstimate: 1.4, collectionType: CollectionType.GARDEN_WASTE, oneWay: false, schoolZone: false, coordinates: [[680, 450], [660, 440], [640, 430]] },
  { id: "st-er-2", name: "Sewerby Road", town: "Bridlington", region: YorkshireRegion.EAST_RIDING, households: 190, wasteTonnageEstimate: 1.6, collectionType: CollectionType.GENERAL_WASTE, oneWay: false, schoolZone: false, coordinates: [[680, 450], [710, 400], [740, 350]] }
];

// Initial pre-loaded vehicle fleet
export const INITIAL_VEHICLES: Vehicle[] = [
  { id: "v-01", plate: "YG75 RRX", propulsion: PropulsionType.ELECTRIC, status: VehicleStatus.ACTIVE, capacityTons: 12.0, currentPayloadTons: 8.4, energyLevel: 78, consumptionRate: "1.45 kWh/km", lastMaintenanceDate: "2026-06-15", nextMaintenanceDate: "2026-12-15", driverId: "d-01", co2EmissionsKgPerKm: 0.0 },
  { id: "v-02", plate: "YH74 RRO", propulsion: PropulsionType.HYDROGEN, status: VehicleStatus.ACTIVE, capacityTons: 15.0, currentPayloadTons: 11.2, energyLevel: 92, consumptionRate: "0.08 kgH2/km", lastMaintenanceDate: "2026-07-02", nextMaintenanceDate: "2027-01-02", driverId: "d-02", co2EmissionsKgPerKm: 0.0 },
  { id: "v-03", plate: "YF23 ABY", propulsion: PropulsionType.DIESEL, status: VehicleStatus.ACTIVE, capacityTons: 18.0, currentPayloadTons: 14.5, energyLevel: 65, consumptionRate: "0.38 L/km", lastMaintenanceDate: "2026-05-10", nextMaintenanceDate: "2026-11-10", driverId: "d-03", co2EmissionsKgPerKm: 1.01 },
  { id: "v-04", plate: "YG22 KLS", propulsion: PropulsionType.DIESEL, status: VehicleStatus.MAINTENANCE, capacityTons: 18.0, currentPayloadTons: 0.0, energyLevel: 10, consumptionRate: "0.41 L/km", lastMaintenanceDate: "2026-07-29", nextMaintenanceDate: "2026-08-05", co2EmissionsKgPerKm: 1.09 },
  { id: "v-05", plate: "YE75 ERT", propulsion: PropulsionType.ELECTRIC, status: VehicleStatus.STANDBY, capacityTons: 10.0, currentPayloadTons: 0.0, energyLevel: 100, consumptionRate: "1.30 kWh/km", lastMaintenanceDate: "2026-06-20", nextMaintenanceDate: "2026-12-20", driverId: "d-04", co2EmissionsKgPerKm: 0.0 },
  { id: "v-06", plate: "YF75 HLL", propulsion: PropulsionType.HYDROGEN, status: VehicleStatus.CHARGING, capacityTons: 15.0, currentPayloadTons: 0.0, energyLevel: 32, consumptionRate: "0.08 kgH2/km", lastMaintenanceDate: "2026-04-12", nextMaintenanceDate: "2026-10-12", co2EmissionsKgPerKm: 0.0 },
  { id: "v-07", plate: "YK74 LDS", propulsion: PropulsionType.ELECTRIC, status: VehicleStatus.ACTIVE, capacityTons: 12.0, currentPayloadTons: 4.2, energyLevel: 55, consumptionRate: "1.40 kWh/km", lastMaintenanceDate: "2026-07-11", nextMaintenanceDate: "2027-01-11", driverId: "d-05", co2EmissionsKgPerKm: 0.0 },
  { id: "v-08", plate: "YJ21 TTR", propulsion: PropulsionType.DIESEL, status: VehicleStatus.ACTIVE, capacityTons: 20.0, currentPayloadTons: 17.1, energyLevel: 45, consumptionRate: "0.44 L/km", lastMaintenanceDate: "2026-03-30", nextMaintenanceDate: "2026-09-30", driverId: "d-06", co2EmissionsKgPerKm: 1.15 }
];

// Operational Drivers
export const INITIAL_DRIVERS: Driver[] = [
  { id: "d-01", name: "Alastair Hirst", assignedVehicleId: "v-01", status: "On Shift", shiftMinutes: 320, maxShiftMinutes: 480 },
  { id: "d-02", name: "Darren Ramsden", assignedVehicleId: "v-02", status: "On Shift", shiftMinutes: 240, maxShiftMinutes: 480 },
  { id: "d-03", name: "Gareth Sugden", assignedVehicleId: "v-03", status: "On Shift", shiftMinutes: 410, maxShiftMinutes: 480 },
  { id: "d-04", name: "Lee Shackleton", assignedVehicleId: "v-05", status: "Resting", shiftMinutes: 0, maxShiftMinutes: 480 },
  { id: "d-05", name: "Sian Priestley", assignedVehicleId: "v-07", status: "On Shift", shiftMinutes: 180, maxShiftMinutes: 480 },
  { id: "d-06", name: "Marcus Broadbent", assignedVehicleId: "v-08", status: "On Shift", shiftMinutes: 380, maxShiftMinutes: 480 },
  { id: "d-07", name: "Craig Armitage", status: "Off Duty", shiftMinutes: 0, maxShiftMinutes: 480 }
];

// Pre-seeded historical ledger blocks
export const INITIAL_LEDGER: LedgerBlock[] = [
  {
    index: 0,
    timestamp: "2026-07-30T06:00:00Z",
    event: "GENESIS_BLOCK",
    operator: "SYSTEM",
    payload: "RhinoRoute Municipal Ledger Initialised.",
    previousHash: "0",
    hash: "6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b"
  },
  {
    index: 1,
    timestamp: "2026-07-30T06:15:30Z",
    event: "ROUTE_PUBLISHED",
    operator: "L_MUNICIPAL_OP_01",
    payload: "Leeds General Waste Route WY-GEN-04 published to vehicle YG75 RRX",
    previousHash: "6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b",
    hash: "d4c22bb609b578c73cd3e387c38520cf977b31131ef8f48037b51bfa50be0689"
  },
  {
    index: 2,
    timestamp: "2026-07-30T06:22:11Z",
    event: "FLEET_DISPATCH",
    operator: "S_FLEET_OP_04",
    payload: "Sheffield Lumley Depot: Dispatched hydrogen vehicle YH74 RRO for recycling route SY-REC-01",
    previousHash: "d4c22bb609b578c73cd3e387c38520cf977b31131ef8f48037b51bfa50be0689",
    hash: "8bf9f143c7b27ff7799b3806fbfa261ee977a41ef5be0689efdf401bc77f394c"
  },
  {
    index: 3,
    timestamp: "2026-07-30T07:10:45Z",
    event: "MAINTENANCE_LOG",
    operator: "Y_TECH_MGR_02",
    payload: "York Vehicle YG22 KLS signed off for major brake fluid inspection and hydraulic seals upgrade.",
    previousHash: "8bf9f143c7b27ff7799b3806fbfa261ee977a41ef5be0689efdf401bc77f394c",
    hash: "f400f913d502fb8872eb1bf386df2ef09ee8a313ef0de0e8ff31bca5e39b03ff"
  }
];

// Pre-seeded R-driven historical metrics (24 months) and forecasting tables
export const REGIONAL_HISTORICAL_TONNAGE: Record<YorkshireRegion, number[]> = {
  [YorkshireRegion.WEST_YORKSHIRE]: [
    12400, 12100, 12800, 13500, 14900, 15300, 15100, 14400, 13900, 13100, 12600, 13200,
    12800, 12400, 13100, 13900, 15400, 15900, 15600, 14900, 14300, 13600, 13000, 13700
  ],
  [YorkshireRegion.SOUTH_YORKSHIRE]: [
    9100, 8900, 9300, 9800, 10700, 11100, 10900, 10400, 10000, 9500, 9200, 9600,
    9300, 9100, 9500, 10100, 11000, 11400, 11200, 10700, 10300, 9800, 9400, 9900
  ],
  [YorkshireRegion.NORTH_YORKSHIRE]: [
    6200, 5900, 6400, 7100, 8300, 8800, 8900, 8100, 7500, 6800, 6300, 6600,
    6400, 6100, 6600, 7400, 8700, 9100, 9200, 8400, 7800, 7000, 6500, 6800
  ],
  [YorkshireRegion.EAST_RIDING]: [
    4800, 4500, 4900, 5500, 6700, 7100, 7200, 6400, 5900, 5200, 4800, 5100,
    5000, 4700, 5100, 5800, 7000, 7400, 7500, 6700, 6100, 5400, 5000, 5300
  ],
  [YorkshireRegion.HULL]: [
    4100, 3950, 4200, 4400, 4750, 4900, 4850, 4600, 4450, 4250, 4150, 4300,
    4220, 4050, 4310, 4520, 4900, 5050, 4980, 4730, 4570, 4380, 4260, 4420
  ]
};

// Growth and seasonal scaling multipliers based on operational waste analysis (e.g. Garden waste high in Summer, General waste stable, Recycling peaks in Dec/Jan)
export const WASTE_TYPE_SEASONALITY: Record<CollectionType, number[]> = {
  [CollectionType.GENERAL_WASTE]: [1.0, 0.98, 1.01, 1.02, 1.03, 1.04, 1.02, 1.01, 1.0, 0.99, 0.98, 1.05], // Christmas peak
  [CollectionType.RECYCLING]: [1.08, 1.02, 0.99, 0.98, 0.99, 1.01, 1.0, 0.98, 0.99, 1.02, 1.05, 1.18], // Big Jan packaging peak
  [CollectionType.GARDEN_WASTE]: [0.1, 0.2, 0.6, 1.1, 1.6, 1.9, 1.8, 1.5, 1.1, 0.5, 0.1, 0.05], // Summer surge
  [CollectionType.FOOD_WASTE]: [1.02, 1.0, 1.01, 1.03, 1.04, 1.05, 1.03, 1.02, 1.01, 1.0, 1.01, 1.08], // Relatively stable
  [CollectionType.COMMERCIAL_WASTE]: [0.95, 0.98, 1.02, 1.05, 1.08, 1.1, 1.08, 1.02, 1.05, 1.04, 1.02, 1.12], // Retail summer & Dec
  [CollectionType.CLINICAL_WASTE]: [1.0, 1.01, 1.0, 0.99, 1.0, 0.98, 0.97, 0.98, 0.99, 1.01, 1.02, 1.03], // High stability
  [CollectionType.BULKY_WASTE]: [0.6, 0.7, 0.9, 1.2, 1.4, 1.5, 1.3, 1.2, 1.1, 0.9, 0.7, 0.6], // Spring cleaning
  [CollectionType.GLASS]: [1.05, 1.0, 1.02, 1.04, 1.08, 1.12, 1.15, 1.1, 1.04, 1.02, 1.05, 1.25] // High summer beverages & Dec festive
};

// Pre-calculated coefficients for ARIMA (1,1,1) x (1,1,0)_12 models simulating R calculations
export const ARIMA_COEFFICIENTS = {
  ar1: 0.421,
  ma1: -0.632,
  sar1: 0.215,
  drift: 15.4 // General positive trend across Yorkshire
};
