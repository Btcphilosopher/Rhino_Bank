export enum YorkshireRegion {
  WEST_YORKSHIRE = "West Yorkshire",
  SOUTH_YORKSHIRE = "South Yorkshire",
  NORTH_YORKSHIRE = "North Yorkshire",
  EAST_RIDING = "East Riding of Yorkshire",
  HULL = "Kingston upon Hull"
}

export enum CollectionType {
  GENERAL_WASTE = "General Waste",
  RECYCLING = "Recycling",
  GARDEN_WASTE = "Garden Waste",
  FOOD_WASTE = "Food Waste",
  COMMERCIAL_WASTE = "Commercial Waste",
  CLINICAL_WASTE = "Clinical Waste",
  BULKY_WASTE = "Bulky Waste",
  GLASS = "Glass Collection"
}

export enum PropulsionType {
  DIESEL = "Diesel",
  ELECTRIC = "Electric (BEV)",
  HYDROGEN = "Hydrogen (FCEV)"
}

export enum VehicleStatus {
  ACTIVE = "Active",
  MAINTENANCE = "Maintenance",
  STANDBY = "Standby",
  CHARGING = "Charging / Refuelling"
}

export interface Depot {
  id: string;
  name: string;
  region: YorkshireRegion;
  lat: number; // For visualization coordinate reference
  lng: number;
  capacity: number; // Max fleet size
  activeVehicles: number;
}

export interface Facility {
  id: string;
  name: string;
  type: "Landfill" | "Energy-from-Waste" | "Recycling Centre" | "Transfer Station";
  region: YorkshireRegion;
  lat: number;
  lng: number;
  fillRate: number; // 0 - 100%
  dailyCapacityTons: number;
}

export interface StreetSegment {
  id: string;
  name: string;
  town: string;
  region: YorkshireRegion;
  households: number;
  wasteTonnageEstimate: number;
  coordinates: [number, number][]; // Line coordinates
  collectionType: CollectionType;
  oneWay: boolean;
  schoolZone: boolean;
}

export interface CollectionRoute {
  id: string;
  name: string;
  region: YorkshireRegion;
  collectionType: CollectionType;
  depotId: string;
  facilityId: string;
  vehicleId: string;
  driverName: string;
  streets: string[]; // List of street IDs
  totalHouseholds: number;
  plannedTonnage: number;
  completedTonnage: number;
  distanceKm: number;
  durationMinutes: number;
  missedCollections: number;
  status: "Planned" | "Active" | "Completed" | "Interrupted";
  points: [number, number][]; // Combined route polyline coords
}

export interface Vehicle {
  id: string;
  plate: string;
  propulsion: PropulsionType;
  status: VehicleStatus;
  capacityTons: number;
  currentPayloadTons: number;
  energyLevel: number; // battery % or fuel %
  consumptionRate: string; // e.g., "1.4 kWh/km" or "0.35 L/km"
  lastMaintenanceDate: string;
  nextMaintenanceDate: string;
  driverId?: string;
  co2EmissionsKgPerKm: number;
}

export interface Driver {
  id: string;
  name: string;
  assignedVehicleId?: string;
  status: "On Shift" | "Resting" | "Off Duty";
  shiftMinutes: number;
  maxShiftMinutes: number;
}

export interface ForecastPoint {
  date: string;
  actualTonnage?: number;
  forecastTonnage: number;
  confidenceLower: number;
  confidenceUpper: number;
}

export interface LedgerBlock {
  index: number;
  timestamp: string;
  event: string;
  operator: string;
  payload: string;
  previousHash: string;
  hash: string;
}

export interface SolverLog {
  timestamp: string;
  level: "INFO" | "WARN" | "ERROR" | "SUCCESS";
  thread: string;
  message: string;
}

export interface SolverConfig {
  iterations: number;
  maxCapacityMultiplier: number;
  weatherFactor: "Fine" | "Rain" | "Snow" | "Ice";
  trafficWeight: number; // 0 - 100
  speedLimitMultiplier: number; // 0.5 - 1.0
  timeWindowStrictness: "Flexible" | "Standard" | "Strict";
  multiDepotBalancing: boolean;
}
