package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.GameViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

enum class GameTab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    CHANCELLERY("Chancellery", Icons.Default.Dashboard),
    MAP("Campus Map", Icons.Default.Map),
    RESEARCH("Research", Icons.Default.Biotech),
    FACULTY("Faculty", Icons.Default.People),
    STUDENTS("Students", Icons.Default.School),
    FINANCES("Finances", Icons.Default.AccountBalanceWallet),
    RANKINGS("Leaderboard", Icons.Default.Leaderboard)
}

class MainActivity : ComponentActivity() {

    private val viewModel: GameViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val gameState by viewModel.gameState.collectAsStateWithLifecycle()
                val universities by viewModel.universities.collectAsStateWithLifecycle()
                val playerAcademics by viewModel.playerAcademics.collectAsStateWithLifecycle()
                val playerStudents by viewModel.playerStudents.collectAsStateWithLifecycle()
                val playerBuildings by viewModel.playerBuildings.collectAsStateWithLifecycle()
                val projects by viewModel.projects.collectAsStateWithLifecycle()
                val theories by viewModel.theories.collectAsStateWithLifecycle()
                val logs by viewModel.logs.collectAsStateWithLifecycle()
                val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()
                val simSpeed by viewModel.simSpeed.collectAsStateWithLifecycle()
                val activeEvent by viewModel.activeEvent.collectAsStateWithLifecycle()
                val activeCompetition by viewModel.activeCompetition.collectAsStateWithLifecycle()
                val recruitmentMarket by viewModel.recruitmentMarket.collectAsStateWithLifecycle()

                var currentTab by remember { mutableStateOf(GameTab.CHANCELLERY) }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (gameState == null) {
                        // Launch starting Setup selection screen
                        SetupScreen(
                            onStartGame = { uniId, vcName, initialTuition ->
                                viewModel.startNewGame(uniId, vcName, initialTuition)
                            }
                        )
                    } else {
                        val state = gameState!!
                        val playerUni = universities.firstOrNull { it.id == state.selectedUniversityId }

                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            bottomBar = {
                                val isDark = MaterialTheme.colorScheme.background == com.example.ui.theme.DeepObsidian
                                NavigationBar(
                                    modifier = Modifier
                                        .windowInsetsPadding(WindowInsets.navigationBars)
                                        .testTag("bottom_nav_bar"),
                                    containerColor = if (isDark) androidx.compose.ui.graphics.Color(0xFF080C14) else androidx.compose.ui.graphics.Color(0xFFF1F5F9),
                                    tonalElevation = 0.dp
                                ) {
                                    GameTab.values().forEach { tab ->
                                        val isSelected = currentTab == tab
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = { currentTab = tab },
                                            icon = {
                                                Icon(
                                                    imageVector = tab.icon,
                                                    contentDescription = tab.label,
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            },
                                            label = {
                                                Text(
                                                    text = tab.label,
                                                    fontSize = 10.sp,
                                                    letterSpacing = 0.5.sp,
                                                    fontWeight = if (isSelected) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Medium
                                                )
                                            },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                                unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                                unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                            ),
                                            modifier = Modifier.testTag("nav_tab_${tab.name}")
                                        )
                                    }
                                }
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                                    .background(MaterialTheme.colorScheme.background)
                            ) {
                                when (currentTab) {
                                    GameTab.CHANCELLERY -> {
                                        DashboardScreen(
                                            gameState = state,
                                            currentUni = playerUni,
                                            isSimulating = isSimulating,
                                            simSpeed = simSpeed,
                                            logs = logs,
                                            activeEvent = activeEvent,
                                            activeCompetition = activeCompetition,
                                            onToggleSim = { viewModel.toggleSimulation() },
                                            onSetSpeed = { viewModel.setSimSpeed(it) },
                                            onSelectEventOption = { viewModel.selectEventOption(it) },
                                            onEnterCompetition = { viewModel.enterCompetition() },
                                            onSkipCompetition = { viewModel.skipCompetition() },
                                            academicsCount = playerAcademics.size,
                                            studentsCount = playerStudents.size,
                                            buildingsCount = playerBuildings.size
                                        )
                                    }
                                    GameTab.MAP -> {
                                        CampusMapScreen(
                                            buildings = playerBuildings,
                                            treasury = state.treasury,
                                            onBuild = { type, x, y -> viewModel.buildStructure(type, x, y) },
                                            onUpgrade = { viewModel.upgradeStructure(it) },
                                            onDemolish = { viewModel.demolishStructure(it) }
                                        )
                                    }
                                    GameTab.RESEARCH -> {
                                        ResearchScreen(
                                            projects = projects,
                                            theories = theories,
                                            academics = playerAcademics,
                                            treasury = state.treasury,
                                            onLaunchProject = { title, dept, leadId, funding ->
                                                viewModel.launchResearchProject(title, dept, leadId, funding)
                                            }
                                        )
                                    }
                                    GameTab.FACULTY -> {
                                        StaffScreen(
                                            hiredAcademics = playerAcademics,
                                            recruitmentMarket = recruitmentMarket,
                                            treasury = state.treasury,
                                            onHire = { viewModel.hireAcademic(it) },
                                            onFire = { viewModel.fireAcademic(it) }
                                        )
                                    }
                                    GameTab.STUDENTS -> {
                                        StudentLifeScreen(
                                            students = playerStudents
                                        )
                                    }
                                    GameTab.FINANCES -> {
                                        FinancesScreen(
                                            gameState = state,
                                            playerUni = playerUni,
                                            academics = playerAcademics,
                                            buildings = playerBuildings,
                                            onSetTuition = { viewModel.setTuition(it) }
                                        )
                                    }
                                    GameTab.RANKINGS -> {
                                        LeaderboardScreen(
                                            gameState = state,
                                            universities = universities
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
