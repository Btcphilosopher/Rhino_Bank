package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameStateEntity
import com.example.data.LogEntity
import com.example.data.UniversityEntity
import com.example.ui.AcademicCompetition
import com.example.ui.SimulationEvent

@Composable
fun DashboardScreen(
    gameState: GameStateEntity,
    currentUni: UniversityEntity?,
    isSimulating: Boolean,
    simSpeed: Long,
    logs: List<LogEntity>,
    activeEvent: SimulationEvent?,
    activeCompetition: AcademicCompetition?,
    onToggleSim: () -> Unit,
    onSetSpeed: (Long) -> Unit,
    onSelectEventOption: (com.example.ui.EventOption) -> Unit,
    onEnterCompetition: () -> Unit,
    onSkipCompetition: () -> Unit,
    academicsCount: Int,
    studentsCount: Int,
    buildingsCount: Int
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("dashboard_screen_container")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "VICE-CHANCELLOR ${gameState.playerChancellorName.uppercase()}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 2.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = currentUni?.name ?: "University",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            fontWeight = FontWeight.Light,
                            letterSpacing = (-0.5).sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                // Date Emblem
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = getMonthName(gameState.month),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Serif,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                fontWeight = FontWeight.Light
                            ),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Y${"%02d".format(gameState.year)}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.onBackground,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // High-Level Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "TREASURY",
                    value = "£${"%,.0f".format(gameState.treasury)}",
                    icon = Icons.Default.AccountBalanceWallet,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f).testTag("metric_treasury")
                )
                MetricCard(
                    title = "PRESTIGE",
                    value = "${"%.1f".format(gameState.prestige)}/100",
                    icon = Icons.Default.Stars,
                    color = Color(0xFFD4AF37), // Gold
                    modifier = Modifier.weight(1f).testTag("metric_prestige")
                )
            }

            // Quick Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatPill(icon = Icons.Default.People, label = "$studentsCount Students", modifier = Modifier.weight(1f))
                StatPill(icon = Icons.Default.School, label = "$academicsCount Faculty", modifier = Modifier.weight(1f))
                StatPill(icon = Icons.Default.Business, label = "$buildingsCount Buildings", modifier = Modifier.weight(1f))
            }

            // Control panel
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onToggleSim,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSimulating) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("toggle_sim_button")
                        ) {
                            Icon(
                                imageVector = if (isSimulating) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isSimulating) "Pause" else "Play",
                                modifier = Modifier.size(20.dp),
                                tint = MaterialTheme.colorScheme.background
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isSimulating) "PAUSE SIM" else "STEP MONTH",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.background
                            )
                        }

                        // Simulation speed multipliers
                        if (isSimulating) {
                            SpeedChip(label = "1x", selected = simSpeed == 1000L, onClick = { onSetSpeed(1000L) })
                            SpeedChip(label = "5x", selected = simSpeed == 200L, onClick = { onSetSpeed(200L) })
                        }
                    }

                    Text(
                        text = if (isSimulating) "Simulation Active" else "Time Paused",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isSimulating) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // History Feed / Terminal Console
            Text(
                text = "CHANCELLERY FEED & ACADEMIC LOGS",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF080C14)), // Dark minimalist console background
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .testTag("console_logs_list"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (logs.isEmpty()) {
                        item {
                            Text(
                                text = "> Initializing log registers...",
                                color = Color(0xFF2C6B4E),
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    } else {
                        items(logs) { log ->
                            TerminalLogLine(log)
                        }
                    }
                }
            }
        }

        // Active Event Dialog/Overlay
        activeEvent?.let { event ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .testTag("event_dialog_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = "Emergency Event",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = event.title,
                                style = MaterialTheme.typography.displayMedium.copy(fontSize = 22.sp),
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.outline)

                        Text(
                            text = event.description,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            event.options.forEachIndexed { idx, option ->
                                Button(
                                    onClick = { onSelectEventOption(option) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .testTag("event_option_$idx"),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = option.text,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.background
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Competition Dialog/Overlay
        activeCompetition?.let { comp ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .testTag("competition_dialog_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(2.dp, Color(0xFFD4AF37)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Competition Trophy",
                            tint = Color(0xFFD4AF37),
                            modifier = Modifier.size(48.dp)
                        )

                        Text(
                            text = "YORKSHIRE ACADEMIC TOURNAMENT",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color(0xFFD4AF37)
                        )

                        Text(
                            text = comp.title,
                            style = MaterialTheme.typography.displayMedium.copy(fontSize = 22.sp),
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "Your university has been invited to join the Yorkshire Academic tournament in the field of ${comp.department}. Our delegation is lead by ${comp.leadAcademic}.",
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = onSkipCompetition,
                                modifier = Modifier.weight(1f).height(48.dp).testTag("skip_comp_button"),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Text("DECLINE")
                            }

                            Button(
                                onClick = onEnterCompetition,
                                modifier = Modifier.weight(1f).height(48.dp).testTag("enter_comp_button"),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD4AF37))
                            ) {
                                Text("ENTER TOURNAMENT", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(18.dp))
            }
            Text(
                text = value,
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = (-0.5).sp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun StatPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.3f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun SpeedChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (selected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("speed_chip_$label")
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun TerminalLogLine(log: LogEntity) {
    val prefixColor = when (log.type) {
        "Research" -> Color(0xFF38BDF8) // Sky Blue
        "Event" -> Color(0xFFF59E0B) // Amber
        "Ranking" -> Color(0xFFF59E0B) // Amber
        "Financial" -> Color(0xFFEF4444) // Warning red
        else -> Color(0xFF10B981) // Emerald
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "[Y${log.year} M${log.month}]",
            fontFamily = FontFamily.Monospace,
            color = Color.Gray,
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            text = when (log.type) {
                "Research" -> "• [RES]"
                "Event" -> "• [EVT]"
                "Ranking" -> "• [RNK]"
                "Financial" -> "• [FIN]"
                else -> "• [SYS]"
            },
            fontFamily = FontFamily.Monospace,
            color = prefixColor,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = log.message,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFFCBD5E1), // Slate-300 text
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
    }
}

fun getMonthName(m: Int): String {
    return when (m) {
        1 -> "JANUARY"
        2 -> "FEBRUARY"
        3 -> "MARCH"
        4 -> "APRIL"
        5 -> "MAY"
        6 -> "JUNE"
        7 -> "JULY"
        8 -> "AUGUST"
        9 -> "SEPTEMBER"
        10 -> "OCTOBER"
        11 -> "NOVEMBER"
        12 -> "DECEMBER"
        else -> "TICK"
    }
}
