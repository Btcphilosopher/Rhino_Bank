package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BuildingEntity

@Composable
fun CampusMapScreen(
    buildings: List<BuildingEntity>,
    treasury: Double,
    onBuild: (String, Int, Int) -> Unit,
    onUpgrade: (BuildingEntity) -> Unit,
    onDemolish: (BuildingEntity) -> Unit
) {
    val gridSize = 6
    var selectedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var showBuildDialog by remember { mutableStateOf(false) }
    var selectedBuilding by remember { mutableStateOf<BuildingEntity?>(null) }

    // Map building type to display labels and costs
    val buildPresets = listOf(
        BuildOption("LectureHall", "Lecture Theatre", 250000.0, "Boosts teaching quality & satisfaction.", Icons.Default.CastForEducation),
        BuildOption("Library", "Bodleian Library", 400000.0, "Increases research rate and reference materials.", Icons.Default.MenuBook),
        BuildOption("Lab", "Robotics Laboratory", 550000.0, "Directly powers research discoveries.", Icons.Default.Science),
        BuildOption("Accommodation", "Student Housing", 450000.0, "Maintains student wellbeing and provides rent.", Icons.Default.Home),
        BuildOption("SportsCentre", "Sports Complex", 350000.0, "Reduces student stress and boosts morale.", Icons.Default.FitnessCenter),
        BuildOption("CoffeeHouse", "Yorkshire Coffee Co.", 150000.0, "Provides monthly commercial revenue.", Icons.Default.LocalCafe),
        BuildOption("SciencePark", "Advanced Tech Park", 750000.0, "Speeds up tech patents & spin-outs.", Icons.Default.DeveloperMode),
        BuildOption("InnovationCentre", "Chancellery Innovation", 500000.0, "Improves grant writing outcomes.", Icons.Default.Lightbulb)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("campus_map_container")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CAMPUS ARCHITECTURE",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Build, upgrade, and structure the physical heart of the institution",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Balance display
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Text(
                        text = "£${"%,.0f".format(treasury)}",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Interactive grid with scroll for Pan support
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF080C14)) // Dark minimalist slate deck
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(rememberScrollState())
                        .verticalScroll(rememberScrollState()),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (y in 0 until gridSize) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                for (x in 0 until gridSize) {
                                    val building = buildings.firstOrNull { it.gridX == x && it.gridY == y }
                                    GridCell(
                                        x = x,
                                        y = y,
                                        building = building,
                                        isSelected = selectedCell?.first == x && selectedCell?.second == y,
                                        onClick = {
                                            selectedCell = Pair(x, y)
                                            if (building != null) {
                                                selectedBuilding = building
                                                showBuildDialog = false
                                            } else {
                                                selectedBuilding = null
                                                showBuildDialog = true
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Selection Info Footer Panel
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Box(modifier = Modifier.padding(16.dp)) {
                    if (selectedBuilding != null) {
                        val bld = selectedBuilding!!
                        val preset = buildPresets.firstOrNull { it.type == bld.type }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(
                                        imageVector = preset?.icon ?: Icons.Default.Business,
                                        contentDescription = bld.type,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = "${preset?.name ?: bld.type} (Level ${bld.level})",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Monthly Maintenance: £${"%,.0f".format(bld.level * bld.operatingCost)} | Strategic Value: +${bld.strategicValue.toInt()} Rating",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = preset?.benefit ?: "Provides structural value to campus.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        onDemolish(bld)
                                        selectedBuilding = null
                                        selectedCell = null
                                    },
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.testTag("demolish_button")
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Demolish", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("DEMOLISH")
                                }

                                Button(
                                    onClick = {
                                        onUpgrade(bld)
                                        selectedBuilding = null
                                        selectedCell = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                    modifier = Modifier.testTag("upgrade_button")
                                ) {
                                    Icon(imageVector = Icons.Default.TrendingUp, contentDescription = "Upgrade", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.background)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("UPGRADE (£${"%,.0f".format(bld.level * 180000.0)})", color = MaterialTheme.colorScheme.background)
                                }
                            }
                        }
                    } else if (showBuildDialog && selectedCell != null) {
                        val (cx, cy) = selectedCell!!
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Construct on Sector ($cx, $cy)",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                buildPresets.forEach { option ->
                                    Card(
                                        modifier = Modifier
                                            .width(200.dp)
                                            .clickable {
                                                onBuild(option.type, cx, cy)
                                                showBuildDialog = false
                                                selectedCell = null
                                            }
                                            .testTag("build_preset_${option.type}"),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Icon(imageVector = option.icon, contentDescription = option.name, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
                                                Text(text = option.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                                            }
                                            Text(text = "Cost: £${"%,.0f".format(option.cost)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                            Text(text = option.benefit, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "Select any sector on the campus grid to inspect or begin construction.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GridCell(
    x: Int,
    y: Int,
    building: BuildingEntity?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val cellColor = when {
        isSelected -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f)
        building != null -> MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
        else -> Color.Transparent
    }

    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.secondary
        building != null -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
    }

    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(cellColor)
            .border(1.dp, borderColor, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .testTag("map_cell_${x}_${y}"),
        contentAlignment = Alignment.Center
    ) {
        if (building != null) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = when (building.type) {
                        "LectureHall" -> Icons.Default.CastForEducation
                        "Library" -> Icons.Default.MenuBook
                        "Lab" -> Icons.Default.Science
                        "Accommodation" -> Icons.Default.Home
                        "SportsCentre" -> Icons.Default.FitnessCenter
                        "CoffeeHouse" -> Icons.Default.LocalCafe
                        "SciencePark" -> Icons.Default.DeveloperMode
                        "InnovationCentre" -> Icons.Default.Lightbulb
                        else -> Icons.Default.Business
                    },
                    contentDescription = building.type,
                    tint = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Lvl ${building.level}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            Text(
                text = "$x,$y",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
            )
        }
    }
}

data class BuildOption(
    val type: String,
    val name: String,
    val cost: Double,
    val benefit: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
