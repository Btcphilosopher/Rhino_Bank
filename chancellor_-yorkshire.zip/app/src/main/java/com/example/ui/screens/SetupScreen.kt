package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

data class StartUniPreset(
    val id: Int,
    val name: String,
    val location: String,
    val prestige: String,
    val funds: String,
    val focus: String,
    val description: String,
    val iconId: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(
    onStartGame: (playerUniId: Int, chancellorName: String, initialTuition: Double) -> Unit
) {
    var chancellorName by remember { mutableStateOf("Dr. Alistair Sterling") }
    var initialTuition by remember { mutableStateOf(9250.0) }
    var selectedUniId by remember { mutableStateOf(1) }

    val presets = listOf(
        StartUniPreset(
            id = 1,
            name = "University of York",
            location = "York",
            prestige = "High (55)",
            funds = "Moderate (£4.0M)",
            focus = "Scientific Research & Liberal Arts",
            description = "A historic institution founded on principles of high academic prestige, tucked behind medieval walls. Excellence in pure research and humanistic inquiry.",
            iconId = R.drawable.ic_launcher_background
        ),
        StartUniPreset(
            id = 2,
            name = "University of Leeds",
            location = "Leeds",
            prestige = "Moderate (52)",
            funds = "Very High (£6.5M)",
            focus = "Industrial Scale & Commerce",
            description = "A redbrick giant built on Leeds' textile and engineering legacy. Massive student numbers and massive funding, balanced in scope.",
            iconId = R.drawable.ic_launcher_background
        ),
        StartUniPreset(
            id = 3,
            name = "University of Sheffield",
            location = "Sheffield",
            prestige = "Moderate (50)",
            funds = "High (£5.0M)",
            focus = "Advanced Materials & Heavy Metallurgy",
            description = "Renowned for its advanced engineering and research labs. Heavily linked with high-tech manufacturing, aerospace, and metallurgy.",
            iconId = R.drawable.ic_launcher_background
        ),
        StartUniPreset(
            id = 4,
            name = "Bradford University",
            location = "Bradford",
            prestige = "Lower (40)",
            funds = "Moderate (£3.0M)",
            focus = "Social Mobility & Student Care",
            description = "A pioneer in community integration and social sciences. Attracts highly motivated students from diverse, resilient backgrounds.",
            iconId = R.drawable.ic_launcher_background
        ),
        StartUniPreset(
            id = 5,
            name = "University of Hull",
            location = "Hull",
            prestige = "Moderate (42)",
            funds = "Moderate (£3.5M)",
            focus = "Maritime & Renewable Ecology",
            description = "Set in the Humber estuary. Excellence in marine biology, supply logistics, and sustainable renewable energy networks.",
            iconId = R.drawable.ic_launcher_background
        ),
        StartUniPreset(
            id = 6,
            name = "Huddersfield University",
            location = "Huddersfield",
            prestige = "Lower (38)",
            funds = "Lower (£2.8M)",
            focus = "Vocational Arts & Technology",
            description = "Known for strong industry links, high graduate employment, and practical, hands-on engineering apprenticeships.",
            iconId = R.drawable.ic_launcher_background
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
            .testTag("setup_screen_container"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "UNIVERSITY CHANCELLOR",
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.secondary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "YORKSHIRE FUTURISM",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 4.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Beautiful Hero Banner representation
            // Using the generated image img_yorkshire_futurism_1785325127801
            Image(
                painter = painterResource(id = R.drawable.img_yorkshire_futurism_1785325127801),
                contentDescription = "Yorkshire futurism university banner",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Chancellor Inauguration",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    OutlinedTextField(
                        value = chancellorName,
                        onValueChange = { chancellorName = it },
                        label = { Text("Vice-Chancellor Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("vc_name_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.secondary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    Text(
                        text = "Initial Tuition: £${initialTuition.toInt()} / year",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = initialTuition.toFloat(),
                        onValueChange = { initialTuition = it.toDouble().coerceIn(6000.0, 12000.0) },
                        valueRange = 6000f..12000f,
                        steps = 6,
                        modifier = Modifier.testTag("tuition_slider")
                    )
                }
            }
        }

        item {
            Text(
                text = "Choose Your Yorkshire Institution",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )
        }

        items(presets) { preset ->
            val isSelected = selectedUniId == preset.id
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedUniId = preset.id }
                    .border(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .testTag("uni_preset_card_${preset.id}"),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.surface.copy(alpha = 0.9f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .background(
                                color = if (isSelected) MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(8.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = "University emblem",
                            tint = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = preset.name,
                                style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = preset.location,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                        Text(
                            text = "Starting Prestige: ${preset.prestige} | Funds: ${preset.funds}",
                            style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        )
                        Text(
                            text = "Primary Focus: ${preset.focus}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Text(
                            text = preset.description,
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        item {
            Button(
                onClick = { onStartGame(selectedUniId, chancellorName, initialTuition) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("start_game_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "INAUGURATE VICE-CHANCELLOR",
                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 16.sp, color = MaterialTheme.colorScheme.background),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
