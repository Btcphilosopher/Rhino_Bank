package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AcademicEntity
import com.example.data.BuildingEntity
import com.example.data.GameStateEntity
import com.example.data.UniversityEntity

@Composable
fun FinancesScreen(
    gameState: GameStateEntity,
    playerUni: UniversityEntity?,
    academics: List<AcademicEntity>,
    buildings: List<BuildingEntity>,
    onSetTuition: (Double) -> Unit
) {
    var feeInput by remember { mutableStateOf(gameState.tuitionFee) }

    // Re-calculate the ledger items based on the active state inside this view
    // to keep it in sync with the simulation math
    val activeStudentsCount = 20 * 120 // simulated scale
    val monthlyTuitionRev = (gameState.tuitionFee * activeStudentsCount) / 12.0

    val accommodationsCount = buildings.count { it.type == "Accommodation" }
    val accommLevels = buildings.filter { it.type == "Accommodation" }.sumOf { it.level }
    val monthlyAccommRev = accommodationsCount * 30000.0 * accommLevels

    val labsCount = buildings.count { it.type == "Lab" }
    val avgGrantWriting = if (academics.isNotEmpty()) academics.map { it.grantWriting }.average() else 40.0
    val monthlyResearchGrants = (labsCount * 45000.0) + (avgGrantWriting * 800.0)

    val commercialCount = buildings.count { it.type == "CoffeeHouse" }
    val campusSatisfaction = playerUni?.satisfactionRating ?: 50.0
    val monthlyCommercialRev = commercialCount * 15000.0 * (1.0 + (campusSatisfaction / 100.0))

    val totalIncome = monthlyTuitionRev + monthlyAccommRev + monthlyResearchGrants + monthlyCommercialRev

    val monthlySalaries = academics.sumOf { it.salary } / 12.0
    val monthlyBuildingMaint = buildings.sumOf { it.level * it.operatingCost } / 12.0
    val monthlyBaseCost = 50000.0

    val totalExpense = monthlySalaries + monthlyBuildingMaint + monthlyBaseCost
    val netBalance = totalIncome - totalExpense

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("finances_screen_container")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FINANCIAL LEDGER & DIRECTIVES",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Review operating statements and adjust macro chancellery policies",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Ledger sheet
            Card(
                modifier = Modifier.fillMaxWidth().weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = "Operating Ledger", tint = MaterialTheme.colorScheme.secondary)
                        Text(
                            text = "MONTHLY FINANCIAL STATEMENT",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.outline)

                    // Revenue Section
                    Text(text = "OPERATING INFLOWS (REVENUE)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    LedgerLineItem(label = "Student Tuition Fees", value = "+£${"%,.0f".format(monthlyTuitionRev)}")
                    LedgerLineItem(label = "Accommodation Rent Inflows", value = "+£${"%,.0f".format(monthlyAccommRev)}")
                    LedgerLineItem(label = "National Research Grants", value = "+£${"%,.0f".format(monthlyResearchGrants)}")
                    LedgerLineItem(label = "Commercial and Coffee Hub Royalties", value = "+£${"%,.0f".format(monthlyCommercialRev)}")
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Total Monthly Inflow", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Text(text = "£${"%,.0f".format(totalIncome)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace), color = Color(0xFF10B981))
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Outflow Section
                    Text(text = "OPERATING OUTFLOWS (EXPENSES)", style = MaterialTheme.typography.labelSmall, color = Color(0xFFEF4444))
                    LedgerLineItem(label = "Academic Staff Salaries", value = "-£${"%,.0f".format(monthlySalaries)}")
                    LedgerLineItem(label = "Physical Building Maintenance & Utilities", value = "-£${"%,.0f".format(monthlyBuildingMaint)}")
                    LedgerLineItem(label = "Administration and Library Services", value = "-£${"%,.0f".format(monthlyBaseCost)}")
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Total Monthly Outflow", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Text(text = "£${"%,.0f".format(totalExpense)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace), color = Color(0xFFEF4444))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Net Margin display
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (netBalance >= 0.0) Color(0xFF10B981).copy(alpha = 0.08f) else Color(0xFFEF4444).copy(alpha = 0.08f)
                        ),
                        border = BorderStroke(1.dp, if (netBalance >= 0.0) Color(0xFF10B981) else Color(0xFFEF4444))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(
                                    imageVector = if (netBalance >= 0.0) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                    contentDescription = null,
                                    tint = if (netBalance >= 0.0) Color(0xFF10B981) else Color(0xFFEF4444)
                                )
                                Text(
                                    text = "NET MONTHLY BALANCE",
                                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 16.sp),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = (if (netBalance >= 0) "+" else "") + "£${"%,.0f".format(netBalance)}",
                                style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace),
                                fontWeight = FontWeight.Bold,
                                color = if (netBalance >= 0) Color(0xFF10B981) else Color(0xFFEF4444)
                            )
                        }
                    }
                }
            }

            // Policy sliders
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Gavel, contentDescription = "Directives", tint = MaterialTheme.colorScheme.secondary)
                        Text(
                            text = "CHANCELLERY FISCAL DIRECTIVES",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.outline)

                    Text(
                        text = "National Tuition Cap: Set Student Annual Fee (£${feeInput.toInt()} / annum)",
                        style = MaterialTheme.typography.bodyLarge
                    )

                    Slider(
                        value = feeInput.toFloat(),
                        onValueChange = { feeInput = it.toDouble().coerceIn(6000.0, 12000.0) },
                        valueRange = 6000f..12000f,
                        steps = 6,
                        modifier = Modifier.testTag("policy_tuition_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Note: Lower tuition increases intake satisfaction and applicant quality. High tuition secures capital expansion at the cost of public satisfaction.",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        Button(
                            onClick = { onSetTuition(feeInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("save_tuition_policy_btn")
                        ) {
                            Text("SAVE DIRECTIVE", color = MaterialTheme.colorScheme.background)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LedgerLineItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace), fontWeight = FontWeight.SemiBold)
    }
}
