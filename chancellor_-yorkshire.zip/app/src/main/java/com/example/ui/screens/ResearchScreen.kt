package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AcademicEntity
import com.example.data.ProjectEntity
import com.example.data.TheoryEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResearchScreen(
    projects: List<ProjectEntity>,
    theories: List<TheoryEntity>,
    academics: List<AcademicEntity>,
    treasury: Double,
    onLaunchProject: (String, String, Int, Double) -> Unit
) {
    var activeTab by remember { mutableStateOf(0) } // 0: Projects, 1: Epistemology Landscape
    var showLaunchForm by remember { mutableStateOf(false) }

    // Launch form states
    var projectTitle by remember { mutableStateOf("Quantum Metallurgy Models") }
    var selectedDept by remember { mutableStateOf("Engineering") }
    var selectedAcademicId by remember { mutableStateOf<Int?>(null) }
    var fundingAmount by remember { mutableStateOf(150000.0) }

    val depts = listOf("Engineering", "Medicine", "Law", "Computer Science", "Philosophy", "Economics")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("research_screen_container")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "RESEARCH & EPISTEMOLOGY",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Commission projects and explore the evolving intellectual landscape",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TabButton(text = "Active Initiatives", selected = activeTab == 0, modifier = Modifier.weight(1f)) {
                    activeTab = 0
                }
                TabButton(text = "Intellectual Landscape", selected = activeTab == 1, modifier = Modifier.weight(1f)) {
                    activeTab = 1
                }
            }

            // Tab Content
            if (activeTab == 0) {
                // ACTIVE PROJECTS
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CURRENT RESEARCH PROJECTS",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )

                        if (!showLaunchForm) {
                            Button(
                                onClick = {
                                    showLaunchForm = true
                                    // Set default academic candidate if available
                                    if (academics.isNotEmpty()) {
                                        selectedAcademicId = academics.first().id
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier.testTag("show_launch_project_button")
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Add project")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("LAUNCH PROJECT")
                            }
                        }
                    }

                    if (showLaunchForm) {
                        // Project launch form
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(8.dp)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Commission New Research Initiative",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.secondary
                                )

                                OutlinedTextField(
                                    value = projectTitle,
                                    onValueChange = { projectTitle = it },
                                    label = { Text("Project Title") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("project_title_input")
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Department dropdown selection
                                    var deptExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.weight(1f)) {
                                        OutlinedButton(
                                            onClick = { deptExpanded = true },
                                            modifier = Modifier.fillMaxWidth().height(56.dp).testTag("dept_dropdown_btn")
                                        ) {
                                            Text("Dept: $selectedDept")
                                        }
                                        DropdownMenu(
                                            expanded = deptExpanded,
                                            onDismissRequest = { deptExpanded = false }
                                        ) {
                                            depts.forEach { d ->
                                                DropdownMenuItem(
                                                    text = { Text(d) },
                                                    onClick = {
                                                        selectedDept = d
                                                        deptExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Lead Academic dropdown selection
                                    var acadExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.weight(1f)) {
                                        val leadName = academics.firstOrNull { it.id == selectedAcademicId }?.name ?: "No Faculty"
                                        OutlinedButton(
                                            onClick = { acadExpanded = true },
                                            modifier = Modifier.fillMaxWidth().height(56.dp).testTag("acad_dropdown_btn")
                                        ) {
                                            Text(leadName)
                                        }
                                        DropdownMenu(
                                            expanded = acadExpanded,
                                            onDismissRequest = { acadExpanded = false }
                                        ) {
                                            academics.forEach { acad ->
                                                DropdownMenuItem(
                                                    text = { Text("${acad.name} (${acad.deptName})") },
                                                    onClick = {
                                                        selectedAcademicId = acad.id
                                                        acadExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                Text(
                                    text = "Allocated Grant Funding: £${"%,.0f".format(fundingAmount)}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Slider(
                                    value = fundingAmount.toFloat(),
                                    onValueChange = { fundingAmount = it.toDouble().coerceIn(50000.0, 400000.0) },
                                    valueRange = 50000f..400000f,
                                    steps = 7,
                                    modifier = Modifier.testTag("funding_slider")
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { showLaunchForm = false },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("CANCEL")
                                    }

                                    Button(
                                        onClick = {
                                            if (selectedAcademicId != null) {
                                                onLaunchProject(projectTitle, selectedDept, selectedAcademicId!!, fundingAmount)
                                                showLaunchForm = false
                                            }
                                        },
                                        modifier = Modifier.weight(1f).testTag("submit_project_button"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                        enabled = selectedAcademicId != null && treasury >= fundingAmount
                                    ) {
                                        Text("COMMISSION")
                                    }
                                }
                            }
                        }
                    }

                    // Projects list
                    val activeProjects = projects.filter { !it.isCompleted }
                    if (activeProjects.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(imageVector = Icons.Default.Biotech, contentDescription = "No Projects", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(48.dp))
                                Text(text = "No Active Research Projects", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "Commission a new initiative to begin publishing and developing patents.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 24.dp))
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).testTag("active_projects_list"),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(activeProjects) { proj ->
                                val lead = academics.firstOrNull { it.id == proj.leadAcademicId }?.name ?: "Professor"
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(text = proj.title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
                                                Text(text = "Field: ${proj.deptName} | Principal Investigator: $lead", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Text(
                                                text = "Grant: £${"%,.0f".format(proj.fundingAllocated)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.secondary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        LinearProgressIndicator(
                                            progress = (proj.progress / 100.0).toFloat(),
                                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                            color = MaterialTheme.colorScheme.secondary,
                                            trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                        )

                                        Text(
                                            text = "Simulation Progress: ${"%.1f".format(proj.progress)}%",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // EPISTEMOLOGY INTELLECTUAL LANDSCAPE
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "YORKSHIRE INTELLECTUAL DISCOVERIES",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (theories.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Landscape empty. Complete projects to trigger scientific breakthroughs.")
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).testTag("theories_list"),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(theories) { theory ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Hub,
                                                contentDescription = "Theory",
                                                tint = MaterialTheme.colorScheme.secondary,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }

                                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(text = theory.title, style = MaterialTheme.typography.titleLarge.copy(fontSize = 16.sp), color = MaterialTheme.colorScheme.onSurface)
                                                Text(
                                                    text = "Impact Score: ${theory.impactScore.toInt()}/100",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color(0xFFD4AF37),
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }

                                            Text(
                                                text = "Field: ${theory.field} | Discovered By: ${theory.discovererUniversity}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.primary
                                            )

                                            Text(
                                                text = "Established in the literature in Year ${theory.yearDiscovered}.",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TabButton(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
            .border(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
            .testTag("tab_${text.replace(" ", "_")}"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
    }
}
