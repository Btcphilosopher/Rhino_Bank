package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository
    init {
        val database = GameDatabase.getDatabase(application)
        repository = GameRepository(database.gameDao())
    }

    // UI state flows
    val gameState: StateFlow<GameStateEntity?> = repository.gameState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val universities: StateFlow<List<UniversityEntity>> = repository.universities.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val projects: StateFlow<List<ProjectEntity>> = repository.projects.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val theories: StateFlow<List<TheoryEntity>> = repository.theories.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val logs: StateFlow<List<LogEntity>> = repository.logs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Player specific reactive datasets (updated dynamically on player university id)
    private val _playerAcademics = MutableStateFlow<List<AcademicEntity>>(emptyList())
    val playerAcademics: StateFlow<List<AcademicEntity>> = _playerAcademics.asStateFlow()

    private val _playerStudents = MutableStateFlow<List<StudentEntity>>(emptyList())
    val playerStudents: StateFlow<List<StudentEntity>> = _playerStudents.asStateFlow()

    private val _playerBuildings = MutableStateFlow<List<BuildingEntity>>(emptyList())
    val playerBuildings: StateFlow<List<BuildingEntity>> = _playerBuildings.asStateFlow()

    // Simulation management state
    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private val _simSpeed = MutableStateFlow(1000L) // ms per month tick
    val simSpeed: StateFlow<Long> = _simSpeed.asStateFlow()

    // Current active random event
    private val _activeEvent = MutableStateFlow<SimulationEvent?>(null)
    val activeEvent: StateFlow<SimulationEvent?> = _activeEvent.asStateFlow()

    // Active academic competition (in progress)
    private val _activeCompetition = MutableStateFlow<AcademicCompetition?>(null)
    val activeCompetition: StateFlow<AcademicCompetition?> = _activeCompetition.asStateFlow()

    // Candidates for recruitment
    private val _recruitmentMarket = MutableStateFlow<List<AcademicEntity>>(emptyList())
    val recruitmentMarket: StateFlow<List<AcademicEntity>> = _recruitmentMarket.asStateFlow()

    private var simJob: Job? = null

    init {
        // Collect gameState to keep the player specific flows in sync
        viewModelScope.launch {
            gameState.collect { state ->
                state?.let {
                    loadPlayerSpecifics(it.selectedUniversityId)
                }
            }
        }
        generateRecruitmentMarket()
    }

    private suspend fun loadPlayerSpecifics(uniId: Int) {
        repository.getAcademics(uniId).collect {
            _playerAcademics.value = it
        }
    }

    init {
        viewModelScope.launch {
            gameState.collect { state ->
                state?.let {
                    repository.getActiveStudents(it.selectedUniversityId).collect { studs ->
                        _playerStudents.value = studs
                    }
                }
            }
        }
    }

    init {
        viewModelScope.launch {
            gameState.collect { state ->
                state?.let {
                    repository.getBuildings(it.selectedUniversityId).collect { blds ->
                        _playerBuildings.value = blds
                    }
                }
            }
        }
    }

    fun startNewGame(playerUniId: Int, chancellorName: String, initialTuition: Double) {
        viewModelScope.launch {
            repository.startNewGame(playerUniId, chancellorName, initialTuition)
            generateRecruitmentMarket()
        }
    }

    fun toggleSimulation() {
        if (_isSimulating.value) {
            _isSimulating.value = false
            simJob?.cancel()
        } else {
            _isSimulating.value = true
            startSimLoop()
        }
    }

    fun setSimSpeed(speedMs: Long) {
        _simSpeed.value = speedMs
        if (_isSimulating.value) {
            simJob?.cancel()
            startSimLoop()
        }
    }

    private fun startSimLoop() {
        simJob = viewModelScope.launch {
            while (_isSimulating.value) {
                delay(_simSpeed.value)
                // If there's an active decision, pause execution until solved
                if (_activeEvent.value == null && _activeCompetition.value == null) {
                    executeMonthTick()
                }
            }
        }
    }

    // Tick Logic
    private suspend fun executeMonthTick() {
        val state = repository.getGameStateDirect() ?: return
        if (state.gameOver) return

        var nextMonth = state.month + 1
        var nextYear = state.year
        if (nextMonth > 12) {
            nextMonth = 1
            nextYear += 1
        }

        val playerUniId = state.selectedUniversityId
        val unis = repository.getUniversitiesDirect()
        val playerUni = unis.first { it.id == playerUniId }

        // Load direct collections
        val playerBlds = repository.getBuildingsDirect(playerUniId)
        val playerAcads = repository.getAcademicsDirect(playerUniId)
        val playerStuds = repository.getStudentsDirect(playerUniId).filter { it.status == "Active" }
        val allProjects = repository.getProjectsDirect()

        // 1. FINANCIAL SIMULATION
        // Tuition per month: based on tuition fee & scaling factor
        val scaledStudentCount = playerStuds.size * 120 // 120 real students represented per mock student profile
        val monthlyTuitionRev = (state.tuitionFee * scaledStudentCount) / 12.0

        // Accommodation revenue if accommodation is built
        val accommodationsCount = playerBlds.count { it.type == "Accommodation" }
        val accommodationLevel = playerBlds.filter { it.type == "Accommodation" }.sumOf { it.level }
        val monthlyAccommRev = accommodationsCount * 30000.0 * accommodationLevel

        // Research Grants
        val researchLabs = playerBlds.count { it.type == "Lab" }
        val averageGrantWriting = if (playerAcads.isNotEmpty()) playerAcads.map { it.grantWriting }.average() else 40.0
        val monthlyResearchGrants = (researchLabs * 45000.0) + (averageGrantWriting * 800.0)

        // Commercial and Coffee House revenue
        val commercialCount = playerBlds.count { it.type == "CoffeeHouse" }
        val campusSatisfaction = playerUni.satisfactionRating
        val monthlyCommercialRev = commercialCount * 15000.0 * (1.0 + (campusSatisfaction / 100.0))

        // Total Income
        val totalIncome = monthlyTuitionRev + monthlyAccommRev + monthlyResearchGrants + monthlyCommercialRev

        // Expenses
        // Staff Salaries
        val monthlySalaries = playerAcads.sumOf { it.salary } / 12.0
        // Building Maintenance
        val monthlyBuildingMaint = playerBlds.sumOf { it.level * it.operatingCost } / 12.0
        // Base admin/utility cost
        val monthlyBaseCost = 50000.0

        val totalExpense = monthlySalaries + monthlyBuildingMaint + monthlyBaseCost
        val netBalance = totalIncome - totalExpense
        val nextTreasury = (state.treasury + netBalance).coerceAtLeast(0.0)

        // Check for Bankruptcy
        var isGameOver = false
        if (nextTreasury <= 0 && state.treasury <= 0) {
            isGameOver = true
            repository.insertLog(LogEntity(year = nextYear, month = nextMonth, message = "CRITICAL: The university treasury has run completely dry. Government regulators have stepped in. Game Over.", type = "Financial"))
        }

        // 2. TEACHING & STUDENT LIFE SIMULATION
        // Student wellbeing and stress adjust
        val hasSportsCentre = playerBlds.any { it.type == "SportsCentre" }
        val hasAccommodation = playerBlds.any { it.type == "Accommodation" }
        val averageTeaching = if (playerAcads.isNotEmpty()) playerAcads.map { it.teaching }.average() else 40.0

        val nextStudentsList = playerStuds.map { s ->
            var stressDelta = Random.nextDouble(-3.0, 5.0)
            if (averageTeaching < 50.0) stressDelta += 2.0 // Bad teaching stresses students
            if (hasSportsCentre) stressDelta -= 1.5
            if (hasAccommodation) stressDelta -= 1.0

            var wellbeingDelta = Random.nextDouble(-2.0, 4.0)
            if (hasSportsCentre) wellbeingDelta += 1.5
            if (hasAccommodation) wellbeingDelta += 1.0
            if (averageTeaching > 60.0) wellbeingDelta += 1.0

            s.copy(
                stress = (s.stress + stressDelta).coerceIn(0.0, 100.0),
                wellbeing = (s.wellbeing + wellbeingDelta).coerceIn(0.0, 100.0)
            )
        }
        repository.insertStudents(nextStudentsList)

        // 3. RESEARCH PROJECT TICK
        val updatedProjects = allProjects.map { proj ->
            if (proj.isCompleted) return@map proj

            val leadAcad = playerAcads.firstOrNull { it.id == proj.leadAcademicId }
            val leadSkill = leadAcad?.research ?: 45.0
            val labModifier = 1.0 + (playerBlds.count { it.type == "Lab" } * 0.15)
            val monthlyProgress = (leadSkill * 0.12 * labModifier * (proj.fundingAllocated / 100000.0)).coerceIn(1.0, 10.0)

            val nextProgress = proj.progress + monthlyProgress
            if (nextProgress >= 100.0) {
                // Completed project! Roll for result
                val roll = Random.nextDouble()
                val resultType = when {
                    roll < 0.15 -> "Failure"
                    roll < 0.65 -> "Paper" // Research Paper
                    roll < 0.85 -> "Patent" // Patented technology
                    else -> "SpinOut" // Business Spin-Out
                }

                // Apply prestige and cash rewards based on result
                var prestigeBonus = 0.0
                var treasuryBonus = 0.0
                val logMsg: String

                when (resultType) {
                    "Paper" -> {
                        prestigeBonus = Random.nextDouble(1.0, 3.0)
                        logMsg = "Research Success: ${leadAcad?.name} published a breakthrough paper titled '${proj.title}' in the Yorkshire Academic Journal! (+${"%.1f".format(prestigeBonus)} Prestige)"
                    }
                    "Patent" -> {
                        prestigeBonus = Random.nextDouble(2.0, 5.0)
                        treasuryBonus = Random.nextDouble(100000.0, 300000.0)
                        logMsg = "Research Patent: '${proj.title}' developed by ${leadAcad?.name} has been patent protected. Major industrial payout received! (+£${"%.0f".format(treasuryBonus)}, +${"%.1f".format(prestigeBonus)} Prestige)"
                    }
                    "SpinOut" -> {
                        prestigeBonus = Random.nextDouble(3.0, 8.0)
                        treasuryBonus = Random.nextDouble(250000.0, 600000.0)
                        logMsg = "Scientific Spin-Out: '${proj.title}' is spun out into a private tech enterprise in Sheffield. This will boost the Yorkshire economy! (+£${"%.0f".format(treasuryBonus)}, +${"%.1f".format(prestigeBonus)} Prestige)"
                    }
                    else -> {
                        logMsg = "Research Concluded: Project '${proj.title}' failed to produce significant peer-reviewed output. Staff morale impacted."
                        leadAcad?.let {
                            repository.updateAcademic(it.copy(morale = (it.morale - 15.0).coerceAtLeast(10.0)))
                        }
                    }
                }

                // Log breakthrough
                repository.insertLog(LogEntity(year = nextYear, month = nextMonth, message = logMsg, type = "Research"))

                // Epistemology Engine: Discover breakthrough theories dynamically!
                if (resultType != "Failure" && Random.nextDouble() < 0.35) {
                    val fields = listOf("Engineering", "Medicine", "Law", "Computer Science", "Philosophy", "Economics")
                    val academicNames = leadAcad?.name ?: "Yorkshire Scholars"
                    val theoryTitle = generateTheoryTitle(proj.deptName)
                    repository.insertTheory(
                        TheoryEntity(
                            title = theoryTitle,
                            field = proj.deptName,
                            discovererUniversity = playerUni.name,
                            impactScore = Random.nextDouble(30.0, 95.0),
                            yearDiscovered = nextYear
                        )
                    )
                    repository.insertLog(LogEntity(year = nextYear, month = nextMonth, message = "EPISTEMIC REVOLUTION: The discovery of '$theoryTitle' has reshaped the intellectual landscape of Yorkshire!", type = "Research"))
                }

                // Rewards applied to state variables (prestige, funds)
                viewModelScope.launch {
                    val currentGameState = repository.getGameStateDirect()
                    if (currentGameState != null) {
                        repository.updateGameState(currentGameState.copy(
                            prestige = (currentGameState.prestige + prestigeBonus).coerceAtMost(100.0),
                            treasury = currentGameState.treasury + treasuryBonus
                        ))
                    }
                }

                proj.copy(progress = 100.0, isCompleted = true, resultType = resultType)
            } else {
                proj.copy(progress = nextProgress)
            }
        }

        // Save updated projects
        updatedProjects.forEach { repository.updateProject(it) }

        // 4. REGIONAL DEVELOPMENT GROWTH
        val prestigeRatio = playerUni.prestige / 100.0
        val isLabsCount = playerBlds.count { it.type == "Lab" }
        val hasSciencePark = playerBlds.any { it.type == "SciencePark" }

        val productivityDelta = (prestigeRatio * 0.5) + (if (hasSciencePark) 0.6 else 0.0) + (isLabsCount * 0.1)
        val transportDelta = if (playerBlds.any { it.type == "SciencePark" }) 0.4 else 0.1
        val cultureDelta = (campusSatisfaction / 200.0) + (playerBlds.count { it.type == "CoffeeHouse" } * 0.2)
        val housingDelta = (accommodationsCount * 0.5) - 0.1 // housing demand from students vs local housing supply

        val nextProductivity = (state.regionalProductivity + productivityDelta).coerceIn(0.0, 100.0)
        val nextTransport = (state.regionalTransport + transportDelta).coerceIn(0.0, 100.0)
        val nextCulture = (state.regionalCulture + cultureDelta).coerceIn(0.0, 100.0)
        val nextHousing = (state.regionalHousing + housingDelta).coerceIn(0.0, 100.0)

        // 5. AI COMPETITORS TICK
        val nextUnis = unis.map { uni ->
            if (uni.isPlayer) {
                // Update player university stats dynamically in the competitor registry
                uni.copy(
                    prestige = state.prestige,
                    funds = nextTreasury,
                    researchRating = (playerAcads.map { it.research }.average().takeIf { !it.isNaN() } ?: 40.0),
                    teachingRating = averageTeaching,
                    satisfactionRating = (playerStuds.map { it.wellbeing }.average().takeIf { !it.isNaN() } ?: 50.0)
                )
            } else {
                // AI University progression logic
                val budget = uni.funds
                val isResearchFocus = uni.strategy == "Research"
                val isTeachingFocus = uni.strategy == "Teaching"
                val isExpansionFocus = uni.strategy == "Expansion"

                var aiPrestige = uni.prestige + Random.nextDouble(-0.5, 0.8)
                var aiFunds = uni.funds + Random.nextDouble(50000.0, 180000.0)
                var aiResearch = uni.researchRating + (if (isResearchFocus) Random.nextDouble(0.2, 0.6) else Random.nextDouble(-0.1, 0.3))
                var aiTeaching = uni.teachingRating + (if (isTeachingFocus) Random.nextDouble(0.2, 0.6) else Random.nextDouble(-0.1, 0.3))
                var aiSatisfaction = uni.satisfactionRating + Random.nextDouble(-0.4, 0.5)

                // Occasional AI breakthroughs
                if (Random.nextDouble() < 0.03) {
                    val discoveryField = listOf("Engineering", "Medicine", "Computer Science", "Economics").random()
                    val theoryName = generateTheoryTitle(discoveryField)
                    repository.insertTheory(
                        TheoryEntity(
                            title = theoryName,
                            field = discoveryField,
                            discovererUniversity = uni.name,
                            impactScore = Random.nextDouble(25.0, 80.0),
                            yearDiscovered = nextYear
                        )
                    )
                    repository.insertLog(LogEntity(year = nextYear, month = nextMonth, message = "COMPETITOR BREAKTHROUGH: ${uni.name} has discovered and published theory '$theoryName'!", type = "Research"))
                    aiPrestige += Random.nextDouble(2.0, 4.0)
                }

                uni.copy(
                    prestige = aiPrestige.coerceIn(1.0, 100.0),
                    funds = aiFunds,
                    researchRating = aiResearch.coerceIn(1.0, 100.0),
                    teachingRating = aiTeaching.coerceIn(1.0, 100.0),
                    satisfactionRating = aiSatisfaction.coerceIn(1.0, 100.0)
                )
            }
        }

        // Apply updated rankings in Month 12
        var rankedUnis = nextUnis
        if (nextMonth == 12) {
            rankedUnis = nextUnis.sortedByDescending {
                (it.researchRating * 0.35) + (it.teachingRating * 0.3) + (it.satisfactionRating * 0.2) + (it.prestige * 0.15)
            }.mapIndexed { index, uni ->
                uni.copy(rank = index + 1)
            }
            repository.insertLog(LogEntity(year = nextYear, month = nextMonth, message = "ANNUAL RANKINGS PUBLISHED: Check the regional leaderboard. Competition in Yorkshire remains fierce!", type = "Ranking"))
        }
        repository.updateUniversities(rankedUnis)

        // 6. ADMISSIONS & GRADUATIONS CYCLE
        // Admissions in Month 9 (September)
        if (nextMonth == 9) {
            // Player admits new students!
            val currentStudentsCount = playerStuds.size
            val admissionQuality = (playerUni.prestige * 0.5) + (playerUni.teachingRating * 0.3) - (state.tuitionFee / 400.0)
            val countToAdmit = (15 + (playerUni.prestige * 0.15) - (state.tuitionFee / 2000.0)).coerceIn(5.0, 30.0).toInt()

            val fNamesList = listOf("Liam", "Charlotte", "Oliver", "Emily", "Harry", "Amelia", "George", "Isla", "William", "Jessica", "Jack", "Olivia", "Freddie", "Poppy", "Thomas", "Grace")
            val lNamesList = listOf("Smith", "Jones", "Taylor", "Brown", "Wilson", "Walker", "Harrison", "Wood", "Peacock", "Brook", "Sykes", "Hirst")
            val deptsList = listOf("Engineering", "Medicine", "Law", "Computer Science", "Philosophy", "Economics")

            val admitted = mutableListOf<StudentEntity>()
            for (i in 1..countToAdmit) {
                admitted.add(
                    StudentEntity(
                        name = "${fNamesList.random()} ${lNamesList.random()}",
                        universityId = playerUniId,
                        deptName = deptsList.random(),
                        intelligence = (Random.nextDouble(45.0, 95.0) + (admissionQuality * 0.3)).coerceIn(20.0, 100.0),
                        curiosity = Random.nextDouble(40.0, 95.0),
                        motivation = Random.nextDouble(40.0, 95.0),
                        stress = Random.nextDouble(10.0, 30.0),
                        wellbeing = Random.nextDouble(60.0, 95.0),
                        status = "Active"
                    )
                )
            }
            repository.insertStudents(admitted)
            repository.insertLog(LogEntity(year = nextYear, month = nextMonth, message = "Admissions Office: A new cohort of $countToAdmit highly motivated students has matriculated at ${playerUni.name}.", type = "General"))
        }

        // Graduation in Month 6 (June)
        if (nextMonth == 6 && playerStuds.isNotEmpty()) {
            val graduatingPercent = 0.25 // roughly 25% of active students graduate
            val graduatingCount = (playerStuds.size * graduatingPercent).toInt().coerceAtLeast(1)
            val graduatingPool = playerStuds.shuffled().take(graduatingCount)

            val updatedGraduatingList = graduatingPool.map { s ->
                s.copy(status = "Graduated")
            }
            repository.insertStudents(updatedGraduatingList)
            
            // Earn some alumni donations from successful graduates
            val donationIncome = graduatingCount * Random.nextDouble(500.0, 3000.0) * (playerUni.satisfactionRating / 50.0)
            
            repository.insertLog(LogEntity(year = nextYear, month = nextMonth, message = "Graduation Ceremony: $graduatingCount students successfully graduated. Alumni donations received: +£" + "%.0f".format(donationIncome) + ".", type = "General"))
            
            viewModelScope.launch {
                val currentGameState = repository.getGameStateDirect()
                if (currentGameState != null) {
                    repository.updateGameState(currentGameState.copy(
                        treasury = currentGameState.treasury + donationIncome
                    ))
                }
            }
        }

        // 7. ANNUAL ACADEMIC COMPETITION CHECK (Months 5 and 11)
        if ((nextMonth == 5 || nextMonth == 11) && playerAcads.isNotEmpty()) {
            setupAcademicCompetition(nextYear, nextMonth)
        }

        // 8. RANDOM EMERGENCE EVENTS
        if (Random.nextDouble() < 0.18 && _activeEvent.value == null) {
            triggerRandomEvent(nextYear, nextMonth)
        }

        // 9. UPDATE MAIN GAME STATE
        val updatedState = state.copy(
            year = nextYear,
            month = nextMonth,
            treasury = nextTreasury,
            prestige = state.prestige.coerceIn(1.0, 100.0),
            regionalProductivity = nextProductivity,
            regionalTransport = nextTransport,
            regionalCulture = nextCulture,
            regionalHousing = nextHousing,
            gameOver = isGameOver
        )
        repository.updateGameState(updatedState)
    }

    private fun generateTheoryTitle(dept: String): String {
        val prefixes = listOf("Quantum", "Neoclassical", "Cognitive", "Computational", "Post-Modern", "Stochastic", "Socio-Ecological", "Bayesian", "Metamaterial", "Epistemic")
        val roots = mapOf(
            "Engineering" to listOf("Structural Origami", "Aerospace Topology", "Fluidics", "Nanometallurgy"),
            "Medicine" to listOf("Immunometabolism", "Oncogenetics", "Neuroplastic Synthesis", "Nano-pharmacology"),
            "Law" to listOf("Jurisprudential Cybernetics", "Resource Equity Code", "Common Wealth Precedent", "Sovereign IP"),
            "Computer Science" to listOf("Neural Hyper-networks", "Sub-Silicon Logic", "Turing Transcendence", "Holographic Cryptography"),
            "Philosophy" to listOf("Existential Pragmatics", "Ethics of Cognitive AI", "Aesthetic Relativism", "Phenomenology of Space"),
            "Economics" to listOf("Game Theory Equilibria", "Macro-currency Synthetics", "Behavioral Labor Dynamics", "Sparsity Modeling")
        )
        val rootsList = roots[dept] ?: listOf("Analysis Method")
        return "${prefixes.random()} ${rootsList.random()}"
    }

    // Dynamic Events Engine
    private fun triggerRandomEvent(year: Int, month: Int) {
        val eventList = listOf(
            SimulationEvent(
                title = "Yorkshire Torrential Floods",
                description = "Severe regional rainstorms have flooded the lower levels of your campus. Engineering labs are damp, and the student union building has water damage. How do you respond?",
                type = "Event",
                options = listOf(
                    EventOption(
                        text = "Hire local contractors for rapid drainage (£120,000)",
                        effect = {
                            viewModelScope.launch {
                                val state = repository.getGameStateDirect()
                                if (state != null) {
                                    repository.updateGameState(state.copy(treasury = (state.treasury - 120000.0).coerceAtLeast(0.0)))
                                    repository.insertLog(LogEntity(year = year, month = month, message = "Torrential Floods: Rapid response saved the labs, though treasury funds took a hit.", type = "Event"))
                                }
                            }
                        }
                    ),
                    EventOption(
                        text = "Rely on university volunteers & delay repairs",
                        effect = {
                            viewModelScope.launch {
                                val state = repository.getGameStateDirect()
                                val academicList = repository.getAllAcademicsDirect().filter { it.universityId == state?.selectedUniversityId }
                                academicList.forEach { repository.updateAcademic(it.copy(morale = (it.morale - 10.0).coerceAtLeast(5.0))) }
                                repository.insertLog(LogEntity(year = year, month = month, message = "Torrential Floods: Delays caused mould in offices. Academic morale has dropped.", type = "Event"))
                            }
                        }
                    )
                )
            ),
            SimulationEvent(
                title = "Major Tech Spin-Out Opportunity",
                description = "A venture capital firm from Leeds is offering to fund a student-led robotics startup. However, they want complete patent ownership and exclusive naming rights to the new campus innovation hub.",
                type = "Event",
                options = listOf(
                    EventOption(
                        text = "Accept terms and claim immediate cash (+£450,000, +5 Prestige)",
                        effect = {
                            viewModelScope.launch {
                                val state = repository.getGameStateDirect()
                                if (state != null) {
                                    repository.updateGameState(state.copy(
                                        treasury = state.treasury + 450000.0,
                                        prestige = (state.prestige + 5.0).coerceAtMost(100.0)
                                    ))
                                    repository.insertLog(LogEntity(year = year, month = month, message = "Tech Spin-Out: The partnership went ahead. Funds and regional reputation boosted.", type = "Event"))
                                }
                            }
                        }
                    ),
                    EventOption(
                        text = "Reject terms to maintain academic freedom (+8 Satisfaction)",
                        effect = {
                            viewModelScope.launch {
                                val state = repository.getGameStateDirect()
                                val unis = repository.getUniversitiesDirect()
                                if (state != null) {
                                    val playerUni = unis.first { it.id == state.selectedUniversityId }
                                    repository.updateUniversity(playerUni.copy(satisfactionRating = (playerUni.satisfactionRating + 8.0).coerceAtMost(100.0)))
                                    repository.insertLog(LogEntity(year = year, month = month, message = "Tech Spin-Out rejected: Academic integrity preserved, students praise the decision.", type = "Event"))
                                }
                            }
                        }
                    )
                )
            ),
            SimulationEvent(
                title = "Industrial Dispute over Pensions",
                description = "Academics across Yorkshire are threatening a series of strikes regarding pension changes. You can offer a local supplementary pension scheme or stand firm with national guidelines.",
                type = "Event",
                options = listOf(
                    EventOption(
                        text = "Implement supplementary pension scheme (£250,000, +20 Morale)",
                        effect = {
                            viewModelScope.launch {
                                val state = repository.getGameStateDirect()
                                val academicList = repository.getAllAcademicsDirect().filter { it.universityId == state?.selectedUniversityId }
                                if (state != null) {
                                    repository.updateGameState(state.copy(treasury = (state.treasury - 250000.0).coerceAtLeast(0.0)))
                                    academicList.forEach { repository.updateAcademic(it.copy(morale = (it.morale + 20.0).coerceAtMost(100.0))) }
                                    repository.insertLog(LogEntity(year = year, month = month, message = "Pension Dispute resolved: Local adjustments restored peace. Faculty morale is high.", type = "Event"))
                                }
                            }
                        }
                    ),
                    EventOption(
                        text = "Stand firm and face striking picket lines (-15 Satisfaction, -10 Prestige)",
                        effect = {
                            viewModelScope.launch {
                                val state = repository.getGameStateDirect()
                                val unis = repository.getUniversitiesDirect()
                                if (state != null) {
                                    val playerUni = unis.first { it.id == state.selectedUniversityId }
                                    repository.updateUniversity(playerUni.copy(
                                        satisfactionRating = (playerUni.satisfactionRating - 15.0).coerceAtLeast(5.0)
                                    ))
                                    repository.updateGameState(state.copy(prestige = (state.prestige - 10.0).coerceAtLeast(5.0)))
                                    repository.insertLog(LogEntity(year = year, month = month, message = "Pension Strike went ahead: Picket lines disrupted teaching. Campus satisfaction plummeted.", type = "Event"))
                                }
                            }
                        }
                    )
                )
            )
        )
        _activeEvent.value = eventList.random()
    }

    fun selectEventOption(option: EventOption) {
        option.effect()
        _activeEvent.value = null
    }

    // Academic Competitions Engine
    private fun setupAcademicCompetition(year: Int, month: Int) {
        val list = listOf(
            "Yorkshire Programming Cup" to "Computer Science",
            "Moot Court Debate" to "Law",
            "Advanced Engineering Challenge" to "Engineering",
            "Northern Business Pitch" to "Economics"
        )
        val selected = list.random()
        val title = selected.first
        val department = selected.second

        val candidateAcademics = _playerAcademics.value.filter { it.deptName == department }
        val leadName = candidateAcademics.maxByOrNull { it.leadership }?.name ?: "Senior Professor"

        _activeCompetition.value = AcademicCompetition(
            title = title,
            department = department,
            leadAcademic = leadName,
            year = year,
            month = month
        )
    }

    fun enterCompetition() {
        val comp = _activeCompetition.value ?: return
        viewModelScope.launch {
            val state = repository.getGameStateDirect() ?: return@launch
            val playerUni = repository.getUniversitiesDirect().first { it.id == state.selectedUniversityId }

            // Find competence based on university ratings
            val skill = when (comp.department) {
                "Computer Science" -> playerUni.researchRating * 1.2
                "Law" -> playerUni.teachingRating * 1.1
                "Engineering" -> playerUni.researchRating * 1.15
                "Economics" -> playerUni.teachingRating * 1.2
                else -> 50.0
            }

            // Roll results
            val roll = Random.nextDouble(10.0, 90.0) + (skill * 0.25)
            val isVictory = roll > 65.0

            if (isVictory) {
                val fundsPrize = 150000.0
                val prestigeGain = 6.0
                repository.updateGameState(state.copy(
                    treasury = state.treasury + fundsPrize,
                    prestige = (state.prestige + prestigeGain).coerceAtMost(100.0)
                ))
                repository.insertLog(LogEntity(year = comp.year, month = comp.month, message = "VICTORY: ${playerUni.name} won first place in the ${comp.title}! (+£${"%.0f".format(fundsPrize)}, +${"%.1f".format(prestigeGain)} Prestige)", type = "Competition"))
            } else {
                val prestigeLoss = 1.0
                repository.updateGameState(state.copy(
                    prestige = (state.prestige - prestigeLoss).coerceAtLeast(1.0)
                ))
                repository.insertLog(LogEntity(year = comp.year, month = comp.month, message = "COMPETITION OUTCOME: ${playerUni.name} finished in 4th place at the ${comp.title}. High competition from competitors.", type = "Competition"))
            }
            _activeCompetition.value = null
        }
    }

    fun skipCompetition() {
        _activeCompetition.value = null
    }

    // RECRUITMENT MARKET
    private fun generateRecruitmentMarket() {
        val depts = listOf("Engineering", "Medicine", "Law", "Computer Science", "Philosophy", "Economics")
        val specialties = mapOf(
            "Engineering" to listOf("Nanotechnology", "Fluid Mechanics", "Robotic Assembly", "Sustainable Infrastructure"),
            "Medicine" to listOf("Cardiology", "Genetic Editing", "Immunotherapy", "Viral Vector Tech"),
            "Law" to listOf("Constitutional Theory", "Corporate Law", "Digital Rights", "Maritime Jurisprudence"),
            "Computer Science" to listOf("Neural Engineering", "Cybersecurity", "Blockchain Systems", "Holographic UX"),
            "Philosophy" to listOf("Ethics of Automation", "Metaphysics of Space", "Social Existentialism", "Classical Epistemology"),
            "Economics" to listOf("Sparsity Analysis", "Venture Capital Dynamics", "Regional Macroeconomics", "Trade Policy")
        )

        val firstNames = listOf("Sarah", "James", "Fiona", "Arthur", "David", "Beatrix", "Oliver", "Claire", "Gareth", "Emily", "Alistair", "Nadia", "Geoffrey", "Rebecca")
        val lastNames = listOf("Cartwright", "Higgins", "Sterling", "Cook", "Featherstone", "Vance", "Ramsden", "Potter", "Peacock", "Brook", "Sykes", "Hirst")

        val list = mutableListOf<AcademicEntity>()
        for (i in 1..4) {
            val dName = depts.random()
            val specList = specialties[dName] ?: listOf("General Theory")
            list.add(
                AcademicEntity(
                    id = Random.nextInt(10000, 99999), // custom market identifier
                    name = "Prof. ${firstNames.random()} ${lastNames.random()}",
                    universityId = 0, // unassigned
                    deptName = dName,
                    research = Random.nextDouble(55.0, 92.0),
                    teaching = Random.nextDouble(50.0, 88.0),
                    leadership = Random.nextDouble(40.0, 85.0),
                    grantWriting = Random.nextDouble(45.0, 85.0),
                    morale = Random.nextDouble(75.0, 98.0),
                    salary = Random.nextDouble(65000.0, 115000.0),
                    specialty = specList.random()
                )
            )
        }
        _recruitmentMarket.value = list
    }

    fun hireAcademic(candidate: AcademicEntity) {
        viewModelScope.launch {
            val state = repository.getGameStateDirect() ?: return@launch
            val currentAcademicsCount = _playerAcademics.value.size
            if (state.treasury < candidate.salary) return@launch

            // Save academic with player university ID
            val hired = candidate.copy(id = 0, universityId = state.selectedUniversityId, morale = 90.0)
            repository.insertAcademic(hired)

            // Deduct salary from treasury and update state
            repository.updateGameState(state.copy(
                treasury = state.treasury - (candidate.salary * 0.1) // 10% immediate signing fee
            ))

            // Remove from recruitment pool and replace
            val updatedMarket = _recruitmentMarket.value.filter { it.id != candidate.id }
            _recruitmentMarket.value = updatedMarket
            repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Faculty Hiring: ${candidate.name} (${candidate.deptName}) has been hired as a Professor of ${candidate.specialty}!", type = "General"))
        }
    }

    fun fireAcademic(academic: AcademicEntity) {
        viewModelScope.launch {
            val state = repository.getGameStateDirect() ?: return@launch
            repository.deleteAcademic(academic.id)
            repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Faculty Termination: ${academic.name} has left the university. Departments reorganized.", type = "General"))
        }
    }

    // CAMPUS CONSTRUCTION
    fun buildStructure(type: String, x: Int, y: Int) {
        viewModelScope.launch {
            val state = repository.getGameStateDirect() ?: return@launch
            val cost = when (type) {
                "LectureHall" -> 250000.0
                "Library" -> 400000.0
                "Lab" -> 550000.0
                "Accommodation" -> 450000.0
                "SportsCentre" -> 350000.0
                "CoffeeHouse" -> 150000.0
                "SciencePark" -> 750000.0
                "InnovationCentre" -> 500000.0
                else -> 200000.0
            }

            if (state.treasury < cost) {
                repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Construction Failed: Insufficient funds to construct $type.", type = "Financial"))
                return@launch
            }

            // Create building
            val building = BuildingEntity(
                universityId = state.selectedUniversityId,
                type = type,
                level = 1,
                gridX = x,
                gridY = y,
                operatingCost = cost * 0.08, // 8% operating cost per month
                strategicValue = when (type) {
                    "Lab" -> 15.0
                    "Library" -> 12.0
                    "SciencePark" -> 25.0
                    else -> 10.0
                }
            )
            repository.insertBuilding(building)

            // Deduct funds
            repository.updateGameState(state.copy(
                treasury = state.treasury - cost
            ))

            repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Campus Expansion: Completed construction of a brand-new $type on campus grid ($x, $y).", type = "General"))
        }
    }

    fun upgradeStructure(building: BuildingEntity) {
        viewModelScope.launch {
            val state = repository.getGameStateDirect() ?: return@launch
            val upgradeCost = building.level * 180000.0

            if (state.treasury < upgradeCost) {
                repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Upgrade Failed: Insufficient funds to upgrade ${building.type}.", type = "Financial"))
                return@launch
            }

            // Update building level
            val nextLevel = building.level + 1
            val updated = building.copy(
                level = nextLevel,
                operatingCost = building.operatingCost * 1.3,
                strategicValue = building.strategicValue * 1.4
            )
            repository.updateBuilding(updated)

            // Deduct funds
            repository.updateGameState(state.copy(
                treasury = state.treasury - upgradeCost
            ))

            repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Campus Modernization: ${building.type} upgraded to Level $nextLevel (+ strategic benefits).", type = "General"))
        }
    }

    fun demolishStructure(building: BuildingEntity) {
        viewModelScope.launch {
            val state = repository.getGameStateDirect() ?: return@launch
            repository.deleteBuilding(building.id)
            repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Campus Reorganization: Demolished ${building.type} from grid (${building.gridX}, ${building.gridY}).", type = "General"))
        }
    }

    // RESEARCH PROJECTS
    fun launchResearchProject(title: String, dept: String, leadAcademicId: Int, funding: Double) {
        viewModelScope.launch {
            val state = repository.getGameStateDirect() ?: return@launch
            if (state.treasury < funding) return@launch

            val proj = ProjectEntity(
                title = title,
                deptName = dept,
                fundingAllocated = funding,
                progress = 0.0,
                leadAcademicId = leadAcademicId,
                isCompleted = false,
                resultType = "Pending"
            )
            repository.insertProject(proj)

            repository.updateGameState(state.copy(
                treasury = state.treasury - funding
            ))

            repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Research Initiative: Started project '$title' inside the department of $dept.", type = "Research"))
        }
    }

    fun setTuition(fee: Double) {
        viewModelScope.launch {
            val state = repository.getGameStateDirect() ?: return@launch
            repository.updateGameState(state.copy(tuitionFee = fee))
            repository.insertLog(LogEntity(year = state.year, month = state.month, message = "Policy Update: Academic board adjusted student tuition fee to £" + "%.0f".format(fee) + " per annum.", type = "Financial"))
        }
    }
}

// Data structures for UI events
data class SimulationEvent(
    val title: String,
    val description: String,
    val type: String,
    val options: List<EventOption>
)

data class EventOption(
    val text: String,
    val effect: () -> Unit
)

data class AcademicCompetition(
    val title: String,
    val department: String,
    val leadAcademic: String,
    val year: Int,
    val month: Int
)
