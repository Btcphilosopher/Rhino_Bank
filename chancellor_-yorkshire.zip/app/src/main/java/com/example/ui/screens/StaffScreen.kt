package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AcademicEntity

@Composable
fun StaffScreen(
    hiredAcademics: List<AcademicEntity>,
    recruitmentMarket: List<AcademicEntity>,
    treasury: Double,
    onHire: (AcademicEntity) -> Unit,
    onFire: (AcademicEntity) -> Unit
) {
    var viewMarket by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("staff_screen_container")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ACADEMIC FACULTY",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Manage university researchers, educators, and leaders",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TabButton(text = "Active Faculty", selected = !viewMarket, modifier = Modifier.weight(1f)) {
                    viewMarket = false
                }
                TabButton(text = "Yorkshire Talent Pool", selected = viewMarket, modifier = Modifier.weight(1f)) {
                    viewMarket = true
                }
            }

            if (!viewMarket) {
                // ACTIVE FACULTY
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CURRENT STAFF MEMBERS (${hiredAcademics.size})",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (hiredAcademics.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No staff currently hired. Visit the Yorkshire Talent Pool to recruit academics.")
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).testTag("active_staff_list"),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(hiredAcademics) { academic ->
                                AcademicCard(
                                    academic = academic,
                                    actionIcon = Icons.Default.Delete,
                                    actionLabel = "TERMINATE CONTRACT",
                                    actionColor = MaterialTheme.colorScheme.error,
                                    onActionClick = { onFire(academic) }
                                )
                            }
                        }
                    }
                }
            } else {
                // RECRUITMENT MARKET
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "AVAILABLE ACADEMICS FOR RECRUITMENT",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (recruitmentMarket.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Check back later. The academic job boards are currently empty.")
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).testTag("recruitment_market_list"),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(recruitmentMarket) { candidate ->
                                val canAfford = treasury >= candidate.salary
                                AcademicCard(
                                    academic = candidate,
                                    actionIcon = Icons.Default.PersonAdd,
                                    actionLabel = "HIRE PROFESSOR",
                                    actionColor = if (canAfford) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline,
                                    onActionClick = { onHire(candidate) },
                                    isRecruiting = true,
                                    canAfford = canAfford
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AcademicCard(
    academic: AcademicEntity,
    actionIcon: androidx.compose.ui.graphics.vector.ImageVector,
    actionLabel: String,
    actionColor: Color,
    onActionClick: () -> Unit,
    isRecruiting: Boolean = false,
    canAfford: Boolean = true
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("academic_card_${academic.name.replace(" ", "_")}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header / Name / Department
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = academic.name, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
                    Text(text = "Dept: ${academic.deptName} | Specialty: ${academic.specialty}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                }

                val moraleHigh = academic.morale > 60.0
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (moraleHigh) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFEF4444).copy(alpha = 0.15f)
                    ),
                    border = BorderStroke(1.dp, if (moraleHigh) Color(0xFF10B981).copy(alpha = 0.3f) else Color(0xFFEF4444).copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "Morale: ${academic.morale.toInt()}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        color = if (moraleHigh) Color(0xFF10B981) else Color(0xFFEF4444),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

            // Stats grid representation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatValueColumn(label = "Research", value = "${academic.research.toInt()}/100", color = Color(0xFF38BDF8))
                StatValueColumn(label = "Teaching", value = "${academic.teaching.toInt()}/100", color = Color(0xFF10B981))
                StatValueColumn(label = "Leadership", value = "${academic.leadership.toInt()}/100", color = Color(0xFFF59E0B))
                StatValueColumn(label = "Grant Writing", value = "${academic.grantWriting.toInt()}/100", color = Color(0xFFF59E0B))
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

            // Action row / Salary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "SALARY COST", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "£${"%,.0f".format(academic.salary)} / year",
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Button(
                    onClick = onActionClick,
                    colors = ButtonDefaults.buttonColors(containerColor = actionColor),
                    shape = RoundedCornerShape(8.dp),
                    enabled = !isRecruiting || canAfford,
                    modifier = Modifier.testTag("academic_action_button_${academic.name.replace(" ", "_")}")
                ) {
                    Icon(imageVector = actionIcon, contentDescription = actionLabel, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = actionLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.background)
                }
            }
        }
    }
}

@Composable
fun StatValueColumn(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(2.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(color.copy(alpha = 0.12f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}
