package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StudentEntity

@Composable
fun StudentLifeScreen(
    students: List<StudentEntity>
) {
    var searchQuery by remember { mutableStateOf("") }
    var deptFilter by remember { mutableStateOf("All") }

    val depts = listOf("All", "Engineering", "Medicine", "Law", "Computer Science", "Philosophy", "Economics")

    // Filter students based on search and selected department
    val filteredStudents = students.filter { s ->
        val matchesSearch = s.name.contains(searchQuery, ignoreCase = true)
        val matchesDept = deptFilter == "All" || s.deptName == deptFilter
        matchesSearch && matchesDept
    }

    // Calculate aggregated metrics
    val avgIntelligence = if (students.isNotEmpty()) students.map { it.intelligence }.average() else 50.0
    val avgWellbeing = if (students.isNotEmpty()) students.map { it.wellbeing }.average() else 50.0
    val avgStress = if (students.isNotEmpty()) students.map { it.stress }.average() else 30.0

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("student_life_screen_container")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "STUDENT LIFE & DIRECTORY",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Track simulated cohorts, student unions, and campus directories",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Summary metrics cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AggregatedMetricCard(
                    title = "Avg Intelligence",
                    value = "${avgIntelligence.toInt()}/100",
                    tint = Color(0xFF3D5A80),
                    modifier = Modifier.weight(1f)
                )
                AggregatedMetricCard(
                    title = "Campus Wellbeing",
                    value = "${avgWellbeing.toInt()}%",
                    tint = Color(0xFF2C6B4E),
                    modifier = Modifier.weight(1f)
                )
                AggregatedMetricCard(
                    title = "Avg Stress Level",
                    value = "${avgStress.toInt()}%",
                    tint = Color(0xFFD47A5F),
                    modifier = Modifier.weight(1f)
                )
            }

            // Filter row
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search Students...") },
                        leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .testTag("student_search_input"),
                        singleLine = true
                    )

                    // Department Filter dropdown selection
                    var filterExpanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(
                            onClick = { filterExpanded = true },
                            modifier = Modifier.height(56.dp).testTag("student_filter_dept_btn")
                        ) {
                            Icon(imageVector = Icons.Default.FilterList, contentDescription = "Filter")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Dept: $deptFilter")
                        }
                        DropdownMenu(
                            expanded = filterExpanded,
                            onDismissRequest = { filterExpanded = false }
                        ) {
                            depts.forEach { d ->
                                DropdownMenuItem(
                                    text = { Text(d) },
                                    onClick = {
                                        deptFilter = d
                                        filterExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Directory list
            Text(
                text = "STUDENT REGISTRY (${filteredStudents.size} active profiles displayed)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )

            if (filteredStudents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No student profiles match the filter criteria.",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).testTag("student_list"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredStudents) { student ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(20.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (student.wellbeing > 50.0) Icons.Default.Mood else Icons.Default.Warning,
                                        contentDescription = "Wellbeing indicator",
                                        tint = if (student.wellbeing > 50.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = student.name, style = MaterialTheme.typography.titleLarge.copy(fontSize = 16.sp), color = MaterialTheme.colorScheme.onSurface)
                                        Text(text = "Dept: ${student.deptName}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        StudentMetricItem(label = "Intelligence", value = "${student.intelligence.toInt()}")
                                        StudentMetricItem(label = "Curiosity", value = "${student.curiosity.toInt()}")
                                        StudentMetricItem(label = "Motivation", value = "${student.motivation.toInt()}")
                                        StudentMetricItem(label = "Stress", value = "${student.stress.toInt()}%")
                                        StudentMetricItem(label = "Wellbeing", value = "${student.wellbeing.toInt()}%")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AggregatedMetricCard(
    title: String,
    value: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(tint.copy(alpha = 0.12f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(text = value, style = MaterialTheme.typography.titleLarge, color = tint, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun StudentMetricItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.primary)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}
