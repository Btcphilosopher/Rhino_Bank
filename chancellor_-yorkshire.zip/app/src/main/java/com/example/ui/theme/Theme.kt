package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = ForestGreen,
    secondary = Copper,
    tertiary = SteelBlue,
    background = DeepObsidian,
    surface = StoneSlate,
    onPrimary = DeepObsidian,
    onSecondary = DeepObsidian,
    onTertiary = DeepObsidian,
    onBackground = TextCream,
    onSurface = TextCream,
    outline = BorderGreen
)

private val LightColorScheme = lightColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFFD97706), // Amber-600 for contrast
    secondary = androidx.compose.ui.graphics.Color(0xFF475569), // Slate-600
    tertiary = androidx.compose.ui.graphics.Color(0xFF059669), // Emerald-600
    background = androidx.compose.ui.graphics.Color(0xFFF8FAFC), // Slate-50
    surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF), // White
    onPrimary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    onSecondary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    onTertiary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    onBackground = androidx.compose.ui.graphics.Color(0xFF0F172A), // Slate-900
    onSurface = androidx.compose.ui.graphics.Color(0xFF0F172A), // Slate-900
    outline = androidx.compose.ui.graphics.Color(0xFFE2E8F0) // Slate-200 border
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // We enforce our custom Clean Minimalism palette rather than system dynamic colors
    // to preserve the signature aesthetic of slate, amber, and deep-navy minimal.
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
