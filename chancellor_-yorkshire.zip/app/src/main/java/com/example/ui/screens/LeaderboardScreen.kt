package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameStateEntity
import com.example.data.UniversityEntity

@Composable
fun LeaderboardScreen(
    gameState: GameStateEntity,
    universities: List<UniversityEntity>
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("leaderboard_screen_container")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "RANKINGS & REGIONAL IMPACT",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Compare chancellery performance and track local expansion indices",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Yorkshire Academic Board
            Text(
                text = "YORKSHIRE BOARD OF ACADEMIC PRESTIGE",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.3f)
                    .testTag("rankings_board_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Sort universities by prestige and stats to ensure rankings are visually accurate
                val sortedUnis = universities.sortedByDescending {
                    (it.researchRating * 0.35) + (it.teachingRating * 0.3) + (it.satisfactionRating * 0.2) + (it.prestige * 0.15)
                }

                itemsIndexed(sortedUnis) { index, uni ->
                    val rankNum = index + 1
                    val isPlayer = uni.isPlayer
                    val cardBorder = if (isPlayer) BorderStroke(1.5.dp, MaterialTheme.colorScheme.secondary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outline)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ranking_card_${uni.name.replace(" ", "_")}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isPlayer) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                        ),
                        border = cardBorder
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Rank Number badge
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(
                                        if (rankNum == 1) Color(0xFFF59E0B).copy(alpha = 0.15f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$rankNum",
                                    style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace),
                                    fontWeight = FontWeight.Bold,
                                    color = if (rankNum == 1) Color(0xFFF59E0B) else MaterialTheme.colorScheme.primary
                                )
                            }

                            // University name & location
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = uni.name,
                                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = if (isPlayer) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (isPlayer) {
                                        Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = "Active Player", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Text(
                                    text = "Focus: ${uni.strategy} | Location: ${uni.location}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            // Stats display
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                MiniStatItem(label = "Research", value = "${uni.researchRating.toInt()}")
                                MiniStatItem(label = "Teaching", value = "${uni.teachingRating.toInt()}")
                                MiniStatItem(label = "Satisfaction", value = "${uni.satisfactionRating.toInt()}")
                                MiniStatItem(label = "Prestige", value = "${uni.prestige.toInt()}")
                            }
                        }
                    }
                }
            }

            // Yorkshire Regional Impact Board
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Map, contentDescription = "Regional Map", tint = MaterialTheme.colorScheme.secondary)
                        Text(
                            text = "YORKSHIRE DEVELOPMENT INDEX",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Text(
                        text = "As Vice-Chancellor, your physical and academic expansions spill over to affect the economic, physical, and cultural vitality of Yorkshire.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )

                    Divider(color = MaterialTheme.colorScheme.outline)

                    // Impact Indices progress bars
                    ImpactIndexLine(label = "Local Business Productivity", value = gameState.regionalProductivity, color = Color(0xFF38BDF8))
                    ImpactIndexLine(label = "Regional Transport Quality", value = gameState.regionalTransport, color = Color(0xFF10B981))
                    ImpactIndexLine(label = "Local Innovation & Patents Index", value = gameState.regionalCulture, color = Color(0xFFF59E0B))
                    ImpactIndexLine(label = "Regional Affordable Housing Capacity", value = gameState.regionalHousing, color = Color(0xFFF59E0B))
                }
            }
        }
    }
}

@Composable
fun MiniStatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.primary)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ImpactIndexLine(label: String, value: Double, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(text = "${"%.1f".format(value)}/100", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace), color = color, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = (value / 100.0).toFloat(),
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )
    }
}
