package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Palette
val ForestGreen = Color(0xFFF59E0B)       // Primary (Amber highlight)
val Copper = Color(0xFFE2E8F0)            // Secondary (Slate Light)
val SteelBlue = Color(0xFF10B981)         // Tertiary (Emerald Success)
val DeepObsidian = Color(0xFF05080F)      // Dark Minimal Background
val NaturalStone = Color(0xFFE2E8F0)      // Slate-200 / Text on Dark / Light Background
val StoneSlate = Color(0xFF101826)        // Card background (Dark Slate Navy)
val SoftCream = Color(0xFFF8FAFC)         // Primary surface in Light Mode (Slate-50)
val Charcoal = Color(0xFF0F172A)          // Body text in Light Mode (Slate-900)
val TextCream = Color(0xFFCBD5E1)         // Body text in Dark Mode (Slate-300)
val AccentGold = Color(0xFFF59E0B)        // Prestige amber metric
val BorderGreen = Color(0x1AFFFFFF)       // White 10% opacity border
