package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_state")
data class GameStateEntity(
    @PrimaryKey val id: Int = 1,
    val year: Int = 1,
    val month: Int = 1, // 1 to 12
    val treasury: Double = 5000000.0,
    val prestige: Double = 30.0,
    val selectedUniversityId: Int = 1,
    val playerChancellorName: String = "Chancellor",
    val tuitionFee: Double = 9250.0,
    val researchFocusShare: Double = 0.4,
    val teachingFocusShare: Double = 0.3,
    val campusFocusShare: Double = 0.3,
    val regionalProductivity: Double = 40.0,
    val regionalTransport: Double = 35.0,
    val regionalCulture: Double = 50.0,
    val regionalHousing: Double = 45.0,
    val gameOver: Boolean = false
)

@Entity(tableName = "universities")
data class UniversityEntity(
    @PrimaryKey val id: Int,
    val name: String,
    val location: String,
    val isPlayer: Boolean,
    val prestige: Double,
    val funds: Double,
    val researchRating: Double,
    val teachingRating: Double,
    val satisfactionRating: Double,
    val strategy: String, // "Research", "Balanced", "Teaching", "Expansion"
    val rank: Int = 0
)

@Entity(tableName = "academics")
data class AcademicEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val universityId: Int,
    val deptName: String,
    val research: Double, // 1-100
    val teaching: Double, // 1-100
    val leadership: Double, // 1-100
    val grantWriting: Double, // 1-100
    val morale: Double, // 1-100
    val salary: Double,
    val specialty: String,
    val currentActivity: String = "Idle"
)

@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val universityId: Int,
    val deptName: String,
    val intelligence: Double, // 1-100
    val curiosity: Double, // 1-100
    val motivation: Double, // 1-100
    val stress: Double, // 0-100
    val wellbeing: Double, // 0-100
    val status: String = "Active" // "Active", "Graduated", "Dropped"
)

@Entity(tableName = "buildings")
data class BuildingEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val universityId: Int,
    val type: String, // "Library", "Lab", "LectureHall", "InnovationCentre", "Accommodation", "SportsCentre", "CoffeeHouse", "SciencePark"
    val level: Int = 1,
    val gridX: Int,
    val gridY: Int,
    val operatingCost: Double = 20000.0,
    val strategicValue: Double = 10.0
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val deptName: String,
    val fundingAllocated: Double = 100000.0,
    val progress: Double = 0.0, // 0 to 100
    val leadAcademicId: Int,
    val isCompleted: Boolean = false,
    val resultType: String = "Pending" // "Pending", "Paper", "Patent", "SpinOut", "Failure"
)

@Entity(tableName = "theories")
data class TheoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val field: String,
    val discovererUniversity: String,
    val impactScore: Double,
    val yearDiscovered: Int
)

@Entity(tableName = "history_logs")
data class LogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val year: Int,
    val month: Int,
    val message: String,
    val type: String // "General", "Research", "Event", "Ranking", "Financial"
)
