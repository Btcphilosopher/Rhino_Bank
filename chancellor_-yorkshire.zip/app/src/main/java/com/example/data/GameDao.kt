package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM game_state WHERE id = 1 LIMIT 1")
    fun getGameState(): Flow<GameStateEntity?>

    @Query("SELECT * FROM game_state WHERE id = 1 LIMIT 1")
    suspend fun getGameStateDirect(): GameStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGameState(gameState: GameStateEntity)

    @Query("SELECT * FROM universities ORDER BY prestige DESC")
    fun getUniversities(): Flow<List<UniversityEntity>>

    @Query("SELECT * FROM universities ORDER BY id ASC")
    suspend fun getUniversitiesDirect(): List<UniversityEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUniversities(universities: List<UniversityEntity>)

    @Update
    suspend fun updateUniversity(university: UniversityEntity)

    @Update
    suspend fun updateUniversities(universities: List<UniversityEntity>)

    @Query("SELECT * FROM academics WHERE universityId = :universityId")
    fun getAcademics(universityId: Int): Flow<List<AcademicEntity>>

    @Query("SELECT * FROM academics")
    suspend fun getAllAcademicsDirect(): List<AcademicEntity>

    @Query("SELECT * FROM academics WHERE universityId = :universityId")
    suspend fun getAcademicsDirect(universityId: Int): List<AcademicEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAcademics(academics: List<AcademicEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAcademic(academic: AcademicEntity)

    @Update
    suspend fun updateAcademic(academic: AcademicEntity)

    @Query("DELETE FROM academics WHERE id = :id")
    suspend fun deleteAcademic(id: Int)

    @Query("SELECT * FROM students WHERE universityId = :universityId AND status = 'Active'")
    fun getActiveStudents(universityId: Int): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE universityId = :universityId")
    suspend fun getStudentsDirect(universityId: Int): List<StudentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<StudentEntity>)

    @Update
    suspend fun updateStudents(students: List<StudentEntity>)

    @Query("SELECT * FROM buildings WHERE universityId = :universityId")
    fun getBuildings(universityId: Int): Flow<List<BuildingEntity>>

    @Query("SELECT * FROM buildings WHERE universityId = :universityId")
    suspend fun getBuildingsDirect(universityId: Int): List<BuildingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuilding(building: BuildingEntity)

    @Update
    suspend fun updateBuilding(building: BuildingEntity)

    @Query("DELETE FROM buildings WHERE id = :id")
    suspend fun deleteBuilding(id: Int)

    @Query("SELECT * FROM projects")
    fun getProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects")
    suspend fun getProjectsDirect(): List<ProjectEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity)

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: Int)

    @Query("SELECT * FROM theories ORDER BY yearDiscovered DESC, impactScore DESC")
    fun getTheories(): Flow<List<TheoryEntity>>

    @Query("SELECT * FROM theories")
    suspend fun getTheoriesDirect(): List<TheoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTheory(theory: TheoryEntity)

    @Query("SELECT * FROM history_logs ORDER BY id DESC LIMIT 100")
    fun getHistoryLogs(): Flow<List<LogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: LogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<LogEntity>)

    @Query("DELETE FROM history_logs")
    suspend fun clearLogs()

    @Transaction
    suspend fun clearAllData() {
        // Simple transaction to clear everything for a clean new game state
        // (will be run before initializing a new game)
    }
}
