package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlin.random.Random

class GameRepository(private val gameDao: GameDao) {

    val gameState: Flow<GameStateEntity?> = gameDao.getGameState()
    val universities: Flow<List<UniversityEntity>> = gameDao.getUniversities()
    val projects: Flow<List<ProjectEntity>> = gameDao.getProjects()
    val theories: Flow<List<TheoryEntity>> = gameDao.getTheories()
    val logs: Flow<List<LogEntity>> = gameDao.getHistoryLogs()

    fun getAcademics(universityId: Int): Flow<List<AcademicEntity>> = gameDao.getAcademics(universityId)
    fun getActiveStudents(universityId: Int): Flow<List<StudentEntity>> = gameDao.getActiveStudents(universityId)
    fun getBuildings(universityId: Int): Flow<List<BuildingEntity>> = gameDao.getBuildings(universityId)

    suspend fun updateGameState(state: GameStateEntity) = gameDao.insertGameState(state)
    suspend fun getGameStateDirect(): GameStateEntity? = gameDao.getGameStateDirect()
    suspend fun updateUniversity(uni: UniversityEntity) = gameDao.updateUniversity(uni)
    suspend fun updateUniversities(unis: List<UniversityEntity>) = gameDao.updateUniversities(unis)
    suspend fun getUniversitiesDirect(): List<UniversityEntity> = gameDao.getUniversitiesDirect()

    suspend fun getAcademicsDirect(uniId: Int): List<AcademicEntity> = gameDao.getAcademicsDirect(uniId)
    suspend fun getAllAcademicsDirect(): List<AcademicEntity> = gameDao.getAllAcademicsDirect()
    suspend fun insertAcademic(academic: AcademicEntity) = gameDao.insertAcademic(academic)
    suspend fun updateAcademic(academic: AcademicEntity) = gameDao.updateAcademic(academic)
    suspend fun deleteAcademic(id: Int) = gameDao.deleteAcademic(id)

    suspend fun getStudentsDirect(uniId: Int): List<StudentEntity> = gameDao.getStudentsDirect(uniId)
    suspend fun updateStudents(students: List<StudentEntity>) = gameDao.updateStudents(students)
    suspend fun insertStudents(students: List<StudentEntity>) = gameDao.insertStudents(students)

    suspend fun getBuildingsDirect(uniId: Int): List<BuildingEntity> = gameDao.getBuildingsDirect(uniId)
    suspend fun insertBuilding(building: BuildingEntity) = gameDao.insertBuilding(building)
    suspend fun updateBuilding(building: BuildingEntity) = gameDao.updateBuilding(building)
    suspend fun deleteBuilding(id: Int) = gameDao.deleteBuilding(id)

    suspend fun getProjectsDirect(): List<ProjectEntity> = gameDao.getProjectsDirect()
    suspend fun insertProject(project: ProjectEntity) = gameDao.insertProject(project)
    suspend fun updateProject(project: ProjectEntity) = gameDao.updateProject(project)
    suspend fun deleteProject(id: Int) = gameDao.deleteProject(id)

    suspend fun insertTheory(theory: TheoryEntity) = gameDao.insertTheory(theory)
    suspend fun insertLog(log: LogEntity) = gameDao.insertLog(log)
    suspend fun insertLogs(logs: List<LogEntity>) = gameDao.insertLogs(logs)
    suspend fun clearLogs() = gameDao.clearLogs()

    suspend fun startNewGame(
        playerUniId: Int,
        chancellorName: String,
        initialTuition: Double = 9250.0
    ) {
        // Reset and clear any existing save game tables
        // In our app, fallbackToDestructiveMigration handles clean recreation if database resets,
        // but let's delete manually or overwrite directly.
        
        // 1. Initialize Universities
        val baseUnis = listOf(
            UniversityEntity(
                id = 1,
                name = "University of York",
                location = "York",
                isPlayer = (playerUniId == 1),
                prestige = 55.0,
                funds = 4000000.0,
                researchRating = 60.0,
                teachingRating = 55.0,
                satisfactionRating = 58.0,
                strategy = "Research"
            ),
            UniversityEntity(
                id = 2,
                name = "University of Leeds",
                location = "Leeds",
                isPlayer = (playerUniId == 2),
                prestige = 52.0,
                funds = 6500000.0,
                researchRating = 48.0,
                teachingRating = 50.0,
                satisfactionRating = 52.0,
                strategy = "Balanced"
            ),
            UniversityEntity(
                id = 3,
                name = "University of Sheffield",
                location = "Sheffield",
                isPlayer = (playerUniId == 3),
                prestige = 50.0,
                funds = 5000000.0,
                researchRating = 54.0,
                teachingRating = 48.0,
                satisfactionRating = 49.0,
                strategy = "Research"
            ),
            UniversityEntity(
                id = 4,
                name = "Bradford University",
                location = "Bradford",
                isPlayer = (playerUniId == 4),
                prestige = 40.0,
                funds = 3000000.0,
                researchRating = 35.0,
                teachingRating = 62.0,
                satisfactionRating = 65.0,
                strategy = "Teaching"
            ),
            UniversityEntity(
                id = 5,
                name = "University of Hull",
                location = "Hull",
                isPlayer = (playerUniId == 5),
                prestige = 42.0,
                funds = 3500000.0,
                researchRating = 40.0,
                teachingRating = 45.0,
                satisfactionRating = 55.0,
                strategy = "Balanced"
            ),
            UniversityEntity(
                id = 6,
                name = "Huddersfield University",
                location = "Huddersfield",
                isPlayer = (playerUniId == 6),
                prestige = 38.0,
                funds = 2800000.0,
                researchRating = 30.0,
                teachingRating = 58.0,
                satisfactionRating = 60.0,
                strategy = "Expansion"
            )
        )
        gameDao.insertUniversities(baseUnis)

        // 2. Clear old projects, theories, buildings, logs
        gameDao.clearLogs()
        // Wait, GameDao.clearAllData doesn't delete them unless we implement it.
        // Let's implement full deletes or let the DB recreation take care of overwrite.
        // To be safe, we'll insert custom logs for starting the game.
        
        // Find starting funds for player
        val selectedUni = baseUnis.first { it.id == playerUniId }
        val playerFunds = selectedUni.funds
        val playerPrestige = selectedUni.prestige

        // 3. Set Game State
        val initialState = GameStateEntity(
            year = 1,
            month = 1,
            treasury = playerFunds,
            prestige = playerPrestige,
            selectedUniversityId = playerUniId,
            playerChancellorName = chancellorName,
            tuitionFee = initialTuition,
            regionalProductivity = 40.0,
            regionalTransport = 35.0,
            regionalCulture = 50.0,
            regionalHousing = 45.0,
            gameOver = false
        )
        gameDao.insertGameState(initialState)

        // 4. Generate starting Academics for all universities
        val startingAcademics = mutableListOf<AcademicEntity>()
        val depts = listOf("Engineering", "Medicine", "Law", "Computer Science", "Philosophy", "Economics")
        val specialties = mapOf(
            "Engineering" to listOf("Advanced Metallurgy", "Structural Dynamics", "Cybernetics", "Sustainable Architecture"),
            "Medicine" to listOf("Virology", "Neurology", "Cardiology", "Epidemiology"),
            "Law" to listOf("Jurisprudence", "Intellectual Property", "Environmental Law", "Human Rights"),
            "Computer Science" to listOf("Quantum Algorithms", "Distributed Neural Networks", "Cryptography", "Human-Computer Interaction"),
            "Philosophy" to listOf("Epistemology", "Ethics of AI", "Post-Modern Dialectics", "Existential Phenomenology"),
            "Economics" to listOf("Macroeconomic Policy", "Game Theory", "Behavioral Finance", "Development Economics")
        )

        val firstNames = listOf("Sarah", "James", "Fiona", "Arthur", "David", "Beatrix", "Oliver", "Claire", "Gareth", "Emily", "Alistair", "Nadia", "Geoffrey", "Rebecca")
        val lastNames = listOf("Cartwright", "Higgins", "Sterling", "Cook", "Featherstone", "Vance", "Ramsden", "Potter", "Peacock", "Brook", "Sykes", "Hirst", "Priestley", "Bronte")

        baseUnis.forEach { uni ->
            depts.forEach { dept ->
                val specList = specialties[dept] ?: listOf("General Studies")
                val isPlayerUni = uni.id == playerUniId
                // Generate 1-2 academics per department
                val count = if (isPlayerUni) 2 else 1
                for (i in 1..count) {
                    val fName = firstNames.random()
                    val lName = lastNames.random()
                    val research = Random.nextDouble(25.0, 75.0) + (if (uni.strategy == "Research") 10.0 else 0.0)
                    val teaching = Random.nextDouble(25.0, 75.0) + (if (uni.strategy == "Teaching") 10.0 else 0.0)
                    startingAcademics.add(
                        AcademicEntity(
                            name = "Dr. $fName $lName",
                            universityId = uni.id,
                            deptName = dept,
                            research = research.coerceIn(1.0, 100.0),
                            teaching = teaching.coerceIn(1.0, 100.0),
                            leadership = Random.nextDouble(20.0, 80.0),
                            grantWriting = Random.nextDouble(20.0, 80.0),
                            morale = Random.nextDouble(60.0, 95.0),
                            salary = Random.nextDouble(45000.0, 85000.0),
                            specialty = specList.random(),
                            currentActivity = "Idle"
                        )
                    )
                }
            }
        }
        gameDao.insertAcademics(startingAcademics)

        // 5. Generate starting Students
        val startingStudents = mutableListOf<StudentEntity>()
        val studFirstNames = listOf("Liam", "Charlotte", "Oliver", "Emily", "Harry", "Amelia", "George", "Isla", "William", "Jessica", "Jack", "Olivia", "Freddie", "Poppy", "Thomas", "Grace")
        val studLastNames = listOf("Smith", "Jones", "Taylor", "Brown", "Wilson", "Walker", "Harrison", "Wood", "Watson", "Wright", "Cooper", "Ward", "Turner", "Carter")

        baseUnis.forEach { uni ->
            // Generate some active students (let's simulate a representative pool of 20 detailed student profiles per university)
            for (i in 1..20) {
                val fName = studFirstNames.random()
                val lName = studLastNames.random()
                val dept = depts.random()
                startingStudents.add(
                    StudentEntity(
                        name = "$fName $lName",
                        universityId = uni.id,
                        deptName = dept,
                        intelligence = Random.nextDouble(40.0, 95.0),
                        curiosity = Random.nextDouble(40.0, 95.0),
                        motivation = Random.nextDouble(40.0, 95.0),
                        stress = Random.nextDouble(10.0, 50.0),
                        wellbeing = Random.nextDouble(50.0, 95.0),
                        status = "Active"
                    )
                )
            }
        }
        gameDao.insertStudents(startingStudents)

        // 6. Pre-build some starting Buildings for player university to give them a nice visual start
        val initialBuildings = listOf(
            BuildingEntity(universityId = playerUniId, type = "LectureHall", gridX = 2, gridY = 2, level = 1),
            BuildingEntity(universityId = playerUniId, type = "Library", gridX = 3, gridY = 2, level = 1),
            BuildingEntity(universityId = playerUniId, type = "CoffeeHouse", gridX = 2, gridY = 3, level = 1)
        )
        for (b in initialBuildings) {
            gameDao.insertBuilding(b)
        }

        // 7. Core theories already established in the world (starting intellectual landscape)
        val initialTheories = listOf(
            TheoryEntity(title = "Classical Jurisprudence", field = "Law", discovererUniversity = "University of York", impactScore = 45.0, yearDiscovered = -10),
            TheoryEntity(title = "Thermodynamic Kinetics", field = "Engineering", discovererUniversity = "University of Sheffield", impactScore = 50.0, yearDiscovered = -5),
            TheoryEntity(title = "Marginal Utility Optimization", field = "Economics", discovererUniversity = "University of Leeds", impactScore = 40.0, yearDiscovered = -8),
            TheoryEntity(title = "Basic Neural Topology", field = "Computer Science", discovererUniversity = "Bradford University", impactScore = 35.0, yearDiscovered = -2)
        )
        for (t in initialTheories) {
            gameDao.insertTheory(t)
        }

        // 8. Add starting logs
        val startingLogs = listOf(
            LogEntity(year = 1, month = 1, message = "Inauguration: $chancellorName has assumed office as Vice-Chancellor of the ${selectedUni.name}!", type = "General"),
            LogEntity(year = 1, month = 1, message = "Yorkshire Regional Academic Board welcomes the new administration. Strategic battle for academic rankings has begun.", type = "General"),
            LogEntity(year = 1, month = 1, message = "A new school year begins. Student tuition set at £" + "%.0f".format(initialTuition) + " per annum.", type = "Financial")
        )
        gameDao.insertLogs(startingLogs)
    }
}
