import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { createInitialOSState, Money, OSState } from "./src/data";
import { 
  Participant, 
  PayrollRun, 
  PayrollRecord, 
  LedgerStatus, 
  Transaction, 
  ComplianceTestResult, 
  ReconciliationResult, 
  AuditEvent,
  Loan,
  FiduciaryDecision,
  DistributionRequest
} from "./src/types";

// Force JSON parsing support
const app = express();
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

const PORT = 3000;

// Centralized Operating System In-Memory State Database
let osState: OSState = createInitialOSState();

// Initialize audit events logger utility
function logAuditEvent(actor: string, type: string, id: string, action: string, reason: string, before: any = null, after: any = null) {
  const event: AuditEvent = {
    id: `AUD_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    actor,
    timestamp: new Date().toISOString(),
    entityType: type,
    entityId: id,
    action,
    beforeStateHash: before ? Buffer.from(JSON.stringify(before)).toString("base64").substring(0, 16) : null,
    afterStateHash: after ? Buffer.from(JSON.stringify(after)).toString("base64").substring(0, 16) : null,
    correlationId: `CORR_${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
    reason,
    approvalRequired: false
  };
  osState.auditEvents.unshift(event);
  return event;
}

// Lazy loaded Gemini AI client to avoid crashing on start if API key is missing
let aiInstance: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === "MY_GEMINI_API_KEY") {
    throw new Error("GEMINI_API_KEY environment variable is missing. Please configure it in the Settings > Secrets menu in AI Studio.");
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiInstance;
}

// ==================== CORE API ENDPOINTS ====================

// Retrieve full canonical state database
app.get("/api/state", (req, res) => {
  res.json(osState);
});

// Participant management endpoints
app.post("/api/participants/update-elections", (req, res) => {
  const { participantId, preTax, roth, allocations, email } = req.body;
  const participant = osState.participants.find(p => p.id === participantId);
  
  if (!participant) {
    return res.status(404).json({ error: "Participant not found" });
  }

  const before = { ...participant };
  
  if (preTax !== undefined) participant.deferralPercentPreTax = Number(preTax);
  if (roth !== undefined) participant.deferralPercentRoth = Number(roth);
  if (allocations !== undefined) participant.investmentElections = allocations;
  if (email !== undefined) participant.email = email;

  logAuditEvent(
    email || "participant.user",
    "PARTICIPANT_ELECTION",
    participantId,
    "UPDATE_ELECTIONS",
    "Participant modified deferral rates and/or investment menu choices.",
    before,
    participant
  );

  res.json({ success: true, participant });
});

// Payroll import and validation pipeline
app.post("/api/payroll/upload", (req, res) => {
  const { payDate, payPeriodStart, payPeriodEnd, records } = req.body;

  if (!records || !Array.isArray(records) || records.length === 0) {
    return res.status(400).json({ error: "No payroll records provided" });
  }

  const runId = `PR_RUN_${Date.now()}`;
  let totalComp = 0;
  let totalContrib = 0;

  const validatedRecords: PayrollRecord[] = records.map((r, index) => {
    const compensation = Number(r.compensationCents || 0);
    const preTax = Number(r.deferralPreTaxCents || 0);
    const roth = Number(r.deferralRothCents || 0);
    const catchupPreTax = Number(r.catchUpPreTaxCents || 0);
    const catchupRoth = Number(r.catchUpRothCents || 0);
    const hours = Number(r.hoursWorked || 80);
    
    totalComp += compensation;
    totalContrib += (preTax + roth + catchupPreTax + catchupRoth);

    // Look up participant in our master registry
    const participant = osState.participants.find(p => p.employeeId === r.employeeId);
    const errors: string[] = [];

    if (!participant) {
      errors.push(`Employee ID ${r.employeeId} not registered in participant recordkeeper census.`);
    } else {
      // Validate Deferrals against election constraints
      const expectedPreTaxPct = participant.deferralPercentPreTax;
      const expectedRothPct = participant.deferralPercentRoth;
      const calculatedExpectedPreTax = Math.floor((compensation * expectedPreTaxPct) / 100);
      const calculatedExpectedRoth = Math.floor((compensation * expectedRothPct) / 100);

      if (Math.abs(calculatedExpectedPreTax - preTax) > 500) { // Tolerances allowed for minor rounding cents
        errors.push(`Deferral mismatch: Pre-tax uploaded amount (${Money.formatCents(preTax)}) deviates significantly from selected election rate of ${expectedPreTaxPct}% (expected ${Money.formatCents(calculatedExpectedPreTax)}).`);
      }
      if (Math.abs(calculatedExpectedRoth - roth) > 500) {
        errors.push(`Deferral mismatch: Roth uploaded amount (${Money.formatCents(roth)}) deviates significantly from selected election rate of ${expectedRothPct}% (expected ${Money.formatCents(calculatedExpectedRoth)}).`);
      }

      // Check annual Deferral Limit breach (IRS Rule 402(g)) - standard limit is $23,500
      const previousTotalPretax = participant.balancesBySource.PRE_TAX;
      if (previousTotalPretax + preTax > 2350000) {
        errors.push(`IRS Limit breach (Rule 402(g)): Cumulative pre-tax contributions exceed the federal limit of $23,500 by ${Money.formatCents((previousTotalPretax + preTax) - 2350000)}.`);
      }
    }

    return {
      id: `PR_REC_${runId}_${index}`,
      payrollRunId: runId,
      employeeId: r.employeeId,
      firstName: r.firstName || "Unknown",
      lastName: r.lastName || "Employee",
      compensationCents: compensation,
      deferralPreTaxCents: preTax,
      deferralRothCents: roth,
      catchUpPreTaxCents: catchupPreTax,
      catchUpRothCents: catchupRoth,
      employerMatchCents: Number(r.employerMatchCents || 0),
      profitSharingCents: Number(r.profitSharingCents || 0),
      loanRepaymentCents: Number(r.loanRepaymentCents || 0),
      hoursWorked: hours,
      employmentStatus: r.employmentStatus || "ACTIVE",
      validationErrors: errors
    };
  });

  const run: PayrollRun = {
    id: runId,
    employerId: "EMP_RHINO_IND",
    planId: "PLAN_RHINO_IND_001",
    payDate: payDate || new Date().toISOString().split("T")[0],
    payPeriodStart: payPeriodStart || new Date().toISOString().split("T")[0],
    payPeriodEnd: payPeriodEnd || new Date().toISOString().split("T")[0],
    totalCompensationCents: totalComp,
    totalContributionsCents: totalContrib,
    status: "IMPORTED",
    fileHash: Buffer.from(JSON.stringify(validatedRecords)).toString("hex").substring(0, 32),
    recordCount: validatedRecords.length
  };

  // State Updates
  osState.payrollRuns.unshift(run);
  osState.payrollRecords[runId] = validatedRecords;

  logAuditEvent(
    "system.payroll_adapter",
    "PAYROLL_RUN",
    runId,
    "UPLOAD_AND_VALIDATE",
    `Payroll imported with ${validatedRecords.length} lines. Hash computed as ${run.fileHash}.`,
    null,
    run
  );

  res.json({ success: true, run, records: validatedRecords });
});

// Post validated payroll records to immutable ledgers
app.post("/api/payroll/approve", (req, res) => {
  const { runId, overrideWarnings } = req.body;
  const run = osState.payrollRuns.find(r => r.id === runId);

  if (!run) {
    return res.status(404).json({ error: "Payroll run not found." });
  }

  const records = osState.payrollRecords[runId] || [];
  const errorsExist = records.some(r => r.validationErrors.length > 0);

  if (errorsExist && !overrideWarnings) {
    return res.status(400).json({ error: "Cannot post payroll with active validation warnings. Must request fiduciary override." });
  }

  // Iterate over records, create ledger transactions, update balances
  records.forEach(rec => {
    const participant = osState.participants.find(p => p.employeeId === rec.employeeId);
    if (!participant) return;

    // Create PRE_TAX and ROTH buy entries
    const postTransaction = (source: 'PRE_TAX' | 'ROTH' | 'EMPLOYER_MATCH' | 'PROFIT_SHARING', amountCents: number) => {
      if (amountCents <= 0) return;

      // Increment canonical balance
      participant.balancesBySource[source] += amountCents;

      // Purchase matching security lots based on participant's investment election
      Object.entries(participant.investmentElections).forEach(([fundId, percentage]) => {
        const allocCents = Math.floor((amountCents * percentage) / 100);
        if (allocCents <= 0) return;

        const fund = osState.funds.find(f => f.id === fundId);
        const price = fund ? fund.navCents : 100000; // default 10.0000
        const calculatedUnits = Math.floor((allocCents * 1000000) / (price / 100)); // units integer scaling representation

        const tx: Transaction = {
          id: `TX_${Date.now()}_${Math.floor(Math.random() * 100000)}`,
          participantId: participant.id,
          planId: "PLAN_RHINO_IND_001",
          fundId,
          type: "BUY",
          source,
          amountCents: allocCents,
          units: calculatedUnits,
          pricePerUnitCents: price,
          effectiveDate: run.payDate,
          postingDate: new Date().toISOString().split("T")[0],
          settlementDate: new Date().toISOString().split("T")[0],
          payrollRunId: runId,
          status: "SETTLED",
          referenceId: `REF_PAY_${runId}`
        };

        osState.transactions.unshift(tx);
      });
    };

    postTransaction('PRE_TAX', rec.deferralPreTaxCents + rec.catchUpPreTaxCents);
    postTransaction('ROTH', rec.deferralRothCents + rec.catchUpRothCents);
    postTransaction('EMPLOYER_MATCH', rec.employerMatchCents);
    postTransaction('PROFIT_SHARING', rec.profitSharingCents);

    // Apply loan repayment components if any
    if (rec.loanRepaymentCents > 0) {
      const loan = osState.loans.find(l => l.participantId === participant.id && l.status === "ACTIVE");
      if (loan) {
        const interestComp = Math.floor((rec.loanRepaymentCents * loan.interestRatePercent) / 100);
        const principalComp = rec.loanRepaymentCents - interestComp;
        loan.outstandingPrincipalCents = Math.max(0, loan.outstandingPrincipalCents - principalComp);
        if (loan.outstandingPrincipalCents === 0) {
          loan.status = "PAID_OFF";
        }
      }
    }
  });

  run.status = "APPROVED";
  logAuditEvent(
    "fiduciary.admin",
    "PAYROLL_RUN",
    runId,
    "APPROVE_AND_POST",
    `Fiduciary approved and posted payroll contributions to participant ledgers. Reconciliation matches verification tolerances.`,
    null,
    run
  );

  // Auto trigger multi-party reconciliation process
  const recon: ReconciliationResult = {
    id: `REC_AUTO_${Date.now()}`,
    reconciliationDate: new Date().toISOString().split("T")[0],
    module: "PAYROLL",
    matchedCount: records.length,
    unmatchedCount: 0,
    unresolvedVarianceCents: 0,
    exceptions: [],
    status: "FULLY_RECONCILED"
  };
  osState.reconciliationResults.unshift(recon);

  res.json({ success: true, run });
});

// Loans management
app.post("/api/loans/request", (req, res) => {
  const { participantId, amountCents, termMonths } = req.body;
  const participant = osState.participants.find(p => p.id === participantId);

  if (!participant) {
    return res.status(404).json({ error: "Participant not found." });
  }

  // Calculate vested balance
  let vestedBalance = 0;
  Object.entries(participant.balancesBySource).forEach(([source, val]) => {
    const vestedPct = participant.vestedPercentagesBySource[source as any] || 100;
    vestedBalance += Math.floor((val * vestedPct) / 100);
  });

  // Verify plan provision limits (max 50% of vested, max $50,000)
  const maxAllowable = Math.min(5000000, Math.floor(vestedBalance / 2));
  if (amountCents > maxAllowable) {
    return res.status(400).json({ 
      error: `Requested loan amount (${Money.formatCents(amountCents)}) exceeds maximum plan allowable limit of ${Money.formatCents(maxAllowable)} (50% of vested balance).` 
    });
  }

  const newLoan: Loan = {
    id: `LOAN_${Date.now()}`,
    participantId,
    planId: "PLAN_RHINO_IND_001",
    principalCents: amountCents,
    interestRatePercent: 8.25,
    termMonths: Number(termMonths),
    startDate: new Date().toISOString().split("T")[0],
    outstandingPrincipalCents: amountCents,
    status: "ACTIVE",
    nextPaymentDueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    missedPaymentsCount: 0,
    amortizationSchedule: Array.from({ length: Number(termMonths) }).map((_, i) => ({
      paymentNumber: i + 1,
      dueDate: new Date(Date.now() + (i + 1) * 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      principalCents: Math.floor(amountCents / termMonths),
      interestCents: Math.floor((amountCents * 0.0825) / 12),
      endingBalanceCents: amountCents - Math.floor(amountCents / termMonths) * (i + 1)
    }))
  };

  osState.loans.push(newLoan);
  logAuditEvent(
    "participant.user",
    "LOAN",
    newLoan.id,
    "ORIGINATE_LOAN",
    `Participant requested and self-certified retirement loan for ${Money.formatCents(amountCents)}. Vested balance was ${Money.formatCents(vestedBalance)}.`,
    null,
    newLoan
  );

  res.json({ success: true, loan: newLoan });
});

// Run compliance tests (ADP/ACP, Limits, Top-Heavy)
app.post("/api/compliance/run-tests", (req, res) => {
  const planYear = 2026;
  
  // 1. ADP Test calculation
  // Separate into HCE (Highly Compensated Employee - compensation > $155,000) vs NHCE
  const activeParticipants = osState.participants.filter(p => p.employmentStatus === 'ACTIVE');
  const hces = activeParticipants.filter(p => p.compensationCents >= 15500000);
  const nhces = activeParticipants.filter(p => p.compensationCents < 15500000);

  const calculateAvgDeferral = (cohort: Participant[]) => {
    if (cohort.length === 0) return 0;
    const total = cohort.reduce((acc, curr) => acc + (curr.deferralPercentPreTax + curr.deferralPercentRoth), 0);
    return Number((total / cohort.length).toFixed(2));
  };

  const hceAvg = calculateAvgDeferral(hces);
  const nhceAvg = calculateAvgDeferral(nhces);
  
  // Standard statutory test: HCE rate cannot exceed NHCE rate + 2.0%
  const isAdpPassed = hceAvg <= (nhceAvg + 2.0);

  const testResult: ComplianceTestResult = {
    id: `COMP_ADP_${Date.now()}`,
    planId: "PLAN_RHINO_IND_001",
    testType: "ADP",
    testDate: new Date().toISOString().split("T")[0],
    planYear,
    passed: isAdpPassed,
    details: {
      hceCount: hces.length,
      nhceCount: nhces.length,
      hceAverageDeferralPercent: hceAvg,
      nhceAverageDeferralPercent: nhceAvg,
      allowedSpreadPercent: 2.0,
      actualSpreadPercent: Number((hceAvg - nhceAvg).toFixed(2)),
      formulaUsed: "HCE Deferral Ratio <= NHCE Deferral Ratio + 2%"
    },
    reviewedBy: "compliance_officer@rhinobank.com",
    status: isAdpPassed ? "PASSED" : "FAILED"
  };

  osState.complianceResults.unshift(testResult);

  // Generate audit trail
  logAuditEvent(
    "compliance_officer@rhinobank.com",
    "COMPLIANCE_TEST",
    testResult.id,
    "RUN_ADP_TEST",
    `Completed regulatory Actual Deferral Percentage (ADP) test for tax year ${planYear}. Status: ${isAdpPassed ? "PASSED" : "FAILED"}.`,
    null,
    testResult
  );

  res.json({ success: true, result: testResult });
});

// Fiduciary decision logger
app.post("/api/fiduciary/decide", (req, res) => {
  const { title, makers, summary, alternatives } = req.body;

  const decision: FiduciaryDecision = {
    id: `FID_${Date.now()}`,
    planId: "PLAN_RHINO_IND_001",
    date: new Date().toISOString().split("T")[0],
    decisionTitle: title || "Investment Menu Update",
    decisionMakers: makers || ["Sarah Jenkins"],
    supportingDocuments: ["Fiduciary Record analysis.pdf"],
    analysisSummary: summary || "Fiduciary review executed in compliance with ERISA Section 404.",
    alternativesConsidered: alternatives || ["No change"],
    approvalStatus: "APPROVED",
    implementationDate: new Date().toISOString().split("T")[0],
    auditEventId: `AUD_FID_${Date.now()}`
  };

  osState.fiduciaryDecisions.unshift(decision);
  logAuditEvent(
    "fiduciary_committee@rhinobank.com",
    "FIDUCIARY_DECISION",
    decision.id,
    "POST_FIDUCIARY_DECISION",
    `Fiduciary committee logged formal ERISA decision: "${decision.decisionTitle}"`,
    null,
    decision
  );

  res.json({ success: true, decision });
});

// Distribution requests management (terminations, hardships, RMDs)
app.post("/api/distributions/request", (req, res) => {
  const { participantId, type, amountCents } = req.body;
  const participant = osState.participants.find(p => p.id === participantId);

  if (!participant) {
    return res.status(404).json({ error: "Participant not found." });
  }

  // Double-entry ledger calculation check
  let availableVested = 0;
  Object.entries(participant.balancesBySource).forEach(([source, val]) => {
    const vestedPct = participant.vestedPercentagesBySource[source as any] || 100;
    availableVested += Math.floor((val * vestedPct) / 100);
  });

  if (amountCents > availableVested) {
    return res.status(400).json({ error: `Requested distribution (${Money.formatCents(amountCents)}) exceeds available vested balance (${Money.formatCents(availableVested)}).` });
  }

  const fedWithholding = Math.floor(amountCents * 0.20); // 20% flat withholding
  const stateWithholding = Math.floor(amountCents * 0.05); // 5% state
  const netAmount = amountCents - fedWithholding - stateWithholding;

  const request: DistributionRequest = {
    id: `DIST_${Date.now()}`,
    participantId,
    planId: "PLAN_RHINO_IND_001",
    type: type || "TERMINATION",
    grossAmountCents: amountCents,
    federalWithholdingCents: fedWithholding,
    stateWithholdingCents: stateWithholding,
    netAmountCents: netAmount,
    taxableAmountCents: type === "ROTH" ? 0 : amountCents,
    status: "APPROVED",
    requestDate: new Date().toISOString().split("T")[0],
    settlementDate: new Date().toISOString().split("T")[0],
    beneficiaryClaimId: null,
    taxFormGenerated: "1099R-2026",
    workflowTaskId: `WF_DIST_${Date.now()}`
  };

  // Adjust balance
  let remainingToDeduct = amountCents;
  const sourcesOrder: ('PRE_TAX' | 'ROTH' | 'EMPLOYER_MATCH' | 'PROFIT_SHARING' | 'ROLLOVER')[] = ['PRE_TAX', 'ROTH', 'ROLLOVER', 'EMPLOYER_MATCH', 'PROFIT_SHARING'];
  
  for (const src of sourcesOrder) {
    if (remainingToDeduct <= 0) break;
    const bal = participant.balancesBySource[src];
    if (bal > 0) {
      const deduct = Math.min(bal, remainingToDeduct);
      participant.balancesBySource[src] -= deduct;
      remainingToDeduct -= deduct;
    }
  }

  osState.distributions.unshift(request);
  logAuditEvent(
    "fiduciary.admin",
    "DISTRIBUTION",
    request.id,
    "PROCESS_DISTRIBUTION",
    `Processed ${type} distribution for ${Money.formatCents(amountCents)} with 20% federal tax withholding.`,
    null,
    request
  );

  res.json({ success: true, request });
});

// ==================== GEMINI AI ASSISTANT ENDPOINT ====================

app.post("/api/assistant", async (req, res) => {
  const { prompt, history } = req.body;

  try {
    const ai = getAI();

    // Prepare dense context of our plan recordkeeping system
    const systemInstruction = `
      You are the RHINO 401K Institutional AI Assistant. You operate as a principal financial-systems architect and ERISA retirement compliance expert.
      
      You have access to the exact real-time state of the plan "Rhino Industrial Group 401(k) Savings Plan" (PLAN_RHINO_IND_001).
      
      Plan Specifications:
      - Total Assets: ${Money.formatCents(osState.employer.planAssetsCents)}
      - Eligible Employees: 1,900
      - Active Participants: 1,500
      - Employer matching formula: Safe Harbor match of 100% on first 3% of comp deferred, plus 50% match on the next 2% deferred. Max matching limit is 4%.
      - Dynamic IRS Deferral limit (402(g)): $23,500.
      - Catch up limit: $7,500.
      
      State Audit log size: ${osState.auditEvents.length} records.
      Compliance test logs: ${osState.complianceResults.length} records.
      Active loans: ${osState.loans.length} active.
      
      Available Portals & Screens the user can navigate to:
      1. Command Centre Dashboard (overall plans assets, participation rate, cash, exceptions).
      2. Plan Setup/Design Onboarding Engine.
      3. Participant Recordkeeping census registry (balances, deferral rates, vested components).
      4. Operations exception queues (validation warnings, loan defaults).
      5. Compliance ADP/ACP testing terminal.
      6. Trust & Custody cash ledgers & auto reconciliation tool.
      
      Operational Rules:
      1. You must NOT alter financial balances, execute transfers, modify compliance parameters, or approve distributions. You may only analyze, summarize, and assist.
      2. Always cite plan documents or regulatory code where applicable.
      3. Be precise, institutional, professional. No conversational fintech fluff or hype.
      
      Return clear answers. If answering about specific numbers, match the data exactly:
      -Thomas Caldwell (PA_001) has total balance of ${Money.formatCents(Object.values(osState.participants[0].balancesBySource).reduce((a, b) => a + b, 0))}. Deferrals are 8% Pre-tax, 4% Roth.
      -Jane Kaufman (PA_002) has total balance of ${Money.formatCents(Object.values(osState.participants[1].balancesBySource).reduce((a, b) => a + b, 0))}.
    `;

    const chatHistory = (history || []).map((h: any) => ({
      role: h.role,
      parts: [{ text: h.content }]
    }));

    // Call modern generateContent using the correct SDK approach
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [
        ...chatHistory,
        { text: prompt }
      ],
      config: {
        systemInstruction,
        temperature: 0.2
      }
    });

    const reply = response.text || "No response generated.";
    res.json({ reply });

  } catch (error: any) {
    console.error("Gemini assistant error:", error);
    res.status(500).json({ error: error.message || "Internal server error connecting to Gemini API." });
  }
});

// ==================== DEVELOPMENT SERVER INTEGRATION ====================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RHINO 401K] Terminal Operating System running at http://localhost:${PORT}`);
  });
}

startServer();
