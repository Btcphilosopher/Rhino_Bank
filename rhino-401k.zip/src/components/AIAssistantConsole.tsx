import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Sparkles, Loader2, ArrowRight } from 'lucide-react';

interface Message {
  role: 'user' | 'model';
  content: string;
}

export default function AIAssistantConsole() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      content: 'Greetings. I am the RHINO 401K Institutional Compliance & Recordkeeping Assistant, powered by Gemini. Ask me about participant balances, contribution formulas, IRS 402(g) limit audits, or ADP compliance metrics.'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = async (textToSend?: string) => {
    const prompt = textToSend || input;
    if (!prompt.trim()) return;

    const updatedMessages = [...messages, { role: 'user', content: prompt } as Message];
    setMessages(updatedMessages);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          history: updatedMessages.slice(0, -1) // Send conversation context history
        })
      });

      if (!res.ok) {
        throw new Error("Assistant response failure.");
      }

      const data = await res.json();
      setMessages(prev => [...prev, { role: 'model', content: data.reply }]);
    } catch (e: any) {
      setMessages(prev => [...prev, { role: 'model', content: `System Exception: ${e.message}. Please verify your GEMINI_API_KEY settings.` }]);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    "How is the Safe Harbor match calculated under this plan design?",
    "Show Thomas Caldwell's contribution rate and subaccount totals.",
    "Verify if our current ADP test outcomes satisfy statutory ERISA limits."
  ];

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-sm overflow-hidden flex flex-col h-[550px]" id="rhino-ai-assistant-root">
      {/* Console Header */}
      <div className="bg-zinc-900 border-b border-zinc-800 p-4 flex items-center justify-between font-mono">
        <div className="flex items-center gap-2">
          <Bot size={16} className="text-amber-500 animate-pulse" />
          <span className="text-xs font-bold text-zinc-200">GEMINI RETIREMENT SYSTEMS CORE</span>
        </div>
        <span className="text-[10px] bg-amber-500/10 text-amber-500 px-2 py-0.5 rounded-sm font-bold flex items-center gap-1">
          <Sparkles size={10} /> DYNAMIC COMPLIANCE ENGINE
        </span>
      </div>

      {/* Messages Log */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-xs">
        {messages.map((m, idx) => (
          <div key={idx} className={`flex gap-3 max-w-[85%] ${m.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}>
            <div className={`p-3 rounded-sm leading-relaxed ${
              m.role === 'user' 
                ? 'bg-amber-500/10 border border-amber-500/20 text-zinc-100' 
                : 'bg-zinc-900/60 border border-zinc-900 text-zinc-300'
            }`}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-2 items-center text-zinc-500 italic">
            <Loader2 size={12} className="animate-spin text-amber-500" />
            <span>Consulting recordkeeper ledgers...</span>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Pre-canned Suggestions */}
      <div className="px-4 py-2 bg-zinc-900/25 border-t border-zinc-900 flex flex-wrap gap-2 font-mono text-[10px]">
        {samplePrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(p)}
            className="bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-750 px-2.5 py-1 rounded-sm"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Inputs */}
      <div className="p-3 bg-zinc-900 border-t border-zinc-800 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask about compliance formulas, vesting limits, participant lot reconciliations..."
          className="flex-1 bg-zinc-950 border border-zinc-800 rounded-sm py-2 px-3 text-xs font-mono text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-amber-500/50"
        />
        <button
          onClick={() => handleSend()}
          className="bg-amber-500 hover:bg-amber-600 text-zinc-950 p-2 rounded-sm"
        >
          <Send size={14} />
        </button>
      </div>
    </div>
  );
}
