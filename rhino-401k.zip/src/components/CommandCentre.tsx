import React, { useState } from 'react';
import { 
  TrendingUp, 
  Users, 
  Layers, 
  Activity, 
  ShieldAlert, 
  CheckCircle2, 
  Briefcase, 
  DollarSign, 
  Calendar, 
  HelpCircle 
} from 'lucide-react';
import { OSState, Money } from '../data';

interface CommandCentreProps {
  state: OSState;
}

type Timeframe = 'TODAY' | 'MONTH' | 'QUARTER' | 'YEAR' | 'PLAN_YEAR' | 'HISTORICAL';

export default function CommandCentre({ state }: CommandCentreProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>('PLAN_YEAR');

  const activeParticipants = state.participants.filter(p => p.employmentStatus === 'ACTIVE');
  const totalEmployees = state.employer.employeeCount;
  const eligibleCount = 1900; // Demanded synthetic statistic
  const activeCount = 1500; // Demanded synthetic statistic
  const participationRate = ((activeCount / eligibleCount) * 100).toFixed(1);
  
  // Calculate average deferral rate
  const avgDeferral = (activeParticipants.reduce((acc, curr) => 
    acc + curr.deferralPercentPreTax + curr.deferralPercentRoth, 0) / activeParticipants.length).toFixed(2);

  // Vested liabilities vs outstanding loans
  const totalVestedCents = state.participants.reduce((acc, curr) => {
    let vested = 0;
    Object.entries(curr.balancesBySource).forEach(([src, val]) => {
      const pct = curr.vestedPercentagesBySource[src as any] || 100;
      vested += Math.floor((val * pct) / 100);
    });
    return acc + vested;
  }, 0);

  const totalBalanceCents = state.participants.reduce((acc, curr) => 
    acc + Object.values(curr.balancesBySource).reduce((sum, val) => sum + val, 0), 0);

  const avgBalance = (totalBalanceCents / state.participants.length);
  const totalOutstandingLoanCents = state.loans.reduce((acc, curr) => 
    curr.status === 'ACTIVE' ? acc + curr.outstandingPrincipalCents : acc, 0);

  const totalDistributionsCents = state.distributions.reduce((acc, curr) => acc + curr.grossAmountCents, 0);

  // Timeframe modifiers to mock real transaction trends
  const getModifier = () => {
    switch(timeframe) {
      case 'TODAY': return 0.0001;
      case 'MONTH': return 0.024;
      case 'QUARTER': return 0.068;
      case 'YEAR': return 0.18;
      case 'HISTORICAL': return 1.0;
      default: return 0.85;
    }
  };

  const modifier = getModifier();
  const displayAssets = state.employer.planAssetsCents * modifier;
  const displayEmployerContrib = Math.floor(totalBalanceCents * 0.4 * modifier);
  const displayEmployeeContrib = Math.floor(totalBalanceCents * 0.6 * modifier);

  return (
    <div className="space-y-6" id="rhino-command-centre-root">
      {/* Timeframe Selector Terminal Bar */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
        <div>
          <h2 className="text-xl font-mono font-bold tracking-tight text-zinc-100">PLAN COMMAND CENTRE</h2>
          <p className="text-xs text-zinc-400 font-mono">Institutional Plan ID: {state.plans[0].planName} ({state.plans[0].planNumber})</p>
        </div>
        
        <div className="flex bg-zinc-900 border border-zinc-800 p-0.5 rounded-md font-mono text-xs">
          {(['TODAY', 'MONTH', 'QUARTER', 'YEAR', 'PLAN_YEAR', 'HISTORICAL'] as Timeframe[]).map((t) => (
            <button
              key={t}
              onClick={() => setTimeframe(t)}
              className={`px-3 py-1.5 font-bold rounded-sm transition-colors ${
                timeframe === t 
                  ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' 
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {t.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Hero Financial Terminal Panels */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm relative overflow-hidden">
          <div className="absolute right-3 top-3 opacity-10">
            <TrendingUp size={48} className="text-amber-500" />
          </div>
          <span className="text-[10px] text-zinc-400 font-mono tracking-wider block uppercase">TOTAL PLAN ASSETS</span>
          <span className="text-2xl font-mono font-bold text-amber-500 tracking-tight block mt-1">
            {Money.formatCents(displayAssets)}
          </span>
          <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-zinc-400 border-t border-zinc-900 pt-2">
            <span>Treasury Cash:</span>
            <span className="text-zinc-200 font-bold">{Money.formatCents(state.custodyAccounts[0].balanceCents)}</span>
          </div>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm relative overflow-hidden">
          <div className="absolute right-3 top-3 opacity-10">
            <Users size={48} className="text-zinc-300" />
          </div>
          <span className="text-[10px] text-zinc-400 font-mono tracking-wider block uppercase">PARTICIPATION METRICS</span>
          <span className="text-2xl font-mono font-bold text-zinc-100 tracking-tight block mt-1">
            {participationRate}%
          </span>
          <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-zinc-400 border-t border-zinc-900 pt-2">
            <span>Active/Eligible:</span>
            <span className="text-zinc-200 font-bold">{activeCount} / {eligibleCount}</span>
          </div>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm relative overflow-hidden">
          <div className="absolute right-3 top-3 opacity-10">
            <Activity size={48} className="text-zinc-300" />
          </div>
          <span className="text-[10px] text-zinc-400 font-mono tracking-wider block uppercase">AVG DEFERRAL RATE</span>
          <span className="text-2xl font-mono font-bold text-zinc-100 tracking-tight block mt-1">
            {avgDeferral}%
          </span>
          <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-zinc-400 border-t border-zinc-900 pt-2">
            <span>Average Balance:</span>
            <span className="text-zinc-200 font-bold">{Money.formatCents(avgBalance)}</span>
          </div>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm relative overflow-hidden">
          <div className="absolute right-3 top-3 opacity-10">
            <ShieldAlert size={48} className="text-green-500" />
          </div>
          <span className="text-[10px] text-zinc-400 font-mono tracking-wider block uppercase">COMPLIANCE TEST STATUS</span>
          <span className="text-lg font-mono font-bold text-emerald-500 tracking-tight flex items-center gap-1.5 mt-1.5">
            <CheckCircle2 size={16} /> PASSING (ADP/ACP)
          </span>
          <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-zinc-400 border-t border-zinc-900 pt-2">
            <span>Last Audit:</span>
            <span className="text-zinc-200 font-bold">2026-09-11 Passed</span>
          </div>
        </div>
      </div>

      {/* Secondary Dashboard Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core Contribution & Matching Ledger Status */}
        <div className="lg:col-span-2 bg-zinc-950 border border-zinc-800 p-5 rounded-sm">
          <div className="flex items-center justify-between border-b border-zinc-900 pb-3 mb-4">
            <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">CONTRIBUTION LEDGER</h3>
            <span className="text-[10px] bg-zinc-900 text-zinc-400 font-mono px-2 py-0.5 rounded-sm">RECONCILED</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-zinc-400">Employee Deferrals (Pre-Tax)</span>
                <span className="text-zinc-200 font-bold">{Money.formatCents(displayEmployeeContrib)}</span>
              </div>
              <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full" style={{ width: '60%' }}></div>
              </div>

              <div className="flex justify-between text-xs font-mono pt-2">
                <span className="text-zinc-400">Employer Matching Contribution</span>
                <span className="text-zinc-200 font-bold">{Money.formatCents(displayEmployerContrib)}</span>
              </div>
              <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden">
                <div className="bg-zinc-400 h-full" style={{ width: '40%' }}></div>
              </div>

              <div className="flex justify-between text-xs font-mono pt-2">
                <span className="text-zinc-400">Vesting Liability</span>
                <span className="text-zinc-300">{Money.formatCents(totalVestedCents)}</span>
              </div>
              <div className="text-[10px] font-mono text-zinc-500 italic mt-1">
                Employer matches are 100% immediately vested per Safe Harbor provisions.
              </div>
            </div>

            <div className="space-y-4 border-l border-zinc-900 pl-6">
              <h4 className="text-[10px] font-mono font-bold text-zinc-400 tracking-wider uppercase">VALUATION SUMMARY SNAPSHOT</h4>
              <div className="space-y-2.5 font-mono text-xs">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Participant Accounts:</span>
                  <span className="text-zinc-300 font-bold">{state.participants.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Outstanding Loans:</span>
                  <span className="text-zinc-300 font-bold">{Money.formatCents(totalOutstandingLoanCents)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Distribution Volume:</span>
                  <span className="text-zinc-300 font-bold">{Money.formatCents(totalDistributionsCents)}</span>
                </div>
                <div className="flex justify-between border-t border-zinc-900 pt-2 font-bold text-zinc-200">
                  <span>Reconciled Trust Assets:</span>
                  <span>{Money.formatCents(displayAssets + totalOutstandingLoanCents)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Plan Operational Status Alerts */}
        <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-sm">
          <div className="flex items-center justify-between border-b border-zinc-900 pb-3 mb-4">
            <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">OPERATIONAL QUEUES</h3>
            <span className="text-[10px] bg-amber-500/10 text-amber-500 font-mono px-2 py-0.5 rounded-sm">1 EXCEPTION</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-sm">
              <div className="flex items-center justify-between">
                <span className="text-amber-500 font-bold text-[10px] tracking-wider uppercase block">PAYROLL CONTEXT WARNING</span>
                <span className="text-[9px] text-zinc-400">UNRESOLVED</span>
              </div>
              <p className="text-zinc-300 text-[11px] mt-1">Pending payroll run cycle ended 2026-09-11 has unresolved deferral rate changes mismatch.</p>
            </div>

            <div className="space-y-2 mt-4 pt-2 border-t border-zinc-900">
              <div className="flex justify-between text-xs text-zinc-400">
                <span>RMD Compliance Trigger:</span>
                <span className="text-zinc-300 font-bold">0 Pending</span>
              </div>
              <div className="flex justify-between text-xs text-zinc-400">
                <span>Data Quality Score:</span>
                <span className="text-emerald-500 font-bold">99.8% Perfect</span>
              </div>
              <div className="flex justify-between text-xs text-zinc-400">
                <span>Custodian Position Sync:</span>
                <span className="text-zinc-300 font-bold">Reconciled</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Asset Allocation Breakdown per Security Lot */}
      <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-sm">
        <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase mb-4">PLAN INVESTMENT MENU & ALLOCATIONS</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {state.funds.map((fund) => {
            const isHigh = fund.riskCategory === 'HIGH';
            const isLow = fund.riskCategory === 'LOW';
            
            return (
              <div key={fund.id} className="p-3 bg-zinc-900/40 border border-zinc-800/60 rounded-sm">
                <div className="flex items-center justify-between">
                  <span className="font-bold font-mono text-zinc-200 text-sm">{fund.ticker}</span>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-sm ${
                    isHigh ? 'bg-red-500/10 text-red-400' : isLow ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'
                  }`}>
                    {fund.assetClass}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1 truncate">{fund.name}</p>
                <div className="mt-3 pt-2 border-t border-zinc-900 flex justify-between text-xs font-mono">
                  <span className="text-zinc-500">NAV Price:</span>
                  <span className="text-zinc-300 font-bold">{Money.formatNav(fund.navCents)}</span>
                </div>
                <div className="flex justify-between text-xs font-mono mt-1">
                  <span className="text-zinc-500">Expense Ratio:</span>
                  <span className="text-zinc-300">{fund.expenseRatio}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
