import React, { useState } from 'react';
import { 
  ShieldCheck, 
  HelpCircle, 
  Settings, 
  Plus, 
  Activity, 
  CheckCircle2, 
  XCircle, 
  FileLock 
} from 'lucide-react';
import { OSState, Money } from '../data';
import { ComplianceTestResult } from '../types';

interface ComplianceHubProps {
  state: OSState;
  onUpdateState: () => void;
}

export default function ComplianceHub({ state, onUpdateState }: ComplianceHubProps) {
  const [runningTest, setRunningTest] = useState(false);

  const handleRunTests = async () => {
    setRunningTest(true);
    try {
      const res = await fetch('/api/compliance/run-tests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });

      if (!res.ok) {
        throw new Error("Failed to execute statutory testing suite.");
      }

      alert("Regulatory ADP/ACP & Coverage testing completed successfully.");
      onUpdateState();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setRunningTest(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="rhino-compliance-hub-root">
      {/* Left Pane: IRS / Statutory Parameter Registry */}
      <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm space-y-4">
        <div className="border-b border-zinc-900 pb-2 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">IRS REGULATORY PARAMETERS</h3>
            <p className="text-[10px] text-zinc-500 font-mono">Tax Year: 2026 Statutory Limits</p>
          </div>
          <Settings size={14} className="text-zinc-500" />
        </div>

        <div className="space-y-3 font-mono text-xs">
          {state.regulatoryParameters.map((param) => (
            <div key={param.id} className="p-3 bg-zinc-900/40 border border-zinc-900 rounded-sm">
              <div className="flex items-center justify-between">
                <span className="font-bold text-zinc-200">{param.parameterName}</span>
                <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded-sm">
                  {param.status}
                </span>
              </div>
              <div className="flex justify-between mt-3 text-[11px] text-zinc-400">
                <span>Value:</span>
                <span className="text-zinc-200 font-bold">
                  {param.unit === 'USD_CENTS' ? Money.formatCents(param.valueCents) : `${param.valueCents} Years`}
                </span>
              </div>
              <div className="text-[9px] text-zinc-500 mt-2 border-t border-zinc-900/50 pt-1">
                Ref: {param.sourceReference} • Version {param.version}
              </div>
            </div>
          ))}
        </div>

        <div className="p-3 bg-zinc-900/10 border border-dashed border-zinc-800 rounded-sm font-mono text-[10px] text-zinc-500 italic">
          IRS limit adjustments or statutory regulatory updates require Qualified Fiduciary and TPA audit authorization prior to system-wide deployment.
        </div>
      </div>

      {/* Right Pane: Nondiscrimination Testing suite & Results */}
      <div className="lg:col-span-2 bg-zinc-950 border border-zinc-800 p-5 rounded-sm space-y-6">
        <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
          <div className="font-mono">
            <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">STATUTORY NONDISCRIMINATION & ADHERENCE TESTING</h3>
            <p className="text-[10px] text-zinc-500">Run actual deferral percentage, coverage ratio, top-heavy and safe harbor conformance checks.</p>
          </div>

          <button
            onClick={handleRunTests}
            disabled={runningTest}
            className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-bold font-mono py-2 px-4 rounded-sm text-xs"
          >
            {runningTest ? 'CALCULATING ADP/ACP COHORTS...' : 'RUN ANNUAL TESTING SUITE'}
          </button>
        </div>

        {/* History of Compliance Testing */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-mono font-bold text-zinc-400 tracking-wider uppercase">HISTORICAL STATUTORY AUDIT RUNS</h4>
          
          <div className="space-y-3">
            {state.complianceResults.map((result) => {
              const passed = result.passed;
              return (
                <div 
                  key={result.id} 
                  className={`p-4 border rounded-sm font-mono text-xs ${
                    passed ? 'bg-emerald-500/5 border-emerald-500/10' : 'bg-red-500/5 border-red-500/10'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
                    <div className="flex items-center gap-2">
                      {passed ? <CheckCircle2 size={16} className="text-emerald-500" /> : <XCircle size={16} className="text-red-500" />}
                      <span className="font-bold text-zinc-200">IRC 401(k) {result.testType} Nondiscrimination Test</span>
                    </div>
                    <span className="text-[10px] text-zinc-500">Plan Year: {result.planYear}</span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3 text-[11px] text-zinc-400">
                    <div>
                      <span>HCE Count:</span>
                      <span className="text-zinc-200 font-bold block mt-0.5">{result.details.hceCount || "N/A"}</span>
                    </div>
                    <div>
                      <span>NHCE Count:</span>
                      <span className="text-zinc-200 font-bold block mt-0.5">{result.details.nhceCount || "N/A"}</span>
                    </div>
                    <div>
                      <span>HCE Avg Deferral:</span>
                      <span className="text-zinc-200 font-bold block mt-0.5">{result.details.hceAverageDeferralPercent || result.details.hceAverageMatchPercent}%</span>
                    </div>
                    <div>
                      <span>NHCE Avg Deferral:</span>
                      <span className="text-zinc-200 font-bold block mt-0.5">{result.details.nhceAverageDeferralPercent || result.details.nhceAverageMatchPercent}%</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-zinc-900/50 flex justify-between items-center text-[10px] text-zinc-500">
                    <span>Audit Date: {result.testDate} • TPA Reviewed</span>
                    <span className={`font-bold ${passed ? 'text-emerald-500' : 'text-red-500'}`}>
                      {passed ? `PASSED (Spread of ${result.details.actualSpreadPercent || 0}% conforms to statutory tolerances)` : 'ACTION REQUIRED'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
