import React, { useState } from 'react';
import { 
  PiggyBank, 
  HelpCircle, 
  Coins, 
  DollarSign, 
  LineChart, 
  Layers, 
  Calculator, 
  ArrowRight 
} from 'lucide-react';
import { OSState, Money } from '../data';
import { Participant } from '../types';

interface ParticipantPortalViewProps {
  state: OSState;
  onUpdateState: () => void;
}

export default function ParticipantPortalView({ state, onUpdateState }: ParticipantPortalViewProps) {
  const [selectedParticipant, setSelectedParticipant] = useState<Participant | null>(state.participants[0]);
  const [loanAmount, setLoanAmount] = useState('5000');
  const [loanTerm, setLoanTerm] = useState('36');
  const [distType, setDistType] = useState('TERMINATION');
  const [distAmount, setDistAmount] = useState('2000');

  // Scenario projections states
  const [targetRetireAge, setTargetRetireAge] = useState(65);
  const [expectedAnnualYield, setExpectedAnnualYield] = useState(7);

  const handleSelectParticipant = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const p = state.participants.find(part => part.id === e.target.value);
    if (p) setSelectedParticipant(p);
  };

  const handleRequestLoan = async () => {
    if (!selectedParticipant) return;
    try {
      const cents = Math.floor(Number(loanAmount) * 100);
      const res = await fetch('/api/loans/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          participantId: selectedParticipant.id,
          amountCents: cents,
          termMonths: loanTerm
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to process loan request.");
      }

      alert("Retirement loan successfully approved and principal funded into your external bank routing!");
      onUpdateState();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleRequestDistribution = async () => {
    if (!selectedParticipant) return;
    try {
      const cents = Math.floor(Number(distAmount) * 100);
      const res = await fetch('/api/distributions/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          participantId: selectedParticipant.id,
          type: distType,
          amountCents: cents
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to process distribution request.");
      }

      alert("Distribution processed. Statutory 1099-R forms generated and tax withholds posted to the IRS.");
      onUpdateState();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const totalBalance = selectedParticipant 
    ? (Object.values(selectedParticipant.balancesBySource) as number[]).reduce((a, b) => a + b, 0)
    : 0;

  // Simple retirement readiness scenario calculator
  const calculateProjections = () => {
    if (!selectedParticipant) return [];
    const currentAge = 35; // mock constant for simplicity
    const yearsToRetire = Math.max(1, targetRetireAge - currentAge);
    
    // Future value formula including compounding & bi-weekly deferral additions
    const rate = expectedAnnualYield / 100;
    const currentVal = totalBalance / 100;
    const annualAddition = 12000; // estimated annual deferral additions

    let balance = currentVal;
    const path = [];
    for (let i = 1; i <= yearsToRetire; i++) {
      balance = (balance * (1 + rate)) + annualAddition;
      path.push({ year: currentAge + i, balance: Math.floor(balance) });
    }
    return path;
  };

  const projections = calculateProjections();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="rhino-participant-portal-root">
      {/* Top Selector Panel */}
      <div className="col-span-1 lg:col-span-3 bg-zinc-950 border border-zinc-800 p-4 rounded-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="font-mono text-xs">
          <span className="text-zinc-500 font-bold block">PARTICIPANT RETIREMENT SERVICES CONSOLE</span>
          <p className="text-[10px] text-zinc-400 mt-0.5">Simulate participant journeys, origin loans, request distributions, and run readiness projections.</p>
        </div>

        <div className="flex items-center gap-3">
          <span className="font-mono text-xs text-zinc-400">Acting Participant:</span>
          <select 
            value={selectedParticipant?.id} 
            onChange={handleSelectParticipant}
            className="bg-zinc-900 border border-zinc-800 rounded-sm font-mono text-xs text-zinc-200 py-1.5 px-3 focus:outline-none"
          >
            {state.participants.map(p => (
              <option key={p.id} value={p.id}>{p.lastName}, {p.firstName} (Bal: {Money.formatCents(Object.values(p.balancesBySource).reduce((a,b)=>a+b, 0))})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Workspace Left Pane: Loan Requests & Hardship Distributions */}
      <div className="lg:col-span-2 space-y-6">
        {/* Loan Request Panel */}
        <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-sm space-y-4">
          <div className="border-b border-zinc-900 pb-2">
            <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">REQUEST LOAN ORIGINATION</h3>
            <p className="text-[10px] text-zinc-500">Plan provisions permit loans up to 50% of your vested balance or $50,000 max.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
            <div>
              <label className="text-zinc-400 block mb-1">Loan Principal Amount ($)</label>
              <input 
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-sm py-1.5 px-3 text-zinc-200 focus:outline-none"
              />
              <span className="text-[9px] text-zinc-500 block mt-1">Plan Rate: 8.25% fixed (Wall Street Journal Prime + 1.00%)</span>
            </div>

            <div>
              <label className="text-zinc-400 block mb-1">Term Length (Months)</label>
              <select
                value={loanTerm}
                onChange={(e) => setLoanTerm(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-sm py-1.5 px-3 text-zinc-200 focus:outline-none"
              >
                <option value="12">12 Months (1 Year)</option>
                <option value="24">24 Months (2 Years)</option>
                <option value="36">36 Months (3 Years)</option>
                <option value="48">48 Months (4 Years)</option>
                <option value="60">60 Months (5 Years - Statutory Max)</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleRequestLoan}
            className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-bold font-mono py-2 px-4 rounded-sm text-xs"
          >
            SUBMIT FOR TRUSTEE ORIGINATION
          </button>
        </div>

        {/* Distributions requests */}
        <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-sm space-y-4">
          <div className="border-b border-zinc-900 pb-2">
            <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">REQUEST IN-SERVICE OR HARDSHIP DISTRIBUTION</h3>
            <p className="text-[10px] text-zinc-500">Federal code mandates 20% flat withholding tax for standard non-Roth termination distributions.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
            <div>
              <label className="text-zinc-400 block mb-1">Distribution Reason Type</label>
              <select
                value={distType}
                onChange={(e) => setDistType(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-sm py-1.5 px-3 text-zinc-200 focus:outline-none"
              >
                <option value="TERMINATION">Post-Termination Rollover / Cash-Out</option>
                <option value="HARDSHIP">ERISA Qualified Hardship Withdrawal</option>
                <option value="RMD">Required Minimum Distribution (RMD)</option>
              </select>
            </div>

            <div>
              <label className="text-zinc-400 block mb-1">Gross Distribution Amount ($)</label>
              <input 
                type="number"
                value={distAmount}
                onChange={(e) => setDistAmount(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-sm py-1.5 px-3 text-zinc-200 focus:outline-none"
              />
              <span className="text-[9px] text-zinc-500 block mt-1">20% Federal + 5% State withholding auto-withheld at settlement.</span>
            </div>
          </div>

          <button
            onClick={handleRequestDistribution}
            className="bg-red-500 hover:bg-red-600 text-white font-bold font-mono py-2 px-4 rounded-sm text-xs"
          >
            SUBMIT COMPLIANCE RELEASE REQUEST
          </button>
        </div>
      </div>

      {/* Right Pane: Scenario Compounding Model */}
      <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-sm space-y-4">
        <div className="border-b border-zinc-900 pb-2">
          <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">RETIREMENT READINESS COMPACT MODEL</h3>
          <p className="text-[10px] text-zinc-500">Compounding growth and target accumulation calculator.</p>
        </div>

        <div className="space-y-3 font-mono text-xs">
          <div>
            <label className="text-zinc-400 block mb-1">Target Retirement Age</label>
            <input 
              type="number"
              value={targetRetireAge}
              onChange={(e) => setTargetRetireAge(Number(e.target.value))}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-sm py-1 px-2 text-zinc-200"
            />
          </div>

          <div>
            <label className="text-zinc-400 block mb-1">Assumed Market Return (%)</label>
            <input 
              type="number"
              value={expectedAnnualYield}
              onChange={(e) => setExpectedAnnualYield(Number(e.target.value))}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-sm py-1 px-2 text-zinc-200"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-zinc-900 space-y-2.5 max-h-[220px] overflow-y-auto">
          <h4 className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-wider">PROJECTED COMPOUND TRAJECTORY</h4>
          {projections.slice(0, 15).map(proj => (
            <div key={proj.year} className="flex justify-between items-center text-xs font-mono text-zinc-400">
              <span>Age {proj.year}:</span>
              <span className="text-zinc-200 font-bold">${proj.balance.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
