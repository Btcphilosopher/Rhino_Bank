import React, { useState } from 'react';
import { 
  FileText, 
  Upload, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  FileCheck, 
  Database, 
  UserCheck 
} from 'lucide-react';
import { OSState, Money } from '../data';
import { PayrollRun, PayrollRecord } from '../types';

interface OperationsCentreProps {
  state: OSState;
  onUpdateState: () => void;
}

export default function OperationsCentre({ state, onUpdateState }: OperationsCentreProps) {
  const [selectedRun, setSelectedRun] = useState<PayrollRun | null>(state.payrollRuns[0] || null);
  const [csvContent, setCsvContent] = useState('');
  const [importing, setImporting] = useState(false);
  const [importedRecords, setImportedRecords] = useState<PayrollRecord[]>([]);
  const [newRun, setNewRun] = useState<PayrollRun | null>(null);

  // Hardcoded highly detailed template for copy-pasting to test custom CSV imports!
  const csvTemplate = `employeeId,firstName,lastName,compensationCents,deferralPreTaxCents,deferralRothCents,catchUpPreTaxCents,catchUpRothCents,employerMatchCents,profitSharingCents,loanRepaymentCents,hoursWorked,employmentStatus
EMP_1001,Thomas,Caldwell,480769,38461,19230,0,0,19230,0,0,80,ACTIVE
EMP_1002,Jane,Kaufman,342307,20538,0,0,0,13692,0,0,80,ACTIVE
EMP_1004,Aaliyah,Williams,200000,8000,0,0,0,8000,0,0,80,ACTIVE`;

  const handleCsvImport = async () => {
    if (!csvContent.trim()) {
      alert("Please provide CSV content to import.");
      return;
    }

    setImporting(true);
    try {
      const lines = csvContent.split('\n');
      const headers = lines[0].split(',');
      
      const records = lines.slice(1).filter(line => line.trim()).map(line => {
        const values = line.split(',');
        const rec: any = {};
        headers.forEach((header, index) => {
          rec[header.trim()] = values[index]?.trim();
        });
        return rec;
      });

      const res = await fetch('/api/payroll/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          payDate: new Date().toISOString().split('T')[0],
          records
        })
      });

      if (!res.ok) {
        throw new Error("Failed to upload and validate payroll.");
      }

      const data = await res.json();
      setNewRun(data.run);
      setImportedRecords(data.records);
      onUpdateState();
      
    } catch (e: any) {
      alert(e.message);
    } finally {
      setImporting(false);
    }
  };

  const handleApprove = async (runId: string) => {
    try {
      const res = await fetch('/api/payroll/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ runId, overrideWarnings: true })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to approve payroll.");
      }

      alert("Payroll cycle successfully approved. Ledger buy transactions posted to trust accounts!");
      setNewRun(null);
      setImportedRecords([]);
      onUpdateState();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const activeRecords = selectedRun 
    ? (state.payrollRecords[selectedRun.id] || []) 
    : importedRecords;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="rhino-operations-centre-root">
      {/* Left Pane: Interactive Payroll CSV Adapter */}
      <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm space-y-4">
        <div className="border-b border-zinc-900 pb-2">
          <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">ENTERPRISE PAYROLL ADAPTER</h3>
          <p className="text-[10px] text-zinc-500 font-mono">Normalize, validate and post bi-weekly census runs.</p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400">
            <span>Direct CSV Feed Stream:</span>
            <button 
              onClick={() => setCsvContent(csvTemplate)}
              className="text-amber-500 hover:underline"
            >
              Load Sample Cycle Template
            </button>
          </div>
          <textarea
            value={csvContent}
            onChange={(e) => setCsvContent(e.target.value)}
            placeholder="Paste raw payroll lines here..."
            rows={10}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-sm p-2 text-[10px] font-mono text-zinc-300 focus:outline-none"
          />
        </div>

        <button
          onClick={handleCsvImport}
          disabled={importing}
          className="w-full bg-zinc-900 hover:bg-zinc-850 text-zinc-200 border border-zinc-800 hover:border-zinc-700 font-mono font-bold py-2 rounded-sm text-xs flex items-center justify-center gap-2"
        >
          <Upload size={14} /> {importing ? 'COMPUTING VALIDATIONS...' : 'IMPORT & RUN ELECTIONS AUDIT'}
        </button>

        {/* Historic Runs List */}
        <div className="pt-4 border-t border-zinc-900 space-y-2">
          <h4 className="text-[10px] font-mono font-bold text-zinc-400 tracking-wider uppercase">HISTORIC PAYROLL CYCLES</h4>
          <div className="space-y-1 max-h-[220px] overflow-y-auto">
            {state.payrollRuns.map(run => (
              <button
                key={run.id}
                onClick={() => {
                  setSelectedRun(run);
                  setNewRun(null);
                  setImportedRecords([]);
                }}
                className={`w-full text-left p-2 rounded-sm border font-mono text-[11px] flex items-center justify-between ${
                  selectedRun?.id === run.id && !newRun
                    ? 'bg-amber-500/5 border-amber-500/20 text-zinc-100 font-bold'
                    : 'bg-zinc-900/10 border-zinc-900/50 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <div>
                  <span>Cycle: {run.id.substring(7, 15)}</span>
                  <span className="block text-[9px] text-zinc-500">Pay Date: {run.payDate}</span>
                </div>
                <span className={`px-1.5 py-0.5 rounded-sm text-[9px] font-bold ${
                  run.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                }`}>
                  {run.status}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Right Pane: Validation Review, Alerts and Posting Engine */}
      <div className="lg:col-span-2 space-y-6">
        {newRun || selectedRun ? (
          <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-sm space-y-4">
            <div className="flex items-start justify-between border-b border-zinc-900 pb-3">
              <div className="font-mono">
                <span className="text-[10px] bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded-sm font-bold">
                  {newRun ? "ACTIVE IMPORT RECONCILIATION PREVIEW" : "HISTORIC POSTED RECORD"}
                </span>
                <h3 className="text-sm font-bold text-zinc-100 mt-2">
                  Cycle Run ID: {newRun ? newRun.id : selectedRun?.id}
                </h3>
                <p className="text-xs text-zinc-400 mt-1">
                  Pay Date: {newRun ? newRun.payDate : selectedRun?.payDate} • File Hash: {newRun ? newRun.fileHash : selectedRun?.fileHash}
                </p>
              </div>

              {newRun && (
                <button
                  onClick={() => handleApprove(newRun.id)}
                  className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-bold font-mono py-2 px-4 rounded-sm text-xs"
                >
                  FIDUCIARY RELEASE & POST LEDGER
                </button>
              )}
            </div>

            {/* Aggregates Banner */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono p-3 bg-zinc-900/40 border border-zinc-900 rounded-sm text-center">
              <div>
                <span className="text-[9px] text-zinc-500 block uppercase">Lines Tracked</span>
                <span className="text-sm font-bold text-zinc-200 mt-0.5 block">{newRun ? newRun.recordCount : selectedRun?.recordCount}</span>
              </div>
              <div>
                <span className="text-[9px] text-zinc-500 block uppercase">Total Compensation</span>
                <span className="text-sm font-bold text-zinc-200 mt-0.5 block">
                  {Money.formatCents(newRun ? newRun.totalCompensationCents : selectedRun?.totalCompensationCents || 0)}
                </span>
              </div>
              <div>
                <span className="text-[9px] text-zinc-500 block uppercase">Contributions Total</span>
                <span className="text-sm font-bold text-zinc-200 mt-0.5 block">
                  {Money.formatCents(newRun ? newRun.totalContributionsCents : selectedRun?.totalContributionsCents || 0)}
                </span>
              </div>
            </div>

            {/* Validation Rows Grid */}
            <div className="space-y-2 max-h-[350px] overflow-y-auto">
              {activeRecords.map((rec) => {
                const hasErrors = rec.validationErrors.length > 0;
                
                return (
                  <div 
                    key={rec.id} 
                    className={`p-3 rounded-sm border font-mono text-xs space-y-2 ${
                      hasErrors ? 'bg-red-500/5 border-red-500/20' : 'bg-zinc-900/30 border-zinc-900'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="font-bold text-zinc-200">{rec.firstName} {rec.lastName}</span>
                        <span className="text-[10px] text-zinc-500 ml-2">ID: {rec.employeeId}</span>
                      </div>
                      <span className="text-zinc-400">Comp: {Money.formatCents(rec.compensationCents)}</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] text-zinc-500 pt-1 border-t border-zinc-900/50">
                      <div><span className="text-zinc-500">PT Def:</span> <span className="text-zinc-300 font-bold">{Money.formatCents(rec.deferralPreTaxCents)}</span></div>
                      <div><span className="text-zinc-500">Roth Def:</span> <span className="text-zinc-300 font-bold">{Money.formatCents(rec.deferralRothCents)}</span></div>
                      <div><span className="text-zinc-500">Matching:</span> <span className="text-emerald-500 font-bold">{Money.formatCents(rec.employerMatchCents)}</span></div>
                      <div><span className="text-zinc-500">Loan Repay:</span> <span className="text-zinc-300">{Money.formatCents(rec.loanRepaymentCents)}</span></div>
                    </div>

                    {hasErrors && (
                      <div className="bg-red-500/10 border border-red-500/20 p-2 rounded-sm space-y-1 text-[10px] text-red-400">
                        {rec.validationErrors.map((err, i) => (
                          <div key={i} className="flex gap-1.5 items-start">
                            <AlertTriangle size={12} className="mt-0.5 shrink-0" />
                            <span>{err}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="bg-zinc-950 border border-zinc-800 p-12 rounded-sm text-center font-mono text-xs text-zinc-500 italic">
            Select a payroll cycle or paste new CSV feed lines in the adapter to conduct validation analysis.
          </div>
        )}
      </div>
    </div>
  );
}
