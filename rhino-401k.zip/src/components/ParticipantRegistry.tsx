import React, { useState } from 'react';
import { 
  Search, 
  User, 
  ShieldCheck, 
  Clock, 
  DollarSign, 
  Heart, 
  Edit3, 
  ArrowRightLeft, 
  TrendingUp 
} from 'lucide-react';
import { OSState, Money } from '../data';
import { Participant, AccountSourceType } from '../types';

interface ParticipantRegistryProps {
  state: OSState;
  onUpdateState: () => void;
}

export default function ParticipantRegistry({ state, onUpdateState }: ParticipantRegistryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedParticipant, setSelectedParticipant] = useState<Participant | null>(state.participants[0]);
  const [isEditingElections, setIsEditingElections] = useState(false);

  // Form states for election updates
  const [preTaxRate, setPreTaxRate] = useState(selectedParticipant?.deferralPercentPreTax || 0);
  const [rothRate, setRothRate] = useState(selectedParticipant?.deferralPercentRoth || 0);

  const filteredParticipants = state.participants.filter(p => 
    `${p.firstName} ${p.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.employeeId.includes(searchTerm)
  );

  const handleSelect = (p: Participant) => {
    setSelectedParticipant(p);
    setPreTaxRate(p.deferralPercentPreTax);
    setRothRate(p.deferralPercentRoth);
    setIsEditingElections(false);
  };

  const handleSaveElections = async () => {
    if (!selectedParticipant) return;

    try {
      const res = await fetch('/api/participants/update-elections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          participantId: selectedParticipant.id,
          preTax: preTaxRate,
          roth: rothRate
        })
      });

      if (!res.ok) {
        throw new Error("Failed to save elections.");
      }

      setIsEditingElections(false);
      onUpdateState();
      
      // Update local state copy to avoid stale references
      setSelectedParticipant({
        ...selectedParticipant,
        deferralPercentPreTax: preTaxRate,
        deferralPercentRoth: rothRate
      });

    } catch (e: any) {
      alert(e.message);
    }
  };

  // Helper to calculate total participant balance
  const getParticipantTotalBalance = (p: Participant) => {
    return (Object.values(p.balancesBySource) as number[]).reduce((sum, val) => sum + val, 0);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="rhino-participant-registry-root">
      {/* Sidebar: Census Directory & Search */}
      <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm space-y-4">
        <div className="border-b border-zinc-900 pb-2">
          <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">PARTICIPANT RECORDKEEPING CENSUS</h3>
          <p className="text-[10px] text-zinc-500 font-mono">Total Registry: {state.participants.length} Active Records</p>
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={14} className="absolute left-3 top-2.5 text-zinc-500" />
          <input
            type="text"
            placeholder="Search Name or Employee ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-sm py-1.5 pl-9 pr-4 text-xs font-mono text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>

        {/* Directory List */}
        <div className="space-y-1.5 max-h-[500px] overflow-y-auto pr-1">
          {filteredParticipants.map((p) => {
            const isSelected = selectedParticipant?.id === p.id;
            const totalVal = getParticipantTotalBalance(p);
            
            return (
              <button
                key={p.id}
                onClick={() => handleSelect(p)}
                className={`w-full text-left p-2.5 rounded-sm border transition-colors flex items-center justify-between ${
                  isSelected 
                    ? 'bg-amber-500/5 border-amber-500/25 text-zinc-100' 
                    : 'bg-zinc-900/30 border-zinc-900/60 hover:bg-zinc-900/70 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <div className="font-mono text-xs">
                  <span className="font-bold block">{p.lastName}, {p.firstName}</span>
                  <span className="text-[10px] text-zinc-500 block mt-0.5">ID: {p.employeeId} • {p.employmentStatus}</span>
                </div>
                <div className="font-mono text-xs text-right">
                  <span className="font-bold text-zinc-300">{Money.formatCents(totalVal)}</span>
                  <span className="text-[9px] text-zinc-500 block mt-0.5">{p.deferralPercentPreTax}% PT / {p.deferralPercentRoth}% Roth</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Workspace: Active Participant File Detailed Viewer */}
      <div className="lg:col-span-2 space-y-6">
        {selectedParticipant ? (
          <>
            {/* Header Identity Badge */}
            <div className="bg-zinc-950 border border-zinc-800 p-5 rounded-sm flex items-start justify-between">
              <div className="flex gap-4">
                <div className="bg-zinc-900 p-3 rounded-sm border border-zinc-800 text-amber-500">
                  <User size={24} />
                </div>
                <div className="font-mono">
                  <h3 className="text-base font-bold text-zinc-100">{selectedParticipant.firstName} {selectedParticipant.lastName}</h3>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-zinc-400 mt-1.5">
                    <div><span className="text-zinc-500">Employee ID:</span> {selectedParticipant.employeeId}</div>
                    <div><span className="text-zinc-500">SSN Ref:</span> {selectedParticipant.ssnMasked}</div>
                    <div><span className="text-zinc-500">Status:</span> {selectedParticipant.employmentStatus}</div>
                    <div><span className="text-zinc-500">Email:</span> {selectedParticipant.email}</div>
                  </div>
                </div>
              </div>

              <div className="text-right font-mono">
                <span className="text-[10px] text-zinc-500 tracking-wider block uppercase">TOTAL RETIREMENT VALUE</span>
                <span className="text-2xl font-bold text-zinc-100 mt-1 block">
                  {Money.formatCents(getParticipantTotalBalance(selectedParticipant))}
                </span>
                <span className="text-[10px] text-emerald-500 block font-bold mt-1">100% Fully Reconciled Lot Lots</span>
              </div>
            </div>

            {/* Subaccounts & Vesting Schedules */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Account Balances by Source */}
              <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm">
                <h4 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase border-b border-zinc-900 pb-2 mb-3">BALANCES BY CONTRIBUTION SOURCE</h4>
                <div className="space-y-3 font-mono text-xs">
                  {(Object.entries(selectedParticipant.balancesBySource) as [AccountSourceType, number][]).map(([source, val]) => {
                    const vestedPct = selectedParticipant.vestedPercentagesBySource[source] || 100;
                    const vestedVal = Math.floor((val * vestedPct) / 100);
                    
                    return (
                      <div key={source} className="p-2 bg-zinc-900/40 border border-zinc-900 rounded-sm">
                        <div className="flex justify-between font-bold text-zinc-300">
                          <span>{source.replace('_', ' ')}</span>
                          <span>{Money.formatCents(val)}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-zinc-500 mt-1 border-t border-zinc-900/50 pt-1">
                          <span>Vesting Percentage: {vestedPct}%</span>
                          <span>Vested Value: <span className="text-zinc-400 font-bold">{Money.formatCents(vestedVal)}</span></span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Deferral Rate & Target Allocations */}
              <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
                  <h4 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">ELECTION RULES & DEFERRALS</h4>
                  <button 
                    onClick={() => setIsEditingElections(!isEditingElections)}
                    className="text-[10px] text-amber-500 font-mono hover:underline flex items-center gap-1"
                  >
                    <Edit3 size={12} /> {isEditingElections ? 'CANCEL' : 'MODIFY RATES'}
                  </button>
                </div>

                {isEditingElections ? (
                  <div className="bg-zinc-900/50 border border-zinc-800 p-3.5 rounded-sm space-y-4 font-mono text-xs">
                    <div>
                      <label className="text-zinc-400 block mb-1">Pre-Tax Employee Deferral (%)</label>
                      <input 
                        type="number" 
                        min="0" 
                        max="100" 
                        value={preTaxRate} 
                        onChange={(e) => setPreTaxRate(Number(e.target.value))}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-sm py-1 px-2 text-zinc-200 text-xs focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-zinc-400 block mb-1">Roth Employee Deferral (%)</label>
                      <input 
                        type="number" 
                        min="0" 
                        max="100" 
                        value={rothRate} 
                        onChange={(e) => setRothRate(Number(e.target.value))}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-sm py-1 px-2 text-zinc-200 text-xs focus:outline-none"
                      />
                    </div>
                    <button 
                      onClick={handleSaveElections}
                      className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-bold py-1.5 rounded-sm text-xs"
                    >
                      POST UPDATE TRANSACTION
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3 font-mono text-xs">
                    <div className="flex justify-between p-2 bg-zinc-900/20 border border-zinc-900 rounded-sm">
                      <span className="text-zinc-500">Pre-Tax Deferral:</span>
                      <span className="text-zinc-300 font-bold">{selectedParticipant.deferralPercentPreTax}%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-zinc-900/20 border border-zinc-900 rounded-sm">
                      <span className="text-zinc-500">Roth Deferral:</span>
                      <span className="text-zinc-300 font-bold">{selectedParticipant.deferralPercentRoth}%</span>
                    </div>
                    <div className="flex justify-between p-2 bg-zinc-900/20 border border-zinc-900 rounded-sm">
                      <span className="text-zinc-500">Annual Catch-Up:</span>
                      <span className="text-zinc-300">{Money.formatCents(selectedParticipant.catchUpPreTaxCents)}</span>
                    </div>
                  </div>
                )}

                {/* Investment elections */}
                <div className="pt-2 border-t border-zinc-900">
                  <h5 className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-wider mb-2">FUTURE CONTRIBUTION INVESTMENT MENU ALLOCATIONS</h5>
                  <div className="space-y-1.5 text-xs font-mono">
                    {Object.entries(selectedParticipant.investmentElections).map(([fundId, percentage]) => {
                      const fund = state.funds.find(f => f.id === fundId);
                      return (
                        <div key={fundId} className="flex justify-between text-zinc-400">
                          <span className="truncate max-w-[150px]">{fund ? fund.ticker : fundId}</span>
                          <span className="text-zinc-300 font-bold">{percentage}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Beneficiaries & Claims */}
            <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm">
              <h4 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase border-b border-zinc-900 pb-2 mb-3">VALIDATED BENEFICIARY DESIGNATIONS</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {state.beneficiaries.filter(b => b.participantId === selectedParticipant.id).map(b => (
                  <div key={b.id} className="p-3 bg-zinc-900/50 border border-zinc-900 rounded-sm font-mono text-xs flex justify-between items-center">
                    <div>
                      <span className="font-bold text-zinc-200 block">{b.name}</span>
                      <span className="text-[10px] text-zinc-500 mt-0.5 block">{b.relation} • {b.type}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-amber-500 block">{b.percentage}% Allocation</span>
                      <span className="text-[9px] text-zinc-500 mt-0.5 block">Eff: {b.effectiveDate}</span>
                    </div>
                  </div>
                ))}
                {state.beneficiaries.filter(b => b.participantId === selectedParticipant.id).length === 0 && (
                  <div className="col-span-2 text-center p-4 border border-dashed border-zinc-900 text-xs text-zinc-500 italic font-mono">
                    No validated beneficiary designations filed. Generates administrative audit flag.
                  </div>
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="bg-zinc-950 border border-zinc-800 p-12 rounded-sm text-center font-mono text-xs text-zinc-500 italic">
            Select a participant record to load full administrative history.
          </div>
        )}
      </div>
    </div>
  );
}
