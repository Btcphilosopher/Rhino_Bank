import React, { useState } from 'react';
import { 
  Shield, 
  Plus, 
  Activity, 
  Award, 
  HelpCircle, 
  CheckCircle2, 
  Eye, 
  Calendar 
} from 'lucide-react';
import { OSState, Money } from '../data';
import { FiduciaryDecision } from '../types';

interface FiduciaryCentreProps {
  state: OSState;
  onUpdateState: () => void;
}

export default function FiduciaryCentre({ state, onUpdateState }: FiduciaryCentreProps) {
  const [loggingDecision, setLoggingDecision] = useState(false);
  const [decisionTitle, setDecisionTitle] = useState('');
  const [decisionMakers, setDecisionMakers] = useState('');
  const [analysisSummary, setAnalysisSummary] = useState('');

  const handleLogDecision = async () => {
    if (!decisionTitle.trim() || !analysisSummary.trim()) {
      alert("Please provide a title and analysis summary.");
      return;
    }

    try {
      const res = await fetch('/api/fiduciary/decide', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: decisionTitle,
          makers: decisionMakers.split(',').map(m => m.trim()),
          summary: analysisSummary
        })
      });

      if (!res.ok) {
        throw new Error("Failed to log fiduciary decision.");
      }

      setDecisionTitle('');
      setDecisionMakers('');
      setAnalysisSummary('');
      setLoggingDecision(false);
      onUpdateState();
      alert("ERISA fiduciary decision recorded. Entry stamped with immutable SHA Hash and logged to the global audit trail.");
    } catch (e: any) {
      alert(e.message);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="rhino-fiduciary-centre-root">
      {/* Left Pane: Fund Monitoring Watchlist under ERISA 404(c) */}
      <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-sm space-y-4">
        <div className="border-b border-zinc-900 pb-2">
          <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">ERISA 404(c) INVESTMENT MONITORING</h3>
          <p className="text-[10px] text-zinc-500 font-mono font-bold">Fiduciary watchlists & performance benchmarking.</p>
        </div>

        <div className="space-y-3 font-mono text-xs">
          {state.funds.map((fund) => {
            const performanceOk = fund.oneYearReturnPercent >= 4.0;
            return (
              <div key={fund.id} className="p-3 bg-zinc-900/40 border border-zinc-900 rounded-sm">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-zinc-200">{fund.ticker}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-sm ${
                    performanceOk ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                  }`}>
                    {performanceOk ? 'CONFORMING' : 'UNDER REVIEW'}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400 mt-1 truncate">{fund.name}</p>
                
                <div className="flex justify-between mt-3 text-[10px] text-zinc-500">
                  <span>1Y Performance:</span>
                  <span className={`font-bold ${performanceOk ? 'text-zinc-300' : 'text-amber-500'}`}>
                    {fund.oneYearReturnPercent}% vs {fund.benchmark}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Pane: Committee Decisions Evidence Log */}
      <div className="lg:col-span-2 bg-zinc-950 border border-zinc-800 p-5 rounded-sm space-y-6">
        <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
          <div className="font-mono">
            <h3 className="text-xs font-mono font-bold tracking-wider text-zinc-300 uppercase">FIDUCIARY EVIDENCE LOG (ERISA 404)</h3>
            <p className="text-[10px] text-zinc-500">Log investment adjustments, committee votes, and plan design decisions.</p>
          </div>

          <button
            onClick={() => setLoggingDecision(!loggingDecision)}
            className="bg-zinc-900 hover:bg-zinc-850 text-zinc-200 border border-zinc-800 hover:border-zinc-700 font-mono font-bold py-2 px-4 rounded-sm text-xs flex items-center gap-1"
          >
            <Plus size={14} /> {loggingDecision ? 'CANCEL' : 'LOG COMMITTEE DECISION'}
          </button>
        </div>

        {loggingDecision && (
          <div className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-sm font-mono text-xs space-y-4">
            <h4 className="text-[10px] text-amber-500 font-bold uppercase tracking-wider">RECORD NEW FORMAL FIDUCIARY PROPOSAL</h4>
            
            <div className="space-y-3">
              <div>
                <label className="text-zinc-400 block mb-1">Decision Title</label>
                <input 
                  type="text"
                  placeholder="e.g. Annual Reallocation mapping of Target Date glide paths"
                  value={decisionTitle}
                  onChange={(e) => setDecisionTitle(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-sm py-1 px-2 text-zinc-200"
                />
              </div>

              <div>
                <label className="text-zinc-400 block mb-1">Decision Makers (comma separated)</label>
                <input 
                  type="text"
                  placeholder="Sarah Jenkins, Marcus Vance"
                  value={decisionMakers}
                  onChange={(e) => setDecisionMakers(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-sm py-1 px-2 text-zinc-200"
                />
              </div>

              <div>
                <label className="text-zinc-400 block mb-1">ERISA Compliance & Analysis Summary</label>
                <textarea 
                  placeholder="Stipulate the investment performance, benchmark research, and fiduciary rationales for changing this plan design provision..."
                  value={analysisSummary}
                  onChange={(e) => setAnalysisSummary(e.target.value)}
                  rows={4}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-sm p-2 text-zinc-200"
                />
              </div>

              <button
                onClick={handleLogDecision}
                className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-bold py-2 rounded-sm"
              >
                COMMIT FIDUCIARY VOTE ENTRY
              </button>
            </div>
          </div>
        )}

        {/* Existing Log Entries */}
        <div className="space-y-4">
          {state.fiduciaryDecisions.map((decision) => (
            <div key={decision.id} className="p-4 border border-zinc-900 bg-zinc-900/10 rounded-sm font-mono text-xs space-y-2">
              <div className="flex justify-between items-start">
                <span className="font-bold text-zinc-200 text-sm">{decision.decisionTitle}</span>
                <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded-sm">
                  {decision.approvalStatus}
                </span>
              </div>
              <p className="text-zinc-400 text-xs">{decision.analysisSummary}</p>
              
              <div className="grid grid-cols-2 gap-2 text-[10px] text-zinc-500 border-t border-zinc-900 pt-2">
                <div><span className="text-zinc-500">Makers:</span> {decision.decisionMakers.join(', ')}</div>
                <div className="text-right"><span className="text-zinc-500">Stamped:</span> {decision.date}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
