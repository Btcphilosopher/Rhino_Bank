/**
 * RHINO 401K - Strongly Typed Domain Models
 * Canonical record representations for institutional retirement-plan administration.
 * Floating-point arithmetic is strictly forbidden for currency. All monetary amounts are handled
 * using standard cents/fixed-scale arithmetic (e.g. integer amounts or custom Decimals in cents).
 */

export interface DecimalVal {
  cents: number; // Value in cents to prevent floating point errors
  currency: string;
}

export type EmploymentStatus = 'ACTIVE' | 'TERMINATED' | 'ON_LEAVE' | 'RETIRED';
export type VestingScheduleType = 'IMMEDIATE' | 'CLIFF' | 'GRADED' | 'CUSTOM';
export type AccountSourceType = 'PRE_TAX' | 'ROTH' | 'EMPLOYER_MATCH' | 'PROFIT_SHARING' | 'ROLLOVER';
export type TransactionType = 'BUY' | 'SELL' | 'EXCHANGE' | 'DIVIDEND' | 'INTEREST' | 'FEE' | 'REINVESTMENT' | 'TRANSFER';
export type LedgerStatus = 'PENDING' | 'VALIDATED' | 'FUNDED' | 'POSTED' | 'SETTLED' | 'REVERSED' | 'REJECTED';
export type DistributionType = 'RETIREMENT' | 'TERMINATION' | 'IN_SERVICE' | 'HARDSHIP' | 'ROLLOVER' | 'RMD';
export type DistributionStatus = 'REQUESTED' | 'ELIGIBILITY_CHECKED' | 'TAX_CALCULATED' | 'APPROVED' | 'SETTLED' | 'REJECTED';
export type LoanStatus = 'ACTIVE' | 'PAID_OFF' | 'DEFAULTED' | 'PENDING_APPROVAL';

// Core Entities
export interface Employer {
  id: string;
  legalName: string;
  ein: string;
  address: string;
  industry: string;
  employeeCount: number;
  payrollFrequency: 'WEEKLY' | 'BI_WEEKLY' | 'SEMI_MONTHLY' | 'MONTHLY';
  planSponsor: string;
  authorizedUsers: string[];
  fiduciaries: string[];
  committees: string[];
  planAssetsCents: number;
  historyNotes: string[];
}

export interface Plan {
  id: string;
  employerId: string;
  planName: string;
  planNumber: string; // e.g., "001"
  effectiveDate: string;
  planYearStart: string; // MM-DD
  status: 'ACTIVE' | 'SUSPENDED' | 'PROPOSED';
  
  // Rule links
  eligibilityRuleId: string;
  contributionRuleId: string;
  matchingRuleId: string;
  vestingRuleId: string;
  loanRuleId: string;
  distributionRuleId: string;
  
  autoEnrollmentEnabled: boolean;
  autoEnrollmentRate: number; // e.g. 3 (%)
  autoEscalationEnabled: boolean;
  autoEscalationMaxRate: number; // e.g. 10 (%)
  autoEscalationIncrement: number; // e.g. 1 (%)
  qdias: string[]; // Fund IDs
  feeScheduleId: string;
  trustStructure: string;
}

export interface PlanDocument {
  id: string;
  planId: string;
  title: string;
  effectiveDate: string;
  expirationDate: string | null;
  version: string;
  hash: string;
  approvalDate: string;
  approvedBy: string[];
  status: 'APPROVED' | 'DRAFT' | 'SUPERSEDED';
}

export interface PlanProvision {
  id: string;
  planDocumentId: string;
  provisionCode: string; // e.g. "ELIG_AGE", "MATCH_FORMULA"
  ruleType: string;
  parameterValue: string; // JSON or raw string
  interpretation: string;
  isSystemAligned: boolean;
}

export interface Participant {
  id: string;
  employeeId: string;
  employerId: string;
  planId: string;
  ssnMasked: string; // "XXX-XX-1234"
  firstName: string;
  lastName: string;
  email: string;
  employmentStatus: EmploymentStatus;
  hireDate: string;
  terminationDate: string | null;
  rehireDate: string | null;
  eligibleDate: string | null;
  entryDate: string | null;
  compensationCents: number;
  
  // Elections
  deferralPercentPreTax: number; // integer percentage (0-100)
  deferralPercentRoth: number; // integer percentage (0-100)
  catchUpPreTaxCents: number;
  catchUpRothCents: number;
  investmentElections: { [fundId: string]: number }; // percentage sum = 100
  
  // Balances in cents
  balancesBySource: { [source in AccountSourceType]: number };
  vestedPercentagesBySource: { [source in AccountSourceType]: number };
  
  communicationPreference: 'EMAIL' | 'PAPER' | 'DIGITAL_ONLY';
}

export interface Beneficiary {
  id: string;
  participantId: string;
  name: string;
  relation: string;
  ssnMasked: string;
  percentage: number; // e.g. 50 (%)
  type: 'PRIMARY' | 'CONTINGENT';
  effectiveDate: string;
}

// Financial Ledger & Lots
export interface Transaction {
  id: string;
  participantId: string;
  planId: string;
  fundId: string; // if security transaction, or "CASH"
  type: TransactionType;
  source: AccountSourceType;
  amountCents: number;
  units: number; // Multiplied by 1,000,000 (represented as integer for precision)
  pricePerUnitCents: number; // Multiplied by 10,000 for precision
  effectiveDate: string;
  postingDate: string;
  settlementDate: string | null;
  payrollRunId: string | null;
  status: LedgerStatus;
  referenceId: string; // correlation ID
}

export interface InvestmentLot {
  id: string;
  participantId: string;
  planId: string;
  fundId: string;
  source: AccountSourceType;
  quantityUnits: number; // Multiplied by 1,000,000
  costBasisCents: number;
  acquisitionDate: string;
  associatedTxId: string;
}

export interface Fund {
  id: string;
  ticker: string;
  name: string;
  assetClass: 'EQUITY' | 'FIXED_INCOME' | 'STABLE_VALUE' | 'TARGET_DATE' | 'MONEY_MARKET';
  navCents: number; // Multiplied by 10,000
  expenseRatio: number; // e.g. 0.05 (%)
  riskCategory: 'LOW' | 'MEDIUM' | 'HIGH';
  benchmark: string;
  manager: string;
  oneYearReturnPercent: number;
}

export interface FundPriceHistory {
  fundId: string;
  date: string;
  navCents: number;
}

// Payroll interface
export interface PayrollRun {
  id: string;
  employerId: string;
  planId: string;
  payDate: string;
  payPeriodStart: string;
  payPeriodEnd: string;
  totalCompensationCents: number;
  totalContributionsCents: number;
  status: 'IMPORTED' | 'VALIDATED' | 'APPROVED' | 'FUNDED' | 'POSTED' | 'RECONCILED';
  fileHash: string;
  recordCount: number;
}

export interface PayrollRecord {
  id: string;
  payrollRunId: string;
  employeeId: string;
  firstName: string;
  lastName: string;
  compensationCents: number;
  deferralPreTaxCents: number;
  deferralRothCents: number;
  catchUpPreTaxCents: number;
  catchUpRothCents: number;
  employerMatchCents: number;
  profitSharingCents: number;
  loanRepaymentCents: number;
  hoursWorked: number;
  employmentStatus: EmploymentStatus;
  validationErrors: string[];
}

// Compliance and Testing
export interface RegulatoryParameter {
  id: string;
  parameterName: string; // e.g. "402g_LIMIT", "415c_LIMIT", "CATCH_UP_LIMIT"
  valueCents: number; // or integer value
  unit: 'USD_CENTS' | 'PERCENT' | 'YEARS';
  effectiveDate: string;
  expirationDate: string | null;
  sourceReference: string;
  jurisdiction: 'US_FEDERAL';
  version: string;
  status: 'ACTIVE' | 'SUPERSEDED';
}

export interface ComplianceTestResult {
  id: string;
  planId: string;
  testType: 'ADP' | 'ACP' | 'TOP_HEAVY' | 'LIMIT_415' | 'LIMIT_402G' | 'COVERAGE';
  testDate: string;
  planYear: number;
  passed: boolean;
  details: any; // test specific statistics
  reviewedBy: string | null;
  status: 'PENDING' | 'PASSED' | 'FAILED_CORRECTED' | 'FAILED';
}

// Loans and Distributions
export interface Loan {
  id: string;
  participantId: string;
  planId: string;
  principalCents: number;
  interestRatePercent: number; // e.g., 8.25
  termMonths: number;
  amortizationSchedule: LoanPaymentAmortization[];
  outstandingPrincipalCents: number;
  status: LoanStatus;
  nextPaymentDueDate: string;
  missedPaymentsCount: number;
  startDate: string;
}

export interface LoanPaymentAmortization {
  paymentNumber: number;
  dueDate: string;
  principalCents: number;
  interestCents: number;
  endingBalanceCents: number;
}

export interface LoanPayment {
  id: string;
  loanId: string;
  participantId: string;
  amountPaidCents: number;
  principalComponentCents: number;
  interestComponentCents: number;
  paymentDate: string;
  payrollRunId: string | null;
}

export interface DistributionRequest {
  id: string;
  participantId: string;
  planId: string;
  type: DistributionType;
  grossAmountCents: number;
  federalWithholdingCents: number;
  stateWithholdingCents: number;
  netAmountCents: number;
  taxableAmountCents: number;
  status: DistributionStatus;
  requestDate: string;
  settlementDate: string | null;
  beneficiaryClaimId: string | null;
  taxFormGenerated: string | null; // e.g. "1099R-2026"
  workflowTaskId: string;
}

// Custody & Reconciliation
export interface CustodyAccount {
  id: string;
  name: string;
  type: 'CUSTODY' | 'TRUST_CASH' | 'SETTLEMENT';
  balanceCents: number;
}

export interface ReconciliationResult {
  id: string;
  reconciliationDate: string;
  module: 'PAYROLL' | 'TRUST' | 'CUSTODY_POSITIONS' | 'PARTICIPANT_BALANCES';
  matchedCount: number;
  unmatchedCount: number;
  unresolvedVarianceCents: number;
  exceptions: ReconciliationException[];
  status: 'FULLY_RECONCILED' | 'UNRESOLVED_DISCREPANCIES' | 'AUTO_RESOLVED';
}

export interface ReconciliationException {
  id: string;
  entityType: string; // e.g. "PARTICIPANT" or "FUND"
  entityId: string;
  description: string;
  varianceCents: number;
  status: 'OPEN' | 'ASSIGNED' | 'RESOLVED' | 'ESCALATED';
  assignedTo: string | null;
}

// Audit & Workflow
export interface AuditEvent {
  id: string;
  actor: string; // user email or system service
  timestamp: string;
  entityType: string;
  entityId: string;
  action: string;
  beforeStateHash: string | null;
  afterStateHash: string | null;
  correlationId: string;
  reason: string;
  approvalRequired: boolean;
}

export interface FiduciaryDecision {
  id: string;
  planId: string;
  date: string;
  decisionTitle: string;
  decisionMakers: string[];
  supportingDocuments: string[];
  analysisSummary: string;
  alternativesConsidered: string[];
  approvalStatus: 'APPROVED' | 'REJECTED' | 'TABLED';
  implementationDate: string | null;
  auditEventId: string;
}

export interface WorkflowTask {
  id: string;
  workflowType: 'NEW_PLAN' | 'PAYROLL' | 'DISTRIBUTION' | 'COMPLIANCE_TEST';
  title: string;
  description: string;
  assignedRole: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'BLOCKED';
  createdDate: string;
  completedDate: string | null;
  correlationId: string;
  steps: { name: string; completed: boolean; date: string | null }[];
}
