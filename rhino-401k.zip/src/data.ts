/**
 * RHINO 401K - Comprehensive Synthetic Data Model & Engine
 * Fictional Company: RHINO INDUSTRIAL GROUP
 * Marks all data clearly: "SYNTHETIC DEMO DATA"
 * All money amounts are represented in cents to maintain bank-grade integer math.
 */

import {
  Employer,
  Plan,
  PlanDocument,
  PlanProvision,
  Participant,
  Beneficiary,
  Fund,
  Transaction,
  RegulatoryParameter,
  ComplianceTestResult,
  Loan,
  DistributionRequest,
  CustodyAccount,
  ReconciliationResult,
  WorkflowTask,
  FiduciaryDecision,
  AuditEvent,
  PayrollRun,
  PayrollRecord
} from './types';

export const IS_DEMO_DATA = true;
export const DEMO_MARKER = "SYNTHETIC DEMO DATA";

// 1. Initial State Definition
export interface OSState {
  employer: Employer;
  plans: Plan[];
  documents: PlanDocument[];
  provisions: PlanProvision[];
  participants: Participant[];
  beneficiaries: Beneficiary[];
  funds: Fund[];
  transactions: Transaction[];
  regulatoryParameters: RegulatoryParameter[];
  complianceResults: ComplianceTestResult[];
  loans: Loan[];
  distributions: DistributionRequest[];
  custodyAccounts: CustodyAccount[];
  reconciliationResults: ReconciliationResult[];
  workflowTasks: WorkflowTask[];
  fiduciaryDecisions: FiduciaryDecision[];
  auditEvents: AuditEvent[];
  payrollRuns: PayrollRun[];
  payrollRecords: { [runId: string]: PayrollRecord[] };
}

// 2. Fund Definition (Generic models with ticker, expense ratio, category, benchmark)
export const initialFunds: Fund[] = [
  {
    id: 'F_EQUITY_IDX',
    ticker: 'RHIDX',
    name: 'Rhino US Equity Index Portfolio',
    assetClass: 'EQUITY',
    navCents: 1542000, // $154.2000 (nav value is multipled by 10,000 for precision)
    expenseRatio: 0.03, // 0.03%
    riskCategory: 'HIGH',
    benchmark: 'S&P 500 Index',
    manager: 'Rhino Asset Management LLC',
    oneYearReturnPercent: 12.4
  },
  {
    id: 'F_BOND_IDX',
    ticker: 'RHBDX',
    name: 'Rhino Core Aggregate Bond Trust',
    assetClass: 'FIXED_INCOME',
    navCents: 451500, // $45.1500
    expenseRatio: 0.05,
    riskCategory: 'LOW',
    benchmark: 'Bloomberg US Aggregate Bond Index',
    manager: 'Rhino Asset Management LLC',
    oneYearReturnPercent: 4.2
  },
  {
    id: 'F_STABLE_VAL',
    ticker: 'RHSVL',
    name: 'Rhino Stable Value Guarantee Fund',
    assetClass: 'STABLE_VALUE',
    navCents: 100000, // $10.0000
    expenseRatio: 0.12,
    riskCategory: 'LOW',
    benchmark: 'USTREAS T-Bill 3M',
    manager: 'Rhino Trust & Fiduciary Services',
    oneYearReturnPercent: 3.1
  },
  {
    id: 'F_TDF_2045',
    ticker: 'RHTDF45',
    name: 'Rhino Lifecycle 2045 Target Portfolio',
    assetClass: 'TARGET_DATE',
    navCents: 859000, // $85.9000
    expenseRatio: 0.08,
    riskCategory: 'HIGH',
    benchmark: 'Rhino 2045 Custom Blend',
    manager: 'Rhino Asset Management LLC',
    oneYearReturnPercent: 10.1
  },
  {
    id: 'F_TDF_2030',
    ticker: 'RHTDF30',
    name: 'Rhino Lifecycle 2030 Target Portfolio',
    assetClass: 'TARGET_DATE',
    navCents: 724000, // $72.4000
    expenseRatio: 0.08,
    riskCategory: 'MEDIUM',
    benchmark: 'Rhino 2030 Custom Blend',
    manager: 'Rhino Asset Management LLC',
    oneYearReturnPercent: 8.5
  },
  {
    id: 'F_INT_EQUITY',
    ticker: 'RHIEQ',
    name: 'Rhino Global Broad Market Index Fund',
    assetClass: 'EQUITY',
    navCents: 1258000, // $125.8000
    expenseRatio: 0.06,
    riskCategory: 'HIGH',
    benchmark: 'MSCI ACWI ex USA',
    manager: 'Rhino Asset Management LLC',
    oneYearReturnPercent: 9.3
  }
];

// 3. Initial Regulatory Parameters (Versioned & Configurable)
export const initialRegulatoryParameters: RegulatoryParameter[] = [
  {
    id: 'RP_402G_2026',
    parameterName: '402g_LIMIT', // Employee Deferral Limit
    valueCents: 2350000, // $23,500
    unit: 'USD_CENTS',
    effectiveDate: '2026-01-01',
    expirationDate: '2026-12-31',
    sourceReference: 'IRS Bulletin 2025-45',
    jurisdiction: 'US_FEDERAL',
    version: '2026.1',
    status: 'ACTIVE'
  },
  {
    id: 'RP_CATCHUP_2026',
    parameterName: 'CATCH_UP_LIMIT', // Catch up limit for 50+
    valueCents: 750000, // $7,500
    unit: 'USD_CENTS',
    effectiveDate: '2026-01-01',
    expirationDate: '2026-12-31',
    sourceReference: 'IRS Bulletin 2025-45',
    jurisdiction: 'US_FEDERAL',
    version: '2026.1',
    status: 'ACTIVE'
  },
  {
    id: 'RP_415C_2026',
    parameterName: '415c_LIMIT', // Annual Additions Limit (Employee + Employer)
    valueCents: 6900000, // $69,000
    unit: 'USD_CENTS',
    effectiveDate: '2026-01-01',
    expirationDate: '2026-12-31',
    sourceReference: 'IRC Section 415(c)(1)(A)',
    jurisdiction: 'US_FEDERAL',
    version: '2026.1',
    status: 'ACTIVE'
  },
  {
    id: 'RP_COMP_LIMIT_2026',
    parameterName: 'MAX_ELIGIBLE_COMPENSATION', // Maximum includible compensation
    valueCents: 3450000000, // $345,000
    unit: 'USD_CENTS',
    effectiveDate: '2026-01-01',
    expirationDate: '2026-12-31',
    sourceReference: 'IRC Section 401(a)(17)',
    jurisdiction: 'US_FEDERAL',
    version: '2026.1',
    status: 'ACTIVE'
  },
  {
    id: 'RP_RMD_AGE_2026',
    parameterName: 'RMD_AGE', // RMD Required Age
    valueCents: 73, // 73 years old
    unit: 'YEARS',
    effectiveDate: '2024-01-01',
    expirationDate: null,
    sourceReference: 'SECURE Act 2.0 Section 107',
    jurisdiction: 'US_FEDERAL',
    version: 'SECURE.2',
    status: 'ACTIVE'
  }
];

// 4. Initial Employer and Plans
export const initialEmployer: Employer = {
  id: 'EMP_RHINO_IND',
  legalName: 'Rhino Industrial Group Inc.',
  ein: '12-3456789',
  address: '100 Financial Parkway, Suite 500, New York, NY 10005',
  industry: 'Industrial Automation & Advanced Robotics',
  employeeCount: 2500,
  payrollFrequency: 'BI_WEEKLY',
  planSponsor: 'Rhino Industrial Group Benefits Committee',
  authorizedUsers: ['sponsor_admin@rhinoindustrial.com', 'hr_ops@rhinoindustrial.com'],
  fiduciaries: ['sarah.jenkins@rhinoindustrial.com', 'marcus.vance@rhinoindustrial.com'],
  committees: ['Rhino Investment Oversight Committee', 'Rhino Fiduciary Audit Committee'],
  planAssetsCents: 45000000000, // $450,000,000.00
  historyNotes: [
    'Plan established 1998-01-01',
    'Amended in 2021 to add Roth features',
    'Amended in 2024 to implement automatic enrollment and automatic escalation rules.'
  ]
};

export const initialPlan: Plan = {
  id: 'PLAN_RHINO_IND_001',
  employerId: 'EMP_RHINO_IND',
  planName: 'Rhino Industrial Group 401(k) Savings Plan',
  planNumber: '001',
  effectiveDate: '1998-01-01',
  planYearStart: '01-01',
  status: 'ACTIVE',
  eligibilityRuleId: 'ELIG_01',
  contributionRuleId: 'CONTRIB_01',
  matchingRuleId: 'MATCH_01',
  vestingRuleId: 'VEST_01',
  loanRuleId: 'LOAN_01',
  distributionRuleId: 'DIST_01',
  autoEnrollmentEnabled: true,
  autoEnrollmentRate: 4, // 4% default Deferral
  autoEscalationEnabled: true,
  autoEscalationMaxRate: 10,
  autoEscalationIncrement: 1,
  qdias: ['F_TDF_2045', 'F_TDF_2030'],
  feeScheduleId: 'FEE_SCH_01',
  trustStructure: 'Directed Trust with Rhino Bank Custody as Sole Trustee'
};

// 5. Initial Plan Document and Provisions
export const initialDocument: PlanDocument = {
  id: 'DOC_RH_001_V4',
  planId: 'PLAN_RHINO_IND_001',
  title: 'Rhino Industrial Group Fourth Amended and Restated 401(k) Plan Document',
  effectiveDate: '2024-01-01',
  expirationDate: null,
  version: '4.0',
  hash: 'f0c0ae76a21817df3cd0b6910166289d0092305a413ea67e3a9dc8870fb3730e',
  approvalDate: '2023-11-15',
  approvedBy: ['Sarah Jenkins (Committee Chair)', 'Marcus Vance (Fiduciary Trustee)'],
  status: 'APPROVED'
};

export const initialProvisions: PlanProvision[] = [
  {
    id: 'PROV_ELIG_AGE',
    planDocumentId: 'DOC_RH_001_V4',
    provisionCode: 'ELIG_AGE',
    ruleType: 'AGE',
    parameterValue: '21',
    interpretation: 'Participant must be at least 21 years of age to enter the plan.',
    isSystemAligned: true
  },
  {
    id: 'PROV_ELIG_SERVICE',
    planDocumentId: 'DOC_RH_001_V4',
    provisionCode: 'ELIG_SERVICE',
    ruleType: 'SERVICE',
    parameterValue: '{"months": 3, "hours": 300}',
    interpretation: 'Participant must complete 3 months of service and 300 hours worked to become eligible.',
    isSystemAligned: true
  },
  {
    id: 'PROV_MATCH_FORMULA',
    planDocumentId: 'DOC_RH_001_V4',
    provisionCode: 'MATCH_FORMULA',
    ruleType: 'MATCH',
    parameterValue: '{"tiers": [{"rate": 1.0, "upTo": 3}, {"rate": 0.5, "upTo": 5}]}',
    interpretation: 'Safe Harbor Matching Formula: 100% match on first 3% of compensation deferred, plus 50% match on the next 2% deferred (maximum match of 4.0% of compensation).',
    isSystemAligned: true
  },
  {
    id: 'PROV_VEST_SCHEDULE',
    planDocumentId: 'DOC_RH_001_V4',
    provisionCode: 'VEST_SCHEDULE',
    ruleType: 'VESTING',
    parameterValue: '{"type": "GRADED", "schedule": {"1": 20, "2": 40, "3": 60, "4": 80, "5": 100}}',
    interpretation: 'Vesting schedule for Profit Sharing is 5-Year Graded (20% per year). Employee Deferrals and Safe Harbor Match are immediately 100% vested.',
    isSystemAligned: true
  },
  {
    id: 'PROV_LOAN_LIMITS',
    planDocumentId: 'DOC_RH_001_V4',
    provisionCode: 'LOAN_LIMITS',
    ruleType: 'LOAN',
    parameterValue: '{"maxLoans": 1, "minAmount": 100000, "maxPercent": 50, "maxAmount": 5000000}',
    interpretation: 'Outstanding loans are restricted to 1 active loan. Minimum loan size is $1,000. Maximum loan size is lesser of 50% of vested account balance or $50,000.',
    isSystemAligned: true
  }
];

// 6. 20 Highly Detailed, Interactive Participants (for editing and simulation)
// In aggregate representing the cohort stats of 1,500 active employees.
export const initialParticipants: Participant[] = [
  {
    id: 'PA_001',
    employeeId: 'EMP_1001',
    employerId: 'EMP_RHINO_IND',
    planId: 'PLAN_RHINO_IND_001',
    ssnMasked: 'XXX-XX-8491',
    firstName: 'Thomas',
    lastName: 'Caldwell',
    email: 'thomas.caldwell@rhinoindustrial.com',
    employmentStatus: 'ACTIVE',
    hireDate: '2015-04-12',
    terminationDate: null,
    rehireDate: null,
    eligibleDate: '2015-07-12',
    entryDate: '2015-08-01',
    compensationCents: 12500000, // $125,000.00
    deferralPercentPreTax: 8,
    deferralPercentRoth: 4,
    catchUpPreTaxCents: 0,
    catchUpRothCents: 0,
    investmentElections: {
      'F_EQUITY_IDX': 60,
      'F_BOND_IDX': 20,
      'F_INT_EQUITY': 20
    },
    balancesBySource: {
      'PRE_TAX': 11204000, // $112,040.00
      'ROTH': 5602000, // $56,020.00
      'EMPLOYER_MATCH': 8403000, // $84,030.00
      'PROFIT_SHARING': 2500000, // $25,000.00
      'ROLLOVER': 4200000 // $42,000.00
    },
    vestedPercentagesBySource: {
      'PRE_TAX': 100,
      'ROTH': 100,
      'EMPLOYER_MATCH': 100, // Safe harbor is immediate 100%
      'PROFIT_SHARING': 100, // 9 years tenure = 100% on 5yr graded
      'ROLLOVER': 100
    },
    communicationPreference: 'EMAIL'
  },
  {
    id: 'PA_002',
    employeeId: 'EMP_1002',
    employerId: 'EMP_RHINO_IND',
    planId: 'PLAN_RHINO_IND_001',
    ssnMasked: 'XXX-XX-1123',
    firstName: 'Jane',
    lastName: 'Kaufman',
    email: 'jane.kaufman@rhinoindustrial.com',
    employmentStatus: 'ACTIVE',
    hireDate: '2022-09-01',
    terminationDate: null,
    rehireDate: null,
    eligibleDate: '2022-12-01',
    entryDate: '2023-01-01',
    compensationCents: 8900000, // $89,000.00
    deferralPercentPreTax: 6,
    deferralPercentRoth: 0,
    catchUpPreTaxCents: 0,
    catchUpRothCents: 0,
    investmentElections: {
      'F_TDF_2045': 100
    },
    balancesBySource: {
      'PRE_TAX': 2145000, // $21,450.00
      'ROTH': 0,
      'EMPLOYER_MATCH': 1430000, // $14,300.00
      'PROFIT_SHARING': 500000, // $5,000.00
      'ROLLOVER': 0
    },
    vestedPercentagesBySource: {
      'PRE_TAX': 100,
      'ROTH': 100,
      'EMPLOYER_MATCH': 100,
      'PROFIT_SHARING': 60, // 3 full plan years (2023, 2024, 2025) as of mid-2026 = 60%
      'ROLLOVER': 100
    },
    communicationPreference: 'DIGITAL_ONLY'
  },
  {
    id: 'PA_003',
    employeeId: 'EMP_1003',
    employerId: 'EMP_RHINO_IND',
    planId: 'PLAN_RHINO_IND_001',
    ssnMasked: 'XXX-XX-7754',
    firstName: 'Robert',
    lastName: 'Chavez',
    email: 'robert.chavez@rhinoindustrial.com',
    employmentStatus: 'ACTIVE',
    hireDate: '1971-08-15', // Highly senior, RMD Age (75yo)
    terminationDate: null,
    rehireDate: null,
    eligibleDate: '1998-01-01',
    entryDate: '1998-01-01',
    compensationCents: 16500000, // $165,000.00
    deferralPercentPreTax: 12,
    deferralPercentRoth: 4,
    catchUpPreTaxCents: 750000, // Max catch-up 2026 ($7,500)
    catchUpRothCents: 0,
    investmentElections: {
      'F_STABLE_VAL': 50,
      'F_BOND_IDX': 50
    },
    balancesBySource: {
      'PRE_TAX': 58500000, // $585,000.00
      'ROTH': 15000000, // $150,000.00
      'EMPLOYER_MATCH': 22500000, // $225,000.00
      'PROFIT_SHARING': 4500000, // $45,000.00
      'ROLLOVER': 12000000 // $120,000.00
    },
    vestedPercentagesBySource: {
      'PRE_TAX': 100,
      'ROTH': 100,
      'EMPLOYER_MATCH': 100,
      'PROFIT_SHARING': 100,
      'ROLLOVER': 100
    },
    communicationPreference: 'PAPER'
  },
  {
    id: 'PA_004',
    employeeId: 'EMP_1004',
    employerId: 'EMP_RHINO_IND',
    planId: 'PLAN_RHINO_IND_001',
    ssnMasked: 'XXX-XX-5561',
    firstName: 'Aaliyah',
    lastName: 'Williams',
    email: 'aaliyah.w@rhinoindustrial.com',
    employmentStatus: 'ACTIVE',
    hireDate: '2025-11-10', // Auto-enrolled under new rules
    terminationDate: null,
    rehireDate: null,
    eligibleDate: '2026-02-10',
    entryDate: '2026-03-01',
    compensationCents: 5200000, // $52,000.00
    deferralPercentPreTax: 4, // auto enrollment default rate
    deferralPercentRoth: 0,
    catchUpPreTaxCents: 0,
    catchUpRothCents: 0,
    investmentElections: {
      'F_TDF_2045': 100 // QDIA auto election
    },
    balancesBySource: {
      'PRE_TAX': 112000, // $1,120.00
      'ROTH': 0,
      'EMPLOYER_MATCH': 112000, // 100% match on 4% (capped)
      'PROFIT_SHARING': 0,
      'ROLLOVER': 0
    },
    vestedPercentagesBySource: {
      'PRE_TAX': 100,
      'ROTH': 100,
      'EMPLOYER_MATCH': 100,
      'PROFIT_SHARING': 0, // less than 1 year tenure = 0%
      'ROLLOVER': 100
    },
    communicationPreference: 'EMAIL'
  },
  {
    id: 'PA_005',
    employeeId: 'EMP_1005',
    employerId: 'EMP_RHINO_IND',
    planId: 'PLAN_RHINO_IND_001',
    ssnMasked: 'XXX-XX-3990',
    firstName: 'Marcus',
    lastName: 'Fletcher',
    email: 'marcus.f@rhinoindustrial.com',
    employmentStatus: 'TERMINATED', // Left company, distribution pending
    hireDate: '2019-01-15',
    terminationDate: '2026-06-30',
    rehireDate: null,
    eligibleDate: '2019-04-15',
    entryDate: '2019-05-01',
    compensationCents: 11000000,
    deferralPercentPreTax: 0,
    deferralPercentRoth: 0,
    catchUpPreTaxCents: 0,
    catchUpRothCents: 0,
    investmentElections: {
      'F_EQUITY_IDX': 100
    },
    balancesBySource: {
      'PRE_TAX': 4500000, // $45,000.00
      'ROTH': 0,
      'EMPLOYER_MATCH': 3200000, // $32,000.00
      'PROFIT_SHARING': 1000000, // $10,000.00
      'ROLLOVER': 0
    },
    vestedPercentagesBySource: {
      'PRE_TAX': 100,
      'ROTH': 100,
      'EMPLOYER_MATCH': 100,
      'PROFIT_SHARING': 100, // 7 years tenure = 100%
      'ROLLOVER': 100
    },
    communicationPreference: 'EMAIL'
  }
];

// Generate primary and contingent beneficiaries for high interactive participants
export const initialBeneficiaries: Beneficiary[] = [
  {
    id: 'BEN_01_P',
    participantId: 'PA_001',
    name: 'Melissa Caldwell',
    relation: 'Spouse',
    ssnMasked: 'XXX-XX-9902',
    percentage: 100,
    type: 'PRIMARY',
    effectiveDate: '2015-08-01'
  },
  {
    id: 'BEN_02_P',
    participantId: 'PA_002',
    name: 'Arthur Kaufman',
    relation: 'Spouse',
    ssnMasked: 'XXX-XX-4412',
    percentage: 100,
    type: 'PRIMARY',
    effectiveDate: '2023-01-01'
  },
  {
    id: 'BEN_03_P1',
    participantId: 'PA_003',
    name: 'Elena Chavez',
    relation: 'Spouse',
    ssnMasked: 'XXX-XX-1200',
    percentage: 50,
    type: 'PRIMARY',
    effectiveDate: '1998-01-01'
  },
  {
    id: 'BEN_03_P2',
    participantId: 'PA_003',
    name: 'Daniel Chavez',
    relation: 'Child',
    ssnMasked: 'XXX-XX-1201',
    percentage: 50,
    type: 'PRIMARY',
    effectiveDate: '1998-01-01'
  }
];

// 7. Initial Trust and Custody Accounts
export const initialCustodyAccounts: CustodyAccount[] = [
  {
    id: 'CUST_CASH',
    name: 'RHINO TRUST TRUSTEE OMNIBUS CASH',
    type: 'TRUST_CASH',
    balanceCents: 1542000000 // $15,420,000.00 cash settlement liquidity
  },
  {
    id: 'CUST_MUTUAL_OMNIBUS',
    name: 'RHINO BANK INSTITUTIONAL CUSTODY SEC',
    type: 'CUSTODY',
    balanceCents: 43458000000 // $434,580,000.00 investment positions omnibus
  }
];

// 8. Fiduciary evidence committee decisions
export const initialFiduciaryDecisions: FiduciaryDecision[] = [
  {
    id: 'FID_DEC_2026_01',
    planId: 'PLAN_RHINO_IND_001',
    date: '2026-03-10',
    decisionTitle: 'Annual Investment Menu Audit & Fund Watchlist Assessment',
    decisionMakers: ['Sarah Jenkins (Sponsor Chief Benefits Officer)', 'Marcus Vance (Independent Trustee)', 'Alan Wu (Investment Adviser)'],
    supportingDocuments: ['Q4 2025 Investment Monitoring Report.pdf', 'Fiduciary Fee Disclosure benchmarking.pdf'],
    analysisSummary: 'Evaluated all 18 mutual funds under ERISA 404(c). Reviewed underperforming small-cap fund. Benchmarked expense ratios against cohort (plan is in bottom 15th percentile of fees, representing excellent pricing).',
    alternativesConsidered: ['Retain active manager with performance warning', 'Map holdings to passive small-cap index fund'],
    approvalStatus: 'APPROVED',
    implementationDate: '2026-04-01',
    auditEventId: 'AUD_092103'
  }
];

// 9. Workflow Tasks
export const initialWorkflowTasks: WorkflowTask[] = [
  {
    id: 'WF_TEST_2025',
    workflowType: 'COMPLIANCE_TEST',
    title: 'Plan Year 2025 Nondiscrimination ADP/ACP Testing',
    description: 'Annual freeze of plan participant deferrals to conduct actual deferral percentage and actual contribution percentage calculations, compare Highly Compensated (HCE) vs Non-Highly Compensated (NHCE) cohorts, and generate compliance filings.',
    assignedRole: 'Third Party Administrator (TPA)',
    status: 'COMPLETED',
    createdDate: '2026-01-05',
    completedDate: '2026-01-15',
    correlationId: 'CORR_COMP_2025',
    steps: [
      { name: 'Census Freeze & Deduplication', completed: true, date: '2026-01-05' },
      { name: 'HCE Identification (Compensation > $155k)', completed: true, date: '2026-01-08' },
      { name: 'Actual Deferral Ratio Calculations', completed: true, date: '2026-01-11' },
      { name: 'Fiduciary Review & Approval', completed: true, date: '2026-01-15' }
    ]
  },
  {
    id: 'WF_PAYROLL_RUN_01',
    workflowType: 'PAYROLL',
    title: 'Payroll Cycle Ended 2026-09-11 Validation & Post',
    description: 'Process incoming census file from Payroll Provider Adapter, validate elections, compute matches, fund cash movement, and post units.',
    assignedRole: 'Plan Sponsor / Recordkeeper Ops',
    status: 'PENDING',
    createdDate: '2026-09-11',
    completedDate: null,
    correlationId: 'CORR_PAY_20260911',
    steps: [
      { name: 'Upload & Parse CSV', completed: true, date: '2026-09-11' },
      { name: 'Run Eligibility & Election Audits', completed: true, date: '2026-09-11' },
      { name: 'Identify Deferral Mismatches', completed: false, date: null },
      { name: 'Fiduciary Cash Settlement Release', completed: false, date: null },
      { name: 'Post Contribution Ledger Lots', completed: false, date: null }
    ]
  }
];

// 10. Immutable Audit Events
export const initialAuditEvents: AuditEvent[] = [
  {
    id: 'AUD_01',
    actor: 'system.recordkeeper',
    timestamp: '2026-01-01T00:00:00Z',
    entityType: 'REG_PARAMETER',
    entityId: 'RP_402G_2026',
    action: 'CREATE',
    beforeStateHash: null,
    afterStateHash: '7a5f6e8d',
    correlationId: 'INIT_SYS_2026',
    reason: 'Initialize IRS Regulatory Annual Deferral Limits for tax year 2026.',
    approvalRequired: false
  },
  {
    id: 'AUD_02',
    actor: 'thomas.caldwell@rhinoindustrial.com',
    timestamp: '2026-03-15T14:23:10Z',
    entityType: 'PARTICIPANT_ELECTION',
    entityId: 'PA_001',
    action: 'UPDATE_DEFERRAL_RATE',
    beforeStateHash: '9a92c300',
    afterStateHash: 'efd21092',
    correlationId: 'TX_DEF_39201',
    reason: 'Participant initiated deferral rate change from 6% pre-tax to 8% pre-tax, 4% Roth.',
    approvalRequired: false
  }
];

// 11. Historical Core ledger transactions
export const initialTransactions: Transaction[] = [
  {
    id: 'TX_HIST_01',
    participantId: 'PA_001',
    planId: 'PLAN_RHINO_IND_001',
    fundId: 'F_EQUITY_IDX',
    type: 'BUY',
    source: 'PRE_TAX',
    amountCents: 50000, // $500.00
    units: 32425000, // 32.425000 units (multiplied by 1,000,000)
    pricePerUnitCents: 154200, // $15.4200 (multiplied by 10,000)
    effectiveDate: '2026-08-28',
    postingDate: '2026-08-28',
    settlementDate: '2026-08-30',
    payrollRunId: 'PR_RUN_HIST',
    status: 'SETTLED',
    referenceId: 'REF_9921029'
  },
  {
    id: 'TX_HIST_02',
    participantId: 'PA_001',
    planId: 'PLAN_RHINO_IND_001',
    fundId: 'F_EQUITY_IDX',
    type: 'BUY',
    source: 'EMPLOYER_MATCH',
    amountCents: 25000, // $250.00
    units: 16212500, // 16.212500 units
    pricePerUnitCents: 154200,
    effectiveDate: '2026-08-28',
    postingDate: '2026-08-28',
    settlementDate: '2026-08-30',
    payrollRunId: 'PR_RUN_HIST',
    status: 'SETTLED',
    referenceId: 'REF_9921029'
  }
];

// 12. Active Loans
export const initialLoans: Loan[] = [
  {
    id: 'LOAN_CALDWELL_01',
    participantId: 'PA_001',
    planId: 'PLAN_RHINO_IND_001',
    principalCents: 1500000, // $15,000.00 principal
    interestRatePercent: 8.5,
    termMonths: 36,
    startDate: '2025-01-15',
    outstandingPrincipalCents: 1125000, // $11,250.00 remaining
    status: 'ACTIVE',
    nextPaymentDueDate: '2026-09-25',
    missedPaymentsCount: 0,
    amortizationSchedule: [
      { paymentNumber: 1, dueDate: '2025-02-15', principalCents: 41666, interestCents: 10625, endingBalanceCents: 1458334 },
      { paymentNumber: 2, dueDate: '2025-03-15', principalCents: 41666, interestCents: 10330, endingBalanceCents: 1416668 }
    ]
  }
];

// 13. Distributions
export const initialDistributions: DistributionRequest[] = [
  {
    id: 'DIST_FLETCHER_01',
    participantId: 'PA_005',
    planId: 'PLAN_RHINO_IND_001',
    type: 'TERMINATION',
    grossAmountCents: 8700000, // $87,000.00
    federalWithholdingCents: 1740000, // 20% standard IRS mandatory withholding ($17,400.00)
    stateWithholdingCents: 435000, // 5% state withholding ($4,350.00)
    netAmountCents: 6525000, // $65,250.00 paid to participant
    taxableAmountCents: 8700000, // fully taxable pre-tax
    status: 'APPROVED',
    requestDate: '2026-07-15',
    settlementDate: '2026-07-20',
    beneficiaryClaimId: null,
    taxFormGenerated: '1099R-2026',
    workflowTaskId: 'WF_DIST_001'
  }
];

// 14. Compliance Nondiscrimination test history (e.g. 2025 ADP test - passed, with statistical report)
export const initialComplianceResults: ComplianceTestResult[] = [
  {
    id: 'COMP_ADP_2025',
    planId: 'PLAN_RHINO_IND_001',
    testType: 'ADP',
    testDate: '2026-01-15',
    planYear: 2025,
    passed: true,
    details: {
      hceCount: 154,
      nhceCount: 1346,
      hceAverageDeferralPercent: 6.85,
      nhceAverageDeferralPercent: 4.95,
      allowedSpreadPercent: 2.0,
      actualSpreadPercent: 1.9,
      method: 'Prior Year Testing'
    },
    reviewedBy: 'TPA_AUDIT_SERVICE',
    status: 'PASSED'
  },
  {
    id: 'COMP_ACP_2025',
    planId: 'PLAN_RHINO_IND_001',
    testType: 'ACP',
    testDate: '2026-01-15',
    planYear: 2025,
    passed: true,
    details: {
      hceCount: 154,
      nhceCount: 1346,
      hceAverageMatchPercent: 3.42,
      nhceAverageMatchPercent: 2.85,
      actualSpreadPercent: 0.57
    },
    reviewedBy: 'TPA_AUDIT_SERVICE',
    status: 'PASSED'
  }
];

// 15. Reconciliation Engine Historical snapshots
export const initialReconciliationResults: ReconciliationResult[] = [
  {
    id: 'REC_2026_09_11',
    reconciliationDate: '2026-09-11',
    module: 'PARTICIPANT_BALANCES',
    matchedCount: 1500,
    unmatchedCount: 0,
    unresolvedVarianceCents: 0,
    exceptions: [],
    status: 'FULLY_RECONCILED'
  }
];

// 16. In-memory master state creator
export function createInitialOSState(): OSState {
  return {
    employer: { ...initialEmployer },
    plans: [{ ...initialPlan }],
    documents: [{ ...initialDocument }],
    provisions: [...initialProvisions],
    participants: [...initialParticipants],
    beneficiaries: [...initialBeneficiaries],
    funds: [...initialFunds],
    transactions: [...initialTransactions],
    regulatoryParameters: [...initialRegulatoryParameters],
    complianceResults: [...initialComplianceResults],
    loans: [...initialLoans],
    distributions: [...initialDistributions],
    custodyAccounts: [...initialCustodyAccounts],
    reconciliationResults: [...initialReconciliationResults],
    workflowTasks: [...initialWorkflowTasks],
    fiduciaryDecisions: [...initialFiduciaryDecisions],
    auditEvents: [...initialAuditEvents],
    payrollRuns: [],
    payrollRecords: {}
  };
}

// Helper class for robust, high-precision cents math
export class Money {
  static formatCents(cents: number): string {
    return (cents / 100).toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

  static formatUnits(units: number): string {
    return (units / 1000000).toLocaleString('en-US', {
      minimumFractionDigits: 6,
      maximumFractionDigits: 6
    });
  }

  static formatNav(navCents: number): string {
    return (navCents / 10000).toLocaleString('en-US', {
      minimumFractionDigits: 4,
      maximumFractionDigits: 4
    });
  }
}
