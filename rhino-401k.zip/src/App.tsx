import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Terminal, 
  Database, 
  ShieldCheck, 
  LineChart, 
  ArrowLeftRight, 
  Activity, 
  Settings, 
  Bot, 
  HelpCircle, 
  Clock, 
  Compass 
} from 'lucide-react';
import { OSState } from './data';
import CommandCentre from './components/CommandCentre';
import ParticipantRegistry from './components/ParticipantRegistry';
import OperationsCentre from './components/OperationsCentre';
import ComplianceHub from './components/ComplianceHub';
import TrustCustodyRecon from './components/TrustCustodyRecon';
import FiduciaryCentre from './components/FiduciaryCentre';
import ParticipantPortalView from './components/ParticipantPortalView';
import AIAssistantConsole from './components/AIAssistantConsole';

type ActiveTab = 
  | 'COMMAND_CENTRE'
  | 'PARTICIPANTS'
  | 'PAYROLL_OPERATIONS'
  | 'COMPLIANCE'
  | 'TRUST_RECON'
  | 'FIDUCIARY'
  | 'PARTICIPANT_PORTAL'
  | 'AI_ASSISTANT';

export default function App() {
  const [state, setState] = useState<OSState | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('COMMAND_CENTRE');
  const [timeStr, setTimeStr] = useState('');

  // Fetch full state from backend Express server
  const fetchState = async () => {
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const data = await res.json();
        setState(data);
      }
    } catch (e) {
      console.error("Error fetching institutional state:", e);
    }
  };

  useEffect(() => {
    fetchState();
    
    // Set up UTC ticker for financial terminal look & feel
    const timer = setInterval(() => {
      const d = new Date();
      setTimeStr(d.toISOString().replace('T', ' ').substring(0, 19) + ' UTC');
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  if (!state) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-400 flex items-center justify-center font-mono text-xs gap-3">
        <Activity className="animate-spin text-amber-500" size={16} />
        <span>BOOTING RHINO BANK RETIREMENT OS KERNEL...</span>
      </div>
    );
  }

  const renderActiveWorkspace = () => {
    switch (activeTab) {
      case 'COMMAND_CENTRE':
        return <CommandCentre state={state} />;
      case 'PARTICIPANTS':
        return <ParticipantRegistry state={state} onUpdateState={fetchState} />;
      case 'PAYROLL_OPERATIONS':
        return <OperationsCentre state={state} onUpdateState={fetchState} />;
      case 'COMPLIANCE':
        return <ComplianceHub state={state} onUpdateState={fetchState} />;
      case 'TRUST_RECON':
        return <TrustCustodyRecon state={state} onUpdateState={fetchState} />;
      case 'FIDUCIARY':
        return <FiduciaryCentre state={state} onUpdateState={fetchState} />;
      case 'PARTICIPANT_PORTAL':
        return <ParticipantPortalView state={state} onUpdateState={fetchState} />;
      case 'AI_ASSISTANT':
        return <AIAssistantConsole />;
    }
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col antialiased selection:bg-amber-500/30 selection:text-zinc-100">
      
      {/* 1. TOP INSTITUTIONAL BAR (Branding and metadata indicators) */}
      <header className="bg-zinc-950 border-b border-zinc-850 px-4 py-2.5 flex items-center justify-between font-mono text-xs select-none">
        <div className="flex items-center gap-3">
          {/* Logo */}
          <div className="flex items-center gap-1.5 font-bold tracking-widest text-zinc-100 text-[13px]">
            <Building2 size={16} className="text-amber-500 shrink-0" />
            <span>RHINO <span className="text-amber-500">401K</span></span>
          </div>
          
          <div className="h-4 w-[1px] bg-zinc-800"></div>

          <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-sm">
            <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">CUSTODY SYNCED</span>
          </div>

          <span className="text-zinc-500 text-[11px] hidden md:inline">
            Tenant: <span className="text-zinc-300 font-bold">{state.employer.name}</span>
          </span>
        </div>

        {/* Real-time system clocks & indicators */}
        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-2 text-zinc-500 text-[11px]">
            <Clock size={12} />
            <span>SYSTEM TIME: <span className="text-zinc-300 font-bold">{timeStr || 'LOADING...'}</span></span>
          </div>

          <div className="h-4 w-[1px] bg-zinc-800 hidden lg:block"></div>

          <span className="text-[10px] bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded-sm font-bold">
            STATUTORY COMPLIANCE: VALIDATED
          </span>
        </div>
      </header>

      {/* 2. TAB CONTROL AND ACTIVE WORKSPACE */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        
        {/* SIDE BAR CONTROL ROOM MENU */}
        <nav className="w-full md:w-64 bg-zinc-950 border-r border-zinc-850 p-4 space-y-6 flex flex-col select-none">
          
          <div className="space-y-1.5">
            <span className="text-[9px] font-mono font-bold text-zinc-500 tracking-wider uppercase block px-2 mb-1">PLAN COMMAND</span>
            
            <button
              onClick={() => setActiveTab('COMMAND_CENTRE')}
              className={`w-full flex items-center gap-2.5 font-mono text-xs px-3 py-2 rounded-sm transition-colors ${
                activeTab === 'COMMAND_CENTRE' 
                  ? 'bg-amber-500/5 border border-amber-500/20 text-zinc-100 font-bold' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
              }`}
            >
              <Compass size={14} className="text-zinc-400 shrink-0" />
              <span>Command Centre</span>
            </button>
          </div>

          <div className="space-y-1.5">
            <span className="text-[9px] font-mono font-bold text-zinc-500 tracking-wider uppercase block px-2 mb-1">RECORDKEEPING CENSUS</span>

            <button
              onClick={() => setActiveTab('PARTICIPANTS')}
              className={`w-full flex items-center gap-2.5 font-mono text-xs px-3 py-2 rounded-sm transition-colors ${
                activeTab === 'PARTICIPANTS' 
                  ? 'bg-amber-500/5 border border-amber-500/20 text-zinc-100 font-bold' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
              }`}
            >
              <Database size={14} className="text-zinc-400 shrink-0" />
              <span>Participant Registry</span>
            </button>
          </div>

          <div className="space-y-1.5">
            <span className="text-[9px] font-mono font-bold text-zinc-500 tracking-wider uppercase block px-2 mb-1">OPERATIONS & CASH</span>

            <button
              onClick={() => setActiveTab('PAYROLL_OPERATIONS')}
              className={`w-full flex items-center gap-2.5 font-mono text-xs px-3 py-2 rounded-sm transition-colors ${
                activeTab === 'PAYROLL_OPERATIONS' 
                  ? 'bg-amber-500/5 border border-amber-500/20 text-zinc-100 font-bold' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
              }`}
            >
              <ArrowLeftRight size={14} className="text-zinc-400 shrink-0" />
              <span>Payroll Centre</span>
            </button>

            <button
              onClick={() => setActiveTab('TRUST_RECON')}
              className={`w-full flex items-center gap-2.5 font-mono text-xs px-3 py-2 rounded-sm transition-colors ${
                activeTab === 'TRUST_RECON' 
                  ? 'bg-amber-500/5 border border-amber-500/20 text-zinc-100 font-bold' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
              }`}
            >
              <Activity size={14} className="text-zinc-400 shrink-0" />
              <span>Trust & Custody Recon</span>
            </button>
          </div>

          <div className="space-y-1.5">
            <span className="text-[9px] font-mono font-bold text-zinc-500 tracking-wider uppercase block px-2 mb-1">FIDUCIARY GOVERNANCE</span>

            <button
              onClick={() => setActiveTab('COMPLIANCE')}
              className={`w-full flex items-center gap-2.5 font-mono text-xs px-3 py-2 rounded-sm transition-colors ${
                activeTab === 'COMPLIANCE' 
                  ? 'bg-amber-500/5 border border-amber-500/20 text-zinc-100 font-bold' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
              }`}
            >
              <ShieldCheck size={14} className="text-zinc-400 shrink-0" />
              <span>Compliance Testing</span>
            </button>

            <button
              onClick={() => setActiveTab('FIDUCIARY')}
              className={`w-full flex items-center gap-2.5 font-mono text-xs px-3 py-2 rounded-sm transition-colors ${
                activeTab === 'FIDUCIARY' 
                  ? 'bg-amber-500/5 border border-amber-500/20 text-zinc-100 font-bold' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
              }`}
            >
              <LineChart size={14} className="text-zinc-400 shrink-0" />
              <span>Fiduciary Committee</span>
            </button>
          </div>

          <div className="space-y-1.5">
            <span className="text-[9px] font-mono font-bold text-zinc-500 tracking-wider uppercase block px-2 mb-1">PARTICIPANT SERVICES</span>

            <button
              onClick={() => setActiveTab('PARTICIPANT_PORTAL')}
              className={`w-full flex items-center gap-2.5 font-mono text-xs px-3 py-2 rounded-sm transition-colors ${
                activeTab === 'PARTICIPANT_PORTAL' 
                  ? 'bg-amber-500/5 border border-amber-500/20 text-zinc-100 font-bold' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
              }`}
            >
              <Settings size={14} className="text-zinc-400 shrink-0" />
              <span>Retirement Portal</span>
            </button>
          </div>

          {/* AI assistant spacer & button */}
          <div className="flex-1"></div>

          <div className="border-t border-zinc-900 pt-4 space-y-2">
            <span className="text-[9px] font-mono font-bold text-zinc-500 tracking-wider uppercase block px-2">INTELLIGENT INSIGHTS</span>
            <button
              onClick={() => setActiveTab('AI_ASSISTANT')}
              className={`w-full flex items-center gap-2.5 font-mono text-xs px-3 py-2.5 rounded-sm transition-colors ${
                activeTab === 'AI_ASSISTANT' 
                  ? 'bg-amber-500/10 border border-amber-500/30 text-amber-500 font-bold' 
                  : 'bg-zinc-900/40 border border-zinc-850 hover:border-zinc-800 text-zinc-300 hover:text-zinc-100'
              }`}
            >
              <Bot size={14} className="text-amber-500 shrink-0" />
              <span>Ask Rhino Gemini AI</span>
            </button>
          </div>
        </nav>

        {/* WORKSPACE AREA */}
        <main className="flex-1 bg-[#09090b] p-6 overflow-y-auto max-h-[calc(100vh-130px)]">
          {renderActiveWorkspace()}
        </main>
      </div>

      {/* 3. IMMUTABLE SYSTEM AUDIT LOG FOOTER */}
      <footer className="bg-zinc-950 border-t border-zinc-850 px-4 py-3 select-none">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="font-mono text-[10px] text-zinc-500 flex items-center gap-2">
            <Terminal size={12} className="text-zinc-500 shrink-0" />
            <span>REAL-TIME AUDIT LOG:</span>
          </div>

          <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-full overflow-hidden">
            {state.auditEvents.slice(0, 4).map((event) => (
              <div key={event.id} className="font-mono text-[9px] text-zinc-500 truncate border-l border-zinc-850 pl-2">
                <span className="text-amber-500 font-bold">[{event.action}]</span>{' '}
                <span className="text-zinc-400 font-bold">{event.actor}</span>: {event.reason}
              </div>
            ))}
          </div>

          <div className="font-mono text-[9px] text-zinc-600">
            SHA-256 Ledger Verified
          </div>
        </div>
      </footer>
    </div>
  );
}
