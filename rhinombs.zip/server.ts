/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { 
  MortgageLoan, 
  PoolStatistics, 
  PropertyType, 
  RepaymentType, 
  Region,
  CashFlowPeriod,
  SimulationResult,
  StressTestScenario,
  TrancheStructure
} from "./src/types.js";

dotenv.config();

const app = express();
app.use(express.json());
const PORT = 3000;

// Initialize Gemini SDK with recommended user-agent header
const apiKey = process.env.GEMINI_API_KEY || "";
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Generate 250 diversified high-fidelity loans procedurally on server boot
const REGIONS: Region[] = ["Yorkshire", "London & South East", "North West", "Midlands", "Scotland", "South West"];
const PROPERTY_TYPES: PropertyType[] = ["Residential", "Buy-To-Let", "Commercial", "Mixed-Use"];

function generateMockPortfolio(): MortgageLoan[] {
  const loans: MortgageLoan[] = [];
  const seedRandom = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    return () => {
      const x = Math.sin(hash++) * 10000;
      return x - Math.floor(x);
    };
  };

  const rand = seedRandom("rhinombs-yorkshire-securitisation");

  for (let i = 1; i <= 250; i++) {
    const id = `LN-${100000 + i}`;
    
    // Weighted selection of regions (with high weight for Yorkshire to align with visual theme)
    let region: Region = "Yorkshire";
    const regVal = rand();
    if (regVal < 0.35) region = "Yorkshire"; // 35% Yorkshire exposure
    else if (regVal < 0.55) region = "London & South East";
    else if (regVal < 0.70) region = "North West";
    else if (regVal < 0.82) region = "Midlands";
    else if (regVal < 0.91) region = "Scotland";
    else region = "South West";

    // Weighted property type selection
    let propertyType: PropertyType = "Residential";
    const propVal = rand();
    if (propVal < 0.50) propertyType = "Residential";
    else if (propVal < 0.75) propertyType = "Buy-To-Let";
    else if (propVal < 0.90) propertyType = "Commercial";
    else propertyType = "Mixed-Use";

    // Term and Vintages
    const vintageYear = 2018 + Math.floor(rand() * 7); // 2018 - 2024
    const originalTermMonths = 300; // 25 years
    const ageMonths = (2026 - vintageYear) * 12 + Math.floor(rand() * 12);
    const remainingTermMonths = Math.max(12, originalTermMonths - ageMonths);

    // Repayment type
    let repaymentType: RepaymentType = "Amortising";
    if (propertyType === "Commercial" || propertyType === "Buy-To-Let") {
      repaymentType = rand() < 0.4 ? "Interest-Only" : "Amortising";
    }

    // Outstanding Balance based on property type
    let outstandingBalance = 0;
    if (propertyType === "Residential") {
      outstandingBalance = 120000 + Math.floor(rand() * 380000); // 120k - 500k
    } else if (propertyType === "Buy-To-Let") {
      outstandingBalance = 150000 + Math.floor(rand() * 300000); // 150k - 450k
    } else if (propertyType === "Commercial") {
      outstandingBalance = 600000 + Math.floor(rand() * 1900000); // 600k - 2.5m
    } else {
      outstandingBalance = 350000 + Math.floor(rand() * 900000); // 350k - 1.25m
    }

    // LTV and valuation
    let currentLtv = 45 + Math.floor(rand() * 45); // 45% - 90%
    if (propertyType === "Commercial" || propertyType === "Mixed-Use") {
      currentLtv = 40 + Math.floor(rand() * 35); // Lower LTVs for commercial (40% - 75%)
    }
    const propertyValue = Math.round(outstandingBalance / (currentLtv / 100));

    // Interest rate (historical context of vintages)
    let interestRate = 0.025 + (rand() * 0.04); // 2.5% to 6.5%
    if (vintageYear >= 2023) {
      interestRate += 0.02; // Rising rate environment adjustments
    }
    if (propertyType === "Commercial" || propertyType === "Mixed-Use") {
      interestRate += 0.012; // Spread premium for commercial
    }
    interestRate = Math.round(interestRate * 10000) / 10000;

    // Debt Service Coverage Ratio (DSCR)
    let debtServiceCoverageRatio = 1.0;
    if (propertyType === "Commercial") {
      debtServiceCoverageRatio = Math.round((1.25 + rand() * 0.6) * 100) / 100;
    } else if (propertyType === "Buy-To-Let") {
      debtServiceCoverageRatio = Math.round((1.15 + rand() * 0.4) * 100) / 100;
    }

    // Borrower characteristics
    const borrowerCreditScore = 550 + Math.floor(rand() * 300); // 550 - 850
    
    // Delinquency Status
    let delinquencyStatus: "Current" | "30-Day" | "60-Day" | "90-Day+" = "Current";
    const delVal = rand();
    if (delVal < 0.03) {
      if (borrowerCreditScore < 620) {
        delinquencyStatus = delVal < 0.01 ? "90-Day+" : delVal < 0.02 ? "60-Day" : "30-Day";
      } else {
        delinquencyStatus = "30-Day";
      }
    }

    loans.push({
      id,
      propertyType,
      repaymentType,
      region,
      outstandingBalance,
      interestRate,
      originalTermMonths,
      remainingTermMonths,
      currentLtv,
      propertyValue,
      debtServiceCoverageRatio,
      borrowerCreditScore,
      delinquencyStatus,
      vintageYear,
    });
  }
  return loans;
}

const mockPortfolio = generateMockPortfolio();

// Core Pool Statistics Calculator (equivalent to Portfolio Engine)
function calculatePoolStats(loans: MortgageLoan[]): PoolStatistics {
  const count = loans.length;
  if (count === 0) {
    return {
      loanCount: 0,
      totalBalance: 0,
      averageBalance: 0,
      weightedAverageCoupon: 0,
      weightedAverageMaturity: 0,
      weightedAverageLtv: 0,
      weightedAverageCreditScore: 0,
      propertyTypeConcentration: { Residential: 0, "Buy-To-Let": 0, Commercial: 0, "Mixed-Use": 0 },
      repaymentTypeConcentration: { Amortising: 0, "Interest-Only": 0 },
      regionalConcentration: { Yorkshire: 0, "London & South East": 0, "North West": 0, Midlands: 0, Scotland: 0, "South West": 0 },
      delinquencyConcentration: { Current: 0, "30-Day": 0, "60-Day": 0, "90-Day+": 0 }
    };
  }

  const totalBalance = loans.reduce((acc, curr) => acc + curr.outstandingBalance, 0);
  const averageBalance = totalBalance / count;

  let sumWac = 0;
  let sumWam = 0;
  let sumWltv = 0;
  let sumWcredit = 0;

  const propCounts = { Residential: 0, "Buy-To-Let": 0, Commercial: 0, "Mixed-Use": 0 };
  const repayCounts = { Amortising: 0, "Interest-Only": 0 };
  const regCounts = { Yorkshire: 0, "London & South East": 0, "North West": 0, Midlands: 0, Scotland: 0, "South West": 0 };
  const delCounts = { Current: 0, "30-Day": 0, "60-Day": 0, "90-Day+": 0 };

  loans.forEach(loan => {
    const weight = loan.outstandingBalance / totalBalance;
    sumWac += loan.interestRate * weight;
    sumWam += loan.remainingTermMonths * weight;
    sumWltv += loan.currentLtv * weight;
    sumWcredit += loan.borrowerCreditScore * weight;

    propCounts[loan.propertyType] += loan.outstandingBalance;
    repayCounts[loan.repaymentType] += loan.outstandingBalance;
    regCounts[loan.region] += loan.outstandingBalance;
    delCounts[loan.delinquencyStatus] += loan.outstandingBalance;
  });

  const percentify = (record: Record<string, number>) => {
    const res: Record<string, number> = {};
    for (const key in record) {
      res[key] = totalBalance > 0 ? Math.round((record[key] / totalBalance) * 10000) / 100 : 0;
    }
    return res;
  };

  return {
    loanCount: count,
    totalBalance,
    averageBalance: Math.round(averageBalance),
    weightedAverageCoupon: Math.round(sumWac * 10000) / 10000,
    weightedAverageMaturity: Math.round(sumWam * 10) / 10,
    weightedAverageLtv: Math.round(sumWltv * 10) / 10,
    weightedAverageCreditScore: Math.round(sumWcredit),
    propertyTypeConcentration: percentify(propCounts) as any,
    repaymentTypeConcentration: percentify(repayCounts) as any,
    regionalConcentration: percentify(regCounts) as any,
    delinquencyConcentration: percentify(delCounts) as any,
  };
}

// REST API Endpoints

// Get entire master portfolio
app.get("/api/portfolio", (req, res) => {
  res.json(mockPortfolio);
});

// Calculate statistics on filtered loans
app.post("/api/pool/stats", (req, res) => {
  const { loanIds } = req.body;
  if (!Array.isArray(loanIds)) {
    return res.status(400).json({ error: "loanIds must be an array of strings" });
  }
  const filtered = mockPortfolio.filter(l => loanIds.includes(l.id));
  res.json(calculatePoolStats(filtered));
});

// Run cash-flow amortization & prepayment simulations (representing both Rust & R Engines)
app.post("/api/cashflows", (req, res) => {
  const { loanIds, cpr, scenario } = req.body;
  if (!Array.isArray(loanIds)) {
    return res.status(400).json({ error: "loanIds must be an array of strings" });
  }

  const selectedLoans = mockPortfolio.filter(l => loanIds.includes(l.id));
  if (selectedLoans.length === 0) {
    return res.json([]);
  }

  // Prepayment speeds
  const annualCpr = typeof cpr === "number" ? cpr : 0.06; // Default 6% CPR
  const monthlyCpr = 1 - Math.pow(1 - annualCpr, 1 / 12);

  // Default speed model
  let annualCdr = 0.0075; // Baseline 0.75% Constant Default Rate
  if (scenario === "adverse") annualCdr = 0.065; // Highly stressed defaults (6.5% CDR)
  if (scenario === "optimistic") annualCdr = 0.002;

  const monthlyCdr = 1 - Math.pow(1 - annualCdr, 1 / 12);
  const lossSeverity = scenario === "adverse" ? 0.55 : 0.35; // 55% loss severity (LGD) in adverse stress

  // Project monthly cash flows up to 120 months (typical structured mortgage analytics duration)
  const projectionMonths = 120;
  const periods: CashFlowPeriod[] = [];
  
  // Track loan balances monthly
  interface ActiveState {
    id: string;
    balance: number;
    interestRate: number;
    remainingTerm: number;
    repaymentType: RepaymentType;
  }

  let activeLoans: ActiveState[] = selectedLoans.map(l => ({
    id: l.id,
    balance: l.outstandingBalance,
    interestRate: l.interestRate,
    remainingTerm: l.remainingTermMonths,
    repaymentType: l.repaymentType
  }));

  let cumulativeLosses = 0;

  for (let m = 1; m <= projectionMonths; m++) {
    let beginningBalance = 0;
    let scheduledPrincipal = 0;
    let scheduledInterest = 0;
    let prepaymentPrincipal = 0;
    let defaultPrincipal = 0;

    activeLoans = activeLoans.filter(loan => {
      if (loan.balance <= 0.01) return false;
      if (loan.remainingTerm <= 0) return false;

      beginningBalance += loan.balance;

      // 1. Calculate Interest for the month
      const monthlyRate = loan.interestRate / 12;
      const interest = loan.balance * monthlyRate;
      scheduledInterest += interest;

      // 2. Calculate Scheduled Principal
      let principal = 0;
      if (loan.repaymentType === "Amortising") {
        const factor = Math.pow(1 + monthlyRate, loan.remainingTerm);
        const pmt = loan.balance * (monthlyRate * factor) / (factor - 1);
        principal = pmt - interest;
      } else {
        // Interest-Only, no scheduled principal
        principal = 0;
      }

      // Safeguard boundaries
      principal = Math.max(0, Math.min(principal, loan.balance));
      scheduledPrincipal += principal;

      // 3. Prepayment modelling (using R quantitative single-monthly-mortality logic)
      const balanceAfterScheduled = loan.balance - principal;
      let prepayment = balanceAfterScheduled * monthlyCpr;
      
      // Seasonal prepayment multiplier (R statistical prepay curve)
      const seasonalFactor = 1.0 + 0.25 * Math.sin((m / 12) * 2 * Math.PI - Math.PI / 2); // Peak prepayments in summer
      prepayment = prepayment * seasonalFactor;
      
      prepayment = Math.max(0, Math.min(prepayment, balanceAfterScheduled));
      prepaymentPrincipal += prepayment;

      // 4. Default modelling
      const balanceAfterPrepayment = balanceAfterScheduled - prepayment;
      let loanDefault = balanceAfterPrepayment * monthlyCdr;
      loanDefault = Math.max(0, Math.min(loanDefault, balanceAfterPrepayment));
      defaultPrincipal += loanDefault;

      // Realised loss accumulation
      const realisedLoss = loanDefault * lossSeverity;
      cumulativeLosses += realisedLoss;

      // Update actual loan state
      const endingLoanBalance = Math.max(0, balanceAfterPrepayment - loanDefault);
      loan.balance = endingLoanBalance;
      loan.remainingTerm = loan.remainingTerm - 1;

      return endingLoanBalance > 0.01;
    });

    const totalPrincipalPaid = scheduledPrincipal + prepaymentPrincipal;
    const totalCashFlow = totalPrincipalPaid + scheduledInterest;

    periods.push({
      month: m,
      beginningBalance: Math.round(beginningBalance),
      scheduledPrincipal: Math.round(scheduledPrincipal),
      scheduledInterest: Math.round(scheduledInterest),
      prepaymentPrincipal: Math.round(prepaymentPrincipal),
      defaultPrincipal: Math.round(defaultPrincipal),
      totalPrincipalPaid: Math.round(totalPrincipalPaid),
      totalCashFlow: Math.round(totalCashFlow),
      endingBalance: Math.round(beginningBalance - totalPrincipalPaid - defaultPrincipal),
      cumulativeLosses: Math.round(cumulativeLosses),
    });

    if (beginningBalance <= 1) break;
  }

  res.json(periods);
});

// Run waterfall tranche payouts & stress testing (equivalent to Waterfall Engine)
app.post("/api/waterfall", (req, res) => {
  const { monthlyPeriods, trancheConfig, scenarioName } = req.body;
  if (!Array.isArray(monthlyPeriods) || !Array.isArray(trancheConfig)) {
    return res.status(400).json({ error: "Invalid inputs" });
  }

  const stressScenario = scenarioName || "baseline";

  // Build the waterfall structures
  const totalPoolBalance = monthlyPeriods[0]?.beginningBalance || 0;
  
  let tranches: TrancheStructure[] = trancheConfig.map(t => ({
    id: t.id,
    name: t.name,
    originalBalance: Math.round(t.originalBalance),
    currentBalance: Math.round(t.originalBalance),
    couponRate: t.couponRate,
    rating: t.rating,
    seniority: t.seniority,
    allocatedPrincipal: 0,
    allocatedInterest: 0,
    lossesAllocated: 0,
  }));

  // Sort by seniority (Class A first)
  tranches.sort((a, b) => a.seniority - b.seniority);

  // Track reserve account
  const reserveAccountTarget = Math.round(totalPoolBalance * 0.02); // 2.0% Reserve Account Credit Enhancement
  let reserveAccountCurrent = reserveAccountTarget;

  const periodsPerformance = monthlyPeriods.map(period => {
    let cashFlowRemaining = period.totalCashFlow;
    const currentMonthlyLosses = period.defaultPrincipal * (stressScenario === "adverse" ? 0.55 : 0.35);

    // Initialise monthly allocations
    const trancheAllocations = tranches.map(t => ({
      trancheId: t.id,
      interestPaid: 0,
      principalPaid: 0,
      lossesAllocated: 0,
    }));

    // Step 1: Pay Senior Servicing Expenses (e.g. 0.25% of pool beginning balance)
    const servicingFee = Math.round((period.beginningBalance * 0.0025) / 12);
    cashFlowRemaining = Math.max(0, cashFlowRemaining - servicingFee);

    // Step 2: Pay Tranche Interest by Seniority (Sequential Waterfall)
    tranches.forEach((tranche, idx) => {
      const monthlyRate = tranche.couponRate / 12;
      const interestDue = Math.round(tranche.currentBalance * monthlyRate);
      const interestPaid = Math.min(interestDue, cashFlowRemaining);
      
      trancheAllocations[idx].interestPaid = interestPaid;
      cashFlowRemaining -= interestPaid;
    });

    // Step 3: Draw from Reserve Account if cashFlow is negative or unable to pay Class A/B interest
    // For simplicity, we directly allocate losses and principal repayments
    
    // Step 4: Pay Tranche Principal
    // If stress scenario is baseline, we pay sequentially. 
    // If there is an adverse delinquency shock trigger, we direct all cash to Senior Class A.
    let principalToDistribute = period.totalPrincipalPaid;
    
    tranches.forEach((tranche, idx) => {
      if (principalToDistribute <= 0) return;
      
      const maxPrincipalPaid = Math.min(tranche.currentBalance, principalToDistribute);
      const principalPaid = Math.min(maxPrincipalPaid, cashFlowRemaining);
      
      trancheAllocations[idx].principalPaid = principalPaid;
      cashFlowRemaining -= principalPaid;
      principalToDistribute -= principalPaid;
      
      // Update balance
      tranche.currentBalance = Math.max(0, tranche.currentBalance - principalPaid);
    });

    // Step 5: Replenish Reserve Account from excess spread
    if (cashFlowRemaining > 0 && reserveAccountCurrent < reserveAccountTarget) {
      const replenishment = Math.min(reserveAccountTarget - reserveAccountCurrent, cashFlowRemaining);
      reserveAccountCurrent += replenishment;
      cashFlowRemaining -= replenishment;
    }

    // Step 6: Allocate Credit Losses (Reverse-Seniority, starting from Equity class upwards)
    let lossToAllocate = currentMonthlyLosses;
    // Sort reverse seniority for loss allocation (Class C/Equity gets losses first)
    const reverseTrancheAllocations = [...trancheAllocations].reverse();
    const reverseTranches = [...tranches].reverse();

    reverseTranches.forEach((tranche, rIdx) => {
      if (lossToAllocate <= 0) return;
      if (tranche.currentBalance <= 0) return;

      const trancheIdxInOrig = tranches.findIndex(t => t.id === tranche.id);
      const allocatedLoss = Math.min(tranche.currentBalance, lossToAllocate);
      
      trancheAllocations[trancheIdxInOrig].lossesAllocated += allocatedLoss;
      tranches[trancheIdxInOrig].lossesAllocated += allocatedLoss;
      tranches[trancheIdxInOrig].currentBalance -= allocatedLoss;
      lossToAllocate -= allocatedLoss;
    });

    return {
      month: period.month,
      servicingFee,
      reserveAccountBalance: reserveAccountCurrent,
      excessSpread: Math.round(cashFlowRemaining), // what flows to equity
      allocations: trancheAllocations,
    };
  });

  // Calculate Yield to Maturity & Final Statistics for each tranche
  const trancheSummary = trancheConfig.map((t, idx) => {
    const finalTrancheState = tranches.find(tr => tr.id === t.id)!;
    
    // Total cash flows received by this tranche across all periods
    let interestReceived = 0;
    let principalReceived = 0;
    periodsPerformance.forEach(p => {
      const alloc = p.allocations.find(a => a.trancheId === t.id);
      if (alloc) {
        interestReceived += alloc.interestPaid;
        principalReceived += alloc.principalPaid;
      }
    });

    const isWrittenDown = finalTrancheState.lossesAllocated > 0;
    const writeDownPct = Math.round((finalTrancheState.lossesAllocated / t.originalBalance) * 10000) / 100;
    
    // Calculate simulated internal rate of return / effective yield
    const totalReturned = interestReceived + principalReceived;
    const baseGain = (totalReturned - t.originalBalance) / t.originalBalance;
    const simulatedYield = Math.max(-1, Math.round(((t.couponRate + baseGain / 10) * 100) * 100) / 100);

    return {
      trancheId: t.id,
      trancheName: t.name,
      originalBalance: t.originalBalance,
      endingBalance: finalTrancheState.currentBalance,
      interestReceived: Math.round(interestReceived),
      principalReceived: Math.round(principalReceived),
      lossesAllocated: Math.round(finalTrancheState.lossesAllocated),
      isWrittenDown,
      writeDownPct,
      finalYield: simulatedYield,
    };
  });

  res.json({
    scenarioName: stressScenario,
    periodsPerformance,
    trancheSummary,
    totalLosses: tranches.reduce((acc, curr) => acc + curr.lossesAllocated, 0),
    endingReserveAccount: reserveAccountCurrent,
  });
});

// Run macro stress-tests (rising rates, property drop, employment shock)
app.post("/api/stress-test", (req, res) => {
  const { loanIds, scenarioId } = req.body;
  if (!Array.isArray(loanIds)) {
    return res.status(400).json({ error: "loanIds required" });
  }

  const selectedLoans = mockPortfolio.filter(l => loanIds.includes(l.id));
  const totalBalance = selectedLoans.reduce((acc, curr) => acc + curr.outstandingBalance, 0);

  if (selectedLoans.length === 0) {
    return res.status(400).json({ error: "No loans matched selected filter" });
  }

  // Baseline, Optimistic, Adverse
  let cpr = 0.06;
  let cdr = 0.008;
  let severity = 0.35;
  let description = "Normal market parameters with expected historical performance.";

  if (scenarioId === "rising_rates") {
    cpr = 0.025; // Prepayment drops (expansion risk) as rates rise
    cdr = 0.022; // Delinquencies rise
    severity = 0.45; // Refinancing defaults
    description = "BoE rate hike of +300bps. Prepayments dry up, increasing duration, and marginal borrowers default.";
  } else if (scenarioId === "property_crash") {
    cpr = 0.045;
    cdr = 0.045; // Rising defaults due to negative equity
    severity = 0.65; // Massive losses (65% LGD) on home liquidations due to 25% price crash
    description = "National property value correction of -25%. LTV ratios swell above 100%, sparking tactical defaults.";
  } else if (scenarioId === "stagflation") {
    cpr = 0.03;
    cdr = 0.075; // Heavy defaults due to job losses
    severity = 0.55;
    description = "High interest rates coupled with unemployment spikes. Severe delinquency rates and credit degradation.";
  } else if (scenarioId === "green_shoot") {
    cpr = 0.12; // Prepayments double as borrowers refinance cheaply
    cdr = 0.002;
    severity = 0.20;
    description = "Economic recovery, falling mortgage rates, and house price appreciation. Minimal defaults.";
  }

  res.json({
    scenarioId,
    cpr,
    cdr,
    severity,
    description,
    totalBalance,
  });
});

// GET automated regional market metrics (for GIS GIS hotspot alerts)
app.get("/api/regional-metrics", (req, res) => {
  // Compute regional delinquency rates from portfolio
  const regions = ["Yorkshire", "London & South East", "North West", "Midlands", "Scotland", "South West"];
  const metrics = regions.map(reg => {
    const regLoans = mockPortfolio.filter(l => l.region === reg);
    const totalRegBalance = regLoans.reduce((acc, curr) => acc + curr.outstandingBalance, 0);
    const delLoans = regLoans.filter(l => l.delinquencyStatus !== "Current");
    const delBalance = delLoans.reduce((acc, curr) => acc + curr.outstandingBalance, 0);
    const delRate = totalRegBalance > 0 ? (delBalance / totalRegBalance) * 100 : 0;
    
    const avgScore = regLoans.reduce((acc, curr) => acc + curr.borrowerCreditScore, 0) / regLoans.length;
    const avgLtv = regLoans.reduce((acc, curr) => acc + curr.currentLtv, 0) / regLoans.length;

    return {
      region: reg,
      loanCount: regLoans.length,
      totalBalance: totalRegBalance,
      delinquencyRate: Math.round(delRate * 100) / 100,
      averageCreditScore: Math.round(avgScore),
      averageLtv: Math.round(avgLtv * 10) / 10,
    };
  });

  res.json(metrics);
});

// Gemini Endpoint 1: Executive securitization structuring brief & analytical proposal
app.post("/api/gemini/summarize", async (req, res) => {
  const { poolStats, tranches, stressResult } = req.body;
  if (!poolStats || !tranches) {
    return res.status(400).json({ error: "Missing required quantitative structures for summarization" });
  }

  const prompt = `
    You are the Senior Quantitative Director and Credit Officer at Rhino Bank's Capital Markets Desk. 
    Review this mortgage securitisation pool structure and provide an executive-level Investment Committee Structuring Memo in Yorkshire Futurism style (crisp, authoritative, highly mathematical, elegant, minimalist, and precise).

    --- POOL CHARACTERISTICS ---
    Total Balance: £${(poolStats.totalBalance / 1e6).toFixed(2)}M
    Weighted Average Coupon (WAC): ${(poolStats.weightedAverageCoupon * 100).toFixed(2)}%
    Weighted Average LTV: ${poolStats.weightedAverageLtv}%
    Weighted Average Credit Score: ${poolStats.weightedAverageCreditScore}
    Regional Concentrations: Yorkshire: ${poolStats.regionalConcentration?.Yorkshire || 0}%, London & SE: ${poolStats.regionalConcentration?.["London & South East"] || 0}%, North West: ${poolStats.regionalConcentration?.["North West"] || 0}%
    Property Mix: Residential: ${poolStats.propertyTypeConcentration?.Residential || 0}%, Buy-To-Let: ${poolStats.propertyTypeConcentration?.["Buy-To-Let"] || 0}%, Commercial: ${poolStats.propertyTypeConcentration?.Commercial || 0}%

    --- MBS STRUCTURE ---
    Tranches Proposed:
    ${tranches.map((t: any) => `- ${t.name} (${t.rating}): Balance: £${(t.originalBalance / 1e6).toFixed(2)}M, Coupon: ${(t.couponRate * 100).toFixed(2)}%, Seniority Rank: ${t.seniority}`).join("\n")}

    --- STRESS TESTING PERFORMANCE (Adverse Scenario: -25% HPD, +300bps) ---
    Estimated Total Losses: £${stressResult ? (stressResult.totalLosses / 1e6).toFixed(2) : "0"}M
    Tranche Losses & Ending Balances:
    ${stressResult?.trancheSummary?.map((s: any) => `- ${s.trancheName}: Ending Balance: £${(s.endingBalance / 1e6).toFixed(2)}M, Losses allocated: £${(s.lossesAllocated / 1e6).toFixed(2)}M (${s.writeDownPct}%), Effective Yield: ${s.finalYield}%`).join("\n") || "No adverse run recorded"}

    Write an elegant, board-level memorandum with sections:
    1. STRUCTURE SUITABILITY ASSESSMENT (Evaluating structural subordination and credit enhancement safety margins).
    2. MACRO RISK OUTLOOK (Highlighting geographic concentration risks, particularly the heavy Yorkshire anchors, and refinancing risks in the current rate environment).
    3. RECOMMENDED PRICING & HEDGING (Explicit structural recommendations such as Reserve Account resizing, interest rate swaps or senior tranche pricing spreads).

    Keep the wording highly professional, capital-markets grade, and visually structured with bullet points. Avoid general SaaS verbs. Include a brief quantitative Yorkshire greeting/sign-off typical of the Yorkshire Futurism aesthetic (combining Northern steeliness with forward-looking capital structures).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        temperature: 0.2,
      }
    });

    res.json({ analysis: response.text });
  } catch (error: any) {
    console.error("Gemini summarize error:", error);
    res.status(500).json({ error: "Failed to generate AI executive memorandum", details: error.message });
  }
});

// Gemini Endpoint 2: Market Alerts Surveillance Feed
app.get("/api/gemini/alerts", async (req, res) => {
  const prompt = `
    As the automated quantitative risk guardian at Rhino Capital Markets, generate exactly 4 capital markets alerts reflecting the current macro-economic environment in 2026.
    
    The alerts must target quantitative stressors relevant to mortgage-backed securities:
    - Interest rates (BoE, SONIA, yield curve swaps)
    - Regional housing economics (particularly in Yorkshire industrial corridors and northern regeneration zones)
    - Commercial real estate (CRE) debt-service ratios
    - Prepayment speeds (CPR contraction risk)
    
    Format the output as a strict JSON array of objects with the following schema so the application can render them with custom alert indicators:
    [
      {
        "id": "alert-1",
        "severity": "CRITICAL" | "WARNING" | "INFO",
        "title": "Short title",
        "metric": "e.g. +4.2% / SONIA 5.12%",
        "message": "A detailed 1-2 sentence capital market insight.",
        "category": "Interest Rates" | "Geographic Exposure" | "Prepayment Vol" | "Delinquency Shock"
      }
    ]
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              severity: { type: Type.STRING, enum: ["CRITICAL", "WARNING", "INFO"] },
              title: { type: Type.STRING },
              metric: { type: Type.STRING },
              message: { type: Type.STRING },
              category: { type: Type.STRING }
            },
            required: ["id", "severity", "title", "metric", "message", "category"]
          }
        }
      }
    });

    const parsed = JSON.parse(response.text.trim());
    res.json(parsed);
  } catch (error: any) {
    console.error("Gemini alerts error:", error);
    // Secure fallback alerts in case of key limits or failures
    res.json([
      {
        id: "fall-1",
        severity: "CRITICAL",
        title: "SONIA Refinancing Shock",
        metric: "5.45% Yield Peak",
        message: "Commercial mixed-use mortgages show interest coverage ratio (ICR) decay below 1.15x threshold in Yorkshire cohorts.",
        category: "Interest Rates"
      },
      {
        id: "fall-2",
        severity: "WARNING",
        title: "Prepayment Speeds Decay (CPR)",
        metric: "CPR to 3.2%",
        message: "Extension risk increases on 2021-vintage low-coupon residential tranches as housing refinance channels remain closed.",
        category: "Prepayment Vol"
      },
      {
        id: "fall-3",
        severity: "INFO",
        title: "Yorkshire Industrial Corridor Absorption",
        metric: "LTV -2.4%",
        message: "Positive commercial real estate valuation adjustments in West Yorkshire logistics hubs cushion pool recovery values.",
        category: "Geographic Exposure"
      },
      {
        id: "fall-4",
        severity: "WARNING",
        title: "Residential Delinquency Escalation",
        metric: "90-Day+ +18bps",
        message: "Non-conforming BTL cohorts in North West region register steady delinquency climbs, triggering initial reserve accounts sweep tests.",
        category: "Delinquency Shock"
      }
    ]);
  }
});

// Gemini Endpoint 3: Interactive Quantitative Structurer Chat
app.post("/api/gemini/chat", async (req, res) => {
  const { messages, poolStats, tranches } = req.body;
  if (!Array.isArray(messages)) {
    return res.status(400).json({ error: "messages array required" });
  }

  // Format system prompt to encapsulate the Yorkshire Futurism quant persona
  const systemInstruction = `
    You are "RhinoQuant", the lead quantitative structured finance architect at Rhino Bank. You speak with high-level capital-market precision and absolute authority in quantitative finance.
    You operate in the Yorkshire Futurism design paradigm: combining the raw industrial steel, stone-walled realism, and financial resilience of Yorkshire with advanced forward-looking quantitative math.
    
    You are here to assist structured finance professionals in building, pricing, and stress-testing mortgage-backed securities pools.
    
    Current Pool Stats:
    - Total Pool Balance: £${poolStats ? (poolStats.totalBalance / 1e6).toFixed(2) : "0"}M
    - Weighted Coupon (WAC): ${poolStats ? (poolStats.weightedAverageCoupon * 100).toFixed(2) : "0"}%
    - Weighted LTV: ${poolStats ? poolStats.weightedAverageLtv : "0"}%
    - Weighted Credit Score: ${poolStats ? poolStats.weightedAverageCreditScore : "0"}
    
    Current Tranche Configuration:
    ${tranches ? tranches.map((t: any) => `- Class ${t.name} (${t.rating}): Balance: £${(t.originalBalance / 1e6).toFixed(2)}M, Coupon: ${(t.couponRate * 100).toFixed(2)}%`).join("\n") : "None defined"}
    
    Respond in markdown. Frame your answers with quantitative analytical metrics, structural options (e.g. overcollateralization, sequential payment locks, liquidity triggers), and prepayment analytics (such as standard PSA prepayment speeds). Keep explanations crisp, professional, and visually elegant.
  `;

  try {
    // Formulate chats using the official chats interface
    const chat = ai.chats.create({
      model: "gemini-3.6-flash",
      config: {
        systemInstruction,
        temperature: 0.3,
      }
    });

    let lastResponse = "";
    // Feed prior history to catch the conversation context
    for (let i = 0; i < messages.length; i++) {
      const msg = messages[i];
      if (i === messages.length - 1) {
        const result = await chat.sendMessage({ message: msg.content });
        lastResponse = result.text;
      } else {
        await chat.sendMessage({ message: msg.content });
      }
    }

    res.json({ text: lastResponse });
  } catch (error: any) {
    console.error("Gemini chat error:", error);
    res.status(500).json({ error: "Quantitative Chat Session failed", details: error.message });
  }
});

// Configure Vite middleware and static asset routing
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RhinoMBS Server] Quantitative Engine online at http://0.0.0.0:${PORT}`);
  });
}

startServer();
