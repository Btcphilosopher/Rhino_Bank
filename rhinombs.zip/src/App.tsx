/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Building2, 
  Layers, 
  TrendingUp, 
  Workflow, 
  ShieldAlert, 
  Globe, 
  BookOpen, 
  Activity, 
  Loader2, 
  LineChart,
  HelpCircle,
  Database
} from "lucide-react";
import { MortgageLoan, PoolStatistics, CashFlowPeriod } from "./types.js";
import DashboardOverview from "./components/DashboardOverview.js";
import MortgagePortfolio from "./components/MortgagePortfolio.js";
import PoolBuilder from "./components/PoolBuilder.js";
import CashFlowAnalytics from "./components/CashFlowAnalytics.js";
import WaterfallSimulation from "./components/WaterfallSimulation.js";
import StressTesting from "./components/StressTesting.js";
import GisAnalytics from "./components/GisAnalytics.js";
import BoardSummarizer from "./components/BoardSummarizer.js";

type TabId = "overview" | "portfolio" | "pool" | "cashflows" | "waterfall" | "stress" | "gis" | "board";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [portfolio, setPortfolio] = useState<MortgageLoan[]>([]);
  const [selectedLoanIds, setSelectedLoanIds] = useState<string[]>([]);
  const [activePoolStats, setActivePoolStats] = useState<PoolStatistics | null>(null);
  
  // Securitisation pool lock states
  const [isPoolLocked, setIsPoolLocked] = useState(false);
  const [lockedPoolName, setLockedPoolName] = useState("");

  // Calculation outputs
  const [monthlyPeriods, setMonthlyPeriods] = useState<CashFlowPeriod[]>([]);
  const [tranches, setTranches] = useState<any[]>([]);

  // Macro Stress Scenarios state: baseline, rising_rates, property_crash, stagflation, green_shoot
  const [currentScenario, setCurrentScenario] = useState<string>("baseline");

  const [loading, setLoading] = useState(true);

  // Load master portfolio on mount
  useEffect(() => {
    const loadPortfolio = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/portfolio");
        const data: MortgageLoan[] = await response.json();
        setPortfolio(data);
        
        // Select all Yorkshire region loans by default to create a premium, domain-appropriate initial state
        const yorkshireIds = data.filter(l => l.region === "Yorkshire").map(l => l.id);
        setSelectedLoanIds(yorkshireIds);
      } catch (error) {
        console.error("Failed to load portfolio:", error);
      } finally {
        setLoading(false);
      }
    };

    loadPortfolio();
  }, []);

  // Compute Pool Statistics dynamically on loan selection changes
  useEffect(() => {
    if (selectedLoanIds.length === 0) {
      setActivePoolStats(null);
      return;
    }

    const fetchStats = async () => {
      try {
        const response = await fetch("/api/pool/stats", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ loanIds: selectedLoanIds })
        });
        const data = await response.json();
        setActivePoolStats(data);
      } catch (error) {
        console.error("Failed to calculate pool statistics:", error);
      }
    };

    fetchStats();
  }, [selectedLoanIds]);

  const handleToggleSelectLoan = (id: string) => {
    if (isPoolLocked) return; // Cannot modify selection if pool is locked for securitisation
    setSelectedLoanIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleSelectMultiple = (ids: string[]) => {
    if (isPoolLocked) return;
    setSelectedLoanIds(ids);
  };

  const handleClearSelection = () => {
    if (isPoolLocked) return;
    setSelectedLoanIds([]);
  };

  const handleFilterYorkshireOnly = () => {
    if (isPoolLocked) return;
    const yorkshireIds = portfolio.filter(l => l.region === "Yorkshire").map(l => l.id);
    setSelectedLoanIds(yorkshireIds);
  };

  const handleLockPool = (poolName: string) => {
    setIsPoolLocked(true);
    setLockedPoolName(poolName);
  };

  const handleResetFilters = () => {
    setIsPoolLocked(false);
    setLockedPoolName("");
    const yorkshireIds = portfolio.filter(l => l.region === "Yorkshire").map(l => l.id);
    setSelectedLoanIds(yorkshireIds);
    setCurrentScenario("baseline");
  };

  // Safe stress scenario mapping
  const getSimScenario = () => {
    if (currentScenario === "stagflation") return "adverse";
    if (currentScenario === "property_crash") return "adverse";
    if (currentScenario === "green_shoot") return "optimistic";
    return "baseline";
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#1A1A1A] text-[#D1CEC4] flex flex-col items-center justify-center font-mono border-8 border-[#0D0D0D]">
        <Loader2 className="h-10 w-10 animate-spin text-[#B87333] mb-4" />
        <span className="text-sm tracking-widest text-[#B87333] font-serif italic">BOOTING RHINOMBS SECURE CORE...</span>
        <span className="text-[10px] text-[#8E9299] mt-2">Connecting to High-Performance Rust & R quantitative nodes</span>
      </div>
    );
  }

  const stats = activePoolStats || {
    loanCount: 0,
    totalBalance: 0,
    averageBalance: 0,
    weightedAverageCoupon: 0,
    weightedAverageMaturity: 0,
    weightedAverageLtv: 0,
    weightedAverageCreditScore: 0,
    propertyTypeConcentration: { Residential: 0, "Buy-To-Let": 0, Commercial: 0, "Mixed-Use": 0 },
    repaymentTypeConcentration: { Amortising: 0, "Interest-Only": 0 },
    regionalConcentration: { Yorkshire: 0, "London & South East": 0, "North West": 0, Midlands: 0, Scotland: 0, "South West": 0 },
    delinquencyConcentration: { Current: 0, "30-Day": 0, "60-Day": 0, "90-Day+": 0 }
  };

  // Convert scenario label for UI
  const getScenarioLabel = (sc: string) => {
    if (sc === "rising_rates") return "BoE Rate Hike (+300bps)";
    if (sc === "property_crash") return "National Property Crash (-25%)";
    if (sc === "stagflation") return "Stagflation Crisis";
    if (sc === "green_shoot") return "Green Shoots Recovery";
    return "Baseline Normal Parameters";
  };

  return (
    <div className="min-h-screen bg-[#1A1A1A] text-[#D1CEC4] flex flex-col font-sans antialiased border-4 border-[#0D0D0D]" id="rhino-mbs-app">
      {/* Platform Topbar Indicators */}
      <div className="bg-[#0A0A0A] border-b border-[#B87333]/30 px-6 py-2.5 flex flex-col sm:flex-row justify-between items-center text-[10px] font-mono text-[#8E9299] gap-2">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-[#B87333] animate-pulse"></span>
            System Node: <strong className="text-[#D1CEC4]">Active (Rust Core)</strong>
          </span>
          <span>BoE Rate: <strong className="text-[#D1CEC4]">5.00%</strong></span>
          <span>SONIA Peak: <strong className="text-[#D1CEC4]">5.05%</strong></span>
        </div>
        
        <div className="flex items-center gap-3">
          <span>Surveillance Engine: <strong className="text-[#B87333]">ACTIVE</strong></span>
          <span className="border-l border-[#B87333]/20 pl-3">Securitised series: <strong className="text-[#D1CEC4]">{isPoolLocked ? lockedPoolName : "Drafting"}</strong></span>
        </div>
      </div>

      {/* Main Structural Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6 flex flex-col justify-between">
        <div className="space-y-6">
          {/* Editorial Header */}
          <header className="flex flex-col md:flex-row justify-between items-start md:items-end border-b border-[#D1CEC4]/20 pb-6 gap-4">
            <div>
              <h1 className="text-3xl font-serif italic tracking-tighter text-[#B87333]">RhinoMBS</h1>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#8E9299] mt-0.5">Institutional Structured Finance</p>
              <h2 className="text-4xl font-serif italic text-[#D1CEC4] mt-4 leading-none">
                {isPoolLocked ? `Pool: ${lockedPoolName}` : "Active Securitisation Desk"}
              </h2>
              <p className="text-xs uppercase tracking-[0.2em] text-[#8E9299] mt-2">
                Residential Mortgage Securitisation / Yorkshire Sentinel Core
              </p>
            </div>
            <div className="text-left md:text-right font-mono">
              <p className="text-3xl font-bold text-[#B87333]">
                {new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP", maximumFractionDigits: 0 }).format(stats.totalBalance)}
              </p>
              <p className="text-[10px] text-[#8E9299] uppercase tracking-wider">Total Pool Balance</p>
            </div>
          </header>

          {/* Tabs Control Strip */}
          <div className="flex flex-wrap gap-1 bg-[#0A0A0A] p-1 rounded-lg border border-[#B87333]/30 font-mono text-xs overflow-x-auto" id="app-tabs">
            <button
              onClick={() => setActiveTab("overview")}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === "overview" 
                  ? "bg-[#B87333] text-[#0A0A0A] font-bold" 
                  : "text-[#8E9299] hover:text-[#D1CEC4]"
              }`}
              id="tab-overview"
            >
              <Activity className="h-3.5 w-3.5" />
              Executive Overview
            </button>

            <button
              onClick={() => setActiveTab("portfolio")}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === "portfolio" 
                  ? "bg-[#B87333] text-[#0A0A0A] font-bold" 
                  : "text-[#8E9299] hover:text-[#D1CEC4]"
              }`}
              id="tab-portfolio"
            >
              <Database className="h-3.5 w-3.5" />
              Mortgage Portfolio
            </button>

            <button
              onClick={() => setActiveTab("pool")}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === "pool" 
                  ? "bg-[#B87333] text-[#0A0A0A] font-bold" 
                  : "text-[#8E9299] hover:text-[#D1CEC4]"
              }`}
              id="tab-pool"
            >
              <Layers className="h-3.5 w-3.5" />
              MBS Pool Builder
            </button>

            <button
              onClick={() => setActiveTab("cashflows")}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === "cashflows" 
                  ? "bg-[#B87333] text-[#0A0A0A] font-bold" 
                  : "text-[#8E9299] hover:text-[#D1CEC4]"
              }`}
              id="tab-cashflows"
            >
              <LineChart className="h-3.5 w-3.5" />
              Prepayment Curves
            </button>

            <button
              onClick={() => setActiveTab("waterfall")}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === "waterfall" 
                  ? "bg-[#B87333] text-[#0A0A0A] font-bold" 
                  : "text-[#8E9299] hover:text-[#D1CEC4]"
              }`}
              id="tab-waterfall"
            >
              <Workflow className="h-3.5 w-3.5" />
              Sequential Waterfall
            </button>

            <button
              onClick={() => setActiveTab("stress")}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === "stress" 
                  ? "bg-[#B87333] text-[#0A0A0A] font-bold" 
                  : "text-[#8E9299] hover:text-[#D1CEC4]"
              }`}
              id="tab-stress"
            >
              <ShieldAlert className="h-3.5 w-3.5" />
              Stress Testing
            </button>

            <button
              onClick={() => setActiveTab("gis")}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === "gis" 
                  ? "bg-[#B87333] text-[#0A0A0A] font-bold" 
                  : "text-[#8E9299] hover:text-[#D1CEC4]"
              }`}
              id="tab-gis"
            >
              <Globe className="h-3.5 w-3.5" />
              GIS Hotspots
            </button>

            <button
              onClick={() => setActiveTab("board")}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === "board" 
                  ? "bg-[#B87333] text-[#0A0A0A] font-bold" 
                  : "text-[#8E9299] hover:text-[#D1CEC4]"
              }`}
              id="tab-board"
            >
              <BookOpen className="h-3.5 w-3.5" />
              Committee Advisor
            </button>
          </div>

          {/* Subheader Status Panel */}
          <div className="bg-[#0D0D0D] border border-[#B87333]/20 rounded-lg px-5 py-3 flex flex-col sm:flex-row justify-between items-center text-xs font-mono text-[#8E9299] gap-2">
            <span>Pool Name: <strong className="text-[#D1CEC4]">{isPoolLocked ? lockedPoolName : "UNLOCKED (DRAFT)"}</strong></span>
            <span>Securitised Collateral: <strong className="text-[#B87333]">{selectedLoanIds.length}</strong> loans</span>
            <span>Macro Stress: <strong className="text-[#B87333] uppercase">{getScenarioLabel(currentScenario)}</strong></span>
          </div>

          {/* Tab Content Router */}
          <div className="transition-all duration-300" id="tab-viewport">
            {activeTab === "overview" && (
              <DashboardOverview 
                portfolio={portfolio}
                stats={stats}
                onFilterYorkshire={handleFilterYorkshireOnly}
                onResetFilters={handleResetFilters}
                isYorkshireFiltered={selectedLoanIds.length < 250 && selectedLoanIds.every(id => portfolio.find(l => l.id === id)?.region === "Yorkshire")}
              />
            )}

            {activeTab === "portfolio" && (
              <MortgagePortfolio 
                portfolio={portfolio}
                selectedLoanIds={selectedLoanIds}
                onToggleSelectLoan={handleToggleSelectLoan}
                onSelectMultiple={handleSelectMultiple}
                onClearSelection={handleClearSelection}
              />
            )}

            {activeTab === "pool" && (
              <PoolBuilder 
                selectedLoanIds={selectedLoanIds}
                portfolio={portfolio}
                activePoolStats={stats}
                onLockPool={handleLockPool}
                isPoolLocked={isPoolLocked}
                lockedPoolName={lockedPoolName}
              />
            )}

            {activeTab === "cashflows" && (
              <CashFlowAnalytics 
                selectedLoanIds={selectedLoanIds}
                portfolio={portfolio}
                onCashFlowsCalculated={(periods) => setMonthlyPeriods(periods)}
                scenario={getSimScenario()}
              />
            )}

            {activeTab === "waterfall" && (
              <WaterfallSimulation 
                selectedLoanIds={selectedLoanIds}
                activePoolStats={stats}
                monthlyPeriods={monthlyPeriods}
                isPoolLocked={isPoolLocked}
                lockedPoolName={lockedPoolName}
                scenario={getSimScenario()}
                onTranchesCalculated={(t) => setTranches(t)}
              />
            )}

            {activeTab === "stress" && (
              <StressTesting 
                selectedLoanIds={selectedLoanIds}
                activePoolStats={stats}
                currentScenario={currentScenario}
                onSelectScenario={(scId) => setCurrentScenario(scId)}
                tranchesPerformance={tranches}
              />
            )}

            {activeTab === "gis" && (
              <GisAnalytics />
            )}

            {activeTab === "board" && (
              <BoardSummarizer 
                selectedLoanIds={selectedLoanIds}
                activePoolStats={stats}
                tranches={tranches}
                stressResult={{ trancheSummary: tranches, totalLosses: tranches.reduce((acc, curr) => acc + curr.lossesAllocated, 0) }}
              />
            )}
          </div>
        </div>

        {/* High-End Professional Footer */}
        <div className="border-t border-[#D1CEC4]/20 pt-4 mt-8 flex flex-col md:flex-row justify-between items-center text-[10px] font-mono text-[#8E9299] gap-2">
          <span>RhinoMBS Quantitative Engine v3.1.2 [Yorkshire Futurism build]</span>
          <span>Security Protocol: TLS 1.3 | RBAC Active</span>
          <span>© 2026 Rhino Bank Capital Markets Desk. All rights reserved.</span>
        </div>
      </div>
    </div>
  );
}
