/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PropertyType = "Residential" | "Buy-To-Let" | "Commercial" | "Mixed-Use";
export type RepaymentType = "Amortising" | "Interest-Only";
export type Region = "Yorkshire" | "London & South East" | "North West" | "Midlands" | "Scotland" | "South West";

export interface MortgageLoan {
  id: string;
  propertyType: PropertyType;
  repaymentType: RepaymentType;
  region: Region;
  outstandingBalance: number;
  interestRate: number; // in decimal, e.g. 0.0525 (5.25%)
  originalTermMonths: number;
  remainingTermMonths: number;
  currentLtv: number; // in percentage, e.g. 72.5
  propertyValue: number;
  debtServiceCoverageRatio: number; // e.g. 1.45 (primarily for commercial/BTL)
  borrowerCreditScore: number; // 300 - 850
  delinquencyStatus: "Current" | "30-Day" | "60-Day" | "90-Day+";
  vintageYear: number;
}

export interface PoolStatistics {
  loanCount: number;
  totalBalance: number;
  averageBalance: number;
  weightedAverageCoupon: number; // WAC
  weightedAverageMaturity: number; // WAM
  weightedAverageLtv: number;
  weightedAverageCreditScore: number;
  propertyTypeConcentration: Record<PropertyType, number>;
  repaymentTypeConcentration: Record<RepaymentType, number>;
  regionalConcentration: Record<Region, number>;
  delinquencyConcentration: Record<string, number>;
}

export interface PrepaymentScenario {
  id: string;
  name: string;
  baseCpr: number; // Annual Constant Prepayment Rate, e.g. 0.06 (6%)
  description: string;
  monthlyCprValues: number[]; // 12 values to simulate seasonal prepayment
}

export interface CashFlowPeriod {
  month: number;
  beginningBalance: number;
  scheduledPrincipal: number;
  scheduledInterest: number;
  prepaymentPrincipal: number;
  defaultPrincipal: number;
  totalPrincipalPaid: number;
  totalCashFlow: number;
  endingBalance: number;
  cumulativeLosses: number;
}

export interface TrancheStructure {
  id: string;
  name: string; // e.g., "Class A Senior", "Class B Mezzanine", "Class C Subordinated", "Equity / Residual"
  originalBalance: number;
  currentBalance: number;
  couponRate: number; // e.g. WAC + Spread or fixed
  rating: "AAA" | "AA" | "BBB" | "Unrated";
  seniority: number; // Lower is more senior, 1 = Senior
  allocatedPrincipal: number;
  allocatedInterest: number;
  lossesAllocated: number;
  yieldToMaturity?: number;
}

export interface WaterfallStructure {
  poolTotalBalance: number;
  reserveAccountTarget: number;
  reserveAccountCurrent: number;
  liquidityFacilityLimit: number;
  liquidityFacilityAvailable: number;
  tranches: TrancheStructure[];
}

export interface StressTestScenario {
  id: string;
  name: string;
  interestRateShockBps: number; // e.g. +300
  housePriceDeclinePct: number; // e.g. -25
  unemploymentRateDelta: number; // e.g. +4.5%
  baseDefaultRatePct: number; // e.g. 5% cumulative
  prepaymentSpeedMultiplier: number; // e.g. 1.5x CPR
  lossSeverityPct: number; // LGD, e.g. 45%
}

export interface SimulationResult {
  scenarioName: string;
  totalCashFlowReceived: number;
  totalInterestPaid: number;
  totalPrincipalPaid: number;
  totalLossesIncurred: number;
  tranchePerformance: Array<{
    trancheId: string;
    trancheName: string;
    originalBalance: number;
    endingBalance: number;
    interestReceived: number;
    principalReceived: number;
    lossesAllocated: number;
    isWrittenDown: boolean;
    finalYield: number;
  }>;
  monthlyPeriods: CashFlowPeriod[];
}
