/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { 
  Search, 
  Filter, 
  Check, 
  Plus, 
  X, 
  SlidersHorizontal, 
  FileSpreadsheet,
  AlertCircle
} from "lucide-react";
import { MortgageLoan, PropertyType, RepaymentType, Region } from "../types.js";

interface MortgagePortfolioProps {
  portfolio: MortgageLoan[];
  selectedLoanIds: string[];
  onToggleSelectLoan: (id: string) => void;
  onSelectMultiple: (ids: string[]) => void;
  onClearSelection: () => void;
}

export default function MortgagePortfolio({
  portfolio,
  selectedLoanIds,
  onToggleSelectLoan,
  onSelectMultiple,
  onClearSelection,
}: MortgagePortfolioProps) {
  // Filters state
  const [regionFilter, setRegionFilter] = useState<string>("");
  const [propertyTypeFilter, setPropertyTypeFilter] = useState<string>("");
  const [repaymentTypeFilter, setRepaymentTypeFilter] = useState<string>("");
  const [delinquencyFilter, setDelinquencyFilter] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  
  // High-density sliders
  const [maxLtv, setMaxLtv] = useState<number>(100);
  const [minCredit, setMinCredit] = useState<number>(550);

  const filteredLoans = useMemo(() => {
    return portfolio.filter(loan => {
      if (regionFilter && loan.region !== regionFilter) return false;
      if (propertyTypeFilter && loan.propertyType !== propertyTypeFilter) return false;
      if (repaymentTypeFilter && loan.repaymentType !== repaymentTypeFilter) return false;
      if (delinquencyFilter && loan.delinquencyStatus !== delinquencyFilter) return false;
      if (loan.currentLtv > maxLtv) return false;
      if (loan.borrowerCreditScore < minCredit) return false;
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          loan.id.toLowerCase().includes(query) ||
          loan.region.toLowerCase().includes(query) ||
          loan.propertyType.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [portfolio, regionFilter, propertyTypeFilter, repaymentTypeFilter, delinquencyFilter, maxLtv, minCredit, searchQuery]);

  const selectAllFiltered = () => {
    const ids = filteredLoans.map(l => l.id);
    onSelectMultiple(ids);
  };

  const selectNoneFiltered = () => {
    const ids = filteredLoans.map(l => l.id);
    const remaining = selectedLoanIds.filter(id => !ids.includes(id));
    onSelectMultiple(remaining);
  };

  const formatGBP = (num: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      maximumFractionDigits: 0
    }).format(num);
  };

  return (
    <div className="space-y-6" id="mortgage-portfolio">
      {/* Portfolio Controls Block */}
      <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-5 rounded space-y-4">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-[#D1CEC4] font-mono">
            <SlidersHorizontal className="h-4 w-4 text-[#B87333]" />
            QUANTITATIVE PORTFOLIO FILTER SELECTION
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#8E9299] font-mono">
              Selected: <strong className="text-[#B87333]">{selectedLoanIds.length}</strong> / {portfolio.length} loans
            </span>
            <button
              onClick={selectAllFiltered}
              className="px-3 py-1 text-xs font-mono bg-[#1A1A1A] text-[#D1CEC4] hover:bg-[#B87333]/10 rounded border border-[#B87333]/30"
              id="btn-select-filtered"
            >
              Select Match ({filteredLoans.length})
            </button>
            <button
              onClick={onClearSelection}
              className="px-3 py-1 text-xs font-mono border border-[#7F1D1D] text-[#EF4444] bg-[#251212] hover:bg-[#3B1313] rounded"
              id="btn-clear-selection"
            >
              Clear All
            </button>
          </div>
        </div>

        {/* Dynamic Filters Form */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search ID */}
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-3.5 w-3.5 text-[#8E9299]" />
            </span>
            <input
              type="text"
              placeholder="Search Loan ID / Region..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-[#1A1A1A] border border-[#D1CEC4]/15 rounded text-[#D1CEC4] focus:outline-none focus:border-[#B87333] font-mono"
              id="input-search-loans"
            />
          </div>

          {/* Region */}
          <select
            value={regionFilter}
            onChange={(e) => setRegionFilter(e.target.value)}
            className="w-full px-3 py-1.5 text-xs bg-[#1A1A1A] border border-[#D1CEC4]/15 rounded text-[#D1CEC4] focus:outline-none focus:border-[#B87333] font-mono"
            id="select-region"
          >
            <option value="">-- Region (All) --</option>
            <option value="Yorkshire">Yorkshire (⚓ Theme Core)</option>
            <option value="London & South East">London & SE</option>
            <option value="North West">North West</option>
            <option value="Midlands">Midlands</option>
            <option value="Scotland">Scotland</option>
            <option value="South West">South West</option>
          </select>

          {/* Property Type */}
          <select
            value={propertyTypeFilter}
            onChange={(e) => setPropertyTypeFilter(e.target.value)}
            className="w-full px-3 py-1.5 text-xs bg-[#1A1A1A] border border-[#D1CEC4]/15 rounded text-[#D1CEC4] focus:outline-none focus:border-[#B87333] font-mono"
            id="select-property-type"
          >
            <option value="">-- Property Mix (All) --</option>
            <option value="Residential">Residential</option>
            <option value="Buy-To-Let">Buy-To-Let (BTL)</option>
            <option value="Commercial">Commercial</option>
            <option value="Mixed-Use">Mixed-Use</option>
          </select>

          {/* Repayment Type */}
          <select
            value={repaymentTypeFilter}
            onChange={(e) => setRepaymentTypeFilter(e.target.value)}
            className="w-full px-3 py-1.5 text-xs bg-[#1A1A1A] border border-[#D1CEC4]/15 rounded text-[#D1CEC4] focus:outline-none focus:border-[#B87333] font-mono"
            id="select-repayment-type"
          >
            <option value="">-- Amortisation Type --</option>
            <option value="Amortising">Repayment (Amortising)</option>
            <option value="Interest-Only">Interest-Only</option>
          </select>

          {/* Delinquency */}
          <select
            value={delinquencyFilter}
            onChange={(e) => setDelinquencyFilter(e.target.value)}
            className="w-full px-3 py-1.5 text-xs bg-[#1A1A1A] border border-[#D1CEC4]/15 rounded text-[#D1CEC4] focus:outline-none focus:border-[#B87333] font-mono"
            id="select-delinquency"
          >
            <option value="">-- Delinquency (All) --</option>
            <option value="Current">Current / Non-Arrears</option>
            <option value="30-Day">30-Day Default</option>
            <option value="60-Day">60-Day Default</option>
            <option value="90-Day+">90-Day+ Serious Delinquency</option>
          </select>
        </div>

        {/* Sliders Layer */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-[#D1CEC4]/10">
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-mono text-[#8E9299]">
              <span>Max Loan-to-Value (LTV) Cap</span>
              <span className="text-[#D1CEC4] font-bold">{maxLtv}%</span>
            </div>
            <input 
              type="range" 
              min="40" 
              max="100" 
              value={maxLtv} 
              onChange={(e) => setMaxLtv(Number(e.target.value))}
              className="w-full h-1 bg-[#1A1A1A] rounded appearance-none cursor-pointer accent-[#B87333]"
              id="slider-max-ltv"
            />
          </div>

          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-mono text-[#8E9299]">
              <span>Min Borrower Credit Score</span>
              <span className="text-[#D1CEC4] font-bold">{minCredit}</span>
            </div>
            <input 
              type="range" 
              min="550" 
              max="850" 
              value={minCredit} 
              onChange={(e) => setMinCredit(Number(e.target.value))}
              className="w-full h-1 bg-[#1A1A1A] rounded appearance-none cursor-pointer accent-[#B87333]"
              id="slider-min-credit"
            />
          </div>
        </div>
      </div>

      {/* Grid Table */}
      <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 rounded overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse" id="portfolio-table">
            <thead>
              <tr className="bg-[#0A0A0A] text-[#8E9299] font-mono text-[10px] uppercase tracking-wider border-b border-[#D1CEC4]/10">
                <th className="py-3 px-4 w-12 text-center">Select</th>
                <th className="py-3 px-4">Loan ID</th>
                <th className="py-3 px-4">Region</th>
                <th className="py-3 px-4">Property Type</th>
                <th className="py-3 px-4 text-right">Outstanding Bal</th>
                <th className="py-3 px-4 text-right">Rate (WAC)</th>
                <th className="py-3 px-4 text-right">LTV</th>
                <th className="py-3 px-4 text-right">Credit Score</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D1CEC4]/10 text-xs">
              {filteredLoans.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-[#8E9299] font-mono">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <AlertCircle className="h-6 w-6 text-[#B87333]" />
                      No mortgages matched the query parameters.
                    </div>
                  </td>
                </tr>
              ) : (
                filteredLoans.slice(0, 50).map((loan) => {
                  const isSelected = selectedLoanIds.includes(loan.id);
                  return (
                    <tr 
                      key={loan.id} 
                      className={`hover:bg-[#B87333]/10 transition-colors cursor-pointer ${
                        isSelected ? "bg-[#B87333]/5" : ""
                      }`}
                      onClick={() => onToggleSelectLoan(loan.id)}
                    >
                      <td className="py-2.5 px-4 text-center" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onToggleSelectLoan(loan.id)}
                          className={`h-4.5 w-4.5 rounded border flex items-center justify-center transition-all ${
                            isSelected 
                              ? "bg-[#B87333] border-[#B87333] text-[#0A0A0A]" 
                              : "border-[#4B5563] hover:border-[#B87333]"
                          }`}
                          id={`chk-${loan.id}`}
                        >
                          {isSelected && <Check className="h-3 w-3 stroke-[3]" />}
                        </button>
                      </td>
                      <td className="py-2.5 px-4 font-mono font-bold text-[#D1CEC4]">{loan.id}</td>
                      <td className="py-2.5 px-4 text-[#8E9299]">{loan.region}</td>
                      <td className="py-2.5 px-4">
                        <span className="px-2 py-0.5 rounded-full bg-[#1A1A1A] text-[#D1CEC4] border border-[#D1CEC4]/10 text-[10px]">
                          {loan.propertyType}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono font-bold text-[#D1CEC4]">
                        {formatGBP(loan.outstandingBalance)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono text-[#B87333]">
                        {(loan.interestRate * 100).toFixed(2)}%
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono text-[#8E9299]">{loan.currentLtv}%</td>
                      <td className="py-2.5 px-4 text-right font-mono text-[#D1CEC4]">{loan.borrowerCreditScore}</td>
                      <td className="py-2.5 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                          loan.delinquencyStatus === "Current"
                            ? "bg-[#064E3B]/80 text-[#10B981]"
                            : loan.delinquencyStatus === "30-Day"
                            ? "bg-[#B87333]/20 text-[#B87333]"
                            : "bg-[#7F1D1D] text-[#EF4444]"
                        }`}>
                          {loan.delinquencyStatus}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        
        {filteredLoans.length > 50 && (
          <div className="py-3 px-4 bg-[#0A0A0A] border-t border-[#D1CEC4]/10 text-center text-xs text-[#8E9299] font-mono">
            Showing first 50 results. Complete dataset contains <strong>{filteredLoans.length}</strong> matching mortgages.
          </div>
        )}
      </div>
    </div>
  );
}
