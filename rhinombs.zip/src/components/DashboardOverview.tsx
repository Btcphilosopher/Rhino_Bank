/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { 
  TrendingUp, 
  AlertTriangle, 
  FileSpreadsheet, 
  Compass, 
  MapPin, 
  Activity, 
  DollarSign, 
  ShieldAlert, 
  Wrench,
  Loader2,
  RefreshCw
} from "lucide-react";
import { MortgageLoan, PoolStatistics } from "../types.js";

interface Alert {
  id: string;
  severity: "CRITICAL" | "WARNING" | "INFO";
  title: string;
  metric: string;
  message: string;
  category: string;
}

interface DashboardOverviewProps {
  portfolio: MortgageLoan[];
  stats: PoolStatistics;
  onFilterYorkshire: () => void;
  onResetFilters: () => void;
  isYorkshireFiltered: boolean;
}

export default function DashboardOverview({
  portfolio,
  stats,
  onFilterYorkshire,
  onResetFilters,
  isYorkshireFiltered
}: DashboardOverviewProps) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loadingAlerts, setLoadingAlerts] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchAlerts = async () => {
    setLoadingAlerts(true);
    try {
      const response = await fetch("/api/gemini/alerts");
      const data = await response.json();
      setAlerts(data);
    } catch (error) {
      console.error("Failed to load alerts:", error);
    } finally {
      setLoadingAlerts(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, []);

  const triggerAlertRefresh = async () => {
    setRefreshing(true);
    await fetchAlerts();
    setRefreshing(false);
  };

  // Capital markets aesthetic formatters
  const formatGBP = (num: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      maximumFractionDigits: 0
    }).format(num);
  };

  const criticalCount = alerts.filter(a => a.severity === "CRITICAL").length;
  const warningCount = alerts.filter(a => a.severity === "WARNING").length;

  return (
    <div className="space-y-8" id="dashboard-overview">
      {/* Platform Header Block in Yorkshire Futurism Styling */}
      <div className="border-b border-[#D1CEC4]/20 pb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[#B87333] text-xs font-mono tracking-widest uppercase">
            <span className="h-1.5 w-1.5 rounded-full bg-[#B87333] animate-pulse"></span>
            Surveillance Dashboard & Risk Sentinels
          </div>
          <h2 className="text-2xl font-serif italic text-[#D1CEC4] tracking-tight mt-1">
            Active Pool Intelligence
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onFilterYorkshire}
            className={`px-4 py-2 text-xs font-mono rounded border transition-all ${
              isYorkshireFiltered
                ? "bg-[#B87333] border-[#B87333] text-[#0A0A0A] font-bold"
                : "border-[#B87333]/30 text-[#D1CEC4] hover:border-[#B87333] hover:bg-[#B87333]/5"
            }`}
            id="btn-filter-yorkshire"
          >
            Yorkshire Focus Pool
          </button>
          {isYorkshireFiltered && (
            <button
              onClick={onResetFilters}
              className="px-3 py-2 text-xs font-mono text-[#8E9299] hover:text-[#D1CEC4] border border-[#D1CEC4]/20 rounded"
              id="btn-reset-filters"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Main KPI Bar - Refined Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" id="kpi-grid">
        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 border-l-2 border-l-[#B87333] p-5 rounded flex flex-col justify-between">
          <div>
            <span className="text-xs font-mono uppercase text-[#8E9299] tracking-wider">Total Pool Balance</span>
            <div className="text-2xl font-bold text-[#D1CEC4] mt-1 tracking-tight">
              {formatGBP(stats.totalBalance)}
            </div>
          </div>
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#D1CEC4]/10 text-xs text-[#8E9299]">
            <span>Active Loans: <strong className="text-[#D1CEC4]">{stats.loanCount}</strong></span>
            <span>Avg: {formatGBP(stats.averageBalance)}</span>
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 border-l-2 border-l-[#B87333] p-5 rounded flex flex-col justify-between">
          <div>
            <span className="text-xs font-mono uppercase text-[#8E9299] tracking-wider">Weighted Avg Coupon (WAC)</span>
            <div className="text-2xl font-bold text-[#B87333] mt-1 tracking-tight">
              {(stats.weightedAverageCoupon * 100).toFixed(3)}%
            </div>
          </div>
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#D1CEC4]/10 text-xs text-[#8E9299]">
            <span>Benchmark SONIA: <strong className="text-[#D1CEC4]">5.05%</strong></span>
            <span>Spread: +{(stats.weightedAverageCoupon * 100 - 5.05).toFixed(2)}%</span>
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 border-l-2 border-l-[#8E9299] p-5 rounded flex flex-col justify-between">
          <div>
            <span className="text-xs font-mono uppercase text-[#8E9299] tracking-wider">Weighted Avg LTV</span>
            <div className="text-2xl font-bold text-[#D1CEC4] mt-1 tracking-tight">
              {stats.weightedAverageLtv}%
            </div>
          </div>
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#D1CEC4]/10 text-xs text-[#8E9299]">
            <span>Original Val: <strong className="text-[#D1CEC4]">£{((stats.totalBalance / (stats.weightedAverageLtv / 100)) / 1e6).toFixed(1)}M</strong></span>
            <span>Healthy Margin</span>
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 border-l-2 border-l-[#8E9299] p-5 rounded flex flex-col justify-between">
          <div>
            <span className="text-xs font-mono uppercase text-[#8E9299] tracking-wider">Weighted Avg Credit Score</span>
            <div className="text-2xl font-bold text-[#D1CEC4] mt-1 tracking-tight">
              {stats.weightedAverageCreditScore}
            </div>
          </div>
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#D1CEC4]/10 text-xs text-[#8E9299]">
            <span>Rating Quality: <strong className="text-[#10B981]">Prime Core</strong></span>
            <span>Range: 550 - 850</span>
          </div>
        </div>
      </div>

      {/* Market surveillance alerts feed (Gemini-powered alerts) */}
      <div className="bg-[#0A0A0A] border border-[#B87333]/30 rounded p-6">
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#D1CEC4]/20">
          <div className="flex items-center gap-2">
            <ShieldAlert className="text-[#B87333] h-5 w-5" />
            <div>
              <h2 className="text-md font-serif italic text-[#D1CEC4] tracking-wider">Gemini Capital Markets Surveillance</h2>
              <p className="text-xs text-[#8E9299]">Live risk sentinel parsing SONIA yield curve anomalies & regional stress factors.</p>
            </div>
          </div>
          <button
            onClick={triggerAlertRefresh}
            disabled={refreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#8E9299] hover:text-[#D1CEC4] border border-[#D1CEC4]/20 hover:border-[#B87333] rounded transition-all font-mono"
            id="btn-refresh-alerts"
          >
            {refreshing ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
            Refresh
          </button>
        </div>

        {loadingAlerts ? (
          <div className="flex flex-col items-center justify-center py-12 text-[#8E9299] text-sm">
            <Loader2 className="h-8 w-8 animate-spin text-[#B87333] mb-3" />
            Simulating quantitative risk vectors...
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="surveillance-alerts-feed">
            {alerts.map(alert => (
              <div 
                key={alert.id}
                className={`p-4 rounded border ${
                  alert.severity === "CRITICAL" 
                    ? "bg-[#251212] border-[#7F1D1D]" 
                    : alert.severity === "WARNING"
                    ? "bg-[#20140F] border-[#B87333]/50"
                    : "bg-[#0D0D0D] border-[#D1CEC4]/15"
                } flex flex-col justify-between`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-1 font-mono">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      alert.severity === "CRITICAL" 
                        ? "bg-[#7F1D1D] text-[#D1CEC4]" 
                        : alert.severity === "WARNING"
                        ? "bg-[#B87333] text-[#0A0A0A]"
                        : "bg-[#1E3A8A] text-[#D1CEC4]"
                    }`}>
                      {alert.severity}
                    </span>
                    <span className="text-[#8E9299]">{alert.category}</span>
                  </div>
                  <h3 className="text-sm font-bold text-[#D1CEC4] mt-2">{alert.title}</h3>
                  <p className="text-xs text-[#8E9299] mt-1 line-clamp-2 leading-relaxed font-serif italic">
                    "{alert.message}"
                  </p>
                </div>
                <div className="mt-3 pt-3 border-t border-[#ffffff05] flex items-center justify-between text-xs font-mono">
                  <span className="text-[#8E9299]">Sentinel Metric</span>
                  <span className="text-[#D1CEC4] font-bold">{alert.metric}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Portfolio Concentrations Grid - Yorkshire Stone themed */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="concentrations-grid">
        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-5 rounded">
          <h3 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider mb-4 border-b border-[#D1CEC4]/10 pb-2">
            Geographic Exposure
          </h3>
          <div className="space-y-3">
            {Object.entries(stats.regionalConcentration).map(([region, pct]) => (
              <div key={region} className="text-xs">
                <div className="flex justify-between text-[#8E9299] mb-1 font-mono">
                  <span className={region === "Yorkshire" ? "text-[#D1CEC4] font-bold" : ""}>
                    {region} {region === "Yorkshire" && "⚓"}
                  </span>
                  <span>{pct.toFixed(2)}%</span>
                </div>
                <div className="h-1.5 w-full bg-[#1A1A1A] rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${region === "Yorkshire" ? "bg-[#B87333]" : "bg-[#4B5563]"}`}
                    style={{ width: `${pct}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-5 rounded">
          <h3 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider mb-4 border-b border-[#D1CEC4]/10 pb-2">
            Property Typologies
          </h3>
          <div className="space-y-3">
            {Object.entries(stats.propertyTypeConcentration).map(([type, pct]) => (
              <div key={type} className="text-xs">
                <div className="flex justify-between text-[#8E9299] mb-1 font-mono">
                  <span>{type}</span>
                  <span>{pct.toFixed(2)}%</span>
                </div>
                <div className="h-1.5 w-full bg-[#1A1A1A] rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-[#B87333] rounded-full"
                    style={{ width: `${pct}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-5 rounded">
          <h3 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider mb-4 border-b border-[#D1CEC4]/10 pb-2">
            Delinquency Ledger
          </h3>
          <div className="space-y-3">
            {Object.entries(stats.delinquencyConcentration).map(([status, pct]) => (
              <div key={status} className="text-xs">
                <div className="flex justify-between text-[#8E9299] mb-1 font-mono">
                  <span>{status}</span>
                  <span className={status !== "Current" && pct > 0 ? "text-[#EF4444]" : ""}>{pct.toFixed(2)}%</span>
                </div>
                <div className="h-1.5 w-full bg-[#1A1A1A] rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      status === "Current" 
                        ? "bg-[#10B981]" 
                        : status === "30-Day"
                        ? "bg-[#B87333]"
                        : "bg-[#EF4444]"
                    }`}
                    style={{ width: `${pct}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
