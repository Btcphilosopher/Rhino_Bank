/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  FolderPlus, 
  Layers, 
  Percent, 
  Sparkles, 
  TrendingUp, 
  CheckCircle,
  Database,
  ArrowRight,
  Loader2,
  Lock
} from "lucide-react";
import { PoolStatistics, MortgageLoan } from "../types.js";

interface PoolBuilderProps {
  selectedLoanIds: string[];
  portfolio: MortgageLoan[];
  activePoolStats: PoolStatistics;
  onLockPool: (poolId: string) => void;
  isPoolLocked: boolean;
  lockedPoolName: string;
}

export default function PoolBuilder({
  selectedLoanIds,
  portfolio,
  activePoolStats,
  onLockPool,
  isPoolLocked,
  lockedPoolName
}: PoolBuilderProps) {
  const [poolName, setPoolName] = useState("Rhino Yorkshire Securitisation 2026-1");
  const [loadingStats, setLoadingStats] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  const formatGBP = (num: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      maximumFractionDigits: 0
    }).format(num);
  };

  const handleSecuritize = () => {
    if (selectedLoanIds.length === 0) return;
    onLockPool(poolName);
    setSuccessMsg("Securitisation pool successfully constructed and structured. Transmitting to waterfall engine...");
    setTimeout(() => setSuccessMsg(""), 5000);
  };

  const selectedCount = selectedLoanIds.length;
  const totalBalance = activePoolStats.totalBalance;

  return (
    <div className="space-y-6" id="pool-builder">
      {/* Pool Header Setup */}
      <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded">
        <h2 className="text-sm font-mono uppercase text-[#B87333] tracking-wider mb-2 flex items-center gap-2">
          <Layers className="h-4 w-4" />
          Securitisation Pool Construction Suite
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end mt-4">
          <div className="space-y-1 md:col-span-2">
            <label className="text-xs text-[#8E9299] font-mono block">MBS Issuance Series Name</label>
            <input
              type="text"
              value={poolName}
              onChange={(e) => setPoolName(e.target.value)}
              disabled={isPoolLocked}
              className="w-full px-3 py-2 text-sm bg-[#1A1A1A] border border-[#D1CEC4]/15 rounded text-[#D1CEC4] font-mono focus:outline-none focus:border-[#B87333] disabled:opacity-60"
              id="input-pool-name"
            />
          </div>
          
          <div>
            <button
              onClick={handleSecuritize}
              disabled={selectedCount === 0 || isPoolLocked}
              className={`w-full py-2 px-4 rounded font-mono text-xs font-bold transition-all flex items-center justify-center gap-2 border ${
                isPoolLocked 
                  ? "bg-[#0A0A0A] border-[#B87333]/30 text-[#8E9299] cursor-not-allowed"
                  : selectedCount > 0
                  ? "bg-[#B87333] border-[#B87333] text-[#0A0A0A] hover:bg-[#A05C23]"
                  : "bg-[#1A1A1A] border-[#D1CEC4]/15 text-[#8E9299] cursor-not-allowed"
              }`}
              id="btn-issue-mbs"
            >
              {isPoolLocked ? <Lock className="h-3.5 w-3.5" /> : <FolderPlus className="h-3.5 w-3.5" />}
              {isPoolLocked ? "MBS Structured & Locked" : `Structure & Issue MBS (${selectedCount} Loans)`}
            </button>
          </div>
        </div>

        {successMsg && (
          <div className="mt-4 p-3 bg-[#064E3B]/80 border border-[#059669] rounded text-xs text-[#D1CEC4] flex items-center gap-2 font-mono">
            <CheckCircle className="h-4 w-4 text-[#10B981]" />
            {successMsg}
          </div>
        )}
      </div>

      {/* Pool Stats and Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="pool-breakdown">
        {/* Statistics Sheet */}
        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded lg:col-span-2 space-y-6">
          <h3 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center justify-between">
            <span>Pool Portfolio Statistics</span>
            <span className="text-[#B87333]">Ready for Securitisation</span>
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            <div>
              <span className="text-[10px] uppercase font-mono text-[#8E9299] tracking-wider block">Total Pool Loans</span>
              <span className="text-xl font-bold text-[#D1CEC4] mt-1 block">{selectedCount}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono text-[#8E9299] tracking-wider block">Aggregate Balance</span>
              <span className="text-xl font-bold text-[#B87333] mt-1 block">{formatGBP(totalBalance)}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono text-[#8E9299] tracking-wider block">Average Principal</span>
              <span className="text-xl font-bold text-[#D1CEC4] mt-1 block">{formatGBP(activePoolStats.averageBalance)}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono text-[#8E9299] tracking-wider block">Weighted Coupon (WAC)</span>
              <span className="text-xl font-bold text-[#B87333] mt-1 block">{(activePoolStats.weightedAverageCoupon * 100).toFixed(3)}%</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono text-[#8E9299] tracking-wider block">Weighted Maturity (WAM)</span>
              <span className="text-xl font-bold text-[#D1CEC4] mt-1 block">{activePoolStats.weightedAverageMaturity} Months</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono text-[#8E9299] tracking-wider block">Weighted Average LTV</span>
              <span className="text-xl font-bold text-[#D1CEC4] mt-1 block">{activePoolStats.weightedAverageLtv}%</span>
            </div>
          </div>

          <div className="p-4 bg-[#0A0A0A] border border-[#D1CEC4]/10 rounded">
            <h4 className="text-[11px] uppercase font-mono text-[#8E9299] mb-2 tracking-wider">Lending Quality Profile</h4>
            <div className="flex justify-between items-center text-xs font-mono">
              <span>Weighted Avg FICO / Credit Score</span>
              <span className="text-[#10B981] font-bold">{activePoolStats.weightedAverageCreditScore}</span>
            </div>
            <div className="w-full bg-[#1A1A1A] h-2 rounded mt-2 overflow-hidden">
              <div 
                className="bg-[#10B981] h-full rounded"
                style={{ width: `${((activePoolStats.weightedAverageCreditScore - 550) / 300) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Issuance Parameters */}
        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded space-y-6">
          <h3 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center gap-1.5">
            <Database className="h-4 w-4 text-[#B87333]" />
            MBS Tranche Structure Model
          </h3>

          <p className="text-xs text-[#8E9299] leading-relaxed">
            By default, the platform structures this pool into a highly robust institutional sequential-pay waterfall backed by a <strong className="text-[#B87333]">2.0% Reserve Account</strong>.
          </p>

          <div className="space-y-3">
            <div className="p-3 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded flex justify-between items-center text-xs">
              <div>
                <div className="font-bold text-[#D1CEC4] font-mono">Class A (Senior)</div>
                <div className="text-[10px] text-[#8E9299]">Rating: AAA • Size: 80%</div>
              </div>
              <div className="text-right font-mono text-[#B87333] font-bold">
                {formatGBP(totalBalance * 0.8)}
              </div>
            </div>

            <div className="p-3 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded flex justify-between items-center text-xs">
              <div>
                <div className="font-bold text-[#D1CEC4] font-mono">Class B (Mezzanine)</div>
                <div className="text-[10px] text-[#8E9299]">Rating: AA • Size: 10%</div>
              </div>
              <div className="text-right font-mono text-[#D1CEC4]">
                {formatGBP(totalBalance * 0.1)}
              </div>
            </div>

            <div className="p-3 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded flex justify-between items-center text-xs">
              <div>
                <div className="font-bold text-[#D1CEC4] font-mono">Class C (Subordinated)</div>
                <div className="text-[10px] text-[#8E9299]">Rating: BBB • Size: 6%</div>
              </div>
              <div className="text-right font-mono text-[#D1CEC4]">
                {formatGBP(totalBalance * 0.06)}
              </div>
            </div>

            <div className="p-3 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded flex justify-between items-center text-xs">
              <div>
                <div className="font-bold text-[#8E9299] font-mono">Equity (Residual)</div>
                <div className="text-[10px] text-[#8E9299]">Rating: Unrated • Size: 4%</div>
              </div>
              <div className="text-right font-mono text-[#8E9299]">
                {formatGBP(totalBalance * 0.04)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
