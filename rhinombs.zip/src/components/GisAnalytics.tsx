/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  MapPin, 
  TrendingUp, 
  ShieldAlert, 
  Globe, 
  Map, 
  Info,
  Loader2,
  Percent,
  CheckCircle
} from "lucide-react";

interface RegionalMetric {
  region: string;
  loanCount: number;
  totalBalance: number;
  delinquencyRate: number;
  averageCreditScore: number;
  averageLtv: number;
}

export default function GisAnalytics() {
  const [metrics, setMetrics] = useState<RegionalMetric[]>([]);
  const [selectedRegion, setSelectedRegion] = useState<string>("Yorkshire");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMetrics = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/regional-metrics");
        const data = await response.json();
        setMetrics(data);
      } catch (error) {
        console.error("Failed to load regional metrics:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMetrics();
  }, []);

  const selectedData = metrics.find(m => m.region === selectedRegion);

  const formatGBP = (num: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      maximumFractionDigits: 0
    }).format(num);
  };

  // Coordinates and shapes for UK/Yorkshire schematic map
  const regionsSvg = [
    { name: "Yorkshire", path: "M 150 180 L 190 190 L 180 230 L 140 220 Z", color: "rgba(184, 115, 51, 0.45)", activeColor: "rgba(184, 115, 51, 0.8)" },
    { name: "London & South East", path: "M 170 270 L 210 270 L 200 310 L 165 300 Z", color: "rgba(75, 85, 99, 0.4)", activeColor: "rgba(75, 85, 99, 0.8)" },
    { name: "North West", path: "M 110 160 L 145 170 L 135 210 L 100 200 Z", color: "rgba(75, 85, 99, 0.4)", activeColor: "rgba(75, 85, 99, 0.8)" },
    { name: "Midlands", path: "M 130 220 L 175 225 L 165 265 L 120 260 Z", color: "rgba(75, 85, 99, 0.4)", activeColor: "rgba(75, 85, 99, 0.8)" },
    { name: "Scotland", path: "M 90 40 L 150 50 L 140 130 L 80 120 Z", color: "rgba(75, 85, 99, 0.3)", activeColor: "rgba(75, 85, 99, 0.7)" },
    { name: "South West", path: "M 80 280 L 120 275 L 110 320 L 70 310 Z", color: "rgba(75, 85, 99, 0.35)", activeColor: "rgba(75, 85, 99, 0.75)" },
  ];

  return (
    <div className="space-y-6" id="gis-analytics">
      {/* GIS Header */}
      <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-5 rounded flex flex-col md:flex-row justify-between items-center">
        <div>
          <h3 className="text-sm font-mono uppercase text-[#B87333] tracking-wider flex items-center gap-1.5">
            <Globe className="h-4.5 w-4.5" />
            Geographic Information Systems (GIS) Surveillance Map
          </h3>
          <p className="text-xs text-[#8E9299] mt-1 max-w-xl">
            Interactive geographical concentration visualizer mapping mortgage exposure and default hotspots across major UK lending blocks.
          </p>
        </div>
        <div className="text-xs text-[#8E9299] font-mono border border-[#D1CEC4]/10 px-3 py-1.5 rounded bg-[#1A1A1A]">
          Anchor Exposure: <strong className="text-[#B87333]">Yorkshire Industrial Corridors</strong>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 text-[#8E9299] bg-[#0D0D0D] border border-[#D1CEC4]/10 rounded">
          <Loader2 className="h-8 w-8 animate-spin text-[#B87333] mb-3" />
          Querying geographical concentration vectors...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="gis-grid">
          {/* Schematic SVG Map */}
          <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded flex flex-col items-center justify-center space-y-4 lg:col-span-2">
            <span className="text-[10px] font-mono uppercase text-[#8E9299] tracking-widest block self-start">
              UK Regional Collateral Density Choropleth (Interactive)
            </span>

            <div className="relative w-full max-w-[400px] h-[360px] flex items-center justify-center">
              {/* Interactive Vector Map */}
              <svg viewBox="50 30 200 300" className="w-full h-full text-slate-800">
                <g stroke="#0D0D0D" strokeWidth="1.5" cursor="pointer">
                  {regionsSvg.map((r) => {
                    const isActive = selectedRegion === r.name;
                    const regionMetric = metrics.find(m => m.region === r.name);
                    const isHotspot = regionMetric ? regionMetric.delinquencyRate > 1.5 : false;
                    
                    // High-end dynamic color fills based on delinquency rates or selected status
                    let fill = r.color;
                    if (isActive) {
                      fill = isHotspot ? "rgba(239, 68, 68, 0.75)" : "rgba(184, 115, 51, 0.8)";
                    } else if (isHotspot) {
                      fill = "rgba(220, 38, 38, 0.3)";
                    }

                    return (
                      <path
                        key={r.name}
                        d={r.path}
                        fill={fill}
                        onClick={() => setSelectedRegion(r.name)}
                        className="transition-all duration-300 hover:opacity-90"
                      />
                    );
                  })}
                </g>

                {/* Map Labels */}
                <text x="142" y="85" fill="#8E9299" fontSize="8" fontFamily="monospace">Scotland</text>
                <text x="100" y="185" fill="#8E9299" fontSize="8" fontFamily="monospace">North West</text>
                <text x="155" y="210" fill="#D1CEC4" fontSize="9" fontWeight="bold" fontFamily="monospace">Yorkshire ⚓</text>
                <text x="135" y="245" fill="#8E9299" fontSize="8" fontFamily="monospace">Midlands</text>
                <text x="168" y="295" fill="#8E9299" fontSize="8" fontFamily="monospace">London & SE</text>
                <text x="75" y="300" fill="#8E9299" fontSize="8" fontFamily="monospace">South West</text>
              </svg>
            </div>
            
            <div className="flex gap-4 text-[10px] font-mono text-[#8E9299] self-start border-t border-[#D1CEC4]/10 pt-3 w-full">
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[#B87333]"></span>
                <span>Active Target</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[#EF4444]"></span>
                <span>Delinquency Hotspot (&gt;1.5%)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[#4B5563]"></span>
                <span>Diversified Collateral</span>
              </div>
            </div>
          </div>

          {/* Regional Details Card */}
          <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded space-y-6 flex flex-col justify-between">
            {selectedData ? (
              <div className="space-y-4">
                <div className="border-b border-[#D1CEC4]/10 pb-3">
                  <span className="text-[10px] font-mono text-[#B87333] tracking-widest uppercase block">Selected Sector</span>
                  <h4 className="text-lg font-bold text-[#D1CEC4] font-mono mt-1 flex items-center gap-2">
                    <MapPin className="h-4.5 w-4.5 text-[#B87333]" />
                    {selectedData.region}
                  </h4>
                </div>

                <div className="space-y-4 font-mono text-xs">
                  <div>
                    <span className="text-[10px] uppercase text-[#8E9299] block">Collateral Outstanding</span>
                    <span className="text-lg font-bold text-[#D1CEC4]">{formatGBP(selectedData.totalBalance)}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-[10px] uppercase text-[#8E9299] block">Loan Count</span>
                      <span className="text-sm font-bold text-[#D1CEC4]">{selectedData.loanCount}</span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase text-[#8E9299] block">Weighted Avg LTV</span>
                      <span className="text-sm font-bold text-[#D1CEC4]">{selectedData.averageLtv}%</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded bg-[#1A1A1A] border border-[#D1CEC4]/10 space-y-2">
                    <span className="text-[10px] uppercase text-[#8E9299] block">Credit & Risk metrics</span>
                    
                    <div className="flex justify-between items-center">
                      <span>Delinquency Rate</span>
                      <span className={`font-bold ${selectedData.delinquencyRate > 1.5 ? "text-[#EF4444]" : "text-[#10B981]"}`}>
                        {selectedData.delinquencyRate.toFixed(2)}%
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span>Avg Credit Score</span>
                      <span className="font-bold text-[#D1CEC4]">{selectedData.averageCreditScore}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center text-xs text-[#8E9299] font-mono py-12">
                Select a geographical sector to view concentrated metrics.
              </div>
            )}

            <div className="p-4 bg-[#2D160A] border border-[#B87333]/30 rounded text-xs leading-relaxed text-[#8E9299] mt-4 flex items-start gap-2.5">
              <Info className="h-4 w-4 text-[#B87333] shrink-0 mt-0.5" />
              <span>
                <strong>Yorkshire Sentinel Note:</strong> As Rhino Bank is heavily anchored in Northern manufacturing and industrial logistic corridors, Yorkshire serves as our core portfolio stabilizer.
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
