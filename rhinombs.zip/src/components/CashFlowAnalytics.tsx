/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  LineChart,
  Line
} from "recharts";
import { 
  Activity, 
  Gauge, 
  TrendingUp, 
  ArrowRight, 
  Calendar,
  Loader2,
  Sliders
} from "lucide-react";
import { CashFlowPeriod, MortgageLoan } from "../types.js";

interface CashFlowAnalyticsProps {
  selectedLoanIds: string[];
  portfolio: MortgageLoan[];
  onCashFlowsCalculated: (periods: CashFlowPeriod[]) => void;
  scenario: "baseline" | "adverse" | "optimistic";
}

export default function CashFlowAnalytics({
  selectedLoanIds,
  portfolio,
  onCashFlowsCalculated,
  scenario
}: CashFlowAnalyticsProps) {
  const [cpr, setCpr] = useState<number>(0.06); // Default 6% CPR
  const [periods, setPeriods] = useState<CashFlowPeriod[]>([]);
  const [loading, setLoading] = useState(false);

  // Fetch projected cash flows from full-stack simulation server
  useEffect(() => {
    if (selectedLoanIds.length === 0) {
      setPeriods([]);
      return;
    }

    const fetchCashFlows = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/cashflows", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            loanIds: selectedLoanIds,
            cpr: cpr,
            scenario: scenario
          })
        });
        const data = await response.json();
        setPeriods(data);
        onCashFlowsCalculated(data);
      } catch (error) {
        console.error("Failed to fetch projected cash flows:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCashFlows();
  }, [selectedLoanIds, cpr, scenario]);

  const formatGBP = (num: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      maximumFractionDigits: 0
    }).format(num);
  };

  const totalInterest = periods.reduce((acc, curr) => acc + curr.scheduledInterest, 0);
  const totalPrincipal = periods.reduce((acc, curr) => acc + curr.totalPrincipalPaid, 0);
  const totalDefaults = periods.reduce((acc, curr) => acc + curr.defaultPrincipal, 0);

  // Downsample to keep chart rendering smooth in complex environments
  const chartData = periods.filter((_, idx) => idx % 2 === 0);

  return (
    <div className="space-y-6" id="cashflow-analytics">
      {/* Interactive Controls Panel */}
      <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-5 rounded flex flex-col md:flex-row gap-6 items-center justify-between">
        <div className="space-y-1">
          <h3 className="text-sm font-mono uppercase text-[#B87333] tracking-wider flex items-center gap-1.5">
            <Gauge className="h-4 w-4" />
            Constant Prepayment Rate (CPR) Engine
          </h3>
          <p className="text-xs text-[#8E9299] max-w-xl">
            Modelling Single Monthly Mortality (SMM) over the collateral pools. Real-time shifts simulate seasonal refinancing vectors.
          </p>
        </div>

        <div className="flex items-center gap-4 w-full md:w-auto min-w-[280px]">
          <span className="text-xs font-mono text-[#8E9299] whitespace-nowrap">Annual CPR Rate</span>
          <input 
            type="range" 
            min="0" 
            max="30" 
            step="1"
            value={cpr * 100} 
            onChange={(e) => setCpr(Number(e.target.value) / 100)}
            className="w-full h-1 bg-[#1A1A1A] rounded appearance-none cursor-pointer accent-[#B87333]"
            id="slider-cpr"
          />
          <span className="text-sm font-mono text-[#B87333] font-bold w-12 text-right">{(cpr * 100).toFixed(0)}%</span>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 text-[#8E9299] bg-[#0D0D0D] border border-[#D1CEC4]/10 rounded">
          <Loader2 className="h-8 w-8 animate-spin text-[#B87333] mb-3" />
          Processing pool cash-flow amortization streams...
        </div>
      ) : periods.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-[#8E9299] bg-[#0D0D0D] border border-[#D1CEC4]/10 rounded font-mono text-xs">
          Select loans in the Mortgage Portfolio tab to begin modelling cash-flow curves.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="cashflow-visuals">
          {/* Main Area Chart */}
          <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded lg:col-span-2 space-y-4">
            <h4 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center justify-between">
              <span>Monthly Projected Distributions (P&I)</span>
              <span className="text-[#B87333]">Sentinel Analytics Ledger</span>
            </h4>

            <div className="h-[320px] w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorInterest" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#1E3A8A" stopOpacity={0.6}/>
                      <stop offset="95%" stopColor="#1E3A8A" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorPrincipal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#B87333" stopOpacity={0.6}/>
                      <stop offset="95%" stopColor="#B87333" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#D1CEC4]/10" />
                  <XAxis dataKey="month" stroke="#8E9299" fontSize={10} tickLine={false} />
                  <YAxis stroke="#8E9299" fontSize={10} tickFormatter={(val) => `${(val / 1000).toFixed(0)}k`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0A0A0A", borderColor: "#B87333/30" }}
                    labelStyle={{ color: "#D1CEC4", fontFamily: "monospace" }}
                    itemStyle={{ color: "#8E9299" }}
                    formatter={(value) => [formatGBP(value as number), ""]}
                  />
                  <Legend wrapperStyle={{ fontSize: "11px", fontFamily: "monospace" }} />
                  <Area type="monotone" dataKey="scheduledInterest" name="Scheduled Interest" stroke="#3B82F6" fillOpacity={1} fill="url(#colorInterest)" />
                  <Area type="monotone" dataKey="scheduledPrincipal" name="Scheduled Principal" stroke="#B87333" fillOpacity={1} fill="url(#colorPrincipal)" />
                  <Area type="monotone" dataKey="prepaymentPrincipal" name="Prepayments" stroke="#B87333" fillOpacity={0.15} fill="#B87333" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Core Analytics Card */}
          <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded space-y-6 flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center gap-1.5">
                <TrendingUp className="h-4 w-4 text-[#B87333]" />
                Pool Amortisation Summary
              </h4>

              <div className="space-y-4 mt-4">
                <div>
                  <span className="text-[10px] uppercase font-mono text-[#8E9299] block">Aggregate Cash Inflows</span>
                  <span className="text-2xl font-bold text-[#D1CEC4]">{formatGBP(totalInterest + totalPrincipal)}</span>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div>
                    <span className="text-[10px] uppercase font-mono text-[#8E9299] block">Total Principal Paid</span>
                    <span className="text-md font-bold text-[#B87333]">{formatGBP(totalPrincipal)}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-mono text-[#8E9299] block">Total Interest Earned</span>
                    <span className="text-md font-bold text-[#D1CEC4]">{formatGBP(totalInterest)}</span>
                  </div>
                </div>

                <div className="p-3 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded space-y-1">
                  <span className="text-[10px] uppercase font-mono text-[#8E9299] block">CPR Default Risks</span>
                  <div className="flex justify-between items-center text-xs font-mono">
                    <span>Expected Liquidations</span>
                    <span className="text-[#EF4444] font-bold">{formatGBP(totalDefaults)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Line Chart of Outstanding Pool Balance */}
            <div className="space-y-2 mt-4 pt-4 border-t border-[#D1CEC4]/10">
              <span className="text-[10px] uppercase font-mono text-[#8E9299] block">Collateral Amortisation Curve</span>
              <div className="h-[120px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#D1CEC4]/10" vertical={false} />
                    <XAxis dataKey="month" hide />
                    <YAxis hide />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#0A0A0A", borderColor: "#B87333/30" }}
                      formatter={(value) => [formatGBP(value as number), "Balance"]}
                    />
                    <Line type="monotone" dataKey="endingBalance" stroke="#B87333" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
