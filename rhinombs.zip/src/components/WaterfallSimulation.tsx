/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Workflow, 
  Layers, 
  Percent, 
  Activity, 
  ArrowDownCircle, 
  ShieldCheck, 
  AlertTriangle,
  Loader2,
  RefreshCw,
  Coins
} from "lucide-react";
import { CashFlowPeriod, PoolStatistics, WaterfallStructure, TrancheStructure } from "../types.js";

interface WaterfallSimulationProps {
  selectedLoanIds: string[];
  activePoolStats: PoolStatistics;
  monthlyPeriods: CashFlowPeriod[];
  isPoolLocked: boolean;
  lockedPoolName: string;
  scenario: "baseline" | "adverse" | "optimistic";
  onTranchesCalculated?: (tranches: any[]) => void;
}

export default function WaterfallSimulation({
  selectedLoanIds,
  activePoolStats,
  monthlyPeriods,
  isPoolLocked,
  lockedPoolName,
  scenario,
  onTranchesCalculated
}: WaterfallSimulationProps) {
  const [tranches, setTranches] = useState<any[]>([]);
  const [reserveAccount, setReserveAccount] = useState(0);
  const [excessSpread, setExcessSpread] = useState(0);
  const [totalLosses, setTotalLosses] = useState(0);
  const [loading, setLoading] = useState(false);

  // Set default initial tranche configurations
  const defaultTrancheConfig = [
    { id: "tranche-a", name: "Class A (Senior)", sizePct: 0.80, couponRate: 0.048, rating: "AAA", seniority: 1 },
    { id: "tranche-b", name: "Class B (Mezzanine)", sizePct: 0.10, couponRate: 0.055, rating: "AA", seniority: 2 },
    { id: "tranche-c", name: "Class C (Subordinated)", sizePct: 0.06, couponRate: 0.068, rating: "BBB", seniority: 3 },
    { id: "tranche-eq", name: "Equity (Residual)", sizePct: 0.04, couponRate: 0.095, rating: "Unrated", seniority: 4 },
  ];

  useEffect(() => {
    if (monthlyPeriods.length === 0) {
      setTranches([]);
      return;
    }

    const calculateWaterfall = async () => {
      setLoading(true);
      try {
        const totalPoolSize = activePoolStats.totalBalance;
        
        // Formulate the structures dynamically based on total pool size
        const tranchePayload = defaultTrancheConfig.map(t => ({
          id: t.id,
          name: t.name,
          originalBalance: totalPoolSize * t.sizePct,
          couponRate: t.couponRate,
          rating: t.rating,
          seniority: t.seniority
        }));

        const response = await fetch("/api/waterfall", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            monthlyPeriods: monthlyPeriods,
            trancheConfig: tranchePayload,
            scenarioName: scenario
          })
        });

        const data = await response.json();
        setTranches(data.trancheSummary || []);
        setReserveAccount(data.endingReserveAccount || 0);
        setTotalLosses(data.totalLosses || 0);

        // Calculate aggregate excess spread (total remaining cash flows)
        const totalRemaining = data.periodsPerformance?.reduce((acc: number, curr: any) => acc + curr.excessSpread, 0) || 0;
        setExcessSpread(totalRemaining);

        if (onTranchesCalculated) {
          onTranchesCalculated(data.trancheSummary || []);
        }
      } catch (error) {
        console.error("Failed to run waterfall calculations:", error);
      } finally {
        setLoading(false);
      }
    };

    calculateWaterfall();
  }, [monthlyPeriods, scenario]);

  const formatGBP = (num: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      maximumFractionDigits: 0
    }).format(num);
  };

  const getRatingColor = (rating: string) => {
    if (rating === "AAA") return "text-[#10B981] border-[#10B981]/30 bg-[#0D2E1F]";
    if (rating === "AA") return "text-[#3B82F6] border-[#3B82F6]/30 bg-[#0F1E3A]";
    if (rating === "BBB") return "text-[#B87333] border-[#B87333]/30 bg-[#2D160A]";
    return "text-[#8E9299] border-[#D1CEC4]/15 bg-[#1A1A1A]";
  };

  return (
    <div className="space-y-6" id="waterfall-simulation">
      <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-5 rounded flex flex-col md:flex-row gap-4 justify-between items-center">
        <div>
          <h3 className="text-sm font-mono uppercase text-[#B87333] tracking-wider flex items-center gap-1.5">
            <Workflow className="h-4 w-4" />
            Structured Watermark Allocation Model
          </h3>
          <p className="text-xs text-[#8E9299] mt-1 max-w-xl">
            Sequential principal paydown waterfall with dynamic reverse-seniority loss allocations. Tracks interest coverage triggers in real-time.
          </p>
        </div>
        <div className="flex gap-4 font-mono text-xs text-right">
          <div>
            <span className="text-[#8E9299] block text-[10px] uppercase">Reserve Fund Credit Enhancement</span>
            <span className="text-[#D1CEC4] font-bold">{formatGBP(reserveAccount)}</span>
          </div>
          <div>
            <span className="text-[#8E9299] block text-[10px] uppercase">Aggregate Excess Spread</span>
            <span className="text-[#10B981] font-bold">{formatGBP(excessSpread)}</span>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 text-[#8E9299] bg-[#0D0D0D] border border-[#D1CEC4]/10 rounded">
          <Loader2 className="h-8 w-8 animate-spin text-[#B87333] mb-3" />
          Simulating hierarchical watermarks...
        </div>
      ) : tranches.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-[#8E9299] bg-[#0D0D0D] border border-[#D1CEC4]/10 rounded font-mono text-xs">
          Amortisation schedules must be generated under the Cash Flow tab before simulation.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="waterfall-tranches-breakdown">
          {/* Tranche Allocation Visualizer */}
          <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded lg:col-span-2 space-y-6">
            <h4 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center justify-between">
              <span>Tranche Payment Seniority Ladder</span>
              <span className="text-[#B87333]">Sequential Amortisation Flow</span>
            </h4>

            {/* Simulated flow visual diagram */}
            <div className="space-y-4">
              {tranches.map((tranche, idx) => {
                const payoffProgress = tranche.originalBalance > 0 
                  ? ((tranche.originalBalance - tranche.endingBalance) / tranche.originalBalance) * 100 
                  : 0;
                const lossPct = tranche.originalBalance > 0 
                  ? (tranche.lossesAllocated / tranche.originalBalance) * 100 
                  : 0;

                return (
                  <div key={tranche.trancheId} className="p-4 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded space-y-3">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                      <div className="flex items-center gap-2.5">
                        <span className="h-5 w-5 bg-[#B87333] text-[#0A0A0A] flex items-center justify-center rounded-full text-xs font-mono font-bold">
                          {idx + 1}
                        </span>
                        <div>
                          <span className="text-sm font-bold text-[#D1CEC4] font-mono">{tranche.trancheName}</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ml-2 ${getRatingColor(tranche.rating)}`}>
                            {tranche.rating}
                          </span>
                        </div>
                      </div>
                      <div className="text-left sm:text-right font-mono text-xs">
                        <span className="text-[#8E9299]">Coupon: </span>
                        <span className="text-[#B87333] font-bold">{(defaultTrancheConfig[idx].couponRate * 100).toFixed(2)}%</span>
                        <span className="text-[#8E9299] ml-3">Yield to Mat: </span>
                        <span className={`font-bold ${tranche.finalYield < 0 ? "text-[#EF4444]" : "text-[#10B981]"}`}>
                          {tranche.finalYield.toFixed(2)}%
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono pt-2 border-t border-[#ffffff05]">
                      <div>
                        <span className="text-[#8E9299] text-[10px] block">Original Balance</span>
                        <span className="text-[#D1CEC4]">{formatGBP(tranche.originalBalance)}</span>
                      </div>
                      <div>
                        <span className="text-[#8E9299] text-[10px] block">Ending Balance</span>
                        <span className="text-[#D1CEC4]">{formatGBP(tranche.endingBalance)}</span>
                      </div>
                      <div>
                        <span className="text-[#8E9299] text-[10px] block">Interest Received</span>
                        <span className="text-[#10B981]">{formatGBP(tranche.interestReceived)}</span>
                      </div>
                      <div>
                        <span className="text-[#8E9299] text-[10px] block">Credit Losses Allocated</span>
                        <span className={`font-bold ${tranche.lossesAllocated > 0 ? "text-[#EF4444]" : "text-[#8E9299]"}`}>
                          {formatGBP(tranche.lossesAllocated)}
                        </span>
                      </div>
                    </div>

                    {/* Progress bars of repayment and losses */}
                    <div className="space-y-1 pt-1">
                      <div className="flex justify-between text-[10px] font-mono text-[#8E9299]">
                        <span>Paydown: {payoffProgress.toFixed(1)}%</span>
                        {tranche.lossesAllocated > 0 && <span className="text-[#EF4444]">Write-down: {lossPct.toFixed(1)}%</span>}
                      </div>
                      <div className="h-2 w-full bg-[#1A1A1A] rounded overflow-hidden flex">
                        <div className="bg-[#B87333] h-full" style={{ width: `${payoffProgress}%` }}></div>
                        <div className="bg-[#EF4444] h-full animate-pulse" style={{ width: `${lossPct}%` }}></div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Enhancement and Triggers Ledger */}
          <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded space-y-6">
            <h4 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center gap-1.5">
              <ShieldCheck className="h-4.5 w-4.5 text-[#10B981]" />
              Credit Enhancement Ledger
            </h4>

            <div className="space-y-4 text-xs">
              <div className="p-4 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded space-y-2">
                <span className="text-[10px] uppercase font-mono text-[#8E9299] block">Reserve Account Status</span>
                <div className="flex justify-between items-center">
                  <span className="text-[#D1CEC4]">Current Balance</span>
                  <span className="font-mono font-bold text-[#D1CEC4]">{formatGBP(reserveAccount)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#8E9299]">Target Cushion (2.0%)</span>
                  <span className="font-mono text-[#8E9299]">{formatGBP(activePoolStats.totalBalance * 0.02)}</span>
                </div>
                <div className="h-1.5 w-full bg-[#1A1A1A] rounded mt-2 overflow-hidden">
                  <div className="bg-[#10B981] h-full" style={{ width: `${(reserveAccount / (activePoolStats.totalBalance * 0.02 || 1)) * 100}%` }}></div>
                </div>
              </div>

              <div className="p-4 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded space-y-2">
                <span className="text-[10px] uppercase font-mono text-[#8E9299] block">Loss Allocation Summary</span>
                <div className="flex justify-between items-center">
                  <span className="text-[#D1CEC4]">Aggregate Pool Losses</span>
                  <span className={`font-mono font-bold ${totalLosses > 0 ? "text-[#EF4444]" : "text-[#10B981]"}`}>
                    {formatGBP(totalLosses)}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[#8E9299]">
                  <span>Loss / Pool Ratio</span>
                  <span>{activePoolStats.totalBalance > 0 ? ((totalLosses / activePoolStats.totalBalance) * 100).toFixed(3) : "0"}%</span>
                </div>
              </div>

              {/* Sequential pay triggers indicators */}
              <div className="p-4 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded space-y-3">
                <span className="text-[10px] uppercase font-mono text-[#8E9299] block">Sequential Pay Triggers</span>
                
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#8E9299]">Delinquency Event Lock</span>
                  <span className="px-2 py-0.5 rounded bg-[#0D2E1F] text-[#10B981] font-mono text-[10px]">Inactive</span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#8E9299]">Cumulative Loss Event</span>
                  <span className="px-2 py-0.5 rounded bg-[#0D2E1F] text-[#10B981] font-mono text-[10px]">Inactive</span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#8E9299]">Overcollateralization Test</span>
                  <span className="px-2 py-0.5 rounded bg-[#0D2E1F] text-[#10B981] font-mono text-[10px]">Passed</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
