/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import Markdown from "react-markdown";
import { 
  BookOpen, 
  Sparkles, 
  Loader2, 
  Send, 
  HelpCircle, 
  Award, 
  ShieldCheck, 
  Download,
  Terminal,
  ChevronRight
} from "lucide-react";
import { PoolStatistics } from "../types.js";

interface BoardSummarizerProps {
  selectedLoanIds: string[];
  activePoolStats: PoolStatistics;
  tranches: any[];
  stressResult: any;
}

interface ChatMessage {
  role: "user" | "model";
  content: string;
}

export default function BoardSummarizer({
  selectedLoanIds,
  activePoolStats,
  tranches,
  stressResult
}: BoardSummarizerProps) {
  const [memo, setMemo] = useState<string>("");
  const [generatingMemo, setGeneratingMemo] = useState(false);
  
  // Conversational AI state
  const [chatInput, setChatInput] = useState("");
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    { role: "model", content: "Greetings. I am **RhinoQuant**, your Capital Markets Structuring Advisor. I am primed to answer quantitative questions on mortgage pricing, sequential triggers, tranche durations, or hedging structures." }
  ]);
  const [sendingChat, setSendingChat] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const generateMemo = async () => {
    setGeneratingMemo(true);
    try {
      const response = await fetch("/api/gemini/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          poolStats: activePoolStats,
          tranches: tranches,
          stressResult: stressResult
        })
      });
      const data = await response.json();
      setMemo(data.analysis || "No response received from advisor.");
    } catch (error) {
      console.error("Failed to generate memo:", error);
      setMemo("Failed to connect to Capital Markets Desk. Verify process credentials.");
    } finally {
      setGeneratingMemo(false);
    }
  };

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMsg = chatInput;
    setChatInput("");
    
    const updatedHistory: ChatMessage[] = [
      ...chatHistory,
      { role: "user", content: userMsg }
    ];
    setChatHistory(updatedHistory);
    setSendingChat(true);

    try {
      const response = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: updatedHistory,
          poolStats: activePoolStats,
          tranches: tranches
        })
      });
      const data = await response.json();
      setChatHistory([
        ...updatedHistory,
        { role: "model", content: data.text || "Calculation timeout. Query aborted." }
      ]);
    } catch (error) {
      console.error("Chat error:", error);
      setChatHistory([
        ...updatedHistory,
        { role: "model", content: "Advisor offline. Reconnecting to Capital Markets node..." }
      ]);
    } finally {
      setSendingChat(false);
    }
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, sendingChat]);

  // Export board report to client
  const handleExportText = () => {
    if (!memo) return;
    const blob = new Blob([memo], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "Investment_Committee_Securitisation_Memo.txt";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" id="board-summarizer">
      {/* Board Memorandums Panel */}
      <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded flex flex-col justify-between min-h-[500px]">
        <div>
          <h3 className="text-xs font-mono uppercase text-[#B87333] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <BookOpen className="h-4 w-4" />
              Investment Committee Securitisation Memo
            </span>
            <span className="text-[10px] text-[#8E9299]">Gemini-Drafted Board Brief</span>
          </h3>

          {memo ? (
            <div className="mt-4 prose prose-invert max-w-none text-xs leading-relaxed text-[#8E9299] max-h-[380px] overflow-y-auto space-y-3 p-4 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded">
              <div className="markdown-body">
                <Markdown>{memo}</Markdown>
              </div>
            </div>
          ) : (
            <div className="mt-4 flex flex-col items-center justify-center py-20 text-center space-y-3 bg-[#1A1A1A] border border-dashed border-[#D1CEC4]/15 rounded">
              <Sparkles className="h-8 w-8 text-[#B87333] animate-pulse" />
              <div className="text-xs text-[#D1CEC4] font-mono uppercase">Draft Committee Memo</div>
              <p className="text-[11px] text-[#8E9299] max-w-sm">
                Compile a comprehensive structured finance executive report reviewing pool balance metrics, tranche sizing, and adverse stress-test delta exposures.
              </p>
            </div>
          )}
        </div>

        <div className="flex gap-2 pt-4 border-t border-[#D1CEC4]/10">
          <button
            onClick={generateMemo}
            disabled={generatingMemo || selectedLoanIds.length === 0}
            className={`flex-1 py-2 text-xs font-mono font-bold rounded flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              selectedLoanIds.length === 0
                ? "bg-[#1A1A1A] text-[#8E9299] cursor-not-allowed"
                : "bg-[#B87333] text-[#0A0A0A] hover:bg-[#A05C23]"
            }`}
            id="btn-draft-memo"
          >
            {generatingMemo ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                Drafting board-level memo...
              </>
            ) : (
              <>
                <Sparkles className="h-3.5 w-3.5" />
                Draft Investment Committee Memo
              </>
            )}
          </button>
          
          {memo && (
            <button
              onClick={handleExportText}
              className="px-3 py-2 text-xs text-[#D1CEC4] border border-[#D1CEC4]/15 hover:border-[#B87333] rounded font-mono"
              id="btn-export-memo"
            >
              <Download className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Real-time Structuring Quant Chat */}
      <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded flex flex-col justify-between min-h-[500px]" id="quant-chat-panel">
        <div>
          <h3 className="text-xs font-mono uppercase text-[#B87333] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Terminal className="h-4 w-4" />
              Conversational Structuring Advisor
            </span>
            <span className="text-[10px] text-[#10B981]">Core Online</span>
          </h3>

          <div className="mt-4 space-y-3 h-[340px] overflow-y-auto p-4 bg-[#1A1A1A] border border-[#D1CEC4]/10 rounded">
            {chatHistory.map((msg, idx) => (
              <div 
                key={idx}
                className={`flex gap-2.5 text-xs ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {msg.role !== "user" && (
                  <span className="h-6 w-6 rounded bg-[#0A0A0A] text-[#B87333] flex items-center justify-center font-mono font-bold text-[10px] border border-[#D1CEC4]/10">
                    RQ
                  </span>
                )}
                <div 
                  className={`p-3 rounded max-w-[85%] leading-relaxed ${
                    msg.role === "user" 
                      ? "bg-[#B87333] text-[#0A0A0A] font-semibold" 
                      : "bg-[#0D0D0D] border border-[#D1CEC4]/10 text-[#8E9299]"
                  }`}
                >
                  <div className="markdown-body">
                    <Markdown>{msg.content}</Markdown>
                  </div>
                </div>
              </div>
            ))}
            
            {sendingChat && (
              <div className="flex gap-2.5 text-xs justify-start">
                <span className="h-6 w-6 rounded bg-[#0A0A0A] text-[#B87333] flex items-center justify-center font-mono font-bold text-[10px] border border-[#D1CEC4]/10">
                  RQ
                </span>
                <div className="p-3 rounded bg-[#0D0D0D] border border-[#D1CEC4]/10 text-[#8E9299] flex items-center gap-1.5">
                  <Loader2 className="h-3 w-3 animate-spin text-[#B87333]" />
                  Recalculating synthetic watermarks...
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
        </div>

        {/* Chat input controls */}
        <form onSubmit={handleSendChat} className="flex gap-2 pt-4 border-t border-[#D1CEC4]/10" id="chat-form">
          <input
            type="text"
            placeholder="Ask about tranche hedges, CPR speeds, or trigger locks..."
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            disabled={sendingChat || selectedLoanIds.length === 0}
            className="flex-1 px-3 py-2 text-xs bg-[#1A1A1A] border border-[#D1CEC4]/15 rounded text-[#D1CEC4] font-mono focus:outline-none focus:border-[#B87333] disabled:opacity-50"
            id="input-chat-query"
          />
          <button
            type="submit"
            disabled={sendingChat || !chatInput.trim() || selectedLoanIds.length === 0}
            className={`p-2 rounded flex items-center justify-center transition-all cursor-pointer ${
              sendingChat || !chatInput.trim() || selectedLoanIds.length === 0
                ? "bg-[#1A1A1A] text-[#8E9299] cursor-not-allowed"
                : "bg-[#B87333] text-[#0A0A0A] hover:bg-[#A05C23]"
            }`}
            id="btn-send-chat"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
