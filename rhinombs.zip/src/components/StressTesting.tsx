/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  ShieldAlert, 
  Flame, 
  TrendingDown, 
  Skull, 
  Percent, 
  DollarSign, 
  Activity,
  Award,
  BookOpen,
  ArrowRight,
  Info
} from "lucide-react";
import { PoolStatistics } from "../types.js";

interface StressTestingProps {
  selectedLoanIds: string[];
  activePoolStats: PoolStatistics;
  currentScenario: string;
  onSelectScenario: (scenarioId: string) => void;
  tranchesPerformance: any[];
}

export default function StressTesting({
  selectedLoanIds,
  activePoolStats,
  currentScenario,
  onSelectScenario,
  tranchesPerformance
}: StressTestingProps) {
  const [scenarioDetails, setScenarioDetails] = useState<any>({
    description: "Standard macroeconomic state of the securitised pool.",
    cpr: 0.06,
    cdr: 0.0075,
    severity: 0.35
  });

  const scenarios = [
    { id: "baseline", name: "Baseline State", icon: Award, desc: "Standard historical parameters" },
    { id: "rising_rates", name: "BoE rate hike (+300bps)", icon: Flame, desc: "Refinancing shocks, expansion risk" },
    { id: "property_crash", name: "National Property Crash (-25%)", icon: Skull, desc: "Slashed recovery values, high severity" },
    { id: "stagflation", name: "Stagflation Crisis", icon: ShieldAlert, desc: "Double defaults, credit decay" },
    { id: "green_shoot", name: "Green Shoots Recovery", icon: Activity, desc: "Accelerated prepayments" },
  ];

  useEffect(() => {
    const fetchScenarioDetails = async () => {
      try {
        const response = await fetch("/api/stress-test", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            loanIds: selectedLoanIds,
            scenarioId: currentScenario
          })
        });
        const data = await response.json();
        setScenarioDetails(data);
      } catch (error) {
        console.error("Failed to load stress scenario detail:", error);
      }
    };

    if (selectedLoanIds.length > 0) {
      fetchScenarioDetails();
    }
  }, [currentScenario, selectedLoanIds]);

  const formatGBP = (num: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      maximumFractionDigits: 0
    }).format(num);
  };

  return (
    <div className="space-y-6" id="stress-testing">
      {/* Scenario Grid Selector */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3" id="scenarios-grid">
        {scenarios.map((sc) => {
          const Icon = sc.icon;
          const isActive = currentScenario === sc.id;
          return (
            <button
              key={sc.id}
              onClick={() => onSelectScenario(sc.id)}
              className={`p-4 rounded border text-left flex flex-col justify-between h-[110px] transition-all cursor-pointer ${
                isActive 
                  ? "bg-[#B87333] border-[#B87333] text-[#0A0A0A]" 
                  : "bg-[#0D0D0D] border-[#D1CEC4]/10 text-[#D1CEC4] hover:border-[#B87333]/40"
              }`}
              id={`btn-sc-${sc.id}`}
            >
              <Icon className={`h-5 w-5 ${isActive ? "text-[#0A0A0A]" : "text-[#B87333]"}`} />
              <div className="mt-2">
                <span className="text-xs font-bold font-mono block leading-tight">{sc.name}</span>
                <span className={`text-[9px] font-mono mt-0.5 block ${isActive ? "text-[#2D160A]" : "text-[#8E9299]"}`}>
                  {sc.desc}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="stress-details-grid">
        {/* Scenario Assumptions Card */}
        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded space-y-4">
          <h3 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider border-b border-[#D1CEC4]/10 pb-2 flex items-center gap-1.5">
            <Info className="h-4 w-4 text-[#B87333]" />
            Macro Shocks Assumptions
          </h3>

          <p className="text-xs text-[#8E9299] leading-relaxed">
            {scenarioDetails.description}
          </p>

          <div className="space-y-4 pt-2">
            <div>
              <div className="flex justify-between text-xs font-mono mb-1 text-[#8E9299]">
                <span>Constant Prepayment (CPR)</span>
                <span className="text-[#D1CEC4] font-bold">{(scenarioDetails.cpr * 100).toFixed(1)}%</span>
              </div>
              <div className="h-1 w-full bg-[#1A1A1A] rounded overflow-hidden">
                <div className="bg-[#B87333] h-full" style={{ width: `${(scenarioDetails.cpr / 0.3) * 100}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1 text-[#8E9299]">
                <span>Constant Default Rate (CDR)</span>
                <span className="text-[#D1CEC4] font-bold">{(scenarioDetails.cdr * 100).toFixed(2)}%</span>
              </div>
              <div className="h-1 w-full bg-[#1A1A1A] rounded overflow-hidden">
                <div className="bg-[#EF4444] h-full" style={{ width: `${(scenarioDetails.cdr / 0.1) * 100}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1 text-[#8E9299]">
                <span>Loss Given Default (LGD severity)</span>
                <span className="text-[#D1CEC4] font-bold">{(scenarioDetails.severity * 100).toFixed(0)}%</span>
              </div>
              <div className="h-1 w-full bg-[#1A1A1A] rounded overflow-hidden">
                <div className="bg-[#B87333] h-full" style={{ width: `${scenarioDetails.severity * 100}%` }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Tranche Delta Impact Grid */}
        <div className="bg-[#0D0D0D] border border-[#D1CEC4]/10 p-6 rounded lg:col-span-2 space-y-4">
          <h3 className="text-xs font-mono uppercase text-[#8E9299] tracking-wider border-b border-[#D1CEC4]/10 pb-2">
            Simulated Tranche Degradation Ledger
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono" id="stress-impact-table">
              <thead>
                <tr className="text-[#8E9299] text-[10px] uppercase border-b border-[#D1CEC4]/10 pb-2">
                  <th className="py-2">Tranche Name</th>
                  <th className="py-2 text-right">Original Bal</th>
                  <th className="py-2 text-right">Write-down</th>
                  <th className="py-2 text-right">Repaid Principal</th>
                  <th className="py-2 text-right">Ending Yield</th>
                  <th className="py-2 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D1CEC4]/10 text-xs">
                {tranchesPerformance.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#8E9299]">
                      Please lock pool and run amortization curves to view stress simulation outcomes.
                    </td>
                  </tr>
                ) : (
                  tranchesPerformance.map((tr) => (
                    <tr key={tr.trancheId} className="hover:bg-[#1A1A1A] transition-colors">
                      <td className="py-3 font-bold text-[#D1CEC4]">{tr.trancheName}</td>
                      <td className="py-3 text-right">{formatGBP(tr.originalBalance)}</td>
                      <td className={`py-3 text-right ${tr.lossesAllocated > 0 ? "text-[#EF4444] font-bold" : "text-[#8E9299]"}`}>
                        {formatGBP(tr.lossesAllocated)}
                      </td>
                      <td className="py-3 text-right text-[#10B981]">{formatGBP(tr.principalReceived)}</td>
                      <td className={`py-3 text-right font-bold ${tr.finalYield < 0 ? "text-[#EF4444]" : "text-[#D1CEC4]"}`}>
                        {tr.finalYield.toFixed(2)}%
                      </td>
                      <td className="py-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          tr.lossesAllocated === 0
                            ? "bg-[#0D2E1F] text-[#10B981]"
                            : tr.endingBalance === 0
                            ? "bg-[#3B1212] text-[#EF4444]"
                            : "bg-[#2D160A] text-[#B87333]"
                        }`}>
                          {tr.lossesAllocated === 0 
                            ? "PRIMED" 
                            : tr.endingBalance === 0 
                            ? "COLLAPSED" 
                            : `IMPAIRED (${tr.writeDownPct}%)`}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
