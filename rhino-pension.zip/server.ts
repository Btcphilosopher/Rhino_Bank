import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Database representing our Rust Member Admin & Employer database
interface Member {
  id: string;
  name: string;
  status: "Active" | "Deferred" | "Pensioner";
  age: number;
  employer: string;
  contributionsYtd: number;
  totalAccruedPension: number;
  avcBalance: number;
  beneficiaries: string;
  joinedDate: string;
}

interface Employer {
  id: string;
  name: string;
  industry: string;
  activeMembers: number;
  monthlyContributionRate: number; // e.g., 18.5%
  complianceStatus: "Compliant" | "Pending Review" | "Under Audit";
  lastPaymentDate: string;
}

interface AuditLog {
  timestamp: string;
  user: string;
  role: string;
  action: string;
  module: string;
  status: "Success" | "Warning" | "Failure";
  details: string;
}

const initialMembers: Member[] = [
  { id: "M001", name: "Sarah Jennings", status: "Active", age: 42, employer: "Leeds City Council", contributionsYtd: 4200, totalAccruedPension: 12500, avcBalance: 8500, beneficiaries: "Thomas Jennings (Spouse, 100%)", joinedDate: "2015-04-12" },
  { id: "M002", name: "David Featherstone", status: "Active", age: 35, employer: "Yorkshire Water", contributionsYtd: 3600, totalAccruedPension: 6800, avcBalance: 1200, beneficiaries: "Mary Featherstone (Mother, 100%)", joinedDate: "2019-10-01" },
  { id: "M003", name: "William Higgins", status: "Pensioner", age: 71, employer: "Sheffield Forgemasters", contributionsYtd: 0, totalAccruedPension: 21400, avcBalance: 0, beneficiaries: "Ann Higgins (Spouse, 50%), Lucy Higgins (Daughter, 50%)", joinedDate: "1988-01-15" },
  { id: "M004", name: "Eleanor Brooks", status: "Deferred", age: 53, employer: "University of Leeds", contributionsYtd: 0, totalAccruedPension: 9800, avcBalance: 3200, beneficiaries: "James Brooks (Husband, 100%)", joinedDate: "2008-09-10" },
  { id: "M005", name: "Richard Croft", status: "Active", age: 58, employer: "Halifax Financial", contributionsYtd: 6200, totalAccruedPension: 28500, avcBalance: 15400, beneficiaries: "Clara Croft (Spouse, 80%), Alice Croft (Daughter, 20%)", joinedDate: "1999-11-20" },
  { id: "M006", name: "Amelia Harrison", status: "Active", age: 29, employer: "Leeds City Council", contributionsYtd: 2900, totalAccruedPension: 3400, avcBalance: 500, beneficiaries: "Mark Harrison (Father, 100%)", joinedDate: "2022-06-15" },
  { id: "M007", name: "Gordon Broadbent", status: "Pensioner", age: 78, employer: "Yorkshire Water", contributionsYtd: 0, totalAccruedPension: 18900, avcBalance: 0, beneficiaries: "Jane Broadbent (Spouse, 100%)", joinedDate: "1982-05-14" },
];

const initialEmployers: Employer[] = [
  { id: "E01", name: "Leeds City Council", industry: "Public Administration", activeMembers: 1450, monthlyContributionRate: 19.5, complianceStatus: "Compliant", lastPaymentDate: "2026-07-20" },
  { id: "E02", name: "Yorkshire Water", industry: "Utilities", activeMembers: 820, monthlyContributionRate: 18.2, complianceStatus: "Compliant", lastPaymentDate: "2026-07-18" },
  { id: "E03", name: "Sheffield Forgemasters", industry: "Heavy Engineering", activeMembers: 350, monthlyContributionRate: 17.5, complianceStatus: "Compliant", lastPaymentDate: "2026-07-15" },
  { id: "E04", name: "University of Leeds", industry: "Higher Education", activeMembers: 1120, monthlyContributionRate: 21.0, complianceStatus: "Compliant", lastPaymentDate: "2026-07-22" },
  { id: "E05", name: "Halifax Financial", industry: "Financial Services", activeMembers: 460, monthlyContributionRate: 16.8, complianceStatus: "Pending Review", lastPaymentDate: "2026-06-30" },
  { id: "E06", name: "Huddersfield Advanced Manufacturing", industry: "Engineering", activeMembers: 190, monthlyContributionRate: 18.0, complianceStatus: "Under Audit", lastPaymentDate: "2026-07-05" },
];

const initialAuditLogs: AuditLog[] = [
  { timestamp: "2026-07-27 09:30:15", user: "system_cron", role: "SRE Daemon", action: "Stochastic Reconciliation", module: "Employer Portal", status: "Success", details: "Auto-reconciliation complete for 5 of 6 active employers. Halifax Financial marked pending." },
  { timestamp: "2026-07-27 09:12:04", user: "a.patterson@rhinobank.co.uk", role: "Quantitative Actuary", action: "Run Nelson-Siegel Fitting", module: "Yield Curve Analytics", status: "Success", details: "Svensson model parameters optimized. Curve fit achieved with residual sum of squares < 0.00012." },
  { timestamp: "2026-07-27 08:45:00", user: "m.hemingway@rhinobank.co.uk", role: "Investment Manager", action: "Rebalance Sovereign Wealth Port", module: "Investment Management", status: "Success", details: "Allocated £25M into West Yorkshire Rail Electrification Infrastructure Project, funding round B." },
  { timestamp: "2026-07-26 17:33:12", user: "e.scruton@rhino-admin.org", role: "Member Administrator", action: "Add AVC Record", module: "Member Administration", status: "Success", details: "Manual contribution of £5,000 processed for Richard Croft." },
];

let members = [...initialMembers];
let employers = [...initialEmployers];
let auditLogs = [...initialAuditLogs];

// Yorkshire Regional economic statistics
const yorkshireEconomicMetrics = {
  regionalGdp: "£142.5 Billion",
  gdpGrowthRate: "+2.1% y/y",
  productivityIndex: "94.2 (UK Baseline = 100)",
  employmentRate: "73.8%",
  unemploymentRate: "4.1%",
  manufacturingGrowth: "+3.8%",
  engineeringSectorValue: "£7.4 Billion",
  infrastructureCommitted: "£1.85 Billion",
  exportsYtd: "£14.2 Billion",
  universityResearchFunding: "£420 Million",
  locations: [
    { name: "Leeds", lat: 53.8008, lng: -1.5491, value: 92, type: "Financial & Tech Hub" },
    { name: "Sheffield", lat: 53.3811, lng: -1.4701, value: 85, type: "Advanced Manufacturing" },
    { name: "Hull", lat: 53.7436, lng: -0.3386, value: 78, type: "Maritime & Green Energy" },
    { name: "York", lat: 53.9599, lng: -1.0873, value: 80, type: "Research & Tourism" },
    { name: "Bradford", lat: 53.7960, lng: -1.7594, value: 74, type: "Textiles & Logistics" },
    { name: "Bradford Tech", lat: 53.83, lng: -1.82, value: 70, type: "Digital Startups" },
    { name: "Huddersfield", lat: 53.6458, lng: -1.7850, value: 79, type: "Precision Engineering" },
    { name: "Doncaster", lat: 53.5228, lng: -1.1311, value: 72, type: "Rail Logistics" },
    { name: "Wakefield", lat: 53.6808, lng: -1.4979, value: 76, type: "Creative & Distribution" },
  ]
};

// Yorkshire Regional Infrastructure projects
const infrastructureProjects = [
  { id: "P001", name: "West Yorkshire Rail Electrification", category: "Railways", allocatedCapital: 120000000, targetIrr: 0.068, npv: 38500000, progress: 0.65, esgScore: 92, jobsCreated: 1450, desc: "Electrification and signalling upgrades across Leeds, Bradford, and Huddersfield core routes." },
  { id: "P002", name: "Humber Estuary Green Hydrogen Ring", category: "Energy", allocatedCapital: 85000000, targetIrr: 0.082, npv: 42000000, progress: 0.40, esgScore: 98, jobsCreated: 820, desc: "Offshore wind integration creating industrial hydrogen grid for Hull refineries and steel works." },
  { id: "P003", name: "Sheffield Forgemasters Giga-Press", category: "Advanced Manufacturing", allocatedCapital: 55000000, targetIrr: 0.095, npv: 24500000, progress: 0.80, esgScore: 84, jobsCreated: 450, desc: "Expanding the nuclear and heavy defense component casting capability in South Yorkshire." },
  { id: "P004", name: "Leeds South Bank Carbon-Zero Housing", category: "Housing", allocatedCapital: 70000000, targetIrr: 0.059, npv: 11200000, progress: 0.35, esgScore: 95, jobsCreated: 680, desc: "Sustainable residential community integrated into South Bank regeneration." },
  { id: "P005", name: "Yorkshire Pennines High-Speed Fiber", category: "Broadband", allocatedCapital: 35000000, targetIrr: 0.071, npv: 12900000, progress: 0.90, esgScore: 89, jobsCreated: 310, desc: "Last-mile gigabit broadband to rural agricultural communities and Dales businesses." },
];

// Current overall asset allocation of Rhino Pension (Billions)
const initialAssetAllocation = [
  { category: "UK Equities", currentVal: 1.25, percentage: 12.5, esgScore: 78, type: "Listed" },
  { category: "Global Equities", currentVal: 2.10, percentage: 21.0, esgScore: 72, type: "Listed" },
  { category: "Government Bonds (Gilts)", currentVal: 2.85, percentage: 28.5, esgScore: 80, type: "Fixed Income" },
  { category: "Corporate Bonds", currentVal: 1.10, percentage: 11.0, esgScore: 75, type: "Fixed Income" },
  { category: "Yorkshire Infrastructure", currentVal: 0.95, percentage: 9.5, esgScore: 94, type: "Alternatives" },
  { category: "Regional Property", currentVal: 0.65, percentage: 6.5, esgScore: 82, type: "Alternatives" },
  { category: "Private Equity & VC", currentVal: 0.40, percentage: 4.0, esgScore: 68, type: "Alternatives" },
  { category: "Renewable Energy", currentVal: 0.50, percentage: 5.0, esgScore: 98, type: "Alternatives" },
  { category: "Cash & Cash Equivalents", currentVal: 0.20, percentage: 2.0, esgScore: 85, type: "Cash" },
];

let assetAllocation = [...initialAssetAllocation];

// ----------------------------------------------------
// QUANTITATIVE ENGINES (TypeScript representations of Rust/R logic)
// ----------------------------------------------------

// 1. Yield Curve Analytics (Nelson-Siegel & Svensson fitting)
// Spot rate model: fits yields based on maturity t (years)
function calculateNelsonSiegel(t: number, b0: number, b1: number, b2: number, tau: number): number {
  if (t <= 0) t = 0.01;
  const factor1 = (1 - Math.exp(-t / tau)) / (t / tau);
  const factor2 = factor1 - Math.exp(-t / tau);
  return b0 + b1 * factor1 + b2 * factor2;
}

function calculateSvensson(t: number, b0: number, b1: number, b2: number, b3: number, tau1: number, tau2: number): number {
  if (t <= 0) t = 0.01;
  const factor1 = (1 - Math.exp(-t / tau1)) / (t / tau1);
  const factor2 = factor1 - Math.exp(-t / tau1);
  const factor3 = ((1 - Math.exp(-t / tau2)) / (t / tau2)) - Math.exp(-t / tau2);
  return b0 + b1 * factor1 + b2 * factor2 + b3 * factor3;
}

// 2. Pension Liability Engine (Projections over 10, 25, 50, 75 years)
// Calculates projected benefits payable for Active, Deferred, Pensioner cohorts
function projectLiabilities(yearsHorizon: number = 75) {
  // Let's model 3 cohorts based on our metrics
  // Base totals: active members = 3,390, deferred = 10,000, pensioners = 5,000
  // Values in Millions of GBP
  const activeBase = 3200; // Valuation of active liabilities
  const deferredBase = 2400; // Valuation of deferred liabilities
  const pensionerBase = 4100; // Valuation of pensioner liabilities
  
  const results = [];
  
  // Assumptions
  const salaryGrowth = 0.035; // 3.5% wage inflation
  const priceInflation = 0.025; // 2.5% CPI
  const discountRate = 0.042; // 4.2% yield curve discount rate
  const mortalityRate = 0.015; // mortality attrition for pensioners
  const retirementTransition = 0.03; // percentage of deferred/actives retiring per year

  let currentActives = activeBase;
  let currentDeferred = deferredBase;
  let currentPensioners = pensionerBase;

  for (let t = 0; t <= yearsHorizon; t++) {
    // Actives grow with salary inflation and decrease as they retire
    const activeVal = activeBase * Math.exp((salaryGrowth - discountRate) * t) * Math.pow(0.97, t);
    // Deferred grow with price inflation and decrease as they retire/retire
    const deferredVal = deferredBase * Math.exp((priceInflation - discountRate) * t) * Math.pow(0.96, t);
    // Pensioners experience decrements via mortality, augmented by transitioning actives and deferred
    const pensionerCashflow = pensionerBase * Math.exp((priceInflation - discountRate) * t) * Math.pow(1 - mortalityRate, t) 
                            + (activeBase * 0.03 * t * Math.exp((priceInflation - discountRate) * t)) 
                            + (deferredBase * 0.02 * t * Math.exp((priceInflation - discountRate) * t));
    
    const totalLiab = activeVal + deferredVal + pensionerCashflow;
    
    // Simulate Asset values under standard 4.8% net ALM return
    const assetStandard = 9.25 * Math.pow(1 + 0.048 - 0.032, t); // standard payout / contribution balance net yield 1.6% real
    const fundingRatio = (assetStandard / (totalLiab / 1000)) * 100; // Asset in Billions, TotalLiab in Millions

    results.push({
      year: t,
      active: Math.round(activeVal * 100) / 100,
      deferred: Math.round(deferredVal * 100) / 100,
      pensioner: Math.round(pensionerCashflow * 100) / 100,
      total: Math.round(totalLiab * 100) / 100,
      projectedAssets: Math.round(assetStandard * 1000 * 100) / 100, // Millions
      fundingRatio: Math.round(fundingRatio * 10) / 10,
    });
  }
  return results;
}

// 3. Monte Carlo Simulator (Simulates economic variables and portfolio values)
// Simulates 1,000 paths over 25 years. Returns statistically relevant percentiles
function runMonteCarlo(paths: number = 1000, horizon: number = 25) {
  const years = Array.from({ length: horizon + 1 }, (_, i) => i);
  
  // Standard deviations (volatilities) and correlations for economic variables
  const volatility = {
    gdp: 0.022,
    inflation: 0.015,
    interestRate: 0.012,
    equities: 0.16,
    bonds: 0.06,
    infrastructure: 0.09
  };

  // Portfolio allocation weights
  const weights = {
    equities: 0.33,
    bonds: 0.40,
    infrastructure: 0.25,
    cash: 0.02
  };

  // Expected returns
  const expReturns = {
    equities: 0.075,
    bonds: 0.038,
    infrastructure: 0.068,
    cash: 0.025
  };

  // Initial portfolio value: £9.75 Billion
  const initialValue = 9.75;
  const initialInflation = 2.5; // %
  const initialGdp = 1.8; // %
  const initialRates = 3.5; // %

  // Let's generate stats. To make it snappy on the server but absolutely real,
  // we simulate paths and extract percentiles (P10, P50, P90).
  const assetPaths: number[][] = Array.from({ length: paths }, () => [initialValue]);
  const inflationPaths: number[][] = Array.from({ length: paths }, () => [initialInflation]);
  const ratePaths: number[][] = Array.from({ length: paths }, () => [initialRates]);

  for (let p = 0; p < paths; p++) {
    let currentAsset = initialValue;
    let currentInf = initialInflation;
    let currentRate = initialRates;

    for (let t = 1; t <= horizon; t++) {
      // Gaussian random walks using Box-Muller transform
      const u1 = Math.random() || 0.0001;
      const u2 = Math.random() || 0.0001;
      const z1 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      const z2 = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);
      
      // Simulate macroeconomic variables
      currentInf = Math.max(-1.0, currentInf + z1 * volatility.inflation * 100 + 0.1 * (2.0 - currentInf)); // Mean reverting inflation to 2%
      currentRate = Math.max(0.1, currentRate + z2 * volatility.interestRate * 100 + 0.05 * (3.5 - currentRate)); // Mean reverting interest rates to 3.5%
      
      // Simulate asset returns
      const rEquities = expReturns.equities + z1 * volatility.equities;
      const rBonds = expReturns.bonds + z2 * volatility.bonds;
      const rInfra = expReturns.infrastructure + (0.3 * z1 + 0.7 * z2) * volatility.infrastructure; // correlated
      const rCash = expReturns.cash;

      const portfolioReturn = weights.equities * rEquities +
                              weights.bonds * rBonds +
                              weights.infrastructure * rInfra +
                              weights.cash * rCash;

      currentAsset = currentAsset * (1 + portfolioReturn) - 0.22; // Subtract net annual member payouts of £220M
      assetPaths[p].push(currentAsset);
      inflationPaths[p].push(currentInf);
      ratePaths[p].push(currentRate);
    }
  }

  // Calculate percentiles
  const percentiles = years.map(t => {
    const assetsAtT = assetPaths.map(path => path[t]).sort((a, b) => a - b);
    const inflAtT = inflationPaths.map(path => path[t]).sort((a, b) => a - b);
    const ratesAtT = ratePaths.map(path => path[t]).sort((a, b) => a - b);

    return {
      year: t,
      assetsP10: Math.round(assetsAtT[Math.floor(paths * 0.1)] * 100) / 100,
      assetsP50: Math.round(assetsAtT[Math.floor(paths * 0.5)] * 100) / 100,
      assetsP90: Math.round(assetsAtT[Math.floor(paths * 0.9)] * 100) / 100,
      
      inflationP10: Math.round(inflAtT[Math.floor(paths * 0.1)] * 100) / 100,
      inflationP50: Math.round(inflAtT[Math.floor(paths * 0.5)] * 100) / 100,
      inflationP90: Math.round(inflAtT[Math.floor(paths * 0.9)] * 100) / 100,
      
      ratesP10: Math.round(ratesAtT[Math.floor(paths * 0.1)] * 100) / 100,
      ratesP50: Math.round(ratesAtT[Math.floor(paths * 0.5)] * 100) / 100,
      ratesP90: Math.round(ratesAtT[Math.floor(paths * 0.9)] * 100) / 100,
    };
  });

  return percentiles;
}

// ----------------------------------------------------
// EXPRESS API ROUTING
// ----------------------------------------------------

// API 1: Healthcheck
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", platform: "Rhino Pension Fund Engine", languages: ["Rust", "R"] });
});

// API 2: Members Administration (Rust-simulated member directory)
app.get("/api/members", (req, res) => {
  res.json(members);
});

app.post("/api/members", (req, res) => {
  const { name, status, age, employer, contributionsYtd, totalAccruedPension, avcBalance, beneficiaries } = req.body;
  if (!name || !status || !age || !employer) {
    return res.status(400).json({ error: "Missing required member parameters" });
  }
  const newMember: Member = {
    id: `M00${members.length + 1}`,
    name,
    status,
    age: parseInt(age),
    employer,
    contributionsYtd: parseFloat(contributionsYtd) || 0,
    totalAccruedPension: parseFloat(totalAccruedPension) || 0,
    avcBalance: parseFloat(avcBalance) || 0,
    beneficiaries: beneficiaries || "Estate (100%)",
    joinedDate: new Date().toISOString().split('T')[0]
  };
  members.unshift(newMember);

  // Write to Audit trail
  auditLogs.unshift({
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    user: "m.adams@rhino-admin.org",
    role: "Member Administrator",
    action: "Register New Member",
    module: "Member Administration",
    status: "Success",
    details: `Successfully registered ${name} (${status}, age ${age}) under employer ${employer}.`
  });

  res.status(201).json(newMember);
});

// API 3: Employers Directory
app.get("/api/employers", (req, res) => {
  res.json(employers);
});

app.post("/api/employers/reconcile", (req, res) => {
  const { employerId } = req.body;
  const empIndex = employers.findIndex(e => e.id === employerId);
  if (empIndex === -1) return res.status(404).json({ error: "Employer not found" });

  employers[empIndex].complianceStatus = "Compliant";
  employers[empIndex].lastPaymentDate = new Date().toISOString().split('T')[0];

  auditLogs.unshift({
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    user: "reconciliation_service",
    role: "SRE Daemon",
    action: "Payroll Schedule Reconciliation",
    module: "Employer Portal",
    status: "Success",
    details: `Payroll and contributions reconciled successfully for ${employers[empIndex].name}. Compliance status reset to Compliant.`
  });

  res.json({ success: true, employer: employers[empIndex] });
});

// API 4: Yield Curve curves (Nelson-Siegel & Svensson fitting)
app.get("/api/curve-analytics", (req, res) => {
  const { b0, b1, b2, b3, tau1, tau2, tau } = req.query;

  // Read query params or apply standard fitted parameters (calibrated to BOE gilts curve)
  const paramB0 = parseFloat(b0 as string) || 4.25; // Asymptote level
  const paramB1 = parseFloat(b1 as string) || -2.40; // Slope term
  const paramB2 = parseFloat(b2 as string) || 3.10; // Curvature term 1
  const paramB3 = parseFloat(b3 as string) || -1.80; // Curvature term 2
  const paramTau1 = parseFloat(tau1 as string) || 1.8;
  const paramTau2 = parseFloat(tau2 as string) || 5.5;
  const paramTau = parseFloat(tau as string) || 2.2;

  const maturities = [0.25, 0.5, 1, 2, 3, 5, 7, 10, 12, 15, 20, 25, 30, 40, 50];
  const curveData = maturities.map(t => {
    const nsRate = calculateNelsonSiegel(t, paramB0 / 100, paramB1 / 100, paramB2 / 100, paramTau);
    const svRate = calculateSvensson(t, paramB0 / 100, paramB1 / 100, paramB2 / 100, paramB3 / 100, paramTau1, paramTau2);
    // Instantaneous Forward curves derived analytically from spot curves
    const forwardRate = svRate + t * 0.001; // representation of forward premium

    return {
      maturity: t,
      maturityLabel: t < 1 ? `${t * 12}M` : `${t}Y`,
      nelsonSiegel: Math.round(nsRate * 10000) / 100,
      svensson: Math.round(svRate * 10000) / 100,
      forwardRate: Math.round(forwardRate * 10000) / 100,
    };
  });

  res.json({
    parameters: { b0: paramB0, b1: paramB1, b2: paramB2, b3: paramB3, tau1: paramTau1, tau2: paramTau2, tau: paramTau },
    curve: curveData
  });
});

// API 5: Pension Liability cashflows (10Y, 25Y, 50Y, 75Y)
app.get("/api/pension-liability", (req, res) => {
  const liabilities = projectLiabilities(75);
  res.json(liabilities);
});

// API 6: Monte Carlo economic asset simulations
app.get("/api/monte-carlo", (req, res) => {
  const mcResults = runMonteCarlo(1000, 25);
  res.json(mcResults);
});

// API 7: Yorkshire Economic Dashboard regional data
app.get("/api/yorkshire-economy", (req, res) => {
  res.json(yorkshireEconomicMetrics);
});

// API 8: Infrastructure Module
app.get("/api/infrastructure", (req, res) => {
  res.json(infrastructureProjects);
});

// API 9: Investment Portfolio & Asset Allocations
app.get("/api/investments", (req, res) => {
  res.json({
    allocation: assetAllocation,
    sovereignTechAllocation: [
      { category: "High Tech Railways", currentVal: 180, percentage: 18, location: "Doncaster Rail Centre" },
      { category: "Sovereign AI Research", currentVal: 220, percentage: 22, location: "University of Leeds Innovation Hub" },
      { category: "Advanced Manufacturing", currentVal: 250, percentage: 25, location: "Sheffield Advanced Manufacturing Hub" },
      { category: "Wind-Grid Hydrogen Power", currentVal: 200, percentage: 20, location: "Humber Estuary Marine Array" },
      { category: "Sovereign Defense Systems", currentVal: 150, percentage: 15, location: "North Yorkshire Defense Hub" },
    ],
    esgMetrics: {
      overallEsgScore: 83.4,
      regionalJobsCreated: 3710,
      co2ReducedTonsYtd: 145000,
      fundingHealthScore: "AAA Stable",
    }
  });
});

app.post("/api/investments/reallocate", (req, res) => {
  const { allocations } = req.body;
  if (!allocations || !Array.isArray(allocations)) {
    return res.status(400).json({ error: "Allocations list required" });
  }

  // Adjust in-memory allocation
  assetAllocation = allocations;

  auditLogs.unshift({
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    user: "m.hemingway@rhinobank.co.uk",
    role: "Investment Manager",
    action: "Sovereign Reallocation",
    module: "Investment Management",
    status: "Success",
    details: `Sovereign wealth asset allocation adjusted to: ${allocations.map(a => `${a.category}: ${a.percentage}%`).join(', ')}`
  });

  res.json({ success: true, updatedAllocation: assetAllocation });
});

// API 10: Quantitative Portfolio Optimisation models
app.get("/api/portfolio-optimisation", (req, res) => {
  const strategies = [
    {
      name: "Mean-Variance (Markowitz)",
      desc: "Maximizes Sharpe ratio subject to historical covariance matrix.",
      allocation: [
        { category: "UK Equities", value: 15 },
        { category: "Global Equities", value: 25 },
        { category: "Government Bonds (Gilts)", value: 20 },
        { category: "Corporate Bonds", value: 15 },
        { category: "Yorkshire Infrastructure", value: 10 },
        { category: "Renewable Energy", value: 10 },
        { category: "Cash & Cash Equivalents", value: 5 },
      ],
      expectedReturn: "6.8%",
      volatility: "11.2%",
      sharpeRatio: "0.61",
    },
    {
      name: "Black-Litterman (Incorporate Actuarial Views)",
      desc: "Adjusts market equilibrium with actuarial views: UK inflation hedge assets premium & Yorkshire regional growth premium.",
      allocation: [
        { category: "UK Equities", value: 10 },
        { category: "Global Equities", value: 20 },
        { category: "Government Bonds (Gilts)", value: 25 },
        { category: "Corporate Bonds", value: 10 },
        { category: "Yorkshire Infrastructure", value: 22 },
        { category: "Renewable Energy", value: 11 },
        { category: "Cash & Cash Equivalents", value: 2 },
      ],
      expectedReturn: "7.2%",
      volatility: "10.4%",
      sharpeRatio: "0.69",
    },
    {
      name: "Risk Parity (Equal Risk Contribution)",
      desc: "Equalizes risk allocation contribution instead of nominal pound weight across volatile equities and stable infrastructure.",
      allocation: [
        { category: "UK Equities", value: 8 },
        { category: "Global Equities", value: 12 },
        { category: "Government Bonds (Gilts)", value: 35 },
        { category: "Corporate Bonds", value: 20 },
        { category: "Yorkshire Infrastructure", value: 12 },
        { category: "Renewable Energy", value: 10 },
        { category: "Cash & Cash Equivalents", value: 3 },
      ],
      expectedReturn: "5.4%",
      volatility: "6.8%",
      sharpeRatio: "0.79",
    },
    {
      name: "Liability Driven Investing (LDI Optimal)",
      desc: "Slightly sacrifices pure return performance to match interest rate and inflation sensitivities of Yorkshire pension liabilities.",
      allocation: [
        { category: "UK Equities", value: 5 },
        { category: "Global Equities", value: 10 },
        { category: "Government Bonds (Gilts)", value: 45 },
        { category: "Corporate Bonds", value: 15 },
        { category: "Yorkshire Infrastructure", value: 15 },
        { category: "Renewable Energy", value: 8 },
        { category: "Cash & Cash Equivalents", value: 2 },
      ],
      expectedReturn: "5.9%",
      volatility: "7.4%",
      sharpeRatio: "0.80",
    }
  ];
  res.json(strategies);
});

// API 11: Audit Trail logs
app.get("/api/audit-logs", (req, res) => {
  res.json(auditLogs);
});

// API 12: Gemini AI Trustee/Executive Reporting Engine
app.post("/api/ai/briefing", async (req, res) => {
  const geminiKey = process.env.GEMINI_API_KEY || "";
  if (!geminiKey) {
    return res.json({
      briefing: "### AI Engine Standby\n\nTo generate an official, real-time Gemini AI actuarial briefing, please configure your **GEMINI_API_KEY** in the AI Studio **Secrets Panel**.\n\n*Temporary Executive Forecast Summary:*\n- **Yorkshire Funding Ratio**: Stable at **102.4%**.\n- **Inflation Hedging**: Highly matched via £2.85B in long-duration gilts and index-linked Yorkshire infrastructure.\n- **Key Asset Risk**: Local heavy manufacturing (Sheffield Forgemasters) under review regarding regional carbon offsets, offset by Humber Green Hydrogen Ring allocations.\n- **Actuarial Surplus**: Estimated £1.35B over a 25-year structural ALM run."
    });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: geminiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const { activeView, scenarioName } = req.body;

    const systemPrompt = `You are an elite quantitative finance and pension actuary AI assistant embedded in Rhino Bank's institutional Yorkshire Pension Fund Platform ("Rhino Pension"). Your audience consists of Yorkshire pension board trustees, corporate employers, and quantitative risk managers. Use precise actuarial, economic, and sovereign wealth terminology, with a refined, clear, professional voice. Do not use hyperbolic marketing words like "supercharge" or "empower". Support your summary with actual economic indicators you receive in context. Limit response to 500 words. Keep headings clean and highly professional.`;

    const contentsPrompt = `Please generate an Executive Actuarial and Risk Briefing for the Board of Trustees based on the current financial position:
    - **Current Assets**: £9.75 Billion
    - **Yorkshire Regional Economic Assets**: Leeds Financial/Tech, Sheffield Heavy Forging, Hull Renewable Hydrogen, and local rail/infrastructure.
    - **Current Funding Ratio**: 102.4% (fully funded).
    - **Actuarial Assumptions**: Wage inflation 3.5%, price inflation 2.5%, discount rate 4.25%.
    - **Asset Allocation**: 39.5% in Government & Corporate Bonds, 33% Equities, 21% Yorkshire Regional Alternatives (Infrastructure & Property), 6.5% other.
    - **ALM / Stress Scenario Focus**: "${scenarioName || "Baseline Economic Growth"}".
    
    Structure the briefing with these exact sections:
    1. **Sovereign Funding & Solvency Verdict** (Analysis of the 102.4% funding ratio and the long-term 75-year liability matches).
    2. **Yorkshire Regional Economic Multiplier** (How allocating £950M specifically into Yorkshire infrastructure acts as a double-impact asset class, generating financial yields + boosting local employment).
    3. **Stress Testing and Risk Mitigation** (Strategic advice under the current selected scenario: "${scenarioName || "Baseline"}").
    4. **AI-Driven Rebalancing Recommendation** (Direct quantitative recommendations for the trustees on Gilts matching vs. local tech & energy investments).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: contentsPrompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.2,
      },
    });

    res.json({ briefing: response.text });
  } catch (error: any) {
    console.error("Gemini API error in briefing API:", error);
    res.status(500).json({ error: "Failed to generate AI briefing: " + error.message });
  }
});


// Start server
async function startServer() {
  // Mount Vite middleware for local development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve the built dist assets
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Rhino Pension full-stack server running on http://localhost:${PORT}`);
  });
}

startServer();
