import React, { useState, useEffect } from "react";
import { 
  Briefcase, 
  Users, 
  Activity, 
  Globe, 
  Sliders, 
  Sparkles, 
  ShieldCheck, 
  FileText,
  Lock,
  ArrowUpRight,
  TrendingUp,
  TrendingDown,
  ChevronRight,
  RefreshCw,
  Scale
} from "lucide-react";

// Types
import { 
  Member, 
  Employer, 
  AuditLog, 
  AssetAllocation, 
  InfrastructureProject, 
  CurvePoint, 
  LiabilityPoint, 
  McPoint, 
  OptimizationStrategy, 
  YorkshireMetric 
} from "./types";

// Components
import OverviewTab from "./components/OverviewTab";
import MemberAdminTab from "./components/MemberAdminTab";
import FixedIncomeTab from "./components/FixedIncomeTab";
import YorkshireEconomicsTab from "./components/YorkshireEconomicsTab";
import PortfolioOptimisationTab from "./components/PortfolioOptimisationTab";
import AIBriefingTab from "./components/AIBriefingTab";
import AuditSecurityTab from "./components/AuditSecurityTab";

export default function App() {
  const [activeTab, setActiveTab] = useState<
    "overview" | "members" | "fixed-income" | "yorkshire" | "optimisation" | "ai-briefing" | "audit"
  >("overview");

  // Server-Backed State
  const [members, setMembers] = useState<Member[]>([]);
  const [employers, setEmployers] = useState<Employer[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [allocations, setAllocations] = useState<AssetAllocation[]>([]);
  const [sovereignTechAllocation, setSovereignTechAllocation] = useState<any[]>([]);
  const [esgMetrics, setEsgMetrics] = useState<any>(null);
  
  const [curvePoints, setCurvePoints] = useState<CurvePoint[]>([]);
  const [liabilities, setLiabilities] = useState<LiabilityPoint[]>([]);
  const [monteCarlo, setMonteCarlo] = useState<McPoint[]>([]);
  const [yorkshireMetrics, setYorkshireMetrics] = useState<any>(null);
  const [infrastructureProjects, setInfrastructureProjects] = useState<InfrastructureProject[]>([]);
  const [strategies, setStrategies] = useState<OptimizationStrategy[]>([]);

  // Simulation Controls
  const [currentScenario, setCurrentScenario] = useState<string>("Baseline");
  const [currentRole, setCurrentRole] = useState<string>("Quantitative Actuary");

  // Fitted Curve parameters state
  const [curveParams, setCurveParams] = useState({
    b0: 4.25,
    b1: -2.40,
    b2: 3.10,
    b3: -1.80,
    tau: 2.2,
    tau1: 1.8,
    tau2: 5.5
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [apiError, setApiError] = useState<string | null>(null);

  // Initial fetch on mount
  useEffect(() => {
    fetchAllData();
  }, [curveParams]);

  const fetchAllData = async () => {
    setIsLoading(true);
    setApiError(null);
    try {
      // Build curve analytics query string from state parameters
      const curveQuery = `b0=${curveParams.b0}&b1=${curveParams.b1}&b2=${curveParams.b2}&b3=${curveParams.b3}&tau=${curveParams.tau}&tau1=${curveParams.tau1}&tau2=${curveParams.tau2}`;

      const [
        resMembers,
        resEmployers,
        resLogs,
        resCurve,
        resLiab,
        resMC,
        resYorkshire,
        resInfra,
        resInvest,
        resOpt
      ] = await Promise.all([
        fetch("/api/members"),
        fetch("/api/employers"),
        fetch("/api/audit-logs"),
        fetch(`/api/curve-analytics?${curveQuery}`),
        fetch("/api/pension-liability"),
        fetch("/api/monte-carlo"),
        fetch("/api/yorkshire-economy"),
        fetch("/api/infrastructure"),
        fetch("/api/investments"),
        fetch("/api/portfolio-optimisation")
      ]);

      const [
        dataMembers,
        dataEmployers,
        dataLogs,
        dataCurve,
        dataLiab,
        dataMC,
        dataYorkshire,
        dataInfra,
        dataInvest,
        dataOpt
      ] = await Promise.all([
        resMembers.json(),
        resEmployers.json(),
        resLogs.json(),
        resCurve.json(),
        resLiab.json(),
        resMC.json(),
        resYorkshire.json(),
        resInfra.json(),
        resInvest.json(),
        resOpt.json()
      ]);

      setMembers(dataMembers);
      setEmployers(dataEmployers);
      setAuditLogs(dataLogs);
      setCurvePoints(dataCurve.curve);
      setLiabilities(dataLiab);
      setMonteCarlo(dataMC);
      setYorkshireMetrics(dataYorkshire);
      setInfrastructureProjects(dataInfra);
      setAllocations(dataInvest.allocation);
      setSovereignTechAllocation(dataInvest.sovereignTechAllocation);
      setEsgMetrics(dataInvest.esgMetrics);
      setStrategies(dataOpt);

    } catch (error: any) {
      console.error("Error loading server-backed data:", error);
      setApiError("Failed to fetch data from the Rhino Pension backend SRE services. Reconnecting...");
    } finally {
      setIsLoading(false);
    }
  };

  // 1. Reconcile an employer
  const handleReconcileEmployer = async (employerId: string) => {
    try {
      const response = await fetch("/api/employers/reconcile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employerId })
      });
      if (response.ok) {
        // Reload directories
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 2. Register a member
  const handleAddMember = async (memberData: any) => {
    try {
      const response = await fetch("/api/members", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(memberData)
      });
      if (response.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 3. Pledge capital into infrastructure project
  const handleInvestInProject = async (projectId: string, amount: number) => {
    try {
      // Draw capital from cash reserves and add to alternatives
      const cashIndex = allocations.findIndex(a => a.category.includes("Cash"));
      const infraIndex = allocations.findIndex(a => a.category.includes("Infrastructure"));
      if (cashIndex === -1 || infraIndex === -1) return;

      const newAlloc = [...allocations];
      // Subtract £amount/1000 to convert Million pledge into Billion asset
      const billVal = amount / 1000;
      newAlloc[cashIndex] = {
        ...newAlloc[cashIndex],
        currentVal: Math.max(0.01, newAlloc[cashIndex].currentVal - billVal),
      };
      newAlloc[infraIndex] = {
        ...newAlloc[infraIndex],
        currentVal: newAlloc[infraIndex].currentVal + billVal,
      };

      // Recompute percentages
      const total = newAlloc.reduce((acc, c) => acc + c.currentVal, 0);
      const remapped = newAlloc.map(a => ({
        ...a,
        percentage: Math.round((a.currentVal / total) * 1000) / 10
      }));

      // Post back to server
      const response = await fetch("/api/investments/reallocate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ allocations: remapped })
      });
      if (response.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 4. Set/Tweak Yield curve parameters
  const handleParamChange = (key: string, value: number) => {
    setCurveParams(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleResetParams = () => {
    setCurveParams({
      b0: 4.25,
      b1: -2.40,
      b2: 3.10,
      b3: -1.80,
      tau: 2.2,
      tau1: 1.8,
      tau2: 5.5
    });
  };

  // 5. Trigger optimization strategy
  const handleApplyAllocation = async (newAlloc: AssetAllocation[]) => {
    try {
      const response = await fetch("/api/investments/reallocate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ allocations: newAlloc })
      });
      if (response.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 6. Push manual security fuzzed logs
  const handleAddSecurityLog = async (logEntry: AuditLog) => {
    // Simply push locally or we can let server know. To keep simple, we reload list
    setAuditLogs(prev => [logEntry, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#001A33] text-[#F5F5F0] font-sans" id="app-root">
      
      {/* Premium Header Bar in Sleek Interface Design */}
      <header className="bg-[#001A33] border-b border-steel sticky top-0 z-50 px-8 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4" id="pension-header">
        <div className="flex items-center gap-4">
          {/* Logo element representing Rhino Pension */}
          <div className="w-10 h-10 bg-[#D4AF37] rounded-sm flex items-center justify-center font-black text-[#001A33] text-2xl shadow-md">
            R
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-[#D4AF37] tracking-widest">RHINO BANK</span>
              <span className="bg-white/10 text-slate-300 text-[9px] px-2 py-0.5 rounded-sm font-mono border border-steel">v3.5 Gilt Hedged</span>
            </div>
            <h1 className="text-xs uppercase tracking-wider text-slate-400 mt-0.5">Yorkshire Pension Fund Platform</h1>
          </div>
        </div>

        {/* Global Controls & Status */}
        <div className="flex items-center gap-3 flex-wrap md:flex-nowrap">
          {/* Active Identity profile dropdown */}
          <div className="bg-white/5 px-3.5 py-1.5 rounded-sm border border-steel flex items-center gap-2 text-xs">
            <Lock className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-slate-300">Security Scope:</span>
            <span className="font-bold text-[#F5F5F0]">{currentRole}</span>
          </div>

          {/* Connected indicators */}
          <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-sm border border-steel text-[11px] font-mono text-[#D4AF37] font-bold">
            <span className="w-1.5 h-1.5 bg-[#D4AF37] rounded-full animate-pulse" />
            <span>R-Svensson Feed Online</span>
          </div>
        </div>
      </header>

      {/* Main Framework Grid */}
      <div className="flex" id="framework-grid">
        {/* Sidebar Nav with beautiful deep navy and steel gold theme details */}
        <nav className="w-64 bg-[#001A33] min-h-[calc(100vh-73px)] border-r border-steel p-4 hidden lg:block flex-shrink-0" id="sidebar-nav">
          <div className="px-5 py-3 text-[11px] text-[#708090] font-bold uppercase tracking-widest">Modules</div>
          <div className="space-y-0.5">
            {[
              { id: "overview", label: "Executive Dashboard", icon: Briefcase },
              { id: "members", label: "Member Administration", icon: Users },
              { id: "fixed-income", label: "Yield Curve Analytics", icon: Sliders },
              { id: "yorkshire", label: "Yorkshire Economic DB", icon: Globe },
              { id: "optimisation", label: "Investment Management", icon: Scale },
              { id: "ai-briefing", label: "AI Trustee Briefing", icon: Sparkles },
              { id: "audit", label: "System Audits & Security", icon: ShieldCheck }
            ].map((tab) => {
              const IconComp = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full flex items-center justify-between sidebar-item ${
                    activeTab === tab.id 
                      ? "active-tab text-[#D4AF37] font-bold" 
                      : "text-[#F5F5F0]/80"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <IconComp className={`w-4.5 h-4.5 ${activeTab === tab.id ? "text-[#D4AF37]" : "text-[#708090]"}`} />
                    <span>{tab.label.toUpperCase()}</span>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 ${activeTab === tab.id ? "text-[#D4AF37]" : "text-[#708090]/50"}`} />
                </button>
              );
            })}
          </div>

          {/* Quick Informational Box inside sidebar */}
          <div className="mt-8 p-4 bg-white/[0.03] rounded-sm border-l-4 border-[#D4AF37] text-[11px] text-slate-300 space-y-3 leading-relaxed">
            <div className="flex items-center gap-1 text-[#D4AF37] font-bold uppercase tracking-wider text-[10px]">
              <Scale className="w-3.5 h-3.5" /> Solvency Ledger
            </div>
            <p>
              Funding ratios computed dynamically using <strong>Svensson Curve Fitting</strong> to yield duration-matched liabilities matching.
            </p>
            <div className="flex justify-between border-t border-steel pt-2 text-[10px]">
              <span>Last calibrated:</span>
              <span className="text-white font-mono font-bold">2026-07-27</span>
            </div>
          </div>
        </nav>

        {/* Core Stage View */}
        <main className="flex-1 p-8 overflow-y-auto min-w-0" id="main-content-area">
          {/* Mobile Tab Navigation */}
          <div className="lg:hidden mb-6 flex overflow-x-auto gap-1 pb-2 border-b border-steel" id="mobile-nav">
            {[
              { id: "overview", label: "Executive Dashboard", icon: Briefcase },
              { id: "members", label: "Members", icon: Users },
              { id: "fixed-income", label: "Yield Curve", icon: Sliders },
              { id: "yorkshire", label: "Yorkshire DB", icon: Globe },
              { id: "optimisation", label: "Investment", icon: Scale },
              { id: "ai-briefing", label: "AI Briefing", icon: Sparkles },
              { id: "audit", label: "Security & Audits", icon: ShieldCheck }
            ].map((tab) => {
              const IconComp = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-sm text-xs font-bold transition-all whitespace-nowrap ${
                    activeTab === tab.id 
                      ? "bg-[#D4AF37] text-[#001A33]" 
                      : "text-slate-300 bg-[#001A33] border border-steel"
                  }`}
                >
                  <IconComp className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* API Loading and Error Alerts */}
          {apiError && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl text-xs mb-6 flex items-center justify-between">
              <span className="font-semibold">{apiError}</span>
              <button 
                onClick={fetchAllData}
                className="px-2.5 py-1 bg-red-500/20 text-red-300 rounded font-bold hover:bg-red-500/30 transition-all text-[11px]"
              >
                Reconnect Feed
              </button>
            </div>
          )}

          {isLoading && !members.length ? (
            <div className="h-96 flex flex-col items-center justify-center space-y-4 text-center">
              <div className="w-10 h-10 border-4 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
              <div>
                <h3 className="font-bold text-white text-sm">Interrogating Rust Engine</h3>
                <p className="text-xs text-slate-400 mt-1">Downloading financial assets, membership databases, and Svensson curve coefficients.</p>
              </div>
            </div>
          ) : (
            <>
              {/* Dynamic rendering of selected tab view */}
              {activeTab === "overview" && (
                <OverviewTab 
                  liabilities={liabilities}
                  monteCarlo={monteCarlo}
                  allocations={allocations}
                  esgMetrics={esgMetrics}
                  currentScenario={currentScenario}
                  onScenarioChange={(scenario) => {
                    setCurrentScenario(scenario);
                    // Log the scenario run
                    const scenarioEntry: AuditLog = {
                      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
                      user: "system_cron",
                      role: "SRE Daemon",
                      action: "Switch Stress Scenario",
                      module: "Asset Liability Management",
                      status: "Success",
                      details: `Evaluated financial solvency under stress context: ${scenario}. Asset paths and percentiles updated.`
                    };
                    handleAddSecurityLog(scenarioEntry);
                  }}
                />
              )}

              {activeTab === "members" && (
                <MemberAdminTab 
                  members={members}
                  employers={employers}
                  onAddMember={handleAddMember}
                  onReconcileEmployer={handleReconcileEmployer}
                />
              )}

              {activeTab === "fixed-income" && (
                <FixedIncomeTab 
                  curvePoints={curvePoints}
                  params={curveParams}
                  onParamChange={handleParamChange}
                  onResetParams={handleResetParams}
                />
              )}

              {activeTab === "yorkshire" && yorkshireMetrics && (
                <YorkshireEconomicsTab 
                  metrics={yorkshireMetrics}
                  infrastructureProjects={infrastructureProjects}
                  onInvestInProject={handleInvestInProject}
                />
              )}

              {activeTab === "optimisation" && (
                <PortfolioOptimisationTab 
                  strategies={strategies}
                  currentAllocations={allocations}
                  sovereignTechAllocation={sovereignTechAllocation}
                  esgMetrics={esgMetrics}
                  onApplyAllocation={handleApplyAllocation}
                />
              )}

              {activeTab === "ai-briefing" && (
                <AIBriefingTab 
                  currentScenario={currentScenario}
                />
              )}

              {activeTab === "audit" && (
                <AuditSecurityTab 
                  logs={auditLogs}
                  currentRole={currentRole}
                  onRoleChange={(role) => {
                    setCurrentRole(role);
                    // Add audit entry for scope change
                    const rbacLog: AuditLog = {
                      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
                      user: "crypt-key-validator",
                      role: "SRE Guard",
                      action: "Elevate Scope Permissions",
                      module: "Authorization",
                      status: "Success",
                      details: `User scope successfully transitioned to security role: ${role}. Web tokens signed.`
                    };
                    handleAddSecurityLog(rbacLog);
                  }}
                  onTriggerPenetrationTest={handleAddSecurityLog}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Sleek Design Footer */}
      <footer className="bg-[#001A33] border-t border-steel px-8 py-4 flex flex-col sm:flex-row items-center justify-between text-xs text-[#708090] gap-2" id="platform-footer">
        <div>
          <span>© 2026 <strong className="text-[#D4AF37]">Rhino Bank Institutional</strong> • Leeds Corporate Head Office. All Rights Reserved.</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Svensson Calibration Version: <strong className="text-[#F5F5F0]">BOE_V3.52</strong></span>
          <span className="w-1.5 h-1.5 bg-[#D4AF37] rounded-full" />
          <span>FCA Certified Server Group 12</span>
        </div>
      </footer>

    </div>
  );
}
