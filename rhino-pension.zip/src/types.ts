export interface Member {
  id: string;
  name: string;
  status: "Active" | "Deferred" | "Pensioner";
  age: number;
  employer: string;
  contributionsYtd: number;
  totalAccruedPension: number;
  avcBalance: number;
  beneficiaries: string;
  joinedDate: string;
}

export interface Employer {
  id: string;
  name: string;
  industry: string;
  activeMembers: number;
  monthlyContributionRate: number;
  complianceStatus: "Compliant" | "Pending Review" | "Under Audit";
  lastPaymentDate: string;
}

export interface AuditLog {
  timestamp: string;
  user: string;
  role: string;
  action: string;
  module: string;
  status: "Success" | "Warning" | "Failure";
  details: string;
}

export interface AssetAllocation {
  category: string;
  currentVal: number;
  percentage: number;
  esgScore: number;
  type: string;
}

export interface InfrastructureProject {
  id: string;
  name: string;
  category: string;
  allocatedCapital: number;
  targetIrr: number;
  npv: number;
  progress: number;
  esgScore: number;
  jobsCreated: number;
  desc: string;
}

export interface CurvePoint {
  maturity: number;
  maturityLabel: string;
  nelsonSiegel: number;
  svensson: number;
  forwardRate: number;
}

export interface LiabilityPoint {
  year: number;
  active: number;
  deferred: number;
  pensioner: number;
  total: number;
  projectedAssets: number;
  fundingRatio: number;
}

export interface McPoint {
  year: number;
  assetsP10: number;
  assetsP50: number;
  assetsP90: number;
  inflationP10: number;
  inflationP50: number;
  inflationP90: number;
  ratesP10: number;
  ratesP50: number;
  ratesP90: number;
}

export interface OptimizationStrategy {
  name: string;
  desc: string;
  allocation: { category: string; value: number }[];
  expectedReturn: string;
  volatility: string;
  sharpeRatio: string;
}

export interface YorkshireMetric {
  name: string;
  lat: number;
  lng: number;
  value: number;
  type: string;
}
