import React, { useState } from "react";
import { 
  Lock, 
  Users, 
  RefreshCw, 
  FileText, 
  Key, 
  Activity
} from "lucide-react";
import { AuditLog } from "../types";

interface AuditSecurityTabProps {
  logs: AuditLog[];
  currentRole: string;
  onRoleChange: (role: string) => void;
  onTriggerPenetrationTest: (logEntry: AuditLog) => void;
}

export default function AuditSecurityTab({
  logs,
  currentRole,
  onRoleChange,
  onTriggerPenetrationTest
}: AuditSecurityTabProps) {
  const [mfaEnabled, setMfaEnabled] = useState(true);
  const [apiKeyVisible, setApiKeyVisible] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatus, setScanStatus] = useState<string | null>(null);

  const handleRoleSelect = (role: string) => {
    onRoleChange(role);
  };

  const handlePenetrationScan = () => {
    setIsScanning(true);
    setScanStatus(null);
    setTimeout(() => {
      setIsScanning(false);
      setScanStatus("OWASP & SOC2 Penetration test suite complete. No critical vulnerabilities detected. 4 non-critical TLS cipher warnings mitigated.");
      
      const newEntry: AuditLog = {
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        user: "sec-ops-runner",
        role: "DevSecOps SRE",
        action: "Penetration Scan",
        module: "Security Auditing",
        status: "Success",
        details: "Automated penetration scanner verified REST API authentication, SQL injection boundaries, and cryptographically salted member indexes."
      };
      onTriggerPenetrationTest(newEntry);
    }, 2500);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="audit-security-root">
      
      {/* Col 1 & 2: Audit Trail Log */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="audit-trail-panel">
          <div className="mb-6">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#D4AF37]" />
              Sovereign Quantitative Audit Trail
            </h3>
            <p className="text-xs text-[#708090]">Cryptographically signed system transaction ledger (Rust services log layer)</p>
          </div>

          <div className="space-y-3" id="logs-history-container">
            {logs.map((log, idx) => (
              <div key={idx} className="bg-white/[0.02] p-4 rounded-sm border border-steel hover:border-[#D4AF37]/50 transition-all">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${
                      log.status === "Success" ? "bg-emerald-500" :
                      log.status === "Warning" ? "bg-[#D4AF37]" : "bg-red-500"
                    }`} />
                    <span className="text-xs font-bold text-[#F5F5F0]">{log.action}</span>
                    <span className="text-[10px] text-[#708090] bg-[#001A33] px-2 py-0.5 rounded-sm border border-steel">{log.module}</span>
                  </div>
                  <span className="text-[10px] text-[#708090] font-mono">{log.timestamp}</span>
                </div>

                <p className="text-xs text-slate-300 mt-2 leading-relaxed">{log.details}</p>

                <div className="flex justify-between items-center mt-3 pt-2 border-t border-steel/20 text-[10px] text-[#708090]">
                  <span>Authorized by: <strong className="text-slate-300">{log.user}</strong></span>
                  <span>Role: <strong className="text-[#D4AF37]">{log.role}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Col 3: Role settings, MFA, and Pen tests */}
      <div className="space-y-6">
        
        {/* Role Access Panel */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="role-access-panel">
          <div className="mb-4">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <Users className="w-5 h-5 text-[#D4AF37]" />
              Role-Based Access (RBAC)
            </h3>
            <p className="text-xs text-[#708090]">Select active cryptographic identity profile</p>
          </div>

          <div className="space-y-2.5" id="roles-selectors">
            {[
              { id: "Quantitative Actuary", desc: "Fits Svensson curves, projects liability cashflows, runs ALM stochastics." },
              { id: "Investment Manager", desc: "Rebalances Sovereign Tech and Yorkshire infrastructure pledge weights." },
              { id: "Trustee Board Member", desc: "Generates executive Gemini briefing summaries and signs off recovery terms." },
              { id: "Member Administrator", desc: "Manages member records registry, AVC contribution records, and beneficiaries." }
            ].map((role) => (
              <button
                key={role.id}
                onClick={() => handleRoleSelect(role.id)}
                className={`w-full text-left p-3 rounded-sm border text-xs transition-all flex flex-col relative cursor-pointer ${
                  currentRole === role.id 
                    ? "border-[#D4AF37] bg-white/5 ring-1 ring-[#D4AF37]/20" 
                    : "border-steel bg-white/[0.01] hover:border-[#D4AF37]/50"
                }`}
              >
                {currentRole === role.id && (
                  <div className="absolute top-3.5 right-3 w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
                )}
                <span className={`font-bold ${currentRole === role.id ? "text-[#D4AF37]" : "text-[#F5F5F0]"}`}>{role.id}</span>
                <span className="text-[10px] text-[#708090] mt-1 leading-normal">{role.desc}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Cryptographic Key and Penetration Testing */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="security-operations">
          <div className="mb-4">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <Lock className="w-5 h-5 text-[#D4AF37]" />
              DevSecOps Hardening
            </h3>
            <p className="text-xs text-[#708090]">MFA toggles and automated continuous penetrative testing triggers</p>
          </div>

          <div className="space-y-4">
            
            {/* MFA Switch */}
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-sm border border-steel">
              <div>
                <span className="text-xs font-bold text-white block">Multi-Factor Auth (MFA)</span>
                <span className="text-[10px] text-[#708090] block mt-0.5 font-bold">YubiKey required for reallocations</span>
              </div>
              <button
                onClick={() => setMfaEnabled(!mfaEnabled)}
                className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none border cursor-pointer ${
                  mfaEnabled ? "bg-[#D4AF37] border-[#D4AF37]" : "bg-transparent border-steel"
                }`}
              >
                <span className={`w-4 h-4 bg-[#001A33] rounded-full absolute top-0.5 transition-all ${
                  mfaEnabled ? "right-0.5" : "left-0.5"
                }`} />
              </button>
            </div>

            {/* API Endpoint Access */}
            <div className="p-3 bg-white/5 rounded-sm border border-steel space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-semibold flex items-center gap-1">
                  <Key className="w-3.5 h-3.5 text-[#708090]" /> API Gateway Token
                </span>
                <button 
                  onClick={() => setApiKeyVisible(!apiKeyVisible)}
                  className="text-[10px] text-[#D4AF37] font-bold hover:underline cursor-pointer"
                >
                  {apiKeyVisible ? "Hide" : "Reveal"}
                </button>
              </div>
              <div className="font-mono text-[10px] bg-[#001A33] p-2 rounded-sm text-slate-400 select-all overflow-x-auto whitespace-nowrap border border-steel/30">
                {apiKeyVisible ? "rhino-pk-live-5cf819e83691cb45ef130ab78f2409c1b8f" : "rhino-pk-live-••••••••••••••••••••••••••••••••"}
              </div>
            </div>

            {/* Penetration Testing Hook */}
            <div className="space-y-2">
              <button
                onClick={handlePenetrationScan}
                disabled={isScanning}
                className="w-full bg-[#D4AF37] hover:bg-[#D4AF37]/90 disabled:bg-white/5 text-[#001A33] font-bold py-2.5 rounded-sm text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isScanning ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Fuzzing REST API Endpoints...
                  </>
                ) : (
                  <>
                    <Activity className="w-3.5 h-3.5 text-[#001A33]" /> Execute Penetration Scan
                  </>
                )}
              </button>

              {scanStatus && (
                <div className="p-2.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-sm text-[10px] leading-relaxed">
                  <span className="font-bold block">✓ DevSecOps Scan Passed</span>
                  {scanStatus}
                </div>
              )}
            </div>

            {/* SOC2 Compliance Status */}
            <div className="p-3.5 bg-white/5 rounded-sm border border-steel text-[10px] text-slate-400 space-y-1">
              <span className="text-[#D4AF37] font-bold block uppercase tracking-wider text-[9px]">Sovereign Standards Compliance</span>
              <div className="flex justify-between">
                <span>SOC2 Type II Audit status:</span>
                <span className="text-white font-semibold">Active Compliance</span>
              </div>
              <div className="flex justify-between">
                <span>Database salt:</span>
                <span className="text-slate-300 font-mono">Argon2id (Rust crypt)</span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
