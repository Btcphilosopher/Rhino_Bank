import React, { useState } from "react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell 
} from "recharts";
import { Activity } from "lucide-react";
import { OptimizationStrategy, AssetAllocation } from "../types";

interface PortfolioOptimisationTabProps {
  strategies: OptimizationStrategy[];
  currentAllocations: AssetAllocation[];
  sovereignTechAllocation: any[];
  esgMetrics: any;
  onApplyAllocation: (allocations: AssetAllocation[]) => Promise<void>;
}

const COLORS = ["#D4AF37", "#708090", "#10b981", "#3b82f6", "#8b5cf6", "#ec4899", "#f43f5e", "#14b8a6", "#6b7280"];

export default function PortfolioOptimisationTab({
  strategies,
  currentAllocations,
  sovereignTechAllocation,
  esgMetrics,
  onApplyAllocation
}: PortfolioOptimisationTabProps) {
  const [selectedStrategy, setSelectedStrategy] = useState<OptimizationStrategy>(strategies[1]); // default Black-Litterman
  const [successMsg, setSuccessMsg] = useState("");

  const handleApplyStrategy = async (strategy: OptimizationStrategy) => {
    // Convert strategy allocation percentages to portfolio billions values (Total assets = £9.75B)
    const totalB = 9.75;
    const remapped: AssetAllocation[] = currentAllocations.map(current => {
      // Find matching category in selected strategy
      const stratAlloc = strategy.allocation.find(s => s.category === current.category) || 
                         strategy.allocation.find(s => current.category.includes(s.category)) ||
                         { value: current.percentage }; // fallback

      return {
        ...current,
        percentage: stratAlloc.value,
        currentVal: Math.round((stratAlloc.value / 100) * totalB * 100) / 100
      };
    });

    try {
      await onApplyAllocation(remapped);
      setSuccessMsg(`Applied "${strategy.name}" asset allocation to Rhino Pension Portfolio successfully!`);
      setTimeout(() => setSuccessMsg(""), 5000);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="portfolio-opt-root">
      {/* Col 1 & 2: Optimization Strategies side-by-side & chart comparison */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Strategy Selector and Details */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="opt-comparison">
          <div className="mb-6">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#D4AF37]" />
              Sovereign Portfolio Optimisation Models
            </h3>
            <p className="text-xs text-[#708090]">Quantitative R asset-liability modeling (Black-Litterman, Risk Parity, and LDI frameworks)</p>
          </div>

          {/* Quick Tabs to select strategy */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6" id="opt-strategy-selector">
            {strategies.map((strat, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedStrategy(strat)}
                className={`p-3 rounded-sm border text-left flex flex-col justify-between transition-all cursor-pointer ${
                  selectedStrategy.name === strat.name 
                    ? "border-[#D4AF37] bg-white/5 shadow-md ring-1 ring-[#D4AF37]/20" 
                    : "border-steel bg-white/[0.01] hover:border-[#D4AF37]/50"
                }`}
              >
                <span className="text-[10px] text-[#708090] font-bold block uppercase tracking-wider">Strategy {idx + 1}</span>
                <span className={`text-[11px] font-bold mt-1 line-clamp-1 ${selectedStrategy.name === strat.name ? "text-[#D4AF37]" : "text-[#F5F5F0]"}`}>
                  {strat.name.split(" ")[0]}
                </span>
              </button>
            ))}
          </div>

          {/* Selected Strategy Card */}
          <div className="bg-white/5 p-5 rounded-sm border border-steel mb-6" id="active-strategy-detail">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-4">
              <div>
                <h4 className="font-bold text-[#F5F5F0] text-md">{selectedStrategy.name}</h4>
                <p className="text-xs text-[#708090] mt-1">{selectedStrategy.desc}</p>
              </div>
              <button
                onClick={() => handleApplyStrategy(selectedStrategy)}
                className="px-4 py-2 bg-[#D4AF37] hover:bg-[#D4AF37]/90 text-[#001A33] rounded-sm text-xs font-bold transition-all whitespace-nowrap self-start sm:self-auto cursor-pointer"
              >
                Apply to Pension Portfolio
              </button>
            </div>

            {/* Performance Stats */}
            <div className="grid grid-cols-3 gap-3 p-3 bg-[#001A33]/60 rounded-sm border border-steel text-center mb-4">
              <div>
                <span className="text-[10px] text-[#708090] block uppercase font-bold">Expected Return (Net)</span>
                <span className="text-sm font-extrabold text-[#F5F5F0]">{selectedStrategy.expectedReturn}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#708090] block uppercase font-bold">Annual Volatility</span>
                <span className="text-sm font-extrabold text-[#F5F5F0]">{selectedStrategy.volatility}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#708090] block uppercase font-bold">Sharpe Ratio</span>
                <span className="text-sm font-extrabold text-[#D4AF37]">{selectedStrategy.sharpeRatio}</span>
              </div>
            </div>

            {/* Strategy Allocation Weights Bar Chart */}
            <div className="h-48 w-full" id="opt-chart-stage">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={selectedStrategy.allocation} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(112,128,144,0.1)" />
                  <XAxis dataKey="category" stroke="#708090" fontSize={10} tickFormatter={(tick) => tick.split(" ")[0]} />
                  <YAxis stroke="#708090" fontSize={10} label={{ value: 'Weight (%)', angle: -90, position: 'insideLeft', offset: 12, fill: '#708090', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: "#001A33", border: "1px solid rgba(112,128,144,0.4)" }} />
                  <Bar dataKey="value" fill="#D4AF37" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {successMsg && (
            <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-sm text-xs font-semibold">
              ✓ {successMsg}
            </div>
          )}
        </div>

        {/* Sovereign Tech / Venture Capital Core Allocation */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="sovereign-tech-vc">
          <div className="mb-4">
            <h3 className="text-md font-bold text-[#F5F5F0]">Sovereign Yorkshire Tech & Venture Allocations</h3>
            <p className="text-xs text-[#708090]">Direct venture capital funding targeted at high-productivity Yorkshire advanced manufacturing</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <div className="md:col-span-2 flex items-center justify-center h-48" id="pie-chart-stage">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sovereignTechAllocation}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={70}
                    paddingAngle={3}
                    dataKey="currentVal"
                  >
                    {sovereignTechAllocation.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: "#001A33", border: "1px solid rgba(112,128,144,0.4)" }} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="md:col-span-3 space-y-2.5 flex flex-col justify-center text-xs">
              {sovereignTechAllocation.map((tech, i) => (
                <div key={i} className="flex justify-between items-center py-1 border-b border-steel/20">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: COLORS[i % COLORS.length] }}></span>
                    <span className="text-slate-300 font-medium">{tech.category}</span>
                  </div>
                  <span className="text-[#F5F5F0] font-semibold font-mono">£{tech.currentVal}M <span className="text-[#708090]">({tech.percentage}%)</span></span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Col 3: Factor Exposure and ESG Ratings */}
      <div className="space-y-6">
        
        {/* Factor Exposures Gauges */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="portfolio-risk-factors">
          <h3 className="text-md font-bold text-[#F5F5F0] mb-4">Pension Factor Exposures</h3>
          <p className="text-xs text-[#708090] mb-4">R stress-tested sensitivities across systematic risk drivers</p>
          
          <div className="space-y-3.5" id="factor-sensitivities">
            {[
              { label: "Equity Beta exposure", val: "0.45", range: "Defensive profile", perc: 45, type: "systematic" },
              { label: "Interest Rate Duration match", val: "14.2Y", range: "ALM Highly Matched", perc: 85, type: "systematic" },
              { label: "Inflation Linker indexation", val: "0.68", range: "High inflation defense", perc: 68, type: "inflation" },
              { label: "Credit Spread sensitivity (CS01)", val: "£420k/bp", range: "Investment grade bounds", perc: 52, type: "credit" },
              { label: "Yorkshire Regional alpha premium", val: "1.42%", range: "Direct project outperformance", perc: 75, type: "regional" }
            ].map((factor, i) => (
              <div key={i} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">{factor.label}</span>
                  <span className="text-[#F5F5F0] font-mono font-bold">{factor.val} <span className="text-[10px] text-[#708090]">({factor.range})</span></span>
                </div>
                <div className="w-full bg-white/5 h-2 rounded-sm overflow-hidden border border-steel/50">
                  <div 
                    className={`h-full rounded-sm ${
                      factor.type === "systematic" ? "bg-[#D4AF37]" :
                      factor.type === "inflation" ? "bg-emerald-500" :
                      factor.type === "credit" ? "bg-[#708090]" : "bg-white"
                    }`}
                    style={{ width: `${factor.perc}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ESG Ratings Summary */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="esg-score-breakdown">
          <h3 className="text-md font-bold text-[#F5F5F0] mb-3">Portfolio ESG Score Breakdown</h3>
          
          <div className="p-4 bg-white/5 rounded-sm border-l-4 border-[#D4AF37] text-center mb-4">
            <span className="text-[10px] text-[#708090] uppercase tracking-widest font-bold block">Aggregated Score</span>
            <div className="text-3xl font-black text-[#D4AF37] mt-1">{esgMetrics?.overallEsgScore || "83.4"}/100</div>
            <p className="text-[10px] text-[#708090] mt-2">AAA rating tier according to Leeds ESG Pension framework standards</p>
          </div>

          <div className="space-y-3 text-xs" id="esg-details-list">
            <div className="flex justify-between py-2 border-b border-steel/20">
              <span className="text-slate-400">Regional Jobs Created:</span>
              <span className="text-white font-bold">{esgMetrics?.regionalJobsCreated || "3,710"} apprenticeships</span>
            </div>
            <div className="flex justify-between py-2 border-b border-steel/20">
              <span className="text-slate-400">Carbon Avoidance YTD:</span>
              <span className="text-emerald-400 font-bold">{esgMetrics?.co2ReducedTonsYtd?.toLocaleString() || "145,000"} tCO2e</span>
            </div>
            <div className="flex justify-between py-2 border-b border-steel/20">
              <span className="text-slate-400">Governance Index:</span>
              <span className="text-white font-bold">92% Compliance</span>
            </div>
            <div className="flex justify-between py-2 border-b border-steel/20">
              <span className="text-slate-400">Sponsoring Employer Rating:</span>
              <span className="text-[#D4AF37] font-bold">AAA Sovereign Grade</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
