import React, { useState } from "react";
import Markdown from "react-markdown";
import { Sparkles, FileText, RefreshCw, Printer, Download } from "lucide-react";

interface AIBriefingTabProps {
  currentScenario: string;
}

export default function AIBriefingTab({ currentScenario }: AIBriefingTabProps) {
  const [briefing, setBriefing] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const generateAIBriefing = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/ai/briefing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          activeView: "Trustee Board",
          scenarioName: currentScenario
        })
      });
      const data = await response.json();
      if (data.briefing) {
        setBriefing(data.briefing);
      } else if (data.error) {
        setBriefing(`### AI Engine Standby\n\nAn error occurred while calling the Gemini API:\n\n*${data.error}*`);
      }
    } catch (error: any) {
      console.error(error);
      setBriefing(`### Connectivity Error\n\nFailed to establish link with the Rhino Bank AI server.`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6" id="ai-briefing-root">
      
      {/* Col 1: Report Configurations and prompts */}
      <div className="lg:col-span-1 space-y-6">
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="briefing-controls">
          <h3 className="text-md font-bold text-[#F5F5F0] mb-4">Briefing Parameters</h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-[10px] text-[#708090] block mb-1 font-bold uppercase tracking-wider">Target Audience</label>
              <select className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2.5 rounded-sm">
                <option>Trustee Board of Directors</option>
                <option>Employer Advisory Panel</option>
                <option>Independent Actuarial Auditor</option>
                <option>Prudential Regulatory Authority</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-[#708090] block mb-1 font-bold uppercase tracking-wider">Economic Scenario context</label>
              <div className="p-2.5 bg-white/5 rounded-sm border border-steel text-xs font-semibold text-[#D4AF37]">
                {currentScenario}
              </div>
              <p className="text-[10px] text-[#708090] mt-1 leading-relaxed">
                The generated briefing will analyze portfolio solvency, risk exposures, and regional Yorkshire multipliers under this stress scenario.
              </p>
            </div>

            <div>
              <label className="text-[10px] text-[#708090] block mb-1 font-bold uppercase tracking-wider">Cognitive Mode</label>
              <div className="p-2.5 bg-white/5 rounded-sm border border-steel text-xs text-[#708090] space-y-1">
                <div className="flex justify-between font-bold">
                  <span>Model:</span>
                  <span className="text-[#F5F5F0] font-mono">Gemini 2.5 Flash</span>
                </div>
                <div className="flex justify-between">
                  <span>Task Depth:</span>
                  <span className="font-semibold text-slate-300">Actuarial Summary</span>
                </div>
              </div>
            </div>

            <button
              onClick={generateAIBriefing}
              disabled={isLoading}
              className="w-full bg-[#D4AF37] hover:bg-[#D4AF37]/90 disabled:bg-white/5 text-[#001A33] font-bold py-3 rounded-sm text-xs transition-colors flex items-center justify-center gap-2 shadow-lg cursor-pointer"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> Compiling Quantitative Briefing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" /> Generate AI Trustee Briefing
                </>
              )}
            </button>
          </div>
        </div>

        {/* Documentation / Templates guidance */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="documentation-quicklinks">
          <h4 className="text-xs font-bold text-[#D4AF37] uppercase tracking-widest mb-3">Pre-formatted Formats</h4>
          <div className="space-y-2 text-xs">
            <button className="w-full text-left p-2.5 bg-white/5 rounded-sm border border-steel hover:border-[#D4AF37]/50 text-slate-300 block cursor-pointer">
              <span className="font-bold block text-white text-[11px]">Board Report (Quarterly)</span>
              A complete financial overview of GVA and assets.
            </button>
            <button className="w-full text-left p-2.5 bg-white/5 rounded-sm border border-steel hover:border-[#D4AF37]/50 text-slate-300 block cursor-pointer">
              <span className="font-bold block text-white text-[11px]">Deficit Recovery Agreement</span>
              Structured schedules for pending reviews.
            </button>
            <button className="w-full text-left p-2.5 bg-white/5 rounded-sm border border-steel hover:border-[#D4AF37]/50 text-slate-300 block cursor-pointer">
              <span className="font-bold block text-white text-[11px]">ESG Yorkshire Impact Ledger</span>
              Productivity gains and apprenticeship audits.
            </button>
          </div>
        </div>
      </div>

      {/* Col 2, 3, 4: Report Viewing Window */}
      <div className="lg:col-span-3 flex flex-col space-y-4">
        
        {/* Document Action bar */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-4 flex justify-between items-center" id="briefing-actions">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-[#D4AF37]/10 text-[#D4AF37] rounded-sm">
              <FileText className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-bold text-[#F5F5F0] text-xs sm:text-sm">Actuarial Report Viewer</h3>
              <span className="text-[10px] text-[#708090]">Status: {briefing ? "Generated" : "Ready to Draft"}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => { if(briefing) window.print(); }}
              disabled={!briefing}
              className="p-2 bg-white/5 hover:bg-white/10 text-[#708090] hover:text-white rounded-sm border border-steel disabled:opacity-50 transition-colors cursor-pointer"
              title="Print Document"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button 
              onClick={() => {
                if(!briefing) return;
                const element = document.createElement("a");
                const file = new Blob([briefing], {type: 'text/plain'});
                element.href = URL.createObjectURL(file);
                element.download = `Rhino_Pension_Trustee_Briefing_${currentScenario}.md`;
                document.body.appendChild(element);
                element.click();
              }}
              disabled={!briefing}
              className="p-2 bg-white/5 hover:bg-white/10 text-[#708090] hover:text-white rounded-sm border border-steel disabled:opacity-50 transition-colors cursor-pointer"
              title="Download Markdown File"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Markdown Content Panel */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-8 min-h-[500px] flex flex-col" id="markdown-viewer">
          {isLoading ? (
            <div className="flex-1 flex flex-col items-center justify-center space-y-4 text-center">
              <div className="relative">
                <div className="w-12 h-12 rounded-full border-4 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin" />
                <Sparkles className="w-5 h-5 text-[#D4AF37] absolute top-3.5 left-3.5 animate-pulse" />
              </div>
              <div>
                <h4 className="font-bold text-[#F5F5F0] text-sm">Querying Quantitative GVA Models</h4>
                <p className="text-xs text-[#708090] mt-1 max-w-sm">Generating an expert actuarial summary using natural language engines calibrated with Yorkshire regional indices.</p>
              </div>
            </div>
          ) : briefing ? (
            <div className="markdown-body text-slate-300 text-sm leading-relaxed space-y-4 max-w-none">
              <Markdown>{briefing}</Markdown>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center space-y-4 text-center text-[#708090]">
              <Sparkles className="w-10 h-10 text-slate-700" />
              <div>
                <h4 className="font-bold text-[#708090] text-sm">Briefing Not Generated</h4>
                <p className="text-xs text-[#708090]/80 mt-1 max-w-xs mx-auto">Click "Generate AI Trustee Briefing" on the left to activate Gemini analysis of solvency metrics and the Yorkshire economic multiplier.</p>
              </div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
