import React, { useState } from "react";
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from "recharts";
import { Sliders, RefreshCw, Activity } from "lucide-react";
import { CurvePoint } from "../types";

interface FixedIncomeTabProps {
  curvePoints: CurvePoint[];
  params: { b0: number; b1: number; b2: number; b3: number; tau1: number; tau2: number; tau: number };
  onParamChange: (key: string, value: number) => void;
  onResetParams: () => void;
}

export default function FixedIncomeTab({
  curvePoints,
  params,
  onParamChange,
  onResetParams
}: FixedIncomeTabProps) {
  const [selectedMaturity, setSelectedMaturity] = useState<number>(15);

  // Compute portfolio key statistics dynamically
  const giltPortfolioVal = 2.85; // £2.85B
  const matchedLiabilitiesRatio = 84.5; // % duration matched

  // Derive duration/convexity from selected maturity point
  const selectedPoint = curvePoints.find(p => p.maturity === selectedMaturity) || curvePoints[7]; // default 10Y
  const fittedYield = selectedPoint ? selectedPoint.svensson : 4.12;

  // Derive duration/convexity approximations
  const modifiedDuration = (selectedMaturity / (1 + fittedYield / 100)).toFixed(2);
  const convexity = (selectedMaturity * (selectedMaturity + 1) / Math.pow(1 + fittedYield / 100, 2)).toFixed(2);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="fixed-income-root">
      {/* Col 1 & 2: Yield Curve visualizer */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="yield-curve-visualizer">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#D4AF37]" />
                Yield Curve Fitting & Pricing Surfaces
              </h3>
              <p className="text-xs text-[#708090]">Institutional Svensson vs. Nelson-Siegel curve models (BOE Calibrated)</p>
            </div>
            
            <button 
              onClick={onResetParams}
              className="px-3 py-1.5 bg-[#D4AF37] hover:bg-[#D4AF37]/90 text-[#001A33] rounded-sm text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Reset Calibrations
            </button>
          </div>

          <div className="h-80 w-full" id="curve-chart-container">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={curvePoints} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(112,128,144,0.2)" />
                <XAxis 
                  dataKey="maturity" 
                  stroke="#708090" 
                  fontSize={11} 
                  label={{ value: 'Maturity (Years)', position: 'insideBottom', offset: -5, fill: '#708090', fontSize: 11 }}
                />
                <YAxis 
                  stroke="#708090" 
                  fontSize={11} 
                  domain={[0, 8]}
                  label={{ value: 'Interest Rate (%)', angle: -90, position: 'insideLeft', offset: 10, fill: '#708090', fontSize: 11 }}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#001A33", border: "1px solid rgba(112,128,144,0.4)" }}
                  labelStyle={{ color: "#D4AF37", fontWeight: "bold" }}
                />
                <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" name="Svensson Spot Curve (%)" dataKey="svensson" stroke="#D4AF37" strokeWidth={3} dot={{ r: 3 }} activeDot={{ r: 5 }} />
                <Line type="monotone" name="Nelson-Siegel Spot Curve (%)" dataKey="nelsonSiegel" stroke="#708090" strokeWidth={1.5} dot={false} strokeDasharray="5 5" />
                <Line type="monotone" name="Instantaneous Forward Curve (%)" dataKey="forwardRate" stroke="#10b981" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <p className="text-xs text-[#708090] mt-4 leading-relaxed">
            *Nelson-Siegel parameters characterize Level, Slope, and Curvature with scale decay parameter <span className="text-[#F5F5F0] font-mono">tau</span>. Svensson extends this with a second curvature term and decay factor <span className="text-[#F5F5F0] font-mono">tau2</span>, significantly improving accuracy on ultra-long maturities (30Y to 50Y).
          </p>
        </div>

        {/* Section: Fixed Income duration risk matching */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="hedging-performance">
          <h3 className="text-md font-bold text-[#F5F5F0] mb-4">Gilt Hedging and Liability-Driven Investing (LDI)</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="p-4 bg-white/[0.02] rounded-sm border border-steel">
              <span className="text-[11px] text-[#708090] block uppercase font-bold tracking-wider">Long Gilt Holdings</span>
              <span className="text-lg font-bold text-[#F5F5F0]">£{giltPortfolioVal.toFixed(2)}B</span>
              <span className="text-[9px] text-[#708090] block mt-1">Inflation-linked Gilts 60%</span>
            </div>
            <div className="p-4 bg-white/[0.02] rounded-sm border border-steel">
              <span className="text-[11px] text-[#708090] block uppercase font-bold tracking-wider">Duration Gap Matching</span>
              <span className="text-lg font-bold text-[#D4AF37]">{matchedLiabilitiesRatio}%</span>
              <span className="text-[9px] text-[#708090] block mt-1 font-bold">Target matched ratio: 90.0%</span>
            </div>
            <div className="p-4 bg-white/[0.02] rounded-sm border border-steel">
              <span className="text-[11px] text-[#708090] block uppercase font-bold tracking-wider">Mean Portfolio Yield</span>
              <span className="text-lg font-bold text-[#F5F5F0]">4.18%</span>
              <span className="text-[9px] text-[#708090] block mt-1 font-bold">Fitted credit spread: 45bps</span>
            </div>
          </div>

          <div className="p-4 bg-white/[0.03] rounded-sm border-l-4 border-[#D4AF37] text-xs text-slate-300 leading-relaxed">
            <span className="font-bold text-[#D4AF37] block mb-1 uppercase tracking-wider text-[11px]">Fixed Income Risk Appraisal:</span>
            A 100bps drop in interest rates would increase estimated liabilities by <strong>£1.42B</strong>. The Long Gilt and swap portfolio contains modified duration matching that compensates with a <strong>£1.20B</strong> asset expansion, yielding a net liability gap protection ratio of <strong>84.5%</strong>.
          </div>
        </div>
      </div>

      {/* Col 3: Calibrator Sliders & convexity calculations */}
      <div className="space-y-6">
        {/* Param Sliders */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="yield-curve-parameters">
          <div className="mb-4">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <Sliders className="w-5 h-5 text-[#D4AF37]" />
              R Curve Calibrators
            </h3>
            <p className="text-xs text-[#708090]">Tweak Nelson-Siegel & Svensson parameters in real-time</p>
          </div>

          <div className="space-y-5" id="parameter-sliders">
            {/* Beta 0 */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300 uppercase font-bold text-[10px]">b0 (Asymptotic Level)</span>
                <span className="text-[#D4AF37] font-bold">{params.b0.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="1.00"
                max="8.00"
                step="0.05"
                value={params.b0}
                onChange={(e) => onParamChange("b0", parseFloat(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
              <span className="text-[9px] text-[#708090] block">Influences high-maturity rate level.</span>
            </div>

            {/* Beta 1 */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300 uppercase font-bold text-[10px]">b1 (Slope Term)</span>
                <span className="text-[#D4AF37] font-bold">{params.b1.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="-6.00"
                max="2.00"
                step="0.05"
                value={params.b1}
                onChange={(e) => onParamChange("b1", parseFloat(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
              <span className="text-[9px] text-[#708090] block">Controls short-term steepness (spread 10Y-3M).</span>
            </div>

            {/* Beta 2 */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300 uppercase font-bold text-[10px]">b2 (Curvature Term 1)</span>
                <span className="text-[#D4AF37] font-bold">{params.b2.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="-4.00"
                max="8.00"
                step="0.05"
                value={params.b2}
                onChange={(e) => onParamChange("b2", parseFloat(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
              <span className="text-[9px] text-[#708090] block">Controls first hump in medium-term maturities.</span>
            </div>

            {/* Beta 3 */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300 uppercase font-bold text-[10px]">b3 (Curvature Term 2)</span>
                <span className="text-[#D4AF37] font-bold">{params.b3.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="-6.00"
                max="2.00"
                step="0.05"
                value={params.b3}
                onChange={(e) => onParamChange("b3", parseFloat(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
              <span className="text-[9px] text-[#708090] block">Controls secondary Svensson curve hump.</span>
            </div>

            {/* Tau */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300 uppercase font-bold text-[10px]">tau (Decay Factor 1)</span>
                <span className="text-[#D4AF37] font-bold">{params.tau.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="8.0"
                step="0.1"
                value={params.tau}
                onChange={(e) => onParamChange("tau", parseFloat(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
            </div>

            {/* Tau 2 */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-slate-300 uppercase font-bold text-[10px]">tau2 (Decay Factor 2)</span>
                <span className="text-[#D4AF37] font-bold">{params.tau2.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="15.0"
                step="0.1"
                value={params.tau2}
                onChange={(e) => onParamChange("tau2", parseFloat(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Dynamic Calculator based on Selected Gilt Point */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="gilt-prizing-card">
          <h3 className="text-md font-bold text-[#F5F5F0] mb-4">Gilt Specific Analytics</h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-xs text-[#708090] block mb-1 uppercase font-bold">Target Gilt Maturity</label>
              <select
                value={selectedMaturity}
                onChange={(e) => setSelectedMaturity(parseInt(e.target.value))}
                className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2.5 rounded-sm"
              >
                <option value="5">5-Year Treasury Gilt</option>
                <option value="10">10-Year UK Gilt</option>
                <option value="15">15-Year UK Sovereign Match</option>
                <option value="25">25-Year Pension Linker Gilt</option>
                <option value="50">50-Year Ultra Long Gilt</option>
              </select>
            </div>

            <div className="p-4 bg-white/5 rounded-sm border border-steel space-y-3">
              <div className="flex justify-between text-xs">
                <span className="text-[#708090]">Modeled Spot Rate:</span>
                <span className="font-bold text-[#F5F5F0]">{fittedYield.toFixed(2)}%</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-[#708090]">Modified Duration:</span>
                <span className="font-bold text-[#D4AF37] font-mono">{modifiedDuration} years</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-[#708090]">Convexity (100x):</span>
                <span className="font-bold text-slate-300 font-mono">{convexity}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
