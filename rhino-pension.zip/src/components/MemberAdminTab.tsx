import React, { useState } from "react";
import { 
  Users, 
  Search, 
  UserPlus, 
  Calculator, 
  Building, 
  Upload, 
  RefreshCw, 
  FileText 
} from "lucide-react";
import { Member, Employer } from "../types";

interface MemberAdminTabProps {
  members: Member[];
  employers: Employer[];
  onAddMember: (memberData: any) => Promise<void>;
  onReconcileEmployer: (employerId: string) => Promise<void>;
}

export default function MemberAdminTab({
  members,
  employers,
  onAddMember,
  onReconcileEmployer
}: MemberAdminTabProps) {
  // Member States
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | "Active" | "Deferred" | "Pensioner">("All");
  
  // New Member Form
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState("");
  const [newAge, setNewAge] = useState(40);
  const [newStatus, setNewStatus] = useState<"Active" | "Deferred" | "Pensioner">("Active");
  const [newEmployer, setNewEmployer] = useState("Leeds City Council");
  const [newContributions, setNewContributions] = useState(1500);
  const [newAccrued, setNewAccrued] = useState(5000);
  const [newAvc, setNewAvc] = useState(2500);
  const [newBeneficiary, setNewBeneficiary] = useState("");

  // Calculator States
  const [calcAge, setCalcAge] = useState(45);
  const [calcSalary, setCalcSalary] = useState(45000);
  const [calcAccrualRate, setCalcAccrualRate] = useState(80); // 1/80th or 1/60th
  const [calcService, setCalcService] = useState(15);
  const [calcAvcCont, setCalcAvcCont] = useState(150); // Monthly

  // Payroll CSV Simulation State
  const [payrollFile, setPayrollFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<"idle" | "success" | "error">("idle");
  const [uploadMessage, setUploadMessage] = useState("");

  const filteredMembers = members.filter(m => {
    const matchesSearch = m.name.toLowerCase().includes(searchQuery.toLowerCase()) || m.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = statusFilter === "All" ? true : m.status === statusFilter;
    return matchesSearch && matchesFilter;
  });

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName) return;
    await onAddMember({
      name: newName,
      age: newAge,
      status: newStatus,
      employer: newEmployer,
      contributionsYtd: newContributions,
      totalAccruedPension: newAccrued,
      avcBalance: newAvc,
      beneficiaries: newBeneficiary || "Estate (100%)"
    });
    // Reset form
    setNewName("");
    setNewAge(40);
    setNewStatus("Active");
    setNewContributions(2000);
    setNewAccrued(5000);
    setNewAvc(1000);
    setNewBeneficiary("");
    setShowAddForm(false);
  };

  // Accrued Pension Retirement Calculator logic:
  // Pension = Service * (1/AccrualRate) * Salary + AVC projection
  const estimatedAnnualPension = Math.round(
    calcService * (1 / calcAccrualRate) * calcSalary + 
    (calcAvcCont * 12 * (65 - calcAge) * 1.04) / 15 // Assuming retirement at 65, 4% compounding, 15-year annuity factor
  );

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    setPayrollFile(file);
    setUploadStatus("success");
    setUploadMessage(`Schedules extracted from "${file.name}" (82 active records match Leeds City Council allocation). Reconciliation success!`);
    // Find Leeds City Council and mark compliant
    const lcc = employers.find(emp => emp.name === "Leeds City Council");
    if (lcc) {
      onReconcileEmployer(lcc.id);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="member-admin-root">
      {/* Col 1 & 2: Member and Employer directories */}
      <div className="lg:col-span-2 space-y-6">
        {/* Section A: Member Administration Directory */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="member-directory">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
                <Users className="w-5 h-5 text-[#D4AF37]" />
                Member Records Registry
              </h3>
              <p className="text-xs text-[#708090]">Search and manage Yorkshire Pension scheme participants</p>
            </div>
            
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-3.5 py-1.5 bg-[#D4AF37] hover:bg-[#D4AF37]/90 text-[#001A33] rounded-sm text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto transition-colors cursor-pointer"
            >
              <UserPlus className="w-4 h-4" /> Register Member
            </button>
          </div>

          {/* Quick Stats bar inside directory */}
          <div className="grid grid-cols-4 gap-2 mb-4 p-2 bg-white/5 rounded-sm border border-steel/60 text-center">
            <div>
              <span className="text-[10px] text-[#708090] block font-bold uppercase tracking-wider">Total Registry</span>
              <span className="text-xs font-bold text-[#F5F5F0]">{members.length}</span>
            </div>
            <div>
              <span className="text-[10px] text-[#708090] block font-bold uppercase tracking-wider">Actives</span>
              <span className="text-xs font-bold text-emerald-500">{members.filter(m => m.status === "Active").length}</span>
            </div>
            <div>
              <span className="text-[10px] text-[#708090] block font-bold uppercase tracking-wider">Deferred</span>
              <span className="text-xs font-bold text-slate-400">{members.filter(m => m.status === "Deferred").length}</span>
            </div>
            <div>
              <span className="text-[10px] text-[#708090] block font-bold uppercase tracking-wider">Pensioners</span>
              <span className="text-xs font-bold text-[#D4AF37]">{members.filter(m => m.status === "Pensioner").length}</span>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#708090]" />
              <input
                type="text"
                placeholder="Search by ID or name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 text-[#F5F5F0] text-xs pl-9 pr-4 py-2.5 rounded-sm border border-steel focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
            <div className="flex items-center gap-1 bg-white/5 border border-steel p-0.5 rounded-sm">
              {(["All", "Active", "Deferred", "Pensioner"] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-3 py-1 rounded-sm text-[11px] font-semibold transition-colors ${statusFilter === status ? "bg-[#D4AF37] text-[#001A33]" : "text-slate-300 hover:text-white"}`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>

          {/* Add member form drawer inside panel */}
          {showAddForm && (
            <form onSubmit={handleFormSubmit} className="bg-white/5 p-4 rounded-sm border border-steel mb-6 space-y-4">
              <h4 className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider">Register Participant Profile</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Martha Clitheroe"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Current Age</label>
                  <input
                    type="number"
                    required
                    min="18"
                    max="110"
                    value={newAge}
                    onChange={(e) => setNewAge(parseInt(e.target.value))}
                    className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Status</label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as any)}
                    className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm focus:outline-none focus:border-[#D4AF37]"
                  >
                    <option value="Active">Active Participant</option>
                    <option value="Deferred">Deferred Member</option>
                    <option value="Pensioner">Pensioner Drawdown</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Employer Authority</label>
                  <select
                    value={newEmployer}
                    onChange={(e) => setNewEmployer(e.target.value)}
                    className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm focus:outline-none"
                  >
                    {employers.map(emp => (
                      <option key={emp.id} value={emp.name}>{emp.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Contributions YTD (£)</label>
                  <input
                    type="number"
                    value={newContributions}
                    onChange={(e) => setNewContributions(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Accrued Annual Pension (£)</label>
                  <input
                    type="number"
                    value={newAccrued}
                    onChange={(e) => setNewAccrued(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Beneficiary Allocations</label>
                  <input
                    type="text"
                    placeholder="e.g. John Clitheroe (Spouse, 100%)"
                    value={newBeneficiary}
                    onChange={(e) => setNewBeneficiary(e.target.value)}
                    className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 bg-white/5 text-[#708090] rounded-sm hover:text-white text-xs border border-steel"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-[#D4AF37] text-[#001A33] font-bold rounded-sm hover:bg-[#D4AF37]/90 text-xs"
                >
                  Confirm Registration
                </button>
              </div>
            </form>
          )}

          {/* Table */}
          <div className="overflow-x-auto" id="members-table-scroll">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-steel text-[#708090] text-[10px] uppercase tracking-wider">
                  <th className="py-3 px-2">ID/Member</th>
                  <th className="py-3 px-2">Age</th>
                  <th className="py-3 px-2">Employer</th>
                  <th className="py-3 px-2">Accrued Pension</th>
                  <th className="py-3 px-2">AVC Balance</th>
                  <th className="py-3 px-2 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-steel/30 text-xs">
                {filteredMembers.map((m) => (
                  <tr key={m.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-2">
                      <div className="font-bold text-[#F5F5F0]">{m.name}</div>
                      <span className="text-[10px] text-[#708090] font-mono">{m.id} • Joined {m.joinedDate}</span>
                    </td>
                    <td className="py-3 px-2 text-slate-300 font-semibold">{m.age}</td>
                    <td className="py-3 px-2 text-[#708090]">{m.employer}</td>
                    <td className="py-3 px-2 text-[#F5F5F0] font-bold">£{m.totalAccruedPension.toLocaleString()}/yr</td>
                    <td className="py-3 px-2">
                      {m.avcBalance > 0 ? (
                        <span className="text-[#D4AF37] font-mono font-semibold">£{m.avcBalance.toLocaleString()}</span>
                      ) : (
                        <span className="text-slate-600">—</span>
                      )}
                    </td>
                    <td className="py-3 px-2 text-right">
                      <span className={`inline-block px-2.5 py-0.5 rounded-sm text-[10px] font-bold ${
                        m.status === "Active" ? "bg-emerald-500/10 text-emerald-400" :
                        m.status === "Deferred" ? "bg-slate-500/10 text-slate-400" :
                        "bg-[#D4AF37]/10 text-[#D4AF37]"
                      }`}>
                        {m.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section B: Employer Portal */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="employer-portal">
          <div className="mb-4">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <Building className="w-5 h-5 text-[#D4AF37]" />
              Sponsoring Employer Portal
            </h3>
            <p className="text-xs text-[#708090]">Payroll validation, compliance tracking, and contribution rates</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {employers.map((emp) => (
              <div key={emp.id} className="bg-white/[0.02] border border-steel rounded-sm p-4 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-[#F5F5F0] text-xs">{emp.name}</h4>
                      <span className="text-[10px] text-[#708090] block">{emp.industry}</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded-sm text-[9px] font-bold ${
                      emp.complianceStatus === "Compliant" ? "bg-emerald-500/10 text-emerald-400" :
                      emp.complianceStatus === "Pending Review" ? "bg-[#D4AF37]/10 text-[#D4AF37]" :
                      "bg-red-500/10 text-red-400"
                    }`}>
                      {emp.complianceStatus}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-3 pt-2 border-t border-steel/20 text-[11px]">
                    <div>
                      <span className="text-[#708090] block">Contribution Rate:</span>
                      <span className="font-semibold text-slate-300">{emp.monthlyContributionRate}%</span>
                    </div>
                    <div>
                      <span className="text-[#708090] block">Active Members:</span>
                      <span className="font-semibold text-slate-300">{emp.activeMembers}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4 pt-2 border-t border-steel/20">
                  <span className="text-[10px] text-[#708090]">Last Payment: {emp.lastPaymentDate}</span>
                  {emp.complianceStatus !== "Compliant" && (
                    <button
                      onClick={() => onReconcileEmployer(emp.id)}
                      className="text-[10px] font-bold bg-[#D4AF37] text-[#001A33] px-2.5 py-1 rounded-sm hover:bg-[#D4AF37]/90 transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" /> Reconcile
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Col 3: Actuarial Estimator & Drag-and-drop file upload */}
      <div className="space-y-6">
        {/* Actuarial Calculator */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="actuarial-benefit-estimator">
          <div className="mb-5">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <Calculator className="w-5 h-5 text-[#D4AF37]" />
              Retirement Benefit Modeler
            </h3>
            <p className="text-xs text-[#708090]">R actuarial formula projection for a single participant</p>
          </div>

          <div className="space-y-4" id="calculator-fields">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Current Member Age</span>
                <span className="text-[#F5F5F0] font-bold">{calcAge} years</span>
              </div>
              <input
                type="range"
                min="18"
                max="64"
                value={calcAge}
                onChange={(e) => setCalcAge(parseInt(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Final Pensionable Salary</span>
                <span className="text-[#F5F5F0] font-bold">£{calcSalary.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="15000"
                max="150000"
                step="5000"
                value={calcSalary}
                onChange={(e) => setCalcSalary(parseInt(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Years of Service</span>
                <span className="text-[#F5F5F0] font-bold">{calcService} years</span>
              </div>
              <input
                type="range"
                min="1"
                max="45"
                value={calcService}
                onChange={(e) => setCalcService(parseInt(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Accrual Fraction</label>
                <select
                  value={calcAccrualRate}
                  onChange={(e) => setCalcAccrualRate(parseInt(e.target.value))}
                  className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm"
                >
                  <option value="60">1/60th Accrual</option>
                  <option value="80">1/80th Accrual</option>
                  <option value="120">1/120th Accrual</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-[#708090] block mb-1 uppercase font-bold">Monthly AVC (£)</label>
                <input
                  type="number"
                  min="0"
                  max="5000"
                  value={calcAvcCont}
                  onChange={(e) => setCalcAvcCont(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2 rounded-sm"
                />
              </div>
            </div>

            {/* Projected Result Box */}
            <div className="p-4 bg-white/5 rounded-sm border-l-4 border-[#D4AF37] text-center">
              <span className="text-[10px] text-[#D4AF37] uppercase font-bold tracking-wider">Projected Annual Pension</span>
              <div className="text-2xl font-black text-[#F5F5F0] mt-1">£{estimatedAnnualPension.toLocaleString()} <span className="text-xs text-[#708090]">/ yr</span></div>
              <p className="text-[10px] text-[#708090] mt-2">Calculated assuming retirement age 65, including 4% interest rate compounding on AVC balances.</p>
            </div>
          </div>
        </div>

        {/* Drag and Drop File Upload for payroll schedules */}
        <div 
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          className={`bg-[#001A33] border border-steel rounded-sm p-6 transition-all relative ${
            dragActive ? "border-[#D4AF37] bg-white/5" : ""
          }`}
          id="payroll-csv-uploader"
        >
          <div className="mb-4">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <Upload className="w-5 h-5 text-[#D4AF37]" />
              Payroll Schedule Gateway
            </h3>
            <p className="text-xs text-[#708090]">Upload CSV payroll records to reconcile monthly schedules</p>
          </div>

          <div className="border-2 border-dashed border-steel rounded-sm p-5 text-center cursor-pointer hover:border-[#D4AF37]/50 transition-colors relative">
            <input 
              type="file" 
              accept=".csv" 
              onChange={handleFileSelect} 
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <FileText className="w-8 h-8 text-[#708090] mx-auto mb-2" />
            <span className="text-xs text-slate-300 font-semibold block">Drag & Drop Payroll CSV here</span>
            <span className="text-[10px] text-[#708090] mt-1 block">or click to browse local files</span>
          </div>

          {uploadStatus === "success" && (
            <div className="mt-3 p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-sm text-xs leading-relaxed">
              <span className="font-bold block">✓ CSV Extraction Success</span>
              {uploadMessage}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
