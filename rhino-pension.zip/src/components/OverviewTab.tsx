import React, { useState } from "react";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  LineChart, 
  Line, 
  CartesianGrid
} from "recharts";
import { 
  TrendingUp, 
  Users, 
  ShieldCheck, 
  ArrowUpRight, 
  Briefcase, 
  Activity, 
  Scale 
} from "lucide-react";
import { LiabilityPoint, McPoint, AssetAllocation } from "../types";

interface OverviewTabProps {
  liabilities: LiabilityPoint[];
  monteCarlo: McPoint[];
  allocations: AssetAllocation[];
  esgMetrics: any;
  currentScenario: string;
  onScenarioChange: (scenario: string) => void;
}

export default function OverviewTab({
  liabilities,
  monteCarlo,
  allocations,
  esgMetrics,
  currentScenario,
  onScenarioChange
}: OverviewTabProps) {
  const [activeChart, setActiveChart] = useState<"alm" | "mc">("alm");

  // Sum up assets
  const totalAssetsVal = allocations.reduce((acc, curr) => acc + curr.currentVal, 0);

  return (
    <div className="space-y-6" id="overview-tab-root">
      {/* KPI Top Bar - Sleek Interface style with left-accent borders */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" id="kpi-grid">
        {/* KPI 1 */}
        <div className="kpi-card flex flex-col justify-between min-h-[120px]" id="kpi-assets">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs uppercase tracking-wider text-[#708090] font-bold">Total Managed Assets</span>
            <span className="p-1 bg-[#D4AF37]/10 text-[#D4AF37] rounded-sm">
              <Briefcase className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-[#F5F5F0]">£{totalAssetsVal.toFixed(2)}B</span>
            <span className="text-xs font-semibold text-emerald-500 flex items-center">
              +4.8% <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
          <p className="text-[10px] text-[#708090] mt-2">Valued at historical amortised cost</p>
        </div>

        {/* KPI 2 */}
        <div className="kpi-card flex flex-col justify-between min-h-[120px]" id="kpi-funding-ratio">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs uppercase tracking-wider text-[#708090] font-bold">Sovereign Funding Ratio</span>
            <span className="p-1 bg-[#D4AF37]/10 text-[#D4AF37] rounded-sm">
              <Scale className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-[#D4AF37]">102.4%</span>
            <span className="text-xs font-semibold text-emerald-500 flex items-center">
              Fully Funded
            </span>
          </div>
          <p className="text-[10px] text-[#708090] mt-2">Valuation Rate: 4.25% (BOE Gilts Linked)</p>
        </div>

        {/* KPI 3 */}
        <div className="kpi-card flex flex-col justify-between min-h-[120px]" id="kpi-members">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs uppercase tracking-wider text-[#708090] font-bold">Yorkshire Beneficiaries</span>
            <span className="p-1 bg-[#D4AF37]/10 text-[#D4AF37] rounded-sm">
              <Users className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-[#F5F5F0]">18,340</span>
            <span className="text-xs text-[#708090]">Active / Def / Pens</span>
          </div>
          <p className="text-[10px] text-[#708090] mt-2">Leeds, Sheffield, York & Humber</p>
        </div>

        {/* KPI 4 */}
        <div className="kpi-card flex flex-col justify-between min-h-[120px]" id="kpi-esg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs uppercase tracking-wider text-[#708090] font-bold">Regional ESG Impact</span>
            <span className="p-1 bg-[#D4AF37]/10 text-[#D4AF37] rounded-sm">
              <ShieldCheck className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-[#F5F5F0]">{esgMetrics?.overallEsgScore || "83.4"}/100</span>
            <span className="text-xs font-semibold text-[#D4AF37] flex items-center">
              AAA Rated
            </span>
          </div>
          <p className="text-[10px] text-[#708090] mt-2">Based on local job & green energy creation</p>
        </div>
      </div>

      {/* Main Charts area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="overview-charts-grid">
        {/* Left 2 cols: Advanced Quantitative Modeling */}
        <div className="lg:col-span-2 bg-[#001A33] border border-steel rounded-sm p-6 flex flex-col justify-between" id="chart-panel">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#D4AF37]" />
                Institutional Actuarial & Asset Projections
              </h3>
              <p className="text-xs text-[#708090]">Simulating long-duration liability-matching vs asset growth</p>
            </div>
            
            {/* Toggle buttons */}
            <div className="flex items-center bg-white/5 p-0.5 rounded-sm border border-steel self-start sm:self-auto">
              <button 
                onClick={() => setActiveChart("alm")}
                className={`px-3 py-1.5 rounded-sm text-xs font-semibold transition-colors ${activeChart === "alm" ? "bg-[#D4AF37] text-[#001A33]" : "text-slate-300 hover:text-[#F5F5F0]"}`}
              >
                75Y ALM Match
              </button>
              <button 
                onClick={() => setActiveChart("mc")}
                className={`px-3 py-1.5 rounded-sm text-xs font-semibold transition-colors ${activeChart === "mc" ? "bg-[#D4AF37] text-[#001A33]" : "text-slate-300 hover:text-[#F5F5F0]"}`}
              >
                25Y Monte Carlo
              </button>
            </div>
          </div>

          <div className="h-80 w-full" id="chart-viewport">
            <ResponsiveContainer width="100%" height="100%">
              {activeChart === "alm" ? (
                <AreaChart data={liabilities} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorAssets" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.25}/>
                      <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorLiabilities" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#708090" stopOpacity={0.25}/>
                      <stop offset="95%" stopColor="#708090" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(112,128,144,0.2)" />
                  <XAxis dataKey="year" stroke="#708090" fontSize={11} label={{ value: 'Projection Years', position: 'insideBottom', offset: -5, fill: '#708090', fontSize: 11 }} />
                  <YAxis stroke="#708090" fontSize={11} label={{ value: 'Fund Value (£ Billions)', angle: -90, position: 'insideLeft', offset: 10, fill: '#708090', fontSize: 11 }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#001A33", border: "1px solid rgba(112,128,144,0.4)" }}
                    labelStyle={{ color: "#D4AF37", fontWeight: "bold" }}
                    itemStyle={{ color: "#F5F5F0" }}
                  />
                  <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: 12 }} />
                  <Area type="monotone" name="Projected Fund Assets (Billions)" dataKey="projectedAssets" stroke="#D4AF37" strokeWidth={2} fillOpacity={1} fill="url(#colorAssets)" />
                  <Area type="monotone" name="Estimated Liabilities (Billions)" dataKey="total" stroke="#708090" strokeWidth={2} fillOpacity={1} fill="url(#colorLiabilities)" />
                </AreaChart>
              ) : (
                <LineChart data={monteCarlo} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(112,128,144,0.2)" />
                  <XAxis dataKey="year" stroke="#708090" fontSize={11} />
                  <YAxis stroke="#708090" fontSize={11} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#001A33", border: "1px solid rgba(112,128,144,0.4)" }}
                    labelStyle={{ color: "#D4AF37", fontWeight: "bold" }}
                  />
                  <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: 12 }} />
                  <Line type="monotone" name="Assets P90 (Optimistic Return)" dataKey="assetsP90" stroke="#10b981" strokeWidth={2} dot={false} strokeDasharray="3 3" />
                  <Line type="monotone" name="Assets P50 (Median Return)" dataKey="assetsP50" stroke="#D4AF37" strokeWidth={3} dot={false} />
                  <Line type="monotone" name="Assets P10 (Stress Market)" dataKey="assetsP10" stroke="#ef4444" strokeWidth={2} dot={false} strokeDasharray="3 3" />
                </LineChart>
              )}
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-[#708090] gap-2">
            <p>Active parameters: Wage Inflation 3.5% | Inflation CPI 2.5% | Net Payout: £220M/yr</p>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#D4AF37] inline-block"></span>
              <span>100k+ R stochastic nodes summarized</span>
            </div>
          </div>
        </div>

        {/* Right col: ALM Scenario Selectors & Stress Testing */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6 flex flex-col justify-between" id="scenario-panel">
          <div>
            <h3 className="text-md font-bold text-[#F5F5F0] mb-2">Macro Stress Testing</h3>
            <p className="text-xs text-[#708090] mb-5">Simulate severe market disruptions & Yorkshire policy adjustments</p>
            
            <div className="space-y-3" id="scenarios-list">
              {[
                { id: "Baseline", name: "Baseline Economic Growth", desc: "Stable CPI at 2.5%, average UK equity yield of 7.5%, gilts flat.", color: "border-steel bg-white/[0.02]" },
                { id: "Inflation Spike", name: "High Stagflation Spike", desc: "CPI surges to 6.2%. Liabilities swell, bonds undergo repricing.", color: "border-red-900/40 bg-red-950/10" },
                { id: "Yorkshire Boom", name: "Northern Powerhouse Surge", desc: "Regional GDP up 3%. Yorkshire Infrastructure yields +150bps alpha.", color: "border-amber-900/40 bg-[#D4AF37]/5" },
                { id: "Global Crash", name: "Global Financial Corrective", desc: "Equities contract by 30%. Gilt rates plunge, driving deficit wider.", color: "border-purple-900/40 bg-purple-950/10" }
              ].map((s) => (
                <button
                  key={s.id}
                  onClick={() => onScenarioChange(s.id)}
                  className={`w-full text-left p-3 rounded-sm border transition-all flex flex-col relative ${
                    currentScenario === s.id 
                      ? "border-[#D4AF37] bg-white/[0.05] ring-1 ring-[#D4AF37]/20" 
                      : `${s.color} hover:border-steel`
                  }`}
                >
                  {currentScenario === s.id && (
                    <div className="absolute top-3 right-3 w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
                  )}
                  <span className={`text-xs font-bold ${currentScenario === s.id ? "text-[#D4AF37]" : "text-[#F5F5F0]"}`}>{s.name}</span>
                  <span className="text-[10px] text-[#708090] mt-1 leading-relaxed">{s.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-steel mt-4 text-xs text-[#708090]">
            <div className="flex justify-between items-center mb-1">
              <span>Selected Stress Mode:</span>
              <span className="font-bold text-[#F5F5F0]">{currentScenario}</span>
            </div>
            <div className="flex justify-between items-center">
              <span>R Analytical Engine:</span>
              <span className="font-semibold text-emerald-500 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" /> Hot Standby
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of regional assets and overall breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" id="assets-and-esg-row">
        {/* Left: Current Sovereign Allocation */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="allocation-breakdown">
          <h3 className="text-md font-bold text-[#F5F5F0] mb-4">Sovereign Asset Allocation</h3>
          <div className="space-y-3">
            {allocations.map((alloc, idx) => (
              <div key={idx} className="flex flex-col space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-slate-300">{alloc.category} ({alloc.type})</span>
                  <span className="text-[#F5F5F0]">£{alloc.currentVal.toFixed(2)}B <span className="text-[#708090]">({alloc.percentage}%)</span></span>
                </div>
                <div className="w-full bg-white/5 h-2 rounded-sm overflow-hidden border border-steel/50">
                  <div 
                    className={`h-full rounded-sm ${
                      alloc.type === "Fixed Income" ? "bg-[#708090]" : 
                      alloc.type === "Alternatives" ? "bg-[#D4AF37]" : 
                      alloc.type === "Cash" ? "bg-white/30" : "bg-white"
                    }`}
                    style={{ width: `${alloc.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Actuarial Assumptions Panel */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6 flex flex-col justify-between" id="actuarial-dashboard">
          <div>
            <h3 className="text-md font-bold text-[#F5F5F0] mb-4">Pension Actuarial Assumptions (R calibrated)</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-white/[0.02] rounded-sm border border-steel">
                <span className="text-[11px] text-[#708090] block uppercase font-bold tracking-wider">Wage Inflation</span>
                <span className="text-lg font-bold text-[#F5F5F0]">3.5%</span>
                <span className="text-[9px] text-[#708090] block mt-1">Calibrated from Yorkshire manufacturing payrolls</span>
              </div>
              <div className="p-4 bg-white/[0.02] rounded-sm border border-steel">
                <span className="text-[11px] text-[#708090] block uppercase font-bold tracking-wider">Mortality Basis</span>
                <span className="text-md font-bold text-[#F5F5F0]">S3PMA_L (1.25% CMI)</span>
                <span className="text-[9px] text-[#708090] block mt-1">Continuous Mortality Investigation improvements</span>
              </div>
              <div className="p-4 bg-white/[0.02] rounded-sm border border-steel">
                <span className="text-[11px] text-[#708090] block uppercase font-bold tracking-wider">Discount Rate</span>
                <span className="text-lg font-bold text-[#F5F5F0]">4.25%</span>
                <span className="text-[9px] text-[#708090] block mt-1">Svensson fitted 15-year maturity gilt rate</span>
              </div>
              <div className="p-4 bg-white/[0.02] rounded-sm border border-steel">
                <span className="text-[11px] text-[#708090] block uppercase font-bold tracking-wider">Indexation Growth</span>
                <span className="text-lg font-bold text-[#F5F5F0]">2.5%</span>
                <span className="text-[9px] text-[#708090] block mt-1">Long-term target statutory pension increase</span>
              </div>
            </div>
          </div>

          <div className="bg-white/5 p-4 rounded-sm border border-steel mt-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="flex h-3.5 w-3.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-[#D4AF37]"></span>
              </span>
              <div>
                <span className="text-xs font-bold text-[#F5F5F0] block">Continuous Gilt Feed Connected</span>
                <span className="text-[10px] text-[#708090]">Yield Curve fitted every 5 minutes by R daemon</span>
              </div>
            </div>
            <span className="text-xs font-mono text-[#708090] bg-white/5 px-2 py-0.5 rounded-sm border border-steel">200 OK</span>
          </div>
        </div>
      </div>
    </div>
  );
}
