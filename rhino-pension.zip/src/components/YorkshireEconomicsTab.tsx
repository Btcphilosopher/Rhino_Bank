import React, { useState } from "react";
import { Globe, MapPin, ShieldCheck, PlusCircle, RefreshCw } from "lucide-react";
import { YorkshireMetric, InfrastructureProject } from "../types";

interface YorkshireEconomicsTabProps {
  metrics: {
    regionalGdp: string;
    gdpGrowthRate: string;
    productivityIndex: string;
    employmentRate: string;
    unemploymentRate: string;
    manufacturingGrowth: string;
    engineeringSectorValue: string;
    infrastructureCommitted: string;
    exportsYtd: string;
    universityResearchFunding: string;
    locations: YorkshireMetric[];
  };
  infrastructureProjects: InfrastructureProject[];
  onInvestInProject: (projectId: string, amount: number) => Promise<void>;
}

export default function YorkshireEconomicsTab({
  metrics,
  infrastructureProjects,
  onInvestInProject
}: YorkshireEconomicsTabProps) {
  const [selectedCity, setSelectedCity] = useState<YorkshireMetric | null>(metrics.locations[0]);
  const [pledgeAmount, setPledgeAmount] = useState<number>(10); // £10M default
  const [selectedProject, setSelectedProject] = useState<InfrastructureProject | null>(infrastructureProjects[0]);
  const [isSubmittingPledge, setIsSubmittingPledge] = useState(false);
  const [pledgeStatus, setPledgeStatus] = useState<string | null>(null);

  const handlePledge = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    setIsSubmittingPledge(true);
    setPledgeStatus(null);
    try {
      await onInvestInProject(selectedProject.id, pledgeAmount);
      setPledgeStatus(`Successfully pledged £${pledgeAmount}M into ${selectedProject.name}. Portfolio allocation adjusted.`);
      setTimeout(() => setPledgeStatus(null), 5000);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSubmittingPledge(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="yorkshire-economics-root">
      {/* Col 1 & 2: Regional Map and Economic Grid */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Yorkshire Map & Regional Explorer */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="yorkshire-map-panel">
          <div className="mb-6">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-2">
              <Globe className="w-5 h-5 text-[#D4AF37]" />
              Yorkshire Regional Investment Heat Map
            </h3>
            <p className="text-xs text-[#708090]">Click municipal pins on the spatial coordinate system to inspect localized productivity data</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            
            {/* Interactive SVG Yorkshire Map Layout */}
            <div className="md:col-span-3 bg-white/[0.02] rounded-sm border border-steel p-4 relative flex items-center justify-center min-h-[320px]" id="interactive-map-stage">
              <svg viewBox="0 0 400 400" className="w-full h-full max-h-[300px] text-slate-800 fill-slate-900 stroke-slate-800 stroke-2">
                {/* Simplified Yorkshire County Shape */}
                <path d="M 120 50 L 220 30 L 320 60 L 380 120 L 390 200 L 350 250 L 320 290 L 240 330 L 180 370 L 100 350 L 50 300 L 30 200 L 60 120 Z" className="fill-white/[0.01] stroke-[#708090]/40" />
                
                {/* East Riding Hull Humber Estuary */}
                <path d="M 320 200 C 350 200, 380 240, 350 250 C 320 260, 310 240, 320 200 Z" className="fill-[#D4AF37]/5 stroke-[#D4AF37]/10" />

                {/* Grid gridlines for statistical feel */}
                <line x1="50" y1="0" x2="50" y2="400" stroke="rgba(112,128,144,0.1)" strokeDasharray="2 4" strokeWidth="0.5" />
                <line x1="150" y1="0" x2="150" y2="400" stroke="rgba(112,128,144,0.1)" strokeDasharray="2 4" strokeWidth="0.5" />
                <line x1="250" y1="0" x2="250" y2="400" stroke="rgba(112,128,144,0.1)" strokeDasharray="2 4" strokeWidth="0.5" />
                <line x1="350" y1="0" x2="350" y2="400" stroke="rgba(112,128,144,0.1)" strokeDasharray="2 4" strokeWidth="0.5" />
                <line x1="0" y1="100" x2="400" y2="100" stroke="rgba(112,128,144,0.1)" strokeDasharray="2 4" strokeWidth="0.5" />
                <line x1="0" y1="200" x2="400" y2="200" stroke="rgba(112,128,144,0.1)" strokeDasharray="2 4" strokeWidth="0.5" />
                <line x1="0" y1="300" x2="400" y2="300" stroke="rgba(112,128,144,0.1)" strokeDasharray="2 4" strokeWidth="0.5" />

                {/* Interactive Pins */}
                {metrics.locations.map((loc, index) => {
                  const y = 350 - ((loc.lat - 53.3) * 450);
                  const x = 50 + ((loc.lng - (-1.9)) * 200);

                  return (
                    <g 
                      key={index} 
                      className="cursor-pointer group"
                      onClick={() => setSelectedCity(loc)}
                    >
                      <circle 
                        cx={x} 
                        cy={y} 
                        r={selectedCity?.name === loc.name ? 12 : 7} 
                        className={`transition-all duration-300 ${
                          selectedCity?.name === loc.name 
                            ? "fill-[#D4AF37]/20 stroke-[#D4AF37] animate-pulse" 
                            : "fill-white/10 stroke-[#708090] group-hover:fill-[#D4AF37]/10 group-hover:stroke-[#D4AF37]"
                        }`}
                      />
                      <circle 
                        cx={x} 
                        cy={y} 
                        r={3} 
                        className={selectedCity?.name === loc.name ? "fill-[#D4AF37]" : "fill-slate-400 group-hover:fill-[#D4AF37]"} 
                      />
                      <text 
                        x={x + 10} 
                        y={y + 4} 
                        className={`text-[9px] font-bold select-none ${
                          selectedCity?.name === loc.name ? "fill-[#D4AF37] font-black" : "fill-[#708090]"
                        }`}
                      >
                        {loc.name}
                      </text>
                    </g>
                  );
                })}
              </svg>

              <div className="absolute bottom-3 left-3 text-[10px] text-[#708090] bg-white/5 px-2 py-0.5 rounded-sm border border-steel">
                Mercator Projection Grid
              </div>
            </div>

            {/* Localized data readout */}
            <div className="md:col-span-2 flex flex-col justify-between" id="city-readout">
              {selectedCity ? (
                <div className="space-y-4">
                  <div className="p-4 bg-white/5 rounded-sm border border-steel">
                    <span className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-wider block">Selected Regional Cluster</span>
                    <h4 className="text-md font-black text-[#F5F5F0] flex items-center gap-1 mt-1">
                      <MapPin className="w-5 h-5 text-[#D4AF37]" />
                      {selectedCity.name}
                    </h4>
                    <span className="text-xs text-[#708090] font-bold block mt-1">{selectedCity.type}</span>
                  </div>

                  <div className="space-y-2.5 text-xs">
                    <div className="flex justify-between py-1.5 border-b border-steel/20">
                      <span className="text-slate-400">Regional Cluster Rating</span>
                      <span className="text-[#F5F5F0] font-bold font-mono">{selectedCity.value} / 100</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-steel/20">
                      <span className="text-slate-400">Investment Focus</span>
                      <span className="text-slate-300 font-semibold">{selectedCity.type}</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-steel/20">
                      <span className="text-slate-400">Co-Funding Partners</span>
                      <span className="text-slate-300 font-semibold font-serif italic">Municipal Authorities & Universities</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-steel/20">
                      <span className="text-slate-400">Status</span>
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> Capital Generating
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-6 text-center text-[#708090] bg-white/5 rounded-sm border border-steel flex items-center justify-center h-full">
                  Click on any map cluster pin to query localized indices
                </div>
              )}

              <div className="bg-white/5 p-4 rounded-sm border border-steel mt-4 text-[11px] text-[#708090] leading-relaxed">
                <strong>Yorkshire Economic Feedback:</strong> Long-term investment in regional infrastructure boosts local GVA, increasing council business tax revenues, thereby improving sponsoring employer compliance stability.
              </div>
            </div>

          </div>
        </div>

        {/* Infrastructure financing table */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="infrastructure-assets">
          <div className="mb-4">
            <h3 className="text-md font-bold text-[#F5F5F0]">Sovereign Yorkshire Infrastructure Portfolio</h3>
            <p className="text-xs text-[#708090]">Direct investment positions in local transport, energy, and engineering</p>
          </div>

          <div className="overflow-x-auto" id="infra-table-scroll">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-steel text-[#708090] text-[10px] uppercase tracking-wider">
                  <th className="py-2.5 px-2">Project</th>
                  <th className="py-2.5 px-2">Sector</th>
                  <th className="py-2.5 px-2">Capital Allocation</th>
                  <th className="py-2.5 px-2">IRR / NPV</th>
                  <th className="py-2.5 px-2">ESG</th>
                  <th className="py-2.5 px-2 text-right">Construction Progress</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-steel/20 text-xs">
                {infrastructureProjects.map((p) => (
                  <tr key={p.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-2">
                      <span className="font-bold text-[#F5F5F0] block">{p.name}</span>
                      <span className="text-[10px] text-[#708090] block line-clamp-1">{p.desc}</span>
                    </td>
                    <td className="py-3 px-2 text-[#708090]">{p.category}</td>
                    <td className="py-3 px-2 font-mono text-slate-300 font-semibold">£{(p.allocatedCapital / 1000000).toFixed(1)}M</td>
                    <td className="py-3 px-2">
                      <div className="text-emerald-400 font-semibold font-mono">{(p.targetIrr * 100).toFixed(1)}% IRR</div>
                      <span className="text-[10px] text-[#708090] font-mono">£{(p.npv / 1000000).toFixed(1)}M NPV</span>
                    </td>
                    <td className="py-3 px-2">
                      <span className="text-[#D4AF37] font-extrabold flex items-center gap-0.5">
                        <ShieldCheck className="w-3.5 h-3.5" /> {p.esgScore}
                      </span>
                    </td>
                    <td className="py-3 px-2 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="text-[10px] text-slate-400 font-semibold">{(p.progress * 100).toFixed(0)}%</span>
                        <div className="w-16 bg-white/5 h-1.5 rounded-sm overflow-hidden border border-steel/50">
                          <div className="bg-[#D4AF37] h-full rounded-sm" style={{ width: `${p.progress * 100}%` }} />
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* Col 3: Yorkshire Dashboard KPIs and Pledge form */}
      <div className="space-y-6">
        
        {/* Economic KPIs */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="yorkshire-economy-kpis">
          <h3 className="text-md font-bold text-[#F5F5F0] mb-4">Yorkshire Economic Indicators</h3>
          <div className="space-y-4" id="economy-indicators">
            {[
              { label: "Regional GDP (Gross Value Add)", val: metrics.regionalGdp, trend: metrics.gdpGrowthRate, trendUp: true },
              { label: "Productivity Index (Relative to UK)", val: metrics.productivityIndex, trend: "Target 100.0", trendUp: false },
              { label: "Regional Manufacturing Expansion", val: metrics.manufacturingGrowth, trend: "Sector Outperforming UK", trendUp: true },
              { label: "Committed Infra Under Management", val: metrics.infrastructureCommitted, trend: "AAA Capital Tier", trendUp: true },
              { label: "Export Volumes YTD", val: metrics.exportsYtd, trend: "Engineering led", trendUp: true },
              { label: "University Research Grants Funding", val: metrics.universityResearchFunding, trend: "Leeds-Sheffield-York Array", trendUp: true }
            ].map((ind, i) => (
              <div key={i} className="p-3 bg-white/[0.02] rounded-sm border border-steel flex justify-between items-center">
                <div>
                  <span className="text-[10px] text-[#708090] block font-bold uppercase tracking-wider">{ind.label}</span>
                  <span className="text-xs font-bold text-[#F5F5F0] block mt-0.5">{ind.val}</span>
                </div>
                <div className="text-right">
                  <span className={`text-[10px] font-bold ${ind.trendUp ? "text-emerald-400" : "text-[#708090]"}`}>{ind.trend}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Capital Allocator Pledge Form */}
        <div className="bg-[#001A33] border border-steel rounded-sm p-6" id="capital-allocator-form">
          <div className="mb-4">
            <h3 className="text-md font-bold text-[#F5F5F0] flex items-center gap-1.5">
              <PlusCircle className="w-5 h-5 text-[#D4AF37]" />
              Infrastructure Capital Pledge
            </h3>
            <p className="text-xs text-[#708090]">Increase direct funding into approved regional development projects</p>
          </div>

          <form onSubmit={handlePledge} className="space-y-4">
            <div>
              <label className="text-xs text-[#708090] block mb-1 uppercase font-bold">Target Project</label>
              <select
                value={selectedProject ? selectedProject.id : ""}
                onChange={(e) => {
                  const found = infrastructureProjects.find(p => p.id === e.target.value);
                  if (found) setSelectedProject(found);
                }}
                className="w-full bg-[#001A33] border border-steel text-[#F5F5F0] text-xs p-2.5 rounded-sm focus:outline-none"
              >
                {infrastructureProjects.map(p => (
                  <option key={p.id} value={p.id}>{p.name} ({(p.targetIrr * 100).toFixed(1)}% IRR)</option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#708090] uppercase font-bold text-[10px]">Pledge Capital Amount</span>
                <span className="text-[#F5F5F0] font-bold">£{pledgeAmount} Million</span>
              </div>
              <input
                type="range"
                min="5"
                max="100"
                step="5"
                value={pledgeAmount}
                onChange={(e) => setPledgeAmount(parseInt(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
              <span className="text-[9px] text-[#708090] block">Funds drawn from Cash reserves.</span>
            </div>

            {selectedProject && (
              <div className="p-3 bg-white/5 rounded-sm border border-steel text-[11px] text-[#708090] space-y-1.5">
                <div className="flex justify-between font-bold text-slate-300">
                  <span>Project IRR:</span>
                  <span className="text-emerald-400">{(selectedProject.targetIrr * 100).toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Jobs to be Created:</span>
                  <span className="text-[#F5F5F0] font-semibold">{Math.round(selectedProject.jobsCreated * (1 + pledgeAmount / 100))}</span>
                </div>
                <div className="flex justify-between">
                  <span>Incremental ESG Impact:</span>
                  <span className="text-[#D4AF37] font-bold">+{(pledgeAmount / 5).toFixed(0)} rating weights</span>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmittingPledge}
              className="w-full bg-[#D4AF37] hover:bg-[#D4AF37]/90 disabled:bg-white/5 text-[#001A33] font-bold py-2.5 rounded-sm text-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
            >
              {isSubmittingPledge ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Committing Funding Round...
                </>
              ) : (
                "Pledge Capital Allocation"
              )}
            </button>

            {pledgeStatus && (
              <div className="p-2.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-sm text-xs">
                {pledgeStatus}
              </div>
            )}
          </form>
        </div>

      </div>
    </div>
  );
}
