/**
 * RHINOQUANT CDS — High Density Main Navigation Bar
 */

import React from 'react';
import {
  TrendingUp,
  Calculator,
  GitCommit,
  Percent,
  Scale,
  Briefcase,
  ShieldAlert,
  Flame,
  Layers,
  Search,
  FileCheck
} from 'lucide-react';

export type MainTab =
  | 'MARKETS'
  | 'PRICING'
  | 'CURVES'
  | 'DEFAULT_PROB'
  | 'BASIS'
  | 'PORTFOLIO'
  | 'RISK'
  | 'SCENARIOS'
  | 'TRADING'
  | 'RESEARCH'
  | 'REPORTS';

interface NavigationProps {
  activeTab: MainTab;
  setActiveTab: (tab: MainTab) => void;
  openOrdersCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab, openOrdersCount }) => {
  const tabs: { id: MainTab; label: string; icon: React.FC<{ className?: string }>; badge?: number }[] = [
    { id: 'MARKETS', label: 'MARKETS', icon: TrendingUp },
    { id: 'PRICING', label: 'CDS PRICING', icon: Calculator },
    { id: 'CURVES', label: 'CURVES', icon: GitCommit },
    { id: 'DEFAULT_PROB', label: 'DEFAULT PROB', icon: Percent },
    { id: 'BASIS', label: 'CDS BASIS', icon: Scale },
    { id: 'PORTFOLIO', label: 'PORTFOLIO', icon: Briefcase },
    { id: 'RISK', label: 'RISK / JTD', icon: ShieldAlert },
    { id: 'SCENARIOS', label: 'SCENARIOS', icon: Flame },
    { id: 'TRADING', label: 'BLOTTER', icon: Layers, badge: openOrdersCount },
    { id: 'RESEARCH', label: 'RESEARCH', icon: Search },
    { id: 'REPORTS', label: 'REPORTS', icon: FileCheck },
  ];

  return (
    <nav id="rhinoquant-main-nav" className="bg-[#09090b] border-b border-[#27272a] px-2 flex items-center overflow-x-auto no-scrollbar h-[34px]">
      <div className="flex space-x-0.5 py-0 h-full items-center">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`nav-tab-${tab.id.toLowerCase()}`}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-2.5 h-full text-[10px] font-sans font-semibold tracking-wider transition-all whitespace-nowrap cursor-pointer border-b-2 uppercase ${
                isActive
                  ? 'bg-[#18181b] text-[#e4e4e7] border-[#f97316]'
                  : 'text-[#a1a1aa] hover:text-[#e4e4e7] hover:bg-[#111114] border-transparent'
              }`}
            >
              <Icon className={`w-3 h-3 ${isActive ? 'text-[#f97316]' : 'text-[#71717a]'}`} />
              <span>{tab.label}</span>
              {tab.badge !== undefined && tab.badge > 0 && (
                <span className="ml-1 px-1 py-0 text-[9px] rounded-[2px] bg-[#f97316]/20 text-[#f97316] font-mono font-bold border border-[#f97316]/40">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
