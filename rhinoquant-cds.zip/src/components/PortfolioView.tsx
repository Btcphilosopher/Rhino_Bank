/**
 * RHINOQUANT CDS — Portfolio Blotter & Exposure Analytics (High Density)
 * Gross/Net Notional, MTM P&L, CS01, JTD, Sector/Rating/Counterparty Concentration
 */

import React, { useState } from 'react';
import {
  Briefcase,
  Plus
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from 'recharts';
import { CDSPosition, PortfolioRiskSummary } from '../types/cds';

interface PortfolioViewProps {
  positions: CDSPosition[];
  riskSummary: PortfolioRiskSummary;
  onUnwindPosition: (positionId: string) => void;
  onOpenNewOrder: () => void;
}

const SECTOR_COLORS = ['#f97316', '#38bdf8', '#22c55e', '#a855f7', '#ec4899', '#f43f5e', '#eab308'];

export const PortfolioView: React.FC<PortfolioViewProps> = ({
  positions,
  riskSummary,
  onUnwindPosition,
  onOpenNewOrder,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'SINGLE_NAME' | 'INDEX'>('ALL');

  const filteredPositions = positions.filter((p) => {
    if (selectedFilter === 'ALL') return true;
    return p.contractType === selectedFilter;
  });

  const sectorChartData = Object.entries(riskSummary?.sectorConcentration || {}).map(([name, notional]) => ({
    name,
    value: Number(notional),
    displayVal: (Number(notional) / 1e6).toFixed(1) + 'M',
  }));

  const ratingChartData = Object.entries(riskSummary?.ratingConcentration || {}).map(([rating, notional]) => ({
    rating,
    notionalM: Number((Number(notional) / 1e6).toFixed(1)),
  }));

  const grossNotional = riskSummary?.totalGrossNotional ?? 0;
  const netNotional = riskSummary?.totalNetNotional ?? 0;
  const totalCS01 = riskSummary?.totalCS01 ?? 0;
  const totalMTM = riskSummary?.totalMTM ?? 0;
  const maxNetJTD = riskSummary?.maxNetJTD ?? 0;
  const expectedLoss1Y = riskSummary?.expectedLoss1Y ?? 0;

  return (
    <div id="portfolio-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top Banner & Portfolio Level KPI Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2 font-mono text-[10px]">
        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Gross / Net Notional</div>
          <div className="text-[13px] font-bold text-[#e4e4e7] mt-0.5">
            ${(grossNotional / 1e6).toFixed(1)}M / ${(netNotional / 1e6).toFixed(1)}M
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">{positions.length} Active Contracts</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Portfolio CS01</div>
          <div className={`text-[13px] font-bold mt-0.5 ${totalCS01 >= 0 ? 'text-emerald-400' : 'text-[#f97316]'}`}>
            {totalCS01 >= 0 ? '+' : ''}${totalCS01.toLocaleString()}/bp
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Spread 1bp Delta</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Total MTM Value / P&L</div>
          <div className={`text-[13px] font-bold mt-0.5 ${totalMTM >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalMTM >= 0 ? '+' : ''}${totalMTM.toLocaleString()}
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">ISDA Mark-to-Market</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Max Net JTD Exposure</div>
          <div className="text-[13px] font-bold text-rose-400 mt-0.5">
            ${(maxNetJTD / 1e6).toFixed(2)}M
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Instant Default Risk</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Expected Loss (1Y)</div>
          <div className="text-[13px] font-bold text-[#f97316] mt-0.5">
            ${expectedLoss1Y.toLocaleString()}
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Base Default Expectation</div>
        </div>
      </div>

      {/* Main Position Blotter Table */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#27272a] pb-1.5 mb-2">
          <div className="flex items-center gap-1.5">
            <Briefcase className="w-3.5 h-3.5 text-[#f97316]" />
            <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
              ACTIVE CREDIT POSITIONS BLOTTER
            </span>
          </div>

          <div className="flex items-center gap-2 font-mono text-[10px]">
            <div className="flex bg-[#09090b] rounded-[2px] p-0.5 border border-[#27272a]">
              <button
                onClick={() => setSelectedFilter('ALL')}
                className={`px-2 py-0.5 rounded-[2px] cursor-pointer ${selectedFilter === 'ALL' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
              >
                All ({positions.length})
              </button>
              <button
                onClick={() => setSelectedFilter('SINGLE_NAME')}
                className={`px-2 py-0.5 rounded-[2px] cursor-pointer ${selectedFilter === 'SINGLE_NAME' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
              >
                Single Name
              </button>
              <button
                onClick={() => setSelectedFilter('INDEX')}
                className={`px-2 py-0.5 rounded-[2px] cursor-pointer ${selectedFilter === 'INDEX' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
              >
                Index
              </button>
            </div>

            <button
              id="portfolio-add-pos-btn"
              onClick={onOpenNewOrder}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] font-bold rounded-[2px] cursor-pointer uppercase"
            >
              <Plus className="w-3 h-3" />
              <span>NEW POSITION</span>
            </button>
          </div>
        </div>

        <table id="positions-blotter-table" className="w-full text-[10px] font-mono text-left border-collapse">
          <thead>
            <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
              <th className="py-1.5 px-2.5">Position / Ticker</th>
              <th className="py-1.5 px-2">Type</th>
              <th className="py-1.5 px-2">Side</th>
              <th className="py-1.5 px-2 text-right">Notional</th>
              <th className="py-1.5 px-2 text-right">Coupon</th>
              <th className="py-1.5 px-2 text-right">Mkt Spread</th>
              <th className="py-1.5 px-2.5 text-right bg-[#18181b]">MTM Value</th>
              <th className="py-1.5 px-2 text-right">CS01</th>
              <th className="py-1.5 px-2 text-right">JTD P&L</th>
              <th className="py-1.5 px-2">Counterparty</th>
              <th className="py-1.5 px-2 text-center">Unwind</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f1f23]">
            {filteredPositions.map((p) => {
              const isBuyer = p.buySell === 'BUY';
              return (
                <tr key={p.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="py-1 px-2.5">
                    <div className="font-semibold text-[#e4e4e7] flex items-center gap-1">
                      <span className="text-[#f97316] font-bold">{p.ticker}</span>
                      <span className="text-[9px] text-[#71717a]">({p.tenor})</span>
                    </div>
                    <div className="text-[8px] text-[#71717a]">{p.id} • Mat: {p.maturityDate}</div>
                  </td>
                  <td className="py-1 px-2 text-[#a1a1aa] text-[9px]">{p.contractType}</td>
                  <td className="py-1 px-2">
                    <span
                      className={`px-1.5 py-0.2 rounded-[2px] text-[8px] font-bold ${
                        isBuyer
                          ? 'bg-orange-950 text-orange-300 border border-orange-800'
                          : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                      }`}
                    >
                      {p.buySell === 'BUY' ? 'LONG' : 'SHORT'}
                    </span>
                  </td>
                  <td className="py-1 px-2 text-right text-[#e4e4e7] font-semibold">
                    ${((p.notional ?? 0) / 1e6).toFixed(1)}M
                  </td>
                  <td className="py-1 px-2 text-right text-[#a1a1aa]">{p.coupon} bp</td>
                  <td className="py-1 px-2 text-right text-[#f97316] font-semibold">{(p.marketSpread ?? 0).toFixed(1)} bp</td>
                  <td className="py-1 px-2.5 text-right font-extrabold bg-[#18181b]/30">
                    <span className={(p.mtm ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                      {(p.mtm ?? 0) >= 0 ? '+' : ''}${(p.mtm ?? 0).toLocaleString()}
                    </span>
                  </td>
                  <td className="py-1 px-2 text-right">
                    <span className={(p.cs01 ?? 0) >= 0 ? 'text-emerald-400' : 'text-[#f97316]'}>
                      {(p.cs01 ?? 0) >= 0 ? '+' : ''}${(p.cs01 ?? 0).toLocaleString()}
                    </span>
                  </td>
                  <td className="py-1 px-2 text-right font-bold text-[#e4e4e7]">
                    {(p.jtd ?? 0) >= 0 ? '+' : ''}${((p.jtd ?? 0) / 1e6).toFixed(2)}M
                  </td>
                  <td className="py-1 px-2 text-[#a1a1aa] text-[9px]">
                    <div>{p.counterparty}</div>
                    <div className="text-[8px] text-emerald-400">{p.clearingHouse} (Cleared)</div>
                  </td>
                  <td className="py-1 px-2 text-center">
                    <button
                      onClick={() => onUnwindPosition(p.id)}
                      className="px-1.5 py-0.2 bg-rose-950/60 hover:bg-rose-900 border border-rose-800/60 text-rose-300 rounded-[2px] text-[9px] font-mono cursor-pointer transition-colors"
                      title="Unwind Position in Market"
                    >
                      UNWIND
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Lower Analytics: Sector and Rating Breakdown Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
        {/* Sector Allocation Breakdown */}
        <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px]">
          <div className="text-[10px] font-mono font-bold text-[#e4e4e7] uppercase tracking-wider mb-2">
            Sector Gross Notional Allocation
          </div>
          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sectorChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={65}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {sectorChartData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={SECTOR_COLORS[index % SECTOR_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: number) => [`$${(val / 1e6).toFixed(1)}M Notional`, 'Gross Exposure']}
                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', color: '#e4e4e7', fontFamily: 'monospace', fontSize: 11 }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Rating Category Breakdown */}
        <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px]">
          <div className="text-[10px] font-mono font-bold text-[#e4e4e7] uppercase tracking-wider mb-2">
            Credit Rating Exposure Distribution ($M Notional)
          </div>
          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ratingChartData} margin={{ top: 10, right: 15, left: 5, bottom: 5 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#27272a" />
                <XAxis dataKey="rating" stroke="#71717a" tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }} />
                <YAxis stroke="#71717a" tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }} unit="M" />
                <Tooltip
                  formatter={(val: number) => [`$${val}M Notional`, 'Exposure']}
                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', color: '#e4e4e7', fontFamily: 'monospace', fontSize: 11 }}
                />
                <Bar dataKey="notionalM" fill="#f97316" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
