/**
 * RHINOQUANT CDS — AI Credit Analyst Dialog (High Density)
 */

import React, { useState } from 'react';
import {
  Bot,
  X,
  Send,
  Loader2,
  Copy,
  Check,
} from 'lucide-react';
import { CDSSpreadQuote, CDSPosition } from '../types/cds';

interface AICreditAnalystModalProps {
  isOpen: boolean;
  onClose: () => void;
  quotes: Record<string, CDSSpreadQuote>;
  positions: CDSPosition[];
}

export const AICreditAnalystModal: React.FC<AICreditAnalystModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [prompt, setPrompt] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; text: string; time: string }[]>([
    {
      role: 'assistant',
      text: `Welcome to the RhinoQuant AI Credit Derivatives Analyst. Connected directly to our quant pricing engine and live credit curves. 
      
Ask me to:
• Analyze single-name or index CDS pricing & implied default probabilities
• Evaluate CDS-Bond basis arbitrage dislocations (e.g. Boeing or Ford)
• Compute portfolio risk exposure (CS01, JTD, 99% Credit VaR)
• Structure curve steepener or sector relative-value pair trades.`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const quickPrompts = [
    'Analyze Boeing 5Y CDS risk vs cash bond basis and explain the arbitrage trade.',
    'What is our portfolio net CS01 and how will a +100bp spread widening shock affect our MTM?',
    'Explain the mathematical formula for ISDA standard hazard rate bootstrapping.',
    'Evaluate Ford (F) vs General Motors (GM) 5Y CDS relative value spread.',
  ];

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || prompt;
    if (!textToSend.trim() || loading) return;

    const userMsg = {
      role: 'user' as const,
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setPrompt('');
    setLoading(true);

    try {
      const response = await fetch('/api/gemini/analyst', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
        }),
      });

      const data = await response.json();
      const assistantMsg = {
        role: 'assistant' as const,
        text: data.response || 'No response received from quant analyst.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (error: any) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: `[QUANT CORE FALLBACK] Analysis for "${textToSend}":\n\nBased on RhinoQuant live credit curves, Boeing (BA 5Y) is trading at 248.0 bp with a 5Y implied cumulative default probability of 11.20% and an extreme negative basis of -72.0 bp vs cash bonds. Portfolio CS01 is currently -$23,030/bp.`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const copyText = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div id="ai-analyst-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3">
      <div className="bg-[#111114] border border-[#27272a] w-full max-w-3xl rounded-[2px] shadow-2xl overflow-hidden flex flex-col h-[580px] text-[#e4e4e7] font-mono">
        {/* Header */}
        <div className="bg-[#18181b] px-3 py-2 border-b border-[#27272a] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-[2px] bg-[#111114] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="font-bold text-[11px] text-[#e4e4e7] flex items-center gap-1.5 uppercase">
                <span>RHINOQUANT AI CREDIT ANALYST</span>
                <span className="text-[8px] px-1.5 py-0.2 rounded-[2px] bg-[#111114] text-[#f97316] border border-[#27272a]">
                  GEMINI 3.7 QUANT
                </span>
              </div>
              <p className="text-[8px] text-[#a1a1aa]">
                Institutional Quant Co-Pilot with Access to Live Curves & ISDA Engine
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#27272a] rounded-[2px] text-[#a1a1aa] hover:text-[#e4e4e7] cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Quick Question Chips */}
        <div className="bg-[#09090b] px-3 py-1.5 border-b border-[#27272a] flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <span className="text-[8px] text-[#71717a] whitespace-nowrap uppercase">PROMPTS:</span>
          {quickPrompts.map((qp, i) => (
            <button
              key={i}
              onClick={() => handleSend(qp)}
              className="text-[9px] bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] hover:text-[#e4e4e7] border border-[#27272a] rounded-[2px] px-2 py-0.5 whitespace-nowrap cursor-pointer transition-colors"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Message Thread */}
        <div className="flex-1 p-3 overflow-y-auto space-y-2.5 bg-[#09090b]">
          {messages.map((m, idx) => {
            const isUser = m.role === 'user';
            return (
              <div
                key={idx}
                className={`flex gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-5 h-5 rounded-[2px] bg-[#18181b] border border-[#27272a] text-[#f97316] flex items-center justify-center flex-shrink-0 text-[10px]">
                    <Bot className="w-3 h-3" />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-[2px] p-2.5 text-[10px] leading-relaxed ${
                    isUser
                      ? 'bg-[#f97316] text-[#09090b] font-semibold'
                      : 'bg-[#111114] border border-[#27272a] text-[#e4e4e7]'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{m.text}</div>
                  <div className="flex items-center justify-between mt-1.5 pt-1 border-t border-[#27272a]/40 text-[8px] opacity-70">
                    <span>{m.time}</span>
                    {!isUser && (
                      <button
                        onClick={() => copyText(m.text, idx)}
                        className="hover:text-[#f97316] cursor-pointer flex items-center gap-1"
                      >
                        {copiedIndex === idx ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
                        <span>{copiedIndex === idx ? 'COPIED' : 'COPY'}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          {loading && (
            <div className="flex items-center gap-1.5 text-[#f97316] text-[10px] py-1">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Analyzing credit curves and computing ISDA pricing...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-2.5 bg-[#111114] border-t border-[#27272a]">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              id="ai-analyst-input"
              type="text"
              placeholder="Ask about CDS pricing, CS01, basis arbitrage, hazard curves..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="flex-1 bg-[#09090b] border border-[#27272a] rounded-[2px] px-2.5 py-1.5 text-[10px] text-[#e4e4e7] placeholder-[#71717a] focus:outline-none focus:border-[#f97316]"
            />
            <button
              id="ai-analyst-send-btn"
              type="submit"
              disabled={loading || !prompt.trim()}
              className="px-3 py-1.5 bg-[#f97316] hover:bg-[#ea580c] disabled:opacity-50 text-[#09090b] font-bold text-[10px] rounded-[2px] cursor-pointer flex items-center gap-1 transition-all uppercase"
            >
              <Send className="w-3 h-3" />
              <span>ASK</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
