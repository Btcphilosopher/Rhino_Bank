/**
 * RHINOQUANT CDS — Pricing & Valuation Engine Workstation (High Density Theme)
 * ISDA Standard 2014 Model Converter, Upfront Cash, Risky PV01, and Sensitivities
 */

import React, { useState, useMemo } from 'react';
import {
  Calculator,
  Zap,
  Copy,
  Check,
  Code,
} from 'lucide-react';
import { ReferenceEntity, BuySell, Tenor, CDSValuationParams, CDSValuationResult } from '../types/cds';
import { priceCDS, generateRustPricingSnippet, TENOR_YEARS_MAP } from '../lib/quantEngine';

interface PricingCalculatorProps {
  entities: ReferenceEntity[];
  selectedEntityId: string;
  onSelectEntity: (id: string) => void;
  onLaunchOrder: (params: { entityId: string; notional: number; tenor: Tenor; coupon: number; buySell: BuySell; spread: number }) => void;
}

export const PricingCalculatorView: React.FC<PricingCalculatorProps> = ({
  entities,
  selectedEntityId,
  onSelectEntity,
  onLaunchOrder,
}) => {
  const currentEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];

  // Pricing Form State
  const [notional, setNotional] = useState<number>(10000000); // $10M
  const [tradeCoupon, setTradeCoupon] = useState<number>(100); // 100 bps standard
  const [marketSpread, setMarketSpread] = useState<number>(145.0); // 145 bps
  const [tenor, setTenor] = useState<Tenor>('5Y');
  const [recoveryRate, setRecoveryRate] = useState<number>(0.40); // 40%
  const [riskFreeRate, setRiskFreeRate] = useState<number>(0.042); // 4.2%
  const [buySell, setBuySell] = useState<BuySell>('BUY'); // BUY = Long Protection
  const [daysSinceCoupon, setDaysSinceCoupon] = useState<number>(45);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'RUST' | 'KOTLIN'>('RUST');

  // Sync market spread when entity changes
  React.useEffect(() => {
    if (currentEntity) {
      setRecoveryRate(currentEntity.standardRecovery);
      if (currentEntity.rating === 'AAA') setMarketSpread(27.5);
      else if (currentEntity.rating === 'BBB') setMarketSpread(145.0);
      else if (currentEntity.rating === 'BBB-') setMarketSpread(248.0);
      else if (currentEntity.rating === 'BB+') setMarketSpread(339.0);
      else setMarketSpread(60.0);
    }
  }, [currentEntity]);

  const valuationParams: CDSValuationParams = useMemo(() => ({
    notional,
    tradeSpread: tradeCoupon,
    marketSpread,
    tenorYears: TENOR_YEARS_MAP[tenor],
    recoveryRate,
    riskFreeRate,
    buySell,
    daysSinceLastCoupon: daysSinceCoupon,
    isdaModel: 'STANDARD_2014',
  }), [notional, tradeCoupon, marketSpread, tenor, recoveryRate, riskFreeRate, buySell, daysSinceCoupon]);

  const valuationResult: CDSValuationResult = useMemo(() => {
    return priceCDS(valuationParams);
  }, [valuationParams]);

  // Multiple Recovery Scenario Matrix
  const recoveryScenarios = [0.20, 0.30, 0.40, 0.50, 0.60].map((rec) => {
    const res = priceCDS({ ...valuationParams, recoveryRate: rec });
    return {
      recovery: rec,
      upfront: res.upfrontCash,
      cleanValue: res.cleanValue,
      cs01: res.cs01,
      jtd: res.jumpToDefault,
      cumDefaultProb: res.cumulativeDefaultProbability,
    };
  });

  // Spread Shock Matrix (+1bp, +5bp, +10bp, +25bp, +50bp, +100bp)
  const spreadShocks = [1, 5, 10, 25, 50, 100].map((shock) => {
    const res = priceCDS({ ...valuationParams, marketSpread: marketSpread + shock });
    const pnlChange = res.cleanValue - valuationResult.cleanValue;
    return {
      shockBps: shock,
      stressedSpread: marketSpread + shock,
      stressedCleanPV: res.cleanValue,
      pnlImpact: pnlChange,
    };
  });

  const rustCode = generateRustPricingSnippet(valuationParams);
  const kotlinCode = `// RHINOQUANT CDS — Kotlin JVM Pricing Service
package com.rhinoquant.cds.pricing

import kotlin.math.exp
import kotlin.math.roundToInt

data class CDSValuationRequest(
    val notional: Double = ${notional}.0,
    val tradeCouponBps: Double = ${tradeCoupon}.0,
    val marketSpreadBps: Double = ${marketSpread}.0,
    val tenorYears: Double = ${TENOR_YEARS_MAP[tenor]},
    val recoveryRate: Double = ${recoveryRate},
    val riskFreeRate: Double = ${riskFreeRate},
    val isBuyer: Boolean = ${buySell === 'BUY'}
)

class CDSPricingEngine {
    fun price(req: CDSValuationRequest): CDSValuationResponse {
        val dt = 0.25
        val steps = (req.tenorYears * 4.0).roundToInt()
        val lgd = 1.0 - req.recoveryRate
        val lambda = (req.marketSpreadBps / 10000.0) / lgd
        
        var rpv01 = 0.0
        var protLeg = 0.0
        var prevQ = 1.0

        for (i in 1..steps) {
            val t = i * dt
            val df = exp(-req.riskFreeRate * t)
            val q = exp(-lambda * t)
            val dq = prevQ - q
            rpv01 += dt * df * (q + 0.5 * dq)
            protLeg += lgd * exp(-req.riskFreeRate * (t - 0.125)) * dq
            prevQ = q
        }
        
        val cleanUpfront = (req.notional * protLeg) - (req.notional * (req.tradeCouponBps / 10000.0) * rpv01)
        val cs01 = req.notional * 0.0001 * rpv01 * (if (req.isBuyer) 1 else -1)
        
        return CDSValuationResponse(cleanUpfront, cs01, rpv01)
    }
}`;

  const copyCodeToClipboard = () => {
    navigator.clipboard.writeText(activeCodeTab === 'RUST' ? rustCode : kotlinCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div id="pricing-calculator-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top Banner: Reference Entity Selector */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <Calculator className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">ISDA STANDARD 2014 PRICING ENGINE</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>{currentEntity.name} ({currentEntity.ticker})</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-[#18181b] text-[#f97316] font-mono border border-[#27272a]">
                {currentEntity.sector} • {currentEntity.rating}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-[10px]">
          <span className="text-[#a1a1aa] uppercase">SELECT ENTITY:</span>
          <select
            id="pricing-entity-select"
            value={selectedEntityId}
            onChange={(e) => onSelectEntity(e.target.value)}
            className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] focus:outline-none focus:border-[#f97316] cursor-pointer text-[10px]"
          >
            {entities.map((ent) => (
              <option key={ent.id} value={ent.id} className="bg-[#111114]">
                {ent.ticker} — {ent.name} ({ent.sector})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid: Inputs (Left) vs Outputs & Sensitivities (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-2.5">
        {/* Left Column: Contract Parameters Input Form */}
        <div className="lg:col-span-5 bg-[#111114] border border-[#27272a] p-3 rounded-[2px] space-y-3">
          <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5">
            <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
              INSTRUMENT CONFIG
            </span>
            <span className="text-[9px] text-[#a1a1aa] font-mono">v2.4 DETERMINISTIC</span>
          </div>

          {/* Long / Short Toggle */}
          <div>
            <label className="block text-[9px] font-mono text-[#a1a1aa] uppercase mb-1">POSITION TYPE</label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                id="btn-pos-buy"
                onClick={() => setBuySell('BUY')}
                className={`py-1.5 rounded-[2px] text-[10px] font-mono font-bold transition-all cursor-pointer uppercase ${
                  buySell === 'BUY'
                    ? 'bg-[#f97316] text-[#09090b]'
                    : 'bg-[#18181b] text-[#a1a1aa] hover:bg-[#27272a]'
                }`}
              >
                BUY PROTECTION (Long Risk)
              </button>
              <button
                type="button"
                id="btn-pos-sell"
                onClick={() => setBuySell('SELL')}
                className={`py-1.5 rounded-[2px] text-[10px] font-mono font-bold transition-all cursor-pointer uppercase ${
                  buySell === 'SELL'
                    ? 'bg-[#f97316] text-[#09090b]'
                    : 'bg-[#18181b] text-[#a1a1aa] hover:bg-[#27272a]'
                }`}
              >
                SELL PROTECTION (Short Risk)
              </button>
            </div>
          </div>

          {/* Notional ($) */}
          <div>
            <label className="block text-[9px] font-mono text-[#a1a1aa] uppercase mb-1">
              NOTIONAL (USD)
            </label>
            <div className="flex gap-1.5">
              <input
                id="input-notional"
                type="number"
                value={notional}
                onChange={(e) => setNotional(Math.max(10000, Number(e.target.value)))}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2.5 py-1 text-[11px] font-mono text-[#e4e4e7] focus:outline-none focus:border-[#f97316]"
              />
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => setNotional(5000000)}
                  className="px-2 py-0.5 bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] text-[10px] font-mono rounded-[2px] border border-[#27272a] cursor-pointer"
                >
                  $5M
                </button>
                <button
                  type="button"
                  onClick={() => setNotional(10000000)}
                  className="px-2 py-0.5 bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] text-[10px] font-mono rounded-[2px] border border-[#27272a] cursor-pointer"
                >
                  $10M
                </button>
                <button
                  type="button"
                  onClick={() => setNotional(25000000)}
                  className="px-2 py-0.5 bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] text-[10px] font-mono rounded-[2px] border border-[#27272a] cursor-pointer"
                >
                  $25M
                </button>
              </div>
            </div>
          </div>

          {/* Quoted Par Spread vs Running Coupon */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[9px] font-mono text-[#a1a1aa] uppercase mb-1">
                MARKET PAR SPREAD (bps)
              </label>
              <input
                id="input-market-spread"
                type="number"
                step="0.5"
                value={marketSpread}
                onChange={(e) => setMarketSpread(Math.max(0.1, Number(e.target.value)))}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2.5 py-1 text-[12px] font-mono text-[#f97316] font-bold focus:outline-none focus:border-[#f97316]"
              />
            </div>
            <div>
              <label className="block text-[9px] font-mono text-[#a1a1aa] uppercase mb-1">
                RUNNING COUPON (bps)
              </label>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => setTradeCoupon(100)}
                  className={`flex-1 py-1 text-[10px] font-mono font-bold rounded-[2px] cursor-pointer border ${
                    tradeCoupon === 100
                      ? 'bg-[#f97316]/15 border-[#f97316] text-[#f97316]'
                      : 'bg-[#18181b] border-[#27272a] text-[#a1a1aa]'
                  }`}
                >
                  100 bp (IG)
                </button>
                <button
                  type="button"
                  onClick={() => setTradeCoupon(500)}
                  className={`flex-1 py-1 text-[10px] font-mono font-bold rounded-[2px] cursor-pointer border ${
                    tradeCoupon === 500
                      ? 'bg-[#f97316]/15 border-[#f97316] text-[#f97316]'
                      : 'bg-[#18181b] border-[#27272a] text-[#a1a1aa]'
                  }`}
                >
                  500 bp (HY)
                </button>
              </div>
            </div>
          </div>

          {/* Tenor & Recovery Rate */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[9px] font-mono text-[#a1a1aa] uppercase mb-1">
                MATURITY TENOR
              </label>
              <select
                id="select-tenor"
                value={tenor}
                onChange={(e) => setTenor(e.target.value as Tenor)}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[10px] font-mono text-[#e4e4e7] focus:outline-none focus:border-[#f97316] cursor-pointer"
              >
                <option value="6M">6M (0.5Y)</option>
                <option value="1Y">1Y (1.0Y)</option>
                <option value="2Y">2Y (2.0Y)</option>
                <option value="3Y">3Y (3.0Y)</option>
                <option value="5Y">5Y (5.0Y - Standard)</option>
                <option value="7Y">7Y (7.0Y)</option>
                <option value="10Y">10Y (10.0Y)</option>
              </select>
            </div>
            <div>
              <label className="block text-[9px] font-mono text-[#a1a1aa] uppercase mb-1">
                RECOVERY: {(recoveryRate * 100).toFixed(0)}%
              </label>
              <input
                id="slider-recovery"
                type="range"
                min="0.10"
                max="0.80"
                step="0.05"
                value={recoveryRate}
                onChange={(e) => setRecoveryRate(Number(e.target.value))}
                className="w-full accent-[#f97316] cursor-pointer mt-1"
              />
            </div>
          </div>

          {/* Risk Free Rate & Accrued Days */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[9px] font-mono text-[#a1a1aa] uppercase mb-1">
                RISK-FREE (SOFR %)
              </label>
              <input
                id="input-rf-rate"
                type="number"
                step="0.001"
                value={(riskFreeRate * 100).toFixed(2)}
                onChange={(e) => setRiskFreeRate(Number(e.target.value) / 100)}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[10px] font-mono text-[#e4e4e7] focus:outline-none focus:border-[#f97316]"
              />
            </div>
            <div>
              <label className="block text-[9px] font-mono text-[#a1a1aa] uppercase mb-1">
                DAYS ACCRUED
              </label>
              <input
                id="input-days-coupon"
                type="number"
                value={daysSinceCoupon}
                onChange={(e) => setDaysSinceCoupon(Math.min(90, Math.max(0, Number(e.target.value))))}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[10px] font-mono text-[#e4e4e7] focus:outline-none focus:border-[#f97316]"
              />
            </div>
          </div>

          {/* Direct Execute Button */}
          <button
            id="pricing-launch-order-btn"
            onClick={() => onLaunchOrder({
              entityId: currentEntity.id,
              notional,
              tenor,
              coupon: tradeCoupon,
              buySell,
              spread: marketSpread,
            })}
            className="w-full py-2 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] font-bold text-[10px] font-mono rounded-[2px] shadow transition-all cursor-pointer flex items-center justify-center gap-1.5 mt-3 uppercase tracking-wider"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>EXECUTE TRADE TICKET</span>
          </button>
        </div>

        {/* Right Column: Quantitative Valuation Results, Sensitivities */}
        <div className="lg:col-span-7 space-y-2.5">
          {/* Main Output Cards */}
          <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px]">
            <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2.5">
              <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
                VALUATION OUTPUT & CASH SETTLEMENT
              </span>
              <span className="text-[9px] font-mono text-emerald-400">ISDA 2014 ACCURACY</span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 font-mono">
              {/* Upfront Cash */}
              <div className="bg-[#18181b] p-2.5 rounded-[2px] border border-[#27272a]">
                <div className="text-[9px] text-[#a1a1aa] uppercase">Upfront Cash (USD)</div>
                <div className={`text-[13px] font-bold mt-0.5 ${(valuationResult?.upfrontCash ?? 0) >= 0 ? 'text-[#f97316]' : 'text-cyan-400'}`}>
                  ${Math.abs(valuationResult?.upfrontCash ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="text-[8px] text-[#71717a] mt-0.5">
                  {(valuationResult?.upfrontCash ?? 0) >= 0 ? 'Buyer pays Upfront' : 'Buyer receives Upfront'}
                </div>
              </div>

              {/* Clean Value */}
              <div className="bg-[#18181b] p-2.5 rounded-[2px] border border-[#27272a]">
                <div className="text-[9px] text-[#a1a1aa] uppercase">Clean MTM Value</div>
                <div className={`text-[13px] font-bold mt-0.5 ${(valuationResult?.cleanValue ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {(valuationResult?.cleanValue ?? 0) >= 0 ? '+' : ''}${(valuationResult?.cleanValue ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="text-[8px] text-[#71717a] mt-0.5">Excludes Accrued</div>
              </div>

              {/* Dirty Value */}
              <div className="bg-[#18181b] p-2.5 rounded-[2px] border border-[#27272a]">
                <div className="text-[9px] text-[#a1a1aa] uppercase">Dirty MTM Value</div>
                <div className={`text-[13px] font-bold mt-0.5 ${(valuationResult?.dirtyValue ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {(valuationResult?.dirtyValue ?? 0) >= 0 ? '+' : ''}${(valuationResult?.dirtyValue ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="text-[8px] text-[#71717a] mt-0.5">Includes Accrued</div>
              </div>

              {/* Risky PV01 / Annuity */}
              <div className="bg-[#18181b] p-2.5 rounded-[2px] border border-[#27272a]">
                <div className="text-[9px] text-[#a1a1aa] uppercase">RPV01 (Annuity)</div>
                <div className="text-[13px] font-bold text-[#e4e4e7] mt-0.5">
                  {(valuationResult?.riskyPV01 ?? 0).toFixed(4)}
                </div>
                <div className="text-[8px] text-[#71717a] mt-0.5">Risky Annuity Factor</div>
              </div>
            </div>

            {/* Leg Decomposition Strip */}
            <div className="mt-2.5 grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px] font-mono bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
              <div>
                <span className="text-[#a1a1aa] text-[8px] uppercase block">PREMIUM LEG PV:</span>
                <span className="text-[#e4e4e7] font-semibold">${(valuationResult?.premiumLegPV ?? 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              </div>
              <div>
                <span className="text-[#a1a1aa] text-[8px] uppercase block">PROTECTION LEG PV:</span>
                <span className="text-[#e4e4e7] font-semibold">${(valuationResult?.protectionLegPV ?? 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              </div>
              <div>
                <span className="text-[#a1a1aa] text-[8px] uppercase block">ACCRUED PREMIUM:</span>
                <span className="text-[#e4e4e7] font-semibold">${(valuationResult?.accruedPremium ?? 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              </div>
              <div>
                <span className="text-[#a1a1aa] text-[8px] uppercase block">FAIR PAR SPREAD:</span>
                <span className="text-[#f97316] font-bold">{(valuationResult?.fairParSpread ?? 0).toFixed(2)} bp</span>
              </div>
            </div>
          </div>

          {/* Sensitivities & Greeks Bento */}
          <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px]">
            <div className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider mb-2">
              RISK SENSITIVITIES & GREEKS (DV01 / CS01 / JTD)
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 font-mono text-[10px]">
              <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
                <div className="text-[9px] text-[#a1a1aa]">CS01 (+1bp Spread)</div>
                <div className={`text-[12px] font-bold mt-0.5 ${(valuationResult?.cs01 ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {(valuationResult?.cs01 ?? 0) >= 0 ? '+' : ''}${(valuationResult?.cs01 ?? 0).toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}
                </div>
                <div className="text-[8px] text-[#71717a]">Spread sensitivity</div>
              </div>

              <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
                <div className="text-[9px] text-[#a1a1aa]">DV01 (+1bp IR)</div>
                <div className="text-[12px] font-bold text-[#e4e4e7] mt-0.5">
                  ${(valuationResult?.dv01 ?? 0).toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}
                </div>
                <div className="text-[8px] text-[#71717a]">Rates sensitivity</div>
              </div>

              <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
                <div className="text-[9px] text-[#a1a1aa]">JUMP-TO-DEFAULT</div>
                <div className={`text-[12px] font-bold mt-0.5 ${(valuationResult?.jumpToDefault ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {(valuationResult?.jumpToDefault ?? 0) >= 0 ? '+' : ''}${(valuationResult?.jumpToDefault ?? 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
                <div className="text-[8px] text-[#71717a]">Instant Default P&L</div>
              </div>

              <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
                <div className="text-[9px] text-[#a1a1aa]">5Y CUMULATIVE DEFAULT</div>
                <div className="text-[12px] font-bold text-rose-400 mt-0.5">
                  {(valuationResult.cumulativeDefaultProbability * 100).toFixed(2)}%
                </div>
                <div className="text-[8px] text-[#71717a]">Survival: {(valuationResult.survivalProbability * 100).toFixed(2)}%</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lower Section: Spread Shocks & Multi-Recovery Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
        {/* Spread Shock Ladder */}
        <div className="bg-[#111114] border border-[#27272a] p-2.5 rounded-[2px] font-mono">
          <div className="text-[10px] font-bold text-[#e4e4e7] uppercase mb-1.5">
            Spread Widening Stress Ladder (+1bp to +100bp)
          </div>
          <table className="w-full text-[10px] text-left">
            <thead>
              <tr className="text-[#a1a1aa] border-b border-[#27272a] text-[9px] uppercase">
                <th className="py-1">Shock</th>
                <th className="py-1">Stressed Spread</th>
                <th className="py-1 text-right">Stressed PV</th>
                <th className="py-1 text-right">P&L Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1f1f23]">
              {spreadShocks.map((s) => (
                <tr key={s.shockBps} className="hover:bg-white/[0.02]">
                  <td className="py-1 font-bold text-[#f97316]">+{s.shockBps} bps</td>
                  <td className="py-1 text-[#a1a1aa]">{s.stressedSpread.toFixed(1)} bp</td>
                  <td className="py-1 text-right text-[#e4e4e7]">${s.stressedCleanPV.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className={`py-1 text-right font-semibold ${s.pnlImpact >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {s.pnlImpact >= 0 ? '+' : ''}${s.pnlImpact.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Multi-Recovery Assumptions Table */}
        <div className="bg-[#111114] border border-[#27272a] p-2.5 rounded-[2px] font-mono">
          <div className="text-[10px] font-bold text-[#e4e4e7] uppercase mb-1.5">
            Recovery Rate Sensitivity Matrix (20% to 60%)
          </div>
          <table className="w-full text-[10px] text-left">
            <thead>
              <tr className="text-[#a1a1aa] border-b border-[#27272a] text-[9px] uppercase">
                <th className="py-1">Recovery (R)</th>
                <th className="py-1 text-right">Upfront</th>
                <th className="py-1 text-right">CS01</th>
                <th className="py-1 text-right">JTD P&L</th>
                <th className="py-1 text-right">Default Prob</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1f1f23]">
              {recoveryScenarios.map((r) => (
                <tr key={r.recovery} className={`hover:bg-white/[0.02] ${r.recovery === recoveryRate ? 'bg-[#f97316]/10' : ''}`}>
                  <td className="py-1 font-bold text-[#e4e4e7]">
                    {(r.recovery * 100).toFixed(0)}% {r.recovery === recoveryRate ? '(ACT)' : ''}
                  </td>
                  <td className="py-1 text-right text-[#a1a1aa]">${r.upfront.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className="py-1 text-right text-[#a1a1aa]">${r.cs01.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className="py-1 text-right text-[#a1a1aa]">${r.jtd.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className="py-1 text-right text-rose-400">{(r.cumDefaultProb * 100).toFixed(1)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Code Export: Rust & Kotlin Quantitative Implementation */}
      <div className="bg-[#111114] border border-[#27272a] p-2.5 rounded-[2px]">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
          <div className="flex items-center gap-1.5">
            <Code className="w-3.5 h-3.5 text-[#f97316]" />
            <span className="text-[10px] font-mono font-bold text-[#e4e4e7] uppercase">
              QUANT CORE EXPORT (RUST / KOTLIN ENGINE)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex bg-[#09090b] rounded-[2px] p-0.5 border border-[#27272a] text-[10px] font-mono">
              <button
                type="button"
                onClick={() => setActiveCodeTab('RUST')}
                className={`px-2 py-0.5 rounded-[2px] cursor-pointer ${activeCodeTab === 'RUST' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
              >
                Rust Engine
              </button>
              <button
                type="button"
                onClick={() => setActiveCodeTab('KOTLIN')}
                className={`px-2 py-0.5 rounded-[2px] cursor-pointer ${activeCodeTab === 'KOTLIN' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
              >
                Kotlin JVM
              </button>
            </div>
            <button
              onClick={copyCodeToClipboard}
              className="flex items-center gap-1 px-2 py-1 bg-[#18181b] hover:bg-[#27272a] text-[#e4e4e7] text-[10px] font-mono rounded-[2px] border border-[#27272a] cursor-pointer"
            >
              {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-[#a1a1aa]" />}
              <span>{copiedCode ? 'COPIED' : 'COPY'}</span>
            </button>
          </div>
        </div>
        <pre className="bg-[#09090b] p-2.5 rounded-[2px] border border-[#27272a] text-[10px] font-mono text-emerald-300 overflow-x-auto max-h-48">
          {activeCodeTab === 'RUST' ? rustCode : kotlinCode}
        </pre>
      </div>
    </div>
  );
};
