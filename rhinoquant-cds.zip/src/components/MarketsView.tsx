/**
 * RHINOQUANT CDS — Markets View (High Density CDS Spreads Monitor & Matrix)
 */

import React, { useState } from 'react';
import {
  Search,
  ArrowUpDown,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import { CDSSpreadQuote, ReferenceEntity } from '../types/cds';

interface MarketsViewProps {
  quotes: Record<string, CDSSpreadQuote>;
  entities: ReferenceEntity[];
  onSelectEntityForPricing: (entityId: string) => void;
  onSelectEntityForTrade: (entityId: string, buySell: 'BUY' | 'SELL') => void;
  onOpenCurve: (entityId: string) => void;
}

export const MarketsView: React.FC<MarketsViewProps> = ({
  quotes,
  entities,
  onSelectEntityForPricing,
  onSelectEntityForTrade,
  onOpenCurve,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedRatingGroup, setSelectedRatingGroup] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'5Y_MID' | 'CHANGE_1D' | 'PERCENTILE' | 'Z_SCORE' | 'VOLATILITY'>('5Y_MID');
  const [sortOrder, setSortOrder] = useState<'ASC' | 'DESC'>('DESC');

  // Filter & Sort Logic
  const quoteList = (Object.values(quotes) as CDSSpreadQuote[]).filter((q: CDSSpreadQuote) => {
    const matchesSearch =
      q.entityName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.ticker.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.sector.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSector = selectedSector === 'ALL' || q.sector === selectedSector;

    let matchesRating = true;
    if (selectedRatingGroup === 'AAA_AA') {
      matchesRating = ['AAA', 'AA+', 'AA', 'AA-'].includes(q.rating);
    } else if (selectedRatingGroup === 'A_BBB') {
      matchesRating = ['A+', 'A', 'A-', 'BBB+', 'BBB', 'BBB-'].includes(q.rating);
    } else if (selectedRatingGroup === 'HY') {
      matchesRating = ['BB+', 'BB', 'BB-', 'B+', 'B', 'B-', 'CCC'].includes(q.rating);
    }

    return matchesSearch && matchesSector && matchesRating;
  });

  quoteList.sort((a, b) => {
    let valA = 0;
    let valB = 0;
    if (sortBy === '5Y_MID') {
      valA = a.tenors['5Y'].mid;
      valB = b.tenors['5Y'].mid;
    } else if (sortBy === 'CHANGE_1D') {
      valA = a.change1D;
      valB = b.change1D;
    } else if (sortBy === 'PERCENTILE') {
      valA = a.percentile1Y;
      valB = b.percentile1Y;
    } else if (sortBy === 'Z_SCORE') {
      valA = a.zScore1Y;
      valB = b.zScore1Y;
    } else if (sortBy === 'VOLATILITY') {
      valA = a.volatility30D;
      valB = b.volatility30D;
    }
    return sortOrder === 'DESC' ? valB - valA : valA - valB;
  });

  const handleSort = (field: typeof sortBy) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC');
    } else {
      setSortBy(field);
      setSortOrder('DESC');
    }
  };

  return (
    <div id="markets-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top High-Density Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-[#111114] px-3 py-2 rounded-[2px] border border-[#27272a]">
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#a1a1aa] absolute left-2.5 top-2" />
            <input
              id="markets-search-input"
              type="text"
              placeholder="Filter ticker, name, sector..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-2.5 py-1 bg-[#09090b] border border-[#27272a] rounded-[2px] text-[11px] font-mono text-[#e4e4e7] placeholder-[#71717a] focus:outline-none focus:border-[#f97316] w-56"
            />
          </div>

          {/* Sector Filter */}
          <div className="flex items-center gap-1 text-[10px] font-mono">
            <span className="text-[#a1a1aa] uppercase">SECTOR:</span>
            <select
              id="markets-sector-filter"
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
            >
              <option value="ALL">All Sectors</option>
              <option value="Financials">Financials</option>
              <option value="Technology">Technology</option>
              <option value="Industrials">Industrials</option>
              <option value="Consumer">Consumer</option>
              <option value="Telecommunications">Telecommunications</option>
              <option value="Energy">Energy</option>
              <option value="Sovereign">Sovereign</option>
            </select>
          </div>

          {/* Rating Filter */}
          <div className="flex items-center gap-1 text-[10px] font-mono">
            <span className="text-[#a1a1aa] uppercase">RATING:</span>
            <select
              id="markets-rating-filter"
              value={selectedRatingGroup}
              onChange={(e) => setSelectedRatingGroup(e.target.value)}
              className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
            >
              <option value="ALL">All Ratings</option>
              <option value="AAA_AA">AAA / AA High Grade</option>
              <option value="A_BBB">A / BBB Investment Grade</option>
              <option value="HY">High Yield (BB/B/CCC)</option>
            </select>
          </div>
        </div>

        {/* Preset Sort Tabs */}
        <div className="flex items-center gap-1 text-[10px] font-mono">
          <span className="text-[#a1a1aa] text-[9px] uppercase tracking-wider mr-1">SORT:</span>
          <button
            id="sort-widest-btn"
            onClick={() => { setSortBy('5Y_MID'); setSortOrder('DESC'); }}
            className={`px-2 py-0.5 rounded-[2px] text-[10px] transition-colors cursor-pointer ${
              sortBy === '5Y_MID' && sortOrder === 'DESC' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'bg-[#18181b] text-[#a1a1aa] hover:bg-[#27272a]'
            }`}
          >
            Widest Spreads
          </button>
          <button
            id="sort-tightest-btn"
            onClick={() => { setSortBy('5Y_MID'); setSortOrder('ASC'); }}
            className={`px-2 py-0.5 rounded-[2px] text-[10px] transition-colors cursor-pointer ${
              sortBy === '5Y_MID' && sortOrder === 'ASC' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'bg-[#18181b] text-[#a1a1aa] hover:bg-[#27272a]'
            }`}
          >
            Tightest
          </button>
          <button
            id="sort-wideners-btn"
            onClick={() => { setSortBy('CHANGE_1D'); setSortOrder('DESC'); }}
            className={`px-2 py-0.5 rounded-[2px] text-[10px] transition-colors cursor-pointer ${
              sortBy === 'CHANGE_1D' && sortOrder === 'DESC' ? 'bg-rose-600 text-white font-bold' : 'bg-[#18181b] text-[#a1a1aa] hover:bg-[#27272a]'
            }`}
          >
            Wideners
          </button>
          <button
            id="sort-tighteners-btn"
            onClick={() => { setSortBy('CHANGE_1D'); setSortOrder('ASC'); }}
            className={`px-2 py-0.5 rounded-[2px] text-[10px] transition-colors cursor-pointer ${
              sortBy === 'CHANGE_1D' && sortOrder === 'ASC' ? 'bg-emerald-600 text-white font-bold' : 'bg-[#18181b] text-[#a1a1aa] hover:bg-[#27272a]'
            }`}
          >
            Tighteners
          </button>
        </div>
      </div>

      {/* Main High-Density CDS Matrix Table */}
      <div className="bg-[#111114] rounded-[2px] border border-[#27272a] overflow-x-auto">
        <table id="cds-market-matrix-table" className="w-full text-left text-[11px] font-mono border-collapse">
          <thead>
            <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] font-semibold text-[10px] tracking-wider uppercase">
              <th className="py-2 px-2.5">Reference Entity</th>
              <th className="py-2 px-2">Sector</th>
              <th className="py-2 px-2">Rating</th>
              <th className="py-2 px-2 text-right">1Y Mid</th>
              <th className="py-2 px-2 text-right">2Y Mid</th>
              <th className="py-2 px-2 text-right">3Y Mid</th>
              <th
                onClick={() => handleSort('5Y_MID')}
                className="py-2 px-2.5 text-right cursor-pointer bg-[#18181b] text-[#f97316] hover:bg-[#27272a]"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>5Y Mid (Bid/Ask)</span>
                  <ArrowUpDown className="w-2.5 h-2.5 text-[#f97316]" />
                </div>
              </th>
              <th className="py-2 px-2 text-right">7Y Mid</th>
              <th className="py-2 px-2 text-right">10Y Mid</th>
              <th
                onClick={() => handleSort('CHANGE_1D')}
                className="py-2 px-2 text-right cursor-pointer hover:bg-[#27272a]"
              >
                1D Δ
              </th>
              <th
                onClick={() => handleSort('PERCENTILE')}
                className="py-2 px-2 text-right cursor-pointer hover:bg-[#27272a]"
              >
                1Y %ile
              </th>
              <th
                onClick={() => handleSort('Z_SCORE')}
                className="py-2 px-2 text-right cursor-pointer hover:bg-[#27272a]"
              >
                Z-Score
              </th>
              <th className="py-2 px-2 text-center">Liquidity</th>
              <th className="py-2 px-2.5 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f1f23]">
            {quoteList.map((q) => {
              const fiveY = q.tenors['5Y'];
              const isWidening = q.change1D > 0;
              const isTightening = q.change1D < 0;

              return (
                <tr
                  key={q.entityId}
                  id={`quote-row-${q.ticker.toLowerCase()}`}
                  className="hover:bg-white/[0.025] transition-colors"
                >
                  {/* Entity & Ticker */}
                  <td className="py-1.5 px-2.5">
                    <div className="font-semibold text-[#e4e4e7] flex items-center gap-1.5">
                      <span className="text-[#f97316] font-bold">{q.ticker}</span>
                      <span className="text-[10px] text-[#a1a1aa] font-normal truncate max-w-[150px]">
                        {q.entityName}
                      </span>
                    </div>
                  </td>

                  {/* Sector */}
                  <td className="py-1.5 px-2 text-[#a1a1aa] text-[10px]">{q.sector}</td>

                  {/* Rating */}
                  <td className="py-1.5 px-2">
                    <span
                      className={`px-1.5 py-0.2 rounded-[2px] text-[9px] font-bold ${
                        ['AAA', 'AA+', 'AA', 'AA-'].includes(q.rating)
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                          : ['A+', 'A', 'A-'].includes(q.rating)
                          ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/60'
                          : ['BBB+', 'BBB', 'BBB-'].includes(q.rating)
                          ? 'bg-amber-950/80 text-amber-300 border border-amber-800/60'
                          : 'bg-rose-950/80 text-rose-300 border border-rose-800/60'
                      }`}
                    >
                      {q.rating}
                    </span>
                  </td>

                  {/* 1Y, 2Y, 3Y */}
                  <td className="py-1.5 px-2 text-right text-[#a1a1aa]">{q.tenors['1Y'].mid.toFixed(1)}</td>
                  <td className="py-1.5 px-2 text-right text-[#a1a1aa]">{q.tenors['2Y'].mid.toFixed(1)}</td>
                  <td className="py-1.5 px-2 text-right text-[#a1a1aa]">{q.tenors['3Y'].mid.toFixed(1)}</td>

                  {/* 5Y Benchmark Spread */}
                  <td className="py-1.5 px-2.5 text-right bg-[#18181b]/50">
                    <div className="text-[#f97316] font-bold">
                      {fiveY.mid.toFixed(2)} bp
                    </div>
                    <div className="text-[9px] text-[#71717a] font-normal">
                      {fiveY.bid.toFixed(1)} / {fiveY.ask.toFixed(1)}
                    </div>
                  </td>

                  {/* 7Y, 10Y */}
                  <td className="py-1.5 px-2 text-right text-[#a1a1aa]">{q.tenors['7Y'].mid.toFixed(1)}</td>
                  <td className="py-1.5 px-2 text-right text-[#a1a1aa]">{q.tenors['10Y'].mid.toFixed(1)}</td>

                  {/* 1D Change */}
                  <td className="py-1.5 px-2 text-right font-semibold">
                    <span
                      className={`inline-flex items-center gap-0.5 ${
                        isWidening
                          ? 'text-rose-400'
                          : isTightening
                          ? 'text-emerald-400'
                          : 'text-[#71717a]'
                      }`}
                    >
                      {isWidening ? <TrendingUp className="w-2.5 h-2.5" /> : isTightening ? <TrendingDown className="w-2.5 h-2.5" /> : null}
                      {q.change1D > 0 ? `+${q.change1D.toFixed(1)}` : q.change1D.toFixed(1)}
                    </span>
                  </td>

                  {/* Percentile */}
                  <td className="py-1.5 px-2 text-right">
                    <span className={q.percentile1Y > 80 ? 'text-rose-400 font-semibold' : q.percentile1Y < 25 ? 'text-emerald-400' : 'text-[#a1a1aa]'}>
                      {q.percentile1Y.toFixed(1)}%
                    </span>
                  </td>

                  {/* Z-Score */}
                  <td className="py-1.5 px-2 text-right">
                    <span className={Math.abs(q.zScore1Y) >= 1.5 ? 'text-[#f97316] font-bold' : 'text-[#71717a]'}>
                      {q.zScore1Y >= 0 ? `+${q.zScore1Y.toFixed(2)}` : q.zScore1Y.toFixed(2)}
                    </span>
                  </td>

                  {/* Liquidity */}
                  <td className="py-1.5 px-2 text-center">
                    <span
                      className={`px-1.5 py-0.2 rounded-[2px] text-[9px] font-medium ${
                        q.liquidityScore === 'HIGH'
                          ? 'text-emerald-300 bg-emerald-950/60'
                          : q.liquidityScore === 'MEDIUM'
                          ? 'text-amber-300 bg-amber-950/60'
                          : 'text-[#71717a] bg-[#18181b]'
                      }`}
                    >
                      {q.liquidityScore}
                    </span>
                  </td>

                  {/* Quick Action Buttons */}
                  <td className="py-1.5 px-2.5 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => onSelectEntityForPricing(q.entityId)}
                        className="px-1.5 py-0.5 bg-[#18181b] hover:bg-[#27272a] text-[#e4e4e7] text-[9px] font-semibold rounded-[2px] border border-[#27272a] cursor-pointer transition-colors"
                        title="Price in ISDA CDS Calculator"
                      >
                        PRICE
                      </button>
                      <button
                        onClick={() => onOpenCurve(q.entityId)}
                        className="px-1.5 py-0.5 bg-[#18181b] hover:bg-[#27272a] text-cyan-400 text-[9px] font-semibold rounded-[2px] border border-[#27272a] cursor-pointer transition-colors"
                        title="View Hazard Curve"
                      >
                        CURVE
                      </button>
                      <button
                        onClick={() => onSelectEntityForTrade(q.entityId, 'BUY')}
                        className="px-2 py-0.5 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] font-bold text-[9px] rounded-[2px] cursor-pointer transition-colors"
                        title="Launch Buy/Sell Order Ticket"
                      >
                        TRADE
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
