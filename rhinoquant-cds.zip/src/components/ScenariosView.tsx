/**
 * RHINOQUANT CDS — Scenario Analysis & Stress Testing Engine (High Density)
 * Crisis Replay, Macro Shocks, Instant Default Stress, Collateral Call Impact
 */

import React, { useState, useMemo } from 'react';
import {
  Flame,
} from 'lucide-react';
import { CDSPosition, StressScenario, StressScenarioResult } from '../types/cds';
import { runScenarioStressTest } from '../lib/quantEngine';
import { STRESS_SCENARIOS } from '../data/marketData';

interface ScenariosViewProps {
  positions: CDSPosition[];
}

export const ScenariosView: React.FC<ScenariosViewProps> = ({ positions }) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(STRESS_SCENARIOS[0].id);
  const [customParallelShift, setCustomParallelShift] = useState<number>(100);
  const [customRecoveryDrop, setCustomRecoveryDrop] = useState<number>(0.10);
  const [customRatesShift, setCustomRatesShift] = useState<number>(0.01);
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);

  const activeScenario: StressScenario = useMemo(() => {
    if (isCustomMode) {
      return {
        id: 'SCEN_CUSTOM',
        name: 'Custom Parameterized Stress Shock',
        description: `Parallel credit spread shift of +${customParallelShift}bp, recovery drop of -${(customRecoveryDrop * 100).toFixed(0)}%, IR shift of +${(customRatesShift * 100).toFixed(0)}bp.`,
        spreadShiftBps: customParallelShift,
        sectorShifts: {},
        ratingShifts: {},
        recoveryShift: -customRecoveryDrop,
        ratesShift: customRatesShift,
      };
    }
    return STRESS_SCENARIOS.find((s) => s.id === selectedScenarioId) || STRESS_SCENARIOS[0];
  }, [isCustomMode, selectedScenarioId, customParallelShift, customRecoveryDrop, customRatesShift]);

  const testResult: StressScenarioResult = useMemo(() => {
    return runScenarioStressTest(activeScenario, positions);
  }, [activeScenario, positions]);

  return (
    <div id="scenarios-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top Banner */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <Flame className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">MACRO SCENARIO & CRISIS STRESS TESTING</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>{activeScenario.name}</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-rose-950/80 text-rose-300 font-mono border border-rose-500/40">
                ACTIVE SIMULATION
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-[10px]">
          <button
            onClick={() => setIsCustomMode(!isCustomMode)}
            className={`px-2.5 py-1 rounded-[2px] cursor-pointer border ${
              isCustomMode
                ? 'bg-[#f97316] text-[#09090b] font-bold border-[#f97316]'
                : 'bg-[#18181b] text-[#a1a1aa] border-[#27272a] hover:bg-[#27272a]'
            }`}
          >
            {isCustomMode ? 'CUSTOM PARAMETERS (ACTIVE)' : 'CUSTOM SHOCK'}
          </button>
        </div>
      </div>

      {/* Preset Scenario Selector Grid */}
      {!isCustomMode && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          {STRESS_SCENARIOS.map((scen) => {
            const isSelected = scen.id === selectedScenarioId;
            return (
              <div
                key={scen.id}
                onClick={() => setSelectedScenarioId(scen.id)}
                className={`p-2.5 rounded-[2px] border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#f97316]/10 border-[#f97316]'
                    : 'bg-[#111114] border-[#27272a] hover:bg-[#18181b]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[11px] font-mono text-[#e4e4e7]">{scen.name}</span>
                  {isSelected && (
                    <span className="text-[8px] bg-[#f97316] text-[#09090b] font-bold px-1.5 py-0.2 rounded-[2px]">
                      SELECTED
                    </span>
                  )}
                </div>
                <p className="text-[9px] text-[#a1a1aa] font-mono mt-1 line-clamp-2">
                  {scen.description}
                </p>
                <div className="mt-1.5 text-[9px] font-mono text-[#f97316]">
                  Shift: +{scen.spreadShiftBps} bp • Recovery: {(scen.recoveryShift * 100).toFixed(0)}%
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Custom Scenario Configurator */}
      {isCustomMode && (
        <div className="bg-[#111114] border border-[#f97316]/40 p-3 rounded-[2px] space-y-2 font-mono text-[10px]">
          <div className="text-[#f97316] font-bold text-[10px] uppercase">Custom Stress Scenario Parameters</div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-[#a1a1aa] mb-0.5">Spread Shock: +{customParallelShift} bps</label>
              <input
                type="range"
                min="10"
                max="800"
                step="10"
                value={customParallelShift}
                onChange={(e) => setCustomParallelShift(Number(e.target.value))}
                className="w-full accent-[#f97316] cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-[#a1a1aa] mb-0.5">Recovery Drop: -{(customRecoveryDrop * 100).toFixed(0)}%</label>
              <input
                type="range"
                min="0"
                max="0.30"
                step="0.05"
                value={customRecoveryDrop}
                onChange={(e) => setCustomRecoveryDrop(Number(e.target.value))}
                className="w-full accent-[#f97316] cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-[#a1a1aa] mb-0.5">SOFR Shift: +{(customRatesShift * 10000).toFixed(0)} bps</label>
              <input
                type="range"
                min="-0.02"
                max="0.04"
                step="0.0025"
                value={customRatesShift}
                onChange={(e) => setCustomRatesShift(Number(e.target.value))}
                className="w-full accent-[#f97316] cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* Stress Results Summary KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 font-mono text-[10px]">
        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Base Portfolio MTM</div>
          <div className={`text-[13px] font-bold mt-0.5 ${(testResult?.baseMTM ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            ${(testResult?.baseMTM ?? 0).toLocaleString()}
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Pre-Stress Valuation</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Stressed Portfolio MTM</div>
          <div className={`text-[13px] font-bold mt-0.5 ${(testResult?.stressedMTM ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            ${(testResult?.stressedMTM ?? 0).toLocaleString()}
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Post-Shock Valuation</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Stress P&L Impact</div>
          <div className={`text-[13px] font-bold mt-0.5 ${(testResult?.pnlImpact ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {(testResult?.pnlImpact ?? 0) >= 0 ? '+' : ''}${(testResult?.pnlImpact ?? 0).toLocaleString()}
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Net Portfolio Shock Δ</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Margin Call / Collateral Demand</div>
          <div className="text-[13px] font-bold text-[#f97316] mt-0.5">
            ${(testResult?.marginCallRequired ?? 0).toLocaleString()}
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Clearing Collateral Call</div>
        </div>
      </div>

      {/* Position Breakdown Under Shock Table */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
          <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
            CONTRACT-BY-CONTRACT STRESS ATTRIBUTION
          </span>
          <span className="text-[9px] font-mono text-[#a1a1aa]">
            STRESSED CS01: ${(testResult?.stressedCS01 ?? 0).toLocaleString()}/bp
          </span>
        </div>

        <table className="w-full text-[10px] font-mono text-left border-collapse">
          <thead>
            <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
              <th className="py-1.5 px-2.5">Position</th>
              <th className="py-1.5 px-2">Side</th>
              <th className="py-1.5 px-2 text-right">Notional</th>
              <th className="py-1.5 px-2 text-right">Base Spread</th>
              <th className="py-1.5 px-2 text-right">Stressed Spread</th>
              <th className="py-1.5 px-2 text-right">Base MTM</th>
              <th className="py-1.5 px-2 text-right">Stressed MTM</th>
              <th className="py-1.5 px-2.5 text-right bg-[#18181b]">P&L Attribution</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f1f23]">
            {(testResult?.positionImpacts || []).map((pos) => (
              <tr key={pos.positionId} className="hover:bg-white/[0.02] transition-colors">
                <td className="py-1 px-2.5 font-bold text-[#e4e4e7]">{pos.ticker}</td>
                <td className="py-1 px-2">
                  <span className={`px-1.5 py-0.2 rounded-[2px] text-[8px] font-bold ${
                    pos.buySell === 'BUY' ? 'bg-orange-950 text-orange-300' : 'bg-cyan-950 text-cyan-300'
                  }`}>
                    {pos.buySell}
                  </span>
                </td>
                <td className="py-1 px-2 text-right text-[#e4e4e7]">${((pos.notional ?? 0) / 1e6).toFixed(1)}M</td>
                <td className="py-1 px-2 text-right text-[#a1a1aa]">{(pos.baseSpread ?? 0).toFixed(1)} bp</td>
                <td className="py-1 px-2 text-right text-rose-400 font-bold">{(pos.stressedSpread ?? 0).toFixed(1)} bp</td>
                <td className="py-1 px-2 text-right text-[#a1a1aa]">${(pos.baseMTM ?? 0).toLocaleString()}</td>
                <td className="py-1 px-2 text-right text-[#e4e4e7]">${(pos.stressedMTM ?? 0).toLocaleString()}</td>
                <td className="py-1 px-2.5 text-right font-extrabold bg-[#18181b]/30">
                  <span className={(pos.pnlDelta ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                    {(pos.pnlDelta ?? 0) >= 0 ? '+' : ''}${(pos.pnlDelta ?? 0).toLocaleString()}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
