/**
 * RHINOQUANT CDS — Default Probability & Term Structure Workstation (High Density)
 * Implied vs Historical Default Probabilities, Risk Premium Ratio, LGD Matrix
 */

import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  Percent,
} from 'lucide-react';
import { ReferenceEntity, CDSSpreadQuote } from '../types/cds';

interface DefaultProbProps {
  entities: ReferenceEntity[];
  quotes: Record<string, CDSSpreadQuote>;
}

// Historical 5Y cumulative default rates by rating
const HISTORICAL_DEFAULT_RATES_5Y: Record<string, number> = {
  'AAA': 0.03,
  'AA+': 0.08,
  'AA': 0.15,
  'AA-': 0.25,
  'A+': 0.40,
  'A': 0.60,
  'A-': 0.90,
  'BBB+': 1.50,
  'BBB': 2.30,
  'BBB-': 3.80,
  'BB+': 6.20,
  'BB': 9.50,
  'BB-': 13.80,
  'B+': 19.50,
  'B': 26.00,
  'B-': 34.00,
  'CCC': 48.00,
};

export const DefaultProbView: React.FC<DefaultProbProps> = ({ entities, quotes }) => {
  const [selectedRating, setSelectedRating] = useState<string>('ALL');
  const [selectedRecovery, setSelectedRecovery] = useState<number>(0.40);

  // Compute table and chart data for each entity
  const entityAnalysis = entities.map((ent) => {
    const q = quotes[ent.id] || quotes['ENT_BA'] || Object.values(quotes)[0];
    const spread5Y = q.tenors['5Y'].mid;
    const spread1Y = q.tenors['1Y'].mid;
    const spread10Y = q.tenors['10Y'].mid;

    const lgd = 1 - selectedRecovery;
    const lambda5Y = (spread5Y / 10000) / lgd;
    const impliedPD1Y = (1 - Math.exp(-((spread1Y / 10000) / lgd) * 1)) * 100;
    const impliedPD5Y = (1 - Math.exp(-lambda5Y * 5)) * 100;
    const impliedPD10Y = (1 - Math.exp(-((spread10Y / 10000) / lgd) * 10)) * 100;

    const histPD5Y = HISTORICAL_DEFAULT_RATES_5Y[ent.rating] || 2.0;
    const riskPremiumRatio = impliedPD5Y / Math.max(0.01, histPD5Y);

    return {
      entityId: ent.id,
      ticker: ent.ticker,
      name: ent.name,
      sector: ent.sector,
      rating: ent.rating,
      spread5Y,
      impliedPD1Y,
      impliedPD5Y,
      impliedPD10Y,
      histPD5Y,
      riskPremiumRatio,
      expectedLoss5Y: impliedPD5Y * lgd,
    };
  });

  const filteredData = entityAnalysis.filter((d) => {
    if (selectedRating === 'ALL') return true;
    if (selectedRating === 'IG') return ['AAA', 'AA+', 'AA', 'AA-', 'A+', 'A', 'A-', 'BBB+', 'BBB', 'BBB-'].includes(d.rating);
    if (selectedRating === 'HY') return ['BB+', 'BB', 'BB-', 'B+', 'B', 'CCC'].includes(d.rating);
    return true;
  });

  const comparisonChartData = filteredData.slice(0, 8).map((d) => ({
    ticker: d.ticker,
    'Market Implied 5Y PD (%)': Number(d.impliedPD5Y.toFixed(2)),
    'Historical 5Y Default (%)': Number(d.histPD5Y.toFixed(2)),
  }));

  return (
    <div id="default-prob-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top Banner & Control Strip */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <Percent className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">IMPLIED DEFAULT PROBABILITY & TERM STRUCTURE</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>Credit Risk Premium & Historical Baseline</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-[#18181b] text-[#f97316] font-mono border border-[#27272a]">
                LGD Assumption: {((1 - selectedRecovery) * 100).toFixed(0)}%
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 font-mono text-[10px]">
          <div className="flex items-center gap-1">
            <span className="text-[#a1a1aa] uppercase">RATING:</span>
            <select
              id="dp-rating-filter"
              value={selectedRating}
              onChange={(e) => setSelectedRating(e.target.value)}
              className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
            >
              <option value="ALL">All Entities</option>
              <option value="IG">Investment Grade (IG)</option>
              <option value="HY">High Yield (HY)</option>
            </select>
          </div>

          <div className="flex items-center gap-1">
            <span className="text-[#a1a1aa] uppercase">RECOVERY:</span>
            <select
              id="dp-recovery-select"
              value={selectedRecovery}
              onChange={(e) => setSelectedRecovery(Number(e.target.value))}
              className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
            >
              <option value={0.20}>20% (Distressed)</option>
              <option value={0.30}>30% (High Yield)</option>
              <option value={0.40}>40% (ISDA Standard)</option>
              <option value={0.50}>50% (Secured / Fins)</option>
              <option value={0.60}>60% (High Quality)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Visual Chart: Market Implied 5Y Default vs Historical Default */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px]">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2.5">
          <span className="text-[10px] font-mono font-bold text-[#e4e4e7] uppercase tracking-wider">
            Market Implied 5Y Default Probability vs Historical Rating Agency Rate (%)
          </span>
          <span className="text-[9px] font-mono text-[#a1a1aa]">CREDIT RISK PREMIUM SPREAD</span>
        </div>

        <div className="h-60 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={comparisonChartData} margin={{ top: 10, right: 25, left: 5, bottom: 5 }}>
              <CartesianGrid strokeDasharray="2 2" stroke="#27272a" />
              <XAxis dataKey="ticker" stroke="#71717a" tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }} />
              <YAxis stroke="#71717a" tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }} unit="%" />
              <Tooltip
                contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', color: '#e4e4e7', fontFamily: 'monospace', fontSize: 11 }}
              />
              <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: 10 }} />
              <Bar dataKey="Market Implied 5Y PD (%)" fill="#f97316" radius={[2, 2, 0, 0]} />
              <Bar dataKey="Historical 5Y Default (%)" fill="#38bdf8" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Term Structure Table */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
          <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
            CUMULATIVE IMPLIED DEFAULT PROBABILITY MATRIX & RISK PREMIA
          </span>
          <span className="text-[9px] font-mono text-[#a1a1aa]">
            EQUATION: PD(T) = 1 - exp(-[Spread / (1-R)] * T)
          </span>
        </div>

        <table id="default-prob-table" className="w-full text-[10px] font-mono text-left border-collapse">
          <thead>
            <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
              <th className="py-1.5 px-2.5">Entity</th>
              <th className="py-1.5 px-2">Sector</th>
              <th className="py-1.5 px-2">Rating</th>
              <th className="py-1.5 px-2 text-right">5Y Spread</th>
              <th className="py-1.5 px-2 text-right">1Y Implied PD</th>
              <th className="py-1.5 px-2.5 text-right bg-[#18181b] text-rose-300">5Y Implied PD</th>
              <th className="py-1.5 px-2 text-right">10Y Implied PD</th>
              <th className="py-1.5 px-2 text-right text-cyan-400">Hist 5Y PD</th>
              <th className="py-1.5 px-2 text-right text-[#f97316]">Risk Premium</th>
              <th className="py-1.5 px-2 text-right">5Y Expected Loss</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f1f23]">
            {filteredData.map((d) => (
              <tr key={d.entityId} className="hover:bg-white/[0.02] transition-colors">
                <td className="py-1 px-2.5">
                  <div className="font-semibold text-[#e4e4e7] flex items-center gap-1">
                    <span className="text-[#f97316] font-bold">{d.ticker}</span>
                    <span className="text-[9px] text-[#71717a] truncate max-w-[140px]">{d.name}</span>
                  </div>
                </td>
                <td className="py-1 px-2 text-[#a1a1aa] text-[9px]">{d.sector}</td>
                <td className="py-1 px-2">
                  <span className="px-1.5 py-0.2 bg-[#18181b] rounded-[2px] text-[9px] font-bold text-[#e4e4e7] border border-[#27272a]">
                    {d.rating}
                  </span>
                </td>
                <td className="py-1 px-2 text-right font-bold text-[#e4e4e7]">{d.spread5Y.toFixed(1)} bp</td>
                <td className="py-1 px-2 text-right text-[#a1a1aa]">{d.impliedPD1Y.toFixed(2)}%</td>
                <td className="py-1 px-2.5 text-right font-bold text-rose-400 bg-[#18181b]/40">
                  {d.impliedPD5Y.toFixed(2)}%
                </td>
                <td className="py-1 px-2 text-right text-[#a1a1aa]">{d.impliedPD10Y.toFixed(2)}%</td>
                <td className="py-1 px-2 text-right text-cyan-400 font-semibold">{d.histPD5Y.toFixed(2)}%</td>
                <td className="py-1 px-2 text-right font-bold text-[#f97316]">{d.riskPremiumRatio.toFixed(1)}x</td>
                <td className="py-1 px-2 text-right text-[#e4e4e7]">{d.expectedLoss5Y.toFixed(2)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
