/**
 * RHINOQUANT CDS — Quantitative Research & Screener Layer (High Density)
 * Statistical Dislocation Filters, PCA Curves, and R Research Script Generator
 */

import React, { useState } from 'react';
import {
  Search,
  Code,
  Zap,
  Copy,
  Check,
} from 'lucide-react';
import { TradeIdea, CDSSpreadQuote, ReferenceEntity } from '../types/cds';
import { INITIAL_TRADE_IDEAS } from '../data/marketData';
import { generateRResearchSnippet } from '../lib/quantEngine';

interface ResearchScreenerProps {
  quotes: Record<string, CDSSpreadQuote>;
  entities: ReferenceEntity[];
  onExecuteTradeIdea: (idea: TradeIdea) => void;
}

export const ResearchScreenerView: React.FC<ResearchScreenerProps> = ({
  quotes,
  onExecuteTradeIdea,
}) => {
  const [minZScore, setMinZScore] = useState<number>(1.2);
  const [copiedRCode, setCopiedRCode] = useState<boolean>(false);

  const tradeIdeas = INITIAL_TRADE_IDEAS;
  const rCodeSnippet = generateRResearchSnippet('ENT_BA');

  const copyRCode = () => {
    navigator.clipboard.writeText(rCodeSnippet);
    setCopiedRCode(true);
    setTimeout(() => setCopiedRCode(false), 2000);
  };

  const screenedQuotes = (Object.values(quotes) as CDSSpreadQuote[]).filter((q: CDSSpreadQuote) => {
    return Math.abs(q.zScore1Y) >= minZScore;
  });

  return (
    <div id="research-screener-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top Banner */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <Search className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">QUANTITATIVE RESEARCH & STATISTICAL SCREENER</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>Ornstein-Uhlenbeck Mean Reversion, PCA Curve Modes</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-[#18181b] text-[#f97316] font-mono border border-[#27272a]">
                R 4.3.2 STATS
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-[10px]">
          <span className="text-[#a1a1aa] uppercase">MIN |Z-SCORE|:</span>
          <select
            value={minZScore}
            onChange={(e) => setMinZScore(Number(e.target.value))}
            className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
          >
            <option value={0.5}>|Z| &ge; 0.5 (Broad)</option>
            <option value={1.0}>|Z| &ge; 1.0 (Standard)</option>
            <option value={1.5}>|Z| &ge; 1.5 (High Conviction)</option>
            <option value={2.0}>|Z| &ge; 2.0 (Extreme Tail)</option>
          </select>
        </div>
      </div>

      {/* Systematic Trade Ideas Grid */}
      <div className="space-y-2">
        <div className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
          ALPHA GENERATION & QUANTITATIVE TRADE IDEAS
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {tradeIdeas.map((idea) => (
            <div
              key={idea.id}
              className="bg-[#111114] border border-[#27272a] hover:border-[#f97316]/50 p-3 rounded-[2px] space-y-2 transition-all font-mono"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[8px] px-1.5 py-0.2 rounded-[2px] bg-[#18181b] text-[#f97316] font-bold border border-[#27272a]">
                    {idea.strategyType}
                  </span>
                  <div className="text-[12px] font-bold text-[#e4e4e7] mt-1">{idea.title}</div>
                </div>
                <div className="text-right">
                  <div className="text-[8px] text-[#a1a1aa]">EXP RETURN</div>
                  <div className="text-[12px] font-bold text-emerald-400">+{idea.expectedReturnBps} bp</div>
                </div>
              </div>

              <p className="text-[10px] text-[#a1a1aa] font-sans leading-relaxed">
                {idea.rationale}
              </p>

              <div className="grid grid-cols-3 gap-1.5 text-[9px] bg-[#09090b] p-1.5 rounded-[2px] border border-[#27272a]">
                <div>
                  <span className="text-[#71717a] block text-[8px]">CARRY / YR:</span>
                  <span className="text-emerald-400 font-semibold">{idea.netCarryBps > 0 ? `+${idea.netCarryBps}` : idea.netCarryBps} bp</span>
                </div>
                <div>
                  <span className="text-[#71717a] block text-[8px]">HORIZON:</span>
                  <span className="text-[#e4e4e7] font-semibold">{idea.timeHorizon}</span>
                </div>
                <div>
                  <span className="text-[#71717a] block text-[8px]">MAX DD:</span>
                  <span className="text-rose-400 font-semibold">-{idea.maxDrawdownBps} bp</span>
                </div>
              </div>

              <button
                onClick={() => onExecuteTradeIdea(idea)}
                className="w-full py-1.5 bg-[#18181b] hover:bg-[#f97316] hover:text-[#09090b] text-[#f97316] font-bold text-[9px] rounded-[2px] border border-[#f97316]/30 transition-all cursor-pointer flex items-center justify-center gap-1 uppercase tracking-wider"
              >
                <Zap className="w-3 h-3" />
                <span>LOAD STRATEGY INTO ORDER TICKET</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Screened Statistical Dislocation Matrix */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
          <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
            STATISTICAL OUTLIERS & MEAN-REVERSION CANDIDATES (|Z| &ge; {minZScore})
          </span>
          <span className="text-[9px] font-mono text-[#a1a1aa]">
            {screenedQuotes.length} ANOMALIES DETECTED
          </span>
        </div>

        <table className="w-full text-[10px] font-mono text-left border-collapse">
          <thead>
            <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
              <th className="py-1.5 px-2.5">Ticker / Name</th>
              <th className="py-1.5 px-2">Sector</th>
              <th className="py-1.5 px-2 text-right">5Y Spread</th>
              <th className="py-1.5 px-2 text-right">1D Δ</th>
              <th className="py-1.5 px-2 text-right">1Y %ile</th>
              <th className="py-1.5 px-2.5 text-right bg-[#18181b] text-[#f97316]">1Y Z-Score</th>
              <th className="py-1.5 px-2 text-right">30D Vol</th>
              <th className="py-1.5 px-2 text-center">Quant Flag</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f1f23]">
            {screenedQuotes.map((q) => (
              <tr key={q.entityId} className="hover:bg-white/[0.02] transition-colors">
                <td className="py-1 px-2.5">
                  <span className="font-bold text-[#e4e4e7]">{q.ticker}</span>
                  <span className="text-[9px] text-[#71717a] ml-1">{q.entityName}</span>
                </td>
                <td className="py-1 px-2 text-[#a1a1aa]">{q.sector}</td>
                <td className="py-1 px-2 text-right font-bold text-[#e4e4e7]">{q.tenors['5Y'].mid.toFixed(1)} bp</td>
                <td className={`py-1 px-2 text-right ${q.change1D > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {q.change1D > 0 ? `+${q.change1D.toFixed(1)}` : q.change1D.toFixed(1)}
                </td>
                <td className="py-1 px-2 text-right text-[#a1a1aa]">{q.percentile1Y.toFixed(1)}%</td>
                <td className="py-1 px-2.5 text-right font-bold text-[#f97316] bg-[#18181b]/30">
                  {q.zScore1Y > 0 ? `+${q.zScore1Y.toFixed(2)}` : q.zScore1Y.toFixed(2)}
                </td>
                <td className="py-1 px-2 text-right text-[#a1a1aa]">{q.volatility30D.toFixed(1)}%</td>
                <td className="py-1 px-2 text-center">
                  <span className={`px-1.5 py-0.2 rounded-[2px] text-[8px] font-bold ${
                    q.zScore1Y > 0 ? 'bg-rose-950 text-rose-300' : 'bg-emerald-950 text-emerald-300'
                  }`}>
                    {q.zScore1Y > 0 ? 'RICH (SHORT)' : 'CHEAP (BUY)'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* R Quantitative Script Generator */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] space-y-1.5">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 font-mono">
          <div className="flex items-center gap-1.5">
            <Code className="w-3.5 h-3.5 text-[#f97316]" />
            <span className="text-[10px] font-bold text-[#e4e4e7] uppercase">
              R RESEARCH LAYER (ORNSTEIN-UHLENBECK REVERSION & PCA TERM STRUCTURE)
            </span>
          </div>
          <button
            onClick={copyRCode}
            className="flex items-center gap-1 px-2 py-0.5 bg-[#18181b] hover:bg-[#27272a] text-[#e4e4e7] text-[10px] font-mono rounded-[2px] border border-[#27272a] cursor-pointer"
          >
            {copiedRCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copiedRCode ? 'COPIED' : 'COPY R SCRIPT'}</span>
          </button>
        </div>

        <pre className="bg-[#09090b] p-2.5 rounded-[2px] border border-[#27272a] text-[10px] font-mono text-cyan-300 overflow-x-auto max-h-44">
          {rCodeSnippet}
        </pre>
      </div>
    </div>
  );
};
