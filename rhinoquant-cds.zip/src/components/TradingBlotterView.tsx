/**
 * RHINOQUANT CDS — Trading Blotter, Execution Gateway & P&L Attribution (High Density)
 */

import React, { useState } from 'react';
import {
  Layers,
  Zap,
} from 'lucide-react';
import { TradeOrder, PnLAttribution } from '../types/cds';

interface TradingBlotterProps {
  orders: TradeOrder[];
  pnlAttribution: PnLAttribution;
  onOpenNewOrder: () => void;
  onCancelOrder: (orderId: string) => void;
}

export const TradingBlotterView: React.FC<TradingBlotterProps> = ({
  orders,
  pnlAttribution,
  onOpenNewOrder,
  onCancelOrder,
}) => {
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  const filteredOrders = orders.filter((o) => {
    if (selectedStatus === 'ALL') return true;
    return o.status === selectedStatus;
  });

  return (
    <div id="trading-blotter-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top Banner */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">EXECUTION GATEWAY & TRADE BLOTTER</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>Electronic Credit Derivatives Order Routing & MTM Attribution</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-emerald-950/80 text-emerald-300 font-mono border border-emerald-500/40">
                GATEWAY: CONNECTED
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 font-mono text-[10px]">
          <div className="flex items-center gap-1">
            <span className="text-[#a1a1aa] uppercase">STATUS:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
            >
              <option value="ALL">All ({orders.length})</option>
              <option value="FILLED">Filled Only</option>
              <option value="NEW">Working / New</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
          </div>

          <button
            onClick={onOpenNewOrder}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] font-bold rounded-[2px] cursor-pointer uppercase"
          >
            <Zap className="w-3 h-3" />
            <span>SUBMIT ORDER</span>
          </button>
        </div>
      </div>

      {/* P&L Attribution Breakdown Panel */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px]">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2 font-mono">
          <span className="text-[10px] font-bold text-[#f97316] uppercase tracking-wider">
            MTD P&L ATTRIBUTION DECOMPOSITION
          </span>
          <span className="text-[10px] font-bold text-[#e4e4e7]">
            TOTAL NET P&L:{' '}
            <span className={(pnlAttribution?.totalPnl ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
              {(pnlAttribution?.totalPnl ?? 0) >= 0 ? '+' : ''}${(pnlAttribution?.totalPnl ?? 0).toLocaleString()}
            </span>
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 font-mono text-[10px]">
          <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
            <div className="text-[9px] text-[#a1a1aa] uppercase">Carry & Rolldown P&L</div>
            <div className={`text-[12px] font-bold mt-0.5 ${(pnlAttribution?.carryRolldownPnl ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              +${(pnlAttribution?.carryRolldownPnl ?? 0).toLocaleString()}
            </div>
            <div className="text-[8px] text-[#71717a] mt-0.5">Spread accrual & time decay</div>
          </div>

          <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
            <div className="text-[9px] text-[#a1a1aa] uppercase">Spread Delta MTM</div>
            <div className={`text-[12px] font-bold mt-0.5 ${(pnlAttribution?.spreadDeltaPnl ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {(pnlAttribution?.spreadDeltaPnl ?? 0) >= 0 ? '+' : ''}${(pnlAttribution?.spreadDeltaPnl ?? 0).toLocaleString()}
            </div>
            <div className="text-[8px] text-[#71717a] mt-0.5">Market spread movement</div>
          </div>

          <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
            <div className="text-[9px] text-[#a1a1aa] uppercase">Curve Shape / Twist</div>
            <div className={`text-[12px] font-bold mt-0.5 ${(pnlAttribution?.curveShapePnl ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              +${(pnlAttribution?.curveShapePnl ?? 0).toLocaleString()}
            </div>
            <div className="text-[8px] text-[#71717a] mt-0.5">Steepening / Flattening</div>
          </div>

          <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
            <div className="text-[9px] text-[#a1a1aa] uppercase">Default P&L</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] mt-0.5">
              ${(pnlAttribution?.defaultPnl ?? 0).toLocaleString()}
            </div>
            <div className="text-[8px] text-[#71717a] mt-0.5">No credit events triggered</div>
          </div>

          <div className="bg-[#18181b] p-2 rounded-[2px] border border-[#27272a]">
            <div className="text-[9px] text-[#a1a1aa] uppercase">Financing & Fees</div>
            <div className="text-[12px] font-bold text-rose-400 mt-0.5">
              -${Math.abs(pnlAttribution?.financingCost ?? 0).toLocaleString()}
            </div>
            <div className="text-[8px] text-[#71717a] mt-0.5">Clearing & repo funding</div>
          </div>
        </div>
      </div>

      {/* Orders & Executed Trades Table */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
          <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
            TRADE BLOTTER & ORDER AUDIT LOG
          </span>
          <span className="text-[9px] font-mono text-[#a1a1aa]">
            {filteredOrders.length} ORDERS DISPLAYED
          </span>
        </div>

        <table id="trade-blotter-table" className="w-full text-[10px] font-mono text-left border-collapse">
          <thead>
            <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
              <th className="py-1.5 px-2.5">Order / Time</th>
              <th className="py-1.5 px-2">Ticker</th>
              <th className="py-1.5 px-2">Tenor</th>
              <th className="py-1.5 px-2">Side</th>
              <th className="py-1.5 px-2 text-right">Notional</th>
              <th className="py-1.5 px-2 text-right">Limit</th>
              <th className="py-1.5 px-2 text-right">Executed</th>
              <th className="py-1.5 px-2">Venue / Broker</th>
              <th className="py-1.5 px-2 text-center">Status</th>
              <th className="py-1.5 px-2 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f1f23]">
            {filteredOrders.map((ord) => {
              const isFilled = ord.status === 'FILLED';
              const isWorking = ord.status === 'NEW' || ord.status === 'PARTIALLY_FILLED';
              return (
                <tr key={ord.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="py-1 px-2.5">
                    <div className="font-bold text-[#e4e4e7]">{ord.id}</div>
                    <div className="text-[8px] text-[#71717a]">{ord.timestamp}</div>
                  </td>
                  <td className="py-1 px-2 font-semibold text-[#f97316]">{ord.ticker}</td>
                  <td className="py-1 px-2 text-[#a1a1aa]">{ord.tenor}</td>
                  <td className="py-1 px-2">
                    <span className={`px-1.5 py-0.2 rounded-[2px] text-[8px] font-bold ${
                      ord.buySell === 'BUY' ? 'bg-orange-950 text-orange-300' : 'bg-cyan-950 text-cyan-300'
                    }`}>
                      {ord.buySell}
                    </span>
                  </td>
                  <td className="py-1 px-2 text-right text-[#e4e4e7] font-semibold">
                    ${(ord.notional / 1e6).toFixed(1)}M
                  </td>
                  <td className="py-1 px-2 text-right text-[#a1a1aa]">{ord.limitSpread.toFixed(1)} bp</td>
                  <td className="py-1 px-2 text-right text-[#f97316] font-bold">
                    {ord.executedSpread ? `${ord.executedSpread.toFixed(1)} bp` : '—'}
                  </td>
                  <td className="py-1 px-2 text-[#a1a1aa] text-[9px]">
                    <div>{ord.venue}</div>
                    <div className="text-[8px] text-[#71717a]">{ord.counterparty}</div>
                  </td>
                  <td className="py-1 px-2 text-center">
                    <span className={`px-1.5 py-0.2 rounded-[2px] text-[8px] font-bold ${
                      isFilled
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : isWorking
                        ? 'bg-orange-950 text-orange-300 border border-orange-800'
                        : 'bg-[#18181b] text-[#71717a]'
                    }`}>
                      {ord.status}
                    </span>
                  </td>
                  <td className="py-1 px-2 text-center">
                    {isWorking && (
                      <button
                        onClick={() => onCancelOrder(ord.id)}
                        className="px-1.5 py-0.2 bg-rose-950/60 hover:bg-rose-900 text-rose-300 text-[9px] rounded-[2px] cursor-pointer"
                      >
                        CANCEL
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
