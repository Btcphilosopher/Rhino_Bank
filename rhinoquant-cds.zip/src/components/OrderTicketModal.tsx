/**
 * RHINOQUANT CDS — Institutional Order Ticket Modal & Pre-Trade Risk Checks (High Density)
 */

import React, { useState } from 'react';
import {
  Zap,
  X,
  ShieldCheck,
} from 'lucide-react';
import { ReferenceEntity, BuySell, Tenor, OrderType, TradeVenue, TradeOrder } from '../types/cds';
import { priceCDS, TENOR_YEARS_MAP } from '../lib/quantEngine';

interface OrderTicketModalProps {
  isOpen: boolean;
  onClose: () => void;
  entities: ReferenceEntity[];
  initialParams?: {
    entityId?: string;
    notional?: number;
    tenor?: Tenor;
    coupon?: number;
    buySell?: BuySell;
    spread?: number;
  };
  onSubmitOrder: (order: Partial<TradeOrder>) => void;
}

export const OrderTicketModal: React.FC<OrderTicketModalProps> = ({
  isOpen,
  onClose,
  entities,
  initialParams,
  onSubmitOrder,
}) => {
  const [selectedEntityId, setSelectedEntityId] = useState<string>(initialParams?.entityId || entities[0]?.id || 'ENT_BA');
  const [buySell, setBuySell] = useState<BuySell>(initialParams?.buySell || 'BUY');
  const [notional, setNotional] = useState<number>(initialParams?.notional || 10000000);
  const [tenor, setTenor] = useState<Tenor>(initialParams?.tenor || '5Y');
  const [coupon, setCoupon] = useState<number>(initialParams?.coupon || 100);
  const [orderType, setOrderType] = useState<OrderType>('LIMIT_SPREAD');
  const [limitSpread, setLimitSpread] = useState<number>(initialParams?.spread || 145.0);
  const [venue, setVenue] = useState<TradeVenue>('TRADEWEB');
  const [counterparty, setCounterparty] = useState<string>('JPMorgan Chase');

  if (!isOpen) return null;

  const currentEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];

  // Pre-Trade Real-Time Quantitative Check
  const estimatedPricing = priceCDS({
    notional,
    tradeSpread: coupon,
    marketSpread: limitSpread,
    tenorYears: TENOR_YEARS_MAP[tenor],
    recoveryRate: currentEntity?.standardRecovery || 0.40,
    riskFreeRate: 0.042,
    buySell,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitOrder({
      ticker: currentEntity.ticker,
      entityName: currentEntity.name,
      contractType: currentEntity.contractType,
      tenor,
      buySell,
      notional,
      coupon,
      orderType,
      limitSpread,
      venue,
      counterparty,
    });
    onClose();
  };

  return (
    <div id="order-ticket-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3">
      <div className="bg-[#111114] border border-[#27272a] w-full max-w-2xl rounded-[2px] shadow-2xl overflow-hidden flex flex-col text-[#e4e4e7] font-mono">
        {/* Header */}
        <div className="bg-[#18181b] px-3 py-2 border-b border-[#27272a] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-[2px] bg-[#111114] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
              <Zap className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="font-bold text-[11px] text-[#e4e4e7] flex items-center gap-1.5 uppercase">
                <span>ELECTRONIC CDS ORDER TICKET</span>
                <span className="text-[8px] px-1.5 py-0.2 rounded-[2px] bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                  FIX 4.4 / FpML
                </span>
              </div>
              <p className="text-[8px] text-[#a1a1aa]">
                Execution Gateway & Real-Time Pre-Trade Risk Approval
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#27272a] rounded-[2px] text-[#a1a1aa] hover:text-[#e4e4e7] cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Order Form */}
        <form onSubmit={handleSubmit} className="p-3 space-y-2.5 text-[10px]">
          {/* Reference Entity & Side */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-[#a1a1aa] mb-0.5 uppercase text-[9px]">REFERENCE ENTITY</label>
              <select
                id="order-entity-select"
                value={selectedEntityId}
                onChange={(e) => setSelectedEntityId(e.target.value)}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] focus:outline-none focus:border-[#f97316] cursor-pointer text-[10px]"
              >
                {entities.map((ent) => (
                  <option key={ent.id} value={ent.id} className="bg-[#111114]">
                    {ent.ticker} — {ent.name} ({ent.sector})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[#a1a1aa] mb-0.5 uppercase text-[9px]">SIDE (PROTECTION)</label>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => setBuySell('BUY')}
                  className={`py-1 rounded-[2px] font-bold cursor-pointer transition-all uppercase ${
                    buySell === 'BUY'
                      ? 'bg-[#f97316] text-[#09090b]'
                      : 'bg-[#18181b] text-[#a1a1aa] hover:bg-[#27272a]'
                  }`}
                >
                  BUY (Long Prot.)
                </button>
                <button
                  type="button"
                  onClick={() => setBuySell('SELL')}
                  className={`py-1 rounded-[2px] font-bold cursor-pointer transition-all uppercase ${
                    buySell === 'SELL'
                      ? 'bg-cyan-600 text-white'
                      : 'bg-[#18181b] text-[#a1a1aa] hover:bg-[#27272a]'
                  }`}
                >
                  SELL (Short Prot.)
                </button>
              </div>
            </div>
          </div>

          {/* Notional & Tenor */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
            <div className="md:col-span-2">
              <label className="block text-[#a1a1aa] mb-0.5 uppercase text-[9px]">NOTIONAL (USD)</label>
              <input
                id="order-notional-input"
                type="number"
                value={notional}
                onChange={(e) => setNotional(Number(e.target.value))}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] font-bold focus:outline-none focus:border-[#f97316] text-[10px]"
              />
            </div>
            <div>
              <label className="block text-[#a1a1aa] mb-0.5 uppercase text-[9px]">TENOR</label>
              <select
                value={tenor}
                onChange={(e) => setTenor(e.target.value as Tenor)}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] focus:outline-none focus:border-[#f97316] cursor-pointer text-[10px]"
              >
                <option value="6M">6M</option>
                <option value="1Y">1Y</option>
                <option value="2Y">2Y</option>
                <option value="3Y">3Y</option>
                <option value="5Y">5Y (Bench)</option>
                <option value="7Y">7Y</option>
                <option value="10Y">10Y</option>
              </select>
            </div>
          </div>

          {/* Running Coupon & Limit Spread */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <div>
              <label className="block text-[#a1a1aa] mb-0.5 uppercase text-[9px]">STANDARD COUPON (bps)</label>
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => setCoupon(100)}
                  className={`flex-1 py-1 rounded-[2px] cursor-pointer border ${
                    coupon === 100 ? 'bg-[#f97316]/20 border-[#f97316] text-[#f97316] font-bold' : 'bg-[#09090b] border-[#27272a] text-[#a1a1aa]'
                  }`}
                >
                  100 bp (IG)
                </button>
                <button
                  type="button"
                  onClick={() => setCoupon(500)}
                  className={`flex-1 py-1 rounded-[2px] cursor-pointer border ${
                    coupon === 500 ? 'bg-[#f97316]/20 border-[#f97316] text-[#f97316] font-bold' : 'bg-[#09090b] border-[#27272a] text-[#a1a1aa]'
                  }`}
                >
                  500 bp (HY)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[#a1a1aa] mb-0.5 uppercase text-[9px]">LIMIT SPREAD (bps)</label>
              <input
                id="order-limit-spread-input"
                type="number"
                step="0.5"
                value={limitSpread}
                onChange={(e) => setLimitSpread(Number(e.target.value))}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#f97316] font-bold focus:outline-none focus:border-[#f97316] text-[10px]"
              />
            </div>
          </div>

          {/* Venue & Counterparty */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <div>
              <label className="block text-[#a1a1aa] mb-0.5 uppercase text-[9px]">EXECUTION VENUE</label>
              <select
                value={venue}
                onChange={(e) => setVenue(e.target.value as TradeVenue)}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] focus:outline-none focus:border-[#f97316] cursor-pointer text-[10px]"
              >
                <option value="TRADEWEB">TradeWeb Institutional</option>
                <option value="MARKETAXESS">MarketAxess Credit</option>
                <option value="ICE_LINK">ICE Link</option>
                <option value="BLOOMBERG_FIT">Bloomberg FIT</option>
                <option value="BILATERAL_VOICE">Direct Bilateral Voice</option>
              </select>
            </div>

            <div>
              <label className="block text-[#a1a1aa] mb-0.5 uppercase text-[9px]">COUNTERPARTY</label>
              <select
                value={counterparty}
                onChange={(e) => setCounterparty(e.target.value)}
                className="w-full bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] focus:outline-none focus:border-[#f97316] cursor-pointer text-[10px]"
              >
                <option value="JPMorgan Chase">JPMorgan Chase</option>
                <option value="Goldman Sachs">Goldman Sachs</option>
                <option value="Morgan Stanley">Morgan Stanley</option>
                <option value="Barclays Capital">Barclays Capital</option>
                <option value="Citigroup">Citigroup Global Markets</option>
                <option value="Bank of America">Bank of America Merrill</option>
              </select>
            </div>
          </div>

          {/* Pre-Trade Risk Impact Check Card */}
          <div className="bg-[#09090b] p-2.5 rounded-[2px] border border-[#27272a] space-y-1.5">
            <div className="flex items-center justify-between text-[#a1a1aa] border-b border-[#27272a] pb-1">
              <span className="font-bold uppercase text-[9px] text-[#f97316] flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>Pre-Trade Risk & Margin Verification</span>
              </span>
              <span className="text-[8px] text-emerald-400">PASSED MANDATE LIMITS</span>
            </div>

            <div className="grid grid-cols-3 gap-1.5 text-[9px]">
              <div>
                <span className="text-[#71717a] block text-[8px] uppercase">EST. UPFRONT:</span>
                <span className="text-[#e4e4e7] font-bold">${Math.abs(estimatedPricing.upfrontCash).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              </div>
              <div>
                <span className="text-[#71717a] block text-[8px] uppercase">INC. CS01:</span>
                <span className={`font-bold ${estimatedPricing.cs01 >= 0 ? 'text-emerald-400' : 'text-[#f97316]'}`}>
                  {estimatedPricing.cs01 >= 0 ? '+' : ''}${estimatedPricing.cs01.toLocaleString(undefined, { maximumFractionDigits: 0 })}/bp
                </span>
              </div>
              <div>
                <span className="text-[#71717a] block text-[8px] uppercase">INC. JTD:</span>
                <span className={`font-bold ${estimatedPricing.jumpToDefault >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  ${(estimatedPricing.jumpToDefault / 1e6).toFixed(2)}M
                </span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1 bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] font-bold rounded-[2px] cursor-pointer transition-colors uppercase text-[10px]"
            >
              CANCEL
            </button>
            <button
              id="submit-order-confirm-btn"
              type="submit"
              className="px-3.5 py-1 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] font-bold rounded-[2px] transition-all cursor-pointer flex items-center gap-1 uppercase text-[10px]"
            >
              <Zap className="w-3 h-3" />
              <span>EXECUTE ORDER</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
