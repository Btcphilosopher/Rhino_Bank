/**
 * RHINOQUANT CDS — CDS-Bond Basis Analyzer & Relative Value Screener (High Density)
 * Cash Bond vs Synthetic CDS Dislocation, Z-Spreads, ASW, and Arbitrage
 */

import React, { useState } from 'react';
import {
  Scale,
  Zap,
} from 'lucide-react';
import { CashBond, CDSSpreadQuote } from '../types/cds';

interface BasisViewProps {
  bonds: CashBond[];
  quotes: Record<string, CDSSpreadQuote>;
  onExecuteBasisTrade: (bond: CashBond, tradeType: 'NEGATIVE_BASIS' | 'POSITIVE_BASIS') => void;
}

export const BasisView: React.FC<BasisViewProps> = ({ bonds, quotes, onExecuteBasisTrade }) => {
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [minZScore, setMinZScore] = useState<number>(0);
  const [selectedBondId, setSelectedBondId] = useState<string>(bonds[0]?.id || '');

  const filteredBonds = bonds.filter((b) => {
    const quote = quotes[b.entityId];
    if (!quote) return false;
    const matchesSector = selectedSector === 'ALL' || quote.sector === selectedSector;
    const matchesZ = Math.abs(b.basisZScore) >= minZScore;
    return matchesSector && matchesZ;
  });

  const activeBond = bonds.find((b) => b.id === selectedBondId) || bonds[0];

  return (
    <div id="basis-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Header & Overview */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <Scale className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">CDS-BOND BASIS & RELATIVE VALUE WORKSTATION</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>Cash vs Synthetic Basis Dislocation Screener</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-[#18181b] text-[#f97316] font-mono border border-[#27272a]">
                Basis = CDS Spread - Bond Z-Spread
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 font-mono text-[10px]">
          <div className="flex items-center gap-1">
            <span className="text-[#a1a1aa] uppercase">SECTOR:</span>
            <select
              id="basis-sector-filter"
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
            >
              <option value="ALL">All Sectors</option>
              <option value="Financials">Financials</option>
              <option value="Industrials">Industrials</option>
              <option value="Technology">Technology</option>
              <option value="Consumer">Consumer</option>
              <option value="Telecommunications">Telecommunications</option>
            </select>
          </div>

          <div className="flex items-center gap-1">
            <span className="text-[#a1a1aa] uppercase">MIN |Z|:</span>
            <select
              id="basis-zscore-filter"
              value={minZScore}
              onChange={(e) => setMinZScore(Number(e.target.value))}
              className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
            >
              <option value={0}>All Levels</option>
              <option value={1.0}>|Z| &ge; 1.0 (Mild)</option>
              <option value={1.5}>|Z| &ge; 1.5 (Significant)</option>
              <option value={2.0}>|Z| &ge; 2.0 (Extreme Arb)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Grid: Screen Table (Left) + Arbitrage Structure Analyzer (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-2.5">
        {/* Left Column: Dislocation Screener Table */}
        <div className="lg:col-span-8 bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
          <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
            <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
              Cash Bonds vs Benchmark CDS Spreads
            </span>
            <span className="text-[9px] font-mono text-[#a1a1aa]">
              {filteredBonds.length} ISSUES MONITORED
            </span>
          </div>

          <table id="basis-screener-table" className="w-full text-[10px] font-mono text-left border-collapse">
            <thead>
              <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
                <th className="py-1.5 px-2.5">Issuer / Bond CUSIP</th>
                <th className="py-1.5 px-2">Maturity</th>
                <th className="py-1.5 px-2 text-right">Price</th>
                <th className="py-1.5 px-2 text-right">Z-Spread</th>
                <th className="py-1.5 px-2 text-right">CDS Spread</th>
                <th className="py-1.5 px-2.5 text-right bg-[#18181b]">Basis</th>
                <th className="py-1.5 px-2 text-right">Z-Score</th>
                <th className="py-1.5 px-2 text-center">Type</th>
                <th className="py-1.5 px-2 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1f1f23]">
              {filteredBonds.map((b) => {
                const isNegativeBasis = b.basis < 0;
                const isSelected = b.id === activeBond?.id;
                return (
                  <tr
                    key={b.id}
                    onClick={() => setSelectedBondId(b.id)}
                    className={`hover:bg-white/[0.02] cursor-pointer transition-colors ${
                      isSelected ? 'bg-[#f97316]/10 border-l-2 border-[#f97316]' : ''
                    }`}
                  >
                    <td className="py-1 px-2.5">
                      <div className="font-semibold text-[#e4e4e7] flex items-center gap-1">
                        <span className="text-[#f97316] font-bold">{b.ticker}</span>
                        <span className="text-[9px] text-[#a1a1aa]">{b.couponRate}%</span>
                      </div>
                      <div className="text-[8px] text-[#71717a]">{b.cusip}</div>
                    </td>
                    <td className="py-1 px-2 text-[#a1a1aa]">{b.maturityDate}</td>
                    <td className="py-1 px-2 text-right text-[#e4e4e7]">{b.price.toFixed(2)}</td>
                    <td className="py-1 px-2 text-right text-[#a1a1aa] font-semibold">{b.zSpread.toFixed(1)} bp</td>
                    <td className="py-1 px-2 text-right text-[#f97316] font-semibold">{b.matchingCDSSpread.toFixed(1)} bp</td>
                    <td className="py-1 px-2.5 text-right font-extrabold bg-[#18181b]/30">
                      <span className={isNegativeBasis ? 'text-cyan-400' : 'text-[#f97316]'}>
                        {b.basis > 0 ? '+' : ''}{b.basis.toFixed(1)} bp
                      </span>
                    </td>
                    <td className="py-1 px-2 text-right">
                      <span className={Math.abs(b.basisZScore) >= 1.5 ? 'text-[#f97316] font-bold' : 'text-[#71717a]'}>
                        {b.basisZScore >= 0 ? `+${b.basisZScore.toFixed(2)}` : b.basisZScore.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-1 px-2 text-center">
                      <span
                        className={`px-1.5 py-0.2 rounded-[2px] text-[8px] font-bold ${
                          isNegativeBasis
                            ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                            : 'bg-orange-950 text-orange-300 border border-orange-800'
                        }`}
                      >
                        {isNegativeBasis ? 'NEG' : 'POS'}
                      </span>
                    </td>
                    <td className="py-1 px-2 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedBondId(b.id);
                        }}
                        className={`px-1.5 py-0.2 rounded-[2px] text-[9px] font-mono cursor-pointer border ${
                          isSelected ? 'bg-[#f97316] text-[#09090b] font-bold border-[#f97316]' : 'bg-[#18181b] text-[#a1a1aa] border-[#27272a]'
                        }`}
                      >
                        {isSelected ? 'ACTIVE' : 'VIEW'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Right Column: Basis Trade Structure & Arbitrage Mechanics */}
        <div className="lg:col-span-4 bg-[#111114] border border-[#27272a] p-3 rounded-[2px] space-y-2.5">
          <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5">
            <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
              ARBITRAGE STRUCTURE
            </span>
            <span className="text-[9px] font-mono text-[#a1a1aa]">{activeBond?.ticker} PACKAGE</span>
          </div>

          {activeBond ? (
            <div className="space-y-2.5 font-mono text-[10px]">
              {/* Basis Summary Banner */}
              <div className="bg-[#09090b] p-2 rounded-[2px] border border-[#27272a] space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-[#a1a1aa]">Selected Bond:</span>
                  <span className="text-[#e4e4e7] font-bold">{activeBond.entityName} {activeBond.couponRate}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#a1a1aa]">Observed Basis:</span>
                  <span className={`font-extrabold text-[12px] ${activeBond.basis < 0 ? 'text-cyan-400' : 'text-[#f97316]'}`}>
                    {activeBond.basis > 0 ? '+' : ''}{activeBond.basis.toFixed(1)} bp
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#a1a1aa]">Statistical Z-Score:</span>
                  <span className="text-[#f97316] font-semibold">{activeBond.basisZScore.toFixed(2)} σ</span>
                </div>
              </div>

              {/* Trade Blueprint Mechanics */}
              <div className="p-2 bg-[#09090b] rounded-[2px] border border-[#27272a] space-y-1.5 text-[10px]">
                <div className="text-[#f97316] font-bold text-[9px] uppercase">
                  {activeBond.basis < 0 ? 'NEGATIVE BASIS ARBITRAGE BLUEPRINT' : 'POSITIVE BASIS TRADE BLUEPRINT'}
                </div>
                
                {activeBond.basis < 0 ? (
                  <div className="space-y-1 text-[#a1a1aa] text-[9px]">
                    <div className="flex items-start gap-1">
                      <span className="text-emerald-400 font-bold">1.</span>
                      <span>Buy Cash Bond at <strong className="text-[#e4e4e7]">${activeBond.price}</strong> (Yielding +{activeBond.zSpread}bp over SOFR).</span>
                    </div>
                    <div className="flex items-start gap-1">
                      <span className="text-emerald-400 font-bold">2.</span>
                      <span>Buy Single-Name CDS Protection at <strong className="text-[#f97316]">{activeBond.matchingCDSSpread}bp</strong>.</span>
                    </div>
                    <div className="flex items-start gap-1">
                      <span className="text-emerald-400 font-bold">3.</span>
                      <span>Finance bond in General Collateral Repo.</span>
                    </div>
                    <div className="mt-1.5 pt-1.5 border-t border-[#27272a] flex justify-between items-center font-bold text-[10px] text-emerald-400">
                      <span>Net Arbitrage Spread Locked:</span>
                      <span>+{Math.abs(activeBond.basis).toFixed(1)} bp / year</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1 text-[#a1a1aa] text-[9px]">
                    <div className="flex items-start gap-1">
                      <span className="text-cyan-400 font-bold">1.</span>
                      <span>Short Cash Bond (Borrow via Repo).</span>
                    </div>
                    <div className="flex items-start gap-1">
                      <span className="text-cyan-400 font-bold">2.</span>
                      <span>Sell Single-Name CDS Protection (+{activeBond.matchingCDSSpread}bp).</span>
                    </div>
                    <div className="mt-1.5 pt-1.5 border-t border-[#27272a] flex justify-between items-center font-bold text-[10px] text-[#f97316]">
                      <span>Net Carry Locked:</span>
                      <span>+{activeBond.basis.toFixed(1)} bp / year</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Execution Action Button */}
              <button
                id="execute-basis-package-btn"
                onClick={() => onExecuteBasisTrade(activeBond, activeBond.basis < 0 ? 'NEGATIVE_BASIS' : 'POSITIVE_BASIS')}
                className="w-full py-2 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] font-bold text-[10px] rounded-[2px] shadow transition-all cursor-pointer flex items-center justify-center gap-1.5 uppercase font-mono tracking-wider"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>EXECUTE BASIS PACKAGE</span>
              </button>
            </div>
          ) : (
            <div className="text-[#71717a] text-[10px] font-mono">Select a bond to inspect basis mechanics.</div>
          )}
        </div>
      </div>
    </div>
  );
};
