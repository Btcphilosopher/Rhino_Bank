/**
 * RHINOQUANT CDS — Reporting, Audit & Model Governance Engine (High Density)
 */

import React, { useState } from 'react';
import {
  Download,
  CheckCircle,
  FileSpreadsheet,
  FileCheck,
} from 'lucide-react';
import { CDSPosition, PortfolioRiskSummary, CDSSpreadQuote } from '../types/cds';

interface ReportsAuditProps {
  positions: CDSPosition[];
  riskSummary: PortfolioRiskSummary;
  quotes: Record<string, CDSSpreadQuote>;
}

export const ReportsAuditView: React.FC<ReportsAuditProps> = ({
  positions,
  riskSummary,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  // Audit Log items
  const auditLogs = [
    { id: 'LOG_9941', timestamp: '2026-08-25 14:15:02 UTC', user: 'j.quant@rhinoquant.com', role: 'Quant', action: 'BOOTSTRAP_CURVE', target: 'BA 5Y Hazard Curve calibrated with 7 nodes' },
    { id: 'LOG_9940', timestamp: '2026-08-25 13:42:19 UTC', user: 'm.trader@rhinoquant.com', role: 'Trader', action: 'SUBMIT_ORDER', target: 'ORD_9001 (BUY 10M CDX NA IG 5Y @ 60.5bp)' },
    { id: 'LOG_9939', timestamp: '2026-08-25 12:00:00 UTC', user: 'SYSTEM_ENGINE', role: 'System', action: 'EOD_MARK_CAPTURE', target: 'ISDA composite mark consensus snapshot locked' },
    { id: 'LOG_9938', timestamp: '2026-08-25 10:15:45 UTC', user: 'r.risk@rhinoquant.com', role: 'Risk Manager', action: 'RUN_STRESS_TEST', target: 'Macro scenario "2008 Financial Crisis" evaluated' },
    { id: 'LOG_9937', timestamp: '2026-08-25 09:30:11 UTC', user: 'c.compliance@rhinoquant.com', role: 'Compliance', action: 'LIMIT_CHECK_PASS', target: 'Pre-trade CS01 and JTD risk limits verified within threshold' },
  ];

  // CSV Exporter for Positions
  const exportPositionsCSV = () => {
    const headers = 'ID,Ticker,ContractType,Tenor,Side,Notional,CouponBps,MarketSpreadBps,MTM,CS01,JTD,Counterparty\n';
    const rows = positions.map((p) =>
      `${p.id},${p.ticker},${p.contractType},${p.tenor},${p.buySell},${p.notional},${p.coupon},${p.marketSpread},${p.mtm},${p.cs01},${p.jtd},"${p.counterparty}"`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RHINOQUANT_CDS_POSITIONS_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    setDownloadSuccess('Positions CSV successfully exported.');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  // JSON Exporter for Risk Report
  const exportRiskJSON = () => {
    const report = {
      firm: 'RhinoQuant Capital Management LLC',
      division: 'Credit Derivatives & Quantitative Strategies',
      reportType: 'INSTITUTIONAL_DAILY_CREDIT_TEARSHEET',
      generatedAt: new Date().toISOString(),
      modelStandard: 'ISDA 2014 STANDARD CDS MODEL',
      riskSummary,
      positions,
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RHINOQUANT_DAILY_RISK_REPORT_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    setDownloadSuccess('Risk Report JSON successfully exported.');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  return (
    <div id="reports-audit-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top Banner */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <FileCheck className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">REPORTING ENGINE, AUDIT TRAIL & GOVERNANCE</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>Institutional Risk Tear Sheet & Immutable Audit</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-emerald-950/80 text-emerald-300 font-mono border border-emerald-500/40">
                SHA-256 VERIFIED
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-[10px]">
          <button
            onClick={exportPositionsCSV}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#18181b] hover:bg-[#27272a] text-[#e4e4e7] rounded-[2px] border border-[#27272a] cursor-pointer"
          >
            <FileSpreadsheet className="w-3 h-3 text-emerald-400" />
            <span>EXPORT CSV</span>
          </button>
          <button
            onClick={exportRiskJSON}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] font-bold rounded-[2px] cursor-pointer uppercase"
          >
            <Download className="w-3 h-3" />
            <span>EXPORT JSON TEARSHEET</span>
          </button>
        </div>
      </div>

      {downloadSuccess && (
        <div className="bg-emerald-950/80 border border-emerald-500/40 p-2 rounded-[2px] font-mono text-[10px] text-emerald-300 flex items-center gap-1.5">
          <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
          <span>{downloadSuccess}</span>
        </div>
      )}

      {/* Daily Institutional Credit Risk Tear Sheet Preview */}
      <div className="bg-[#111114] border border-[#27272a] p-3.5 rounded-[2px] space-y-3 font-mono">
        <div className="flex justify-between items-start border-b border-[#27272a] pb-2.5">
          <div>
            <div className="text-[14px] font-bold text-[#e4e4e7] tracking-wider">
              RHINOQUANT <span className="text-[#f97316]">CREDIT DERIVATIVES TEARSHEET</span>
            </div>
            <div className="text-[9px] text-[#a1a1aa] mt-0.5">
              End-of-Day Risk, Valuation & Scenario Summary • Date: {new Date().toLocaleDateString()}
            </div>
          </div>
          <div className="text-right text-[9px] text-[#a1a1aa]">
            <div>CONFIDENTIAL — DESK USE ONLY</div>
            <div className="text-emerald-400 mt-0.5">ISDA 2014 STANDARD ENGINE</div>
          </div>
        </div>

        {/* Core Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px]">
          <div className="bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
            <span className="text-[#a1a1aa] text-[8px] block uppercase">GROSS NOTIONAL</span>
            <span className="text-[#e4e4e7] font-bold text-[12px] mt-0.5 block">${(((riskSummary?.totalGrossNotional ?? 0)) / 1e6).toFixed(1)}M USD</span>
          </div>
          <div className="bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
            <span className="text-[#a1a1aa] text-[8px] block uppercase">PORTFOLIO CS01</span>
            <span className="text-[#f97316] font-bold text-[12px] mt-0.5 block">${(riskSummary?.totalCS01 ?? 0).toLocaleString()}/bp</span>
          </div>
          <div className="bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
            <span className="text-[#a1a1aa] text-[8px] block uppercase">UNREALIZED MTM</span>
            <span className="text-emerald-400 font-bold text-[12px] mt-0.5 block">{(riskSummary?.totalMTM ?? 0) >= 0 ? '+' : ''}${(riskSummary?.totalMTM ?? 0).toLocaleString()} USD</span>
          </div>
          <div className="bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
            <span className="text-[#a1a1aa] text-[8px] block uppercase">1D 99% CREDIT VaR</span>
            <span className="text-rose-400 font-bold text-[12px] mt-0.5 block">${(riskSummary?.creditVaR99_1D ?? 0).toLocaleString()} USD</span>
          </div>
        </div>
      </div>

      {/* Model Governance & Methodology Attestation */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] space-y-2 font-mono text-[10px]">
        <div className="text-[10px] font-bold text-[#f97316] uppercase tracking-wider">
          QUANTITATIVE MODEL GOVERNANCE & ISDA COMPLIANCE
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[#a1a1aa]">
          <div className="flex items-start gap-1.5 bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-[#e4e4e7]">ISDA 2014 Standard Pricing Model</div>
              <div className="text-[9px] text-[#71717a]">Quarterly accrual conventions (IMM dates 20 Mar, 20 Jun, 20 Sep, 20 Dec), Actual/360 day count.</div>
            </div>
          </div>
          <div className="flex items-start gap-1.5 bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-[#e4e4e7]">Hazard Rate Curve Calibration</div>
              <div className="text-[9px] text-[#71717a]">Piecewise constant intensity bootstrapping with deterministic root-finding and survival monotonicity check.</div>
            </div>
          </div>
          <div className="flex items-start gap-1.5 bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-[#e4e4e7]">SOFR OIS Discounting</div>
              <div className="text-[9px] text-[#71717a]">Continuous discounting factor formulation exp(-r*t) mapped from zero rates curve.</div>
            </div>
          </div>
          <div className="flex items-start gap-1.5 bg-[#09090b] p-2 rounded-[2px] border border-[#27272a]">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-[#e4e4e7]">Non-Linear JTD & CS01 Greeks</div>
              <div className="text-[9px] text-[#71717a]">Full repricing under discrete bumps rather than purely linear delta approximations.</div>
            </div>
          </div>
        </div>
      </div>

      {/* Immutable Audit Log Table */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
          <span className="text-[10px] font-mono font-bold text-[#e4e4e7] uppercase tracking-wider">
            SYSTEM & USER AUDIT TRAIL (SOC 2 COMPLIANT)
          </span>
          <span className="text-[9px] font-mono text-[#a1a1aa]">CRYPTOGRAPHIC LOG CHAIN</span>
        </div>

        <table className="w-full text-[10px] font-mono text-left border-collapse">
          <thead>
            <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
              <th className="py-1.5 px-2.5">Event ID</th>
              <th className="py-1.5 px-2">Timestamp (UTC)</th>
              <th className="py-1.5 px-2">User / Identity</th>
              <th className="py-1.5 px-2">Role</th>
              <th className="py-1.5 px-2">Action</th>
              <th className="py-1.5 px-2.5">Target Details</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f1f23]">
            {auditLogs.map((log) => (
              <tr key={log.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="py-1 px-2.5 font-bold text-[#f97316]">{log.id}</td>
                <td className="py-1 px-2 text-[#71717a]">{log.timestamp}</td>
                <td className="py-1 px-2 text-[#e4e4e7]">{log.user}</td>
                <td className="py-1 px-2">
                  <span className="px-1.5 py-0.2 bg-[#18181b] text-[#a1a1aa] rounded-[2px] text-[9px] border border-[#27272a]">
                    {log.role}
                  </span>
                </td>
                <td className="py-1 px-2 font-bold text-cyan-400">{log.action}</td>
                <td className="py-1 px-2.5 text-[#a1a1aa]">{log.target}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
