/**
 * RHINOQUANT CDS — Credit Curve Construction & Hazard Rate Engine (High Density)
 * Bootstraps piecewise constant hazard rates, survival curves, and diagnostics
 */

import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import {
  GitCommit,
  CheckCircle,
} from 'lucide-react';
import { ReferenceEntity, CDSSpreadQuote, Tenor, CDSCurve } from '../types/cds';
import { bootstrapHazardCurve } from '../lib/quantEngine';

interface CurvesHazardProps {
  entities: ReferenceEntity[];
  quotes: Record<string, CDSSpreadQuote>;
  selectedEntityId: string;
  onSelectEntity: (id: string) => void;
}

export const CurvesHazardView: React.FC<CurvesHazardProps> = ({
  entities,
  quotes,
  selectedEntityId,
  onSelectEntity,
}) => {
  const currentEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];
  const quote = quotes[currentEntity.id] || quotes['ENT_BA'] || Object.values(quotes)[0];

  const [customRecovery, setCustomRecovery] = useState<number>(currentEntity.standardRecovery);
  const [riskFreeRate] = useState<number>(0.042);
  const [activeCurveTab, setActiveCurveTab] = useState<'SPREAD_HAZARD' | 'SURVIVAL_DEFAULT'>('SPREAD_HAZARD');

  // Multi-tenor spread inputs (allows interactive bumping)
  const [spreadAdjustments, setSpreadAdjustments] = useState<Record<string, number>>({});

  const effectiveSpreads = useMemo(() => {
    const mapped: Record<Tenor, number> = {
      '6M': (quote.tenors['6M']?.mid || 20) + (spreadAdjustments['6M'] || 0),
      '1Y': (quote.tenors['1Y']?.mid || 30) + (spreadAdjustments['1Y'] || 0),
      '2Y': (quote.tenors['2Y']?.mid || 45) + (spreadAdjustments['2Y'] || 0),
      '3Y': (quote.tenors['3Y']?.mid || 60) + (spreadAdjustments['3Y'] || 0),
      '4Y': (quote.tenors['4Y']?.mid || 70) + (spreadAdjustments['4Y'] || 0),
      '5Y': (quote.tenors['5Y']?.mid || 85) + (spreadAdjustments['5Y'] || 0),
      '7Y': (quote.tenors['7Y']?.mid || 105) + (spreadAdjustments['7Y'] || 0),
      '10Y': (quote.tenors['10Y']?.mid || 130) + (spreadAdjustments['10Y'] || 0),
      '15Y': (quote.tenors['15Y']?.mid || 150) + (spreadAdjustments['15Y'] || 0),
      '20Y': (quote.tenors['20Y']?.mid || 170) + (spreadAdjustments['20Y'] || 0),
      '30Y': (quote.tenors['30Y']?.mid || 195) + (spreadAdjustments['30Y'] || 0),
    };
    return mapped;
  }, [quote, spreadAdjustments]);

  // Calibrate & Bootstrap Hazard Curve
  const calibratedCurve: CDSCurve = useMemo(() => {
    return bootstrapHazardCurve(
      currentEntity.id,
      currentEntity.name,
      effectiveSpreads,
      customRecovery,
      riskFreeRate
    );
  }, [currentEntity, effectiveSpreads, customRecovery, riskFreeRate]);

  // Curve Shape Slopes
  const slope1Y_5Y = (effectiveSpreads['5Y'] - effectiveSpreads['1Y']).toFixed(2);
  const slope3Y_5Y = (effectiveSpreads['5Y'] - effectiveSpreads['3Y']).toFixed(2);
  const slope5Y_10Y = (effectiveSpreads['10Y'] - effectiveSpreads['5Y']).toFixed(2);
  const butterfly2_5_10 = (2 * effectiveSpreads['5Y'] - effectiveSpreads['2Y'] - effectiveSpreads['10Y']).toFixed(2);

  // Chart dataset
  const chartData = calibratedCurve.points.map((pt) => ({
    tenor: pt.tenor,
    year: pt.yearFrac,
    spreadBps: Number(pt.marketSpread.toFixed(2)),
    hazardRatePct: Number((pt.hazardRate * 100).toFixed(3)),
    survivalProbPct: Number((pt.survivalProb * 100).toFixed(2)),
    cumDefaultProbPct: Number((pt.cumDefaultProb * 100).toFixed(2)),
    marginalDefaultProbPct: Number((pt.marginalDefaultProb * 100).toFixed(2)),
    forwardHazardPct: Number((pt.forwardHazardRate * 100).toFixed(3)),
  }));

  const resetBumps = () => {
    setSpreadAdjustments({});
  };

  const bumpTenor = (tenor: Tenor, delta: number) => {
    setSpreadAdjustments((prev) => ({
      ...prev,
      [tenor]: (prev[tenor] || 0) + delta,
    }));
  };

  return (
    <div id="curves-hazard-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Header Selector & Status */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <GitCommit className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">HAZARD RATE CURVE & SURVIVAL ENGINE</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>{currentEntity.name} ({currentEntity.ticker})</span>
              <span
                className={`text-[9px] px-1.5 py-0.2 rounded-[2px] font-mono font-bold ${
                  calibratedCurve.calibrationStatus === 'VALID'
                    ? 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-300'
                    : 'bg-amber-950/80 border border-amber-500/40 text-amber-300'
                }`}
              >
                {calibratedCurve.calibrationStatus === 'VALID' ? 'CALIBRATION CONVERGED' : calibratedCurve.calibrationStatus}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 font-mono text-[10px]">
          <div className="flex items-center gap-1">
            <span className="text-[#a1a1aa] uppercase">ENTITY:</span>
            <select
              id="curve-entity-select"
              value={selectedEntityId}
              onChange={(e) => { onSelectEntity(e.target.value); setSpreadAdjustments({}); }}
              className="bg-[#09090b] border border-[#27272a] rounded-[2px] px-2 py-1 text-[#e4e4e7] text-[10px] focus:outline-none focus:border-[#f97316] cursor-pointer"
            >
              {entities.map((ent) => (
                <option key={ent.id} value={ent.id} className="bg-[#111114]">
                  {ent.ticker} — {ent.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1">
            <span className="text-[#a1a1aa] uppercase">REC:</span>
            <input
              type="number"
              step="0.05"
              value={customRecovery}
              onChange={(e) => setCustomRecovery(Number(e.target.value))}
              className="w-14 bg-[#09090b] border border-[#27272a] rounded-[2px] px-1.5 py-0.5 text-[#e4e4e7] text-[10px] font-mono"
            />
          </div>

          <button
            onClick={resetBumps}
            className="px-2 py-1 bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] text-[10px] font-mono rounded-[2px] border border-[#27272a] cursor-pointer transition-colors"
          >
            RESET
          </button>
        </div>
      </div>

      {/* Curve Slope & Shape Tiles */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 font-mono text-[10px]">
        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">1Y–5Y Curve Slope</div>
          <div className={`text-[13px] font-bold mt-0.5 ${Number(slope1Y_5Y) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {Number(slope1Y_5Y) >= 0 ? '+' : ''}{slope1Y_5Y} bp
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Front-end Steepness</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">3Y–5Y Belly Slope</div>
          <div className={`text-[13px] font-bold mt-0.5 ${Number(slope3Y_5Y) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {Number(slope3Y_5Y) >= 0 ? '+' : ''}{slope3Y_5Y} bp
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Belly Inversion Check</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">5Y–10Y Tail Slope</div>
          <div className={`text-[13px] font-bold mt-0.5 ${Number(slope5Y_10Y) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {Number(slope5Y_10Y) >= 0 ? '+' : ''}{slope5Y_10Y} bp
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Long-End Premium</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">2Y-5Y-10Y Butterfly</div>
          <div className="text-[13px] font-bold text-[#f97316] mt-0.5">
            {butterfly2_5_10} bp
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Curvature Dislocation</div>
        </div>
      </div>

      {/* Main Visual Chart */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px]">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#27272a] pb-1.5 mb-2.5">
          <span className="text-[10px] font-mono font-bold text-[#e4e4e7] uppercase tracking-wider">
            {activeCurveTab === 'SPREAD_HAZARD' ? 'CDS PAR SPREAD (BP) & HAZARD RATE λ (%)' : 'SURVIVAL PROBABILITY Q(t) & CUMULATIVE DEFAULT %'}
          </span>

          <div className="flex bg-[#09090b] rounded-[2px] p-0.5 border border-[#27272a] text-[10px] font-mono">
            <button
              onClick={() => setActiveCurveTab('SPREAD_HAZARD')}
              className={`px-2.5 py-0.5 rounded-[2px] cursor-pointer ${activeCurveTab === 'SPREAD_HAZARD' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
            >
              Spread vs Hazard
            </button>
            <button
              onClick={() => setActiveCurveTab('SURVIVAL_DEFAULT')}
              className={`px-2.5 py-0.5 rounded-[2px] cursor-pointer ${activeCurveTab === 'SURVIVAL_DEFAULT' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
            >
              Survival vs Default
            </button>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {activeCurveTab === 'SPREAD_HAZARD' ? (
              <LineChart data={chartData} margin={{ top: 10, right: 25, left: 5, bottom: 5 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#27272a" />
                <XAxis dataKey="tenor" stroke="#71717a" tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }} />
                <YAxis yAxisId="left" stroke="#f97316" tick={{ fill: '#f97316', fontSize: 10, fontFamily: 'monospace' }} unit=" bp" />
                <YAxis yAxisId="right" orientation="right" stroke="#38bdf8" tick={{ fill: '#38bdf8', fontSize: 10, fontFamily: 'monospace' }} unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', color: '#e4e4e7', fontFamily: 'monospace', fontSize: 11 }}
                />
                <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: 10 }} />
                <Line yAxisId="left" type="monotone" dataKey="spreadBps" name="Market Par Spread (bp)" stroke="#f97316" strokeWidth={2} dot={{ r: 3, fill: '#f97316' }} />
                <Line yAxisId="right" type="stepAfter" dataKey="hazardRatePct" name="Hazard Rate λ (%/yr)" stroke="#38bdf8" strokeWidth={1.5} strokeDasharray="3 3" dot={{ r: 3, fill: '#38bdf8' }} />
                <Line yAxisId="right" type="monotone" dataKey="forwardHazardPct" name="Forward Hazard (%)" stroke="#22c55e" strokeWidth={1.2} dot={false} />
              </LineChart>
            ) : (
              <AreaChart data={chartData} margin={{ top: 10, right: 25, left: 5, bottom: 5 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#27272a" />
                <XAxis dataKey="tenor" stroke="#71717a" tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }} />
                <YAxis stroke="#71717a" tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }} unit="%" domain={[0, 100]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', color: '#e4e4e7', fontFamily: 'monospace', fontSize: 11 }}
                />
                <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: 10 }} />
                <Area type="monotone" dataKey="survivalProbPct" name="Survival Prob Q(t) %" stroke="#22c55e" fill="#22c55e" fillOpacity={0.15} strokeWidth={1.5} />
                <Area type="monotone" dataKey="cumDefaultProbPct" name="Cum Default Prob %" stroke="#ef4444" fill="#ef4444" fillOpacity={0.15} strokeWidth={1.5} />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Tenor Diagnostics Table */}
      <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
          <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
            BOOTSTRAPPED NODE PARAMETERS & DIAGNOSTICS
          </span>
          <span className="text-[9px] font-mono text-[#a1a1aa]">
            SOFR OIS DISCOUNT: {(riskFreeRate * 100).toFixed(2)}%
          </span>
        </div>

        <table className="w-full text-[10px] font-mono text-left border-collapse">
          <thead>
            <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
              <th className="py-1.5 px-2.5">Tenor</th>
              <th className="py-1.5 px-2">Year</th>
              <th className="py-1.5 px-2 text-right">Spread</th>
              <th className="py-1.5 px-2 text-right">Hazard Rate (λ)</th>
              <th className="py-1.5 px-2 text-right">Survival Q(t)</th>
              <th className="py-1.5 px-2 text-right">Cum Default</th>
              <th className="py-1.5 px-2 text-right">Marginal</th>
              <th className="py-1.5 px-2 text-right">Discount Z(t)</th>
              <th className="py-1.5 px-2 text-center">Interactive Shock</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f1f23]">
            {calibratedCurve.points.map((pt) => {
              const isBumped = (spreadAdjustments[pt.tenor] || 0) !== 0;
              return (
                <tr key={pt.tenor} className={`hover:bg-white/[0.02] ${isBumped ? 'bg-[#f97316]/5' : ''}`}>
                  <td className="py-1 px-2.5 font-bold text-[#e4e4e7]">{pt.tenor}</td>
                  <td className="py-1 px-2 text-[#71717a]">{pt.yearFrac.toFixed(1)}y</td>
                  <td className="py-1 px-2 text-right font-bold text-[#f97316]">
                    {pt.marketSpread.toFixed(2)} bp
                    {isBumped && (
                      <span className="text-[8px] text-[#f97316] ml-1">
                        ({spreadAdjustments[pt.tenor] > 0 ? '+' : ''}{spreadAdjustments[pt.tenor]}bp)
                      </span>
                    )}
                  </td>
                  <td className="py-1 px-2 text-right text-cyan-400">
                    {(pt.hazardRate * 100).toFixed(3)}%/yr
                  </td>
                  <td className="py-1 px-2 text-right text-emerald-400">
                    {(pt.survivalProb * 100).toFixed(2)}%
                  </td>
                  <td className="py-1 px-2 text-right text-rose-400 font-semibold">
                    {(pt.cumDefaultProb * 100).toFixed(2)}%
                  </td>
                  <td className="py-1 px-2 text-right text-[#a1a1aa]">
                    {(pt.marginalDefaultProb * 100).toFixed(2)}%
                  </td>
                  <td className="py-1 px-2 text-right text-[#71717a]">
                    {pt.discountFactor.toFixed(4)}
                  </td>
                  <td className="py-1 px-2 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => bumpTenor(pt.tenor, -5)}
                        className="px-1 py-0.2 bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] rounded-[2px] border border-[#27272a] text-[9px] cursor-pointer"
                      >
                        -5
                      </button>
                      <button
                        onClick={() => bumpTenor(pt.tenor, 5)}
                        className="px-1 py-0.2 bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] rounded-[2px] border border-[#27272a] text-[9px] cursor-pointer"
                      >
                        +5
                      </button>
                      <button
                        onClick={() => bumpTenor(pt.tenor, 25)}
                        className="px-1.5 py-0.2 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] font-bold rounded-[2px] text-[9px] cursor-pointer"
                      >
                        +25
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Diagnostics Box */}
        <div className="mt-2.5 p-2 bg-[#09090b] rounded-[2px] border border-[#27272a] font-mono text-[10px] space-y-0.5">
          <div className="text-[#a1a1aa] font-bold uppercase text-[9px]">Calibration Provenance:</div>
          {calibratedCurve.diagnostics.map((diag, idx) => (
            <div key={idx} className="text-[#e4e4e7] flex items-center gap-1.5">
              <CheckCircle className="w-3 h-3 text-emerald-400 flex-shrink-0" />
              <span>{diag}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
