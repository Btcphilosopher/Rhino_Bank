/**
 * RHINOQUANT CDS — Risk Management & Jump-to-Default (JTD) Workstation (High Density)
 * CS01 Shock Ladder, Instant Default Impact, Credit VaR, and Counterparty PFE
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
} from 'lucide-react';
import { CDSPosition, PortfolioRiskSummary } from '../types/cds';

interface RiskJTDProps {
  positions: CDSPosition[];
  riskSummary: PortfolioRiskSummary;
}

export const RiskJTDView: React.FC<RiskJTDProps> = ({ positions, riskSummary }) => {
  const [selectedConfidence, setSelectedConfidence] = useState<'95' | '99' | '99.9'>('99');

  // Compute CS01 ladder for portfolio
  const cs01Shocks = [-50, -25, -10, 10, 25, 50, 100, 200];
  const shockLadder = cs01Shocks.map((bps) => {
    const pnlImpact = riskSummary.totalCS01 * bps;
    const additionalMarginRequired = Math.abs(pnlImpact) * 0.35;
    return {
      shockBps: bps,
      pnlImpact,
      additionalMarginRequired,
    };
  });

  // Calculate Jump-To-Default (JTD) exposure table per entity
  const jtdTable = positions.map((p) => {
    return {
      id: p.id,
      ticker: p.ticker,
      buySell: p.buySell,
      notional: p.notional,
      recoveryRate: p.recoveryRate,
      jtdExposure: p.jtd,
      currentMTM: p.mtm,
      netDefaultShock: p.jtd - p.mtm,
      counterparty: p.counterparty,
    };
  }).sort((a, b) => Math.abs(b.jtdExposure) - Math.abs(a.jtdExposure));

  // VaR values based on selected confidence
  const var1D = selectedConfidence === '95'
    ? (riskSummary?.creditVaR95_1D ?? 0)
    : selectedConfidence === '99'
    ? (riskSummary?.creditVaR99_1D ?? 0)
    : (riskSummary?.creditVaR99_1D ?? 0) * 1.35;

  const var10D = var1D * Math.sqrt(10);

  const totalGrossNotional = riskSummary?.totalGrossNotional ?? 0;
  const totalCS01 = riskSummary?.totalCS01 ?? 0;
  const maxNetJTD = riskSummary?.maxNetJTD ?? 0;
  const creditVaR99_1D = riskSummary?.creditVaR99_1D ?? 0;

  // Risk Limits Compliance Check
  const limits = [
    { name: 'Max Gross Portfolio Notional', limit: 250000000, current: totalGrossNotional, unit: '$' },
    { name: 'Max Portfolio CS01 Sensitivity', limit: 50000, current: Math.abs(totalCS01), unit: '$/bp' },
    { name: 'Max Single-Name JTD Exposure', limit: 20000000, current: maxNetJTD, unit: '$' },
    { name: 'Max 1D 99% Credit VaR', limit: 10000000, current: creditVaR99_1D, unit: '$' },
  ];

  return (
    <div id="risk-jtd-view" className="p-3 space-y-2.5 text-[#e4e4e7] bg-[#09090b] min-h-[calc(100vh-76px)]">
      {/* Top Banner & Risk Overview */}
      <div className="bg-[#111114] border border-[#27272a] px-3 py-2 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[2px] bg-[#18181b] border border-[#f97316]/40 flex items-center justify-center text-[#f97316]">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[9px] text-[#a1a1aa] font-mono uppercase tracking-wider">RISK & JUMP-TO-DEFAULT (JTD) ENGINE</div>
            <div className="text-[12px] font-bold text-[#e4e4e7] flex items-center gap-2">
              <span>Non-Linear Credit Sensitivities, VaR & Default Stress</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-emerald-950/80 text-emerald-300 font-mono border border-emerald-500/40">
                LIMITS COMPLIANT
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-[10px]">
          <span className="text-[#a1a1aa] uppercase">VaR CONFIDENCE:</span>
          <div className="flex bg-[#09090b] rounded-[2px] p-0.5 border border-[#27272a]">
            <button
              onClick={() => setSelectedConfidence('95')}
              className={`px-2 py-0.5 rounded-[2px] cursor-pointer ${selectedConfidence === '95' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
            >
              95%
            </button>
            <button
              onClick={() => setSelectedConfidence('99')}
              className={`px-2 py-0.5 rounded-[2px] cursor-pointer ${selectedConfidence === '99' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
            >
              99%
            </button>
            <button
              onClick={() => setSelectedConfidence('99.9')}
              className={`px-2 py-0.5 rounded-[2px] cursor-pointer ${selectedConfidence === '99.9' ? 'bg-[#f97316] text-[#09090b] font-bold' : 'text-[#a1a1aa]'}`}
            >
              99.9%
            </button>
          </div>
        </div>
      </div>

      {/* Primary Risk KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 font-mono text-[10px]">
        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">{selectedConfidence}% 1-Day Credit VaR</div>
          <div className="text-[13px] font-bold text-rose-400 mt-0.5">
            ${var1D.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Parametric Monte Carlo</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">{selectedConfidence}% 10-Day Horizon VaR</div>
          <div className="text-[13px] font-bold text-rose-400 mt-0.5">
            ${var10D.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Basel Capital Metric</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Worst Single JTD Default</div>
          <div className="text-[13px] font-bold text-[#f97316] mt-0.5">
            ${(maxNetJTD / 1e6).toFixed(2)}M
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Boeing (BA 5Y CDS)</div>
        </div>

        <div className="bg-[#111114] p-2.5 rounded-[2px] border border-[#27272a]">
          <div className="text-[9px] text-[#a1a1aa] uppercase">Net Portfolio CS01</div>
          <div className={`text-[13px] font-bold mt-0.5 ${totalCS01 >= 0 ? 'text-emerald-400' : 'text-[#f97316]'}`}>
            ${totalCS01.toLocaleString()}/bp
          </div>
          <div className="text-[8px] text-[#71717a] mt-0.5">Total Spread Beta</div>
        </div>
      </div>

      {/* Two Columns: Jump-to-Default Table (Left) + CS01 Shock Ladder & Limits (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-2.5">
        {/* Left Column: Jump-To-Default (JTD) Matrix */}
        <div className="lg:col-span-7 bg-[#111114] border border-[#27272a] p-3 rounded-[2px] overflow-x-auto">
          <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5 mb-2">
            <span className="text-[10px] font-mono font-bold text-[#f97316] uppercase tracking-wider">
              JUMP-TO-DEFAULT (JTD) EXPOSURE RANKING
            </span>
            <span className="text-[9px] font-mono text-[#a1a1aa]">INSTANT DEFAULT SCENARIO</span>
          </div>

          <table className="w-full text-[10px] font-mono text-left border-collapse">
            <thead>
              <tr className="bg-[#18181b] border-b border-[#27272a] text-[#a1a1aa] uppercase text-[9px]">
                <th className="py-1.5 px-2.5">Reference Name</th>
                <th className="py-1.5 px-2">Side</th>
                <th className="py-1.5 px-2 text-right">Notional</th>
                <th className="py-1.5 px-2 text-right">Recovery</th>
                <th className="py-1.5 px-2.5 text-right bg-[#18181b] text-[#f97316]">JTD Payoff</th>
                <th className="py-1.5 px-2 text-right">Net MTM Δ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1f1f23]">
              {jtdTable.map((item) => (
                <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="py-1 px-2.5">
                    <span className="font-bold text-[#e4e4e7]">{item.ticker}</span>
                    <div className="text-[8px] text-[#71717a]">{item.id}</div>
                  </td>
                  <td className="py-1 px-2">
                    <span className={`px-1.5 py-0.2 rounded-[2px] text-[8px] font-bold ${
                      item.buySell === 'BUY' ? 'bg-orange-950 text-orange-300' : 'bg-cyan-950 text-cyan-300'
                    }`}>
                      {item.buySell}
                    </span>
                  </td>
                  <td className="py-1 px-2 text-right text-[#e4e4e7] font-semibold">
                    ${(item.notional / 1e6).toFixed(1)}M
                  </td>
                  <td className="py-1 px-2 text-right text-[#a1a1aa]">
                    {(item.recoveryRate * 100).toFixed(0)}%
                  </td>
                  <td className="py-1 px-2.5 text-right font-extrabold bg-[#18181b]/30">
                    <span className={item.jtdExposure >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                      {item.jtdExposure >= 0 ? '+' : ''}${(item.jtdExposure / 1e6).toFixed(2)}M
                    </span>
                  </td>
                  <td className={`py-1 px-2 text-right font-semibold ${item.netDefaultShock >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {item.netDefaultShock >= 0 ? '+' : ''}${(item.netDefaultShock / 1e6).toFixed(2)}M
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Right Column: CS01 Shock Ladder & Risk Mandate Compliance */}
        <div className="lg:col-span-5 space-y-2.5">
          {/* CS01 Spread Shock Ladder */}
          <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] font-mono">
            <div className="text-[10px] font-bold text-[#e4e4e7] uppercase mb-1.5">
              Portfolio CS01 Shock Ladder
            </div>
            <table className="w-full text-[10px] text-left">
              <thead>
                <tr className="text-[#a1a1aa] border-b border-[#27272a] text-[9px] uppercase">
                  <th className="py-1">Shock</th>
                  <th className="py-1 text-right">P&L Impact</th>
                  <th className="py-1 text-right">Margin Call Est.</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1f1f23]">
                {shockLadder.map((row) => (
                  <tr key={row.shockBps}>
                    <td className="py-1 font-bold text-[#f97316]">
                      {row.shockBps > 0 ? `+${row.shockBps}` : row.shockBps} bps
                    </td>
                    <td className={`py-1 text-right font-semibold ${(row.pnlImpact ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {(row.pnlImpact ?? 0) >= 0 ? '+' : ''}${(row.pnlImpact ?? 0).toLocaleString()}
                    </td>
                    <td className="py-1 text-right text-[#a1a1aa]">
                      ${(row.additionalMarginRequired ?? 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Risk Limit Governance Checklist */}
          <div className="bg-[#111114] border border-[#27272a] p-3 rounded-[2px] font-mono text-[10px] space-y-2">
            <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5">
              <span className="font-bold text-[#f97316] uppercase text-[9px]">
                RISK MANDATE LIMIT COMPLIANCE
              </span>
              <span className="text-[8px] text-emerald-400">100% PASS</span>
            </div>

            {limits.map((l) => {
              const utilPct = (l.current / l.limit) * 100;
              return (
                <div key={l.name} className="space-y-0.5">
                  <div className="flex justify-between text-[9px]">
                    <span className="text-[#a1a1aa]">{l.name}:</span>
                    <span className="text-[#e4e4e7] font-semibold">
                      {l.unit === '$' ? `$${((l.current ?? 0) / 1e6).toFixed(1)}M / $${((l.limit ?? 1) / 1e6).toFixed(1)}M` : `${(l.current ?? 0).toLocaleString()}${l.unit} / ${(l.limit ?? 1).toLocaleString()}${l.unit}`} ({utilPct.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="w-full bg-[#18181b] h-1 rounded-[1px] overflow-hidden border border-[#27272a]">
                    <div
                      className={`h-full rounded-[1px] ${utilPct > 90 ? 'bg-rose-500' : utilPct > 70 ? 'bg-[#f97316]' : 'bg-emerald-500'}`}
                      style={{ width: `${Math.min(100, utilPct)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
