/**
 * RHINOQUANT CDS — High Density Institutional Header & Telemetry Bar
 */

import React from 'react';
import {
  Activity,
  Bot,
  Zap,
  Play,
  Pause,
  AlertTriangle,
  Radio,
  Cpu,
} from 'lucide-react';
import { UserRole } from '../types/cds';

interface HeaderProps {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  isSimulating: boolean;
  setIsSimulating: (val: boolean) => void;
  onOpenAIAnalyst: () => void;
  onOpenNewOrder: () => void;
  portfolioGrossNotional: number;
  portfolioCS01: number;
  totalPnl: number;
  onTriggerMarketShock: () => void;
  activeTab: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  setCurrentRole,
  isSimulating,
  setIsSimulating,
  onOpenAIAnalyst,
  onOpenNewOrder,
  portfolioGrossNotional,
  portfolioCS01,
  totalPnl,
  onTriggerMarketShock,
}) => {
  return (
    <header id="rhinoquant-header" className="bg-[#09090b] border-b border-[#27272a] text-[#e4e4e7] select-none text-[11px]">
      {/* Top High-Density Header */}
      <div className="px-3 py-1.5 flex items-center justify-between gap-3 h-[42px]">
        {/* Brand & Platform Identity */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 font-black tracking-tight text-[13px] text-[#f97316]">
            <div className="w-5 h-5 rounded-[2px] bg-[#f97316] text-[#09090b] flex items-center justify-center font-black text-[10px] tracking-tighter">
              RQ
            </div>
            <span>RHINO<span className="text-[#e4e4e7]">QUANT</span></span>
            <span className="text-[11px] font-normal text-[#a1a1aa] tracking-normal">CDS</span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 ml-1">
            <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 font-mono font-medium">
              ISDA 2014
            </span>
            <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-[#18181b] border border-[#27272a] text-[#a1a1aa] font-mono hidden md:inline">
              RUST_ENGINE::OK
            </span>
            <span className="text-[9px] px-1.5 py-0.2 rounded-[2px] bg-[#18181b] border border-[#27272a] text-[#a1a1aa] font-mono hidden xl:inline">
              LATENCY: 0.18ms
            </span>
          </div>
        </div>

        {/* Live Market Benchmark Strip */}
        <div className="hidden lg:flex items-center gap-4 px-2.5 py-1 bg-[#111114] rounded-[2px] border border-[#27272a] text-[10px] font-mono">
          <div className="flex items-center gap-1.5">
            <span className="text-[#a1a1aa]">CDX.NA.IG 5Y:</span>
            <span className="text-[#e4e4e7] font-semibold">60.25 bp</span>
            <span className="text-emerald-400 text-[9px]">+0.75</span>
          </div>
          <div className="w-px h-2.5 bg-[#27272a]"></div>
          <div className="flex items-center gap-1.5">
            <span className="text-[#a1a1aa]">CDX.NA.HY 5Y:</span>
            <span className="text-[#e4e4e7] font-semibold">401.0 bp</span>
            <span className="text-rose-400 text-[9px]">+4.25</span>
          </div>
          <div className="w-px h-2.5 bg-[#27272a]"></div>
          <div className="flex items-center gap-1.5">
            <span className="text-[#a1a1aa]">iTraxx EUR 5Y:</span>
            <span className="text-[#e4e4e7] font-semibold">58.40 bp</span>
            <span className="text-emerald-400 text-[9px]">-0.60</span>
          </div>
          <div className="w-px h-2.5 bg-[#27272a]"></div>
          <div className="flex items-center gap-1.5">
            <span className="text-[#a1a1aa]">SOFR 10Y:</span>
            <span className="text-[#e4e4e7] font-semibold">3.78%</span>
          </div>
        </div>

        {/* Portfolio Live KPI Strip */}
        <div className="flex items-center gap-3 text-[11px] font-mono">
          <div className="hidden sm:block text-right">
            <div className="text-[9px] text-[#a1a1aa] uppercase tracking-wider">CS01</div>
            <div className={`font-semibold ${(portfolioCS01 ?? 0) >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
              ${(portfolioCS01 ?? 0).toLocaleString()}/bp
            </div>
          </div>
          <div className="hidden sm:block text-right">
            <div className="text-[9px] text-[#a1a1aa] uppercase tracking-wider">Gross Notional</div>
            <div className="text-[#e4e4e7] font-semibold">
              ${((portfolioGrossNotional ?? 0) / 1e6).toFixed(1)}M
            </div>
          </div>
          <div className="text-right">
            <div className="text-[9px] text-[#a1a1aa] uppercase tracking-wider">MTM P&L</div>
            <div className={`font-semibold ${(totalPnl ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {(totalPnl ?? 0) >= 0 ? '+' : ''}${(totalPnl ?? 0).toLocaleString()}
            </div>
          </div>
        </div>

        {/* Action Controls & Fast Triggers */}
        <div className="flex items-center gap-1.5">
          {/* Order Ticket Quick Action */}
          <button
            id="header-quick-order-btn"
            onClick={onOpenNewOrder}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#f97316] hover:bg-[#ea580c] text-[#09090b] text-[10px] font-bold tracking-wider rounded-[2px] shadow-sm transition-colors cursor-pointer uppercase"
          >
            <Zap className="w-3 h-3 text-[#09090b] stroke-[2.5]" />
            <span>TRADE</span>
          </button>

          {/* AI Credit Analyst Co-Pilot */}
          <button
            id="header-ai-analyst-btn"
            onClick={onOpenAIAnalyst}
            className="flex items-center gap-1 px-2 py-1 bg-[#18181b] hover:bg-[#27272a] border border-[#f97316]/40 text-[#f97316] text-[10px] font-semibold tracking-wider rounded-[2px] transition-colors cursor-pointer uppercase"
            title="Ask Gemini 3.7 AI Credit Analyst"
          >
            <Bot className="w-3 h-3 text-[#f97316]" />
            <span className="hidden md:inline">AI COPILOT</span>
          </button>

          {/* Market Simulation Feed */}
          <button
            id="header-sim-toggle-btn"
            onClick={() => setIsSimulating(!isSimulating)}
            className={`flex items-center gap-1 px-2 py-1 text-[10px] font-mono rounded-[2px] border transition-colors cursor-pointer ${
              isSimulating
                ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-300'
                : 'bg-[#18181b] border-[#27272a] text-[#a1a1aa]'
            }`}
            title="Toggle Live Market Quotes Simulation Feed"
          >
            {isSimulating ? <Pause className="w-2.5 h-2.5 text-emerald-400" /> : <Play className="w-2.5 h-2.5" />}
            <span className="hidden xl:inline">{isSimulating ? 'FEED: ON' : 'FEED: OFF'}</span>
          </button>

          {/* Market Shock Trigger */}
          <button
            id="header-shock-btn"
            onClick={onTriggerMarketShock}
            className="px-2 py-1 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-600/40 text-rose-300 text-[10px] font-mono rounded-[2px] transition-colors cursor-pointer flex items-center gap-1"
            title="Inject Market-Wide +25bp Credit Shock"
          >
            <AlertTriangle className="w-2.5 h-2.5 text-rose-400" />
            <span className="hidden 2xl:inline">+25bp SHOCK</span>
          </button>

          {/* RBAC Role Selector */}
          <div className="flex items-center gap-1 bg-[#111114] border border-[#27272a] rounded-[2px] px-1.5 py-0.5">
            <span className="text-[9px] text-[#a1a1aa] font-mono uppercase">ROLE:</span>
            <select
              id="header-role-selector"
              value={currentRole}
              onChange={(e) => setCurrentRole(e.target.value as UserRole)}
              className="bg-transparent text-[#f97316] text-[10px] font-mono font-semibold focus:outline-none cursor-pointer"
            >
              <option value="Trader" className="bg-[#111114] text-[#e4e4e7]">Trader</option>
              <option value="Quant" className="bg-[#111114] text-[#e4e4e7]">Quant</option>
              <option value="Risk Manager" className="bg-[#111114] text-[#e4e4e7]">Risk Manager</option>
              <option value="Portfolio Manager" className="bg-[#111114] text-[#e4e4e7]">Portfolio Mgr</option>
              <option value="Operations" className="bg-[#111114] text-[#e4e4e7]">Operations</option>
              <option value="Compliance" className="bg-[#111114] text-[#e4e4e7]">Compliance</option>
              <option value="Administrator" className="bg-[#111114] text-[#e4e4e7]">Admin</option>
              <option value="Read Only" className="bg-[#111114] text-[#e4e4e7]">Read Only</option>
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};
