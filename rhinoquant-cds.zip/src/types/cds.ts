/**
 * RHINOQUANT CDS — Core Types & Institutional Data Model
 */

export type Seniority = 'SNR_UNSEC' | 'SUB' | 'TIER_1' | 'TIER_2' | 'JUNIOR';
export type RestructuringClause = 'CR14' | 'MR14' | 'MM14' | 'XR14' | 'CR' | 'MR' | 'MM' | 'XR'; // ISDA 2014 / 2003
export type Sector = 'Financials' | 'Technology' | 'Energy' | 'Industrials' | 'Healthcare' | 'Consumer' | 'Sovereign' | 'Telecommunications' | 'Utilities';
export type Rating = 'AAA' | 'AA+' | 'AA' | 'AA-' | 'A+' | 'A' | 'A-' | 'BBB+' | 'BBB' | 'BBB-' | 'BB+' | 'BB' | 'BB-' | 'B+' | 'B' | 'B-' | 'CCC' | 'D';
export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY';
export type Tenor = '6M' | '1Y' | '2Y' | '3Y' | '4Y' | '5Y' | '7Y' | '10Y' | '15Y' | '20Y' | '30Y';
export type BuySell = 'BUY' | 'SELL'; // BUY = Long Protection (Pay Spread, Receive Default), SELL = Short Protection
export type OrderStatus = 'NEW' | 'PENDING_APPROVAL' | 'WORKING' | 'FILLED' | 'REJECTED' | 'CANCELLED';
export type OrderType = 'LIMIT_SPREAD' | 'MARKET' | 'UPFRONT_LIMIT';
export type TradeVenue = 'TRADEWEB' | 'MARKETAXESS' | 'ICE_LINK' | 'BLOOMBERG_FIT' | 'BILATERAL_VOICE';
export type TradeStatus = 'CONFIRMED' | 'SETTLED' | 'TERMINATED' | 'DEFAULTED';
export type UserRole = 'Trader' | 'Quant' | 'Risk Manager' | 'Portfolio Manager' | 'Operations' | 'Compliance' | 'Administrator' | 'Read Only';

export interface ReferenceEntity {
  id: string;
  name: string;
  ticker: string;
  redCode: string; // ISDA RED code
  country: string;
  region: 'North America' | 'Europe' | 'Asia-Pac' | 'Latin America' | 'Emerging Markets';
  sector: Sector;
  rating: Rating;
  defaultProbability1Y: number; // in %
  defaultProbability5Y: number; // in %
  standardRecovery: number; // e.g. 0.40 (40%)
  seniority: Seniority;
  restructuringClause: RestructuringClause;
  currency: Currency;
  contractType?: 'SINGLE_NAME' | 'INDEX';
  isIndexConstituent?: boolean;
  indexName?: string;
}

export interface CDSSpreadQuote {
  entityId: string;
  entityName: string;
  ticker: string;
  sector: Sector;
  rating: Rating;
  currency: Currency;
  tenors: Record<Tenor, {
    bid: number; // in bps
    ask: number; // in bps
    mid: number; // in bps
  }>;
  change1D: number; // 5Y change in bps
  change1W: number;
  change1M: number;
  percentile1Y: number; // 0 - 100%
  zScore1Y: number;
  volatility30D: number; // in bps / ann
  liquidityScore: 'HIGH' | 'MEDIUM' | 'LOW';
  volume24h: number; // in Millions USD
  lastUpdated: string;
}

export interface CDSCurvePoint {
  tenor: Tenor;
  yearFrac: number;
  marketSpread: number; // in bps
  hazardRate: number; // lambda_i (instantaneous hazard rate)
  survivalProb: number; // Q(t)
  cumDefaultProb: number; // 1 - Q(t)
  marginalDefaultProb: number;
  forwardHazardRate: number;
  discountFactor: number; // Z(t)
}

export interface CDSCurve {
  entityId: string;
  entityName: string;
  calibrationDate: string;
  modelType: 'PIECEWISE_CONSTANT_HAZARD' | 'PIECEWISE_LINEAR_HAZARD';
  recoveryRate: number; // e.g. 0.40
  points: CDSCurvePoint[];
  calibrationStatus: 'VALID' | 'WARNING_NEGATIVE_HAZARD' | 'WARNING_INVERTED' | 'FAILED';
  diagnostics: string[];
}

export interface CDSValuationParams {
  notional: number;
  tradeSpread: number; // Running coupon (e.g. 100bp or 500bp or custom)
  marketSpread: number; // Quoted par spread
  tenorYears: number; // e.g. 5
  recoveryRate: number; // e.g. 0.40
  riskFreeRate: number; // e.g. 0.042 (4.2%)
  buySell: BuySell;
  daysSinceLastCoupon?: number;
  isdaModel?: 'STANDARD_2014' | 'STANDARD_2003';
}

export interface CDSValuationResult {
  premiumLegPV: number; // Present value of premium payments
  protectionLegPV: number; // Present value of contingent default protection
  accruedPremium: number;
  upfrontCash: number; // Upfront payment (buyer pays if positive, seller receives)
  cleanValue: number; // Upfront without accrued
  dirtyValue: number; // Clean value + accrued
  fairParSpread: number; // Fair break-even spread (bps)
  riskyPV01: number; // Risky annuity (dollar PV of 1bp coupon per notional)
  cs01: number; // Dollar P&L for +1bp market spread widening
  dv01: number; // Dollar P&L for +1bp IR shift
  rec01: number; // Dollar P&L for +1% recovery change
  gammaSpread: number; // Convexity
  expectedLoss: number;
  jumpToDefault: number; // JTD P&L in case of immediate default
  survivalProbability: number;
  cumulativeDefaultProbability: number;
}

export interface CDSPosition {
  id: string;
  contractId?: string;
  entityId: string;
  entityName: string;
  ticker: string;
  contractType?: 'SINGLE_NAME' | 'INDEX';
  sector?: Sector;
  rating?: Rating;
  currency?: Currency;
  tenor: Tenor;
  buySell: BuySell;
  notional: number;
  coupon: number; // Running coupon (bps)
  tradeSpread?: number;
  marketSpread: number; // Current 5Y mid (bps)
  entrySpread?: number; // Executed spread (bps)
  entryDate?: string;
  maturityDate: string;
  recoveryRate: number;
  counterpartyId?: string;
  counterparty?: string;
  counterpartyName?: string;
  clearingHouse?: string;
  cleanValue?: number;
  dirtyValue?: number;
  mtm: number; // Clean MTM in USD
  accrued?: number;
  accruedPremium?: number;
  totalPnl?: number;
  dailyPnl?: number;
  cs01: number; // in USD
  dv01: number;
  jtd: number; // Jump to default P&L
  expectedLoss?: number;
  defaultProbability5Y?: number;
}

export interface CashBond {
  id: string;
  issuerId?: string;
  issuerName?: string;
  entityId?: string;
  entityName?: string;
  ticker: string;
  cusip?: string;
  isin?: string;
  seniority?: Seniority;
  couponRate: number; // %
  maturityDate: string;
  tenorYears?: number;
  price: number; // e.g. 96.50
  ytm?: number; // % e.g. 0.056
  yieldToMaturity?: number; // %
  benchmarkYield?: number; // %
  zSpread: number; // in bps
  aswSpread: number; // in bps
  matchingCDSSpread: number; // in bps
  basis: number; // CDS Spread - Bond Z-Spread (bps)
  basisZScore: number;
  basisPercentile?: number;
  rating?: Rating;
}

export type BondInstrument = CashBond;

export interface Counterparty {
  id: string;
  name: string;
  redCode: string;
  creditRating: Rating;
  grossExposure: number; // USD
  netExposure: number; // USD after netting
  pfe95: number; // Potential Future Exposure 95%
  collateralPosted: number; // USD
  collateralHeld: number; // USD
  netCollateral: number;
  variationMarginThreshold: number;
  initialMarginHeld: number;
  creditLimit: number; // USD
  utilizationPct: number; // %
  tradeCount: number;
  status: 'COMPLIANT' | 'WARNING' | 'BREACH';
}

export interface PortfolioRiskSummary {
  totalGrossNotional: number;
  totalNetNotional: number;
  totalCS01: number;
  totalDV01: number;
  totalMTM: number;
  maxNetJTD: number;
  expectedLoss1Y: number;
  creditVaR95_1D: number;
  creditVaR99_1D: number;
  sectorConcentration: Record<string, number>;
  ratingConcentration: Record<string, number>;
  counterpartyExposure: Record<string, number>;
  grossNotional?: number;
  netNotional?: number;
  totalMtm?: number;
  totalAccrued?: number;
  totalPnl?: number;
  dailyPnl?: number;
  totalJTD?: number;
  totalExpectedLoss?: number;
  spreadDuration?: number;
  creditVaR95?: number;
  creditVaR99?: number;
  creditVaR99_9?: number;
  cs01BySector?: Record<Sector, number>;
  cs01ByTenor?: Record<Tenor, number>;
  notionalByRating?: Record<string, number>;
  notionalByCounterparty?: Record<string, number>;
  jtdByIssuer?: { entityName: string; notional: number; buySell: string; recovery: number; jtd: number }[];
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  category?: 'MARKET_WIDE' | 'CRISIS' | 'SECTOR' | 'DEFAULT' | 'CUSTOM' | string;
  spreadShiftBps?: number;
  sectorShifts?: Partial<Record<Sector, number>>;
  ratingShifts?: Partial<Record<Rating, number>>;
  recoveryShift?: number;
  ratesShift?: number;
  spreadShocks?: Partial<Record<Sector | 'ALL', number>>;
  ratingShocks?: Partial<Record<Rating, number>>;
  defaultEntities?: string[];
  interestRateShockBps?: number;
  recoveryShockPct?: number;
}

export interface StressScenarioResult {
  scenarioId: string;
  scenarioName: string;
  baseMTM: number;
  stressedMTM: number;
  pnlImpact: number;
  marginCallRequired: number;
  stressedCS01: number;
  positionImpacts: {
    positionId: string;
    ticker: string;
    buySell: BuySell;
    notional: number;
    baseSpread: number;
    stressedSpread: number;
    baseMTM: number;
    stressedMTM: number;
    pnlDelta: number;
  }[];
}

export interface ScenarioResult {
  scenarioId: string;
  scenarioName: string;
  portfolioPnl: number;
  cs01Impact: number;
  marginRequirementDelta: number;
  pnlBySector: Record<string, number>;
  pnlByEntity: { entityName: string; pnl: number; notional: number; shockBps: number }[];
  defaultLosses: number;
  worstHitEntity: string;
  topGainerEntity: string;
}

export interface OrderTicket {
  id?: string;
  entityId: string;
  entityName: string;
  ticker: string;
  buySell: BuySell;
  notional: number;
  tenor: Tenor;
  coupon: number; // 100 or 500 bps
  limitSpread?: number;
  quotedSpread: number;
  upfrontAmount?: number;
  counterpartyId: string;
  seniority: Seniority;
  restructuringClause: RestructuringClause;
  currency: Currency;
  recoveryRate: number;
  status?: OrderStatus;
  notes?: string;
}

export interface TradeRecord {
  tradeId: string;
  orderId: string;
  timestamp: string;
  entityId: string;
  entityName: string;
  ticker: string;
  buySell: BuySell;
  notional: number;
  tenor: Tenor;
  executedSpread: number;
  coupon: number;
  upfrontSettlement: number;
  counterparty: string;
  trader: string;
  status: TradeStatus;
  pvAtExecution: number;
  cs01: number;
}

export interface TradeOrder {
  id: string;
  timestamp: string;
  ticker: string;
  entityName: string;
  contractType: 'SINGLE_NAME' | 'INDEX';
  tenor: Tenor;
  buySell: BuySell;
  notional: number;
  coupon: number;
  orderType: OrderType;
  limitSpread: number;
  executedSpread?: number;
  venue: TradeVenue;
  counterparty: string;
  clearingBroker?: string;
  status: OrderStatus;
}

export interface TradeIdea {
  id: string;
  strategyType?: string;
  title: string;
  type?: 'RELATIVE_VALUE_BASIS' | 'CURVE_STEEPENER' | 'CURVE_FLATTENER' | 'SPREAD_DISPERSION' | 'RATING_DISLOCATION' | 'CREDIT_DEFAULT_ASYMMETRY' | string;
  entityName?: string;
  ticker?: string;
  confidence?: 'HIGH' | 'MEDIUM' | 'OPPORTUNISTIC' | string;
  recommendedAction?: string;
  basisOrSpreadVal?: number;
  historicalZScore?: number;
  expectedAlphaBps?: number;
  expectedReturnBps?: number;
  netCarryBps?: number;
  timeHorizon?: string;
  maxDrawdownBps?: number;
  rationale: string;
  quantitativeEvidence?: string[];
  suggestedTenor?: Tenor;
  riskRewardRatio?: number;
  legs?: {
    entityId: string;
    buySell: BuySell;
    tenor: Tenor;
    notional: number;
  }[];
}

export interface PnLAttribution {
  totalPnl: number;
  spreadMovementPnl?: number;
  spreadDeltaPnl?: number;
  curveShapePnl: number;
  carryPnl?: number;
  rollDownPnl?: number;
  carryRolldownPnl?: number;
  interestRateDv01Pnl?: number;
  defaultPnl: number;
  defaultEventPnl?: number;
  recoveryChangePnl?: number;
  fxPnl?: number;
  financingCost?: number;
  executionSlippageFees?: number;
  history?: { date: string; cumulativePnl: number; dailyPnl: number; spreadComponent: number; carryComponent: number }[];
}

export interface AuditRecord {
  id: string;
  timestamp: string;
  userId: string;
  userRole: UserRole;
  actionType: 'CALCULATION' | 'TRADE_EXECUTION' | 'MODEL_CALIBRATION' | 'RISK_OVERRIDE' | 'SCENARIO_RUN' | 'LIMIT_BREACH';
  details: string;
  modelVersion: string;
  inputsDigest: string;
  outputsDigest: string;
  status: 'SUCCESS' | 'WARNING' | 'REJECTED';
}

export interface ModelGovernanceItem {
  id: string;
  modelName: string;
  modelIdentifier: string;
  version: string;
  lastCalibrated: string;
  methodology: string;
  assumptions: string[];
  validationStatus: 'VALIDATED_PRODUCTION' | 'PENDING_ANNUAL_REVIEW' | 'RESEARCH_BETA';
  owner: string;
  changeLog: { date: string; description: string; author: string }[];
}

export interface PreTradeRiskCheck {
  passed: boolean;
  violations: { rule: string; limit: string; proposed: string; severity: 'ERROR' | 'WARNING' }[];
  maxSingleNameNotionalLimit: number;
  maxCounterpartyExposureLimit: number;
  maxPortfolioCS01Limit: number;
  maxPortfolioJTDLimit: number;
}
