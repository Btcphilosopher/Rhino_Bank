/**
 * RHINOQUANT CDS — INSTITUTIONAL CREDIT DERIVATIVES PLATFORM
 * Master Application Shell & State Engine
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Header } from './components/Header';
import { Navigation, MainTab } from './components/Navigation';
import { MarketsView } from './components/MarketsView';
import { PricingCalculatorView } from './components/PricingCalculatorView';
import { CurvesHazardView } from './components/CurvesHazardView';
import { DefaultProbView } from './components/DefaultProbView';
import { BasisView } from './components/BasisView';
import { PortfolioView } from './components/PortfolioView';
import { RiskJTDView } from './components/RiskJTDView';
import { ScenariosView } from './components/ScenariosView';
import { TradingBlotterView } from './components/TradingBlotterView';
import { ResearchScreenerView } from './components/ResearchScreenerView';
import { ReportsAuditView } from './components/ReportsAuditView';
import { AICreditAnalystModal } from './components/AICreditAnalystModal';
import { OrderTicketModal } from './components/OrderTicketModal';

import {
  ReferenceEntity,
  CDSSpreadQuote,
  CashBond,
  CDSPosition,
  TradeOrder,
  UserRole,
  BuySell,
  Tenor,
  TradeIdea,
  PnLAttribution,
  PortfolioRiskSummary
} from './types/cds';

import {
  INITIAL_ENTITIES,
  INITIAL_QUOTES,
  INITIAL_BONDS,
  INITIAL_POSITIONS,
  INITIAL_ORDERS
} from './data/marketData';

import { calculatePortfolioRisk, priceCDS, TENOR_YEARS_MAP } from './lib/quantEngine';

export function App() {
  // Navigation & Role State
  const [activeTab, setActiveTab] = useState<MainTab>('MARKETS');
  const [currentRole, setCurrentRole] = useState<UserRole>('Quant');
  const [isSimulating, setIsSimulating] = useState<boolean>(true);

  // Core Data Stores
  const [entities] = useState<ReferenceEntity[]>(INITIAL_ENTITIES);
  const [quotes, setQuotes] = useState<Record<string, CDSSpreadQuote>>(INITIAL_QUOTES);
  const [bonds, setBonds] = useState<CashBond[]>(INITIAL_BONDS);
  const [positions, setPositions] = useState<CDSPosition[]>(INITIAL_POSITIONS);
  const [orders, setOrders] = useState<TradeOrder[]>(INITIAL_ORDERS);

  // Selected Reference Entity for Focused Views (Pricing & Curves)
  const [selectedEntityId, setSelectedEntityId] = useState<string>('ENT_BA');

  // Modals
  const [isAIAnalystOpen, setIsAIAnalystOpen] = useState<boolean>(false);
  const [isOrderTicketOpen, setIsOrderTicketOpen] = useState<boolean>(false);
  const [orderInitialParams, setOrderInitialParams] = useState<{
    entityId?: string;
    notional?: number;
    tenor?: Tenor;
    coupon?: number;
    buySell?: BuySell;
    spread?: number;
  }>({});

  // Dynamic Portfolio Risk Calculation
  const portfolioRisk: PortfolioRiskSummary = useMemo(() => {
    return calculatePortfolioRisk(positions);
  }, [positions]);

  // P&L Attribution Breakdown
  const pnlAttribution: PnLAttribution = useMemo(() => {
    return {
      carryRolldownPnl: 342000,
      spreadDeltaPnl: portfolioRisk.totalMTM - 342000 - 145000 + 48000,
      curveShapePnl: 145000,
      defaultPnl: 0,
      financingCost: -48000,
      totalPnl: portfolioRisk.totalMTM,
    };
  }, [portfolioRisk.totalMTM]);

  // Live Market Quotes Simulator Loop (ticks spreads randomly by ±0.25 to ±0.75 bps)
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setQuotes((prevQuotes) => {
        const nextQuotes = { ...prevQuotes };
        // Tick 2-3 random entities
        const keys = Object.keys(nextQuotes);
        for (let i = 0; i < 2; i++) {
          const randomKey = keys[Math.floor(Math.random() * keys.length)];
          const current = nextQuotes[randomKey];
          if (!current) continue;

          const delta = (Math.random() - 0.49) * 0.8; // small spread wiggle
          const new5YMid = Math.max(5, current.tenors['5Y'].mid + delta);

          nextQuotes[randomKey] = {
            ...current,
            tenors: {
              ...current.tenors,
              '5Y': {
                ...current.tenors['5Y'],
                mid: Number(new5YMid.toFixed(2)),
                bid: Number((new5YMid - 1.5).toFixed(2)),
                ask: Number((new5YMid + 1.5).toFixed(2)),
              },
            },
            change1D: Number((current.change1D + delta).toFixed(2)),
          };
        }
        return nextQuotes;
      });
    }, 3500);

    return () => clearInterval(interval);
  }, [isSimulating]);

  // Market Shock Injection Action (+25bp across all entities)
  const handleTriggerMarketShock = () => {
    setQuotes((prev) => {
      const shocked = { ...prev };
      Object.keys(shocked).forEach((key) => {
        const q = shocked[key];
        const bumped5Y = q.tenors['5Y'].mid + 25.0;
        shocked[key] = {
          ...q,
          tenors: {
            ...q.tenors,
            '5Y': {
              ...q.tenors['5Y'],
              mid: Number(bumped5Y.toFixed(2)),
              bid: Number((bumped5Y - 1.5).toFixed(2)),
              ask: Number((bumped5Y + 1.5).toFixed(2)),
            },
          },
          change1D: Number((q.change1D + 25.0).toFixed(2)),
        };
      });
      return shocked;
    });

    // Update positions MTM under shock
    setPositions((prev) =>
      prev.map((pos) => {
        const newSpread = pos.marketSpread + 25.0;
        const res = priceCDS({
          notional: pos.notional,
          tradeSpread: pos.coupon,
          marketSpread: newSpread,
          tenorYears: TENOR_YEARS_MAP[pos.tenor],
          recoveryRate: pos.recoveryRate,
          riskFreeRate: 0.042,
          buySell: pos.buySell,
        });
        return {
          ...pos,
          marketSpread: newSpread,
          mtm: res.cleanValue,
          cs01: res.cs01,
        };
      })
    );
  };

  // Handlers for cross-view navigation
  const handleSelectEntityForPricing = (entityId: string) => {
    setSelectedEntityId(entityId);
    setActiveTab('PRICING');
  };

  const handleOpenCurve = (entityId: string) => {
    setSelectedEntityId(entityId);
    setActiveTab('CURVES');
  };

  const handleSelectEntityForTrade = (entityId: string, buySell: BuySell = 'BUY') => {
    const ent = entities.find((e) => e.id === entityId);
    const q = quotes[entityId] || Object.values(quotes)[0];
    setOrderInitialParams({
      entityId,
      buySell,
      notional: 10000000,
      tenor: '5Y',
      coupon: 100,
      spread: q?.tenors['5Y']?.mid || 100,
    });
    setIsOrderTicketOpen(true);
  };

  const handleLaunchOrderFromPricing = (params: {
    entityId: string;
    notional: number;
    tenor: Tenor;
    coupon: number;
    buySell: BuySell;
    spread: number;
  }) => {
    setOrderInitialParams(params);
    setIsOrderTicketOpen(true);
  };

  // Submit Order into Blotter & Create New Portfolio Position
  const handleSubmitOrder = (orderData: Partial<TradeOrder>) => {
    const newOrderId = `ORD_${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder: TradeOrder = {
      id: newOrderId,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
      ticker: orderData.ticker || 'BA',
      entityName: orderData.entityName || 'The Boeing Company',
      contractType: orderData.contractType || 'SINGLE_NAME',
      tenor: orderData.tenor || '5Y',
      buySell: orderData.buySell || 'BUY',
      notional: orderData.notional || 10000000,
      coupon: orderData.coupon || 100,
      orderType: orderData.orderType || 'LIMIT_SPREAD',
      limitSpread: orderData.limitSpread || 145.0,
      executedSpread: orderData.limitSpread || 145.0,
      status: 'FILLED',
      venue: orderData.venue || 'TRADEWEB',
      counterparty: orderData.counterparty || 'JPMorgan Chase',
      clearingBroker: 'ICE Clear Credit',
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Add executed position to active positions
    const valuation = priceCDS({
      notional: newOrder.notional,
      tradeSpread: newOrder.coupon,
      marketSpread: newOrder.executedSpread || newOrder.limitSpread,
      tenorYears: TENOR_YEARS_MAP[newOrder.tenor],
      recoveryRate: 0.40,
      riskFreeRate: 0.042,
      buySell: newOrder.buySell,
    });

    const newPosition: CDSPosition = {
      id: `POS_${Math.floor(100 + Math.random() * 900)}`,
      entityId: orderData.ticker ? `ENT_${orderData.ticker}` : 'ENT_CUSTOM',
      ticker: newOrder.ticker,
      entityName: newOrder.entityName,
      contractType: newOrder.contractType,
      tenor: newOrder.tenor,
      maturityDate: '2031-06-20',
      buySell: newOrder.buySell,
      notional: newOrder.notional,
      coupon: newOrder.coupon,
      tradeSpread: newOrder.executedSpread || newOrder.limitSpread,
      marketSpread: newOrder.executedSpread || newOrder.limitSpread,
      recoveryRate: 0.40,
      cleanValue: valuation.cleanValue,
      dirtyValue: valuation.dirtyValue,
      mtm: valuation.cleanValue,
      accruedPremium: valuation.accruedPremium,
      cs01: valuation.cs01,
      dv01: valuation.dv01,
      jtd: valuation.jumpToDefault,
      counterparty: newOrder.counterparty,
      clearingHouse: 'ICE Clear Credit',
    };

    setPositions((prev) => [newPosition, ...prev]);
  };

  // Unwind Position
  const handleUnwindPosition = (positionId: string) => {
    setPositions((prev) => prev.filter((p) => p.id !== positionId));
  };

  // Execute 2-Leg Basis Trade Package
  const handleExecuteBasisTrade = (bond: CashBond, tradeType: 'NEGATIVE_BASIS' | 'POSITIVE_BASIS') => {
    // 1. Buy/Sell CDS leg
    handleSubmitOrder({
      ticker: bond.ticker,
      entityName: bond.entityName,
      contractType: 'SINGLE_NAME',
      tenor: '5Y',
      buySell: tradeType === 'NEGATIVE_BASIS' ? 'BUY' : 'SELL',
      notional: 10000000,
      coupon: 100,
      limitSpread: bond.matchingCDSSpread,
      venue: 'TRADEWEB',
      counterparty: 'Goldman Sachs',
    });

    setActiveTab('PORTFOLIO');
  };

  // Execute Systematic Trade Idea
  const handleExecuteTradeIdea = (idea: TradeIdea) => {
    setOrderInitialParams({
      entityId: idea.legs[0]?.entityId || 'ENT_BA',
      buySell: idea.legs[0]?.buySell || 'BUY',
      notional: idea.legs[0]?.notional || 10000000,
      tenor: idea.legs[0]?.tenor || '5Y',
      coupon: 100,
      spread: 145,
    });
    setIsOrderTicketOpen(true);
  };

  return (
    <div id="rhinoquant-cds-app" className="min-h-screen bg-[#070a0f] text-slate-100 flex flex-col antialiased selection:bg-amber-500 selection:text-slate-950 font-sans">
      {/* Top Header */}
      <Header
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        isSimulating={isSimulating}
        setIsSimulating={setIsSimulating}
        onOpenAIAnalyst={() => setIsAIAnalystOpen(true)}
        onOpenNewOrder={() => {
          setOrderInitialParams({});
          setIsOrderTicketOpen(true);
        }}
        portfolioGrossNotional={portfolioRisk.totalGrossNotional}
        portfolioCS01={portfolioRisk.totalCS01}
        totalPnl={portfolioRisk.totalMTM}
        onTriggerMarketShock={handleTriggerMarketShock}
        activeTab={activeTab}
      />

      {/* Main Navigation Tabs */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openOrdersCount={orders.filter((o) => o.status === 'NEW').length}
      />

      {/* Main Active View */}
      <main className="flex-1 overflow-y-auto">
        {activeTab === 'MARKETS' && (
          <MarketsView
            quotes={quotes}
            entities={entities}
            onSelectEntityForPricing={handleSelectEntityForPricing}
            onSelectEntityForTrade={handleSelectEntityForTrade}
            onOpenCurve={handleOpenCurve}
          />
        )}

        {activeTab === 'PRICING' && (
          <PricingCalculatorView
            entities={entities}
            selectedEntityId={selectedEntityId}
            onSelectEntity={setSelectedEntityId}
            onLaunchOrder={handleLaunchOrderFromPricing}
          />
        )}

        {activeTab === 'CURVES' && (
          <CurvesHazardView
            entities={entities}
            quotes={quotes}
            selectedEntityId={selectedEntityId}
            onSelectEntity={setSelectedEntityId}
          />
        )}

        {activeTab === 'DEFAULT_PROB' && (
          <DefaultProbView
            entities={entities}
            quotes={quotes}
          />
        )}

        {activeTab === 'BASIS' && (
          <BasisView
            bonds={bonds}
            quotes={quotes}
            onExecuteBasisTrade={handleExecuteBasisTrade}
          />
        )}

        {activeTab === 'PORTFOLIO' && (
          <PortfolioView
            positions={positions}
            riskSummary={portfolioRisk}
            onUnwindPosition={handleUnwindPosition}
            onOpenNewOrder={() => {
              setOrderInitialParams({});
              setIsOrderTicketOpen(true);
            }}
          />
        )}

        {activeTab === 'RISK' && (
          <RiskJTDView
            positions={positions}
            riskSummary={portfolioRisk}
          />
        )}

        {activeTab === 'SCENARIOS' && (
          <ScenariosView
            positions={positions}
          />
        )}

        {activeTab === 'TRADING' && (
          <TradingBlotterView
            orders={orders}
            pnlAttribution={pnlAttribution}
            onOpenNewOrder={() => {
              setOrderInitialParams({});
              setIsOrderTicketOpen(true);
            }}
            onCancelOrder={(id) => {
              setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status: 'CANCELLED' } : o)));
            }}
          />
        )}

        {activeTab === 'RESEARCH' && (
          <ResearchScreenerView
            quotes={quotes}
            entities={entities}
            onExecuteTradeIdea={handleExecuteTradeIdea}
          />
        )}

        {activeTab === 'REPORTS' && (
          <ReportsAuditView
            positions={positions}
            riskSummary={portfolioRisk}
            quotes={quotes}
          />
        )}
      </main>

      {/* Institutional AI Credit Analyst Modal (Gemini 3.7) */}
      <AICreditAnalystModal
        isOpen={isAIAnalystOpen}
        onClose={() => setIsAIAnalystOpen(false)}
        quotes={quotes}
        positions={positions}
      />

      {/* Electronic Order Ticket Modal */}
      <OrderTicketModal
        isOpen={isOrderTicketOpen}
        onClose={() => setIsOrderTicketOpen(false)}
        entities={entities}
        initialParams={orderInitialParams}
        onSubmitOrder={handleSubmitOrder}
      />
    </div>
  );
}

export default App;
