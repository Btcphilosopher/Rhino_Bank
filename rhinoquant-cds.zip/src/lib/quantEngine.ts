/**
 * RHINOQUANT CDS — Quantitative Pricing & Risk Engine
 * High-performance, deterministic numerical algorithms for CDS valuation,
 * hazard-rate bootstrapping, credit curves, CS01, JTD, VaR, and stress scenarios.
 */

import {
  CDSValuationParams,
  CDSValuationResult,
  CDSCurve,
  CDSCurvePoint,
  Tenor,
  CDSPosition,
  StressScenario,
  ScenarioResult,
  Sector,
  PortfolioRiskSummary
} from '../types/cds';

export const TENOR_YEARS_MAP: Record<Tenor, number> = {
  '6M': 0.5,
  '1Y': 1.0,
  '2Y': 2.0,
  '3Y': 3.0,
  '4Y': 4.0,
  '5Y': 5.0,
  '7Y': 7.0,
  '10Y': 10.0,
  '15Y': 15.0,
  '20Y': 20.0,
  '30Y': 30.0,
};

export const STANDARD_TENORS: Tenor[] = ['6M', '1Y', '2Y', '3Y', '5Y', '7Y', '10Y'];

/**
 * Standard discount factor assuming continuous flat/curve yield
 */
export function getDiscountFactor(t: number, riskFreeRate: number = 0.042): number {
  return Math.exp(-riskFreeRate * t);
}

/**
 * Approximate hazard rate lambda from a single par spread (Rule of thumb: lambda = S / (1 - R))
 */
export function flatHazardRateFromSpread(spreadBps: number, recoveryRate: number = 0.40): number {
  const s = spreadBps / 10000;
  return s / (1 - recoveryRate);
}

/**
 * Calculate Survival Probability Q(t) under constant hazard rate lambda
 */
export function survivalProbConstantHazard(lambda: number, t: number): number {
  return Math.exp(-lambda * t);
}

/**
 * Full Institutional CDS Valuation (ISDA Standard 2014 compliant logic)
 */
export function priceCDS(params: CDSValuationParams): CDSValuationResult {
  const {
    notional,
    tradeSpread, // Running coupon (e.g. 100bp or 500bp)
    marketSpread, // Current quoted par spread (e.g. 145bp)
    tenorYears,
    recoveryRate = 0.40,
    riskFreeRate = 0.042,
    buySell,
    daysSinceLastCoupon = 45,
  } = params;

  // Derive implied hazard rate from market spread
  const marketS = marketSpread / 10000;
  const tradeC = tradeSpread / 10000;
  const lgd = 1 - recoveryRate; // Loss Given Default

  // Numerical integration over quarterly coupon periods
  const dt = 0.25; // 4 payments per year (ISDA standard)
  const numSteps = Math.max(1, Math.round(tenorYears * 4));

  // Implied piecewise hazard rate lambda matching market spread
  // Iterative calibration for single tenor
  let lambda = marketS / lgd;
  for (let iter = 0; iter < 10; iter++) {
    let rpv01Test = 0;
    let protLegTest = 0;
    let prevQ = 1.0;

    for (let i = 1; i <= numSteps; i++) {
      const t = i * dt;
      const tMid = (i - 0.5) * dt;
      const df = getDiscountFactor(t, riskFreeRate);
      const dfMid = getDiscountFactor(tMid, riskFreeRate);
      const q = Math.exp(-lambda * t);
      const defaultProbPeriod = prevQ - q;

      // Premium leg annuity with accrual on default
      rpv01Test += dt * df * (q + 0.5 * defaultProbPeriod);
      // Protection leg
      protLegTest += lgd * dfMid * defaultProbPeriod;
      prevQ = q;
    }

    const modelFairSpread = rpv01Test > 0 ? (protLegTest / rpv01Test) : marketS;
    const diff = modelFairSpread - marketS;
    if (Math.abs(diff) < 1e-7) break;
    // Newton-Raphson update step
    lambda = Math.max(0.00001, lambda - diff / (lgd * 0.9));
  }

  // Calculate actual legs with calibrated lambda
  let riskyPV01Sum = 0;
  let protLegSum = 0;
  let prevQ = 1.0;

  for (let i = 1; i <= numSteps; i++) {
    const t = i * dt;
    const tMid = (i - 0.5) * dt;
    const df = getDiscountFactor(t, riskFreeRate);
    const dfMid = getDiscountFactor(tMid, riskFreeRate);
    const q = Math.exp(-lambda * t);
    const defaultProbPeriod = prevQ - q;

    riskyPV01Sum += dt * df * (q + 0.5 * defaultProbPeriod);
    protLegSum += lgd * dfMid * defaultProbPeriod;
    prevQ = q;
  }

  const premiumLegPV = notional * tradeC * riskyPV01Sum;
  const protectionLegPV = notional * protLegSum;
  const fairParSpread = riskyPV01Sum > 0 ? (protLegSum / riskyPV01Sum) * 10000 : marketSpread;
  const riskyPV01Dollar = notional * 0.0001 * riskyPV01Sum;

  // Upfront cash: From perspective of Protection Buyer
  // Buyer pays Premium Leg, receives Protection Leg => Buyer PV = Protection PV - Premium PV
  // Upfront to buy = Protection Leg PV - Premium Leg PV
  const cleanValue = protectionLegPV - premiumLegPV;
  const accruedFraction = Math.min(1.0, Math.max(0, daysSinceLastCoupon / 90));
  const accruedPremium = notional * tradeC * dt * accruedFraction;
  const dirtyValue = cleanValue + accruedPremium;

  // Sensitivity: CS01 (+1bp spread shock)
  // For long protection: value rises when spread widens (+CS01)
  const isBuyer = buySell === 'BUY';
  const cs01Direction = isBuyer ? 1 : -1;
  const cs01 = cs01Direction * riskyPV01Dollar;

  // Sensitivity: DV01 (+1bp IR shift)
  const bumpedRfResult = priceCDSInternal(notional, tradeC, marketS, tenorYears, recoveryRate, riskFreeRate + 0.0001, dt, numSteps);
  const dv01 = isBuyer ? (bumpedRfResult.cleanValue - cleanValue) : -(bumpedRfResult.cleanValue - cleanValue);

  // Recovery sensitivity Rec01 (+1% recovery, e.g. 0.40 -> 0.41)
  const bumpedRecResult = priceCDSInternal(notional, tradeC, marketS, tenorYears, recoveryRate + 0.01, riskFreeRate, dt, numSteps);
  const rec01 = isBuyer ? (bumpedRecResult.cleanValue - cleanValue) : -(bumpedRecResult.cleanValue - cleanValue);

  // Convexity / Gamma
  const bumpedUpSpread = priceCDSInternal(notional, tradeC, (marketSpread + 10) / 10000, tenorYears, recoveryRate, riskFreeRate, dt, numSteps);
  const bumpedDownSpread = priceCDSInternal(notional, tradeC, (marketSpread - 10) / 10000, tenorYears, recoveryRate, riskFreeRate, dt, numSteps);
  const gammaSpread = ((bumpedUpSpread.cleanValue + bumpedDownSpread.cleanValue - 2 * cleanValue) / 100) * (isBuyer ? 1 : -1);

  // Survival probability & default probabilities
  const finalSurvivalProb = Math.exp(-lambda * tenorYears);
  const cumDefaultProb = 1 - finalSurvivalProb;
  const expectedLoss = notional * cumDefaultProb * lgd;

  // Jump-to-Default (JTD): Instantaneous default P&L
  // Long protection receives (1 - R)*Notional, minus current MTM and accrued
  const jtd = isBuyer
    ? notional * lgd - cleanValue - accruedPremium
    : -notional * lgd - cleanValue - accruedPremium;

  return {
    premiumLegPV,
    protectionLegPV,
    accruedPremium,
    upfrontCash: cleanValue,
    cleanValue: isBuyer ? cleanValue : -cleanValue,
    dirtyValue: isBuyer ? dirtyValue : -dirtyValue,
    fairParSpread,
    riskyPV01: riskyPV01Sum,
    cs01,
    dv01,
    rec01,
    gammaSpread,
    expectedLoss,
    jumpToDefault: jtd,
    survivalProbability: finalSurvivalProb,
    cumulativeDefaultProbability: cumDefaultProb,
  };
}

function priceCDSInternal(
  notional: number,
  tradeC: number,
  marketS: number,
  tenorYears: number,
  recoveryRate: number,
  riskFreeRate: number,
  dt: number,
  numSteps: number
): { cleanValue: number; rpv01: number } {
  const lgd = 1 - recoveryRate;
  const lambda = marketS / lgd;
  let riskyPV01Sum = 0;
  let protLegSum = 0;
  let prevQ = 1.0;

  for (let i = 1; i <= numSteps; i++) {
    const t = i * dt;
    const tMid = (i - 0.5) * dt;
    const df = Math.exp(-riskFreeRate * t);
    const dfMid = Math.exp(-riskFreeRate * tMid);
    const q = Math.exp(-lambda * t);
    const defaultProbPeriod = prevQ - q;

    riskyPV01Sum += dt * df * (q + 0.5 * defaultProbPeriod);
    protLegSum += lgd * dfMid * defaultProbPeriod;
    prevQ = q;
  }

  const premiumLegPV = notional * tradeC * riskyPV01Sum;
  const protectionLegPV = notional * protLegSum;
  return { cleanValue: protectionLegPV - premiumLegPV, rpv01: riskyPV01Sum };
}

/**
 * Hazard Rate Curve Bootstrapper
 * Iteratively constructs piecewise-constant hazard rates across market tenors (6M to 10Y/30Y)
 */
export function bootstrapHazardCurve(
  entityId: string,
  entityName: string,
  marketSpreads: Record<Tenor, number>,
  recoveryRate: number = 0.40,
  riskFreeRate: number = 0.042
): CDSCurve {
  const tenorsToBootstrap: Tenor[] = ['6M', '1Y', '2Y', '3Y', '5Y', '7Y', '10Y'];
  const points: CDSCurvePoint[] = [];
  const diagnostics: string[] = [];
  let calibrationStatus: CDSCurve['calibrationStatus'] = 'VALID';

  const dt = 0.25;
  let prevT = 0;
  let prevSurvivalProb = 1.0;

  for (let k = 0; k < tenorsToBootstrap.length; k++) {
    const tenor = tenorsToBootstrap[k];
    const targetSpreadBps = marketSpreads[tenor] || (marketSpreads['5Y'] * (0.6 + 0.08 * k));
    const targetSpread = targetSpreadBps / 10000;
    const maturityT = TENOR_YEARS_MAP[tenor];
    const lgd = 1 - recoveryRate;

    // Numerical root search for lambda_k in (prevT, maturityT]
    let lambdaK = targetSpread / lgd;
    const numStepsInPeriod = Math.round((maturityT - prevT) / dt);

    for (let iter = 0; iter < 12; iter++) {
      // Evaluate total curve from 0 to maturityT with current lambdaK on latest interval
      let totalRpv01 = 0;
      let totalProtLeg = 0;

      // 1. Prior fixed intervals
      for (let p = 0; p < points.length; p++) {
        const pt = points[p];
        const ptPrevT = p === 0 ? 0 : TENOR_YEARS_MAP[points[p - 1].tenor];
        const ptT = TENOR_YEARS_MAP[pt.tenor];
        const ptLambda = pt.hazardRate;
        const ptPrevQ = p === 0 ? 1.0 : points[p - 1].survivalProb;
        const ptSteps = Math.round((ptT - ptPrevT) / dt);

        let qStep = ptPrevQ;
        for (let s = 1; s <= ptSteps; s++) {
          const tCur = ptPrevT + s * dt;
          const tMid = tCur - 0.5 * dt;
          const df = getDiscountFactor(tCur, riskFreeRate);
          const dfMid = getDiscountFactor(tMid, riskFreeRate);
          const nextQ = ptPrevQ * Math.exp(-ptLambda * (s * dt));
          const dQ = qStep - nextQ;

          totalRpv01 += dt * df * (nextQ + 0.5 * dQ);
          totalProtLeg += lgd * dfMid * dQ;
          qStep = nextQ;
        }
      }

      // 2. Current interval (prevT to maturityT)
      let qStep = prevSurvivalProb;
      for (let s = 1; s <= numStepsInPeriod; s++) {
        const tCur = prevT + s * dt;
        const tMid = tCur - 0.5 * dt;
        const df = getDiscountFactor(tCur, riskFreeRate);
        const dfMid = getDiscountFactor(tMid, riskFreeRate);
        const nextQ = prevSurvivalProb * Math.exp(-lambdaK * (s * dt));
        const dQ = qStep - nextQ;

        totalRpv01 += dt * df * (nextQ + 0.5 * dQ);
        totalProtLeg += lgd * dfMid * dQ;
        qStep = nextQ;
      }

      const modelSpread = totalRpv01 > 0 ? (totalProtLeg / totalRpv01) : targetSpread;
      const diff = modelSpread - targetSpread;
      if (Math.abs(diff) < 1e-7) break;
      lambdaK = Math.max(0.000001, lambdaK - diff / (lgd * 0.85));
    }

    if (lambdaK <= 0.0001) {
      calibrationStatus = 'WARNING_NEGATIVE_HAZARD';
      diagnostics.push(`Negative or near-zero hazard rate detected at tenor ${tenor} (λ = ${(lambdaK * 100).toFixed(3)}%). Possible curve arbitrage.`);
    }

    // Check for inversion
    if (k > 0 && targetSpreadBps < (marketSpreads[tenorsToBootstrap[k - 1]] || targetSpreadBps)) {
      if (calibrationStatus === 'VALID') calibrationStatus = 'WARNING_INVERTED';
      diagnostics.push(`Inversion detected: ${tenor} spread (${targetSpreadBps.toFixed(1)}bp) < ${tenorsToBootstrap[k - 1]} spread.`);
    }

    const intervalDuration = maturityT - prevT;
    const survivalProb = prevSurvivalProb * Math.exp(-lambdaK * intervalDuration);
    const cumDefaultProb = 1 - survivalProb;
    const marginalDefaultProb = prevSurvivalProb - survivalProb;

    // Forward hazard rate between prevT and maturityT
    const forwardHazardRate = lambdaK;

    points.push({
      tenor,
      yearFrac: maturityT,
      marketSpread: targetSpreadBps,
      hazardRate: lambdaK,
      survivalProb,
      cumDefaultProb,
      marginalDefaultProb,
      forwardHazardRate,
      discountFactor: getDiscountFactor(maturityT, riskFreeRate),
    });

    prevT = maturityT;
    prevSurvivalProb = survivalProb;
  }

  if (diagnostics.length === 0) {
    diagnostics.push('ISDA Piecewise Constant Hazard Rate Bootstrapping successful with zero arbitrage violations.');
  }

  return {
    entityId,
    entityName,
    calibrationDate: new Date().toISOString().split('T')[0],
    modelType: 'PIECEWISE_CONSTANT_HAZARD',
    recoveryRate,
    points,
    calibrationStatus,
    diagnostics,
  };
}

/**
 * Portfolio Risk Aggregator & CS01 Breakdown
 */
export function calculatePortfolioRisk(positions: CDSPosition[]): PortfolioRiskSummary {
  let grossNotional = 0;
  let netNotional = 0;
  let totalMtm = 0;
  let totalAccrued = 0;
  let totalPnl = 0;
  let dailyPnl = 0;
  let totalCS01 = 0;
  let totalDV01 = 0;
  let totalJTD = 0;
  let totalExpectedLoss = 0;

  const cs01BySector: Record<Sector, number> = {
    Financials: 0,
    Technology: 0,
    Energy: 0,
    Industrials: 0,
    Healthcare: 0,
    Consumer: 0,
    Sovereign: 0,
    Telecommunications: 0,
    Utilities: 0,
  };

  const cs01ByTenor: Record<Tenor, number> = {
    '6M': 0, '1Y': 0, '2Y': 0, '3Y': 0, '4Y': 0, '5Y': 0, '7Y': 0, '10Y': 0, '15Y': 0, '20Y': 0, '30Y': 0
  };

  const sectorConcentration: Record<string, number> = {};
  const ratingConcentration: Record<string, number> = {};
  const counterpartyExposure: Record<string, number> = {};
  const jtdByIssuer: { entityName: string; notional: number; buySell: string; recovery: number; jtd: number }[] = [];

  for (const pos of positions) {
    const notional = pos.notional || 0;
    const mtm = pos.mtm || 0;
    const cs01 = pos.cs01 || 0;
    const dv01 = pos.dv01 || 0;
    const jtd = pos.jtd || 0;
    const accrued = pos.accrued || pos.accruedPremium || 0;
    const pnl = pos.totalPnl || mtm;
    const dPnl = pos.dailyPnl || 0;
    const expLoss = pos.expectedLoss || 0;

    grossNotional += notional;
    netNotional += pos.buySell === 'BUY' ? notional : -notional;
    totalMtm += mtm;
    totalAccrued += accrued;
    totalPnl += pnl;
    dailyPnl += dPnl;
    totalCS01 += cs01;
    totalDV01 += dv01;
    totalJTD += jtd;
    totalExpectedLoss += expLoss;

    const sector = pos.sector || 'Financials';
    if (sector in cs01BySector) {
      cs01BySector[sector as Sector] += cs01;
    }
    sectorConcentration[sector] = (sectorConcentration[sector] || 0) + notional;

    const tenor = pos.tenor || '5Y';
    if (tenor in cs01ByTenor) {
      cs01ByTenor[tenor as Tenor] += cs01;
    }

    const rating = pos.rating || 'BBB';
    ratingConcentration[rating] = (ratingConcentration[rating] || 0) + notional;

    const cpName = pos.counterpartyName || pos.counterparty || 'ICE Clear Credit';
    counterpartyExposure[cpName] = (counterpartyExposure[cpName] || 0) + notional;

    jtdByIssuer.push({
      entityName: pos.entityName || pos.ticker || 'Unknown',
      notional,
      buySell: pos.buySell || 'BUY',
      recovery: pos.recoveryRate || 0.40,
      jtd,
    });
  }

  const maxNetJTD = jtdByIssuer.length > 0 ? Math.max(...jtdByIssuer.map((j) => Math.abs(j.jtd))) : 0;

  // Parametric & Historical Credit VaR approximation
  const dailySpreadStdDevDollar = Math.abs(totalCS01) * 3.5; // ~3.5bp daily move 1-sigma

  const creditVaR95 = dailySpreadStdDevDollar * 1.645 * Math.sqrt(10); // 10-day 95% VaR
  const creditVaR99 = dailySpreadStdDevDollar * 2.326 * Math.sqrt(10); // 10-day 99% VaR
  const creditVaR99_9 = dailySpreadStdDevDollar * 3.090 * Math.sqrt(10); // 10-day 99.9% VaR

  // Spread Duration = CS01 / (MarketValue or NetNotional * 0.0001)
  const spreadDuration = netNotional !== 0 ? Math.abs(totalCS01 / (netNotional * 0.0001)) : 4.6;

  return {
    totalGrossNotional: grossNotional,
    totalNetNotional: netNotional,
    totalCS01,
    totalDV01,
    totalMTM: totalMtm,
    maxNetJTD,
    expectedLoss1Y: totalExpectedLoss,
    creditVaR95_1D: creditVaR95,
    creditVaR99_1D: creditVaR99,
    sectorConcentration,
    ratingConcentration,
    counterpartyExposure,
    grossNotional,
    netNotional,
    totalMtm,
    totalAccrued,
    totalPnl,
    dailyPnl,
    totalJTD,
    totalExpectedLoss,
    spreadDuration,
    creditVaR95,
    creditVaR99,
    creditVaR99_9,
    cs01BySector,
    cs01ByTenor,
    notionalByRating: ratingConcentration,
    notionalByCounterparty: counterpartyExposure,
    jtdByIssuer: jtdByIssuer.sort((a, b) => Math.abs(b.jtd) - Math.abs(a.jtd)),
  };
}

/**
 * Execute Multi-Factor Stress Testing Scenario
 */
export function runScenarioStressTest(
  scenario: StressScenario,
  positions: CDSPosition[]
): ScenarioResult {
  let portfolioPnl = 0;
  let cs01Impact = 0;
  let defaultLosses = 0;
  const pnlBySector: Record<Sector, number> = {
    Financials: 0,
    Technology: 0,
    Energy: 0,
    Industrials: 0,
    Healthcare: 0,
    Consumer: 0,
    Sovereign: 0,
    Telecommunications: 0,
    Utilities: 0,
  };

  const pnlByEntity: { entityName: string; pnl: number; notional: number; shockBps: number }[] = [];

  for (const pos of positions) {
    let shockBps = scenario.spreadShocks.ALL || 0;
    if (scenario.spreadShocks[pos.sector] !== undefined) {
      shockBps = scenario.spreadShocks[pos.sector]!;
    }

    // Default scenario override
    const isDefaulted = scenario.defaultEntities?.includes(pos.entityId) || scenario.defaultEntities?.includes(pos.ticker);
    let entityPnl = 0;

    if (isDefaulted) {
      entityPnl = pos.jtd;
      defaultLosses += entityPnl;
    } else {
      // Linear + Convexity approximation: PnL = CS01 * shockBps + 0.5 * Gamma * shockBps^2
      const linearPnl = pos.cs01 * shockBps;
      const convexityPnl = 0.5 * (pos.cs01 / 100) * Math.pow(shockBps / 10, 2);
      entityPnl = linearPnl + convexityPnl;
    }

    portfolioPnl += entityPnl;
    cs01Impact += pos.cs01 * (1 + shockBps / 500); // Higher spreads increase CS01 slightly
    pnlBySector[pos.sector] += entityPnl;

    pnlByEntity.push({
      entityName: pos.entityName,
      pnl: entityPnl,
      notional: pos.notional,
      shockBps: isDefaulted ? 9999 : shockBps,
    });
  }

  pnlByEntity.sort((a, b) => a.pnl - b.pnl);
  const worstHitEntity = pnlByEntity.length > 0 ? `${pnlByEntity[0].entityName} ($${(pnlByEntity[0].pnl / 1000).toFixed(0)}k)` : 'None';
  const topGainerEntity = pnlByEntity.length > 0 ? `${pnlByEntity[pnlByEntity.length - 1].entityName} (+$${(pnlByEntity[pnlByEntity.length - 1].pnl / 1000).toFixed(0)}k)` : 'None';

  // Margin Requirement Delta (typically 15-20% of stressed losses plus collateral cushion)
  const marginRequirementDelta = Math.max(0, -portfolioPnl * 0.35 + Math.abs(cs01Impact) * 20);

  return {
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    portfolioPnl,
    cs01Impact,
    marginRequirementDelta,
    pnlBySector,
    pnlByEntity,
    defaultLosses,
    worstHitEntity,
    topGainerEntity,
  };
}

/**
 * Generate Rust Quantitative Engine Code for Audit / Local Quant Reproduction
 */
export function generateRustPricingSnippet(params: CDSValuationParams): string {
  return `// RHINOQUANT CDS — Rust Quant Core Engine v2026.4
// Reference: ISDA Standard Model 2014 & Jarrow-Turnbull Hazard Rate Formulation
use std::f64;

#[derive(Debug, Clone)]
pub struct CDSContract {
    pub notional: f64,
    pub running_coupon_bps: f64,
    pub market_par_spread_bps: f64,
    pub tenor_years: f64,
    pub recovery_rate: f64,
    pub risk_free_rate: f64,
    pub is_buyer: bool,
}

pub struct CDSValuation {
    pub premium_leg_pv: f64,
    pub protection_leg_pv: f64,
    pub clean_upfront_pv: f64,
    pub risky_pv01: f64,
    pub cs01_dollar: f64,
    pub jump_to_default_pnl: f64,
    pub cumulative_default_prob: f64,
}

pub fn price_cds_isda_standard(c: &CDSContract) -> CDSValuation {
    let dt = 0.25; // Quarterly ISDA cycle
    let num_steps = (c.tenor_years * 4.0).round() as usize;
    let lgd = 1.0 - c.recovery_rate;
    let market_s = c.market_par_spread_bps / 10_000.0;
    let trade_c = c.running_coupon_bps / 10_000.0;

    // Piecewise hazard rate approximation
    let lambda = market_s / lgd;

    let mut rpv01_sum = 0.0;
    let mut prot_leg_sum = 0.0;
    let mut prev_q = 1.0;

    for i in 1..=num_steps {
        let t = i as f64 * dt;
        let t_mid = (i as f64 - 0.5) * dt;
        let df = (-c.risk_free_rate * t).exp();
        let df_mid = (-c.risk_free_rate * t_mid).exp();
        let q = (-lambda * t).exp();
        let dq = prev_q - q;

        rpv01_sum += dt * df * (q + 0.5 * dq);
        prot_leg_sum += lgd * df_mid * dq;
        prev_q = q;
    }

    let premium_leg_pv = c.notional * trade_c * rpv01_sum;
    let protection_leg_pv = c.notional * prot_leg_sum;
    let clean_upfront = protection_leg_pv - premium_leg_pv;
    let risky_pv01_dollar = c.notional * 0.0001 * rpv01_sum;
    let cs01 = if c.is_buyer { risky_pv01_dollar } else { -risky_pv01_dollar };

    let cum_dp = 1.0 - (-lambda * c.tenor_years).exp();
    let jtd = if c.is_buyer {
        c.notional * lgd - clean_upfront
    } else {
        -c.notional * lgd - clean_upfront
    };

    CDSValuation {
        premium_leg_pv,
        protection_leg_pv,
        clean_upfront_pv: if c.is_buyer { clean_upfront } else { -clean_upfront },
        risky_pv01: rpv01_sum,
        cs01_dollar: cs01,
        jump_to_default_pnl: jtd,
        cumulative_default_prob: cum_dp,
    }
}

fn main() {
    let trade = CDSContract {
        notional: ${params.notional}.0,
        running_coupon_bps: ${params.tradeSpread}.0,
        market_par_spread_bps: ${params.marketSpread}.0,
        tenor_years: ${params.tenorYears}.0,
        recovery_rate: ${params.recoveryRate},
        risk_free_rate: ${params.riskFreeRate},
        is_buyer: ${params.buySell === 'BUY'},
    };
    let val = price_cds_isda_standard(&trade);
    println!("Clean Upfront PV: \${:.2}", val.clean_upfront_pv);
    println!("CS01 (1bp): \${:.2}", val.cs01_dollar);
    println!("Jump to Default P&L: \${:.2}", val.jump_to_default_pnl);
}
`;
}

/**
 * Generate R Quantitative Research Code for Credit Econometrics & Backtesting
 */
export function generateRResearchSnippet(ticker: string = 'BA', spreads: number[] = [210, 225, 238, 245, 252, 248]): string {
  return `# RHINOQUANT CDS — R Quant Research Script
# Econometric Credit Spread Modeling, OU Process, and Basis Analysis
library(zoo)
library(tseries)

cat("========================================\\n")
cat("RHINOQUANT CDS RESEARCH: ${ticker}\\n")
cat("========================================\\n")

# 5Y Spreads historical vector (bps)
spreads <- c(${spreads.join(', ')})
dates <- seq(as.Date("2025-01-01"), by="day", length.out=length(spreads))
cds_ts <- zoo(spreads, order.by=dates)

# 1. Summary Statistics & Percentiles
spread_mean <- mean(spreads)
spread_sd <- sd(spreads)
spread_zscore <- (tail(spreads, 1) - spread_mean) / spread_sd
quantiles <- quantile(spreads, probs=c(0.05, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99))

cat("Current Spread:", tail(spreads, 1), "bps\\n")
cat("Historical Mean:", round(spread_mean, 2), "bps | SD:", round(spread_sd, 2), "bps\\n")
cat("Current Z-Score:", round(spread_zscore, 3), "\\n")
cat("95th Percentile:", round(quantiles["95%"], 2), "bps\\n")

# 2. Augmented Dickey-Fuller Test for Mean-Reversion
adf_res <- adf.test(spreads)
cat("ADF Stationarity p-value:", round(adf_res$p.value, 4), "\\n")

# 3. Fit Ornstein-Uhlenbeck (OU) Mean-Reverting Drift & Volatility
# dS_t = theta * (mu - S_t) dt + sigma dW_t
dt <- 1/252
reg <- lm(diff(spreads) ~ lag(spreads, -1))
theta <- -coef(reg)[2] / dt
mu <- coef(reg)[1] / (theta * dt)
sigma <- sd(residuals(reg)) / sqrt(dt)
half_life_days <- log(2) / (theta * dt)

cat("\\n[OU Parameters]\\n")
cat("Mean Reversion Speed (theta):", round(theta, 3), "\\n")
cat("Long-Term Equilibrium (mu):", round(mu, 2), "bps\\n")
cat("Half-Life to Mean:", round(half_life_days, 1), "trading days\\n")
`;
}
