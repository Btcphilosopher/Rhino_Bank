import { IPOProjectState, DigitalTwinCalculations, FinancialYearData, SyntheticInvestor } from '../types/ipo';
import { TRADING_COMPS_DATABASE } from '../data/mockDatabase';

export function runDigitalTwinSimulation(project: IPOProjectState): DigitalTwinCalculations {
  // 1. Scenario Adjustment Factors
  let revenueGrowthModifier = 0;
  let ebitdaMarginModifier = 0;
  let multipleModifier = 1.0;
  let discountModifier = 0;
  let demandMultiplier = 1.0;

  switch (project.currentScenario) {
    case 'BEAR':
      revenueGrowthModifier = -10.0;
      ebitdaMarginModifier = -4.0;
      multipleModifier = 0.85;
      discountModifier = 5.0; // wider discount required
      demandMultiplier = 0.7;
      break;
    case 'EXTREME_BEAR':
      revenueGrowthModifier = -22.0;
      ebitdaMarginModifier = -9.0;
      multipleModifier = 0.65;
      discountModifier = 10.0;
      demandMultiplier = 0.45;
      break;
    case 'BULL':
      revenueGrowthModifier = 8.0;
      ebitdaMarginModifier = 3.0;
      multipleModifier = 1.15;
      discountModifier = -3.0;
      demandMultiplier = 1.4;
      break;
    case 'EXTREME_BULL':
      revenueGrowthModifier = 18.0;
      ebitdaMarginModifier = 6.0;
      multipleModifier = 1.35;
      discountModifier = -7.0;
      demandMultiplier = 1.9;
      break;
    case 'BASE':
    default:
      revenueGrowthModifier = 0;
      ebitdaMarginModifier = 0;
      multipleModifier = 1.0;
      discountModifier = 0;
      demandMultiplier = 1.0;
      break;
  }

  // 2. Compute Financial Forecast
  const lastHist = project.financials.filter(f => !f.isForecast).slice(-1)[0] || project.financials[0];
  const horizon = project.forecastAssumptions.horizonYears;
  const forecastYears: FinancialYearData[] = [];

  let currentRev = lastHist.revenue;
  const startYear = lastHist.year + 1;

  for (let i = 0; i < horizon; i++) {
    const yearNum = startYear + i;
    const baseGrowth = (project.forecastAssumptions.revenueGrowthRates[i] !== undefined)
      ? project.forecastAssumptions.revenueGrowthRates[i]
      : Math.max(10, 30 - i * 4);
      
    const effectiveGrowth = Math.max(-10, baseGrowth + revenueGrowthModifier);
    currentRev = currentRev * (1 + effectiveGrowth / 100);

    const grossMargin = Math.min(95, Math.max(20, project.forecastAssumptions.grossMarginPercent));
    const grossProfit = currentRev * (grossMargin / 100);

    const baseEbitdaMargin = Math.min(60, Math.max(-20, (grossMargin - project.forecastAssumptions.opexPercentRevenue) + ebitdaMarginModifier));
    const ebitda = currentRev * (baseEbitdaMargin / 100);

    const capex = currentRev * (project.forecastAssumptions.capexPercentRevenue / 100);
    const ebit = ebitda - (capex * 0.8); // Depreciation proxy
    const interest = lastHist.debt * (project.forecastAssumptions.interestRatePercent / 100);
    const EBT = ebit - interest;
    const tax = EBT > 0 ? EBT * (project.forecastAssumptions.taxRatePercent / 100) : 0;
    const netIncome = EBT - tax;

    const workingCap = currentRev * (project.forecastAssumptions.nwcPercentRevenue / 100);
    const ocf = ebitda - tax;
    const fcf = ocf - capex;

    forecastYears.push({
      year: yearNum,
      isForecast: true,
      revenue: Math.round(currentRev * 10) / 10,
      grossProfit: Math.round(grossProfit * 10) / 10,
      ebitda: Math.round(ebitda * 10) / 10,
      ebit: Math.round(ebit * 10) / 10,
      netIncome: Math.round(netIncome * 10) / 10,
      operatingCashFlow: Math.round(ocf * 10) / 10,
      freeCashFlow: Math.round(fcf * 10) / 10,
      cash: Math.round((lastHist.cash + (fcf > 0 ? fcf * (i + 1) * 0.7 : 0)) * 10) / 10,
      debt: lastHist.debt,
      capex: Math.round(capex * 10) / 10,
      workingCapital: Math.round(workingCap * 10) / 10,
      employees: Math.round(lastHist.employees * (1 + (i + 1) * 0.2)),
      customers: Math.round(lastHist.customers * (1 + (i + 1) * 0.25))
    });
  }

  // 3. DCF Valuation Engine Calculation
  const wacc = project.dcfInputs.waccPercent / 100;
  const g = project.dcfInputs.terminalGrowthRatePercent / 100;
  
  let pvFCFSum = 0;
  forecastYears.forEach((fy, idx) => {
    const discountFactor = Math.pow(1 + wacc, idx + 1);
    pvFCFSum += fy.freeCashFlow / discountFactor;
  });

  const lastForecast = forecastYears[forecastYears.length - 1];
  const terminalYearFCF = lastForecast.freeCashFlow * (1 + g);
  
  let terminalValue = 0;
  if (project.dcfInputs.terminalMethod === 'PERPETUITY') {
    terminalValue = (wacc > g) ? terminalYearFCF / (wacc - g) : terminalYearFCF / 0.05;
  } else {
    terminalValue = lastForecast.ebitda * project.dcfInputs.exitEbitdaMultiple;
  }

  const pvTerminalValue = terminalValue / Math.pow(1 + wacc, horizon);
  const dcfEnterpriseValue = Math.round((pvFCFSum + pvTerminalValue) * 10) / 10;
  
  const currentCash = lastHist.cash;
  const currentDebt = lastHist.debt;
  const dcfEquityValue = Math.round((dcfEnterpriseValue + currentCash - currentDebt) * 10) / 10;

  // 4. Trading Comparables Calculation
  const selectedComps = TRADING_COMPS_DATABASE.filter(c => project.selectedCompIds.includes(c.id));
  const activeComps = selectedComps.length > 0 ? selectedComps : TRADING_COMPS_DATABASE.slice(0, 4);

  const evRevMultiples = activeComps.map(c => c.evRevenue * multipleModifier);
  const evEbitdaMultiples = activeComps.map(c => c.evEbitda * multipleModifier);

  const medianEvRevenue = median(evRevMultiples) || 15.0;
  const medianEvEbitda = median(evEbitdaMultiples) || 35.0;

  const ntmRevenue = forecastYears[0]?.revenue || lastHist.revenue * 1.3;
  const ntmEbitda = forecastYears[0]?.ebitda || lastHist.ebitda * 1.3;

  const compsEvFromRev = ntmRevenue * medianEvRevenue;
  const compsEvFromEbitda = ntmEbitda * medianEvEbitda;
  
  const compsImpliedEv = Math.round(((compsEvFromRev * 0.6) + (compsEvFromEbitda * 0.4)) * 10) / 10;
  const compsImpliedEquityValue = Math.round((compsImpliedEv + currentCash - currentDebt) * 10) / 10;

  // Blended Pre-Money Equity Valuation
  const preMoneyEquityValue = Math.round(((dcfEquityValue * 0.5) + (compsImpliedEquityValue * 0.5)) * 10) / 10;
  const enterpriseValue = Math.round((preMoneyEquityValue - currentCash + currentDebt) * 10) / 10;

  // 5. Share Count & Pricing Range Engine
  const totalPreIpoShares = project.shareholders.reduce((acc, sh) => acc + sh.preShares, 0);
  const dcfImpliedPricePerShare = Math.round((dcfEquityValue * 1000000 / totalPreIpoShares) * 100) / 100;
  
  const basePreSharePrice = preMoneyEquityValue * 1000000 / totalPreIpoShares;

  // Indicative Price Range before discount
  const indicativePriceLow = Math.round((basePreSharePrice * 0.90) * 100) / 100;
  const indicativePriceMid = Math.round((basePreSharePrice * 1.00) * 100) / 100;
  const indicativePriceHigh = Math.round((basePreSharePrice * 1.10) * 100) / 100;

  // Apply Configurable IPO Discount
  const totalDiscountPercent = Math.max(0, Math.min(40, project.ipoDiscountPercent + discountModifier));
  const finalOfferPrice = Math.round((indicativePriceMid * (1 - totalDiscountPercent / 100)) * 100) / 100;

  // 6. Primary and Secondary Offering Proceeds
  const primaryShares = project.newPrimaryShares;
  const secondaryShares = project.secondarySharesOffered;
  const totalOfferedShares = primaryShares + secondaryShares;

  const primaryProceedsGross = Math.round((primaryShares * finalOfferPrice / 1000000) * 10) / 10; // $M
  const secondaryProceedsGross = Math.round((secondaryShares * finalOfferPrice / 1000000) * 10) / 10; // $M
  const totalGrossProceeds = Math.round((primaryProceedsGross + secondaryProceedsGross) * 10) / 10;

  const totalPostIpoShares = totalPreIpoShares + primaryShares;
  const postMoneyEquityValue = Math.round((totalPostIpoShares * finalOfferPrice / 1000000) * 10) / 10;

  // Fees Engine
  const underwritingFeeUSD = (totalGrossProceeds * (project.feeUnderwritingPercent / 100));
  const totalTransactionFees = Math.round((underwritingFeeUSD + project.feeAdvisoryUSD + project.feeLegalUSD + project.feeAuditUSD + project.feeListingAndMarketingUSD) * 10) / 10;
  const netPrimaryProceeds = Math.round((primaryProceedsGross - totalTransactionFees) * 10) / 10;

  // 7. Cap Table Post-IPO ownership & Dilution
  const postIpoPublicFreeFloatPercent = Math.round(((totalOfferedShares / totalPostIpoShares) * 100) * 10) / 10;
  const dilutionPercent = Math.round(((primaryShares / totalPostIpoShares) * 100) * 10) / 10;

  const foundersShares = project.shareholders.filter(s => s.category === 'Founders').reduce((a, b) => a + (b.preShares - b.secondarySharesSold), 0);
  const mgmtShares = project.shareholders.filter(s => s.category === 'Management' || s.category === 'Employees').reduce((a, b) => a + (b.preShares - b.secondarySharesSold), 0);
  const vcPeShares = project.shareholders.filter(s => s.category === 'Venture Capital' || s.category === 'Private Equity').reduce((a, b) => a + (b.preShares - b.secondarySharesSold), 0);

  const foundersPostOwnershipPercent = Math.round(((foundersShares / totalPostIpoShares) * 100) * 10) / 10;
  const mgmtPostOwnershipPercent = Math.round(((mgmtShares / totalPostIpoShares) * 100) * 10) / 10;
  const vcPePostOwnershipPercent = Math.round(((vcPeShares / totalPostIpoShares) * 100) * 10) / 10;

  // 8. Bookbuilding & Demand Simulation
  const effectiveInvestorBook = project.investorBook.map(inv => {
    // Price elasticity: request drops if final offer price exceeds target price
    const priceDiffRatio = (inv.targetPriceUSD - finalOfferPrice) / inv.targetPriceUSD;
    let elasticityFactor = 1 + (priceDiffRatio * inv.priceSensitivity * 2);
    elasticityFactor = Math.max(0.1, Math.min(2.0, elasticityFactor));
    
    const simulatedShares = Math.round(inv.requestedShares * elasticityFactor * demandMultiplier);
    return {
      ...inv,
      requestedShares: simulatedShares
    };
  });

  const totalBookDemandShares = effectiveInvestorBook.reduce((sum, inv) => sum + inv.requestedShares, 0);
  const totalBookDemandUSD = Math.round((totalBookDemandShares * finalOfferPrice / 1000000) * 10) / 10;
  const oversubscriptionRatio = Math.round((totalBookDemandShares / Math.max(1, totalOfferedShares)) * 100) / 100;

  const institutionalDemandUSD = Math.round((effectiveInvestorBook.filter(i => i.category !== 'RETAIL').reduce((s, i) => s + (i.requestedShares * finalOfferPrice / 1000000), 0)) * 10) / 10;
  const retailDemandUSD = Math.round((effectiveInvestorBook.filter(i => i.category === 'RETAIL').reduce((s, i) => s + (i.requestedShares * finalOfferPrice / 1000000), 0)) * 10) / 10;

  // Equilibrium Price calculation (where demand equals supply)
  const equilibriumPriceUSD = Math.round((indicativePriceMid * (0.95 + (oversubscriptionRatio * 0.05))) * 100) / 100;

  // 9. Allocation Engine Execution
  const allocatedInvestors: SyntheticInvestor[] = effectiveInvestorBook.map(inv => {
    let fillRatio = 1 / Math.max(1, oversubscriptionRatio);
    if (project.allocationStrategy === 'TIERED_QUALITY') {
      if (inv.tier === 'Tier 1 Anchor') fillRatio *= 1.8;
      else if (inv.tier === 'Tier 2 Quality') fillRatio *= 1.2;
      else if (inv.tier === 'Retail') fillRatio = (project.retailAllocationPercent / 100) * (totalOfferedShares / Math.max(1, inv.requestedShares));
      else fillRatio *= 0.6;
    } else if (project.allocationStrategy === 'LONG_ONLY_FAVOURED') {
      if (inv.category === 'LONG_ONLY' || inv.category === 'PENSION_FUNDS') fillRatio *= 2.0;
      else if (inv.category === 'HEDGE_FUNDS') fillRatio *= 0.4;
    }

    fillRatio = Math.min(1.0, Math.max(0, fillRatio));
    const allocatedShares = Math.round(inv.requestedShares * fillRatio);
    return {
      ...inv,
      allocatedShares
    };
  });

  const allocatedSumShares = allocatedInvestors.reduce((s, i) => s + (i.allocatedShares || 0), 0);
  const unfilledDemandUSD = Math.round((Math.max(0, totalBookDemandShares - allocatedSumShares) * finalOfferPrice / 1000000) * 10) / 10;

  // Calculate Herfindahl Concentration Index (HHI) for allocated investors
  let hhiSum = 0;
  if (allocatedSumShares > 0) {
    allocatedInvestors.forEach(inv => {
      const sharePct = ((inv.allocatedShares || 0) / allocatedSumShares) * 100;
      hhiSum += Math.pow(sharePct, 2);
    });
  }
  const top10InvestorConcentrationIndex = Math.round(hhiSum);

  // 10. Offer Size Optimizer Matrix (10% to 50%)
  const sizeSteps = [10, 15, 20, 25, 30, 35, 40, 50];
  const sizeOptimizationMatrix = sizeSteps.map(pct => {
    const offerShares = Math.round(totalPreIpoShares * (pct / (100 - pct)));
    const gross = Math.round((offerShares * finalOfferPrice / 1000000) * 10) / 10;
    const postCap = Math.round(((totalPreIpoShares + offerShares) * finalOfferPrice / 1000000) * 10) / 10;
    const dil = Math.round((offerShares / (totalPreIpoShares + offerShares)) * 1000) / 10;
    const float = dil;
    const liquidityScore = Math.min(100, Math.round(float * 2.2 + (gross / 20)));

    return {
      equityOfferedPercent: pct,
      sharesIssued: offerShares,
      grossProceeds: gross,
      postMarketCap: postCap,
      dilutionPercent: dil,
      freeFloatPercent: float,
      liquidityScore
    };
  });

  // 11. Market Window & Risk Score Calculation
  const vixPenalty = Math.max(0, (project.marketConditions.equityVixIndex - 15) * 2.5);
  const windowRaw = (project.marketConditions.investorSentimentIndex * 0.4) +
                    (project.marketConditions.ipoMarketActivityIndex * 0.3) +
                    (project.marketConditions.sectorPerformance3M * 2.0) - vixPenalty;
  
  const ipoMarketWindowScore = Math.min(100, Math.max(10, Math.round(windowRaw)));
  const marketWindowStatus = ipoMarketWindowScore >= 75 ? 'OPTIMAL_WINDOW' : ipoMarketWindowScore >= 50 ? 'CAUTION_WINDOW' : 'CLOSED_WINDOW';

  // Risk Score Breakdown
  const valRisk = Math.min(100, Math.round(totalDiscountPercent < 10 ? 75 : totalDiscountPercent > 20 ? 30 : 45));
  const execRisk = Math.min(100, Math.round(oversubscriptionRatio < 1.5 ? 80 : oversubscriptionRatio > 4.0 ? 20 : 40));
  const mktRisk = Math.min(100, Math.round(project.marketConditions.equityVixIndex * 3.5));
  const liqRisk = Math.min(100, Math.round(postIpoPublicFreeFloatPercent < 15 ? 75 : 25));
  const demRisk = Math.min(100, Math.round(unfilledDemandUSD < 100 ? 65 : 20));
  const levRisk = Math.min(100, Math.round((lastHist.debt / Math.max(1, lastHist.ebitda)) * 25));
  const dilRisk = Math.min(100, Math.round(dilutionPercent * 2.2));

  const totalRiskScore = Math.round((valRisk + execRisk + mktRisk + liqRisk + demRisk + levRisk + dilRisk) / 7);

  // 12. Greenshoe Model
  const greenshoeShares = Math.round(totalOfferedShares * (project.greenshoePercent / 100));
  const greenshoeGrossProceeds = Math.round((greenshoeShares * (project.greenshoeExercisedPercent / 100) * finalOfferPrice / 1000000) * 10) / 10;
  const totalOfferedSharesWithGreenshoe = totalOfferedShares + Math.round(greenshoeShares * (project.greenshoeExercisedPercent / 100));

  // 13. Aftermarket Trajectory Simulation
  const popPercent = Math.min(45, Math.max(-15, (oversubscriptionRatio - 1) * 8 + (totalDiscountPercent * 0.6) - (vixPenalty * 0.3)));
  
  const periods = [
    { period: 'Listing Open', mult: 1 + (popPercent / 100) },
    { period: 'Day 1 Close', mult: 1 + (popPercent * 1.1 / 100) },
    { period: 'Day 7', mult: 1 + ((popPercent * 1.05 + 2) / 100) },
    { period: 'Day 30', mult: 1 + ((popPercent * 0.95 + 4) / 100) },
    { period: 'Day 90', mult: 1 + ((popPercent * 0.85 + 7) / 100) },
    { period: 'Day 180 (Lockup Expiry)', mult: 1 + ((popPercent * 0.70 + 10) / 100) },
    { period: '1 Year', mult: 1 + ((popPercent * 0.75 + 16) / 100) }
  ];

  const aftermarketTrajectory = periods.map(p => {
    const simPrice = Math.round((finalOfferPrice * p.mult) * 100) / 100;
    const retPct = Math.round(((simPrice - finalOfferPrice) / finalOfferPrice) * 1000) / 10;
    const benchRet = Math.round((retPct * 0.6 + 2) * 10) / 10;
    return {
      period: p.period,
      simulatedPrice: simPrice,
      returnPercent: retPct,
      benchmarkReturnPercent: benchRet
    };
  });

  return {
    forecastYears,
    terminalYearFCF: Math.round(terminalYearFCF * 10) / 10,
    dcfEnterpriseValue,
    dcfEquityValue,
    impliedWacc: project.dcfInputs.waccPercent,
    dcfImpliedPricePerShare,
    medianEvRevenue,
    medianEvEbitda,
    compsImpliedEv,
    compsImpliedEquityValue,
    preMoneyEquityValue,
    postMoneyEquityValue,
    enterpriseValue,
    totalPreIpoShares,
    totalPostIpoShares,
    indicativePriceLow,
    indicativePriceMid,
    indicativePriceHigh,
    finalOfferPrice,
    impliedDiscountValuationPercent: totalDiscountPercent,
    primaryProceedsGross,
    secondaryProceedsGross,
    totalGrossProceeds,
    totalTransactionFees,
    netPrimaryProceeds,
    postIpoPublicFreeFloatPercent,
    foundersPostOwnershipPercent,
    mgmtPostOwnershipPercent,
    vcPePostOwnershipPercent,
    dilutionPercent,
    totalBookDemandUSD,
    totalBookDemandShares,
    oversubscriptionRatio,
    institutionalDemandUSD,
    retailDemandUSD,
    equilibriumPriceUSD,
    allocatedInvestors,
    top10InvestorConcentrationIndex,
    unfilledDemandUSD,
    sizeOptimizationMatrix,
    ipoMarketWindowScore,
    marketWindowStatus,
    ipoRiskScore: totalRiskScore,
    riskBreakdown: {
      valuationRisk: valRisk,
      executionRisk: execRisk,
      marketRisk: mktRisk,
      liquidityRisk: liqRisk,
      demandRisk: demRisk,
      leverageRisk: levRisk,
      dilutionRisk: dilRisk
    },
    greenshoeShares,
    greenshoeGrossProceeds,
    totalOfferedSharesWithGreenshoe,
    aftermarketTrajectory
  };
}

function median(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const half = Math.floor(sorted.length / 2);
  if (sorted.length % 2) return sorted[half];
  return (sorted[half - 1] + sorted[half]) / 2.0;
}
