import { AuditRecord, IPOProjectState, DigitalTwinCalculations } from '../types/ipo';

export function generateAuditLog(project: IPOProjectState, calc: DigitalTwinCalculations): AuditRecord[] {
  const ts = new Date().toISOString();
  const version = project.version;

  return [
    {
      id: `aud-1-${Date.now()}`,
      timestamp: ts,
      inputName: 'Revenue Forecast Array & Horizon',
      assumptionValue: `Horizon: ${project.forecastAssumptions.horizonYears}Y | Growth: [${project.forecastAssumptions.revenueGrowthRates.join(', ')}]%`,
      formulaDescription: 'Revenue_t = Revenue_{t-1} * (1 + Growth_t%) + Scenario_Delta',
      outputResult: `Terminal Year Revenue: $${calc.forecastYears[calc.forecastYears.length - 1]?.revenue}M`,
      modelVersion: version
    },
    {
      id: `aud-2-${Date.now()}`,
      timestamp: ts,
      inputName: 'DCF WACC & Terminal Growth',
      assumptionValue: `WACC: ${project.dcfInputs.waccPercent}% | Terminal Growth: ${project.dcfInputs.terminalGrowthRatePercent}%`,
      formulaDescription: 'PV(FCF) + PV(FCF_T * (1+g) / (WACC - g))',
      outputResult: `DCF Enterprise Value: $${calc.dcfEnterpriseValue}M | Equity Value: $${calc.dcfEquityValue}M`,
      modelVersion: version
    },
    {
      id: `aud-3-${Date.now()}`,
      timestamp: ts,
      inputName: 'Trading Comparables Multiples',
      assumptionValue: `Selected Comps: ${project.selectedCompIds.length} | Median EV/Rev: ${calc.medianEvRevenue}x | EV/EBITDA: ${calc.medianEvEbitda}x`,
      formulaDescription: 'Comps EV = 60% * (NTM_Rev * Median_EV/Rev) + 40% * (NTM_EBITDA * Median_EV/EBITDA)',
      outputResult: `Comps Enterprise Value: $${calc.compsImpliedEv}M`,
      modelVersion: version
    },
    {
      id: `aud-4-${Date.now()}`,
      timestamp: ts,
      inputName: 'Pre-Money & Indicative Price',
      assumptionValue: `Pre-IPO Shares: ${(calc.totalPreIpoShares / 1000000).toFixed(1)}M | Blended Value: 50% DCF + 50% Comps`,
      formulaDescription: 'PreSharePrice = PreMoneyEquity / TotalPreIpoShares',
      outputResult: `Mid Price: $${calc.indicativePriceMid} / share (Range: $${calc.indicativePriceLow} - $${calc.indicativePriceHigh})`,
      modelVersion: version
    },
    {
      id: `aud-5-${Date.now()}`,
      timestamp: ts,
      inputName: 'IPO Valuation Discount',
      assumptionValue: `Configured Discount: ${project.ipoDiscountPercent}% | Effective Discount: ${calc.impliedDiscountValuationPercent}%`,
      formulaDescription: 'Final Offer Price = Mid Indicative Price * (1 - Effective Discount %)',
      outputResult: `Final Offer Price: $${calc.finalOfferPrice} / share`,
      modelVersion: version
    },
    {
      id: `aud-6-${Date.now()}`,
      timestamp: ts,
      inputName: 'Offering Structure & Gross Proceeds',
      assumptionValue: `Primary: ${(project.newPrimaryShares/1000000).toFixed(1)}M | Secondary: ${(project.secondarySharesOffered/1000000).toFixed(1)}M`,
      formulaDescription: 'Gross Proceeds = (PrimaryShares + SecondaryShares) * FinalOfferPrice',
      outputResult: `Gross Proceeds: $${calc.totalGrossProceeds}M (Primary: $${calc.primaryProceedsGross}M, Secondary: $${calc.secondaryProceedsGross}M)`,
      modelVersion: version
    },
    {
      id: `aud-7-${Date.now()}`,
      timestamp: ts,
      inputName: 'Syndicate Fees & Net Proceeds',
      assumptionValue: `Underwriting Fee: ${project.feeUnderwritingPercent}% | Advisory & Expense: $${(project.feeAdvisoryUSD + project.feeLegalUSD + project.feeAuditUSD + project.feeListingAndMarketingUSD).toFixed(1)}M`,
      formulaDescription: 'Net Primary Proceeds = Gross Primary Proceeds - Total Fees',
      outputResult: `Total Fees: $${calc.totalTransactionFees}M | Net Primary Proceeds: $${calc.netPrimaryProceeds}M`,
      modelVersion: version
    },
    {
      id: `aud-8-${Date.now()}`,
      timestamp: ts,
      inputName: 'Bookbuilding Demand & Elasticity',
      assumptionValue: `Total Orders: ${project.investorBook.length} | Price Elasticity Applied | Scenario: ${project.currentScenario}`,
      formulaDescription: 'Oversubscription Ratio = Total Demand Shares / Total Offered Shares',
      outputResult: `Demand: $${calc.totalBookDemandUSD}M (${calc.oversubscriptionRatio}x Oversubscribed) | Equilibrium Price: $${calc.equilibriumPriceUSD}`,
      modelVersion: version
    },
    {
      id: `aud-9-${Date.now()}`,
      timestamp: ts,
      inputName: 'Market Window & Integrated Risk',
      assumptionValue: `VIX: ${project.marketConditions.equityVixIndex} | Sentiment: ${project.marketConditions.investorSentimentIndex}/100`,
      formulaDescription: 'Market Window Score = Sentiment + Activity - VIX Penalty | Risk Score = Avg(7 Risk Dimensions)',
      outputResult: `Market Window Score: ${calc.ipoMarketWindowScore}/100 (${calc.marketWindowStatus}) | IPO Risk Score: ${calc.ipoRiskScore}/100`,
      modelVersion: version
    }
  ];
}
