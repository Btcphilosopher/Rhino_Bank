import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../types/ipo';
import { 
  Briefcase, 
  Layers, 
  Activity, 
  FileText, 
  Bot, 
  Download, 
  Copy, 
  TrendingUp, 
  ShieldAlert, 
  GitCompare, 
  Database, 
  Code
} from 'lucide-react';

interface HeaderNavProps {
  currentProject: IPOProjectState;
  projectsList: IPOProjectState[];
  onSelectProject: (id: string) => void;
  calc: DigitalTwinCalculations;
  onOpenWorkspaceModal: () => void;
  onOpenAuditDrawer: () => void;
  onOpenAiDrawer: () => void;
  activePanel: string;
  setActivePanel: (panel: string) => void;
  onScenarioChange: (scenario: IPOProjectState['currentScenario']) => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentProject,
  projectsList,
  onSelectProject,
  calc,
  onOpenWorkspaceModal,
  onOpenAuditDrawer,
  onOpenAiDrawer,
  activePanel,
  setActivePanel,
  onScenarioChange
}) => {
  return (
    <header className="bg-[#0E1013] border-b border-slate-800 text-slate-300 sticky top-0 z-40 shadow-2xl">
      {/* Top Bank Identity Bar */}
      <div className="max-w-[1700px] mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between border-b border-slate-800 text-xs">
        {/* Left Branding */}
        <div className="flex items-center space-x-3">
          <div className="bg-blue-600 text-white font-black px-2 py-1 text-xs tracking-tighter rounded-sm">
            RHINOQUANT
          </div>
          <div className="h-4 w-px bg-slate-700"></div>
          <div className="flex items-center space-x-2 text-slate-300">
            <span className="font-semibold text-white">RHINO BANK ECM</span>
            <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400 font-mono">
              ECM-ID: 8829-X
            </span>
          </div>
        </div>

        {/* Center Active Project Selector & Quick Stats */}
        <div className="flex items-center space-x-3 my-1 sm:my-0">
          <div className="flex items-center space-x-1.5 bg-[#0A0B0D] border border-slate-800 rounded px-2.5 py-1">
            <Briefcase className="w-3.5 h-3.5 text-blue-400" />
            <select
              value={currentProject.id}
              onChange={(e) => onSelectProject(e.target.value)}
              className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer text-xs"
            >
              {projectsList.map((p) => (
                <option key={p.id} value={p.id} className="bg-[#0E1013] text-slate-100">
                  PROJECT: {p.companyName.toUpperCase()} ({p.proposedTicker})
                </option>
              ))}
            </select>
          </div>

          {/* Live Market Sync Indicator */}
          <div className="flex items-center space-x-1.5 px-2 py-1 rounded bg-[#0A0B0D] border border-slate-800">
            <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
            <span className="text-[10px] font-mono text-green-500 uppercase tracking-wider font-bold">Live Market Sync</span>
          </div>
        </div>

        {/* Right Tools & Scenario Controls */}
        <div className="flex items-center space-x-2">
          {/* Scenario Selector */}
          <div className="flex items-center space-x-1 bg-[#0A0B0D] border border-slate-800 rounded p-0.5">
            <span className="text-[10px] text-slate-500 px-1 font-mono uppercase font-bold">Scenario:</span>
            {(['BEAR', 'BASE', 'BULL', 'EXTREME_BULL'] as const).map((sc) => (
              <button
                key={sc}
                onClick={() => onScenarioChange(sc)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-bold tracking-tight transition ${
                  currentProject.currentScenario === sc
                    ? 'bg-blue-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {sc.replace('_', ' ')}
              </button>
            ))}
          </div>

          {/* Action Triggers */}
          <button
            onClick={onOpenWorkspaceModal}
            className="flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded text-xs transition border border-slate-700 font-medium"
            title="Workspace Management"
          >
            <Layers className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">Workspace</span>
          </button>

          <button
            onClick={onOpenAuditDrawer}
            className="flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded text-xs transition border border-slate-700 font-medium"
            title="Model Calculation Audit Trail"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Audit</span>
          </button>

          <button
            onClick={onOpenAiDrawer}
            className="flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1 rounded text-xs transition shadow border border-blue-400/40"
          >
            <Bot className="w-3.5 h-3.5 text-blue-200" />
            <span>AI Advisor</span>
          </button>
        </div>
      </div>

      {/* Main Module Navigation Tabs */}
      <div className="max-w-[1700px] mx-auto px-4 overflow-x-auto scrollbar-none py-1 flex items-center space-x-1 text-[11px] font-medium uppercase tracking-wider">
        {[
          { id: 'overview', label: '1. Executive Overview', icon: Activity },
          { id: 'fundamentals', label: '2. Fundamentals & Forecast', icon: TrendingUp },
          { id: 'valuation', label: '3. Valuation (DCF & Comps)', icon: Layers },
          { id: 'valuation_range', label: '4. Valuation Range', icon: GitCompare },
          { id: 'cap_table', label: '5. Cap Table & Dilution', icon: Briefcase },
          { id: 'size_optimizer', label: '6. Offer Size Optimiser', icon: Layers },
          { id: 'pricing_discount', label: '7. Price & Discount', icon: TrendingUp },
          { id: 'bookbuilding', label: '8. Bookbuilding & Demand', icon: Activity },
          { id: 'allocation', label: '9. Allocation Engine', icon: Briefcase },
          { id: 'syndicate_fees', label: '10. Syndicate & Fees', icon: Layers },
          { id: 'use_of_proceeds', label: '11. Use of Proceeds', icon: FileText },
          { id: 'scenarios_risk', label: '12. Market Window & Risk', icon: ShieldAlert },
          { id: 'aftermarket', label: '13. Aftermarket & Greenshoe', icon: TrendingUp },
          { id: 'comps_database', label: '14. Comps DB & Backtesting', icon: Database },
          { id: 'api_explorer', label: '15. API Architecture', icon: Code }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activePanel === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActivePanel(tab.id)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-t transition border-b-2 ${
                isActive
                  ? 'bg-[#15181D] text-blue-400 border-blue-500 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-[#15181D] border-transparent'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
