import React, { useState } from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../types/ipo';
import { X, Bot, Sparkles, Send, RefreshCw, CheckCircle2 } from 'lucide-react';

interface AiEcmAdvisorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
}

export const AiEcmAdvisorDrawer: React.FC<AiEcmAdvisorDrawerProps> = ({
  isOpen,
  onClose,
  project,
  calc
}) => {
  const [memoText, setMemoText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [focusQuery, setFocusQuery] = useState<string>('General Strategic Pricing & Allocation Briefing');

  if (!isOpen) return null;

  const fetchAiMemo = async (queryType: string) => {
    setIsLoading(true);
    setFocusQuery(queryType);

    try {
      const res = await fetch('/api/ai/advise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectState: project,
          calcResults: calc,
          queryType
        })
      });
      const data = await res.json();
      setMemoText(data.memo || 'Failed to generate memorandum.');
    } catch (err) {
      setMemoText('Error connecting to Rhino AI Advisor server endpoint.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-xl bg-[#0B0F17] border-l border-[#1E293B] shadow-2xl flex flex-col text-slate-100">
      {/* Header */}
      <div className="p-4 border-b border-[#1E293B] bg-[#111827] flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 bg-gradient-to-tr from-cyan-600 to-blue-600 rounded">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-100">Rhino AI ECM Partner</h2>
            <p className="text-[10px] text-cyan-400 font-mono">Gemini 3.7 Flash Investment Banking Advisor</p>
          </div>
        </div>
        <button onClick={onClose} className="p-1 rounded hover:bg-slate-800 text-slate-400">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Query Preset Quick Buttons */}
      <div className="p-3 bg-[#141B2D] border-b border-[#1E293B] space-y-2">
        <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Request Deal Briefing Focus:</span>
        <div className="flex flex-wrap gap-1.5">
          {[
            'General Strategic Briefing',
            'DCF vs Trading Comps Valuation Gap',
            'Bookbuilding & Price Elasticity Strategy',
            'Allocation & Corner Stone Anchor Rules',
            'Syndicate Underwriting Fee Split & Net Proceeds',
            'Market Window & Aftermarket Stabilization'
          ].map((q) => (
            <button
              key={q}
              onClick={() => fetchAiMemo(q)}
              disabled={isLoading}
              className="text-[10px] bg-[#0B0F17] hover:bg-slate-800 text-cyan-300 border border-cyan-800/60 px-2.5 py-1 rounded transition whitespace-nowrap"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Memo Display Area */}
      <div className="flex-1 overflow-y-auto p-4 font-sans text-xs space-y-4">
        {isLoading ? (
          <div className="h-64 flex flex-col items-center justify-center space-y-3 text-slate-400">
            <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
            <p className="font-mono text-xs">Generating Institutional Deal Advisory Memo for {project.companyName}...</p>
          </div>
        ) : memoText ? (
          <div className="bg-[#141B2D] border border-cyan-500/30 rounded-lg p-4 space-y-3 text-slate-200 leading-relaxed shadow-lg">
            <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
              <span className="font-mono font-bold text-cyan-300 text-xs">CONFIDENTIAL ECM DEAL MEMORANDUM</span>
              <span className="text-[10px] text-slate-500">{new Date().toLocaleDateString()}</span>
            </div>
            <div className="whitespace-pre-wrap font-sans text-xs leading-relaxed text-slate-200">
              {memoText}
            </div>
          </div>
        ) : (
          <div className="h-64 flex flex-col items-center justify-center space-y-3 text-slate-500 text-center px-6">
            <Sparkles className="w-10 h-10 text-cyan-500/50" />
            <p className="text-xs">Click one of the prompt focus areas above to generate a real-time investment banking advisory memo powered by Gemini 3.7 Flash.</p>
          </div>
        )}
      </div>
    </div>
  );
};
