import React, { useState } from 'react';
import { IPOProjectState, DigitalTwinCalculations, SyndicateMember } from '../../types/ipo';
import { Layers, DollarSign, Plus, Trash2 } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const SyndicateAndFeesPanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  const [newBankName, setNewBankName] = useState('');
  const [newRole, setNewRole] = useState<SyndicateMember['role']>('Joint Bookrunner');
  const [newFeeShare, setNewFeeShare] = useState(25);

  const handleAddBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBankName) return;

    const newBank: SyndicateMember = {
      id: `bank-${Date.now()}`,
      institutionName: newBankName,
      role: newRole,
      feeSharePercent: newFeeShare,
      commitmentShares: 5000000,
      leadContact: 'ECM Desk'
    };

    onUpdateProject({
      syndicate: [...project.syndicate, newBank]
    });

    setNewBankName('');
  };

  const handleRemoveBank = (id: string) => {
    onUpdateProject({
      syndicate: project.syndicate.filter(b => b.id !== id)
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>Syndicate Desk & Advisory Fees Engine</span>
          </h2>
          <p className="text-xs text-slate-400">Underwriting fee economics, syndicate split, legal/audit expenses, and net proceeds waterfall.</p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Gross Spread %</span>
            <span className="font-bold text-amber-300 text-sm">{project.feeUnderwritingPercent}%</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Total Bank Fees</span>
            <span className="font-bold text-cyan-300 text-sm">${calc.underwritingFeesUSD}M</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Net Primary Proceeds</span>
            <span className="font-bold text-emerald-400 text-sm">${calc.netPrimaryProceeds}M</span>
          </div>
        </div>
      </div>

      {/* Advisory & Listing Expenses Breakdown */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Transaction Expense Assumptions ($M)</h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
          <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
            <label className="text-slate-400 block text-[10px] uppercase mb-1">Legal Counsel</label>
            <input
              type="number"
              step="0.1"
              value={project.feeLegalUSD}
              onChange={(e) => onUpdateProject({ feeLegalUSD: parseFloat(e.target.value) || 0 })}
              className="w-full bg-[#141B2D] border border-slate-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none"
            />
          </div>

          <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
            <label className="text-slate-400 block text-[10px] uppercase mb-1">Audit & Accounting</label>
            <input
              type="number"
              step="0.1"
              value={project.feeAuditUSD}
              onChange={(e) => onUpdateProject({ feeAuditUSD: parseFloat(e.target.value) || 0 })}
              className="w-full bg-[#141B2D] border border-slate-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none"
            />
          </div>

          <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
            <label className="text-slate-400 block text-[10px] uppercase mb-1">Exchange Listing & PR</label>
            <input
              type="number"
              step="0.1"
              value={project.feeListingAndMarketingUSD}
              onChange={(e) => onUpdateProject({ feeListingAndMarketingUSD: parseFloat(e.target.value) || 0 })}
              className="w-full bg-[#141B2D] border border-slate-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none"
            />
          </div>

          <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
            <label className="text-slate-400 block text-[10px] uppercase mb-1">Advisory & Printing</label>
            <input
              type="number"
              step="0.1"
              value={project.feeAdvisoryUSD}
              onChange={(e) => onUpdateProject({ feeAdvisoryUSD: parseFloat(e.target.value) || 0 })}
              className="w-full bg-[#141B2D] border border-slate-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Syndicate Underwriting Table */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Syndicate Banking Roster & Fee Economics</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left text-slate-300">
            <thead className="bg-[#0B0F17] text-slate-400">
              <tr>
                <th className="p-2.5">Banking Institution</th>
                <th className="p-2.5">Role</th>
                <th className="p-2.5 text-right">Underwriting Commitment ($M)</th>
                <th className="p-2.5 text-right">Fee Share %</th>
                <th className="p-2.5 text-right font-bold text-cyan-300">Underwriting Economics ($M)</th>
                <th className="p-2.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {project.syndicate.map(bank => {
                const econ = Math.round((calc.underwritingFeesUSD * (bank.feeSharePercent / 100)) * 10) / 10;
                return (
                  <tr key={bank.id} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-bold text-slate-100">{bank.institutionName}</td>
                    <td className="p-2.5 text-slate-400">{bank.role}</td>
                    <td className="p-2.5 text-right">{(bank.commitmentShares / 1000000).toFixed(1)}M Shares</td>
                    <td className="p-2.5 text-right text-amber-300 font-bold">{bank.feeSharePercent}%</td>
                    <td className="p-2.5 text-right font-bold text-cyan-300">${econ}M</td>
                    <td className="p-2.5 text-center">
                      <button onClick={() => handleRemoveBank(bank.id)} className="text-rose-400 p-1">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Banking Institution */}
      <form onSubmit={handleAddBank} className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-3">
        <h3 className="font-bold text-xs text-slate-300 uppercase tracking-wider">Add Investment Banking Syndicate Member</h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono text-xs">
          <input
            type="text"
            placeholder="Bank Name (e.g. Goldman Sachs)"
            value={newBankName}
            onChange={(e) => setNewBankName(e.target.value)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          />
          <select
            value={newRole}
            onChange={(e) => setNewRole(e.target.value as any)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          >
            <option value="Lead Left Bookrunner">Lead Left Bookrunner</option>
            <option value="Joint Bookrunner">Joint Bookrunner</option>
            <option value="Co-Manager">Co-Manager</option>
            <option value="Syndicate Member">Syndicate Member</option>
          </select>
          <input
            type="number"
            placeholder="Fee Share %"
            value={newFeeShare}
            onChange={(e) => setNewFeeShare(parseFloat(e.target.value) || 0)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          />
          <button
            type="submit"
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-1.5 rounded transition flex items-center justify-center space-x-1"
          >
            <Plus className="w-4 h-4" />
            <span>Add Bank</span>
          </button>
        </div>
      </form>
    </div>
  );
};
