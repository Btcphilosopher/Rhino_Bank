import React, { useState } from 'react';
import { IPOProjectState, DigitalTwinCalculations, Shareholder } from '../../types/ipo';
import { Users, Plus, Trash2 } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const CapTablePanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  const [newShareholderName, setNewShareholderName] = useState('');
  const [newCategory, setNewCategory] = useState<Shareholder['category']>('Venture Capital');
  const [newShares, setNewShares] = useState(1000000);
  const [newVotingMult, setNewVotingMult] = useState(1);

  const handleAddShareholder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newShareholderName) return;

    const newSh: Shareholder = {
      id: `sh-${Date.now()}`,
      name: newShareholderName,
      category: newCategory,
      preShares: newShares,
      secondarySharesSold: 0,
      votingRightsMultiplier: newVotingMult
    };

    onUpdateProject({
      shareholders: [...project.shareholders, newSh]
    });

    setNewShareholderName('');
  };

  const handleRemoveShareholder = (id: string) => {
    onUpdateProject({
      shareholders: project.shareholders.filter(s => s.id !== id)
    });
  };

  const handleShareChange = (id: string, field: 'preShares' | 'secondarySharesSold' | 'votingRightsMultiplier', val: number) => {
    onUpdateProject({
      shareholders: project.shareholders.map(s => s.id === id ? { ...s, [field]: val } : s)
    });
  };

  // Calculate Voting Rights Total
  const totalVotingPower = project.shareholders.reduce((sum, s) => {
    const postShares = s.preShares - s.secondarySharesSold;
    return sum + (postShares * s.votingRightsMultiplier);
  }, 0) + project.newPrimaryShares + project.secondarySharesOffered; // 1 vote per public share

  return (
    <div className="space-y-6">
      {/* Cap Table Overview Banner */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <Users className="w-5 h-5 text-cyan-400" />
            <span>Capital Structure & Capitalisation Table</span>
          </h2>
          <p className="text-xs text-slate-400">Pre-IPO vs Post-IPO ownership %, Dilution, Economic & Dual-Class Voting Ownership.</p>
        </div>

        <div className="flex items-center space-x-4 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Pre-IPO Total Shares</span>
            <span className="font-bold text-slate-100 text-sm">{(calc.totalPreIpoShares / 1000000).toFixed(2)}M</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Post-IPO Total Shares</span>
            <span className="font-bold text-cyan-300 text-sm">{(calc.totalPostIpoShares / 1000000).toFixed(2)}M</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Public Dilution %</span>
            <span className="font-bold text-emerald-400 text-sm">{calc.dilutionPercent}%</span>
          </div>
        </div>
      </div>

      {/* Interactive Cap Table */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Detailed Shareholder Register</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left text-slate-300">
            <thead className="bg-[#0B0F17] text-slate-400">
              <tr>
                <th className="p-2.5">Shareholder</th>
                <th className="p-2.5">Category</th>
                <th className="p-2.5 text-right">Pre-IPO Shares</th>
                <th className="p-2.5 text-right">Pre Ownership %</th>
                <th className="p-2.5 text-right">Secondary Sold</th>
                <th className="p-2.5 text-right">Post-IPO Shares</th>
                <th className="p-2.5 text-right">Post Ownership %</th>
                <th className="p-2.5 text-right">Voting Power %</th>
                <th className="p-2.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {project.shareholders.map(sh => {
                const prePct = ((sh.preShares / calc.totalPreIpoShares) * 100).toFixed(1);
                const postShares = sh.preShares - sh.secondarySharesSold;
                const postPct = ((postShares / calc.totalPostIpoShares) * 100).toFixed(1);
                const votingPower = (((postShares * sh.votingRightsMultiplier) / totalVotingPower) * 100).toFixed(1);

                return (
                  <tr key={sh.id} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-bold text-slate-100">{sh.name}</td>
                    <td className="p-2.5 text-slate-400">{sh.category}</td>
                    <td className="p-2.5 text-right">
                      <input
                        type="number"
                        value={sh.preShares}
                        onChange={(e) => handleShareChange(sh.id, 'preShares', parseInt(e.target.value) || 0)}
                        className="w-28 bg-[#0B0F17] border border-slate-700 rounded px-2 py-0.5 text-right font-bold text-slate-100 focus:outline-none"
                      />
                    </td>
                    <td className="p-2.5 text-right text-cyan-300 font-bold">{prePct}%</td>
                    <td className="p-2.5 text-right">
                      <input
                        type="number"
                        value={sh.secondarySharesSold}
                        onChange={(e) => handleShareChange(sh.id, 'secondarySharesSold', parseInt(e.target.value) || 0)}
                        className="w-24 bg-[#0B0F17] border border-slate-700 rounded px-2 py-0.5 text-right text-rose-300 focus:outline-none"
                      />
                    </td>
                    <td className="p-2.5 text-right font-bold text-slate-100">{(postShares / 1000000).toFixed(2)}M</td>
                    <td className="p-2.5 text-right font-bold text-emerald-400">{postPct}%</td>
                    <td className="p-2.5 text-right font-bold text-amber-300">{votingPower}% ({sh.votingRightsMultiplier}x)</td>
                    <td className="p-2.5 text-center">
                      <button
                        onClick={() => handleRemoveShareholder(sh.id)}
                        className="text-rose-400 hover:text-rose-300 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}

              {/* New Public Shareholders Row */}
              <tr className="bg-cyan-950/20 font-bold text-cyan-300">
                <td className="p-2.5">NEW PUBLIC INVESTORS (Primary)</td>
                <td className="p-2.5">Public Market</td>
                <td className="p-2.5 text-right">-</td>
                <td className="p-2.5 text-right">0.0%</td>
                <td className="p-2.5 text-right">-</td>
                <td className="p-2.5 text-right">{(project.newPrimaryShares / 1000000).toFixed(2)}M</td>
                <td className="p-2.5 text-right text-emerald-300">{calc.dilutionPercent}%</td>
                <td className="p-2.5 text-right">{((project.newPrimaryShares / totalVotingPower) * 100).toFixed(1)}% (1x)</td>
                <td className="p-2.5 text-center">-</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Shareholder Form */}
      <form onSubmit={handleAddShareholder} className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-3">
        <h3 className="font-bold text-xs text-slate-300 uppercase tracking-wider">Add Pre-IPO Shareholder Entry</h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono text-xs">
          <input
            type="text"
            placeholder="Shareholder Name"
            value={newShareholderName}
            onChange={(e) => setNewShareholderName(e.target.value)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          />
          <select
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value as any)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          >
            <option value="Founders">Founders</option>
            <option value="Management">Management</option>
            <option value="Employees">Employees</option>
            <option value="Venture Capital">Venture Capital</option>
            <option value="Private Equity">Private Equity</option>
            <option value="Strategic Investors">Strategic Investors</option>
          </select>
          <input
            type="number"
            placeholder="Pre Shares"
            value={newShares}
            onChange={(e) => setNewShares(parseInt(e.target.value) || 0)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          />
          <button
            type="submit"
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-1.5 rounded transition flex items-center justify-center space-x-1"
          >
            <Plus className="w-4 h-4" />
            <span>Add Entry</span>
          </button>
        </div>
      </form>
    </div>
  );
};
