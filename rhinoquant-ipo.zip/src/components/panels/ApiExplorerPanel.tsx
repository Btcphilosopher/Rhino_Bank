import React, { useState } from 'react';
import { IPOProjectState } from '../../types/ipo';
import { Code, Send, CheckCircle2 } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
}

export const ApiExplorerPanel: React.FC<PanelProps> = ({ project }) => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<'/api/v1/projects' | '/simulate' | '/api/ai/advise'>('/simulate');
  const [responseJson, setResponseJson] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleTestApi = async () => {
    setIsLoading(true);
    try {
      if (selectedEndpoint === '/api/v1/projects') {
        const res = await fetch('/api/v1/projects');
        const data = await res.json();
        setResponseJson(JSON.stringify(data, null, 2));
      } else if (selectedEndpoint === '/simulate') {
        const res = await fetch(`/api/v1/projects/${project.id}/simulate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ projectState: project })
        });
        const data = await res.json();
        setResponseJson(JSON.stringify(data, null, 2));
      } else {
        const res = await fetch('/api/ai/advise', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            projectState: project,
            queryType: 'General Strategic Briefing'
          })
        });
        const data = await res.json();
        setResponseJson(JSON.stringify(data, null, 2));
      }
    } catch (err) {
      setResponseJson('API execution error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <Code className="w-5 h-5 text-cyan-400" />
            <span>Rhino Bank Programmatic REST API Explorer</span>
          </h2>
          <p className="text-xs text-slate-400">Institutional REST API endpoints for algorithmic bookbuilding, quantitative valuation & AI deal memos.</p>
        </div>

        <button
          onClick={handleTestApi}
          disabled={isLoading}
          className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-4 py-2 rounded text-xs transition shadow flex items-center space-x-1.5"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Execute Endpoint Call</span>
        </button>
      </div>

      {/* Endpoint Selection & Live JSON Response */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        {/* Endpoint List */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-3">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider font-sans">Available REST Endpoints</h3>

          {[
            { id: '/api/v1/projects', method: 'GET', title: 'List All IPO Projects' },
            { id: '/simulate', method: 'POST', title: 'Digital Twin Simulation' },
            { id: '/api/ai/advise', method: 'POST', title: 'Gemini 3.7 Deal Memo' }
          ].map((ep) => (
            <div
              key={ep.id}
              onClick={() => setSelectedEndpoint(ep.id as any)}
              className={`p-3 rounded-lg border cursor-pointer transition ${
                selectedEndpoint === ep.id
                  ? 'bg-cyan-950/60 border-cyan-400 text-cyan-300 font-bold'
                  : 'bg-[#0B0F17] border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center space-x-2">
                <span className={`px-1.5 py-0.5 rounded text-[10px] ${ep.method === 'GET' ? 'bg-emerald-950 text-emerald-300' : 'bg-cyan-950 text-cyan-300'}`}>
                  {ep.method}
                </span>
                <span className="truncate">{ep.title}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Live Payload & Output */}
        <div className="lg:col-span-2 bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-3">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider font-sans">Live JSON API Response Payload</h3>

          <div className="bg-[#0B0F17] p-4 rounded border border-slate-800 max-h-96 overflow-y-auto text-emerald-400 font-mono text-xs leading-relaxed">
            {isLoading ? (
              <span className="text-slate-500 animate-pulse">Executing HTTP request to Rhino Bank ECM Server...</span>
            ) : responseJson ? (
              <pre>{responseJson}</pre>
            ) : (
              <span className="text-slate-600">Click "Execute Endpoint Call" above to send request.</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
