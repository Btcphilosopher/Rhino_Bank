import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { ShieldAlert, Activity, TrendingUp, Sliders } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
  onScenarioChange: (scenario: IPOProjectState['currentScenario']) => void;
}

export const ScenarioAndMarketPanel: React.FC<PanelProps> = ({
  project,
  calc,
  onUpdateProject,
  onScenarioChange
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-cyan-400" />
            <span>Market Window Index & IPO Risk Radar</span>
          </h2>
          <p className="text-xs text-slate-400">Quantitative macro window readiness score & 6-factor integrated IPO risk model.</p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Market Window Index</span>
            <span className="font-bold text-emerald-400 text-sm">{calc.ipoMarketWindowScore} / 100 ({calc.marketWindowStatus})</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Integrated Risk Score</span>
            <span className="font-bold text-amber-300 text-sm">{calc.ipoRiskScore} / 100</span>
          </div>
        </div>
      </div>

      {/* Scenario Selector Panel */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Macro Scenario Matrix Switcher</h3>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 font-mono text-xs">
          {[
            { id: 'EXTREME_BEAR', label: 'Extreme Bear', desc: 'VIX 35+, Market Freeze, 35% Valuation Cut' },
            { id: 'BEAR', label: 'Bear Case', desc: 'VIX 25+, Soft Demand, 15% Valuation Cut' },
            { id: 'BASE', label: 'Base Case', desc: 'Standard Market Conditions & Multiples' },
            { id: 'BULL', label: 'Bull Case', desc: 'VIX <15, Strong Appetite, 15% Premium' },
            { id: 'EXTREME_BULL', label: 'Extreme Bull', desc: 'Tech Rally, 3x Oversubscribed, 30% Premium' }
          ].map((sc) => (
            <button
              key={sc.id}
              onClick={() => onScenarioChange(sc.id as any)}
              className={`p-3 rounded-lg border text-left transition ${
                project.currentScenario === sc.id
                  ? 'bg-cyan-950/60 border-cyan-400 text-cyan-300 font-bold shadow'
                  : 'bg-[#0B0F17] border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <span className="block text-xs uppercase font-bold text-slate-100">{sc.label}</span>
              <span className="text-[10px] font-sans text-slate-400 block mt-1 leading-tight">{sc.desc}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grid: Market Window Drivers vs IPO Risk Radar Factors */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* Left: Market Window Drivers */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider font-sans">Market Window Driver Parameters</h3>

          <div className="space-y-3">
            <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
              <label className="text-slate-400 block text-[10px] uppercase mb-1">CBOE Volatility Index (VIX)</label>
              <input
                type="number"
                value={project.marketConditions.equityVixIndex}
                onChange={(e) => onUpdateProject({
                  marketConditions: { ...project.marketConditions, equityVixIndex: parseFloat(e.target.value) || 0 }
                })}
                className="w-full bg-[#141B2D] border border-slate-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none"
              />
            </div>

            <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
              <label className="text-slate-400 block text-[10px] uppercase mb-1">Sector Index 3M Return %</label>
              <input
                type="number"
                value={project.marketConditions.sectorPerformance3M}
                onChange={(e) => onUpdateProject({
                  marketConditions: { ...project.marketConditions, sectorPerformance3M: parseFloat(e.target.value) || 0 }
                })}
                className="w-full bg-[#141B2D] border border-slate-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none"
              />
            </div>

            <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
              <label className="text-slate-400 block text-[10px] uppercase mb-1">10-Year Benchmark Interest Rate %</label>
              <input
                type="number"
                value={project.marketConditions.tenYearTreasuryRate}
                onChange={(e) => onUpdateProject({
                  marketConditions: { ...project.marketConditions, tenYearTreasuryRate: parseFloat(e.target.value) || 0 }
                })}
                className="w-full bg-[#141B2D] border border-slate-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Right: Integrated IPO Risk Breakdown */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider font-sans">Risk Factors Radar Breakdown</h3>

          <div className="space-y-3">
            {[
              { label: 'Valuation & Multiple Compression Risk', score: 25, color: 'bg-cyan-400' },
              { label: 'Public Dilution & Floating Volatility Risk', score: 35, color: 'bg-emerald-400' },
              { label: 'Macro Volatility / VIX Window Risk', score: Math.round(project.marketConditions.equityVixIndex * 2.2), color: 'bg-amber-400' },
              { label: 'Lockup Expiry Selling Pressure Risk', score: 40, color: 'bg-purple-400' },
              { label: 'Top 10 Institutional Concentration Risk', score: 30, color: 'bg-blue-400' }
            ].map(rf => (
              <div key={rf.label} className="bg-[#0B0F17] p-3 rounded border border-slate-800 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-300 font-semibold">{rf.label}</span>
                  <span className="font-bold text-slate-100">{rf.score} / 100</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                  <div className={`h-full ${rf.color}`} style={{ width: `${rf.score}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
