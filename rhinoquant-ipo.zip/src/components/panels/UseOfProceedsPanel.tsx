import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { PieChart as PieIcon, DollarSign } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const UseOfProceedsPanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  const COLORS = ['#00F2FE', '#00E676', '#FFB800', '#FF3366', '#A855F7'];

  const handleProceedsChange = (field: keyof IPOProjectState['useOfProceeds'], val: number) => {
    onUpdateProject({
      useOfProceeds: {
        ...project.useOfProceeds,
        [field]: val
      }
    });
  };

  const chartData = [
    { name: 'R&D / AI Infrastructure', value: project.useOfProceeds.rdPercent },
    { name: 'Sales & Global Marketing', value: project.useOfProceeds.salesMarketingPercent },
    { name: 'Debt Refinancing & Deleveraging', value: project.useOfProceeds.debtPaydownPercent },
    { name: 'Strategic M&A Expansion', value: project.useOfProceeds.maExpansionPercent },
    { name: 'General Working Capital', value: project.useOfProceeds.workingCapitalPercent }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <PieIcon className="w-5 h-5 text-cyan-400" />
            <span>Management Use of Proceeds Allocator</span>
          </h2>
          <p className="text-xs text-slate-400">Model capital allocation across primary growth initiatives and debt paydown.</p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Net Primary Proceeds</span>
            <span className="font-bold text-emerald-400 text-sm">${calc.netPrimaryProceeds}M</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Pro-Forma Post Cash</span>
            <span className="font-bold text-cyan-300 text-sm">${calc.proFormaCashPostIpo}M</span>
          </div>
        </div>
      </div>

      {/* Grid: Donut Chart vs Sliders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Donut Chart */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Net Proceeds Capital Allocation ($M)</h3>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0B0F17', borderColor: '#334155', borderRadius: '6px', color: '#F1F5F9' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            {chartData.map((item, idx) => (
              <div key={item.name} className="flex items-center space-x-2 bg-[#0B0F17] p-2 rounded border border-slate-800">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx] }} />
                <div className="truncate">
                  <span className="text-slate-300 block text-[10px] truncate">{item.name}</span>
                  <span className="font-bold text-slate-100">{item.value}% (${Math.round(calc.netPrimaryProceeds * (item.value / 100))}M)</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Allocation Sliders */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider font-sans">Adjust Allocation % Sliders</h3>

          {[
            { key: 'rdPercent', label: 'R&D / AI Infrastructure' },
            { key: 'salesMarketingPercent', label: 'Sales & Global Marketing' },
            { key: 'debtPaydownPercent', label: 'Debt Refinancing' },
            { key: 'maExpansionPercent', label: 'Strategic M&A' },
            { key: 'workingCapitalPercent', label: 'General Working Capital' }
          ].map((field) => (
            <div key={field.key} className="bg-[#0B0F17] p-3 rounded border border-slate-800 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-300 font-bold">{field.label}:</span>
                <span className="text-cyan-300 font-bold">{project.useOfProceeds[field.key as keyof IPOProjectState['useOfProceeds']]}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={project.useOfProceeds[field.key as keyof IPOProjectState['useOfProceeds']]}
                onChange={(e) => handleProceedsChange(field.key as any, parseFloat(e.target.value) || 0)}
                className="w-full accent-cyan-400 bg-slate-800 rounded cursor-pointer h-2"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
