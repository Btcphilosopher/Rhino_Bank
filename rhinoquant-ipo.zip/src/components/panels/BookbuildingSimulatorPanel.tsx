import React, { useState } from 'react';
import { IPOProjectState, DigitalTwinCalculations, SyntheticInvestor } from '../../types/ipo';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Activity, Plus, Trash2, Users } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const BookbuildingSimulatorPanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  const [newInvName, setNewInvName] = useState('');
  const [newInvCategory, setNewInvCategory] = useState<SyntheticInvestor['category']>('MUTUAL_FUNDS');
  const [newMaxAlloc, setNewMaxAlloc] = useState(200);
  const [newTargetPrice, setNewTargetPrice] = useState(calc.finalOfferPrice + 2);

  const handleAddOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newInvName) return;

    const newInv: SyntheticInvestor = {
      id: `inv-${Date.now()}`,
      name: newInvName,
      category: newInvCategory,
      maxAllocationUSD: newMaxAlloc,
      targetPriceUSD: newTargetPrice,
      priceSensitivity: 0.25,
      tier: 'Tier 2 Quality',
      requestedShares: Math.round((newMaxAlloc * 1000000) / newTargetPrice),
      status: 'Active'
    };

    onUpdateProject({
      investorBook: [...project.investorBook, newInv]
    });

    setNewInvName('');
  };

  const handleRemoveOrder = (id: string) => {
    onUpdateProject({
      investorBook: project.investorBook.filter(i => i.id !== id)
    });
  };

  // Generate Price vs Demand Curve series
  const pricePoints = [30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50];
  const demandCurveData = pricePoints.map(p => {
    let totalSharesAtPrice = 0;
    project.investorBook.forEach(inv => {
      const priceDiffRatio = (inv.targetPriceUSD - p) / inv.targetPriceUSD;
      let elasticityFactor = 1 + (priceDiffRatio * inv.priceSensitivity * 2);
      elasticityFactor = Math.max(0.0, Math.min(2.0, elasticityFactor));
      totalSharesAtPrice += Math.round(inv.requestedShares * elasticityFactor);
    });

    const sharesOffered = project.newPrimaryShares + project.secondarySharesOffered;
    return {
      price: `$${p}`,
      demandSharesM: Math.round((totalSharesAtPrice / 1000000) * 10) / 10,
      offeredSharesM: Math.round((sharesOffered / 1000000) * 10) / 10,
      oversubscription: Math.round((totalSharesAtPrice / Math.max(1, sharesOffered)) * 10) / 10
    };
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <span>Institutional Order Bookbuilding Simulator</span>
          </h2>
          <p className="text-xs text-slate-400">Orderbook aggregation across Long-Only, Mutual Funds, Pension, SWFs, Hedge Funds & Retail.</p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Total Book Demand</span>
            <span className="font-bold text-cyan-300 text-sm">${calc.totalBookDemandUSD.toLocaleString()}M</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Oversubscription</span>
            <span className="font-bold text-amber-300 text-sm">{calc.oversubscriptionRatio}x</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Equilibrium Price</span>
            <span className="font-bold text-emerald-400 text-sm">${calc.equilibriumPriceUSD}</span>
          </div>
        </div>
      </div>

      {/* Demand Curve Chart (Price vs Demand) */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Price Elasticity & Investor Demand Curve (Millions of Shares)</h3>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={demandCurveData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
              <XAxis dataKey="price" stroke="#64748B" fontSize={11} />
              <YAxis stroke="#64748B" fontSize={11} />
              <Tooltip contentStyle={{ backgroundColor: '#0B0F17', borderColor: '#334155', borderRadius: '6px', color: '#F1F5F9' }} />
              <Line type="monotone" dataKey="demandSharesM" stroke="#00F2FE" strokeWidth={3} name="Total Investor Demand (M Shares)" />
              <Line type="monotone" dataKey="offeredSharesM" stroke="#FFB800" strokeWidth={2} strokeDasharray="5 5" name="Shares Offered (Supply)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Institutional Investor Orderbook Table */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Institutional Order Book Register</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left text-slate-300">
            <thead className="bg-[#0B0F17] text-slate-400">
              <tr>
                <th className="p-2.5">Investor Name</th>
                <th className="p-2.5">Category</th>
                <th className="p-2.5">Tier</th>
                <th className="p-2.5 text-right">Max Alloc ($M)</th>
                <th className="p-2.5 text-right">Target Limit ($)</th>
                <th className="p-2.5 text-right">Order Shares</th>
                <th className="p-2.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {project.investorBook.map(inv => (
                <tr key={inv.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-slate-100">{inv.name}</td>
                  <td className="p-2.5 text-slate-400">{inv.category}</td>
                  <td className="p-2.5 font-semibold text-cyan-300">{inv.tier}</td>
                  <td className="p-2.5 text-right">${inv.maxAllocationUSD}M</td>
                  <td className="p-2.5 text-right text-emerald-400 font-bold">${inv.targetPriceUSD}</td>
                  <td className="p-2.5 text-right font-bold text-slate-100">{(inv.requestedShares / 1000000).toFixed(2)}M</td>
                  <td className="p-2.5 text-center">
                    <button onClick={() => handleRemoveOrder(inv.id)} className="text-rose-400 p-1">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Submit Synthetic Order Form */}
      <form onSubmit={handleAddOrder} className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-3">
        <h3 className="font-bold text-xs text-slate-300 uppercase tracking-wider">Inject Synthetic Institutional Order</h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono text-xs">
          <input
            type="text"
            placeholder="Institutional Name (e.g. Wellington)"
            value={newInvName}
            onChange={(e) => setNewInvName(e.target.value)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          />
          <select
            value={newInvCategory}
            onChange={(e) => setNewInvCategory(e.target.value as any)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          >
            <option value="LONG_ONLY">LONG_ONLY</option>
            <option value="MUTUAL_FUNDS">MUTUAL_FUNDS</option>
            <option value="PENSION_FUNDS">PENSION_FUNDS</option>
            <option value="SOVEREIGN_WEALTH">SOVEREIGN_WEALTH</option>
            <option value="HEDGE_FUNDS">HEDGE_FUNDS</option>
            <option value="FAMILY_OFFICE">FAMILY_OFFICE</option>
            <option value="RETAIL">RETAIL</option>
          </select>
          <input
            type="number"
            placeholder="Max Allocation ($M)"
            value={newMaxAlloc}
            onChange={(e) => setNewMaxAlloc(parseFloat(e.target.value) || 0)}
            className="bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:outline-none"
          />
          <button
            type="submit"
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-1.5 rounded transition flex items-center justify-center space-x-1"
          >
            <Plus className="w-4 h-4" />
            <span>Inject Order</span>
          </button>
        </div>
      </form>
    </div>
  );
};
