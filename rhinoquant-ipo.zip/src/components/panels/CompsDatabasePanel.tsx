import React, { useState } from 'react';
import { TRADING_COMPS_DATABASE, HISTORICAL_IPOS_DATABASE } from '../../data/mockDatabase';
import { Database, Search, Filter } from 'lucide-react';

export const CompsDatabasePanel: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sectorFilter, setSectorFilter] = useState('ALL');

  const filteredComps = TRADING_COMPS_DATABASE.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) || c.ticker.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSector = sectorFilter === 'ALL' || c.sector === sectorFilter;
    return matchesSearch && matchesSector;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <Database className="w-5 h-5 text-cyan-400" />
            <span>Institutional Comparables & Historical IPO Research Database</span>
          </h2>
          <p className="text-xs text-slate-400">Searchable public market peer multiples database & historical IPO cohort performance backtesting.</p>
        </div>

        {/* Filter Inputs */}
        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="flex items-center space-x-2 bg-[#0B0F17] px-3 py-1.5 rounded border border-slate-700">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search ticker or name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-slate-100 focus:outline-none w-36"
            />
          </div>

          <select
            value={sectorFilter}
            onChange={(e) => setSectorFilter(e.target.value)}
            className="bg-[#0B0F17] border border-slate-700 text-slate-200 text-xs rounded px-3 py-1.5 focus:outline-none"
          >
            <option value="ALL">All Sectors</option>
            <option value="Enterprise Software / AI">Enterprise Software / AI</option>
            <option value="Fintech & Payments">Fintech & Payments</option>
            <option value="CleanTech & Energy">CleanTech & Energy</option>
          </select>
        </div>
      </div>

      {/* Trading Comps Table */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Public Peer Group Multiples</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left text-slate-300">
            <thead className="bg-[#0B0F17] text-slate-400">
              <tr>
                <th className="p-2.5">Company</th>
                <th className="p-2.5">Ticker</th>
                <th className="p-2.5">Sector</th>
                <th className="p-2.5 text-right">EV / Rev</th>
                <th className="p-2.5 text-right">EV / EBITDA</th>
                <th className="p-2.5 text-right">P / E</th>
                <th className="p-2.5 text-right">FCF Yield %</th>
                <th className="p-2.5 text-right">Rev Growth %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredComps.map(c => (
                <tr key={c.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-slate-100">{c.name}</td>
                  <td className="p-2.5 font-mono text-cyan-300 font-bold">{c.ticker}</td>
                  <td className="p-2.5 text-slate-400">{c.sector}</td>
                  <td className="p-2.5 text-right text-cyan-300 font-bold">{c.evRevenue}x</td>
                  <td className="p-2.5 text-right text-emerald-300">{c.evEbitda}x</td>
                  <td className="p-2.5 text-right">{c.pe}x</td>
                  <td className="p-2.5 text-right">{c.fcfYield}%</td>
                  <td className="p-2.5 text-right text-amber-300">+{c.revenueGrowth}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
