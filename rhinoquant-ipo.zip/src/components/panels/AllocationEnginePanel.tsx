import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { Briefcase, Sliders, ShieldCheck } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const AllocationEnginePanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-cyan-400" />
            <span>Rule-Based Syndicate Allocation Engine</span>
          </h2>
          <p className="text-xs text-slate-400">Allocate bookdemand using institutional allocation rules & monitor investor quality concentration.</p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Herfindahl Concentration (HHI)</span>
            <span className="font-bold text-cyan-300 text-sm">{calc.top10InvestorConcentrationIndex}</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Tier 1 Quality Ratio</span>
            <span className="font-bold text-emerald-400 text-sm">82.4%</span>
          </div>
        </div>
      </div>

      {/* Strategy Selector Controls */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Select Allocation Strategy Rule Set</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { id: 'LONG_ONLY_BIAS', label: 'Long-Only Bias', desc: 'Prioritize pension, SWFs, & long-term mutual funds to reduce aftermarket volatility.' },
            { id: 'PRO_RATA', label: 'Pro-Rata Equal', desc: 'Allocate strictly proportional to order size without qualitative tiering.' },
            { id: 'QUALITY_TIER_MAX', label: 'Quality Tier Max', desc: 'Maximize allocation to Tier 1 quality investors, scalping low-tier hedge funds.' },
            { id: 'BALANCED_STAKEHOLDER', label: 'Balanced Stakeholder', desc: 'Mix strategic anchors, long-only funds, and 10% retail tranche.' }
          ].map((strat) => (
            <div
              key={strat.id}
              onClick={() => onUpdateProject({ allocationStrategy: strat.id as any })}
              className={`p-4 rounded-lg border cursor-pointer transition ${
                project.allocationStrategy === strat.id
                  ? 'bg-cyan-950/50 border-cyan-400 shadow-md'
                  : 'bg-[#0B0F17] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-100 text-xs font-mono">{strat.label}</span>
                {project.allocationStrategy === strat.id && <ShieldCheck className="w-4 h-4 text-cyan-400" />}
              </div>
              <p className="text-[11px] text-slate-400 mt-2 font-sans">{strat.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Allocation Breakdown Table */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Investor Allocation Table ($M & Shares)</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left text-slate-300">
            <thead className="bg-[#0B0F17] text-slate-400">
              <tr>
                <th className="p-2.5">Investor Name</th>
                <th className="p-2.5">Category</th>
                <th className="p-2.5">Tier</th>
                <th className="p-2.5 text-right">Requested ($M)</th>
                <th className="p-2.5 text-right">Allocated Shares (M)</th>
                <th className="p-2.5 text-right font-bold text-cyan-300">Allocated Value ($M)</th>
                <th className="p-2.5 text-right">Fill Rate %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {calc.allocatedInvestors.map(inv => {
                const requestedVal = inv.maxAllocationUSD;
                const fillRate = requestedVal > 0 ? ((inv.allocatedUSD / requestedVal) * 100).toFixed(1) : '0';

                return (
                  <tr key={inv.id} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-bold text-slate-100">{inv.name}</td>
                    <td className="p-2.5 text-slate-400">{inv.category}</td>
                    <td className="p-2.5 font-semibold text-cyan-300">{inv.tier}</td>
                    <td className="p-2.5 text-right">${requestedVal}M</td>
                    <td className="p-2.5 text-right font-bold text-slate-100">{(inv.allocatedShares / 1000000).toFixed(2)}M</td>
                    <td className="p-2.5 text-right font-bold text-cyan-300">${inv.allocatedUSD}M</td>
                    <td className="p-2.5 text-right text-emerald-400 font-bold">{fillRate}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
