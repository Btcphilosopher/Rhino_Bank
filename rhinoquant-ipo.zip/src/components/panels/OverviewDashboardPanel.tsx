import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { 
  Building2, 
  DollarSign, 
  TrendingUp, 
  ShieldAlert, 
  Activity, 
  Users, 
  Layers, 
  PieChart, 
  ArrowRight,
  Sparkles
} from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onNavigateTab: (tabId: string) => void;
}

export const OverviewDashboardPanel: React.FC<PanelProps> = ({ project, calc, onNavigateTab }) => {
  return (
    <div className="space-y-6">
      {/* Deal Overview Banner */}
      <div className="bg-[#0E1013] p-5 rounded-lg border border-slate-800 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Building2 className="w-64 h-64 text-blue-400" />
        </div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center space-x-3">
              <span className="bg-blue-600 text-white font-bold px-2 py-0.5 rounded text-xs font-mono tracking-wider">
                {project.proposedExchange}: {project.proposedTicker}
              </span>
              <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono border border-slate-700">
                {project.jurisdiction} ({project.currency})
              </span>
              <span className="text-xs bg-green-950 text-green-300 border border-green-800 px-2 py-0.5 rounded font-semibold font-mono">
                Target Date: {project.ipoDate}
              </span>
            </div>
            <h1 className="text-xl font-bold text-white mt-2 uppercase tracking-wide">{project.companyName}</h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">{project.notes}</p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => onNavigateTab('bookbuilding')}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded text-xs transition shadow flex items-center space-x-1.5"
            >
              <Activity className="w-4 h-4" />
              <span>Simulate Bookbuilding</span>
            </button>
            <button
              onClick={() => onNavigateTab('valuation')}
              className="bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold px-4 py-2 rounded text-xs transition border border-slate-700 flex items-center space-x-1.5"
            >
              <Layers className="w-4 h-4 text-blue-400" />
              <span>Adjust Valuation</span>
            </button>
          </div>
        </div>

        {/* Executive Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mt-5 pt-5 border-t border-slate-800 font-mono text-xs">
          <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Post-Money Value</span>
            <span className="text-base font-bold text-blue-400">${calc.postMoneyEquityValue.toLocaleString()}M</span>
            <span className="text-[10px] text-slate-500 block">Pre: ${calc.preMoneyEquityValue.toLocaleString()}M</span>
          </div>

          <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Final Offer Price</span>
            <span className="text-base font-bold text-green-500">${calc.finalOfferPrice}</span>
            <span className="text-[10px] text-slate-500 block">Indicative: ${calc.indicativePriceMid}</span>
          </div>

          <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Gross Proceeds</span>
            <span className="text-base font-bold text-white">${calc.totalGrossProceeds}M</span>
            <span className="text-[10px] text-slate-500 block">Net Prim: ${calc.netPrimaryProceeds}M</span>
          </div>

          <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Book Oversubscribed</span>
            <span className="text-base font-bold text-blue-400">{calc.oversubscriptionRatio}x</span>
            <span className="text-[10px] text-slate-500 block">Demand: ${calc.totalBookDemandUSD}M</span>
          </div>

          <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Free Float %</span>
            <span className="text-base font-bold text-blue-300">{calc.postIpoPublicFreeFloatPercent}%</span>
            <span className="text-[10px] text-slate-500 block">Dilution: {calc.dilutionPercent}%</span>
          </div>

          <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Market Window Score</span>
            <span className={`text-base font-bold ${calc.ipoMarketWindowScore >= 75 ? 'text-green-500' : 'text-amber-400'}`}>
              {calc.ipoMarketWindowScore}/100
            </span>
            <span className="text-[10px] text-slate-500 block">{calc.marketWindowStatus}</span>
          </div>

          <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Integrated IPO Risk</span>
            <span className="text-base font-bold text-rose-400">{calc.ipoRiskScore}/100</span>
            <span className="text-[10px] text-slate-500 block">Low-Med Risk</span>
          </div>
        </div>
      </div>

      {/* Requirement #21: IPO DIGITAL TWIN FLOW MAP */}
      <div className="bg-[#0E1013] rounded-lg border border-slate-800 shadow-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 bg-[#15181D] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <h2 className="font-bold text-xs text-white uppercase tracking-wider">IPO Digital Twin Reactive Architecture</h2>
          </div>
          <span className="text-[10px] font-mono text-blue-400 bg-blue-900/40 border border-blue-800 px-2 py-0.5 rounded">
            27 Live Engines Linked
          </span>
        </div>

        {/* Visual Flow Pipeline */}
        <div className="p-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-10 gap-2 font-mono text-[11px] text-center">
          {[
            { label: 'Company', sub: project.sector.split(' ')[0], bg: 'border-slate-800' },
            { label: 'Forecast', sub: `${project.forecastAssumptions.horizonYears}Y Horizon`, bg: 'border-blue-900' },
            { label: 'DCF Value', sub: `$${calc.dcfEquityValue}M`, bg: 'border-blue-800' },
            { label: 'Comps Value', sub: `$${calc.compsImpliedEquityValue}M`, bg: 'border-blue-800' },
            { label: 'Cap Table', sub: `${calc.totalPreIpoShares/1000000}M Shares`, bg: 'border-slate-700' },
            { label: 'Offer Size', sub: `$${calc.totalGrossProceeds}M`, bg: 'border-slate-700' },
            { label: 'Demand', sub: `${calc.oversubscriptionRatio}x Book`, bg: 'border-amber-900' },
            { label: 'Offer Price', sub: `$${calc.finalOfferPrice}`, bg: 'border-green-900' },
            { label: 'Allocation', sub: `${project.allocationStrategy}`, bg: 'border-green-800' },
            { label: 'Aftermarket', sub: `+${calc.aftermarketTrajectory[0]?.returnPercent}% D1`, bg: 'border-purple-900' }
          ].map((item, idx) => (
            <div key={idx} className={`bg-[#0A0B0D] p-2 rounded border ${item.bg} flex flex-col justify-between h-20 shadow-sm`}>
              <span className="text-slate-500 text-[9px] uppercase font-bold">{idx + 1}. {item.label}</span>
              <span className="text-blue-400 font-bold text-xs my-0.5">{item.sub}</span>
              <span className="text-[8px] text-slate-600">→ Linked</span>
            </div>
          ))}
        </div>
      </div>

      {/* Grid Layout: Valuation Football Field vs Syndicate & Bookbuilding Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Valuation Methods Football Field */}
        <div className="bg-[#0E1013] rounded-lg border border-slate-800 shadow-2xl overflow-hidden space-y-0">
          <div className="px-4 py-3 border-b border-slate-800 bg-[#15181D] flex items-center justify-between">
            <h3 className="font-bold text-xs text-white uppercase tracking-wider">Valuation Methodology Comparison ($M)</h3>
            <button onClick={() => onNavigateTab('valuation')} className="text-xs text-blue-400 hover:underline flex items-center space-x-1 font-mono">
              <span>Detailed Model</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="p-4 space-y-4 font-mono text-xs">
            {/* DCF Valuation */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>DCF (WACC {project.dcfInputs.waccPercent}%, g {project.dcfInputs.terminalGrowthRatePercent}%)</span>
                <span className="font-bold text-blue-400">${calc.dcfEquityValue}M</span>
              </div>
              <div className="w-full bg-[#0A0B0D] h-3 rounded overflow-hidden p-0.5 border border-slate-800">
                <div className="bg-blue-600 h-full rounded" style={{ width: `${Math.min(100, (calc.dcfEquityValue / (calc.postMoneyEquityValue * 1.3)) * 100)}%` }} />
              </div>
            </div>

            {/* Trading Comps */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Trading Comparables ({calc.medianEvRevenue}x EV/Rev, {calc.medianEvEbitda}x EV/EBITDA)</span>
                <span className="font-bold text-blue-300">${calc.compsImpliedEquityValue}M</span>
              </div>
              <div className="w-full bg-[#0A0B0D] h-3 rounded overflow-hidden p-0.5 border border-slate-800">
                <div className="bg-slate-600 h-full rounded" style={{ width: `${Math.min(100, (calc.compsImpliedEquityValue / (calc.postMoneyEquityValue * 1.3)) * 100)}%` }} />
              </div>
            </div>

            {/* Post-Money Valuation */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="text-green-400 font-bold">Target Post-Money Offer Valuation (at ${calc.finalOfferPrice})</span>
                <span className="font-bold text-green-500">${calc.postMoneyEquityValue}M</span>
              </div>
              <div className="w-full bg-[#0A0B0D] h-3 rounded overflow-hidden p-0.5 border border-slate-800">
                <div className="bg-green-500 h-full rounded" style={{ width: `${Math.min(100, (calc.postMoneyEquityValue / (calc.postMoneyEquityValue * 1.3)) * 100)}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Bookbuilding & Syndicate Summary */}
        <div className="bg-[#0E1013] rounded-lg border border-slate-800 shadow-2xl overflow-hidden space-y-0">
          <div className="px-4 py-3 border-b border-slate-800 bg-[#15181D] flex items-center justify-between">
            <h3 className="font-bold text-xs text-white uppercase tracking-wider">Syndicate & Bookbuild Status</h3>
            <button onClick={() => onNavigateTab('syndicate_fees')} className="text-xs text-blue-400 hover:underline flex items-center space-x-1 font-mono">
              <span>Syndicate Desk</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="p-4 space-y-3 font-mono text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Global Coordinator</span>
                <span className="font-bold text-white">{project.syndicate[0]?.institutionName}</span>
                <span className="text-blue-400 block mt-1">{project.syndicate[0]?.feeSharePercent}% Underwriting Fee</span>
              </div>

              <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Total Syndicate Members</span>
                <span className="font-bold text-white">{project.syndicate.length} Banking Houses</span>
                <span className="text-green-500 block mt-1">${calc.totalTransactionFees}M Total Fees</span>
              </div>
            </div>

            <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Anchor Investor Coverage:</span>
                <span className="font-bold text-green-500">100% Covered (Tier 1 Quality)</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Top 10 Concentration Index:</span>
                <span className="font-bold text-blue-400">{calc.top10InvestorConcentrationIndex} HHI</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
