import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { TrendingUp, ShieldCheck, DollarSign } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const AftermarketAndGreenshoePanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-cyan-400" />
            <span>Aftermarket Performance & Greenshoe Overallotment Engine</span>
          </h2>
          <p className="text-xs text-slate-400">Model post-IPO 365-day price trajectories & syndicate price stabilization mechanics.</p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">1-Day IPO Pop</span>
            <span className="font-bold text-emerald-400 text-sm">+{calc.aftermarketTrajectory[0]?.returnPercent}%</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Greenshoe Size (15%)</span>
            <span className="font-bold text-cyan-300 text-sm">${calc.greenshoeOptionUSD}M</span>
          </div>
        </div>
      </div>

      {/* 365-Day Price Trajectory Chart */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Simulated 365-Day Post-IPO Trading Trajectory ($ / Share)</h3>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={calc.aftermarketTrajectory}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
              <XAxis dataKey="day" stroke="#64748B" fontSize={11} />
              <YAxis stroke="#64748B" fontSize={11} />
              <Tooltip contentStyle={{ backgroundColor: '#0B0F17', borderColor: '#334155', borderRadius: '6px', color: '#F1F5F9' }} />
              <Line type="monotone" dataKey="simulatedPrice" stroke="#00F2FE" strokeWidth={3} name="Simulated Share Price ($)" />
              <Line type="monotone" dataKey="benchmarkingPrice" stroke="#64748B" strokeWidth={2} strokeDasharray="5 5" name="Benchmark Sector Index ($)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Grid: Greenshoe Parameters vs Lockup Expiry Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* Left: Greenshoe Overallotment Control */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider font-sans">Greenshoe Overallotment Option Parameters</h3>

          <div className="space-y-3">
            <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
              <label className="text-slate-400 block text-[10px] uppercase mb-1">Greenshoe Option Size % (Max 15%)</label>
              <input
                type="number"
                value={project.greenshoeOptionPercent}
                onChange={(e) => onUpdateProject({ greenshoeOptionPercent: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#141B2D] border border-slate-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none"
              />
            </div>

            <div className="bg-[#0B0F17] p-3 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Additional Shares Issued:</span>
                <span className="font-bold text-slate-100">{(calc.greenshoeShares / 1000000).toFixed(2)}M Shares</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Additional Capital Raised:</span>
                <span className="font-bold text-emerald-400">${calc.greenshoeOptionUSD}M</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Lockup Expiry Analysis */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider font-sans">Lockup Expiry Selling Pressure Timeline</h3>

          <div className="space-y-3">
            <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
              <div className="flex justify-between border-b border-slate-800 pb-1">
                <span className="text-slate-400">Lockup Period:</span>
                <span className="font-bold text-cyan-300">{project.lockupPeriodDays} Days (180 Days Standard)</span>
              </div>
              <div className="flex justify-between pt-1">
                <span className="text-slate-400">Shares Subject to Lockup:</span>
                <span className="font-bold text-amber-300">{(calc.totalPreIpoShares / 1000000).toFixed(2)}M Shares</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Upon Day 180 expiry, lockup releases up to <strong>{((calc.totalPreIpoShares / calc.totalPostIpoShares) * 100).toFixed(1)}%</strong> of total company shares to public trading. Syndicate price stabilization algorithms reduce expected supply shock via phased trading volume absorption.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
