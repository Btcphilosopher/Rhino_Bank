import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { GitCompare, Sliders } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const ValuationRangePanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  const lowMultiplier = 0.82;
  const baseMultiplier = 1.0;
  const highMultiplier = 1.18;

  const cases = [
    { name: 'LOW CASE (Bearish)', mult: lowMultiplier, color: 'border-rose-800 bg-rose-950/20 text-rose-300' },
    { name: 'BASE CASE (Target)', mult: baseMultiplier, color: 'border-cyan-500 bg-[#141B2D] text-cyan-300' },
    { name: 'HIGH CASE (Bullish)', mult: highMultiplier, color: 'border-emerald-800 bg-emerald-950/20 text-emerald-300' }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800">
        <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2 mb-1">
          <GitCompare className="w-5 h-5 text-cyan-400" />
          <span>Institutional Valuation Range Engine</span>
        </h2>
        <p className="text-xs text-slate-400">Low, Base, and High case valuation spectrum across Enterprise, Equity, Pre-Money, Post-Money and Fully Diluted Values.</p>
      </div>

      {/* Case Comparison Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {cases.map((c) => {
          const preVal = Math.round(calc.preMoneyEquityValue * c.mult);
          const postVal = Math.round(calc.postMoneyEquityValue * c.mult);
          const evVal = Math.round(calc.enterpriseValue * c.mult);
          const price = (calc.finalOfferPrice * c.mult).toFixed(2);
          const fullyDilutedVal = Math.round(postVal * 1.05); // including unexercised options

          return (
            <div key={c.name} className={`p-5 rounded-xl border ${c.color} shadow-lg space-y-4`}>
              <h3 className="font-bold text-sm uppercase font-mono tracking-wider">{c.name}</h3>

              <div className="space-y-2 font-mono text-xs">
                <div className="flex justify-between border-b border-slate-800/80 pb-1">
                  <span className="text-slate-400">Offer Price / Share:</span>
                  <span className="font-bold text-base">${price}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800/80 pb-1">
                  <span className="text-slate-400">Pre-Money Equity:</span>
                  <span className="font-bold">${preVal.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between border-b border-slate-800/80 pb-1">
                  <span className="text-slate-400">Post-Money Equity:</span>
                  <span className="font-bold">${postVal.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between border-b border-slate-800/80 pb-1">
                  <span className="text-slate-400">Enterprise Value:</span>
                  <span className="font-bold">${evVal.toLocaleString()}M</span>
                </div>
                <div className="flex justify-between pt-1">
                  <span className="text-slate-400">Fully Diluted Value:</span>
                  <span className="font-bold">${fullyDilutedVal.toLocaleString()}M</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Football Field Visual Range Chart */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Valuation Range Football Field Chart ($M Equity Value)</h3>
        
        <div className="space-y-4 font-mono text-xs">
          {/* DCF Range */}
          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>DCF Valuation Range ($WACC 8.5% - 10.5%)</span>
              <span className="text-cyan-300 font-bold">${Math.round(calc.dcfEquityValue * 0.85)}M - ${Math.round(calc.dcfEquityValue * 1.15)}M</span>
            </div>
            <div className="w-full bg-[#0B0F17] h-4 rounded overflow-hidden relative border border-slate-800">
              <div 
                className="bg-gradient-to-r from-cyan-600 to-cyan-400 h-full rounded absolute" 
                style={{ left: '25%', width: '45%' }}
              />
            </div>
          </div>

          {/* Trading Comps Range */}
          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>Peer Trading Comps Multiple Range (12x - 22x EV/Rev)</span>
              <span className="text-blue-300 font-bold">${Math.round(calc.compsImpliedEquityValue * 0.8)}M - ${Math.round(calc.compsImpliedEquityValue * 1.2)}M</span>
            </div>
            <div className="w-full bg-[#0B0F17] h-4 rounded overflow-hidden relative border border-slate-800">
              <div 
                className="bg-gradient-to-r from-blue-600 to-blue-400 h-full rounded absolute" 
                style={{ left: '20%', width: '55%' }}
              />
            </div>
          </div>

          {/* Target IPO Pricing Range */}
          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span className="text-emerald-300 font-bold">Rhino Bank Indicative IPO Offer Price Range</span>
              <span className="text-emerald-400 font-bold">${calc.indicativePriceLow} - ${calc.indicativePriceHigh} / share</span>
            </div>
            <div className="w-full bg-[#0B0F17] h-4 rounded overflow-hidden relative border border-slate-800">
              <div 
                className="bg-gradient-to-r from-emerald-600 to-emerald-400 h-full rounded absolute shadow-lg" 
                style={{ left: '35%', width: '30%' }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
