import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { TRADING_COMPS_DATABASE, HISTORICAL_IPOS_DATABASE } from '../../data/mockDatabase';
import { Layers, CheckSquare, Square } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const ValuationEnginePanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  const toggleCompSelection = (id: string) => {
    const current = [...project.selectedCompIds];
    const exists = current.includes(id);
    const updated = exists ? current.filter(c => c !== id) : [...current, id];
    onUpdateProject({ selectedCompIds: updated });
  };

  // Generate 2D Sensitivity Table for WACC vs Terminal Growth Rate
  const waccSteps = [project.dcfInputs.waccPercent - 1.0, project.dcfInputs.waccPercent - 0.5, project.dcfInputs.waccPercent, project.dcfInputs.waccPercent + 0.5, project.dcfInputs.waccPercent + 1.0];
  const gSteps = [project.dcfInputs.terminalGrowthRatePercent - 0.5, project.dcfInputs.terminalGrowthRatePercent, project.dcfInputs.terminalGrowthRatePercent + 0.5];

  return (
    <div className="space-y-6">
      {/* Top Section: DCF Valuation Engine */}
      <div className="bg-[#0E1013] rounded-lg border border-slate-800 shadow-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 bg-[#15181D] flex items-center justify-between">
          <div>
            <h2 className="font-bold text-xs text-white uppercase tracking-wider flex items-center space-x-2">
              <Layers className="w-4 h-4 text-blue-400" />
              <span>Discounted Cash Flow (DCF) Engine</span>
            </h2>
            <p className="text-[10px] text-slate-400">NPV of Unlevered Free Cash Flows & Terminal Value calculation.</p>
          </div>
          <div className="text-right font-mono">
            <span className="text-[10px] text-slate-400 block">DCF Implied Equity Value</span>
            <span className="text-lg font-extrabold text-blue-400">${calc.dcfEquityValue.toLocaleString()}M</span>
            <span className="text-[10px] text-green-500 block">${calc.dcfImpliedPricePerShare} / share</span>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* DCF Input Parameters */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
              <label className="text-slate-500 block text-[10px] uppercase font-bold mb-1">WACC %</label>
              <input
                type="number"
                step="0.1"
                value={project.dcfInputs.waccPercent}
                onChange={(e) => onUpdateProject({
                  dcfInputs: { ...project.dcfInputs, waccPercent: parseFloat(e.target.value) || 0 }
                })}
                className="w-full bg-[#15181D] border border-slate-700 rounded px-2.5 py-1 text-blue-400 font-bold focus:outline-none"
              />
            </div>

            <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
              <label className="text-slate-500 block text-[10px] uppercase font-bold mb-1">Terminal Growth %</label>
              <input
                type="number"
                step="0.1"
                value={project.dcfInputs.terminalGrowthRatePercent}
                onChange={(e) => onUpdateProject({
                  dcfInputs: { ...project.dcfInputs, terminalGrowthRatePercent: parseFloat(e.target.value) || 0 }
                })}
                className="w-full bg-[#15181D] border border-slate-700 rounded px-2.5 py-1 text-blue-400 font-bold focus:outline-none"
              />
            </div>

            <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
              <label className="text-slate-500 block text-[10px] uppercase font-bold mb-1">Terminal Method</label>
              <select
                value={project.dcfInputs.terminalMethod}
                onChange={(e) => onUpdateProject({
                  dcfInputs: { ...project.dcfInputs, terminalMethod: e.target.value as any }
                })}
                className="w-full bg-[#15181D] border border-slate-700 rounded px-2 py-1 text-slate-100 focus:outline-none"
              >
                <option value="PERPETUITY">Gordon Growth Perpetuity</option>
                <option value="EXIT_MULTIPLE">Exit EBITDA Multiple</option>
              </select>
            </div>

            <div className="bg-[#0A0B0D] p-3 rounded border border-slate-800">
              <label className="text-slate-500 block text-[10px] uppercase font-bold mb-1">DCF Enterprise Value</label>
              <span className="text-base font-bold text-white block mt-1">${calc.dcfEnterpriseValue.toLocaleString()}M</span>
            </div>
          </div>

          {/* DCF WACC vs Terminal Growth Sensitivity Grid */}
          <div className="pt-2">
            <h4 className="font-bold text-xs text-slate-300 uppercase tracking-wider mb-2">DCF Sensitivity Matrix: WACC vs Terminal Growth ($M Equity Value)</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-center border border-slate-800">
                <thead className="bg-[#0A0B0D] text-slate-400">
                  <tr>
                    <th className="p-2 border border-slate-800">Terminal g \ WACC</th>
                    {waccSteps.map(w => (
                      <th key={w} className={`p-2 border border-slate-800 ${w === project.dcfInputs.waccPercent ? 'text-blue-400 bg-blue-950/40' : ''}`}>
                        {w.toFixed(1)}%
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {gSteps.map(gVal => (
                    <tr key={gVal} className="divide-x divide-slate-800">
                      <td className={`p-2 font-bold bg-[#0A0B0D] ${gVal === project.dcfInputs.terminalGrowthRatePercent ? 'text-blue-400' : 'text-slate-400'}`}>
                        g = {gVal.toFixed(1)}%
                      </td>
                      {waccSteps.map(wVal => {
                        const w = wVal / 100;
                        const g = gVal / 100;
                        const pvFcf = calc.forecastYears.reduce((sum, fy, idx) => sum + (fy.freeCashFlow / Math.pow(1 + w, idx + 1)), 0);
                        const termFcf = calc.forecastYears[calc.forecastYears.length - 1].freeCashFlow * (1 + g);
                        const tv = w > g ? termFcf / (w - g) : termFcf / 0.05;
                        const pvTv = tv / Math.pow(1 + w, project.forecastAssumptions.horizonYears);
                        const sensitivityEquityVal = Math.round(pvFcf + pvTv + calc.forecastYears[0].cash - calc.forecastYears[0].debt);
                        const isBase = wVal === project.dcfInputs.waccPercent && gVal === project.dcfInputs.terminalGrowthRatePercent;

                        return (
                          <td
                            key={wVal}
                            className={`p-2 border border-slate-800 ${
                              isBase
                                ? 'bg-blue-600 text-white font-bold shadow'
                                : 'bg-[#0E1013] text-slate-200'
                            }`}
                          >
                            ${sensitivityEquityVal.toLocaleString()}M
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Section 2: Trading Comparables & Peer Selection Table */}
      <div className="bg-[#0E1013] rounded-lg border border-slate-800 shadow-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 bg-[#15181D] flex items-center justify-between">
          <div>
            <h3 className="font-bold text-xs text-white uppercase tracking-wider">Trading Comparables Peer Group Engine</h3>
            <p className="text-[10px] text-slate-400">Select peer companies to calculate median trading multiples (EV/Revenue, EV/EBITDA, P/E).</p>
          </div>
          <div className="text-right font-mono text-xs">
            <span className="text-slate-400 block text-[10px]">Comps Implied Equity Value</span>
            <span className="font-bold text-blue-400 text-base">${calc.compsImpliedEquityValue.toLocaleString()}M</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left text-slate-300">
            <thead className="bg-[#0A0B0D] text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Select</th>
                <th className="p-2.5">Company</th>
                <th className="p-2.5">Sector</th>
                <th className="p-2.5 text-right">EV / Rev</th>
                <th className="p-2.5 text-right">EV / EBITDA</th>
                <th className="p-2.5 text-right">P / E</th>
                <th className="p-2.5 text-right">FCF Yield</th>
                <th className="p-2.5 text-right">Rev Growth</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {TRADING_COMPS_DATABASE.map(c => {
                const isSelected = project.selectedCompIds.includes(c.id);
                return (
                  <tr
                    key={c.id}
                    onClick={() => toggleCompSelection(c.id)}
                    className={`cursor-pointer transition ${isSelected ? 'bg-blue-950/40' : 'hover:bg-slate-800/50'}`}
                  >
                    <td className="p-2.5">
                      {isSelected ? <CheckSquare className="w-4 h-4 text-blue-400" /> : <Square className="w-4 h-4 text-slate-600" />}
                    </td>
                    <td className="p-2.5 font-bold text-white">{c.name} ({c.ticker})</td>
                    <td className="p-2.5 text-slate-400">{c.sector}</td>
                    <td className="p-2.5 text-right text-blue-400 font-bold">{c.evRevenue}x</td>
                    <td className="p-2.5 text-right text-green-500">{c.evEbitda}x</td>
                    <td className="p-2.5 text-right">{c.pe}x</td>
                    <td className="p-2.5 text-right">{c.fcfYield}%</td>
                    <td className="p-2.5 text-right text-amber-400">+{c.revenueGrowth}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Section 3: IPO Comparable Transactions Analysis */}
      <div className="bg-[#0E1013] rounded-lg border border-slate-800 shadow-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 bg-[#15181D]">
          <h3 className="font-bold text-xs text-white uppercase tracking-wider">Recent Precedent IPO Multiples & Aftermarket Pops</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left text-slate-300">
            <thead className="bg-[#0A0B0D] text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-2.5">IPO Company</th>
                <th className="p-2.5">Year</th>
                <th className="p-2.5 text-right">IPO Value ($M)</th>
                <th className="p-2.5 text-right">EV/Rev Multiple</th>
                <th className="p-2.5 text-right">1-Day Return</th>
                <th className="p-2.5 text-right">30-Day Return</th>
                <th className="p-2.5 text-right">90-Day Return</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {HISTORICAL_IPOS_DATABASE.map(hipo => (
                <tr key={hipo.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-white">{hipo.name} ({hipo.ticker})</td>
                  <td className="p-2.5 text-slate-400">{hipo.ipoYear}</td>
                  <td className="p-2.5 text-right font-bold text-blue-400">${hipo.ipoValuation.toLocaleString()}M</td>
                  <td className="p-2.5 text-right">{hipo.evRevenueMultiple}x</td>
                  <td className={`p-2.5 text-right font-bold ${hipo.firstDayReturn >= 0 ? 'text-green-500' : 'text-rose-400'}`}>
                    +{hipo.firstDayReturn}%
                  </td>
                  <td className={`p-2.5 text-right ${hipo.day30Return >= 0 ? 'text-green-500' : 'text-rose-400'}`}>
                    {hipo.day30Return}%
                  </td>
                  <td className={`p-2.5 text-right ${hipo.day90Return >= 0 ? 'text-green-500' : 'text-rose-400'}`}>
                    {hipo.day90Return}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
