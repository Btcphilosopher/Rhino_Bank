import React, { useState } from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { Layers, Sliders, CheckCircle2, AlertTriangle } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const OfferSizeOptimiserPanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  const [minCapitalConstraint, setMinCapitalConstraint] = useState<number>(300); // $300M
  const [maxDilutionConstraint, setMaxDilutionConstraint] = useState<number>(25); // 25%

  const steps = calc.sizeOptimizationMatrix;

  return (
    <div className="space-y-6">
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>IPO Offering Size Optimiser Engine</span>
          </h2>
          <p className="text-xs text-slate-400">Evaluate optimal equity float percentages (10% to 50%) based on gross proceeds, dilution, and liquidity.</p>
        </div>

        {/* User Constraints Inputs */}
        <div className="flex items-center space-x-4 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2 rounded border border-slate-800">
            <label className="text-slate-400 block text-[10px] uppercase">Min Capital Constraint ($M)</label>
            <input
              type="number"
              value={minCapitalConstraint}
              onChange={(e) => setMinCapitalConstraint(parseFloat(e.target.value) || 0)}
              className="w-24 bg-[#141B2D] border border-slate-700 rounded px-2 py-0.5 text-cyan-300 font-bold focus:outline-none"
            />
          </div>

          <div className="bg-[#0B0F17] p-2 rounded border border-slate-800">
            <label className="text-slate-400 block text-[10px] uppercase">Max Dilution Constraint (%)</label>
            <input
              type="number"
              value={maxDilutionConstraint}
              onChange={(e) => setMaxDilutionConstraint(parseFloat(e.target.value) || 0)}
              className="w-24 bg-[#141B2D] border border-slate-700 rounded px-2 py-0.5 text-cyan-300 font-bold focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Offer Size Optimization Matrix Table */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Equity Offered Scenario Comparison Matrix</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left text-slate-300">
            <thead className="bg-[#0B0F17] text-slate-400">
              <tr>
                <th className="p-2.5">% Equity Offered</th>
                <th className="p-2.5 text-right">Shares Issued</th>
                <th className="p-2.5 text-right">Gross Capital Raised ($M)</th>
                <th className="p-2.5 text-right">Post Market Cap ($M)</th>
                <th className="p-2.5 text-right">Dilution %</th>
                <th className="p-2.5 text-right">Free Float %</th>
                <th className="p-2.5 text-right">Liquidity Score</th>
                <th className="p-2.5 text-center">Constraint Status</th>
                <th className="p-2.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {steps.map(step => {
                const meetsMinCapital = step.grossProceeds >= minCapitalConstraint;
                const meetsMaxDilution = step.dilutionPercent <= maxDilutionConstraint;
                const isValid = meetsMinCapital && meetsMaxDilution;
                const isCurrent = Math.abs(project.targetEquityOfferedPercent - step.equityOfferedPercent) < 2.5;

                return (
                  <tr
                    key={step.equityOfferedPercent}
                    className={`transition ${
                      isCurrent
                        ? 'bg-cyan-950/40 border-l-4 border-cyan-400 font-bold'
                        : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <td className="p-2.5 text-slate-100 font-bold text-sm">{step.equityOfferedPercent}% Equity</td>
                    <td className="p-2.5 text-right">{(step.sharesIssued / 1000000).toFixed(2)}M</td>
                    <td className="p-2.5 text-right text-cyan-300 font-bold">${step.grossProceeds.toLocaleString()}M</td>
                    <td className="p-2.5 text-right">${step.postMarketCap.toLocaleString()}M</td>
                    <td className="p-2.5 text-right text-amber-300">{step.dilutionPercent}%</td>
                    <td className="p-2.5 text-right">{step.freeFloatPercent}%</td>
                    <td className="p-2.5 text-right text-emerald-400">{step.liquidityScore} / 100</td>
                    <td className="p-2.5 text-center">
                      {isValid ? (
                        <span className="inline-flex items-center space-x-1 text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded text-[10px]">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Optimal</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 text-rose-400 bg-rose-950/60 border border-rose-800 px-2 py-0.5 rounded text-[10px]">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Breached</span>
                        </span>
                      )}
                    </td>
                    <td className="p-2.5 text-center">
                      <button
                        onClick={() => onUpdateProject({ targetEquityOfferedPercent: step.equityOfferedPercent })}
                        disabled={isCurrent}
                        className={`px-2.5 py-1 rounded text-[10px] font-bold transition ${
                          isCurrent
                            ? 'bg-cyan-500 text-slate-950'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                        }`}
                      >
                        {isCurrent ? 'Selected' : 'Apply Float %'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
