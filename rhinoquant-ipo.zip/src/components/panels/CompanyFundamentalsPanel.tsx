import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const CompanyFundamentalsPanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  const allYears = [...project.financials.filter(f => !f.isForecast), ...calc.forecastYears];

  const handleGrowthChange = (index: number, val: number) => {
    const newRates = [...project.forecastAssumptions.revenueGrowthRates];
    newRates[index] = val;
    onUpdateProject({
      forecastAssumptions: {
        ...project.forecastAssumptions,
        revenueGrowthRates: newRates
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Forecast Controls Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100">Financial Forecast Engine (Multi-Year)</h2>
          <p className="text-xs text-slate-400">Configure top-down or bottom-up forecast parameters across 3Y to 10Y horizons.</p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono">
          {/* Horizon Selector */}
          <div className="flex items-center space-x-1.5 bg-[#0B0F17] p-1 rounded border border-slate-800">
            <span className="text-slate-500 px-1">Horizon:</span>
            {[3, 5, 7, 10].map((h) => (
              <button
                key={h}
                onClick={() => onUpdateProject({
                  forecastAssumptions: { ...project.forecastAssumptions, horizonYears: h as any }
                })}
                className={`px-2 py-0.5 rounded transition ${
                  project.forecastAssumptions.horizonYears === h
                    ? 'bg-cyan-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {h}Y
              </button>
            ))}
          </div>

          {/* Forecast Method */}
          <div className="flex items-center space-x-1.5 bg-[#0B0F17] p-1 rounded border border-slate-800">
            <span className="text-slate-500 px-1">Method:</span>
            {(['TOP_DOWN', 'BOTTOM_UP'] as const).map((m) => (
              <button
                key={m}
                onClick={() => onUpdateProject({
                  forecastAssumptions: { ...project.forecastAssumptions, forecastMethod: m }
                })}
                className={`px-2 py-0.5 rounded transition ${
                  project.forecastAssumptions.forecastMethod === m
                    ? 'bg-cyan-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {m.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Financial Statement & Forecast Table */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 overflow-x-auto">
        <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider mb-3">Multi-Year Financial Model ($M)</h3>
        <table className="w-full text-xs font-mono text-left text-slate-300">
          <thead className="bg-[#0B0F17] text-slate-400 text-[11px]">
            <tr>
              <th className="p-2.5 font-bold">Line Item</th>
              {allYears.map(y => (
                <th key={y.year} className={`p-2.5 text-right ${y.isForecast ? 'text-cyan-400 bg-cyan-950/20' : ''}`}>
                  {y.year} {y.isForecast ? '(F)' : '(H)'}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            <tr>
              <td className="p-2.5 font-bold text-slate-100">Revenue ($M)</td>
              {allYears.map(y => <td key={y.year} className="p-2.5 text-right font-bold text-slate-100">${y.revenue.toLocaleString()}</td>)}
            </tr>
            <tr className="bg-[#111827]/40">
              <td className="p-2.5 text-slate-400">Revenue Growth %</td>
              {allYears.map((y, idx) => {
                const prev = allYears[idx - 1];
                const g = prev ? ((y.revenue - prev.revenue) / prev.revenue) * 100 : 0;
                return (
                  <td key={y.year} className="p-2.5 text-right text-emerald-400 font-semibold">
                    {g > 0 ? `+${g.toFixed(1)}%` : `${g.toFixed(1)}%`}
                  </td>
                );
              })}
            </tr>
            <tr>
              <td className="p-2.5 text-slate-300">Gross Profit ($M)</td>
              {allYears.map(y => <td key={y.year} className="p-2.5 text-right">${y.grossProfit.toLocaleString()}</td>)}
            </tr>
            <tr>
              <td className="p-2.5 font-bold text-cyan-300">EBITDA ($M)</td>
              {allYears.map(y => <td key={y.year} className="p-2.5 text-right font-bold text-cyan-300">${y.ebitda.toLocaleString()}</td>)}
            </tr>
            <tr className="bg-[#111827]/40">
              <td className="p-2.5 text-slate-400">EBITDA Margin %</td>
              {allYears.map(y => (
                <td key={y.year} className="p-2.5 text-right text-amber-300 font-semibold">
                  {((y.ebitda / y.revenue) * 100).toFixed(1)}%
                </td>
              ))}
            </tr>
            <tr>
              <td className="p-2.5 text-slate-300">EBIT ($M)</td>
              {allYears.map(y => <td key={y.year} className="p-2.5 text-right">${y.ebit.toLocaleString()}</td>)}
            </tr>
            <tr>
              <td className="p-2.5 font-bold text-emerald-400">Net Income ($M)</td>
              {allYears.map(y => <td key={y.year} className="p-2.5 text-right font-bold text-emerald-400">${y.netIncome.toLocaleString()}</td>)}
            </tr>
            <tr className="bg-[#111827]/40">
              <td className="p-2.5 font-bold text-cyan-300">Free Cash Flow ($M)</td>
              {allYears.map(y => <td key={y.year} className="p-2.5 text-right font-bold text-cyan-300">${y.freeCashFlow.toLocaleString()}</td>)}
            </tr>
            <tr>
              <td className="p-2.5 text-slate-400">Net Debt ($M)</td>
              {allYears.map(y => <td key={y.year} className="p-2.5 text-right text-slate-400">${(y.debt - y.cash).toLocaleString()}</td>)}
            </tr>
          </tbody>
        </table>
      </div>

      {/* Editable Forecast Assumptions & Revenue/EBITDA Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Interactive Growth & Margin Controls */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Forecast Driver Assumptions</h3>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Target Gross Margin %</label>
              <input
                type="number"
                value={project.forecastAssumptions.grossMarginPercent}
                onChange={(e) => onUpdateProject({
                  forecastAssumptions: { ...project.forecastAssumptions, grossMarginPercent: parseFloat(e.target.value) || 0 }
                })}
                className="w-full bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">OpEx % of Revenue</label>
              <input
                type="number"
                value={project.forecastAssumptions.opexPercentRevenue}
                onChange={(e) => onUpdateProject({
                  forecastAssumptions: { ...project.forecastAssumptions, opexPercentRevenue: parseFloat(e.target.value) || 0 }
                })}
                className="w-full bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">Capex % Revenue</label>
                <input
                  type="number"
                  value={project.forecastAssumptions.capexPercentRevenue}
                  onChange={(e) => onUpdateProject({
                    forecastAssumptions: { ...project.forecastAssumptions, capexPercentRevenue: parseFloat(e.target.value) || 0 }
                  })}
                  className="w-full bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:border-cyan-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">NWC % Revenue</label>
                <input
                  type="number"
                  value={project.forecastAssumptions.nwcPercentRevenue}
                  onChange={(e) => onUpdateProject({
                    forecastAssumptions: { ...project.forecastAssumptions, nwcPercentRevenue: parseFloat(e.target.value) || 0 }
                  })}
                  className="w-full bg-[#0B0F17] border border-slate-700 rounded px-3 py-1.5 text-slate-100 focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            {/* Editable Growth Rate per Year */}
            <div className="pt-2">
              <span className="block text-slate-400 mb-2">Yearly Revenue Growth % Inputs:</span>
              <div className="grid grid-cols-5 gap-2">
                {calc.forecastYears.map((fy, idx) => (
                  <div key={fy.year} className="bg-[#0B0F17] p-2 rounded border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-500 block">{fy.year}</span>
                    <input
                      type="number"
                      value={project.forecastAssumptions.revenueGrowthRates[idx] ?? 30}
                      onChange={(e) => handleGrowthChange(idx, parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent text-center font-bold text-cyan-300 focus:outline-none text-xs"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right: Revenue & EBITDA Trajectory Chart */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Revenue & EBITDA Trajectory ($M)</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={allYears}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="year" stroke="#64748B" fontSize={11} />
                <YAxis stroke="#64748B" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0B0F17', borderColor: '#334155', borderRadius: '6px', color: '#F1F5F9' }} />
                <Bar dataKey="revenue" fill="#00F2FE" name="Revenue ($M)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="ebitda" fill="#00E676" name="EBITDA ($M)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
