import React from 'react';
import { IPOProjectState, DigitalTwinCalculations } from '../../types/ipo';
import { DollarSign, Percent, TrendingUp, Sliders } from 'lucide-react';

interface PanelProps {
  project: IPOProjectState;
  calc: DigitalTwinCalculations;
  onUpdateProject: (updated: Partial<IPOProjectState>) => void;
}

export const PricingAndDiscountPanel: React.FC<PanelProps> = ({ project, calc, onUpdateProject }) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-base text-slate-100 flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-cyan-400" />
            <span>IPO Price & Discount Engine</span>
          </h2>
          <p className="text-xs text-slate-400">Model indicative price ranges, valuation discounts, and capital raised sensitivity.</p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Indicative Mid Price</span>
            <span className="font-bold text-slate-100 text-sm">${calc.indicativePriceMid}</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Effective IPO Discount</span>
            <span className="font-bold text-amber-300 text-sm">{calc.impliedDiscountValuationPercent}%</span>
          </div>
          <div className="bg-[#0B0F17] p-2.5 rounded border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Final Offer Price</span>
            <span className="font-bold text-emerald-400 text-sm">${calc.finalOfferPrice}</span>
          </div>
        </div>
      </div>

      {/* Interactive Discount Slider & Indicative Range Card */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Indicative Price Range */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Indicative Pricing Range</h3>

          <div className="grid grid-cols-3 gap-3 text-center font-mono">
            <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block uppercase">Low Range</span>
              <span className="text-lg font-bold text-slate-300">${calc.indicativePriceLow}</span>
            </div>
            <div className="bg-[#0B0F17] p-3 rounded border border-cyan-500/50 shadow">
              <span className="text-[10px] text-cyan-400 block uppercase">Mid Range</span>
              <span className="text-xl font-bold text-cyan-300">${calc.indicativePriceMid}</span>
            </div>
            <div className="bg-[#0B0F17] p-3 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block uppercase">High Range</span>
              <span className="text-lg font-bold text-slate-300">${calc.indicativePriceHigh}</span>
            </div>
          </div>

          {/* Discount Slider */}
          <div className="bg-[#0B0F17] p-4 rounded border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-300 font-bold">Target IPO Discount %:</span>
              <span className="text-amber-300 font-bold text-sm">{project.ipoDiscountPercent}%</span>
            </div>

            <input
              type="range"
              min="0"
              max="35"
              step="0.5"
              value={project.ipoDiscountPercent}
              onChange={(e) => onUpdateProject({ ipoDiscountPercent: parseFloat(e.target.value) || 0 })}
              className="w-full accent-cyan-400 bg-slate-800 rounded cursor-pointer h-2"
            />

            <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
              IPO discounts compensate new institutional investors for illiquidity, pricing risk, and market volatility. Current configured discount provides a <strong>${(calc.indicativePriceMid - calc.finalOfferPrice).toFixed(2)} / share</strong> price concessions relative to intrinsic DCF/Comps midpoint.
            </p>
          </div>
        </div>

        {/* Right: Effect of Offer Price Changes on Capital & Returns */}
        <div className="bg-[#141B2D] p-5 rounded-xl border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-100 uppercase tracking-wider">Offer Price Sensitivity Matrix</h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left text-slate-300">
              <thead className="bg-[#0B0F17] text-slate-400">
                <tr>
                  <th className="p-2">Price / Share</th>
                  <th className="p-2 text-right">Gross Proceeds</th>
                  <th className="p-2 text-right">Net Proceeds</th>
                  <th className="p-2 text-right">Post Market Cap</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {[-10, -5, 0, +5, +10].map(delta => {
                  const p = Math.round((calc.finalOfferPrice * (1 + delta / 100)) * 100) / 100;
                  const gross = Math.round((p * (project.newPrimaryShares + project.secondarySharesOffered) / 1000000) * 10) / 10;
                  const net = Math.round((gross - calc.totalTransactionFees) * 10) / 10;
                  const postCap = Math.round((p * calc.totalPostIpoShares / 1000000) * 10) / 10;
                  const isCurrent = delta === 0;

                  return (
                    <tr key={delta} className={isCurrent ? 'bg-emerald-950/40 text-emerald-300 font-bold' : 'hover:bg-slate-800/40'}>
                      <td className="p-2">${p} ({delta >= 0 ? `+${delta}` : delta}%)</td>
                      <td className="p-2 text-right">${gross.toLocaleString()}M</td>
                      <td className="p-2 text-right">${net.toLocaleString()}M</td>
                      <td className="p-2 text-right">${postCap.toLocaleString()}M</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
