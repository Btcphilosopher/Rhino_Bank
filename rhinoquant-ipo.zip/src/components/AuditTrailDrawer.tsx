import React from 'react';
import { AuditRecord } from '../types/ipo';
import { X, FileText, CheckCircle2, Copy } from 'lucide-react';

interface AuditTrailDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  auditTrail: AuditRecord[];
}

export const AuditTrailDrawer: React.FC<AuditTrailDrawerProps> = ({
  isOpen,
  onClose,
  auditTrail
}) => {
  if (!isOpen) return null;

  const copyAuditLogToClipboard = () => {
    const text = auditTrail.map(a => `[${a.timestamp}] ${a.inputName}\nAssumption: ${a.assumptionValue}\nFormula: ${a.formulaDescription}\nOutput: ${a.outputResult}\n---\n`).join('\n');
    navigator.clipboard.writeText(text);
    alert('Audit log copied to clipboard!');
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-xl bg-[#0B0F17] border-l border-[#1E293B] shadow-2xl flex flex-col text-slate-100">
      {/* Header */}
      <div className="p-4 border-b border-[#1E293B] bg-[#111827] flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FileText className="w-5 h-5 text-amber-400" />
          <h2 className="font-bold text-base text-slate-100">Model Calculation Audit Log</h2>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={copyAuditLogToClipboard}
            className="flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-2.5 py-1 rounded border border-slate-700"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Copy Log</span>
          </button>
          <button onClick={onClose} className="p-1 rounded hover:bg-slate-800 text-slate-400">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Audit Log Entries */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono text-xs">
        <div className="bg-amber-950/30 border border-amber-800/50 p-2.5 rounded text-amber-200/90 text-[11px] leading-relaxed">
          <strong>Auditability Guarantee:</strong> Every numerical output in the RhinoQuant Digital Twin engine is derived directly from deterministic financial formulas, recorded with explicit input parameters and execution timestamps.
        </div>

        {auditTrail.map((record) => (
          <div key={record.id} className="bg-[#141B2D] border border-slate-800 rounded-lg p-3 space-y-1.5 hover:border-cyan-500/50 transition">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-1">
              <span className="font-bold text-cyan-300">{record.inputName}</span>
              <span className="text-[10px] text-slate-500">{new Date(record.timestamp).toLocaleTimeString()}</span>
            </div>

            <div>
              <span className="text-slate-500 text-[10px] uppercase block">Assumption:</span>
              <span className="text-slate-300 font-sans text-xs">{record.assumptionValue}</span>
            </div>

            <div className="bg-[#0B0F17] p-2 rounded border border-slate-800 text-[11px] text-amber-300/90">
              <span className="text-slate-500 block text-[9px] uppercase">Formula:</span>
              <code>{record.formulaDescription}</code>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-slate-500 text-[10px] uppercase">Result:</span>
              <span className="text-emerald-400 font-bold">{record.outputResult}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
