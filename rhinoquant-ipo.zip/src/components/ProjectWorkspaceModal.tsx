import React, { useState } from 'react';
import { IPOProjectState } from '../types/ipo';
import { X, Plus, Copy, Archive, Download, Upload, GitCompare, CheckCircle } from 'lucide-react';

interface ProjectWorkspaceModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProject: IPOProjectState;
  projectsList: IPOProjectState[];
  onCreateProject: (newProject: IPOProjectState) => void;
  onDuplicateProject: (sourceId: string) => void;
  onArchiveProject: (id: string) => void;
  onImportProject: (importedState: IPOProjectState) => void;
}

export const ProjectWorkspaceModal: React.FC<ProjectWorkspaceModalProps> = ({
  isOpen,
  onClose,
  currentProject,
  projectsList,
  onCreateProject,
  onDuplicateProject,
  onArchiveProject,
  onImportProject
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'manage' | 'compare' | 'export_import'>('manage');
  const [compareTargetId, setCompareTargetId] = useState<string>(projectsList[1]?.id || projectsList[0]?.id || '');

  // Form state for Create New IPO
  const [newCompanyName, setNewCompanyName] = useState('');
  const [newSector, setNewSector] = useState<IPOProjectState['sector']>('Enterprise Software / AI');
  const [newExchange, setNewExchange] = useState<IPOProjectState['proposedExchange']>('NASDAQ');
  const [newTicker, setNewTicker] = useState('');

  if (!isOpen) return null;

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompanyName || !newTicker) return;

    const newProj: IPOProjectState = {
      ...currentProject,
      id: `proj-${Date.now()}`,
      version: '1.0.0-PROD',
      companyName: newCompanyName,
      sector: newSector,
      proposedExchange: newExchange,
      proposedTicker: newTicker.toUpperCase(),
      updatedAt: new Date().toISOString(),
      notes: `Created on ${new Date().toLocaleDateString()}`
    };

    onCreateProject(newProj);
    setActiveTab('manage');
  };

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(currentProject, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${currentProject.proposedTicker}_IPO_Model_RhinoQuant.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], "UTF-8");
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed.companyName && parsed.shareholders) {
            onImportProject(parsed);
            alert(`Successfully imported model for ${parsed.companyName}`);
            onClose();
          }
        } catch (err) {
          alert("Invalid IPO model JSON file");
        }
      };
    }
  };

  const compareTarget = projectsList.find(p => p.id === compareTargetId) || currentProject;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0B0F17] border border-[#1E293B] rounded-xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-[#1E293B] flex items-center justify-between bg-[#111827]">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-lg text-cyan-300">IPO Project Workspace</span>
            <span className="text-xs bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">Rhino Bank ECM</span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex items-center space-x-2 bg-[#141B2D] p-2 border-b border-[#1E293B] text-xs font-semibold">
          <button
            onClick={() => setActiveTab('manage')}
            className={`px-3 py-1.5 rounded transition ${activeTab === 'manage' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            Manage IPO Models ({projectsList.length})
          </button>
          <button
            onClick={() => setActiveTab('create')}
            className={`px-3 py-1.5 rounded transition ${activeTab === 'create' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            + Create New IPO
          </button>
          <button
            onClick={() => setActiveTab('compare')}
            className={`px-3 py-1.5 rounded transition ${activeTab === 'compare' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            Compare Versions
          </button>
          <button
            onClick={() => setActiveTab('export_import')}
            className={`px-3 py-1.5 rounded transition ${activeTab === 'export_import' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            Export / Import Model
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'manage' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider">Active Deals in Queue</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projectsList.map((p) => (
                  <div
                    key={p.id}
                    className={`p-4 rounded-lg border transition ${
                      p.id === currentProject.id
                        ? 'bg-[#141B2D] border-cyan-500/80 shadow-md'
                        : 'bg-[#111827] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="font-bold text-slate-100 text-base">{p.companyName}</h4>
                          <span className="text-xs font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 px-1.5 py-0.5 rounded">
                            {p.proposedTicker}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{p.sector} | {p.proposedExchange} ({p.currency})</p>
                      </div>
                      {p.id === currentProject.id && (
                        <span className="flex items-center space-x-1 text-xs text-emerald-400 font-semibold bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded">
                          <CheckCircle className="w-3 h-3" />
                          <span>Active</span>
                        </span>
                      )}
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-mono">Ver: {p.version}</span>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => onDuplicateProject(p.id)}
                          className="flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2 py-1 rounded transition border border-slate-700"
                        >
                          <Copy className="w-3 h-3" />
                          <span>Duplicate</span>
                        </button>
                        {projectsList.length > 1 && (
                          <button
                            onClick={() => onArchiveProject(p.id)}
                            className="flex items-center space-x-1 bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 px-2 py-1 rounded transition border border-rose-800/60"
                          >
                            <Archive className="w-3 h-3" />
                            <span>Archive</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'create' && (
            <form onSubmit={handleCreateSubmit} className="space-y-4 max-w-xl mx-auto">
              <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider">Initialize New IPO Deal Workspace</h3>
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Company Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apex Robotics Inc"
                  value={newCompanyName}
                  onChange={(e) => setNewCompanyName(e.target.value)}
                  className="w-full bg-[#141B2D] border border-slate-700 rounded px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Proposed Ticker *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ARBX"
                    value={newTicker}
                    onChange={(e) => setNewTicker(e.target.value)}
                    className="w-full bg-[#141B2D] border border-slate-700 rounded px-3 py-2 text-sm text-slate-100 font-mono uppercase focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Exchange</label>
                  <select
                    value={newExchange}
                    onChange={(e) => setNewExchange(e.target.value as any)}
                    className="w-full bg-[#141B2D] border border-slate-700 rounded px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="NASDAQ">NASDAQ</option>
                    <option value="NYSE">NYSE</option>
                    <option value="LSE">LSE</option>
                    <option value="Euronext">Euronext</option>
                    <option value="HKEX">HKEX</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Industry Sector</label>
                <select
                  value={newSector}
                  onChange={(e) => setNewSector(e.target.value as any)}
                  className="w-full bg-[#141B2D] border border-slate-700 rounded px-3 py-2 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
                >
                  <option value="Enterprise Software / AI">Enterprise Software / AI</option>
                  <option value="Biotech & Pharma">Biotech & Pharma</option>
                  <option value="Fintech & Payments">Fintech & Payments</option>
                  <option value="CleanTech & Energy">CleanTech & Energy</option>
                  <option value="Consumer Tech">Consumer Tech</option>
                  <option value="Industrial & Robotics">Industrial & Robotics</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2.5 rounded transition shadow-md flex items-center justify-center space-x-2 mt-6"
              >
                <Plus className="w-4 h-4" />
                <span>Create & Switch to Model</span>
              </button>
            </form>
          )}

          {activeTab === 'compare' && (
            <div className="space-y-4">
              <div className="flex items-center space-x-3 bg-[#111827] p-3 rounded border border-slate-800">
                <span className="text-xs text-slate-400 font-semibold">Compare Active ({currentProject.companyName}) with:</span>
                <select
                  value={compareTargetId}
                  onChange={(e) => setCompareTargetId(e.target.value)}
                  className="bg-[#141B2D] border border-slate-700 text-cyan-300 text-xs rounded px-2.5 py-1 focus:outline-none"
                >
                  {projectsList.map(p => (
                    <option key={p.id} value={p.id}>{p.companyName} ({p.proposedTicker})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                <div className="bg-[#141B2D] p-4 rounded border border-cyan-500/40">
                  <h4 className="font-bold text-cyan-300 mb-3 text-sm">{currentProject.companyName} (Active)</h4>
                  <div className="space-y-2 text-slate-300">
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>Sector:</span><span>{currentProject.sector}</span></div>
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>Exchange:</span><span>{currentProject.proposedExchange}</span></div>
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>Target Equity Offered:</span><span>{currentProject.targetEquityOfferedPercent}%</span></div>
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>IPO Discount:</span><span>{currentProject.ipoDiscountPercent}%</span></div>
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>Syndicate Lead:</span><span>{currentProject.syndicate[0]?.institutionName}</span></div>
                  </div>
                </div>

                <div className="bg-[#111827] p-4 rounded border border-slate-800">
                  <h4 className="font-bold text-slate-200 mb-3 text-sm">{compareTarget.companyName}</h4>
                  <div className="space-y-2 text-slate-300">
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>Sector:</span><span>{compareTarget.sector}</span></div>
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>Exchange:</span><span>{compareTarget.proposedExchange}</span></div>
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>Target Equity Offered:</span><span>{compareTarget.targetEquityOfferedPercent}%</span></div>
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>IPO Discount:</span><span>{compareTarget.ipoDiscountPercent}%</span></div>
                    <div className="flex justify-between border-b border-slate-800 pb-1"><span>Syndicate Lead:</span><span>{compareTarget.syndicate[0]?.institutionName}</span></div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'export_import' && (
            <div className="space-y-6 max-w-xl mx-auto text-center">
              <div className="bg-[#141B2D] p-6 rounded-lg border border-slate-800 space-y-3">
                <Download className="w-8 h-8 text-cyan-400 mx-auto" />
                <h4 className="font-bold text-slate-100">Export Model Snapshot</h4>
                <p className="text-xs text-slate-400">Download full RhinoQuant JSON state for {currentProject.companyName} including forecast parameters, valuation assumptions, syndicate split, and orderbook.</p>
                <button
                  onClick={handleExportJSON}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-4 py-2 rounded text-xs transition"
                >
                  Download .JSON Model File
                </button>
              </div>

              <div className="bg-[#141B2D] p-6 rounded-lg border border-slate-800 space-y-3">
                <Upload className="w-8 h-8 text-amber-400 mx-auto" />
                <h4 className="font-bold text-slate-100">Import Model File</h4>
                <p className="text-xs text-slate-400">Upload a saved RhinoQuant JSON model file to restore project state.</p>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="block w-full text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-cyan-300 hover:file:bg-slate-700 cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
