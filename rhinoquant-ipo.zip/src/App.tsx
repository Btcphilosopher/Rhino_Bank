import React, { useState, useMemo } from 'react';
import { IPOProjectState, AuditRecord } from './types/ipo';
import { INITIAL_PROJECT_TITAN, SAMPLE_PROJECT_APEX } from './data/mockDatabase';
import { runDigitalTwinSimulation } from './services/digitalTwinEngine';
import { generateAuditLog } from './services/auditLogger';
import { HeaderNav } from './components/HeaderNav';
import { ProjectWorkspaceModal } from './components/ProjectWorkspaceModal';
import { AuditTrailDrawer } from './components/AuditTrailDrawer';
import { AiEcmAdvisorDrawer } from './components/AiEcmAdvisorDrawer';

// Import Panels
import { OverviewDashboardPanel } from './components/panels/OverviewDashboardPanel';
import { CompanyFundamentalsPanel } from './components/panels/CompanyFundamentalsPanel';
import { ValuationEnginePanel } from './components/panels/ValuationEnginePanel';
import { ValuationRangePanel } from './components/panels/ValuationRangePanel';
import { CapTablePanel } from './components/panels/CapTablePanel';
import { OfferSizeOptimiserPanel } from './components/panels/OfferSizeOptimiserPanel';
import { PricingAndDiscountPanel } from './components/panels/PricingAndDiscountPanel';
import { BookbuildingSimulatorPanel } from './components/panels/BookbuildingSimulatorPanel';
import { AllocationEnginePanel } from './components/panels/AllocationEnginePanel';
import { SyndicateAndFeesPanel } from './components/panels/SyndicateAndFeesPanel';
import { UseOfProceedsPanel } from './components/panels/UseOfProceedsPanel';
import { ScenarioAndMarketPanel } from './components/panels/ScenarioAndMarketPanel';
import { AftermarketAndGreenshoePanel } from './components/panels/AftermarketAndGreenshoePanel';
import { CompsDatabasePanel } from './components/panels/CompsDatabasePanel';
import { ApiExplorerPanel } from './components/panels/ApiExplorerPanel';

export function App() {
  const [projectsList, setProjectsList] = useState<IPOProjectState[]>([
    INITIAL_PROJECT_TITAN,
    SAMPLE_PROJECT_APEX
  ]);
  const [currentProjectId, setCurrentProjectId] = useState<string>(INITIAL_PROJECT_TITAN.id);
  const [activePanel, setActivePanel] = useState<string>('overview');

  // Drawer Modals State
  const [isWorkspaceModalOpen, setIsWorkspaceModalOpen] = useState<boolean>(false);
  const [isAuditDrawerOpen, setIsAuditDrawerOpen] = useState<boolean>(false);
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState<boolean>(false);

  // Active Project Reference
  const currentProject = useMemo(() => {
    return projectsList.find(p => p.id === currentProjectId) || projectsList[0];
  }, [projectsList, currentProjectId]);

  // Reactive Digital Twin Simulation
  const { calculations: calc, auditLogs } = useMemo(() => {
    const calculations = runDigitalTwinSimulation(currentProject);
    const auditLogs = generateAuditLog(currentProject, calculations);
    return { calculations, auditLogs };
  }, [currentProject]);

  // Handlers to update current project state reactively
  const handleUpdateCurrentProject = (updated: Partial<IPOProjectState>) => {
    setProjectsList(prev => prev.map(p => {
      if (p.id === currentProjectId) {
        return {
          ...p,
          ...updated,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    }));
  };

  const handleScenarioChange = (scenario: IPOProjectState['currentScenario']) => {
    handleUpdateCurrentProject({ currentScenario: scenario });
  };

  const handleCreateProject = (newProject: IPOProjectState) => {
    setProjectsList(prev => [...prev, newProject]);
    setCurrentProjectId(newProject.id);
  };

  const handleDuplicateProject = (sourceId: string) => {
    const source = projectsList.find(p => p.id === sourceId);
    if (!source) return;

    const dup: IPOProjectState = {
      ...source,
      id: `proj-${Date.now()}`,
      companyName: `${source.companyName} (Copy)`,
      proposedTicker: `${source.proposedTicker}C`,
      updatedAt: new Date().toISOString()
    };

    setProjectsList(prev => [...prev, dup]);
    setCurrentProjectId(dup.id);
  };

  const handleArchiveProject = (id: string) => {
    if (projectsList.length <= 1) return;
    const filtered = projectsList.filter(p => p.id !== id);
    setProjectsList(filtered);
    if (currentProjectId === id) {
      setCurrentProjectId(filtered[0].id);
    }
  };

  const handleImportProject = (importedState: IPOProjectState) => {
    setProjectsList(prev => [...prev, importedState]);
    setCurrentProjectId(importedState.id);
  };

  return (
    <div className="min-h-screen bg-[#0A0B0D] text-slate-300 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Banking Navigation Bar */}
      <HeaderNav
        currentProject={currentProject}
        projectsList={projectsList}
        onSelectProject={(id) => setCurrentProjectId(id)}
        calc={calc}
        onOpenWorkspaceModal={() => setIsWorkspaceModalOpen(true)}
        onOpenAuditDrawer={() => setIsAuditDrawerOpen(true)}
        onOpenAiDrawer={() => setIsAiDrawerOpen(true)}
        activePanel={activePanel}
        setActivePanel={setActivePanel}
        onScenarioChange={handleScenarioChange}
      />

      {/* High Density Metric Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-slate-800 border-b border-slate-800 text-xs font-mono">
        <div className="bg-[#0A0B0D] p-3 sm:p-4">
          <div className="text-[10px] uppercase text-slate-500 font-bold tracking-wider">Implied Post-Money</div>
          <div className="text-xl sm:text-2xl font-mono text-white mt-0.5 font-bold">${calc.postMoneyEquityValue.toLocaleString()}M</div>
          <div className="text-[10px] text-green-500 mt-0.5 font-semibold">Pre-Money: ${calc.preMoneyEquityValue.toLocaleString()}M</div>
        </div>

        <div className="bg-[#0A0B0D] p-3 sm:p-4">
          <div className="text-[10px] uppercase text-slate-500 font-bold tracking-wider">Total Offering Size</div>
          <div className="text-xl sm:text-2xl font-mono text-white mt-0.5 font-bold">${calc.totalGrossProceeds.toLocaleString()}M</div>
          <div className="text-[10px] text-slate-400 mt-0.5">{calc.postIpoPublicFreeFloatPercent}% Free Float</div>
        </div>

        <div className="bg-[#0A0B0D] p-3 sm:p-4">
          <div className="text-[10px] uppercase text-slate-500 font-bold tracking-wider">Price Range / Offer</div>
          <div className="text-xl sm:text-2xl font-mono text-white mt-0.5 font-bold">${calc.indicativePriceLow.toFixed(2)} - ${calc.indicativePriceHigh.toFixed(2)}</div>
          <div className="text-[10px] text-blue-400 mt-0.5 font-semibold">Final Offer: ${calc.finalOfferPrice.toFixed(2)}</div>
        </div>

        <div className="bg-[#0A0B0D] p-3 sm:p-4">
          <div className="text-[10px] uppercase text-slate-500 font-bold tracking-wider">Oversubscription</div>
          <div className="text-xl sm:text-2xl font-mono text-blue-400 mt-0.5 font-bold">{calc.oversubscriptionRatio}x</div>
          <div className="text-[10px] text-blue-500 mt-0.5 font-semibold">Demand: ${calc.totalBookDemandUSD.toLocaleString()}M</div>
        </div>
      </div>

      {/* Main Workspace Content Area */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto px-4 py-6">
        {activePanel === 'overview' && (
          <OverviewDashboardPanel project={currentProject} calc={calc} onNavigateTab={setActivePanel} />
        )}
        {activePanel === 'fundamentals' && (
          <CompanyFundamentalsPanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'valuation' && (
          <ValuationEnginePanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'valuation_range' && (
          <ValuationRangePanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'cap_table' && (
          <CapTablePanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'size_optimizer' && (
          <OfferSizeOptimiserPanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'pricing_discount' && (
          <PricingAndDiscountPanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'bookbuilding' && (
          <BookbuildingSimulatorPanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'allocation' && (
          <AllocationEnginePanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'syndicate_fees' && (
          <SyndicateAndFeesPanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'use_of_proceeds' && (
          <UseOfProceedsPanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'scenarios_risk' && (
          <ScenarioAndMarketPanel
            project={currentProject}
            calc={calc}
            onUpdateProject={handleUpdateCurrentProject}
            onScenarioChange={handleScenarioChange}
          />
        )}
        {activePanel === 'aftermarket' && (
          <AftermarketAndGreenshoePanel project={currentProject} calc={calc} onUpdateProject={handleUpdateCurrentProject} />
        )}
        {activePanel === 'comps_database' && (
          <CompsDatabasePanel />
        )}
        {activePanel === 'api_explorer' && (
          <ApiExplorerPanel project={currentProject} />
        )}
      </main>

      {/* Footer */}
      <footer className="h-8 bg-[#0E1013] border-t border-slate-800 flex items-center px-4 justify-between text-[9px] font-mono uppercase text-slate-500 tracking-[1px]">
        <div>
          <span>RHINOQUANT TERMINAL ID: RHNO-01 // US-EAST-1A</span> &bull; <span>Rhino Bank ECM</span>
        </div>
        <div className="flex items-center space-x-4">
          <span>Digital Twin Sync Status: <strong className="text-green-500">ACTIVE</strong></span>
          <span>Security: <strong className="text-blue-400">RESTRICTED INSTITUTIONAL</strong></span>
        </div>
      </footer>

      {/* Overlay Drawers & Modals */}
      <ProjectWorkspaceModal
        isOpen={isWorkspaceModalOpen}
        onClose={() => setIsWorkspaceModalOpen(false)}
        currentProject={currentProject}
        projectsList={projectsList}
        onCreateProject={handleCreateProject}
        onDuplicateProject={handleDuplicateProject}
        onArchiveProject={handleArchiveProject}
        onImportProject={handleImportProject}
      />

      <AuditTrailDrawer
        isOpen={isAuditDrawerOpen}
        onClose={() => setIsAuditDrawerOpen(false)}
        auditTrail={auditLogs}
      />

      <AiEcmAdvisorDrawer
        isOpen={isAiDrawerOpen}
        onClose={() => setIsAiDrawerOpen(false)}
        project={currentProject}
        calc={calc}
      />
    </div>
  );
}

export default App;
