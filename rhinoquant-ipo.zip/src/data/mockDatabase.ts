import { IPOProjectState, TradingCompCompany, HistoricalIPO } from '../types/ipo';

export const TRADING_COMPS_DATABASE: TradingCompCompany[] = [
  { id: 'comp-1', name: 'Palantir Tech', ticker: 'PLTR', sector: 'Enterprise Software / AI', evRevenue: 28.5, evEbitda: 65.2, pe: 82.0, evEbit: 74.1, fcfYield: 2.1, revenueGrowth: 27.5, ebitdaMargin: 38.2 },
  { id: 'comp-2', name: 'Snowflake Inc', ticker: 'SNOW', sector: 'Enterprise Software / AI', evRevenue: 16.8, evEbitda: 48.0, pe: 62.5, evEbit: 52.0, fcfYield: 2.8, revenueGrowth: 29.0, ebitdaMargin: 24.5 },
  { id: 'comp-3', name: 'Datadog Inc', ticker: 'DDOG', sector: 'Enterprise Software / AI', evRevenue: 18.2, evEbitda: 51.4, pe: 68.0, evEbit: 58.2, fcfYield: 3.1, revenueGrowth: 26.0, ebitdaMargin: 28.0 },
  { id: 'comp-4', name: 'CrowdStrike', ticker: 'CRWD', sector: 'Enterprise Software / AI', evRevenue: 22.4, evEbitda: 58.0, pe: 75.0, evEbit: 62.0, fcfYield: 3.4, revenueGrowth: 32.0, ebitdaMargin: 31.0 },
  { id: 'comp-5', name: 'Adyen N.V.', ticker: 'ADYEN', sector: 'Fintech & Payments', evRevenue: 21.0, evEbitda: 42.0, pe: 54.0, evEbit: 45.0, fcfYield: 2.9, revenueGrowth: 24.0, ebitdaMargin: 48.0 },
  { id: 'comp-6', name: 'Stripe Inc (Private Comps)', ticker: 'STRIP', sector: 'Fintech & Payments', evRevenue: 19.5, evEbitda: 44.0, pe: 58.0, evEbit: 48.0, fcfYield: 2.5, revenueGrowth: 28.0, ebitdaMargin: 35.0 },
  { id: 'comp-7', name: 'Toast Inc', ticker: 'TOST', sector: 'Fintech & Payments', evRevenue: 6.8, evEbitda: 28.0, pe: 38.0, evEbit: 31.0, fcfYield: 4.2, revenueGrowth: 31.0, ebitdaMargin: 18.0 },
  { id: 'comp-8', name: 'Vertex Pharmaceuticals', ticker: 'VRTX', sector: 'Biotech & Pharma', evRevenue: 10.2, evEbitda: 18.5, pe: 24.0, evEbit: 21.0, fcfYield: 4.8, revenueGrowth: 14.0, ebitdaMargin: 46.0 },
  { id: 'comp-9', name: 'Moderna Inc', ticker: 'MRNA', sector: 'Biotech & Pharma', evRevenue: 7.5, evEbitda: 15.0, pe: 18.0, evEbit: 16.0, fcfYield: 5.5, revenueGrowth: 18.0, ebitdaMargin: 32.0 },
  { id: 'comp-10', name: 'Enphase Energy', ticker: 'ENPH', sector: 'CleanTech & Energy', evRevenue: 8.5, evEbitda: 22.0, pe: 28.0, evEbit: 24.0, fcfYield: 4.1, revenueGrowth: 21.0, ebitdaMargin: 30.0 },
  { id: 'comp-11', name: 'Tesla Inc', ticker: 'TSLA', sector: 'CleanTech & Energy', evRevenue: 7.2, evEbitda: 32.0, pe: 65.0, evEbit: 38.0, fcfYield: 1.8, revenueGrowth: 19.0, ebitdaMargin: 16.5 },
  { id: 'comp-12', name: 'Intuitive Surgical', ticker: 'ISRG', sector: 'Industrial & Robotics', evRevenue: 15.4, evEbitda: 36.0, pe: 48.0, evEbit: 40.0, fcfYield: 2.6, revenueGrowth: 17.0, ebitdaMargin: 36.0 }
];

export const HISTORICAL_IPOS_DATABASE: HistoricalIPO[] = [
  { id: 'hipo-1', name: 'Arm Holdings', ticker: 'ARM', sector: 'Enterprise Software / AI', exchange: 'NASDAQ', ipoYear: 2023, ipoValuation: 54500, ipoPrice: 51.0, revenue: 2680, revenueGrowth: 19.5, ebitdaMargin: 42.0, evRevenueMultiple: 20.3, firstDayReturn: 24.8, day30Return: 18.2, day90Return: 42.5, year1Return: 128.0 },
  { id: 'hipo-2', name: 'Instacart (Maplebear)', ticker: 'CART', sector: 'Consumer Tech', exchange: 'NASDAQ', ipoYear: 2023, ipoValuation: 9900, ipoPrice: 30.0, revenue: 2550, revenueGrowth: 31.0, ebitdaMargin: 22.0, evRevenueMultiple: 3.8, firstDayReturn: 12.3, day30Return: -15.4, day90Return: -8.2, year1Return: 22.5 },
  { id: 'hipo-3', name: 'Klaviyo Inc', ticker: 'KVYO', sector: 'Enterprise Software / AI', exchange: 'NYSE', ipoYear: 2023, ipoValuation: 9200, ipoPrice: 30.0, revenue: 580, revenueGrowth: 48.0, ebitdaMargin: 14.0, evRevenueMultiple: 15.8, firstDayReturn: 9.2, day30Return: 2.5, day90Return: -5.1, year1Return: 18.4 },
  { id: 'hipo-4', name: 'Reddit Inc', ticker: 'RDDT', sector: 'Consumer Tech', exchange: 'NYSE', ipoYear: 2024, ipoValuation: 6400, ipoPrice: 34.0, revenue: 804, revenueGrowth: 20.5, ebitdaMargin: 12.0, evRevenueMultiple: 7.9, firstDayReturn: 48.4, day30Return: 35.2, day90Return: 68.0, year1Return: 110.0 },
  { id: 'hipo-5', name: 'Astera Labs', ticker: 'ALAB', sector: 'Enterprise Software / AI', exchange: 'NASDAQ', ipoYear: 2024, ipoValuation: 5500, ipoPrice: 36.0, revenue: 115, revenueGrowth: 206.0, ebitdaMargin: 28.0, evRevenueMultiple: 47.8, firstDayReturn: 72.2, day30Return: 88.0, day90Return: 45.0, year1Return: 92.0 },
  { id: 'hipo-6', name: 'Rubrik Inc', ticker: 'RBRK', sector: 'Enterprise Software / AI', exchange: 'NYSE', ipoYear: 2024, ipoValuation: 5600, ipoPrice: 32.0, revenue: 628, revenueGrowth: 29.0, ebitdaMargin: -15.0, evRevenueMultiple: 8.9, firstDayReturn: 15.6, day30Return: 8.4, day90Return: 12.0, year1Return: 34.0 },
  { id: 'hipo-7', name: 'Tempus AI', ticker: 'TEM', sector: 'Biotech & Pharma', exchange: 'NASDAQ', ipoYear: 2024, ipoValuation: 6100, ipoPrice: 37.0, revenue: 531, revenueGrowth: 25.8, ebitdaMargin: -18.0, evRevenueMultiple: 11.4, firstDayReturn: 8.8, day30Return: 18.2, day90Return: 31.0, year1Return: 52.0 },
  { id: 'hipo-8', name: 'Ibotta Inc', ticker: 'IBTA', sector: 'Consumer Tech', exchange: 'NYSE', ipoYear: 2024, ipoValuation: 2600, ipoPrice: 88.0, revenue: 320, revenueGrowth: 52.0, ebitdaMargin: 30.0, evRevenueMultiple: 8.1, firstDayReturn: 17.3, day30Return: -12.0, day90Return: -28.0, year1Return: -35.0 }
];

export const INITIAL_PROJECT_TITAN: IPOProjectState = {
  id: 'proj-titan',
  version: '1.0.0-PROD',
  companyName: 'CloudScale AI Corp',
  sector: 'Enterprise Software / AI',
  jurisdiction: 'USA',
  proposedExchange: 'NASDAQ',
  proposedTicker: 'CSAI',
  ipoDate: '2026-10-15',
  currency: 'USD',
  
  shareholders: [
    { id: 'sh-1', name: 'Founders & Executive Team', category: 'Founders', preShares: 45000000, secondarySharesSold: 2000000, votingRightsMultiplier: 10 },
    { id: 'sh-2', name: 'Sequoia Capital & Accel', category: 'Venture Capital', preShares: 30000000, secondarySharesSold: 3000000, votingRightsMultiplier: 1 },
    { id: 'sh-3', name: 'Insight Partners', category: 'Private Equity', preShares: 15000000, secondarySharesSold: 1000000, votingRightsMultiplier: 1 },
    { id: 'sh-4', name: 'NVIDIA Ventures', category: 'Strategic Investors', preShares: 10000000, secondarySharesSold: 0, votingRightsMultiplier: 1 },
    { id: 'sh-5', name: 'Employee Option Pool', category: 'Employees', preShares: 10000000, secondarySharesSold: 0, votingRightsMultiplier: 1 }
  ],
  
  newPrimaryShares: 15000000,
  secondarySharesOffered: 6000000,
  targetEquityOfferedPercent: 17.0,
  
  financials: [
    { year: 2023, isForecast: false, revenue: 145.0, grossProfit: 112.0, ebitda: 22.0, ebit: 15.0, netIncome: 10.5, operatingCashFlow: 18.0, freeCashFlow: 12.0, cash: 45.0, debt: 15.0, capex: 6.0, workingCapital: 12.0, employees: 340, customers: 1200 },
    { year: 2024, isForecast: false, revenue: 280.0, grossProfit: 224.0, ebitda: 58.0, ebit: 46.0, netIncome: 34.0, operatingCashFlow: 52.0, freeCashFlow: 38.0, cash: 85.0, debt: 10.0, capex: 14.0, workingCapital: 18.0, employees: 580, customers: 2400 },
    { year: 2025, isForecast: false, revenue: 520.0, grossProfit: 426.0, ebitda: 140.0, ebit: 118.0, netIncome: 92.0, operatingCashFlow: 132.0, freeCashFlow: 105.0, cash: 180.0, debt: 5.0, capex: 27.0, workingCapital: 28.0, employees: 920, customers: 4800 },
    { year: 2026, isForecast: true, revenue: 880.0, grossProfit: 730.0, ebitda: 272.0, ebit: 238.0, netIncome: 188.0, operatingCashFlow: 260.0, freeCashFlow: 212.0, cash: 320.0, debt: 0.0, capex: 48.0, workingCapital: 42.0, employees: 1350, customers: 8200 },
    { year: 2027, isForecast: true, revenue: 1320.0, grossProfit: 1108.0, ebitda: 435.0, ebit: 388.0, netIncome: 310.0, operatingCashFlow: 420.0, freeCashFlow: 352.0, cash: 540.0, debt: 0.0, capex: 68.0, workingCapital: 60.0, employees: 1850, customers: 12500 },
    { year: 2028, isForecast: true, revenue: 1850.0, grossProfit: 1572.0, ebitda: 647.0, ebit: 582.0, netIncome: 465.0, operatingCashFlow: 620.0, freeCashFlow: 528.0, cash: 880.0, debt: 0.0, capex: 92.0, workingCapital: 85.0, employees: 2400, customers: 18000 }
  ],
  
  forecastAssumptions: {
    horizonYears: 5,
    forecastMethod: 'TOP_DOWN',
    revenueGrowthRates: [69.2, 50.0, 40.1, 30.0, 22.0],
    grossMarginPercent: 83.0,
    opexPercentRevenue: 52.0,
    taxRatePercent: 21.0,
    capexPercentRevenue: 5.5,
    nwcPercentRevenue: 4.8,
    interestRatePercent: 5.0
  },
  
  dcfInputs: {
    waccPercent: 9.5,
    terminalGrowthRatePercent: 3.5,
    terminalMethod: 'PERPETUITY',
    exitEbitdaMultiple: 22.0,
    costOfEquityPercent: 11.2,
    costOfDebtPercent: 5.5,
    taxRatePercent: 21.0
  },
  
  selectedCompIds: ['comp-1', 'comp-2', 'comp-3', 'comp-4'],
  ipoDiscountPercent: 15.0,
  
  syndicate: [
    { id: 'syn-1', institutionName: 'Rhino Bank ECM', role: 'Global Coordinator', feeSharePercent: 42.0, commitmentShares: 8820000, leadContact: 'Marcus Sterling (Managing Director)' },
    { id: 'syn-2', institutionName: 'Goldman Sachs & Co.', role: 'Joint Bookrunner', feeSharePercent: 28.0, commitmentShares: 5880000, leadContact: 'Sarah Vance (Partner)' },
    { id: 'syn-3', institutionName: 'Morgan Stanley', role: 'Joint Bookrunner', feeSharePercent: 20.0, commitmentShares: 4200000, leadContact: 'David Chen (Director)' },
    { id: 'syn-4', institutionName: 'J.P. Morgan Securities', role: 'Co-Manager', feeSharePercent: 10.0, commitmentShares: 2100000, leadContact: 'Elena Rostova (Executive Director)' }
  ],
  
  feeUnderwritingPercent: 3.5,
  feeAdvisoryUSD: 12.5,
  feeLegalUSD: 4.8,
  feeAuditUSD: 3.2,
  feeListingAndMarketingUSD: 2.5,
  
  useOfProceeds: [
    { id: 'uop-1', category: 'R&D', amountUSD: 250, percentage: 38.5, description: 'Scaling Next-Gen AI Inference Infrastructure & LLM Optimization' },
    { id: 'uop-2', category: 'Global Expansion', amountUSD: 180, percentage: 27.7, description: 'Expanding Data Centers in EMEA & APAC Enterprise Corridors' },
    { id: 'uop-3', category: 'Acquisitions (M&A)', amountUSD: 120, percentage: 18.5, description: 'Opportunistic M&A of AI Data Engineering Tooling Startups' },
    { id: 'uop-4', category: 'Working Capital', amountUSD: 100, percentage: 15.3, description: 'General Corporate Purposes & Enterprise Sales Hiring' }
  ],
  
  investorBook: [
    { id: 'inv-1', name: 'BlackRock Systematic Equity', category: 'LONG_ONLY', maxAllocationUSD: 350, targetPriceUSD: 42.0, priceSensitivity: 0.15, tier: 'Tier 1 Anchor', requestedShares: 8333333, status: 'Active' },
    { id: 'inv-2', name: 'Fidelity Management & Research', category: 'MUTUAL_FUNDS', maxAllocationUSD: 280, targetPriceUSD: 40.0, priceSensitivity: 0.20, tier: 'Tier 1 Anchor', requestedShares: 7000000, status: 'Active' },
    { id: 'inv-3', name: 'T. Rowe Price Associates', category: 'MUTUAL_FUNDS', maxAllocationUSD: 220, targetPriceUSD: 39.5, priceSensitivity: 0.25, tier: 'Tier 1 Anchor', requestedShares: 5569620, status: 'Active' },
    { id: 'inv-4', name: 'GIC Sovereign Fund (Singapore)', category: 'SOVEREIGN_WEALTH', maxAllocationUSD: 250, targetPriceUSD: 41.5, priceSensitivity: 0.10, tier: 'Tier 1 Anchor', requestedShares: 6024096, status: 'Active' },
    { id: 'inv-5', name: 'Norges Bank Investment Mgmt', category: 'PENSION_FUNDS', maxAllocationUSD: 180, targetPriceUSD: 38.0, priceSensitivity: 0.35, tier: 'Tier 2 Quality', requestedShares: 4736842, status: 'Active' },
    { id: 'inv-6', name: 'Millennium Management', category: 'HEDGE_FUNDS', maxAllocationUSD: 150, targetPriceUSD: 44.0, priceSensitivity: 0.75, tier: 'Tier 3 Speculative', requestedShares: 3409090, status: 'Active' },
    { id: 'inv-7', name: 'Citadel Global Equities', category: 'HEDGE_FUNDS', maxAllocationUSD: 160, targetPriceUSD: 43.5, priceSensitivity: 0.70, tier: 'Tier 3 Speculative', requestedShares: 3678160, status: 'Active' },
    { id: 'inv-8', name: 'Retail Syndicate Pool', category: 'RETAIL', maxAllocationUSD: 120, targetPriceUSD: 38.0, priceSensitivity: 0.50, tier: 'Retail', requestedShares: 3157894, status: 'Active' }
  ],
  
  allocationStrategy: 'TIERED_QUALITY',
  retailAllocationPercent: 10.0,
  
  currentScenario: 'BASE',
  marketConditions: {
    equityVixIndex: 16.2,
    sectorPerformance3M: 8.5,
    tenYearTreasuryRate: 4.15,
    creditSpreadBaa: 1.45,
    ipoMarketActivityIndex: 78,
    investorSentimentIndex: 82
  },
  
  greenshoePercent: 15.0,
  greenshoeExercisedPercent: 100.0,
  
  updatedAt: new Date().toISOString(),
  notes: 'Primary IPO candidate for Rhino Bank ECM Fall 2026 queue. High investor enthusiasm for AI infrastructure plays.'
};

export const SAMPLE_PROJECT_APEX: IPOProjectState = {
  ...INITIAL_PROJECT_TITAN,
  id: 'proj-apex',
  companyName: 'BioGenX Therapeutics',
  sector: 'Biotech & Pharma',
  proposedTicker: 'BGNX',
  proposedExchange: 'NASDAQ',
  newPrimaryShares: 12000000,
  secondarySharesOffered: 2000000,
  selectedCompIds: ['comp-8', 'comp-9'],
  financials: [
    { year: 2023, isForecast: false, revenue: 45.0, grossProfit: 38.0, ebitda: -25.0, ebit: -28.0, netIncome: -26.0, operatingCashFlow: -20.0, freeCashFlow: -28.0, cash: 85.0, debt: 0.0, capex: 8.0, workingCapital: 10.0, employees: 140, customers: 12 },
    { year: 2024, isForecast: false, revenue: 95.0, grossProfit: 82.0, ebitda: 12.0, ebit: 8.0, netIncome: 6.0, operatingCashFlow: 15.0, freeCashFlow: 5.0, cash: 120.0, debt: 0.0, capex: 10.0, workingCapital: 14.0, employees: 210, customers: 28 },
    { year: 2025, isForecast: false, revenue: 190.0, grossProfit: 165.0, ebitda: 55.0, ebit: 48.0, netIncome: 38.0, operatingCashFlow: 50.0, freeCashFlow: 38.0, cash: 180.0, debt: 0.0, capex: 12.0, workingCapital: 20.0, employees: 320, customers: 65 },
    { year: 2026, isForecast: true, revenue: 340.0, grossProfit: 298.0, ebitda: 118.0, ebit: 105.0, netIncome: 82.0, operatingCashFlow: 110.0, freeCashFlow: 88.0, cash: 290.0, debt: 0.0, capex: 22.0, workingCapital: 32.0, employees: 480, customers: 140 }
  ],
  notes: 'Phase III clinical trials successful for precision oncology pipeline.'
};
