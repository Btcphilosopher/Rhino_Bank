export type SectorType = 
  | 'Enterprise Software / AI'
  | 'Biotech & Pharma'
  | 'Fintech & Payments'
  | 'CleanTech & Energy'
  | 'Consumer Tech'
  | 'Industrial & Robotics';

export type JurisdictionType = 'USA' | 'UK' | 'EU (Euronext)' | 'Singapore' | 'Hong Kong';
export type ExchangeType = 'NASDAQ' | 'NYSE' | 'LSE' | 'Euronext' | 'HKEX' | 'SGX';
export type CurrencyType = 'USD' | 'EUR' | 'GBP' | 'HKD' | 'SGD';

export interface Shareholder {
  id: string;
  name: string;
  category: 'Founders' | 'Management' | 'Employees' | 'Venture Capital' | 'Private Equity' | 'Strategic Investors' | 'Other Existing';
  preShares: number;
  secondarySharesSold: number;
  votingRightsMultiplier: number; // e.g. Class B dual-class = 10x
}

export interface SyndicateMember {
  id: string;
  institutionName: string;
  role: 'Global Coordinator' | 'Joint Bookrunner' | 'Co-Manager' | 'Corporate Adviser' | 'Legal Adviser' | 'Auditor' | 'Registrar';
  feeSharePercent: number; // e.g., 40% of underwriting fee
  commitmentShares: number;
  leadContact: string;
}

export interface FinancialYearData {
  year: number;
  isForecast: boolean;
  revenue: number;
  grossProfit: number;
  ebitda: number;
  ebit: number;
  netIncome: number;
  operatingCashFlow: number;
  freeCashFlow: number;
  cash: number;
  debt: number;
  capex: number;
  workingCapital: number;
  employees: number;
  customers: number;
}

export interface ForecastAssumptions {
  horizonYears: 3 | 5 | 7 | 10;
  forecastMethod: 'TOP_DOWN' | 'BOTTOM_UP';
  revenueGrowthRates: number[]; // % array for forecast years
  grossMarginPercent: number;
  opexPercentRevenue: number;
  taxRatePercent: number;
  capexPercentRevenue: number;
  nwcPercentRevenue: number;
  interestRatePercent: number;
}

export interface DCFModelInputs {
  waccPercent: number;
  terminalGrowthRatePercent: number;
  terminalMethod: 'PERPETUITY' | 'EXIT_MULTIPLE';
  exitEbitdaMultiple: number;
  costOfEquityPercent: number;
  costOfDebtPercent: number;
  taxRatePercent: number;
}

export interface TradingCompCompany {
  id: string;
  name: string;
  ticker: string;
  sector: SectorType;
  evRevenue: number;
  evEbitda: number;
  pe: number;
  evEbit: number;
  fcfYield: number;
  revenueGrowth: number;
  ebitdaMargin: number;
}

export interface HistoricalIPO {
  id: string;
  name: string;
  ticker: string;
  sector: SectorType;
  exchange: ExchangeType;
  ipoYear: number;
  ipoValuation: number; // $M
  ipoPrice: number;
  revenue: number;
  revenueGrowth: number;
  ebitdaMargin: number;
  evRevenueMultiple: number;
  firstDayReturn: number; // %
  day30Return: number; // %
  day90Return: number; // %
  year1Return: number; // %
}

export interface SyntheticInvestor {
  id: string;
  name: string;
  category: 'LONG_ONLY' | 'MUTUAL_FUNDS' | 'PENSION_FUNDS' | 'SOVEREIGN_WEALTH' | 'HEDGE_FUNDS' | 'FAMILY_OFFICE' | 'RETAIL' | 'STRATEGIC';
  maxAllocationUSD: number; // $M
  targetPriceUSD: number;
  priceSensitivity: number; // 0 (insensitive) to 1 (highly sensitive)
  tier: 'Tier 1 Anchor' | 'Tier 2 Quality' | 'Tier 3 Speculative' | 'Retail';
  requestedShares: number;
  allocatedShares?: number;
  status: 'Active' | 'Withdrawn' | 'Modified';
}

export interface UseOfProceedsItem {
  id: string;
  category: 'Capex' | 'R&D' | 'Acquisitions (M&A)' | 'Debt Repayment' | 'Working Capital' | 'Global Expansion' | 'Technology' | 'General Corporate';
  amountUSD: number; // $M or %
  percentage: number;
  description: string;
}

export interface ScenarioDefinition {
  id: 'BEAR' | 'BASE' | 'BULL' | 'EXTREME_BULL' | 'EXTREME_BEAR';
  name: string;
  revenueGrowthDelta: number; // e.g. -0.10 for Bear
  ebitdaMarginDelta: number;
  multipleDelta: number;
  ipoDiscountDelta: number;
  investorDemandMultiplier: number;
}

export interface MarketConditionInputs {
  equityVixIndex: number; // e.g., 18.5
  sectorPerformance3M: number; // %
  tenYearTreasuryRate: number; // %
  creditSpreadBaa: number; // %
  ipoMarketActivityIndex: number; // 0-100
  investorSentimentIndex: number; // 0-100
}

export interface IPOProjectState {
  id: string;
  version: string;
  companyName: string;
  sector: SectorType;
  jurisdiction: JurisdictionType;
  proposedExchange: ExchangeType;
  proposedTicker: string;
  ipoDate: string;
  currency: CurrencyType;
  
  // Shareholders / Cap Table
  shareholders: Shareholder[];
  
  // Offering Structure
  newPrimaryShares: number;
  secondarySharesOffered: number;
  targetEquityOfferedPercent: number; // e.g. 20%
  
  // Financial Data
  financials: FinancialYearData[];
  forecastAssumptions: ForecastAssumptions;
  
  // Valuation Engine Parameters
  dcfInputs: DCFModelInputs;
  selectedCompIds: string[];
  ipoDiscountPercent: number; // e.g., 15%
  
  // Syndicate & Fees
  syndicate: SyndicateMember[];
  feeUnderwritingPercent: number; // e.g. 3.5%
  feeAdvisoryUSD: number;
  feeLegalUSD: number;
  feeAuditUSD: number;
  feeListingAndMarketingUSD: number;
  
  // Use of Proceeds
  useOfProceeds: UseOfProceedsItem[];
  
  // Bookbuilding Orders
  investorBook: SyntheticInvestor[];
  
  // Allocation Rules
  allocationStrategy: 'PRO_RATA' | 'TIERED_QUALITY' | 'ANCHOR_PRIORITY' | 'LONG_ONLY_FAVOURED';
  retailAllocationPercent: number; // e.g., 10%
  
  // Market & Scenario
  currentScenario: 'BEAR' | 'BASE' | 'BULL' | 'EXTREME_BULL' | 'EXTREME_BEAR';
  marketConditions: MarketConditionInputs;
  
  // Greenshoe / Overallotment
  greenshoePercent: number; // e.g., 15%
  greenshoeExercisedPercent: number; // e.g. 100%
  
  // Metadata & History
  updatedAt: string;
  notes: string;
}

export interface AuditRecord {
  id: string;
  timestamp: string;
  inputName: string;
  assumptionValue: string | number;
  formulaDescription: string;
  outputResult: string | number;
  modelVersion: string;
}

// Interconnected Calculated Outputs from Digital Twin Core
export interface DigitalTwinCalculations {
  // Financial Forecast
  forecastYears: FinancialYearData[];
  terminalYearFCF: number;
  
  // DCF Output
  dcfEnterpriseValue: number;
  dcfEquityValue: number;
  impliedWacc: number;
  dcfImpliedPricePerShare: number;
  
  // Comps Output
  medianEvRevenue: number;
  medianEvEbitda: number;
  compsImpliedEv: number;
  compsImpliedEquityValue: number;
  
  // Pre-Money / Post-Money Valuation
  preMoneyEquityValue: number;
  postMoneyEquityValue: number;
  enterpriseValue: number;
  
  // Share Count & Pricing Range
  totalPreIpoShares: number;
  totalPostIpoShares: number;
  indicativePriceLow: number;
  indicativePriceMid: number;
  indicativePriceHigh: number;
  finalOfferPrice: number;
  impliedDiscountValuationPercent: number;
  
  // Offering Financials
  primaryProceedsGross: number;
  secondaryProceedsGross: number;
  totalGrossProceeds: number;
  totalTransactionFees: number;
  netPrimaryProceeds: number;
  
  // Cap Table Post-IPO
  postIpoPublicFreeFloatPercent: number;
  foundersPostOwnershipPercent: number;
  mgmtPostOwnershipPercent: number;
  vcPePostOwnershipPercent: number;
  dilutionPercent: number;
  
  // Bookbuilding & Demand
  totalBookDemandUSD: number;
  totalBookDemandShares: number;
  oversubscriptionRatio: number;
  institutionalDemandUSD: number;
  retailDemandUSD: number;
  equilibriumPriceUSD: number;
  
  // Allocation
  allocatedInvestors: SyntheticInvestor[];
  top10InvestorConcentrationIndex: number; // Herfindahl index (0 - 10,000)
  unfilledDemandUSD: number;
  
  // Offer Size Optimizer (10% to 50%)
  sizeOptimizationMatrix: Array<{
    equityOfferedPercent: number;
    sharesIssued: number;
    grossProceeds: number;
    postMarketCap: number;
    dilutionPercent: number;
    freeFloatPercent: number;
    liquidityScore: number;
  }>;
  
  // Market Window & Risk Engine
  ipoMarketWindowScore: number; // 0-100
  marketWindowStatus: 'OPTIMAL_WINDOW' | 'CAUTION_WINDOW' | 'CLOSED_WINDOW';
  ipoRiskScore: number; // 0-100
  riskBreakdown: {
    valuationRisk: number;
    executionRisk: number;
    marketRisk: number;
    liquidityRisk: number;
    demandRisk: number;
    leverageRisk: number;
    dilutionRisk: number;
  };
  
  // Greenshoe Impact
  greenshoeShares: number;
  greenshoeGrossProceeds: number;
  totalOfferedSharesWithGreenshoe: number;
  
  // Aftermarket Trajectory (Simulation)
  aftermarketTrajectory: Array<{
    period: string;
    simulatedPrice: number;
    returnPercent: number;
    benchmarkReturnPercent: number;
  }>;
}
