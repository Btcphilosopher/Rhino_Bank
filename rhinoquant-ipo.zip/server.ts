import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_PROJECT_TITAN, SAMPLE_PROJECT_APEX, TRADING_COMPS_DATABASE, HISTORICAL_IPOS_DATABASE } from './src/data/mockDatabase';
import { runDigitalTwinSimulation } from './src/services/digitalTwinEngine';
import { generateAuditLog } from './src/services/auditLogger';

const app = express();
const PORT = 3000;

app.use(express.json());

// Shared projects store in memory for API routes
const projectsStore: Record<string, any> = {
  'proj-titan': INITIAL_PROJECT_TITAN,
  'proj-apex': SAMPLE_PROJECT_APEX
};

// Gemini AI Client Setup
let aiClient: GoogleGenAI | null = null;
function getGenAIClient() {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// -------------------------------------------------------------
// REST API ROUTES (Requirement #26 API Architecture)
// -------------------------------------------------------------

// 1. Health check
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'ok', platform: 'RhinoQuant IPO ECM Terminal', version: '3.7-PROD', timestamp: new Date().toISOString() });
});

// 2. List projects
app.get('/api/v1/projects', (req, res) => {
  const summary = Object.values(projectsStore).map(p => ({
    id: p.id,
    version: p.version,
    companyName: p.companyName,
    sector: p.sector,
    proposedExchange: p.proposedExchange,
    proposedTicker: p.proposedTicker,
    currency: p.currency,
    updatedAt: p.updatedAt
  }));
  res.json({ projects: summary });
});

// 3. Get Project details and calculations
app.get('/api/v1/projects/:id', (req, res) => {
  const proj = projectsStore[req.params.id];
  if (!proj) {
    return res.status(404).json({ error: 'Project not found' });
  }
  const calc = runDigitalTwinSimulation(proj);
  const audit = generateAuditLog(proj, calc);
  res.json({ project: proj, calculations: calc, auditTrail: audit });
});

// 4. Digital Twin Simulation endpoint
app.post('/api/v1/projects/:id/simulate', (req, res) => {
  const baseProj = projectsStore[req.params.id] || INITIAL_PROJECT_TITAN;
  const updatedState = { ...baseProj, ...req.body };
  const calc = runDigitalTwinSimulation(updatedState);
  res.json({ calculations: calc });
});

// 5. Research Comps database
app.get('/api/v1/comps', (req, res) => {
  res.json({ comps: TRADING_COMPS_DATABASE });
});

// 6. Historical IPOs database
app.get('/api/v1/historical-ipos', (req, res) => {
  res.json({ historicalIpos: HISTORICAL_IPOS_DATABASE });
});

// 7. AI Executive ECM Advisor Memo
app.post('/api/ai/advise', async (req, res) => {
  try {
    const { projectState, calcResults, queryType } = req.body;
    const ai = getGenAIClient();

    if (!ai) {
      return res.json({
        memo: `[Rhino Bank ECM AI Advisor Offline - Local Fallback Mode]\n\nDeal Briefing for ${projectState?.companyName || 'Target Company'}:\n- Proposed Valuation: $${calcResults?.postMoneyEquityValue || 'N/A'}M\n- Final Offer Price: $${calcResults?.finalOfferPrice || 'N/A'}/share\n- Book Oversubscription: ${calcResults?.oversubscriptionRatio || 'N/A'}x\n- Market Window Score: ${calcResults?.ipoMarketWindowScore || 'N/A'}/100 (${calcResults?.marketWindowStatus || 'N/A'})\n\nRecommendation: Proceed with syndicate roadshow. Maintain 15% valuation discount to preserve first-day aftermarket stability.`
      });
    }

    const prompt = `You are the Senior ECM Managing Director & Head of Syndicate at Rhino Bank.
Provide an executive, high-density Investment Banking Deal Advisory Memo for the following proposed IPO deal.

Deal Context:
- Company: ${projectState?.companyName} (${projectState?.sector})
- Proposed Exchange: ${projectState?.proposedExchange} (${projectState?.proposedTicker})
- Pre-Money Equity Value: $${calcResults?.preMoneyEquityValue}M
- Post-Money Market Cap: $${calcResults?.postMoneyEquityValue}M
- Final Offer Price: $${calcResults?.finalOfferPrice} / share
- Target IPO Discount: ${calcResults?.impliedDiscountValuationPercent}%
- Total Gross Proceeds: $${calcResults?.totalGrossProceeds}M (Primary: $${calcResults?.primaryProceedsGross}M, Secondary: $${calcResults?.secondaryProceedsGross}M)
- Book Oversubscription: ${calcResults?.oversubscriptionRatio}x (Total Demand: $${calcResults?.totalBookDemandUSD}M)
- IPO Market Window Score: ${calcResults?.ipoMarketWindowScore}/100 (${calcResults?.marketWindowStatus})
- Integrated IPO Risk Score: ${calcResults?.ipoRiskScore}/100
- Syndicate Leader: ${projectState?.syndicate?.[0]?.institutionName || 'Rhino Bank ECM'}

User Focus Request: ${queryType || 'General Strategic Pricing & Allocation Briefing'}

Instructions:
Format as a professional investment bank deal memorandum with 4 short, crisp sections:
1. EXECUTIVE SUMMARY & DEAL ATTRACTIVENESS
2. VALUATION & DISCOUNT STRATEGY (DCF vs Comps)
3. BOOKBUILDING, DEMAND ELASTICITY & ALLOCATION RISK
4. SYNDICATE RECOMMENDATION & MARKET WINDOW TACTICS

Keep it institutional, concise, authoritative, with numeric highlights and bold key takeaways.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an institutional ECM Managing Director at Rhino Bank writing confidential IPO deal memos.',
        temperature: 0.7
      }
    });

    res.json({ memo: response.text });
  } catch (err: any) {
    console.error('Gemini AI Advisor Error:', err);
    res.status(500).json({ error: err.message || 'Failed to generate AI ECM Memo' });
  }
});

// -------------------------------------------------------------
// VITE / STATIC SERVER SETUP
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[RHINOQUANT IPO] Server running on http://localhost:${PORT}`);
  });
}

startServer();
