# NATIONAL COAL BOARD — NCB TERMINAL
### Production-Grade Android Application | Industrial Supermodernity

## 1. Overview & Core Identity
**NCB TERMINAL** represents a modernised National Coal Board, imagined as if the industrial computing vision of the 1980s had advanced directly into the 2020s. 

- **Primary Visual Identity**: Strict black and gold theme (`#000000` pitch black background, `#FFC247` primary amber, `#D99A16` deep industrial gold, `#FFD166` highlight gold).
- **Core Pillars**: Energy, Industry, Britain, Coal, Production, Logistics, Markets, Mainframe Control.

---

## 2. Global Standards
### A. Monetary Standard: GBP (£) Exclusively
- **Mandate**: All monetary values throughout all modules, tables, terminal commands, and contracts are expressed strictly in **GBP (£)**. No USD, EUR, or foreign exchange panels exist.
- **Formulas**:
  $$\text{Revenue (£)} = \text{Tonnes} \times \text{Price (£/t)}$$
  $$\text{Effective Energy Price (£/MMBtu)} = \frac{\text{Price (£/t)}}{\text{MMBtu/tonne}}$$

### B. Energy Standard: BTU-Based Units Exclusively
- **Mandate**: All thermal energy quantities use British thermal units (**BTU**, **kBTU**, **MMBtu**, **BTU/lb**).
- **Conversion Factor**: 
  $$1\text{ Metric Tonne (MT)} = 1,000\text{ kg} = 2,204.62262185\text{ lbs}$$
- **Calorific Baseline**: $11,200\text{ BTU/lb}$ (British Bituminous Steam Coal baseline, configurable per coal grade up to $13,200\text{ BTU/lb}$ for Welsh Anthracite).
- **Thermal Intensity**:
  $$\text{MMBtu per Tonne} = \frac{2,204.62262 \times \text{BTU/lb}}{1,000,000} \approx 24.69\text{ MMBtu/tonne}$$
- **Total MMBtu**:
  $$\text{Total MMBtu} = \frac{\text{Tonnes} \times 2,204.62262 \times \text{BTU/lb}}{1,000,000}$$

---

## 3. Architecture & Data Flow
The application adopts an enterprise MVVM Clean Architecture:
```
┌────────────────────────────────────────────────────────┐
│                   JETPACK COMPOSE UI                   │
│   Overview, Production, Logistics, Markets, Contracts, │
│   Assets, Reports, Terminal CLI, Telemetry Inspector   │
└───────────────────────────▲────────────────────────────┘
                            │ StateFlow
┌───────────────────────────┴────────────────────────────┐
│                  NcbTerminalViewModel                  │
│    Navigation Routing, Command Dispatch, Telemetry     │
└─────────────▲─────────────────────────────▲────────────┘
              │                             │
┌─────────────┴─────────────┐ ┌─────────────┴────────────┐
│   MiningSimulationEngine  │ │       Data Layer         │
│ • 3D Vehicle Kinematics   │ │ • Room Database (SQLite) │
│ • Dragline Slew & Bucket  │ │   - ContractEntity       │
│ • Sheave Rotation & Radar │ │   - LogEntity            │
│ • Production & Del. Stream│ │   - ProductionRecord     │
│ • Live Event Generator    │ │ • DataStore Preferences  │
└───────────────────────────┘ └──────────────────────────┘
```

---

## 4. 3D Mining Digital Twin Renderer
The central mining simulation is implemented via a dedicated vector and projection engine (`com.example.renderer`):
1. **Geometric Foundations**:
   - 6 concentric stepped excavation benches with sloping terraced walls.
   - Front cutaway geological strata exposing Top Hard, Barnsley, and Silkstone coal seams.
   - 4-leg headframe winding tower with rotating dual sheave wheels.
   - Overland conveyor truss gantry with moving animated coal particles.
   - Walking Dragline Excavator with articulated boom, hoist cable, and dipping bucket.
   - Haul truck fleet navigating 3D haul road waypoints along pit benches.
2. **Interactive Controls**:
   - Orbit: Drag horizontally and vertically to rotate the camera in 360°.
   - Zoom: Two-finger pinch to scale smoothly from 0.55x to 2.8x.
   - Inspection: Tap any haul truck, excavator, conveyor, or strata wall for detailed engineering telemetry.
   - Reset: Dedicated button and double-tap gesture to restore default isometric view.

---

## 5. Mainframe Command Interpreter
The Terminal interface implements a full parser (`TerminalCommandParser`):
- `STATUS`: Overall system and colliery health.
- `PRODUCTION [--period]`: Current output and recovery rates.
- `MINES [--list]`: UK colliery sites, coordinates, and depths.
- `ASSETS [--status]`: Heavy machinery and fleet power draw (kBTU/h).
- `LOGISTICS [--deliveries]`: Rail freight train movements and port terminals.
- `MARKETS [--currency GBP]`: Real-time commodity benchmarks in £/t.
- `CONTRACTS [--active]`: Off-taker agreements and committed volumes.
- `STOCKS`: Strategic stockpile reserves.
- `ENERGY [--unit MMBtu]`: Conversion documentation and energy intensity.
- `QUALITY`: Coal seam analysis, ash content, and calorific values.
- `REPORTS`: Official shift and financial statements.
- `CLEAR`: Clears terminal output.

---

## 6. Build, Test & Run Instructions
To compile the application:
```bash
# Run unit tests (Energy conversions, terminal parser)
gradle :app:testDebugUnitTest

# Assemble Debug APK
gradle :app:assembleDebug
```
The resulting debug APK is located at:
`app/build/outputs/apk/debug/app-debug.apk`
