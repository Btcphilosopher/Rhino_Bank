package com.example

import com.example.data.simulation.MiningSimulationEngine
import com.example.terminal.TerminalCommandParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TerminalCommandParserTest {

    private val engine = MiningSimulationEngine(CoroutineScope(Dispatchers.Unconfined))

    @Test
    fun testHelpCommand() {
        val state = engine.state.value
        val result = TerminalCommandParser.execute("HELP", state)
        assertTrue(result.output.contains("NATIONAL COAL BOARD"))
        assertTrue(result.output.contains("STATUS"))
        assertTrue(result.output.contains("PRODUCTION"))
    }

    @Test
    fun testStatusCommand() {
        val state = engine.state.value
        val result = TerminalCommandParser.execute("STATUS", state)
        assertTrue(result.output.contains("[SYSTEM STATUS: ONLINE]"))
        assertTrue(result.output.contains("COLLIERY SITES: 7 / 7"))
    }

    @Test
    fun testProductionCommandWithArgs() {
        val state = engine.state.value
        val result = TerminalCommandParser.execute("PRODUCTION --period today", state)
        assertTrue(result.output.contains("NCB NATIONAL PRODUCTION TELEMETRY"))
        assertTrue(result.output.contains("Kellingley"))
        assertTrue(result.output.contains("MMBtu"))
    }

    @Test
    fun testMarketsCommandGbpOnly() {
        val state = engine.state.value
        val result = TerminalCommandParser.execute("MARKETS --currency GBP", state)
        assertTrue(result.output.contains("UK COAL COMMODITY MARKETS"))
        assertTrue(result.output.contains("£"))
        assertFalse(result.output.contains("USD"))
        assertFalse(result.output.contains("EUR"))
    }

    @Test
    fun testEnergyCommand() {
        val state = engine.state.value
        val result = TerminalCommandParser.execute("ENERGY --unit MMBtu", state)
        assertTrue(result.output.contains("GLOBAL ENERGY STANDARD"))
        assertTrue(result.output.contains("BTU-BASED MEASUREMENTS"))
        assertTrue(result.output.contains("11,200 BTU/lb"))
    }

    @Test
    fun testClearCommand() {
        val state = engine.state.value
        val result = TerminalCommandParser.execute("CLEAR", state)
        assertTrue(result.isClear)
    }

    @Test
    fun testUnknownCommandError() {
        val state = engine.state.value
        val result = TerminalCommandParser.execute("INVALID_COMMAND_XYZ", state)
        assertTrue(result.output.startsWith("ERR: UNRECOGNIZED COMMAND"))
    }
}
