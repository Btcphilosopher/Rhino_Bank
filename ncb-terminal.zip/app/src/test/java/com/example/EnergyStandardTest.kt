package com.example

import com.example.model.EnergyStandard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EnergyStandardTest {

    @Test
    fun testMmbTuCalculation() {
        // 1 Metric Tonne = 2,204.6226 lbs
        // At 11,200 BTU/lb:
        // Total BTU = 1 * 2204.62262 * 11200 = 24,691,773.3 BTU -> ~24.69 MMBtu
        val mmbtu = EnergyStandard.calculateMmbTu(1.0, 11200.0)
        assertEquals(24.6917, mmbtu, 0.01)

        // 1,000,000 tonnes at 11,200 BTU/lb
        val largeMmbTu = EnergyStandard.calculateMmbTu(1_000_000.0, 11200.0)
        assertEquals(24_691_773.3, largeMmbTu, 100.0)
    }

    @Test
    fun testMmbTuPerTonneIntensity() {
        val intensity = EnergyStandard.calculateMmbTuPerTonne(11200.0)
        assertTrue(intensity > 24.6 && intensity < 24.8)
    }

    @Test
    fun testRevenueCalculationGbp() {
        // 100,000 tonnes @ £142.60/t = £14,260,000
        val rev = EnergyStandard.calculateRevenueGbp(100000.0, 142.60)
        assertEquals(14_260_000.0, rev, 0.001)

        val formatted = EnergyStandard.formatGbp(rev)
        assertEquals("£14.26 million", formatted)

        val largeGbp = EnergyStandard.formatGbp(2_400_000_000.0)
        assertEquals("£2.40 billion", largeGbp)

        val pricePerTonne = EnergyStandard.formatGbpPerTonne(142.60)
        assertEquals("£142.60/t", pricePerTonne)
    }

    @Test
    fun testEnergyParityPrice() {
        // Price £142.60/t, ~24.69 MMBtu/t -> £142.60 / 24.6917 = £5.77 / MMBtu
        val gbpPerMmbTu = EnergyStandard.calculateGbpPerMmbTu(142.60, 11200.0)
        assertEquals(5.77, gbpPerMmbTu, 0.05)
    }

    @Test
    fun testFormatting() {
        val formattedTonnes = EnergyStandard.formatTonnes(1248600.0)
        assertTrue(formattedTonnes.contains("1,248,600"))
        assertTrue(formattedTonnes.endsWith("t"))

        val calorific = EnergyStandard.formatCalorificValue(11800.0)
        assertEquals("11,800 BTU/lb", calorific)
    }
}
