package com.example.renderer

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

data class BenchContour(
    val levelIndex: Int,
    val elevationMeters: Float,
    val points: List<Vector3>
)

data class GeologicalCutaway(
    val topPoints: List<Vector3>,
    val bottomPoints: List<Vector3>,
    val seamDepthMeters: Float,
    val seamName: String
)

data class StructureWireframe(
    val id: String,
    val name: String,
    val edges: List<Pair<Vector3, Vector3>>,
    val center: Vector3
)

object MineSceneGeometry {

    // Bench elevations
    val BENCH_LEVELS = listOf(
        0f,     // Surface Rim
        -35f,   // Bench 1 - Top Hard Seam
        -75f,   // Bench 2 - Overburden Intermediate
        -115f,  // Bench 3 - Barnsley Main Seam (Excavation Face)
        -150f,  // Bench 4 - Silkstone Coking Seam
        -182f   // Pit Floor / Sump
    )

    /**
     * Generates terraced open-cast benches with a cutaway front sector (from -35° to 95°)
     * exactly like the reference image.
     */
    fun generateBenches(segments: Int = 36): List<BenchContour> {
        val contours = mutableListOf<BenchContour>()

        BENCH_LEVELS.forEachIndexed { index, zMeters ->
            val factor = 1.0f - (index * 0.14f)
            val radiusX = 140f * factor
            val radiusY = 85f * factor
            val points = mutableListOf<Vector3>()

            // We cut away the front corner (between 0.05*PI and 0.55*PI) to expose geological strata
            val startAngle = 0.55 * PI
            val endAngle = 2.05 * PI
            val step = (endAngle - startAngle) / segments

            for (i in 0..segments) {
                val angle = startAngle + i * step
                // subtle noise/terracing curve
                val perturb = (sin(angle * 4.0) * 2.5f).toFloat()
                val x = ((radiusX + perturb) * cos(angle)).toFloat()
                val y = ((radiusY + perturb) * sin(angle)).toFloat()
                // Convert elevation: 1m depth = 0.5 unit in 3D space
                points.add(Vector3(x, y, zMeters * 0.45f))
            }

            contours.add(BenchContour(index, zMeters, points))
        }

        return contours
    }

    /**
     * Generates the layered geological strata face on the front cutaway wall.
     */
    fun generateStrataCutaway(): List<GeologicalCutaway> {
        val layers = mutableListOf<GeologicalCutaway>()

        // 3 major visible coal seams in the cutaway wall
        val seamConfigs = listOf(
            Triple(-25f, -40f, "TOP HARD SEAM (11,200 BTU/lb)"),
            Triple(-85f, -105f, "BARNSLEY HIGH-BTU SEAM (11,800 BTU/lb)"),
            Triple(-140f, -165f, "SILKSTONE COKING SEAM (12,400 BTU/lb)")
        )

        val wallX1 = 30f
        val wallY1 = 45f
        val wallX2 = 135f
        val wallY2 = 25f

        seamConfigs.forEach { (topZ, bottomZ, name) ->
            val top = listOf(
                Vector3(wallX1, wallY1, topZ * 0.45f),
                Vector3((wallX1 + wallX2) / 2f, (wallY1 + wallY2) / 2f, topZ * 0.45f),
                Vector3(wallX2, wallY2, topZ * 0.45f)
            )
            val bottom = listOf(
                Vector3(wallX1, wallY1, bottomZ * 0.45f),
                Vector3((wallX1 + wallX2) / 2f, (wallY1 + wallY2) / 2f, bottomZ * 0.45f),
                Vector3(wallX2, wallY2, bottomZ * 0.45f)
            )
            layers.add(GeologicalCutaway(top, bottom, topZ, name))
        }

        return layers
    }

    /**
     * Surface headframe winding tower with lattice structure.
     */
    fun generateHeadframe(): StructureWireframe {
        val basePos = Vector3(95f, -45f, 0f)
        val height = 48f
        val width = 14f

        val b1 = basePos + Vector3(-width / 2, -width / 2, 0f)
        val b2 = basePos + Vector3(width / 2, -width / 2, 0f)
        val b3 = basePos + Vector3(width / 2, width / 2, 0f)
        val b4 = basePos + Vector3(-width / 2, width / 2, 0f)

        val t1 = basePos + Vector3(-width * 0.35f, -width * 0.35f, height)
        val t2 = basePos + Vector3(width * 0.35f, -width * 0.35f, height)
        val t3 = basePos + Vector3(width * 0.35f, width * 0.35f, height)
        val t4 = basePos + Vector3(-width * 0.35f, width * 0.35f, height)

        val backLeg1 = basePos + Vector3(-width * 1.5f, width * 0.8f, 0f)
        val backLeg2 = basePos + Vector3(-width * 1.5f, -width * 0.8f, 0f)

        val edges = mutableListOf<Pair<Vector3, Vector3>>()

        // Base rectangle
        edges.add(b1 to b2); edges.add(b2 to b3); edges.add(b3 to b4); edges.add(b4 to b1)
        // Top rectangle
        edges.add(t1 to t2); edges.add(t2 to t3); edges.add(t3 to t4); edges.add(t4 to t1)
        // Columns
        edges.add(b1 to t1); edges.add(b2 to t2); edges.add(b3 to t3); edges.add(b4 to t4)
        // X-bracing
        edges.add(b1 to t2); edges.add(b2 to t1)
        edges.add(b3 to t4); edges.add(b4 to t3)
        // Back-stay diagonal braces
        edges.add(backLeg1 to t4); edges.add(backLeg2 to t1)

        // Sheave wheel platform & wheel circles
        val sheaveCenter1 = basePos + Vector3(-2f, 0f, height + 4f)
        val sheaveCenter2 = basePos + Vector3(2f, 0f, height + 4f)
        val wheelRadius = 5.5f

        val wheelSegments = 12
        for (i in 0 until wheelSegments) {
            val a1 = (i * 2 * PI / wheelSegments).toFloat()
            val a2 = ((i + 1) * 2 * PI / wheelSegments).toFloat()

            val p1A = sheaveCenter1 + Vector3(0f, cos(a1) * wheelRadius, sin(a1) * wheelRadius)
            val p2A = sheaveCenter1 + Vector3(0f, cos(a2) * wheelRadius, sin(a2) * wheelRadius)
            edges.add(p1A to p2A)

            val p1B = sheaveCenter2 + Vector3(0f, cos(a1) * wheelRadius, sin(a1) * wheelRadius)
            val p2B = sheaveCenter2 + Vector3(0f, cos(a2) * wheelRadius, sin(a2) * wheelRadius)
            edges.add(p1B to p2B)

            // Wheel spokes
            if (i % 3 == 0) {
                edges.add(sheaveCenter1 to p1A)
                edges.add(sheaveCenter2 to p1B)
            }
        }

        return StructureWireframe(
            id = "STR-HEADFRAME-01",
            name = "Kellingley Pit Headframe No. 2",
            edges = edges,
            center = basePos + Vector3(0f, 0f, height / 2)
        )
    }

    /**
     * Long elevated overland conveyor gantry crossing the pit rim.
     */
    fun generateConveyorGantry(): StructureWireframe {
        val start = Vector3(85f, -40f, 2f)
        val mid = Vector3(15f, -15f, 4f)
        val end = Vector3(-65f, 15f, 6f)

        val edges = mutableListOf<Pair<Vector3, Vector3>>()

        // Main conveyor truss rails (left and right)
        val offset = Vector3(-1.5f, 1.5f, 0f)
        val r1Start = start + offset; val r1Mid = mid + offset; val r1End = end + offset
        val r2Start = start - offset; val r2Mid = mid - offset; val r2End = end - offset

        edges.add(r1Start to r1Mid); edges.add(r1Mid to r1End)
        edges.add(r2Start to r2Mid); edges.add(r2Mid to r2End)

        // Truss ties
        val steps = 14
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val pt1 = lerp(r1Start, r1End, t)
            val pt2 = lerp(r2Start, r2End, t)
            edges.add(pt1 to pt2)

            // Support piers every 3 steps down to ground
            if (i % 3 == 0 && i in 2..(steps - 1)) {
                val groundZ = if (t < 0.4f) -12f else if (t < 0.7f) -35f else -50f
                val pierLeft = Vector3(pt1.x, pt1.y, groundZ)
                val pierRight = Vector3(pt2.x, pt2.y, groundZ)
                edges.add(pt1 to pierLeft)
                edges.add(pt2 to pierRight)
                edges.add(pierLeft to pierRight)
                edges.add(pt1 to pierRight) // Cross-brace
            }
        }

        return StructureWireframe(
            id = "CV-OVERLAND-TRUNK",
            name = "Main Overland Trunk Conveyor (4,200 t/h)",
            edges = edges,
            center = mid
        )
    }

    /**
     * Crushing, screening & rail load-out facility.
     */
    fun generateCrushingPlant(): StructureWireframe {
        val base = Vector3(-75f, 22f, 0f)
        val w = 18f
        val l = 24f
        val h = 18f

        val c1 = base + Vector3(-w / 2, -l / 2, 0f)
        val c2 = base + Vector3(w / 2, -l / 2, 0f)
        val c3 = base + Vector3(w / 2, l / 2, 0f)
        val c4 = base + Vector3(-w / 2, l / 2, 0f)

        val t1 = c1 + Vector3(0f, 0f, h)
        val t2 = c2 + Vector3(0f, 0f, h)
        val t3 = c3 + Vector3(0f, 0f, h)
        val t4 = c4 + Vector3(0f, 0f, h)

        val edges = mutableListOf<Pair<Vector3, Vector3>>()
        edges.add(c1 to c2); edges.add(c2 to c3); edges.add(c3 to c4); edges.add(c4 to c1)
        edges.add(t1 to t2); edges.add(t2 to t3); edges.add(t3 to t4); edges.add(t4 to t1)
        edges.add(c1 to t1); edges.add(c2 to t2); edges.add(c3 to t3); edges.add(c4 to t4)
        // Roof gable
        val ridge = base + Vector3(0f, 0f, h + 6f)
        edges.add(t1 to ridge); edges.add(t2 to ridge); edges.add(t3 to ridge); edges.add(t4 to ridge)

        return StructureWireframe(
            id = "PLANT-CRUSH-01",
            name = "Primary Rotary Breaker & Screening Plant",
            edges = edges,
            center = base + Vector3(0f, 0f, h / 2)
        )
    }

    /**
     * Haul road waypoints along benches down to the pit floor.
     */
    fun getHaulRoadWaypoints(): List<Vector3> {
        return listOf(
            Vector3(-70f, 15f, 0f),      // 0: Surface Crusher Dump Hopper
            Vector3(-55f, 0f, -8f),       // 1: Ramp 1 Top
            Vector3(-40f, -25f, -16f),    // 2: Bench 1 North
            Vector3(-10f, -40f, -25f),    // 3: Bench 2 Switchback
            Vector3(25f, -30f, -38f),     // 4: Bench 3 Loading Face
            Vector3(15f, 0f, -50f),       // 5: Bench 4 Lower Shovel
            Vector3(-15f, 15f, -65f),     // 6: Pit Floor Sump
            Vector3(0f, 25f, -52f),       // 7: Ascent Ramp Lower
            Vector3(30f, 10f, -35f),      // 8: Ascent Switchback
            Vector3(0f, -20f, -18f),      // 9: Ascent Upper Ramp
            Vector3(-50f, 5f, -2f)        // 10: Crusher Approach
        )
    }

    private fun lerp(v1: Vector3, v2: Vector3, t: Float): Vector3 {
        return Vector3(
            v1.x + (v2.x - v1.x) * t,
            v1.y + (v2.y - v1.y) * t,
            v1.z + (v2.z - v1.z) * t
        )
    }
}
