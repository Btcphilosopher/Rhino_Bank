package com.example.renderer

import kotlin.math.cos
import kotlin.math.sin

data class Vector3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(other: Vector3) = Vector3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3) = Vector3(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Float) = Vector3(x * scalar, y * scalar, z * scalar)
}

data class ProjectedPoint(
    val screenX: Float,
    val screenY: Float,
    val depth: Float,
    val visible: Boolean = true
)

class Camera3D(
    var yawDeg: Float = 35f,       // Horizontal orbit
    var pitchDeg: Float = -38f,    // Elevation looking down into pit
    var zoom: Float = 1.0f,
    var panX: Float = 0f,
    var panY: Float = 0f
) {
    fun project(
        point: Vector3,
        centerX: Float,
        centerY: Float,
        baseScale: Float
    ): ProjectedPoint {
        val yawRad = Math.toRadians(yawDeg.toDouble()).toFloat()
        val pitchRad = Math.toRadians(pitchDeg.toDouble()).toFloat()

        // Rotate around Z axis (Yaw)
        val cosY = cos(yawRad)
        val sinY = sin(yawRad)
        val x1 = point.x * cosY - point.y * sinY
        val y1 = point.x * sinY + point.y * cosY
        val z1 = point.z

        // Rotate around X axis (Pitch)
        val cosP = cos(pitchRad)
        val sinP = sin(pitchRad)
        val y2 = y1 * cosP - z1 * sinP
        val z2 = y1 * sinP + z2FromZ(z1, cosP)

        // Orthographic with subtle depth scaling for industrial isometric look
        val scale = baseScale * zoom
        val screenX = centerX + panX + (x1 * scale)
        val screenY = centerY + panY + (y2 * scale)

        return ProjectedPoint(
            screenX = screenX,
            screenY = screenY,
            depth = z2
        )
    }

    private fun z2FromZ(z: Float, cosP: Float): Float {
        return z * cosP
    }
}
