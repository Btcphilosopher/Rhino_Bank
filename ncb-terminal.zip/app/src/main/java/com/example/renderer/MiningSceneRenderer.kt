package com.example.renderer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.model.DraglineExcavator
import com.example.model.HaulTruck
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDark
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbAmberSubtle
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbGreen
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

data class InspectedAsset(
    val title: String,
    val type: String,
    val location: String,
    val status: String,
    val currentRate: String,
    val energyDraw: String,
    val details: String
)

@Composable
fun MiningSceneRenderer(
    simulationState: SimulationState,
    onInspectAsset: (InspectedAsset) -> Unit,
    modifier: Modifier = Modifier
) {
    // 3D Camera State
    var yawDeg by remember { mutableFloatStateOf(42f) }
    var pitchDeg by remember { mutableFloatStateOf(-36f) }
    var zoom by remember { mutableFloatStateOf(1.0f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }

    // Layer Visibilities
    var showTerrain by remember { mutableStateOf(true) }
    var showGeology by remember { mutableStateOf(true) }
    var showMachinery by remember { mutableStateOf(true) }
    var showFlow by remember { mutableStateOf(true) }
    var autoOrbit by remember { mutableStateOf(false) }

    val camera = remember { Camera3D(yawDeg, pitchDeg, zoom, panX, panY) }
    camera.yawDeg = if (autoOrbit) (yawDeg + 0.15f) % 360f else yawDeg
    camera.pitchDeg = pitchDeg
    camera.zoom = zoom
    camera.panX = panX
    camera.panY = panY

    val benches = remember { MineSceneGeometry.generateBenches(segments = 40) }
    val strataCutaways = remember { MineSceneGeometry.generateStrataCutaway() }
    val headframe = remember { MineSceneGeometry.generateHeadframe() }
    val conveyor = remember { MineSceneGeometry.generateConveyorGantry() }
    val crusher = remember { MineSceneGeometry.generateCrushingPlant() }

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .background(NcbBlack)
            .testTag("mining_scene_container")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, gestureZoom, _ ->
                        zoom = (zoom * gestureZoom).coerceIn(0.55f, 2.8f)
                        yawDeg = (yawDeg + pan.x * 0.25f) % 360f
                        pitchDeg = (pitchDeg - pan.y * 0.2f).coerceIn(-75f, -15f)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            yawDeg = 42f
                            pitchDeg = -36f
                            zoom = 1.0f
                            panX = 0f
                            panY = 0f
                        },
                        onTap = { offset ->
                            // Hit test for inspection
                            checkAssetTap(
                                offset,
                                camera,
                                size.width.toFloat(),
                                size.height.toFloat(),
                                simulationState,
                                onInspectAsset
                            )
                        }
                    )
                }
        ) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.52f
            val baseScale = size.width * 0.0036f

            // 1. Draw Background Grid & Survey HUD
            drawSurveyGrid(this)

            // 2. Draw Terraced Excavation Benches
            if (showTerrain) {
                drawTerracedBenches(benches, camera, cx, cy, baseScale, simulationState.scanWaveProgress)
            }

            // 3. Draw Geological Strata Cutaway Wall
            if (showGeology) {
                drawGeologicalStrata(strataCutaways, camera, cx, cy, baseScale, textMeasurer)
            }

            // 4. Draw Fixed Infrastructure (Headframe, Conveyor, Crusher)
            if (showMachinery) {
                drawStructure(headframe, camera, cx, cy, baseScale)
                drawStructure(conveyor, camera, cx, cy, baseScale)
                drawStructure(crusher, camera, cx, cy, baseScale)

                // Headframe Spinning Sheave Wheels
                drawSpinningSheaves(headframe.center, simulationState.sheaveRotationAngle, camera, cx, cy, baseScale)
            }

            // 5. Draw Conveyor Coal Production Particles
            if (showFlow) {
                drawConveyorFlow(conveyor, simulationState.conveyorParticleOffsets, camera, cx, cy, baseScale)
            }

            // 6. Draw Mobile Equipment (Dragline & Haul Trucks)
            if (showMachinery) {
                drawDragline(simulationState.dragline, camera, cx, cy, baseScale)
                drawHaulTrucks(simulationState.haulTrucks, camera, cx, cy, baseScale, textMeasurer)
            }

            // 7. Draw HUD telemetry overlay
            drawTelemetryOverlay(this, textMeasurer)
        }

        // Layer & Camera Controls Overlay (Top Right / Bottom Right)
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AssistChip(
                onClick = { autoOrbit = !autoOrbit },
                label = { Text(if (autoOrbit) "ORBIT ON" else "ORBIT", fontSize = 10.sp, color = NcbAmber) },
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = if (autoOrbit) NcbAmberSubtle else NcbBlack,
                    labelColor = NcbAmber
                ),
                border = AssistChipDefaults.assistChipBorder(borderColor = NcbAmberDark, enabled = true),
                modifier = Modifier.padding(end = 4.dp).testTag("orbit_toggle_btn")
            )

            AssistChip(
                onClick = { showGeology = !showGeology },
                label = { Text(if (showGeology) "STRATA: ON" else "STRATA: OFF", fontSize = 10.sp, color = if (showGeology) NcbAmberHighlight else NcbAmberMuted) },
                colors = AssistChipDefaults.assistChipColors(containerColor = NcbBlack),
                border = AssistChipDefaults.assistChipBorder(borderColor = NcbAmberDark, enabled = true),
                modifier = Modifier.padding(end = 4.dp).testTag("strata_layer_btn")
            )

            IconButton(
                onClick = {
                    yawDeg = 42f
                    pitchDeg = -36f
                    zoom = 1.0f
                    panX = 0f
                    panY = 0f
                },
                modifier = Modifier.size(32.dp).testTag("reset_camera_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset Camera",
                    tint = NcbAmber
                )
            }
        }
    }
}

// DRAWING PRIMITIVES

private fun drawSurveyGrid(scope: DrawScope) {
    val step = 48f
    val stroke = Stroke(width = 0.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 8f), 0f))
    var x = 0f
    while (x < scope.size.width) {
        scope.drawLine(NcbAmberSubtle, Offset(x, 0f), Offset(x, scope.size.height), strokeWidth = 0.5f)
        x += step
    }
    var y = 0f
    while (y < scope.size.height) {
        scope.drawLine(NcbAmberSubtle, Offset(0f, y), Offset(scope.size.width, y), strokeWidth = 0.5f)
        y += step
    }
}

private fun DrawScope.drawTerracedBenches(
    benches: List<BenchContour>,
    camera: Camera3D,
    cx: Float,
    cy: Float,
    scale: Float,
    scanProgress: Float
) {
    val projectedBenches = benches.map { bench ->
        bench to bench.points.map { camera.project(it, cx, cy, scale) }
    }

    // Draw Bench Contour rings
    projectedBenches.forEachIndexed { index, (bench, projPoints) ->
        if (projPoints.size > 1) {
            val path = Path()
            path.moveTo(projPoints.first().screenX, projPoints.first().screenY)
            for (i in 1 until projPoints.size) {
                path.lineTo(projPoints[i].screenX, projPoints[i].screenY)
            }

            val isFloor = index == benches.lastIndex
            val color = if (isFloor) NcbAmberHighlight else if (index % 2 == 0) NcbAmber else NcbAmberDeep
            val strokeW = if (isFloor) 1.8f else 1.2f

            drawPath(path, color = color, style = Stroke(width = strokeW))

            // Connect vertical slope ribs to previous bench
            if (index > 0) {
                val prevPoints = projectedBenches[index - 1].second
                val step = 4
                for (i in 0 until minOf(projPoints.size, prevPoints.size) step step) {
                    val p1 = prevPoints[i]
                    val p2 = projPoints[i]
                    drawLine(
                        color = NcbAmberMuted,
                        start = Offset(p1.screenX, p1.screenY),
                        end = Offset(p2.screenX, p2.screenY),
                        strokeWidth = 0.8f
                    )
                }
            }
        }
    }

    // Draw animated scanning radar pulse across benches
    if (projectedBenches.isNotEmpty()) {
        val scanIndex = (scanProgress * projectedBenches.size).toInt().coerceIn(0, projectedBenches.lastIndex)
        val scanPoints = projectedBenches[scanIndex].second
        if (scanPoints.size > 1) {
            val scanPath = Path()
            scanPath.moveTo(scanPoints.first().screenX, scanPoints.first().screenY)
            for (p in scanPoints) {
                scanPath.lineTo(p.screenX, p.screenY)
            }
            drawPath(scanPath, color = NcbAmberHighlight, style = Stroke(width = 2.4f))
        }
    }
}

private fun DrawScope.drawGeologicalStrata(
    strata: List<GeologicalCutaway>,
    camera: Camera3D,
    cx: Float,
    cy: Float,
    scale: Float,
    textMeasurer: TextMeasurer
) {
    strata.forEach { seam ->
        val projTop = seam.topPoints.map { camera.project(it, cx, cy, scale) }
        val projBottom = seam.bottomPoints.map { camera.project(it, cx, cy, scale) }

        if (projTop.size >= 2 && projBottom.size >= 2) {
            val seamPath = Path().apply {
                moveTo(projTop[0].screenX, projTop[0].screenY)
                projTop.forEach { lineTo(it.screenX, it.screenY) }
                for (i in projBottom.indices.reversed()) {
                    lineTo(projBottom[i].screenX, projBottom[i].screenY)
                }
                close()
            }

            // Fill seam with solid deep gold/amber
            drawPath(seamPath, color = NcbAmberDeep.copy(alpha = 0.75f))
            drawPath(seamPath, color = NcbAmberHighlight, style = Stroke(width = 1.2f))

            // Strata internal hash markings
            for (t in 1..4) {
                val frac = t / 5f
                val h1X = projTop[0].screenX + (projBottom[0].screenX - projTop[0].screenX) * frac
                val h1Y = projTop[0].screenY + (projBottom[0].screenY - projTop[0].screenY) * frac
                val h2X = projTop.last().screenX + (projBottom.last().screenX - projTop.last().screenX) * frac
                val h2Y = projTop.last().screenY + (projBottom.last().screenY - projTop.last().screenY) * frac
                drawLine(
                    color = NcbAmber.copy(alpha = 0.4f),
                    start = Offset(h1X, h1Y),
                    end = Offset(h2X, h2Y),
                    strokeWidth = 0.6f
                )
            }
        }
    }
}

private fun DrawScope.drawStructure(
    struct: StructureWireframe,
    camera: Camera3D,
    cx: Float,
    cy: Float,
    scale: Float
) {
    struct.edges.forEach { (v1, v2) ->
        val p1 = camera.project(v1, cx, cy, scale)
        val p2 = camera.project(v2, cx, cy, scale)
        drawLine(
            color = NcbAmber,
            start = Offset(p1.screenX, p1.screenY),
            end = Offset(p2.screenX, p2.screenY),
            strokeWidth = 1.0f
        )
    }
}

private fun DrawScope.drawSpinningSheaves(
    center: Vector3,
    sheaveAngle: Float,
    camera: Camera3D,
    cx: Float,
    cy: Float,
    scale: Float
) {
    val projCenter = camera.project(center, cx, cy, scale)
    val r = 10f * camera.zoom

    // Rotating cross spokes
    val angleRad = Math.toRadians(sheaveAngle.toDouble()).toFloat()
    for (i in 0..3) {
        val a = angleRad + (i * PI.toFloat() / 2f)
        val sx = projCenter.screenX + cos(a) * r
        val sy = projCenter.screenY + sin(a) * r
        drawLine(
            color = NcbAmberHighlight,
            start = Offset(projCenter.screenX, projCenter.screenY),
            end = Offset(sx, sy),
            strokeWidth = 1.2f
        )
    }
}

private fun DrawScope.drawConveyorFlow(
    conveyor: StructureWireframe,
    particleOffsets: List<Float>,
    camera: Camera3D,
    cx: Float,
    cy: Float,
    scale: Float
) {
    if (conveyor.edges.size < 2) return
    val start = conveyor.edges[0].first
    val end = conveyor.edges[1].second

    particleOffsets.forEach { offset ->
        val current3D = Vector3(
            start.x + (end.x - start.x) * offset,
            start.y + (end.y - start.y) * offset,
            start.z + (end.z - start.z) * offset + 1.2f
        )
        val proj = camera.project(current3D, cx, cy, scale)
        drawCircle(
            color = NcbAmberHighlight,
            radius = 3.5f * camera.zoom,
            center = Offset(proj.screenX, proj.screenY)
        )
    }
}

private fun DrawScope.drawDragline(
    dragline: DraglineExcavator,
    camera: Camera3D,
    cx: Float,
    cy: Float,
    scale: Float
) {
    val base = Vector3(dragline.worldX, dragline.worldY, dragline.worldZ)
    val projBase = camera.project(base, cx, cy, scale)

    // Machinery Tub
    drawCircle(
        color = NcbAmberDeep,
        radius = 8f * camera.zoom,
        center = Offset(projBase.screenX, projBase.screenY),
        style = Stroke(width = 1.5f)
    )

    // Boom Vector
    val slewRad = Math.toRadians(dragline.slewAngleDegrees.toDouble()).toFloat()
    val boomLen = 32f
    val boomTip = Vector3(
        base.x + cos(slewRad) * boomLen,
        base.y + sin(slewRad) * boomLen,
        base.z + 18f
    )
    val projBoomTip = camera.project(boomTip, cx, cy, scale)

    // Boom twin lattice chords
    drawLine(
        color = NcbAmberHighlight,
        start = Offset(projBase.screenX, projBase.screenY),
        end = Offset(projBoomTip.screenX, projBoomTip.screenY),
        strokeWidth = 2.0f
    )

    // Suspended Dragline Bucket
    val bucketPos = Vector3(
        boomTip.x - 4f,
        boomTip.y - 2f,
        base.z + (sin(dragline.bucketCycleProgress * 2 * PI).toFloat() * 6f) + 4f
    )
    val projBucket = camera.project(bucketPos, cx, cy, scale)

    // Hoist Cable
    drawLine(
        color = NcbAmberMuted,
        start = Offset(projBoomTip.screenX, projBoomTip.screenY),
        end = Offset(projBucket.screenX, projBucket.screenY),
        strokeWidth = 0.8f
    )

    // Bucket symbol
    drawRect(
        color = NcbAmberHighlight,
        topLeft = Offset(projBucket.screenX - 4f, projBucket.screenY - 3f),
        size = androidx.compose.ui.geometry.Size(8f, 6f)
    )
}

private fun DrawScope.drawHaulTrucks(
    trucks: List<HaulTruck>,
    camera: Camera3D,
    cx: Float,
    cy: Float,
    scale: Float,
    textMeasurer: TextMeasurer
) {
    trucks.forEach { truck ->
        val pos3D = Vector3(truck.worldX, truck.worldY, truck.worldZ)
        val proj = camera.project(pos3D, cx, cy, scale)

        // 3D Truck body wireframe
        val truckW = 7f * camera.zoom
        val truckH = 4.5f * camera.zoom

        drawRect(
            color = if (truck.currentPayloadTonnes > 0) NcbAmberHighlight else NcbAmberMuted,
            topLeft = Offset(proj.screenX - truckW / 2, proj.screenY - truckH / 2),
            size = androidx.compose.ui.geometry.Size(truckW, truckH),
            style = Stroke(width = 1.2f)
        )

        // Glowing headlights
        drawCircle(
            color = NcbAmberHighlight,
            radius = 1.8f * camera.zoom,
            center = Offset(proj.screenX + truckW / 2 + 1f, proj.screenY)
        )

        // Identifier label
        drawText(
            textMeasurer = textMeasurer,
            text = truck.id,
            topLeft = Offset(proj.screenX - 12f, proj.screenY - 14f),
            style = TextStyle(
                color = NcbAmber,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

private fun drawTelemetryOverlay(scope: DrawScope, textMeasurer: TextMeasurer) {
    // Top Left Status
    scope.drawText(
        textMeasurer = textMeasurer,
        text = "UK COAL RESERVES & OPERATIONS\nLIVE",
        topLeft = Offset(14f, 12f),
        style = TextStyle(
            color = NcbAmber,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            lineHeight = 13.sp
        )
    )

    // Top Right Coordinates
    scope.drawText(
        textMeasurer = textMeasurer,
        text = "54.3°N  1.7°W\nDEPTH: 182m (AVG)",
        topLeft = Offset(scope.size.width - 150f, 12f),
        style = TextStyle(
            color = NcbAmber,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            lineHeight = 13.sp
        )
    )
}

private fun checkAssetTap(
    tapOffset: Offset,
    camera: Camera3D,
    width: Float,
    height: Float,
    simulationState: SimulationState,
    onInspect: (InspectedAsset) -> Unit
) {
    val cx = width * 0.5f
    val cy = height * 0.52f
    val scale = width * 0.0036f

    // 1. Check haul trucks first
    for (truck in simulationState.haulTrucks) {
        val proj = camera.project(Vector3(truck.worldX, truck.worldY, truck.worldZ), cx, cy, scale)
        val dist = hypot(tapOffset.x - proj.screenX, tapOffset.y - proj.screenY)
        if (dist < 32f) {
            onInspect(
                InspectedAsset(
                    title = "HAUL TRUCK ${truck.id}",
                    type = truck.model,
                    location = truck.routeDescription,
                    status = truck.status.name,
                    currentRate = "PAYLOAD: ${truck.currentPayloadTonnes} t / ${truck.capacityTonnes} t",
                    energyDraw = "FUEL RATE: ${truck.fuelRateKbtuPerHr} kBTU/hr",
                    details = "Speed: ${truck.speedKph} km/h. Automated GPS guidance active. Telemetry feed online."
                )
            )
            return
        }
    }

    // 2. Check dragline excavator
    val dragline = simulationState.dragline
    val draglineProj = camera.project(Vector3(dragline.worldX, dragline.worldY, dragline.worldZ), cx, cy, scale)
    val draglineDist = hypot(tapOffset.x - draglineProj.screenX, tapOffset.y - draglineProj.screenY)
    if (draglineDist < 40f) {
        onInspect(
            InspectedAsset(
                title = dragline.name,
                type = "Heavy Walking Dragline Excavator",
                location = "Bench 3 - Barnsley Seam Face",
                status = dragline.status.name,
                currentRate = "BUCKET CAPACITY: ${dragline.bucketCapacityTonnes} t / cycle",
                energyDraw = "POWER DRAW: ${dragline.powerDrawKbtuPerHr} kBTU/hr (Electric 11kV Grid)",
                details = "Operating Hours: ${dragline.operatingHours} hrs. Slew angle: ${dragline.slewAngleDegrees.toInt()}°. Boom pitch: ${dragline.boomElevationDegrees.toInt()}°."
            )
        )
        return
    }

    // Default inspection: General Mine Site Telemetry
    onInspect(
        InspectedAsset(
            title = "OPEN-CAST EXCAVATION PIT",
            type = "Terraced Multi-Seam Digital Twin",
            location = "54.3°N 1.7°W (Yorkshire Coal Basin)",
            status = "OPERATIONAL (6 BENCHES ACTIVE)",
            currentRate = "EXCAVATION: 4,850 t/day",
            energyDraw = "TOTAL ENERGY: 30,830,420 MMBtu YTD",
            details = "Active strata: Top Hard (11,200 BTU/lb), Barnsley Main (11,800 BTU/lb), Silkstone Deep (12,400 BTU/lb). Overall depth: 182m."
        )
    )
}
