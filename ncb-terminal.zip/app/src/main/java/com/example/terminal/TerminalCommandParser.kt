package com.example.terminal

import com.example.data.simulation.SimulationState
import com.example.model.EnergyStandard

data class CommandResult(
    val output: String,
    val isClear: Boolean = false
)

object TerminalCommandParser {

    fun execute(commandRaw: String, state: SimulationState): CommandResult {
        val trimmed = commandRaw.trim()
        if (trimmed.isEmpty()) return CommandResult("")

        val parts = trimmed.split("\\s+".toRegex())
        val command = parts[0].uppercase()
        val args = parts.drop(1)

        return when (command) {
            "CLEAR", "CLS" -> CommandResult("", isClear = true)

            "HELP" -> CommandResult(
                """
                === NATIONAL COAL BOARD — MAINFRAME OS v3.8 ===
                AVAILABLE OPERATIONAL COMMANDS:
                  STATUS                     View overall system & colliery status
                  PRODUCTION [--period]      Display coal production & target rates
                  MINES [--list]             List registered UK colliery sites & coordinates
                  ASSETS [--status]          Inspect excavators, haul fleet & conveyors
                  LOGISTICS [--deliveries]   Freightliner rail dispatch & delivery tracking
                  MARKETS [--currency GBP]   Coal index prices (£/t) & spark spreads
                  CONTRACTS [--active]       Commercial counterparty contract register
                  STOCKS                     Strategic stockpile levels by terminal
                  ENERGY [--unit MMBtu]      Thermal energy output & BTU conversion specs
                  QUALITY                    Coal grade analysis & calorific values (BTU/lb)
                  REPORTS [--production]     Generate operational shift summary report
                  ALERTS [--active]          Current system safety alerts & notices
                  SYSTEM                     Terminal architecture & telemetry telemetry
                  CLEAR                      Clear terminal viewport
                """.trimIndent()
            )

            "STATUS" -> CommandResult(
                """
                [SYSTEM STATUS: ONLINE]
                COLLIERY SITES: 7 / 7 REPORTING OPERATIONAL
                TELEMETRY LINK: 100% (UK INDUSTRIAL GRID)
                ACTIVE BENCHES: 23 OPEN-CAST / DEEP SECTIONS
                HAUL FLEET:     18 UNITS ACTIVE (0 CRITICAL FAULTS)
                TOTAL PRODUCTION: ${EnergyStandard.formatTonnes(state.metrics.productionTonnes)} (+${state.metrics.productionWoWPercent}% WoW)
                THERMAL OUTPUT:   ${EnergyStandard.formatMmbTu(state.metrics.thermalEnergyMmbTu)}
                AVG REALIZED:     ${EnergyStandard.formatGbpPerTonne(state.metrics.averagePriceGbp)}
                """.trimIndent()
            )

            "PRODUCTION" -> {
                val period = args.find { it.startsWith("--period") } ?: "TODAY"
                val lines = state.mines.joinToString("\n") { mine ->
                    val mmbtu = EnergyStandard.calculateMmbTu(mine.currentOutputTonnes, mine.calorificValueBtuPerLb)
                    String.format(
                        "  %-14s %8.0f t  |  %8.1f MMBtu  |  %s",
                        mine.name, mine.currentOutputTonnes, mmbtu, mine.status
                    )
                }
                CommandResult(
                    """
                    === NCB NATIONAL PRODUCTION TELEMETRY [$period] ===
                    TOTAL PHYSICAL OUTPUT: ${EnergyStandard.formatTonnes(state.metrics.productionTonnes)}
                    TOTAL THERMAL OUTPUT:  ${EnergyStandard.formatMmbTu(state.metrics.thermalEnergyMmbTu)}
                    DELIVERIES DISPATCHED: ${EnergyStandard.formatTonnes(state.metrics.deliveriesTonnes)}
                    
                    SITE BREAKDOWN:
                    MINE NAME        OUTPUT (t)      THERMAL (MMBtu)    STATUS
                    -----------------------------------------------------------
                    $lines
                    -----------------------------------------------------------
                    EQUIPMENT UTILISATION: ${state.metrics.equipmentUtilisationPercent}%
                    OPERATIONAL AVAILABILITY: ${state.metrics.operationalAvailabilityPercent}%
                    """.trimIndent()
                )
            }

            "MINES" -> {
                val lines = state.mines.joinToString("\n") { mine ->
                    String.format(
                        "  %-14s  %-12s  Depth: %4dm  Coord: %-12s  Seam: %s",
                        mine.name, mine.county, mine.depthMeters, mine.coordinates, mine.seamName
                    )
                }
                CommandResult(
                    """
                    === NCB REGISTERED COLLIERY REGISTER ===
                    $lines
                    ALL SITES CLASSIFIED AS STRATEGIC UK ENERGY ASSETS.
                    """.trimIndent()
                )
            }

            "ASSETS" -> {
                val truckLines = state.haulTrucks.joinToString("\n") { truck ->
                    String.format(
                        "  %-8s %-20s Payload: %3.0ft/%3.0ft  Fuel: %4.0f kBTU/h  [%s]",
                        truck.id, truck.model, truck.currentPayloadTonnes, truck.capacityTonnes, truck.fuelRateKbtuPerHr, truck.status
                    )
                }
                val dragline = state.dragline
                CommandResult(
                    """
                    === HEAVY MINING EQUIPMENT REGISTER ===
                    DRAGLINE EXCAVATOR:
                      ID: ${dragline.id} (${dragline.name})
                      Bucket: ${dragline.bucketCapacityTonnes} t | Power: ${dragline.powerDrawKbtuPerHr} kBTU/hr | Slew: ${dragline.slewAngleDegrees.toInt()}°
                      Status: ${dragline.status} | Operating Hours: ${dragline.operatingHours} hrs
                    
                    HAUL TRUCK FLEET:
                    $truckLines
                    
                    CONVEYOR NETWORK:
                      CV-OVERLAND-TRUNK: 4,200 t/h max capacity | Status: ONLINE | Speed: 4.2 m/s
                    """.trimIndent()
                )
            }

            "LOGISTICS" -> CommandResult(
                """
                === FREIGHTLINER & LOGISTICS DISPATCH ===
                RAIL MOVEMENTS (24-HR CYCLE):
                  TRAIN FL-66108: Kellingley -> Drax Power (2,450 t dispatched 10:28)
                  TRAIN FL-66224: Blyth -> Port of Tyne Terminal (1,800 t in transit)
                  TRAIN FL-66042: Hatfield -> Ratcliffe Power Station (2,100 t loading)
                  TRAIN FL-66315: Ffos-y-fran -> Port Talbot Steelworks (1,650 t metallurgical)
                
                TOTAL COAL DELIVERED YTD: ${EnergyStandard.formatTonnes(state.metrics.deliveriesTonnes)}
                ACTIVE RAIL FREIGHT CAPACITY: 12 TRAINS IN SERVICE
                PORT TERMINALS: Tyne (Blyth Dock) & Immingham Bulk Terminal ACTIVE
                """.trimIndent()
            )

            "MARKETS" -> {
                val lines = state.marketPrices.joinToString("\n") { price ->
                    String.format(
                        "  %-26s %s  (+%.1f%% WoW)  Spark: £%.2f/MWh  Basis: %.0f BTU/lb",
                        price.name, EnergyStandard.formatGbpPerTonne(price.priceGbpPerTonne),
                        price.changePercentWoW, price.sparkSpreadGbp, price.calorificBasisBtuPerLb
                    )
                }
                CommandResult(
                    """
                    === UK COAL COMMODITY MARKETS (STRICT GBP STANDARD) ===
                    $lines
                    AVERAGE REALIZED CONTRACT PRICE: ${EnergyStandard.formatGbpPerTonne(state.metrics.averagePriceGbp)}
                    NOTE: All market benchmarks displayed in GBP (£) per tonne.
                    """.trimIndent()
                )
            }

            "CONTRACTS" -> {
                val lines = state.contracts.joinToString("\n") { con ->
                    val totalValGbp = EnergyStandard.calculateRevenueGbp(con.totalVolumeTonnes, con.pricePerTonneGbp)
                    String.format(
                        "  %-26s Vol: %8.0f t  Price: %s  Total: %s  [%s]",
                        con.counterparty, con.totalVolumeTonnes, EnergyStandard.formatGbpPerTonne(con.pricePerTonneGbp),
                        EnergyStandard.formatGbp(totalValGbp), con.status
                    )
                }
                CommandResult(
                    """
                    === COMMERCIAL CONTRACT REGISTER ===
                    $lines
                    TOP OFF-TAKER: Drax Power Ltd (28% of national forward allocation)
                    """.trimIndent()
                )
            }

            "STOCKS" -> CommandResult(
                """
                === NATIONAL STRATEGIC COAL RESERVES ===
                TOTAL STRATEGIC INVENTORY: ${EnergyStandard.formatTonnes(state.metrics.stockTonnes)} (+${state.metrics.stockWoWPercent}% WoW)
                STOCKPILE LOCATIONS:
                  Kellingley Surface Yard:       112,400 t (Silkstone blend)
                  Blyth Terminal Yard:            84,600 t (Thermal washed)
                  Ffos-y-fran Bunkers:            68,200 t (High-grade Anthracite)
                  Hatfield & Central Reserve:     97,600 t (Industrial steam coal)
                COVERAGE: 48 DAYS OF UK BASELOAD DISPATCH AT FULL GENERATION
                """.trimIndent()
            )

            "ENERGY" -> {
                val baseline = EnergyStandard.DEFAULT_CALORIFIC_VALUE_BTU_PER_LB
                val mmbtuPerTonne = EnergyStandard.calculateMmbTuPerTonne(baseline)
                CommandResult(
                    """
                    === GLOBAL ENERGY STANDARD CONVERSION SPECIFICATION ===
                    STANDARD: BTU-BASED MEASUREMENTS (BRITISH THERMAL UNITS)
                    
                    CALORIFIC BASELINE:     ${EnergyStandard.formatCalorificValue(baseline)}
                    CONVERSION CONSTANT:    1 Metric Tonne (MT) = 2,204.6226 lbs
                    ENERGY INTENSITY:       ${String.format("%.2f", mmbtuPerTonne)} MMBtu / tonne
                    TOTAL OUTPUT TO DATE:   ${EnergyStandard.formatMmbTu(state.metrics.thermalEnergyMmbTu)}
                    AVERAGE ENERGY PRICE:   ${String.format("£%.2f", EnergyStandard.calculateGbpPerMmbTu(state.metrics.averagePriceGbp, baseline))} / MMBtu
                    
                    FORMULA: Total BTU = Tonnes * 2,204.6226 * (BTU/lb)
                    """.trimIndent()
                )
            }

            "QUALITY" -> {
                val lines = state.geologicalLayers.joinToString("\n") { layer ->
                    String.format(
                        "  %-26s  %s  Calorific: %.0f BTU/lb  Ash: %.1f%%  Reserves: %.1f MT",
                        layer.name, layer.depthRangeMeters, layer.calorificValueBtuPerLb, layer.ashContentPercent, layer.estimatedReservesMt
                    )
                }
                CommandResult(
                    """
                    === GEOLOGICAL COAL STRATA & QUALITY ANALYSIS ===
                    $lines
                    SULPHUR CONTENT: Average < 0.8% across UK bituminous seams
                    MOISTURE: 7.2% washed basis
                    """.trimIndent()
                )
            }

            "REPORTS" -> CommandResult(
                """
                === NCB EXECUTIVE SHIFT REPORT #2026-10-22 ===
                PERIOD: MORNING SHIFT 06:00 - 14:00
                NATIONAL PRODUCTION: ${EnergyStandard.formatTonnes(state.metrics.productionTonnes)}
                ENERGY GENERATION EQUIVALENT: ${EnergyStandard.formatMmbTu(state.metrics.thermalEnergyMmbTu)}
                COMMERCIAL REVENUE ACCRUED: ${EnergyStandard.formatGbp(EnergyStandard.calculateRevenueGbp(state.metrics.productionTonnes, state.metrics.averagePriceGbp))}
                SAFETY RECORD: ZERO INCIDENTS
                OPERATIONAL EFFICIENCY: ${state.metrics.operationalAvailabilityPercent}%
                AUTHORIZED BY: CHIEF MINING CONTROLLER, DONCASTER OPERATIONS
                """.trimIndent()
            )

            "ALERTS" -> CommandResult(
                """
                === CURRENT OPERATIONAL ALERTS ===
                [OK] Kellingley Methane Drainage: NORMAL (0.12% CH4)
                [OK] Pit Sump Pumping Rate: 840 gpm (Nominal)
                [OK] High-Voltage Switchgear (11kV): 100% HEALTH
                [NOTICE] Routine roller lubrication scheduled on CV-OVERLAND-TRUNK at 22:00
                NO CRITICAL ALERTS REPORTED.
                """.trimIndent()
            )

            "SYSTEM" -> CommandResult(
                """
                === NCB MAINFRAME TERMINAL SYSTEM ===
                TERMINAL ID: NCB-TRADING-TERM-3829
                KERNEL:      INDUSTRIAL KOTLIN/COMPOSE 2026.4
                RENDERER:    3D WIREFRAME ISOMETRIC ACCELERATED CANVAS
                TELEMETRY:   COROUTINE FLOW 33ms TICK (60 FPS TARGET)
                CURRENCY:    GBP ONLY (£)
                ENERGY UNIT: BTU / MMBtu ONLY
                TIME (UTC):  ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.UK).format(java.util.Date())}
                STATUS:      SUPERMODERN INDUSTRIAL CONTROL SYSTEM READY
                """.trimIndent()
            )

            else -> CommandResult(
                "ERR: UNRECOGNIZED COMMAND '$command'. Type 'HELP' to view registered terminal commands."
            )
        }
    }
}
