package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.ContractEntity
import com.example.data.db.LogEntity
import com.example.data.db.NcbDatabase
import com.example.data.db.ProductionRecordEntity
import com.example.data.prefs.NcbPreferencesRepository
import com.example.data.simulation.MiningSimulationEngine
import com.example.data.simulation.SimulationState
import com.example.model.CoalContract
import com.example.model.ContractStatus
import com.example.model.EnergyStandard
import com.example.renderer.InspectedAsset
import com.example.terminal.TerminalCommandParser
import com.example.ui.navigation.NcbDestination
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NcbTerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val database = NcbDatabase.getDatabase(application)
    val preferencesRepository = NcbPreferencesRepository(application)
    val simulationEngine = MiningSimulationEngine(viewModelScope)

    val simulationState: StateFlow<SimulationState> = simulationEngine.state

    private val _currentDestination = MutableStateFlow(NcbDestination.OVERVIEW)
    val currentDestination: StateFlow<NcbDestination> = _currentDestination.asStateFlow()

    private val _commandOutput = MutableStateFlow("")
    val commandOutput: StateFlow<String> = _commandOutput.asStateFlow()

    private val _inspectedAsset = MutableStateFlow<InspectedAsset?>(null)
    val inspectedAsset: StateFlow<InspectedAsset?> = _inspectedAsset.asStateFlow()

    val persistedContracts: StateFlow<List<ContractEntity>> = database.contractDao()
        .getAllContracts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val persistedLogs: StateFlow<List<LogEntity>> = database.logDao()
        .getRecentLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val productionHistory: StateFlow<List<ProductionRecordEntity>> = database.productionDao()
        .getProductionHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Seed initial contracts and historical records if empty
        viewModelScope.launch {
            seedInitialDatabase()
        }
    }

    private suspend fun seedInitialDatabase() {
        val initialContracts = listOf(
            ContractEntity("CON-DRAX-01", "Drax Power (UK)", "Power Generation", 3200000.0, 2150000.0, 141.50, 11200.0, "2025-28", "ACTIVE"),
            ContractEntity("CON-TATA-02", "Tata Steel (Port Talbot)", "Metallurgical Coking", 1750000.0, 980000.0, 168.00, 12600.0, "2025-27", "ACTIVE"),
            ContractEntity("CON-UNIPER-03", "Uniper Energy (Ratcliffe)", "Power Generation", 980000.0, 620000.0, 138.20, 11000.0, "2025-26", "ACTIVE"),
            ContractEntity("CON-INDIA-04", "Steel Authority Term (Spot)", "Industrial Export", 640000.0, 310000.0, 155.00, 12200.0, "2025-26", "ACTIVE"),
            ContractEntity("CON-BRIT-SUGAR", "British Sugar (Newark)", "Industrial Heat", 320000.0, 190000.0, 144.00, 11400.0, "2025-26", "ACTIVE"),
            ContractEntity("CON-SCUN-STEEL", "Scunthorpe Steelworks", "Metallurgical Blend", 890000.0, 520000.0, 164.50, 12400.0, "2025-27", "ACTIVE")
        )
        database.contractDao().insertContracts(initialContracts)

        val sampleProduction = listOf(
            ProductionRecordEntity(0, "2026-10-21", "MINE-KEL", "Kellingley", 19240.0, EnergyStandard.calculateMmbTu(19240.0, 11600.0), 11600.0, 19240.0 * 142.60),
            ProductionRecordEntity(0, "2026-10-21", "MINE-FFO", "Ffos-y-fran", 17210.0, EnergyStandard.calculateMmbTu(17210.0, 13200.0), 13200.0, 17210.0 * 155.00),
            ProductionRecordEntity(0, "2026-10-21", "MINE-HAT", "Hatfield", 15800.0, EnergyStandard.calculateMmbTu(15800.0, 11400.0), 11400.0, 15800.0 * 140.00),
            ProductionRecordEntity(0, "2026-10-21", "MINE-BLY", "Blyth", 14890.0, EnergyStandard.calculateMmbTu(14890.0, 10400.0), 10400.0, 14890.0 * 136.50)
        )
        database.productionDao().insertRecords(sampleProduction)
    }

    fun navigateTo(destination: NcbDestination) {
        _currentDestination.value = destination
    }

    fun executeCommand(commandStr: String) {
        val result = TerminalCommandParser.execute(commandStr, simulationState.value)
        if (result.isClear) {
            _commandOutput.value = ""
        } else {
            val prefix = "NCB> $commandStr\n"
            _commandOutput.value = if (_commandOutput.value.isEmpty()) {
                prefix + result.output
            } else {
                "${_commandOutput.value}\n\n$prefix${result.output}"
            }
        }

        // Record into simulation log and database
        viewModelScope.launch {
            val logEntity = LogEntity(
                timestamp = java.text.SimpleDateFormat("HH:mm", java.util.Locale.UK).format(java.util.Date()),
                source = "TERMINAL",
                message = "Executed: $commandStr",
                severity = "INFO"
            )
            database.logDao().insertLog(logEntity)
        }
    }

    fun inspectAsset(asset: InspectedAsset?) {
        _inspectedAsset.value = asset
    }

    fun addContract(
        counterparty: String,
        sector: String,
        tonnes: Double,
        priceGbp: Double,
        btuPerLb: Double,
        deliveryPeriod: String
    ) {
        viewModelScope.launch {
            val id = "CON-" + counterparty.take(4).uppercase() + "-" + System.currentTimeMillis().toString().takeLast(4)
            val newContract = ContractEntity(
                id = id,
                counterparty = counterparty,
                sector = sector,
                totalVolumeTonnes = tonnes,
                fulfilledTonnes = 0.0,
                pricePerTonneGbp = priceGbp,
                energySpecBtuPerLb = btuPerLb,
                deliveryPeriod = deliveryPeriod,
                status = "ACTIVE"
            )
            database.contractDao().insertContract(newContract)
            simulationEngine.addLog("Commercial", "New contract registered: $counterparty ($tonnes t @ £$priceGbp/t)")
        }
    }

    fun setSimulationSpeed(speed: Float) {
        simulationEngine.setSimulationSpeed(speed)
        viewModelScope.launch {
            preferencesRepository.setSimulationSpeed(speed)
        }
    }

    fun togglePause() {
        simulationEngine.togglePause()
    }

    fun resetAllData() {
        simulationEngine.resetData()
        _commandOutput.value = ""
        viewModelScope.launch {
            database.logDao().clearLogs()
            seedInitialDatabase()
        }
    }
}
