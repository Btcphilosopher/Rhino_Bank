package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.model.EnergyStandard
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDark
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun SettingsScreen(
    state: SimulationState,
    onSetSpeed: (Float) -> Unit,
    onTogglePause: () -> Unit,
    onResetData: () -> Unit,
    modifier: Modifier = Modifier
) {
    var calorificBaseline by remember { mutableFloatStateOf(11200f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("settings_screen")
    ) {
        NcbHeader()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            item {
                Text(
                    text = "MAINFRAME CONFIGURATION & SIMULATION SETTINGS",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "NATIONAL COAL BOARD INDUSTRIAL DIGITAL TWIN PARAMETERS",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmberDeep
                )
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Simulation Controls
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "SIMULATION ENGINE RATE",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = NcbAmberHighlight
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SPEED MULTIPLIER: ${state.simulationSpeed}x",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmber
                        )
                        Row {
                            listOf(0.5f, 1.0f, 2.0f, 5.0f).forEach { speed ->
                                Button(
                                    onClick = { onSetSpeed(speed) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (state.simulationSpeed == speed) NcbAmber else NcbBlack
                                    ),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(NcbAmberDark)),
                                    modifier = Modifier.padding(horizontal = 2.dp)
                                ) {
                                    Text(
                                        text = "${speed}x",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (state.simulationSpeed == speed) NcbBlack else NcbAmber
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (state.isPaused) "SIMULATION: PAUSED" else "SIMULATION: RUNNING (60 FPS)",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = if (state.isPaused) NcbAmberMuted else NcbAmberHighlight
                        )
                        Button(
                            onClick = onTogglePause,
                            colors = ButtonDefaults.buttonColors(containerColor = if (state.isPaused) NcbAmber else NcbBlack),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(NcbAmber))
                        ) {
                            Text(
                                text = if (state.isPaused) "RESUME" else "PAUSE",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isPaused) NcbBlack else NcbAmber
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Energy Standard Baseline
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "ENERGY STANDARD CALORIFIC BASELINE",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = NcbAmberHighlight
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "CURRENT VALUE: ${EnergyStandard.formatCalorificValue(calorificBaseline.toDouble())}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmber
                    )
                    Slider(
                        value = calorificBaseline,
                        onValueChange = { calorificBaseline = it },
                        valueRange = 9500f..14000f,
                        steps = 45,
                        colors = SliderDefaults.colors(
                            thumbColor = NcbAmberHighlight,
                            activeTrackColor = NcbAmber,
                            inactiveTrackColor = NcbAmberDark
                        )
                    )
                    Text(
                        text = "Calculated Intensity: ${String.format("%.2f", EnergyStandard.calculateMmbTuPerTonne(calorificBaseline.toDouble()))} MMBtu / tonne",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmberMuted
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Reset Controls
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "DATA & PERSISTENCE MANAGEMENT",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = NcbAmberHighlight
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Reset all simulated telemetry and restore defaults",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmberMuted
                        )
                        Button(
                            onClick = onResetData,
                            colors = ButtonDefaults.buttonColors(containerColor = NcbBlack),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(NcbAmber))
                        ) {
                            Text("RESET SIMULATION", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmber)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // About Specification
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(12.dp)
                ) {
                    Text("NATIONAL COAL BOARD TERMINAL — INDUSTRIAL SUPERMODERNITY", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, color = NcbAmber)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Commissioned for British Colliery Operations & Energy Trading.", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    Text("Pure Black & Amber Visual Identity with Hardware-Accelerated 3D Mine.", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    Text("Strict Currency Standard: GBP (£) | Strict Energy Standard: BTU / MMBtu.", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                }
            }
        }
    }
}
