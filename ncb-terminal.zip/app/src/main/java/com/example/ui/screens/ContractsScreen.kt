package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.ContractEntity
import com.example.model.EnergyStandard
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmber
import com.example.ui.theme.NcbBorderAmberThin
import com.example.ui.theme.NcbGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContractsScreen(
    contracts: List<ContractEntity>,
    onAddContract: (counterparty: String, sector: String, tonnes: Double, priceGbp: Double, btuPerLb: Double, period: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var showDraftDialog by remember { mutableStateOf(false) }

    val filtered = contracts.filter {
        it.counterparty.contains(searchQuery, ignoreCase = true) ||
                it.sector.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("contracts_screen")
    ) {
        NcbHeader()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COMMERCIAL CONTRACT REGISTER",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = 1.0.sp,
                        color = NcbAmber
                    )
                    Text(
                        text = "DURABLE ROOM DATABASE PERSISTENCE  |  STRICT GBP & BTU TERMS",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmberDeep
                    )
                }

                Button(
                    onClick = { showDraftDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = NcbAmber),
                    modifier = Modifier.testTag("draft_contract_btn")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Draft Contract", tint = NcbBlack)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("DRAFT CONTRACT", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbBlack)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NcbBlack)
                    .border(width = 1.dp, color = NcbBorderAmberThin)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SEARCH:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbAmberMuted)
                Spacer(modifier = Modifier.width(8.dp))
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    textStyle = TextStyle(
                        color = NcbAmberHighlight,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    cursorBrush = SolidColor(NcbAmber),
                    singleLine = true,
                    modifier = Modifier.weight(1f).testTag("contract_search_input")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Contract list
            LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                items(filtered) { contract ->
                    val totalGbp = EnergyStandard.calculateRevenueGbp(contract.totalVolumeTonnes, contract.pricePerTonneGbp)
                    val mmbtu = EnergyStandard.calculateMmbTu(contract.totalVolumeTonnes, contract.energySpecBtuPerLb)

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(NcbBlack)
                            .border(width = 1.dp, color = NcbBorderAmberThin)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = contract.counterparty,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmber
                            )
                            Text(
                                text = "[${contract.status}]",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = NcbGreen
                            )
                        }

                        Text(
                            text = "SECTOR: ${contract.sector} | DELIVERY: ${contract.deliveryPeriod}",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmberMuted
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Volume: ${EnergyStandard.formatTonnes(contract.totalVolumeTonnes)}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberHighlight
                            )
                            Text(
                                text = "Price: ${EnergyStandard.formatGbpPerTonne(contract.pricePerTonneGbp)}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberHighlight
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Contract Value: ${EnergyStandard.formatGbp(totalGbp)}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = NcbAmber
                            )
                            Text(
                                text = "Energy: ${EnergyStandard.formatMmbTu(mmbtu)} (${EnergyStandard.formatCalorificValue(contract.energySpecBtuPerLb)})",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberDeep
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDraftDialog) {
        DraftContractDialog(
            onDismiss = { showDraftDialog = false },
            onConfirm = { cp, sec, ton, price, btu, per ->
                onAddContract(cp, sec, ton, price, btu, per)
                showDraftDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DraftContractDialog(
    onDismiss: () -> Unit,
    onConfirm: (counterparty: String, sector: String, tonnes: Double, priceGbp: Double, btuPerLb: Double, period: String) -> Unit
) {
    var counterparty by remember { mutableStateOf("SSE Thermal (Peterhead)") }
    var sector by remember { mutableStateOf("Power Generation") }
    var volumeTonnes by remember { mutableStateOf("500000") }
    var priceGbp by remember { mutableStateOf("145.00") }
    var btuPerLb by remember { mutableStateOf("11200") }
    var period by remember { mutableStateOf("2026-2027") }

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth(0.92f)
            .background(NcbBlack)
            .border(width = 1.5.dp, color = NcbBorderAmber)
            .padding(14.dp)
            .testTag("draft_contract_dialog")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "DRAFT COMMERCIAL CONTRACT",
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = NcbAmberHighlight
            )
            Text(
                text = "TERMS: GBP (£) ONLY  |  ENERGY SPECIFICATION IN BTU/lb",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = NcbAmberMuted
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = counterparty,
                onValueChange = { counterparty = it },
                label = { Text("Counterparty Name", color = NcbAmberDeep, fontSize = 10.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NcbAmberHighlight,
                    unfocusedTextColor = NcbAmber,
                    focusedBorderColor = NcbAmber,
                    unfocusedBorderColor = NcbBorderAmberThin
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(4.dp))

            OutlinedTextField(
                value = volumeTonnes,
                onValueChange = { volumeTonnes = it },
                label = { Text("Volume (Metric Tonnes)", color = NcbAmberDeep, fontSize = 10.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NcbAmberHighlight,
                    unfocusedTextColor = NcbAmber,
                    focusedBorderColor = NcbAmber,
                    unfocusedBorderColor = NcbBorderAmberThin
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = priceGbp,
                    onValueChange = { priceGbp = it },
                    label = { Text("Price (£/t)", color = NcbAmberDeep, fontSize = 10.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NcbAmberHighlight,
                        unfocusedTextColor = NcbAmber,
                        focusedBorderColor = NcbAmber,
                        unfocusedBorderColor = NcbBorderAmberThin
                    ),
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(6.dp))

                OutlinedTextField(
                    value = btuPerLb,
                    onValueChange = { btuPerLb = it },
                    label = { Text("Energy Spec (BTU/lb)", color = NcbAmberDeep, fontSize = 10.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NcbAmberHighlight,
                        unfocusedTextColor = NcbAmber,
                        focusedBorderColor = NcbAmber,
                        unfocusedBorderColor = NcbBorderAmberThin
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) {
                    Text("CANCEL", color = NcbAmberMuted, fontFamily = FontFamily.Monospace)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val ton = volumeTonnes.toDoubleOrNull() ?: 100000.0
                        val pr = priceGbp.toDoubleOrNull() ?: 140.0
                        val btu = btuPerLb.toDoubleOrNull() ?: 11200.0
                        onConfirm(counterparty, sector, ton, pr, btu, period)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NcbAmber)
                ) {
                    Text("SAVE TO REGISTER", color = NcbBlack, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
