package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.model.EnergyStandard
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun ReportsScreen(
    state: SimulationState,
    modifier: Modifier = Modifier
) {
    var selectedReport by remember { mutableStateOf("SHIFT_SUMMARY") }

    val revenueGbp = EnergyStandard.calculateRevenueGbp(state.metrics.productionTonnes, state.metrics.averagePriceGbp)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("reports_screen")
    ) {
        NcbHeader()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            item {
                Text(
                    text = "NCB OPERATIONAL & FINANCIAL AUDIT REPORTS",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "CERTIFIED INDUSTRIAL COMPLIANCE  |  NATIONAL ENERGY BALANCES",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmberDeep
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Report category selector
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ReportTabButton("OPERATIONAL SHIFT", selectedReport == "SHIFT_SUMMARY") { selectedReport = "SHIFT_SUMMARY" }
                    ReportTabButton("THERMAL ENERGY", selectedReport == "ENERGY_AUDIT") { selectedReport = "ENERGY_AUDIT" }
                    ReportTabButton("COMMERCIAL REVENUE", selectedReport == "FINANCIAL") { selectedReport = "FINANCIAL" }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Report Document
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(14.dp)
                ) {
                    when (selectedReport) {
                        "SHIFT_SUMMARY" -> {
                            Text(
                                text = "=== NATIONAL SHIFT AUDIT REPORT: MORNING 06:00 - 14:00 ===",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberHighlight
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            ReportRow("NATIONAL RUN-OF-MINE OUTPUT", EnergyStandard.formatTonnes(state.metrics.productionTonnes))
                            ReportRow("WEEK-ON-WEEK OUTPUT VARIANCE", "+${state.metrics.productionWoWPercent}%")
                            ReportRow("COMMERCIAL DELIVERIES DISPATCHED", EnergyStandard.formatTonnes(state.metrics.deliveriesTonnes))
                            ReportRow("SURFACE STRATEGIC RESERVES", EnergyStandard.formatTonnes(state.metrics.stockTonnes))
                            ReportRow("FLEET UTILISATION INDEX", "${state.metrics.equipmentUtilisationPercent}%")
                            ReportRow("LOST TIME INJURY FREQUENCY", "0.00 (ZERO INCIDENTS)")
                            ReportRow("OFFICIAL AUDITOR", "CHIEF MINING CONTROLLER, DONCASTER")
                        }
                        "ENERGY_AUDIT" -> {
                            Text(
                                text = "=== BRITISH THERMAL ENERGY BALANCES & CONVERSION ===",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberHighlight
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            ReportRow("TOTAL THERMAL EQUIVALENT", EnergyStandard.formatMmbTu(state.metrics.thermalEnergyMmbTu))
                            ReportRow("BASELINE BITUMINOUS CALORIFIC SPEC", "11,200 BTU/lb")
                            ReportRow("METRIC CONVERSION FACTOR", "2,204.6226 lbs / tonne")
                            ReportRow("THERMAL ENERGY INTENSITY", "24.69 MMBtu / tonne")
                            ReportRow("POWER STATION DISPATCH RATE", "30,830,420 MMBtu YTD")
                            ReportRow("EMISSIONS COMPLIANCE", "LOW-SULPHUR WASHED BLEND (<0.8% S)")
                        }
                        "FINANCIAL" -> {
                            Text(
                                text = "=== COMMERCIAL REVENUE & REALIZED VALUE (GBP ONLY) ===",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberHighlight
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            ReportRow("GROSS REALIZED REVENUE", EnergyStandard.formatGbp(revenueGbp))
                            ReportRow("AVERAGE REALIZED COMMODITY PRICE", EnergyStandard.formatGbpPerTonne(state.metrics.averagePriceGbp))
                            ReportRow("EFFECTIVE ENERGY PRICE", String.format("£%.2f / MMBtu", EnergyStandard.calculateGbpPerMmbTu(state.metrics.averagePriceGbp, 11200.0)))
                            ReportRow("FORWARD CONTRACT COMMITMENTS", "£1.28 billion across 4 counterparties")
                            ReportRow("AUDITING STANDARD", "BRITISH STATUTORY INDUSTRIAL ACCOUNTS")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportTabButton(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) NcbAmber else NcbBlack
        ),
        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(NcbAmberDeep)),
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) NcbBlack else NcbAmber
        )
    }
}

@Composable
private fun ReportRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
        Text(text = value, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbAmber)
    }
}
