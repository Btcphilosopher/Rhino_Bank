package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.model.EnergyStandard
import com.example.model.MineSite
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDark
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin
import com.example.ui.theme.NcbGreen

@Composable
fun ProductionScreen(
    state: SimulationState,
    onMineSelected: (MineSite) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("production_screen")
    ) {
        NcbHeader()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Text(
                text = "NATIONAL COLLIERY PRODUCTION & ENERGY TELEMETRY",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = 1.0.sp,
                color = NcbAmber
            )

            Text(
                text = "SHIFT: 06:00 - 14:00  |  BTU THERMAL INTENSITY: 11,200 BTU/lb BASELINE",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = NcbAmberDeep
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Summary metrics bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NcbBlack)
                    .border(width = 1.dp, color = NcbBorderAmberThin)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("TOTAL PRODUCTION", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    Text(EnergyStandard.formatTonnes(state.metrics.productionTonnes), fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbAmberHighlight)
                }
                Column {
                    Text("THERMAL GENERATION", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    Text(EnergyStandard.formatMmbTu(state.metrics.thermalEnergyMmbTu), fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbAmberHighlight)
                }
                Column {
                    Text("RECOVERABLE RESERVES", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    Text("245.3 MT", fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbAmberHighlight)
                }
                Column {
                    Text("UTILISATION", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    Text("${state.metrics.equipmentUtilisationPercent}%", fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbAmberHighlight)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // List of Colliery Sites with Production & Thermal Output
            LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                items(state.mines) { mine ->
                    val mmbtu = EnergyStandard.calculateMmbTu(mine.currentOutputTonnes, mine.calorificValueBtuPerLb)
                    val percentTarget = (mine.currentOutputTonnes / mine.dailyTargetTonnes * 100.0).toInt()

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(NcbBlack)
                            .border(width = 1.dp, color = NcbBorderAmberThin)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = mine.name.uppercase(),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace,
                                    color = NcbAmber
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "(${mine.county})",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = NcbAmberDeep
                                )
                            }
                            Text(
                                text = mine.status.name,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = NcbGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Output: ${EnergyStandard.formatTonnes(mine.currentOutputTonnes)}  /  Target: ${EnergyStandard.formatTonnes(mine.dailyTargetTonnes)} ($percentTarget%)",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberHighlight
                            )
                            Text(
                                text = "Thermal: ${EnergyStandard.formatMmbTu(mmbtu)}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmber
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Seam: ${mine.seamName} (${EnergyStandard.formatCalorificValue(mine.calorificValueBtuPerLb)})",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberMuted
                            )
                            Text(
                                text = "Depth: ${mine.depthMeters}m | Benches: ${mine.activeBenches} | Trucks: ${mine.haulTrucksAssigned}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberMuted
                            )
                        }
                    }
                }
            }
        }
    }
}
