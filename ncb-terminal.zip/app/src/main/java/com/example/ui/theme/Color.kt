package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Industrial Supermodernity - NCB National Coal Board Palette
val NcbBlack = Color(0xFF000000)
val NcbBlackElevation1 = Color(0xFF070502)
val NcbBlackElevation2 = Color(0xFF0D0A04)
val NcbBlackSurface = Color(0xFF140F06)

// Gold & Amber Spectrums
val NcbAmber = Color(0xFFFFC247)         // Primary NCB Amber
val NcbAmberDeep = Color(0xFFD99A16)     // Deep Industrial Gold
val NcbAmberHighlight = Color(0xFFFFD166)// Highlight Gold
val NcbAmberMuted = Color(0xFF85651D)    // Muted Amber
val NcbAmberDark = Color(0xFF523E11)     // Faint Border / Dividers
val NcbAmberSubtle = Color(0xFF261D07)   // Background Grid / Fill

// Operational & Alert Accents (strictly restrained)
val NcbGreen = Color(0xFF00E676)         // Online Status Restrained Green
val NcbGreenDim = Color(0xFF008542)
val NcbRed = Color(0xFFFF3333)           // Fault / Critical Alert Only
val NcbRedDim = Color(0xFF7A1414)

val NcbTextPrimary = NcbAmber
val NcbTextSecondary = Color(0xFFD99A16)
val NcbTextMuted = Color(0xFF85651D)
val NcbBorderAmber = Color(0xFF85651D)
val NcbBorderAmberThin = Color(0xFF42330F)
