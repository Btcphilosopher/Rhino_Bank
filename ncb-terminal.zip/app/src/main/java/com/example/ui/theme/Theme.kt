package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NcbDarkColorScheme = darkColorScheme(
    primary = NcbAmber,
    onPrimary = NcbBlack,
    primaryContainer = NcbAmberSubtle,
    onPrimaryContainer = NcbAmberHighlight,
    secondary = NcbAmberDeep,
    onSecondary = NcbBlack,
    secondaryContainer = NcbAmberDark,
    onSecondaryContainer = NcbAmber,
    tertiary = NcbAmberHighlight,
    onTertiary = NcbBlack,
    background = NcbBlack,
    onBackground = NcbAmber,
    surface = NcbBlackElevation1,
    onSurface = NcbAmber,
    surfaceVariant = NcbBlackElevation2,
    onSurfaceVariant = NcbAmberDeep,
    outline = NcbBorderAmber,
    outlineVariant = NcbBorderAmberThin
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    // We intentionally enforce the authentic NCB Industrial dark palette on all devices
    MaterialTheme(
        colorScheme = NcbDarkColorScheme,
        typography = Typography,
        content = content
    )
}
