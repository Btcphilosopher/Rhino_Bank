package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.model.EnergyStandard
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDark
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun SalesTradingScreen(
    state: SimulationState,
    modifier: Modifier = Modifier
) {
    var volumeSliderTonnes by remember { mutableFloatStateOf(50000f) }
    var priceSliderGbp by remember { mutableFloatStateOf(142.50f) }
    var calorificSliderBtu by remember { mutableFloatStateOf(11200f) }

    val calculatedMmbTu = EnergyStandard.calculateMmbTu(volumeSliderTonnes.toDouble(), calorificSliderBtu.toDouble())
    val calculatedRevenueGbp = EnergyStandard.calculateRevenueGbp(volumeSliderTonnes.toDouble(), priceSliderGbp.toDouble())
    val gbpPerMmbTu = EnergyStandard.calculateGbpPerMmbTu(priceSliderGbp.toDouble(), calorificSliderBtu.toDouble())

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("sales_trading_screen")
    ) {
        NcbHeader()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            item {
                Text(
                    text = "NCB COMMODITY SALES & ENERGY CONTRACT TRADING",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "STANDARDS: CURRENCY IN GBP (£) ONLY  |  ENERGY IN BTU / MMBtu ONLY",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmberDeep
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Interactive Commercial Valuation Calculator
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "COMMERCIAL ENERGY & REVENUE CALCULATOR",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmberHighlight
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "CONTRACT VOLUME: ${EnergyStandard.formatTonnes(volumeSliderTonnes.toDouble())}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmber
                    )
                    Slider(
                        value = volumeSliderTonnes,
                        onValueChange = { volumeSliderTonnes = it },
                        valueRange = 5000f..250000f,
                        steps = 48,
                        colors = SliderDefaults.colors(
                            thumbColor = NcbAmberHighlight,
                            activeTrackColor = NcbAmber,
                            inactiveTrackColor = NcbAmberDark
                        )
                    )

                    Text(
                        text = "PRICE PER TONNE: ${EnergyStandard.formatGbpPerTonne(priceSliderGbp.toDouble())}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmber
                    )
                    Slider(
                        value = priceSliderGbp,
                        onValueChange = { priceSliderGbp = it },
                        valueRange = 90f..220f,
                        steps = 65,
                        colors = SliderDefaults.colors(
                            thumbColor = NcbAmberHighlight,
                            activeTrackColor = NcbAmber,
                            inactiveTrackColor = NcbAmberDark
                        )
                    )

                    Text(
                        text = "CALORIFIC SPECIFICATION: ${EnergyStandard.formatCalorificValue(calorificSliderBtu.toDouble())}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmber
                    )
                    Slider(
                        value = calorificSliderBtu,
                        onValueChange = { calorificSliderBtu = it },
                        valueRange = 9500f..14000f,
                        steps = 45,
                        colors = SliderDefaults.colors(
                            thumbColor = NcbAmberHighlight,
                            activeTrackColor = NcbAmber,
                            inactiveTrackColor = NcbAmberDark
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Spacer(modifier = Modifier.fillMaxWidth().height(1.dp).background(NcbBorderAmberThin))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TOTAL CONTRACT VALUE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                            Text(EnergyStandard.formatGbp(calculatedRevenueGbp), fontSize = 18.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, color = NcbAmberHighlight)
                        }
                        Column {
                            Text("THERMAL ENERGY OUTPUT", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                            Text(EnergyStandard.formatMmbTu(calculatedMmbTu), fontSize = 18.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, color = NcbAmberHighlight)
                        }
                        Column {
                            Text("ENERGY PARITY", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                            Text(String.format("£%.2f/MMBtu", gbpPerMmbTu), fontSize = 18.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, color = NcbAmberHighlight)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            item {
                Text(
                    text = "STANDARD UK COAL COMMERCIAL GRADES",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NcbAmber
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            items(state.geologicalLayers.size) { i ->
                val layer = state.geologicalLayers[i]
                val indicativePrice = 110.0 + (layer.calorificValueBtuPerLb - 10000.0) * 0.02
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = layer.name, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbAmber)
                        Text(text = "Spec: ${EnergyStandard.formatCalorificValue(layer.calorificValueBtuPerLb)} | Ash: ${layer.ashContentPercent}%", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = EnergyStandard.formatGbpPerTonne(indicativePrice), fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, color = NcbAmberHighlight)
                        Text(text = "FOB Immingham Term", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberDeep)
                    }
                }
            }
        }
    }
}
