package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDark
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbAmberSubtle
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun TerminalScreen(
    state: SimulationState,
    commandOutput: String,
    onRunCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var inputCommand by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val quickCommands = listOf("STATUS", "PRODUCTION", "MINES", "ASSETS", "LOGISTICS", "MARKETS", "CONTRACTS", "STOCKS", "ENERGY", "QUALITY", "REPORTS", "ALERTS", "CLEAR", "HELP")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("terminal_screen")
    ) {
        NcbHeader()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "NCB MAINFRAME INDUSTRIAL INTERPRETER v3.8",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmber
                )
                Text(
                    text = "[READY / SESSION: OPERATOR]",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NcbAmberHighlight
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Quick command chips row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                quickCommands.take(7).forEach { cmd ->
                    AssistChip(
                        onClick = { onRunCommand(cmd) },
                        label = { Text(cmd, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmber) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = NcbAmberSubtle),
                        border = AssistChipDefaults.assistChipBorder(borderColor = NcbAmberDark, enabled = true)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Terminal Screen Viewport
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(NcbBlack)
                    .border(width = 1.dp, color = NcbBorderAmberThin)
                    .padding(10.dp)
            ) {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    item {
                        Text(
                            text = """
                            ========================================================================
                            NATIONAL COAL BOARD — DISTRIBUTED INDUSTRIAL COMPUTING GRID
                            ALL SYSTEMS REPORTING NOMINAL TELEMETRY. CURRENCY: GBP | ENERGY: BTU.
                            TYPE 'HELP' FOR THE COMPREHENSIVE COMMAND DIRECTORY.
                            ========================================================================
                            
                            """.trimIndent(),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbAmberDeep,
                            lineHeight = 14.sp
                        )
                    }

                    if (commandOutput.isNotEmpty()) {
                        item {
                            Text(
                                text = commandOutput,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NcbAmberHighlight,
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }

                    item {
                        Text(
                            text = "LIVE SYSTEM EVENT STREAM:",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbAmberMuted
                        )
                    }

                    items(state.recentLogs) { log ->
                        Text(
                            text = "[${log.timestamp}] ${log.source.uppercase()}: ${log.message}",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmber,
                            lineHeight = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Interactive Command Prompt
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NcbBlack)
                    .border(width = 1.5.dp, color = NcbAmber)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "NCB_TERMINAL >",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmber
                )

                Spacer(modifier = Modifier.width(8.dp))

                BasicTextField(
                    value = inputCommand,
                    onValueChange = { inputCommand = it },
                    textStyle = TextStyle(
                        color = NcbAmberHighlight,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    cursorBrush = SolidColor(NcbAmber),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (inputCommand.isNotBlank()) {
                                onRunCommand(inputCommand)
                                inputCommand = ""
                            }
                        }
                    ),
                    modifier = Modifier.weight(1f).testTag("fullscreen_terminal_input")
                )

                IconButton(
                    onClick = {
                        if (inputCommand.isNotBlank()) {
                            onRunCommand(inputCommand)
                            inputCommand = ""
                        }
                    },
                    modifier = Modifier.size(28.dp).testTag("fullscreen_terminal_send")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Run",
                        tint = NcbAmber
                    )
                }
            }
        }
    }
}
