package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TerminalLogEvent
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun NcbTerminalPanel(
    logs: List<TerminalLogEvent>,
    onRunCommand: (String) -> Unit,
    commandOutput: String = "",
    modifier: Modifier = Modifier
) {
    var inputCommand by remember { mutableStateOf("") }
    val logListState = rememberLazyListState()

    val quickCommands = listOf(
        "status" to "view site status",
        "production" to "latest output figures",
        "markets" to "coal prices & trends",
        "contracts" to "view active contracts",
        "logistics" to "transport & shipping",
        "reports" to "generate reports",
        "help" to "show all commands"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NcbBlack)
            .border(width = 1.dp, color = NcbBorderAmberThin)
            .padding(10.dp)
            .testTag("terminal_panel")
    ) {
        // Terminal Header Prompt
        Text(
            text = "NCB_TERMINAL > _",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.0.sp,
            color = NcbAmber
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Split view: Left = quick commands table, Right = timestamped log stream
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 145.dp)
        ) {
            // Left Quick Commands
            Column(
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                quickCommands.forEach { (cmd, desc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onRunCommand(cmd)
                            }
                            .padding(vertical = 1.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "> $cmd",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbAmber,
                            modifier = Modifier.width(92.dp)
                        )
                        Text(
                            text = "# $desc",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Normal,
                            color = NcbAmberMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Thin vertical gold divider
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .fillMaxHeight()
                    .background(NcbBorderAmberThin)
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Right Live Event Logs
            LazyColumn(
                state = logListState,
                modifier = Modifier
                    .weight(1.05f)
                    .fillMaxHeight()
            ) {
                items(logs) { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 1.5.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "[${log.timestamp}]",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbAmberDeep,
                            modifier = Modifier.width(44.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${log.source} - ${log.message}",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Normal,
                            color = NcbAmberHighlight,
                            lineHeight = 12.sp
                        )
                    }
                }
            }
        }

        // Optional terminal command result buffer if user has executed commands
        if (commandOutput.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NcbBlack)
                    .border(width = 1.dp, color = NcbBorderAmberThin)
                    .padding(6.dp)
            ) {
                Text(
                    text = commandOutput.takeLast(1200),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Normal,
                    color = NcbAmberHighlight,
                    lineHeight = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Interactive Command Input Line
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NcbBlack)
                .border(width = 1.dp, color = NcbBorderAmberThin)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "NCB>",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = NcbAmber
            )

            Spacer(modifier = Modifier.width(6.dp))

            BasicTextField(
                value = inputCommand,
                onValueChange = { inputCommand = it },
                textStyle = TextStyle(
                    color = NcbAmberHighlight,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                ),
                cursorBrush = SolidColor(NcbAmber),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputCommand.isNotBlank()) {
                            onRunCommand(inputCommand)
                            inputCommand = ""
                        }
                    }
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_input_field")
            )

            IconButton(
                onClick = {
                    if (inputCommand.isNotBlank()) {
                        onRunCommand(inputCommand)
                        inputCommand = ""
                    }
                },
                modifier = Modifier.size(24.dp).testTag("terminal_send_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Execute Command",
                    tint = NcbAmber,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
