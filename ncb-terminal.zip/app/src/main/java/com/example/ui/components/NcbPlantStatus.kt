package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EnergyStandard
import com.example.model.MineSite
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin
import com.example.ui.theme.NcbGreen

@Composable
fun NcbPlantStatus(
    mines: List<MineSite>,
    totalOutputTonnes: Double,
    onMineSelected: (MineSite) -> Unit = {},
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NcbBlack)
            .border(width = 1.dp, color = NcbBorderAmberThin)
            .padding(10.dp)
            .testTag("plant_status_panel")
    ) {
        Text(
            text = "PLANT STATUS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.2.sp,
            color = NcbAmberMuted
        )

        Spacer(modifier = Modifier.height(8.dp))

        mines.forEach { mine ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clickable { onMineSelected(mine) },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(NcbGreen)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = mine.name,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        color = NcbAmberDeep
                    )
                }

                Text(
                    text = mine.status.name,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NcbAmber
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(NcbBorderAmberThin)
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Total Output Section matching reference
        Text(
            text = "TOTAL OUTPUT (MT)",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.0.sp,
            color = NcbAmber
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = EnergyStandard.formatTonnesMt(totalOutputTonnes),
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp,
            color = NcbAmberHighlight
        )

        Spacer(modifier = Modifier.height(2.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "▲",
                fontSize = 10.sp,
                color = NcbAmber
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "+3.2% vs. last week",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = NcbAmberDeep
            )
        }
    }
}
