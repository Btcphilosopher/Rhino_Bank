package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CustomerDemand
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDark
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun NcbCustomersPanel(
    customers: List<CustomerDemand>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NcbBlack)
            .border(width = 1.dp, color = NcbBorderAmberThin)
            .padding(10.dp)
            .testTag("customers_panel")
    ) {
        Text(
            text = "TOP CUSTOMERS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.0.sp,
            color = NcbAmber
        )

        Spacer(modifier = Modifier.height(8.dp))

        customers.forEach { customer ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = customer.name,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    color = NcbAmberDeep,
                    modifier = Modifier.width(90.dp)
                )

                // Amber progress bar
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(8.dp)
                        .background(NcbAmberDark)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(customer.sharePercent / 100f)
                            .background(NcbAmberHighlight)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "${customer.sharePercent}%",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NcbAmber,
                    modifier = Modifier.width(28.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Bottom NCB industrial seal matching reference image
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(width = 1.dp, color = NcbBorderAmberThin)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "NCB",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = (-1.0).sp,
                color = NcbAmber
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = "BRITISH COAL",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "FOR A STRONGER TOMORROW",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 0.5.sp,
                    color = NcbAmberDeep
                )
            }
        }
    }
}
