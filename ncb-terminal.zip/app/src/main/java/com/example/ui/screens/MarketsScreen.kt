package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.model.EnergyStandard
import com.example.ui.components.MarketPriceChart
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun MarketsScreen(
    state: SimulationState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("markets_screen")
    ) {
        NcbHeader()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            item {
                Text(
                    text = "COMMODITIES MARKET INTELLIGENCE & DARK SPREADS",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "GLOBAL BENCHMARKS CONVERTED STRICTLY TO GBP (£) PER TONNE",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmberDeep
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Mountain Chart
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "HISTORICAL BENCHMARK COMPOSITE (£/T)",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = NcbAmberHighlight
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    MarketPriceChart(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            item {
                Text(
                    text = "LIVE COMMODITY INDEX BENCHMARKS",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NcbAmber
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            items(state.marketPrices.size) { i ->
                val index = state.marketPrices[i]
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = index.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmber
                        )
                        Text(
                            text = EnergyStandard.formatGbpPerTonne(index.priceGbpPerTonne),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmberHighlight
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Basis: ${EnergyStandard.formatCalorificValue(index.calorificBasisBtuPerLb)} (${index.location})",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmberMuted
                        )
                        Text(
                            text = "▲ +${index.changePercentWoW}% WoW",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "UK Clean Dark Spread: £${index.sparkSpreadGbp}/MWh",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbAmberDeep
                        )
                        Text(
                            text = "Effective Energy: £${String.format("%.2f", EnergyStandard.calculateGbpPerMmbTu(index.priceGbpPerTonne, index.calorificBasisBtuPerLb))}/MMBtu",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmberDeep
                        )
                    }
                }
            }
        }
    }
}
