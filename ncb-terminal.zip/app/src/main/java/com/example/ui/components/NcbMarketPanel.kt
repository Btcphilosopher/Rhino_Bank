package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MarketPriceIndex
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbAmberSubtle
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun NcbMarketPanel(
    marketPrices: List<MarketPriceIndex>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NcbBlack)
            .border(width = 1.dp, color = NcbBorderAmberThin)
            .padding(10.dp)
            .testTag("market_panel")
    ) {
        Text(
            text = "COAL MARKET PRICES (£/T)",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.0.sp,
            color = NcbAmber
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Price index items
        marketPrices.forEach { price ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = price.name.take(18),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    color = NcbAmberDeep
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = String.format(java.util.Locale.UK, "%.2f", price.priceGbpPerTonne),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = NcbAmberHighlight
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "▲",
                        fontSize = 8.sp,
                        color = NcbAmber
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "+${price.changePercentWoW}%",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = NcbAmber
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Amber Mountain Price Trend Chart
        MarketPriceChart(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
        )

        // Quarter axis labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("80", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
            Text("Q1", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
            Text("Q2", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
            Text("Q3", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
            Text("Q4", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
        }
    }
}

@Composable
fun MarketPriceChart(
    modifier: Modifier = Modifier
) {
    // 24 simulated seasonal points rising towards year end
    val points = listOf(
        88f, 91f, 89f, 94f, 96f, 102f, 105f, 101f, 108f, 114f, 112f, 118f,
        122f, 120f, 125f, 131f, 128f, 134f, 138f, 142f, 145f, 148f, 153f, 158f
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val minVal = 70f
        val maxVal = 170f

        // Draw horizontal grid lines
        val gridLevels = listOf(80f, 100f, 120f, 140f, 160f)
        gridLevels.forEach { lvl ->
            val y = h - ((lvl - minVal) / (maxVal - minVal) * h)
            drawLine(
                color = NcbBorderAmberThin,
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 0.5f
            )
        }

        // Build filled mountain path
        val path = Path()
        val fillPath = Path()

        val stepX = w / (points.size - 1)

        points.forEachIndexed { i, pt ->
            val x = i * stepX
            val y = h - ((pt - minVal) / (maxVal - minVal) * h)
            if (i == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }

        fillPath.lineTo(w, h)
        fillPath.close()

        // Gradient fill
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    NcbAmberHighlight.copy(alpha = 0.6f),
                    NcbAmber.copy(alpha = 0.25f),
                    NcbBlack.copy(alpha = 0.05f)
                )
            )
        )

        // Stroke line
        drawPath(
            path = path,
            color = NcbAmberHighlight,
            style = Stroke(width = 1.5f)
        )
    }
}
