package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EnergyStandard
import com.example.model.ProductionMetrics
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin

@Composable
fun NcbMetricsStrip(
    metrics: ProductionMetrics,
    modifier: Modifier = Modifier
) {
    var showEnergyDetails by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NcbBlack)
            .border(width = 1.dp, color = NcbBorderAmberThin)
            .clickable { showEnergyDetails = !showEnergyDetails }
            .testTag("metrics_strip")
    ) {
        // Primary 4 Metrics Strip matching reference image
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            MetricBlock(
                title = "PRODUCTION (MT)",
                value = EnergyStandard.formatTonnesMt(metrics.productionTonnes),
                trend = "+${metrics.productionWoWPercent}% WoW",
                modifier = Modifier.weight(1f).testTag("metric_production")
            )

            MetricDivider()

            MetricBlock(
                title = "DELIVERIES (MT)",
                value = EnergyStandard.formatTonnesMt(metrics.deliveriesTonnes),
                trend = "+${metrics.deliveriesWoWPercent}% WoW",
                modifier = Modifier.weight(1f).testTag("metric_deliveries")
            )

            MetricDivider()

            MetricBlock(
                title = "STOCKS (MT)",
                value = EnergyStandard.formatTonnesMt(metrics.stockTonnes),
                trend = "+${metrics.stockWoWPercent}% WoW",
                modifier = Modifier.weight(1f).testTag("metric_stocks")
            )

            MetricDivider()

            MetricBlock(
                title = "AVERAGE PRICE (£/T)",
                value = String.format(java.util.Locale.UK, "%.2f", metrics.averagePriceGbp),
                trend = "+${metrics.averagePriceWoWPercent}% WoW",
                modifier = Modifier.weight(1f).testTag("metric_avg_price")
            )
        }

        // Secondary Expandable BTU Energy Strip (Global Energy Standard)
        AnimatedVisibility(visible = showEnergyDetails) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NcbBlack)
                    .border(width = 1.dp, color = NcbBorderAmberThin)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricBlock(
                        title = "THERMAL ENERGY (MMBtu)",
                        value = EnergyStandard.formatMmbTu(metrics.thermalEnergyMmbTu),
                        trend = "11,200 BTU/lb BASE",
                        modifier = Modifier.weight(1f)
                    )
                    MetricDivider()
                    MetricBlock(
                        title = "ENERGY INTENSITY",
                        value = "24.69 MMBtu/t",
                        trend = "BTU-BASED STANDARD",
                        modifier = Modifier.weight(1f)
                    )
                    MetricDivider()
                    MetricBlock(
                        title = "EQUIPMENT UTILISATION",
                        value = "${metrics.equipmentUtilisationPercent}%",
                        trend = "23 BENCHES ACTIVE",
                        modifier = Modifier.weight(1f)
                    )
                    MetricDivider()
                    MetricBlock(
                        title = "OPERATIONAL AVAILABILITY",
                        value = "${metrics.operationalAvailabilityPercent}%",
                        trend = "ZERO CRITICAL FAULTS",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricBlock(
    title: String,
    value: String,
    trend: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(horizontal = 6.dp)
    ) {
        Text(
            text = title,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp,
            color = NcbAmberDeep
        )

        Spacer(modifier = Modifier.height(3.dp))

        Text(
            text = value,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.4.sp,
            color = NcbAmberHighlight
        )

        Spacer(modifier = Modifier.height(2.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "▲",
                fontSize = 8.sp,
                color = NcbAmber
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = trend,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = NcbAmberDeep
            )
        }
    }
}

@Composable
private fun MetricDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(48.dp)
            .background(NcbBorderAmberThin)
    )
}
