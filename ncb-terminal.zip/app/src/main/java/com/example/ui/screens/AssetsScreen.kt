package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin
import com.example.ui.theme.NcbGreen

@Composable
fun AssetsScreen(
    state: SimulationState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("assets_screen")
    ) {
        NcbHeader()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            item {
                Text(
                    text = "HEAVY MINING EQUIPMENT & ASSET INVENTORY",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "TELEMETRY LINK: 18 ACTIVE UNITS  |  POWER DRAW IN kBTU/hr",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmberDeep
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Dragline Asset Card
            item {
                val dragline = state.dragline
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = dragline.name.uppercase(),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmber
                        )
                        Text(
                            text = "[${dragline.status}]",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbGreen
                        )
                    }
                    Text(
                        text = "ID: ${dragline.id} | Location: Bench ${dragline.benchIndex} Face",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmberDeep
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Bucket: ${dragline.bucketCapacityTonnes} t/cycle", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmberHighlight)
                        Text("Power Draw: ${dragline.powerDrawKbtuPerHr} kBTU/hr", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmberHighlight)
                        Text("Hours: ${dragline.operatingHours} hrs", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmberHighlight)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Fixed Infrastructure
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "OVERLAND TRUNK CONVEYOR (CV-MAIN)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmber
                        )
                        Text(
                            text = "[ONLINE]",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbGreen
                        )
                    }
                    Text("Length: 1,450 m | Belt Speed: 4.2 m/s | Power: 8,400 kBTU/hr", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    Text("Current Throughput: 3,920 t/h (Max 4,200 t/h - 93% Load)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmberHighlight)
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            item {
                Text(
                    text = "AUTONOMOUS HAUL TRUCK FLEET (TELEMETRY LIVE)",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NcbAmber
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Haul Trucks
            items(state.haulTrucks.size) { i ->
                val truck = state.haulTrucks[i]
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${truck.id} — ${truck.model}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmber
                        )
                        Text(
                            text = "[${truck.status}]",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbGreen
                        )
                    }
                    Text(
                        text = "Route: ${truck.routeDescription}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmberDeep
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Payload: ${truck.currentPayloadTonnes} t / ${truck.capacityTonnes} t", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmberHighlight)
                        Text("Speed: ${truck.speedKph} km/h", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmberHighlight)
                        Text("Fuel Rate: ${truck.fuelRateKbtuPerHr} kBTU/hr", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = NcbAmberHighlight)
                    }
                }
            }
        }
    }
}
