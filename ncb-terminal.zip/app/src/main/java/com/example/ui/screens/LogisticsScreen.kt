package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.SimulationState
import com.example.model.EnergyStandard
import com.example.ui.components.NcbHeader
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin
import com.example.ui.theme.NcbGreen

@Composable
fun LogisticsScreen(
    state: SimulationState,
    modifier: Modifier = Modifier
) {
    val trains = listOf(
        Triple("FL-66108", "Kellingley Pit Loop -> Drax Power Station", "2,450 t | 10:28 Dispatched | In Transit (45 km/h)"),
        Triple("FL-66224", "Blyth Terminal -> Port of Tyne Coal Terminal", "1,800 t | 10:14 Dispatched | Approaching Dock"),
        Triple("FL-66042", "Hatfield Colliery -> Ratcliffe-on-Soar Power Station", "2,100 t | Loading at Rail Head"),
        Triple("FL-66315", "Ffos-y-fran Yard -> Tata Steel Port Talbot", "1,650 t (Coking) | In Transit (52 km/h)")
    )

    val stockpiles = listOf(
        Triple("Kellingley Surface Yard", "112,400 t", "Silkstone Deep Blend (12,400 BTU/lb)"),
        Triple("Blyth Terminal Stockyard", "84,600 t", "Northumberland Steam Coal (10,400 BTU/lb)"),
        Triple("Ffos-y-fran Storage Bunkers", "68,200 t", "Welsh High-Grade Anthracite (13,200 BTU/lb)"),
        Triple("Hatfield Central Railhead", "97,600 t", "Industrial Washing Smalls (11,400 BTU/lb)")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("logistics_screen")
    ) {
        NcbHeader()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            item {
                Text(
                    text = "BRITISH RAIL FREIGHT & LOGISTICS DISPATCH",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "OPERATING NETWORK: FREIGHTLINER CLASS 66 FLEET  |  PORTS: TYNE & IMMINGHAM",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmberDeep
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            item {
                Text(
                    text = "ACTIVE TRAIN DISPATCH MOVEMENTS",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NcbAmber
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            items(trains.size) { i ->
                val (loco, route, details) = trains[i]
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LOCOMOTIVE $loco",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = NcbAmberHighlight
                        )
                        Text(
                            text = "STATUS: TRACKED",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NcbGreen
                        )
                    }
                    Text(
                        text = route,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmber
                    )
                    Text(
                        text = details,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmberMuted
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "STRATEGIC COAL STOCKPILES (TOTAL: ${EnergyStandard.formatTonnes(state.metrics.stockTonnes)})",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NcbAmber
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            items(stockpiles.size) { i ->
                val (loc, vol, spec) = stockpiles[i]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .background(NcbBlack)
                        .border(width = 1.dp, color = NcbBorderAmberThin)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = loc, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NcbAmber)
                        Text(text = spec, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = NcbAmberMuted)
                    }
                    Text(text = vol, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, color = NcbAmberHighlight)
                }
            }
        }
    }
}
