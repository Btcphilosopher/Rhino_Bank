package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NcbHeader(
    modifier: Modifier = Modifier
) {
    var currentTimeStr by remember { mutableStateOf("14 NOV 2026 10:42:17") }

    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("dd MMM yyyy   HH:mm:ss", Locale.UK)
        while (true) {
            currentTimeStr = sdf.format(Date()).uppercase()
            delay(1000)
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(NcbBlack)
            .border(width = 1.dp, color = NcbBorderAmberThin)
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("ncb_header"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left Branding: Giant bold NCB logo and Title
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "NCB",
                fontSize = 34.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = (-1.0).sp,
                color = NcbAmber,
                modifier = Modifier.testTag("ncb_logo_text")
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Thin vertical gold divider
            Spacer(
                modifier = Modifier
                    .width(2.dp)
                    .height(34.dp)
                    .background(NcbAmber)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "NATIONAL COAL BOARD",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.5.sp,
                    color = NcbAmber
                )
                Text(
                    text = "ENERGY  |  INDUSTRY  |  BRITAIN",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.0.sp,
                    color = NcbAmberDeep
                )
            }
        }

        // Right Telemetry & Motto
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = currentTimeStr,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "NCB_TRADING_TERMINAL v3.8",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Normal,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.0.sp,
                    color = NcbAmberDeep
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Thin vertical gold divider
            Spacer(
                modifier = Modifier
                    .width(1.dp)
                    .height(32.dp)
                    .background(NcbAmberMuted)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "COAL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "POWERS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
                Text(
                    text = "PROGRESS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.0.sp,
                    color = NcbAmber
                )
            }
        }
    }
}
