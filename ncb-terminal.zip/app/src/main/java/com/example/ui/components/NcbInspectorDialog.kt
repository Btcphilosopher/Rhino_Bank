package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.renderer.InspectedAsset
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NcbInspectorDialog(
    asset: InspectedAsset,
    onDismiss: () -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth(0.92f)
            .background(NcbBlack)
            .border(width = 1.5.dp, color = NcbBorderAmber)
            .padding(16.dp)
            .testTag("asset_inspector_dialog")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ASSET TELEMETRY INSPECTOR",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.2.sp,
                    color = NcbAmberMuted
                )
                Text(
                    text = "[LIVE LINK]",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = NcbAmber
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = asset.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = NcbAmberHighlight
            )

            Text(
                text = asset.type,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = NcbAmberDeep
            )

            Spacer(modifier = Modifier.height(10.dp))
            Spacer(modifier = Modifier.fillMaxWidth().height(1.dp).background(NcbBorderAmber))
            Spacer(modifier = Modifier.height(10.dp))

            InspectorRow("LOCATION", asset.location)
            InspectorRow("STATUS", asset.status)
            InspectorRow("RATE / PAYLOAD", asset.currentRate)
            InspectorRow("ENERGY CONSUMPTION", asset.energyDraw)

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = asset.details,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = NcbAmberDeep,
                lineHeight = 14.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("inspector_close_btn")
                ) {
                    Text(
                        text = "CLOSE TELEMETRY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = NcbAmber
                    )
                }
            }
        }
    }
}

@Composable
private fun InspectorRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            color = NcbAmberMuted
        )
        Text(
            text = value,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = NcbAmber
        )
    }
}
