package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.simulation.SimulationState
import com.example.model.CoalContract
import com.example.model.MineSite
import com.example.renderer.InspectedAsset
import com.example.renderer.MiningSceneRenderer
import com.example.ui.components.NcbContractsPanel
import com.example.ui.components.NcbCustomersPanel
import com.example.ui.components.NcbHeader
import com.example.ui.components.NcbMarketPanel
import com.example.ui.components.NcbMetricsStrip
import com.example.ui.components.NcbPlantStatus
import com.example.ui.components.NcbTerminalPanel
import com.example.ui.navigation.NcbDestination
import com.example.ui.navigation.NcbNavigationRail
import com.example.ui.theme.NcbBlack

@Composable
fun OverviewScreen(
    state: SimulationState,
    currentDestination: NcbDestination,
    commandOutput: String,
    onNavigate: (NcbDestination) -> Unit,
    onInspectAsset: (InspectedAsset) -> Unit,
    onRunCommand: (String) -> Unit,
    onMineSelected: (MineSite) -> Unit,
    onContractSelected: (CoalContract) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("overview_screen")
    ) {
        val isWide = maxWidth > 840.dp

        Column(modifier = Modifier.fillMaxSize()) {
            // Master Header across top
            NcbHeader()

            if (isWide) {
                // Wide / Tablet / Desktop split layout matching the reference image exactly
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(6.dp)
                ) {
                    // Left Column: Nav rail + Plant status list + Total Output
                    Column(
                        modifier = Modifier
                            .width(220.dp)
                            .fillMaxHeight()
                    ) {
                        NcbNavigationRail(
                            currentDestination = currentDestination,
                            onDestinationSelected = onNavigate,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        NcbPlantStatus(
                            mines = state.mines,
                            totalOutputTonnes = state.metrics.productionTonnes,
                            onMineSelected = onMineSelected,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Center Column: 3D Mine Animation + Metrics Strip + Terminal
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        MiningSceneRenderer(
                            simulationState = state,
                            onInspectAsset = onInspectAsset,
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        NcbMetricsStrip(
                            metrics = state.metrics,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        NcbTerminalPanel(
                            logs = state.recentLogs,
                            onRunCommand = onRunCommand,
                            commandOutput = commandOutput,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Right Column: Market Prices + Contracts + Top Customers
                    Column(
                        modifier = Modifier
                            .width(260.dp)
                            .fillMaxHeight()
                    ) {
                        NcbMarketPanel(
                            marketPrices = state.marketPrices,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        NcbContractsPanel(
                            contracts = state.contracts,
                            onContractSelected = onContractSelected,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        NcbCustomersPanel(
                            customers = state.topCustomers,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            } else {
                // Portrait Mobile Layout: Scrollable responsive presentation
                val scrollState = rememberScrollState()
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(6.dp)
                ) {
                    // 3D Animated Mining Digital Twin at the top
                    MiningSceneRenderer(
                        simulationState = state,
                        onInspectAsset = onInspectAsset,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Metrics Strip
                    NcbMetricsStrip(
                        metrics = state.metrics,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Terminal Panel
                    NcbTerminalPanel(
                        logs = state.recentLogs,
                        onRunCommand = onRunCommand,
                        commandOutput = commandOutput,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Market Prices
                    NcbMarketPanel(
                        marketPrices = state.marketPrices,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Plant Status
                    NcbPlantStatus(
                        mines = state.mines,
                        totalOutputTonnes = state.metrics.productionTonnes,
                        onMineSelected = onMineSelected,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Contracts & Customers
                    NcbContractsPanel(
                        contracts = state.contracts,
                        onContractSelected = onContractSelected,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    NcbCustomersPanel(
                        customers = state.topCustomers,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
