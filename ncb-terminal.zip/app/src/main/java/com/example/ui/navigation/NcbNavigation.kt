package com.example.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDeep
import com.example.ui.theme.NcbBlack

enum class NcbDestination(val label: String, val icon: ImageVector) {
    OVERVIEW("OVERVIEW", Icons.Default.GridView),
    PRODUCTION("PRODUCTION", Icons.Default.Build),
    LOGISTICS("LOGISTICS", Icons.Default.LocalShipping),
    SALES_TRADING("SALES & TRADING", Icons.Default.TrendingUp),
    CONTRACTS("CONTRACTS", Icons.Default.Description),
    MARKETS("MARKETS", Icons.Default.Public),
    ASSETS("ASSETS", Icons.Default.Business),
    REPORTS("REPORTS", Icons.Default.Assessment),
    TERMINAL("TERMINAL", Icons.Default.Terminal),
    SETTINGS("SETTINGS", Icons.Default.Settings)
}

@Composable
fun NcbNavigationRail(
    currentDestination: NcbDestination,
    onDestinationSelected: (NcbDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(NcbBlack)
            .padding(vertical = 4.dp)
            .testTag("ncb_navigation_rail")
    ) {
        NcbDestination.entries.forEach { destination ->
            val isSelected = destination == currentDestination

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 1.dp, horizontal = 2.dp)
                    .background(if (isSelected) NcbAmber else NcbBlack)
                    .clickable { onDestinationSelected(destination) }
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .testTag("nav_item_${destination.name.lowercase()}"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = destination.icon,
                    contentDescription = destination.label,
                    tint = if (isSelected) NcbBlack else NcbAmber,
                    modifier = Modifier.width(18.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = destination.label,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = if (isSelected) NcbBlack else NcbAmberDeep
                )
            }
        }
    }
}
