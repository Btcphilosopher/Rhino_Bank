package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.renderer.InspectedAsset
import com.example.ui.components.NcbInspectorDialog
import com.example.ui.navigation.NcbDestination
import com.example.ui.screens.AssetsScreen
import com.example.ui.screens.ContractsScreen
import com.example.ui.screens.LogisticsScreen
import com.example.ui.screens.MarketsScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.ProductionScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SalesTradingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NcbAmber
import com.example.ui.theme.NcbAmberDark
import com.example.ui.theme.NcbAmberHighlight
import com.example.ui.theme.NcbAmberMuted
import com.example.ui.theme.NcbAmberSubtle
import com.example.ui.theme.NcbBlack
import com.example.ui.theme.NcbBorderAmberThin
import com.example.viewmodel.NcbTerminalViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: NcbTerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NcbTerminalApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun NcbTerminalApp(viewModel: NcbTerminalViewModel) {
    val currentDestination by viewModel.currentDestination.collectAsState()
    val simulationState by viewModel.simulationState.collectAsState()
    val commandOutput by viewModel.commandOutput.collectAsState()
    val inspectedAsset by viewModel.inspectedAsset.collectAsState()
    val persistedContracts by viewModel.persistedContracts.collectAsState()

    // Handle system back navigation to return to OVERVIEW
    BackHandler(enabled = currentDestination != NcbDestination.OVERVIEW) {
        viewModel.navigateTo(NcbDestination.OVERVIEW)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(NcbBlack)
            .testTag("ncb_main_scaffold"),
        containerColor = NcbBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(NcbBlack)
        ) {
            // Quick Module Navigation Bar
            QuickDestinationChips(
                currentDestination = currentDestination,
                onSelectDestination = { viewModel.navigateTo(it) },
                onBack = { viewModel.navigateTo(NcbDestination.OVERVIEW) }
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (currentDestination) {
                    NcbDestination.OVERVIEW -> {
                        OverviewScreen(
                            state = simulationState,
                            currentDestination = currentDestination,
                            commandOutput = commandOutput,
                            onNavigate = { viewModel.navigateTo(it) },
                            onInspectAsset = { viewModel.inspectAsset(it) },
                            onRunCommand = { viewModel.executeCommand(it) },
                            onMineSelected = { mine ->
                                viewModel.inspectAsset(
                                    InspectedAsset(
                                        title = "${mine.name.uppercase()} COLLIERY",
                                        type = "Deep Seam Mining Site (${mine.county})",
                                        location = mine.coordinates,
                                        status = mine.status.name,
                                        currentRate = "DAILY OUTPUT: ${mine.currentOutputTonnes} t",
                                        energyDraw = "CALORIFIC SPEC: ${mine.calorificValueBtuPerLb} BTU/lb",
                                        details = "Seam: ${mine.seamName}. Depth: ${mine.depthMeters}m. Active Benches: ${mine.activeBenches}. Haul fleet: ${mine.haulTrucksAssigned} units."
                                    )
                                )
                            },
                            onContractSelected = { contract ->
                                viewModel.inspectAsset(
                                    InspectedAsset(
                                        title = contract.counterparty,
                                        type = "Commercial Coal Supply Contract",
                                        location = contract.sector,
                                        status = contract.status.name,
                                        currentRate = "COMMITTED: ${contract.totalVolumeTonnes} t",
                                        energyDraw = "ENERGY SPEC: ${contract.energySpecBtuPerLb} BTU/lb",
                                        details = "Price: £${contract.pricePerTonneGbp}/t. Delivery Period: ${contract.deliveryPeriod}."
                                    )
                                )
                            }
                        )
                    }

                    NcbDestination.PRODUCTION -> {
                        ProductionScreen(
                            state = simulationState,
                            onMineSelected = { viewModel.inspectAsset(null) }
                        )
                    }

                    NcbDestination.LOGISTICS -> {
                        LogisticsScreen(state = simulationState)
                    }

                    NcbDestination.SALES_TRADING -> {
                        SalesTradingScreen(state = simulationState)
                    }

                    NcbDestination.CONTRACTS -> {
                        ContractsScreen(
                            contracts = persistedContracts,
                            onAddContract = { cp, sec, ton, price, btu, per ->
                                viewModel.addContract(cp, sec, ton, price, btu, per)
                            }
                        )
                    }

                    NcbDestination.MARKETS -> {
                        MarketsScreen(state = simulationState)
                    }

                    NcbDestination.ASSETS -> {
                        AssetsScreen(state = simulationState)
                    }

                    NcbDestination.REPORTS -> {
                        ReportsScreen(state = simulationState)
                    }

                    NcbDestination.TERMINAL -> {
                        TerminalScreen(
                            state = simulationState,
                            commandOutput = commandOutput,
                            onRunCommand = { viewModel.executeCommand(it) }
                        )
                    }

                    NcbDestination.SETTINGS -> {
                        SettingsScreen(
                            state = simulationState,
                            onSetSpeed = { viewModel.setSimulationSpeed(it) },
                            onTogglePause = { viewModel.togglePause() },
                            onResetData = { viewModel.resetAllData() }
                        )
                    }
                }

                // Global Asset Inspector Dialog
                inspectedAsset?.let { asset ->
                    NcbInspectorDialog(
                        asset = asset,
                        onDismiss = { viewModel.inspectAsset(null) }
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickDestinationChips(
    currentDestination: NcbDestination,
    onSelectDestination: (NcbDestination) -> Unit,
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcbBlack)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (currentDestination != NcbDestination.OVERVIEW) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("top_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Return to Overview",
                    tint = NcbAmber
                )
            }
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(scrollState),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NcbDestination.entries.forEach { dest ->
                val isSelected = dest == currentDestination
                AssistChip(
                    onClick = { onSelectDestination(dest) },
                    label = {
                        Text(
                            text = dest.label,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                            color = if (isSelected) NcbBlack else NcbAmber
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (isSelected) NcbAmber else NcbAmberSubtle
                    ),
                    border = AssistChipDefaults.assistChipBorder(
                        borderColor = if (isSelected) NcbAmberHighlight else NcbBorderAmberThin,
                        enabled = true
                    ),
                    modifier = Modifier
                        .padding(horizontal = 2.dp)
                        .testTag("top_chip_${dest.name.lowercase()}")
                )
            }
        }
    }
}
