package com.example.model

enum class EquipmentStatus {
    ONLINE, HAULING, EXCAVATING, CRUSHING, MAINTENANCE, FAULT
}

enum class MineStatus {
    ONLINE, IDLE, MAINTENANCE
}

enum class ContractStatus {
    ACTIVE, PENDING, RENEWAL, FULFILLED
}

enum class LogSeverity {
    INFO, SUCCESS, WARNING, CRITICAL
}

data class MineSite(
    val id: String,
    val name: String,
    val county: String,
    val coordinates: String,
    val depthMeters: Int,
    val status: MineStatus,
    val dailyTargetTonnes: Double,
    val currentOutputTonnes: Double,
    val calorificValueBtuPerLb: Double,
    val seamName: String,
    val activeBenches: Int,
    val haulTrucksAssigned: Int
)

data class HaulTruck(
    val id: String,
    val model: String,
    val capacityTonnes: Double,
    var currentPayloadTonnes: Double,
    var currentBench: Int,
    var status: EquipmentStatus,
    var speedKph: Float,
    var routeDescription: String,
    var fuelRateKbtuPerHr: Double,
    var pathProgress: Float = 0f, // 0.0 to 1.0 along bench haul road
    var worldX: Float = 0f,
    var worldY: Float = 0f,
    var worldZ: Float = 0f
)

data class DraglineExcavator(
    val id: String,
    val name: String,
    val benchIndex: Int,
    val bucketCapacityTonnes: Double,
    var slewAngleDegrees: Float = 0f,
    var boomElevationDegrees: Float = 35f,
    var bucketCycleProgress: Float = 0f,
    var status: EquipmentStatus = EquipmentStatus.EXCAVATING,
    var powerDrawKbtuPerHr: Double = 18400.0,
    var operatingHours: Int = 14280,
    var worldX: Float = 0f,
    var worldY: Float = 0f,
    var worldZ: Float = 0f
)

data class ConveyorGantry(
    val id: String,
    val name: String,
    val lengthMeters: Int,
    val maxCapacityTph: Double,
    var currentThroughputTph: Double,
    var beltSpeedMps: Float,
    var status: EquipmentStatus,
    var powerDrawKbtuPerHr: Double,
    var destination: String
)

data class CoalContract(
    val id: String,
    val counterparty: String,
    val sector: String,
    val totalVolumeTonnes: Double,
    val fulfilledTonnes: Double,
    val pricePerTonneGbp: Double,
    val energySpecBtuPerLb: Double,
    val deliveryPeriod: String,
    val status: ContractStatus
)

data class CustomerDemand(
    val name: String,
    val sharePercent: Int,
    val contractType: String,
    val annualVolumeTonnes: Double,
    val primarySupplySite: String
)

data class MarketPriceIndex(
    val id: String,
    val name: String,
    val location: String,
    val priceGbpPerTonne: Double,
    val changePercentWoW: Double,
    val calorificBasisBtuPerLb: Double,
    val sparkSpreadGbp: Double,
    val historyPrices: List<Double>
)

data class ProductionMetrics(
    val productionTonnes: Double,
    val productionWoWPercent: Double,
    val deliveriesTonnes: Double,
    val deliveriesWoWPercent: Double,
    val stockTonnes: Double,
    val stockWoWPercent: Double,
    val averagePriceGbp: Double,
    val averagePriceWoWPercent: Double,
    val thermalEnergyMmbTu: Double,
    val energyContentBtuPerTonne: Double,
    val equipmentUtilisationPercent: Double,
    val operationalAvailabilityPercent: Double
)

data class TerminalLogEvent(
    val id: Long = 0,
    val timestamp: String,
    val source: String,
    val message: String,
    val severity: LogSeverity = LogSeverity.INFO
)

data class GeologicalLayer(
    val name: String,
    val depthRangeMeters: String,
    val seamThicknessMeters: Double,
    val calorificValueBtuPerLb: Double,
    val estimatedReservesMt: Double,
    val ashContentPercent: Double
)
