package com.example.model

import java.text.DecimalFormat
import java.util.Locale

/**
 * NCB GLOBAL ENERGY & CURRENCY STANDARD
 * Strict Industrial Specification:
 * - Currency: GBP (£) exclusively. No other currencies permitted.
 * - Energy: BTU-based units only (BTU, kBTU, MMBtu, BTU/lb, MMBtu/day).
 * - Mass: Metric Tonnes (t / MT), Kilograms (kg).
 */
object EnergyStandard {

    // 1 Metric Tonne (MT) = 1,000 kg = 2,204.62262185 lbs
    const val LBS_PER_METRIC_TONNE: Double = 2204.62262185

    // Standard British Bituminous Coal Calorific Baseline (BTU/lb)
    const val DEFAULT_CALORIFIC_VALUE_BTU_PER_LB: Double = 11200.0

    // Typical grade calorific ranges in BTU/lb
    val GRADE_CALORIFIC_VALUES: Map<String, Double> = mapOf(
        "Barnsley High-Btu Seam" to 11800.0,
        "Silkstone Deep Coking" to 12400.0,
        "Top Hard Industrial Brights" to 11200.0,
        "Ffos-y-fran Premium Anthracite" to 13200.0,
        "Hatfield Main Washed Smalls" to 10600.0,
        "Blyth Power Station Blend" to 10200.0
    )

    /**
     * Converts physical coal mass (in metric tonnes) to thermal energy (MMBtu)
     * using the specified or default calorific value (in BTU/lb).
     *
     * Formula:
     *   Total BTU = tonnes * LBS_PER_METRIC_TONNE * calorificValueBtuPerLb
     *   MMBtu = Total BTU / 1,000,000
     */
    fun calculateMmbTu(tonnes: Double, calorificValueBtuPerLb: Double = DEFAULT_CALORIFIC_VALUE_BTU_PER_LB): Double {
        if (tonnes <= 0.0 || calorificValueBtuPerLb <= 0.0) return 0.0
        val totalBtu = tonnes * LBS_PER_METRIC_TONNE * calorificValueBtuPerLb
        return totalBtu / 1_000_000.0
    }

    /**
     * Calculates thermal energy intensity per metric tonne (MMBtu/t).
     */
    fun calculateMmbTuPerTonne(calorificValueBtuPerLb: Double = DEFAULT_CALORIFIC_VALUE_BTU_PER_LB): Double {
        return (LBS_PER_METRIC_TONNE * calorificValueBtuPerLb) / 1_000_000.0
    }

    /**
     * Calculates revenue in GBP (£) from coal volume (tonnes) and price (£/t).
     */
    fun calculateRevenueGbp(tonnes: Double, pricePerTonneGbp: Double): Double {
        if (tonnes <= 0.0 || pricePerTonneGbp <= 0.0) return 0.0
        return tonnes * pricePerTonneGbp
    }

    /**
     * Calculates effective energy price in GBP per MMBtu (£/MMBtu).
     */
    fun calculateGbpPerMmbTu(pricePerTonneGbp: Double, calorificValueBtuPerLb: Double = DEFAULT_CALORIFIC_VALUE_BTU_PER_LB): Double {
        val mmbtuPerTonne = calculateMmbTuPerTonne(calorificValueBtuPerLb)
        if (mmbtuPerTonne <= 0.0) return 0.0
        return pricePerTonneGbp / mmbtuPerTonne
    }

    // FORMATTERS

    fun formatGbp(amount: Double): String {
        return when {
            amount >= 1_000_000_000.0 -> String.format(Locale.UK, "£%.2f billion", amount / 1_000_000_000.0)
            amount >= 1_000_000.0 -> String.format(Locale.UK, "£%.2f million", amount / 1_000_000.0)
            amount >= 1_000.0 -> "£" + DecimalFormat("#,##0").format(amount)
            else -> String.format(Locale.UK, "£%.2f", amount)
        }
    }

    fun formatGbpPerTonne(price: Double): String {
        return String.format(Locale.UK, "£%.2f/t", price)
    }

    fun formatTonnes(tonnes: Double): String {
        return DecimalFormat("#,##0").format(tonnes) + " t"
    }

    fun formatTonnesMt(tonnes: Double): String {
        return DecimalFormat("#,##0").format(tonnes)
    }

    fun formatMmbTu(mmbtu: Double): String {
        return when {
            mmbtu >= 1_000_000.0 -> String.format(Locale.UK, "%.2f M MMBtu", mmbtu / 1_000_000.0)
            mmbtu >= 1_000.0 -> DecimalFormat("#,##0").format(mmbtu) + " MMBtu"
            else -> String.format(Locale.UK, "%.1f MMBtu", mmbtu)
        }
    }

    fun formatCalorificValue(btuPerLb: Double): String {
        return DecimalFormat("#,##0").format(btuPerLb) + " BTU/lb"
    }
}
