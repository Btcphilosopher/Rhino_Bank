package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ncb_preferences")

class NcbPreferencesRepository(private val context: Context) {

    companion object {
        val KEY_SIMULATION_SPEED = floatPreferencesKey("sim_speed")
        val KEY_CALORIFIC_BASELINE = doublePreferencesKey("calorific_baseline")
        val KEY_SHOW_GEOLOGY = booleanPreferencesKey("show_geology")
        val KEY_SHOW_FLOW = booleanPreferencesKey("show_flow")
        val KEY_SHOW_EQUIPMENT = booleanPreferencesKey("show_equipment")
        val KEY_CINEMATIC_ORBIT = booleanPreferencesKey("cinematic_orbit")
        val KEY_SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val KEY_DISPLAY_DENSITY = stringPreferencesKey("display_density")
    }

    val simulationSpeed: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[KEY_SIMULATION_SPEED] ?: 1.0f
    }

    val calorificBaseline: Flow<Double> = context.dataStore.data.map { prefs ->
        prefs[KEY_CALORIFIC_BASELINE] ?: 11200.0
    }

    val showGeology: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SHOW_GEOLOGY] ?: true
    }

    val showFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SHOW_FLOW] ?: true
    }

    val showEquipment: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SHOW_EQUIPMENT] ?: true
    }

    val cinematicOrbit: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_CINEMATIC_ORBIT] ?: true
    }

    val soundEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SOUND_ENABLED] ?: false
    }

    val displayDensity: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_DISPLAY_DENSITY] ?: "HIGH_DENSITY"
    }

    suspend fun setSimulationSpeed(speed: Float) {
        context.dataStore.edit { prefs ->
            prefs[KEY_SIMULATION_SPEED] = speed
        }
    }

    suspend fun setCalorificBaseline(value: Double) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CALORIFIC_BASELINE] = value
        }
    }

    suspend fun setLayerVisibility(geology: Boolean? = null, flow: Boolean? = null, equipment: Boolean? = null) {
        context.dataStore.edit { prefs ->
            geology?.let { prefs[KEY_SHOW_GEOLOGY] = it }
            flow?.let { prefs[KEY_SHOW_FLOW] = it }
            equipment?.let { prefs[KEY_SHOW_EQUIPMENT] = it }
        }
    }

    suspend fun setCinematicOrbit(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CINEMATIC_ORBIT] = enabled
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_SOUND_ENABLED] = enabled
        }
    }

    suspend fun setDisplayDensity(density: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_DISPLAY_DENSITY] = density
        }
    }
}
