package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contracts")
data class ContractEntity(
    @PrimaryKey val id: String,
    val counterparty: String,
    val sector: String,
    val totalVolumeTonnes: Double,
    val fulfilledTonnes: Double,
    val pricePerTonneGbp: Double,
    val energySpecBtuPerLb: Double,
    val deliveryPeriod: String,
    val status: String
)

@Entity(tableName = "terminal_logs")
data class LogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: String,
    val source: String,
    val message: String,
    val severity: String
)

@Entity(tableName = "production_records")
data class ProductionRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String,
    val mineId: String,
    val mineName: String,
    val tonnesProduced: Double,
    val thermalEnergyMmbTu: Double,
    val calorificValueBtuPerLb: Double,
    val revenueGbp: Double
)
