package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ContractEntity::class, LogEntity::class, ProductionRecordEntity::class],
    version = 1,
    exportSchema = false
)
abstract class NcbDatabase : RoomDatabase() {
    abstract fun contractDao(): ContractDao
    abstract fun logDao(): LogDao
    abstract fun productionDao(): ProductionDao

    companion object {
        @Volatile
        private var INSTANCE: NcbDatabase? = null

        fun getDatabase(context: Context): NcbDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NcbDatabase::class.java,
                    "ncb_terminal_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
