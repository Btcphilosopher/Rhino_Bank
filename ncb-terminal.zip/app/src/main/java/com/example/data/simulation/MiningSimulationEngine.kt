package com.example.data.simulation

import com.example.model.CoalContract
import com.example.model.ContractStatus
import com.example.model.CustomerDemand
import com.example.model.DraglineExcavator
import com.example.model.EnergyStandard
import com.example.model.EquipmentStatus
import com.example.model.GeologicalLayer
import com.example.model.HaulTruck
import com.example.model.LogSeverity
import com.example.model.MarketPriceIndex
import com.example.model.MineSite
import com.example.model.MineStatus
import com.example.model.ProductionMetrics
import com.example.model.TerminalLogEvent
import com.example.renderer.MineSceneGeometry
import com.example.renderer.Vector3
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

data class SimulationState(
    val metrics: ProductionMetrics,
    val mines: List<MineSite>,
    val haulTrucks: List<HaulTruck>,
    val dragline: DraglineExcavator,
    val marketPrices: List<MarketPriceIndex>,
    val contracts: List<CoalContract>,
    val topCustomers: List<CustomerDemand>,
    val recentLogs: List<TerminalLogEvent>,
    val geologicalLayers: List<GeologicalLayer>,
    val sheaveRotationAngle: Float = 0f,
    val scanWaveProgress: Float = 0f,
    val conveyorParticleOffsets: List<Float> = emptyList(),
    val isPaused: Boolean = false,
    val simulationSpeed: Float = 1.0f
)

class MiningSimulationEngine(
    private val scope: CoroutineScope
) {
    private var simulationJob: Job? = null
    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.UK)

    // Initial domain state matching reference image
    private var currentProductionTonnes = 1248600.0
    private var currentDeliveriesTonnes = 1176200.0
    private var currentStockTonnes = 362800.0
    private var currentAvgPriceGbp = 142.60

    private val waypoints = MineSceneGeometry.getHaulRoadWaypoints()

    private val haulTrucks = mutableListOf(
        HaulTruck("HT-101", "Cat 789D (195t)", 195.0, 184.0, 3, EquipmentStatus.HAULING, 32f, "Bench 3 Face -> Crusher Dump", 2400.0, pathProgress = 0.05f),
        HaulTruck("HT-102", "Cat 789D (195t)", 195.0, 192.0, 2, EquipmentStatus.HAULING, 28f, "Bench 2 Ramp -> Stockpile Loop", 2450.0, pathProgress = 0.32f),
        HaulTruck("HT-103", "Komatsu 930E (290t)", 290.0, 275.0, 4, EquipmentStatus.HAULING, 24f, "Pit Sump -> Incline Transfer", 3200.0, pathProgress = 0.65f),
        HaulTruck("HT-104", "Komatsu 930E (290t)", 290.0, 0.0, 1, EquipmentStatus.HAULING, 38f, "Returning Empty -> Bench 4", 1600.0, pathProgress = 0.88f)
    )

    private val dragline = DraglineExcavator(
        id = "EXC-1150-BIG-GEORDIE",
        name = "Bucyrus-Erie 1150-B Walking Dragline",
        benchIndex = 3,
        bucketCapacityTonnes = 65.0,
        slewAngleDegrees = 0f,
        boomElevationDegrees = 38f,
        bucketCycleProgress = 0f,
        status = EquipmentStatus.EXCAVATING,
        powerDrawKbtuPerHr = 18400.0,
        operatingHours = 24190,
        worldX = 25f,
        worldY = -30f,
        worldZ = -38f * 0.45f
    )

    private val mineSites = listOf(
        MineSite("MINE-KEL", "Kellingley", "North Yorkshire", "53.7°N 1.2°W", 780, MineStatus.ONLINE, 18500.0, 19240.0, 11600.0, "Silkstone Seam", 4, 18),
        MineSite("MINE-CAP", "Caphouse", "West Yorkshire", "53.6°N 1.6°W", 140, MineStatus.ONLINE, 6200.0, 6150.0, 11100.0, "Flockton Thick", 2, 8),
        MineSite("MINE-BLY", "Blyth", "Northumberland", "55.1°N 1.5°W", 120, MineStatus.ONLINE, 14200.0, 14890.0, 10400.0, "Plessey Seam", 3, 14),
        MineSite("MINE-FFO", "Ffos-y-fran", "South Wales", "51.7°N 3.3°W", 182, MineStatus.ONLINE, 16800.0, 17210.0, 13200.0, "Upper Four Feet", 5, 22),
        MineSite("MINE-WHI", "Whitehaven", "Cumbria", "54.5°N 3.6°W", 450, MineStatus.ONLINE, 12500.0, 12100.0, 12800.0, "Main Band Coking", 3, 12),
        MineSite("MINE-EAS", "East Kilbride", "Lanarkshire", "55.7°N 4.1°W", 210, MineStatus.ONLINE, 8900.0, 9150.0, 10800.0, "Ell Coal Seam", 2, 9),
        MineSite("MINE-HAT", "Hatfield", "South Yorkshire", "53.5°N 1.0°W", 820, MineStatus.ONLINE, 15400.0, 15800.0, 11400.0, "High Hazel Seam", 4, 16)
    )

    private val marketPrices = listOf(
        MarketPriceIndex(
            id = "MP-API2",
            name = "API2 (UK Immingham Basis)",
            location = "ARA / UK North Sea",
            priceGbpPerTonne = 119.40,
            changePercentWoW = 2.3,
            calorificBasisBtuPerLb = 10800.0,
            sparkSpreadGbp = 42.10,
            historyPrices = listOf(95.0, 102.0, 108.0, 114.0, 112.0, 115.0, 118.0, 119.40)
        ),
        MarketPriceIndex(
            id = "MP-NEWC",
            name = "NEWC (UK Term Basis)",
            location = "Newcastle UK Spec",
            priceGbpPerTonne = 118.70,
            changePercentWoW = 2.1,
            calorificBasisBtuPerLb = 11200.0,
            sparkSpreadGbp = 40.80,
            historyPrices = listOf(98.0, 104.0, 106.0, 110.0, 115.0, 116.5, 118.0, 118.70)
        ),
        MarketPriceIndex(
            id = "MP-RB",
            name = "Richards Bay (Import Equiv)",
            location = "South Africa -> UK Port",
            priceGbpPerTonne = 104.20,
            changePercentWoW = 1.8,
            calorificBasisBtuPerLb = 10600.0,
            sparkSpreadGbp = 36.50,
            historyPrices = listOf(89.0, 93.0, 96.0, 99.0, 101.0, 102.5, 103.8, 104.20)
        ),
        MarketPriceIndex(
            id = "MP-FOB-NEWC",
            name = "FOB Tyne & Blyth Term",
            location = "Port of Tyne Coal Dock",
            priceGbpPerTonne = 116.80,
            changePercentWoW = 2.0,
            calorificBasisBtuPerLb = 11000.0,
            sparkSpreadGbp = 39.20,
            historyPrices = listOf(96.0, 100.0, 103.0, 108.0, 111.0, 114.0, 115.5, 116.80)
        )
    )

    private val contracts = listOf(
        CoalContract("CON-DRAX-01", "Drax Power (UK)", "Power Generation", 3200000.0, 2150000.0, 141.50, 11200.0, "2025-28", ContractStatus.ACTIVE),
        CoalContract("CON-TATA-02", "Tata Steel (Port Talbot)", "Metallurgical Coking", 1750000.0, 980000.0, 168.00, 12600.0, "2025-27", ContractStatus.ACTIVE),
        CoalContract("CON-UNIPER-03", "Uniper Energy (Ratcliffe)", "Power Generation", 980000.0, 620000.0, 138.20, 11000.0, "2025-26", ContractStatus.ACTIVE),
        CoalContract("CON-INDIA-04", "Steel Authority Term (Spot)", "Industrial Export", 640000.0, 310000.0, 155.00, 12200.0, "2025-26", ContractStatus.ACTIVE)
    )

    private val topCustomers = listOf(
        CustomerDemand("Drax Power", 28, "Power (UK Grid)", 3200000.0, "Kellingley / Blyth"),
        CustomerDemand("Uniper", 17, "Power (Ratcliffe)", 1950000.0, "Hatfield"),
        CustomerDemand("Tata Steel", 12, "Coking (Port Talbot)", 1400000.0, "Ffos-y-fran / Whitehaven"),
        CustomerDemand("China Energy", 9, "Industrial Grade", 1020000.0, "Port of Tyne"),
        CustomerDemand("Others", 34, "Domestic & Industrial", 3890000.0, "Combined Sites")
    )

    private val geologicalLayers = listOf(
        GeologicalLayer("Top Hard Brights", "0m to -40m", 2.8, 11200.0, 48.2, 8.4),
        GeologicalLayer("Barnsley High-Btu Seam", "-40m to -115m", 4.2, 11800.0, 112.5, 6.1),
        GeologicalLayer("Silkstone Deep Coking", "-115m to -182m", 3.1, 12400.0, 84.6, 4.8)
    )

    private val initialLogs = listOf(
        TerminalLogEvent(1, "10:39", "Kellingley", "Output up 4.1% - Bench 3 face operating at peak recovery", LogSeverity.INFO),
        TerminalLogEvent(2, "10:37", "Drax Power", "New contract tranche confirmed: 3,200,000 t delivery schedule active", LogSeverity.SUCCESS),
        TerminalLogEvent(3, "10:32", "Newcastle", "Price +2.0% (WoW) - Immingham thermal baseline £118.70/t", LogSeverity.INFO),
        TerminalLogEvent(4, "10:28", "Rail Freight", "12 Freightliner Class 66 trains dispatched to Drax and Ratcliffe", LogSeverity.SUCCESS),
        TerminalLogEvent(5, "10:21", "Stockpiles", "Total strategic reserves 362,800 MT verified across all terminals", LogSeverity.INFO),
        TerminalLogEvent(6, "10:18", "Safety", "Zero lost-time incidents reported across all 7 operational colliery sites", LogSeverity.SUCCESS),
        TerminalLogEvent(7, "10:12", "Market", "API2 +2.3% - Strong UK baseload power demand driving forward contracts", LogSeverity.INFO),
        TerminalLogEvent(8, "10:06", "System", "NCB Mainframe Terminal v3.8 - All colliery telemetry nodes online", LogSeverity.SUCCESS)
    )

    private val logs = mutableListOf<TerminalLogEvent>().apply { addAll(initialLogs) }

    private val _state = MutableStateFlow(
        SimulationState(
            metrics = computeMetrics(),
            mines = mineSites,
            haulTrucks = haulTrucks,
            dragline = dragline,
            marketPrices = marketPrices,
            contracts = contracts,
            topCustomers = topCustomers,
            recentLogs = logs.take(20),
            geologicalLayers = geologicalLayers,
            conveyorParticleOffsets = listOf(0.1f, 0.25f, 0.45f, 0.65f, 0.85f)
        )
    )
    val state: StateFlow<SimulationState> = _state.asStateFlow()

    init {
        startSimulationLoop()
    }

    private fun computeMetrics(): ProductionMetrics {
        val totalThermalMmbTu = EnergyStandard.calculateMmbTu(currentProductionTonnes, EnergyStandard.DEFAULT_CALORIFIC_VALUE_BTU_PER_LB)
        val btuPerTonne = EnergyStandard.LBS_PER_METRIC_TONNE * EnergyStandard.DEFAULT_CALORIFIC_VALUE_BTU_PER_LB

        return ProductionMetrics(
            productionTonnes = currentProductionTonnes,
            productionWoWPercent = 3.2,
            deliveriesTonnes = currentDeliveriesTonnes,
            deliveriesWoWPercent = 2.8,
            stockTonnes = currentStockTonnes,
            stockWoWPercent = 1.4,
            averagePriceGbp = currentAvgPriceGbp,
            averagePriceWoWPercent = 4.7,
            thermalEnergyMmbTu = totalThermalMmbTu,
            energyContentBtuPerTonne = btuPerTonne,
            equipmentUtilisationPercent = 94.2,
            operationalAvailabilityPercent = 98.7
        )
    }

    fun startSimulationLoop() {
        if (simulationJob?.isActive == true) return

        simulationJob = scope.launch(Dispatchers.Default) {
            var lastTickTime = System.currentTimeMillis()
            var eventTimer = 0f
            var sheaveAngle = 0f
            var scanWave = 0f

            while (isActive) {
                val now = System.currentTimeMillis()
                val deltaSeconds = ((now - lastTickTime) / 1000f).coerceIn(0.01f, 0.1f)
                lastTickTime = now

                val speed = _state.value.simulationSpeed
                val isPaused = _state.value.isPaused

                if (!isPaused) {
                    val effectiveDelta = deltaSeconds * speed

                    // 1. Advance Sheave Wheel Rotation
                    sheaveAngle = (sheaveAngle + (effectiveDelta * 180f)) % 360f

                    // 2. Advance Geological Radar Scan Wave
                    scanWave = (scanWave + (effectiveDelta * 0.15f)) % 1.0f

                    // 3. Animate Dragline Excavator Cycle
                    dragline.bucketCycleProgress = (dragline.bucketCycleProgress + (effectiveDelta * 0.08f)) % 1.0f
                    // Slew back and forth between 0° and 65°
                    dragline.slewAngleDegrees = (sin(dragline.bucketCycleProgress * 2 * PI).toFloat() * 32.5f) + 32.5f
                    // Boom subtle dip
                    dragline.boomElevationDegrees = 38f + (sin(dragline.bucketCycleProgress * 4 * PI).toFloat() * 2.5f)

                    // 4. Animate Haul Trucks along waypoints
                    haulTrucks.forEachIndexed { index, truck ->
                        truck.pathProgress = (truck.pathProgress + (effectiveDelta * (0.015f + index * 0.003f))) % 1.0f
                        updateTruckPosition(truck, waypoints)
                    }

                    // 5. Advance Conveyor Coal Particles
                    val updatedParticles = _state.value.conveyorParticleOffsets.map { offset ->
                        (offset + (effectiveDelta * 0.18f)) % 1.0f
                    }

                    // 6. Production increment
                    val tonDelta = (12.5 * effectiveDelta * speed)
                    currentProductionTonnes += tonDelta
                    currentDeliveriesTonnes += (tonDelta * 0.94)
                    currentStockTonnes = (currentStockTonnes + (tonDelta * 0.06)).coerceAtLeast(350000.0)

                    // 7. Periodic operational events (every 18-25 seconds)
                    eventTimer += effectiveDelta
                    if (eventTimer >= 22f) {
                        eventTimer = 0f
                        triggerRandomOperationalEvent()
                    }

                    _state.value = _state.value.copy(
                        metrics = computeMetrics(),
                        sheaveRotationAngle = sheaveAngle,
                        scanWaveProgress = scanWave,
                        conveyorParticleOffsets = updatedParticles,
                        haulTrucks = haulTrucks.map { it.copy() },
                        dragline = dragline.copy(),
                        recentLogs = logs.take(20)
                    )
                }

                // 30-50ms tick rate for smooth 60fps Compose animation
                delay(33)
            }
        }
    }

    private fun updateTruckPosition(truck: HaulTruck, path: List<Vector3>) {
        if (path.size < 2) return
        val totalSegments = path.size - 1
        val scaledProgress = (truck.pathProgress * totalSegments).coerceIn(0f, totalSegments.toFloat())
        val segIndex = scaledProgress.toInt().coerceIn(0, totalSegments - 1)
        val segT = scaledProgress - segIndex

        val p1 = path[segIndex]
        val p2 = path[segIndex + 1]

        truck.worldX = p1.x + (p2.x - p1.x) * segT
        truck.worldY = p1.y + (p2.y - p1.y) * segT
        truck.worldZ = p1.z + (p2.z - p1.z) * segT
    }

    private fun triggerRandomOperationalEvent() {
        val nowStr = timeFormatter.format(Date())
        val eventCandidates = listOf(
            Triple("Rail Freight", "Train FL-66108 loaded with 2,450 t high-Btu coal dispatched to Ratcliffe", LogSeverity.SUCCESS),
            Triple("Ffos-y-fran", "Bench 4 Anthracite recovery rate exceeded target: 13,200 BTU/lb certified", LogSeverity.INFO),
            Triple("Conveyor", "Main Overland Trunk belt speed calibrated to 4.2 m/s; throughput 3,920 t/h", LogSeverity.INFO),
            Triple("Markets", "UK Baseload Clean Dark Spread widens to £38.40/MWh; coal dispatch priority active", LogSeverity.SUCCESS),
            Triple("Blyth", "Bulk rail shipment departed for Port of Tyne coal terminal - 1,800 t loaded", LogSeverity.INFO),
            Triple("Energy Audit", "Thermal generation equivalent: 30.8 M MMBtu produced year-to-date", LogSeverity.INFO)
        )
        val randomEvent = eventCandidates.random()
        val newLog = TerminalLogEvent(
            id = System.currentTimeMillis(),
            timestamp = nowStr.substring(0, 5),
            source = randomEvent.first,
            message = randomEvent.second,
            severity = randomEvent.third
        )
        logs.add(0, newLog)
    }

    fun addLog(source: String, message: String, severity: LogSeverity = LogSeverity.INFO) {
        val nowStr = timeFormatter.format(Date())
        val newLog = TerminalLogEvent(
            id = System.currentTimeMillis(),
            timestamp = nowStr.substring(0, 5),
            source = source,
            message = message,
            severity = severity
        )
        logs.add(0, newLog)
        _state.value = _state.value.copy(recentLogs = logs.take(20))
    }

    fun setSimulationSpeed(speed: Float) {
        _state.value = _state.value.copy(simulationSpeed = speed.coerceIn(0.2f, 5.0f))
    }

    fun togglePause() {
        _state.value = _state.value.copy(isPaused = !_state.value.isPaused)
    }

    fun resetData() {
        currentProductionTonnes = 1248600.0
        currentDeliveriesTonnes = 1176200.0
        currentStockTonnes = 362800.0
        currentAvgPriceGbp = 142.60
        logs.clear()
        logs.addAll(initialLogs)
        _state.value = _state.value.copy(
            metrics = computeMetrics(),
            recentLogs = logs.take(20)
        )
    }
}
