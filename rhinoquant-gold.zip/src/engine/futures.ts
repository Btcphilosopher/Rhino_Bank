/**
 * RHINOQUANT GOLD - Futures & Curve Engine
 * CME Gold Futures (100oz GC, 10oz MGC, 1oz 1OZ), Term Structure Curve, Calendar Spreads, Spot-Futures Basis.
 */

import { globalMarketEngine } from './market';

export interface FuturesContract {
  symbol: string;             // e.g. GC1 (Front), GC2, GC3, GC6, GC12, MGC1, 1OZ1
  name: string;               // e.g. "COMEX Gold Apr 2026"
  expiryCode: string;         // e.g. "GCJ26"
  contractSizeOz: number;     // 100 for GC, 10 for MGC, 1 for 1OZ
  expiryDate: string;         // YYYY-MM-DD
  daysToExpiry: number;
  price: number;
  change24h: number;
  change24hPct: number;
  volume: number;
  openInterest: number;
  spotPrice: number;
  basisUsd: number;           // Futures - Spot
  annualisedBasisPct: number; // (Basis / Spot) * (365 / Days) * 100
  impliedFinancingRatePct: number;
  convenienceYieldPct: number;
}

export interface CalendarSpread {
  spreadPair: string;         // e.g. "GC1 - GC2"
  nearSymbol: string;
  farSymbol: string;
  nearPrice: number;
  farPrice: number;
  spreadPriceUsd: number;
  zScore: number;
  percentile: number;
  volatilityPct: number;
  meanReversionSignal: 'STRONG_BUY' | 'NEUTRAL' | 'STRONG_SELL';
}

export interface FuturesCurveAnalysis {
  timestamp: string;
  spotPriceUsd: number;
  marketStructure: 'CONTANGO' | 'BACKWARDATION' | 'FLAT';
  frontMonthBasis: number;
  annualisedFrontBasisPct: number;
  rollYieldAnnualisedPct: number;
  contracts: FuturesContract[];
  calendarSpreads: CalendarSpread[];
}

export class FuturesCurveEngine {
  public getCurveAnalysis(): FuturesCurveAnalysis {
    const spot = globalMarketEngine.getSpotUsd();
    const timestamp = new Date().toISOString();

    // Standard interest rate risk-free benchmark ~ 5.15%, storage/insurance ~ 0.25%
    const annualCarryRate = 0.0540;

    const createContract = (
      symbol: string,
      name: string,
      expiryCode: string,
      contractSizeOz: number,
      monthsOut: number
    ): FuturesContract => {
      const daysToExpiry = monthsOut * 30 + 15;
      const tYears = daysToExpiry / 365;

      // Futures price = Spot * (1 + carryRate * tYears) + small random noise
      const carryCost = spot * annualCarryRate * tYears;
      const noise = Math.sin(monthsOut * 0.8) * 0.35;
      const futuresPrice = Number((spot + carryCost + noise).toFixed(2));
      const basisUsd = Number((futuresPrice - spot).toFixed(2));
      const annualisedBasisPct = Number(((basisUsd / spot) * (365 / daysToExpiry) * 100).toFixed(2));
      const impliedFinancingRatePct = Number((annualisedBasisPct - 0.25).toFixed(2)); // deducting storage
      const convenienceYieldPct = Number((0.15 + Math.random() * 0.1).toFixed(2));

      return {
        symbol,
        name,
        expiryCode,
        contractSizeOz,
        expiryDate: new Date(Date.now() + daysToExpiry * 86400000).toISOString().substring(0, 10),
        daysToExpiry,
        price: futuresPrice,
        change24h: Number((basisUsd + 12.4).toFixed(2)),
        change24hPct: +1.28,
        volume: Math.floor(180000 / Math.pow(monthsOut, 0.7)),
        openInterest: Math.floor(450000 / Math.pow(monthsOut, 0.6)),
        spotPrice: spot,
        basisUsd,
        annualisedBasisPct,
        impliedFinancingRatePct,
        convenienceYieldPct,
      };
    };

    const contracts: FuturesContract[] = [
      createContract('GC1', 'COMEX Gold 100oz (Front)', 'GCJ26', 100, 1),
      createContract('GC2', 'COMEX Gold 100oz (Next)', 'GCM26', 100, 2),
      createContract('GC3', 'COMEX Gold 100oz (+3M)', 'GCQ26', 100, 3),
      createContract('GC6', 'COMEX Gold 100oz (+6M)', 'GCV26', 100, 6),
      createContract('GC12', 'COMEX Gold 100oz (+12M)', 'GCJ27', 100, 12),
      createContract('MGC1', 'COMEX Micro Gold 10oz', 'MGCJ26', 10, 1),
      createContract('1OZ1', 'CME 1-Ounce Gold Futures', '1OZJ26', 1, 1),
    ];

    // Calendar spreads
    const gc1 = contracts[0];
    const gc2 = contracts[1];
    const gc3 = contracts[2];
    const gc6 = contracts[3];

    const spreads: CalendarSpread[] = [
      {
        spreadPair: 'GC1 - GC2',
        nearSymbol: gc1.symbol,
        farSymbol: gc2.symbol,
        nearPrice: gc1.price,
        farPrice: gc2.price,
        spreadPriceUsd: Number((gc2.price - gc1.price).toFixed(2)),
        zScore: +1.15,
        percentile: 78.4,
        volatilityPct: 8.2,
        meanReversionSignal: 'NEUTRAL',
      },
      {
        spreadPair: 'GC2 - GC3',
        nearSymbol: gc2.symbol,
        farSymbol: gc3.symbol,
        nearPrice: gc2.price,
        farPrice: gc3.price,
        spreadPriceUsd: Number((gc3.price - gc2.price).toFixed(2)),
        zScore: +0.42,
        percentile: 62.1,
        volatilityPct: 7.8,
        meanReversionSignal: 'NEUTRAL',
      },
      {
        spreadPair: 'GC1 - GC6',
        nearSymbol: gc1.symbol,
        farSymbol: gc6.symbol,
        nearPrice: gc1.price,
        farPrice: gc6.price,
        spreadPriceUsd: Number((gc6.price - gc1.price).toFixed(2)),
        zScore: +2.10,
        percentile: 94.5,
        volatilityPct: 12.4,
        meanReversionSignal: 'STRONG_SELL', // Spread too wide, sell spread
      },
    ];

    // Contango vs Backwardation check
    const isContango = gc6.price > gc1.price;

    return {
      timestamp,
      spotPriceUsd: spot,
      marketStructure: isContango ? 'CONTANGO' : 'BACKWARDATION',
      frontMonthBasis: gc1.basisUsd,
      annualisedFrontBasisPct: gc1.annualisedBasisPct,
      rollYieldAnnualisedPct: Number((-gc1.annualisedBasisPct).toFixed(2)), // negative in contango
      contracts,
      calendarSpreads: spreads,
    };
  }
}

export const globalFuturesEngine = new FuturesCurveEngine();
