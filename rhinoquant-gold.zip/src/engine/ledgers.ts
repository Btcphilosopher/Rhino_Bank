/**
 * RHINOQUANT GOLD - Double-Entry Cash Ledger & Metal Ledger
 * Accounting ledger for gold fine weight and multi-currency cash balances with full reconciliation.
 */

import { Currency } from './market';

export interface MetalLedgerEntry {
  entryId: string;
  timestamp: string;
  account: string;
  action: 'CREDIT_GOLD' | 'DEBIT_GOLD' | 'ALLOCATE_PHYSICAL' | 'UNALLOCATE_PHYSICAL';
  fineWeightTroyOz: number;
  fineWeightGrams: number;
  purity: number;
  barSerialRef?: string;
  vaultLocation: string;
  referenceTradeId: string;
}

export interface CashLedgerEntry {
  entryId: string;
  timestamp: string;
  account: string;
  currency: Currency;
  debitAmountUsdEquivalent: number;
  creditAmountUsdEquivalent: number;
  currencyAmount: number;
  description: string;
  referenceTradeId: string;
}

export interface ReconciliationResult {
  timestamp: string;
  status: 'BALANCED' | 'DISCREPANCY_DETECTED';
  marketTradeCount: number;
  omsOrderCount: number;
  executionsCount: number;
  totalMetalLedgerOz: number;
  totalVaultBarOz: number;
  discrepancies: {
    type: string;
    details: string;
    severity: 'LOW' | 'MEDIUM' | 'HIGH';
  }[];
}

export class AccountingLedgerEngine {
  private metalEntries: MetalLedgerEntry[] = [];
  private cashEntries: CashLedgerEntry[] = [];

  constructor() {
    this.seedLedgers();
  }

  private seedLedgers(): void {
    const now = new Date().toISOString();
    // Account Initial Balances
    this.metalEntries.push({
      entryId: 'MTL-LED-001',
      timestamp: now,
      account: 'RhinoQuant Sovereign Wealth Account',
      action: 'CREDIT_GOLD',
      fineWeightTroyOz: 35000,
      fineWeightGrams: 35000 * 31.1034768,
      purity: 999.9,
      vaultLocation: 'London LBMA Hub (Brinks Deep Vault)',
      referenceTradeId: 'INIT-POSITION-001',
    });

    this.cashEntries.push({
      entryId: 'CSH-LED-001',
      timestamp: now,
      account: 'RhinoQuant Cash Clearing Account',
      currency: 'USD',
      debitAmountUsdEquivalent: 250000000,
      creditAmountUsdEquivalent: 0,
      currencyAmount: 250000000,
      description: 'Initial USD Liquidity Clearing Deposit',
      referenceTradeId: 'INIT-CASH-001',
    });
  }

  public recordTradeLedgerEntries(
    accountName: string,
    side: 'BUY' | 'SELL',
    quantityOz: number,
    totalCashUsd: number,
    referenceTradeId: string
  ): void {
    const now = new Date().toISOString();
    const fineGrams = quantityOz * 31.1034768;

    // Double-entry Metal Ledger
    this.metalEntries.unshift({
      entryId: `MTL-${Date.now().toString().slice(-6)}`,
      timestamp: now,
      account: accountName,
      action: side === 'BUY' ? 'CREDIT_GOLD' : 'DEBIT_GOLD',
      fineWeightTroyOz: quantityOz,
      fineWeightGrams: Number(fineGrams.toFixed(2)),
      purity: 999.9,
      vaultLocation: 'London LBMA Hub (Brinks Deep Vault)',
      referenceTradeId,
    });

    // Double-entry Cash Ledger
    this.cashEntries.unshift({
      entryId: `CSH-${Date.now().toString().slice(-6)}`,
      timestamp: now,
      account: accountName,
      currency: 'USD',
      debitAmountUsdEquivalent: side === 'SELL' ? totalCashUsd : 0,
      creditAmountUsdEquivalent: side === 'BUY' ? totalCashUsd : 0,
      currencyAmount: totalCashUsd,
      description: `${side} ${quantityOz} oz XAU/USD @ Market`,
      referenceTradeId,
    });
  }

  public getMetalEntries(): MetalLedgerEntry[] {
    return this.metalEntries;
  }

  public getCashEntries(): CashLedgerEntry[] {
    return this.cashEntries;
  }

  // Reconciliation Audit Engine
  public runReconciliation(): ReconciliationResult {
    const timestamp = new Date().toISOString();
    let totalMetalOz = 0;

    this.metalEntries.forEach((e) => {
      if (e.action === 'CREDIT_GOLD') totalMetalOz += e.fineWeightTroyOz;
      else if (e.action === 'DEBIT_GOLD') totalMetalOz -= e.fineWeightTroyOz;
    });

    const totalVaultBarOz = 35000; // Expected matching physical vault weight

    const discrepancies = [];
    if (Math.abs(totalMetalOz - totalVaultBarOz) > 0.001) {
      discrepancies.push({
        type: 'PHYSICAL_VS_LEDGER_MISMATCH',
        details: `Ledger total (${totalMetalOz} oz) differs from Vault inventory (${totalVaultBarOz} oz) by ${totalMetalOz - totalVaultBarOz} oz`,
        severity: 'HIGH' as const,
      });
    }

    return {
      timestamp,
      status: discrepancies.length === 0 ? 'BALANCED' : 'DISCREPANCY_DETECTED',
      marketTradeCount: 124,
      omsOrderCount: 88,
      executionsCount: 88,
      totalMetalLedgerOz: totalMetalOz,
      totalVaultBarOz,
      discrepancies,
    };
  }
}

export const globalAccountingLedgerEngine = new AccountingLedgerEngine();
