/**
 * RHINOQUANT GOLD - Options & Volatility Surface Engine
 * Black-Scholes pricing, Greeks (Delta, Gamma, Theta, Vega, Rho), IV Surface (Smile/Skew), Options Strategy Lab.
 */

import { globalMarketEngine } from './market';

export type OptionType = 'CALL' | 'PUT';

export interface OptionGreeks {
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
}

export interface OptionContract {
  optionId: string;
  underlying: string;        // 'XAU/USD'
  type: OptionType;
  strikeUsd: number;
  expiryDays: number;
  expiryDate: string;
  impliedVolPct: number;
  premiumUsd: number;
  greeks: OptionGreeks;
  intrinsicValue: number;
  timeValue: number;
}

export interface VolatilitySurfacePoint {
  expiryDays: number;
  strikeUsd: number;
  strikePctSpot: number;     // e.g. 90%, 95%, 100% ATM, 105%, 110%
  impliedVolPct: number;
  delta: number;
}

export interface OptionsStrategyLeg {
  type: OptionType;
  strikeUsd: number;
  expiryDays: number;
  side: 'BUY' | 'SELL';
  contractsCount: number;
  premiumPerOz: number;
}

export interface OptionsStrategyResult {
  strategyName: string;
  legs: OptionsStrategyLeg[];
  totalNetPremiumUsd: number;
  netDelta: number;
  netGamma: number;
  netTheta: number;
  netVega: number;
  maxProfitUsd: number | 'UNLIMITED';
  maxLossUsd: number | 'UNLIMITED';
  breakevenUsd: number[];
  payoffCurve: { spotPrice: number; pnlUsd: number }[];
}

// Standard Normal Cumulative Distribution Function N(x)
function normalCdf(x: number): number {
  const a1 = 0.319381530;
  const a2 = -0.356563782;
  const a3 = 1.781477937;
  const a4 = -1.821255978;
  const a5 = 1.330274429;
  const L = Math.abs(x);
  const K = 1.0 / (1.0 + 0.2316419 * L);
  let w = 1.0 - 1.0 / Math.sqrt(2 * Math.PI) * Math.exp(-L * L / 2) *
    (a1 * K + a2 * K * K + a3 * Math.pow(K, 3) + a4 * Math.pow(K, 4) + a5 * Math.pow(K, 5));
  if (x < 0) w = 1.0 - w;
  return w;
}

// Standard Normal Probability Density Function N'(x)
function normalPdf(x: number): number {
  return (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);
}

export class OptionsEngine {
  // Black-Scholes Pricer
  public calculateBlackScholes(
    type: OptionType,
    S: number,        // Spot price
    K: number,        // Strike price
    T: number,        // Time to expiry in years
    r: number,        // Risk-free rate (e.g. 0.0515)
    sigma: number     // Volatility (e.g. 0.165 for 16.5%)
  ): { price: number; greeks: OptionGreeks; intrinsic: number; timeVal: number } {
    if (T <= 0) {
      const intrinsic = type === 'CALL' ? Math.max(0, S - K) : Math.max(0, K - S);
      return {
        price: intrinsic,
        greeks: { delta: type === 'CALL' ? (S > K ? 1 : 0) : (S < K ? -1 : 0), gamma: 0, theta: 0, vega: 0, rho: 0 },
        intrinsic,
        timeVal: 0,
      };
    }

    const d1 = (Math.log(S / K) + (r + (sigma * sigma) / 2) * T) / (sigma * Math.sqrt(T));
    const d2 = d1 - sigma * Math.sqrt(T);

    let price = 0;
    let delta = 0;
    let rho = 0;

    if (type === 'CALL') {
      price = S * normalCdf(d1) - K * Math.exp(-r * T) * normalCdf(d2);
      delta = normalCdf(d1);
      rho = (K * T * Math.exp(-r * T) * normalCdf(d2)) / 100;
    } else {
      price = K * Math.exp(-r * T) * normalCdf(-d2) - S * normalCdf(-d1);
      delta = -normalCdf(-d1);
      rho = (-K * T * Math.exp(-r * T) * normalCdf(-d2)) / 100;
    }

    const gamma = normalPdf(d1) / (S * sigma * Math.sqrt(T));
    const vega = (S * Math.sqrt(T) * normalPdf(d1)) / 100; // per 1% vol
    const thetaCall = -(S * sigma * normalPdf(d1)) / (2 * Math.sqrt(T)) - r * K * Math.exp(-r * T) * normalCdf(d2);
    const thetaPut = -(S * sigma * normalPdf(d1)) / (2 * Math.sqrt(T)) + r * K * Math.exp(-r * T) * normalCdf(-d2);
    const theta = (type === 'CALL' ? thetaCall : thetaPut) / 365; // per day

    const intrinsic = type === 'CALL' ? Math.max(0, S - K) : Math.max(0, K - S);
    const timeVal = Math.max(0, price - intrinsic);

    return {
      price: Number(price.toFixed(2)),
      greeks: {
        delta: Number(delta.toFixed(4)),
        gamma: Number(gamma.toFixed(6)),
        theta: Number(theta.toFixed(2)),
        vega: Number(vega.toFixed(2)),
        rho: Number(rho.toFixed(4)),
      },
      intrinsic: Number(intrinsic.toFixed(2)),
      timeVal: Number(timeVal.toFixed(2)),
    };
  }

  // Generate Volatility Surface (Smile / Skew / Term Structure)
  public getVolatilitySurface(): VolatilitySurfacePoint[] {
    const spot = globalMarketEngine.getSpotUsd();
    const expiriesDays = [30, 60, 90, 180, 360];
    const strikeMoneyness = [0.85, 0.90, 0.95, 1.00, 1.05, 1.10, 1.15]; // 85% OTM put to 115% OTM call

    const surface: VolatilitySurfacePoint[] = [];

    expiriesDays.forEach((days) => {
      const t = days / 365;
      const baseAtmVol = 0.155 + (360 - days) * 0.00005; // slight term structure tilt

      strikeMoneyness.forEach((m) => {
        const strike = Math.round(spot * m);

        // Volatility Smile/Skew formula: skew towards OTM puts (gold downside fear)
        const moneynessLog = Math.log(m);
        const skewCoefficient = -0.18; // negative skew
        const smileCoefficient = 0.45;  // smile curvature
        const iv = baseAtmVol + skewCoefficient * moneynessLog + smileCoefficient * Math.pow(moneynessLog, 2);

        const bs = this.calculateBlackScholes('CALL', spot, strike, t, 0.0515, iv);

        surface.push({
          expiryDays: days,
          strikeUsd: strike,
          strikePctSpot: Math.round(m * 100),
          impliedVolPct: Number((iv * 100).toFixed(2)),
          delta: bs.greeks.delta,
        });
      });
    });

    return surface;
  }

  // Build Option Strategy Payoff (Collar, Straddle, Protective Put, Call Spread, etc.)
  public buildStrategy(
    strategyName: string,
    legs: OptionsStrategyLeg[],
    quantityOz = 100
  ): OptionsStrategyResult {
    const spot = globalMarketEngine.getSpotUsd();
    const r = 0.0515;

    let netPremium = 0;
    let netDelta = 0;
    let netGamma = 0;
    let netTheta = 0;
    let netVega = 0;

    const evaluatedLegs = legs.map((leg) => {
      const t = leg.expiryDays / 365;
      const iv = 0.165; // standard IV
      const bs = this.calculateBlackScholes(leg.type, spot, leg.strikeUsd, t, r, iv);

      const sign = leg.side === 'BUY' ? 1 : -1;
      const legNetPrem = sign * bs.price * leg.contractsCount * quantityOz;

      netPremium += legNetPrem;
      netDelta += sign * bs.greeks.delta * leg.contractsCount * quantityOz;
      netGamma += sign * bs.greeks.gamma * leg.contractsCount * quantityOz;
      netTheta += sign * bs.greeks.theta * leg.contractsCount * quantityOz;
      netVega += sign * bs.greeks.vega * leg.contractsCount * quantityOz;

      return {
        ...leg,
        premiumPerOz: bs.price,
      };
    });

    // Generate Payoff Curve across spot range
    const minSpot = Math.round(spot * 0.75);
    const maxSpot = Math.round(spot * 1.25);
    const step = Math.round((maxSpot - minSpot) / 50);

    const payoffCurve: { spotPrice: number; pnlUsd: number }[] = [];

    for (let s = minSpot; s <= maxSpot; s += step) {
      let expiryVal = 0;
      evaluatedLegs.forEach((leg) => {
        const sign = leg.side === 'BUY' ? 1 : -1;
        const intrinsicAtExpiry = leg.type === 'CALL' ? Math.max(0, s - leg.strikeUsd) : Math.max(0, leg.strikeUsd - s);
        expiryVal += sign * (intrinsicAtExpiry - leg.premiumPerOz) * leg.contractsCount * quantityOz;
      });

      payoffCurve.push({
        spotPrice: s,
        pnlUsd: Number(expiryVal.toFixed(2)),
      });
    }

    return {
      strategyName,
      legs: evaluatedLegs,
      totalNetPremiumUsd: Number(netPremium.toFixed(2)),
      netDelta: Number(netDelta.toFixed(2)),
      netGamma: Number(netGamma.toFixed(4)),
      netTheta: Number(netTheta.toFixed(2)),
      netVega: Number(netVega.toFixed(2)),
      maxProfitUsd: strategyName.includes('Collar') ? Number((payoffCurve[payoffCurve.length - 1].pnlUsd).toFixed(2)) : 'UNLIMITED',
      maxLossUsd: strategyName.includes('Straddle') ? Number(Math.abs(netPremium).toFixed(2)) : 'UNLIMITED',
      breakevenUsd: [Math.round(spot * 0.94), Math.round(spot * 1.06)],
      payoffCurve,
    };
  }
}

export const globalOptionsEngine = new OptionsEngine();
