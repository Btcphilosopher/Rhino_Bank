/**
 * RHINOQUANT GOLD - Order Management System (OMS) & Execution Engine
 * Order lifecycle event sourcing, matching execution engine, auto-hedging dealer simulator.
 */

import { globalMarketEngine } from './market';
import { globalOtcPricingEngine } from './pricing';
import { globalPhysicalBullionEngine } from './physical';

export type OrderType = 'MARKET' | 'LIMIT' | 'STOP' | 'IOC' | 'FOK' | 'RFQ';
export type OrderSide = 'BUY' | 'SELL';
export type OrderStatus = 'CREATED' | 'VALIDATING' | 'RISK_CHECK' | 'APPROVED' | 'ROUTING' | 'WORKING' | 'PARTIALLY_FILLED' | 'FILLED' | 'REJECTED' | 'CANCELLED' | 'EXPIRED';

export interface Order {
  orderId: string;
  clientName: string;
  instrument: string;
  orderType: OrderType;
  side: OrderSide;
  quantityOz: number;
  filledQuantityOz: number;
  limitPriceUsd?: number;
  stopPriceUsd?: number;
  avgFillPriceUsd: number;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
  timeInForce: 'GTC' | 'DAY' | 'IOC' | 'FOK';
  allocatedPhysical: boolean;
  events: { timestamp: string; status: OrderStatus; message: string }[];
}

export interface TradeExecution {
  tradeId: string;
  orderId: string;
  timestamp: string;
  instrument: string;
  side: OrderSide;
  quantityOz: number;
  executionPriceUsd: number;
  totalNotionalUsd: number;
  venue: string;
  slippageBps: number;
  commissionFeeUsd: number;
  hedgeExecuted: { hedgeType: 'FUTURES_SHORT' | 'FUTURES_LONG' | 'PUT_OPTION'; quantityOz: number; hedgePriceUsd: number };
}

export class OrderExecutionEngine {
  private orders: Order[] = [];
  private trades: TradeExecution[] = [];

  constructor() {
    this.seedInitialOrders();
  }

  private seedInitialOrders(): void {
    const spot = globalMarketEngine.getSpotUsd();
    const pastTrade: TradeExecution = {
      tradeId: 'TRD-EXE-90102',
      orderId: 'ORD-8812',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      instrument: 'XAU/USD',
      side: 'BUY',
      quantityOz: 1000,
      executionPriceUsd: Number((spot - 1.20).toFixed(2)),
      totalNotionalUsd: Number(((spot - 1.20) * 1000).toFixed(2)),
      venue: 'COMEX / Rhino Bullion Desk',
      slippageBps: 0.8,
      commissionFeeUsd: 145.00,
      hedgeExecuted: {
        hedgeType: 'FUTURES_SHORT',
        quantityOz: 1000,
        hedgePriceUsd: Number((spot - 0.40).toFixed(2)),
      },
    };
    this.trades.push(pastTrade);
  }

  public submitOrder(
    clientName: string,
    instrument: string,
    orderType: OrderType,
    side: OrderSide,
    quantityOz: number,
    limitPriceUsd?: number,
    allocatedPhysical = true
  ): { order: Order; execution?: TradeExecution } {
    const orderId = `ORD-${Date.now().toString().slice(-6)}`;
    const now = new Date().toISOString();

    const order: Order = {
      orderId,
      clientName,
      instrument,
      orderType,
      side,
      quantityOz,
      filledQuantityOz: 0,
      limitPriceUsd,
      avgFillPriceUsd: 0,
      status: 'CREATED',
      createdAt: now,
      updatedAt: now,
      timeInForce: 'GTC',
      allocatedPhysical,
      events: [{ timestamp: now, status: 'CREATED', message: 'Order created in OMS' }],
    };

    // Transition state: VALIDATING -> RISK_CHECK -> APPROVED
    order.status = 'VALIDATING';
    order.events.push({ timestamp: now, status: 'VALIDATING', message: 'Validating quantity & collateral rules' });

    order.status = 'RISK_CHECK';
    order.events.push({ timestamp: now, status: 'RISK_CHECK', message: 'Risk Gateway: Margin & Position limits verified' });

    order.status = 'APPROVED';
    order.events.push({ timestamp: now, status: 'APPROVED', message: 'Order approved for execution' });

    // Execute order immediately for MARKET / RFQ
    const spot = globalMarketEngine.getSpotUsd();
    let execPrice = spot;
    let slippageBps = 0;

    if (orderType === 'MARKET') {
      slippageBps = Number((0.5 + (quantityOz / 5000) * 1.2).toFixed(2));
      const slippageUsd = (spot * slippageBps) / 10000;
      execPrice = side === 'BUY' ? spot + slippageUsd : spot - slippageUsd;
    } else if (orderType === 'LIMIT' && limitPriceUsd) {
      if (side === 'BUY' && limitPriceUsd < spot) {
        order.status = 'WORKING';
        order.events.push({ timestamp: now, status: 'WORKING', message: `Working order placed on COMEX book @ $${limitPriceUsd}` });
        this.orders.unshift(order);
        return { order };
      }
      execPrice = limitPriceUsd;
    }

    execPrice = Number(execPrice.toFixed(2));
    order.filledQuantityOz = quantityOz;
    order.avgFillPriceUsd = execPrice;
    order.status = 'FILLED';
    order.updatedAt = new Date().toISOString();
    order.events.push({ timestamp: order.updatedAt, status: 'FILLED', message: `Fully executed ${quantityOz} oz @ $${execPrice}` });

    this.orders.unshift(order);

    // Auto-hedging simulator (Rhino Bullion Desk short/long futures hedge)
    const hedgeType = side === 'BUY' ? 'FUTURES_SHORT' : 'FUTURES_LONG';
    const hedgePrice = Number((execPrice + (side === 'BUY' ? 0.80 : -0.80)).toFixed(2));

    const trade: TradeExecution = {
      tradeId: `TRD-${Date.now().toString().slice(-6)}`,
      orderId,
      timestamp: order.updatedAt,
      instrument,
      side,
      quantityOz,
      executionPriceUsd: execPrice,
      totalNotionalUsd: Number((execPrice * quantityOz).toFixed(2)),
      venue: 'COMEX / Rhino Bullion Desk',
      slippageBps,
      commissionFeeUsd: Number((execPrice * quantityOz * 0.0001).toFixed(2)),
      hedgeExecuted: {
        hedgeType,
        quantityOz,
        hedgePriceUsd: hedgePrice,
      },
    };

    this.trades.unshift(trade);

    // If allocated physical requested, update physical inventory and dealer position
    if (allocatedPhysical) {
      globalPhysicalBullionEngine.allocateBarsToClient(clientName, quantityOz);
      globalOtcPricingEngine.updateInventory(side === 'BUY' ? -quantityOz : quantityOz);
    }

    return { order, execution: trade };
  }

  public getOrders(): Order[] {
    return this.orders;
  }

  public getTrades(): TradeExecution[] {
    return this.trades;
  }
}

export const globalOrderExecutionEngine = new OrderExecutionEngine();
