/**
 * RHINOQUANT GOLD - Quantitative Research, Backtesting & Monte Carlo Simulation Lab
 * Backtesting engine for Gold Momentum, Mean Reversion, Roll Yield, Gold/Silver Arbitrage, Real Yield Arbitrage.
 */

import { globalMarketEngine } from './market';

export interface BacktestConfig {
  strategyName: 'Gold Momentum' | 'Gold Mean Reversion' | 'Futures Curve Roll Yield' | 'Gold/Silver Ratio Reversion' | 'Gold/Real Yield Arbitrage' | 'Volatility Surface Arbitrage';
  startDate: string;
  endDate: string;
  initialCapitalUsd: number;
  slippageBps: number;
  feeBps: number;
  leverage: number;
}

export interface BacktestResult {
  config: BacktestConfig;
  totalReturnPct: number;
  annualisedReturnPct: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdownPct: number;
  volatilityPct: number;
  winRatePct: number;
  totalTrades: number;
  profitFactor: number;
  equityCurve: { date: string; equityUsd: number; benchmarkEquityUsd: number; drawdownPct: number }[];
  tradeHistory: { id: string; date: string; action: 'BUY' | 'SELL'; priceUsd: number; qtyOz: number; pnlUsd: number }[];
}

export interface MonteCarloSimulationResult {
  simulationsCount: number;
  horizonDays: number;
  initialPriceUsd: number;
  meanFinalPriceUsd: number;
  medianFinalPriceUsd: number;
  percentile5thPriceUsd: number;
  percentile95thPriceUsd: number;
  maxPathPriceUsd: number;
  minPathPriceUsd: number;
  probabilityOfProfitPct: number;
  paths: { day: number; prices: number[] }[]; // sample paths
}

export interface ResearchNotebookCell {
  cellId: string;
  language: 'python' | 'r';
  code: string;
  outputType: 'table' | 'chart' | 'text' | 'json';
  outputContent: any;
  executionTimeMs: number;
}

export class QuantResearchEngine {
  public runBacktest(config: BacktestConfig): BacktestResult {
    const spot = globalMarketEngine.getSpotUsd();
    const days = 365 * 3; // 3 years backtest
    const startDate = new Date(Date.now() - days * 86400000);

    let currentEquity = config.initialCapitalUsd;
    let benchmarkEquity = config.initialCapitalUsd;
    let peakEquity = currentEquity;
    let maxDrawdown = 0;

    const equityCurve: BacktestResult['equityCurve'] = [];
    const tradeHistory: BacktestResult['tradeHistory'] = [];

    const baseDrift = config.strategyName.includes('Momentum') ? 0.0006 : 0.0004;
    const vol = 0.011;

    let wins = 0;
    let totalTrades = 0;

    for (let i = 0; i < 90; i++) { // 90 sampling points
      const pointDate = new Date(startDate.getTime() + (i / 90) * days * 86400000).toISOString().substring(0, 10);

      const stratReturn = (Math.random() - 0.47) * vol * Math.sqrt(365 / 90) + baseDrift;
      const bchReturn = (Math.random() - 0.49) * vol * Math.sqrt(365 / 90) + 0.0003;

      currentEquity *= (1 + stratReturn * config.leverage);
      benchmarkEquity *= (1 + bchReturn);

      if (currentEquity > peakEquity) peakEquity = currentEquity;
      const dd = ((peakEquity - currentEquity) / peakEquity) * 100;
      if (dd > maxDrawdown) maxDrawdown = dd;

      equityCurve.push({
        date: pointDate,
        equityUsd: Number(currentEquity.toFixed(2)),
        benchmarkEquityUsd: Number(benchmarkEquity.toFixed(2)),
        drawdownPct: Number((-dd).toFixed(2)),
      });

      if (i % 6 === 0) {
        totalTrades++;
        const pnl = (Math.random() - 0.44) * 8500 * config.leverage;
        if (pnl > 0) wins++;
        tradeHistory.push({
          id: `TRD-BK-${1000 + i}`,
          date: pointDate,
          action: Math.random() > 0.5 ? 'BUY' : 'SELL',
          priceUsd: Number((spot + (Math.random() - 0.5) * 80).toFixed(2)),
          qtyOz: 100 * config.leverage,
          pnlUsd: Number(pnl.toFixed(2)),
        });
      }
    }

    const totalReturnPct = Number((((currentEquity - config.initialCapitalUsd) / config.initialCapitalUsd) * 100).toFixed(2));
    const annualisedReturnPct = Number((totalReturnPct / 3).toFixed(2));
    const winRatePct = Number(((wins / totalTrades) * 100).toFixed(1));

    return {
      config,
      totalReturnPct,
      annualisedReturnPct,
      sharpeRatio: Number((annualisedReturnPct / 14.2).toFixed(2)),
      sortinoRatio: Number(((annualisedReturnPct * 1.35) / 14.2).toFixed(2)),
      maxDrawdownPct: Number(maxDrawdown.toFixed(2)),
      volatilityPct: 14.2,
      winRatePct,
      totalTrades,
      profitFactor: 1.84,
      equityCurve,
      tradeHistory,
    };
  }

  public runMonteCarlo(simulationsCount = 1000, horizonDays = 252): MonteCarloSimulationResult {
    const initialPriceUsd = globalMarketEngine.getSpotUsd();
    const annualDrift = 0.08; // 8% expected annual drift
    const annualVol = 0.16;   // 16% volatility
    const dt = 1 / 252;

    const samplePaths: { day: number; prices: number[] }[] = [];
    const finalPrices: number[] = [];

    // Generate 5 visual sample paths
    for (let day = 0; day <= horizonDays; day += 7) {
      samplePaths.push({ day, prices: [] });
    }

    for (let sim = 0; sim < simulationsCount; sim++) {
      let p = initialPriceUsd;
      for (let day = 1; day <= horizonDays; day++) {
        const z = (Math.random() + Math.random() + Math.random() + Math.random() - 2) * 1.732; // Normal approximation
        p = p * Math.exp((annualDrift - 0.5 * annualVol * annualVol) * dt + annualVol * Math.sqrt(dt) * z);

        if (sim < 5 && day % 7 === 0) {
          const sampleIndex = Math.floor(day / 7);
          samplePaths[sampleIndex].prices.push(Number(p.toFixed(2)));
        }
      }
      finalPrices.push(p);
    }

    finalPrices.sort((a, b) => a - b);
    const meanFinal = finalPrices.reduce((a, b) => a + b, 0) / simulationsCount;
    const medianFinal = finalPrices[Math.floor(simulationsCount * 0.5)];
    const p5 = finalPrices[Math.floor(simulationsCount * 0.05)];
    const p95 = finalPrices[Math.floor(simulationsCount * 0.95)];
    const profitable = finalPrices.filter((p) => p > initialPriceUsd).length;

    return {
      simulationsCount,
      horizonDays,
      initialPriceUsd,
      meanFinalPriceUsd: Number(meanFinal.toFixed(2)),
      medianFinalPriceUsd: Number(medianFinal.toFixed(2)),
      percentile5thPriceUsd: Number(p5.toFixed(2)),
      percentile95thPriceUsd: Number(p95.toFixed(2)),
      maxPathPriceUsd: Number(finalPrices[finalPrices.length - 1].toFixed(2)),
      minPathPriceUsd: Number(finalPrices[0].toFixed(2)),
      probabilityOfProfitPct: Number(((profitable / simulationsCount) * 100).toFixed(1)),
      paths: samplePaths,
    };
  }

  // Pre-configured Python/R Research Notebook cells
  public getDefaultNotebookCells(): ResearchNotebookCell[] {
    const spot = globalMarketEngine.getSpotUsd();
    return [
      {
        cellId: 'CELL-01',
        language: 'python',
        code: `import rhinoquant as rq
import pandas as pd

gold = rq.market("XAUUSD")
curve = rq.futures_curve("GC")
basis = rq.basis(gold, curve)

print(f"Current XAU/USD Spot: $\{gold.spot_usd:.2f}")
print(f"Front Month GC Basis: $\{basis.front_basis_usd:.2f} ({basis.annualised_basis_pct:.2f}% p.a.)")
rq.plot_curve(curve)`,
        outputType: 'text',
        outputContent: `Current XAU/USD Spot: $${spot.toFixed(2)}\nFront Month GC Basis: $2.20 (+0.54% p.a.)\nFutures Market Structure: CONTANGO\nAnnualized Carry Cost: $261.90 / oz`,
        executionTimeMs: 142,
      },
      {
        cellId: 'CELL-02',
        language: 'python',
        code: `portfolio = rq.get_portfolio()
risk = rq.calculate_var(portfolio, confidence=0.99, horizon=1)
stress = rq.run_stress(portfolio, gold_move=-0.25)

print(f"1D 99% Parametric VaR: $\{risk.parametric_var_usd:,.2f}")
print(f"Expected Shortfall (ES): $\{risk.expected_shortfall_usd:,.2f}")
print(f"Liquidity Deleveraging P&L: $\{stress.pnl_usd:,.2f}")`,
        outputType: 'text',
        outputContent: `1D 99% Parametric VaR: $4,200,000.00\nExpected Shortfall (ES): $6,100,000.00\nLiquidity Deleveraging P&L: -$42,500,000.00\nConsolidated Gold Delta: 35,000.00 troy oz`,
        executionTimeMs: 210,
      },
    ];
  }
}

export const globalQuantResearchEngine = new QuantResearchEngine();
