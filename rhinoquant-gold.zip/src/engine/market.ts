/**
 * RHINOQUANT GOLD - Market Data Engine & Price Normalisation
 * Adapters for Spot XAU, FX, LBMA Benchmarks, Regional Premiums & Live Order Book.
 */

import { UNIT_TO_TROY_OZ, TROY_OZ_TO_GRAMS } from './units';

export type Currency = 'USD' | 'EUR' | 'GBP' | 'CHF' | 'JPY' | 'CNY' | 'CNH' | 'HKD' | 'SGD' | 'INR' | 'KRW';

export interface MarketObservation {
  timestamp: string;
  venue: string;
  instrument: string;
  currency: Currency;
  unit: 'oz' | 'g' | 'kg';
  bid: number;
  ask: number;
  mid: number;
  last: number;
  change24h: number;
  change24hPct: number;
  high24h: number;
  low24h: number;
  volume: number;
  openInterest?: number;
  source: string;
  sequence: number;
  quality: 'LIVE' | 'BENCHMARK' | 'SYNTHETIC' | 'DELAYED';
}

export interface FxRate {
  pair: string; // e.g. 'EURUSD', 'USDJPY', 'USDCNH'
  rate: number;
  bid: number;
  ask: number;
  change24hPct: number;
}

export interface LBMABenchmark {
  benchmarkName: 'LBMA Gold Price AM' | 'LBMA Gold Price PM';
  timestamp: string;
  currency: 'USD' | 'GBP' | 'EUR';
  priceOz: number;
  unit: 'troy_oz';
  source: 'ICE Benchmark Administration (Adapter Proxy)';
  licenceStatus: 'SIMULATED_DEMO_LICENCE';
}

export interface RegionalPremium {
  region: 'London' | 'New York' | 'Hong Kong' | 'Shanghai' | 'Tokyo' | 'Singapore' | 'Dubai' | 'Mumbai' | 'Zurich';
  currency: Currency;
  unit: 'oz' | 'g';
  localPrice: number;
  usdEquivalentOz: number;
  benchmarkPriceOz: number;
  premiumUsdOz: number;
  premiumPct: number;
  inventoryLevel: 'HIGH' | 'NORMAL' | 'TIGHT' | 'DEFICIT';
  tradingStatus: 'ACTIVE' | 'CLOSED' | 'PRE_OPEN';
}

export interface OrderBookLevel {
  price: number;
  sizeOz: number;
  ordersCount: number;
  totalOz: number;
}

export interface OrderBook {
  instrument: string;
  timestamp: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread: number;
  spreadBps: number;
}

export interface TimeAndSalesTrade {
  id: string;
  timestamp: string;
  instrument: string;
  price: number;
  sizeOz: number;
  side: 'BUY' | 'SELL';
  venue: string;
}

// Initial Base Market State
const BASE_XAU_USD = 4850.20;

export class MarketDataEngine {
  private baseSpotUsd: number = BASE_XAU_USD;
  private sequence = 10000;
  private fxRates: Record<string, FxRate> = {
    EURUSD: { pair: 'EURUSD', rate: 1.0850, bid: 1.0849, ask: 1.0851, change24hPct: +0.12 },
    GBPUSD: { pair: 'GBPUSD', rate: 1.2720, bid: 1.2719, ask: 1.2721, change24hPct: -0.08 },
    USDCHF: { pair: 'USDCHF', rate: 0.8840, bid: 0.8839, ask: 0.8841, change24hPct: -0.15 },
    USDJPY: { pair: 'USDJPY', rate: 154.20, bid: 154.18, ask: 154.22, change24hPct: +0.35 },
    USDCNY: { pair: 'USDCNY', rate: 7.2350, bid: 7.2340, ask: 7.2360, change24hPct: +0.05 },
    USDCNH: { pair: 'USDCNH', rate: 7.2410, bid: 7.2400, ask: 7.2420, change24hPct: +0.08 },
    USDHKD: { pair: 'USDHKD', rate: 7.8210, bid: 7.8205, ask: 7.8215, change24hPct: 0.00 },
    USDSGD: { pair: 'USDSGD', rate: 1.3450, bid: 1.3448, ask: 1.3452, change24hPct: -0.10 },
    USDINR: { pair: 'USDINR', rate: 84.500, bid: 84.490, ask: 84.510, change24hPct: +0.18 },
    USDKRW: { pair: 'USDKRW', rate: 1385.0, bid: 1384.5, ask: 1385.5, change24hPct: +0.22 },
  };

  private lastTrades: TimeAndSalesTrade[] = [];

  constructor() {
    // Generate initial time & sales history
    const venues = ['London OTC', 'COMEX NY', 'HKEx Gold', 'SGE Shanghai', 'Zurich Vault'];
    const now = Date.now();
    for (let i = 20; i >= 0; i--) {
      const price = BASE_XAU_USD + (Math.random() - 0.5) * 3;
      this.lastTrades.push({
        id: `TRD-${1000 + i}`,
        timestamp: new Date(now - i * 1500).toISOString().substring(11, 19),
        instrument: 'XAU/USD',
        price: Number(price.toFixed(2)),
        sizeOz: Math.floor(Math.random() * 500) + 25,
        side: Math.random() > 0.5 ? 'BUY' : 'SELL',
        venue: venues[Math.floor(Math.random() * venues.length)],
      });
    }
  }

  // Tick generator with micro Brownian motion
  public tick(): void {
    this.sequence++;
    const delta = (Math.random() - 0.495) * 0.85; // slight bullish bias
    this.baseSpotUsd = Math.max(1000, Number((this.baseSpotUsd + delta).toFixed(2)));

    // Micro noise on FX
    for (const k of Object.keys(this.fxRates)) {
      const fxDelta = (Math.random() - 0.5) * 0.0003 * this.fxRates[k].rate;
      this.fxRates[k].rate = Number((this.fxRates[k].rate + fxDelta).toFixed(4));
    }

    // Add new trade occasionally
    if (Math.random() > 0.4) {
      const side: 'BUY' | 'SELL' = Math.random() > 0.5 ? 'BUY' : 'SELL';
      const sizeOz = Math.floor(Math.random() * 800) + 10;
      const price = side === 'BUY' ? this.baseSpotUsd + 0.10 : this.baseSpotUsd - 0.10;
      const venues = ['London OTC', 'COMEX NY', 'HKEx Gold', 'SGE Shanghai', 'Zurich Vault'];

      this.lastTrades.unshift({
        id: `TRD-${this.sequence}`,
        timestamp: new Date().toISOString().substring(11, 19),
        instrument: 'XAU/USD',
        price: Number(price.toFixed(2)),
        sizeOz,
        side,
        venue: venues[Math.floor(Math.random() * venues.length)],
      });
      if (this.lastTrades.length > 50) this.lastTrades.pop();
    }
  }

  public getSpotUsd(): number {
    return this.baseSpotUsd;
  }

  // Get XAU Spot across 11 currencies
  public getSpotQuotes(): Record<Currency, MarketObservation> {
    const usdBid = Number((this.baseSpotUsd - 0.15).toFixed(2));
    const usdAsk = Number((this.baseSpotUsd + 0.15).toFixed(2));
    const midUsd = this.baseSpotUsd;
    const timestamp = new Date().toISOString();

    const result = {} as Record<Currency, MarketObservation>;

    // Helper to calculate foreign currency gold price
    const calcObservation = (curr: Currency, fxMultiplierToUsd: number): MarketObservation => {
      // fxMultiplierToUsd is how many 'curr' per 1 USD (e.g. 7.24 for CNH, 0.92 for EUR)
      const mid = Number((midUsd * fxMultiplierToUsd).toFixed(2));
      const bid = Number((usdBid * fxMultiplierToUsd).toFixed(2));
      const ask = Number((usdAsk * fxMultiplierToUsd).toFixed(2));
      const last = mid;

      return {
        timestamp,
        venue: 'RhinoQuant OTC Aggregator',
        instrument: `XAU/${curr}`,
        currency: curr,
        unit: 'oz',
        bid,
        ask,
        mid,
        last,
        change24h: Number((60.20 * fxMultiplierToUsd).toFixed(2)),
        change24hPct: +1.26,
        high24h: Number(((BASE_XAU_USD + 28.5) * fxMultiplierToUsd).toFixed(2)),
        low24h: Number(((BASE_XAU_USD - 15.0) * fxMultiplierToUsd).toFixed(2)),
        volume: 485200,
        openInterest: 1245000,
        source: 'Synthetic Market Adapter',
        sequence: this.sequence,
        quality: 'LIVE',
      };
    };

    result.USD = calcObservation('USD', 1.0);
    result.EUR = calcObservation('EUR', 1 / this.fxRates.EURUSD.rate);
    result.GBP = calcObservation('GBP', 1 / this.fxRates.GBPUSD.rate);
    result.CHF = calcObservation('CHF', this.fxRates.USDCHF.rate);
    result.JPY = calcObservation('JPY', this.fxRates.USDJPY.rate);
    result.CNY = calcObservation('CNY', this.fxRates.USDCNY.rate);
    result.CNH = calcObservation('CNH', this.fxRates.USDCNH.rate);
    result.HKD = calcObservation('HKD', this.fxRates.USDHKD.rate);
    result.SGD = calcObservation('SGD', this.fxRates.USDSGD.rate);
    result.INR = calcObservation('INR', this.fxRates.USDINR.rate);
    result.KRW = calcObservation('KRW', this.fxRates.USDKRW.rate);

    return result;
  }

  // LBMA Benchmark Service (Adapter proxy)
  public getLBMABenchmarks(): LBMABenchmark[] {
    const timestamp = new Date().toISOString();
    return [
      {
        benchmarkName: 'LBMA Gold Price AM',
        timestamp,
        currency: 'USD',
        priceOz: Number((this.baseSpotUsd - 2.50).toFixed(2)),
        unit: 'troy_oz',
        source: 'ICE Benchmark Administration (Adapter Proxy)',
        licenceStatus: 'SIMULATED_DEMO_LICENCE',
      },
      {
        benchmarkName: 'LBMA Gold Price PM',
        timestamp,
        currency: 'USD',
        priceOz: Number((this.baseSpotUsd + 1.10).toFixed(2)),
        unit: 'troy_oz',
        source: 'ICE Benchmark Administration (Adapter Proxy)',
        licenceStatus: 'SIMULATED_DEMO_LICENCE',
      },
    ];
  }

  // Regional Physical Premiums (London, NY, HK, Shanghai, Tokyo, Singapore, Dubai, Mumbai, Zurich)
  public getRegionalPremiums(): RegionalPremium[] {
    const base = this.baseSpotUsd;
    const cnhRate = this.fxRates.USDCNH.rate;
    const inrRate = this.fxRates.USDINR.rate;

    return [
      {
        region: 'London',
        currency: 'USD',
        unit: 'oz',
        localPrice: base,
        usdEquivalentOz: base,
        benchmarkPriceOz: base,
        premiumUsdOz: 0.00,
        premiumPct: 0.00,
        inventoryLevel: 'NORMAL',
        tradingStatus: 'ACTIVE',
      },
      {
        region: 'New York',
        currency: 'USD',
        unit: 'oz',
        localPrice: base + 0.80,
        usdEquivalentOz: base + 0.80,
        benchmarkPriceOz: base,
        premiumUsdOz: 0.80,
        premiumPct: 0.016,
        inventoryLevel: 'NORMAL',
        tradingStatus: 'ACTIVE',
      },
      {
        region: 'Shanghai',
        currency: 'CNH',
        unit: 'g',
        localPrice: Number(((base + 38.50) * cnhRate / TROY_OZ_TO_GRAMS).toFixed(2)),
        usdEquivalentOz: base + 38.50,
        benchmarkPriceOz: base,
        premiumUsdOz: 38.50,
        premiumPct: 0.79,
        inventoryLevel: 'TIGHT',
        tradingStatus: 'ACTIVE',
      },
      {
        region: 'Hong Kong',
        currency: 'HKD',
        unit: 'oz',
        localPrice: Number(((base + 4.20) * this.fxRates.USDHKD.rate).toFixed(2)),
        usdEquivalentOz: base + 4.20,
        benchmarkPriceOz: base,
        premiumUsdOz: 4.20,
        premiumPct: 0.087,
        inventoryLevel: 'HIGH',
        tradingStatus: 'ACTIVE',
      },
      {
        region: 'Mumbai',
        currency: 'INR',
        unit: 'g',
        localPrice: Number(((base + 42.00) * inrRate / TROY_OZ_TO_GRAMS).toFixed(2)),
        usdEquivalentOz: base + 42.00,
        benchmarkPriceOz: base,
        premiumUsdOz: 42.00,
        premiumPct: 0.87,
        inventoryLevel: 'DEFICIT',
        tradingStatus: 'ACTIVE',
      },
      {
        region: 'Dubai',
        currency: 'USD',
        unit: 'oz',
        localPrice: base + 6.50,
        usdEquivalentOz: base + 6.50,
        benchmarkPriceOz: base,
        premiumUsdOz: 6.50,
        premiumPct: 0.134,
        inventoryLevel: 'HIGH',
        tradingStatus: 'ACTIVE',
      },
      {
        region: 'Zurich',
        currency: 'USD',
        unit: 'oz',
        localPrice: base - 0.20,
        usdEquivalentOz: base - 0.20,
        benchmarkPriceOz: base,
        premiumUsdOz: -0.20,
        premiumPct: -0.004,
        inventoryLevel: 'NORMAL',
        tradingStatus: 'ACTIVE',
      },
      {
        region: 'Singapore',
        currency: 'SGD',
        unit: 'oz',
        localPrice: Number(((base + 3.10) * this.fxRates.USDSGD.rate).toFixed(2)),
        usdEquivalentOz: base + 3.10,
        benchmarkPriceOz: base,
        premiumUsdOz: 3.10,
        premiumPct: 0.064,
        inventoryLevel: 'NORMAL',
        tradingStatus: 'ACTIVE',
      },
      {
        region: 'Tokyo',
        currency: 'JPY',
        unit: 'g',
        localPrice: Number(((base + 2.80) * this.fxRates.USDJPY.rate / TROY_OZ_TO_GRAMS).toFixed(2)),
        usdEquivalentOz: base + 2.80,
        benchmarkPriceOz: base,
        premiumUsdOz: 2.80,
        premiumPct: 0.058,
        inventoryLevel: 'NORMAL',
        tradingStatus: 'CLOSED',
      },
    ];
  }

  // Orderbook Depth Generator
  public getOrderBook(instrument = 'XAU/USD'): OrderBook {
    const mid = this.baseSpotUsd;
    const spread = 0.20;
    const bids: OrderBookLevel[] = [];
    const asks: OrderBookLevel[] = [];

    let cumBidOz = 0;
    let cumAskOz = 0;

    for (let i = 0; i < 10; i++) {
      const bidPrice = Number((mid - (spread / 2) - i * 0.15).toFixed(2));
      const askPrice = Number((mid + (spread / 2) + i * 0.15).toFixed(2));

      const bidSize = Math.floor(200 + Math.sin(i * 1.5) * 150 + Math.random() * 400);
      const askSize = Math.floor(200 + Math.cos(i * 1.5) * 150 + Math.random() * 400);

      cumBidOz += bidSize;
      cumAskOz += askSize;

      bids.push({
        price: bidPrice,
        sizeOz: bidSize,
        ordersCount: Math.floor(Math.random() * 8) + 1,
        totalOz: cumBidOz,
      });

      asks.push({
        price: askPrice,
        sizeOz: askSize,
        ordersCount: Math.floor(Math.random() * 8) + 1,
        totalOz: cumAskOz,
      });
    }

    return {
      instrument,
      timestamp: new Date().toISOString(),
      bids,
      asks,
      spread,
      spreadBps: Number(((spread / mid) * 10000).toFixed(2)),
    };
  }

  public getTimeAndSales(): TimeAndSalesTrade[] {
    return this.lastTrades;
  }

  public getFxRates(): Record<string, FxRate> {
    return this.fxRates;
  }
}

export const globalMarketEngine = new MarketDataEngine();
