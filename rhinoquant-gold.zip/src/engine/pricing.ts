/**
 * RHINOQUANT GOLD - OTC Dealer Pricing Engine & RFQ Engine
 * Calculates dealer quotes, tier spreads, inventory skew, funding costs, and competitive RFQs.
 */

import { globalMarketEngine } from './market';

export type ClientTier = 'TIER_1_INSTITUTIONAL' | 'TIER_2_BANK' | 'TIER_3_CORPORATE' | 'RETAIL_DESK';

export interface DealerQuoteInput {
  instrument: string;
  side: 'BUY' | 'SELL' | 'TWO_WAY';
  quantityOz: number;
  clientTier: ClientTier;
  settlementDays: 'T+0' | 'T+1' | 'T+2' | 'T+5';
  allocated: boolean;
}

export interface DealerQuote {
  quoteId: string;
  dealerName: string;
  timestamp: string;
  validitySeconds: number;
  referencePrice: number;
  bidPrice: number;
  askPrice: number;
  spreadUsd: number;
  spreadBps: number;
  quantityOz: number;
  estimatedSettlementDate: string;
  feeUsd: number;
  fundingCostUsd: number;
  hedgingCostUsd: number;
  status: 'ACTIVE' | 'EXPIRED' | 'EXECUTED' | 'REJECTED';
}

export interface RfqRequest {
  rfqId: string;
  clientName: string;
  instrument: string;
  quantityOz: number;
  side: 'BUY' | 'SELL';
  settlement: 'T+0' | 'T+1' | 'T+2';
  timestamp: string;
  expiryTimestamp: string;
  quotes: DealerQuote[];
  status: 'OPEN' | 'COMPLETED' | 'EXPIRED' | 'CANCELLED';
  executedDealer?: string;
  executionPrice?: number;
}

export class OTCDealerPricingEngine {
  private currentInventoryOz = 120000; // Rhino Bullion Desk physical inventory

  public generateQuote(input: DealerQuoteInput): DealerQuote {
    const spot = globalMarketEngine.getSpotUsd();
    const timestamp = new Date().toISOString();

    // Base spread based on client tier
    let baseHalfSpread = 0.15; // default $0.30 full spread
    if (input.clientTier === 'TIER_1_INSTITUTIONAL') baseHalfSpread = 0.10;
    else if (input.clientTier === 'TIER_2_BANK') baseHalfSpread = 0.12;
    else if (input.clientTier === 'TIER_3_CORPORATE') baseHalfSpread = 0.20;
    else if (input.clientTier === 'RETAIL_DESK') baseHalfSpread = 0.50;

    // Size penalty / market impact
    const sizeImpact = (input.quantityOz / 10000) * 0.15;

    // Inventory skew penalty (if dealer is low on inventory and client wants to BUY, charge higher offer)
    let inventorySkew = 0;
    if (this.currentInventoryOz < 50000 && input.side === 'BUY') {
      inventorySkew = 0.25; // price premium on offer
    } else if (this.currentInventoryOz > 200000 && input.side === 'SELL') {
      inventorySkew = -0.20; // lower bid
    }

    // Settlement funding cost (e.g. 5% annual interest on gold value for T+2)
    const days = input.settlementDays === 'T+0' ? 0 : input.settlementDays === 'T+1' ? 1 : input.settlementDays === 'T+2' ? 2 : 5;
    const annualFundingRate = 0.0525;
    const fundingCostPerOz = (spot * annualFundingRate * days) / 365;

    const bid = Number((spot - baseHalfSpread - sizeImpact + inventorySkew).toFixed(2));
    const ask = Number((spot + baseHalfSpread + sizeImpact + inventorySkew + fundingCostPerOz).toFixed(2));
    const spread = Number((ask - bid).toFixed(2));

    const totalVal = spot * input.quantityOz;
    const feeUsd = Number((totalVal * 0.00015).toFixed(2)); // 1.5 bps fee
    const fundingCostUsd = Number((fundingCostPerOz * input.quantityOz).toFixed(2));
    const hedgingCostUsd = Number((input.quantityOz * 0.08).toFixed(2)); // CME futures transaction fee

    const quoteId = `QT-RHINO-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    return {
      quoteId,
      dealerName: 'Rhino Bullion Desk (HQ London)',
      timestamp,
      validitySeconds: 15,
      referencePrice: spot,
      bidPrice: bid,
      askPrice: ask,
      spreadUsd: spread,
      spreadBps: Number(((spread / spot) * 10000).toFixed(2)),
      quantityOz: input.quantityOz,
      estimatedSettlementDate: new Date(Date.now() + days * 86400000).toISOString().substring(0, 10),
      feeUsd,
      fundingCostUsd,
      hedgingCostUsd,
      status: 'ACTIVE',
    };
  }

  // Generate competitive 3-Dealer RFQ Response
  public createCompetitiveRfq(
    clientName: string,
    quantityOz: number,
    side: 'BUY' | 'SELL',
    settlement: 'T+0' | 'T+1' | 'T+2' = 'T+2'
  ): RfqRequest {
    const spot = globalMarketEngine.getSpotUsd();
    const timestamp = new Date();
    const expiry = new Date(timestamp.getTime() + 30000); // 30s expiry

    const rhinoQuote = this.generateQuote({
      instrument: 'XAU/USD',
      side,
      quantityOz,
      clientTier: 'TIER_1_INSTITUTIONAL',
      settlementDays: settlement,
      allocated: true,
    });

    // Dealer B (Zurich Gold Bank) quote
    const quoteB: DealerQuote = {
      ...rhinoQuote,
      quoteId: `QT-ZURICH-${Date.now()}`,
      dealerName: 'Zurich Gold Bank AG',
      bidPrice: Number((spot - 0.25 - (Math.random() * 0.1)).toFixed(2)),
      askPrice: Number((spot + 0.22 + (Math.random() * 0.1)).toFixed(2)),
      spreadUsd: 0.47,
      spreadBps: Number(((0.47 / spot) * 10000).toFixed(2)),
    };

    // Dealer C (Hong Kong Bullion Corp) quote
    const quoteC: DealerQuote = {
      ...rhinoQuote,
      quoteId: `QT-HKBC-${Date.now()}`,
      dealerName: 'Hong Kong Bullion Corp',
      bidPrice: Number((spot - 0.20 + (Math.random() * 0.15)).toFixed(2)),
      askPrice: Number((spot + 0.35 - (Math.random() * 0.1)).toFixed(2)),
      spreadUsd: 0.55,
      spreadBps: Number(((0.55 / spot) * 10000).toFixed(2)),
    };

    const rfqId = `RFQ-${Date.now().toString().slice(-6)}`;

    return {
      rfqId,
      clientName,
      instrument: 'XAU/USD',
      quantityOz,
      side,
      settlement,
      timestamp: timestamp.toISOString(),
      expiryTimestamp: expiry.toISOString(),
      quotes: [rhinoQuote, quoteB, quoteC],
      status: 'OPEN',
    };
  }

  public getInventoryOz(): number {
    return this.currentInventoryOz;
  }

  public updateInventory(deltaOz: number): void {
    this.currentInventoryOz += deltaOz;
  }
}

export const globalOtcPricingEngine = new OTCDealerPricingEngine();
