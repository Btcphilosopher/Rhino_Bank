/**
 * RHINOQUANT GOLD - Unit & Purity Engine
 * Exact conversion constants and fixed-precision financial arithmetic.
 */

export type GoldUnit = 'oz' | 'g' | 'kg' | 'tonne' | 'dwt' | 'tola' | 'tael';
export type GoldPurity = 999.9 | 999.0 | 995.0 | 916.7 | 900.0 | 750.0 | 585.0;

// Conversion ratios relative to 1 Troy Ounce
export const UNIT_TO_TROY_OZ: Record<GoldUnit, number> = {
  oz: 1,                          // 1 troy oz = 1 troy oz
  g: 0.032150746568628,          // 1 gram = 0.032150746568628 troy oz
  kg: 32.150746568628,            // 1 kg = 32.150746568628 troy oz
  tonne: 32150.746568628,         // 1 metric tonne = 32,150.746568628 troy oz
  dwt: 0.05,                      // 1 pennyweight = 0.05 troy oz
  tola: 0.375,                    // 1 Indian tola = 0.375 troy oz (11.6638038g)
  tael: 1.20337054,               // 1 Hong Kong tael = 1.20337054 troy oz (37.429g)
};

export const TROY_OZ_TO_GRAMS = 31.1034768;

export interface UnitConversionResult {
  troyOunces: number;
  grams: number;
  kilograms: number;
  metricTonnes: number;
  pennyweight: number;
  tolas: number;
  taels: number;
}

export function convertGoldQuantity(quantity: number, fromUnit: GoldUnit): UnitConversionResult {
  const ozRatio = UNIT_TO_TROY_OZ[fromUnit];
  const troyOunces = quantity * ozRatio;

  return {
    troyOunces: Number(troyOunces.toFixed(6)),
    grams: Number((troyOunces * TROY_OZ_TO_GRAMS).toFixed(6)),
    kilograms: Number((troyOunces * TROY_OZ_TO_GRAMS / 1000).toFixed(6)),
    metricTonnes: Number((troyOunces * TROY_OZ_TO_GRAMS / 1000000).toFixed(8)),
    pennyweight: Number((troyOunces / UNIT_TO_TROY_OZ.dwt).toFixed(6)),
    tolas: Number((troyOunces / UNIT_TO_TROY_OZ.tola).toFixed(6)),
    taels: Number((troyOunces / UNIT_TO_TROY_OZ.tael).toFixed(6)),
  };
}

export interface FineGoldResult {
  grossWeightGrams: number;
  purity: GoldPurity;
  fineWeightGrams: number;
  fineWeightTroyOz: number;
  purityFraction: number;
}

export function calculateFineGold(grossWeightGrams: number, purity: GoldPurity): FineGoldResult {
  const purityFraction = purity / 1000;
  const fineWeightGrams = grossWeightGrams * purityFraction;
  const fineWeightTroyOz = fineWeightGrams * UNIT_TO_TROY_OZ.g;

  return {
    grossWeightGrams: Number(grossWeightGrams.toFixed(4)),
    purity,
    fineWeightGrams: Number(fineWeightGrams.toFixed(4)),
    fineWeightTroyOz: Number(fineWeightTroyOz.toFixed(6)),
    purityFraction,
  };
}

export function formatCurrency(amount: number, currency = 'USD', decimals = 2): string {
  const symbols: Record<string, string> = {
    USD: '$',
    EUR: '€',
    GBP: '£',
    CHF: 'CHF ',
    JPY: '¥',
    CNY: '¥',
    CNH: '¥',
    HKD: 'HK$',
    SGD: 'S$',
    INR: '₹',
    KRW: '₩',
  };
  const symbol = symbols[currency] || `${currency} `;
  return `${symbol}${amount.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
}

export function formatQuantity(qty: number, unit: GoldUnit, decimals = 2): string {
  return `${qty.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })} ${unit}`;
}
