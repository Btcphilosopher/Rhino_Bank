/**
 * RHINOQUANT GOLD - Flagship Application Shell
 * Institutional Gold Trading, Quantitative Research, Pricing, Risk & Physical Bullion Platform.
 */

import React, { useState, useEffect } from 'react';
import { Navbar, ActiveTab } from './components/Navbar';
import { TickerBar } from './components/TickerBar';
import { MarketsView } from './components/MarketsView';
import { TradingRfqView } from './components/TradingRfqView';
import { FuturesCurveView } from './components/FuturesCurveView';
import { OptionsLabView } from './components/OptionsLabView';
import { VaultDigitalTwinView } from './components/VaultDigitalTwinView';
import { PortfolioLedgerView } from './components/PortfolioLedgerView';
import { RiskMacroView } from './components/RiskMacroView';
import { QuantLabView } from './components/QuantLabView';
import { ReportsCliView } from './components/ReportsCliView';
import { QuickOrderModal } from './components/QuickOrderModal';
import { AiQuantModal } from './components/AiQuantModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('MARKETS');
  const [spotUsd, setSpotUsd] = useState<number>(4850.20);

  // Engine Data States
  const [spotQuotes, setSpotQuotes] = useState<any>({});
  const [lbmaBenchmarks, setLbmaBenchmarks] = useState<any[]>([]);
  const [regionalPremiums, setRegionalPremiums] = useState<any[]>([]);
  const [orderBook, setOrderBook] = useState<any>({ bids: [], asks: [], spread: 0.2, spreadBps: 0.4 });
  const [timeAndSales, setTimeAndSales] = useState<any[]>([]);
  const [futuresCurve, setFuturesCurve] = useState<any>({ contracts: [], calendarSpreads: [], marketStructure: 'CONTANGO', frontMonthBasis: 2.2, annualisedFrontBasisPct: 0.54, rollYieldAnnualisedPct: -0.54 });
  const [optionsSurface, setOptionsSurface] = useState<any[]>([]);
  const [vaults, setVaults] = useState<any[]>([]);
  const [bars, setBars] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [trades, setTrades] = useState<any[]>([]);
  const [portfolio, setPortfolio] = useState<any>({});
  const [metalLedger, setMetalLedger] = useState<any[]>([]);
  const [cashLedger, setCashLedger] = useState<any[]>([]);
  const [reconciliation, setReconciliation] = useState<any>({ status: 'BALANCED', executionsCount: 0, totalMetalLedgerOz: 35000, totalVaultBarOz: 35000 });
  const [riskData, setRiskData] = useState<any>(null);

  // Modals
  const [isQuickOrderOpen, setIsQuickOrderOpen] = useState(false);
  const [isAiQuantOpen, setIsAiQuantOpen] = useState(false);

  // Primary Data Fetcher
  const fetchAllEngineData = async () => {
    try {
      // 1. Markets
      const mktsRes = await fetch('/api/v1/markets');
      const mktsData = await mktsRes.json();
      setSpotQuotes(mktsData.spotQuotes || {});
      setLbmaBenchmarks(mktsData.lbmaBenchmarks || []);
      setRegionalPremiums(mktsData.regionalPremiums || []);
      if (mktsData.spotQuotes?.USD) {
        setSpotUsd(mktsData.spotQuotes.USD.mid);
      }

      // 2. Orderbook & Time and Sales
      const obRes = await fetch('/api/v1/orderbook');
      const obData = await obRes.json();
      setOrderBook(obData.orderBook || { bids: [], asks: [], spread: 0.2, spreadBps: 0.4 });
      setTimeAndSales(obData.timeAndSales || []);

      // 3. Futures
      const futRes = await fetch('/api/v1/futures');
      const futData = await futRes.json();
      setFuturesCurve(futData);

      // 4. Options
      const optRes = await fetch('/api/v1/options');
      const optData = await optRes.json();
      setOptionsSurface(optData.surface || []);

      // 5. Vaults
      const vltRes = await fetch('/api/v1/vaults');
      const vltData = await vltRes.json();
      setVaults(vltData.vaults || []);
      setBars(vltData.bars || []);

      // 6. Orders
      const ordRes = await fetch('/api/v1/orders');
      const ordData = await ordRes.json();
      setOrders(ordData.orders || []);
      setTrades(ordData.trades || []);

      // 7. Portfolio & Ledgers
      const portRes = await fetch('/api/v1/portfolio');
      const portData = await portRes.json();
      setPortfolio(portData.portfolio || {});
      setMetalLedger(portData.metalLedger || []);
      setCashLedger(portData.cashLedger || []);
      setReconciliation(portData.reconciliation || { status: 'BALANCED' });

      // 8. Risk
      const rskRes = await fetch('/api/v1/risk');
      const rskData = await rskRes.json();
      setRiskData(rskData);
    } catch (err) {
      console.error('Error fetching engine data:', err);
    }
  };

  useEffect(() => {
    fetchAllEngineData();
    const interval = setInterval(fetchAllEngineData, 1200);
    return () => clearInterval(interval);
  }, []);

  // Submit OMS Order Handler
  const handleSubmitOrder = async (
    clientName: string,
    orderType: 'MARKET' | 'LIMIT',
    side: 'BUY' | 'SELL',
    quantityOz: number,
    limitPriceUsd?: number
  ) => {
    try {
      await fetch('/api/v1/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName,
          orderType,
          side,
          quantityOz,
          limitPriceUsd,
          allocatedPhysical: true,
        }),
      });
      fetchAllEngineData();
    } catch (e) {
      console.error('Order submission error:', e);
    }
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-[#F1F5F9] font-sans antialiased flex flex-col">
      {/* Navbar (Top Bar Contract) */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        spotUsd={spotUsd}
        onOpenQuickOrder={() => setIsQuickOrderOpen(true)}
        onOpenAiQuant={() => setIsAiQuantOpen(true)}
      />

      {/* Flagship High-Density Ticker Bar */}
      <TickerBar spotUsd={spotUsd} />

      {/* Main Terminal Workspace */}
      <main className="flex-1 max-w-[1800px] w-full mx-auto p-4 md:p-6 space-y-6">
        {activeTab === 'MARKETS' && (
          <MarketsView
            spotQuotes={spotQuotes}
            lbmaBenchmarks={lbmaBenchmarks}
            regionalPremiums={regionalPremiums}
            spotUsd={spotUsd}
          />
        )}

        {activeTab === 'TRADING' && (
          <TradingRfqView
            orderBook={orderBook}
            timeAndSales={timeAndSales}
            orders={orders}
            trades={trades}
            spotUsd={spotUsd}
            onSubmitOrder={handleSubmitOrder}
          />
        )}

        {activeTab === 'FUTURES' && (
          <FuturesCurveView
            curveData={futuresCurve}
            spotUsd={spotUsd}
          />
        )}

        {activeTab === 'OPTIONS' && (
          <OptionsLabView
            surface={optionsSurface}
            spotUsd={spotUsd}
          />
        )}

        {activeTab === 'VAULT' && (
          <VaultDigitalTwinView
            vaults={vaults}
            bars={bars}
            spotUsd={spotUsd}
          />
        )}

        {activeTab === 'PORTFOLIO' && (
          <PortfolioLedgerView
            portfolio={portfolio}
            metalLedger={metalLedger}
            cashLedger={cashLedger}
            reconciliation={reconciliation}
            spotUsd={spotUsd}
          />
        )}

        {activeTab === 'RISK' && riskData && (
          <RiskMacroView
            var99={riskData.var99}
            var95={riskData.var95}
            var999={riskData.var999}
            stressScenarios={riskData.stress}
            factorAttribution={riskData.factorAttribution}
            crossAssetRatios={riskData.crossAssetRatios}
            spotUsd={spotUsd}
          />
        )}

        {activeTab === 'QUANT' && (
          <QuantLabView spotUsd={spotUsd} />
        )}

        {activeTab === 'REPORTS' && (
          <ReportsCliView spotUsd={spotUsd} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#0B132B] border-t border-[#1E293B] py-3 px-6 text-xs font-mono text-[#64748B]">
        <div className="max-w-[1800px] mx-auto flex flex-wrap justify-between items-center gap-4">
          <div>
            RHINOQUANT GOLD (RQ-GOLD) · Institutional Gold Trading & Quantitative Research Platform
          </div>
          <div>
            Synthetic Market Simulator Mode · All Calculations Deterministic · LBMA / COMEX Adapter Proxies
          </div>
        </div>
      </footer>

      {/* Modals */}
      <QuickOrderModal
        isOpen={isQuickOrderOpen}
        onClose={() => setIsQuickOrderOpen(false)}
        spotUsd={spotUsd}
        onSubmitOrder={handleSubmitOrder}
      />

      <AiQuantModal
        isOpen={isAiQuantOpen}
        onClose={() => setIsAiQuantOpen(false)}
        spotUsd={spotUsd}
      />
    </div>
  );
}
