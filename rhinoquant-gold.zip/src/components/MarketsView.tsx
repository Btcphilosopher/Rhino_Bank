/**
 * RHINOQUANT GOLD - Markets & OTC Pricing Matrix View
 * Spot XAU across 11 currencies, Unit & Purity Engine, LBMA Benchmarks & Regional Physical Premiums.
 */

import React, { useState } from 'react';
import { MarketObservation, LBMABenchmark, RegionalPremium } from '../engine/market';
import { GoldUnit, GoldPurity, convertGoldQuantity, calculateFineGold } from '../engine/units';
import { ArrowUpRight, ArrowDownRight, Globe, Scale, RefreshCw, Layers } from 'lucide-react';

interface MarketsViewProps {
  spotQuotes: Record<string, MarketObservation>;
  lbmaBenchmarks: LBMABenchmark[];
  regionalPremiums: RegionalPremium[];
  spotUsd: number;
}

export const MarketsView: React.FC<MarketsViewProps> = ({
  spotQuotes,
  lbmaBenchmarks,
  regionalPremiums,
  spotUsd,
}) => {
  // Unit & Purity Normalizer State
  const [calcQty, setCalcQty] = useState<number>(100);
  const [calcUnit, setCalcUnit] = useState<GoldUnit>('oz');
  const [calcPurity, setCalcPurity] = useState<GoldPurity>(999.9);

  const convertedUnits = convertGoldQuantity(calcQty, calcUnit);
  const fineCalculation = calculateFineGold(convertedUnits.grams, calcPurity);

  // Candlestick chart simulation interval
  const [chartInterval, setChartInterval] = useState<'1M' | '5M' | '1H' | '1D' | '1W'>('1D');

  return (
    <div className="space-y-6">
      {/* Top Overview Cards & Candlestick Hero */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Spot Chart Container */}
        <div className="lg:col-span-2 bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-cinzel text-lg font-bold text-[#F8FAFC]">XAU / USD - Spot Gold</h2>
                <span className="text-xs font-mono text-[#D4AF37] bg-[#161F38] px-2 py-0.5 rounded border border-[#1E293B]">
                  London OTC
                </span>
              </div>
              <div className="flex items-center gap-3 mt-1 text-xs font-mono">
                <span className="text-2xl font-bold text-[#F8FAFC] tabular-nums">${spotUsd.toFixed(2)}</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-0.5">
                  <ArrowUpRight className="w-4 h-4" /> +$60.20 (+1.26%)
                </span>
                <span className="text-[#64748B]">High: ${(spotUsd + 28.5).toFixed(2)}</span>
                <span className="text-[#64748B]">Low: ${(spotUsd - 15.0).toFixed(2)}</span>
              </div>
            </div>

            {/* Interval Toggles */}
            <div className="flex items-center gap-1 bg-[#090D16] p-1 rounded border border-[#1E293B] text-xs font-mono">
              {(['1M', '5M', '1H', '1D', '1W'] as const).map((interval) => (
                <button
                  key={interval}
                  onClick={() => setChartInterval(interval)}
                  className={`px-2.5 py-1 rounded transition-colors ${
                    chartInterval === interval
                      ? 'bg-[#1E293B] text-[#D4AF37] font-bold'
                      : 'text-[#94A3B8] hover:text-[#F8FAFC]'
                  }`}
                >
                  {interval}
                </button>
              ))}
            </div>
          </div>

          {/* SVG Candlestick Chart Simulation */}
          <div className="h-64 relative bg-[#090D16] rounded border border-[#1E293B] p-2 flex flex-col justify-between overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-20" />
            
            <svg className="w-full h-full relative z-10" viewBox="0 0 600 200" preserveAspectRatio="none">
              {/* Grid lines */}
              <line x1="0" y1="40" x2="600" y2="40" stroke="#1E293B" strokeDasharray="4 4" />
              <line x1="0" y1="80" x2="600" y2="80" stroke="#1E293B" strokeDasharray="4 4" />
              <line x1="0" y1="120" x2="600" y2="120" stroke="#1E293B" strokeDasharray="4 4" />
              <line x1="0" y1="160" x2="600" y2="160" stroke="#1E293B" strokeDasharray="4 4" />

              {/* Simulated Candlesticks */}
              {Array.from({ length: 32 }).map((_, i) => {
                const x = 12 + i * 18.5;
                const base = 120 - Math.sin(i * 0.3) * 35 - i * 0.8;
                const open = base + (Math.sin(i * 1.5) * 8);
                const close = base + (Math.cos(i * 1.8) * 9);
                const high = Math.max(open, close) + Math.random() * 8 + 2;
                const low = Math.min(open, close) - Math.random() * 8 - 2;
                const isGreen = close >= open;

                return (
                  <g key={i}>
                    {/* Wick */}
                    <line
                      x1={x}
                      y1={200 - high}
                      x2={x}
                      y2={200 - low}
                      stroke={isGreen ? '#10B981' : '#F43F5E'}
                      strokeWidth="1.2"
                    />
                    {/* Candle Body */}
                    <rect
                      x={x - 4}
                      y={200 - Math.max(open, close)}
                      width="8"
                      height={Math.max(2, Math.abs(close - open))}
                      fill={isGreen ? '#10B981' : '#F43F5E'}
                      rx="1"
                    />
                  </g>
                );
              })}

              {/* Moving Average Line */}
              <path
                d="M 12 110 Q 150 140 300 90 T 580 60"
                fill="none"
                stroke="#D4AF37"
                strokeWidth="1.8"
                opacity="0.85"
              />
            </svg>

            <div className="flex items-center justify-between text-[11px] font-mono text-[#64748B] z-10 px-2 pt-1 border-t border-[#1E293B]">
              <span>09:00 AM</span>
              <span>12:00 PM</span>
              <span>03:00 PM</span>
              <span>06:00 PM</span>
              <span>09:00 PM GMT</span>
            </div>
          </div>
        </div>

        {/* Unit & Purity Engine Calculator */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4">
          <div className="flex items-center gap-2 border-b border-[#1E293B] pb-2">
            <Scale className="w-4 h-4 text-[#D4AF37]" />
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">Gold Price & Purity Engine</h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-[#94A3B8] block mb-1 font-mono">Quantity</label>
              <input
                type="number"
                value={calcQty}
                onChange={(e) => setCalcQty(Math.max(0.01, parseFloat(e.target.value) || 0))}
                className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 font-mono text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[#94A3B8] block mb-1 font-mono">Unit</label>
                <select
                  value={calcUnit}
                  onChange={(e) => setCalcUnit(e.target.value as GoldUnit)}
                  className="w-full bg-[#090D16] border border-[#1E293B] rounded px-2.5 py-1.5 font-mono text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
                >
                  <option value="oz">Troy Ounce (oz)</option>
                  <option value="g">Gram (g)</option>
                  <option value="kg">Kilogram (kg)</option>
                  <option value="tonne">Metric Tonne (t)</option>
                  <option value="dwt">Pennyweight (dwt)</option>
                  <option value="tola">Indian Tola</option>
                  <option value="tael">HK Tael</option>
                </select>
              </div>

              <div>
                <label className="text-[#94A3B8] block mb-1 font-mono">Purity</label>
                <select
                  value={calcPurity}
                  onChange={(e) => setCalcPurity(parseFloat(e.target.value) as GoldPurity)}
                  className="w-full bg-[#090D16] border border-[#1E293B] rounded px-2.5 py-1.5 font-mono text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
                >
                  <option value={999.9}>999.9 (Four Nines / Fine)</option>
                  <option value={999.0}>999.0 (Three Nines)</option>
                  <option value={995.0}>995.0 (LBMA Standard)</option>
                  <option value={916.7}>916.7 (22 Karat Crown)</option>
                  <option value={750.0}>750.0 (18 Karat)</option>
                  <option value={585.0}>585.0 (14 Karat)</option>
                </select>
              </div>
            </div>

            {/* Calculation Output Box */}
            <div className="bg-[#090D16] border border-[#1E293B] rounded p-3 space-y-2 font-mono text-[11px] tabular-nums">
              <div className="flex justify-between border-b border-[#1E293B]/60 pb-1">
                <span className="text-[#64748B]">Fine Troy Ounces:</span>
                <span className="text-[#D4AF37] font-bold">{fineCalculation.fineWeightTroyOz.toLocaleString()} oz</span>
              </div>
              <div className="flex justify-between border-b border-[#1E293B]/60 pb-1">
                <span className="text-[#64748B]">Fine Weight (Grams):</span>
                <span className="text-[#F8FAFC]">{fineCalculation.fineWeightGrams.toLocaleString()} g</span>
              </div>
              <div className="flex justify-between border-b border-[#1E293B]/60 pb-1">
                <span className="text-[#64748B]">Fine Weight (Kilograms):</span>
                <span className="text-[#F8FAFC]">{(fineCalculation.fineWeightGrams / 1000).toFixed(4)} kg</span>
              </div>
              <div className="flex justify-between pt-1">
                <span className="text-[#94A3B8]">Est. USD Value:</span>
                <span className="text-emerald-400 font-bold text-sm">
                  ${(fineCalculation.fineWeightTroyOz * spotUsd).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Spot Quotes Across 11 Currencies Table */}
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-[#D4AF37]" />
            <h3 className="font-cinzel text-base font-bold text-[#F8FAFC]">XAU Spot Matrix (11 International Currencies)</h3>
          </div>
          <span className="text-xs font-mono text-[#64748B]">Real-time Normalised Cross-Rates</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono tabular-nums">
            <thead>
              <tr className="border-b border-[#1E293B] text-[#64748B] uppercase">
                <th className="py-2.5 px-3">Currency Pair</th>
                <th className="py-2.5 px-3">Bid</th>
                <th className="py-2.5 px-3">Ask</th>
                <th className="py-2.5 px-3">Mid / Oz</th>
                <th className="py-2.5 px-3">Gram Equivalent</th>
                <th className="py-2.5 px-3">24h Change</th>
                <th className="py-2.5 px-3">Venue</th>
                <th className="py-2.5 px-3">Quality</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]/60 text-[#F8FAFC]">
              {Object.entries(spotQuotes).map(([curr, obs]) => {
                const gramPrice = (obs.mid / 31.1035).toFixed(2);
                return (
                  <tr key={curr} className="hover:bg-[#161F38] transition-colors">
                    <td className="py-2.5 px-3 font-bold text-[#D4AF37]">{obs.instrument}</td>
                    <td className="py-2.5 px-3 text-[#94A3B8]">{obs.bid.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-[#94A3B8]">{obs.ask.toLocaleString()}</td>
                    <td className="py-2.5 px-3 font-semibold">{obs.mid.toLocaleString()} {curr}</td>
                    <td className="py-2.5 px-3 text-[#94A3B8]">{gramPrice} {curr}/g</td>
                    <td className="py-2.5 px-3 text-emerald-400">+{obs.change24hPct}%</td>
                    <td className="py-2.5 px-3 text-[#64748B]">{obs.venue}</td>
                    <td className="py-2.5 px-3">
                      <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-1.5 py-0.5 rounded">
                        {obs.quality}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* LBMA Benchmarks & Regional Physical Premiums Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* LBMA Benchmarks */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">LBMA Gold Price Benchmark Service</h3>
            <span className="text-[11px] font-mono text-[#D4AF37]">ICE Benchmark Admin Proxy</span>
          </div>

          <div className="space-y-2">
            {lbmaBenchmarks.map((bm, idx) => (
              <div key={idx} className="bg-[#090D16] border border-[#1E293B] p-3 rounded flex items-center justify-between font-mono text-xs">
                <div>
                  <div className="text-[#F8FAFC] font-semibold">{bm.benchmarkName}</div>
                  <div className="text-[11px] text-[#64748B]">{bm.source} · {bm.licenceStatus}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-[#D4AF37]">${bm.priceOz.toLocaleString()} / oz</div>
                  <div className="text-[10px] text-[#94A3B8]">Fixing Currency: {bm.currency}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Regional Premiums */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">Regional Gold Physical Premiums</h3>
            <span className="text-[11px] font-mono text-[#64748B]">Physical vs Benchmark</span>
          </div>

          <div className="overflow-x-auto max-h-52 overflow-y-auto">
            <table className="w-full text-left text-xs font-mono tabular-nums">
              <thead>
                <tr className="border-b border-[#1E293B] text-[#64748B]">
                  <th className="py-2 px-2">Region</th>
                  <th className="py-2 px-2">Local Price</th>
                  <th className="py-2 px-2">USD Eq/Oz</th>
                  <th className="py-2 px-2">Premium/Oz</th>
                  <th className="py-2 px-2">Inventory</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]/60 text-[#F8FAFC]">
                {regionalPremiums.map((reg) => (
                  <tr key={reg.region} className="hover:bg-[#161F38]">
                    <td className="py-2 px-2 font-semibold text-[#D4AF37]">{reg.region}</td>
                    <td className="py-2 px-2">{reg.localPrice.toLocaleString()} {reg.currency}/{reg.unit}</td>
                    <td className="py-2 px-2">${reg.usdEquivalentOz.toLocaleString()}</td>
                    <td className={`py-2 px-2 font-semibold ${reg.premiumUsdOz >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {reg.premiumUsdOz >= 0 ? `+$${reg.premiumUsdOz.toFixed(2)}` : `-$${Math.abs(reg.premiumUsdOz).toFixed(2)}`}
                    </td>
                    <td className="py-2 px-2">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded border ${
                        reg.inventoryLevel === 'TIGHT' || reg.inventoryLevel === 'DEFICIT'
                          ? 'bg-rose-950 text-rose-400 border-rose-800'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}>
                        {reg.inventoryLevel}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
