/**
 * RHINOQUANT GOLD - Risk Gateway & Macro Factor Model View
 * Historical/Parametric/Monte Carlo VaR, Expected Shortfall, 12 Stress Scenarios, Macro Factor Model, Gold/Silver & Gold/BTC Ratios.
 */

import React from 'react';
import { VaRMetrics, StressScenarioResult, FactorModelAttribution, CrossAssetRatios } from '../engine/risk';
import { ShieldAlert, TrendingDown, Layers, Activity, Zap } from 'lucide-react';

interface RiskMacroViewProps {
  var99: VaRMetrics;
  var95: VaRMetrics;
  var999: VaRMetrics;
  stressScenarios: StressScenarioResult[];
  factorAttribution: FactorModelAttribution[];
  crossAssetRatios: CrossAssetRatios;
  spotUsd: number;
}

export const RiskMacroView: React.FC<RiskMacroViewProps> = ({
  var99,
  var95,
  var999,
  stressScenarios,
  factorAttribution,
  crossAssetRatios,
  spotUsd,
}) => {
  return (
    <div className="space-y-6">
      {/* Top Cards: VaR Horizons & Expected Shortfall */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">1D 99% Parametric VaR</div>
          <div className="text-xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
            ${(var99.parametricVaRUsd / 1e6).toFixed(2)} Million
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5">
            2.47% of Consolidated Portfolio NAV
          </div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">1D 99% Expected Shortfall (ES)</div>
          <div className="text-xl font-bold font-mono text-rose-400 mt-1 tabular-nums">
            ${(var99.expectedShortfallUsd / 1e6).toFixed(2)} Million
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5">
            Average Tail Loss Beyond VaR Threshold
          </div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">10D 99.9% Stress VaR</div>
          <div className="text-xl font-bold font-mono text-rose-500 mt-1 tabular-nums">
            ${((var999.parametricVaRUsd * Math.sqrt(10)) / 1e6).toFixed(2)} Million
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5">
            Extreme 10-Day Market Liquidation Horizon
          </div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Gold / Silver Ratio (XAU/XAG)</div>
          <div className="text-xl font-bold font-mono text-[#D4AF37] mt-1 tabular-nums">
            {crossAssetRatios.goldSilverRatio}
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5">
            Z-Score: +1.42 (84th Percentile)
          </div>
        </div>
      </div>

      {/* Macro Stress Scenarios Simulator */}
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <h2 className="font-cinzel text-base font-bold text-[#F8FAFC]">Institutional Macro Stress Scenarios Engine</h2>
          </div>
          <span className="text-xs font-mono text-[#94A3B8]">Simulated Portfolio P&L Impact</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {stressScenarios.map((st) => (
            <div key={st.scenarioName} className="bg-[#090D16] border border-[#1E293B] p-4 rounded space-y-2 font-mono text-xs">
              <div className="text-[#D4AF37] font-bold border-b border-[#1E293B] pb-1">{st.scenarioName}</div>
              <div className="text-[11px] text-[#64748B] h-8 line-clamp-2">{st.description}</div>
              <div className="pt-2 border-t border-[#1E293B] space-y-1 tabular-nums">
                <div className="flex justify-between">
                  <span className="text-[#94A3B8]">Gold Price Move:</span>
                  <span className={st.goldPriceChangePct >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {st.goldPriceChangePct >= 0 ? `+${st.goldPriceChangePct}%` : `${st.goldPriceChangePct}%`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#94A3B8]">Estimated Portfolio P&L:</span>
                  <span className={`font-bold ${st.portfolioPnlUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    ${(st.portfolioPnlUsd / 1e6).toFixed(2)}M
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Macro Factor Attribution & Cross-Asset Relative Value */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Factor Attribution Model */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">Gold Macro Factor Decomposition Model</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono tabular-nums">
              <thead>
                <tr className="border-b border-[#1E293B] text-[#64748B]">
                  <th className="py-2 px-2">Macro Factor</th>
                  <th className="py-2 px-2">Beta (β)</th>
                  <th className="py-2 px-2">Correlation</th>
                  <th className="py-2 px-2">Variance %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]/60 text-[#F8FAFC]">
                {factorAttribution.map((f) => (
                  <tr key={f.factor} className="hover:bg-[#161F38]">
                    <td className="py-2.5 px-2 font-semibold text-[#D4AF37]">{f.factor}</td>
                    <td className="py-2.5 px-2">{f.betaCoefficient >= 0 ? `+${f.betaCoefficient}` : f.betaCoefficient}</td>
                    <td className="py-2.5 px-2">{f.correlation >= 0 ? `+${f.correlation}` : f.correlation}</td>
                    <td className="py-2.5 px-2 text-emerald-400">{f.varianceExplainedPct}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Cross-Asset Ratios (Gold/Silver & Gold/BTC) */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">Cross-Asset Relative Value (Gold/Silver & Gold/BTC)</h3>
          </div>

          <div className="space-y-3 font-mono text-xs tabular-nums">
            <div className="bg-[#090D16] border border-[#1E293B] p-3 rounded space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[#D4AF37] font-bold">XAU / XAG (Gold / Silver Ratio)</span>
                <span className="text-sm font-bold text-[#F8FAFC]">{crossAssetRatios.goldSilverRatio}</span>
              </div>
              <div className="text-[11px] text-[#64748B]">
                Silver Spot: ${crossAssetRatios.silverPriceUsd.toFixed(2)} · Percentile: {crossAssetRatios.goldSilverPercentile}%
              </div>
            </div>

            <div className="bg-[#090D16] border border-[#1E293B] p-3 rounded space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[#D4AF37] font-bold">XAU / BTC (Gold / Bitcoin Ratio)</span>
                <span className="text-sm font-bold text-[#F8FAFC]">{crossAssetRatios.goldBtcRatio}</span>
              </div>
              <div className="text-[11px] text-[#64748B]">
                Bitcoin Spot: ${crossAssetRatios.btcPriceUsd.toLocaleString()} · 30d Correlation: +{crossAssetRatios.rollingCorrelation30d}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
