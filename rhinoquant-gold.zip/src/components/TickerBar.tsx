/**
 * RHINOQUANT GOLD - Institutional Flagship Ticker Bar
 * High-density ticker across XAU/USD, XAU/GBP, XAU/HKD, XAU/CNH, Gold/Silver Ratio, GC Front, GC Next, Gold Delta, VaR & P&L.
 */

import React from 'react';
import { TrendingUp, ShieldAlert, Award, DollarSign } from 'lucide-react';

interface TickerBarProps {
  spotUsd: number;
}

export const TickerBar: React.FC<TickerBarProps> = ({ spotUsd }) => {
  const gbpPrice = (spotUsd / 1.272).toFixed(2);
  const hkdPrice = Math.round(spotUsd * 7.821);
  const cnhGramPrice = ((spotUsd * 7.241) / 31.1035).toFixed(2);
  const gcFront = (spotUsd + 2.20).toFixed(2);
  const gcNext = (spotUsd + 15.00).toFixed(2);

  return (
    <div className="bg-[#090D16] border-b border-[#1E293B] px-4 py-2 overflow-x-auto text-xs font-mono tabular-nums select-none">
      <div className="flex items-center justify-between gap-6 min-w-[1200px] max-w-[1800px] mx-auto text-[#94A3B8]">
        {/* XAU/USD */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[#64748B] uppercase">XAU/USD:</span>
          <span className="text-[#F8FAFC] font-bold">${spotUsd.toFixed(2)}</span>
          <span className="text-emerald-400 font-semibold">+1.24%</span>
        </div>

        {/* XAU/GBP */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[#64748B]">XAU/GBP:</span>
          <span className="text-[#F8FAFC]">£{gbpPrice}</span>
        </div>

        {/* XAU/HKD */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[#64748B]">XAU/HKD:</span>
          <span className="text-[#F8FAFC]">HK${hkdPrice.toLocaleString()}</span>
        </div>

        {/* XAU/CNH */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[#64748B]">XAU/CNH:</span>
          <span className="text-[#F8FAFC]">¥{cnhGramPrice}/g</span>
        </div>

        {/* GOLD/SILVER */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[#64748B]">GOLD/SILVER:</span>
          <span className="text-[#F8FAFC]">149.70</span>
        </div>

        {/* GC FRONT */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[#64748B]">GC FRONT:</span>
          <span className="text-[#D4AF37] font-semibold">${gcFront}</span>
        </div>

        {/* GC NEXT */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[#64748B]">GC NEXT:</span>
          <span className="text-[#F8FAFC]">${gcNext}</span>
        </div>

        {/* GOLD DELTA */}
        <div className="flex items-center gap-1.5 shrink-0 bg-[#161F38] px-2 py-0.5 rounded border border-[#1E293B]">
          <span className="text-[#D4AF37]">GOLD DELTA:</span>
          <span className="text-[#F8FAFC] font-bold">+35,000 oz</span>
        </div>

        {/* VaR */}
        <div className="flex items-center gap-1.5 shrink-0 bg-[#161F38] px-2 py-0.5 rounded border border-[#1E293B]">
          <ShieldAlert className="w-3 h-3 text-amber-400" />
          <span className="text-[#64748B]">1D VaR 99%:</span>
          <span className="text-amber-400 font-bold">$4.2M</span>
        </div>

        {/* P&L */}
        <div className="flex items-center gap-1.5 shrink-0 bg-[#161F38] px-2 py-0.5 rounded border border-[#1E293B]">
          <TrendingUp className="w-3 h-3 text-emerald-400" />
          <span className="text-[#64748B]">YTD P&L:</span>
          <span className="text-emerald-400 font-bold">+$1.82M</span>
        </div>
      </div>
    </div>
  );
};
