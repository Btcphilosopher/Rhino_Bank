/**
 * RHINOQUANT GOLD - Futures Curve & Basis Arbitrage View
 * CME Gold Futures term structure (GC Front, GC Next, GC+2, GC+3, GC+6, GC+12, MGC, 1OZ), Calendar Spreads, Basis Arbitrage.
 */

import { FuturesCurveAnalysis } from '../engine/futures';
import { TrendingUp, Layers, ArrowDownUp, Shield, BarChart3 } from 'lucide-react';

interface FuturesCurveViewProps {
  curveData: FuturesCurveAnalysis;
  spotUsd: number;
}

export const FuturesCurveView: React.FC<FuturesCurveViewProps> = ({
  curveData,
  spotUsd,
}) => {
  return (
    <div className="space-y-6">
      {/* Overview Metric Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Market Structure</div>
          <div className="text-lg font-bold font-cinzel text-[#D4AF37] mt-1 flex items-center gap-2">
            <span>{curveData.marketStructure}</span>
            <span className="text-xs font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded">
              Contango Yield: {curveData.rollYieldAnnualisedPct}%
            </span>
          </div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Front Month Basis (GC1 - Spot)</div>
          <div className="text-lg font-bold font-mono text-[#F8FAFC] mt-1 tabular-nums">
            +${curveData.frontMonthBasis.toFixed(2)} / oz
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5">
            Annualised: {curveData.annualisedFrontBasisPct}% p.a.
          </div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Implied Financing Benchmark</div>
          <div className="text-lg font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            5.15% SOFR + 25bps
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5">
            Net Storage Cost: ~0.25% p.a.
          </div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Active COMEX Gold Volume</div>
          <div className="text-lg font-bold font-mono text-[#F8FAFC] mt-1 tabular-nums">
            180,450 Contracts
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5">
            Open Interest: 452,100 ($109B)
          </div>
        </div>
      </div>

      {/* Futures Term Structure SVG Curve */}
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#D4AF37]" />
            <h2 className="font-cinzel text-base font-bold text-[#F8FAFC]">COMEX Gold Futures Term Structure Curve</h2>
          </div>
          <span className="text-xs font-mono text-[#94A3B8]">Price ($/oz) vs Expiry Months</span>
        </div>

        {/* SVG Term Structure Chart */}
        <div className="h-64 relative bg-[#090D16] border border-[#1E293B] rounded p-4 flex flex-col justify-between">
          <svg className="w-full h-full" viewBox="0 0 600 200" preserveAspectRatio="none">
            {/* Grid */}
            <line x1="0" y1="50" x2="600" y2="50" stroke="#1E293B" strokeDasharray="3 3" />
            <line x1="0" y1="100" x2="600" y2="100" stroke="#1E293B" strokeDasharray="3 3" />
            <line x1="0" y1="150" x2="600" y2="150" stroke="#1E293B" strokeDasharray="3 3" />

            {/* Spot Baseline */}
            <line x1="50" y1="170" x2="550" y2="170" stroke="#334155" strokeWidth="1.5" />
            <text x="10" y="174" fill="#64748B" fontSize="10" fontFamily="monospace">Spot</text>

            {/* Curve Line */}
            <path
              d="M 60 170 Q 200 130 350 90 T 540 30"
              fill="none"
              stroke="#D4AF37"
              strokeWidth="3"
            />

            {/* Contract Nodes */}
            {curveData.contracts.slice(0, 5).map((c, i) => {
              const x = 60 + i * 120;
              const y = 170 - (i + 1) * 28;
              return (
                <g key={c.symbol}>
                  <circle cx={x} cy={y} r="6" fill="#D4AF37" stroke="#090D16" strokeWidth="2" />
                  <text x={x - 12} y={y - 12} fill="#F8FAFC" fontSize="11" fontWeight="bold" fontFamily="monospace">
                    ${c.price.toFixed(1)}
                  </text>
                  <text x={x - 10} y={y + 18} fill="#94A3B8" fontSize="10" fontFamily="monospace">
                    {c.symbol}
                  </text>
                </g>
              );
            })}
          </svg>

          <div className="flex justify-between text-[11px] font-mono text-[#64748B] pt-2 border-t border-[#1E293B]">
            <span>SPOT (${spotUsd.toFixed(2)})</span>
            <span>GC1 (1M)</span>
            <span>GC2 (2M)</span>
            <span>GC3 (3M)</span>
            <span>GC6 (6M)</span>
            <span>GC12 (12M)</span>
          </div>
        </div>
      </div>

      {/* Contract Specifications Table & Calendar Spreads */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Full Contract Specifications Table */}
        <div className="lg:col-span-2 bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">Active COMEX Futures Contracts (100oz, 10oz, 1oz)</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono tabular-nums">
              <thead>
                <tr className="border-b border-[#1E293B] text-[#64748B]">
                  <th className="py-2 px-3">Symbol</th>
                  <th className="py-2 px-3">Contract Name</th>
                  <th className="py-2 px-3">Size</th>
                  <th className="py-2 px-3">Expiry</th>
                  <th className="py-2 px-3">Price</th>
                  <th className="py-2 px-3">Basis Usd</th>
                  <th className="py-2 px-3">Ann. Basis %</th>
                  <th className="py-2 px-3">Volume</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]/60 text-[#F8FAFC]">
                {curveData.contracts.map((c) => (
                  <tr key={c.symbol} className="hover:bg-[#161F38]">
                    <td className="py-2.5 px-3 font-bold text-[#D4AF37]">{c.symbol}</td>
                    <td className="py-2.5 px-3 text-[#94A3B8]">{c.name} ({c.expiryCode})</td>
                    <td className="py-2.5 px-3">{c.contractSizeOz} oz</td>
                    <td className="py-2.5 px-3 text-[#64748B]">{c.expiryDate}</td>
                    <td className="py-2.5 px-3 font-semibold">${c.price.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-emerald-400">+${c.basisUsd.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-emerald-400">+{c.annualisedBasisPct}%</td>
                    <td className="py-2.5 px-3 text-[#94A3B8]">{c.volume.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Calendar Spread Arbitrage */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">Calendar Spread Arbitrage Signals</h3>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {curveData.calendarSpreads.map((sp) => (
              <div key={sp.spreadPair} className="bg-[#090D16] border border-[#1E293B] p-3 rounded space-y-1.5">
                <div className="flex justify-between items-center border-b border-[#1E293B] pb-1">
                  <span className="text-[#D4AF37] font-bold">{sp.spreadPair}</span>
                  <span className="text-sm font-bold text-[#F8FAFC]">${sp.spreadPriceUsd.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[#64748B] text-[11px] tabular-nums">
                  <span>Z-Score: {sp.zScore >= 0 ? `+${sp.zScore}` : sp.zScore}</span>
                  <span>Percentile: {sp.percentile}%</span>
                </div>
                <div className="pt-1">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold border ${
                    sp.meanReversionSignal === 'STRONG_SELL'
                      ? 'bg-rose-950 text-rose-400 border-rose-800'
                      : 'bg-emerald-950 text-emerald-400 border-emerald-800'
                  }`}>
                    Signal: {sp.meanReversionSignal}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
