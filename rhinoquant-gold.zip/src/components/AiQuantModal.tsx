/**
 * RHINOQUANT GOLD - AI Quantitative Macro Strategist Modal (Gemini 3.6 Server-Side)
 * Connects to /api/v1/ai-quant endpoint powered by gemini-3.8-flash.
 */

import React, { useState } from 'react';
import { Bot, X, Send, Sparkles, AlertCircle } from 'lucide-react';

interface AiQuantModalProps {
  isOpen: boolean;
  onClose: () => void;
  spotUsd: number;
}

export const AiQuantModal: React.FC<AiQuantModalProps> = ({ isOpen, onClose, spotUsd }) => {
  const [prompt, setPrompt] = useState('');
  const [queryType, setQueryType] = useState<'General Macro' | 'Risk Attribution' | 'Option Hedging' | 'Futures Basis'>('General Macro');
  const [loading, setLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerateAnalysis = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setAiResponse(null);

    try {
      const res = await fetch('/api/v1/ai-quant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, queryType }),
      });
      const data = await res.json();
      if (data.success) {
        setAiResponse(data.text);
      } else {
        setError(data.details || 'Failed to generate AI analysis.');
      }
    } catch (err: any) {
      setError(err?.message || 'Server connection error.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg max-w-2xl w-full p-6 space-y-4 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#94A3B8] hover:text-[#F8FAFC] p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 border-b border-[#1E293B] pb-3">
          <Bot className="w-5 h-5 text-[#D4AF37]" />
          <h2 className="font-cinzel text-lg font-bold text-[#F8FAFC]">Gemini 3.6 AI Quantitative Macro Strategist</h2>
        </div>

        <form onSubmit={handleGenerateAnalysis} className="space-y-3 font-mono text-xs">
          <div>
            <label className="text-[#94A3B8] block mb-1">Analysis Perspective</label>
            <div className="grid grid-cols-4 gap-1">
              {(['General Macro', 'Risk Attribution', 'Option Hedging', 'Futures Basis'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setQueryType(t)}
                  className={`py-1.5 px-2 rounded border transition-all text-center ${
                    queryType === t
                      ? 'bg-[#1E293B] text-[#D4AF37] border-[#D4AF37] font-bold'
                      : 'bg-[#090D16] text-[#94A3B8] border-[#1E293B]'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[#94A3B8] block mb-1">Custom Macro / Risk Query</label>
            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. Analyze current 10Y TIP real yield trends, COMEX futures contango, and recommended collar option hedge for 35,000 oz exposure."
              className="w-full bg-[#090D16] border border-[#1E293B] rounded p-2.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-[#D4AF37] to-[#C5A059] text-[#090D16] font-bold py-2 rounded hover:brightness-110 transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              <Sparkles className="w-4 h-4 animate-spin text-[#090D16]" />
            ) : (
              <Send className="w-4 h-4" />
            )}
            <span>{loading ? 'Generating Analysis...' : 'Generate Institutional Report'}</span>
          </button>
        </form>

        {error && (
          <div className="bg-rose-950/60 border border-rose-800 p-3 rounded text-rose-300 font-mono text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {aiResponse && (
          <div className="bg-[#090D16] border border-[#1E293B] rounded p-4 max-h-72 overflow-y-auto font-mono text-xs text-[#F8FAFC] leading-relaxed whitespace-pre-wrap">
            {aiResponse}
          </div>
        )}
      </div>
    </div>
  );
};
