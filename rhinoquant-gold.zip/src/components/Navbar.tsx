/**
 * RHINOQUANT GOLD - Navigation Bar (Top Bar Contract)
 * Zone 1: Single text wordmark "RHINOQUANT GOLD"
 * Zone 2: Clean navigation links (Markets, Trading & RFQ, Futures & Curve, Options Lab, Physical Vault, Portfolio, Risk & Macro, Quant Lab, Reports & CLI)
 * Zone 3: Live Rate Ticker & Action Buttons
 */

import React from 'react';
import { Activity, Zap, Bot, Shield, Layers } from 'lucide-react';

export type ActiveTab =
  | 'MARKETS'
  | 'TRADING'
  | 'FUTURES'
  | 'OPTIONS'
  | 'VAULT'
  | 'PORTFOLIO'
  | 'RISK'
  | 'QUANT'
  | 'REPORTS';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  spotUsd: number;
  onOpenQuickOrder: () => void;
  onOpenAiQuant: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  spotUsd,
  onOpenQuickOrder,
  onOpenAiQuant,
}) => {
  const navItems: { id: ActiveTab; label: string }[] = [
    { id: 'MARKETS', label: 'Markets' },
    { id: 'TRADING', label: 'Trading & RFQ' },
    { id: 'FUTURES', label: 'Futures & Curve' },
    { id: 'OPTIONS', label: 'Options Lab' },
    { id: 'VAULT', label: 'Physical Vault' },
    { id: 'PORTFOLIO', label: 'Portfolio' },
    { id: 'RISK', label: 'Risk & Macro' },
    { id: 'QUANT', label: 'Quant Lab' },
    { id: 'REPORTS', label: 'Reports & CLI' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#0B132B]/95 backdrop-blur-md border-b border-[#1E293B] px-4 py-2.5">
      <div className="flex items-center justify-between gap-4 max-w-[1800px] mx-auto">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('MARKETS');
          }}
          className="flex items-center gap-2 group shrink-0"
        >
          <div className="w-8 h-8 rounded bg-gradient-to-br from-[#D4AF37] to-[#8A6D1C] flex items-center justify-center font-cinzel font-bold text-[#090D16] text-sm shadow-md">
            RQ
          </div>
          <span className="font-cinzel text-base md:text-lg font-bold tracking-wider text-[#F8FAFC] group-hover:text-[#D4AF37] transition-colors whitespace-nowrap">
            RHINOQUANT GOLD
          </span>
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 overflow-x-auto py-1 text-xs font-medium text-[#94A3B8]">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1.5 rounded transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-[#1E293B] text-[#D4AF37] font-semibold shadow-inner border-b-2 border-[#D4AF37]'
                    : 'hover:text-[#F8FAFC] hover:bg-[#161F38]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions & Live Rates */}
        <div className="flex items-center gap-2 md:gap-3 shrink-0">
          {/* Live Spot Badge */}
          <div className="hidden sm:flex items-center gap-2 bg-[#090D16] border border-[#1E293B] px-2.5 py-1 rounded text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[#94A3B8] font-mono">XAU/USD</span>
            <span className="text-[#F8FAFC] font-mono font-bold tabular-nums">
              ${spotUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-emerald-400 font-mono text-[11px]">+1.24%</span>
          </div>

          {/* Quick Order Button */}
          <button
            onClick={onOpenQuickOrder}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#090D16] bg-gradient-to-r from-[#D4AF37] to-[#C5A059] hover:brightness-110 rounded transition-all shadow-sm whitespace-nowrap"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Quick Order</span>
          </button>

          {/* AI Quant Strategist Trigger */}
          <button
            onClick={onOpenAiQuant}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#F8FAFC] bg-[#1E293B] hover:bg-[#334155] border border-[#334155] rounded transition-all whitespace-nowrap"
          >
            <Bot className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="hidden md:inline">AI Quant Strategist</span>
          </button>
        </div>
      </div>

      {/* Mobile Nav Drawer Row */}
      <div className="flex lg:hidden overflow-x-auto gap-1 mt-2 pt-2 border-t border-[#1E293B] text-xs">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`px-2.5 py-1 rounded whitespace-nowrap ${
              activeTab === item.id
                ? 'bg-[#1E293B] text-[#D4AF37] font-semibold'
                : 'text-[#94A3B8] hover:text-[#F8FAFC]'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>
  );
};
