/**
 * RHINOQUANT GOLD - Quantitative Research, Backtesting & Monte Carlo Lab View
 * Backtester for Momentum, Mean Reversion, Curve Roll Yield; Monte Carlo price path simulator; Python/R notebook interpreter.
 */

import React, { useState } from 'react';
import { BacktestResult, MonteCarloSimulationResult, ResearchNotebookCell } from '../engine/quant';
import { Play, Terminal, LineChart, Cpu, Zap, Code2 } from 'lucide-react';

interface QuantLabViewProps {
  spotUsd: number;
}

export const QuantLabView: React.FC<QuantLabViewProps> = ({ spotUsd }) => {
  const [selectedStrategy, setSelectedStrategy] = useState<BacktestResult['config']['strategyName']>('Gold Momentum');
  const [leverage, setLeverage] = useState<number>(1.0);
  const [backtestResult, setBacktestResult] = useState<BacktestResult | null>(null);
  const [monteCarloResult, setMonteCarloResult] = useState<MonteCarloSimulationResult | null>(null);

  // Run Strategy Backtest
  const handleRunBacktest = async () => {
    try {
      const res = await fetch('/api/v1/backtest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ strategyName: selectedStrategy, leverage, initialCapitalUsd: 10000000 }),
      });
      const data: BacktestResult = await res.json();
      setBacktestResult(data);
    } catch (e) {
      console.error('Backtest error:', e);
    }
  };

  // Run Monte Carlo Simulation
  const handleRunMonteCarlo = async () => {
    try {
      const res = await fetch('/api/v1/monte-carlo');
      const data: MonteCarloSimulationResult = await res.json();
      setMonteCarloResult(data);
    } catch (e) {
      console.error('Monte Carlo error:', e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Strategy Backtesting Module */}
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <LineChart className="w-4 h-4 text-[#D4AF37]" />
            <h2 className="font-cinzel text-base font-bold text-[#F8FAFC]">Quantitative Strategy Backtesting Engine</h2>
          </div>
          <span className="text-xs font-mono text-[#94A3B8]">3-Year Institutional Backtest (2023 - 2026)</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-mono">
          <div>
            <label className="text-[#94A3B8] block mb-1">Strategy Model</label>
            <select
              value={selectedStrategy}
              onChange={(e) => setSelectedStrategy(e.target.value as any)}
              className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
            >
              <option value="Gold Momentum">Gold Momentum Trend Follower</option>
              <option value="Gold Mean Reversion">Gold Mean Reversion Oscillator</option>
              <option value="Futures Curve Roll Yield">Futures Curve Roll Yield Harvester</option>
              <option value="Gold/Silver Ratio Reversion">Gold/Silver Ratio Reversion Arbitrage</option>
              <option value="Gold/Real Yield Arbitrage">Gold vs 10Y Real Yield Arbitrage</option>
            </select>
          </div>

          <div>
            <label className="text-[#94A3B8] block mb-1">Leverage Multiplier</label>
            <select
              value={leverage}
              onChange={(e) => setLeverage(parseFloat(e.target.value))}
              className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
            >
              <option value={1.0}>1.0x (Unleveraged Unallocated Gold)</option>
              <option value={2.0}>2.0x (Comex Futures 50% Margin)</option>
              <option value={3.0}>3.0x (Tactical Derivative Exposure)</option>
            </select>
          </div>

          <div className="flex items-end md:col-span-2">
            <button
              onClick={handleRunBacktest}
              className="w-full bg-gradient-to-r from-[#D4AF37] to-[#C5A059] text-[#090D16] font-bold py-1.5 px-3 rounded hover:brightness-110 transition-all flex items-center justify-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Execute Strategy Backtest</span>
            </button>
          </div>
        </div>

        {/* Backtest Results Dashboard */}
        {backtestResult && (
          <div className="space-y-4 pt-2 font-mono text-xs">
            <div className="grid grid-cols-2 md:grid-cols-6 gap-3 text-center tabular-nums">
              <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded">
                <div className="text-[#64748B]">Total Return</div>
                <div className="text-base font-bold text-emerald-400 mt-0.5">+{backtestResult.totalReturnPct}%</div>
              </div>
              <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded">
                <div className="text-[#64748B]">Sharpe Ratio</div>
                <div className="text-base font-bold text-[#D4AF37] mt-0.5">{backtestResult.sharpeRatio}</div>
              </div>
              <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded">
                <div className="text-[#64748B]">Sortino Ratio</div>
                <div className="text-base font-bold text-[#F8FAFC] mt-0.5">{backtestResult.sortinoRatio}</div>
              </div>
              <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded">
                <div className="text-[#64748B]">Max Drawdown</div>
                <div className="text-base font-bold text-rose-400 mt-0.5">-{backtestResult.maxDrawdownPct}%</div>
              </div>
              <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded">
                <div className="text-[#64748B]">Win Rate</div>
                <div className="text-base font-bold text-emerald-400 mt-0.5">{backtestResult.winRatePct}%</div>
              </div>
              <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded">
                <div className="text-[#64748B]">Profit Factor</div>
                <div className="text-base font-bold text-[#F8FAFC] mt-0.5">{backtestResult.profitFactor}</div>
              </div>
            </div>

            {/* Equity Curve Chart */}
            <div className="h-44 bg-[#090D16] border border-[#1E293B] rounded p-2 flex flex-col justify-between">
              <svg className="w-full h-full" viewBox="0 0 500 120" preserveAspectRatio="none">
                <path
                  d="M 10 100 Q 150 80 250 50 T 490 15"
                  fill="none"
                  stroke="#10B981"
                  strokeWidth="2.5"
                />
                <path
                  d="M 10 100 Q 150 90 250 70 T 490 40"
                  fill="none"
                  stroke="#64748B"
                  strokeWidth="1.5"
                  strokeDasharray="4 4"
                />
              </svg>
              <div className="flex justify-between text-[10px] text-[#64748B] pt-1 border-t border-[#1E293B]">
                <span>2023 Start ($10.0M)</span>
                <span className="text-emerald-400">Strategy Equity (${(10 * (1 + backtestResult.totalReturnPct / 100)).toFixed(2)}M)</span>
                <span>Benchmark Equity</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Monte Carlo Simulation Lab & Python Research Notebook */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monte Carlo Price Path Lab */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="flex justify-between items-center border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">1,000-Path Monte Carlo Price Simulator</h3>
            <button
              onClick={handleRunMonteCarlo}
              className="bg-[#1E293B] hover:bg-[#334155] text-[#D4AF37] px-2.5 py-1 rounded font-mono text-xs transition-colors"
            >
              Run 1k Simulations
            </button>
          </div>

          {monteCarloResult && (
            <div className="space-y-3 font-mono text-xs tabular-nums">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-[#090D16] border border-[#1E293B] p-2 rounded">
                  <div className="text-[#64748B]">5th Percentile</div>
                  <div className="text-rose-400 font-bold">${monteCarloResult.percentile5thPriceUsd}</div>
                </div>
                <div className="bg-[#090D16] border border-[#1E293B] p-2 rounded">
                  <div className="text-[#64748B]">Mean Final Price</div>
                  <div className="text-[#D4AF37] font-bold">${monteCarloResult.meanFinalPriceUsd}</div>
                </div>
                <div className="bg-[#090D16] border border-[#1E293B] p-2 rounded">
                  <div className="text-[#64748B]">95th Percentile</div>
                  <div className="text-emerald-400 font-bold">${monteCarloResult.percentile95thPriceUsd}</div>
                </div>
              </div>

              <div className="text-right text-[#94A3B8] text-[11px]">
                Probability of Positive Return: <span className="text-emerald-400 font-bold">{monteCarloResult.probabilityOfProfitPct}%</span>
              </div>
            </div>
          )}
        </div>

        {/* Python/R Research Notebook Interpreter Simulation */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="flex justify-between items-center border-b border-[#1E293B] pb-2">
            <div className="flex items-center gap-1.5">
              <Code2 className="w-4 h-4 text-[#D4AF37]" />
              <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">Native Python Quant Notebook</h3>
            </div>
            <span className="text-xs font-mono text-emerald-400">Kernel: Python 3.12 (rq-gold-sdk)</span>
          </div>

          <div className="bg-[#090D16] border border-[#1E293B] rounded p-3 font-mono text-xs space-y-2">
            <div className="text-[#94A3B8]"># Cell 1: Query Gold Basis & VaR</div>
            <pre className="text-emerald-400 text-[11px] leading-relaxed">
              {`import rhinoquant as rq
gold = rq.market("XAUUSD")
print(f"Spot XAU: \${gold.spot_usd:.2f}")
risk = rq.calculate_var(rq.get_portfolio(), 0.99)
print(f"1D 99% VaR: \${risk.parametric_var_usd:,.2f}")`}
            </pre>
            <div className="pt-2 border-t border-[#1E293B] text-[#F8FAFC] text-[11px] font-bold">
              Out [1]: Spot XAU: ${spotUsd.toFixed(2)} | 1D 99% VaR: $4,200,000.00
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
