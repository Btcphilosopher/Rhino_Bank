/**
 * RHINOQUANT GOLD - Quick Order Execution Modal
 */

import React, { useState } from 'react';
import { X, Zap, ShieldCheck } from 'lucide-react';

interface QuickOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  spotUsd: number;
  onSubmitOrder: (
    clientName: string,
    orderType: 'MARKET' | 'LIMIT',
    side: 'BUY' | 'SELL',
    qtyOz: number,
    limitPrice?: number
  ) => void;
}

export const QuickOrderModal: React.FC<QuickOrderModalProps> = ({
  isOpen,
  onClose,
  spotUsd,
  onSubmitOrder,
}) => {
  const [client, setClient] = useState('RhinoQuant Sovereign Desk');
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [qtyOz, setQtyOz] = useState<number>(500);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitOrder(client, 'MARKET', side, qtyOz);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#94A3B8] hover:text-[#F8FAFC] p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 border-b border-[#1E293B] pb-3">
          <Zap className="w-5 h-5 text-[#D4AF37]" />
          <h2 className="font-cinzel text-lg font-bold text-[#F8FAFC]">Quick Order Execution</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 font-mono text-xs">
          <div>
            <label className="text-[#94A3B8] block mb-1">Entity Account</label>
            <input
              type="text"
              value={client}
              onChange={(e) => setClient(e.target.value)}
              className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[#94A3B8] block mb-1">Side</label>
              <select
                value={side}
                onChange={(e) => setSide(e.target.value as 'BUY' | 'SELL')}
                className="w-full bg-[#090D16] border border-[#1E293B] rounded px-2.5 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
              >
                <option value="BUY">BUY GOLD</option>
                <option value="SELL">SELL GOLD</option>
              </select>
            </div>

            <div>
              <label className="text-[#94A3B8] block mb-1">Quantity (Troy Oz)</label>
              <input
                type="number"
                value={qtyOz}
                onChange={(e) => setQtyOz(parseFloat(e.target.value) || 100)}
                className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>
          </div>

          <div className="bg-[#090D16] border border-[#1E293B] p-3 rounded space-y-1 tabular-nums text-[11px]">
            <div className="flex justify-between text-[#64748B]">
              <span>Spot Reference Price:</span>
              <span className="text-[#F8FAFC]">${spotUsd.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-[#64748B]">
              <span>Total Notional:</span>
              <span className="text-[#D4AF37] font-bold">${(qtyOz * spotUsd).toLocaleString()}</span>
            </div>
          </div>

          <button
            type="submit"
            className={`w-full py-2 px-4 rounded font-bold transition-all text-xs ${
              side === 'BUY' ? 'bg-emerald-600 hover:bg-emerald-500 text-white' : 'bg-rose-600 hover:bg-rose-500 text-white'
            }`}
          >
            Confirm & Execute {side} {qtyOz} oz
          </button>
        </form>
      </div>
    </div>
  );
};
