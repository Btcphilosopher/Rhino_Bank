/**
 * RHINOQUANT GOLD - Physical Bullion Vault Digital Twin & Refinery View
 * 12 Global Vault Digital Twins, Spatial Bar Registry (32,480+ bars simulated), Allocated vs Unallocated dual-ledger, Refinery XRF Assay Simulator.
 */

import React, { useState } from 'react';
import { GoldBar, VaultLocation, RefineryBatch } from '../engine/physical';
import { Building2, Box, ShieldCheck, Flame, Scale, Search, CheckCircle2 } from 'lucide-react';

interface VaultDigitalTwinViewProps {
  vaults: VaultLocation[];
  bars: GoldBar[];
  spotUsd: number;
}

export const VaultDigitalTwinView: React.FC<VaultDigitalTwinViewProps> = ({
  vaults,
  bars,
  spotUsd,
}) => {
  const [selectedVaultId, setSelectedVaultId] = useState<string>(vaults[0]?.vaultId || '');
  const [allocatedFilter, setAllocatedFilter] = useState<'ALL' | 'ALLOCATED' | 'UNALLOCATED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Refinery State
  const [feedstock, setFeedstock] = useState<RefineryBatch['sourceFeedstock']>('Doré Bars');
  const [inputKg, setInputKg] = useState<number>(100);
  const [activeRefineryBatch, setActiveRefineryBatch] = useState<RefineryBatch | null>(null);

  const selectedVault = vaults.find((v) => v.vaultId === selectedVaultId) || vaults[0];

  const filteredBars = bars.filter((bar) => {
    if (allocatedFilter === 'ALLOCATED' && !bar.allocatedToClient) return false;
    if (allocatedFilter === 'UNALLOCATED' && bar.allocatedToClient) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        bar.serialNumber.toLowerCase().includes(q) ||
        bar.refiner.toLowerCase().includes(q) ||
        bar.owner.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleRunRefineryBatch = async () => {
    try {
      const res = await fetch('/api/v1/refinery/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ feedstock, inputKg }),
      });
      const data: RefineryBatch = await res.json();
      setActiveRefineryBatch(data);
    } catch (e) {
      console.error('Refinery batch failed:', e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Overview Cards Across 12 Global Vaults */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Total Physical Bullion Stored</div>
          <div className="text-xl font-bold font-cinzel text-[#D4AF37] mt-1">1,284,500 troy oz</div>
          <div className="text-xs text-[#94A3B8] font-mono mt-0.5">39.95 Metric Tonnes</div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Allocated vs Unallocated</div>
          <div className="text-xl font-bold font-mono text-[#F8FAFC] mt-1 tabular-nums">840,000 / 444,500 oz</div>
          <div className="text-xs text-[#94A3B8] font-mono mt-0.5">65.4% Allocated to Clients</div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Total Vault Inventory Valuation</div>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            ${((1284500 * spotUsd) / 1e9).toFixed(2)} Billion
          </div>
          <div className="text-xs text-[#94A3B8] font-mono mt-0.5">@ ${spotUsd.toFixed(2)}/oz Spot</div>
        </div>

        <div className="bg-[#0B132B] border border-[#1E293B] p-4 rounded-lg">
          <div className="text-xs text-[#64748B] font-mono">Active Global Vault Hubs</div>
          <div className="text-xl font-bold font-mono text-[#F8FAFC] mt-1 tabular-nums">12 Secure Depositories</div>
          <div className="text-xs text-emerald-400 font-mono mt-0.5">Class AAAA Military Depository</div>
        </div>
      </div>

      {/* Global Vault Hub Selector Bar */}
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#D4AF37]" />
            <h2 className="font-cinzel text-base font-bold text-[#F8FAFC]">Global Physical Vault Digital Twins</h2>
          </div>
          <span className="text-xs font-mono text-[#94A3B8]">Select Vault Depository for Drill-down</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
          {vaults.map((v) => (
            <button
              key={v.vaultId}
              onClick={() => setSelectedVaultId(v.vaultId)}
              className={`p-2.5 rounded border text-left transition-all font-mono text-xs ${
                selectedVault.vaultId === v.vaultId
                  ? 'bg-[#1E293B] text-[#D4AF37] border-[#D4AF37] font-bold shadow'
                  : 'bg-[#090D16] text-[#94A3B8] border-[#1E293B] hover:text-[#F8FAFC]'
              }`}
            >
              <div className="text-xs font-semibold">{v.city} Hub</div>
              <div className="text-[10px] text-[#64748B] truncate">{v.operator}</div>
              <div className="text-[10px] text-emerald-400 mt-1">{v.occupiedWeightTonnes}t Stored</div>
            </button>
          ))}
        </div>
      </div>

      {/* Vault Spatial Rack & Bar Registry Drilldown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Selected Vault Infrastructure Detail */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-base font-bold text-[#D4AF37]">{selectedVault.name}</h3>
            <span className="text-xs font-mono text-[#64748B]">{selectedVault.city}, {selectedVault.country}</span>
          </div>

          <div className="space-y-2 font-mono text-xs tabular-nums">
            <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded flex justify-between">
              <span className="text-[#64748B]">Vault Operator:</span>
              <span className="text-[#F8FAFC] font-semibold">{selectedVault.operator}</span>
            </div>
            <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded flex justify-between">
              <span className="text-[#64748B]">Capacity Usage:</span>
              <span className="text-[#F8FAFC]">{selectedVault.occupiedWeightTonnes}t / {selectedVault.totalCapacityTonnes}t ({Math.round((selectedVault.occupiedWeightTonnes / selectedVault.totalCapacityTonnes) * 100)}%)</span>
            </div>
            <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded flex justify-between">
              <span className="text-[#64748B]">Total Bars Stored:</span>
              <span className="text-[#D4AF37] font-bold">{selectedVault.totalBarCount.toLocaleString()} Bars</span>
            </div>
            <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded flex justify-between">
              <span className="text-[#64748B]">Allocated / Unallocated:</span>
              <span className="text-emerald-400">{selectedVault.allocatedBarCount} / {selectedVault.unallocatedBarCount}</span>
            </div>
          </div>

          {/* Spatial Rack Visual Map Grid */}
          <div className="bg-[#090D16] border border-[#1E293B] rounded p-3 space-y-2">
            <div className="text-xs font-mono text-[#D4AF37] font-bold">Spatial Vault Rack Map</div>
            <div className="grid grid-cols-4 gap-1.5">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className="bg-[#161F38] border border-[#1E293B] p-2 rounded text-center font-mono text-[10px] hover:border-[#D4AF37] transition-all cursor-pointer"
                >
                  <div className="text-[#94A3B8]">Rack {i + 10}</div>
                  <div className="text-emerald-400 font-bold">100% Full</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Individual Bar Registry Table */}
        <div className="lg:col-span-2 bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
            <h3 className="font-cinzel text-base font-bold text-[#F8FAFC]">Physical Gold Bar Inspector & Serial Registry</h3>

            {/* Filter controls */}
            <div className="flex items-center gap-2 font-mono text-xs">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-[#64748B] absolute left-2.5 top-2" />
                <input
                  type="text"
                  placeholder="Search Serial / Refiner / Owner..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-[#090D16] border border-[#1E293B] rounded pl-8 pr-3 py-1 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none w-48 text-xs"
                />
              </div>

              <select
                value={allocatedFilter}
                onChange={(e) => setAllocatedFilter(e.target.value as any)}
                className="bg-[#090D16] border border-[#1E293B] rounded px-2 py-1 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none text-xs"
              >
                <option value="ALL">All Statuses</option>
                <option value="ALLOCATED">Allocated Only</option>
                <option value="UNALLOCATED">Unallocated Only</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto max-h-80 overflow-y-auto">
            <table className="w-full text-left text-xs font-mono tabular-nums">
              <thead>
                <tr className="border-b border-[#1E293B] text-[#64748B]">
                  <th className="py-2 px-3">Serial Number</th>
                  <th className="py-2 px-3">Refiner / Brand</th>
                  <th className="py-2 px-3">Fine Weight</th>
                  <th className="py-2 px-3">Purity</th>
                  <th className="py-2 px-3">Location</th>
                  <th className="py-2 px-3">Owner</th>
                  <th className="py-2 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]/60 text-[#F8FAFC]">
                {filteredBars.slice(0, 15).map((bar) => (
                  <tr key={bar.barId} className="hover:bg-[#161F38]">
                    <td className="py-2 px-3 font-bold text-[#D4AF37]">{bar.serialNumber}</td>
                    <td className="py-2 px-3 text-[#94A3B8]">{bar.refiner}</td>
                    <td className="py-2 px-3 font-semibold">{bar.fineWeightTroyOz} oz</td>
                    <td className="py-2 px-3">{bar.purity}</td>
                    <td className="py-2 px-3 text-[#64748B]">{bar.location.zone} / {bar.location.rackId}</td>
                    <td className="py-2 px-3 text-[#94A3B8] truncate max-w-[140px]">{bar.owner}</td>
                    <td className="py-2 px-3">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded border ${
                        bar.allocatedToClient
                          ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border-amber-800'
                      }`}>
                        {bar.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Refinery Digital Twin & XRF Assay Simulator */}
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-[#D4AF37]" />
            <h2 className="font-cinzel text-base font-bold text-[#F8FAFC]">Refinery Digital Twin & XRF Assay Engine</h2>
          </div>
          <span className="text-xs font-mono text-[#D4AF37]">Doré / Scrap Processing into 400oz Good Delivery Bars</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
          <div>
            <label className="text-[#94A3B8] block mb-1">Source Feedstock</label>
            <select
              value={feedstock}
              onChange={(e) => setFeedstock(e.target.value as any)}
              className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
            >
              <option value="Doré Bars">Mining Doré Bars (88.5% Au)</option>
              <option value="E-Waste Scrap">Industrial E-Waste Scrap (45% Au)</option>
              <option value="Jewellery Scrap">Jewellery Scrap (75% Au)</option>
            </select>
          </div>

          <div>
            <label className="text-[#94A3B8] block mb-1">Input Weight (Kilograms)</label>
            <input
              type="number"
              value={inputKg}
              onChange={(e) => setInputKg(parseFloat(e.target.value) || 10)}
              className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
            />
          </div>

          <div className="flex items-end md:col-span-2">
            <button
              onClick={handleRunRefineryBatch}
              className="w-full bg-gradient-to-r from-[#D4AF37] to-[#C5A059] text-[#090D16] font-bold py-1.5 px-3 rounded hover:brightness-110 transition-all"
            >
              Simulate Processing, XRF Assay & Casting Batch
            </button>
          </div>
        </div>

        {activeRefineryBatch && (
          <div className="bg-[#090D16] border border-[#1E293B] p-4 rounded space-y-2 font-mono text-xs tabular-nums">
            <div className="flex justify-between border-b border-[#1E293B] pb-2">
              <span className="text-[#D4AF37] font-bold">{activeRefineryBatch.batchId}</span>
              <span className="text-emerald-400 font-bold">XRF Assay Verified: 999.9 Fine Gold</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px] pt-1">
              <div>
                <span className="text-[#64748B] block">Input Weight:</span>
                <span className="text-[#F8FAFC] font-bold">{(activeRefineryBatch.inputWeightGrams / 1000).toFixed(1)} kg</span>
              </div>
              <div>
                <span className="text-[#64748B] block">Recovered Fine Gold:</span>
                <span className="text-emerald-400 font-bold">{(activeRefineryBatch.expectedFineGoldGrams / 1000).toFixed(3)} kg</span>
              </div>
              <div>
                <span className="text-[#64748B] block">Good Delivery 400oz Bars:</span>
                <span className="text-[#D4AF37] font-bold">{activeRefineryBatch.output400ozBarCount} Bars</span>
              </div>
              <div>
                <span className="text-[#64748B] block">Processing Fee:</span>
                <span className="text-[#F8FAFC]">${activeRefineryBatch.processingCostUsd.toLocaleString()}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
