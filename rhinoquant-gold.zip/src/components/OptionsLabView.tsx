/**
 * RHINOQUANT GOLD - Options & Volatility Surface Engine View
 * Black-Scholes Greeks, IV Surface (Smile/Skew/Term Structure), Options Strategy Lab.
 */

import React, { useState } from 'react';
import { VolatilitySurfacePoint, OptionsStrategyResult } from '../engine/options';
import { Sliders, Layers, PieChart, ShieldCheck } from 'lucide-react';

interface OptionsLabViewProps {
  surface: VolatilitySurfacePoint[];
  spotUsd: number;
}

export const OptionsLabView: React.FC<OptionsLabViewProps> = ({ surface, spotUsd }) => {
  const [selectedStrategy, setSelectedStrategy] = useState<'Collar' | 'Straddle' | 'Call Spread'>('Collar');
  const [strategyResult, setStrategyResult] = useState<OptionsStrategyResult | null>(null);

  const handleRunStrategy = async (stratName: string) => {
    try {
      const legs = stratName === 'Collar'
        ? [
            { type: 'CALL' as const, strikeUsd: Math.round(spotUsd * 1.05), expiryDays: 90, side: 'SELL' as const, contractsCount: 10, premiumPerOz: 48 },
            { type: 'PUT' as const, strikeUsd: Math.round(spotUsd * 0.95), expiryDays: 90, side: 'BUY' as const, contractsCount: 10, premiumPerOz: 42 },
          ]
        : stratName === 'Straddle'
        ? [
            { type: 'CALL' as const, strikeUsd: Math.round(spotUsd), expiryDays: 60, side: 'BUY' as const, contractsCount: 10, premiumPerOz: 85 },
            { type: 'PUT' as const, strikeUsd: Math.round(spotUsd), expiryDays: 60, side: 'BUY' as const, contractsCount: 10, premiumPerOz: 82 },
          ]
        : [
            { type: 'CALL' as const, strikeUsd: Math.round(spotUsd * 1.02), expiryDays: 60, side: 'BUY' as const, contractsCount: 10, premiumPerOz: 62 },
            { type: 'CALL' as const, strikeUsd: Math.round(spotUsd * 1.08), expiryDays: 60, side: 'SELL' as const, contractsCount: 10, premiumPerOz: 22 },
          ];

      const res = await fetch('/api/v1/options/strategy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ strategyName: stratName, legs, quantityOz: 1000 }),
      });
      const data: OptionsStrategyResult = await res.json();
      setStrategyResult(data);
    } catch (e) {
      console.error('Failed to run options strategy:', e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Row: Volatility Surface Matrix */}
      <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#D4AF37]" />
            <h2 className="font-cinzel text-base font-bold text-[#F8FAFC]">Gold Implied Volatility Surface (Smile & Skew)</h2>
          </div>
          <span className="text-xs font-mono text-[#94A3B8]">ATM Vol: 15.5% · 25-Delta Put Skew: +3.2%</span>
        </div>

        {/* Vol Surface Heatmap Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-center text-xs font-mono tabular-nums">
            <thead>
              <tr className="border-b border-[#1E293B] text-[#64748B] uppercase">
                <th className="py-2.5 px-3 text-left">Expiry / Strike %</th>
                <th className="py-2.5 px-3">85% OTM Put</th>
                <th className="py-2.5 px-3">90% OTM Put</th>
                <th className="py-2.5 px-3">95% Put</th>
                <th className="py-2.5 px-3 text-[#D4AF37]">100% ATM</th>
                <th className="py-2.5 px-3">105% Call</th>
                <th className="py-2.5 px-3">110% OTM Call</th>
                <th className="py-2.5 px-3">115% OTM Call</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]/60 text-[#F8FAFC]">
              {[30, 60, 90, 180, 360].map((days) => {
                const dayPoints = surface.filter((s) => s.expiryDays === days);
                return (
                  <tr key={days} className="hover:bg-[#161F38]">
                    <td className="py-2.5 px-3 text-left font-bold text-[#D4AF37]">{days} Days</td>
                    {dayPoints.map((pt) => {
                      const iv = pt.impliedVolPct;
                      const isAtm = pt.strikePctSpot === 100;
                      return (
                        <td key={pt.strikePctSpot} className="py-2.5 px-3">
                          <span className={`inline-block px-2 py-0.5 rounded ${
                            isAtm
                              ? 'bg-[#1E293B] text-[#D4AF37] font-bold border border-[#D4AF37]'
                              : iv > 17
                              ? 'bg-amber-950/60 text-amber-300'
                              : 'bg-[#090D16] text-[#94A3B8]'
                          }`}>
                            {iv}%
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Options Strategy Lab */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Strategy Selection Form */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-base font-bold text-[#F8FAFC]">Options Strategy Builder</h3>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-[#94A3B8] block mb-1">Select Strategy Template</label>
              <div className="grid grid-cols-3 gap-1">
                {(['Collar', 'Straddle', 'Call Spread'] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => {
                      setSelectedStrategy(s);
                      handleRunStrategy(s);
                    }}
                    className={`py-1.5 px-2 rounded border transition-all ${
                      selectedStrategy === s
                        ? 'bg-[#1E293B] text-[#D4AF37] border-[#D4AF37] font-bold'
                        : 'bg-[#090D16] text-[#94A3B8] border-[#1E293B] hover:text-[#F8FAFC]'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => handleRunStrategy(selectedStrategy)}
              className="w-full bg-gradient-to-r from-[#D4AF37] to-[#C5A059] text-[#090D16] font-bold py-2 rounded hover:brightness-110 transition-all text-xs"
            >
              Evaluate Payoff & Greeks
            </button>
          </div>
        </div>

        {/* Strategy Evaluation Output */}
        {strategyResult && (
          <div className="lg:col-span-2 bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4 font-mono text-xs">
            <div className="flex justify-between items-center border-b border-[#1E293B] pb-2">
              <h3 className="font-cinzel text-base font-bold text-[#D4AF37]">{strategyResult.strategyName} Evaluation</h3>
              <span className="text-[#94A3B8]">Net Premium: ${strategyResult.totalNetPremiumUsd.toLocaleString()}</span>
            </div>

            {/* Greeks Summary Cards */}
            <div className="grid grid-cols-4 gap-2 text-center tabular-nums">
              <div className="bg-[#090D16] border border-[#1E293B] p-2 rounded">
                <div className="text-[#64748B]">Delta (Δ)</div>
                <div className="text-sm font-bold text-[#F8FAFC]">{strategyResult.netDelta}</div>
              </div>
              <div className="bg-[#090D16] border border-[#1E293B] p-2 rounded">
                <div className="text-[#64748B]">Gamma (Γ)</div>
                <div className="text-sm font-bold text-[#F8FAFC]">{strategyResult.netGamma}</div>
              </div>
              <div className="bg-[#090D16] border border-[#1E293B] p-2 rounded">
                <div className="text-[#64748B]">Theta (Θ)</div>
                <div className="text-sm font-bold text-rose-400">${strategyResult.netTheta}/d</div>
              </div>
              <div className="bg-[#090D16] border border-[#1E293B] p-2 rounded">
                <div className="text-[#64748B]">Vega (ν)</div>
                <div className="text-sm font-bold text-emerald-400">${strategyResult.netVega}/%</div>
              </div>
            </div>

            {/* Payoff Curve Visualizer */}
            <div className="h-40 bg-[#090D16] border border-[#1E293B] rounded p-2 flex flex-col justify-between">
              <svg className="w-full h-full" viewBox="0 0 500 120" preserveAspectRatio="none">
                <line x1="0" y1="60" x2="500" y2="60" stroke="#334155" strokeWidth="1" strokeDasharray="3 3" />
                <path
                  d="M 10 100 L 150 100 L 350 20 L 490 20"
                  fill="none"
                  stroke="#D4AF37"
                  strokeWidth="2.5"
                />
              </svg>
              <div className="flex justify-between text-[10px] text-[#64748B] pt-1 border-t border-[#1E293B]">
                <span>Spot $3,637 (-25%)</span>
                <span>Breakeven ${strategyResult.breakevenUsd[0]}</span>
                <span>Spot ${spotUsd.toFixed(0)}</span>
                <span>Breakeven ${strategyResult.breakevenUsd[1]}</span>
                <span>Spot $6,062 (+25%)</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
