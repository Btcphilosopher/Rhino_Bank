/**
 * RHINOQUANT GOLD - Trading & RFQ Execution View
 * Order book depth, time & sales tape, Rhino Bullion Desk dealer pricing, competitive 3-dealer RFQs, OMS execution form.
 */

import React, { useState } from 'react';
import { OrderBook, TimeAndSalesTrade } from '../engine/market';
import { DealerQuote, RfqRequest } from '../engine/pricing';
import { Order, TradeExecution } from '../engine/trading';
import { Zap, Send, ShieldCheck, Clock, CheckCircle2, ArrowRight } from 'lucide-react';

interface TradingRfqViewProps {
  orderBook: OrderBook;
  timeAndSales: TimeAndSalesTrade[];
  orders: Order[];
  trades: TradeExecution[];
  spotUsd: number;
  onSubmitOrder: (
    clientName: string,
    orderType: 'MARKET' | 'LIMIT',
    side: 'BUY' | 'SELL',
    qtyOz: number,
    limitPrice?: number
  ) => void;
}

export const TradingRfqView: React.FC<TradingRfqViewProps> = ({
  orderBook,
  timeAndSales,
  orders,
  trades,
  spotUsd,
  onSubmitOrder,
}) => {
  // RFQ Generator State
  const [rfqClientName, setRfqClientName] = useState('RhinoQuant Sovereign Wealth Trust');
  const [rfqQtyOz, setRfqQtyOz] = useState<number>(25000);
  const [rfqSide, setRfqSide] = useState<'BUY' | 'SELL'>('BUY');
  const [currentRfq, setCurrentRfq] = useState<RfqRequest | null>(null);

  // OMS Form State
  const [orderClient, setOrderClient] = useState('Apex Institutional Fund');
  const [orderSide, setOrderSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT'>('MARKET');
  const [orderQtyOz, setOrderQtyOz] = useState<number>(1000);
  const [limitPriceUsd, setLimitPriceUsd] = useState<number>(Math.round(spotUsd));

  // Generate 3-Dealer Competitive RFQ
  const handleRequestRfq = async () => {
    try {
      const res = await fetch('/api/v1/rfq', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: rfqClientName,
          quantityOz: rfqQtyOz,
          side: rfqSide,
          settlement: 'T+2',
        }),
      });
      const data: RfqRequest = await res.json();
      setCurrentRfq(data);
    } catch (e) {
      console.error('RFQ Request failed:', e);
    }
  };

  const handleAcceptQuote = (quote: DealerQuote) => {
    if (!currentRfq) return;
    onSubmitOrder(rfqClientName, 'MARKET', rfqSide, rfqQtyOz, quote.askPrice);
    setCurrentRfq({
      ...currentRfq,
      status: 'COMPLETED',
      executedDealer: quote.dealerName,
      executionPrice: rfqSide === 'BUY' ? quote.askPrice : quote.bidPrice,
    });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitOrder(
      orderClient,
      orderType,
      orderSide,
      orderQtyOz,
      orderType === 'LIMIT' ? limitPriceUsd : undefined
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Row: Competitive RFQ System & OMS Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 3-Dealer Competitive RFQ System */}
        <div className="lg:col-span-2 bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#D4AF37]" />
              <h2 className="font-cinzel text-base font-bold text-[#F8FAFC]">Institutional Competitive RFQ Execution</h2>
            </div>
            <span className="text-xs font-mono text-[#D4AF37] bg-[#161F38] px-2 py-0.5 rounded border border-[#1E293B]">
              Rhino Bullion Desk + 2 External Dealers
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-mono">
            <div>
              <label className="text-[#94A3B8] block mb-1">Client Entity</label>
              <input
                type="text"
                value={rfqClientName}
                onChange={(e) => setRfqClientName(e.target.value)}
                className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[#94A3B8] block mb-1">Quantity (Troy Oz)</label>
              <input
                type="number"
                value={rfqQtyOz}
                onChange={(e) => setRfqQtyOz(parseFloat(e.target.value) || 1000)}
                className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[#94A3B8] block mb-1">Direction</label>
              <select
                value={rfqSide}
                onChange={(e) => setRfqSide(e.target.value as 'BUY' | 'SELL')}
                className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
              >
                <option value="BUY">BUY GOLD (Client Paying Cash)</option>
                <option value="SELL">SELL GOLD (Client Receiving Cash)</option>
              </select>
            </div>

            <div className="flex items-end">
              <button
                onClick={handleRequestRfq}
                className="w-full bg-gradient-to-r from-[#D4AF37] to-[#C5A059] text-[#090D16] font-bold py-1.5 px-3 rounded hover:brightness-110 transition-all flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Request Quotes</span>
              </button>
            </div>
          </div>

          {/* Active RFQ Dealer Quotes Response */}
          {currentRfq && (
            <div className="bg-[#090D16] border border-[#1E293B] rounded p-4 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[#D4AF37] font-bold">{currentRfq.rfqId}</span>
                  <span className="text-[#94A3B8]">| {currentRfq.quantityOz.toLocaleString()} oz XAU/USD</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] ${currentRfq.side === 'BUY' ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                    {currentRfq.side}
                  </span>
                </div>
                {currentRfq.status === 'OPEN' ? (
                  <span className="text-amber-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 animate-spin" /> Quotes Expire in 25s
                  </span>
                ) : (
                  <span className="text-emerald-400 flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Executed @ ${currentRfq.executionPrice?.toFixed(2)} with {currentRfq.executedDealer}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {currentRfq.quotes.map((q) => {
                  const targetPrice = currentRfq.side === 'BUY' ? q.askPrice : q.bidPrice;
                  return (
                    <div
                      key={q.quoteId}
                      className="bg-[#0B132B] border border-[#1E293B] hover:border-[#D4AF37] transition-all p-3 rounded space-y-2"
                    >
                      <div className="text-[#F8FAFC] font-bold border-b border-[#1E293B] pb-1">{q.dealerName}</div>
                      <div className="space-y-1 text-[11px] tabular-nums">
                        <div className="flex justify-between text-[#94A3B8]">
                          <span>Bid: ${q.bidPrice.toFixed(2)}</span>
                          <span>Ask: ${q.askPrice.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-[#64748B]">
                          <span>Spread: ${q.spreadUsd.toFixed(2)} ({q.spreadBps} bps)</span>
                          <span>Fee: ${q.feeUsd.toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-[#1E293B]">
                        <div className="text-sm font-bold text-[#D4AF37] mb-1">
                          ${targetPrice.toFixed(2)} / oz
                        </div>
                        {currentRfq.status === 'OPEN' && (
                          <button
                            onClick={() => handleAcceptQuote(q)}
                            className="w-full bg-[#1E293B] hover:bg-[#D4AF37] hover:text-[#090D16] text-[#F8FAFC] font-semibold py-1 rounded transition-colors text-xs"
                          >
                            Accept & Trade
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* OMS Direct Order Submission Form */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-4">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-base font-bold text-[#F8FAFC]">Direct OMS Order Execution</h3>
          </div>

          <form onSubmit={handleFormSubmit} className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-[#94A3B8] block mb-1">Client Entity</label>
              <input
                type="text"
                value={orderClient}
                onChange={(e) => setOrderClient(e.target.value)}
                className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[#94A3B8] block mb-1">Side</label>
                <select
                  value={orderSide}
                  onChange={(e) => setOrderSide(e.target.value as 'BUY' | 'SELL')}
                  className="w-full bg-[#090D16] border border-[#1E293B] rounded px-2.5 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
                >
                  <option value="BUY">BUY XAU</option>
                  <option value="SELL">SELL XAU</option>
                </select>
              </div>

              <div>
                <label className="text-[#94A3B8] block mb-1">Order Type</label>
                <select
                  value={orderType}
                  onChange={(e) => setOrderType(e.target.value as 'MARKET' | 'LIMIT')}
                  className="w-full bg-[#090D16] border border-[#1E293B] rounded px-2.5 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
                >
                  <option value="MARKET">MARKET</option>
                  <option value="LIMIT">LIMIT</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-[#94A3B8] block mb-1">Quantity (Troy Oz)</label>
              <input
                type="number"
                value={orderQtyOz}
                onChange={(e) => setOrderQtyOz(parseFloat(e.target.value) || 100)}
                className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            {orderType === 'LIMIT' && (
              <div>
                <label className="text-[#94A3B8] block mb-1">Limit Price ($/oz)</label>
                <input
                  type="number"
                  value={limitPriceUsd}
                  onChange={(e) => setLimitPriceUsd(parseFloat(e.target.value) || Math.round(spotUsd))}
                  className="w-full bg-[#090D16] border border-[#1E293B] rounded px-3 py-1.5 text-[#F8FAFC] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>
            )}

            <div className="bg-[#090D16] border border-[#1E293B] p-2.5 rounded space-y-1 text-[11px] tabular-nums">
              <div className="flex justify-between text-[#64748B]">
                <span>Est. Notional Value:</span>
                <span className="text-[#F8FAFC]">${(orderQtyOz * spotUsd).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#64748B]">
                <span>Allocated Physical Bar:</span>
                <span className="text-emerald-400">YES (Valcambi/PAMP)</span>
              </div>
            </div>

            <button
              type="submit"
              className={`w-full py-2 px-4 rounded font-bold transition-all text-xs ${
                orderSide === 'BUY'
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-rose-600 hover:bg-rose-500 text-white'
              }`}
            >
              Submit {orderSide} Order ({orderQtyOz} oz)
            </button>
          </form>
        </div>
      </div>

      {/* Bottom Grid: Order Book Depth, Time & Sales, and Execution History */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* L2 Order Book Depth */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">COMEX XAU/USD Order Book Depth</h3>
            <span className="text-xs font-mono text-emerald-400">Spread: ${orderBook.spread.toFixed(2)} ({orderBook.spreadBps} bps)</span>
          </div>

          <div className="grid grid-cols-2 gap-2 font-mono text-[11px] tabular-nums">
            {/* ASKS (Sells) */}
            <div>
              <div className="text-rose-400 font-bold mb-1">ASKS (Sellers)</div>
              <div className="space-y-1">
                {orderBook.asks.slice(0, 7).reverse().map((ask, i) => (
                  <div key={i} className="flex justify-between bg-rose-950/20 px-1.5 py-0.5 rounded border border-rose-900/30">
                    <span className="text-rose-400">${ask.price.toFixed(2)}</span>
                    <span className="text-[#94A3B8]">{ask.sizeOz} oz</span>
                  </div>
                ))}
              </div>
            </div>

            {/* BIDS (Buys) */}
            <div>
              <div className="text-emerald-400 font-bold mb-1">BIDS (Buyers)</div>
              <div className="space-y-1">
                {orderBook.bids.slice(0, 7).map((bid, i) => (
                  <div key={i} className="flex justify-between bg-emerald-950/20 px-1.5 py-0.5 rounded border border-emerald-900/30">
                    <span className="text-emerald-400">${bid.price.toFixed(2)}</span>
                    <span className="text-[#94A3B8]">{bid.sizeOz} oz</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Time & Sales Trade Tape */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">Live Time & Sales Tape</h3>
          </div>

          <div className="overflow-y-auto max-h-56 space-y-1 font-mono text-[11px] tabular-nums">
            {timeAndSales.map((t) => (
              <div key={t.id} className="flex items-center justify-between bg-[#090D16] px-2 py-1 rounded border border-[#1E293B]">
                <span className="text-[#64748B]">{t.timestamp}</span>
                <span className={t.side === 'BUY' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  ${t.price.toFixed(2)}
                </span>
                <span className="text-[#F8FAFC]">{t.sizeOz} oz</span>
                <span className="text-[#64748B] text-[10px]">{t.venue}</span>
              </div>
            ))}
          </div>
        </div>

        {/* OMS Orders & Fills Audit List */}
        <div className="bg-[#0B132B] border border-[#1E293B] rounded-lg p-4 space-y-3">
          <div className="border-b border-[#1E293B] pb-2">
            <h3 className="font-cinzel text-sm font-bold text-[#F8FAFC]">OMS Working Orders & Executed Trades</h3>
          </div>

          <div className="overflow-y-auto max-h-56 space-y-2 font-mono text-[11px] tabular-nums">
            {trades.map((trd) => (
              <div key={trd.tradeId} className="bg-[#090D16] border border-[#1E293B] p-2 rounded space-y-1">
                <div className="flex justify-between border-b border-[#1E293B]/60 pb-1">
                  <span className="text-[#D4AF37] font-bold">{trd.tradeId}</span>
                  <span className="text-emerald-400 font-semibold">{trd.side} {trd.quantityOz} oz @ ${trd.executionPriceUsd}</span>
                </div>
                <div className="flex justify-between text-[#64748B]">
                  <span>Notional: ${trd.totalNotionalUsd.toLocaleString()}</span>
                  <span>Auto-Hedge: {trd.hedgeExecuted.hedgeType}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
