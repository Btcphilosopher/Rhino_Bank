/**
 * RHINOQUANT GOLD - Full-Stack Express Server & Vite Dev Server Middleware
 * Handles API routes for Market Data, OTC Pricing, Futures, Options, Physical Vaults, OMS, Risk, Quant Backtests & Gemini AI.
 */

import express from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { globalMarketEngine } from './src/engine/market';
import { globalOtcPricingEngine } from './src/engine/pricing';
import { globalFuturesEngine } from './src/engine/futures';
import { globalOptionsEngine } from './src/engine/options';
import { globalPhysicalBullionEngine } from './src/engine/physical';
import { globalOrderExecutionEngine } from './src/engine/trading';
import { globalAccountingLedgerEngine } from './src/engine/ledgers';
import { globalRiskAndMacroEngine } from './src/engine/risk';
import { globalQuantResearchEngine } from './src/engine/quant';
import { globalBenchmarkEngine } from './src/engine/benchmarks';
import { convertGoldQuantity, calculateFineGold, GoldUnit, GoldPurity } from './src/engine/units';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Gemini 3.6 SDK
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || 'MOCK_KEY',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Periodic market background tick
setInterval(() => {
  globalMarketEngine.tick();
}, 1000);

// ================= API V1 ROUTES =================

// 1. Markets & Spot Data
app.get('/api/v1/markets', (req, res) => {
  const spotQuotes = globalMarketEngine.getSpotQuotes();
  const lbmaBenchmarks = globalMarketEngine.getLBMABenchmarks();
  const regionalPremiums = globalMarketEngine.getRegionalPremiums();
  const fxRates = globalMarketEngine.getFxRates();

  res.json({
    spotQuotes,
    lbmaBenchmarks,
    regionalPremiums,
    fxRates,
  });
});

app.get('/api/v1/orderbook', (req, res) => {
  const instrument = (req.query.instrument as string) || 'XAU/USD';
  const orderBook = globalMarketEngine.getOrderBook(instrument);
  const timeAndSales = globalMarketEngine.getTimeAndSales();

  res.json({ orderBook, timeAndSales });
});

// Unit conversion endpoint
app.get('/api/v1/convert', (req, res) => {
  const qty = parseFloat(req.query.qty as string) || 1.0;
  const unit = (req.query.unit as GoldUnit) || 'oz';
  const purity = (parseFloat(req.query.purity as string) || 999.9) as GoldPurity;

  const converted = convertGoldQuantity(qty, unit);
  const fine = calculateFineGold(converted.grams, purity);

  res.json({ converted, fine });
});

// 2. OTC Dealer Pricing & Competitive RFQ
app.post('/api/v1/quotes', (req, res) => {
  const { instrument, side, quantityOz, clientTier, settlementDays, allocated } = req.body;
  const quote = globalOtcPricingEngine.generateQuote({
    instrument: instrument || 'XAU/USD',
    side: side || 'TWO_WAY',
    quantityOz: parseFloat(quantityOz) || 100,
    clientTier: clientTier || 'TIER_1_INSTITUTIONAL',
    settlementDays: settlementDays || 'T+2',
    allocated: allocated !== false,
  });

  res.json(quote);
});

app.post('/api/v1/rfq', (req, res) => {
  const { clientName, quantityOz, side, settlement } = req.body;
  const rfq = globalOtcPricingEngine.createCompetitiveRfq(
    clientName || 'Institutional Client',
    parseFloat(quantityOz) || 1000,
    side || 'BUY',
    settlement || 'T+2'
  );

  res.json(rfq);
});

// 3. Futures & Term Structure Curve
app.get('/api/v1/futures', (req, res) => {
  const curve = globalFuturesEngine.getCurveAnalysis();
  res.json(curve);
});

// 4. Options & Volatility Surface
app.get('/api/v1/options', (req, res) => {
  const surface = globalOptionsEngine.getVolatilitySurface();
  res.json({ surface });
});

app.post('/api/v1/options/strategy', (req, res) => {
  const { strategyName, legs, quantityOz } = req.body;
  const result = globalOptionsEngine.buildStrategy(
    strategyName || 'Collar Strategy',
    legs || [
      { type: 'CALL', strikeUsd: 5000, expiryDays: 90, side: 'SELL', contractsCount: 10, premiumPerOz: 45 },
      { type: 'PUT', strikeUsd: 4700, expiryDays: 90, side: 'BUY', contractsCount: 10, premiumPerOz: 42 },
    ],
    parseFloat(quantityOz) || 1000
  );

  res.json(result);
});

// 5. Physical Vault Digital Twin & Bar Registry
app.get('/api/v1/vaults', (req, res) => {
  const vaults = globalPhysicalBullionEngine.getVaults();
  const bars = globalPhysicalBullionEngine.getBars(req.query.vaultId as string);

  res.json({ vaults, bars });
});

app.post('/api/v1/refinery/batch', (req, res) => {
  const { feedstock, inputKg } = req.body;
  const batch = globalPhysicalBullionEngine.simulateRefineryBatch(
    feedstock || 'Doré Bars',
    parseFloat(inputKg) || 100.0
  );

  res.json(batch);
});

// 6. OMS & Trade Execution
app.get('/api/v1/orders', (req, res) => {
  const orders = globalOrderExecutionEngine.getOrders();
  const trades = globalOrderExecutionEngine.getTrades();

  res.json({ orders, trades });
});

app.post('/api/v1/orders', (req, res) => {
  const { clientName, instrument, orderType, side, quantityOz, limitPriceUsd, allocatedPhysical } = req.body;
  const result = globalOrderExecutionEngine.submitOrder(
    clientName || 'Institutional Fund',
    instrument || 'XAU/USD',
    orderType || 'MARKET',
    side || 'BUY',
    parseFloat(quantityOz) || 100,
    limitPriceUsd ? parseFloat(limitPriceUsd) : undefined,
    allocatedPhysical !== false
  );

  if (result.execution) {
    globalAccountingLedgerEngine.recordTradeLedgerEntries(
      result.order.clientName,
      result.order.side,
      result.order.quantityOz,
      result.execution.totalNotionalUsd,
      result.execution.tradeId
    );
  }

  res.json(result);
});

// 7. Portfolio & Double-Entry Ledgers
app.get('/api/v1/portfolio', (req, res) => {
  const portfolio = globalRiskAndMacroEngine.getConsolidatedPortfolio();
  const metalLedger = globalAccountingLedgerEngine.getMetalEntries();
  const cashLedger = globalAccountingLedgerEngine.getCashEntries();
  const reconciliation = globalAccountingLedgerEngine.runReconciliation();

  res.json({ portfolio, metalLedger, cashLedger, reconciliation });
});

// 8. Risk Engine & Stress Scenarios
app.get('/api/v1/risk', (req, res) => {
  const portfolio = globalRiskAndMacroEngine.getConsolidatedPortfolio();
  const var99 = globalRiskAndMacroEngine.calculateVaR(portfolio, 99, 1);
  const var95 = globalRiskAndMacroEngine.calculateVaR(portfolio, 95, 1);
  const var999 = globalRiskAndMacroEngine.calculateVaR(portfolio, 99.9, 1);
  const stress = globalRiskAndMacroEngine.runStressScenarios(portfolio);
  const factorAttribution = globalRiskAndMacroEngine.getFactorAttribution();
  const crossAssetRatios = globalRiskAndMacroEngine.getCrossAssetRatios();

  res.json({
    portfolio,
    var99,
    var95,
    var999,
    stress,
    factorAttribution,
    crossAssetRatios,
  });
});

// 9. Quantitative Research & Backtester
app.post('/api/v1/backtest', (req, res) => {
  const { strategyName, leverage, initialCapitalUsd } = req.body;
  const result = globalQuantResearchEngine.runBacktest({
    strategyName: strategyName || 'Gold Momentum',
    startDate: '2023-01-01',
    endDate: '2026-03-01',
    initialCapitalUsd: parseFloat(initialCapitalUsd) || 10000000,
    slippageBps: 1.0,
    feeBps: 1.5,
    leverage: parseFloat(leverage) || 1.0,
  });

  res.json(result);
});

app.get('/api/v1/monte-carlo', (req, res) => {
  const simulations = globalQuantResearchEngine.runMonteCarlo(1000, 252);
  res.json(simulations);
});

app.get('/api/v1/research/notebook', (req, res) => {
  const cells = globalQuantResearchEngine.getDefaultNotebookCells();
  res.json({ cells });
});

// 10. Benchmarking
app.get('/api/v1/benchmark', (req, res) => {
  const metrics = globalBenchmarkEngine.runRealBenchmark();
  res.json(metrics);
});

// 11. AI Quantitative Macro Analyst (Gemini 3.6 integration)
app.post('/api/v1/ai-quant', async (req, res) => {
  try {
    const { prompt, queryType } = req.body;
    const spot = globalMarketEngine.getSpotUsd();
    const portfolio = globalRiskAndMacroEngine.getConsolidatedPortfolio();

    const systemPrompt = `You are the Lead Quantitative Strategist for RHINOQUANT GOLD (RQ-GOLD), an institutional precious metals platform.
Provide precise, institutional-grade market commentary, risk attribution, or trading strategy analysis based on current synthetic market state:
- Spot XAU/USD: $${spot.toFixed(2)}
- Consolidated Gold Exposure: ${portfolio.totalGoldEquivalentOz.toLocaleString()} oz ($${(portfolio.totalGoldValueUsd / 1e6).toFixed(1)}M)
- Cash Liquidity: $${(portfolio.cashUsdBalance / 1e6).toFixed(1)}M
- Portfolio VaR (99% 1D): $4.2M

Format output cleanly with section headers, tabular numbers, bulleted macro drivers (Real Yields, DXY, Central Bank reserve accumulation, COMEX positioning), and actionable hedging recommendations.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `${systemPrompt}\n\nUser Analysis Query (${queryType || 'General Macro'}): ${prompt || 'Analyze current gold market regime, basis structure, and recommended risk hedging strategy.'}`,
    });

    res.json({
      success: true,
      text: response.text || 'Quantitative analysis generation completed.',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Gemini AI Quant error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate AI quantitative report.',
      details: error?.message || String(error),
    });
  }
});

// Setup Vite Dev Middleware in Development mode
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[RHINOQUANT GOLD] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
