# RhinoQuant Tranche Analytics v3.4
### Institutional Structured Credit & CDO Tranche Analytics Workbench
*Quantitative companion to RhinoBank TrancheWorks (Structuring) and RhinoBank TrancheDesk (Trading & Risk)*

---

## 1. Executive Summary & Capabilities
RhinoQuant Tranche Analytics is an institutional quantitative application designed for analyzing Collateralized Debt Obligation (CDO/CLO) tranches, structured-credit reference portfolios, and synthetic credit index/bespoke tranches.

The application strictly separates:
- **Contractual calculations:** dynamic period-by-period cash-flow waterfall, coverage test diversions (OC/IC), principal deficiency ledgers (PDL), reserve fund mechanisms, sequential vs pro-rata amortisation.
- **Economic credit simulation:** 1-factor Gaussian and heavy-tailed Student-t copulas, time-dependent hazard curves, recovery distributions, and Common Random Numbers (CRN).
- **Market-calibrated valuation:** discount margin (DM), clean and dirty prices, multi-root investor IRR diagnostics, weighted-average life (WAL), and synthetic CDS fair running spreads / upfronts.

---

## 2. Mathematical Specifications

### 2.1 Static Reference Portfolio Tranche Loss
For a static portfolio with cumulative loss fraction $L_{\text{port}} \in [0, 1]$, attachment point $A$, and detachment point $D$ where $0 \le A < D \le 1$:
$$L_{\text{tranche}}(L_{\text{port}}) = \frac{\min(\max(L_{\text{port}} - A, 0), D - A)}{D - A}$$

*Architectural Boundary Note:* This static piecewise linear function applies to synthetic single-tranche CDS exposures. It is **not** a substitute for an amortising cash CLO note's dynamic contractual waterfall.

### 2.2 Correlated Credit Simulation (1-Factor Copula)
Obligor $i$ latent asset value:
$$X_i = \sqrt{\rho} M + \sqrt{1 - \rho} Z_i$$
where $M \sim \mathcal{N}(0, 1)$ is the systemic credit factor, $Z_i \sim \mathcal{N}(0, 1)$ is idiosyncratic risk.
For heavy-tailed Student-$t_\nu$, $M$ and $Z_i$ are scaled by $\sqrt{\nu / W}$ where $W \sim \chi^2_\nu$.

Default occurs over horizon $T$ when $X_i \le \Phi^{-1}(PD_i(T))$.
**Notice on Correlation:** The continuous latent correlation $\rho$ is mathematically distinct from the discrete realized pairwise default correlation $\text{Corr}(\mathbf{1}_{\tau_i \le T}, \mathbf{1}_{\tau_j \le T})$, which is significantly lower due to non-linear tail truncation.

### 2.3 Cash-Flow Waterfall & Cash Conservation
At every period $t$:
$$\text{Total In}_t = \text{Interest Collections}_t + \text{Principal Collections}_t + \text{Recoveries}_t + \text{Hedge Inflow}_t$$
$$\text{Total Out}_t = \text{Fees}_t + \text{Hedge Outflow}_t + \text{Tranche Interest}_t + \text{Principal Repayment}_t + \Delta\text{Reserve}_t + \text{Reinvestment}_t + \text{Equity Distribution}_t$$
The engine validates $\text{Total In}_t - \text{Total Out}_t = 0.0000$ (cash variance $< \$0.05$ tolerance).

### 2.4 Semiconductor Specialized Adapter
Adapts micro-operational supply chain and fab dynamics directly into borrower cash flows:
1. **Fab capacity utilization shock:** drop in utilization below 65% downgrades debt rating notches due to fixed-cost deleverage.
2. **Tape-out qualification failure:** in-progress bringup tests trigger margin calls and coupon step-ups.
3. **Customer DSO payment delay:** extension of Days Sales Outstanding beyond 100 days forces short-term coupon deferral.

### 2.5 P&L Attribution with Unexplained Residual
$$\Delta P\&L = \text{Carry} + \text{Distributions} + \Delta\text{Rates} + \Delta\text{Spreads} + \text{Defaults} + \text{FX} + \text{Trades} + \text{Model} + \text{Unexplained Residual}$$
Pursuant to RhinoBank risk standards, any higher-order cross-gamma or non-linear effects are explicitly documented as **Unexplained Residual** rather than forcing attribution to artificially balance.

---

## 3. Directory Layout
```
r_project/
├── DESCRIPTION                 # Package metadata and versioning (3.4.0)
├── renv.lock                   # Reproducible dependency lockfile
├── README.md                   # Technical and mathematical documentation
├── app.R                       # Interactive Shiny dashboard with bslib theme
├── run_cli.R                   # Headless execution CLI
├── R/
│   ├── 01_data_models.R        # Ingestion, schema validation, and unit checks
│   ├── 02_tranche_loss.R       # Analytical static tranche loss formulas
│   ├── 03_waterfall_engine.R   # Dynamic period-by-period cash-flow waterfall
│   ├── 04_credit_simulation.R  # Correlated Gaussian & Student-t copula MC
│   ├── 05_valuation.R          # Cash-note & synthetic CDS pricing engines
│   ├── 06_risk_sensitivities.R # Finite-difference DV01, CS01, Rec, Corr, JTD
│   ├── 07_stress_testing.R     # Macro scenarios & Semiconductor Adapter
│   ├── 08_portfolio_pnl.R      # TrancheDesk import & P&L attribution
│   ├── 09_export_report.R      # Reproducible JSON/CSV run bundler
│   └── 10_api_wrapper.R       # High-level exports: run_full_analysis()
├── data/
│   ├── collateral_pool_100m.csv# USD 100M reference pool (100 corporate obligors)
│   ├── capital_stack_config.json# Tranches, subordination, waterfall rules
│   ├── market_curves.json      # SOFR discount curve, rating default curves
│   └── tranche_desk_trades.csv # TrancheDesk trading holdings & positions
└── tests/
    ├── testthat.R              # Test runner
    └── testthat/
        └── test_tranche_analytics.R # 30 unit tests covering all mathematical checks
```

---

## 4. Execution & Verification

### Running the Testthat Suite (30 Verification Tests)
```bash
Rscript r_project/tests/testthat.R
```

### Running the End-to-End Headless CLI Pipeline
```bash
Rscript r_project/run_cli.R [n_sims=3000] [rho=0.30] [seed=42]
```

### Launching the Interactive Shiny App Locally
```R
# In R console:
shiny::runApp("r_project")
```
