# ==============================================================================
# RhinoQuant Tranche Analytics - 04_credit_simulation.R
# Correlated Portfolio Credit Simulation Engine
# Copyright (c) 2026 RhinoBank Quant Group
# ==============================================================================

#' Correlated Portfolio Default Simulation
#'
#' Implements a transparent factor copula framework for simulating joint defaults
#' across credit portfolios. Supports:
#'   1. One-factor Gaussian Copula (Vasicek / Merton structural baseline)
#'   2. Heavy-tailed Student-t Copula with degrees of freedom nu (captures tail dependence)
#'
#' MATHEMATICAL DOCUMENTATION ON LATENT CORRELATION VS REALISED DEPENDENCE:
#' The latent factor loading rho represents the correlation between the continuous
#' latent credit assets X_i and X_j: Corr(X_i, X_j) = rho_i * rho_j.
#' Due to nonlinear thresholding (default occurs only when X_i <= Phi^-1(PD_i)),
#' the realised default correlation Corr(1_{tau_i <= t}, 1_{tau_j <= t}) is
#' SUBSTANTIALLY LOWER than rho, especially for investment grade names with small PD.
#' These two quantities are mathematically distinct and must never be conflated.
#'
#' @param collateral data.table of validated collateral
#' @param n_sims Number of Monte Carlo paths (default 5,000)
#' @param correlation_rho Latent systemic factor correlation rho in [0, 0.95]
#' @param copula_type "Gaussian" or "Student-t"
#' @param student_t_df Degrees of freedom for Student-t copula (default 4)
#' @param recovery_mean Mean recovery rate (default 0.65 for senior secured)
#' @param recovery_sd Standard deviation of recovery rate (default 0.15)
#' @param time_horizon_years Simulation horizon in years (default 5.0)
#' @param seed Random seed for exact reproducibility
#' @return list containing 'portfolio_loss_distribution', 'default_counts', 'diagnostics'
#' @export
simulate_portfolio_defaults <- function(collateral,
                                       n_sims = 5000,
                                       correlation_rho = 0.30,
                                       copula_type = c("Gaussian", "Student-t"),
                                       student_t_df = 4,
                                       recovery_mean = 0.65,
                                       recovery_sd = 0.15,
                                       time_horizon_years = 5.0,
                                       seed = 42) {
  start_time <- Sys.time()
  copula_type <- match.arg(copula_type)
  
  if (correlation_rho < 0 || correlation_rho >= 1.0) {
    stop("Credit simulation error: correlation_rho must satisfy: 0 <= correlation_rho < 1.0")
  }
  
  dt <- data.table::as.data.table(data.table::copy(collateral))
  N <- nrow(dt)
  total_notional <- sum(dt$current_balance)
  notional_weights <- dt$current_balance / total_notional
  
  # Set reproducible seed
  if (!is.null(seed)) {
    set.seed(seed)
  }
  
  # Map ratings to 5-year cumulative default probabilities (PD_5Y)
  # Calibrated to historical corporate default statistics
  rating_pd_5y <- c(
    "AAA" = 0.0010, "AA+" = 0.0020, "AA" = 0.0035, "AA-" = 0.0060,
    "A+"  = 0.0090, "A"   = 0.0135, "A-"  = 0.0210,
    "BBB+"= 0.0320, "BBB" = 0.0480, "BBB-"= 0.0750,
    "BB+" = 0.1150, "BB"  = 0.1650, "BB-" = 0.2250,
    "B+"  = 0.2950, "B"   = 0.3800, "B-"  = 0.4800,
    "CCC+"= 0.5800, "CCC" = 0.6800, "D"   = 1.0000
  )
  
  # Default probability for each obligor over the horizon
  pds <- sapply(dt$rating, function(r) {
    if (r %in% names(rating_pd_5y)) rating_pd_5y[[r]] else 0.0500
  })
  
  # Adjust PDs if maturity is less than time_horizon_years
  # PD(T) ~ 1 - (1 - PD_5Y)^(T / 5)
  effective_pds <- 1 - (1 - pds)^(dt$maturity_years / 5.0)
  
  # Latent default thresholds: C_i = Phi^-1(effective_PD_i)
  thresholds <- stats::qnorm(effective_pds)
  
  # Factor model generation:
  # Systemic factor M ~ N(0, 1) or t(nu)
  # Obligor idiosyncratic Z_i ~ N(0, 1) or t(nu)
  sqrt_rho <- sqrt(correlation_rho)
  sqrt_1_minus_rho <- sqrt(1 - correlation_rho)
  
  # Latent factor matrix: N x n_sims
  # 1. Systemic market factor M (length n_sims)
  M <- stats::rnorm(n_sims)
  
  if (copula_type == "Student-t") {
    # Heavy-tailed copula: scale Gaussian variates by sqrt(nu / W) where W ~ Chisq(nu)
    W <- stats::rchisq(n_sims, df = student_t_df)
    scale_factor <- sqrt(student_t_df / W)
    M <- M * scale_factor
  }
  
  # 2. Idiosyncratic factors Z: matrix N x n_sims
  Z <- matrix(stats::rnorm(N * n_sims), nrow = N, ncol = n_sims)
  if (copula_type == "Student-t") {
    # In Student-t copula, the same scaling variable W applies across common latent draws
    Z <- sweep(Z, 2, scale_factor, `*`)
  }
  
  # Latent credit score: X_i = sqrt(rho) * M + sqrt(1 - rho) * Z_i
  # Using vectorization for high speed
  X <- sqrt_rho * matrix(rep(M, each = N), nrow = N, ncol = n_sims) +
       sqrt_1_minus_rho * Z
  
  # In Student-t, convert to uniform margins then to normal quantiles if needed,
  # or compare directly to Student-t quantiles:
  if (copula_type == "Student-t") {
    # Transform margins
    t_thresholds <- stats::qt(effective_pds, df = student_t_df)
    default_indicators <- X <= t_thresholds
  } else {
    default_indicators <- X <= thresholds
  }
  
  # Generate recovery rates for defaulted obligors:
  # Beta distribution parameterized by mean and sd
  alpha <- recovery_mean * ((recovery_mean * (1 - recovery_mean) / (recovery_sd^2)) - 1)
  beta_param <- (1 - recovery_mean) * ((recovery_mean * (1 - recovery_mean) / (recovery_sd^2)) - 1)
  alpha <- max(0.5, alpha)
  beta_param <- max(0.5, beta_param)
  
  # Recoveries matrix
  recoveries <- matrix(stats::rbeta(N * n_sims, shape1 = alpha, shape2 = beta_param),
                       nrow = N, ncol = n_sims)
  loss_given_default <- 1 - recoveries
  
  # Compute loss amount per obligor: notional * indicator * LGD
  loss_matrix <- sweep(default_indicators * loss_given_default, 1, dt$current_balance, `*`)
  
  # Total portfolio loss per simulation path
  sim_loss_amounts <- colSums(loss_matrix)
  sim_loss_fractions <- sim_loss_amounts / total_notional
  sim_default_counts <- colSums(default_indicators)
  
  elapsed_seconds <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
  
  # Calculate Monte Carlo convergence diagnostics & standard error
  mc_mean <- mean(sim_loss_fractions)
  mc_sd <- stats::sd(sim_loss_fractions)
  mc_se <- mc_sd / sqrt(n_sims)
  
  # Batch convergence: split into 10 batches to check parameter stability
  batch_size <- floor(n_sims / 10)
  batch_means <- sapply(1:10, function(b) {
    idx <- ((b - 1) * batch_size + 1):(b * batch_size)
    mean(sim_loss_fractions[idx])
  })
  
  list(
    portfolio_loss_fractions = sim_loss_fractions,
    portfolio_loss_amounts = sim_loss_amounts,
    default_counts = sim_default_counts,
    n_sims = n_sims,
    correlation_rho = correlation_rho,
    copula_type = copula_type,
    seed = seed,
    diagnostics = list(
      runtime_seconds = elapsed_seconds,
      mean_loss_pct = mc_mean * 100,
      mean_loss_currency = mc_mean * total_notional,
      mc_standard_error_pct = mc_se * 100,
      loss_sd_pct = mc_sd * 100,
      q50_pct = stats::quantile(sim_loss_fractions, 0.50) * 100,
      q95_pct = stats::quantile(sim_loss_fractions, 0.95) * 100,
      q99_pct = stats::quantile(sim_loss_fractions, 0.99) * 100,
      q999_pct = stats::quantile(sim_loss_fractions, 0.999) * 100,
      var_99_amount = stats::quantile(sim_loss_amounts, 0.99),
      cvar_99_amount = mean(sim_loss_amounts[sim_loss_amounts >= stats::quantile(sim_loss_amounts, 0.99)]),
      batch_convergence_means = batch_means * 100,
      effective_sample_tail_disclosure = sprintf(
        "Tail estimates: at 99.9th percentile, effective sample size in tail is ~%.0f paths. Uncertainty interval is +/- %.2f bps.",
        n_sims * 0.001, (mc_se * 100 * 3)
      )
    )
  )
}
