# ==============================================================================
# RhinoQuant Tranche Analytics - 05_valuation.R
# Cash Note Valuation & Synthetic Tranche Pricing Engine
# Copyright (c) 2026 RhinoBank Quant Group
# ==============================================================================

#' Internal Rate of Return (IRR) Solver with Multiple Root Detection
#'
#' Solves for r such that: sum_{t=0}^T CF_t / (1 + r)^t = 0
#' Checks for sign changes and verifies root uniqueness over [-0.5, 2.0].
#'
#' @param cash_flows Numeric vector of cash flows starting at t=0 (initial outflow < 0)
#' @param times Numeric vector of payment times in years (t=0, t_1, ..., t_n)
#' @return list(irr, status, root_count)
calc_irr_robust <- function(cash_flows, times) {
  if (length(cash_flows) < 2) {
    return(list(irr = NA_real_, status = "INSUFFICIENT_PERIODS", roots_found = 0))
  }
  
  # Check sign changes (Descartes' rule of signs)
  signs <- sign(cash_flows[cash_flows != 0])
  sign_changes <- sum(diff(signs) != 0)
  if (sign_changes == 0) {
    return(list(irr = NA_real_, status = "NO_SIGN_CHANGE", roots_found = 0))
  }
  
  npv_fn <- function(r) {
    sum(cash_flows / ((1 + r)^times))
  }
  
  # Grid scan across plausible range [-0.20, 1.00] to detect multiple roots
  grid_r <- seq(-0.20, 1.00, by = 0.02)
  npv_vals <- sapply(grid_r, npv_fn)
  valid_idx <- which(!is.na(npv_vals) & is.finite(npv_vals))
  
  bracket_changes <- which(diff(sign(npv_vals[valid_idx])) != 0)
  
  if (length(bracket_changes) == 0) {
    return(list(irr = NA_real_, status = "NO_ROOT_IN_INTERVAL", roots_found = 0))
  }
  
  roots <- numeric(0)
  for (idx in bracket_changes) {
    lower_r <- grid_r[valid_idx[idx]]
    upper_r <- grid_r[valid_idx[idx + 1]]
    root_try <- try(stats::uniroot(npv_fn, interval = c(lower_r, upper_r), tol = 1e-6), silent = TRUE)
    if (!inherits(root_try, "try-error")) {
      roots <- c(roots, root_try$root)
    }
  }
  
  roots <- unique(round(roots, 6))
  if (length(roots) == 1) {
    return(list(irr = roots[1], status = "UNIQUE_ROOT", roots_found = 1))
  } else if (length(roots) > 1) {
    return(list(irr = roots[1], status = "MULTIPLE_ROOTS_DETECTED", roots_found = length(roots), candidate_roots = roots))
  } else {
    return(list(irr = NA_real_, status = "CONVERGENCE_FAILURE", roots_found = 0))
  }
}

#' Value Funded Cash CDO Notes
#'
#' @param waterfall_result Output list from run_waterfall()
#' @param tranches data.table of tranches
#' @param discount_curve list or data.table of discount factors
#' @param market_quotes optional data.table of observed market prices (clean price % of par)
#' @return data.table of tranche valuations, WAL, DM, clean and dirty prices
#' @export
value_cash_tranche <- function(waterfall_result,
                               tranches,
                               discount_curve = NULL,
                               market_quotes = NULL) {
  ledger <- waterfall_result$ledger
  n_periods <- nrow(ledger)
  
  # Default SOFR curve if not supplied (flat 4.25% discount rate)
  times <- c(0, ledger$period * 0.25) # times in years
  dfs <- exp(-0.0425 * times)
  
  tranches_dt <- data.table::as.data.table(data.table::copy(tranches))
  
  val_rows <- list()
  
  for (i in seq_len(nrow(tranches_dt))) {
    tid <- tranches_dt$tranche_id[i]
    tname <- tranches_dt$name[i]
    orig_bal <- tranches_dt$original_balance[i]
    curr_bal <- tranches_dt$current_balance[i]
    p_factor <- curr_bal / orig_bal
    
    # Extract cash flows from waterfall ledger
    int_col <- switch(tid,
                      "TR-AAA" = "aaa_interest",
                      "TR-AA"  = "aa_interest",
                      "TR-BBB" = "bbb_interest",
                      "TR-EQUITY" = "equity_distribution")
    
    prn_col <- switch(tid,
                      "TR-AAA" = "aaa_principal",
                      "TR-AA"  = "aa_principal",
                      "TR-BBB" = "bbb_principal",
                      "TR-EQUITY" = NA_character_)
    
    interest_cf <- ledger[[int_col]]
    principal_cf <- if (!is.na(prn_col)) ledger[[prn_col]] else rep(0, n_periods)
    total_cf <- interest_cf + principal_cf
    
    # Weighted Average Life (WAL) in years
    # WAL = sum(t * Principal_t) / sum(Principal_t)
    total_prn <- sum(principal_cf)
    wal <- if (total_prn > 0) {
      sum((ledger$period * 0.25) * principal_cf) / total_prn
    } else {
      max(ledger$period * 0.25)
    }
    
    # Discounted cash flows along curve
    # Note: Period 1..n discounts correspond to dfs[2:(n+1)]
    period_dfs <- dfs[2:(n_periods + 1)]
    pv_interest <- sum(interest_cf * period_dfs)
    pv_principal <- sum(principal_cf * period_dfs)
    pv_total <- pv_interest + pv_principal
    
    # Model Present Value as % of Current Balance
    # ARCHITECTURAL CHECK: Price basis is % of current balance. Factor is NOT double-applied.
    model_price_dirty <- if (curr_bal > 0) (pv_total / curr_bal) * 100 else 0
    
    # Accrued interest estimation for next coupon (assuming mid-quarter settlement = 45 days)
    accrued_days <- 45
    coupon_rate <- (4.25 + tranches_dt$spread_bps[i] / 100) / 100
    accrued_interest_amount <- curr_bal * coupon_rate * (accrued_days / 360)
    accrued_interest_pct <- if (curr_bal > 0) (accrued_interest_amount / curr_bal) * 100 else 0
    
    model_price_clean <- model_price_dirty - accrued_interest_pct
    
    # Market observed price (if available)
    mkt_price_clean <- NA_real_
    if (!is.null(market_quotes) && tid %in% market_quotes$tranche_id) {
      mkt_price_clean <- market_quotes[tranche_id == tid, clean_price[1]]
    }
    
    # Discount Margin (DM) calculation: spread s over SOFR that equates PV to Clean Price
    # DM is well-defined when price and cash flows are standard amortising notes
    dm_bps <- NA_real_
    if (!is.na(mkt_price_clean) && mkt_price_clean > 0 && total_prn > 0) {
      obj_dm <- function(s_bps) {
        disc_rates <- 0.0425 + (s_bps / 10000)
        d_factors <- exp(-disc_rates * (ledger$period * 0.25))
        sum(total_cf * d_factors) - (mkt_price_clean / 100 * curr_bal)
      }
      dm_fit <- try(stats::uniroot(obj_dm, interval = c(-500, 3000), tol = 1e-4), silent = TRUE)
      if (!inherits(dm_fit, "try-error")) {
        dm_bps <- dm_fit$root
      }
    }
    
    # Investor IRR calculation from initial investment = curr_bal * (model_price_clean / 100)
    initial_outflow <- -1 * (curr_bal * (model_price_clean / 100))
    irr_cf_vector <- c(initial_outflow, total_cf)
    irr_times <- c(0, ledger$period * 0.25)
    irr_result <- calc_irr_robust(irr_cf_vector, irr_times)
    
    # Principal & Interest Shortfalls
    expected_full_principal <- curr_bal
    principal_shortfall <- max(0, expected_full_principal - total_prn)
    
    val_rows[[i]] <- data.table::data.table(
      tranche_id = tid,
      name = tname,
      rating = tranches_dt$rating[i],
      original_balance = orig_bal,
      current_balance = curr_bal,
      principal_factor = p_factor,
      wal_years = round(wal, 2),
      pv_total = pv_total,
      model_price_clean = round(model_price_clean, 3),
      model_price_dirty = round(model_price_dirty, 3),
      market_observed_price = mkt_price_clean,
      accrued_interest_amount = accrued_interest_amount,
      discount_margin_bps = if (!is.na(dm_bps)) round(dm_bps, 1) else NA_real_,
      investor_irr_pct = if (!is.na(irr_result$irr)) round(irr_result$irr * 100, 2) else NA_real_,
      irr_status = irr_result$status,
      principal_shortfall = principal_shortfall,
      valuation_basis = "Economic Model PV (% Current Balance, Single-Factor Applied)"
    )
  }
  
  data.table::rbindlist(val_rows)
}

#' Value Synthetic Credit Tranches
#'
#' Evaluates the Premium Leg and Protection Leg for standard synthetic CDS tranches.
#'
#' @param syn_spec List containing synthetic tranche definition
#' @param loss_simulation_result Output from simulate_portfolio_defaults()
#' @param discount_rate Continuous risk-free discount rate (default 0.0425)
#' @return data.table of synthetic tranche valuations, fair spreads, and upfronts
#' @export
value_synthetic_tranche <- function(syn_spec,
                                    loss_simulation_result,
                                    discount_rate = 0.0425) {
  loss_samples <- loss_simulation_result$portfolio_loss_fractions
  M <- length(loss_samples)
  
  tranches_dt <- data.table::as.data.table(syn_spec$tranches)
  tenor <- if (!is.null(syn_spec$tenor_years)) syn_spec$tenor_years else 5.0
  total_notional <- syn_spec$total_notional
  
  # Standard quarterly schedule for CDS tranches (20 quarters)
  times_qtr <- seq(0.25, tenor, by = 0.25)
  dfs <- exp(-discount_rate * times_qtr)
  
  val_list <- list()
  
  for (i in seq_len(nrow(tranches_dt))) {
    t_id <- tranches_dt$id[i]
    t_name <- tranches_dt$name[i]
    att <- tranches_dt$attachment[i]
    det <- tranches_dt$detachment[i]
    thk <- det - att
    tranche_notional <- thk * total_notional
    running_spread_bps <- tranches_dt$running_bps[i]
    
    # Calculate tranche loss fraction for each MC path
    t_loss_fracs <- tranche_loss_fraction(loss_samples, att, det)
    tranche_expected_loss_frac <- mean(t_loss_fracs)
    expected_protection_loss_amount <- tranche_expected_loss_frac * tranche_notional
    
    # Discounted Protection Leg PV
    # Assume default timing is distributed uniformly over the 5-year period for expected loss arrival
    # PV_Prot = sum_{t} DF(t) * dLoss(t)
    # Using continuous mid-period approximation:
    avg_df <- mean(dfs)
    pv_protection_leg <- expected_protection_loss_amount * avg_df
    
    # Expected Tranche Outstanding Notional over time
    # Tranche amortises as losses eat into it
    exp_rem_factor <- 1 - (tranche_expected_loss_frac * 0.5) # Average notional exposed to coupon
    
    # Premium Leg PV for 1 bp running spread (Risky PV01)
    # PV01 = sum_{t} DF(t) * dcf * Notional(t) * 0.0001
    pv01_unit <- sum(dfs * 0.25 * tranche_notional * exp_rem_factor * 0.0001)
    
    # Premium Leg PV at stated running spread
    pv_premium_leg <- pv01_unit * running_spread_bps
    
    # Fair Running Spread (Spread that equates Premium Leg to Protection Leg with 0 upfront):
    # s_fair = PV_Prot / PV01
    fair_spread_bps <- if (pv01_unit > 0) pv_protection_leg / pv01_unit else NA_real_
    
    # Standard Upfront Payment (where running spread is fixed at standard 100 or 500 bps)
    # Upfront = PV_Prot - PV_Prem
    upfront_amount <- pv_protection_leg - pv_premium_leg
    upfront_pct <- (upfront_amount / tranche_notional) * 100
    
    val_list[[i]] <- data.table::data.table(
      tranche_id = t_id,
      name = t_name,
      attachment_pct = att * 100,
      detachment_pct = det * 100,
      thickness_pct = thk * 100,
      notional = tranche_notional,
      stated_running_bps = running_spread_bps,
      fair_spread_bps = round(fair_spread_bps, 1),
      pv01 = round(pv01_unit, 2),
      pv_premium_leg = round(pv_premium_leg, 2),
      pv_protection_leg = round(pv_protection_leg, 2),
      upfront_amount = round(upfront_amount, 2),
      upfront_pct = round(upfront_pct, 2),
      expected_loss_pct = round(tranche_expected_loss_frac * 100, 2),
      market_calibration_mode = "Risk-Neutral Synthetic CDS Pricing Conventions"
    )
  }
  
  data.table::rbindlist(val_list)
}
