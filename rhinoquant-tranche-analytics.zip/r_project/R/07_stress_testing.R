# ==============================================================================
# RhinoQuant Tranche Analytics - 07_stress_testing.R
# Stress Testing Matrix & Semiconductor Borrower Cash-Flow Adapter
# Copyright (c) 2026 RhinoBank Quant Group
# ==============================================================================

#' Semiconductor Borrower Cash-Flow Adapter
#'
#' Adjusts semiconductor obligor cash flows, default hazards, and liquidity
#' based on micro-operational semiconductor shocks:
#'   1. Production delays (months of wafer fab delay)
#'   2. Low fab capacity utilization (e.g., dropping from 85% to 50%)
#'   3. Tape-out / Qualification test failures (triggers margin calls and debt restructuring)
#'   4. Customer Days Sales Outstanding (DSO) payment delays (cash conversion cycle disruption)
#'
#' @param collateral data.table of collateral
#' @param fab_utilization_shock_pct Absolute drop in fab capacity utilization (e.g. -25%)
#' @param tapeout_failure_rate Probability that in-progress tapeouts fail qualification (e.g. 0.40)
#' @param dso_extension_days Additional days added to DSO (e.g. +45 days)
#' @return modified collateral table with shocked coupon, balance, and default ratings
#' @export
apply_semiconductor_stress_adapter <- function(collateral,
                                              fab_utilization_shock_pct = 25,
                                              tapeout_failure_rate = 0.35,
                                              dso_extension_days = 40) {
  dt <- data.table::as.data.table(data.table::copy(collateral))
  
  # Identify semiconductor obligors
  semi_idx <- which(dt$is_semiconductor == TRUE | dt$sector == "Semiconductor")
  if (length(semi_idx) == 0) {
    return(dt)
  }
  
  for (i in semi_idx) {
    # 1. Fab capacity utilization shock:
    curr_util <- if (!is.na(dt$fab_utilization_pct[i])) dt$fab_utilization_pct[i] else 80
    new_util <- max(40, curr_util - fab_utilization_shock_pct)
    dt$fab_utilization_pct[i] <- new_util
    
    # Low utilization directly shrinks EBITDA margins: downgrade rating notch
    if (new_util < 65) {
      curr_r <- dt$rating[i]
      new_r <- switch(curr_r,
                      "BBB+" = "BBB", "BBB" = "BBB-", "BBB-" = "BB+",
                      "BB+" = "BB", "BB" = "BB-", "BB-" = "B+",
                      "B+" = "B", "B" = "B-", "B-" = "CCC+",
                      curr_r)
      dt$rating[i] <- new_r
    }
    
    # 2. Tapeout qualification failure shock:
    stage <- dt$tapeout_stage[i]
    if (!is.na(stage) && grepl("Qualification|Tapeout|Bringup", stage)) {
      # Fail qualification: increase spread or downgrade
      dt$spread_bps[i] <- dt$spread_bps[i] + 120
      # Partial write-down if in extreme bringup failure
      if (grepl("Silicon Bringup|Validation Hold", stage)) {
        dt$current_balance[i] <- dt$current_balance[i] * 0.90
        dt$principal_factor[i] <- dt$current_balance[i] / dt$original_face[i]
      }
    }
    
    # 3. Customer payment delay (DSO extension):
    curr_dso <- if (!is.na(dt$dso_days[i])) dt$dso_days[i] else 60
    new_dso <- curr_dso + dso_extension_days
    dt$dso_days[i] <- new_dso
    
    # Severe cash crunch from DSO > 110 days impairs short-term coupon payment
    if (new_dso > 100) {
      dt$coupon_pct[i] <- max(2.0, dt$coupon_pct[i] * 0.85) # Temporary liquidity deferral
    }
  }
  
  attr(dt, "adapter_applied") <- "SEMICONDUCTOR_MICRO_CASHFLOW_SHOCK"
  dt
}

#' Run Comprehensive Stress Scenarios
#'
#' Evaluates standard institutional macro scenarios and specialized semiconductor stresses.
#'
#' @param collateral data.table of collateral
#' @param structure list of tranches and rules
#' @return list of scenario results with detailed tranche metrics
#' @export
run_stress_scenarios <- function(collateral, structure) {
  scenarios <- list(
    "Baseline" = list(
      name = "Baseline Contractual Forecast",
      default_rate_annual = 0.022,
      recovery_rate = 0.65,
      recovery_delay_quarters = 2,
      base_interest_rate_pct = 4.25,
      adapter = NULL
    ),
    "Clustered_Defaults" = list(
      name = "Contagion & Clustered Defaults",
      default_rate_annual = 0.065, # 3x baseline default rate
      recovery_rate = 0.50,
      recovery_delay_quarters = 3,
      base_interest_rate_pct = 4.25,
      adapter = NULL
    ),
    "Recovery_Collapse" = list(
      name = "Severe Recovery Collapse",
      default_rate_annual = 0.035,
      recovery_rate = 0.25, # Recovery crashes to 25%
      recovery_delay_quarters = 4,
      base_interest_rate_pct = 4.00,
      adapter = NULL
    ),
    "Delayed_Recoveries" = list(
      name = "Extended Resolution (Delayed Recoveries)",
      default_rate_annual = 0.030,
      recovery_rate = 0.55,
      recovery_delay_quarters = 6, # 18 months resolution delay
      base_interest_rate_pct = 4.25,
      adapter = NULL
    ),
    "Aggressive_Rate_Hikes" = list(
      name = "Aggressive Monetary Tightening (+300 bps)",
      default_rate_annual = 0.038,
      recovery_rate = 0.55,
      recovery_delay_quarters = 2,
      base_interest_rate_pct = 7.25, # Rates rise to 7.25%
      adapter = NULL
    ),
    "Major_Obligor_Failure" = list(
      name = "Top-3 Obligors Sudden Default",
      default_rate_annual = 0.045,
      recovery_rate = 0.40,
      recovery_delay_quarters = 3,
      base_interest_rate_pct = 4.25,
      adapter = "TOP3_DEFAULT"
    ),
    "Semiconductor_Fab_Disruption" = list(
      name = "Semiconductor Supply Shock & Fab Utilization Crunch",
      default_rate_annual = 0.040,
      recovery_rate = 0.45,
      recovery_delay_quarters = 3,
      base_interest_rate_pct = 4.50,
      adapter = "SEMI_ADAPTER"
    )
  )
  
  results <- list()
  
  for (scen_key in names(scenarios)) {
    scen <- scenarios[[scen_key]]
    
    # Apply adapter if specified
    active_collat <- data.table::copy(collateral)
    if (!is.null(scen$adapter)) {
      if (scen$adapter == "SEMI_ADAPTER") {
        active_collat <- apply_semiconductor_stress_adapter(active_collat,
                                                           fab_utilization_shock_pct = 30,
                                                           tapeout_failure_rate = 0.45,
                                                           dso_extension_days = 50)
      } else if (scen$adapter == "TOP3_DEFAULT") {
        data.table::setorder(active_collat, -current_balance)
        # Default top 3 obligors immediately
        active_collat$current_balance[1:3] <- active_collat$current_balance[1:3] * 0.40 # Immediate 60% loss
        active_collat$principal_factor[1:3] <- active_collat$current_balance[1:3] / active_collat$original_face[1:3]
      }
    }
    
    # Run waterfall under scenario
    wf_res <- run_waterfall(active_collat, structure, scenario = scen)
    val_res <- value_cash_tranche(wf_res, structure$tranches)
    
    # Summary metrics per tranche
    scen_summary <- data.table::copy(val_res)
    scen_summary[, scenario := scen_key]
    scen_summary[, scenario_name := scen$name]
    scen_summary[, oc_breached := any(!wf_res$ledger$senior_oc_pass | !wf_res$ledger$mezz_oc_pass | !wf_res$ledger$junior_oc_pass)]
    scen_summary[, total_interest_paid := sum(wf_res$ledger$aaa_interest + wf_res$ledger$aa_interest + wf_res$ledger$bbb_interest + wf_res$ledger$equity_distribution)]
    
    results[[scen_key]] <- list(
      scenario_info = scen,
      tranche_valuations = scen_summary,
      ledger = wf_res$ledger,
      ending_reserve = wf_res$final_reserve,
      cash_conserved = wf_res$audit_cash_conserved
    )
  }
  
  results
}
