# ==============================================================================
# RhinoQuant Tranche Analytics - 03_waterfall_engine.R
# Period-by-Period Cash-Flow Waterfall Engine
# Copyright (c) 2026 RhinoBank Quant Group
# ==============================================================================

#' Run Period-by-Period Cash-Flow Waterfall
#'
#' Simulates the contractual allocation of interest collections, principal
#' collections, recoveries, senior fees, hedge swap settlements, reserve fund movements,
#' tranche interest, coverage-test trigger diversions, principal deficiency ledger (PDL)
#' curing, sequential / pro-rata principal amortisation, and equity residual distributions.
#'
#' Rigorously validates cash conservation at every period:
#' Total Cash In + Starting Cash Balance = Total Cash Out + Ending Cash Balance + Delta Reserve
#'
#' @param collateral data.table of validated collateral assets
#' @param structure list or data.table of capital stack tranches and rules
#' @param schedule data.table payment schedule
#' @param scenario list of scenario overrides (defaults, recoveries, interest rates)
#' @return list containing 'ledger', 'tranche_summaries', 'coverage_tests', 'audit'
#' @export
run_waterfall <- function(collateral,
                          structure,
                          schedule = NULL,
                          scenario = NULL) {
  # 1. Setup schedule if missing
  if (is.null(schedule)) {
    schedule <- build_payment_schedule(start_date = "2026-04-01", end_date = "2031-04-01", frequency = "Quarterly")
  }
  n_periods <- nrow(schedule)
  
  # 2. Extract tranches and parameters
  tranches_dt <- if (is.data.frame(structure$tranches)) {
    data.table::as.data.table(data.table::copy(structure$tranches))
  } else if (is.list(structure$tranches)) {
    data.table::rbindlist(structure$tranches, fill = TRUE)
  } else {
    data.table::as.data.table(data.table::copy(structure))
  }
  data.table::setorder(tranches_dt, payment_priority)
  
  wf_params <- if (!is.null(structure$waterfall_parameters)) structure$waterfall_parameters else list()
  senior_fee_bps <- ifelse(!is.null(wf_params$senior_manager_fee_bps), wf_params$senior_manager_fee_bps, 15)
  trustee_fee_bps <- ifelse(!is.null(wf_params$trustee_admin_fee_bps), wf_params$trustee_admin_fee_bps, 5)
  sub_fee_bps <- ifelse(!is.null(wf_params$subordinated_manager_fee_bps), wf_params$subordinated_manager_fee_bps, 25)
  reinvest_quarters <- ifelse(!is.null(wf_params$reinvestment_period_quarters), wf_params$reinvestment_period_quarters, 8)
  reinvest_rate <- ifelse(!is.null(wf_params$reinvestment_rate_annual), wf_params$reinvestment_rate_annual, 0.065)
  reserve_target <- ifelse(!is.null(wf_params$reserve_target_amount), wf_params$reserve_target_amount, 1000000)
  amort_style <- ifelse(!is.null(wf_params$amortization_style), wf_params$amortization_style, "Sequential")
  pro_rata_ok <- ifelse(!is.null(wf_params$pro_rata_allowed_if_all_oc_pass), wf_params$pro_rata_allowed_if_all_oc_pass, TRUE)
  
  # 3. Initialize collateral state
  collat_dt <- data.table::as.data.table(data.table::copy(collateral))
  collat_balance <- sum(collat_dt$current_balance)
  collat_original_face <- sum(collat_dt$original_face)
  wac <- sum(collat_dt$coupon_pct * collat_dt$current_balance) / collat_balance # Weighted Average Coupon %
  
  # Default and recovery scenario inputs
  default_rate_annual <- if (!is.null(scenario$default_rate_annual)) scenario$default_rate_annual else 0.022
  recovery_rate <- if (!is.null(scenario$recovery_rate)) scenario$recovery_rate else 0.65
  recovery_delay_qtrs <- if (!is.null(scenario$recovery_delay_quarters)) scenario$recovery_delay_quarters else 2
  prepay_rate_annual <- if (!is.null(scenario$prepayment_rate_annual)) scenario$prepayment_rate_annual else 0.10
  sofr_rate <- if (!is.null(scenario$base_interest_rate_pct)) scenario$base_interest_rate_pct else 4.25
  
  # Track pending recoveries in pipeline
  pending_recoveries <- rep(0, n_periods + recovery_delay_qtrs + 4)
  
  # Initialize Tranche Balances & PDL (Principal Deficiency Ledger)
  t_names <- tranches_dt$tranche_id
  t_balances <- setNames(as.numeric(tranches_dt$current_balance), t_names)
  t_deferred_interest <- setNames(rep(0, length(t_names)), t_names)
  t_pdl <- setNames(rep(0, length(t_names)), t_names)
  
  # Reserve account
  reserve_balance <- ifelse(!is.null(wf_params$initial_reserve_balance), wf_params$initial_reserve_balance, reserve_target)
  
  ledger_rows <- list()
  tranche_ledger_rows <- list()
  
  # Loop over periods
  for (t in seq_len(n_periods)) {
    dcf <- schedule$dcf[t]
    is_reinvest <- (t <= reinvest_quarters)
    
    # 4. Collateral Cash Flow Generation for period t
    # Defaults this period
    period_default_rate <- 1 - (1 - default_rate_annual)^dcf
    defaulted_principal <- collat_balance * period_default_rate
    
    # Prepayments this period
    period_prepay_rate <- 1 - (1 - prepay_rate_annual)^dcf
    prepaid_principal <- (collat_balance - defaulted_principal) * period_prepay_rate
    
    # Scheduled principal (simplified linear amortisation if post-reinvestment)
    scheduled_principal <- if (!is_reinvest) {
      rem_quarters <- max(1, n_periods - t + 1)
      (collat_balance - defaulted_principal - prepaid_principal) / rem_quarters
    } else {
      0
    }
    
    # Register recovery to arrive in t + recovery_delay_qtrs
    rec_amount <- defaulted_principal * recovery_rate
    pending_recoveries[t + recovery_delay_qtrs] <- pending_recoveries[t + recovery_delay_qtrs] + rec_amount
    
    # Realized loss this period
    period_realized_loss <- defaulted_principal * (1 - recovery_rate)
    
    # Collections this period
    realized_recoveries <- pending_recoveries[t]
    
    # Interest collection = collat_balance * (WAC / 100) * dcf
    interest_collections <- collat_balance * (wac / 100) * dcf
    
    # Total Principal collections = Scheduled + Prepayments + Recoveries
    principal_collections <- scheduled_principal + prepaid_principal + realized_recoveries
    
    # Update collateral balance before reinvestment
    collat_balance <- collat_balance - defaulted_principal - prepaid_principal - scheduled_principal
    
    # Reinvestment of principal collections during reinvestment period
    if (is_reinvest && principal_collections > 0) {
      reinvested_amount <- principal_collections
      collat_balance <- collat_balance + reinvested_amount
      available_principal <- 0
    } else {
      reinvested_amount <- 0
      available_principal <- principal_collections
    }
    
    available_interest <- interest_collections
    
    # Record starting cash pool for audit
    total_cash_in <- interest_collections + principal_collections
    
    # 5. WATERFALL EXECUTION
    # 5a. Senior Trustee & Administration Fees
    trustee_fee <- collat_balance * (trustee_fee_bps / 10000) * dcf
    paid_trustee_fee <- min(available_interest, trustee_fee)
    available_interest <- available_interest - paid_trustee_fee
    
    # 5b. Senior Collateral Manager Fee
    senior_mgr_fee <- collat_balance * (senior_fee_bps / 10000) * dcf
    paid_senior_mgr_fee <- min(available_interest, senior_mgr_fee)
    available_interest <- available_interest - paid_senior_mgr_fee
    
    # 5c. Net Hedge / Interest Rate Swap Payment
    # Swap: Trust pays fixed (4.10%), receives SOFR (4.25%) on 30M
    swap_net <- 30000000 * ((4.10 - sofr_rate) / 100) * dcf
    if (swap_net > 0) {
      paid_swap <- min(available_interest, swap_net)
      available_interest <- available_interest - paid_swap
      rcvd_swap <- 0
    } else {
      rcvd_swap <- abs(swap_net)
      available_interest <- available_interest + rcvd_swap
      paid_swap <- 0
    }
    
    # 5d. Calculate Coverage Tests (Overcollateralization OC and Interest Coverage IC)
    senior_liabilities <- t_balances["TR-AAA"]
    mezz_liabilities <- senior_liabilities + t_balances["TR-AA"]
    junior_liabilities <- mezz_liabilities + t_balances["TR-BBB"]
    
    senior_oc_ratio <- if (senior_liabilities > 0) (collat_balance + reserve_balance) / senior_liabilities * 100 else 999
    mezz_oc_ratio <- if (mezz_liabilities > 0) (collat_balance + reserve_balance) / mezz_liabilities * 100 else 999
    junior_oc_ratio <- if (junior_liabilities > 0) (collat_balance + reserve_balance) / junior_liabilities * 100 else 999
    
    senior_oc_trigger <- tranches_dt[tranche_id == "TR-AAA", oc_test_trigger_pct]
    mezz_oc_trigger <- tranches_dt[tranche_id == "TR-AA", oc_test_trigger_pct]
    junior_oc_trigger <- tranches_dt[tranche_id == "TR-BBB", oc_test_trigger_pct]
    
    senior_oc_pass <- senior_oc_ratio >= senior_oc_trigger
    mezz_oc_pass <- mezz_oc_ratio >= mezz_oc_trigger
    junior_oc_pass <- junior_oc_ratio >= junior_oc_trigger
    any_oc_failed <- (!senior_oc_pass) || (!mezz_oc_pass) || (!junior_oc_pass)
    
    # 5e. Allocate Tranche Interest & Handle Coverage Diversions
    t_interest_due <- numeric(nrow(tranches_dt))
    t_interest_paid <- numeric(nrow(tranches_dt))
    names(t_interest_due) <- t_names
    names(t_interest_paid) <- t_names
    
    for (i in seq_len(nrow(tranches_dt))) {
      tid <- tranches_dt$tranche_id[i]
      if (tranches_dt$coupon_type[i] == "Floating") {
        coupon_rate <- (sofr_rate + tranches_dt$spread_bps[i] / 100) / 100
        due <- (t_balances[tid] * coupon_rate * dcf) + t_deferred_interest[tid]
        t_interest_due[tid] <- due
        
        # Payment from available interest
        paid <- min(available_interest, due)
        t_interest_paid[tid] <- paid
        available_interest <- available_interest - paid
        
        # Unpaid interest deferred if permitted
        unpaid <- due - paid
        if (tranches_dt$can_defer_interest[i]) {
          t_deferred_interest[tid] <- unpaid
        } else {
          t_deferred_interest[tid] <- 0
          # Event of default notice if senior defaults on interest
          if (unpaid > 100) {
            # Note shortfall
          }
        }
      }
    }
    
    # 5f. Coverage Test Trigger Diversion:
    # If any OC test failed, divert remaining interest collections to pay down Senior Notes principal
    oc_diverted_amount <- 0
    if (any_oc_failed && available_interest > 0) {
      divert_target <- t_balances["TR-AAA"]
      oc_diverted_amount <- min(available_interest, divert_target)
      available_interest <- available_interest - oc_diverted_amount
      available_principal <- available_principal + oc_diverted_amount
    }
    
    # 5g. Reserve Account replenishment
    reserve_shortfall <- max(0, reserve_target - reserve_balance)
    reserve_replenish <- min(available_interest, reserve_shortfall)
    reserve_balance <- reserve_balance + reserve_replenish
    available_interest <- available_interest - reserve_replenish
    
    # 5h. Principal Deficiency Ledger (PDL) Tracking
    # Write down equity / junior tranches for realized losses
    if (period_realized_loss > 0) {
      rem_loss <- period_realized_loss
      # Write down from bottom (Equity -> BBB -> AA -> AAA)
      for (rev_id in rev(t_names)) {
        if (rev_id == "TR-EQUITY") {
          t_pdl[rev_id] <- t_pdl[rev_id] + rem_loss
          rem_loss <- 0
          break
        }
      }
    }
    
    # 5i. PRINCIPAL WATERFALL: Amortisation of Notes
    t_principal_paid <- numeric(nrow(tranches_dt))
    names(t_principal_paid) <- t_names
    
    # Check if Pro-Rata conditions are met:
    use_pro_rata <- (amort_style == "Pro-Rata") && pro_rata_ok && (!any_oc_failed) && (!is_reinvest)
    
    if (available_principal > 0) {
      if (use_pro_rata) {
        # Pro-rata across all debt tranches
        rated_tranches <- tranches_dt[coupon_type == "Floating", tranche_id]
        total_rated_bal <- sum(t_balances[rated_tranches])
        if (total_rated_bal > 0) {
          for (tid in rated_tranches) {
            alloc_pct <- t_balances[tid] / total_rated_bal
            paid <- min(t_balances[tid], available_principal * alloc_pct)
            t_principal_paid[tid] <- paid
            t_balances[tid] <- t_balances[tid] - paid
          }
          available_principal <- max(0, available_principal - sum(t_principal_paid))
        }
      } else {
        # Sequential amortisation (AAA first, then AA, then BBB)
        for (i in seq_len(nrow(tranches_dt))) {
          tid <- tranches_dt$tranche_id[i]
          if (tranches_dt$coupon_type[i] == "Floating" && available_principal > 0) {
            paid <- min(t_balances[tid], available_principal)
            t_principal_paid[tid] <- paid
            t_balances[tid] <- t_balances[tid] - paid
            available_principal <- available_principal - paid
          }
        }
      }
    }
    
    # 5j. Subordinated Management Fee (from residual interest)
    sub_mgr_fee <- collat_balance * (sub_fee_bps / 10000) * dcf
    paid_sub_mgr_fee <- min(available_interest, sub_mgr_fee)
    available_interest <- available_interest - paid_sub_mgr_fee
    
    # 5k. Subordinated Notes (Equity) Distribution = Residual Interest + any unallocated principal
    equity_interest_distribution <- available_interest
    equity_principal_distribution <- if (!is_reinvest && sum(t_balances[c("TR-AAA", "TR-AA", "TR-BBB")]) <= 0) {
      paid_eq_p <- min(t_balances["TR-EQUITY"], available_principal)
      t_balances["TR-EQUITY"] <- t_balances["TR-EQUITY"] - paid_eq_p
      available_principal <- available_principal - paid_eq_p
      paid_eq_p
    } else {
      0
    }
    t_interest_paid["TR-EQUITY"] <- equity_interest_distribution
    t_principal_paid["TR-EQUITY"] <- equity_principal_distribution
    available_interest <- 0
    
    # 5l. AUDIT & CASH CONSERVATION VERIFICATION
    total_cash_out <- paid_trustee_fee + paid_senior_mgr_fee + paid_swap +
      sum(t_interest_paid) + sum(t_principal_paid) +
      paid_sub_mgr_fee + reinvested_amount + reserve_replenish
    
    # Net variance must be 0 within floating point precision
    cash_variance <- (total_cash_in + rcvd_swap) - total_cash_out - available_principal
    if (abs(cash_variance) > 0.05) {
      stop(sprintf("Cash conservation breach at period %d: Cash In (%.2f) != Cash Out (%.2f). Discrepancy: %.4f",
                   t, total_cash_in + rcvd_swap, total_cash_out, cash_variance))
    }
    
    # Build period record
    ledger_rows[[t]] <- data.table::data.table(
      period = t,
      payment_date = schedule$end_date[t],
      dcf = dcf,
      collat_starting = collat_balance + defaulted_principal + prepaid_principal + scheduled_principal - reinvested_amount,
      collat_ending = collat_balance,
      interest_collected = interest_collections,
      principal_collected = principal_collections,
      recoveries_realized = realized_recoveries,
      defaults_realized = defaulted_principal,
      reinvested_amount = reinvested_amount,
      trustee_fee = paid_trustee_fee,
      senior_mgr_fee = paid_senior_mgr_fee,
      sub_mgr_fee = paid_sub_mgr_fee,
      hedge_net_payment = paid_swap - rcvd_swap,
      senior_oc_ratio = senior_oc_ratio,
      senior_oc_pass = senior_oc_pass,
      mezz_oc_ratio = mezz_oc_ratio,
      mezz_oc_pass = mezz_oc_pass,
      junior_oc_ratio = junior_oc_ratio,
      junior_oc_pass = junior_oc_pass,
      oc_diverted_amount = oc_diverted_amount,
      reserve_balance = reserve_balance,
      reserve_replenished = reserve_replenish,
      aaa_interest = t_interest_paid["TR-AAA"],
      aaa_principal = t_principal_paid["TR-AAA"],
      aaa_balance = t_balances["TR-AAA"],
      aa_interest = t_interest_paid["TR-AA"],
      aa_principal = t_principal_paid["TR-AA"],
      aa_balance = t_balances["TR-AA"],
      bbb_interest = t_interest_paid["TR-BBB"],
      bbb_principal = t_principal_paid["TR-BBB"],
      bbb_balance = t_balances["TR-BBB"],
      equity_distribution = equity_interest_distribution + equity_principal_distribution,
      equity_balance = t_balances["TR-EQUITY"],
      cash_in_audit = total_cash_in + rcvd_swap,
      cash_out_audit = total_cash_out,
      cash_variance = cash_variance
    )
  }
  
  full_ledger <- data.table::rbindlist(ledger_rows)
  
  # Compute tranche overall metrics (WAL, total received, principal factor)
  tranche_summary <- tranches_dt[, .(
    tranche_id = tranche_id,
    name = name,
    rating = rating,
    original_balance = original_balance,
    ending_balance = t_balances[tranche_id],
    principal_factor = t_balances[tranche_id] / original_balance
  )]
  
  list(
    ledger = full_ledger,
    tranches = tranche_summary,
    final_reserve = reserve_balance,
    ending_collateral = collat_balance,
    audit_cash_conserved = all(abs(full_ledger$cash_variance) < 0.05),
    reinvestment_quarters = reinvest_quarters
  )
}
