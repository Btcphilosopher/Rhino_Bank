# ==============================================================================
# RhinoQuant Tranche Analytics - 01_data_models.R
# Institutional Structured Credit & CDO Tranche Analytics
# Copyright (c) 2026 RhinoBank Quant Group
# ==============================================================================

#' Create a validated Model Run metadata object
#' @param run_id Unique run identifier (e.g. RUN-20260315-001)
#' @param mode Analysis mode: "cash_cdo", "synthetic_tranche", or "investor_portfolio"
#' @param user_id Analyst or system identifier
#' @param description Narrative of analytical purpose
#' @return S3 object of class 'rhino_model_run'
create_model_run <- function(run_id = paste0("RUN-", format(Sys.time(), "%Y%m%d%H%M%S")),
                             mode = c("cash_cdo", "synthetic_tranche", "investor_portfolio"),
                             user_id = "tranche_quant_desk",
                             description = "Institutional CLO / CDO tranche evaluation") {
  mode <- match.arg(mode)
  structure(
    list(
      run_id = as.character(run_id),
      mode = mode,
      user_id = as.character(user_id),
      created_at = Sys.time(),
      version = "3.4.0-rhinoquant",
      description = as.character(description),
      status = "INITIALIZED"
    ),
    class = "rhino_model_run"
  )
}

#' Validate Collateral Asset Table
#'
#' Rejects duplicate assets, missing currencies, unsupported assumptions,
#' and invalid numeric values. Never silently replaces NA with 0.
#'
#' @param collateral data.frame or data.table of collateral assets
#' @return validated data.table
#' @export
validate_collateral <- function(collateral) {
  if (missing(collateral) || is.null(collateral) || nrow(collateral) == 0) {
    stop("Collateral validation error: Collateral dataset is missing or empty.")
  }
  
  dt <- data.table::as.data.table(data.table::copy(collateral))
  
  required_cols <- c("asset_id", "obligor_id", "obligor_name", "sector", "region",
                     "rating", "spread_bps", "coupon_pct", "original_face",
                     "current_balance", "principal_factor", "maturity_years",
                     "seniority", "currency")
  missing_cols <- setdiff(required_cols, names(dt))
  if (length(missing_cols) > 0) {
    stop(sprintf("Collateral validation error: Missing required column(s): %s",
                 paste(missing_cols, collapse = ", ")))
  }
  
  # Check for duplicate asset IDs
  dups <- dt[duplicated(asset_id), asset_id]
  if (length(dups) > 0) {
    stop(sprintf("Collateral validation error: Duplicate asset_id(s) detected: %s",
                 paste(head(dups, 5), collapse = ", ")))
  }
  
  # Check for missing values in core fields - Never silently replace with zero
  na_check_cols <- c("asset_id", "obligor_id", "original_face", "current_balance",
                     "principal_factor", "coupon_pct", "currency")
  for (col in na_check_cols) {
    if (any(is.na(dt[[col]]))) {
      bad_rows <- which(is.na(dt[[col]]))
      stop(sprintf("Collateral validation error: Column '%s' contains NA at row(s) %s. Silently replacing missing values with zero is strictly prohibited.",
                   col, paste(head(bad_rows, 5), collapse = ", ")))
    }
  }
  
  # Validate currency
  invalid_currencies <- dt[!currency %in% c("USD", "EUR", "GBP"), unique(currency)]
  if (length(invalid_currencies) > 0) {
    stop(sprintf("Collateral validation error: Unsupported currency: %s. Only USD, EUR, GBP supported.",
                 paste(invalid_currencies, collapse = ", ")))
  }
  
  # Validate principal consistency: current_balance <= original_face * 1.0001
  bad_balances <- dt[current_balance > original_face * 1.00001]
  if (nrow(bad_balances) > 0) {
    stop(sprintf("Collateral validation error: Current balance exceeds original face for asset: %s",
                 bad_balances$asset_id[1]))
  }
  
  # Validate principal factor = current_balance / original_face within tolerance
  computed_factor <- dt$current_balance / dt$original_face
  factor_diff <- abs(dt$principal_factor - computed_factor)
  if (any(factor_diff > 0.005)) {
    bad_factor_idx <- which(factor_diff > 0.005)[1]
    stop(sprintf("Collateral validation error: Principal factor mismatch on %s: stated factor is %.4f, computed factor is %.4f",
                 dt$asset_id[bad_factor_idx], dt$principal_factor[bad_factor_idx], computed_factor[bad_factor_idx]))
  }
  
  # Validate rating categories
  valid_ratings <- c("AAA", "AA+", "AA", "AA-", "A+", "A", "A-", "BBB+", "BBB", "BBB-",
                     "BB+", "BB", "BB-", "B+", "B", "B-", "CCC+", "CCC", "CC", "C", "D")
  bad_ratings <- setdiff(unique(dt$rating), valid_ratings)
  if (length(bad_ratings) > 0) {
    stop(sprintf("Collateral validation error: Unsupported rating(s): %s",
                 paste(bad_ratings, collapse = ", ")))
  }
  
  # Validate maturity and spreads
  if (any(dt$maturity_years <= 0)) {
    stop("Collateral validation error: Maturity must be strictly positive.")
  }
  if (any(dt$spread_bps < 0)) {
    stop("Collateral validation error: Spread must be non-negative.")
  }
  
  attr(dt, "validation_timestamp") <- Sys.time()
  attr(dt, "asset_count") <- nrow(dt)
  attr(dt, "total_notional") <- sum(dt$current_balance)
  
  dt
}

#' Validate Capital Structure and Tranche Definitions
#'
#' @param tranches data.frame or list defining tranches
#' @param total_collateral_notional numeric total asset balance
#' @return validated data.table
#' @export
validate_structure <- function(tranches, total_collateral_notional) {
  if (missing(tranches) || is.null(tranches)) {
    stop("Structure validation error: Tranche specification is missing.")
  }
  
  dt <- data.table::as.data.table(data.table::copy(tranches))
  
  required_cols <- c("tranche_id", "name", "rating", "original_balance",
                     "current_balance", "attachment_point", "detachment_point",
                     "thickness", "subordination_pct", "spread_bps", "payment_priority")
  missing_cols <- setdiff(required_cols, names(dt))
  if (length(missing_cols) > 0) {
    stop(sprintf("Structure validation error: Missing tranche field(s): %s",
                 paste(missing_cols, collapse = ", ")))
  }
  
  # Sort by payment priority
  data.table::setorder(dt, payment_priority)
  
  # Attachment and detachment boundary validation: 0 <= attachment < detachment <= 1
  for (i in seq_len(nrow(dt))) {
    att <- dt$attachment_point[i]
    det <- dt$detachment_point[i]
    if (is.na(att) || is.na(det)) {
      stop(sprintf("Structure validation error: NA attachment/detachment in tranche '%s'", dt$tranche_id[i]))
    }
    if (att < 0 || det > 1 || att >= det) {
      stop(sprintf("Structure validation error: Invalid attachment/detachment on '%s': [%.4f, %.4f]. Must satisfy 0 <= att < det <= 1.",
                   dt$tranche_id[i], att, det))
    }
    # Thickness check
    thk <- dt$thickness[i]
    if (abs(thk - (det - att)) > 1e-4) {
      stop(sprintf("Structure validation error: Thickness (%.4f) does not match detachment - attachment (%.4f) for '%s'",
                   thk, det - att, dt$tranche_id[i]))
    }
  }
  
  # Attachment point continuity check: each tranche attachment should equal previous detachment
  if (nrow(dt) > 1) {
    for (i in 2:nrow(dt)) {
      prev_det <- dt$detachment_point[i - 1]
      curr_att <- dt$attachment_point[i]
      if (abs(curr_att - prev_det) > 1e-4) {
        warning(sprintf("Structure notice: Discontinuous capital stack between '%s' (det: %.2f) and '%s' (att: %.2f).",
                        dt$tranche_id[i - 1], prev_det, dt$tranche_id[i], curr_att))
      }
    }
  }
  
  # Capital stack reconciliation with total collateral
  total_tranche_balance <- sum(dt$current_balance)
  if (!missing(total_collateral_notional) && !is.null(total_collateral_notional)) {
    if (abs(total_tranche_balance - total_collateral_notional) > 1.0) {
      warning(sprintf("Capital stack reconciliation notice: Sum of tranche balances (USD %.2f) differs from collateral balance (USD %.2f) by USD %.2f.",
                      total_tranche_balance, total_collateral_notional, total_tranche_balance - total_collateral_notional))
    }
  }
  
  attr(dt, "validation_timestamp") <- Sys.time()
  dt
}

#' Validate Payment Schedule
#' @param start_date Date or string
#' @param end_date Date or string
#' @param frequency "Quarterly", "Semi-Annual", or "Monthly"
#' @return data.table with payment dates, period numbers, and year fractions (ACT/360)
#' @export
build_payment_schedule <- function(start_date = "2026-04-01",
                                   end_date = "2031-04-01",
                                   frequency = c("Quarterly", "Semi-Annual", "Monthly"),
                                   day_count = "ACT/360") {
  frequency <- match.arg(frequency)
  start <- as.Date(start_date)
  end <- as.Date(end_date)
  
  if (end <= start) {
    stop("Payment schedule validation error: end_date must be strictly after start_date.")
  }
  
  months_step <- switch(frequency,
                        "Quarterly" = 3,
                        "Semi-Annual" = 6,
                        "Monthly" = 1)
  
  # Generate payment dates
  dates <- seq(from = start, to = end, by = paste0(months_step, " months"))
  if (tail(dates, 1) < end) {
    dates <- c(dates, end)
  }
  
  n_periods <- length(dates) - 1
  sched <- data.table::data.table(
    period = seq_len(n_periods),
    start_date = dates[1:n_periods],
    end_date = dates[2:(n_periods + 1)]
  )
  sched[, days := as.numeric(end_date - start_date)]
  sched[, dcf := days / 360] # Standard ACT/360
  sched[, cumulative_years := cumsum(days) / 365.25]
  
  sched
}
