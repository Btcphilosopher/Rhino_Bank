# ==============================================================================
# RhinoQuant Tranche Analytics - 10_api_wrapper.R
# Top-Level Institutional Function Exports & Unified Dispatcher
# Copyright (c) 2026 RhinoBank Quant Group
# ==============================================================================

# Source all modular analytical engines
source_dir <- function(path = "R") {
  files <- sort(list.files(path, pattern = "^0[0-9].*\\.R$", full.names = TRUE))
  for (f in files) {
    source(f)
  }
}

# Auto-source if called directly
if (dir.exists("R")) {
  source_dir("R")
} else if (dir.exists("r_project/R")) {
  source_dir("r_project/R")
}

#' Execute Complete End-to-End Tranche Analytics Pipeline
#'
#' Runs the complete analytical workflow:
#' Import -> Validate -> Structure -> Simulate -> Waterfall -> Value -> Stress -> Export
#'
#' @param collateral_path Path to collateral CSV
#' @param structure_path Path to capital stack JSON
#' @param n_sims Monte Carlo path count (default 5000)
#' @param rho Correlation coefficient (default 0.30)
#' @param seed Random seed for reproducibility (default 42)
#' @return Comprehensive result list containing all pipeline outputs
#' @export
run_full_analysis <- function(collateral_path = "data/collateral_pool_100m.csv",
                              structure_path = "data/capital_stack_config.json",
                              n_sims = 5000,
                              rho = 0.30,
                              seed = 42) {
  cat("\n=== RhinoQuant Tranche Analytics Pipeline Initializing ===\n")
  
  # Step 1: Ingest & Validate
  cat("1. Ingesting and validating collateral pool...\n")
  collateral_raw <- data.table::fread(collateral_path)
  collateral <- validate_collateral(collateral_raw)
  cat(sprintf("   [OK] Validated %d assets. Total Face: USD %s\n",
              nrow(collateral), format(sum(collateral$current_balance), big.mark = ",")))
  
  cat("2. Ingesting and validating capital structure...\n")
  structure <- jsonlite::fromJSON(structure_path)
  validated_struct <- validate_structure(structure$tranches, sum(collateral$current_balance))
  cat("   [OK] Capital structure reconciled.\n")
  
  # Step 2: Payment Schedule
  cat("3. Building payment schedule...\n")
  schedule <- build_payment_schedule(
    start_date = structure$closing_date,
    end_date = "2031-04-01",
    frequency = "Quarterly"
  )
  cat(sprintf("   [OK] Generated %d payment periods (ACT/360).\n", nrow(schedule)))
  
  # Step 3: Monte Carlo Credit Simulation
  cat(sprintf("4. Running correlated credit simulation (%d paths, rho = %.2f, seed = %d)...\n", n_sims, rho, seed))
  sim_results <- simulate_portfolio_defaults(
    collateral = collateral,
    n_sims = n_sims,
    correlation_rho = rho,
    copula_type = "Gaussian",
    seed = seed
  )
  cat(sprintf("   [OK] Mean Loss: %.2f%% (SE: +/- %.4f%%). 99%% VaR: USD %s\n",
              sim_results$diagnostics$mean_loss_pct,
              sim_results$diagnostics$mc_standard_error_pct,
              format(round(sim_results$diagnostics$var_99_amount), big.mark = ",")))
  
  # Step 4: Tranche Loss Allocation
  cat("5. Allocating losses across static capital stack...\n")
  tranche_loss_res <- allocate_tranche_losses(
    sim_results$portfolio_loss_fractions,
    validated_struct,
    total_reference_notional = sum(collateral$current_balance)
  )
  cat("   [OK] Tranche loss distribution resolved.\n")
  
  # Step 5: Cash-Flow Waterfall Engine
  cat("6. Executing dynamic period-by-period cash-flow waterfall...\n")
  wf_results <- run_waterfall(collateral, structure, schedule = schedule)
  cat(sprintf("   [OK] Waterfall executed. Cash Conserved: %s. Final Reserve: USD %s\n",
              wf_results$audit_cash_conserved,
              format(wf_results$final_reserve, big.mark = ",")))
  
  # Step 6: Cash Note Valuation
  cat("7. Calculating cash-note valuations, WAL, DM, and IRR...\n")
  val_results <- value_cash_tranche(wf_results, validated_struct)
  cat("   [OK] Note valuations completed.\n")
  
  # Step 7: Synthetic Tranche Valuation
  cat("8. Pricing synthetic CDS tranches...\n")
  syn_results <- value_synthetic_tranche(structure$synthetic_reference_spec, sim_results)
  cat("   [OK] Synthetic premium and protection legs evaluated.\n")
  
  # Step 8: Sensitivities (CRN)
  cat("9. Computing finite-difference sensitivities (DV01, CS01, Rec, Corr, JTD)...\n")
  sens_results <- calculate_sensitivities(collateral, structure, seed = seed)
  cat("   [OK] Risk sensitivities calculated.\n")
  
  # Step 9: Stress Testing Matrix & Semiconductor Adapter
  cat("10. Executing stress testing suite (Macro + Semiconductor adapter)...\n")
  stress_results <- run_stress_scenarios(collateral, structure)
  cat("   [OK] Evaluated 7 stress scenarios.\n")
  
  # Step 10: Export Reproducible Bundle
  cat("11. Exporting reproducible run bundle and markdown report...\n")
  model_run <- create_model_run(run_id = paste0("RUN-", format(Sys.time(), "%Y%m%d-%H%M%S")),
                               mode = "cash_cdo",
                               description = "Institutional CLO 2026-I Primary Benchmark")
  export_res <- export_analysis(
    model_run = model_run,
    waterfall_result = wf_results,
    valuation_result = val_results,
    simulation_result = sim_results,
    stress_results = stress_results
  )
  cat(sprintf("   [OK] Export completed: %s (Hash: %s)\n", export_res$json_bundle, export_res$run_hash))
  
  cat("=== Pipeline Execution Complete ===\n\n")
  
  list(
    model_run = model_run,
    collateral = collateral,
    structure = validated_struct,
    schedule = schedule,
    simulation = sim_results,
    tranche_losses = tranche_loss_res,
    waterfall = wf_results,
    valuation = val_results,
    synthetic = syn_results,
    sensitivities = sens_results,
    stress = stress_results,
    export = export_res
  )
}
