# ==============================================================================
# RhinoQuant Tranche Analytics - 02_tranche_loss.R
# Static Reference Portfolio Analytical Loss Functions
# Copyright (c) 2026 RhinoBank Quant Group
# ==============================================================================

#' Contractual Static Tranche Loss Fraction Function
#'
#' Evaluates the proportion of tranche principal written down given a static
#' cumulative portfolio loss fraction.
#'
#' IMPORTANT ARCHITECTURAL BOUNDARY:
#' This static analytical formula applies strictly to synthetic credit tranches
#' or static unhedged bullet structures. It must NOT be used as a replacement
#' for an amortising cash CDO's contractual period-by-period waterfall, where
#' principal collections, sequential paying down of senior tranches, and
#' coverage-test diversions alter the effective loss absorption dynamically.
#'
#' @param portfolio_loss Numeric or numeric vector of portfolio cumulative loss fraction in [0, 1]
#' @param attachment Tranche attachment point in [0, 1)
#' @param detachment Tranche detachment point in (attachment, 1]
#' @return Tranche loss fraction in [0, 1]
#' @export
tranche_loss_fraction <- function(portfolio_loss, attachment, detachment) {
  # Strict boundary and sanity validations
  if (missing(portfolio_loss) || is.null(portfolio_loss)) {
    stop("Tranche loss error: 'portfolio_loss' must be provided.")
  }
  if (missing(attachment) || missing(detachment)) {
    stop("Tranche loss error: 'attachment' and 'detachment' points must be provided.")
  }
  
  if (attachment < 0 || detachment > 1 || attachment >= detachment) {
    stop(sprintf("Tranche loss error: Invalid attachment (%.4f) and detachment (%.4f). Requires: 0 <= attachment < detachment <= 1",
                 attachment, detachment))
  }
  
  if (any(portfolio_loss < 0, na.rm = TRUE) || any(portfolio_loss > 1, na.rm = TRUE)) {
    stop("Tranche loss error: 'portfolio_loss' must strictly satisfy: 0 <= portfolio_loss <= 1")
  }
  
  pmin(
    pmax(portfolio_loss - attachment, 0),
    detachment - attachment
  ) / (detachment - attachment)
}

#' Allocate Simulated Portfolio Losses to Tranche Capital Stack
#'
#' @param portfolio_loss_samples Numeric vector of simulated portfolio loss fractions (length M)
#' @param tranches data.table of tranches containing 'tranche_id', 'attachment_point', 'detachment_point', 'current_balance'
#' @param total_reference_notional Numeric total reference notional in currency units
#' @param currency ISO currency code (default 'USD')
#' @return List of detailed tranche loss statistics and distribution matrices
#' @export
allocate_tranche_losses <- function(portfolio_loss_samples,
                                   tranches,
                                   total_reference_notional = 100000000,
                                   currency = "USD") {
  if (any(portfolio_loss_samples < 0) || any(portfolio_loss_samples > 1)) {
    stop("Portfolio loss samples must be bounded within [0, 1].")
  }
  
  M <- length(portfolio_loss_samples)
  dt_tranches <- data.table::as.data.table(data.table::copy(tranches))
  
  results <- list()
  summary_rows <- list()
  
  for (i in seq_len(nrow(dt_tranches))) {
    t_id <- dt_tranches$tranche_id[i]
    t_name <- dt_tranches$name[i]
    att <- dt_tranches$attachment_point[i]
    det <- dt_tranches$detachment_point[i]
    thickness <- det - att
    tranche_notional <- thickness * total_reference_notional
    
    # Calculate vector of loss fractions for this tranche across all MC paths
    t_loss_frac <- tranche_loss_fraction(portfolio_loss_samples, att, det)
    t_loss_currency <- t_loss_frac * tranche_notional
    t_remaining_currency <- tranche_notional - t_loss_currency
    t_remaining_frac <- 1 - t_loss_frac
    
    # Metrics
    el_pct <- mean(t_loss_frac)
    el_currency <- mean(t_loss_currency)
    prob_any_loss <- mean(portfolio_loss_samples > att) # Loss > 0%
    prob_complete_loss <- mean(portfolio_loss_samples >= det) # Loss = 100%
    exp_remaining_notional <- mean(t_remaining_currency)
    exp_remaining_pct <- mean(t_remaining_frac)
    
    # Quantiles
    q_probs <- c(0.50, 0.75, 0.90, 0.95, 0.99, 0.999)
    loss_quantiles_pct <- stats::quantile(t_loss_frac, probs = q_probs)
    loss_quantiles_currency <- stats::quantile(t_loss_currency, probs = q_probs)
    
    summary_rows[[i]] <- data.table::data.table(
      tranche_id = t_id,
      name = t_name,
      attachment_pct = att * 100,
      detachment_pct = det * 100,
      thickness_pct = thickness * 100,
      tranche_notional = tranche_notional,
      currency = currency,
      expected_loss_pct = el_pct * 100,
      expected_loss_amount = el_currency,
      prob_any_loss_pct = prob_any_loss * 100,
      prob_complete_loss_pct = prob_complete_loss * 100,
      expected_remaining_amount = exp_remaining_notional,
      expected_remaining_pct = exp_remaining_pct * 100,
      q50_loss_pct = loss_quantiles_pct["50%"] * 100,
      q90_loss_pct = loss_quantiles_pct["90%"] * 100,
      q95_loss_pct = loss_quantiles_pct["95%"] * 100,
      q99_loss_pct = loss_quantiles_pct["99%"] * 100,
      q999_loss_pct = loss_quantiles_pct["99.9%"] * 100
    )
  }
  
  summary_table <- data.table::rbindlist(summary_rows)
  
  list(
    summary = summary_table,
    reference_notional = total_reference_notional,
    sample_count = M,
    portfolio_expected_loss_pct = mean(portfolio_loss_samples) * 100,
    portfolio_expected_loss_amount = mean(portfolio_loss_samples) * total_reference_notional,
    methodology_note = "Static reference portfolio loss partition. For dynamic amortising cash CLO notes, execute run_waterfall()."
  )
}
