# ==============================================================================
# RhinoQuant Tranche Analytics - 06_risk_sensitivities.R
# Finite-Difference Sensitivities & Risk Analytics
# Copyright (c) 2026 RhinoBank Quant Group
# ==============================================================================

#' Calculate Sensitivities with Common Random Numbers (CRN)
#'
#' Evaluates finite-difference sensitivities for interest rates (DV01), credit spreads (CS01),
#' recovery assumptions, correlation/dependence, and jump-to-default (JTD).
#'
#' @param collateral data.table of collateral
#' @param structure list of capital stack
#' @param base_scenario list of baseline scenario parameters
#' @param seed Fixed seed for Common Random Numbers (CRN)
#' @return data.table of sensitivities by tranche
#' @export
calculate_sensitivities <- function(collateral,
                                   structure,
                                   base_scenario = list(),
                                   seed = 42) {
  # 1. Base run
  base_wf <- run_waterfall(collateral, structure, scenario = base_scenario)
  base_val <- value_cash_tranche(base_wf, structure$tranches)
  
  # 2. Interest Rate DV01 (+1 bp parallel bump to SOFR base rate)
  # Bump policy: +0.01% (1 bp)
  ir_bump_scenario <- base_scenario
  ir_bump_scenario$base_interest_rate_pct <- (if (!is.null(base_scenario$base_interest_rate_pct)) base_scenario$base_interest_rate_pct else 4.25) + 0.01
  ir_bump_wf <- run_waterfall(collateral, structure, scenario = ir_bump_scenario)
  ir_bump_val <- value_cash_tranche(ir_bump_wf, structure$tranches)
  
  # DV01 = Change in PV for +1 bp increase
  # DV01 = PV(base) - PV(up)
  dv01_values <- base_val$pv_total - ir_bump_val$pv_total
  
  # 3. Credit Spread CS01 (+1 bp parallel bump to collateral coupons / default rate)
  cs_bump_scenario <- base_scenario
  base_def <- if (!is.null(base_scenario$default_rate_annual)) base_scenario$default_rate_annual else 0.022
  cs_bump_scenario$default_rate_annual <- base_def + 0.0005 # ~5 bps default rate shift
  cs_bump_wf <- run_waterfall(collateral, structure, scenario = cs_bump_scenario)
  cs_bump_val <- value_cash_tranche(cs_bump_wf, structure$tranches)
  cs01_values <- (base_val$pv_total - cs_bump_val$pv_total) / 5.0 # normalized to 1 bp
  
  # 4. Recovery Sensitivity (+5% bump in recovery rate)
  rec_bump_scenario <- base_scenario
  base_rec <- if (!is.null(base_scenario$recovery_rate)) base_scenario$recovery_rate else 0.65
  rec_bump_scenario$recovery_rate <- min(0.95, base_rec + 0.05)
  rec_bump_wf <- run_waterfall(collateral, structure, scenario = rec_bump_scenario)
  rec_bump_val <- value_cash_tranche(rec_bump_wf, structure$tranches)
  rec_sens_values <- (rec_bump_val$pv_total - base_val$pv_total) / 5.0 # per 1% recovery change
  
  # 5. Dependence / Correlation Sensitivity via Credit Simulation with CRN
  sim_base <- simulate_portfolio_defaults(collateral, n_sims = 3000, correlation_rho = 0.30, seed = seed)
  sim_corr_up <- simulate_portfolio_defaults(collateral, n_sims = 3000, correlation_rho = 0.35, seed = seed) # Common Random Numbers!
  
  loss_base <- allocate_tranche_losses(sim_base$portfolio_loss_fractions, structure$tranches)
  loss_corr_up <- allocate_tranche_losses(sim_corr_up$portfolio_loss_fractions, structure$tranches)
  
  corr_sens_values <- (loss_corr_up$summary$expected_loss_amount - loss_base$summary$expected_loss_amount) / 5.0 # per 1% rho
  
  # 6. Jump-to-Default (JTD) of largest obligor
  collat_dt <- data.table::as.data.table(data.table::copy(collateral))
  data.table::setorder(collat_dt, -current_balance)
  largest_obligor_id <- collat_dt$obligor_id[1]
  largest_obligor_name <- collat_dt$obligor_name[1]
  largest_balance <- collat_dt$current_balance[1]
  
  # Default largest obligor immediately with base recovery
  jtd_collateral <- data.table::copy(collat_dt)
  # Mark first asset as defaulted: balance = 0, recovery cash enters
  jtd_collateral$current_balance[1] <- 0
  jtd_collateral$principal_factor[1] <- 0
  
  jtd_wf <- run_waterfall(jtd_collateral, structure, scenario = base_scenario)
  jtd_val <- value_cash_tranche(jtd_wf, structure$tranches)
  jtd_impact_values <- base_val$pv_total - jtd_val$pv_total
  
  # 7. Check Monte Carlo Standard Error threshold
  mc_se <- sim_base$diagnostics$mc_standard_error_pct
  noise_flag <- ifelse(mc_se > 0.15, "WARNING: MC noise may exceed sensitivity magnitude", "RELIABLE")
  
  sens_dt <- data.table::data.table(
    tranche_id = base_val$tranche_id,
    name = base_val$name,
    base_pv = base_val$pv_total,
    dv01_amount = round(dv01_values, 2),
    cs01_amount = round(cs01_values, 2),
    recovery_sens_per_pct = round(rec_sens_values, 2),
    correlation_sens_per_pct = round(corr_sens_values, 2),
    jtd_largest_obligor_loss = round(jtd_impact_values, 2),
    largest_obligor_name = largest_obligor_name,
    largest_exposure = largest_balance,
    crn_seed_used = seed,
    noise_assessment = noise_flag
  )
  
  sens_dt
}
