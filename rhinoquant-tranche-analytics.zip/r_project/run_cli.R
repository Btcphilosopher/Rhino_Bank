#!/usr/bin/env Rscript

# ==============================================================================
# RhinoQuant Tranche Analytics - Headless CLI Execution
# Usage: Rscript r_project/run_cli.R [n_sims] [rho] [seed]
# ==============================================================================

args <- commandArgs(trailingOnly = TRUE)
n_sims <- if (length(args) >= 1) as.integer(args[1]) else 3000
rho    <- if (length(args) >= 2) as.numeric(args[2]) else 0.30
seed   <- if (length(args) >= 3) as.integer(args[3]) else 42

# Ensure project directory is set
if (dir.exists("r_project/R")) {
  setwd("r_project")
}

source("R/01_data_models.R")
source("R/02_tranche_loss.R")
source("R/03_waterfall_engine.R")
source("R/04_credit_simulation.R")
source("R/05_valuation.R")
source("R/06_risk_sensitivities.R")
source("R/07_stress_testing.R")
source("R/08_portfolio_pnl.R")
source("R/09_export_report.R")
source("R/10_api_wrapper.R")

res <- run_full_analysis(
  collateral_path = "data/collateral_pool_100m.csv",
  structure_path = "data/capital_stack_config.json",
  n_sims = n_sims,
  rho = rho,
  seed = seed
)

cat("\nSUCCESS: Analysis complete. Result hash:", res$export$run_hash, "\n")
cat("Output bundle written to:", res$export$json_bundle, "\n")
