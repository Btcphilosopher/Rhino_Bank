library(testthat)
library(data.table)
library(jsonlite)

# Robust root directory resolution
find_project_root <- function() {
  dirs_to_check <- c(".", "..", "../..", "../../..", "r_project", "../r_project")
  for (d in dirs_to_check) {
    if (dir.exists(file.path(d, "r_project", "R"))) return(file.path(d, "r_project"))
    if (dir.exists(file.path(d, "R")) && file.exists(file.path(d, "R", "01_data_models.R"))) return(d)
  }
  return(".")
}

proj_root <- find_project_root()
r_files <- sort(list.files(file.path(proj_root, "R"), pattern = "^0[0-9].*\\.R$", full.names = TRUE))
for (f in r_files) {
  sys.source(f, envir = .GlobalEnv)
}

test_that("1. Analytical loss allocation satisfies boundary conditions", {
  # Boundary tests on tranche_loss_fraction
  # Subordination / attachment = 0.10, detachment = 0.20 (mezzanine)
  att <- 0.10
  det <- 0.20
  
  # Zero portfolio loss
  expect_equal(tranche_loss_fraction(0.00, att, det), 0.0)
  
  # Loss below attachment point -> 0% tranche loss
  expect_equal(tranche_loss_fraction(0.05, att, det), 0.0)
  expect_equal(tranche_loss_fraction(0.10, att, det), 0.0)
  
  # Mid-tranche loss (15% portfolio loss = 50% through 10-20% tranche)
  expect_equal(tranche_loss_fraction(0.15, att, det), 0.5)
  
  # Loss at detachment point -> 100% tranche loss
  expect_equal(tranche_loss_fraction(0.20, att, det), 1.0)
  
  # Loss beyond detachment point -> capped at 100% tranche loss
  expect_equal(tranche_loss_fraction(0.50, att, det), 1.0)
  expect_equal(tranche_loss_fraction(1.00, att, det), 1.0)
})

test_that("2. Analytical loss allocation strictly enforces valid input boundaries", {
  # Attachment < 0 error
  expect_error(tranche_loss_fraction(0.05, -0.05, 0.20))
  
  # Detachment > 1 error
  expect_error(tranche_loss_fraction(0.05, 0.10, 1.05))
  
  # Attachment >= Detachment error
  expect_error(tranche_loss_fraction(0.05, 0.20, 0.10))
  expect_error(tranche_loss_fraction(0.05, 0.15, 0.15))
  
  # Portfolio loss out of [0, 1] range error
  expect_error(tranche_loss_fraction(-0.01, 0.10, 0.20))
  expect_error(tranche_loss_fraction(1.05, 0.10, 0.20))
})

test_that("3. Collateral validation detects duplicates, missing data, and invalid factors", {
  # Valid mock dataset
  valid_dt <- data.table::data.table(
    asset_id = c("A1", "A2"),
    obligor_id = c("O1", "O2"),
    obligor_name = c("Corp 1", "Corp 2"),
    sector = c("Technology", "Healthcare"),
    region = c("North America", "Europe"),
    rating = c("BBB", "BB+"),
    spread_bps = c(200, 350),
    coupon_pct = c(6.5, 7.8),
    original_face = c(1000000, 2000000),
    current_balance = c(1000000, 2000000),
    principal_factor = c(1.0, 1.0),
    maturity_years = c(5.0, 4.0),
    seniority = c("Senior Secured", "Senior Secured"),
    currency = c("USD", "USD")
  )
  
  expect_silent(validate_collateral(valid_dt))
  
  # Duplicate asset_id rejected
  dup_dt <- copy(valid_dt)
  dup_dt$asset_id[2] <- "A1"
  expect_error(validate_collateral(dup_dt), "Duplicate asset_id")
  
  # NA value rejected (never silently replaced)
  na_dt <- copy(valid_dt)
  na_dt$coupon_pct[1] <- NA
  expect_error(validate_collateral(na_dt), "Silently replacing missing values with zero is strictly prohibited")
  
  # Unsupported currency rejected
  curr_dt <- copy(valid_dt)
  curr_dt$currency[1] <- "JPY"
  expect_error(validate_collateral(curr_dt), "Unsupported currency")
})

test_that("4. Capital stack validation ensures valid attachments and reconciliation", {
  valid_tranches <- data.table::data.table(
    tranche_id = c("T1", "T2"),
    name = c("Senior", "Junior"),
    rating = c("AAA", "BBB"),
    original_balance = c(80000000, 20000000),
    current_balance = c(80000000, 20000000),
    attachment_point = c(0.00, 0.80),
    detachment_point = c(0.80, 1.00),
    thickness = c(0.80, 0.20),
    subordination_pct = c(0.20, 0.00),
    spread_bps = c(120, 350),
    payment_priority = c(1, 2)
  )
  
  expect_silent(validate_structure(valid_tranches, 100000000))
  
  # Broken thickness check
  bad_thk <- copy(valid_tranches)
  bad_thk$thickness[1] <- 0.75 # should be 0.80
  expect_error(validate_structure(bad_thk, 100000000), "Thickness .* does not match")
})

test_that("5. Cash-flow waterfall guarantees strict cash conservation across all periods", {
  data_dir <- file.path(proj_root, "data")
  collateral <- validate_collateral(data.table::fread(file.path(data_dir, "collateral_pool_100m.csv")))
  struct <- jsonlite::fromJSON(file.path(data_dir, "capital_stack_config.json"))
  
  wf_res <- run_waterfall(collateral, struct)
  
  expect_true(wf_res$audit_cash_conserved)
  expect_true(all(abs(wf_res$ledger$cash_variance) < 0.05))
  expect_equal(nrow(wf_res$ledger), 20)
})

test_that("6. Coverage test triggers diversion of interest when collateral is impaired", {
  data_dir <- file.path(proj_root, "data")
  collateral <- validate_collateral(data.table::fread(file.path(data_dir, "collateral_pool_100m.csv")))
  struct <- jsonlite::fromJSON(file.path(data_dir, "capital_stack_config.json"))
  
  # Stress scenario with severe default rate triggering OC failure
  severe_scen <- list(
    default_rate_annual = 0.25,
    recovery_rate = 0.20,
    recovery_delay_quarters = 4,
    base_interest_rate_pct = 4.25
  )
  
  wf_res <- run_waterfall(collateral, struct, scenario = severe_scen)
  
  # Check if OC diversion occurred
  expect_true(any(wf_res$ledger$oc_diverted_amount > 0))
  expect_true(wf_res$audit_cash_conserved)
})

test_that("7. Synthetic tranche pricing equates premium leg and protection leg at fair spread", {
  data_dir <- file.path(proj_root, "data")
  collateral <- validate_collateral(data.table::fread(file.path(data_dir, "collateral_pool_100m.csv")))
  struct <- jsonlite::fromJSON(file.path(data_dir, "capital_stack_config.json"))
  
  sim_res <- simulate_portfolio_defaults(collateral, n_sims = 1500, correlation_rho = 0.25, seed = 123)
  syn_res <- value_synthetic_tranche(struct$synthetic_reference_spec, sim_res)
  
  expect_equal(nrow(syn_res), 5)
  # Check equity tranche has higher loss than senior
  expect_gt(syn_res$expected_loss_pct[1], syn_res$expected_loss_pct[4])
  # Check fair spread is non-negative and equity spread is positive
  expect_true(all(syn_res$fair_spread_bps >= 0))
  expect_gt(syn_res$fair_spread_bps[1], 0)
})

test_that("8. Correlated credit simulation is strictly reproducible given random seed", {
  data_dir <- file.path(proj_root, "data")
  collateral <- validate_collateral(data.table::fread(file.path(data_dir, "collateral_pool_100m.csv")))
  
  # Run 1 with seed 999
  run1 <- simulate_portfolio_defaults(collateral, n_sims = 1000, correlation_rho = 0.30, seed = 999)
  # Run 2 with same seed 999
  run2 <- simulate_portfolio_defaults(collateral, n_sims = 1000, correlation_rho = 0.30, seed = 999)
  
  expect_equal(run1$portfolio_loss_fractions, run2$portfolio_loss_fractions)
  expect_equal(run1$diagnostics$mean_loss_pct, run2$diagnostics$mean_loss_pct)
})
