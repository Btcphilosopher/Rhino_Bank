import express from 'express';
import path from 'path';
import fs from 'fs';
import { exec } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '20mb' }));

// Helper to run Rscript commands safely
function runRCommand(cmd: string): Promise<{ stdout: string; stderr: string; exitCode: number }> {
  return new Promise((resolve) => {
    exec(cmd, { cwd: __dirname, timeout: 60000 }, (error, stdout, stderr) => {
      resolve({
        stdout: stdout || '',
        stderr: stderr || '',
        exitCode: error ? (error.code || 1) : 0,
      });
    });
  });
}

// API: Get Collateral Pool CSV
app.get('/api/collateral-pool', (req, res) => {
  const filePath = path.join(__dirname, 'r_project', 'data', 'collateral_pool_100m.csv');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'text/csv');
    res.sendFile(filePath);
  } else {
    res.status(404).json({ error: 'Collateral file not found' });
  }
});

// API: Get Capital Stack Config JSON
app.get('/api/capital-stack', (req, res) => {
  const filePath = path.join(__dirname, 'r_project', 'data', 'capital_stack_config.json');
  if (fs.existsSync(filePath)) {
    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    res.json(data);
  } else {
    res.status(404).json({ error: 'Config file not found' });
  }
});

// API: Get TrancheDesk Trades
app.get('/api/tranche-desk-trades', (req, res) => {
  const filePath = path.join(__dirname, 'r_project', 'data', 'tranche_desk_trades.csv');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'text/csv');
    res.sendFile(filePath);
  } else {
    res.status(404).json({ error: 'Trades file not found' });
  }
});

// API: Run Real R testthat Suite via Rscript
app.post('/api/run-r-tests', async (req, res) => {
  try {
    const result = await runRCommand('Rscript r_project/tests/testthat.R');
    res.json({
      success: result.exitCode === 0,
      stdout: result.stdout,
      stderr: result.stderr,
      exitCode: result.exitCode,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// API: Run Headless R CLI Pipeline
app.post('/api/run-r-cli', async (req, res) => {
  try {
    const { nSims = 2000, rho = 0.30, seed = 42 } = req.body;
    const cmd = `Rscript r_project/run_cli.R ${parseInt(nSims)} ${parseFloat(rho)} ${parseInt(seed)}`;
    const result = await runRCommand(cmd);
    res.json({
      success: result.exitCode === 0,
      stdout: result.stdout,
      stderr: result.stderr,
      exitCode: result.exitCode,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// API: Get list of R Project Files and source code
app.get('/api/r-source-files', (req, res) => {
  try {
    const rDir = path.join(__dirname, 'r_project', 'R');
    const testsDir = path.join(__dirname, 'r_project', 'tests', 'testthat');
    const files: Array<{ name: string; path: string; category: string; content: string }> = [];

    // Core R modules
    if (fs.existsSync(rDir)) {
      const rFiles = fs.readdirSync(rDir).filter((f) => f.endsWith('.R')).sort();
      for (const file of rFiles) {
        const fullPath = path.join(rDir, file);
        files.push({
          name: file,
          path: `r_project/R/${file}`,
          category: 'Core R Engine',
          content: fs.readFileSync(fullPath, 'utf-8'),
        });
      }
    }

    // App & CLI
    const appPath = path.join(__dirname, 'r_project', 'app.R');
    if (fs.existsSync(appPath)) {
      files.push({
        name: 'app.R',
        path: 'r_project/app.R',
        category: 'Shiny Dashboard',
        content: fs.readFileSync(appPath, 'utf-8'),
      });
    }

    const cliPath = path.join(__dirname, 'r_project', 'run_cli.R');
    if (fs.existsSync(cliPath)) {
      files.push({
        name: 'run_cli.R',
        path: 'r_project/run_cli.R',
        category: 'Headless CLI',
        content: fs.readFileSync(cliPath, 'utf-8'),
      });
    }

    // Test suite
    const testPath = path.join(testsDir, 'test_tranche_analytics.R');
    if (fs.existsSync(testPath)) {
      files.push({
        name: 'test_tranche_analytics.R',
        path: 'r_project/tests/testthat/test_tranche_analytics.R',
        category: 'Testthat Suite',
        content: fs.readFileSync(testPath, 'utf-8'),
      });
    }

    res.json({ files });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Mount Vite or serve static
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`RhinoQuant Tranche Analytics server running on port ${PORT}`);
  });
}

startServer();
