import React, { useMemo } from 'react';
import {
  Flame,
  Activity,
  BarChart3,
  CheckCircle2,
  AlertTriangle,
  Info,
  Sliders,
  TrendingDown,
  Clock,
  RotateCcw,
} from 'lucide-react';
import { SimulationDiagnostics } from '../types/tranche';

interface SimulationTabProps {
  diagnostics: SimulationDiagnostics;
  lossFractions: number[];
  nSims: number;
  setNSims: (n: number) => void;
  rho: number;
  setRho: (r: number) => void;
  copulaType: 'Gaussian' | 'Student-t';
  setCopulaType: (c: 'Gaussian' | 'Student-t') => void;
  seed: number;
  setSeed: (s: number) => void;
  onReSimulate: () => void;
  isExecuting: boolean;
  totalNotional: number;
}

export const SimulationTab: React.FC<SimulationTabProps> = ({
  diagnostics,
  lossFractions,
  nSims,
  setNSims,
  rho,
  setRho,
  copulaType,
  setCopulaType,
  seed,
  setSeed,
  onReSimulate,
  isExecuting,
  totalNotional,
}) => {
  // Generate histogram bins for loss distribution
  const histogramBins = useMemo(() => {
    const binCount = 20;
    const maxLoss = Math.max(0.12, Math.min(0.35, diagnostics.q999_pct / 100 * 1.2));
    const step = maxLoss / binCount;
    const bins = new Array(binCount).fill(0).map((_, i) => ({
      rangeStart: i * step,
      rangeEnd: (i + 1) * step,
      label: `${(i * step * 100).toFixed(1)}%`,
      count: 0,
    }));

    for (const loss of lossFractions) {
      const idx = Math.min(binCount - 1, Math.floor(loss / step));
      if (idx >= 0 && idx < binCount) {
        bins[idx].count++;
      }
    }

    const maxCount = Math.max(...bins.map((b) => b.count), 1);
    return bins.map((b) => ({
      ...b,
      frequencyPct: (b.count / lossFractions.length) * 100,
      heightPct: (b.count / maxCount) * 100,
    }));
  }, [lossFractions, diagnostics]);

  return (
    <div className="space-y-6">
      {/* Simulation Parameter Controls */}
      <div className="bg-[#111620] border border-[#1e293b] p-6 rounded-xl">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-[#1e293b] mb-4 gap-2">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-[#c5a059]" />
            <span>Correlated Credit Copula Configuration</span>
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Runtime: <strong className="text-emerald-400">{diagnostics.runtime_seconds.toFixed(3)}s</strong> • Seed: {seed}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Slider 1: Paths */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Monte Carlo Paths:</span>
              <strong className="text-[#c5a059]">{nSims.toLocaleString()}</strong>
            </div>
            <input
              type="range"
              min="1000"
              max="15000"
              step="500"
              value={nSims}
              onChange={(e) => setNSims(Number(e.target.value))}
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>1k</span>
              <span>5k</span>
              <span>10k</span>
              <span>15k</span>
            </div>
          </div>

          {/* Slider 2: Latent Correlation rho */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Latent Correlation (rho):</span>
              <strong className="text-emerald-400">{rho.toFixed(2)}</strong>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.80"
              step="0.05"
              value={rho}
              onChange={(e) => setRho(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>0.05 (Idio)</span>
              <span>0.30 (CLO Base)</span>
              <span>0.80 (Crisis)</span>
            </div>
          </div>

          {/* Selector: Copula Engine */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Copula Distribution:</span>
              <strong className="text-sky-400">{copulaType}</strong>
            </div>
            <select
              value={copulaType}
              onChange={(e) => setCopulaType(e.target.value as any)}
              className="w-full bg-[#0b0e14] border border-[#1e293b] rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#c5a059]"
            >
              <option value="Gaussian">Gaussian Copula (Standard)</option>
              <option value="Student-t">Student-t Copula (Heavy-Tailed, nu=4)</option>
            </select>
            <span className="text-[10px] text-slate-500 block font-mono">
              {copulaType === 'Student-t' ? 'Captures extreme tail joint clustering' : 'Merton/Vasicek 1-Factor Baseline'}
            </span>
          </div>

          {/* Run Button */}
          <div className="flex flex-col justify-end">
            <button
              onClick={onReSimulate}
              disabled={isExecuting}
              className="w-full bg-[#c5a059] hover:bg-[#dfbe76] text-[#0b0e14] font-semibold text-xs py-2 rounded-lg transition-all flex items-center justify-center space-x-2 shadow-md"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isExecuting ? 'animate-spin' : ''}`} />
              <span>Simulate Portfolio</span>
            </button>
          </div>
        </div>
      </div>

      {/* Latent Correlation vs Realised Dependence Boundary Notice */}
      <div className="bg-[#111620] border-l-4 border-sky-400 border-y border-r border-[#1e293b] p-4 rounded-r-xl text-xs font-sans">
        <div className="flex items-start space-x-3">
          <Info className="w-4 h-4 text-sky-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong className="text-slate-200">
              Crucial Quantitative Note on Latent Factor Correlation vs Realised Default Dependence:
            </strong>
            <p className="text-slate-400 leading-relaxed">
              The parameter <code className="text-[#c5a059] font-mono">rho = {rho}</code> represents continuous asset value correlation in latent Merton space:{' '}
              <code className="text-sky-300 font-mono">X_i = sqrt(rho)*M + sqrt(1-rho)*Z_i</code>.
              Because default occurs only when an obligor crosses its extreme threshold <code className="text-emerald-400 font-mono">Phi^-1(PD)</code>,
              the actual realised default correlation <code className="text-slate-200 font-mono">Corr(1_tau_i, 1_tau_j)</code> is <strong>substantially lower</strong> (typically 2% to 6%).
              RhinoQuant does not present latent correlation and discrete joint default probability as identical.
            </p>
          </div>
        </div>
      </div>

      {/* Visual Loss Distribution Histogram */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-[#1e293b] mb-4 gap-2">
          <div>
            <h4 className="text-xs uppercase font-bold tracking-wider text-slate-200 flex items-center space-x-2">
              <BarChart3 className="w-4 h-4 text-[#c5a059]" />
              <span>Simulated Cumulative Portfolio Loss Distribution ({nSims} Paths)</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Mean: <span className="text-[#c5a059] font-mono font-bold">{diagnostics.mean_loss_pct.toFixed(2)}%</span> • 99% VaR: <span className="text-rose-400 font-mono font-bold">{diagnostics.q99_pct.toFixed(2)}%</span>
            </p>
          </div>
        </div>

        {/* Histogram Bars */}
        <div className="h-44 w-full flex items-end gap-1 px-2 pt-6 pb-2 bg-[#0b0e14] rounded-xl border border-[#1e293b]">
          {histogramBins.map((bin, i) => (
            <div key={i} className="flex-1 flex flex-col items-center h-full justify-end group relative">
              {/* Tooltip */}
              <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-10 bg-slate-900 border border-slate-700 text-[10px] font-mono text-slate-200 px-2 py-1 rounded shadow-lg pointer-events-none whitespace-nowrap z-20">
                Range: {bin.label} • {bin.count} paths ({bin.frequencyPct.toFixed(1)}%)
              </div>

              {/* Bar */}
              <div
                style={{ height: `${Math.max(4, bin.heightPct)}%` }}
                className={`w-full rounded-t transition-all ${
                  bin.rangeStart * 100 >= diagnostics.q99_pct
                    ? 'bg-rose-500 hover:bg-rose-400'
                    : bin.rangeStart * 100 >= diagnostics.q95_pct
                    ? 'bg-amber-500 hover:bg-amber-400'
                    : 'bg-[#c5a059]/80 hover:bg-[#c5a059]'
                }`}
              />
            </div>
          ))}
        </div>

        <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-2 px-1">
          <span>0.0% Loss</span>
          <span>{histogramBins[Math.floor(histogramBins.length / 2)]?.label}</span>
          <span className="text-rose-400">99% VaR: {diagnostics.q99_pct.toFixed(1)}%</span>
          <span>{histogramBins[histogramBins.length - 1]?.label}+</span>
        </div>
      </div>

      {/* Diagnostics Grid & Batch Convergence */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Diagnostics Table */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl space-y-3">
          <h4 className="text-xs uppercase font-bold tracking-wider text-slate-300 pb-2 border-b border-[#1e293b]">
            Monte Carlo Precision & Diagnostics
          </h4>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Number of Simulations (M):</span>
              <span className="text-slate-100 font-bold">{nSims.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Random Stream Seed:</span>
              <span>{seed} (Reproducible CRN)</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Estimated Mean Loss:</span>
              <span className="text-[#c5a059] font-bold">{diagnostics.mean_loss_pct.toFixed(3)}%</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Monte Carlo Standard Error:</span>
              <span className="text-emerald-400">+/- {diagnostics.mc_standard_error_pct.toFixed(4)}%</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Standard Deviation of Loss:</span>
              <span>{diagnostics.loss_sd_pct.toFixed(2)}%</span>
            </div>
            <div className="flex justify-between text-slate-300 pt-2 border-t border-[#1e293b]">
              <span className="text-slate-400">95.0% Quantile:</span>
              <span>{diagnostics.q95_pct.toFixed(2)}%</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">99.0% Value-at-Risk (VaR):</span>
              <span className="text-rose-400 font-bold">${(diagnostics.var_99_amount / 1e6).toFixed(2)}M ({diagnostics.q99_pct.toFixed(2)}%)</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">99.0% Expected Shortfall (CVaR):</span>
              <span className="text-rose-400">${(diagnostics.cvar_99_amount / 1e6).toFixed(2)}M</span>
            </div>
          </div>

          <div className="pt-2 text-[11px] text-amber-400/90 font-sans border-t border-[#1e293b]">
            <AlertTriangle className="w-3.5 h-3.5 inline mr-1 text-amber-400" />
            {diagnostics.effective_sample_tail_disclosure}
          </div>
        </div>

        {/* Batch Convergence Chart */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl space-y-3">
          <h4 className="text-xs uppercase font-bold tracking-wider text-slate-300 pb-2 border-b border-[#1e293b]">
            Convergence by Simulation Batch (10 Independent Blocks)
          </h4>
          <p className="text-xs text-slate-400 font-sans">
            Demonstrates numerical stability across consecutive Monte Carlo batches of {Math.floor(nSims / 10)} paths.
          </p>

          <div className="space-y-2 mt-4">
            {diagnostics.batch_convergence_means.map((m, i) => (
              <div key={i} className="flex items-center space-x-3 text-xs font-mono">
                <span className="w-16 text-slate-400 text-[11px]">Batch {i + 1}:</span>
                <div className="flex-1 h-3 bg-[#0b0e14] rounded-full overflow-hidden border border-[#1e293b]">
                  <div
                    style={{ width: `${Math.min(100, (m / (diagnostics.mean_loss_pct * 2)) * 100)}%` }}
                    className="h-full bg-gradient-to-r from-[#c5a059] to-[#dfbe76] rounded-full"
                  />
                </div>
                <span className="w-16 text-right text-slate-200 font-semibold">{m.toFixed(2)}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
