import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  Cpu,
  Layers,
  ArrowUpDown,
  Building2,
  Calendar,
  Percent,
} from 'lucide-react';
import { CollateralAsset } from '../types/tranche';

interface CollateralTabProps {
  collateral: CollateralAsset[];
}

export const CollateralTab: React.FC<CollateralTabProps> = ({ collateral }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedRating, setSelectedRating] = useState<string>('ALL');
  const [semiOnly, setSemiOnly] = useState<boolean>(false);
  const [sortField, setSortField] = useState<keyof CollateralAsset>('current_balance');
  const [sortAsc, setSortAsc] = useState<boolean>(false);

  // Available sectors and ratings for filters
  const sectors = useMemo(() => {
    return ['ALL', ...Array.from(new Set(collateral.map((a) => a.sector))).sort()];
  }, [collateral]);

  const ratings = useMemo(() => {
    return ['ALL', ...Array.from(new Set(collateral.map((a) => a.rating))).sort()];
  }, [collateral]);

  // Filtered and sorted assets
  const filteredAssets = useMemo(() => {
    return collateral
      .filter((a) => {
        const matchesSearch =
          a.obligor_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          a.asset_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          a.obligor_id.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesSector = selectedSector === 'ALL' || a.sector === selectedSector;
        const matchesRating = selectedRating === 'ALL' || a.rating === selectedRating;
        const matchesSemi = !semiOnly || a.is_semiconductor;

        return matchesSearch && matchesSector && matchesRating && matchesSemi;
      })
      .sort((a, b) => {
        const valA = a[sortField];
        const valB = b[sortField];
        if (typeof valA === 'number' && typeof valB === 'number') {
          return sortAsc ? valA - valB : valB - valA;
        }
        return sortAsc
          ? String(valA).localeCompare(String(valB))
          : String(valB).localeCompare(String(valA));
      });
  }, [collateral, searchTerm, selectedSector, selectedRating, semiOnly, sortField, sortAsc]);

  // Aggregate stats
  const totalBalance = useMemo(
    () => filteredAssets.reduce((sum, a) => sum + a.current_balance, 0),
    [filteredAssets]
  );
  const totalOriginalFace = useMemo(
    () => filteredAssets.reduce((sum, a) => sum + a.original_face, 0),
    [filteredAssets]
  );
  const wac = useMemo(() => {
    if (totalBalance === 0) return 0;
    return filteredAssets.reduce((sum, a) => sum + a.coupon_pct * a.current_balance, 0) / totalBalance;
  }, [filteredAssets, totalBalance]);

  const was = useMemo(() => {
    if (totalBalance === 0) return 0;
    return filteredAssets.reduce((sum, a) => sum + a.spread_bps * a.current_balance, 0) / totalBalance;
  }, [filteredAssets, totalBalance]);

  const handleSort = (field: keyof CollateralAsset) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Validation Header Banner */}
      <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-semibold text-slate-200">Collateral Pool Integrity Verification</span>
            <span className="text-xs bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 px-2 py-0.5 rounded-full flex items-center font-mono">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              100% Passed
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Engine verified: 0 duplicate asset IDs • 0 missing values • Single-currency (USD) • Principal factors synchronized.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
          <div className="bg-[#0b0e14] px-3 py-1.5 rounded-lg border border-[#1e293b] text-slate-300">
            Assets: <strong className="text-emerald-400">{filteredAssets.length}</strong> / {collateral.length}
          </div>
          <div className="bg-[#0b0e14] px-3 py-1.5 rounded-lg border border-[#1e293b] text-slate-300">
            Balance: <strong className="text-[#c5a059]">${(totalBalance / 1e6).toFixed(2)}M</strong>
          </div>
          <div className="bg-[#0b0e14] px-3 py-1.5 rounded-lg border border-[#1e293b] text-slate-300">
            WAC: <strong className="text-slate-100">{wac.toFixed(2)}%</strong>
          </div>
          <div className="bg-[#0b0e14] px-3 py-1.5 rounded-lg border border-[#1e293b] text-slate-300">
            WAS: <strong className="text-slate-100">{was.toFixed(0)} bps</strong>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#111620] border border-[#1e293b] p-4 rounded-xl flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="flex flex-1 items-center space-x-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search obligor name, loan ID, or obligor ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0b0e14] border border-[#1e293b] rounded-lg pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-[#c5a059]"
            />
          </div>

          {/* Sector Filter */}
          <div className="flex items-center space-x-1.5 text-xs text-slate-400">
            <span>Sector:</span>
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="bg-[#0b0e14] border border-[#1e293b] rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#c5a059]"
            >
              {sectors.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* Rating Filter */}
          <div className="flex items-center space-x-1.5 text-xs text-slate-400">
            <span>Rating:</span>
            <select
              value={selectedRating}
              onChange={(e) => setSelectedRating(e.target.value)}
              className="bg-[#0b0e14] border border-[#1e293b] rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#c5a059]"
            >
              {ratings.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Semiconductor Adapter Toggle */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSemiOnly(!semiOnly)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all border ${
              semiOnly
                ? 'bg-[#c5a059] text-[#0b0e14] border-[#c5a059]'
                : 'bg-[#0b0e14] text-slate-300 border-[#1e293b] hover:border-slate-600'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Semiconductor Obligors Only</span>
          </button>
        </div>
      </div>

      {/* Collateral Table */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl overflow-hidden">
        <div className="overflow-x-auto max-h-[580px]">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0b0e14] sticky top-0 z-10 border-b border-[#1e293b] text-slate-400 font-sans">
              <tr>
                <th
                  onClick={() => handleSort('asset_id')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center space-x-1">
                    <span>Asset ID</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('obligor_name')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center space-x-1">
                    <span>Obligor Name</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Sector</th>
                <th
                  onClick={() => handleSort('rating')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center space-x-1">
                    <span>Rating</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('current_balance')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>Balance</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4 text-right">Factor</th>
                <th
                  onClick={() => handleSort('coupon_pct')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>Coupon</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('spread_bps')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>Spread</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4 text-right">Maturity</th>
                <th className="py-3 px-4 text-center">Semi Micro Attributes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/60">
              {filteredAssets.map((asset) => (
                <tr key={asset.asset_id} className="hover:bg-[#161c28] transition-colors">
                  <td className="py-2.5 px-4 font-bold text-[#c5a059]">{asset.asset_id}</td>
                  <td className="py-2.5 px-4 font-sans text-slate-200 font-medium">
                    <div className="flex items-center space-x-2">
                      <span>{asset.obligor_name}</span>
                      {asset.is_semiconductor && (
                        <span className="text-[10px] bg-amber-950/60 text-amber-400 px-1.5 py-0.2 rounded border border-amber-800/40">
                          Semi
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-2.5 px-4 font-sans text-slate-400">{asset.sector}</td>
                  <td className="py-2.5 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        asset.rating.startsWith('A')
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                          : asset.rating.startsWith('BBB')
                          ? 'bg-sky-950/60 text-sky-400 border border-sky-800/40'
                          : 'bg-amber-950/60 text-amber-400 border border-amber-800/40'
                      }`}
                    >
                      {asset.rating}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-100 font-bold">
                    ${asset.current_balance.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-400">
                    {asset.principal_factor.toFixed(3)}
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-200 font-semibold">
                    {asset.coupon_pct.toFixed(2)}%
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-300">
                    {asset.spread_bps} bps
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-400">
                    {asset.maturity_years.toFixed(1)} yrs
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    {asset.is_semiconductor ? (
                      <div className="text-[10px] text-slate-300 font-sans inline-flex items-center space-x-1.5">
                        <span className="text-amber-400">{asset.fab_utilization_pct}% Util</span>
                        <span>•</span>
                        <span className="truncate max-w-[90px]">{asset.tapeout_stage}</span>
                        <span>•</span>
                        <span className="text-slate-400">{asset.dso_days}d DSO</span>
                      </div>
                    ) : (
                      <span className="text-slate-600">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
