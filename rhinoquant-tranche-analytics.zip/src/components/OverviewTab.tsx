import React from 'react';
import {
  DollarSign,
  ShieldCheck,
  TrendingDown,
  AlertTriangle,
  Layers,
  ArrowRight,
  Database,
  Calculator,
  Flame,
  FileCheck2,
  ChevronRight,
  Activity,
} from 'lucide-react';
import { TrancheDefinition, SimulationDiagnostics } from '../types/tranche';

interface OverviewTabProps {
  tranches: TrancheDefinition[];
  diagnostics: SimulationDiagnostics;
  setActiveTab: (tab: string) => void;
  cashConserved: boolean;
  totalNotional: number;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  tranches,
  diagnostics,
  setActiveTab,
  cashConserved,
  totalNotional,
}) => {
  return (
    <div className="space-y-6">
      {/* Institutional KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl relative overflow-hidden group hover:border-[#c5a059]/50 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400">Reference Collateral</span>
            <div className="p-2 rounded-lg bg-[#c5a059]/10 border border-[#c5a059]/20 text-[#c5a059]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-100">
              ${(totalNotional / 1e6).toFixed(1)}M
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center space-x-1">
              <span className="text-emerald-400 font-medium">100 Assets</span>
              <span>•</span>
              <span>USD Currency</span>
              <span>•</span>
              <span className="text-slate-300">WAC 6.94%</span>
            </div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl relative overflow-hidden group hover:border-emerald-500/50 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400">Class A Subordination</span>
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-emerald-400">
              35.00%
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center space-x-1">
              <span>$35.0M Cushion</span>
              <span>•</span>
              <span className="text-emerald-400 font-medium">AAA Rated</span>
              <span>•</span>
              <span>SOFR + 125 bps</span>
            </div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl relative overflow-hidden group hover:border-amber-500/50 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400">Expected Portfolio Loss</span>
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-amber-400">
              {diagnostics.mean_loss_pct.toFixed(2)}%
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center space-x-1">
              <span>${(diagnostics.mean_loss_currency / 1e6).toFixed(2)}M Mean</span>
              <span>•</span>
              <span className="text-slate-300">SE +/-{diagnostics.mc_standard_error_pct.toFixed(3)}%</span>
            </div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl relative overflow-hidden group hover:border-rose-500/50 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400">99.0% Portfolio VaR</span>
            <div className="p-2 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-rose-400">
              ${(diagnostics.var_99_amount / 1e6).toFixed(2)}M
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center space-x-1">
              <span className="text-rose-400 font-medium">{diagnostics.q99_pct.toFixed(2)}% Notional</span>
              <span>•</span>
              <span>CVaR ${(diagnostics.cvar_99_amount / 1e6).toFixed(2)}M</span>
            </div>
          </div>
        </div>
      </div>

      {/* Capital Structure Bar Visualization */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-[#1e293b] mb-4 gap-2">
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
              <Layers className="w-4 h-4 text-[#c5a059]" />
              <span>Capital Structure & Loss Subordination Ladder</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              RhinoQuant CLO 2026-I • Total Liabilities: USD 100,000,000 • Fully Collateralized
            </p>
          </div>
          <div className="flex items-center space-x-2 text-xs font-mono">
            <span className="text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded border border-emerald-800/40">
              Cash Conserved: {cashConserved ? 'VERIFIED (0.00 Var)' : 'BREACH'}
            </span>
          </div>
        </div>

        {/* Stack Bar */}
        <div className="space-y-3">
          <div className="h-10 w-full rounded-lg overflow-hidden flex shadow-inner border border-[#1e293b] p-0.5 bg-[#0b0e14]">
            {/* Senior AAA */}
            <div
              style={{ width: '65%' }}
              className="bg-emerald-600/80 hover:bg-emerald-500 transition-colors flex items-center justify-between px-3 text-xs font-mono text-white font-semibold cursor-pointer border-r border-[#0b0e14]"
              title="Class A-1 Senior: $65M (0-65% attachment/detachment, 35% subordination)"
            >
              <span className="truncate">Class A-1 (AAA) - 65%</span>
              <span className="text-emerald-200 text-[10px] hidden md:inline">$65.0M • SOFR+125</span>
            </div>

            {/* Mezzanine AA */}
            <div
              style={{ width: '15%' }}
              className="bg-sky-600/80 hover:bg-sky-500 transition-colors flex items-center justify-between px-2 text-xs font-mono text-white font-semibold cursor-pointer border-r border-[#0b0e14]"
              title="Class B Mezzanine: $15M (65-80% attachment/detachment, 20% subordination)"
            >
              <span className="truncate">Class B (AA) - 15%</span>
              <span className="text-sky-200 text-[10px] hidden lg:inline">$15M</span>
            </div>

            {/* Junior BBB */}
            <div
              style={{ width: '10%' }}
              className="bg-amber-600/80 hover:bg-amber-500 transition-colors flex items-center justify-between px-2 text-xs font-mono text-white font-semibold cursor-pointer border-r border-[#0b0e14]"
              title="Class C Junior: $10M (80-90% attachment/detachment, 10% subordination)"
            >
              <span className="truncate">Class C (BBB) - 10%</span>
              <span className="text-amber-200 text-[10px] hidden xl:inline">$10M</span>
            </div>

            {/* Equity */}
            <div
              style={{ width: '10%' }}
              className="bg-rose-600/80 hover:bg-rose-500 transition-colors flex items-center justify-between px-2 text-xs font-mono text-white font-semibold cursor-pointer"
              title="Subordinated Equity: $10M (90-100% attachment/detachment, First-Loss)"
            >
              <span className="truncate">Equity - 10%</span>
              <span className="text-rose-200 text-[10px] hidden xl:inline">$10M</span>
            </div>
          </div>

          {/* Scale Markers */}
          <div className="flex justify-between text-[11px] font-mono text-slate-500 px-1">
            <span>0% (Senior)</span>
            <span>65% (Mezz Attachment)</span>
            <span>80% (Junior Attachment)</span>
            <span>90% (Equity Attachment)</span>
            <span>100% (Detachment)</span>
          </div>
        </div>

        {/* Tranche Table Details */}
        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1e293b] text-slate-400 font-sans">
                <th className="pb-2.5">Tranche Class</th>
                <th className="pb-2.5">Rating</th>
                <th className="pb-2.5">Balance</th>
                <th className="pb-2.5">Attachment</th>
                <th className="pb-2.5">Detachment</th>
                <th className="pb-2.5">Subordination</th>
                <th className="pb-2.5">Coupon</th>
                <th className="pb-2.5">OC Trigger</th>
                <th className="pb-2.5 text-right">Priority</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/50">
              {tranches.map((t) => (
                <tr key={t.tranche_id} className="hover:bg-[#161c28]/60 transition-colors">
                  <td className="py-2.5 font-sans font-semibold text-slate-200">{t.name}</td>
                  <td className="py-2.5">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      t.rating === 'AAA' ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40' :
                      t.rating === 'AA' ? 'bg-sky-950/60 text-sky-400 border border-sky-800/40' :
                      t.rating === 'BBB' ? 'bg-amber-950/60 text-amber-400 border border-amber-800/40' :
                      'bg-rose-950/60 text-rose-400 border border-rose-800/40'
                    }`}>
                      {t.rating}
                    </span>
                  </td>
                  <td className="py-2.5 text-slate-300 font-mono">${(t.current_balance / 1e6).toFixed(1)}M</td>
                  <td className="py-2.5 text-slate-400">{(t.attachment_point * 100).toFixed(1)}%</td>
                  <td className="py-2.5 text-slate-400">{(t.detachment_point * 100).toFixed(1)}%</td>
                  <td className="py-2.5 text-emerald-400 font-semibold">{(t.subordination_pct * 100).toFixed(1)}%</td>
                  <td className="py-2.5 text-slate-300">
                    {t.coupon_type === 'Floating' ? `SOFR + ${t.spread_bps} bps` : 'Residual Cash'}
                  </td>
                  <td className="py-2.5 text-slate-400">
                    {t.oc_test_trigger_pct ? `${t.oc_test_trigger_pct.toFixed(1)}%` : '—'}
                  </td>
                  <td className="py-2.5 text-right text-[#c5a059] font-bold">Priority {t.payment_priority}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quantitative Workflow Stepper */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl p-6">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 mb-4 flex items-center space-x-2">
          <Activity className="w-4 h-4 text-[#c5a059]" />
          <span>Institutional Analytical Workflow & Modules</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Step 1 */}
          <div
            onClick={() => setActiveTab('collateral')}
            className="p-4 rounded-lg bg-[#0b0e14] border border-[#1e293b] hover:border-[#c5a059] transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between text-xs font-semibold text-[#c5a059]">
              <span>STEP 01</span>
              <Database className="w-4 h-4 text-slate-400 group-hover:text-[#c5a059]" />
            </div>
            <h4 className="font-semibold text-slate-200 mt-2 text-sm">Collateral Explorer</h4>
            <p className="text-xs text-slate-400 mt-1">
              Validate 100 corporate loans, micro-semiconductor adapters, ratings, and duplicate asset checks.
            </p>
          </div>

          {/* Step 2 */}
          <div
            onClick={() => setActiveTab('waterfall')}
            className="p-4 rounded-lg bg-[#0b0e14] border border-[#1e293b] hover:border-[#c5a059] transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between text-xs font-semibold text-[#c5a059]">
              <span>STEP 02</span>
              <Calculator className="w-4 h-4 text-slate-400 group-hover:text-[#c5a059]" />
            </div>
            <h4 className="font-semibold text-slate-200 mt-2 text-sm">Waterfall Engine</h4>
            <p className="text-xs text-slate-400 mt-1">
              Period-by-period allocation across 20 quarters. OC/IC test diversions, PDL, and cash conservation.
            </p>
          </div>

          {/* Step 3 */}
          <div
            onClick={() => setActiveTab('simulation')}
            className="p-4 rounded-lg bg-[#0b0e14] border border-[#1e293b] hover:border-[#c5a059] transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between text-xs font-semibold text-[#c5a059]">
              <span>STEP 03</span>
              <Flame className="w-4 h-4 text-slate-400 group-hover:text-[#c5a059]" />
            </div>
            <h4 className="font-semibold text-slate-200 mt-2 text-sm">Simulation Lab</h4>
            <p className="text-xs text-slate-400 mt-1">
              Correlated 1-factor Gaussian & Student-t Copula. Monte Carlo convergence & standard error diagnostics.
            </p>
          </div>

          {/* Step 4 */}
          <div
            onClick={() => setActiveTab('reports')}
            className="p-4 rounded-lg bg-[#0b0e14] border border-[#1e293b] hover:border-[#c5a059] transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between text-xs font-semibold text-[#c5a059]">
              <span>STEP 04</span>
              <FileCheck2 className="w-4 h-4 text-slate-400 group-hover:text-[#c5a059]" />
            </div>
            <h4 className="font-semibold text-slate-200 mt-2 text-sm">Reports & R Hub</h4>
            <p className="text-xs text-slate-400 mt-1">
              Export reproducible audit JSON with SHA256 hashes, inspect R source code, and run testthat tests.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
