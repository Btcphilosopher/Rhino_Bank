import React from 'react';
import {
  Layers,
  Play,
  RotateCcw,
  CheckCircle2,
  TrendingUp,
  Cpu,
  BarChart3,
  Terminal,
  ShieldAlert,
} from 'lucide-react';

interface HeaderProps {
  analysisMode: 'cash_cdo' | 'synthetic_tranche' | 'investor_portfolio';
  setAnalysisMode: (mode: 'cash_cdo' | 'synthetic_tranche' | 'investor_portfolio') => void;
  isExecuting: boolean;
  onExecute: () => void;
  runHash: string;
  seed: number;
  nSims: number;
  rho: number;
}

export const Header: React.FC<HeaderProps> = ({
  analysisMode,
  setAnalysisMode,
  isExecuting,
  onExecute,
  runHash,
  seed,
  nSims,
  rho,
}) => {
  return (
    <header className="bg-[#0b0e14] border-b border-[#1e293b] px-6 py-4 sticky top-0 z-50">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Brand & Identity */}
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#c5a059] to-[#8c6d2c] flex items-center justify-center shadow-lg shadow-[#c5a059]/20 border border-[#dfbe76]/40">
            <Layers className="w-5 h-5 text-[#0b0e14]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-['Cinzel'] tracking-widest text-lg font-bold text-[#c5a059]">
                RHINOQUANT
              </span>
              <span className="text-xs bg-[#1e2430] text-[#94a3b8] px-2 py-0.5 rounded border border-[#334155]/60 font-mono">
                Tranche Analytics v3.4
              </span>
              <span className="flex items-center text-xs text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40 font-mono">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                R Engine Verified
              </span>
            </div>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Deal: <span className="text-slate-200 font-medium">RhinoQuant CLO 2026-I</span> • USD 100M Reference Pool • TrancheWorks & TrancheDesk Companion
            </p>
          </div>
        </div>

        {/* Mode Selector & Action Bar */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Analysis Mode Pills */}
          <div className="flex bg-[#111620] p-1 rounded-lg border border-[#1e293b]">
            <button
              onClick={() => setAnalysisMode('cash_cdo')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all flex items-center space-x-1.5 ${
                analysisMode === 'cash_cdo'
                  ? 'bg-[#c5a059] text-[#0b0e14] font-semibold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Funded Cash Notes</span>
            </button>
            <button
              onClick={() => setAnalysisMode('synthetic_tranche')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all flex items-center space-x-1.5 ${
                analysisMode === 'synthetic_tranche'
                  ? 'bg-[#c5a059] text-[#0b0e14] font-semibold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Synthetic CDS Tranches</span>
            </button>
            <button
              onClick={() => setAnalysisMode('investor_portfolio')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all flex items-center space-x-1.5 ${
                analysisMode === 'investor_portfolio'
                  ? 'bg-[#c5a059] text-[#0b0e14] font-semibold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Investor Portfolio</span>
            </button>
          </div>

          {/* Seed and Hash Badge */}
          <div className="hidden xl:flex items-center space-x-2 text-xs font-mono bg-[#111620] px-3 py-1.5 rounded-lg border border-[#1e293b] text-slate-400">
            <span>Seed: <strong className="text-slate-200">{seed}</strong></span>
            <span>•</span>
            <span>rho: <strong className="text-slate-200">{rho}</strong></span>
            <span>•</span>
            <span className="text-[#c5a059]">Hash: #{runHash.slice(0, 8)}</span>
          </div>

          {/* Re-calculate Button */}
          <button
            onClick={onExecute}
            disabled={isExecuting}
            className={`px-4 py-2 rounded-lg font-semibold text-xs tracking-wider uppercase transition-all flex items-center space-x-2 shadow-md ${
              isExecuting
                ? 'bg-amber-600/40 text-amber-200 border border-amber-500/40 cursor-wait'
                : 'bg-gradient-to-r from-[#c5a059] to-[#b38d43] hover:from-[#dfbe76] hover:to-[#c5a059] text-[#0b0e14] shadow-[#c5a059]/20'
            }`}
          >
            {isExecuting ? (
              <>
                <RotateCcw className="w-4 h-4 animate-spin" />
                <span>Computing...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Run Pipeline</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
