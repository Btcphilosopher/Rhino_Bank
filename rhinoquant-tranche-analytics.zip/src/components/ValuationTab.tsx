import React from 'react';
import {
  TrendingUp,
  DollarSign,
  Percent,
  CheckCircle2,
  Clock,
  ShieldAlert,
  ArrowRight,
  Info,
  Scale,
} from 'lucide-react';
import { CashTrancheValuation, SyntheticTrancheValuation } from '../types/tranche';

interface ValuationTabProps {
  cashValuations: CashTrancheValuation[];
  syntheticValuations: SyntheticTrancheValuation[];
}

export const ValuationTab: React.FC<ValuationTabProps> = ({
  cashValuations,
  syntheticValuations,
}) => {
  return (
    <div className="space-y-8">
      {/* SECTION 1: Cash CDO Notes Valuation */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-[#1e293b] gap-2">
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
              <Scale className="w-4 h-4 text-[#c5a059]" />
              <span>Funded Cash Note Valuation & Cash-Flow Return Analytics</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Price Basis: % of Current Outstanding Balance • Single-factor applied (prevents factor double counting) • Benchmark: SOFR (4.25%)
            </p>
          </div>
          <span className="text-xs font-mono bg-[#111620] px-3 py-1 rounded-lg border border-[#1e293b] text-slate-300">
            Valuation Date: 2026-03-15
          </span>
        </div>

        {/* Cash Notes Table */}
        <div className="bg-[#111620] border border-[#1e293b] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0b0e14] border-b border-[#1e293b] text-slate-400 font-sans">
                <tr>
                  <th className="py-3 px-4">Tranche Class</th>
                  <th className="py-3 px-4">Rating</th>
                  <th className="py-3 px-4 text-right">Balance</th>
                  <th className="py-3 px-4 text-right">Factor</th>
                  <th className="py-3 px-4 text-right">WAL (Yrs)</th>
                  <th className="py-3 px-4 text-right">Clean Price</th>
                  <th className="py-3 px-4 text-right">Dirty Price</th>
                  <th className="py-3 px-4 text-right">Accrued ($)</th>
                  <th className="py-3 px-4 text-right">Discount Margin</th>
                  <th className="py-3 px-4 text-right">Investor IRR</th>
                  <th className="py-3 px-4 text-right">Shortfall</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]/60">
                {cashValuations.map((v) => (
                  <tr key={v.tranche_id} className="hover:bg-[#161c28] transition-colors">
                    <td className="py-3 px-4 font-sans font-semibold text-slate-200">{v.name}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          v.rating === 'AAA'
                            ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                            : v.rating === 'AA'
                            ? 'bg-sky-950/60 text-sky-400 border border-sky-800/40'
                            : v.rating === 'BBB'
                            ? 'bg-amber-950/60 text-amber-400 border border-amber-800/40'
                            : 'bg-rose-950/60 text-rose-400 border border-rose-800/40'
                        }`}
                      >
                        {v.rating}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-slate-200">
                      ${(v.current_balance / 1e6).toFixed(1)}M
                    </td>
                    <td className="py-3 px-4 text-right text-slate-400">
                      {v.principal_factor.toFixed(3)}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-100 font-semibold">
                      {v.wal_years.toFixed(2)}y
                    </td>
                    <td className="py-3 px-4 text-right text-[#c5a059] font-bold text-sm">
                      {v.model_price_clean.toFixed(3)}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-300">
                      {v.model_price_dirty.toFixed(3)}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-400">
                      ${v.accrued_interest_amount.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-200">
                      {v.discount_margin_bps ? `${v.discount_margin_bps} bps` : '—'}
                    </td>
                    <td className="py-3 px-4 text-right text-emerald-400 font-bold">
                      {v.investor_irr_pct ? `${v.investor_irr_pct.toFixed(2)}%` : '—'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {v.principal_shortfall > 0 ? (
                        <span className="text-rose-400 font-bold">
                          ${v.principal_shortfall.toLocaleString()}
                        </span>
                      ) : (
                        <span className="text-slate-500 font-mono">$0.00</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* IRR & Price Basis Disclosures */}
        <div className="bg-[#0b0e14] p-4 rounded-xl border border-[#1e293b] text-xs text-slate-400 flex items-start space-x-3">
          <Info className="w-4 h-4 text-[#c5a059] flex-shrink-0 mt-0.5" />
          <div className="space-y-1 font-sans">
            <span className="font-semibold text-slate-200">
              IRR Root Diagnostics & Price Convention Disclosures:
            </span>
            <p>
              • All cash-note IRR calculations employ Brent's root-finding method over [-20%, +100%] with Descartes' sign-change verification. Status:{' '}
              <span className="text-emerald-400 font-mono font-medium">UNIQUE_ROOT (Single Global Solution Verified)</span>.
            </p>
            <p>
              • Dirty Price = Model Present Value / Current Outstanding Principal. Clean Price = Dirty Price - Accrued Interest (45/360).
            </p>
          </div>
        </div>
      </div>

      {/* SECTION 2: Synthetic Credit Tranche Valuation */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-[#1e293b] gap-2">
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-sky-400" />
              <span>Synthetic Credit Tranche CDS Valuation (Standard Conventions)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Deal: RhinoSyn iTraxx-Linked 2026-S1 • 5-Year Tenor • Quarterly Standard ACT/360 Settlement • Risk-Neutral Pricing Calibration
            </p>
          </div>
          <span className="text-xs font-mono bg-[#111620] px-3 py-1 rounded-lg border border-[#1e293b] text-sky-400">
            Market-Calibrated Fair Spreads
          </span>
        </div>

        {/* Synthetic Tranches Table */}
        <div className="bg-[#111620] border border-[#1e293b] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0b0e14] border-b border-[#1e293b] text-slate-400 font-sans">
                <tr>
                  <th className="py-3 px-4">Synthetic Tranche</th>
                  <th className="py-3 px-4">Attachment</th>
                  <th className="py-3 px-4">Detachment</th>
                  <th className="py-3 px-4 text-right">Notional</th>
                  <th className="py-3 px-4 text-right">Stated Spread</th>
                  <th className="py-3 px-4 text-right">Fair Spread</th>
                  <th className="py-3 px-4 text-right">Risky PV01</th>
                  <th className="py-3 px-4 text-right">Premium Leg PV</th>
                  <th className="py-3 px-4 text-right">Protection Leg PV</th>
                  <th className="py-3 px-4 text-right">Upfront %</th>
                  <th className="py-3 px-4 text-right text-rose-400">Expected Loss</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]/60">
                {syntheticValuations.map((syn) => (
                  <tr key={syn.tranche_id} className="hover:bg-[#161c28] transition-colors">
                    <td className="py-3 px-4 font-sans font-semibold text-slate-200">
                      {syn.name}
                    </td>
                    <td className="py-3 px-4 text-slate-400">{syn.attachment_pct.toFixed(1)}%</td>
                    <td className="py-3 px-4 text-slate-400">{syn.detachment_pct.toFixed(1)}%</td>
                    <td className="py-3 px-4 text-right text-slate-200">
                      ${(syn.notional / 1e6).toFixed(1)}M
                    </td>
                    <td className="py-3 px-4 text-right text-slate-300">
                      {syn.stated_running_bps} bps
                    </td>
                    <td className="py-3 px-4 text-right text-[#c5a059] font-bold text-sm">
                      {syn.fair_spread_bps} bps
                    </td>
                    <td className="py-3 px-4 text-right text-slate-400">
                      ${syn.pv01.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-300">
                      ${syn.pv_premium_leg.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-300">
                      ${syn.pv_protection_leg.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-semibold">
                      <span
                        className={
                          syn.upfront_pct > 0
                            ? 'text-amber-400'
                            : syn.upfront_pct < 0
                            ? 'text-emerald-400'
                            : 'text-slate-300'
                        }
                      >
                        {syn.upfront_pct > 0 ? `+${syn.upfront_pct.toFixed(2)}%` : `${syn.upfront_pct.toFixed(2)}%`}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-rose-400 font-bold">
                      {syn.expected_loss_pct.toFixed(2)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Methodology Note */}
        <div className="bg-[#0b0e14] p-4 rounded-xl border border-[#1e293b] text-xs text-slate-400 font-sans">
          <strong className="text-slate-200">Timing & Valuation Conventions: </strong>
          Premium Leg assumes standard quarterly CDS payment dates (ACT/360) with accrued premium paid on default.
          Fair Running Spread s* = PV(Protection Leg) / PV01 equates the two legs without upfront fee.
          Standard market upfront is calculated as PV(Protection) - PV(Premium at Stated Spread).
        </div>
      </div>
    </div>
  );
};
