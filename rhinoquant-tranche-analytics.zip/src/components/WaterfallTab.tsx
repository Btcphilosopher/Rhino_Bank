import React, { useState } from 'react';
import {
  Calculator,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  Shield,
  Layers,
  DollarSign,
  TrendingUp,
} from 'lucide-react';
import { WaterfallPeriodRecord } from '../types/tranche';

interface WaterfallTabProps {
  ledger: WaterfallPeriodRecord[];
  cashConserved: boolean;
  finalReserve: number;
  endingCollateral: number;
}

export const WaterfallTab: React.FC<WaterfallTabProps> = ({
  ledger,
  cashConserved,
  finalReserve,
  endingCollateral,
}) => {
  const [selectedPeriod, setSelectedPeriod] = useState<number>(1);

  const activePeriod = ledger.find((p) => p.period === selectedPeriod) || ledger[0];

  return (
    <div className="space-y-6">
      {/* Cash Conservation & Trigger Audit Banner */}
      <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-semibold text-slate-200">
              Cash Conservation & Coverage-Test Ledger Audit
            </span>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-mono flex items-center ${
                cashConserved
                  ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                  : 'bg-rose-950/60 text-rose-400 border border-rose-800/40'
              }`}
            >
              <CheckCircle2 className="w-3 h-3 mr-1" />
              {cashConserved ? 'Cash Conserved (Discrepancy < $0.05)' : 'Audit Breach'}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Period-by-period strict verification: Total In = Total Out + Reserve Replenish. Prevents double-counting and cash leakage.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
          <div className="bg-[#0b0e14] px-3 py-1.5 rounded-lg border border-[#1e293b] text-slate-300">
            Final Reserve: <strong className="text-emerald-400">${finalReserve.toLocaleString()}</strong>
          </div>
          <div className="bg-[#0b0e14] px-3 py-1.5 rounded-lg border border-[#1e293b] text-slate-300">
            Ending Collateral: <strong className="text-[#c5a059]">${Math.round(endingCollateral).toLocaleString()}</strong>
          </div>
        </div>
      </div>

      {/* Period Navigator Slider */}
      <div className="bg-[#111620] border border-[#1e293b] p-6 rounded-xl">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs uppercase tracking-wider font-semibold text-slate-300 flex items-center space-x-1.5">
            <Clock className="w-4 h-4 text-[#c5a059]" />
            <span>Select Period Horizon: Quarter {selectedPeriod} of 20 (ACT/360)</span>
          </span>
          <span className="text-xs font-mono text-[#c5a059] font-bold">
            {activePeriod.payment_date} {selectedPeriod <= 8 ? '• REINVESTMENT PERIOD' : '• AMORTISATION PERIOD'}
          </span>
        </div>

        <input
          type="range"
          min="1"
          max="20"
          value={selectedPeriod}
          onChange={(e) => setSelectedPeriod(Number(e.target.value))}
          className="w-full accent-[#c5a059] cursor-pointer"
        />

        <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-1.5">
          <span>Q1 (Closing)</span>
          <span>Q4 (Year 1)</span>
          <span>Q8 (End Reinvestment)</span>
          <span>Q12 (Year 3)</span>
          <span>Q16 (Year 4)</span>
          <span>Q20 (Maturity)</span>
        </div>
      </div>

      {/* Period Detail Breakdown Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Step A: Collections In */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1e293b]">
            <h4 className="text-xs uppercase font-bold tracking-wider text-emerald-400">
              1. Cash Collections In
            </h4>
            <span className="font-mono text-xs font-bold text-slate-200">
              ${(activePeriod.cash_in_audit).toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Interest Collections:</span>
              <span>${Math.round(activePeriod.interest_collected).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Principal Collections:</span>
              <span>${Math.round(activePeriod.principal_collected).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Recoveries Realized:</span>
              <span className="text-emerald-400">${Math.round(activePeriod.recoveries_realized).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Realized Defaults:</span>
              <span className="text-rose-400">${Math.round(activePeriod.defaults_realized).toLocaleString()}</span>
            </div>
            {activePeriod.reinvested_amount > 0 && (
              <div className="flex justify-between text-amber-300 pt-2 border-t border-[#1e293b]">
                <span>Reinvested to Collateral:</span>
                <span>${Math.round(activePeriod.reinvested_amount).toLocaleString()}</span>
              </div>
            )}
          </div>
        </div>

        {/* Step B: Senior Fees, Swap & Tranche Interest */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1e293b]">
            <h4 className="text-xs uppercase font-bold tracking-wider text-[#c5a059]">
              2. Fees, Swap & Interest Waterfall
            </h4>
            <span className="font-mono text-xs text-slate-400">Priority 1 to 3</span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Trustee & Admin Fee:</span>
              <span>${Math.round(activePeriod.trustee_fee).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Senior Manager Fee:</span>
              <span>${Math.round(activePeriod.senior_mgr_fee).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Hedge Swap Net:</span>
              <span>${Math.round(activePeriod.hedge_net_payment).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300 pt-2 border-t border-[#1e293b]">
              <span className="text-slate-400">Class A-1 Interest (AAA):</span>
              <span className="text-slate-100 font-semibold">${Math.round(activePeriod.aaa_interest).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Class B Interest (AA):</span>
              <span className="text-slate-100 font-semibold">${Math.round(activePeriod.aa_interest).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Class C Interest (BBB):</span>
              <span className="text-slate-100 font-semibold">${Math.round(activePeriod.bbb_interest).toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Step C: Principal Repayments & Residual Equity */}
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#1e293b]">
            <h4 className="text-xs uppercase font-bold tracking-wider text-sky-400">
              3. Principal Amortisation & Equity
            </h4>
            <span className="font-mono text-xs text-slate-400">Priority 4 & Residual</span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Class A Principal Paid:</span>
              <span className="text-emerald-400 font-semibold">${Math.round(activePeriod.aaa_principal).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Class B Principal Paid:</span>
              <span className="text-sky-400 font-semibold">${Math.round(activePeriod.aa_principal).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Class C Principal Paid:</span>
              <span className="text-amber-400 font-semibold">${Math.round(activePeriod.bbb_principal).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-300 pt-2 border-t border-[#1e293b]">
              <span className="text-slate-400">Subordinated Manager Fee:</span>
              <span>${Math.round(activePeriod.sub_mgr_fee).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-emerald-300 font-bold">
              <span>Subordinated Notes (Equity):</span>
              <span>${Math.round(activePeriod.equity_distribution).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Coverage Test Monitor for Active Period */}
      <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl">
        <h4 className="text-xs uppercase font-bold tracking-wider text-slate-300 mb-3 flex items-center space-x-2">
          <Shield className="w-4 h-4 text-[#c5a059]" />
          <span>Overcollateralization (OC) Coverage Test Status for Period {activePeriod.period}</span>
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          {/* Senior OC */}
          <div className="bg-[#0b0e14] p-3 rounded-lg border border-[#1e293b]">
            <div className="flex justify-between text-slate-400 mb-1">
              <span>Senior Class A OC:</span>
              <span className={activePeriod.senior_oc_pass ? 'text-emerald-400' : 'text-rose-400'}>
                {activePeriod.senior_oc_pass ? 'PASS' : 'BREACH'}
              </span>
            </div>
            <div className="text-lg font-bold text-slate-100">
              {activePeriod.senior_oc_ratio.toFixed(2)}%
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">Trigger Threshold: 118.00%</div>
          </div>

          {/* Mezzanine OC */}
          <div className="bg-[#0b0e14] p-3 rounded-lg border border-[#1e293b]">
            <div className="flex justify-between text-slate-400 mb-1">
              <span>Mezzanine Class B OC:</span>
              <span className={activePeriod.mezz_oc_pass ? 'text-emerald-400' : 'text-rose-400'}>
                {activePeriod.mezz_oc_pass ? 'PASS' : 'BREACH'}
              </span>
            </div>
            <div className="text-lg font-bold text-slate-100">
              {activePeriod.mezz_oc_ratio.toFixed(2)}%
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">Trigger Threshold: 112.00%</div>
          </div>

          {/* Junior OC */}
          <div className="bg-[#0b0e14] p-3 rounded-lg border border-[#1e293b]">
            <div className="flex justify-between text-slate-400 mb-1">
              <span>Junior Class C OC:</span>
              <span className={activePeriod.junior_oc_pass ? 'text-emerald-400' : 'text-rose-400'}>
                {activePeriod.junior_oc_pass ? 'PASS' : 'BREACH'}
              </span>
            </div>
            <div className="text-lg font-bold text-slate-100">
              {activePeriod.junior_oc_ratio.toFixed(2)}%
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">Trigger Threshold: 106.00%</div>
          </div>
        </div>
      </div>

      {/* Comprehensive 20-Period Interactive Waterfall Table */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl overflow-hidden">
        <div className="p-4 border-b border-[#1e293b] flex items-center justify-between">
          <h4 className="text-xs uppercase font-bold tracking-wider text-slate-200">
            Complete Period-by-Period Cash-Flow Waterfall Ledger (Periods 1 - 20)
          </h4>
          <span className="text-xs text-slate-400 font-mono">
            Click any row to inspect period details
          </span>
        </div>

        <div className="overflow-x-auto max-h-[500px]">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0b0e14] sticky top-0 z-10 border-b border-[#1e293b] text-slate-400 font-sans">
              <tr>
                <th className="py-2.5 px-3">Period</th>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3 text-right">Collateral End</th>
                <th className="py-2.5 px-3 text-right">Interest In</th>
                <th className="py-2.5 px-3 text-right">Principal In</th>
                <th className="py-2.5 px-3 text-right">Senior OC</th>
                <th className="py-2.5 px-3 text-right">Class A Prn</th>
                <th className="py-2.5 px-3 text-right">Class A Bal</th>
                <th className="py-2.5 px-3 text-right">Class B Bal</th>
                <th className="py-2.5 px-3 text-right">Class C Bal</th>
                <th className="py-2.5 px-3 text-right text-emerald-400">Equity Dist</th>
                <th className="py-2.5 px-3 text-right text-slate-400">Variance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/50">
              {ledger.map((p) => (
                <tr
                  key={p.period}
                  onClick={() => setSelectedPeriod(p.period)}
                  className={`hover:bg-[#161c28] cursor-pointer transition-colors ${
                    selectedPeriod === p.period ? 'bg-[#1e2430] border-l-2 border-[#c5a059]' : ''
                  }`}
                >
                  <td className="py-2 px-3 font-bold text-[#c5a059]">P{p.period}</td>
                  <td className="py-2 px-3 text-slate-300">{p.payment_date}</td>
                  <td className="py-2 px-3 text-right text-slate-200 font-medium">
                    ${Math.round(p.collat_ending / 1e3).toLocaleString()}k
                  </td>
                  <td className="py-2 px-3 text-right text-slate-300">
                    ${Math.round(p.interest_collected).toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-right text-slate-300">
                    ${Math.round(p.principal_collected).toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-right">
                    <span className={p.senior_oc_pass ? 'text-emerald-400' : 'text-rose-400'}>
                      {p.senior_oc_ratio.toFixed(1)}%
                    </span>
                  </td>
                  <td className="py-2 px-3 text-right text-slate-200">
                    ${Math.round(p.aaa_principal).toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-right text-slate-300">
                    ${Math.round(p.aaa_balance / 1e3).toLocaleString()}k
                  </td>
                  <td className="py-2 px-3 text-right text-slate-300">
                    ${Math.round(p.aa_balance / 1e3).toLocaleString()}k
                  </td>
                  <td className="py-2 px-3 text-right text-slate-300">
                    ${Math.round(p.bbb_balance / 1e3).toLocaleString()}k
                  </td>
                  <td className="py-2 px-3 text-right text-emerald-400 font-semibold">
                    ${Math.round(p.equity_distribution).toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-right text-slate-500 font-mono text-[10px]">
                    ${p.cash_variance.toFixed(4)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
