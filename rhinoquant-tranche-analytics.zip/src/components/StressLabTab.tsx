import React, { useState, useMemo } from 'react';
import {
  Flame,
  Cpu,
  AlertTriangle,
  Layers,
  ArrowRight,
  TrendingDown,
  Shield,
  Sliders,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { CollateralAsset, TrancheDefinition } from '../types/tranche';
import { executeWaterfall, valueCashNotes } from '../engine/trancheCalculations';

interface StressLabTabProps {
  collateral: CollateralAsset[];
  tranches: TrancheDefinition[];
}

export const StressLabTab: React.FC<StressLabTabProps> = ({
  collateral,
  tranches,
}) => {
  // Semiconductor Interactive Adapter State
  const [fabUtilizationShock, setFabUtilizationShock] = useState<number>(25); // -25%
  const [tapeoutFailureRate, setTapeoutFailureRate] = useState<number>(35); // 35% fail
  const [dsoExtension, setDsoExtension] = useState<number>(45); // +45 days
  const [selectedScenario, setSelectedScenario] = useState<string>('Baseline');

  // Baseline waterfall and valuation
  const baseResult = useMemo(() => {
    const wf = executeWaterfall(collateral, tranches, {
      defaultRateAnnual: 0.022,
      recoveryRate: 0.65,
      recoveryDelayQuarters: 2,
      sofrRate: 4.25,
    });
    const val = valueCashNotes(wf.ledger, tranches);
    return { wf, val };
  }, [collateral, tranches]);

  // Standard Scenarios Matrix
  const scenarios = useMemo(() => {
    return [
      {
        id: 'Baseline',
        name: 'Baseline Contractual Forecast',
        desc: 'Contractual baseline: 2.2% annual defaults, 65% senior secured recovery, 4.25% SOFR.',
        defaultRate: 0.022,
        recovery: 0.65,
        delay: 2,
        sofr: 4.25,
      },
      {
        id: 'Clustered_Defaults',
        name: 'Contagion & Clustered Defaults',
        desc: 'Correlated systemic contagion: 3x default frequency (6.5%), lower recovery (50%).',
        defaultRate: 0.065,
        recovery: 0.50,
        delay: 3,
        sofr: 4.25,
      },
      {
        id: 'Recovery_Collapse',
        name: 'Severe Recovery Collapse',
        desc: 'Asset liquidation distress: recovery falls to 25%, 12-month delay.',
        defaultRate: 0.035,
        recovery: 0.25,
        delay: 4,
        sofr: 4.00,
      },
      {
        id: 'Delayed_Recoveries',
        name: 'Extended Bankruptcy (Delayed Recoveries)',
        desc: 'Protracted restructuring: recovery delay extends to 6 quarters (18 months).',
        defaultRate: 0.030,
        recovery: 0.55,
        delay: 6,
        sofr: 4.25,
      },
      {
        id: 'Aggressive_Rate_Hikes',
        name: 'Aggressive Monetary Tightening (+300 bps)',
        desc: 'Stagflation shock: SOFR spikes to 7.25%, collateral defaults increase to 3.8%.',
        defaultRate: 0.038,
        recovery: 0.55,
        delay: 2,
        sofr: 7.25,
      },
      {
        id: 'Major_Obligor_Failure',
        name: 'Top-3 Obligors Sudden Default',
        desc: 'Idiosyncratic credit shock: immediate 60% loss on 3 largest exposures.',
        defaultRate: 0.045,
        recovery: 0.40,
        delay: 3,
        sofr: 4.25,
      },
      {
        id: 'Semiconductor_Stress',
        name: 'Semiconductor Supply Shock & Fab Utilization Crunch',
        desc: 'Specialized Borrower Adapter: Fab utilization down, qualification test failures, and DSO payment stretch.',
        defaultRate: 0.040,
        recovery: 0.45,
        delay: 3,
        sofr: 4.50,
        isCustomSemi: true,
      },
    ];
  }, []);

  // Compute stressed results
  const currentScenario = scenarios.find((s) => s.id === selectedScenario) || scenarios[0];

  const stressedResult = useMemo(() => {
    // If semiconductor custom stress
    let activeCollateral = [...collateral];

    if (currentScenario.id === 'Semiconductor_Stress') {
      activeCollateral = collateral.map((a) => {
        if (!a.is_semiconductor) return a;

        // Apply fab utilization drop
        const newUtil = Math.max(40, (a.fab_utilization_pct || 80) - fabUtilizationShock);
        let newRating = a.rating;
        if (newUtil < 65) {
          if (a.rating === 'BBB+') newRating = 'BBB';
          else if (a.rating === 'BBB') newRating = 'BBB-';
          else if (a.rating === 'BB+') newRating = 'BB';
        }

        // Apply tapeout qualification failure
        let newSpread = a.spread_bps;
        if (a.tapeout_stage && a.tapeout_stage.includes('Qualification')) {
          newSpread += Math.round(tapeoutFailureRate * 3);
        }

        // Apply DSO extension
        const newDso = (a.dso_days || 60) + dsoExtension;
        let newCoupon = a.coupon_pct;
        if (newDso > 100) {
          newCoupon = Math.max(2.0, a.coupon_pct * 0.85);
        }

        return {
          ...a,
          rating: newRating,
          spread_bps: newSpread,
          coupon_pct: newCoupon,
          fab_utilization_pct: newUtil,
          dso_days: newDso,
        };
      });
    }

    const wf = executeWaterfall(activeCollateral, tranches, {
      defaultRateAnnual: currentScenario.defaultRate,
      recoveryRate: currentScenario.recovery,
      recoveryDelayQuarters: currentScenario.delay,
      sofrRate: currentScenario.sofr,
    });
    const val = valueCashNotes(wf.ledger, tranches);

    const ocBreached = wf.ledger.some((p) => !p.senior_oc_pass || !p.mezz_oc_pass || !p.junior_oc_pass);

    return { wf, val, ocBreached };
  }, [
    collateral,
    tranches,
    currentScenario,
    fabUtilizationShock,
    tapeoutFailureRate,
    dsoExtension,
  ]);

  return (
    <div className="space-y-6">
      {/* Scenario Selector Tabs */}
      <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-[#1e293b] mb-4 gap-2">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
            <Flame className="w-4 h-4 text-rose-400" />
            <span>Configurable Stress Scenario Matrix</span>
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Selected: <strong className="text-[#c5a059]">{currentScenario.name}</strong>
          </span>
        </div>

        {/* Scenario Pill Buttons */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
          {scenarios.map((scen) => (
            <button
              key={scen.id}
              onClick={() => setSelectedScenario(scen.id)}
              className={`p-2.5 rounded-lg text-left text-xs transition-all border ${
                selectedScenario === scen.id
                  ? 'bg-[#c5a059] text-[#0b0e14] border-[#c5a059] font-bold shadow'
                  : 'bg-[#0b0e14] text-slate-300 border-[#1e293b] hover:border-slate-600'
              }`}
            >
              <div className="truncate font-semibold">{scen.name}</div>
              <div className="text-[10px] opacity-80 mt-1 font-mono">
                Def: {(scen.defaultRate * 100).toFixed(1)}% • Rec: {(scen.recovery * 100).toFixed(0)}%
              </div>
            </button>
          ))}
        </div>

        <p className="text-xs text-slate-400 font-sans mt-3 bg-[#0b0e14] p-3 rounded-lg border border-[#1e293b]">
          {currentScenario.desc}
        </p>
      </div>

      {/* SPECIALIZED SEMICONDUCTOR BORROWER ADAPTER PANEL */}
      {selectedScenario === 'Semiconductor_Stress' && (
        <div className="bg-[#111620] border-2 border-[#c5a059]/60 rounded-xl p-6 shadow-lg shadow-[#c5a059]/10 space-y-4">
          <div className="flex items-center space-x-2 pb-3 border-b border-[#1e293b]">
            <Cpu className="w-5 h-5 text-[#c5a059]" />
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              Specialized Semiconductor Portfolio Cash-Flow Adapter
            </h4>
            <span className="text-xs bg-[#c5a059]/20 text-[#c5a059] px-2 py-0.5 rounded border border-[#c5a059]/30 font-mono">
              Operational Micro-Shock Adapter
            </span>
          </div>

          <p className="text-xs text-slate-400 font-sans">
            Directly maps fab operational disruptions into borrower balance sheets: low capacity utilization triggers rating downgrades, qualification test failures step up borrowing spreads, and extended customer DSO causes cash collection delays.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            {/* Control 1: Fab Utilization Shock */}
            <div className="space-y-2 bg-[#0b0e14] p-4 rounded-lg border border-[#1e293b]">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">Fab Utilization Drop:</span>
                <strong className="text-rose-400">-{fabUtilizationShock}%</strong>
              </div>
              <input
                type="range"
                min="10"
                max="45"
                step="5"
                value={fabUtilizationShock}
                onChange={(e) => setFabUtilizationShock(Number(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
              <span className="text-[10px] text-slate-500 block">
                Impact: Drop below 65% forces EBITDA margin compression and rating notch cuts.
              </span>
            </div>

            {/* Control 2: Tapeout Qualification Failure Rate */}
            <div className="space-y-2 bg-[#0b0e14] p-4 rounded-lg border border-[#1e293b]">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">Qualification Failure Rate:</span>
                <strong className="text-amber-400">{tapeoutFailureRate}%</strong>
              </div>
              <input
                type="range"
                min="10"
                max="60"
                step="5"
                value={tapeoutFailureRate}
                onChange={(e) => setTapeoutFailureRate(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <span className="text-[10px] text-slate-500 block">
                Impact: Silicon bringup re-spins trigger credit margin calls (+120 bps step-up).
              </span>
            </div>

            {/* Control 3: DSO Days Extension */}
            <div className="space-y-2 bg-[#0b0e14] p-4 rounded-lg border border-[#1e293b]">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">Customer DSO Delay:</span>
                <strong className="text-sky-400">+{dsoExtension} Days</strong>
              </div>
              <input
                type="range"
                min="10"
                max="80"
                step="5"
                value={dsoExtension}
                onChange={(e) => setDsoExtension(Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer"
              />
              <span className="text-[10px] text-slate-500 block">
                Impact: Working capital stretch beyond 100 days forces short-term coupon deferral.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Stress Impact Comparison Table */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl overflow-hidden">
        <div className="p-4 border-b border-[#1e293b] flex items-center justify-between">
          <h4 className="text-xs uppercase font-bold tracking-wider text-slate-200">
            Tranche Impact: Baseline vs Stressed Scenario ({currentScenario.name})
          </h4>
          <span
            className={`text-xs px-2.5 py-0.5 rounded-full font-mono ${
              stressedResult.ocBreached
                ? 'bg-rose-950/60 text-rose-400 border border-rose-800/40'
                : 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
            }`}
          >
            {stressedResult.ocBreached ? 'Coverage Test Breached: Interest Diverted' : 'All Coverage Tests Passed'}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0b0e14] border-b border-[#1e293b] text-slate-400 font-sans">
              <tr>
                <th className="py-3 px-4">Tranche</th>
                <th className="py-3 px-4">Rating</th>
                <th className="py-3 px-4 text-right">Base Price</th>
                <th className="py-3 px-4 text-right">Stressed Price</th>
                <th className="py-3 px-4 text-right">Price Delta</th>
                <th className="py-3 px-4 text-right">Base WAL</th>
                <th className="py-3 px-4 text-right">Stressed WAL</th>
                <th className="py-3 px-4 text-right">WAL Extension</th>
                <th className="py-3 px-4 text-right">Shortfall</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/60">
              {tranches.map((t, idx) => {
                const baseVal = baseResult.val[idx];
                const stressVal = stressedResult.val[idx];
                const priceDelta = stressVal.model_price_clean - baseVal.model_price_clean;
                const walDelta = stressVal.wal_years - baseVal.wal_years;

                return (
                  <tr key={t.tranche_id} className="hover:bg-[#161c28] transition-colors">
                    <td className="py-3 px-4 font-sans font-semibold text-slate-200">{t.name}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          t.rating === 'AAA'
                            ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                            : t.rating === 'AA'
                            ? 'bg-sky-950/60 text-sky-400 border border-sky-800/40'
                            : t.rating === 'BBB'
                            ? 'bg-amber-950/60 text-amber-400 border border-amber-800/40'
                            : 'bg-rose-950/60 text-rose-400 border border-rose-800/40'
                        }`}
                      >
                        {t.rating}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-slate-400">
                      {baseVal.model_price_clean.toFixed(3)}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-100 font-bold">
                      {stressVal.model_price_clean.toFixed(3)}
                    </td>
                    <td className="py-3 px-4 text-right font-bold">
                      <span className={priceDelta < 0 ? 'text-rose-400' : 'text-emerald-400'}>
                        {priceDelta > 0 ? `+${priceDelta.toFixed(3)}` : priceDelta.toFixed(3)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-slate-400">
                      {baseVal.wal_years.toFixed(2)}y
                    </td>
                    <td className="py-3 px-4 text-right text-slate-200">
                      {stressVal.wal_years.toFixed(2)}y
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className={walDelta > 0.1 ? 'text-amber-400 font-medium' : 'text-slate-400'}>
                        {walDelta > 0 ? `+${walDelta.toFixed(2)}y` : `${walDelta.toFixed(2)}y`}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {stressVal.principal_shortfall > 0 ? (
                        <span className="text-rose-400 font-bold">
                          ${stressVal.principal_shortfall.toLocaleString()}
                        </span>
                      ) : (
                        <span className="text-emerald-400 font-mono">$0</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
