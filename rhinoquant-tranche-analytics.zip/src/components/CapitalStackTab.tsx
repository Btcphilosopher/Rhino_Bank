import React from 'react';
import {
  Layers,
  Shield,
  Info,
  TrendingDown,
  BarChart,
  Percent,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { TrancheDefinition } from '../types/tranche';
import { trancheLossFraction } from '../engine/trancheCalculations';

interface CapitalStackTabProps {
  tranches: TrancheDefinition[];
  simLossFractions: number[];
  totalNotional: number;
}

export const CapitalStackTab: React.FC<CapitalStackTabProps> = ({
  tranches,
  simLossFractions,
  totalNotional,
}) => {
  // Compute static analytical metrics for each tranche across simulation paths
  const trancheAnalytics = tranches.map((t) => {
    const att = t.attachment_point;
    const det = t.detachment_point;
    const thk = det - att;
    const trancheNotional = thk * totalNotional;

    let lossSum = 0;
    let anyLossCount = 0;
    let completeLossCount = 0;
    const trancheLossFractions: number[] = new Array(simLossFractions.length);

    for (let i = 0; i < simLossFractions.length; i++) {
      const portLoss = simLossFractions[i];
      const tLoss = trancheLossFraction(portLoss, att, det);
      trancheLossFractions[i] = tLoss;
      lossSum += tLoss;
      if (tLoss > 0.0001) anyLossCount++;
      if (tLoss >= 0.9999) completeLossCount++;
    }

    const n = simLossFractions.length;
    const expLossFrac = lossSum / n;
    const expLossAmount = expLossFrac * trancheNotional;
    const probAnyLoss = (anyLossCount / n) * 100;
    const probCompleteLoss = (completeLossCount / n) * 100;
    const expRemainingAmount = trancheNotional - expLossAmount;

    // Quantiles
    const sortedTLoss = [...trancheLossFractions].sort((a, b) => a - b);
    const q50 = sortedTLoss[Math.floor(n * 0.50)] * 100;
    const q90 = sortedTLoss[Math.floor(n * 0.90)] * 100;
    const q95 = sortedTLoss[Math.floor(n * 0.95)] * 100;
    const q99 = sortedTLoss[Math.floor(n * 0.99)] * 100;

    return {
      tranche: t,
      attachmentPct: att * 100,
      detachmentPct: det * 100,
      thicknessPct: thk * 100,
      trancheNotional,
      expLossFrac: expLossFrac * 100,
      expLossAmount,
      probAnyLoss,
      probCompleteLoss,
      expRemainingAmount,
      expRemainingPct: (1 - expLossFrac) * 100,
      q50,
      q90,
      q95,
      q99,
    };
  });

  return (
    <div className="space-y-6">
      {/* Methodological Boundary Callout */}
      <div className="bg-[#111620] border-l-4 border-[#c5a059] border-y border-r border-[#1e293b] p-5 rounded-r-xl">
        <div className="flex items-start space-x-3">
          <Info className="w-5 h-5 text-[#c5a059] flex-shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <span className="font-semibold text-slate-200">
              Contractual Formula & Methodology Boundary Notice:
            </span>
            <p className="text-slate-400 leading-relaxed font-sans">
              The calculations below use the contractual static tranche loss piecewise linear function:{' '}
              <code className="text-[#c5a059] bg-[#0b0e14] px-1.5 py-0.5 rounded font-mono">
                tranche_loss_fraction(L, A, D) = min(max(L - A, 0), D - A) / (D - A)
              </code>
              . Strict validation enforces{' '}
              <code className="text-emerald-400 font-mono">0 &le; A &lt; D &le; 1</code> and{' '}
              <code className="text-emerald-400 font-mono">0 &le; L &le; 1</code>.
              <strong className="text-amber-300 ml-1">
                This static formula applies to synthetic CDS reference exposures. It does not replace an amortising cash CDO's dynamic period-by-period waterfall.
              </strong>
            </p>
          </div>
        </div>
      </div>

      {/* Visual Capital Stack Ladder */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl p-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#1e293b] mb-6">
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
              <Layers className="w-4 h-4 text-[#c5a059]" />
              <span>Capital Structure Loss Absorption Profile</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Reference Pool Notional: <span className="text-slate-200 font-mono font-medium">$100,000,000</span>
            </p>
          </div>
        </div>

        {/* Visual Stack Cards */}
        <div className="space-y-4">
          {trancheAnalytics.map((item) => (
            <div
              key={item.tranche.tranche_id}
              className="bg-[#0b0e14] border border-[#1e293b] rounded-xl p-4 hover:border-slate-600 transition-all"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                <div className="flex items-center space-x-3">
                  <span
                    className={`w-14 text-center py-1 rounded text-xs font-bold font-mono ${
                      item.tranche.rating === 'AAA'
                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                        : item.tranche.rating === 'AA'
                        ? 'bg-sky-950/60 text-sky-400 border border-sky-800/40'
                        : item.tranche.rating === 'BBB'
                        ? 'bg-amber-950/60 text-amber-400 border border-amber-800/40'
                        : 'bg-rose-950/60 text-rose-400 border border-rose-800/40'
                    }`}
                  >
                    {item.tranche.rating}
                  </span>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-100">{item.tranche.name}</h4>
                    <span className="text-xs font-mono text-slate-400">
                      [{item.attachmentPct.toFixed(1)}% &mdash; {item.detachmentPct.toFixed(1)}%] • Thickness {item.thicknessPct.toFixed(1)}%
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
                  <div className="bg-[#111620] px-3 py-1.5 rounded-lg border border-[#1e293b]">
                    <span className="text-slate-400">Notional: </span>
                    <strong className="text-slate-100">${(item.trancheNotional / 1e6).toFixed(1)}M</strong>
                  </div>
                  <div className="bg-[#111620] px-3 py-1.5 rounded-lg border border-[#1e293b]">
                    <span className="text-slate-400">Subordination: </span>
                    <strong className="text-emerald-400">{(item.tranche.subordination_pct * 100).toFixed(1)}%</strong>
                  </div>
                  <div className="bg-[#111620] px-3 py-1.5 rounded-lg border border-[#1e293b]">
                    <span className="text-slate-400">P(Any Loss): </span>
                    <strong className={item.probAnyLoss > 10 ? 'text-amber-400' : 'text-slate-200'}>
                      {item.probAnyLoss.toFixed(2)}%
                    </strong>
                  </div>
                  <div className="bg-[#111620] px-3 py-1.5 rounded-lg border border-[#1e293b]">
                    <span className="text-slate-400">Expected Loss: </span>
                    <strong className="text-rose-400">
                      {item.expLossFrac.toFixed(2)}% (${(item.expLossAmount / 1e6).toFixed(2)}M)
                    </strong>
                  </div>
                </div>
              </div>

              {/* Loss Buffer Progress Bar */}
              <div className="mt-3">
                <div className="flex justify-between text-[11px] font-mono text-slate-500 mb-1">
                  <span>Loss Buffer Cushion: {item.attachmentPct.toFixed(1)}% Portfolio Loss</span>
                  <span>Expected Remaining: {item.expRemainingPct.toFixed(2)}% (${(item.expRemainingAmount / 1e6).toFixed(2)}M)</span>
                </div>
                <div className="h-2 w-full rounded-full bg-[#1e293b] overflow-hidden flex">
                  <div
                    style={{ width: `${Math.min(100, item.expRemainingPct)}%` }}
                    className="bg-emerald-500/80 rounded-full"
                  />
                  <div
                    style={{ width: `${Math.min(100, item.expLossFrac)}%` }}
                    className="bg-rose-500/80"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quantiles & Tail Loss Table */}
        <div className="mt-8">
          <h4 className="text-xs uppercase tracking-wider font-semibold text-slate-300 mb-3">
            Loss Distribution Quantiles & Tail Analysis (Static Portfolio Model)
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#1e293b] text-slate-400 font-sans">
                  <th className="pb-2.5">Tranche</th>
                  <th className="pb-2.5">Notional</th>
                  <th className="pb-2.5">Expected Loss</th>
                  <th className="pb-2.5">Prob(Loss &gt; 0)</th>
                  <th className="pb-2.5">Prob(Total Wipeout)</th>
                  <th className="pb-2.5">50% Median</th>
                  <th className="pb-2.5">90% Loss</th>
                  <th className="pb-2.5">95% Loss</th>
                  <th className="pb-2.5 text-right">99% Tail VaR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e293b]/50">
                {trancheAnalytics.map((item) => (
                  <tr key={item.tranche.tranche_id} className="hover:bg-[#161c28]">
                    <td className="py-2.5 font-sans font-semibold text-slate-200">
                      {item.tranche.name}
                    </td>
                    <td className="py-2.5 text-slate-300">${(item.trancheNotional / 1e6).toFixed(1)}M</td>
                    <td className="py-2.5 text-rose-400 font-semibold">
                      {item.expLossFrac.toFixed(2)}% (${(item.expLossAmount / 1e6).toFixed(3)}M)
                    </td>
                    <td className="py-2.5 text-slate-300">{item.probAnyLoss.toFixed(2)}%</td>
                    <td className="py-2.5 text-slate-300">{item.probCompleteLoss.toFixed(2)}%</td>
                    <td className="py-2.5 text-slate-400">{item.q50.toFixed(2)}%</td>
                    <td className="py-2.5 text-slate-300">{item.q90.toFixed(2)}%</td>
                    <td className="py-2.5 text-amber-400 font-medium">{item.q95.toFixed(2)}%</td>
                    <td className="py-2.5 text-right text-rose-400 font-bold">{item.q99.toFixed(2)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
