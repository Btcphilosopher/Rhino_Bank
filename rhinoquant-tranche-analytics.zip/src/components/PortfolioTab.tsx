import React, { useState } from 'react';
import {
  TrendingUp,
  CheckCircle2,
  Clock,
  Layers,
  DollarSign,
  AlertTriangle,
  Scale,
  Shield,
  FileSpreadsheet,
} from 'lucide-react';
import { TrancheDeskTrade } from '../types/tranche';
import { getPnLAttribution } from '../engine/trancheCalculations';

interface PortfolioTabProps {
  trades: TrancheDeskTrade[];
}

export const PortfolioTab: React.FC<PortfolioTabProps> = ({ trades }) => {
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'SETTLED' | 'UNSETTLED'>('ALL');

  const settled = trades.filter((t) => t.status === 'SETTLED');
  const unsettled = trades.filter((t) => t.status === 'UNSETTLED');

  const displayTrades = activeFilter === 'ALL' ? trades : activeFilter === 'SETTLED' ? settled : unsettled;

  const totalCarryingValue = settled.reduce((sum, t) => sum + t.carrying_value, 0);
  const totalUnrealizedPnL = settled.reduce((sum, t) => sum + t.unrealized_pnl, 0);
  const totalAccrued = settled.reduce((sum, t) => sum + t.accrued_coupon, 0);
  const unsettledCashDue = unsettled
    .filter((t) => t.side === 'BUY')
    .reduce((sum, t) => sum + t.notional * (t.trade_price / 100), 0);

  const attribution = getPnLAttribution(125400);

  return (
    <div className="space-y-6">
      {/* Institutional Top Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl">
          <div className="flex justify-between text-xs text-slate-400 uppercase font-semibold">
            <span>Settled Carrying Value</span>
            <span className="text-emerald-400 font-mono">5 Positions</span>
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-2">
            ${(totalCarryingValue / 1e6).toFixed(2)}M
          </div>
          <p className="text-xs text-slate-400 mt-1">Mark-to-Market Valuation</p>
        </div>

        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl">
          <div className="flex justify-between text-xs text-slate-400 uppercase font-semibold">
            <span>Unrealized P&L</span>
            <span className={totalUnrealizedPnL >= 0 ? 'text-emerald-400 font-mono' : 'text-rose-400 font-mono'}>
              MTM
            </span>
          </div>
          <div className={`text-2xl font-bold font-mono mt-2 ${totalUnrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            ${totalUnrealizedPnL >= 0 ? `+${totalUnrealizedPnL.toLocaleString()}` : totalUnrealizedPnL.toLocaleString()}
          </div>
          <p className="text-xs text-slate-400 mt-1">Carrying vs Trade Execution Price</p>
        </div>

        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl">
          <div className="flex justify-between text-xs text-slate-400 uppercase font-semibold">
            <span>Accrued Interest</span>
            <span className="text-slate-400 font-mono">ACT/360</span>
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-2">
            ${totalAccrued.toLocaleString()}
          </div>
          <p className="text-xs text-slate-400 mt-1">Pending Next Payment Date</p>
        </div>

        <div className="bg-[#111620] border border-[#1e293b] p-5 rounded-xl">
          <div className="flex justify-between text-xs text-slate-400 uppercase font-semibold">
            <span>Unsettled Cash Due</span>
            <span className="text-amber-400 font-mono">T+3 Settlement</span>
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-2">
            ${(unsettledCashDue / 1e6).toFixed(2)}M
          </div>
          <p className="text-xs text-slate-400 mt-1">Pending Trade Deliveries</p>
        </div>
      </div>

      {/* TrancheDesk Positions Table */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl overflow-hidden">
        <div className="p-4 border-b border-[#1e293b] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center space-x-2">
            <FileSpreadsheet className="w-4 h-4 text-[#c5a059]" />
            <h4 className="text-xs uppercase font-bold tracking-wider text-slate-200">
              RhinoBank TrancheDesk Institutional Holdings (Adapter v3.4)
            </h4>
          </div>

          <div className="flex bg-[#0b0e14] p-1 rounded-lg border border-[#1e293b] text-xs font-mono">
            <button
              onClick={() => setActiveFilter('ALL')}
              className={`px-3 py-1 rounded transition-colors ${
                activeFilter === 'ALL' ? 'bg-[#c5a059] text-[#0b0e14] font-bold' : 'text-slate-400'
              }`}
            >
              All ({trades.length})
            </button>
            <button
              onClick={() => setActiveFilter('SETTLED')}
              className={`px-3 py-1 rounded transition-colors ${
                activeFilter === 'SETTLED' ? 'bg-[#c5a059] text-[#0b0e14] font-bold' : 'text-slate-400'
              }`}
            >
              Settled ({settled.length})
            </button>
            <button
              onClick={() => setActiveFilter('UNSETTLED')}
              className={`px-3 py-1 rounded transition-colors ${
                activeFilter === 'UNSETTLED' ? 'bg-[#c5a059] text-[#0b0e14] font-bold' : 'text-slate-400'
              }`}
            >
              Unsettled ({unsettled.length})
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0b0e14] border-b border-[#1e293b] text-slate-400 font-sans">
              <tr>
                <th className="py-3 px-4">Trade ID</th>
                <th className="py-3 px-4">Deal / Instrument</th>
                <th className="py-3 px-4">Side</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Notional</th>
                <th className="py-3 px-4 text-right">Trade Price</th>
                <th className="py-3 px-4 text-right">Market Quote</th>
                <th className="py-3 px-4 text-right">Carrying Value</th>
                <th className="py-3 px-4 text-right">Unrealized P&L</th>
                <th className="py-3 px-4">Custodian / Book</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/60">
              {displayTrades.map((t) => (
                <tr key={t.trade_id} className="hover:bg-[#161c28] transition-colors">
                  <td className="py-3 px-4 text-[#c5a059] font-bold">{t.trade_id}</td>
                  <td className="py-3 px-4 font-sans text-slate-200">
                    <div>{t.tranche_name}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{t.deal_name}</div>
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-300">{t.side}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        t.status === 'SETTLED'
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                          : 'bg-amber-950/60 text-amber-400 border border-amber-800/40'
                      }`}
                    >
                      {t.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-slate-200">
                    ${t.notional.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-400">
                    {t.trade_price.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-100 font-semibold">
                    {t.market_quote_price.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-100 font-bold">
                    ${t.carrying_value.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-bold">
                    <span className={t.unrealized_pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                      {t.unrealized_pnl >= 0 ? `+$${t.unrealized_pnl.toLocaleString()}` : `-$${Math.abs(t.unrealized_pnl).toLocaleString()}`}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                    <div>{t.custodian}</div>
                    <div className="text-[10px] text-slate-500">{t.book}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* P&L Attribution with Strict Unexplained Residual */}
      <div className="bg-[#111620] border border-[#1e293b] rounded-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-[#1e293b] gap-2">
          <div>
            <h4 className="text-xs uppercase font-bold tracking-wider text-slate-200 flex items-center space-x-2">
              <Scale className="w-4 h-4 text-[#c5a059]" />
              <span>Institutional P&L Attribution & Unexplained Residual Disclosure</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Strict RhinoBank Risk Governance Policy: Unexplained non-linear cross effects must be explicitly reported as a residual rather than forced to zero.
            </p>
          </div>
          <div className="text-xs font-mono bg-[#0b0e14] px-3 py-1.5 rounded-lg border border-[#1e293b]">
            Total Observed Period P&L: <strong className="text-emerald-400">+${attribution.totalObserved.toLocaleString()}</strong>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0b0e14] border-b border-[#1e293b] text-slate-400 font-sans">
              <tr>
                <th className="py-2.5 px-4">Attribution Component</th>
                <th className="py-2.5 px-4 text-right">Amount (USD)</th>
                <th className="py-2.5 px-4 text-right">% of Total</th>
                <th className="py-2.5 px-4">Accounting & Model Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/50">
              {attribution.items.map((item, idx) => (
                <tr
                  key={idx}
                  className={`hover:bg-[#161c28] transition-colors ${
                    item.component.includes('Unexplained') ? 'bg-[#181d28] font-bold text-amber-300' : ''
                  }`}
                >
                  <td className="py-2.5 px-4 font-sans text-slate-200 font-medium">
                    {item.component}
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <span
                      className={
                        item.amount_usd > 0
                          ? 'text-emerald-400'
                          : item.amount_usd < 0
                          ? 'text-rose-400'
                          : 'text-slate-400'
                      }
                    >
                      {item.amount_usd >= 0 ? `+$${item.amount_usd.toLocaleString()}` : `-$${Math.abs(item.amount_usd).toLocaleString()}`}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-300">
                    {item.pct_of_total.toFixed(2)}%
                  </td>
                  <td className="py-2.5 px-4 text-slate-400 font-sans text-[11px]">
                    {item.accounting_status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
