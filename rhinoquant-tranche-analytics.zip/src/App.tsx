/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  LayoutDashboard,
  Database,
  Layers,
  Calculator,
  Scale,
  Flame,
  Sliders,
  TrendingUp,
  FileCheck2,
  CheckCircle2,
  RotateCcw,
} from 'lucide-react';

import { Header } from './components/Header';
import { OverviewTab } from './components/OverviewTab';
import { CollateralTab } from './components/CollateralTab';
import { CapitalStackTab } from './components/CapitalStackTab';
import { WaterfallTab } from './components/WaterfallTab';
import { ValuationTab } from './components/ValuationTab';
import { SimulationTab } from './components/SimulationTab';
import { StressLabTab } from './components/StressLabTab';
import { PortfolioTab } from './components/PortfolioTab';
import { ReportsTab } from './components/ReportsTab';

import {
  CollateralAsset,
  TrancheDefinition,
  WaterfallPeriodRecord,
  CashTrancheValuation,
  SyntheticTrancheValuation,
  SimulationDiagnostics,
  TrancheDeskTrade,
} from './types/tranche';

import {
  simulateCreditDefaults,
  executeWaterfall,
  valueCashNotes,
  valueSyntheticTranches,
} from './engine/trancheCalculations';

export default function App() {
  // Navigation & Mode
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [analysisMode, setAnalysisMode] = useState<'cash_cdo' | 'synthetic_tranche' | 'investor_portfolio'>('cash_cdo');

  // Simulation Parameters
  const [nSims, setNSims] = useState<number>(3000);
  const [rho, setRho] = useState<number>(0.30);
  const [copulaType, setCopulaType] = useState<'Gaussian' | 'Student-t'>('Gaussian');
  const [seed, setSeed] = useState<number>(42);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);

  // Datasets
  const [collateral, setCollateral] = useState<CollateralAsset[]>([]);
  const [tranches, setTranches] = useState<TrancheDefinition[]>([]);
  const [trades, setTrades] = useState<TrancheDeskTrade[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Simulation and Analytical Results State
  const [lossFractions, setLossFractions] = useState<number[]>([]);
  const [diagnostics, setDiagnostics] = useState<SimulationDiagnostics | null>(null);
  const [waterfallLedger, setWaterfallLedger] = useState<WaterfallPeriodRecord[]>([]);
  const [cashConserved, setCashConserved] = useState<boolean>(true);
  const [finalReserve, setFinalReserve] = useState<number>(1000000);
  const [endingCollateral, setEndingCollateral] = useState<number>(100000000);
  const [cashValuations, setCashValuations] = useState<CashTrancheValuation[]>([]);
  const [syntheticValuations, setSyntheticValuations] = useState<SyntheticTrancheValuation[]>([]);
  const [runHash, setRunHash] = useState<string>('8f9c2d14e7a2b560');

  // Initial Data Ingestion
  useEffect(() => {
    async function loadData() {
      try {
        // 1. Fetch Collateral CSV
        const collatRes = await fetch('/api/collateral-pool');
        const collatText = await collatRes.text();
        const collatRows = collatText.trim().split('\n');
        const headers = collatRows[0].split(',');
        const parsedAssets: CollateralAsset[] = [];

        for (let i = 1; i < collatRows.length; i++) {
          const cols = collatRows[i].split(',');
          if (cols.length >= 14) {
            parsedAssets.push({
              asset_id: cols[0],
              obligor_id: cols[1],
              obligor_name: cols[2],
              sector: cols[3],
              region: cols[4],
              rating: cols[5],
              spread_bps: parseFloat(cols[6]),
              coupon_pct: parseFloat(cols[7]),
              original_face: parseFloat(cols[8]),
              current_balance: parseFloat(cols[9]),
              principal_factor: parseFloat(cols[10]),
              maturity_years: parseFloat(cols[11]),
              seniority: cols[12],
              currency: cols[13],
              is_semiconductor: cols[14] === 'TRUE',
              fab_utilization_pct: cols[15] !== 'NA' ? parseFloat(cols[15]) : undefined,
              tapeout_stage: cols[16] !== 'NA' ? cols[16] : undefined,
              dso_days: cols[17] !== 'NA' ? parseFloat(cols[17]) : undefined,
            });
          }
        }
        setCollateral(parsedAssets);

        // 2. Fetch Capital Stack
        const structRes = await fetch('/api/capital-stack');
        const structData = await structRes.json();
        setTranches(structData.tranches || []);

        // 3. Fetch TrancheDesk Trades
        const tradeRes = await fetch('/api/tranche-desk-trades');
        const tradeText = await tradeRes.text();
        const tradeRows = tradeText.trim().split('\n');
        const parsedTrades: TrancheDeskTrade[] = [];

        for (let i = 1; i < tradeRows.length; i++) {
          const cols = tradeRows[i].split(',');
          if (cols.length >= 10) {
            parsedTrades.push({
              trade_id: cols[0],
              position_id: cols[1],
              deal_name: cols[2],
              tranche_id: cols[3],
              tranche_name: cols[4],
              side: cols[5],
              status: cols[6] as any,
              trade_date: cols[7],
              settlement_date: cols[8],
              notional: parseFloat(cols[9]),
              trade_price: parseFloat(cols[10]),
              market_quote_price: parseFloat(cols[11]),
              carrying_value: parseFloat(cols[12]),
              unrealized_pnl: parseFloat(cols[13]),
              accrued_coupon: parseFloat(cols[14]),
              book: cols[15],
              custodian: cols[16],
              source: cols[17],
            });
          }
        }
        setTrades(parsedTrades);

        // Run Initial Calculations
        runPipeline(parsedAssets, structData.tranches, nSims, rho, copulaType, seed);
      } catch (err) {
        console.error('Error initializing data:', err);
      } finally {
        setIsLoading(false);
      }
    }

    loadData();
  }, []);

  // Calculation Pipeline Runner
  const runPipeline = useCallback(
    (
      collatData: CollateralAsset[],
      trancheData: TrancheDefinition[],
      numSims: number,
      corrRho: number,
      copula: 'Gaussian' | 'Student-t',
      rndSeed: number
    ) => {
      setIsExecuting(true);

      // Run Credit Simulation
      const sim = simulateCreditDefaults(collatData, numSims, corrRho, copula, rndSeed);
      setLossFractions(sim.lossFractions);
      setDiagnostics(sim.diagnostics);

      // Run Cash Flow Waterfall
      const wf = executeWaterfall(collatData, trancheData, {
        defaultRateAnnual: 0.022,
        recoveryRate: 0.65,
        sofrRate: 4.25,
      });
      setWaterfallLedger(wf.ledger);
      setCashConserved(wf.cashConserved);
      setFinalReserve(wf.finalReserve);
      setEndingCollateral(wf.endingCollateral);

      // Value Cash Notes
      const cashVals = valueCashNotes(wf.ledger, trancheData);
      setCashValuations(cashVals);

      // Value Synthetic Tranches
      const synVals = valueSyntheticTranches(sim.lossFractions);
      setSyntheticValuations(synVals);

      // Generate Run Hash
      const hash = Math.floor(Math.random() * 0xffffffff).toString(16).padStart(8, '0') +
                   Math.floor(Math.random() * 0xffffffff).toString(16).padStart(8, '0');
      setRunHash(hash);

      setIsExecuting(false);
    },
    []
  );

  const handleManualRun = () => {
    if (collateral.length > 0 && tranches.length > 0) {
      runPipeline(collateral, tranches, nSims, rho, copulaType, seed);
    }
  };

  const totalNotional = useMemo(() => {
    return collateral.reduce((sum, a) => sum + a.current_balance, 0) || 100000000;
  }, [collateral]);

  // Tab definitions
  const tabs = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'collateral', label: 'Collateral', icon: Database },
    { id: 'capital_stack', label: 'Capital Stack', icon: Layers },
    { id: 'waterfall', label: 'Waterfall', icon: Calculator },
    { id: 'valuation', label: 'Valuation', icon: Scale },
    { id: 'simulation', label: 'Simulation', icon: Sliders },
    { id: 'stress_lab', label: 'Stress Lab', icon: Flame },
    { id: 'portfolio', label: 'Portfolio', icon: TrendingUp },
    { id: 'reports', label: 'Reports', icon: FileCheck2 },
  ];

  if (isLoading || !diagnostics) {
    return (
      <div className="min-h-screen bg-[#07090e] text-slate-200 flex flex-col items-center justify-center font-sans">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#c5a059] to-[#8c6d2c] flex items-center justify-center animate-pulse mb-4 shadow-lg shadow-[#c5a059]/30">
          <Layers className="w-6 h-6 text-[#0b0e14]" />
        </div>
        <h2 className="text-lg font-bold font-['Cinzel'] tracking-widest text-[#c5a059]">
          RHINOQUANT TRANCHE ANALYTICS
        </h2>
        <p className="text-xs text-slate-400 font-mono mt-1">
          Initializing institutional engine & validating USD 100M pool...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-[#c5a059]/30 selection:text-[#dfbe76]">
      {/* Institutional Top Bar */}
      <Header
        analysisMode={analysisMode}
        setAnalysisMode={setAnalysisMode}
        isExecuting={isExecuting}
        onExecute={handleManualRun}
        runHash={runHash}
        seed={seed}
        nSims={nSims}
        rho={rho}
      />

      {/* Institutional Tab Navigation */}
      <div className="bg-[#0b0e14] border-b border-[#1e293b] px-6">
        <nav className="flex space-x-1 overflow-x-auto no-scrollbar">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-3.5 px-4 text-xs font-semibold uppercase tracking-wider flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap ${
                  isActive
                    ? 'border-[#c5a059] text-[#c5a059] bg-[#111620]'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#c5a059]' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 p-6 max-w-7xl w-full mx-auto">
        {activeTab === 'overview' && (
          <OverviewTab
            tranches={tranches}
            diagnostics={diagnostics}
            setActiveTab={setActiveTab}
            cashConserved={cashConserved}
            totalNotional={totalNotional}
          />
        )}

        {activeTab === 'collateral' && (
          <CollateralTab collateral={collateral} />
        )}

        {activeTab === 'capital_stack' && (
          <CapitalStackTab
            tranches={tranches}
            simLossFractions={lossFractions}
            totalNotional={totalNotional}
          />
        )}

        {activeTab === 'waterfall' && (
          <WaterfallTab
            ledger={waterfallLedger}
            cashConserved={cashConserved}
            finalReserve={finalReserve}
            endingCollateral={endingCollateral}
          />
        )}

        {activeTab === 'valuation' && (
          <ValuationTab
            cashValuations={cashValuations}
            syntheticValuations={syntheticValuations}
          />
        )}

        {activeTab === 'simulation' && (
          <SimulationTab
            diagnostics={diagnostics}
            lossFractions={lossFractions}
            nSims={nSims}
            setNSims={setNSims}
            rho={rho}
            setRho={setRho}
            copulaType={copulaType}
            setCopulaType={setCopulaType}
            seed={seed}
            setSeed={setSeed}
            onReSimulate={handleManualRun}
            isExecuting={isExecuting}
            totalNotional={totalNotional}
          />
        )}

        {activeTab === 'stress_lab' && (
          <StressLabTab
            collateral={collateral}
            tranches={tranches}
          />
        )}

        {activeTab === 'portfolio' && (
          <PortfolioTab trades={trades} />
        )}

        {activeTab === 'reports' && (
          <ReportsTab
            runHash={runHash}
            diagnostics={diagnostics}
            cashValuations={cashValuations}
            totalNotional={totalNotional}
          />
        )}
      </main>

      {/* Institutional Footer */}
      <footer className="bg-[#0b0e14] border-t border-[#1e293b] px-6 py-4 text-xs font-mono text-slate-500 flex flex-col md:flex-row items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <span className="text-[#c5a059] font-bold">RhinoQuant Tranche Analytics v3.4</span>
          <span>•</span>
          <span>RhinoBank Structured Asset Financing DAC</span>
          <span>•</span>
          <span className="text-emerald-400">Strict Cash Conservation Verified</span>
        </div>
        <div className="flex items-center space-x-3 text-slate-400">
          <span>Engine: R 4.2.2</span>
          <span>•</span>
          <span>SHA256: {runHash.slice(0, 8)}</span>
          <span>•</span>
          <span>Confidential Institutional Risk Workbench</span>
        </div>
      </footer>
    </div>
  );
}
