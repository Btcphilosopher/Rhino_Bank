export interface CollateralAsset {
  asset_id: string;
  obligor_id: string;
  obligor_name: string;
  sector: string;
  region: string;
  rating: string;
  spread_bps: number;
  coupon_pct: number;
  original_face: number;
  current_balance: number;
  principal_factor: number;
  maturity_years: number;
  seniority: string;
  currency: string;
  is_semiconductor: boolean;
  fab_utilization_pct?: number;
  tapeout_stage?: string;
  dso_days?: number;
}

export interface TrancheDefinition {
  tranche_id: string;
  name: string;
  rating: string;
  original_balance: number;
  current_balance: number;
  attachment_point: number;
  detachment_point: number;
  thickness: number;
  subordination_pct: number;
  coupon_type: 'Floating' | 'Fixed' | 'Residual';
  benchmark?: string | null;
  spread_bps: number;
  fixed_coupon_pct?: number | null;
  oc_test_trigger_pct?: number | null;
  ic_test_trigger_pct?: number | null;
  payment_priority: number;
  can_defer_interest: boolean;
}

export interface WaterfallPeriodRecord {
  period: number;
  payment_date: string;
  dcf: number;
  collat_starting: number;
  collat_ending: number;
  interest_collected: number;
  principal_collected: number;
  recoveries_realized: number;
  defaults_realized: number;
  reinvested_amount: number;
  trustee_fee: number;
  senior_mgr_fee: number;
  sub_mgr_fee: number;
  hedge_net_payment: number;
  senior_oc_ratio: number;
  senior_oc_pass: boolean;
  mezz_oc_ratio: number;
  mezz_oc_pass: boolean;
  junior_oc_ratio: number;
  junior_oc_pass: boolean;
  oc_diverted_amount: number;
  reserve_balance: number;
  reserve_replenished: number;
  aaa_interest: number;
  aaa_principal: number;
  aaa_balance: number;
  aa_interest: number;
  aa_principal: number;
  aa_balance: number;
  bbb_interest: number;
  bbb_principal: number;
  bbb_balance: number;
  equity_distribution: number;
  equity_balance: number;
  cash_in_audit: number;
  cash_out_audit: number;
  cash_variance: number;
}

export interface CashTrancheValuation {
  tranche_id: string;
  name: string;
  rating: string;
  original_balance: number;
  current_balance: number;
  principal_factor: number;
  wal_years: number;
  pv_total: number;
  model_price_clean: number;
  model_price_dirty: number;
  market_observed_price?: number;
  accrued_interest_amount: number;
  discount_margin_bps?: number;
  investor_irr_pct?: number;
  irr_status: string;
  principal_shortfall: number;
  valuation_basis: string;
}

export interface SyntheticTrancheValuation {
  tranche_id: string;
  name: string;
  attachment_pct: number;
  detachment_pct: number;
  thickness_pct: number;
  notional: number;
  stated_running_bps: number;
  fair_spread_bps: number;
  pv01: number;
  pv_premium_leg: number;
  pv_protection_leg: number;
  upfront_amount: number;
  upfront_pct: number;
  expected_loss_pct: number;
}

export interface SimulationDiagnostics {
  runtime_seconds: number;
  mean_loss_pct: number;
  mean_loss_currency: number;
  mc_standard_error_pct: number;
  loss_sd_pct: number;
  q50_pct: number;
  q95_pct: number;
  q99_pct: number;
  q999_pct: number;
  var_99_amount: number;
  cvar_99_amount: number;
  batch_convergence_means: number[];
  effective_sample_tail_disclosure: string;
}

export interface TrancheDeskTrade {
  trade_id: string;
  position_id: string;
  deal_name: string;
  tranche_id: string;
  tranche_name: string;
  side: string;
  status: 'SETTLED' | 'UNSETTLED';
  trade_date: string;
  settlement_date: string;
  notional: number;
  trade_price: number;
  market_quote_price: number;
  carrying_value: number;
  unrealized_pnl: number;
  accrued_coupon: number;
  book: string;
  custodian: string;
  source: string;
}

export interface PnLAttributionItem {
  component: string;
  amount_usd: number;
  pct_of_total: number;
  accounting_status: string;
}
