import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_UNDERLYINGS, INITIAL_YIELD_CURVES, INITIAL_COUNTERPARTIES, INITIAL_COLLATERAL } from './src/data/initialMarketData';
import { INITIAL_TRADES } from './src/data/initialTrades';
import { priceInterestRateSwap, priceBlackScholes, runMonteCarloSimulation } from './src/quant/pricingEngine';
import { compileContractToCode } from './src/quant/contractCompiler';
import { Trade, AuditEvent, LedgerEntry, SurveillanceAlert } from './src/types';

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory state store for simulation state
let tradesStore: Trade[] = [...INITIAL_TRADES];
let auditStore: AuditEvent[] = [
  {
    id: 'AUD-2026-0001',
    timestamp: new Date().toISOString(),
    user: 'T. HENDERSON [HEAD QUANT]',
    role: 'QUANT_LEAD',
    action: 'INITIALIZE_MARKET_STATE',
    objectType: 'SYSTEM_STATE',
    objectId: 'RHINO-SEED-2026',
    oldState: 'UNINITIALIZED',
    newState: 'ONLINE_ACTIVE',
    signature: '0x8f1e...49ab'
  }
];

let ledgerStore: LedgerEntry[] = [
  {
    id: 'LED-001',
    timestamp: new Date().toISOString(),
    debitAccount: 'CASH_RESERVES',
    creditAccount: 'INITIAL_MARGIN_RECEIVABLE',
    amount: 12500000,
    currency: 'USD',
    referenceId: 'RQ-2026-009821',
    description: 'Initial Margin Posting - $100M 5Y IRS'
  }
];

let surveillanceAlerts: SurveillanceAlert[] = [
  {
    id: 'ALERT-001',
    timestamp: new Date().toISOString(),
    severity: 'MEDIUM',
    alertType: 'LIMIT_BREACH',
    description: 'SIMULATED ALERT: Counterparty RHINO BANK PLC DV01 utilization at 82% of $10M ceiling.',
    tradeId: 'RQ-2026-009821',
    status: 'OPEN'
  }
];

// Server-side Gemini AI Client
const getGeminiAi = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
};

// API ROUTES
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    systemClock: new Date().toISOString(),
    engines: {
      risk: 'ONLINE',
      pricing: 'ONLINE',
      margin: 'ONLINE',
      execution: 'ONLINE',
      collateral: 'ONLINE',
      contractCompiler: 'ONLINE'
    }
  });
});

app.get('/api/market', (req, res) => {
  res.json({
    underlyings: INITIAL_UNDERLYINGS,
    yieldCurves: INITIAL_YIELD_CURVES,
    counterparties: INITIAL_COUNTERPARTIES,
    collateral: INITIAL_COLLATERAL
  });
});

app.get('/api/trades', (req, res) => {
  res.json({ trades: tradesStore });
});

app.post('/api/trades', (req, res) => {
  const newTradeData: Partial<Trade> = req.body;
  const newTrade: Trade = {
    id: `RQ-2026-${Math.floor(100000 + Math.random() * 900000)}`,
    tradeDate: new Date().toISOString().split('T')[0],
    effectiveDate: newTradeData.effectiveDate || new Date().toISOString().split('T')[0],
    maturityDate: newTradeData.maturityDate || '2031-09-22',
    product: newTradeData.product || 'InterestRateSwap',
    underlyingSymbol: newTradeData.underlyingSymbol || 'SOFR',
    direction: newTradeData.direction || 'PAY_FIXED',
    notional: newTradeData.notional || 100000000,
    currency: newTradeData.currency || 'USD',
    fixedRate: newTradeData.fixedRate || 0.0412,
    floatingIndex: newTradeData.floatingIndex || 'SOFR',
    executionPrice: newTradeData.executionPrice || 0.0412,
    counterparty: newTradeData.counterparty || 'RHINO BANK PLC',
    trader: 'D. MILLER [EXECUTION DESK]',
    book: newTradeData.book || 'RHINO GLOBAL RATES',
    desk: 'RATES DERIVATIVES DESK',
    venue: 'RHINO EXECUTION VENUE',
    state: 'EXECUTED',
    mtm: 0,
    pnl: 0,
    realizedPnl: 0,
    unrealizedPnl: 0,
    initialMargin: Math.round((newTradeData.notional || 100000000) * 0.082),
    variationMargin: 0,
    greeks: {
      dv01: Math.round(((newTradeData.notional || 100000000) / 10000) * 4.1),
      pv01: Math.round((newTradeData.notional || 100000000) * 4.1),
      delta: 0.95,
      gamma: 0.02,
      vega: 12000,
      theta: -340,
      rho: 4200
    },
    ir: {
      id: `IR-${Date.now()}`,
      product: newTradeData.product || 'InterestRateSwap',
      currency: newTradeData.currency || 'USD',
      notional: newTradeData.notional || 100000000,
      fixedRate: newTradeData.fixedRate || 0.0412,
      floatingIndex: newTradeData.floatingIndex || 'SOFR',
      paymentFrequency: 'QUARTERLY',
      effectiveDate: newTradeData.effectiveDate || new Date().toISOString().split('T')[0],
      maturityDate: newTradeData.maturityDate || '2031-09-22',
      dayCount: 'ACT/360',
      settlement: 'CASH',
      collateralAsset: 'USD_CASH',
      marginType: 'BILATERAL',
      counterparty: newTradeData.counterparty || 'RHINO BANK PLC',
      book: newTradeData.book || 'RHINO GLOBAL RATES'
    },
    cashFlows: []
  };

  tradesStore.unshift(newTrade);

  // Record audit log
  auditStore.unshift({
    id: `AUD-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: 'TRADER [DESK 1]',
    role: 'TRADER',
    action: 'EXECUTE_DERIVATIVE_TRADE',
    objectType: 'TRADE',
    objectId: newTrade.id,
    oldState: 'PRE_TRADE_QUOTE',
    newState: 'EXECUTED',
    signature: `0x${Math.random().toString(16).substring(2, 10)}...`
  });

  res.json({ success: true, trade: newTrade });
});

app.post('/api/quotes', (req, res) => {
  const { product, notional, currency, direction } = req.body;
  const baseRate = 0.0412;
  const quotes = [
    { provider: 'RHINO BANK PLC', bid: baseRate, ask: baseRate + 0.0003, size: notional, quoteAgeMs: 120 },
    { provider: 'ALBION MARKETS', bid: baseRate - 0.0001, ask: baseRate + 0.0002, size: notional, quoteAgeMs: 85 },
    { provider: 'MERIDIAN CAPITAL', bid: baseRate + 0.0001, ask: baseRate + 0.0005, size: notional, quoteAgeMs: 140 },
    { provider: 'NORTH ATLANTIC SECURITIES', bid: baseRate - 0.0002, ask: baseRate + 0.0001, size: notional, quoteAgeMs: 60 }
  ];
  res.json({ quotes });
});

app.post('/api/contracts/compile', (req, res) => {
  const ir = req.body;
  const compiled = compileContractToCode(ir);
  res.json(compiled);
});

app.post('/api/simulation/run', (req, res) => {
  const { initialSpot = 1.1742, drift = 0.02, volatility = 0.15, tenorYears = 1.0, numPaths = 1000 } = req.body;
  const mcResult = runMonteCarloSimulation(initialSpot, drift, volatility, tenorYears, numPaths);
  res.json(mcResult);
});

app.get('/api/audit', (req, res) => {
  res.json({ auditLog: auditStore, ledger: ledgerStore, alerts: surveillanceAlerts });
});

// Server-Side Gemini AI Assistant Endpoint for Quant & Contract Explanation
app.post('/api/quant/explain', async (req, res) => {
  try {
    const { prompt, tradeContext } = req.body;
    const ai = getGeminiAi();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server.',
        explanation: 'Simulated Institutional Response: The $100M 5Y USD Interest Rate Swap represents a fixed-for-floating interest rate agreement. DV01 indicates $41,200 P&L impact per +1bp rate shift. Pre-trade limit check confirmed passing DV01 and counterparty exposure thresholds.'
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `You are RHINOQUANT AI, an expert quantitative financial analyst at a top-tier London/NY investment bank.
Context: ${JSON.stringify(tradeContext || {})}
User Query: ${prompt}`,
      config: {
        systemInstruction: "Provide concise, mathematically precise, institutional explanations regarding derivative pricing, Greeks, ISDA contract IR terms, and risk management. Keep responses professional and well-formatted."
      }
    });

    res.json({ explanation: response.text });
  } catch (err: any) {
    console.error('Gemini API error:', err);
    res.status(500).json({ error: err.message || 'Error processing AI explanation' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RHINOQUANT DERIVATIVES.OS Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
