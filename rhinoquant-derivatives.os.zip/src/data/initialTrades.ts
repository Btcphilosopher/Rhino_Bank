import { Trade } from '../types';
import { INITIAL_YIELD_CURVES } from './initialMarketData';
import { priceInterestRateSwap, priceBlackScholes } from '../quant/pricingEngine';

const usdCurve = INITIAL_YIELD_CURVES[0];

// Slice 1: $100M 5Y USD IRS
const irsPricing = priceInterestRateSwap(100000000, 0.0412, 5, usdCurve, true);

// Slice 2: EUR/USD Option
const fxOptionPricing = priceBlackScholes(1.1742, 1.1800, 1.0, 0.0418, 0.082, true);

export const INITIAL_TRADES: Trade[] = [
  {
    id: 'RQ-2026-009821',
    tradeDate: '2026-09-22',
    effectiveDate: '2026-09-24',
    maturityDate: '2031-09-24',
    product: 'InterestRateSwap',
    underlyingSymbol: 'SOFR',
    direction: 'PAY_FIXED',
    notional: 100000000,
    currency: 'USD',
    fixedRate: 0.0412,
    floatingIndex: 'SOFR',
    executionPrice: 0.0412,
    counterparty: 'RHINO BANK PLC',
    trader: 'T. HENDERSON [QUANT DESK 1]',
    book: 'RHINO GLOBAL RATES',
    desk: 'RATES DERIVATIVES DESK',
    venue: 'RHINO EXECUTION VENUE',
    state: 'ACTIVE',
    mtm: Math.round(irsPricing.npv),
    pnl: Math.round(irsPricing.npv),
    realizedPnl: 0,
    unrealizedPnl: Math.round(irsPricing.npv),
    initialMargin: 8210000,
    variationMargin: Math.round(irsPricing.npv),
    greeks: irsPricing.greeks,
    ir: {
      id: 'IR-2026-009821',
      product: 'InterestRateSwap',
      currency: 'USD',
      notional: 100000000,
      fixedRate: 0.0412,
      floatingIndex: 'SOFR',
      paymentFrequency: 'QUARTERLY',
      effectiveDate: '2026-09-24',
      maturityDate: '2031-09-24',
      dayCount: 'ACT/360',
      settlement: 'CASH',
      collateralAsset: 'USD_CASH',
      marginType: 'BILATERAL',
      counterparty: 'RHINO BANK PLC',
      book: 'RHINO GLOBAL RATES'
    },
    cashFlows: irsPricing.cashFlows
  },
  {
    id: 'RQ-2026-009822',
    tradeDate: '2026-09-22',
    effectiveDate: '2026-09-22',
    maturityDate: '2027-09-22',
    product: 'FXOption',
    underlyingSymbol: 'EUR/USD',
    direction: 'BUY',
    notional: 100000000,
    currency: 'USD',
    strike: 1.1800,
    executionPrice: fxOptionPricing.price,
    counterparty: 'NORTH ATLANTIC SECURITIES',
    trader: 'E. CHEN [FX QUANT DESK]',
    book: 'RHINO FX OPTIONS',
    desk: 'FX DERIVATIVES DESK',
    venue: 'BILATERAL OTC',
    state: 'ACTIVE',
    mtm: Math.round(fxOptionPricing.price * 100000000),
    pnl: Math.round((fxOptionPricing.price - 0.024) * 100000000),
    realizedPnl: 0,
    unrealizedPnl: Math.round((fxOptionPricing.price - 0.024) * 100000000),
    initialMargin: 4200000,
    variationMargin: Math.round(fxOptionPricing.price * 100000000),
    greeks: fxOptionPricing.greeks,
    ir: {
      id: 'IR-2026-009822',
      product: 'FXOption',
      currency: 'USD',
      notional: 100000000,
      strike: 1.1800,
      optionType: 'CALL',
      exerciseStyle: 'EUROPEAN',
      paymentFrequency: 'ANNUAL',
      effectiveDate: '2026-09-22',
      maturityDate: '2027-09-22',
      dayCount: 'ACT/365',
      settlement: 'CASH',
      collateralAsset: 'USD_CASH',
      marginType: 'BILATERAL',
      counterparty: 'NORTH ATLANTIC SECURITIES',
      book: 'RHINO FX OPTIONS'
    },
    cashFlows: [
      {
        id: 'CF-FX-1',
        paymentDate: '2027-09-22',
        legAAmount: 100000000,
        legBAmount: 118000000,
        netAmount: Math.round(fxOptionPricing.price * 100000000),
        currency: 'USD',
        status: 'PROJECTED',
        description: 'Option Settlement Payoff'
      }
    ]
  },
  {
    id: 'RQ-2026-009823',
    tradeDate: '2026-09-21',
    effectiveDate: '2026-09-21',
    maturityDate: '2026-12-18',
    product: 'EquityFuture',
    underlyingSymbol: 'SPX',
    direction: 'LONG',
    notional: 200000000,
    currency: 'USD',
    executionPrice: 6482.12,
    counterparty: 'MERIDIAN CAPITAL PARTNERS',
    trader: 'M. VANCE [EQUITY DESK]',
    book: 'RHINO EQUITY DERIVATIVES',
    desk: 'EQUITY FUTURES DESK',
    venue: 'CME SYNTHETIC',
    state: 'ACTIVE',
    mtm: 1840000,
    pnl: 1840000,
    realizedPnl: 0,
    unrealizedPnl: 1840000,
    initialMargin: 12000000,
    variationMargin: 1840000,
    greeks: {
      dv01: 0,
      pv01: 0,
      delta: 0.98,
      gamma: 0.002,
      vega: 0,
      theta: -420,
      rho: 0
    },
    ir: {
      id: 'IR-2026-009823',
      product: 'EquityFuture',
      currency: 'USD',
      notional: 200000000,
      paymentFrequency: 'QUARTERLY',
      effectiveDate: '2026-09-21',
      maturityDate: '2026-12-18',
      dayCount: 'ACT/360',
      settlement: 'CASH',
      collateralAsset: 'USD_CASH',
      marginType: 'CLEARED',
      counterparty: 'MERIDIAN CAPITAL PARTNERS',
      book: 'RHINO EQUITY DERIVATIVES'
    },
    cashFlows: []
  }
];
