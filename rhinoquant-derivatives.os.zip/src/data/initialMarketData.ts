import { UnderlyingAsset, YieldCurve, Counterparty, CollateralAsset } from '../types';

export const INITIAL_UNDERLYINGS: UnderlyingAsset[] = [
  // Rates
  { id: 'u-sofr', symbol: 'SOFR', name: 'USD Secured Overnight Financing Rate', assetClass: 'RATES', spot: 4.18, bid: 4.175, ask: 4.185, change24h: -0.02, volatility: 8.4, volume: 1420000, openInterest: 8900000, currency: 'USD' },
  { id: 'u-sonia', symbol: 'SONIA', name: 'GBP Sterling Overnight Index Average', assetClass: 'RATES', spot: 4.95, bid: 4.945, ask: 4.955, change24h: 0.01, volatility: 9.1, volume: 820000, openInterest: 4500000, currency: 'GBP' },
  { id: 'u-estr', symbol: '€STR', name: 'EUR Euro Short-Term Rate', assetClass: 'RATES', spot: 3.42, bid: 3.415, ask: 3.425, change24h: -0.01, volatility: 7.2, volume: 1100000, openInterest: 6700000, currency: 'EUR' },
  { id: 'u-tona', symbol: 'TONA', name: 'JPY Tokyo Overnight Average Rate', assetClass: 'RATES', spot: 0.25, bid: 0.245, ask: 0.255, change24h: 0.00, volatility: 12.0, volume: 950000, openInterest: 5200000, currency: 'JPY' },
  { id: 'u-saron', symbol: 'SARON', name: 'CHF Swiss Average Rate Overnight', assetClass: 'RATES', spot: 1.20, bid: 1.195, ask: 1.205, change24h: 0.00, volatility: 6.8, volume: 310000, openInterest: 1800000, currency: 'CHF' },

  // FX
  { id: 'u-eurusd', symbol: 'EUR/USD', name: 'Euro / US Dollar', assetClass: 'FX', spot: 1.1742, bid: 1.1741, ask: 1.1743, change24h: 0.0018, volatility: 7.8, volume: 24500000, openInterest: 14000000, currency: 'USD' },
  { id: 'u-gbpusd', symbol: 'GBP/USD', name: 'British Pound / US Dollar', assetClass: 'FX', spot: 1.3125, bid: 1.3123, ask: 1.3127, change24h: -0.0021, volatility: 8.6, volume: 18200000, openInterest: 9800000, currency: 'USD' },
  { id: 'u-usdjpy', symbol: 'USD/JPY', name: 'US Dollar / Japanese Yen', assetClass: 'FX', spot: 147.82, bid: 147.80, ask: 147.84, change24h: 0.42, volatility: 10.4, volume: 28900000, openInterest: 16500000, currency: 'JPY' },
  { id: 'u-usdchf', symbol: 'USD/CHF', name: 'US Dollar / Swiss Franc', assetClass: 'FX', spot: 0.8512, bid: 0.8510, ask: 0.8514, change24h: -0.0010, volatility: 6.9, volume: 9400000, openInterest: 4200000, currency: 'CHF' },
  { id: 'u-audusd', symbol: 'AUD/USD', name: 'Australian Dollar / US Dollar', assetClass: 'FX', spot: 0.6784, bid: 0.6782, ask: 0.6786, change24h: 0.0012, volatility: 9.8, volume: 12100000, openInterest: 6100000, currency: 'USD' },

  // Equity
  { id: 'u-spx', symbol: 'SPX', name: 'S&P 500 Index', assetClass: 'EQUITY', spot: 6482.12, bid: 6481.80, ask: 6482.44, change24h: 18.40, volatility: 18.42, volume: 48900000, openInterest: 32000000, currency: 'USD' },
  { id: 'u-ndx', symbol: 'NDX', name: 'Nasdaq 100 Index', assetClass: 'EQUITY', spot: 21240.85, bid: 21239.50, ask: 21242.20, change24h: 112.30, volatility: 21.60, volume: 39500000, openInterest: 24500000, currency: 'USD' },
  { id: 'u-ftse', symbol: 'FTSE 100', name: 'FTSE 100 Index', assetClass: 'EQUITY', spot: 8420.50, bid: 8419.80, ask: 8421.20, change24h: -12.40, volatility: 14.80, volume: 18400000, openInterest: 11200000, currency: 'GBP' },
  { id: 'u-dax', symbol: 'DAX', name: 'DAX Performance Index', assetClass: 'EQUITY', spot: 18950.30, bid: 18948.90, ask: 18951.70, change24h: 42.10, volatility: 16.20, volume: 21000000, openInterest: 13800000, currency: 'EUR' },

  // Credit
  { id: 'u-cdxig', symbol: 'CDX IG', name: 'North American Investment Grade CDS Index', assetClass: 'CREDIT', spot: 52.4, bid: 52.2, ask: 52.6, change24h: -0.80, volatility: 15.2, volume: 5400000, openInterest: 8900000, currency: 'USD' },
  { id: 'u-cdxhy', symbol: 'CDX HY', name: 'North American High Yield CDS Index', assetClass: 'CREDIT', spot: 328.5, bid: 327.5, ask: 329.5, change24h: -2.10, volatility: 22.4, volume: 4100000, openInterest: 6200000, currency: 'USD' },

  // Commodities
  { id: 'u-brent', symbol: 'BRENT', name: 'Brent Crude Oil', assetClass: 'COMMODITIES', spot: 74.85, bid: 74.82, ask: 74.88, change24h: -0.45, volatility: 24.8, volume: 18900000, openInterest: 12400000, currency: 'USD' },
  { id: 'u-gold', symbol: 'GOLD', name: 'Spot Gold / USD', assetClass: 'COMMODITIES', spot: 2654.20, bid: 2653.80, ask: 2654.60, change24h: 14.50, volatility: 16.4, volume: 22100000, openInterest: 18900000, currency: 'USD' }
];

export const INITIAL_YIELD_CURVES: YieldCurve[] = [
  {
    id: 'yc-usd-sofr',
    currency: 'USD',
    benchmarkIndex: 'SOFR',
    points: [
      { tenor: '1M', years: 1/12, zeroRate: 4.18, discountFactor: 0.9965, forwardRate: 4.18, dv01Per100M: 830 },
      { tenor: '3M', years: 0.25, zeroRate: 4.15, discountFactor: 0.9897, forwardRate: 4.14, dv01Per100M: 2470 },
      { tenor: '6M', years: 0.50, zeroRate: 4.10, discountFactor: 0.9797, forwardRate: 4.05, dv01Per100M: 4900 },
      { tenor: '1Y', years: 1.0, zeroRate: 4.02, discountFactor: 0.9606, forwardRate: 3.94, dv01Per100M: 9600 },
      { tenor: '2Y', years: 2.0, zeroRate: 3.92, discountFactor: 0.9246, forwardRate: 3.82, dv01Per100M: 18500 },
      { tenor: '5Y', years: 5.0, zeroRate: 4.02, discountFactor: 0.8179, forwardRate: 4.18, dv01Per100M: 40900 },
      { tenor: '10Y', years: 10.0, zeroRate: 4.18, discountFactor: 0.6583, forwardRate: 4.34, dv01Per100M: 65800 },
      { tenor: '30Y', years: 30.0, zeroRate: 4.35, discountFactor: 0.2712, forwardRate: 4.45, dv01Per100M: 81300 }
    ]
  },
  {
    id: 'yc-eur-estr',
    currency: 'EUR',
    benchmarkIndex: '€STR',
    points: [
      { tenor: '1M', years: 1/12, zeroRate: 3.42, discountFactor: 0.9971, forwardRate: 3.42, dv01Per100M: 831 },
      { tenor: '1Y', years: 1.0, zeroRate: 3.25, discountFactor: 0.9680, forwardRate: 3.08, dv01Per100M: 9680 },
      { tenor: '5Y', years: 5.0, zeroRate: 2.95, discountFactor: 0.8628, forwardRate: 2.87, dv01Per100M: 43140 },
      { tenor: '10Y', years: 10.0, zeroRate: 3.12, discountFactor: 0.7320, forwardRate: 3.29, dv01Per100M: 73200 }
    ]
  }
];

export const INITIAL_COUNTERPARTIES: Counterparty[] = [
  {
    id: 'cp-rhino-bank',
    name: 'RHINO BANK PLC',
    legalEntity: 'RHINO BANK PLC (UK LEI: 213800RHINO111999)',
    rating: 'AA-',
    creditLimit: 500000000,
    currentExposure: 18420000,
    potentialFutureExposure: 42100000,
    initialMarginPosted: 12500000,
    variationMarginPosted: 18420000,
    nettingSetId: 'NET-RHINO-01',
    csaType: 'ISDA 2018 IM CSA'
  },
  {
    id: 'cp-north-atlantic',
    name: 'NORTH ATLANTIC SECURITIES',
    legalEntity: 'NORTH ATLANTIC SECURITIES LLC',
    rating: 'A+',
    creditLimit: 250000000,
    currentExposure: 9210000,
    potentialFutureExposure: 21000000,
    initialMarginPosted: 6500000,
    variationMarginPosted: 9210000,
    nettingSetId: 'NET-NAS-02',
    csaType: 'ISDA 2016 VM CSA'
  },
  {
    id: 'cp-meridian',
    name: 'MERIDIAN CAPITAL PARTNERS',
    legalEntity: 'MERIDIAN CAPITAL INTERNATIONAL LTD',
    rating: 'A',
    creditLimit: 150000000,
    currentExposure: 14800000,
    potentialFutureExposure: 32000000,
    initialMarginPosted: 8200000,
    variationMarginPosted: 14800000,
    nettingSetId: 'NET-MERIDIAN-03',
    csaType: 'ISDA 2018 IM CSA'
  },
  {
    id: 'cp-albion',
    name: 'ALBION MARKETS',
    legalEntity: 'ALBION MARKETS LIMITED',
    rating: 'A-',
    creditLimit: 200000000,
    currentExposure: 4500000,
    potentialFutureExposure: 12000000,
    initialMarginPosted: 4100000,
    variationMarginPosted: 4500000,
    nettingSetId: 'NET-ALBION-04',
    csaType: 'ISDA 2016 VM CSA'
  }
];

export const INITIAL_COLLATERAL: CollateralAsset[] = [
  { id: 'col-usd-cash', assetName: 'USD CASH', type: 'CASH', currency: 'USD', marketValue: 50000000, haircut: 0.0, eligibleValue: 50000000, pledged: 28420000, available: 21580000, counterparty: 'RHINO BANK PLC' },
  { id: 'col-us-treasuries', assetName: 'US TREASURY 4.125% 2031', type: 'GOVT_BOND', currency: 'USD', marketValue: 35000000, haircut: 2.0, eligibleValue: 34300000, pledged: 15000000, available: 19300000, counterparty: 'NORTH ATLANTIC SECURITIES' },
  { id: 'col-gbp-gilts', assetName: 'UK GILT 3.75% 2030', type: 'GOVT_BOND', currency: 'GBP', marketValue: 20000000, haircut: 3.0, eligibleValue: 19400000, pledged: 10000000, available: 9400000, counterparty: 'ALBION MARKETS' },
  { id: 'col-german-bunds', assetName: 'GERMAN BUND 2.50% 2032', type: 'GOVT_BOND', currency: 'EUR', marketValue: 15000000, haircut: 2.5, eligibleValue: 14625000, pledged: 8000000, available: 6625000, counterparty: 'MERIDIAN CAPITAL PARTNERS' }
];
