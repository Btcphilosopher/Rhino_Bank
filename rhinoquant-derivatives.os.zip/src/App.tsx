import React, { useState, useEffect } from 'react';
import { GlobalHeader } from './components/GlobalHeader';
import { PrimaryNav, MainTab, SecondaryTab } from './components/PrimaryNav';
import { CommandPalette } from './components/CommandPalette';
import { MarketCentreView } from './components/MarketCentreView';
import { TradeTicketView } from './components/TradeTicketView';
import { TradeBlotterView } from './components/TradeBlotterView';
import { PositionBookView } from './components/PositionBookView';
import { PricingEngineView } from './components/PricingEngineView';
import { RiskCentreView } from './components/RiskCentreView';
import { MarginCollateralView } from './components/MarginCollateralView';
import { LifecycleEngineView } from './components/LifecycleEngineView';
import { ContractsParityView } from './components/ContractsParityView';
import { QuantLabView } from './components/QuantLabView';
import { SimulationView } from './components/SimulationView';
import { SurveillanceView } from './components/SurveillanceView';
import { ClearingView } from './components/ClearingView';
import { ReportingLedgerView } from './components/ReportingLedgerView';
import { AuditView } from './components/AuditView';
import { QuantAiAssistantModal } from './components/QuantAiAssistantModal';
import { TradeDetailModal } from './components/TradeDetailModal';

import { INITIAL_UNDERLYINGS, INITIAL_YIELD_CURVES, INITIAL_COUNTERPARTIES, INITIAL_COLLATERAL } from './data/initialMarketData';
import { INITIAL_TRADES } from './data/initialTrades';
import { Trade, UnderlyingAsset, Counterparty, CollateralAsset, AuditEvent, LedgerEntry, SurveillanceAlert } from './types';

export function App() {
  const [activeTab, setActiveTab] = useState<MainTab>('MARKETS');
  const [activeSecondaryTab, setActiveSecondaryTab] = useState<SecondaryTab | null>(null);
  
  const [terminalMode, setTerminalMode] = useState<boolean>(true);
  const [isCmdOpen, setIsCmdOpen] = useState<boolean>(false);
  const [isAiOpen, setIsAiOpen] = useState<boolean>(false);
  const [selectedTradeForDetail, setSelectedTradeForDetail] = useState<Trade | null>(null);
  const [selectedAssetForTrade, setSelectedAssetForTrade] = useState<UnderlyingAsset | null>(null);

  // Core system state
  const [underlyings, setUnderlyings] = useState<UnderlyingAsset[]>(INITIAL_UNDERLYINGS);
  const [yieldCurves, setYieldCurves] = useState(INITIAL_YIELD_CURVES);
  const [counterparties, setCounterparties] = useState<Counterparty[]>(INITIAL_COUNTERPARTIES);
  const [collateral, setCollateral] = useState<CollateralAsset[]>(INITIAL_COLLATERAL);
  const [trades, setTrades] = useState<Trade[]>(INITIAL_TRADES);

  const [auditLog, setAuditLog] = useState<AuditEvent[]>([
    {
      id: 'AUD-2026-0001',
      timestamp: new Date().toISOString(),
      user: 'SYSTEM [INIT]',
      role: 'QUANT_DESK_HEAD',
      action: 'SYSTEM_BOOTSTRAP',
      objectType: 'SYSTEM_STATE',
      objectId: 'RHINO-SEED-2026',
      signature: '0x9a2e...41bf'
    }
  ]);

  const [ledger, setLedger] = useState<LedgerEntry[]>([
    {
      id: 'LED-001',
      timestamp: new Date().toISOString(),
      debitAccount: 'CASH_RESERVES',
      creditAccount: 'INITIAL_MARGIN_RECEIVABLE',
      amount: 12500000,
      currency: 'USD',
      referenceId: 'RQ-2026-009821',
      description: 'Initial Margin Posting - $100M 5Y IRS'
    }
  ]);

  const [alerts, setAlerts] = useState<SurveillanceAlert[]>([
    {
      id: 'ALERT-001',
      timestamp: new Date().toISOString(),
      severity: 'MEDIUM',
      alertType: 'LIMIT_BREACH',
      description: 'SIMULATED ALERT: Counterparty RHINO BANK PLC DV01 utilization at 82% of $10M ceiling.',
      tradeId: 'RQ-2026-009821',
      status: 'OPEN'
    }
  ]);

  // Real-time Clock Simulation
  const [clock, setClock] = useState<Date>(new Date());
  useEffect(() => {
    const timer = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch API State on mount
  useEffect(() => {
    fetch('/api/market')
      .then(res => res.json())
      .then(data => {
        if (data.underlyings) setUnderlyings(data.underlyings);
        if (data.yieldCurves) setYieldCurves(data.yieldCurves);
        if (data.counterparties) setCounterparties(data.counterparties);
        if (data.collateral) setCollateral(data.collateral);
      })
      .catch(() => {});

    fetch('/api/trades')
      .then(res => res.json())
      .then(data => {
        if (data.trades) setTrades(data.trades);
      })
      .catch(() => {});

    fetch('/api/audit')
      .then(res => res.json())
      .then(data => {
        if (data.auditLog) setAuditLog(data.auditLog);
        if (data.ledger) setLedger(data.ledger);
        if (data.alerts) setAlerts(data.alerts);
      })
      .catch(() => {});
  }, []);

  // Execute trade callback
  const handleExecuteTrade = (tradeData: any) => {
    fetch('/api/trades', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(tradeData)
    })
      .then(res => res.json())
      .then(data => {
        if (data.trade) {
          setTrades(prev => [data.trade, ...prev]);
          setActiveTab('BOOK'); // Navigate to Position Book
        }
      })
      .catch(() => {
        // Fallback local execution
        const newTrade: Trade = {
          id: `RQ-2026-${Math.floor(100000 + Math.random() * 900000)}`,
          tradeDate: new Date().toISOString().split('T')[0],
          effectiveDate: tradeData.effectiveDate || new Date().toISOString().split('T')[0],
          maturityDate: tradeData.maturityDate || '2031-09-22',
          product: tradeData.product || 'InterestRateSwap',
          underlyingSymbol: tradeData.underlyingSymbol || 'SOFR',
          direction: tradeData.direction || 'PAY_FIXED',
          notional: tradeData.notional || 100000000,
          currency: tradeData.currency || 'USD',
          fixedRate: tradeData.fixedRate || 0.0412,
          floatingIndex: tradeData.floatingIndex || 'SOFR',
          executionPrice: tradeData.executionPrice || 0.0412,
          counterparty: tradeData.counterparty || 'RHINO BANK PLC',
          trader: 'T. HENDERSON [QUANT DESK 1]',
          book: 'RHINO GLOBAL RATES',
          desk: 'RATES DERIVATIVES DESK',
          venue: 'RHINO EXECUTION VENUE',
          state: 'EXECUTED',
          mtm: 0,
          pnl: 0,
          realizedPnl: 0,
          unrealizedPnl: 0,
          initialMargin: Math.round((tradeData.notional || 100000000) * 0.082),
          variationMargin: 0,
          greeks: {
            dv01: Math.round(((tradeData.notional || 100000000) / 10000) * 4.1),
            pv01: Math.round((tradeData.notional || 100000000) * 4.1),
            delta: 0.95,
            gamma: 0.02,
            vega: 12000,
            theta: -340,
            rho: 4200
          },
          ir: {
            id: `IR-${Date.now()}`,
            product: tradeData.product || 'InterestRateSwap',
            currency: tradeData.currency || 'USD',
            notional: tradeData.notional || 100000000,
            fixedRate: tradeData.fixedRate || 0.0412,
            floatingIndex: tradeData.floatingIndex || 'SOFR',
            paymentFrequency: 'QUARTERLY',
            effectiveDate: tradeData.effectiveDate || new Date().toISOString().split('T')[0],
            maturityDate: tradeData.maturityDate || '2031-09-22',
            dayCount: 'ACT/360',
            settlement: 'CASH',
            collateralAsset: 'USD_CASH',
            marginType: 'BILATERAL',
            counterparty: tradeData.counterparty || 'RHINO BANK PLC',
            book: 'RHINO GLOBAL RATES'
          },
          cashFlows: []
        };
        setTrades(prev => [newTrade, ...prev]);
        setActiveTab('BOOK');
      });
  };

  const simulatedTimeStr = clock.toTimeString().split(' ')[0] + ' UTC';
  const simulatedDateStr = '2026-09-22';

  return (
    <div className={`min-h-screen bg-[#080a0e] text-[#e6edf3] font-mono flex flex-col antialiased ${terminalMode ? 'terminal-density' : ''}`}>
      {/* Global Terminal Header */}
      <GlobalHeader
        onOpenCommandPalette={() => setIsCmdOpen(true)}
        onOpenAiAssistant={() => setIsAiOpen(true)}
        terminalMode={terminalMode}
        setTerminalMode={setTerminalMode}
        simulatedTime={simulatedTimeStr}
        simulatedDate={simulatedDateStr}
      />

      {/* Primary & Secondary Navigation */}
      <PrimaryNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeSecondaryTab={activeSecondaryTab}
        setActiveSecondaryTab={setActiveSecondaryTab}
      />

      {/* Main Content Workspace */}
      <main className="flex-1 p-3 overflow-y-auto">
        {activeTab === 'MARKETS' && (
          <MarketCentreView
            underlyings={underlyings}
            yieldCurves={yieldCurves}
            onSelectForTrade={(asset) => {
              setSelectedAssetForTrade(asset);
              setActiveTab('TRADE');
            }}
          />
        )}

        {activeTab === 'TRADE' && (
          <TradeTicketView
            counterparties={counterparties}
            onExecuteTrade={handleExecuteTrade}
            selectedAssetForTrade={selectedAssetForTrade}
          />
        )}

        {(activeTab === 'BOOK' || activeSecondaryTab === 'ACCOUNTS') && (
          <PositionBookView trades={trades} />
        )}

        {activeTab === 'PRICING' && (
          <PricingEngineView />
        )}

        {activeTab === 'RISK' && (
          <RiskCentreView trades={trades} />
        )}

        {activeTab === 'MARGIN' && (
          <MarginCollateralView collateral={collateral} />
        )}

        {activeTab === 'COLLATERAL' && (
          <MarginCollateralView collateral={collateral} />
        )}

        {activeTab === 'LIFECYCLE' && (
          <LifecycleEngineView trades={trades} />
        )}

        {activeTab === 'EXECUTION' && (
          <TradeBlotterView
            trades={trades}
            onSelectTradeDetail={(t) => setSelectedTradeForDetail(t)}
          />
        )}

        {activeTab === 'CONTRACTS' && (
          <ContractsParityView tradeIr={trades[0]?.ir} />
        )}

        {activeTab === 'QUANTS' && (
          <QuantLabView />
        )}

        {activeTab === 'SIMULATION' && (
          <SimulationView trades={trades} />
        )}

        {activeTab === 'SURVEILLANCE' && (
          <SurveillanceView alerts={alerts} />
        )}

        {activeTab === 'CLEARING' && (
          <ClearingView />
        )}

        {activeTab === 'REPORTING' && (
          <ReportingLedgerView ledger={ledger} />
        )}

        {activeTab === 'AUDIT' && (
          <AuditView auditLog={auditLog} />
        )}

        {/* Secondary Navigation Fallback Views */}
        {activeSecondaryTab === 'PRODUCTS' && <MarketCentreView underlyings={underlyings} yieldCurves={yieldCurves} onSelectForTrade={() => setActiveTab('TRADE')} />}
        {activeSecondaryTab === 'CURVES' && <MarketCentreView underlyings={underlyings} yieldCurves={yieldCurves} onSelectForTrade={() => setActiveTab('TRADE')} />}
        {activeSecondaryTab === 'VOLATILITY' && <QuantLabView />}
        {activeSecondaryTab === 'COUNTERPARTIES' && <RiskCentreView trades={trades} />}
        {activeSecondaryTab === 'VENUES' && <TradeBlotterView trades={trades} onSelectTradeDetail={(t) => setSelectedTradeForDetail(t)} />}
        {activeSecondaryTab === 'MODELS' && <PricingEngineView />}
        {activeSecondaryTab === 'SCENARIOS' && <SimulationView trades={trades} />}
      </main>

      {/* Command Palette Modal (Ctrl+K) */}
      <CommandPalette
        isOpen={isCmdOpen}
        onClose={() => setIsCmdOpen(false)}
        onSelectTab={(tab) => setActiveTab(tab)}
        onExecuteSlice1={() => {
          setActiveTab('TRADE');
        }}
        onExecuteSlice2={() => {
          setActiveTab('TRADE');
        }}
      />

      {/* Quant AI Assistant Modal */}
      <QuantAiAssistantModal
        isOpen={isAiOpen}
        onClose={() => setIsAiOpen(false)}
        tradeContext={trades[0]}
      />

      {/* Contract IR Inspector Modal */}
      <TradeDetailModal
        trade={selectedTradeForDetail}
        onClose={() => setSelectedTradeForDetail(null)}
      />
    </div>
  );
}

export default App;
