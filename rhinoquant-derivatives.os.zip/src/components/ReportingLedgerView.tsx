import React from 'react';
import { LedgerEntry } from '../types';
import { BookOpen, CheckCircle } from 'lucide-react';

interface ReportingLedgerViewProps {
  ledger: LedgerEntry[];
}

export const ReportingLedgerView: React.FC<ReportingLedgerViewProps> = ({ ledger }) => {
  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <BookOpen className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">IMMUTABLE GENERAL LEDGER & RECONCILIATION ENGINE</h2>
        </div>
        <div className="text-[10px] text-[#238636] bg-[#238636]/10 px-2 py-0.5 border border-[#238636]/30">
          DOUBLE-ENTRY BALANCED (ZERO BREAKS)
        </div>
      </div>

      <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
        <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
          <span>GENERAL LEDGER JOURNAL ENTRIES</span>
          <span className="text-[#8b949e] text-[10px]">{ledger.length} BALANCED ENTRIES</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px] whitespace-nowrap">
            <thead>
              <tr className="text-[#8b949e] border-b border-[#1c2436] bg-[#0b0e14]">
                <th className="py-2 px-2.5 font-bold">ENTRY ID</th>
                <th className="py-2 px-2.5 font-bold">TIMESTAMP</th>
                <th className="py-2 px-2.5 font-bold">DEBIT ACCOUNT</th>
                <th className="py-2 px-2.5 font-bold">CREDIT ACCOUNT</th>
                <th className="py-2 px-2.5 font-bold text-right">AMOUNT ($)</th>
                <th className="py-2 px-2.5 font-bold">REFERENCE REF</th>
                <th className="py-2 px-2.5 font-bold">DESCRIPTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#151c2a]">
              {ledger.map((e) => (
                <tr key={e.id} className="hover:bg-[#161e2e]">
                  <td className="py-2 px-2.5 font-bold text-[#38bdf8]">{e.id}</td>
                  <td className="py-2 px-2.5 text-[#8b949e]">{e.timestamp}</td>
                  <td className="py-2 px-2.5 text-[#da3633] font-semibold">{e.debitAccount}</td>
                  <td className="py-2 px-2.5 text-[#238636] font-semibold">{e.creditAccount}</td>
                  <td className="py-2 px-2.5 text-right font-bold text-[#e6edf3] num">${e.amount.toLocaleString()}</td>
                  <td className="py-2 px-2.5 text-[#38bdf8]">{e.referenceId}</td>
                  <td className="py-2 px-2.5 text-[#8b949e]">{e.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
