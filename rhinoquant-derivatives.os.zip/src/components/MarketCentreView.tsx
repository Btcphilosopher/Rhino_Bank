import React, { useState } from 'react';
import { UnderlyingAsset, YieldCurve } from '../types';
import { TrendingUp, TrendingDown, Layers, BarChart2 } from 'lucide-react';

interface MarketCentreViewProps {
  underlyings: UnderlyingAsset[];
  yieldCurves: YieldCurve[];
  onSelectForTrade: (asset: UnderlyingAsset) => void;
}

export const MarketCentreView: React.FC<MarketCentreViewProps> = ({
  underlyings,
  yieldCurves,
  onSelectForTrade
}) => {
  const [selectedAssetClass, setSelectedAssetClass] = useState<string>('ALL');
  const [activeCurveIndex, setActiveCurveIndex] = useState<number>(0);

  const filteredAssets = selectedAssetClass === 'ALL'
    ? underlyings
    : underlyings.filter(a => a.assetClass === selectedAssetClass);

  const activeCurve = yieldCurves[activeCurveIndex] || yieldCurves[0];

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Top Filter Bar */}
      <div className="flex items-center justify-between bg-[#0f141d] p-2 border border-[#1c2436]">
        <div className="flex items-center space-x-1">
          <span className="text-[#8b949e] font-bold mr-2 uppercase text-[11px]">ASSET CLASS:</span>
          {['ALL', 'RATES', 'FX', 'EQUITY', 'CREDIT', 'COMMODITIES'].map((ac) => (
            <button
              key={ac}
              onClick={() => setSelectedAssetClass(ac)}
              className={`px-2.5 py-1 text-[11px] font-bold cursor-pointer transition-colors ${
                selectedAssetClass === ac
                  ? 'bg-[#1e2a3f] text-[#38bdf8] border border-[#2d3f5e]'
                  : 'text-[#8b949e] hover:text-[#e6edf3] bg-[#111622] border border-transparent'
              }`}
            >
              {ac}
            </button>
          ))}
        </div>
        <div className="text-[10px] text-[#38bdf8] bg-[#38bdf8]/10 px-2 py-0.5 border border-[#38bdf8]/20">
          SYNTHETIC REAL-TIME FEED (RHINO-SEED-2026)
        </div>
      </div>

      {/* Main Grid: Market Ticker Table + Yield Curve & Volatility Profile */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Ticker Table (Spans 2 cols on large screens) */}
        <div className="lg:col-span-2 bg-[#0f141d] border border-[#1c2436] p-3 space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-[#1c2436]">
            <h3 className="font-bold text-[#e6edf3] flex items-center space-x-2">
              <BarChart2 className="w-4 h-4 text-[#38bdf8]" />
              <span>SYNTHETIC DERIVATIVES MARKET CENTRE</span>
            </h3>
            <span className="text-[10px] text-[#8b949e]">{filteredAssets.length} INSTRUMENTS LIVE</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11px]">
              <thead>
                <tr className="text-[#8b949e] border-b border-[#1a2232] bg-[#0b0e14]">
                  <th className="py-1.5 px-2 font-bold">SYMBOL</th>
                  <th className="py-1.5 px-2 font-bold">NAME</th>
                  <th className="py-1.5 px-2 font-bold text-right">SPOT / LAST</th>
                  <th className="py-1.5 px-2 font-bold text-right">BID</th>
                  <th className="py-1.5 px-2 font-bold text-right">ASK</th>
                  <th className="py-1.5 px-2 font-bold text-right">24H CHG</th>
                  <th className="py-1.5 px-2 font-bold text-right">IMP VOL</th>
                  <th className="py-1.5 px-2 font-bold text-center">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#151c2a]">
                {filteredAssets.map((asset) => {
                  const isPositive = asset.change24h >= 0;
                  return (
                    <tr key={asset.id} className="hover:bg-[#161e2e] transition-colors">
                      <td className="py-2 px-2 font-bold text-[#38bdf8]">{asset.symbol}</td>
                      <td className="py-2 px-2 text-[#8b949e] text-[10px] truncate max-w-[160px]">{asset.name}</td>
                      <td className="py-2 px-2 text-right font-bold text-[#e6edf3] num">{asset.spot.toLocaleString()}</td>
                      <td className="py-2 px-2 text-right text-[#8b949e] num">{asset.bid.toLocaleString()}</td>
                      <td className="py-2 px-2 text-right text-[#8b949e] num">{asset.ask.toLocaleString()}</td>
                      <td className={`py-2 px-2 text-right font-bold num ${isPositive ? 'text-[#238636]' : 'text-[#da3633]'}`}>
                        {isPositive ? '+' : ''}{asset.change24h}
                      </td>
                      <td className="py-2 px-2 text-right text-[#d29922] font-semibold num">{asset.volatility.toFixed(1)}%</td>
                      <td className="py-2 px-2 text-center">
                        <button
                          onClick={() => onSelectForTrade(asset)}
                          className="px-2 py-0.5 bg-[#1b263b] hover:bg-[#273857] text-[#38bdf8] border border-[#2c3f63] font-bold text-[10px] cursor-pointer"
                        >
                          TRADE TICKET
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Yield Curve & Volatility Profile */}
        <div className="space-y-4">
          {/* Yield Curve Visualizer */}
          <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#1c2436]">
              <h4 className="font-bold text-[#e6edf3] flex items-center space-x-1.5">
                <Layers className="w-3.5 h-3.5 text-[#38bdf8]" />
                <span>BENCHMARK YIELD CURVE</span>
              </h4>
              <div className="flex space-x-1 text-[10px]">
                {yieldCurves.map((yc, idx) => (
                  <button
                    key={yc.id}
                    onClick={() => setActiveCurveIndex(idx)}
                    className={`px-1.5 py-0.5 font-bold cursor-pointer ${
                      activeCurveIndex === idx ? 'bg-[#38bdf8] text-[#0a0d12]' : 'bg-[#141b27] text-[#8b949e]'
                    }`}
                  >
                    {yc.currency} {yc.benchmarkIndex}
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated Curve Graph visualization */}
            <div className="bg-[#0b0e14] p-3 border border-[#182030] space-y-2">
              <div className="flex justify-between text-[10px] text-[#8b949e]">
                <span>CURVE: {activeCurve.currency} {activeCurve.benchmarkIndex}</span>
                <span>PAR RATE AVG: 4.12%</span>
              </div>

              {/* Bar visualization of zero rates across tenors */}
              <div className="h-28 flex items-end justify-between gap-1 pt-4 border-b border-[#1e2738] px-2">
                {activeCurve.points.map((pt) => {
                  const heightPercent = Math.min(100, (pt.zeroRate / 6.0) * 100);
                  return (
                    <div key={pt.tenor} className="flex-1 flex flex-col items-center group relative">
                      <div className="text-[9px] text-[#38bdf8] font-bold mb-1 opacity-0 group-hover:opacity-100 transition-opacity absolute -top-4">
                        {pt.zeroRate}%
                      </div>
                      <div
                        style={{ height: `${heightPercent}%` }}
                        className="w-full bg-[#2a3a5c] group-hover:bg-[#38bdf8] border-t-2 border-[#38bdf8] transition-all"
                      ></div>
                      <span className="text-[9px] text-[#8b949e] mt-1">{pt.tenor}</span>
                    </div>
                  );
                })}
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px] pt-1">
                <div className="bg-[#121824] p-1.5 border border-[#1d273a]">
                  <span className="text-[#8b949e]">1Y ZERO:</span>
                  <span className="float-right text-[#e6edf3] font-bold">
                    {activeCurve.points.find(p => p.tenor === '1Y')?.zeroRate || 4.02}%
                  </span>
                </div>
                <div className="bg-[#121824] p-1.5 border border-[#1d273a]">
                  <span className="text-[#8b949e]">5Y ZERO:</span>
                  <span className="float-right text-[#e6edf3] font-bold">
                    {activeCurve.points.find(p => p.tenor === '5Y')?.zeroRate || 4.02}%
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Institutional Market Overview Info */}
          <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-2 text-[11px] text-[#8b949e]">
            <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-1">
              INFRASTRUCTURE AUDIT SPEC
            </div>
            <p className="leading-relaxed">
              All derivative contracts in RHINOQUANT are executable state machines backed by deterministic pricing models (Black-76, Black-Scholes, and Discounted Cash Flow zero-curve engines).
            </p>
            <div className="p-2 bg-[#121824] border border-[#1d273a] text-[#38bdf8] text-[10px]">
              ✓ Pre-trade risk checks active (DV01 limit: $10.0M / Counterparty limit: $500M)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
