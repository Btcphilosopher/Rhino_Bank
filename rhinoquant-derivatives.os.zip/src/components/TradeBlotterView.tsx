import React, { useState } from 'react';
import { Trade } from '../types';
import { ListFilter, Search, ExternalLink, FileText, Download } from 'lucide-react';

interface TradeBlotterViewProps {
  trades: Trade[];
  onSelectTradeDetail: (trade: Trade) => void;
}

export const TradeBlotterView: React.FC<TradeBlotterViewProps> = ({
  trades,
  onSelectTradeDetail
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filteredTrades = trades.filter((t) => {
    const matchesSearch =
      t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.counterparty.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.product.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || t.state === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Top Filter & Search Bar */}
      <div className="bg-[#0f141d] border border-[#1c2436] p-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#8b949e] absolute left-2 top-2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search Trade ID, Counterparty, Product..."
              className="bg-[#0b0e14] border border-[#1f293d] pl-7 pr-3 py-1 text-[#e6edf3] text-xs outline-none focus:border-[#38bdf8] w-64"
            />
          </div>

          <div className="flex items-center space-x-1">
            <span className="text-[#8b949e] text-[10px] font-bold">STATE:</span>
            {['ALL', 'ACTIVE', 'EXECUTED', 'CONFIRMED', 'SETTLED'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2 py-0.5 text-[10px] font-bold cursor-pointer transition-colors ${
                  statusFilter === st
                    ? 'bg-[#1f2b3e] text-[#38bdf8] border border-[#2f405c]'
                    : 'text-[#8b949e] hover:text-[#e6edf3] bg-[#111622] border border-transparent'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center space-x-2 text-[10px] text-[#8b949e]">
          <span>TOTAL TRADES: <span className="text-[#e6edf3] font-bold">{trades.length}</span></span>
          <button className="bg-[#111622] hover:bg-[#18202e] text-[#38bdf8] px-2 py-1 border border-[#1f293d] flex items-center space-x-1 cursor-pointer">
            <Download className="w-3 h-3" />
            <span>EXPORT CSV</span>
          </button>
        </div>
      </div>

      {/* Blotter Table */}
      <div className="bg-[#0f141d] border border-[#1c2436] overflow-x-auto">
        <table className="w-full text-left text-[11px] whitespace-nowrap">
          <thead>
            <tr className="text-[#8b949e] border-b border-[#1c2436] bg-[#0b0e14]">
              <th className="py-2 px-2.5 font-bold">TIME / DATE</th>
              <th className="py-2 px-2.5 font-bold">TRADE ID</th>
              <th className="py-2 px-2.5 font-bold">PRODUCT</th>
              <th className="py-2 px-2.5 font-bold">UNDERLYING</th>
              <th className="py-2 px-2.5 font-bold">DIRECTION</th>
              <th className="py-2 px-2.5 font-bold text-right">NOTIONAL</th>
              <th className="py-2 px-2.5 font-bold text-right">PRICE / RATE</th>
              <th className="py-2 px-2.5 font-bold">COUNTERPARTY</th>
              <th className="py-2 px-2.5 font-bold">BOOK</th>
              <th className="py-2 px-2.5 font-bold">STATUS</th>
              <th className="py-2 px-2.5 font-bold text-right">MTM ($)</th>
              <th className="py-2 px-2.5 font-bold text-right">P&L ($)</th>
              <th className="py-2 px-2.5 font-bold text-center">INSPECT</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#151c2a]">
            {filteredTrades.map((t) => {
              const isPnlPos = t.pnl >= 0;
              return (
                <tr key={t.id} className="hover:bg-[#161e2e] transition-colors cursor-pointer" onClick={() => onSelectTradeDetail(t)}>
                  <td className="py-2 px-2.5 text-[#8b949e]">{t.tradeDate}</td>
                  <td className="py-2 px-2.5 font-bold text-[#38bdf8]">{t.id}</td>
                  <td className="py-2 px-2.5 font-bold text-[#e6edf3]">{t.product}</td>
                  <td className="py-2 px-2.5 text-[#8b949e]">{t.underlyingSymbol}</td>
                  <td className="py-2 px-2.5">
                    <span className={`px-1.5 py-0.5 text-[9px] font-bold border ${
                      t.direction.includes('BUY') || t.direction.includes('LONG')
                        ? 'bg-[#238636]/20 text-[#238636] border-[#238636]/40'
                        : 'bg-[#da3633]/20 text-[#da3633] border-[#da3633]/40'
                    }`}>
                      {t.direction}
                    </span>
                  </td>
                  <td className="py-2 px-2.5 text-right font-bold text-[#e6edf3] num">
                    ${(t.notional / 1000000).toFixed(0)}M
                  </td>
                  <td className="py-2 px-2.5 text-right text-[#8b949e] num">
                    {t.fixedRate ? `${(t.fixedRate * 100).toFixed(3)}%` : t.executionPrice}
                  </td>
                  <td className="py-2 px-2.5 text-[#e6edf3] font-medium">{t.counterparty}</td>
                  <td className="py-2 px-2.5 text-[#8b949e] text-[10px]">{t.book}</td>
                  <td className="py-2 px-2.5">
                    <span className="bg-[#121824] text-[#38bdf8] border border-[#1e283c] px-1.5 py-0.5 text-[9px] font-bold">
                      {t.state}
                    </span>
                  </td>
                  <td className="py-2 px-2.5 text-right font-bold text-[#e6edf3] num">
                    ${t.mtm.toLocaleString()}
                  </td>
                  <td className={`py-2 px-2.5 text-right font-bold num ${isPnlPos ? 'text-[#238636]' : 'text-[#da3633]'}`}>
                    {isPnlPos ? '+' : ''}${t.pnl.toLocaleString()}
                  </td>
                  <td className="py-2 px-2.5 text-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectTradeDetail(t);
                      }}
                      className="p-1 bg-[#162032] hover:bg-[#22304a] text-[#38bdf8] border border-[#273754] rounded-none cursor-pointer inline-flex items-center justify-center"
                    >
                      <FileText className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
