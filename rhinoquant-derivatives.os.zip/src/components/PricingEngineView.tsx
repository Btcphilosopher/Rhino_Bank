import React, { useState } from 'react';
import { priceBlackScholes, priceInterestRateSwap, runMonteCarloSimulation } from '../quant/pricingEngine';
import { INITIAL_YIELD_CURVES } from '../data/initialMarketData';
import { Calculator, Cpu, TrendingUp, Layers } from 'lucide-react';

export const PricingEngineView: React.FC = () => {
  const [activeModel, setActiveModel] = useState<'BS' | 'IRS' | 'MC'>('BS');

  // Black-Scholes state
  const [bsSpot, setBsSpot] = useState<number>(1.1742);
  const [bsStrike, setBsStrike] = useState<number>(1.1800);
  const [bsTenor, setBsTenor] = useState<number>(1.0);
  const [bsRate, setBsRate] = useState<number>(0.0418);
  const [bsVol, setBsVol] = useState<number>(0.082);
  const [bsIsCall, setBsIsCall] = useState<boolean>(true);

  // IRS State
  const [irsNotional, setIrsNotional] = useState<number>(100000000);
  const [irsFixedRate, setIrsFixedRate] = useState<number>(0.0412);
  const [irsTenor, setIrsTenor] = useState<number>(5);

  // MC State
  const [mcSpot, setMcSpot] = useState<number>(100);
  const [mcDrift, setMcDrift] = useState<number>(0.03);
  const [mcVol, setMcVol] = useState<number>(0.20);
  const [mcTenor, setMcTenor] = useState<number>(1.0);
  const [mcPaths, setMcPaths] = useState<number>(1000);

  // Calculations
  const bsResult = priceBlackScholes(bsSpot, bsStrike, bsTenor, bsRate, bsVol, bsIsCall);
  const irsResult = priceInterestRateSwap(irsNotional, irsFixedRate, irsTenor, INITIAL_YIELD_CURVES[0], true);
  const mcResult = runMonteCarloSimulation(mcSpot, mcDrift, mcVol, mcTenor, mcPaths);

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Top Model Selector Bar */}
      <div className="bg-[#0f141d] border border-[#1c2436] p-2 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Cpu className="w-4 h-4 text-[#38bdf8]" />
          <span className="font-bold text-[#e6edf3] uppercase">QUANTITATIVE PRICING & ANALYTICS ENGINE:</span>
          {[
            { id: 'BS', label: 'BLACK-SCHOLES (OPTIONS)' },
            { id: 'IRS', label: 'DISCOUNTED CASH FLOW (IRS)' },
            { id: 'MC', label: 'MONTE CARLO (GBM PATHS)' }
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => setActiveModel(m.id as any)}
              className={`px-2.5 py-1 text-[11px] font-bold cursor-pointer transition-colors ${
                activeModel === m.id
                  ? 'bg-[#1e2a3f] text-[#38bdf8] border border-[#2d3f5e]'
                  : 'text-[#8b949e] hover:text-[#e6edf3] bg-[#111622] border border-transparent'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
        <div className="text-[10px] text-[#38bdf8] bg-[#38bdf8]/10 px-2 py-0.5 border border-[#38bdf8]/20">
          ANALYTICAL CLOSED FORM & NUMERICAL STOCHASTIC ENGINES
        </div>
      </div>

      {/* Model Content */}
      {activeModel === 'BS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="bg-[#0f141d] border border-[#1c2436] p-4 space-y-3">
            <h3 className="font-bold text-[#38bdf8] uppercase border-b border-[#1c2436] pb-2">BLACK-SCHOLES PARAMETERS</h3>
            
            <div className="space-y-2">
              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">SPOT PRICE (S)</label>
                <input
                  type="number"
                  step="0.0001"
                  value={bsSpot}
                  onChange={(e) => setBsSpot(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">STRIKE PRICE (K)</label>
                <input
                  type="number"
                  step="0.0001"
                  value={bsStrike}
                  onChange={(e) => setBsStrike(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">TIME TO MATURITY (YEARS)</label>
                <input
                  type="number"
                  step="0.1"
                  value={bsTenor}
                  onChange={(e) => setBsTenor(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">RISK-FREE RATE (r)</label>
                <input
                  type="number"
                  step="0.001"
                  value={bsRate}
                  onChange={(e) => setBsRate(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">IMPLIED VOLATILITY (σ)</label>
                <input
                  type="number"
                  step="0.005"
                  value={bsVol}
                  onChange={(e) => setBsVol(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">OPTION TYPE</label>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setBsIsCall(true)}
                    className={`flex-1 py-1 font-bold ${bsIsCall ? 'bg-[#38bdf8] text-[#0b0e14]' : 'bg-[#111622] text-[#8b949e]'}`}
                  >
                    CALL
                  </button>
                  <button
                    onClick={() => setBsIsCall(false)}
                    className={`flex-1 py-1 font-bold ${!bsIsCall ? 'bg-[#38bdf8] text-[#0b0e14]' : 'bg-[#111622] text-[#8b949e]'}`}
                  >
                    PUT
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 bg-[#0f141d] border border-[#1c2436] p-4 space-y-4">
            <h3 className="font-bold text-[#e6edf3] uppercase border-b border-[#1c2436] pb-2 flex justify-between">
              <span>PRICING OUTPUT & FULL GREEKS</span>
              <span className="text-[#38bdf8]">${(bsResult.price * 100000000).toLocaleString('en-US', { maximumFractionDigits: 0 })} per $100M</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                <div className="text-[10px] text-[#8b949e]">OPTION PREMIUM</div>
                <div className="text-base font-bold text-[#38bdf8] num">{bsResult.price.toFixed(4)}</div>
              </div>
              <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                <div className="text-[10px] text-[#8b949e]">DELTA (Δ)</div>
                <div className="text-base font-bold text-[#e6edf3] num">{bsResult.greeks.delta.toFixed(4)}</div>
              </div>
              <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                <div className="text-[10px] text-[#8b949e]">GAMMA (Γ)</div>
                <div className="text-base font-bold text-[#e6edf3] num">{bsResult.greeks.gamma.toFixed(4)}</div>
              </div>
              <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                <div className="text-[10px] text-[#8b949e]">VEGA (ν)</div>
                <div className="text-base font-bold text-[#e6edf3] num">{bsResult.greeks.vega.toFixed(4)}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center pt-2">
              <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                <div className="text-[10px] text-[#8b949e]">THETA (Θ) / DAY</div>
                <div className="text-sm font-bold text-[#da3633] num">{bsResult.greeks.theta.toFixed(5)}</div>
              </div>
              <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                <div className="text-[10px] text-[#8b949e]">RHO (ρ)</div>
                <div className="text-sm font-bold text-[#e6edf3] num">{bsResult.greeks.rho.toFixed(4)}</div>
              </div>
              <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                <div className="text-[10px] text-[#8b949e]">VANNA</div>
                <div className="text-sm font-bold text-[#8b949e] num">{bsResult.greeks.vanna?.toFixed(4) || 0}</div>
              </div>
              <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                <div className="text-[10px] text-[#8b949e]">VOLGA</div>
                <div className="text-sm font-bold text-[#8b949e] num">{bsResult.greeks.volga?.toFixed(4) || 0}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeModel === 'IRS' && (
        <div className="bg-[#0f141d] border border-[#1c2436] p-4 space-y-4">
          <h3 className="font-bold text-[#38bdf8] uppercase border-b border-[#1c2436] pb-2">
            DISCOUNTED CASH FLOW INTEREST RATE SWAP (IRS) CALCULATOR
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-3 bg-[#0b0e14] p-3 border border-[#1a2232]">
              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">NOTIONAL ($)</label>
                <input
                  type="number"
                  value={irsNotional}
                  onChange={(e) => setIrsNotional(Number(e.target.value))}
                  className="w-full bg-[#111622] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">FIXED RATE (%)</label>
                <input
                  type="number"
                  step="0.001"
                  value={irsFixedRate * 100}
                  onChange={(e) => setIrsFixedRate(Number(e.target.value) / 100)}
                  className="w-full bg-[#111622] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">TENOR (YEARS)</label>
                <input
                  type="number"
                  value={irsTenor}
                  onChange={(e) => setIrsTenor(Number(e.target.value))}
                  className="w-full bg-[#111622] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>
            </div>

            <div className="md:col-span-2 space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-[#0b0e14] p-3 border border-[#1a2232] text-center">
                  <div className="text-[10px] text-[#8b949e]">NET PRESENT VALUE (NPV)</div>
                  <div className="text-base font-bold text-[#38bdf8] num">${Math.round(irsResult.npv).toLocaleString()}</div>
                </div>
                <div className="bg-[#0b0e14] p-3 border border-[#1a2232] text-center">
                  <div className="text-[10px] text-[#8b949e]">PAR SWAP RATE</div>
                  <div className="text-base font-bold text-[#238636] num">{(irsResult.parRate * 100).toFixed(4)}%</div>
                </div>
                <div className="bg-[#0b0e14] p-3 border border-[#1a2232] text-center">
                  <div className="text-[10px] text-[#8b949e]">DV01 (1BP SHIFT)</div>
                  <div className="text-base font-bold text-[#d29922] num">${Math.round(irsResult.dv01).toLocaleString()}</div>
                </div>
              </div>

              <div className="bg-[#0b0e14] p-3 border border-[#1a2232]">
                <div className="text-[10px] font-bold text-[#8b949e] mb-2 uppercase">PROJECTED CASH FLOW SCHEDULE ({irsResult.cashFlows.length} PERIODS)</div>
                <div className="max-h-48 overflow-y-auto">
                  <table className="w-full text-left text-[10px]">
                    <thead>
                      <tr className="text-[#8b949e] border-b border-[#182030]">
                        <th className="py-1">PERIOD</th>
                        <th className="py-1">PAYMENT DATE</th>
                        <th className="py-1 text-right">FIXED LEG ($)</th>
                        <th className="py-1 text-right">FLOATING LEG ($)</th>
                        <th className="py-1 text-right">NET CASH FLOW ($)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#121824]">
                      {irsResult.cashFlows.map((cf) => (
                        <tr key={cf.id}>
                          <td className="py-1 text-[#38bdf8] font-bold">{cf.id}</td>
                          <td className="py-1 text-[#8b949e]">{cf.paymentDate}</td>
                          <td className="py-1 text-right text-[#da3633] num">${Math.abs(cf.legAAmount).toLocaleString()}</td>
                          <td className="py-1 text-right text-[#238636] num">${Math.abs(cf.legBAmount).toLocaleString()}</td>
                          <td className="py-1 text-right font-bold text-[#e6edf3] num">${cf.netAmount.toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeModel === 'MC' && (
        <div className="bg-[#0f141d] border border-[#1c2436] p-4 space-y-4">
          <h3 className="font-bold text-[#38bdf8] uppercase border-b border-[#1c2436] pb-2">
            GEOMETRIC BROWNIAN MOTION (GBM) MONTE CARLO STOCHASTIC ENGINE
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-3 bg-[#0b0e14] p-3 border border-[#1a2232]">
              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">INITIAL SPOT (S0)</label>
                <input
                  type="number"
                  value={mcSpot}
                  onChange={(e) => setMcSpot(Number(e.target.value))}
                  className="w-full bg-[#111622] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">DRIFT (μ)</label>
                <input
                  type="number"
                  step="0.01"
                  value={mcDrift}
                  onChange={(e) => setMcDrift(Number(e.target.value))}
                  className="w-full bg-[#111622] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">VOLATILITY (σ)</label>
                <input
                  type="number"
                  step="0.01"
                  value={mcVol}
                  onChange={(e) => setMcVol(Number(e.target.value))}
                  className="w-full bg-[#111622] border border-[#1f293d] text-[#e6edf3] p-1.5 num"
                />
              </div>

              <div>
                <label className="block text-[#8b949e] text-[10px] mb-1">SIMULATION PATHS</label>
                <select
                  value={mcPaths}
                  onChange={(e) => setMcPaths(Number(e.target.value))}
                  className="w-full bg-[#111622] border border-[#1f293d] text-[#e6edf3] p-1.5"
                >
                  <option value={1000}>1,000 Paths</option>
                  <option value={5000}>5,000 Paths</option>
                  <option value={10000}>10,000 Paths</option>
                </select>
              </div>
            </div>

            <div className="md:col-span-3 space-y-3">
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                  <div className="text-[10px] text-[#8b949e]">MEAN SPOT (T=1Y)</div>
                  <div className="text-sm font-bold text-[#38bdf8] num">{mcResult.mean.toFixed(2)}</div>
                </div>
                <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                  <div className="text-[10px] text-[#8b949e]">5th PERCENTILE</div>
                  <div className="text-sm font-bold text-[#da3633] num">{mcResult.p05.toFixed(2)}</div>
                </div>
                <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                  <div className="text-[10px] text-[#8b949e]">50th PERCENTILE (MEDIAN)</div>
                  <div className="text-sm font-bold text-[#e6edf3] num">{mcResult.p50.toFixed(2)}</div>
                </div>
                <div className="bg-[#0b0e14] p-2 border border-[#1a2232]">
                  <div className="text-[10px] text-[#8b949e]">95th PERCENTILE</div>
                  <div className="text-sm font-bold text-[#238636] num">{mcResult.p95.toFixed(2)}</div>
                </div>
              </div>

              <div className="bg-[#0b0e14] p-3 border border-[#1a2232] h-48 flex items-end justify-between gap-1">
                {mcResult.paths.slice(0, 30).map((path, idx) => {
                  const finalVal = path[path.length - 1];
                  const height = Math.min(100, Math.max(10, (finalVal / mcSpot) * 50));
                  return (
                    <div
                      key={idx}
                      style={{ height: `${height}%` }}
                      className="flex-1 bg-[#23324a] hover:bg-[#38bdf8] transition-colors"
                    ></div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
