import React, { useState } from 'react';
import { AlertOctagon, Play, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { Trade } from '../types';

interface SimulationViewProps {
  trades: Trade[];
}

export const SimulationView: React.FC<SimulationViewProps> = ({ trades }) => {
  const [selectedScenario, setSelectedScenario] = useState<'RATES_UP' | 'RATES_DOWN' | 'VOL_SPIKE' | 'EQUITY_CRASH' | 'CP_DEFAULT'>('RATES_UP');
  const [isSimulating, setIsSimulating] = useState(false);
  const [simLogs, setSimLogs] = useState<string[]>([]);

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setSimLogs([`Initializing macro stress simulation environment...`]);

    setTimeout(() => {
      if (selectedScenario === 'CP_DEFAULT') {
        setSimLogs(prev => [
          ...prev,
          `Triggering Counterparty Default Sequence on RHINO BANK PLC...`,
          `Step 1: Terminating all active transactions in netting set NET-RHINO-01`,
          `Step 2: Calculating Closeout MTM Amount: +$18,420,000`,
          `Step 3: Liquidating pledged USD Cash Collateral Pool: -$12,500,000`,
          `Step 4: Applying Variation Margin Netting: -$5,920,000`,
          `FINAL RESULT: Net Residual Uncollateralized Default Loss = $0.00 (100% Fully Collateralized & Settled)`
        ]);
      } else if (selectedScenario === 'RATES_UP') {
        setSimLogs(prev => [
          ...prev,
          `Applying +200bp Parallel Yield Curve Shock across USD SOFR & EUR €STR...`,
          `Re-evaluating $100M 5Y USD IRS: MTM change -$8,240,000`,
          `Re-evaluating EUR/USD Option: Delta shift +0.12`,
          `Total Portfolio MTM Shift: -$8,240,000`,
          `Generating automated Margin Call: Additional $8,240,000 Variation Margin required within T+1`
        ]);
      } else {
        setSimLogs(prev => [
          ...prev,
          `Executing stress scenario ${selectedScenario}...`,
          `Portfolio MTM revaluation complete.`,
          `All risk limits re-verified.`
        ]);
      }
      setIsSimulating(false);
    }, 800);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <AlertOctagon className="w-4 h-4 text-[#da3633]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">MACRO STRESS SCENARIO & COUNTERPARTY DEFAULT SIMULATOR</h2>
        </div>
        <button
          onClick={handleRunSimulation}
          disabled={isSimulating}
          className="px-3 py-1.5 bg-[#da3633] hover:bg-[#b92c2a] text-[#ffffff] font-bold cursor-pointer flex items-center space-x-1.5"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>{isSimulating ? 'SIMULATING STRESS...' : 'RUN STRESS SCENARIO'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Scenario Selection */}
        <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-2">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2">SELECT STRESS EVENT</div>
          
          <div className="space-y-1">
            {[
              { id: 'RATES_UP', label: '+200BP PARALLEL RATE SHOCK', desc: 'Central bank hawkish tightening event' },
              { id: 'RATES_DOWN', label: '-200BP PARALLEL RATE SHOCK', desc: 'Central bank emergency easing event' },
              { id: 'VOL_SPIKE', label: '+25% VOLATILITY SPIKE', desc: 'Market turbulence & option repricing' },
              { id: 'EQUITY_CRASH', label: '-20% GLOBAL EQUITY CRASH', desc: 'Systemic equity index selloff' },
              { id: 'CP_DEFAULT', label: 'RHINO BANK DEFAULT SEQUENCE', desc: 'Full ISDA closeout netting & collateral liquidation' }
            ].map((sc) => (
              <button
                key={sc.id}
                onClick={() => setSelectedScenario(sc.id as any)}
                className={`w-full text-left p-2 border cursor-pointer transition-all ${
                  selectedScenario === sc.id
                    ? 'bg-[#1e2a3f] text-[#38bdf8] border-[#38bdf8]'
                    : 'bg-[#0b0e14] text-[#8b949e] border-[#182030] hover:text-[#e6edf3]'
                }`}
              >
                <div className="font-bold text-[11px]">{sc.label}</div>
                <div className="text-[10px] text-[#8b949e]">{sc.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Execution Output Console */}
        <div className="lg:col-span-2 bg-[#0f141d] border border-[#1c2436] p-3 space-y-2 flex flex-col justify-between">
          <div>
            <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
              <span>STRESS EXECUTION AUDIT LOG</span>
              <span className="text-[#38bdf8] text-[10px]">REAL-TIME EVENT STREAM</span>
            </div>

            <div className="bg-[#0b0e14] p-3 border border-[#182030] text-[#38bdf8] text-[11px] min-h-60 max-h-80 overflow-y-auto space-y-1 font-mono">
              {simLogs.length === 0 ? (
                <div className="text-[#8b949e] italic">Select a stress scenario and click 'RUN STRESS SCENARIO' to simulate macro shocks or counterparty closeout netting.</div>
              ) : (
                simLogs.map((log, i) => (
                  <div key={i} className="flex items-start space-x-2">
                    <span className="text-[#238636] font-bold">&gt;</span>
                    <span className="text-[#e6edf3]">{log}</span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="p-2 bg-[#121824] border border-[#1d273a] text-[10px] text-[#8b949e]">
            Stress simulations run against synthetic digital twin engines without impacting live order books.
          </div>
        </div>
      </div>
    </div>
  );
};
