import React, { useState, useEffect } from 'react';
import { Terminal, Search, ArrowRight, X } from 'lucide-react';
import { MainTab } from './PrimaryNav';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: MainTab) => void;
  onExecuteSlice1: () => void;
  onExecuteSlice2: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onExecuteSlice1,
  onExecuteSlice2
}) => {
  const [input, setInput] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else {
          // Open
          window.dispatchEvent(new CustomEvent('open-cmd-palette'));
        }
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleCommandRun = (cmd: string) => {
    const uppercaseCmd = cmd.trim().toUpperCase();
    if (uppercaseCmd.includes('SWAP') || uppercaseCmd.includes('IRS') || uppercaseCmd === 'NEW TRADE') {
      onSelectTab('TRADE');
      onExecuteSlice1();
    } else if (uppercaseCmd.includes('OPTION') || uppercaseCmd.includes('EURUSD')) {
      onSelectTab('TRADE');
      onExecuteSlice2();
    } else if (uppercaseCmd.includes('BOOK')) {
      onSelectTab('BOOK');
    } else if (uppercaseCmd.includes('PRICING')) {
      onSelectTab('PRICING');
    } else if (uppercaseCmd.includes('RISK') || uppercaseCmd.includes('STRESS')) {
      onSelectTab('RISK');
    } else if (uppercaseCmd.includes('MARGIN')) {
      onSelectTab('MARGIN');
    } else if (uppercaseCmd.includes('COLLATERAL')) {
      onSelectTab('COLLATERAL');
    } else if (uppercaseCmd.includes('LIFECYCLE')) {
      onSelectTab('LIFECYCLE');
    } else if (uppercaseCmd.includes('CONTRACT')) {
      onSelectTab('CONTRACTS');
    } else {
      onSelectTab('MARKETS');
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-start justify-center pt-20 p-4 font-mono">
      <div className="bg-[#0f141d] border border-[#2b3750] w-full max-w-xl shadow-2xl text-xs overflow-hidden">
        {/* Terminal Header */}
        <div className="flex items-center justify-between px-3 py-2 bg-[#161c28] border-b border-[#212c40]">
          <div className="flex items-center space-x-2 text-[#38bdf8] font-bold">
            <Terminal className="w-4 h-4" />
            <span>RHINOQUANT COMMAND PALETTE</span>
          </div>
          <button onClick={onClose} className="text-[#8b949e] hover:text-[#e6edf3]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input */}
        <div className="p-3 border-b border-[#1c2436] flex items-center space-x-2 bg-[#0b0e14]">
          <span className="text-[#38bdf8] font-bold">&lt;RQ&gt;</span>
          <input
            type="text"
            autoFocus
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && input.trim()) {
                handleCommandRun(input);
              }
            }}
            placeholder="Type command e.g. <RQ> USD IRS 5Y, PRICE OPTION, STRESS TEST..."
            className="w-full bg-transparent text-[#e6edf3] outline-none placeholder-[#505a6e]"
          />
        </div>

        {/* Shortcuts / Quick Commands */}
        <div className="p-3 space-y-1 bg-[#0e121a] max-h-80 overflow-y-auto">
          <div className="text-[10px] text-[#8b949e] uppercase font-bold mb-2">Preset Quick Operations:</div>
          
          <button
            onClick={() => handleCommandRun('<RQ> USD IRS 5Y')}
            className="w-full text-left px-2 py-1.5 hover:bg-[#182133] border border-transparent hover:border-[#2a3854] flex items-center justify-between text-[#e6edf3] group cursor-pointer"
          >
            <div className="flex items-center space-x-2">
              <span className="text-[#38bdf8] font-bold">&lt;RQ&gt;</span>
              <span>USD IRS 5Y - Trade $100M Pay Fixed / Rec SOFR</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-[#505a6e] group-hover:text-[#38bdf8]" />
          </button>

          <button
            onClick={() => handleCommandRun('PRICE EURUSD OPTION')}
            className="w-full text-left px-2 py-1.5 hover:bg-[#182133] border border-transparent hover:border-[#2a3854] flex items-center justify-between text-[#e6edf3] group cursor-pointer"
          >
            <div className="flex items-center space-x-2">
              <span className="text-[#38bdf8] font-bold">&lt;RQ&gt;</span>
              <span>FX OPTION - $100M EUR/USD 1Y Call Option</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-[#505a6e] group-hover:text-[#38bdf8]" />
          </button>

          <button
            onClick={() => handleCommandRun('OPEN BOOK')}
            className="w-full text-left px-2 py-1.5 hover:bg-[#182133] border border-transparent hover:border-[#2a3854] flex items-center justify-between text-[#e6edf3] group cursor-pointer"
          >
            <div className="flex items-center space-x-2">
              <span className="text-[#8b949e]">BOOK</span>
              <span>Open Position Book & Greeks Analytics</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-[#505a6e] group-hover:text-[#38bdf8]" />
          </button>

          <button
            onClick={() => handleCommandRun('RUN STRESS')}
            className="w-full text-left px-2 py-1.5 hover:bg-[#182133] border border-transparent hover:border-[#2a3854] flex items-center justify-between text-[#e6edf3] group cursor-pointer"
          >
            <div className="flex items-center space-x-2">
              <span className="text-[#8b949e]">STRESS</span>
              <span>Execute +200bp Rate & +25% Vol Stress Scenario</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-[#505a6e] group-hover:text-[#38bdf8]" />
          </button>

          <button
            onClick={() => handleCommandRun('LIFECYCLE ADVANCE')}
            className="w-full text-left px-2 py-1.5 hover:bg-[#182133] border border-transparent hover:border-[#2a3854] flex items-center justify-between text-[#e6edf3] group cursor-pointer"
          >
            <div className="flex items-center space-x-2">
              <span className="text-[#8b949e]">LIFECYCLE</span>
              <span>Open Executable Contract State Machine & Stepper</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-[#505a6e] group-hover:text-[#38bdf8]" />
          </button>
        </div>

        <div className="px-3 py-1.5 bg-[#080a0e] border-t border-[#1a2232] text-[10px] text-[#8b949e] flex justify-between">
          <span>Press [ENTER] to execute command</span>
          <span>[ESC] to dismiss</span>
        </div>
      </div>
    </div>
  );
};
