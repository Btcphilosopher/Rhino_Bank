import React, { useState } from 'react';
import { Cpu, Layers, TrendingUp, RefreshCw } from 'lucide-react';

export const QuantLabView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'VOL_SURFACE' | 'CURVE_SHOCKS' | 'STOCHASTIC'>('VOL_SURFACE');

  // Synthetic 3D Volatility Surface Grid (Expiry vs Strike)
  const volMatrix = [
    { strike: '90%', m1: '12.4%', m3: '11.8%', m6: '11.2%', y1: '10.8%' },
    { strike: '95%', m1: '10.2%', m3: '9.8%', m6: '9.5%', y1: '9.2%' },
    { strike: '100% (ATM)', m1: '8.4%', m3: '8.2%', m6: '8.0%', y1: '7.8%' },
    { strike: '105%', m1: '9.1%', m3: '8.9%', m6: '8.6%', y1: '8.3%' },
    { strike: '110%', m1: '11.2%', m3: '10.6%', m6: '10.1%', y1: '9.7%' }
  ];

  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Cpu className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">QUANTITATIVE RESEARCH & MODELING LABORATORY</h2>
        </div>
        <div className="flex space-x-1 text-[10px]">
          {['VOL_SURFACE', 'CURVE_SHOCKS', 'STOCHASTIC'].map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t as any)}
              className={`px-2.5 py-1 font-bold cursor-pointer transition-colors ${
                activeTab === t ? 'bg-[#1f2b3e] text-[#38bdf8] border border-[#2d3e5a]' : 'bg-[#111622] text-[#8b949e]'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'VOL_SURFACE' && (
        <div className="bg-[#0f141d] border border-[#1c2436] p-4 space-y-4">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
            <span>IMPLIED VOLATILITY SURFACE SMILE / SKEW (SOFR SWAPTION & FX)</span>
            <span className="text-[#38bdf8]">MODEL: SABR / HESTON CALIBRATION</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center text-[11px]">
              <thead>
                <tr className="text-[#8b949e] border-b border-[#1c2436] bg-[#0b0e14]">
                  <th className="py-2 text-left px-2">STRIKE / MONIELNESS</th>
                  <th className="py-2">1M EXPIRY</th>
                  <th className="py-2">3M EXPIRY</th>
                  <th className="py-2">6M EXPIRY</th>
                  <th className="py-2">1Y EXPIRY</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#151c2a]">
                {volMatrix.map((row, idx) => (
                  <tr key={idx} className="hover:bg-[#161e2e]">
                    <td className="py-2.5 text-left px-2 font-bold text-[#38bdf8]">{row.strike}</td>
                    <td className="py-2.5 font-bold text-[#d29922] num">{row.m1}</td>
                    <td className="py-2.5 font-bold text-[#d29922] num">{row.m3}</td>
                    <td className="py-2.5 font-bold text-[#d29922] num">{row.m6}</td>
                    <td className="py-2.5 font-bold text-[#d29922] num">{row.y1}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-2 bg-[#0b0e14] border border-[#182030] text-[10px] text-[#8b949e]">
            SABR Parameters: α = 0.082, β = 0.50, ρ = -0.24, ν = 0.38 (Calibrated against live market quotes)
          </div>
        </div>
      )}

      {activeTab === 'CURVE_SHOCKS' && (
        <div className="bg-[#0f141d] border border-[#1c2436] p-4 space-y-4">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2">
            STRESS YIELD CURVE SHOCK SCENARIOS (+200BP, -200BP, STEEPENER, FLATTENER)
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="bg-[#0b0e14] p-3 border border-[#182030] space-y-1">
              <div className="text-[10px] text-[#8b949e]">PARALLEL +200BP</div>
              <div className="text-base font-bold text-[#da3633] num">-$8,240,000</div>
              <div className="text-[9px] text-[#8b949e]">P&L Impact on Pay-Fixed Swap</div>
            </div>

            <div className="bg-[#0b0e14] p-3 border border-[#182030] space-y-1">
              <div className="text-[10px] text-[#8b949e]">PARALLEL -200BP</div>
              <div className="text-base font-bold text-[#238636] num">+$8,240,000</div>
              <div className="text-[9px] text-[#8b949e]">P&L Impact on Pay-Fixed Swap</div>
            </div>

            <div className="bg-[#0b0e14] p-3 border border-[#182030] space-y-1">
              <div className="text-[10px] text-[#8b949e]">2Y/10Y STEEPENER (+50BP)</div>
              <div className="text-base font-bold text-[#d29922] num">+$1,420,000</div>
              <div className="text-[9px] text-[#8b949e]">P&L Impact</div>
            </div>

            <div className="bg-[#0b0e14] p-3 border border-[#182030] space-y-1">
              <div className="text-[10px] text-[#8b949e]">2Y/10Y FLATTENER (-50BP)</div>
              <div className="text-base font-bold text-[#da3633] num">-$1,420,000</div>
              <div className="text-[9px] text-[#8b949e]">P&L Impact</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
