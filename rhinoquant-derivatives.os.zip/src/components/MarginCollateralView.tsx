import React, { useState } from 'react';
import { CollateralAsset } from '../types';
import { Shield, DollarSign, ArrowUpRight, ArrowDownLeft, CheckCircle, RefreshCw } from 'lucide-react';

interface MarginCollateralViewProps {
  collateral: CollateralAsset[];
}

export const MarginCollateralView: React.FC<MarginCollateralViewProps> = ({ collateral: initialCollateral }) => {
  const [collateralList, setCollateralList] = useState<CollateralAsset[]>(initialCollateral);
  const [activeTab, setActiveTab] = useState<'MARGIN' | 'INVENTORY' | 'OPTIMIZER'>('MARGIN');

  const totalMarketVal = collateralList.reduce((a, b) => a + b.marketValue, 0);
  const totalEligibleVal = collateralList.reduce((a, b) => a + b.eligibleValue, 0);
  const totalPledged = collateralList.reduce((a, b) => a + b.pledged, 0);
  const totalAvailable = collateralList.reduce((a, b) => a + b.available, 0);

  const handlePledgeMore = (assetId: string) => {
    setCollateralList(prev => prev.map(c => {
      if (c.id === assetId && c.available >= 1000000) {
        return {
          ...c,
          pledged: c.pledged + 1000000,
          available: c.available - 1000000
        };
      }
      return c;
    }));
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Shield className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">ISDA SIMM v2.5 MARGIN & COLLATERAL MANAGEMENT</h2>
        </div>
        <div className="flex space-x-1 text-[10px]">
          {['MARGIN', 'INVENTORY', 'OPTIMIZER'].map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t as any)}
              className={`px-2.5 py-1 font-bold cursor-pointer transition-colors ${
                activeTab === t ? 'bg-[#1f2b3e] text-[#38bdf8] border border-[#2d3e5a]' : 'bg-[#111622] text-[#8b949e]'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Top Collateral KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">TOTAL MARKET VALUE</div>
          <div className="text-base font-bold text-[#e6edf3] num">${(totalMarketVal / 1000000).toFixed(2)}M</div>
          <div className="text-[9px] text-[#8b949e]">Unadjusted pool</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">ELIGIBLE VALUE (POST-HAIRCUT)</div>
          <div className="text-base font-bold text-[#38bdf8] num">${(totalEligibleVal / 1000000).toFixed(2)}M</div>
          <div className="text-[9px] text-[#238636]">Basel III compliant</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">PLEDGED / OUTSTANDING</div>
          <div className="text-base font-bold text-[#d29922] num">${(totalPledged / 1000000).toFixed(2)}M</div>
          <div className="text-[9px] text-[#8b949e]">IM + VM Coverage</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">AVAILABLE SURPLUS</div>
          <div className="text-base font-bold text-[#238636] num">${(totalAvailable / 1000000).toFixed(2)}M</div>
          <div className="text-[9px] text-[#238636]">Ready for settlement</div>
        </div>
      </div>

      {/* Main Collateral Table */}
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
        <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
          <span>ELIGIBLE COLLATERAL INVENTORY & HAIRCUT SCHEDULE</span>
          <span className="text-[#38bdf8] text-[10px]">CSA REGIME: ISDA 2018 IM / 2016 VM</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px] whitespace-nowrap">
            <thead>
              <tr className="text-[#8b949e] border-b border-[#1c2436] bg-[#0b0e14]">
                <th className="py-2 px-2.5 font-bold">ASSET DESCRIPTION</th>
                <th className="py-2 px-2.5 font-bold">TYPE</th>
                <th className="py-2 px-2.5 font-bold text-right">MARKET VALUE ($)</th>
                <th className="py-2 px-2.5 font-bold text-right">HAIRCUT (%)</th>
                <th className="py-2 px-2.5 font-bold text-right">ELIGIBLE VALUE ($)</th>
                <th className="py-2 px-2.5 font-bold text-right">PLEDGED ($)</th>
                <th className="py-2 px-2.5 font-bold text-right">AVAILABLE ($)</th>
                <th className="py-2 px-2.5 font-bold">COUNTERPARTY</th>
                <th className="py-2 px-2.5 font-bold text-center">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#151c2a]">
              {collateralList.map((asset) => (
                <tr key={asset.id} className="hover:bg-[#161e2e]">
                  <td className="py-2 px-2.5 font-bold text-[#e6edf3]">{asset.assetName}</td>
                  <td className="py-2 px-2.5 text-[#38bdf8]">{asset.type}</td>
                  <td className="py-2 px-2.5 text-right font-bold text-[#e6edf3] num">${asset.marketValue.toLocaleString()}</td>
                  <td className="py-2 px-2.5 text-right text-[#d29922] font-bold num">{asset.haircut.toFixed(1)}%</td>
                  <td className="py-2 px-2.5 text-right text-[#238636] font-bold num">${asset.eligibleValue.toLocaleString()}</td>
                  <td className="py-2 px-2.5 text-right text-[#d29922] num">${asset.pledged.toLocaleString()}</td>
                  <td className="py-2 px-2.5 text-right text-[#238636] font-bold num">${asset.available.toLocaleString()}</td>
                  <td className="py-2 px-2.5 text-[#8b949e]">{asset.counterparty}</td>
                  <td className="py-2 px-2.5 text-center">
                    <button
                      onClick={() => handlePledgeMore(asset.id)}
                      className="px-2 py-0.5 bg-[#1b2a20] hover:bg-[#253d2d] text-[#238636] border border-[#2e5239] font-bold text-[10px] cursor-pointer"
                    >
                      PLEDGE +$1M
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
