import React from 'react';
import { Trade } from '../types';
import { X, FileText, Code, ShieldCheck, DollarSign } from 'lucide-react';

interface TradeDetailModalProps {
  trade: Trade | null;
  onClose: () => void;
}

export const TradeDetailModal: React.FC<TradeDetailModalProps> = ({ trade, onClose }) => {
  if (!trade) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#2b3750] w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-3 py-2 bg-[#161c28] border-b border-[#212c40]">
          <div className="flex items-center space-x-2 text-[#38bdf8] font-bold">
            <FileText className="w-4 h-4" />
            <span>CONTRACT IR & TRADE INSPECTOR: {trade.id}</span>
          </div>
          <button onClick={onClose} className="text-[#8b949e] hover:text-[#e6edf3]">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4 bg-[#0b0e14]">
          {/* Top Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
            <div className="bg-[#0f141d] p-2 border border-[#182030]">
              <div className="text-[10px] text-[#8b949e]">NOTIONAL</div>
              <div className="font-bold text-[#e6edf3] num">${(trade.notional / 1000000).toFixed(0)}M {trade.currency}</div>
            </div>
            <div className="bg-[#0f141d] p-2 border border-[#182030]">
              <div className="text-[10px] text-[#8b949e]">MARKET VALUE (MTM)</div>
              <div className="font-bold text-[#38bdf8] num">${trade.mtm.toLocaleString()}</div>
            </div>
            <div className="bg-[#0f141d] p-2 border border-[#182030]">
              <div className="text-[10px] text-[#8b949e]">INTRADAY P&L</div>
              <div className={`font-bold num ${trade.pnl >= 0 ? 'text-[#238636]' : 'text-[#da3633]'}`}>
                ${trade.pnl.toLocaleString()}
              </div>
            </div>
            <div className="bg-[#0f141d] p-2 border border-[#182030]">
              <div className="text-[10px] text-[#8b949e]">INITIAL MARGIN</div>
              <div className="font-bold text-[#d29922] num">${(trade.initialMargin / 1000000).toFixed(2)}M</div>
            </div>
          </div>

          {/* Contract IR JSON */}
          <div className="bg-[#0f141d] border border-[#182030] p-3 space-y-1">
            <div className="font-bold text-[#38bdf8] border-b border-[#182030] pb-1 uppercase">CANONICAL ISDA CDM CONTRACT IR</div>
            <pre className="bg-[#080a0e] p-2 text-[#e6edf3] text-[10px] overflow-x-auto max-h-48 font-mono">
              {JSON.stringify(trade.ir, null, 2)}
            </pre>
          </div>

          {/* Risk Greeks */}
          <div className="bg-[#0f141d] border border-[#182030] p-3 space-y-2">
            <div className="font-bold text-[#e6edf3] border-b border-[#182030] pb-1 uppercase">RISK GREEKS PROFILE</div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-[10px]">
              <div className="bg-[#080a0e] p-1.5 border border-[#182030]">
                <div className="text-[#8b949e]">DV01 ($/BP)</div>
                <div className="font-bold text-[#d29922] num">${trade.greeks?.dv01?.toLocaleString() || 0}</div>
              </div>
              <div className="bg-[#080a0e] p-1.5 border border-[#182030]">
                <div className="text-[#8b949e]">DELTA</div>
                <div className="font-bold text-[#e6edf3] num">{trade.greeks?.delta?.toFixed(2) || '0.00'}</div>
              </div>
              <div className="bg-[#080a0e] p-1.5 border border-[#182030]">
                <div className="text-[#8b949e]">GAMMA</div>
                <div className="font-bold text-[#e6edf3] num">{trade.greeks?.gamma?.toFixed(4) || '0.00'}</div>
              </div>
              <div className="bg-[#080a0e] p-1.5 border border-[#182030]">
                <div className="text-[#8b949e]">VEGA</div>
                <div className="font-bold text-[#e6edf3] num">{trade.greeks?.vega?.toFixed(0) || '0'}</div>
              </div>
              <div className="bg-[#080a0e] p-1.5 border border-[#182030]">
                <div className="text-[#8b949e]">THETA/DAY</div>
                <div className="font-bold text-[#da3633] num">{trade.greeks?.theta?.toFixed(0) || '0'}</div>
              </div>
              <div className="bg-[#080a0e] p-1.5 border border-[#182030]">
                <div className="text-[#8b949e]">RHO</div>
                <div className="font-bold text-[#e6edf3] num">{trade.greeks?.rho?.toFixed(0) || '0'}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
