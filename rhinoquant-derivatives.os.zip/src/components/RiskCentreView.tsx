import React from 'react';
import { ShieldAlert, Activity, BarChart2, TrendingDown, Layers } from 'lucide-react';
import { Trade } from '../types';

interface RiskCentreViewProps {
  trades: Trade[];
}

export const RiskCentreView: React.FC<RiskCentreViewProps> = ({ trades }) => {
  const totalNotional = trades.reduce((a, b) => a + b.notional, 0);
  const totalDv01 = trades.reduce((a, b) => a + (b.greeks?.dv01 || 0), 0);

  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <ShieldAlert className="w-4 h-4 text-[#da3633]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">ENTERPRISE RISK & XVA ANALYTICS CENTRE</h2>
        </div>
        <div className="text-[10px] text-[#38bdf8] bg-[#38bdf8]/10 px-2 py-0.5 border border-[#38bdf8]/30">
          MONTE CARLO 99% HISTORICAL & PARAMETRIC VaR
        </div>
      </div>

      {/* Top Value at Risk & XVA Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-center">
        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">1-DAY 99% VaR</div>
          <div className="text-sm font-bold text-[#da3633] num">$1,842,000</div>
          <div className="text-[9px] text-[#8b949e]">Historical 500-day</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">EXPECTED SHORTFALL (CVaR)</div>
          <div className="text-sm font-bold text-[#da3633] num">$2,410,500</div>
          <div className="text-[9px] text-[#8b949e]">Tail risk beyond 99%</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">CVA (CREDIT ADJ)</div>
          <div className="text-sm font-bold text-[#d29922] num">-$210,400</div>
          <div className="text-[9px] text-[#8b949e]">Counterparty default risk</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">DVA (DEBIT ADJ)</div>
          <div className="text-sm font-bold text-[#238636] num">+$82,100</div>
          <div className="text-[9px] text-[#8b949e]">Own credit spread benefit</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">FVA (FUNDING ADJ)</div>
          <div className="text-sm font-bold text-[#d29922] num">-$142,000</div>
          <div className="text-[9px] text-[#8b949e]">Uncollateralized funding</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5">
          <div className="text-[10px] text-[#8b949e]">KVA (CAPITAL ADJ)</div>
          <div className="text-sm font-bold text-[#da3633] num">-$85,300</div>
          <div className="text-[9px] text-[#8b949e]">Basel III regulatory capital</div>
        </div>
      </div>

      {/* Main Grid: Key Rate DV01 Ladder + Counterparty Exposure Profile */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Key Rate DV01 Profile */}
        <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
            <span>KEY-RATE DV01 BUCKET PROFILE (USD SOFR)</span>
            <span className="text-[#d29922] num">NET DV01: ${totalDv01.toLocaleString()}/bp</span>
          </div>

          <div className="space-y-1 text-[10px]">
            {[
              { tenor: '1M', dv01: 830, limit: 100000 },
              { tenor: '3M', dv01: 2470, limit: 250000 },
              { tenor: '6M', dv01: 4900, limit: 500000 },
              { tenor: '1Y', dv01: 9600, limit: 1000000 },
              { tenor: '2Y', dv01: 18500, limit: 2000000 },
              { tenor: '5Y', dv01: 40900, limit: 5000000 },
              { tenor: '10Y', dv01: 65800, limit: 10000000 },
              { tenor: '30Y', dv01: 28400, limit: 5000000 }
            ].map((bucket) => {
              const util = Math.min(100, (bucket.dv01 / bucket.limit) * 100);
              return (
                <div key={bucket.tenor} className="bg-[#0b0e14] p-1.5 border border-[#182030] flex items-center justify-between gap-3">
                  <span className="w-8 font-bold text-[#38bdf8]">{bucket.tenor}</span>
                  <div className="flex-1 bg-[#151c2a] h-2.5 overflow-hidden">
                    <div style={{ width: `${util * 5}%` }} className="bg-[#38bdf8] h-full"></div>
                  </div>
                  <span className="w-24 text-right font-bold text-[#e6edf3] num">${bucket.dv01.toLocaleString()}</span>
                  <span className="w-16 text-right text-[#8b949e]">{(util * 5).toFixed(1)}%</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Counterparty Credit Exposure (PFE 95%) */}
        <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
            <span>POTENTIAL FUTURE EXPOSURE (PFE 95% ISDA SIMM)</span>
            <span className="text-[#238636]">100% COLLATERALIZED</span>
          </div>

          <div className="space-y-2 text-[11px]">
            {[
              { cp: 'RHINO BANK PLC', rating: 'AA-', limit: 500000000, ead: 18420000, pfe: 42100000 },
              { cp: 'NORTH ATLANTIC SECURITIES', rating: 'A+', limit: 250000000, ead: 9210000, pfe: 21000000 },
              { cp: 'MERIDIAN CAPITAL PARTNERS', rating: 'A', limit: 150000000, ead: 14800000, pfe: 32000000 },
              { cp: 'ALBION MARKETS', rating: 'A-', limit: 200000000, ead: 4500000, pfe: 12000000 }
            ].map((cp, idx) => (
              <div key={idx} className="bg-[#0b0e14] p-2 border border-[#182030] space-y-1">
                <div className="flex justify-between font-bold text-[#e6edf3]">
                  <span>{cp.cp} ({cp.rating})</span>
                  <span className="text-[#38bdf8]">${(cp.limit / 1000000).toFixed(0)}M LIMIT</span>
                </div>
                <div className="flex justify-between text-[10px] text-[#8b949e]">
                  <span>EXPOSURE AT DEFAULT (EAD): <span className="text-[#e6edf3] font-bold num">${(cp.ead / 1000000).toFixed(2)}M</span></span>
                  <span>PFE (95%): <span className="text-[#d29922] font-bold num">${(cp.pfe / 1000000).toFixed(2)}M</span></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
