import React, { useState } from 'react';
import { ContractIR } from '../types';
import { compileContractToCode, CodeGenOutput } from '../quant/contractCompiler';
import { Code, FileCode2, Shield, Copy, Check } from 'lucide-react';

interface ContractsParityViewProps {
  tradeIr?: ContractIR;
}

export const ContractsParityView: React.FC<ContractsParityViewProps> = ({ tradeIr }) => {
  const sampleIr: ContractIR = tradeIr || {
    id: 'IR-2026-009821',
    product: 'InterestRateSwap',
    currency: 'USD',
    notional: 100000000,
    fixedRate: 0.0412,
    floatingIndex: 'SOFR',
    paymentFrequency: 'QUARTERLY',
    effectiveDate: '2026-09-24',
    maturityDate: '2031-09-24',
    dayCount: 'ACT/360',
    settlement: 'CASH',
    collateralAsset: 'USD_CASH',
    marginType: 'BILATERAL',
    counterparty: 'RHINO BANK PLC',
    book: 'RHINO GLOBAL RATES'
  };

  const compiled: CodeGenOutput = compileContractToCode(sampleIr);

  const [activeLang, setActiveLang] = useState<'solidity' | 'rust' | 'typescript' | 'python'>('solidity');
  const [copied, setCopied] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(compiled[activeLang]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Code className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">CONTRACT COMPILER & LEGAL CLAUSE PARITY LINKER</h2>
        </div>
        <div className="text-[10px] text-[#238636] bg-[#238636]/10 px-2 py-0.5 border border-[#238636]/30">
          ISDA CDM COMPLIANT CONTRACT IR
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left Column: Contract Intermediate Representation (IR) + Legal Parity Matrix */}
        <div className="space-y-4">
          <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-2">
            <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
              <span>CANONICAL CONTRACT IR (JSON)</span>
              <span className="text-[#38bdf8]">{sampleIr.id}</span>
            </div>

            <pre className="bg-[#0b0e14] p-3 border border-[#182030] text-[#e6edf3] text-[11px] overflow-x-auto max-h-60 leading-relaxed font-mono">
              {JSON.stringify(sampleIr, null, 2)}
            </pre>
          </div>

          <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-2">
            <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
              <span>LEGAL CLAUSE PARITY MATRIX</span>
              <span className="text-[#238636] text-[10px]">VERIFIED 100% PARITY</span>
            </div>

            <div className="space-y-1.5">
              {compiled.parityClauses.map((item, idx) => (
                <div key={idx} className="bg-[#0b0e14] p-2 border border-[#182030] space-y-1 text-[10px]">
                  <div className="flex justify-between font-bold text-[#38bdf8]">
                    <span>{item.clauseNumber}: {item.clauseTitle}</span>
                    <span className="text-[#238636]">{item.testFunction}</span>
                  </div>
                  <div className="flex justify-between text-[#8b949e]">
                    <span>IR Property: <code className="text-[#e6edf3]">{item.irProperty}</code></span>
                    <span>Exec Rule: <code className="text-[#d29922]">{item.executableRule}</code></span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Code Generator View (Solidity, Rust, TS, Python) */}
        <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <FileCode2 className="w-4 h-4 text-[#38bdf8]" />
                <span>EXECUTABLE SMART CODE GENERATOR</span>
              </div>
              <button
                onClick={handleCopyCode}
                className="px-2 py-0.5 bg-[#162032] hover:bg-[#202d47] text-[#38bdf8] border border-[#2a3c5d] font-bold text-[10px] cursor-pointer flex items-center space-x-1"
              >
                {copied ? <Check className="w-3 h-3 text-[#238636]" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'COPIED' : 'COPY CODE'}</span>
              </button>
            </div>

            <div className="flex space-x-1 border-b border-[#1c2436] pb-2 text-[10px]">
              {[
                { id: 'solidity', label: 'SOLIDITY (EVM)' },
                { id: 'rust', label: 'RUST (WASM / SOLANA)' },
                { id: 'typescript', label: 'TYPESCRIPT (NODE)' },
                { id: 'python', label: 'PYTHON (QUANT)' }
              ].map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => setActiveLang(lang.id as any)}
                  className={`px-2 py-1 font-bold cursor-pointer transition-colors ${
                    activeLang === lang.id
                      ? 'bg-[#1e2a3f] text-[#38bdf8] border border-[#2d3f5e]'
                      : 'text-[#8b949e] hover:text-[#e6edf3] bg-[#111622]'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>

            <pre className="bg-[#0b0e14] p-3 border border-[#182030] text-[#38bdf8] text-[10px] overflow-x-auto max-h-96 leading-relaxed font-mono">
              {compiled[activeLang]}
            </pre>
          </div>

          <div className="p-2 bg-[#121824] border border-[#1d273a] text-[#8b949e] text-[10px]">
            Generated code is deterministically compiled from Contract IR and contains embedded state machine guards and settlement handlers.
          </div>
        </div>
      </div>
    </div>
  );
};
