import React from 'react';
import { AuditEvent } from '../types';
import { ShieldCheck, Lock } from 'lucide-react';

interface AuditViewProps {
  auditLog: AuditEvent[];
}

export const AuditView: React.FC<AuditViewProps> = ({ auditLog }) => {
  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-[#238636]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">CRYPTO-VERIFIED AUDIT LOG & COMPLIANCE TRAIL</h2>
        </div>
        <div className="text-[10px] text-[#238636] bg-[#238636]/10 px-2 py-0.5 border border-[#238636]/30">
          SHA-256 HASH CHAIN INTEGRITY VERIFIED
        </div>
      </div>

      <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
        <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
          <span>EVENT SOURCED SYSTEM AUDIT TRAIL</span>
          <span className="text-[#8b949e] text-[10px]">{auditLog.length} CRYPTOGRAPHIC LOGS</span>
        </div>

        <div className="space-y-2">
          {auditLog.map((log) => (
            <div key={log.id} className="bg-[#0b0e14] p-2.5 border border-[#182030] space-y-1">
              <div className="flex justify-between font-bold text-[#e6edf3]">
                <div className="flex items-center space-x-2">
                  <span className="text-[#38bdf8]">{log.id}</span>
                  <span className="text-[#238636] font-bold">[{log.action}]</span>
                  <span>{log.objectType}: {log.objectId}</span>
                </div>
                <span className="text-[#8b949e] text-[10px]">{log.timestamp}</span>
              </div>
              <div className="flex justify-between text-[10px] text-[#8b949e]">
                <span>User: <span className="text-[#e6edf3] font-semibold">{log.user} ({log.role})</span></span>
                <span>Hash Signature: <code className="text-[#d29922]">{log.signature}</code></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
