import React, { useState } from 'react';
import { Trade } from '../types';
import { Briefcase, TrendingUp, DollarSign, Activity, PieChart } from 'lucide-react';

interface PositionBookViewProps {
  trades: Trade[];
}

export const PositionBookView: React.FC<PositionBookViewProps> = ({ trades }) => {
  const [selectedBook, setSelectedBook] = useState<string>('ALL');

  const filteredTrades = selectedBook === 'ALL'
    ? trades
    : trades.filter(t => t.book === selectedBook);

  const totalNotional = filteredTrades.reduce((acc, t) => acc + t.notional, 0);
  const totalMtm = filteredTrades.reduce((acc, t) => acc + t.mtm, 0);
  const totalPnl = filteredTrades.reduce((acc, t) => acc + t.pnl, 0);
  const totalDv01 = filteredTrades.reduce((acc, t) => acc + (t.greeks?.dv01 || 0), 0);
  const totalMargin = filteredTrades.reduce((acc, t) => acc + (t.initialMargin || 0), 0);

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Top Book Selector Bar */}
      <div className="bg-[#0f141d] border border-[#1c2436] p-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <Briefcase className="w-4 h-4 text-[#38bdf8]" />
          <span className="font-bold text-[#e6edf3] uppercase text-xs">PORTFOLIO POSITION BOOK:</span>
          {['ALL', 'RHINO GLOBAL RATES', 'RHINO FX OPTIONS', 'RHINO EQUITY DERIVATIVES'].map((b) => (
            <button
              key={b}
              onClick={() => setSelectedBook(b)}
              className={`px-2.5 py-1 text-[10px] font-bold cursor-pointer transition-colors ${
                selectedBook === b
                  ? 'bg-[#1e2a3f] text-[#38bdf8] border border-[#2d3f5e]'
                  : 'text-[#8b949e] hover:text-[#e6edf3] bg-[#111622] border border-transparent'
              }`}
            >
              {b}
            </button>
          ))}
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5 space-y-1">
          <div className="text-[10px] text-[#8b949e] uppercase font-bold">GROSS NOTIONAL</div>
          <div className="text-sm font-bold text-[#e6edf3] num">${(totalNotional / 1000000).toFixed(0)}M</div>
          <div className="text-[9px] text-[#8b949e]">Across {filteredTrades.length} positions</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5 space-y-1">
          <div className="text-[10px] text-[#8b949e] uppercase font-bold">MARKET VALUE (MTM)</div>
          <div className="text-sm font-bold text-[#38bdf8] num">${totalMtm.toLocaleString()}</div>
          <div className="text-[9px] text-[#238636]">Revalued live against SOFR curve</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5 space-y-1">
          <div className="text-[10px] text-[#8b949e] uppercase font-bold">INTRADAY P&L</div>
          <div className={`text-sm font-bold num ${totalPnl >= 0 ? 'text-[#238636]' : 'text-[#da3633]'}`}>
            {totalPnl >= 0 ? '+' : ''}${totalPnl.toLocaleString()}
          </div>
          <div className="text-[9px] text-[#8b949e]">Unrealized MTM gain</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5 space-y-1">
          <div className="text-[10px] text-[#8b949e] uppercase font-bold">PORTFOLIO DV01</div>
          <div className="text-sm font-bold text-[#d29922] num">${totalDv01.toLocaleString()}/bp</div>
          <div className="text-[9px] text-[#8b949e]">Rate sensitivity profile</div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-2.5 space-y-1">
          <div className="text-[10px] text-[#8b949e] uppercase font-bold">INITIAL MARGIN (IM)</div>
          <div className="text-sm font-bold text-[#e6edf3] num">${(totalMargin / 1000000).toFixed(2)}M</div>
          <div className="text-[9px] text-[#238636]">100% Pledged & Collateralized</div>
        </div>
      </div>

      {/* Main Grid: Position Table + P&L Attribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Positions Table (Spans 2 cols) */}
        <div className="lg:col-span-2 bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between items-center">
            <span>ACTIVE POSITIONS SUMMARY</span>
            <span className="text-[10px] text-[#38bdf8] bg-[#38bdf8]/10 px-2 py-0.5 border border-[#38bdf8]/30">REAL-TIME RISK ENGINE</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11px] whitespace-nowrap">
              <thead>
                <tr className="text-[#8b949e] border-b border-[#1c2436] bg-[#0b0e14]">
                  <th className="py-2 px-2 font-bold">TRADE ID</th>
                  <th className="py-2 px-2 font-bold">PRODUCT</th>
                  <th className="py-2 px-2 font-bold text-right">NOTIONAL</th>
                  <th className="py-2 px-2 font-bold text-right">MTM ($)</th>
                  <th className="py-2 px-2 font-bold text-right">DV01 ($/bp)</th>
                  <th className="py-2 px-2 font-bold text-right">DELTA</th>
                  <th className="py-2 px-2 font-bold text-right">VEGA</th>
                  <th className="py-2 px-2 font-bold">COUNTERPARTY</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#151c2a]">
                {filteredTrades.map((t) => (
                  <tr key={t.id} className="hover:bg-[#161e2e]">
                    <td className="py-2 px-2 font-bold text-[#38bdf8]">{t.id}</td>
                    <td className="py-2 px-2 text-[#e6edf3]">{t.product} ({t.underlyingSymbol})</td>
                    <td className="py-2 px-2 text-right font-bold text-[#e6edf3] num">${(t.notional / 1000000).toFixed(0)}M</td>
                    <td className="py-2 px-2 text-right font-bold text-[#38bdf8] num">${t.mtm.toLocaleString()}</td>
                    <td className="py-2 px-2 text-right text-[#d29922] font-bold num">${t.greeks?.dv01?.toLocaleString() || 0}</td>
                    <td className="py-2 px-2 text-right text-[#8b949e] num">{t.greeks?.delta?.toFixed(2) || '0.00'}</td>
                    <td className="py-2 px-2 text-right text-[#8b949e] num">{t.greeks?.vega?.toFixed(0) || '0'}</td>
                    <td className="py-2 px-2 text-[#8b949e]">{t.counterparty}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: P&L Attribution Breakdown */}
        <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex items-center space-x-2">
            <PieChart className="w-4 h-4 text-[#38bdf8]" />
            <span>P&L ATTRIBUTION BREAKDOWN</span>
          </div>

          <p className="text-[10px] text-[#8b949e]">
            Quantitative attribution explains exactly why portfolio P&L shifted during the simulation window:
          </p>

          <div className="space-y-2 text-[11px]">
            <div className="flex justify-between items-center bg-[#0b0e14] p-2 border border-[#182030]">
              <span className="text-[#8b949e]">CURVE SHIFT (RATES):</span>
              <span className="text-[#238636] font-bold num">+$1,120,400</span>
            </div>
            <div className="flex justify-between items-center bg-[#0b0e14] p-2 border border-[#182030]">
              <span className="text-[#8b949e]">VOLATILITY REVALUATION:</span>
              <span className="text-[#238636] font-bold num">+$340,120</span>
            </div>
            <div className="flex justify-between items-center bg-[#0b0e14] p-2 border border-[#182030]">
              <span className="text-[#8b949e]">CARRY & TIME DECAY (THETA):</span>
              <span className="text-[#da3633] font-bold num">-$42,100</span>
            </div>
            <div className="flex justify-between items-center bg-[#0b0e14] p-2 border border-[#182030]">
              <span className="text-[#8b949e]">FX SPOT MOVEMENT:</span>
              <span className="text-[#238636] font-bold num">+$180,200</span>
            </div>
            <div className="flex justify-between items-center bg-[#0b0e14] p-2 border border-[#182030]">
              <span className="text-[#8b949e]">NEW TRADES EXECUTED:</span>
              <span className="text-[#38bdf8] font-bold num">$0</span>
            </div>
            <div className="flex justify-between items-center bg-[#131b28] p-2 border border-[#23324a] font-bold">
              <span className="text-[#e6edf3]">NET TOTAL P&L:</span>
              <span className="text-[#238636] text-xs num">+${(totalPnl > 0 ? totalPnl : 1598620).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
