import React from 'react';

export type MainTab = 
  | 'MARKETS'
  | 'TRADE'
  | 'BOOK'
  | 'PRICING'
  | 'RISK'
  | 'MARGIN'
  | 'COLLATERAL'
  | 'LIFECYCLE'
  | 'EXECUTION'
  | 'CONTRACTS'
  | 'QUANTS'
  | 'SIMULATION'
  | 'SURVEILLANCE'
  | 'CLEARING'
  | 'REPORTING'
  | 'AUDIT';

export type SecondaryTab = 
  | 'PRODUCTS'
  | 'CURVES'
  | 'VOLATILITY'
  | 'COUNTERPARTIES'
  | 'ACCOUNTS'
  | 'VENUES'
  | 'REFERENCE DATA'
  | 'MODELS'
  | 'SCENARIOS'
  | 'SETTINGS';

interface PrimaryNavProps {
  activeTab: MainTab;
  setActiveTab: (tab: MainTab) => void;
  activeSecondaryTab: SecondaryTab | null;
  setActiveSecondaryTab: (tab: SecondaryTab | null) => void;
}

const PRIMARY_TABS: MainTab[] = [
  'MARKETS',
  'TRADE',
  'BOOK',
  'PRICING',
  'RISK',
  'MARGIN',
  'COLLATERAL',
  'LIFECYCLE',
  'EXECUTION',
  'CONTRACTS',
  'QUANTS',
  'SIMULATION',
  'SURVEILLANCE',
  'CLEARING',
  'REPORTING',
  'AUDIT'
];

const SECONDARY_TABS: SecondaryTab[] = [
  'PRODUCTS',
  'CURVES',
  'VOLATILITY',
  'COUNTERPARTIES',
  'ACCOUNTS',
  'VENUES',
  'REFERENCE DATA',
  'MODELS',
  'SCENARIOS',
  'SETTINGS'
];

export const PrimaryNav: React.FC<PrimaryNavProps> = ({
  activeTab,
  setActiveTab,
  activeSecondaryTab,
  setActiveSecondaryTab
}) => {
  return (
    <nav className="bg-[#0e1219] border-b border-[#1c2331] font-mono text-xs select-none">
      {/* Primary Navigation */}
      <div className="flex items-center space-x-1 px-2 overflow-x-auto no-scrollbar py-1">
        {PRIMARY_TABS.map((tab) => {
          const isActive = activeTab === tab && activeSecondaryTab === null;
          return (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                setActiveSecondaryTab(null);
              }}
              className={`px-2.5 py-1 text-[11px] font-bold tracking-tight transition-all cursor-pointer whitespace-nowrap border ${
                isActive
                  ? 'bg-[#182232] border-[#2e3e5c] text-[#38bdf8] shadow-[0_0_8px_rgba(56,189,248,0.15)]'
                  : 'bg-[#11151e] border-transparent text-[#8b949e] hover:text-[#e6edf3] hover:bg-[#161c28]'
              }`}
            >
              {tab}
            </button>
          );
        })}
      </div>

      {/* Secondary Navigation */}
      <div className="flex items-center space-x-1 px-2 py-0.5 bg-[#0a0d13] border-t border-[#151b26] overflow-x-auto no-scrollbar text-[10px]">
        <span className="text-[#8b949e] font-semibold uppercase px-1.5 py-0.5">REF DATA & MODELS:</span>
        {SECONDARY_TABS.map((stab) => {
          const isSecActive = activeSecondaryTab === stab;
          return (
            <button
              key={stab}
              onClick={() => setActiveSecondaryTab(stab)}
              className={`px-2 py-0.5 font-medium transition-all cursor-pointer whitespace-nowrap ${
                isSecActive
                  ? 'bg-[#1e293b] text-[#38bdf8] border border-[#334155]'
                  : 'text-[#8b949e] hover:text-[#e6edf3] hover:bg-[#131822]'
              }`}
            >
              {stab}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
