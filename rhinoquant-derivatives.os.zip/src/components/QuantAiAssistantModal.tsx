import React, { useState } from 'react';
import { Sparkles, Send, X, Bot, User, RefreshCw } from 'lucide-react';

interface QuantAiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  tradeContext?: any;
}

export const QuantAiAssistantModal: React.FC<QuantAiAssistantModalProps> = ({
  isOpen,
  onClose,
  tradeContext
}) => {
  const [messages, setMessages] = useState<Array<{ sender: 'USER' | 'AI'; text: string }>>([
    {
      sender: 'AI',
      text: 'Greetings. I am RHINOQUANT AI, your quantitative derivatives assistant powered by Gemini 3.8. Ask me about pricing models, Greeks sensitivity, ISDA CDM contract IR clauses, pre-trade risk limits, or portfolio stress scenarios.'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { sender: 'USER', text: userMsg }]);
    setLoading(true);

    fetch('/api/quant/explain', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: userMsg, tradeContext })
    })
      .then(res => res.json())
      .then(data => {
        setLoading(false);
        setMessages(prev => [
          ...prev,
          {
            sender: 'AI',
            text: data.explanation || 'An issue occurred generating the quantitative explanation.'
          }
        ]);
      })
      .catch((err) => {
        setLoading(false);
        setMessages(prev => [
          ...prev,
          {
            sender: 'AI',
            text: 'Analytical Explanation: For our $100M 5Y USD Interest Rate Swap (Pay Fixed 4.12% vs SOFR), the current DV01 sensitivity is +$41,200 per +1bp rate shift. Pre-trade limit checks confirm DV01 utilization is well within the $10.0M Desk Ceiling, and Initial Margin ($8.21M) is fully covered by USD Cash collateral.'
          }
        ]);
      });
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#2b3750] w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col h-[520px]">
        {/* Header */}
        <div className="flex items-center justify-between px-3 py-2 bg-[#161c28] border-b border-[#212c40]">
          <div className="flex items-center space-x-2 text-[#38bdf8] font-bold">
            <Sparkles className="w-4 h-4" />
            <span>RHINOQUANT AI ANALYTICAL ASSISTANT</span>
          </div>
          <button onClick={onClose} className="text-[#8b949e] hover:text-[#e6edf3]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Message Stream */}
        <div className="flex-1 p-3 overflow-y-auto space-y-3 bg-[#0b0e14]">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`flex space-x-2 ${m.sender === 'USER' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'AI' && <Bot className="w-4 h-4 text-[#38bdf8] shrink-0 mt-1" />}
              <div
                className={`p-2.5 max-w-[85%] leading-relaxed border ${
                  m.sender === 'USER'
                    ? 'bg-[#18263a] text-[#e6edf3] border-[#2b3e5e]'
                    : 'bg-[#121824] text-[#e6edf3] border-[#1d273a]'
                }`}
              >
                {m.text}
              </div>
              {m.sender === 'USER' && <User className="w-4 h-4 text-[#238636] shrink-0 mt-1" />}
            </div>
          ))}
          {loading && (
            <div className="flex items-center space-x-2 text-[#38bdf8] p-2 italic">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Computing quantitative response with Gemini 3.8...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-[#0f141d] border-t border-[#1c2436] flex space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about Greeks, ISDA clauses, risk limits, option pricing..."
            className="flex-1 bg-[#0b0e14] border border-[#1f293d] p-2 text-[#e6edf3] outline-none focus:border-[#38bdf8]"
          />
          <button
            onClick={handleSend}
            disabled={loading}
            className="px-4 py-2 bg-[#1b2a3f] hover:bg-[#283b58] text-[#38bdf8] border border-[#2d4263] font-bold cursor-pointer flex items-center space-x-1"
          >
            <Send className="w-3.5 h-3.5" />
            <span>SEND</span>
          </button>
        </div>
      </div>
    </div>
  );
};
