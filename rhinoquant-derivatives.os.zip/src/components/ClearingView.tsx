import React from 'react';
import { Layers, CheckCircle } from 'lucide-react';

export const ClearingView: React.FC = () => {
  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Layers className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">CENTRAL COUNTERPARTY (CCP) CLEARING & SETTLEMENT</h2>
        </div>
        <span className="text-[10px] text-[#238636] bg-[#238636]/10 px-2 py-0.5 border border-[#238636]/30">
          LCH SwapClear / CME Clearing Synchronized
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-2">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2">CCP DEFAULT FUND & MARGIN POOL</div>
          <div className="space-y-2">
            <div className="bg-[#0b0e14] p-2 border border-[#182030] flex justify-between">
              <span className="text-[#8b949e]">TOTAL CCP CLEARED NOTIONAL:</span>
              <span className="text-[#38bdf8] font-bold num">$200,000,000</span>
            </div>
            <div className="bg-[#0b0e14] p-2 border border-[#182030] flex justify-between">
              <span className="text-[#8b949e]">CCP INITIAL MARGIN (IM):</span>
              <span className="text-[#e6edf3] font-bold num">$12,000,000</span>
            </div>
            <div className="bg-[#0b0e14] p-2 border border-[#182030] flex justify-between">
              <span className="text-[#8b949e]">DEFAULT FUND CONTRIBUTION:</span>
              <span className="text-[#238636] font-bold num">$2,500,000</span>
            </div>
          </div>
        </div>

        <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-2">
          <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2">BILATERAL OTC VS CLEARED RATIO</div>
          <div className="space-y-2">
            <div className="bg-[#0b0e14] p-2 border border-[#182030] flex justify-between">
              <span className="text-[#8b949e]">CLEARED TRADES (CCP):</span>
              <span className="text-[#238636] font-bold num">50.0% ($200M)</span>
            </div>
            <div className="bg-[#0b0e14] p-2 border border-[#182030] flex justify-between">
              <span className="text-[#8b949e]">BILATERAL OTC (ISDA CSA):</span>
              <span className="text-[#38bdf8] font-bold num">50.0% ($200M)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
