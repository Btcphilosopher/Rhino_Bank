import React from 'react';
import { SurveillanceAlert } from '../types';
import { Eye, AlertTriangle, ShieldCheck } from 'lucide-react';

interface SurveillanceViewProps {
  alerts: SurveillanceAlert[];
}

export const SurveillanceView: React.FC<SurveillanceViewProps> = ({ alerts }) => {
  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Eye className="w-4 h-4 text-[#d29922]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">MARKET SURVEILLANCE & ALGORITHMIC CONTROLS</h2>
        </div>
        <div className="text-[10px] text-[#238636] bg-[#238636]/10 px-2 py-0.5 border border-[#238636]/30">
          AUTOMATED COMPLIANCE MONITORING ACTIVE
        </div>
      </div>

      <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-3">
        <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
          <span>SURVEILLANCE ALERTS LOG</span>
          <span className="text-[#8b949e] text-[10px]">{alerts.length} ALERTS RECORDED</span>
        </div>

        <div className="space-y-2">
          {alerts.map((al) => (
            <div key={al.id} className="bg-[#0b0e14] p-2.5 border border-[#182030] flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className={`px-1.5 py-0.5 text-[9px] font-bold border ${
                  al.severity === 'HIGH' ? 'bg-[#da3633]/20 text-[#da3633] border-[#da3633]/40' : 'bg-[#d29922]/20 text-[#d29922] border-[#d29922]/40'
                }`}>
                  {al.severity}
                </span>
                <div>
                  <div className="font-bold text-[#e6edf3]">{al.alertType}: {al.description}</div>
                  <div className="text-[10px] text-[#8b949e]">Trade Ref: {al.tradeId || 'SYSTEM_GLOBAL'}</div>
                </div>
              </div>
              <span className="text-[#8b949e] text-[10px]">{al.timestamp}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
