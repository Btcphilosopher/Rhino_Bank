import React, { useState } from 'react';
import { ProductType, TradeDirection, PreTradeCheckResult, Counterparty } from '../types';
import { ShieldCheck, Zap, AlertCircle, CheckCircle2, DollarSign, Calculator } from 'lucide-react';

interface TradeTicketViewProps {
  counterparties: Counterparty[];
  onExecuteTrade: (tradeData: any) => void;
  selectedAssetForTrade?: any;
}

export const TradeTicketView: React.FC<TradeTicketViewProps> = ({
  counterparties,
  onExecuteTrade,
  selectedAssetForTrade
}) => {
  const [product, setProduct] = useState<ProductType>(
    selectedAssetForTrade?.assetClass === 'FX' ? 'FXOption' : 'InterestRateSwap'
  );
  const [direction, setDirection] = useState<TradeDirection>('PAY_FIXED');
  const [notional, setNotional] = useState<number>(100000000); // $100M
  const [currency, setCurrency] = useState<string>('USD');
  const [tenor, setTenor] = useState<string>('5Y');
  const [fixedRate, setFixedRate] = useState<number>(4.1200); // %
  const [strike, setStrike] = useState<number>(1.1800);
  const [counterparty, setCounterparty] = useState<string>('RHINO BANK PLC');
  const [collateral, setCollateral] = useState<string>('USD_CASH');
  const [marginType, setMarginType] = useState<string>('BILATERAL');

  // Pre-trade checks state
  const [preTradeCheck, setPreTradeCheck] = useState<PreTradeCheckResult | null>(null);
  const [isCheckingRisk, setIsCheckingRisk] = useState<boolean>(false);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [quotes, setQuotes] = useState<any[]>([]);

  const handleRunPreTradeCheck = () => {
    setIsCheckingRisk(true);
    setTimeout(() => {
      setIsCheckingRisk(false);
      setPreTradeCheck({
        limitCheck: 'PASS',
        counterpartyCheck: 'PASS',
        liquidityCheck: 'PASS',
        marginCheck: 'PASS',
        collateralCheck: 'PASS',
        modelCheck: 'PASS',
        complianceCheck: 'PASS',
        overall: true,
        notes: [
          `DV01 Impact: +$41,200/bp within $10.0M Desk Limit`,
          `Counterparty Exposure: $18.42M / $500M Ceiling`,
          `Initial Margin Requirement: $8,210,000 (ISDA SIMM v2.5)`,
          `Collateral Asset Eligibility: USD CASH (100% Eligible, 0% Haircut)`
        ]
      });
    }, 600);
  };

  const handleRequestQuotes = () => {
    fetch('/api/quotes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product, notional, currency, direction })
    })
      .then(res => res.json())
      .then(data => {
        if (data.quotes) setQuotes(data.quotes);
      })
      .catch(() => {
        setQuotes([
          { provider: 'RHINO BANK PLC', bid: 0.0412, ask: 0.0415, size: notional, quoteAgeMs: 90 },
          { provider: 'ALBION MARKETS', bid: 0.0411, ask: 0.0413, size: notional, quoteAgeMs: 45 },
          { provider: 'MERIDIAN CAPITAL', bid: 0.0413, ask: 0.0417, size: notional, quoteAgeMs: 110 }
        ]);
      });
  };

  const handleExecute = () => {
    if (!preTradeCheck) {
      handleRunPreTradeCheck();
      return;
    }
    setIsExecuting(true);
    setTimeout(() => {
      setIsExecuting(false);
      onExecuteTrade({
        product,
        direction,
        notional,
        currency,
        tenor,
        fixedRate: fixedRate / 100,
        strike,
        counterparty,
        collateral,
        marginType,
        underlyingSymbol: product === 'FXOption' ? 'EUR/USD' : 'SOFR',
        effectiveDate: new Date().toISOString().split('T')[0],
        maturityDate: '2031-09-22',
        executionPrice: fixedRate / 100
      });
    }, 500);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Zap className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">INSTITUTIONAL TRADE TICKET & EXECUTION VENUE</h2>
        </div>
        <div className="text-[10px] text-[#8b949e]">
          PRE-TRADE LIMIT CHECK ENGINE: <span className="text-[#238636] font-bold">READY</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Trade Specification Form */}
        <div className="lg:col-span-2 bg-[#0f141d] border border-[#1c2436] p-4 space-y-4">
          <div className="text-[11px] font-bold text-[#38bdf8] pb-1 border-b border-[#1c2436] uppercase tracking-wider">
            1. CONTRACTUAL & ECONOMIC PRODUCT SPECIFICATION
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[#8b949e] mb-1 text-[10px]">PRODUCT TYPE</label>
              <select
                value={product}
                onChange={(e) => setProduct(e.target.value as ProductType)}
                className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none"
              >
                <option value="InterestRateSwap">Interest Rate Swap (IRS)</option>
                <option value="OIS">Overnight Indexed Swap (OIS)</option>
                <option value="FXOption">FX European Option</option>
                <option value="FXForward">FX Forward</option>
                <option value="EquityFuture">Equity Future</option>
                <option value="CDS">Credit Default Swap (CDS)</option>
              </select>
            </div>

            <div>
              <label className="block text-[#8b949e] mb-1 text-[10px]">DIRECTION</label>
              <select
                value={direction}
                onChange={(e) => setDirection(e.target.value as TradeDirection)}
                className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none"
              >
                <option value="PAY_FIXED">PAY FIXED / RECEIVE SOFR</option>
                <option value="RECEIVE_FIXED">RECEIVE FIXED / PAY SOFR</option>
                <option value="BUY">BUY / LONG</option>
                <option value="SELL">SELL / SHORT</option>
              </select>
            </div>

            <div>
              <label className="block text-[#8b949e] mb-1 text-[10px]">NOTIONAL AMOUNT ($)</label>
              <input
                type="number"
                value={notional}
                onChange={(e) => setNotional(Number(e.target.value))}
                className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none font-mono num"
              />
            </div>

            <div>
              <label className="block text-[#8b949e] mb-1 text-[10px]">CURRENCY</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none"
              >
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="GBP">GBP</option>
                <option value="JPY">JPY</option>
                <option value="CHF">CHF</option>
              </select>
            </div>

            <div>
              <label className="block text-[#8b949e] mb-1 text-[10px]">TENOR / MATURITY</label>
              <select
                value={tenor}
                onChange={(e) => setTenor(e.target.value)}
                className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none"
              >
                <option value="1Y">1Y (Maturity 2027-09-22)</option>
                <option value="2Y">2Y (Maturity 2028-09-22)</option>
                <option value="5Y">5Y (Maturity 2031-09-22)</option>
                <option value="10Y">10Y (Maturity 2036-09-22)</option>
                <option value="30Y">30Y (Maturity 2056-09-22)</option>
              </select>
            </div>

            {product === 'InterestRateSwap' || product === 'OIS' ? (
              <div>
                <label className="block text-[#8b949e] mb-1 text-[10px]">FIXED RATE (%)</label>
                <input
                  type="number"
                  step="0.001"
                  value={fixedRate}
                  onChange={(e) => setFixedRate(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none num"
                />
              </div>
            ) : (
              <div>
                <label className="block text-[#8b949e] mb-1 text-[10px]">STRIKE PRICE</label>
                <input
                  type="number"
                  step="0.0001"
                  value={strike}
                  onChange={(e) => setStrike(Number(e.target.value))}
                  className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none num"
                />
              </div>
            )}
          </div>

          <div className="text-[11px] font-bold text-[#38bdf8] pt-2 pb-1 border-b border-[#1c2436] uppercase tracking-wider">
            2. COUNTERPARTY, MARGIN & COLLATERAL TERMS
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[#8b949e] mb-1 text-[10px]">COUNTERPARTY</label>
              <select
                value={counterparty}
                onChange={(e) => setCounterparty(e.target.value)}
                className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none"
              >
                {counterparties.map(cp => (
                  <option key={cp.id} value={cp.name}>{cp.name} ({cp.rating})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[#8b949e] mb-1 text-[10px]">COLLATERAL ASSET</label>
              <select
                value={collateral}
                onChange={(e) => setCollateral(e.target.value)}
                className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none"
              >
                <option value="USD_CASH">USD CASH (0% Haircut)</option>
                <option value="US_TREASURIES">US TREASURIES (2% Haircut)</option>
                <option value="UK_GILTS">UK GILTS (3% Haircut)</option>
                <option value="GERMAN_BUNDS">GERMAN BUND (2.5% Haircut)</option>
              </select>
            </div>

            <div>
              <label className="block text-[#8b949e] mb-1 text-[10px]">MARGIN REGIME</label>
              <select
                value={marginType}
                onChange={(e) => setMarginType(e.target.value)}
                className="w-full bg-[#0b0e14] border border-[#1f293d] text-[#e6edf3] p-1.5 focus:border-[#38bdf8] outline-none"
              >
                <option value="BILATERAL">BILATERAL (ISDA SIMM v2.5)</option>
                <option value="CLEARED">CLEARED (LCH / CME CCP)</option>
              </select>
            </div>
          </div>

          {/* Quote Request & Pre-trade Risk Buttons */}
          <div className="flex flex-wrap gap-2 pt-2">
            <button
              onClick={handleRequestQuotes}
              className="px-3 py-2 bg-[#162032] hover:bg-[#202d47] text-[#38bdf8] border border-[#2b3d60] font-bold cursor-pointer flex items-center space-x-1.5"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>REQUEST MARKET QUOTES</span>
            </button>

            <button
              onClick={handleRunPreTradeCheck}
              className="px-3 py-2 bg-[#1b2a20] hover:bg-[#253d2d] text-[#238636] border border-[#2e5239] font-bold cursor-pointer flex items-center space-x-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>RUN PRE-TRADE RISK CHECK</span>
            </button>
          </div>

          {/* Quotes Matrix Table */}
          {quotes.length > 0 && (
            <div className="bg-[#0b0e14] p-3 border border-[#1c2436] space-y-2">
              <div className="text-[10px] text-[#38bdf8] font-bold uppercase">LIVE SYNTHETIC MARKET MAKER QUOTES</div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[10px]">
                  <thead>
                    <tr className="text-[#8b949e] border-b border-[#182030]">
                      <th className="py-1">MARKET MAKER</th>
                      <th className="py-1 text-right">BID RATE</th>
                      <th className="py-1 text-right">ASK RATE</th>
                      <th className="py-1 text-right">SPREAD (BP)</th>
                      <th className="py-1 text-right">LATENCY</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#121824]">
                    {quotes.map((q, idx) => (
                      <tr key={idx} className="hover:bg-[#121824]">
                        <td className="py-1 font-bold text-[#e6edf3]">{q.provider}</td>
                        <td className="py-1 text-right text-[#238636] font-bold num">{(q.bid * 100).toFixed(3)}%</td>
                        <td className="py-1 text-right text-[#38bdf8] font-bold num">{(q.ask * 100).toFixed(3)}%</td>
                        <td className="py-1 text-right text-[#8b949e] num">{((q.ask - q.bid) * 10000).toFixed(1)}</td>
                        <td className="py-1 text-right text-[#8b949e]">{q.quoteAgeMs}ms</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Pre-Trade Risk Verification & Execution Panel */}
        <div className="bg-[#0f141d] border border-[#1c2436] p-4 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="text-[11px] font-bold text-[#38bdf8] pb-1 border-b border-[#1c2436] uppercase tracking-wider flex items-center justify-between">
              <span>PRE-TRADE CHECK STATUS</span>
              <span className={`text-[10px] px-1.5 py-0.5 ${preTradeCheck?.overall ? 'bg-[#238636]/20 text-[#238636] border border-[#238636]/40' : 'bg-[#d29922]/20 text-[#d29922]'}`}>
                {preTradeCheck ? 'PASSED' : 'UNVERIFIED'}
              </span>
            </div>

            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between items-center bg-[#0b0e14] p-1.5 border border-[#182030]">
                <span className="text-[#8b949e]">DESK DV01 LIMIT</span>
                <span className="text-[#238636] font-bold flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>PASS ($41.2K / $10M)</span>
                </span>
              </div>
              <div className="flex justify-between items-center bg-[#0b0e14] p-1.5 border border-[#182030]">
                <span className="text-[#8b949e]">COUNTERPARTY LIMIT</span>
                <span className="text-[#238636] font-bold flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>PASS ($18.4M / $500M)</span>
                </span>
              </div>
              <div className="flex justify-between items-center bg-[#0b0e14] p-1.5 border border-[#182030]">
                <span className="text-[#8b949e]">LIQUIDITY CHECK</span>
                <span className="text-[#238636] font-bold flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>PASS (HIGH)</span>
                </span>
              </div>
              <div className="flex justify-between items-center bg-[#0b0e14] p-1.5 border border-[#182030]">
                <span className="text-[#8b949e]">INITIAL MARGIN CHECK</span>
                <span className="text-[#238636] font-bold flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>PASS ($8.21M REQUIREMENT)</span>
                </span>
              </div>
              <div className="flex justify-between items-center bg-[#0b0e14] p-1.5 border border-[#182030]">
                <span className="text-[#8b949e]">COLLATERAL ELIGIBILITY</span>
                <span className="text-[#238636] font-bold flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>PASS (USD CASH)</span>
                </span>
              </div>
              <div className="flex justify-between items-center bg-[#0b0e14] p-1.5 border border-[#182030]">
                <span className="text-[#8b949e]">PRICING MODEL</span>
                <span className="text-[#238636] font-bold flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>PASS (RHINO-ZERO-DCF v1.4)</span>
                </span>
              </div>
            </div>

            {preTradeCheck?.notes && (
              <div className="bg-[#0b0e14] p-2 border border-[#182030] space-y-1 text-[10px] text-[#8b949e]">
                <div className="font-bold text-[#38bdf8] uppercase">CHECK NOTES:</div>
                {preTradeCheck.notes.map((note, i) => (
                  <div key={i} className="text-[#e6edf3]">· {note}</div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-[#1c2436] space-y-2">
            <button
              disabled={isExecuting}
              onClick={handleExecute}
              className={`w-full py-3 font-bold text-sm tracking-wider uppercase transition-all cursor-pointer flex items-center justify-center space-x-2 border ${
                preTradeCheck
                  ? 'bg-[#238636] hover:bg-[#2ea043] text-[#ffffff] border-[#3fb950] shadow-[0_0_12px_rgba(35,134,54,0.4)]'
                  : 'bg-[#1b2433] hover:bg-[#253247] text-[#38bdf8] border-[#2f3d57]'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>{isExecuting ? 'EXECUTING TRADE...' : preTradeCheck ? 'EXECUTE DERIVATIVE TRADE' : 'RUN RISK & EXECUTE'}</span>
            </button>
            <p className="text-[10px] text-center text-[#8b949e]">
              Execution generates immutable event log, updates position book, and triggers ISDA Contract IR state machine.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
