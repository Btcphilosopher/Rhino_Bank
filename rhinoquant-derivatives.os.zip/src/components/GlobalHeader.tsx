import React, { useState, useEffect } from 'react';
import { Activity, ShieldCheck, Cpu, Terminal as TerminalIcon, Sparkles, AlertTriangle, Layers } from 'lucide-react';

interface GlobalHeaderProps {
  onOpenCommandPalette: () => void;
  onOpenAiAssistant: () => void;
  terminalMode: boolean;
  setTerminalMode: (val: boolean) => void;
  simulatedTime: string;
  simulatedDate: string;
}

export const GlobalHeader: React.FC<GlobalHeaderProps> = ({
  onOpenCommandPalette,
  onOpenAiAssistant,
  terminalMode,
  setTerminalMode,
  simulatedTime,
  simulatedDate
}) => {
  return (
    <header className="bg-[#0b0e14] border-b border-[#1c2331] text-xs font-mono select-none sticky top-0 z-40">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between px-3 py-1.5 bg-[#080a0e] border-b border-[#161c27]">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 font-bold tracking-wider text-[#e6edf3]">
            <span className="w-2.5 h-2.5 bg-[#38bdf8] rounded-none inline-block"></span>
            <span className="text-[#38bdf8] font-black tracking-widest text-sm">RHINOQUANT</span>
            <span className="text-[#8b949e] font-light">DERIVATIVES.OS</span>
          </div>

          <span className="text-[#212836]">|</span>

          <div className="flex items-center space-x-1 bg-[#121722] px-2 py-0.5 border border-[#1e2738]">
            <span className="text-[#8b949e]">STATUS:</span>
            <span className="text-[#238636] font-semibold">OPEN</span>
            <span className="w-1.5 h-1.5 bg-[#238636] rounded-full animate-pulse ml-1"></span>
          </div>

          <div className="hidden sm:flex items-center space-x-2 text-[#8b949e]">
            <span>CLOCK: <span className="text-[#e6edf3] font-semibold">{simulatedTime}</span></span>
            <span>DATE: <span className="text-[#e6edf3] font-semibold">{simulatedDate}</span></span>
            <span className="text-[#38bdf8] text-[10px] bg-[#38bdf8]/10 px-1 border border-[#38bdf8]/30">SIMULATED MARKET</span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* Engine Indicators */}
          <div className="hidden md:flex items-center space-x-2 text-[10px] text-[#8b949e]">
            <div className="flex items-center space-x-1 bg-[#0f141d] px-1.5 py-0.5 border border-[#1a2232]">
              <span className="w-1 h-1 bg-[#238636] rounded-full"></span>
              <span>RISK</span>
            </div>
            <div className="flex items-center space-x-1 bg-[#0f141d] px-1.5 py-0.5 border border-[#1a2232]">
              <span className="w-1 h-1 bg-[#238636] rounded-full"></span>
              <span>PRICING</span>
            </div>
            <div className="flex items-center space-x-1 bg-[#0f141d] px-1.5 py-0.5 border border-[#1a2232]">
              <span className="w-1 h-1 bg-[#238636] rounded-full"></span>
              <span>MARGIN</span>
            </div>
            <div className="flex items-center space-x-1 bg-[#0f141d] px-1.5 py-0.5 border border-[#1a2232]">
              <span className="w-1 h-1 bg-[#238636] rounded-full"></span>
              <span>COLLATERAL</span>
            </div>
          </div>

          <button
            onClick={onOpenAiAssistant}
            className="flex items-center space-x-1 bg-[#1a2234] hover:bg-[#232e47] text-[#38bdf8] px-2 py-0.5 border border-[#2d3b59] transition-colors cursor-pointer"
          >
            <Sparkles className="w-3 h-3" />
            <span>QUANT AI</span>
          </button>

          <button
            onClick={onOpenCommandPalette}
            className="flex items-center space-x-1 bg-[#111622] hover:bg-[#182030] text-[#8b949e] px-2 py-0.5 border border-[#1c2436] transition-colors cursor-pointer"
          >
            <TerminalIcon className="w-3 h-3 text-[#38bdf8]" />
            <span>CMD <kbd className="text-[9px] bg-[#1a2232] px-1 border border-[#2b3750] text-[#e6edf3]">CTRL+K</kbd></span>
          </button>

          <button
            onClick={() => setTerminalMode(!terminalMode)}
            className={`px-2 py-0.5 border text-[11px] font-bold cursor-pointer transition-colors ${
              terminalMode
                ? 'bg-[#d29922]/20 border-[#d29922] text-[#f2cc60]'
                : 'bg-[#11151e] border-[#1c2436] text-[#8b949e] hover:text-[#e6edf3]'
            }`}
          >
            {terminalMode ? 'TERMINAL ON' : 'GUI MODE'}
          </button>
        </div>
      </div>

      {/* Benchmark Ticker Ribbon */}
      <div className="flex items-center space-x-6 px-3 py-1 bg-[#0a0d12] overflow-x-auto text-[11px] no-scrollbar text-[#8b949e]">
        <div className="flex items-center space-x-1.5 shrink-0">
          <span className="font-semibold text-[#e6edf3]">SOFR</span>
          <span className="text-[#38bdf8] font-mono">4.180%</span>
          <span className="text-[#238636] text-[10px]">-0.02</span>
        </div>
        <div className="flex items-center space-x-1.5 shrink-0">
          <span className="font-semibold text-[#e6edf3]">EUR/USD</span>
          <span className="text-[#e6edf3] font-mono">1.1742</span>
          <span className="text-[#238636] text-[10px]">+0.0018</span>
        </div>
        <div className="flex items-center space-x-1.5 shrink-0">
          <span className="font-semibold text-[#e6edf3]">USD/JPY</span>
          <span className="text-[#e6edf3] font-mono">147.82</span>
          <span className="text-[#da3633] text-[10px]">+0.42</span>
        </div>
        <div className="flex items-center space-x-1.5 shrink-0">
          <span className="font-semibold text-[#e6edf3]">SPX</span>
          <span className="text-[#e6edf3] font-mono">6,482.12</span>
          <span className="text-[#238636] text-[10px]">+18.40</span>
        </div>
        <div className="flex items-center space-x-1.5 shrink-0">
          <span className="font-semibold text-[#e6edf3]">UST 10Y</span>
          <span className="text-[#e6edf3] font-mono">4.020%</span>
          <span className="text-[#da3633] text-[10px]">+0.03</span>
        </div>
        <div className="flex items-center space-x-1.5 shrink-0">
          <span className="font-semibold text-[#e6edf3]">VIX</span>
          <span className="text-[#e6edf3] font-mono">18.42</span>
          <span className="text-[#238636] text-[10px]">-0.85</span>
        </div>
        <div className="flex items-center space-x-1.5 shrink-0">
          <span className="font-semibold text-[#e6edf3]">CDX IG</span>
          <span className="text-[#e6edf3] font-mono">52.4bp</span>
          <span className="text-[#238636] text-[10px]">-0.8bp</span>
        </div>
      </div>
    </header>
  );
};
