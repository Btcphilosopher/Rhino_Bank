import React, { useState } from 'react';
import { Trade, LifecycleState } from '../types';
import { GitCommit, ArrowRight, Play, CheckCircle2, RefreshCw } from 'lucide-react';

interface LifecycleEngineViewProps {
  trades: Trade[];
}

export const LifecycleEngineView: React.FC<LifecycleEngineViewProps> = ({ trades }) => {
  const selectedTrade = trades[0]; // $100M 5Y USD IRS
  const [currentState, setCurrentState] = useState<LifecycleState>(selectedTrade?.state || 'ACTIVE');
  const [eventHistory, setEventHistory] = useState<Array<{ event: string; timestamp: string; details: string }>>([
    { event: 'TRADE_EXECUTION', timestamp: '2026-09-22T08:14:02Z', details: 'Trade executed at 4.1200% fixed vs SOFR' },
    { event: 'LEGAL_CONFIRMATION', timestamp: '2026-09-22T08:14:05Z', details: 'ISDA CDM JSON IR generated and signed' },
    { event: 'INITIAL_MARGIN_POSTED', timestamp: '2026-09-22T08:15:00Z', details: '$8,210,000 USD Cash collateral pledged' }
  ]);

  const lifecycleStages: LifecycleState[] = [
    'DRAFT',
    'QUOTED',
    'EXECUTED',
    'CONFIRMED',
    'ACTIVE',
    'RESET',
    'PAYMENT',
    'MATURITY',
    'SETTLED'
  ];

  const handleAdvanceState = () => {
    const currentIndex = lifecycleStages.indexOf(currentState);
    if (currentIndex < lifecycleStages.length - 1) {
      const nextState = lifecycleStages[currentIndex + 1];
      setCurrentState(nextState);

      const eventNames: Record<string, string> = {
        RESET: 'SOFR_INDEX_FIXING_RESET',
        PAYMENT: 'QUARTERLY_CASH_FLOW_SETTLEMENT',
        MATURITY: 'CONTRACT_EXPIRATION_MATURITY',
        SETTLED: 'FINAL_NET_SETTLEMENT_COMPLETE'
      };

      setEventHistory(prev => [
        {
          event: eventNames[nextState] || `STATE_TRANSITION_${nextState}`,
          timestamp: new Date().toISOString(),
          details: `Contract transitioned from ${currentState} to ${nextState}`
        },
        ...prev
      ]);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <GitCommit className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="font-bold text-[#e6edf3] text-sm uppercase">ISDA CDM EXECUTABLE LIFECYCLE STATE MACHINE</h2>
        </div>
        <button
          onClick={handleAdvanceState}
          className="px-3 py-1.5 bg-[#1b2a20] hover:bg-[#253d2d] text-[#238636] border border-[#2e5239] font-bold cursor-pointer flex items-center space-x-1.5"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>ADVANCE ONE LIFECYCLE EVENT</span>
        </button>
      </div>

      {/* Selected Trade Header Info */}
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 flex flex-wrap justify-between items-center text-[11px]">
        <div>
          <span className="text-[#8b949e]">TRADE ID:</span>
          <span className="font-bold text-[#38bdf8] ml-2">{selectedTrade?.id}</span>
        </div>
        <div>
          <span className="text-[#8b949e]">PRODUCT:</span>
          <span className="font-bold text-[#e6edf3] ml-2">{selectedTrade?.product} (${(selectedTrade?.notional || 0) / 1000000}M {selectedTrade?.currency})</span>
        </div>
        <div>
          <span className="text-[#8b949e]">COUNTERPARTY:</span>
          <span className="font-bold text-[#e6edf3] ml-2">{selectedTrade?.counterparty}</span>
        </div>
        <div>
          <span className="text-[#8b949e]">CURRENT STATE:</span>
          <span className="bg-[#182232] text-[#38bdf8] border border-[#2c3e5a] px-2 py-0.5 font-bold ml-2">
            {currentState}
          </span>
        </div>
      </div>

      {/* State Machine Visualizer Bar */}
      <div className="bg-[#0f141d] border border-[#1c2436] p-4 space-y-2">
        <div className="text-[10px] text-[#8b949e] uppercase font-bold">STATE MACHINE TIMELINE</div>
        <div className="flex items-center justify-between overflow-x-auto py-2">
          {lifecycleStages.map((st, idx) => {
            const isActive = st === currentState;
            const isPassed = lifecycleStages.indexOf(st) < lifecycleStages.indexOf(currentState);

            return (
              <React.Fragment key={st}>
                <div className={`flex flex-col items-center px-2 py-1.5 border min-w-20 text-center transition-all ${
                  isActive
                    ? 'bg-[#182638] text-[#38bdf8] border-[#38bdf8] shadow-[0_0_10px_rgba(56,189,248,0.2)] font-bold'
                    : isPassed
                    ? 'bg-[#121a24] text-[#238636] border-[#1e2e22]'
                    : 'bg-[#0b0e14] text-[#8b949e] border-[#182030]'
                }`}>
                  <span className="text-[9px]">{st}</span>
                  {isPassed && <CheckCircle2 className="w-3 h-3 text-[#238636] mt-1" />}
                </div>
                {idx < lifecycleStages.length - 1 && (
                  <ArrowRight className={`w-3.5 h-3.5 shrink-0 ${isPassed ? 'text-[#238636]' : 'text-[#222c3d]'}`} />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* ISDA CDM Event Sourcing Log */}
      <div className="bg-[#0f141d] border border-[#1c2436] p-3 space-y-2">
        <div className="font-bold text-[#e6edf3] border-b border-[#1c2436] pb-2 flex justify-between">
          <span>IMMUTABLE ISDA CDM EVENT SOURCING LOG</span>
          <span className="text-[#8b949e] text-[10px]">{eventHistory.length} AUDITED EVENTS</span>
        </div>

        <div className="space-y-1.5 max-h-60 overflow-y-auto">
          {eventHistory.map((ev, i) => (
            <div key={i} className="bg-[#0b0e14] p-2 border border-[#182030] flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className="text-[#38bdf8] font-bold text-[10px]">{ev.event}</span>
                <span className="text-[#e6edf3]">{ev.details}</span>
              </div>
              <span className="text-[#8b949e] text-[10px]">{ev.timestamp}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
