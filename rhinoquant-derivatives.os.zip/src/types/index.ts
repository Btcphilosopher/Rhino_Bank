export type ProductType = 
  | 'InterestRateSwap'
  | 'OIS'
  | 'BasisSwap'
  | 'FRA'
  | 'InterestRateFuture'
  | 'Cap'
  | 'Floor'
  | 'Swaption'
  | 'BondFuture'
  | 'FXForward'
  | 'FXFuture'
  | 'FXSwap'
  | 'CurrencySwap'
  | 'FXOption'
  | 'BarrierOption'
  | 'DigitalOption'
  | 'EquityFuture'
  | 'EquityOption'
  | 'VarianceSwap'
  | 'CDS'
  | 'IndexCDS'
  | 'CommodityFuture'
  | 'CommodityOption'
  | 'Autocall';

export type AssetClass = 'RATES' | 'FX' | 'EQUITY' | 'CREDIT' | 'COMMODITIES' | 'STRUCTURED';

export type TradeDirection = 'PAY_FIXED' | 'RECEIVE_FIXED' | 'BUY' | 'SELL' | 'LONG' | 'SHORT';

export type LifecycleState = 
  | 'DRAFT'
  | 'QUOTED'
  | 'NEGOTIATED'
  | 'EXECUTED'
  | 'CONFIRMED'
  | 'EFFECTIVE'
  | 'ACTIVE'
  | 'RESET'
  | 'PAYMENT'
  | 'MATURITY'
  | 'SETTLED'
  | 'AMENDED'
  | 'NOVATED'
  | 'COMPRESSED'
  | 'EARLY_TERMINATED'
  | 'DEFAULTED'
  | 'DISPUTED';

export type SettlementType = 'CASH' | 'PHYSICAL';
export type MarginType = 'BILATERAL' | 'CLEARED' | 'NONE';
export type DayCount = 'ACT/360' | 'ACT/365' | '30/360' | 'ACT/ACT';

export interface UnderlyingAsset {
  id: string;
  symbol: string;
  name: string;
  assetClass: AssetClass;
  spot: number;
  bid: number;
  ask: number;
  change24h: number;
  volatility: number;
  volume: number;
  openInterest: number;
  currency: string;
}

export interface YieldCurvePoint {
  tenor: string;
  years: number;
  zeroRate: number; // percentage, e.g., 4.18
  discountFactor: number;
  forwardRate: number;
  dv01Per100M: number;
}

export interface YieldCurve {
  id: string;
  currency: string;
  benchmarkIndex: string; // e.g. SOFR, SONIA, €STR
  points: YieldCurvePoint[];
}

export interface VolatilityPoint {
  tenor: string;
  strike: number;
  moneyness: string; // e.g., 'ATM', '90% OTM', '110% ITM'
  impliedVol: number; // percentage, e.g. 18.5
}

export interface ContractIR {
  id: string;
  product: ProductType;
  currency: string;
  notional: number;
  fixedRate?: number;
  floatingIndex?: string;
  strike?: number;
  optionType?: 'CALL' | 'PUT';
  exerciseStyle?: 'EUROPEAN' | 'AMERICAN' | 'BERMUDAN';
  paymentFrequency: 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL';
  effectiveDate: string;
  maturityDate: string;
  dayCount: DayCount;
  settlement: SettlementType;
  collateralAsset: string;
  marginType: MarginType;
  counterparty: string;
  book: string;
}

export interface TradeGreeks {
  dv01: number;
  pv01: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
  vanna?: number;
  volga?: number;
  cs01?: number;
}

export interface CashFlow {
  id: string;
  paymentDate: string;
  legAAmount: number;
  legBAmount: number;
  netAmount: number;
  currency: string;
  status: 'PROJECTED' | 'FIXED' | 'SETTLED';
  description: string;
}

export interface Trade {
  id: string;
  tradeDate: string;
  effectiveDate: string;
  maturityDate: string;
  product: ProductType;
  underlyingSymbol: string;
  direction: TradeDirection;
  notional: number;
  currency: string;
  fixedRate?: number;
  floatingIndex?: string;
  strike?: number;
  executionPrice: number;
  counterparty: string;
  trader: string;
  book: string;
  desk: string;
  venue: string;
  state: LifecycleState;
  mtm: number;
  pnl: number;
  realizedPnl: number;
  unrealizedPnl: number;
  initialMargin: number;
  variationMargin: number;
  greeks: TradeGreeks;
  ir: ContractIR;
  cashFlows: CashFlow[];
}

export interface PreTradeCheckResult {
  limitCheck: 'PASS' | 'WARN' | 'FAIL';
  counterpartyCheck: 'PASS' | 'WARN' | 'FAIL';
  liquidityCheck: 'PASS' | 'WARN' | 'FAIL';
  marginCheck: 'PASS' | 'WARN' | 'FAIL';
  collateralCheck: 'PASS' | 'WARN' | 'FAIL';
  modelCheck: 'PASS' | 'WARN' | 'FAIL';
  complianceCheck: 'PASS' | 'WARN' | 'FAIL';
  overall: boolean;
  notes: string[];
}

export interface Counterparty {
  id: string;
  name: string;
  legalEntity: string;
  rating: string; // Fictional credit assessment
  creditLimit: number;
  currentExposure: number;
  potentialFutureExposure: number;
  initialMarginPosted: number;
  variationMarginPosted: number;
  nettingSetId: string;
  csaType: 'ISDA 2016 VM CSA' | 'ISDA 2018 IM CSA';
}

export interface CollateralAsset {
  id: string;
  assetName: string;
  type: 'CASH' | 'GOVT_BOND' | 'CORP_BOND' | 'EQUITY';
  currency: string;
  marketValue: number;
  haircut: number; // percentage e.g. 2.5%
  eligibleValue: number;
  pledged: number;
  available: number;
  counterparty: string;
}

export interface LedgerEntry {
  id: string;
  timestamp: string;
  debitAccount: string;
  creditAccount: string;
  amount: number;
  currency: string;
  referenceId: string;
  description: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: string;
  objectType: string;
  objectId: string;
  oldState?: string;
  newState?: string;
  signature: string;
}

export interface SurveillanceAlert {
  id: string;
  timestamp: string;
  severity: 'HIGH' | 'MEDIUM' | 'LOW';
  alertType: 'LIMIT_BREACH' | 'UNUSUAL_VOLUME' | 'PRICE_ANOMALY' | 'MODEL_DIVERGENCE' | 'COUNTERPARTY_EXPOSURE';
  description: string;
  tradeId?: string;
  status: 'OPEN' | 'INVESTIGATING' | 'RESOLVED';
}

export interface StressScenario {
  id: string;
  name: string;
  rateShiftBp: number;
  volShiftPercent: number;
  fxShiftPercent: number;
  equityShiftPercent: number;
  creditSpreadShiftBp: number;
}
