import { ContractIR } from '../types';

export interface CodeGenOutput {
  solidity: string;
  rust: string;
  typescript: string;
  python: string;
  parityClauses: {
    clauseNumber: string;
    clauseTitle: string;
    irProperty: string;
    executableRule: string;
    testFunction: string;
  }[];
}

export function compileContractToCode(ir: ContractIR): CodeGenOutput {
  const notionalStr = ir.notional.toLocaleString('en-US');
  const fixedRateBps = ir.fixedRate ? (ir.fixedRate * 10000).toFixed(0) : '0';

  const solidity = `// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.20;

/**
 * @title RhinoQuant Executable Derivative Contract
 * @dev ISDA CDM Compliant State Machine for Trade ID #${ir.id}
 */
contract RhinoQuantDerivativeContract {
    enum LifecycleState { DRAFT, QUOTED, EXECUTED, CONFIRMED, ACTIVE, RESET, PAYMENT, MATURITY, SETTLED, EARLY_TERMINATED }
    
    struct EconomicTerms {
        string productType;
        string currency;
        uint256 notional;
        uint256 fixedRateBps;
        string floatingIndex;
        uint256 maturityTimestamp;
        address partyA;
        address partyB;
    }

    LifecycleState public currentState;
    EconomicTerms public terms;
    
    event StateTransition(LifecycleState indexed previousState, LifecycleState indexed newState, uint256 timestamp);
    event SettlementExecuted(address indexed payer, address indexed payee, uint256 amount);

    constructor(address _partyA, address _partyB) {
        terms = EconomicTerms({
            productType: "${ir.product}",
            currency: "${ir.currency}",
            notional: ${ir.notional},
            fixedRateBps: ${fixedRateBps},
            floatingIndex: "${ir.floatingIndex || 'SOFR'}",
            maturityTimestamp: 1947811200, // ${ir.maturityDate}
            partyA: _partyA,
            partyB: _partyB
        });
        currentState = LifecycleState.EXECUTED;
        emit StateTransition(LifecycleState.DRAFT, LifecycleState.EXECUTED, block.timestamp);
    }

    function calculateNetPayment(uint256 floatingRateBps) public view returns (int256 netAmount) {
        int256 fixedPayment = int256((terms.notional * terms.fixedRateBps) / 10000);
        int256 floatingPayment = int256((terms.notional * floatingRateBps) / 10000);
        return floatingPayment - fixedPayment;
    }

    function executePayment(uint256 currentFloatingRateBps) external returns (bool) {
        require(currentState == LifecycleState.ACTIVE || currentState == LifecycleState.RESET, "Invalid State");
        int256 net = calculateNetPayment(currentFloatingRateBps);
        
        currentState = LifecycleState.PAYMENT;
        emit StateTransition(LifecycleState.ACTIVE, LifecycleState.PAYMENT, block.timestamp);
        
        if (net > 0) {
            emit SettlementExecuted(terms.partyB, terms.partyA, uint256(net));
        } else if (net < 0) {
            emit SettlementExecuted(terms.partyA, terms.partyB, uint256(-net));
        }
        
        currentState = LifecycleState.ACTIVE;
        return true;
    }
}`;

  const rust = `// RhinoQuant Rust Executable Engine Token
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum LifecycleState {
    Draft,
    Executed,
    Active,
    Reset,
    Payment,
    Maturity,
    Settled,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EconomicTerms {
    pub product: String,
    pub currency: String,
    pub notional: f64,
    pub fixed_rate: f64,
    pub floating_index: String,
}

pub struct RhinoDerivativeContract {
    pub id: String,
    pub state: LifecycleState,
    pub terms: EconomicTerms,
}

impl RhinoDerivativeContract {
    pub fn new(id: String, notional: f64, fixed_rate: f64) -> Self {
        Self {
            id,
            state: LifecycleState::Executed,
            terms: EconomicTerms {
                product: "${ir.product}".to_string(),
                currency: "${ir.currency}".to_string(),
                notional,
                fixed_rate,
                floating_index: "${ir.floatingIndex || 'SOFR'}".to_string(),
            },
        }
    }

    pub fn calculate_net_cashflow(&self, floating_rate: f64, dt: f64) -> f64 {
        let fixed_leg = self.terms.notional * self.terms.fixed_rate * dt;
        let float_leg = self.terms.notional * floating_rate * dt;
        float_leg - fixed_leg
    }
}`;

  const typescript = `import { ContractIR, LifecycleState } from './types';

export class ExecutableDerivativeContract {
  public state: LifecycleState = 'ACTIVE';

  constructor(public readonly ir: ContractIR) {}

  public calculatePayment(floatingObservedRate: number, dtYears: number = 0.25): number {
    const fixedLeg = this.ir.notional * (this.ir.fixedRate || 0) * dtYears;
    const floatingLeg = this.ir.notional * floatingObservedRate * dtYears;
    return floatingLeg - fixedLeg;
  }

  public advanceState(event: 'RESET' | 'PAYMENT' | 'MATURITY'): LifecycleState {
    if (event === 'RESET') this.state = 'RESET';
    else if (event === 'PAYMENT') this.state = 'PAYMENT';
    else if (event === 'MATURITY') this.state = 'MATURITY';
    return this.state;
  }
}`;

  const python = `class ExecutableDerivativeContract:
    def __init__(self, trade_id: str, notional: float, fixed_rate: float, currency: str = "USD"):
        self.trade_id = trade_id
        self.notional = notional
        self.fixed_rate = fixed_rate
        self.currency = currency
        self.state = "ACTIVE"

    def calculate_net_cash_flow(self, floating_rate: float, dt: float = 0.25) -> float:
        fixed_payment = self.notional * self.fixed_rate * dt
        floating_payment = self.notional * floating_rate * dt
        return floating_payment - fixed_payment

    def process_lifecycle_event(self, event_type: str) -> str:
        self.state = event_type
        return f"Trade {self.trade_id} transitioned to {self.state}"
`;

  return {
    solidity,
    rust,
    typescript,
    python,
    parityClauses: [
      {
        clauseNumber: "Clause 2.1",
        clauseTitle: "Notional Amount & Currency Specification",
        irProperty: `notional: ${notionalStr} ${ir.currency}`,
        executableRule: "terms.notional",
        testFunction: "test_notional_integrity()"
      },
      {
        clauseNumber: "Clause 4.3",
        clauseTitle: "Fixed Rate Payer Obligation",
        irProperty: `fixedRate: ${((ir.fixedRate || 0.0412) * 100).toFixed(4)}%`,
        executableRule: "calculateFixedLegPV()",
        testFunction: "test_fixed_leg_pv()"
      },
      {
        clauseNumber: "Clause 5.1",
        clauseTitle: "Floating Rate Index Observation",
        irProperty: `floatingIndex: ${ir.floatingIndex || 'SOFR'}`,
        executableRule: "observeIndexFixing()",
        testFunction: "test_sofr_fixing()"
      },
      {
        clauseNumber: "Clause 7.2",
        clauseTitle: "Bilateral Margin & Settlement Netting",
        irProperty: `margin: ${ir.marginType}, collateral: ${ir.collateralAsset}`,
        executableRule: "calculateNetPayment()",
        testFunction: "test_margin_netting_settlement()"
      }
    ]
  };
}
