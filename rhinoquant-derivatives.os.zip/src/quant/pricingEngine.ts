import { TradeGreeks, CashFlow, ContractIR, YieldCurve } from '../types';

// Standard normal cumulative distribution function approximation
export function normCdf(x: number): number {
  const b1 = 0.319381530;
  const b2 = -0.356563782;
  const b3 = 1.781477937;
  const b4 = -1.821255978;
  const b5 = 1.330274429;
  const p = 0.2316419;
  const c = 0.3989422804014337; // 1 / sqrt(2 * pi)

  if (x >= 0) {
    const t = 1.0 / (1.0 + p * x);
    return 1.0 - c * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  } else {
    const t = 1.0 / (1.0 - p * x);
    return c * Math.exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1);
  }
}

// Standard normal probability density function
export function normPdf(x: number): number {
  return (1.0 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);
}

// Black-Scholes European Option Pricing & Full Greeks
export function priceBlackScholes(
  spot: number,
  strike: number,
  timeToMaturityYears: number,
  riskFreeRate: number,
  volatility: number,
  isCall: boolean
) {
  const S = spot;
  const K = strike;
  const T = Math.max(0.0001, timeToMaturityYears);
  const r = riskFreeRate;
  const sigma = Math.max(0.001, volatility);

  const d1 = (Math.log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * Math.sqrt(T));
  const d2 = d1 - sigma * Math.sqrt(T);

  let price = 0;
  let delta = 0;

  if (isCall) {
    price = S * normCdf(d1) - K * Math.exp(-r * T) * normCdf(d2);
    delta = normCdf(d1);
  } else {
    price = K * Math.exp(-r * T) * normCdf(-d2) - S * normCdf(-d1);
    delta = normCdf(d1) - 1.0;
  }

  const gamma = normPdf(d1) / (S * sigma * Math.sqrt(T));
  const vega = S * normPdf(d1) * Math.sqrt(T) / 100; // per 1% vol
  const theta = (-(S * normPdf(d1) * sigma) / (2 * Math.sqrt(T)) - (isCall ? r * K * Math.exp(-r * T) * normCdf(d2) : -r * K * Math.exp(-r * T) * normCdf(-d2))) / 365; // daily
  const rho = (isCall ? K * T * Math.exp(-r * T) * normCdf(d2) : -K * T * Math.exp(-r * T) * normCdf(-d2)) / 100; // per 1% rate

  // Second order Greeks
  const vanna = -normPdf(d1) * d2 / sigma;
  const volga = S * normPdf(d1) * Math.sqrt(T) * d1 * d2 / sigma;

  return {
    price: Math.max(0.001, price),
    greeks: {
      delta,
      gamma,
      vega,
      theta,
      rho,
      vanna,
      volga,
      dv01: rho * 10,
      pv01: rho * 10
    } as TradeGreeks
  };
}

// Interest Rate Swap (IRS) Pricing Engine
export function priceInterestRateSwap(
  notional: number,
  fixedRate: number,
  tenorYears: number,
  discountCurve: YieldCurve,
  isPayFixed: boolean
) {
  // Generate cash flow schedule
  const periods = Math.round(tenorYears * 4); // Quarterly payments
  const dt = 0.25; // ACT/360 approx
  let fixedLegPV = 0;
  let floatingLegPV = 0;
  let totalPV01 = 0;

  const cashFlows: CashFlow[] = [];
  const currentDate = new Date('2026-09-22');

  for (let i = 1; i <= periods; i++) {
    const t = i * dt;
    // Find discount factor from yield curve points
    const curvePoint = discountCurve.points.find(p => p.years >= t) || discountCurve.points[discountCurve.points.length - 1];
    const zeroRate = curvePoint ? curvePoint.zeroRate / 100 : 0.0418;
    const df = Math.exp(-zeroRate * t);
    const forwardRate = curvePoint ? curvePoint.forwardRate / 100 : 0.0418;

    const fixedPayment = notional * fixedRate * dt;
    const floatingPayment = notional * forwardRate * dt;

    fixedLegPV += fixedPayment * df;
    floatingLegPV += floatingPayment * df;
    totalPV01 += notional * dt * df;

    const pDate = new Date(currentDate);
    pDate.setMonth(pDate.getMonth() + i * 3);
    const dateStr = pDate.toISOString().split('T')[0];

    cashFlows.push({
      id: `CF-${i}`,
      paymentDate: dateStr,
      legAAmount: isPayFixed ? -fixedPayment : fixedPayment,
      legBAmount: isPayFixed ? floatingPayment : -floatingPayment,
      netAmount: isPayFixed ? (floatingPayment - fixedPayment) : (fixedPayment - floatingPayment),
      currency: discountCurve.currency,
      status: 'PROJECTED',
      description: `Period ${i} Swap Exchange`
    });
  }

  // NPV from pay fixed perspective: PV(Floating) - PV(Fixed)
  const npv = isPayFixed ? (floatingLegPV - fixedLegPV) : (fixedLegPV - floatingLegPV);
  const parRate = totalPV01 > 0 ? floatingLegPV / totalPV01 : fixedRate;
  const dv01 = (totalPV01 / 10000);

  return {
    npv,
    parRate,
    fixedLegPV,
    floatingLegPV,
    dv01,
    pv01: totalPV01,
    cashFlows,
    greeks: {
      dv01,
      pv01: totalPV01,
      delta: dv01 * 100,
      gamma: dv01 * 0.05,
      vega: 0,
      theta: (npv * 0.0001),
      rho: dv01 * 10
    } as TradeGreeks
  };
}

// Monte Carlo Geometric Brownian Motion Engine
export function runMonteCarloSimulation(
  initialSpot: number,
  drift: number,
  volatility: number,
  tenorYears: number,
  numPaths: number = 1000,
  numSteps: number = 252,
  seed: string = 'RHINO-SEED-2026'
) {
  const dt = tenorYears / numSteps;
  const paths: number[][] = [];
  const finalValues: number[] = [];

  // Pseudo-random generator using seed
  let seedNum = 20260922;
  for (let i = 0; i < seed.length; i++) {
    seedNum = (seedNum << 5) - seedNum + seed.charCodeAt(i);
    seedNum |= 0;
  }
  const random = () => {
    seedNum = (seedNum * 9301 + 49297) % 233280;
    return seedNum / 233280;
  };

  const boxMuller = () => {
    let u = 0, v = 0;
    while (u === 0) u = random();
    while (v === 0) v = random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  };

  for (let p = 0; p < Math.min(numPaths, 100); p++) { // Keep 100 visual paths
    const path = [initialSpot];
    let S = initialSpot;
    for (let s = 1; s <= numSteps; s++) {
      const z = boxMuller();
      S = S * Math.exp((drift - 0.5 * volatility * volatility) * dt + volatility * Math.sqrt(dt) * z);
      path.push(S);
    }
    paths.push(path);
    finalValues.push(S);
  }

  finalValues.sort((a, b) => a - b);
  const mean = finalValues.reduce((a, b) => a + b, 0) / finalValues.length;
  const p05 = finalValues[Math.floor(finalValues.length * 0.05)];
  const p50 = finalValues[Math.floor(finalValues.length * 0.50)];
  const p95 = finalValues[Math.floor(finalValues.length * 0.95)];

  return {
    paths,
    mean,
    p05,
    p50,
    p95,
    expectedPayoff: Math.max(0, mean - initialSpot),
    confidenceInterval95: [p05, p95]
  };
}
