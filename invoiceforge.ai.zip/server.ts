import express from "express";
import path from "path";
import { exec } from "child_process";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "20mb" }));

  // API Endpoints
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", engine: "INVOICEFORGE.AI", version: "v4.22.0-STABLE" });
  });

  // Run python demonstration pipeline
  app.post("/api/demo/run", (req, res) => {
    const pyScript = path.join(process.cwd(), "invoiceforge-ai", "main.py");
    exec(`python3 "${pyScript}"`, (error, stdout, stderr) => {
      if (error) {
        console.error("Demo execution error:", stderr);
        return res.status(500).json({ error: "Pipeline execution error", details: stderr || error.message });
      }
      res.json({ success: true, output: stdout });
    });
  });

  // Fetch KPI Metrics
  app.get("/api/metrics", (req, res) => {
    res.json({
      automationRate: 84.2,
      totalQueue: 1204,
      autoApproved: 1014,
      manualReview: 190,
      confidence: 99.82,
      duplicates: 12,
      anomalies: 8,
      nodes: 12,
      memory: "14.4GB / 64GB",
      uptime: "142d 11h"
    });
  });

  // Fetch Models
  app.get("/api/models", (req, res) => {
    res.json([
      { name: "Invoice Extractor", version: "v1.4.2", status: "Production", accuracy: 99.82 },
      { name: "Document Classifier", version: "v1.2.0", status: "Production", accuracy: 98.90 },
      { name: "Supplier Matcher", version: "v2.0.0", status: "Production", accuracy: 98.50 },
      { name: "Duplicate Detector", version: "v1.1.0", status: "Production", accuracy: 99.90 },
      { name: "Anomaly Detector", version: "v1.3.0", status: "Production", accuracy: 96.50 },
      { name: "Payment Matcher", version: "v1.0.2", status: "Production", accuracy: 97.20 }
    ]);
  });

  // Fetch Audit Log
  app.get("/api/audit", (req, res) => {
    res.json([
      { timestamp: "12:04:11.92", action: "AUTO_POST_LEDGER", confidence: "0.999", decision: "SUCCESS", risk: "0.02" },
      { timestamp: "12:03:55.04", action: "ANOMALY_TRIGGER", confidence: "0.824", decision: "QUEUED_REVIEW", risk: "0.58" },
      { timestamp: "12:01:22.48", action: "DUP_DETECTION", confidence: "1.000", decision: "CLEAN", risk: "0.01" },
      { timestamp: "11:58:02.10", action: "THREE_WAY_MATCH", confidence: "0.985", decision: "PASSED", risk: "0.05" }
    ]);
  });

  // Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
