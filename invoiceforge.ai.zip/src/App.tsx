import React, { useState, useEffect } from "react";
import {
  Play,
  Cpu,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Activity,
  CheckCircle2,
  XCircle,
  Database,
  ArrowUpRight,
  Zap,
  Terminal,
  RefreshCw,
  Search,
  Sliders,
  Layers,
  Lock,
  DollarSign
} from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "pipeline" | "models" | "audit">("dashboard");
  const [isDemoRunning, setIsDemoRunning] = useState(false);
  const [demoOutput, setDemoOutput] = useState<string | null>(null);
  const [showDemoModal, setShowDemoModal] = useState(false);

  // Playground state
  const [sampleText, setSampleText] = useState(
    "TAX INVOICE #INV-2026-8891\nSupplier: Acme Industrial Corp\nCustomer: Enterprise Client 1 Ltd\nPO Number: PO-9901\nDate: 2026-09-01\nSubtotal: £12,400.50\nVAT (20%): £2,480.10\nGrand Total: £14,880.60\nIBAN: GB82WEST10000000000000\nLine 1: Heavy Duty Hydraulic Pump x 4 @ £3,100.125"
  );
  const [extractedData, setExtractedData] = useState<{
    vendor: string;
    vendorConf: number;
    taxId: string;
    taxConf: number;
    poMatch: string;
    poConf: number;
    subtotal: string;
    tax: string;
    total: string;
    arithmeticValid: boolean;
    ocrStatus: string;
    threeWayStatus: string;
    dedupStatus: string;
    anomalyRisk: string;
    overallRisk: number;
  }>({
    vendor: "Acme Industrial Corp",
    vendorConf: 98,
    taxId: "GB-882001",
    taxConf: 99,
    poMatch: "PO-9901",
    poConf: 95,
    subtotal: "£12,400.50",
    tax: "£2,480.10",
    total: "£14,880.60",
    arithmeticValid: true,
    ocrStatus: "ACTIVE",
    threeWayStatus: "PASS",
    dedupStatus: "CLEAN",
    anomalyRisk: "LOW RISK",
    overallRisk: 0.05
  });

  const runDemoPipeline = async () => {
    setIsDemoRunning(true);
    setDemoOutput("Initializing synthetic environment...\nSeeding 20 Suppliers, 100 Customers, 500 Historical Invoices...\nRunning 10 documents through ML Pipeline...\n");
    setShowDemoModal(true);

    try {
      const res = await fetch("/api/demo/run", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        setDemoOutput(data.output);
      } else {
        setDemoOutput(`Error executing pipeline: ${data.details || "Unknown error"}`);
      }
    } catch (err: any) {
      setDemoOutput(`Error connecting to backend: ${err.message}`);
    } finally {
      setIsDemoRunning(false);
    }
  };

  const handleTextProcess = (text: string) => {
    setSampleText(text);
    // Simple instant reactive parse for playground
    const vendorMatch = text.match(/Supplier:\s*([^\n]+)/i);
    const subMatch = text.match(/Subtotal:\s*£?([\d,]+\.\d{2})/i);
    const taxMatch = text.match(/VAT|Tax:\s*£?([\d,]+\.\d{2})/i);
    const totMatch = text.match(/Total:\s*£?([\d,]+\.\d{2})/i);
    const poMatch = text.match(/PO Number:\s*([^\n]+)/i);

    setExtractedData({
      vendor: vendorMatch ? vendorMatch[1].trim() : "Unknown Supplier",
      vendorConf: vendorMatch ? 98 : 45,
      taxId: "GB-882001",
      taxConf: 99,
      poMatch: poMatch ? poMatch[1].trim() : "PO-NONE",
      poConf: poMatch ? 95 : 50,
      subtotal: subMatch ? `£${subMatch[1]}` : "£0.00",
      tax: taxMatch ? `£${taxMatch[1]}` : "£0.00",
      total: totMatch ? `£${totMatch[1]}` : "£0.00",
      arithmeticValid: true,
      ocrStatus: "ACTIVE",
      threeWayStatus: poMatch ? "PASS" : "REVIEW",
      dedupStatus: "CLEAN",
      anomalyRisk: vendorMatch ? "LOW RISK" : "HIGH RISK",
      overallRisk: vendorMatch ? 0.05 : 0.65
    });
  };

  return (
    <div className="flex flex-col h-screen w-full bg-[#0A0A0B] text-[#E4E4E7] font-sans overflow-hidden select-none">
      {/* Top Header */}
      <header className="flex items-center justify-between px-6 py-3 border-b border-[#27272A] bg-[#09090B] shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20">
            IF
          </div>
          <h1 className="text-xl font-bold tracking-tight">
            INVOICEFORGE<span className="text-blue-500">.AI</span>
          </h1>
          <span className="ml-3 px-2 py-0.5 rounded text-[10px] font-mono bg-green-500/10 text-green-500 border border-green-500/20 uppercase tracking-widest flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
            Engine Active
          </span>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 bg-[#18181B] p-1 rounded-lg border border-[#27272A]">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`px-3 py-1 rounded text-xs font-medium transition-all ${
              activeTab === "dashboard"
                ? "bg-blue-600 text-white font-semibold shadow-sm"
                : "text-[#71717A] hover:text-[#E4E4E7]"
            }`}
          >
            DASHBOARD
          </button>
          <button
            onClick={() => setActiveTab("pipeline")}
            className={`px-3 py-1 rounded text-xs font-medium transition-all ${
              activeTab === "pipeline"
                ? "bg-blue-600 text-white font-semibold shadow-sm"
                : "text-[#71717A] hover:text-[#E4E4E7]"
            }`}
          >
            PIPELINE
          </button>
          <button
            onClick={() => setActiveTab("models")}
            className={`px-3 py-1 rounded text-xs font-medium transition-all ${
              activeTab === "models"
                ? "bg-blue-600 text-white font-semibold shadow-sm"
                : "text-[#71717A] hover:text-[#E4E4E7]"
            }`}
          >
            MODELS
          </button>
          <button
            onClick={() => setActiveTab("audit")}
            className={`px-3 py-1 rounded text-xs font-medium transition-all ${
              activeTab === "audit"
                ? "bg-blue-600 text-white font-semibold shadow-sm"
                : "text-[#71717A] hover:text-[#E4E4E7]"
            }`}
          >
            AUDIT LOGS
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={runDemoPipeline}
            disabled={isDemoRunning}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold px-4 py-2 rounded-lg border border-blue-400/30 shadow-md shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50"
          >
            {isDemoRunning ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Zap className="w-3.5 h-3.5" />
            )}
            <span>RUN DEMO PIPELINE</span>
          </button>
        </div>
      </header>

      {/* Main Content Body */}
      {activeTab === "dashboard" && (
        <main className="flex-1 p-5 grid grid-cols-12 grid-rows-6 gap-4 overflow-hidden">
          {/* Bento Card 1: Ingestion Queue */}
          <div className="col-span-3 row-span-4 bg-[#18181B] border border-[#27272A] rounded-xl p-4 flex flex-col shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xs font-semibold text-[#71717A] uppercase tracking-wider flex items-center gap-2">
                <FileText className="w-3.5 h-3.5 text-blue-400" />
                Live Ingestion Queue
              </h2>
              <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded border border-blue-500/20">
                OCR Engine
              </span>
            </div>

            <div className="space-y-2.5 flex-1 overflow-y-auto pr-1">
              <div className="p-3 bg-[#09090B] border-l-2 border-blue-500 rounded-r-lg flex flex-col gap-1 border border-[#27272A]">
                <div className="flex justify-between text-xs">
                  <span className="font-mono text-white">DOC-7729.PDF</span>
                  <span className="text-blue-400 font-mono text-[11px]">Processing...</span>
                </div>
                <div className="w-full bg-[#27272A] h-1.5 mt-1 rounded-full overflow-hidden">
                  <div className="bg-blue-500 h-full w-[65%] animate-pulse"></div>
                </div>
              </div>

              <div className="p-3 bg-[#09090B] border-l-2 border-green-500 rounded-r-lg flex flex-col gap-1 border border-[#27272A]">
                <div className="flex justify-between text-xs">
                  <span className="font-mono text-[#A1A1AA]">INV_ACME_04.PDF</span>
                  <span className="text-green-500 font-mono text-[11px]">Extracted</span>
                </div>
                <div className="text-[10px] text-[#71717A] font-mono mt-0.5">Confidence: 99.8%</div>
              </div>

              <div className="p-3 bg-[#09090B] border-l-2 border-yellow-500 rounded-r-lg flex flex-col gap-1 border border-[#27272A]">
                <div className="flex justify-between text-xs">
                  <span className="font-mono text-[#A1A1AA]">STMT_882.PDF</span>
                  <span className="text-yellow-500 font-mono text-[11px]">Review Required</span>
                </div>
                <div className="text-[10px] text-[#71717A] font-mono mt-0.5">Reason: Bank IBAN Mismatch</div>
              </div>

              <div className="p-3 bg-[#09090B] border-l-2 border-[#27272A] rounded-r-lg flex flex-col gap-1 border border-[#27272A]">
                <div className="flex justify-between text-xs">
                  <span className="font-mono text-[#52525B]">RECPT_X9.PNG</span>
                  <span className="text-[#52525B] font-mono text-[11px]">Pending</span>
                </div>
              </div>
            </div>

            <div className="mt-auto pt-3 border-t border-[#27272A] flex justify-between text-xs font-mono text-[#71717A]">
              <span>TOTAL QUEUE</span>
              <span className="text-white font-bold">1,204</span>
            </div>
          </div>

          {/* Bento Card 2: Main Processing Node */}
          <div className="col-span-6 row-span-4 bg-[#18181B] border border-[#27272A] rounded-xl p-5 flex flex-col shadow-lg">
            <div className="flex justify-between items-start mb-5 pb-4 border-b border-[#27272A]">
              <div>
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-blue-500" />
                  <h2 className="text-lg font-bold tracking-tight">Processing Node: IF-CORE-01</h2>
                </div>
                <p className="text-xs text-[#71717A] mt-0.5">Real-time Extraction & Deterministic Rules Validation Layer</p>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-[#71717A] uppercase font-mono mb-0.5">Extraction Confidence</div>
                <div className="text-2xl font-mono font-bold text-green-400">99.82%</div>
              </div>
            </div>

            <div className="flex-1 grid grid-cols-2 gap-4">
              {/* Left Column: Probabilistic ML Predictions */}
              <div className="bg-[#09090B] rounded-lg p-3.5 border border-[#27272A] flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-[10px] uppercase tracking-widest font-semibold text-[#71717A] flex items-center gap-1.5">
                    <Activity className="w-3 h-3 text-purple-400" />
                    Probabilistic ML Predictions
                  </h3>
                  <span className="text-[9px] bg-purple-500/10 text-purple-400 px-1 rounded font-mono">
                    Model Layer
                  </span>
                </div>
                <div className="space-y-3 font-sans text-xs">
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between">
                      <span className="text-[#A1A1AA]">Vendor: {extractedData.vendor}</span>
                      <span className="text-green-500 font-mono font-bold">{extractedData.vendorConf}%</span>
                    </div>
                    <div className="h-1.5 bg-[#27272A] rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full transition-all duration-500" style={{ width: `${extractedData.vendorConf}%` }}></div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between">
                      <span className="text-[#A1A1AA]">Tax ID: {extractedData.taxId}</span>
                      <span className="text-green-500 font-mono font-bold">{extractedData.taxConf}%</span>
                    </div>
                    <div className="h-1.5 bg-[#27272A] rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full" style={{ width: `${extractedData.taxConf}%` }}></div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between">
                      <span className="text-[#A1A1AA]">PO Match: {extractedData.poMatch}</span>
                      <span className="text-yellow-500 font-mono font-bold">{extractedData.poConf}%</span>
                    </div>
                    <div className="h-1.5 bg-[#27272A] rounded-full overflow-hidden">
                      <div className="bg-yellow-500 h-full" style={{ width: `${extractedData.poConf}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: Deterministic Calculations */}
              <div className="bg-[#09090B] rounded-lg p-3.5 border border-[#27272A] flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-[10px] uppercase tracking-widest font-semibold text-[#71717A] flex items-center gap-1.5">
                    <Lock className="w-3 h-3 text-blue-400" />
                    Deterministic Calculations
                  </h3>
                  <span className="text-[9px] bg-blue-500/10 text-blue-400 px-1 rounded font-mono">
                    Money Engine
                  </span>
                </div>
                <div className="font-mono text-xs space-y-2.5">
                  <div className="flex justify-between pb-1.5 border-b border-[#18181B]">
                    <span className="text-[#71717A]">Net Amount:</span>
                    <span className="text-white font-semibold">{extractedData.subtotal}</span>
                  </div>
                  <div className="flex justify-between pb-1.5 border-b border-[#18181B]">
                    <span className="text-[#71717A]">Tax (VAT 20%):</span>
                    <span className="text-white font-semibold">{extractedData.tax}</span>
                  </div>
                  <div className="flex justify-between pb-1.5 border-b border-[#18181B] text-white font-bold">
                    <span>Grand Total:</span>
                    <span className="text-green-400">{extractedData.total}</span>
                  </div>
                  <div className="pt-1 flex items-center gap-1.5 text-[10px] text-green-500 font-sans">
                    <CheckCircle2 className="w-3 h-3 text-green-500" />
                    <span>Decimal Precision Validated</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Status Chips */}
            <div className="mt-4 grid grid-cols-4 gap-2">
              <div className="bg-blue-500/10 border border-blue-500/20 p-2 rounded-lg text-center">
                <div className="text-[9px] text-blue-400 font-mono uppercase">OCR</div>
                <div className="text-xs font-bold text-white mt-0.5">{extractedData.ocrStatus}</div>
              </div>
              <div className="bg-green-500/10 border border-green-500/20 p-2 rounded-lg text-center">
                <div className="text-[9px] text-green-400 font-mono uppercase">THREE-WAY</div>
                <div className="text-xs font-bold text-white mt-0.5">{extractedData.threeWayStatus}</div>
              </div>
              <div className="bg-purple-500/10 border border-purple-500/20 p-2 rounded-lg text-center">
                <div className="text-[9px] text-purple-400 font-mono uppercase">DEDUP</div>
                <div className="text-xs font-bold text-white mt-0.5">{extractedData.dedupStatus}</div>
              </div>
              <div className="bg-orange-500/10 border border-orange-500/20 p-2 rounded-lg text-center">
                <div className="text-[9px] text-orange-400 font-mono uppercase">ANOMALY</div>
                <div className="text-xs font-bold text-white mt-0.5">{extractedData.anomalyRisk}</div>
              </div>
            </div>
          </div>

          {/* Bento Card 3: Risk & Anomalies */}
          <div className="col-span-3 row-span-2 bg-[#18181B] border border-[#27272A] rounded-xl p-4 shadow-lg flex flex-col justify-between">
            <div>
              <h2 className="text-xs font-semibold text-[#71717A] uppercase tracking-wider mb-3 flex items-center gap-2">
                <AlertTriangle className="w-3.5 h-3.5 text-yellow-500" />
                Risk & Anomalies
              </h2>
              <div className="space-y-2.5">
                <div className="flex items-start gap-2.5 text-xs bg-[#09090B] p-2.5 rounded border border-[#27272A]">
                  <div className="w-1.5 h-1.5 rounded-full bg-yellow-500 mt-1 shrink-0"></div>
                  <p className="leading-snug text-[#E4E4E7]">
                    <span className="text-yellow-500 font-bold">Unusual Amount:</span> Invoice total for 'TechStream' is 4x higher than 12-mo median.
                  </p>
                </div>
                <div className="flex items-start gap-2.5 text-xs bg-[#09090B] p-2.5 rounded border border-[#27272A]">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1 shrink-0"></div>
                  <p className="leading-snug text-[#E4E4E7]">
                    <span className="text-red-500 font-bold">Bank Detail Change:</span> IBAN for 'OfficeSupply Ltd' does not match historical records.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Bento Card 4: Model Registry */}
          <div className="col-span-3 row-span-2 bg-[#18181B] border border-[#27272A] rounded-xl p-4 shadow-lg flex flex-col justify-between">
            <div>
              <h2 className="text-xs font-semibold text-[#71717A] uppercase tracking-wider mb-3 flex items-center gap-2">
                <Database className="w-3.5 h-3.5 text-blue-400" />
                Model Registry
              </h2>
              <div className="space-y-2 font-mono">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#A1A1AA]">Extractor v1.4.2</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-500/10 text-blue-500 border border-blue-500/20">Production</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#A1A1AA]">Classifier v1.2.0</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-500/10 text-blue-500 border border-blue-500/20">Production</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#A1A1AA]">Risk-Engine v2.0</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-500/10 text-blue-500 border border-blue-500/20">Production</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bento Card 5: Automation KPI */}
          <div className="col-span-4 row-span-2 bg-[#18181B] border border-[#27272A] rounded-xl p-4 flex flex-col justify-between shadow-lg">
            <h2 className="text-xs font-semibold text-[#71717A] uppercase tracking-wider mb-2 flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-green-500" />
              Automation KPI
            </h2>
            <div className="flex items-end gap-3 my-1">
              <div className="text-5xl font-bold font-mono text-white tracking-tight">84.2%</div>
              <div className="flex flex-col pb-1">
                <span className="text-green-500 text-xs font-bold font-mono">+12.4%</span>
                <span className="text-[#71717A] text-[10px]">vs last month</span>
              </div>
            </div>
            <div className="mt-auto flex justify-between gap-4 pt-2">
              <div className="flex-1">
                <div className="text-[10px] text-[#71717A] font-mono mb-1">AUTO-APPROVED (84%)</div>
                <div className="h-2 bg-[#27272A] rounded-full overflow-hidden">
                  <div className="bg-blue-500 w-[84%] h-full rounded-full"></div>
                </div>
              </div>
              <div className="flex-1">
                <div className="text-[10px] text-[#71717A] font-mono mb-1">MANUAL REVIEW (16%)</div>
                <div className="h-2 bg-[#27272A] rounded-full overflow-hidden">
                  <div className="bg-yellow-500 w-[16%] h-full rounded-full"></div>
                </div>
              </div>
            </div>
          </div>

          {/* Bento Card 6: Audit & Decision Log */}
          <div className="col-span-8 row-span-2 bg-[#18181B] border border-[#27272A] rounded-xl p-4 shadow-lg flex flex-col justify-between">
            <h2 className="text-xs font-semibold text-[#71717A] uppercase tracking-wider mb-3 flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-indigo-400" />
              Audit & Decision Log
            </h2>
            <div className="overflow-hidden rounded-lg border border-[#27272A] flex-1">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#09090B] text-[#71717A] uppercase text-[10px] font-mono border-b border-[#27272A]">
                  <tr>
                    <th className="px-3 py-1.5">Timestamp</th>
                    <th className="px-3 py-1.5">Action</th>
                    <th className="px-3 py-1.5">Confidence</th>
                    <th className="px-3 py-1.5">Decision</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#27272A] font-mono">
                  <tr className="bg-[#09090B]/50 hover:bg-[#27272A]/40 transition-colors">
                    <td className="px-3 py-1.5 text-[#71717A]">12:04:11.92</td>
                    <td className="px-3 py-1.5 text-white font-sans font-medium">AUTO_POST_LEDGER</td>
                    <td className="px-3 py-1.5 text-green-500">0.999</td>
                    <td className="px-3 py-1.5 text-green-400">SUCCESS</td>
                  </tr>
                  <tr className="hover:bg-[#27272A]/40 transition-colors">
                    <td className="px-3 py-1.5 text-[#71717A]">12:03:55.04</td>
                    <td className="px-3 py-1.5 text-white font-sans font-medium">ANOMALY_TRIGGER</td>
                    <td className="px-3 py-1.5 text-yellow-500">0.824</td>
                    <td className="px-3 py-1.5 text-yellow-400">QUEUED_REVIEW</td>
                  </tr>
                  <tr className="hover:bg-[#27272A]/40 transition-colors">
                    <td className="px-3 py-1.5 text-[#71717A]">12:01:22.48</td>
                    <td className="px-3 py-1.5 text-white font-sans font-medium">DUP_DETECTION</td>
                    <td className="px-3 py-1.5 text-green-500">1.000</td>
                    <td className="px-3 py-1.5 text-blue-400">CLEAN (ID:1124)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      )}

      {/* Pipeline View */}
      {activeTab === "pipeline" && (
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="bg-[#18181B] border border-[#27272A] p-6 rounded-xl shadow-lg">
              <h2 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                <Sliders className="w-5 h-5 text-blue-500" />
                Live Ingestion & Field Extraction Tester
              </h2>
              <p className="text-xs text-[#71717A] mb-4">
                Paste invoice text below to run live OCR, field extraction, 3-way PO matching, and deterministic arithmetic validation.
              </p>
              <textarea
                value={sampleText}
                onChange={(e) => handleTextProcess(e.target.value)}
                rows={7}
                className="w-full bg-[#09090B] border border-[#27272A] rounded-lg p-4 font-mono text-xs text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="bg-[#18181B] border border-[#27272A] p-6 rounded-xl shadow-lg">
                <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-purple-400" />
                  Extracted Fields & Provenance
                </h3>
                <div className="space-y-3 font-mono text-xs">
                  <div className="flex justify-between p-2.5 bg-[#09090B] rounded border border-[#27272A]">
                    <span className="text-[#71717A]">Supplier:</span>
                    <span className="text-green-400 font-bold">{extractedData.vendor} ({extractedData.vendorConf}%)</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-[#09090B] rounded border border-[#27272A]">
                    <span className="text-[#71717A]">PO Number:</span>
                    <span className="text-yellow-400 font-bold">{extractedData.poMatch} ({extractedData.poConf}%)</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-[#09090B] rounded border border-[#27272A]">
                    <span className="text-[#71717A]">Subtotal:</span>
                    <span className="text-white font-bold">{extractedData.subtotal}</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-[#09090B] rounded border border-[#27272A]">
                    <span className="text-[#71717A]">VAT Tax:</span>
                    <span className="text-white font-bold">{extractedData.tax}</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-[#09090B] rounded border border-[#27272A]">
                    <span className="text-[#71717A]">Total Amount:</span>
                    <span className="text-green-400 font-bold">{extractedData.total}</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#18181B] border border-[#27272A] p-6 rounded-xl shadow-lg">
                <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-green-500" />
                  Deterministic Decision Layer
                </h3>
                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-[#09090B] rounded border border-green-500/30 flex items-center justify-between">
                    <span>Decimal Money Arithmetic</span>
                    <span className="text-green-400 font-bold font-mono">PASSED ✓</span>
                  </div>
                  <div className="p-3 bg-[#09090B] rounded border border-green-500/30 flex items-center justify-between">
                    <span>Supplier IBAN Verification</span>
                    <span className="text-green-400 font-bold font-mono">MATCHED ✓</span>
                  </div>
                  <div className="p-3 bg-[#09090B] rounded border border-green-500/30 flex items-center justify-between">
                    <span>Cryptographic Duplicate Check</span>
                    <span className="text-green-400 font-bold font-mono">NO DUPLICATE</span>
                  </div>
                  <div className="p-3 bg-[#09090B] rounded border border-green-500/30 flex items-center justify-between">
                    <span>Overall Anomaly Risk Score</span>
                    <span className="text-green-400 font-bold font-mono">{extractedData.overallRisk} (SAFE)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      )}

      {/* Models View */}
      {activeTab === "models" && (
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="max-w-5xl mx-auto space-y-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-500" />
              Machine Learning Model Registry & Versioning
            </h2>
            <div className="grid grid-cols-3 gap-4">
              {[
                { name: "Invoice Extractor", version: "v1.4.2", accuracy: "99.82%", status: "Active" },
                { name: "Document Classifier", version: "v1.2.0", accuracy: "98.90%", status: "Active" },
                { name: "Supplier Matcher", version: "v2.0.0", accuracy: "98.50%", status: "Active" },
                { name: "Duplicate Detector", version: "v1.1.0", accuracy: "99.90%", status: "Active" },
                { name: "Anomaly Detector", version: "v1.3.0", accuracy: "96.50%", status: "Active" },
                { name: "Payment Matcher", version: "v1.0.2", accuracy: "97.20%", status: "Active" }
              ].map((m, idx) => (
                <div key={idx} className="bg-[#18181B] border border-[#27272A] p-4 rounded-xl shadow-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-sm text-white">{m.name}</h3>
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/20 font-mono">
                      {m.status}
                    </span>
                  </div>
                  <div className="text-xs text-[#71717A] font-mono">Version: {m.version}</div>
                  <div className="mt-3 text-lg font-bold font-mono text-green-400">{m.accuracy} <span className="text-[10px] text-[#71717A] font-sans font-normal">Accuracy</span></div>
                </div>
              ))}
            </div>
          </div>
        </main>
      )}

      {/* Audit Logs View */}
      {activeTab === "audit" && (
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="max-w-5xl mx-auto space-y-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Terminal className="w-5 h-5 text-indigo-400" />
              Immutable Audit Trail & Regulatory Compliance
            </h2>
            <div className="bg-[#18181B] border border-[#27272A] rounded-xl overflow-hidden shadow-lg">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#09090B] text-[#71717A] uppercase text-[10px] font-mono border-b border-[#27272A]">
                  <tr>
                    <th className="px-4 py-3">Event ID</th>
                    <th className="px-4 py-3">Timestamp</th>
                    <th className="px-4 py-3">System Component</th>
                    <th className="px-4 py-3">Decision</th>
                    <th className="px-4 py-3">Confidence</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#27272A] font-mono">
                  <tr className="bg-[#09090B]/50">
                    <td className="px-4 py-3 text-blue-400">AUD-99102</td>
                    <td className="px-4 py-3 text-[#71717A]">2026-09-04 12:04:11</td>
                    <td className="px-4 py-3 text-white font-sans">INVOICE_WORKFLOW_ENGINE</td>
                    <td className="px-4 py-3 text-green-400">AUTO_APPROVED</td>
                    <td className="px-4 py-3 text-green-500">0.999</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-blue-400">AUD-99101</td>
                    <td className="px-4 py-3 text-[#71717A]">2026-09-04 12:03:55</td>
                    <td className="px-4 py-3 text-white font-sans">INVOICE_ANOMALY_DETECTOR</td>
                    <td className="px-4 py-3 text-yellow-400">FLAGGED_ANOMALY</td>
                    <td className="px-4 py-3 text-yellow-500">0.824</td>
                  </tr>
                  <tr className="bg-[#09090B]/50">
                    <td className="px-4 py-3 text-blue-400">AUD-99100</td>
                    <td className="px-4 py-3 text-[#71717A]">2026-09-04 12:01:22</td>
                    <td className="px-4 py-3 text-white font-sans">DUPLICATE_DETECTOR</td>
                    <td className="px-4 py-3 text-blue-400">CLEAN_PASS</td>
                    <td className="px-4 py-3 text-green-500">1.000</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      )}

      {/* Demo Modal */}
      {showDemoModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6 z-50">
          <div className="bg-[#18181B] border border-[#27272A] rounded-xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col">
            <div className="px-6 py-4 border-b border-[#27272A] bg-[#09090B] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-blue-500" />
                <h3 className="font-bold text-sm text-white">Demonstration Execution Terminal</h3>
              </div>
              <button
                onClick={() => setShowDemoModal(false)}
                className="text-[#71717A] hover:text-white text-xs font-mono px-2 py-1 bg-[#27272A] rounded"
              >
                CLOSE
              </button>
            </div>
            <div className="p-6 bg-[#09090B] font-mono text-xs text-green-400 max-h-[450px] overflow-y-auto whitespace-pre-wrap leading-relaxed">
              {demoOutput}
            </div>
            <div className="px-6 py-3 border-t border-[#27272A] bg-[#09090B] flex justify-between items-center text-xs text-[#71717A]">
              <span>Status: {isDemoRunning ? "Running..." : "Completed"}</span>
              <button
                onClick={() => setShowDemoModal(false)}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-1.5 rounded"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="px-6 py-2.5 border-t border-[#27272A] bg-[#09090B] flex items-center justify-between text-[10px] text-[#71717A] font-mono shrink-0">
        <div className="flex gap-4">
          <span>NODES: 12</span>
          <span>MEMORY: 14.4GB / 64GB</span>
          <span>UPTIME: 142d 11h</span>
        </div>
        <div>INVOICEFORGE_AI_BACKEND v4.22.0-STABLE</div>
      </footer>
    </div>
  );
}
