def register_model():
    print("Registering model invoice-extractor-v1.4.1 in Model Registry...")
    print("Model registered successfully.")

if __name__ == "__main__":
    register_model()
