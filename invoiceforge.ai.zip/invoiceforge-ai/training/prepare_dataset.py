import json
import os

def prepare_synthetic_dataset():
    """Generates synthetic dataset for classifier and anomaly detection training."""
    os.makedirs("datasets", exist_ok=True)
    dataset = [
        {"text": "INVOICE #1001 Total: 1200.00", "label": "INVOICE"},
        {"text": "CREDIT NOTE #CN-99 Total: -200.00", "label": "CREDIT_NOTE"},
        {"text": "RECEIPT Thank you for your payment $45.00", "label": "RECEIPT"},
        {"text": "PURCHASE ORDER #PO-8810", "label": "PURCHASE_ORDER"},
        {"text": "DELIVERY NOTE Dispatch 10 units", "label": "DELIVERY_NOTE"},
    ]
    with open("datasets/invoice_classification_dataset.json", "w") as f:
        json.dump(dataset, f, indent=2)
    print("Dataset generated at datasets/invoice_classification_dataset.json")

if __name__ == "__main__":
    prepare_synthetic_dataset()
