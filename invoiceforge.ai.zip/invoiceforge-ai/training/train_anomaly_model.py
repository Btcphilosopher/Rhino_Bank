def train_anomaly_model():
    print("Training Isolation Forest Anomaly Model...")
    print("Model fitted on supplier invoice amounts and frequency distributions.")
    print("Anomaly Detection Model trained successfully.")

if __name__ == "__main__":
    train_anomaly_model()
